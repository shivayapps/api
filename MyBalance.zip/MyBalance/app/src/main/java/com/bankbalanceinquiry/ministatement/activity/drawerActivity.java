package com.bankbalanceinquiry.ministatement.activity;

import static com.bankbalanceinquiry.ministatement.inapp.InAppPurchaseHelperKt.PRODUCT_PURCHASED;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.bankbalanceinquiry.ministatement.BuildConfig;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.ui.TrackActivity;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.inapp.InAppPurchaseHelper;
import com.bankbalanceinquiry.ministatement.notification.AlarmUtils;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.DialogUtilKt;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;
import com.bankbalanceinquiry.ministatement.utils.SharedPreferenceClass;

import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.app.ads.helper.AdMobAdsUtilsKt;
import com.example.app.ads.helper.InterstitialAdHelper;
import com.example.app.ads.helper.NativeAdsSize;
import com.example.app.ads.helper.NativeAdvancedModelHelper;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;

public class drawerActivity extends AppCompatActivity implements InAppPurchaseHelper.OnPurchased{

    private AppBarConfiguration mAppBarConfiguration;
    public static NavigationView navigationView;
    public static NavController navController;
    public static TextView navBalance;
    public static String bank_name;
    String bank_change;
    public static Toolbar toolbar;
    public AppBarLayout appBarlayout;
    public DrawerLayout mDrawerLayout;
    public ActionBarDrawerToggle mDrawerToggle;
    private boolean mToolBarNavigationListenerIsRegistered = true;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editorBank;
    FrameLayout ad_view_container;
    Button allow_Permission;
    boolean check = true;
    public static int check1 = 1;
    private FrameLayout adLayout;
    private CardView adcard;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drawer);

        toolbar = findViewById(R.id.toolbar);
        appBarlayout = findViewById(R.id.appBarlayout);
        setSupportActionBar(toolbar);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setHomeAsUpIndicator(getResources().getDrawable(R.drawable.ic_drawer));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().setStatusBarColor(getColor(R.color.app_color));
        }
        allow_Permission = findViewById(R.id.allow_Permission);
        ad_view_container = findViewById(R.id.ad_view_container);
        mDrawerLayout = findViewById(R.id.drawer_layout);

        mDrawerToggle = new ActionBarDrawerToggle(this,
                mDrawerLayout, toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        //mDrawerToggle.syncState();

        mDrawerToggle.setDrawerIndicatorEnabled(false);
        mDrawerToggle.setHomeAsUpIndicator(R.drawable.ic_drawer);
        mDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("mDrawerToggle", "OnClick_DrawerToggle");
                if (mToolBarNavigationListenerIsRegistered) {
                    onBackPressed();
                } else {
                    if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
                        mDrawerLayout.closeDrawer(GravityCompat.START);
                    } else {
                        mDrawerLayout.openDrawer(GravityCompat.START);
                    }
                }
            }
        });
        FirebaseRemoteConfig remoteConfig=FirebaseRemoteConfig.getInstance();
        if(!SharedPreferenceClass.getBoolean(drawerActivity.this, "v_"+BuildConfig.VERSION_CODE,false)) {
            remoteConfig.reset();
            SharedPreferenceClass.setBoolean(drawerActivity.this,"v_"+BuildConfig.VERSION_CODE,true);
        }

        String adShowCount=remoteConfig.getString("adShowCount");
        if(adShowCount.isEmpty()) {
            adShowCount="5";
        }

        String removeAdCount=remoteConfig.getString("removeAdCount");
        if(removeAdCount.isEmpty()) {
            removeAdCount="0";
        }
        AdMobAdsUtilsKt.setAdShowCount(Integer.parseInt(adShowCount));
        AdMobAdsUtilsKt.setRemoveAdCount(Integer.parseInt(removeAdCount));

        adLayout = findViewById(R.id.adLayout);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setItemIconTintList(null);

        View headerView = navigationView.getHeaderView(0);
        navBalance = headerView.findViewById(R.id.textView_balance);

        sharedPreferences = getApplicationContext().getSharedPreferences("bank_select", MODE_PRIVATE);
        editorBank = sharedPreferences.edit();

        //bank_name = sharedPreferences.getString("bank_name", "No Bank");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED) {
                Log.e("Permision==>", "true");
            }
            Log.e("Permision==>", "false");
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECEIVE_SMS}, 100);
        }

        mAppBarConfiguration = new AppBarConfiguration.Builder(R.id.nav_box, R.id.nav_more, R.id.nav_privacy, R.id.nav_cash, R.id.nav_bills)
                .setDrawerLayout(mDrawerLayout)
                .build();

        navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

       /* navController.removeOnDestinationChangedListener(new NavController.OnDestinationChangedListener() {
            @Override
            public void onDestinationChanged(@NonNull NavController controller, @NonNull NavDestination destination, @Nullable Bundle arguments) {
                Toast.makeText(getApplicationContext(), "destination", Toast.LENGTH_SHORT).show();
            }
        });*/

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    /*case R.id.nav_bank_change:
                        navController.navigate(R.id.nav_bank_change);
                        break;*/
                    case android.R.id.home:
                        onBackPressed();
                        break;
//                    case R.id.nav_box:
//                        if (new AdsManager(drawerActivity.this).isNeedToShowAds() && NetworkManager.isInternetConnected(drawerActivity.this)) {
//                            InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) drawerActivity.this, false, new Function1<Boolean, Unit>() {
//                                @Override
//                                public Unit invoke(Boolean aBoolean) {
//                                    navController.navigate(R.id.nav_box);
//                                    return null;
//                                }
//                            });
//                        } else {
//                            navController.navigate(R.id.nav_box);
//                        }
                    case R.id.nav_bank_passbook:
                        if (new AdsManager(drawerActivity.this).isNeedToShowAds() && NetworkManager.isInternetConnected(drawerActivity.this)) {
                            InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) drawerActivity.this, false, new Function1<Boolean, Unit>() {
                                @Override
                                public Unit invoke(Boolean aBoolean) {
                                    navController.navigate(R.id.nav_bank_passbook);
                                    return null;
                                }
                            });
                        } else {
                            navController.navigate(R.id.nav_bank_passbook);
                        }
                        break;
                    case R.id.nav_cash:
                        if (new AdsManager(drawerActivity.this).isNeedToShowAds() && NetworkManager.isInternetConnected(drawerActivity.this)) {
                            InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) drawerActivity.this, false, new Function1<Boolean, Unit>() {
                                @Override
                                public Unit invoke(Boolean aBoolean) {
                                    navController.navigate(R.id.nav_cash);
                                    return null;
                                }
                            });
                        } else {
                            navController.navigate(R.id.nav_cash);
                        }
                        break;
                    case R.id.nav_bills:
                        if (new AdsManager(drawerActivity.this).isNeedToShowAds() && NetworkManager.isInternetConnected(drawerActivity.this)) {
                            InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) drawerActivity.this, false, new Function1<Boolean, Unit>() {
                                @Override
                                public Unit invoke(Boolean aBoolean) {
                                    navController.navigate(R.id.nav_bills);
                                    return null;
                                }
                            });
                        } else {
                            navController.navigate(R.id.nav_bills);
                        }
                        break;
                    case R.id.nav_upgrade:
                        InAppPurchaseHelper.Companion.getInstance().purchaseProductFromJava(PRODUCT_PURCHASED,false);
                        break;
                    case R.id.nav_privacy:
                        //showRateDailog();
//                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(getResources().getString(R.string.privacy_policy)));
//                        if (i.resolveActivity(getPackageManager()) != null) {
//                            startActivity(i);
//                        }

                        new CustomTabsIntent.Builder().build().launchUrl(drawerActivity.this, Uri.parse(getString(R.string.privacy_policy)));

                        break;
                    case R.id.nav_rate:
                        showRateDailog(false);
                        break;
                    case R.id.nav_share:
                        showShareDialog();
                        break;
                }
                mDrawerLayout.closeDrawer(GravityCompat.START);
                return false;
            }
        });

        enableViews(false);

        navController.addOnDestinationChangedListener(new NavController.OnDestinationChangedListener() {
            @Override
            public void onDestinationChanged(@NonNull NavController controller, @NonNull NavDestination destination, @Nullable Bundle arguments) {
                bank_name = sharedPreferences.getString("bank_name", "No Bank");
                if (destination.getId() == R.id.nav_bills) {
                    // check1 = 2;
                    check1 = 1;
                    adLayout.setVisibility(View.GONE);
                } else if (destination.getId() == R.id.nav_cash) {
                    // check1 = 2;
                    check1 = 1;
                    adLayout.setVisibility(View.GONE);
                }
//                else if (destination.getId() != R.id.nav_box) {
//                    mDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            onBackPressed();
//                        }
//                    });
//                }
                else if (destination.getId() == R.id.nav_box) {
                    adLayout.setVisibility(View.GONE);
                    if (bank_name.matches("No Bank")) {
                        toolbar.setTitle("");
                        check1 = 1;
                    } else {
                        toolbar.setTitle(bank_name);
                        check1 = 1;
                    }
                    enableViews(false);
                } else if (destination.getId() == R.id.nav_bank_passbook) {
                    adLayout.setVisibility(View.GONE);
                    toolbar.setTitle(bank_name);
                    check1 = 1;
                    enableViews(true);
                } else if (destination.getId() == R.id.nav_send_money) {
                    adLayout.setVisibility(View.GONE);
                    check1 = 1;
                    toolbar.setTitle(bank_name);
                    enableViews(true);
                } else if (destination.getId() == R.id.nav_sms_banking) {
                    adLayout.setVisibility(View.GONE);
                    check1 = 1;
                    toolbar.setTitle(bank_name);
                    enableViews(true);
                } else if (destination.getId() == R.id.nav_bank_balnce) {
                    adLayout.setVisibility(View.GONE);
                    check1 = 1;
                    toolbar.setTitle(bank_name);
                    enableViews(true);
                } else if (destination.getId() == R.id.nav_bank_ussd) {
                    adLayout.setVisibility(View.GONE);
                    check1 = 1;
                    toolbar.setTitle(bank_name);
                    enableViews(true);
                } else if (destination.getId() == R.id.nav_epf_service) {
                    adLayout.setVisibility(View.GONE);
                    check1 = 1;
                    toolbar.setTitle(bank_name);
                    enableViews(true);
                }
//                else if (destination.getId() == R.id.nav_bank_emi) {
//                    adLayout.setVisibility(View.GONE);
//                    check1 = 1;
//                    toolbar.setTitle(bank_name);
//                    enableViews(true);
//                }
                /*else if (destination.getId() == R.id.nav_bank_change) {
                    adLayout.setVisibility(View.VISIBLE);
                    check1 = 1;
                    Log.e("Value3--)", "" + check1);
                    toolbar.setTitle(R.string.menu_change);
                    enableViews(true);
                }*/
                /*else if (destination.getId() == R.id.nav_share) {
                    adLayout.setVisibility(View.VISIBLE);
                    check1 = 1;
                    showShareDialog();
                    //toolbar.setTitle(R.string.menu_change);
                }*/
                /*else if (destination.getId() == R.id.nav_rate) {
                    adLayout.setVisibility(View.VISIBLE);
                    check1 = 1;
                    showRateDailog();
                    //toolbar.setTitle(R.string.menu_change);
                }*/
            }
        });


        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    InAppPurchaseHelper.Companion.getInstance().initBillingClient(drawerActivity.this, drawerActivity.this);
                } catch (Exception e) {
                    Log.e("mTAG", "initBillingClient: " + e.getMessage());
                }
            }
        });


        Calendar calendar = Calendar.getInstance();
        AlarmUtils alarmUtils = new AlarmUtils(this);
        alarmUtils.initRepeatingAlarm(calendar);

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

    }


    private void enableViews(boolean enable) {

        if (enable) {/*
            mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
            mDrawerToggle.setDrawerIndicatorEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(getResources().getDrawable(R.drawable.iv_back));*/
            if (!mToolBarNavigationListenerIsRegistered) {
                /*mDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onBackPressed();
                    }
                });
*/
                mToolBarNavigationListenerIsRegistered = true;
            }

        } else {
           /* mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            getSupportActionBar().setHomeAsUpIndicator(getResources().getDrawable(R.drawable.ic_drawer));
            mDrawerToggle.setDrawerIndicatorEnabled(true);
            mDrawerToggle.setToolbarNavigationClickListener(null);*/
            mToolBarNavigationListenerIsRegistered = false;
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //getMenuInflater().inflate(R.menu.drawer, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                //loadAds.showFullAd(1);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
        //return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        //return NavigationUI.navigateUp(navController, mAppBarConfiguration) ||
        return super.onSupportNavigateUp();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //mDrawerToggle.setDrawerIndicatorEnabled(true);
        bank_name = sharedPreferences.getString("bank_name", "Select Bank");
        toolbar.setTitle(bank_name);
    }

    @Override
    public void onBackPressed() {
        Log.e("onBackPressed", "01_getNavigatorName:" + navController.getCurrentDestination().getNavigatorName());
        Log.e("onBackPressed", "01_getLabel:" + navController.getCurrentDestination().getLabel());

        String current = navController.getCurrentDestination().getLabel().toString();
        if (current.equalsIgnoreCase("select bank")) {
            if (!SharedPreferenceClass.getBoolean(drawerActivity.this, "apprate", false))
                showRateDailog(true);
            else
                askAlertDialog(drawerActivity.this, "Do you want to exit.?", "Press YES to Exit or NO to Cancel",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finishAffinity();
                            }
                        },
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //finishAffinity();
                            }
                        });
        } else {
            super.onBackPressed();
        }
        /*if (check1 == 0) {
            showRateDailog();
        } else if (check1 == 1) {
            super.onBackPressed();
        } else {
            finish();
        }*/
        Log.e("onBackPressed", "02_getNavigatorName:" + navController.getCurrentDestination().getNavigatorName());
        Log.e("onBackPressed", "02_getLabel:" + navController.getCurrentDestination().getLabel());
    }

    private void showShareDialog() {

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.app_description) + "\n" + getResources().getString(R.string.app_short_link));
        startActivity(shareIntent);
    }

    public static void reportBug(Context context, String subject, String errorMessage, float ratingValue) {

        // Get App Version
        PackageInfo pInfo = null;
        try {
            pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        String version = pInfo.versionName;

        // Device Name
        String deviceName = Build.MANUFACTURER + " " + Build.MODEL;

        // OS Version
        String osVersion = Build.VERSION.RELEASE;
        int osAPI = Build.VERSION.SDK_INT;

        // Get Country Name
        String country = "";
        try {
            TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            String countryCode = "";
            if (tm != null) {
                countryCode = tm.getNetworkCountryIso();
            }
            Locale loc = new Locale("", countryCode);
            country = loc.getDisplayCountry();
        } catch (Exception e) {
            e.printStackTrace();
        }

        HashMap<String, Boolean> mapPermission = new HashMap<>();

        //Intent email = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto", "appguru34@gmail.com", null));
        //email.putExtra(Intent.EXTRA_SUBJECT, subject);

        Iterator<Map.Entry<String, Boolean>> mIterator = mapPermission.entrySet().iterator();
        String mExtraText = "";
        while (mIterator.hasNext()) {
            Map.Entry<String, Boolean> mEntry = mIterator.next();
            if (mEntry.getKey().trim().length() > 0) {
                mExtraText += (mEntry.getKey() + " : "
                        + (mEntry.getValue() ? "YES" : "NO") + "\n");
            }
        }
        String body = "Your message: " + errorMessage +
                "\r\n" +
                "\r\nRating :" + ratingValue +
                "\r\nDevice Information - " + context.getResources().getString(R.string.app_name) +
                "\r\nVersion : " + version +
                "\r\nDevice Name : " + deviceName +
                "\r\nAndroid API : " + osAPI +
                "\r\nAndroid Version : " + osVersion +
                "\r\nCountry : " + country;
        //"\nExtraText : "+mExtraText;


        subject = subject + " " + context.getResources().getString(R.string.app_name);

        try {

            context.startActivity(
                    Intent.createChooser(
                            new Intent(
                                    Intent.ACTION_SENDTO,
                                    Uri.parse(
                                            "mailto:" + context.getResources().getString(R.string.email)
                                                    + "?cc=&subject=" + Uri.encode(subject).toString()
                                                    + "&body=" + Uri.encode(body)
                                    )
                            ), context.getString(R.string.email_choose_from_client)
                    )
            );

        } catch (ActivityNotFoundException ex) {

        }
    }

    public void showRate(Context mContext) {
        SharedPreferenceClass.setBoolean(mContext, "apprate", true);
        try {
            mContext.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + mContext.getPackageName())));
        } catch (ActivityNotFoundException e) {
            mContext.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + mContext.getPackageName())));
        }
    }


    public static void askAlertDialog(Context context, String title, String message, DialogInterface.OnClickListener positiveListener, DialogInterface.OnClickListener negativeListener) {
        new AlertDialog.Builder(context)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Yes", positiveListener)
                .setNegativeButton("No", negativeListener)
                .show();
    }

    boolean bug = false;
    String feedback = "";

    private void showRateDailog(final boolean isFinish) {
        final View dialogView = View.inflate(drawerActivity.this, R.layout.dialog_say_thanks, null);
        final android.app.AlertDialog.Builder mAlertDialog = new android.app.AlertDialog.Builder(drawerActivity.this)
                .setView(dialogView)
                .setCancelable(true);

        final android.app.AlertDialog mAlertDialog1 = mAlertDialog.create();
        mAlertDialog1.setCancelable(true);
        mAlertDialog1.setCanceledOnTouchOutside(true);
        mAlertDialog1.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        TextView buttonPositive = (TextView) dialogView.findViewById(R.id.btn_rate_now);
        TextView buttonNegative = (TextView) dialogView.findViewById(R.id.btn_later);
        final ImageView img_reaction = (ImageView) dialogView.findViewById(R.id.img_reaction);
        final RatingBar rating_bar = (RatingBar) dialogView.findViewById(R.id.rating_bar);
        final LinearLayout lay_feedback = (LinearLayout) dialogView.findViewById(R.id.lay_feedback);
        final EditText txtfeedback = (EditText) dialogView.findViewById(R.id.txtfeedback);


        rating_bar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (rating == 1) {
                    bug = true;
                    img_reaction.setImageDrawable(getResources().getDrawable(R.drawable.rate_1));
                } else if (rating == 2) {
                    bug = true;
                    img_reaction.setImageDrawable(getResources().getDrawable(R.drawable.rate_2));
                } else if (rating == 3) {
                    bug = true;
                    img_reaction.setImageDrawable(getResources().getDrawable(R.drawable.rate_3));
                } else if (rating == 4) {
                    bug = false;
                    img_reaction.setImageDrawable(getResources().getDrawable(R.drawable.rate_4));
                } else if (rating == 5) {
                    bug = false;
                    img_reaction.setImageDrawable(getResources().getDrawable(R.drawable.rate_5));
                }
            }
        });

        buttonPositive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (bug) {
                    feedback = txtfeedback.getText().toString().trim();
                    reportBug(drawerActivity.this, "Feedback/Suggestion", feedback, rating_bar.getRating());
                    mAlertDialog1.dismiss();
                } else {
                    if (rating_bar.getRating() >= 1 && rating_bar.getRating() < 4) {
                        bug = true;
                        lay_feedback.setVisibility(View.VISIBLE);

                        txtfeedback.requestFocus();
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.showSoftInput(txtfeedback, InputMethodManager.SHOW_IMPLICIT);

                    } else if (rating_bar.getRating() >= 4 && rating_bar.getRating() <= 5) {
                        bug = false;
                        showRate(drawerActivity.this);
                        mAlertDialog1.dismiss();
                    } else if (rating_bar.getRating() == 0.0f) {
                        Snackbar.make(dialogView, getString(R.string.rate_app_zero_star_error), Snackbar.LENGTH_SHORT).show();
                    } else {
                        bug = false;
                        showRate(drawerActivity.this);
                        mAlertDialog1.dismiss();
                    }
                }
            }
        });
        buttonNegative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFinish) {
                    Intent startMain = new Intent(Intent.ACTION_MAIN);
                    startMain.addCategory(Intent.CATEGORY_HOME);
                    startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(startMain);
                    finish();
                }
                mAlertDialog1.dismiss();
            }
        });
        mAlertDialog1.show();


    }

    @Override
    public void onPurchasedSuccess(@NonNull Purchase purchase) {
        DialogUtilKt.showPurchaseSuccess(drawerActivity.this);

    }

    @Override
    public void onProductAlreadyOwn() {

    }

    @Override
    public void onBillingSetupFinished(@NonNull BillingResult billingResult) {
        if(billingResult.getResponseCode()== BillingClient.BillingResponseCode.OK){
            InAppPurchaseHelper.Companion.getInstance().initProductFromJava();
        }
    }

    @Override
    public void onBillingUnavailable() {

    }

    @Override
    public void onBillingKeyNotFound(@NonNull String productId) {

    }
}
