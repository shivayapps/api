package com.bankbalanceinquiry.ministatement.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.amulyakhare.textdrawable.TextDrawable;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;


public class TransactionDetailsActivity extends AppCompatActivity {

    int color, icon;
    RelativeLayout mBarBg;
    private Toolbar toolbar;
    HomeAccoutList allAccountModel;
    private TextView mDesc, mTransactionName, mPayeeName, mDate, mAmount;
    private ImageView mImg;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transection_details);
        mDesc = findViewById(R.id.desc);
        mTransactionName = findViewById(R.id.transaction_name);
        mPayeeName = findViewById(R.id.payee_name);
        mDate = findViewById(R.id.date);
        mAmount = findViewById(R.id.tvTotalAmout);
        mImg = findViewById(R.id.img);
        mBarBg = findViewById(R.id.bar_bg);
        mDesc = findViewById(R.id.desc);
        Intent getdata = getIntent();
        if (getdata != null) {
            allAccountModel = (HomeAccoutList) getdata.getSerializableExtra("OBJ");
            color = getdata.getIntExtra("color", ContextCompat.getColor(this, R.color.colorPrimary));
            icon = getdata.getIntExtra("icon", -1);
            initToolBar();
            mDesc.setText(allAccountModel.body);
//            mTransactionName.setText(allAccountModel.transactionDesc);
            if (!TextUtils.isEmpty(allAccountModel.finalTransactionDesc)) {
                mPayeeName.setText(allAccountModel.finalTransactionDesc);
            }
            mDate.setText(allAccountModel.dateValHistory);
            mAmount.setText(getString(R.string.Rs) + " " + allAccountModel.amount);
            if (icon != -1) {
                mImg.setImageResource(icon);
            } else {
                String FirstName = allAccountModel.transactionDesc.replaceAll(" ", "");
                if (!TextUtils.isEmpty(FirstName)) {
                    String FirstLetter = FirstName.substring(0, 1);
                    TextDrawable drawable1 = TextDrawable.builder()
                            .buildRound(FirstLetter, ContextCompat.getColor(this, R.color.app_color));
                    mImg.setImageDrawable(drawable1);
                }
            }
        }

    }


    private void initToolBar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(allAccountModel.transactionDesc);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        mBarBg.setBackgroundColor(color);
        toolbar.setBackgroundColor(color);
        int mixColor = mixTwoColors(color, Color.WHITE, 0.5f);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(color);
        }
    }

    private int mixTwoColors(int color1, int color2, float amount) {
        final byte ALPHA_CHANNEL = 24;
        final byte RED_CHANNEL = 16;
        final byte GREEN_CHANNEL = 8;
        final byte BLUE_CHANNEL = 0;

        final float inverseAmount = 1.0f - amount;

        int a = ((int) (((float) (color1 >> ALPHA_CHANNEL & 0xff) * amount) +
                ((float) (color2 >> ALPHA_CHANNEL & 0xff) * inverseAmount))) & 0xff;
        int r = ((int) (((float) (color1 >> RED_CHANNEL & 0xff) * amount) +
                ((float) (color2 >> RED_CHANNEL & 0xff) * inverseAmount))) & 0xff;
        int g = ((int) (((float) (color1 >> GREEN_CHANNEL & 0xff) * amount) +
                ((float) (color2 >> GREEN_CHANNEL & 0xff) * inverseAmount))) & 0xff;
        int b = ((int) (((float) (color1 & 0xff) * amount) +
                ((float) (color2 & 0xff) * inverseAmount))) & 0xff;

        return a << ALPHA_CHANNEL | r << RED_CHANNEL | g << GREEN_CHANNEL | b << BLUE_CHANNEL;
    }
}
