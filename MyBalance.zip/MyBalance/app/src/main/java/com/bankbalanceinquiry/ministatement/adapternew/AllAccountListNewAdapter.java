package com.bankbalanceinquiry.ministatement.adapternew;

import android.app.Activity;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.amulyakhare.textdrawable.TextDrawable;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class AllAccountListNewAdapter extends RecyclerView.Adapter<AllAccountListNewAdapter.MyViewHolder> {
    private Activity activity;
    public ClickActivDeactiveint clickActivDeactiveint;
    private ArrayList<HomeAccoutList> allAccountModels;
    private ArrayList<Integer> colors = new ArrayList<>();


    public interface ClickActivDeactiveint {
        void ClickActiveDeactive(int position, int color);

        void ClickBusinessOrPersion(int position);
    }

    public void RegisterInterface(ClickActivDeactiveint photoInterface) {
        this.clickActivDeactiveint = photoInterface;
    }

    public AllAccountListNewAdapter(Activity activity, ArrayList<HomeAccoutList> listOfAllImages) {
        this.activity = activity;
        this.allAccountModels = listOfAllImages;
        this.colors.add(ContextCompat.getColor(activity, R.color.google_blue));
        this.colors.add(ContextCompat.getColor(activity, R.color.google_red));
        this.colors.add(ContextCompat.getColor(activity, R.color.google_yellow));
        this.colors.add(ContextCompat.getColor(activity, R.color.google_green));
    }

    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(activity).inflate(R.layout.raw_account_list, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        final HomeAccoutList alldata = allAccountModels.get(position);

        String AccountNumber = alldata.FinalAccountNo;

        String date = alldata.dateValAccount;
        String AccountAmount = alldata.FinalAccountBalance;
        String name = alldata.full_name.replace(" Bank", "");
        if (!TextUtils.isEmpty(AccountNumber)) {
            holder.tvBankNameAndAcNo.setText(name + " - " + AccountNumber);
        } else {
            holder.tvBankNameAndAcNo.setText(name);
        }

        if(!alldata.account_type.isEmpty()){
            holder.tvACtype.setText(alldata.account_type.trim());
        }

        Date date2 = new Date(System.currentTimeMillis());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy", Locale.US);
        String year = simpleDateFormat.format(date2);
        String dateVal = date;
        if (date.contains(year)) {
            dateVal = date.replace(" " + year, "");
        }

        holder.tvDate.setText(dateVal);

        if (!TextUtils.isEmpty(AccountAmount)) {
            if (AccountAmount.contains(",")) {
                AccountAmount = AccountAmount.replace(",", "");
            }
            AccountAmount = AccountAmount.replaceAll("[^\\d.]", "");
            double d = Double.parseDouble(AccountAmount);
            if (AccountAmount.contains(".")) {
                String afterPoint = AccountAmount.substring(AccountAmount.indexOf(".") + 1);
                if (afterPoint.length() > 2) {
                    DecimalFormat decim = new DecimalFormat("#,##,###.##");
                    AccountAmount = decim.format(d);
                }
            }
            DecimalFormat decim = new DecimalFormat("#,##,###.#");
            AccountAmount = decim.format(d);

            holder.tvBalanceAndDate.setText(activity.getString(R.string.Rs) + " " + AccountAmount+" as on "+dateVal);
        } else {
            holder.tvBalanceAndDate.setText("");
        }

      /*  if (alldata.getBankIcon() != 0) {
            holder.ivBankLogo.setImageResource(alldata.getBankIcon());

        }*/

        String FirstName = alldata.full_name;
        int color = 0;
        if (!TextUtils.isEmpty(getBankName(alldata.full_name))) {
            int id = activity.getResources().getIdentifier(getBankName(alldata.full_name), "drawable", activity.getPackageName());
            if (id != -1) {
                holder.ivBankLogo.setImageResource(id);
            } else {
                Random rnd = new Random();
                color = colors.get(rnd.nextInt(3));
                if (!TextUtils.isEmpty(FirstName) && !FirstName.equalsIgnoreCase("")) {
                    String FirstLetter = FirstName.substring(0, 1);
                    TextDrawable drawable = TextDrawable.builder()
                            .buildRound(FirstLetter, color);
                    holder.ivBankLogo.setImageDrawable(drawable);
                } else {
                    TextDrawable drawable = TextDrawable.builder()
                            .buildRound("U", color);
                    holder.ivBankLogo.setImageDrawable(drawable);
                }
            }
        } else {
            Random rnd = new Random();
            color = colors.get(rnd.nextInt(3));
            if (!TextUtils.isEmpty(FirstName) && !FirstName.equalsIgnoreCase("")) {
                String FirstLetter = FirstName.substring(0, 1);
                TextDrawable drawable = TextDrawable.builder()
                        .buildRound(FirstLetter, color);
                holder.ivBankLogo.setImageDrawable(drawable);
            } else {
                TextDrawable drawable = TextDrawable.builder()
                        .buildRound("U", color);
                holder.ivBankLogo.setImageDrawable(drawable);
            }
        }


//        Random rnd = new Random();
//        final int color = colors.get(rnd.nextInt(3));

//        int id = activity.getResources().getIdentifier("ic_" +alldata.getB_short().toLowerCase(), "drawable", activity.getPackageName());
//        if (id != -1) {
//            photo_card.setImageResource(id);
//        }

//        int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
//        if (!TextUtils.isEmpty(FirstName) && !FirstName.equalsIgnoreCase("")) {
//            String FirstLetter = FirstName.substring(0, 1);
//            TextDrawable drawable = TextDrawable.builder()
//                    .buildRound(FirstLetter, color);
//            holder.ivBankLogo.setImageDrawable(drawable);
//        } else {
//            TextDrawable drawable = TextDrawable.builder()
//                    .buildRound("U", color);
//            holder.ivBankLogo.setImageDrawable(drawable);
//        }
        final int finalColor = color;
        holder.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (clickActivDeactiveint != null) {
                    clickActivDeactiveint.ClickActiveDeactive(holder.getAdapterPosition(), finalColor);
                }
            }
        });
//        holder.ivActiveInActive.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });
//
//        holder.rlPersonBusiness.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (clickActivDeactiveint != null) {
//                    clickActivDeactiveint.ClickBusinessOrPersion(holder.getAdapterPosition());
//                }
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return allAccountModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private LinearLayout llMain;
        private ImageView ivBankLogo;
        private TextView tvBankNameAndAcNo;
        private TextView tvBalanceAndDate, tvDate,tvACtype;

//        private ImageView ivActiveInActive;
//        private TextView tvActiveInActive;
//
//        private RelativeLayout rlPersonBusiness;
//        private ImageView ivBusinessOrPersion;
//        private TextView tvBusinessOrPersion;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            llMain = itemView.findViewById(R.id.llMain);
            ivBankLogo = itemView.findViewById(R.id.ivBankLogo);
            tvBankNameAndAcNo = itemView.findViewById(R.id.tvBankNameAndAcNo);
            tvACtype = itemView.findViewById(R.id.tvACtype);
            tvDate = itemView.findViewById(R.id.tvDDate);
            tvBalanceAndDate = itemView.findViewById(R.id.tvBalanceAndDate);

//            ivActiveInActive = itemView.findViewById(R.id.ivActiveInActive);
//            tvActiveInActive = itemView.findViewById(R.id.tvActiveInActive);
//
//            rlPersonBusiness = itemView.findViewById(R.id.rlPersonBusiness);
//            ivBusinessOrPersion = itemView.findViewById(R.id.ivBusinessOrPersion);
//            tvBusinessOrPersion = itemView.findViewById(R.id.tvBusinessOrPersion);
        }
    }


    private String getBankName(String name) {

        switch (name) {
            case "Allahabad Bank":
                return "ic_alb";
            case "American Express":
                return "ic_aeb";
            case "Andhra Bank":
                return "ic_anb";
            case "Axis Bank":
                return "ic_axb";
            case "Bank of Baroda":
                return "ic_bob";
            case "Bank of India":
                return "ic_boi";
            case "Bank of Maharashtra":
                return "ic_bom";
            case "Corporation Bank":
                return "ic_crb";
            case "Canara Bank":
                return "ic_cnb";
            case "Citibank":
                return "ic_cb";
            case "Deutsche Bank":
                return "ic_db";
            case "Federal Bank":
                return "ic_fbl";
            case "HDFC Bank":
                return "ic_hdf";
            case "HSBC":
                return "ic_hsb";
            case "ICICI Bank":
                return "ic_ici";
            case "IDBI Bank":
                return "ic_idb";
            case "Indian Bank":
                return "ic_inb";
            case "IndusInd Bank":
                return "ic_iib";
            case "Kotak Mahindra Bank":
                return "ic_kmb";
            case "Punjab National Bank":
                return "ic_pnb";
            case "State Bank of India":
                return "ic_sbi";
            case "Standard Chartered":
                return "ic_scb";
            case "Union Bank of India":
                return "ic_uob";
            case "Yes Bank":
                return "ic_ybl";
            case "Central Bank of India":
                return "ic_cbi";
            case "Vijaya Bank":
                return "ic_vjb";
            case "Syndicate Bank":
                return "ic_syb";
            case "Indian Overseas Bank":
                return "ic_iob";
            case "South Indian Bank":
                return "ic_sib";
            case "City Union Bank":
                return "ic_cub";
            case "Saraswat Bank":
                return "ic_src";
            case "United Bank of India":
                return "ic_ubi";
            case "Dhanlaxmi Bank":
                return "ic_dlb";
            case "Tamilnad Mercantile Bank":
                return "ic_tmb";
            case "IDFC First Bank":
                return "ic_idf";
            case "Karnataka Bank":
                return "ic_ktb";
            case "Punjab & Sind Bank":
                return "ic_psb";
            case "Bandhan Bank":
                return "ic_band";
            default:
                return "";
        }

    }
}
