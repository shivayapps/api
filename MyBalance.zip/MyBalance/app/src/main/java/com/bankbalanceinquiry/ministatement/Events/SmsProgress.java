package com.bankbalanceinquiry.ministatement.Events;

public class SmsProgress {
    private int progress;

    public SmsProgress(int progress) {
        this.progress = progress;
    }

    public int getProgress() {
        return progress;
    }

    public void setProgress(int progress) {
        this.progress = progress;
    }
}
