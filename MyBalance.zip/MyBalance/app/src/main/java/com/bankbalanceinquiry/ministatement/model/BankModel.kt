package com.bankbalanceinquiry.ministatement.model

data class BankMissCallModel(
    var mBankID: Int,
    var mBankImage: Int,
    var mBankCustomer: String,
    var mBankName: String,
    var mBankBalance: String,
    var mBankMiniStatement: String?,
    var mNetBanking: String?
    )

//data class BankSmsModel(
//    var mBankName: String,
//    var mBankImage: Int,
//    var mBankSmsNumber: String?,
//    var mGetCustomerId: String?,
//    var mSmsBalanceEnq: String?,
//    var mSmsLastTransaction: String?,
//    var mNearestAtm: String?,
//    var mRegisterEStatement: String?,
//    var mGetChequeBook: String?,
//    var mChequeBookStatus: String?,
//    var mLinkAadhaarWithBank: String?,
//    var mUpdateEmail: String?,
//    var mUpdatePan: String?
//)

data class BankSmsModel(
    var mBankName: String,
    var mBankImage: Int,
    var mTitle: String,
    var mMessage: String,
    var mPhone: String
)

data class BankingModel(var mImage: Int, var mText: String)

data class SmsModel(var mText: String, var mPhone: String,var mCode:String,var mInfo:String?)

data class CallModel(var mType: String, var mBalance: String?)

data class StateModel(var mDate: String, var mDay: String, var mHoliday: String)

data class UssdModel(var mIVLeft: Int, var mTVText: String, var mIVRight: Int)

data class ShortBankModel(
    var mTVName: String,
    var mTVShortName: String,
    var mTVCode: String,
    var mTVIFSC: String
)
