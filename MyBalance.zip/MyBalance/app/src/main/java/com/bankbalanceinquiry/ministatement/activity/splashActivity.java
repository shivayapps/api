package com.bankbalanceinquiry.ministatement.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.app.ActivityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.ViewPropertyAnimatorCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.bankbalanceinquiry.ministatement.R;

import com.bankbalanceinquiry.ministatement.activity.ui.TrackActivity;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.inapp.InAppPurchaseHelper;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;
import com.example.app.ads.helper.InterstitialAdHelper;
import com.google.android.material.snackbar.Snackbar;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlinx.coroutines.GlobalScope;


public class splashActivity extends AppCompatActivity implements InAppPurchaseHelper.OnPurchased {


    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
    private static int SPLASH_TIME_OUT = 2000;
    LinearLayout lout_terms;
    CheckBox chkPrivacy;
    TextView tvPrivacyPolicy;
    TextView tvstart;

    public static final int STARTUP_DELAY = 300;
    public static final int ANIM_ITEM_DURATION = 1000;
    public static final int ITEM_DELAY = 300;

    private boolean animationStarted = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_splash);

        if (new AdsManager(splashActivity.this).isNeedToShowAds()) {
            InterstitialAdHelper.INSTANCE.loadInterstitialAd(
                    splashActivity.this,
                    false, new Function0<Unit>() {
                        @Override
                        public Unit invoke() {
                            return null;
                        }
                    });
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().setStatusBarColor(getColor(R.color.white));
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                try {
                    InAppPurchaseHelper.Companion.getInstance().initBillingClient(splashActivity.this, splashActivity.this);
                } catch (Exception e) {
                    Log.e("mTAG", "initBillingClient: " + e.getMessage());
                }
            }
        }); {
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (PreferenceHelper.getFromUserDefaults(getApplicationContext(), Constant.LOGIN_PREF).equals("")) {
                initView();
            } else {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        if (isStoragePermissionGranted()) {

                            if (new AdsManager(splashActivity.this).isNeedToShowAds() && NetworkManager.isInternetConnected(splashActivity.this)) {

                                InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) splashActivity.this, false, new Function1<Boolean, Unit>() {
                                    @Override
                                    public Unit invoke(Boolean aBoolean) {

                                        if (TextUtils.isEmpty(PreferenceHelper.getFromUserDefaults(getApplicationContext(), Constant.TRACK_PREF))) {
                                            Intent i = new Intent(getApplicationContext(), TrackActivity.class);
                                            startActivity(i);
                                            finish();
                                        } else {
                                            Intent i = new Intent(getApplicationContext(), drawerActivity.class);
                                            startActivity(i);
                                            finish();
                                        }
                                        return null;
                                    }
                                });
                            } else {
                                if (TextUtils.isEmpty(PreferenceHelper.getFromUserDefaults(getApplicationContext(), Constant.TRACK_PREF))) {
                                    Intent i = new Intent(getApplicationContext(), TrackActivity.class);
                                    startActivity(i);
                                    finish();
                                } else {
                                    Intent i = new Intent(getApplicationContext(), drawerActivity.class);
                                    startActivity(i);
                                    finish();
                                }
                            }

                        }
                    }
                }, SPLASH_TIME_OUT);
            }
//
        } else {
            if (PreferenceHelper.getFromUserDefaults(getApplicationContext(), Constant.LOGIN_PREF).equals("")) {
                initView();
            } else {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isStoragePermissionGranted()) {
                            if (TextUtils.isEmpty(PreferenceHelper.getFromUserDefaults(getApplicationContext(), Constant.TRACK_PREF))) {
                                Intent i = new Intent(getApplicationContext(), TrackActivity.class);
                                startActivity(i);
                                finish();
                            } else {
                                Intent i = new Intent(getApplicationContext(), drawerActivity.class);
                                startActivity(i);
                                finish();
                            }
                        }
                    }
                }, SPLASH_TIME_OUT);
            }
        }
    }

//    @Override
//    public void onWindowFocusChanged(boolean hasFocus) {
//
//        if (!hasFocus || animationStarted) {
//            return;
//        }
//
//        animate();
//
//        super.onWindowFocusChanged(hasFocus);
//    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }


    private void animate() {
        ImageView logoImageView = findViewById(R.id.appicon);
        ViewGroup container = findViewById(R.id.lout_terms);

        ViewCompat.animate(logoImageView)
                .translationY(-250)
                .setStartDelay(STARTUP_DELAY)
                .setDuration(ANIM_ITEM_DURATION).setInterpolator(
                        new DecelerateInterpolator(1.2f)).start();

        for (int i = 0; i < container.getChildCount(); i++) {
            View v = container.getChildAt(i);
            ViewPropertyAnimatorCompat viewAnimator;

            if (!(v instanceof TextView)) {
                viewAnimator = ViewCompat.animate(v)
                        .translationY(50).alpha(1)
                        .setStartDelay((ITEM_DELAY * i) + 500)
                        .setDuration(1000);
            } else {
                viewAnimator = ViewCompat.animate(v)
                        .scaleY(1).scaleX(1)
                        .setStartDelay((ITEM_DELAY * i) + 500)
                        .setDuration(500);
            }

            viewAnimator.setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    public void initView() {
        lout_terms = findViewById(R.id.lout_terms);
        lout_terms.setVisibility(View.VISIBLE);
        tvstart = findViewById(R.id.tvstart);
        chkPrivacy = findViewById(R.id.chkPrivacy);
        tvPrivacyPolicy = findViewById(R.id.tvPrivacyPolicy);


        tvstart.setEnabled(false);
        tvstart.setClickable(false);
        tvstart.setAlpha(0.5f);

        String str = "By clicking i'm agree with our privacy policy";

        SpannableString ss = new SpannableString(str);
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View view) {
//                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(getResources().getString(R.string.privacy_policy)));
//                startActivity(browserIntent);

                new CustomTabsIntent.Builder().build().launchUrl(splashActivity.this, Uri.parse(getString(R.string.privacy_policy)));

            }

            @Override
            public void updateDrawState(TextPaint textPaint) {
                super.updateDrawState(textPaint);
                textPaint.setUnderlineText(false);
            }
        };

        int start = str.indexOf("privacy");
        int end = str.length();
        ss.setSpan(clickableSpan, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tvPrivacyPolicy.setText(ss);
        tvPrivacyPolicy.setMovementMethod(LinkMovementMethod.getInstance());
        tvPrivacyPolicy.setHighlightColor(Color.TRANSPARENT);

        chkPrivacy.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    tvstart.setEnabled(true);
                    tvstart.setClickable(true);
                    tvstart.setAlpha(1.0f);
                } else {
                    tvstart.setEnabled(false);
                    tvstart.setClickable(false);
                    tvstart.setAlpha(0.5f);
                }
            }
        });

        tvstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (chkPrivacy.isChecked()) {

                    PreferenceHelper.saveToUserDefaults(getApplicationContext(), Constant.LOGIN_PREF, "1");
                    Intent i = new Intent(getApplicationContext(), PermissionActivity.class);
                    startActivity(i);
                    finish();
                } else {
                    Snackbar.make(lout_terms, "Please", Snackbar.LENGTH_SHORT).show();
                    Toast.makeText(getApplicationContext(), "Please read privacy policy first!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void setAppId(String appId) {
        try {
            ApplicationInfo ai = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            String myApiKey = bundle.getString("com.google.android.gms.ads.APPLICATION_ID");
            Log.d("TAG", "Name Found: " + myApiKey);
            ai.metaData.putString("com.google.android.gms.ads.APPLICATION_ID", appId);//you can replace your key APPLICATION_ID here
            String ApiKey = bundle.getString("com.google.android.gms.ads.APPLICATION_ID");
            Log.d("TAG", "ReNamed Found: " + ApiKey);
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("TAG", "Failed to load meta-data, NameNotFound: " + e.getMessage());
        } catch (NullPointerException e) {
            Log.e("TAG", "Failed to load meta-data, NullPointer: " + e.getMessage());
        }
    }

    public boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(splashActivity.this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
                return true;
            } else {
                Intent i = new Intent(getApplicationContext(), PermissionActivity.class);
                startActivity(i);
                finish();

                return false;
            }
        } else {

            return true;
        }
    }

    @Override
    public void onPurchasedSuccess(@NonNull Purchase purchase) {

    }

    @Override
    public void onProductAlreadyOwn() {

    }

    @Override
    public void onBillingSetupFinished(@NonNull BillingResult billingResult) {
        if(billingResult.getResponseCode()== BillingClient.BillingResponseCode.OK){
            InAppPurchaseHelper.Companion.getInstance().initProductFromJava();
        }
    }

    @Override
    public void onBillingUnavailable() {

    }

    @Override
    public void onBillingKeyNotFound(@NonNull String productId) {

    }
}
