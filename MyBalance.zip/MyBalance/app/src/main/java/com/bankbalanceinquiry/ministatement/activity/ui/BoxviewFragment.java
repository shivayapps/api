package com.bankbalanceinquiry.ministatement.activity.ui;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.Events.SmsList;
import com.bankbalanceinquiry.ministatement.Events.SmsProgress;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.AccountHisotryActivity;
import com.bankbalanceinquiry.ministatement.activity.AllAccountActivity;
import com.bankbalanceinquiry.ministatement.activity.BillsNewActivity;
import com.bankbalanceinquiry.ministatement.activity.CashWithdrawalActivity;
import com.bankbalanceinquiry.ministatement.activity.drawerActivity;
import com.bankbalanceinquiry.ministatement.adapter.AllAccountListAdapter;
import com.bankbalanceinquiry.ministatement.adapter.listBankAdapter;
import com.bankbalanceinquiry.ministatement.adapternew.AllAccountListNewAdapter;
import com.bankbalanceinquiry.ministatement.common.AllBankAvilabeBalancMsg;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.common.ReadJsonFile;
import com.bankbalanceinquiry.ministatement.database.DatabaseAccess;
import com.bankbalanceinquiry.ministatement.databased.DBHelperAccount;
import com.bankbalanceinquiry.ministatement.databased.DBHelperAccountHistory;
import com.bankbalanceinquiry.ministatement.databased.DBHelperBills;
import com.bankbalanceinquiry.ministatement.databased.DBHelperCash;
import com.bankbalanceinquiry.ministatement.databased.StoreValue;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.model.AllAccountModel;
import com.bankbalanceinquiry.ministatement.model.AllAccountModelHistory;
import com.bankbalanceinquiry.ministatement.model.AvilabeBalanceModel;
import com.bankbalanceinquiry.ministatement.model.BilsEmiModel;
import com.bankbalanceinquiry.ministatement.model.CashModelHistory;
import com.bankbalanceinquiry.ministatement.model.bankname;
import com.bankbalanceinquiry.ministatement.model.mbalance;
import com.bankbalanceinquiry.ministatement.model.passBook;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;
import com.bankbalanceinquiry.ministatement.utils.SharedPreferenceClass;
import com.bankbalanceinquiry.ministatement.utils.SmsService;
import com.daimajia.numberprogressbar.NumberProgressBar;
import com.example.app.ads.helper.InterstitialAdHelper;
import com.example.app.ads.helper.NativeAdsSize;
import com.example.app.ads.helper.NativeAdvancedModelHelper;
import com.google.android.material.snackbar.Snackbar;
import com.jaredrummler.materialspinner.MaterialSpinner;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static android.content.Context.MODE_PRIVATE;
import static com.bankbalanceinquiry.ministatement.activity.drawerActivity.navBalance;
import static com.bankbalanceinquiry.ministatement.activity.drawerActivity.navController;
import static com.bankbalanceinquiry.ministatement.activity.drawerActivity.toolbar;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;

public class BoxviewFragment extends Fragment implements AllAccountListNewAdapter.ClickActivDeactiveint {
    public static String bank_name = "", txtbank_id, txtbank_short;
    public static String account_name;
    static Integer aval_balance;
    int bank_id;
    String url_netBank, bank_change;
    public static List<passBook> pData;
    Button change_bank;
    private LinearLayout bank_balance, emi_calcu, ussd_banking, sms_banking, online_banking, epf_service;
    public static TextView account_balance, account_no, details;
    static ImageView see_passbook;
    public static RelativeLayout box_view_relative;
    //public static LinearLayout list_bank_relative;
    //public static ListView custom_list_view;
    List<bankname> mData;
    List<mbalance> mBalanceList = new ArrayList<>();
    SharedPreferences preferences;
    SharedPreferences.Editor editorBank;
    RelativeLayout account_passbook;
    Context context;
    RecyclerView recycle_passBank;
    ScrollView scrollMain;
    listBankAdapter listBankAdapter;
    ArrayList<String> array_Account = new ArrayList<>();
    ArrayList<String> array_Amount = new ArrayList<>();
    public static List<String> find = new ArrayList<>();
    int check;

    private Button btnAccount;

    private Activity activity;
    private ArrayList<AllAccountModel> allAccountModels;
    private ArrayList<AllAccountModel> allAccountModelstmp;
    private AllAccountListAdapter allAccountListAdapter;
    private AsyncTask mMyTask = null;
    private ProgressBar pbLoading;

    private ArrayList<AvilabeBalanceModel> avilabeBalanceModels;
    //private ArrayList<BankNameLogo> bankNameLogos;
    private String BankName = "";
    private String BankNameFinal = "";
    private int BankIconFinal = 0;

    private ArrayList<String> avilabestringarray;

    private DBHelperAccount mydbAccount;
    private DBHelperAccountNew mydbAccountNew;
    private DBHelperCash mydbCash;
    private DBHelperBills mydbBill;
    private DBHelperAccountHistory dbHelperAccountHistory;


    private ArrayList<CashModelHistory> cashModelHistories;
    private ArrayList<AllAccountModelHistory> allAccountModelHistories;
    String TodayDate = "";
    private ArrayList<BilsEmiModel> bilsEmiModels;
    private ArrayList<String> AllBankingTransferFrom = new ArrayList<>();


    private ArrayList<HomeAccoutList> homeAccoutLists = new ArrayList<>();
    private ArrayList<HomeAccoutList> allTransactionList = new ArrayList<>();
    private RecyclerView rvAccountList;
    private AllAccountListNewAdapter allAccountListNewAdapter;

    private ArrayList<String> tempAccountNo = new ArrayList<>();

    //    TextView mCount;
    RelativeLayout mLoading;
    //    SeekBar mProgress;
//    ImageView mCancel;
    boolean isCountRunning = true;

    CardView mCashL, mBillL;

    private NumberProgressBar progress;
    private TextView count;
    private LinearLayout progress_lay;
    private FrameLayout adLayout;
    private CardView adcard;

    MaterialSpinner spChangeBank;
    List<bankname> MDetail;
    int spCheck = 0;

    /*@Subscribe
    public void OnSmsProgress(final SmsProgress smsProgress) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mCount.setText(SmsService.smsCount + "/" + SmsService.TotalCount);
                    mProgress.setMax(SmsService.TotalCount);
                    mProgress.setProgress(smsProgress.getProgress());
                }
            });
        }
    }*/

    @Subscribe
    public void OnSmsProgress(final SmsProgress smsProgress) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    count.setText(SmsService.smsCount + "/" + SmsService.TotalCount);
                    progress.setMax(SmsService.TotalCount);
                    progress.setProgress(smsProgress.getProgress());
                    if (SmsService.smsCount == (SmsService.TotalCount - 1)) {
                        PreferenceHelper.saveToUserDefaults(getActivity(), Constant.TRACK_PREF, "1");
                        progress_lay.setVisibility(View.GONE);
                        CallNewHomeAccount();
                        setSpinnerData();
                        //getActivity().recreate();
                    }
                }
            });
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_boxview, container, false);

//        toolbar.setTitle(bank_name.equalsIgnoreCase("No Bank") ? getContext().getResources().getString(R.string.menu_box) : bank_name);
        progress = root.findViewById(R.id.progress);
        count = root.findViewById(R.id.count);
        progress_lay = root.findViewById(R.id.progress_lay);
        if (isMyServiceRunning(SmsService.class)) {
            progress_lay.setVisibility(View.VISIBLE);
        } else {
            progress_lay.setVisibility(View.GONE);
        }


        Log.e("BoxViewfrg==", "Yes");
        // EventBus
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this);

        context = getActivity();
        activity = getActivity();
//        mCount = root.findViewById(R.id.count);
        mLoading = root.findViewById(R.id.loading);

        adLayout = root.findViewById(R.id.adLayout);
        adcard = root.findViewById(R.id.adcard);
        int colors = ContextCompat.getColor(getActivity(), R.color.colorAccent);

        if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {
            new NativeAdvancedModelHelper(getActivity()).loadNativeAdvancedAd(NativeAdsSize.Medium,
                    adLayout, null, true, true, new Function1<Boolean, Unit>() {
                        @Override
                        public Unit invoke(Boolean aBoolean) {
                            return null;
                        }
                    }, new Function0<Unit>() {
                        @Override
                        public Unit invoke() {
                            return null;
                        }
                    });
        }

//        mProgress = root.findViewById(R.id.progress);
//        mCancel = root.findViewById(R.id.close);
        /*mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EventBus.getDefault().post(new ServiceStop(true));
            }
        });*/
        /*mProgress.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        });*/
        account_balance = root.findViewById(R.id.account_balance);
        account_no = root.findViewById(R.id.account_no);
        details = root.findViewById(R.id.details);
        see_passbook = root.findViewById(R.id.see_passbook);

        bank_balance = root.findViewById(R.id.bank_balance);
        emi_calcu = root.findViewById(R.id.emi_calcu);
        ussd_banking = root.findViewById(R.id.ussd_banking);
        sms_banking = root.findViewById(R.id.sms_banking);
        online_banking = root.findViewById(R.id.online_banking);
        epf_service = root.findViewById(R.id.epf_service);
        recycle_passBank = root.findViewById(R.id.recycle_passBank);

        //list_bank_relative = root.findViewById(R.id.list_bank_relative);
        box_view_relative = root.findViewById(R.id.box_view_relative);
        account_passbook = root.findViewById(R.id.account_passbook);

        mCashL = root.findViewById(R.id.cash_l);
        mBillL = root.findViewById(R.id.bills_l);

        spChangeBank = (MaterialSpinner) root.findViewById(R.id.spChangeBank);

        mCashL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), CashWithdrawalActivity.class));
            }
        });


        mBillL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), BillsNewActivity.class));
            }
        });

        change_bank = root.findViewById(R.id.change_bank);

        preferences = getActivity().getSharedPreferences("bank_select", MODE_PRIVATE);
        editorBank = preferences.edit();

        rvAccountList = root.findViewById(R.id.rvAccountList);
        pbLoading = root.findViewById(R.id.pbLoading);

        LinearLayoutManager linearLayoutManagern = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        rvAccountList.setLayoutManager(linearLayoutManagern);

        btnAccount = root.findViewById(R.id.btnAccount);
        btnAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), AllAccountActivity.class);
                startActivity(i);
            }
        });

        //set list Bank
        //custom_list_view = root.findViewById(R.id.custom_list_view);

        try {
            DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getActivity());
            databaseAccess.open();
            mData = databaseAccess.getList();
            databaseAccess.close();

            /*bank_change = preferences.getString("bank", "no_select");

            if(bank_change.matches("select")) {
                int sbank_id = mData.get(0).getB_id();
                String bank_n = mData.get(0).getB_name();
                String bank_url = mData.get(0).getB_netbank();
                String bank_short = mData.get(0).getB_short();

                editorBank.putString("bank", "select");
                editorBank.putString("bank_name", bank_n);
                editorBank.putString("bank_url", bank_url);
                editorBank.putString("bank_short", bank_short);
                editorBank.putString("bank_id", String.valueOf(sbank_id));
                editorBank.commit();
            }*/

        } catch (Exception e) {
            e.printStackTrace();
        }

        setSpinnerData();

        avilabeBalanceModels = new ArrayList<>();
        //  bankNameLogos = new ArrayList<>();
        avilabeBalanceModels.addAll(AllBankAvilabeBalancMsg.AddAvilableMsg());
        // bankNameLogos.addAll(AllBankAvilabeBalancMsg.getBankNameAndLogo());
        avilabestringarray = new ArrayList<>();
        avilabestringarray.addAll(AllBankAvilabeBalancMsg.GetAvilabeBalanceArrayList());

        pbLoading.setVisibility(View.GONE);
        mydbAccount = new DBHelperAccount(activity);
        mydbAccountNew = new DBHelperAccountNew(activity);
        mydbCash = new DBHelperCash(activity);
        mydbBill = new DBHelperBills(activity);
        dbHelperAccountHistory = new DBHelperAccountHistory(activity);

        AllBankingTransferFrom.addAll(AllBankAvilabeBalancMsg.GetTransperFrom());

        if (CommonFun.IsAllSmsmFill.equalsIgnoreCase("")) {
            String FirstTime = StoreValue.GetFirstime("OK");
            if (FirstTime.equalsIgnoreCase("")) {
                CommonFun.IsAllSmsmFill = "";
                Log.e("FIRSTIMEINSERDATA==>", "FirstTime");
                if (mMyTask != null) {
                    if (mMyTask.getStatus() == AsyncTask.Status.RUNNING) {
                        // My AsyncTask is currently doing work in doInBackground()
                    }
                } else {
                    // mMyTask = new AllOptionFilterFirstTime().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                    String FirstTimeON = StoreValue.GetLodingData("DOUBLE");
                    if (FirstTimeON.equalsIgnoreCase("")) {
                        StoreValue.SetLodingData("DOUBLE", "Ok");
                        Log.e("FirstTimeON", FirstTimeON);
                    } else {
                        Log.e("FirstTimeON", " AfterLoad");
//                        mMyTask = new MyTaskNewAccount().execute(20);
                        mLoading.setVisibility(View.VISIBLE);
//                        mCancel.setVisibility(View.VISIBLE);
                        account_passbook.setVisibility(View.GONE);
                       /* if (!isMyServiceRunning(SmsService.class)) {
                            getActivity().startService(new Intent(getActivity(), SmsService.class));
                        }*/
//                        countThread.start();
                    }
                }

            } else {
                mLoading.setVisibility(View.GONE);
//                mCancel.setVisibility(View.GONE);
                account_passbook.setVisibility(View.VISIBLE);
                CommonFun.IsAllSmsmFill = "AllFill";
                Log.e("FIRSTIMEINSERDATA==>", " AlredyInsert");
                CallNewHomeAccount();
            }
        } else {
            mLoading.setVisibility(View.GONE);
//            mCancel.setVisibility(View.GONE);
            account_passbook.setVisibility(View.VISIBLE);
            CallNewHomeAccount();
        }

        String[] bankColor_array = getActivity().getResources().getStringArray(R.array.listcolors);

        //Check preference
        bank_change = preferences.getString("bank", "no_select");
        bank_name = preferences.getString("bank_name", "No Bank");
        txtbank_id = preferences.getString("bank_id", "No Id");
        txtbank_short = preferences.getString("bank_short", "No Short");

        if (bank_change.matches("select")) {
            //list_bank_relative.setVisibility(View.GONE);
            //box_view_relative.setVisibility(View.VISIBLE);
            bank_id = Integer.parseInt(txtbank_id);
            Log.e("txtbank_", " " + txtbank_short);
        } else {
            //list_bank_relative.setVisibility(View.GONE);
            //box_view_relative.setVisibility(View.VISIBLE);

        }

        pData = new ArrayList<>();
        //add Data in Passbook model
        aval_balance = 0;
        // readMessages();

//        account_balance.setText("\u20B9" + aval_balance);

        listBankAdapter = new listBankAdapter(getActivity(), mData, bankColor_array);
        //custom_list_view.setAdapter(listBankAdapter);

        Log.e("Size Array--)", " " + array_Account.size());
        Log.e("Size PArray--)", " " + pData.size());


        for (int j = 0; j < array_Account.size(); j++) {
            check = 0;
            for (int i = 0; i < pData.size(); i++) {
                if (j == pData.get(i).getBank_type()) {
                    try {
                        if (pData.get(i).getPass_which().matches("Cr")) {
                            check = check + Integer.parseInt(pData.get(i).getPass_amount());
                            Log.e("Ava_c--)", " " + check);
                        } else if (pData.get(i).getPass_which().matches("Dr")) {
                            check = check - Integer.parseInt(pData.get(i).getPass_amount());
                        }
                    } catch (Exception e) {
                        Log.e("Error--)", " " + e.getMessage());
                    }
                }
            }
            Log.e("AmountAccoutasaaaa", String.valueOf(check));
            array_Amount.add(String.valueOf(check));
        }


        bank_balance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bank_change.matches("select")) {
                    if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {
                        InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) getActivity(), false, new Function1<Boolean, Unit>() {
                            @Override
                            public Unit invoke(Boolean aBoolean) {
                                navController.navigate(R.id.nav_bank_balnce);
                                return null;
                            }
                        });
                    } else {
                        navController.navigate(R.id.nav_bank_balnce);
                    }
                } else {
                    //list_bank_relative.setVisibility(View.VISIBLE);
                    //box_view_relative.setVisibility(View.GONE);
                    Snackbar.make(box_view_relative, "Select Bank First", Snackbar.LENGTH_SHORT).show();

                }
            }
        });

        ussd_banking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bank_change.matches("select")) {
                    if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {
                        InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) getActivity(), false, new Function1<Boolean, Unit>() {
                            @Override
                            public Unit invoke(Boolean aBoolean) {
                                navController.navigate(R.id.nav_bank_ussd);
                                return null;
                            }
                        });
                    } else {
                        navController.navigate(R.id.nav_bank_ussd);
                    }
                } else {
                    Snackbar.make(box_view_relative, "Select Bank First", Snackbar.LENGTH_SHORT).show();
                }

            }
        });

        account_passbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              /*  loadAds.showFullAd(1);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        navController.navigate(R.id.nav_bank_passbook);
                    }
                }, 200);*/

            }
        });

        sms_banking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (bank_change.matches("select")) {
                    if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {
                        InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) getActivity(), false, new Function1<Boolean, Unit>() {
                            @Override
                            public Unit invoke(Boolean aBoolean) {
                                redirectToSmsBanking();
                                return null;
                            }
                        });
                    } else {
                        redirectToSmsBanking();
                    }
                } else {
                    Snackbar.make(box_view_relative, "Select Bank First", Snackbar.LENGTH_SHORT).show();
                }
            }
        });

        online_banking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (bank_change.matches("select")) {
                    if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {
                        InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) getActivity(), false, new Function1<Boolean, Unit>() {
                            @Override
                            public Unit invoke(Boolean aBoolean) {
                                redirectToOnlineBanking();
                                return null;
                            }
                        });
                    } else {
                        redirectToOnlineBanking();
                    }
                } else {
                    Snackbar.make(box_view_relative, "Select Bank First", Snackbar.LENGTH_SHORT).show();
                }



            }
        });

        epf_service.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bank_change.matches("select")) {

                    if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {

                        InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) getActivity(), false, new Function1<Boolean, Unit>() {
                            @Override
                            public Unit invoke(Boolean aBoolean) {

                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        navController.navigate(R.id.nav_epf_service);
                                    }
                                }, 200);
                                return null;
                            }
                        });
                    } else {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                navController.navigate(R.id.nav_epf_service);
                            }
                        }, 200);
                    }
                } else {
                    //list_bank_relative.setVisibility(View.VISIBLE);
                    //box_view_relative.setVisibility(View.GONE);

                    Snackbar.make(box_view_relative, "Select Bank First", Snackbar.LENGTH_SHORT).show();

                }

            }
        });

        emi_calcu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (bank_change.matches("select")) {
                    if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {
                        InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) getActivity(), false, new Function1<Boolean, Unit>() {
                            @Override
                            public Unit invoke(Boolean aBoolean) {
                                navController.navigate(R.id.nav_bank_emi);
                                return null;
                            }
                        });
                    } else {
                        navController.navigate(R.id.nav_bank_emi);
                    }
                } else {
                    Snackbar.make(box_view_relative, "Select Bank First", Snackbar.LENGTH_SHORT).show();
                }


            }
        });


//        change_bank.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////                editorBank.clear();
////                editorBank.commit();
//
//                box_view_relative.setVisibility(View.GONE);
//                list_bank_relative.setVisibility(View.VISIBLE);
//                account_name = null;
//                toolbar.setTitle(R.string.app_name);
//
//            }
//        });

        /*scrollMain = root.findViewById(R.id.scrollMain);
        scrollMain.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                scrollMain.post(new Runnable() {
                    public void run() {
                        scrollMain.fullScroll(View.FOCUS_DOWN);
                    }
                });
            }
        });*/
        Log.e("FrgmentOpne Mm", "newww");
        return root;
    }

    private void redirectToSmsBanking() {


        if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {
            InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) getActivity(), false, new Function1<Boolean, Unit>() {
                @Override
                public Unit invoke(Boolean aBoolean) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            navController.navigate(R.id.nav_sms_banking);
                        }
                    }, 200);
                    return null;
                }
            });
        } else {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    navController.navigate(R.id.nav_sms_banking);
                }
            }, 200);
        }
    }

    private void redirectToOnlineBanking() {

        try {
            if (NetworkManager.isInternetConnected(getActivity())) {
                url_netBank = preferences.getString("bank_url", "no_url");
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        Uri webpage = Uri.parse(url_netBank);
                        if (!url_netBank.startsWith("http://") && !url_netBank.startsWith("https://")) {
                            webpage = Uri.parse("http://" + url_netBank);
                        }
                        if (getActivity() != null) {
                            Intent i = new Intent(Intent.ACTION_VIEW, webpage);
//                            i.setData(webpage);
                            if (i.resolveActivity(getActivity().getPackageManager()) != null) {
                                startActivity(i);
                            }
                        }
                    }
                }, 1500);
            } else {
                Snackbar.make(box_view_relative, "Internet Connection Required", Snackbar.LENGTH_SHORT).show();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void checkNotification() {

        try {
            if (SharedPreferenceClass.getBoolean(getActivity(), Constant.IS_FROM_NOTIFICATION)) {
                SharedPreferenceClass.setBoolean(getActivity(), Constant.IS_FROM_NOTIFICATION, false);
                String type = SharedPreferenceClass.getString(getActivity(), Constant.IS_FROM_NOTIFICATION_type, "");
                if (type != null && !type.equals("") && type.length() > 0) {

                    if (type.equals("rate")) {
                        Log.e("MainActivity", "onResume: Rate " + "notification message");
                        // SetRateApp();

                    } else if (type.equals("share")) {
                        //For Sharing Application Choose One Dialog

                    } else if (type.equals("message")) {
                        //Message will store
                        Log.e("MainActivity", "onResume:  message" + "notification message");
                        String message = SharedPreferenceClass.getString(getActivity(), Constant.IS_FROM_NOTIFICATION_MESSAGE, "");
                        showMessageDialog(getActivity(), this.getResources().getString(R.string.app_name), message);

                    } else if (type.equals("update")) {
                        //Update Message For updating
                        // makeGetLocalCall();

                    } else if (type.equals("offer")) {
                        //Offer Screen
                        boolean isFromClickOnNotification = true;
                        //getOfferScreenDetails(false);

                    } else {
                        /*if (type != null && !type.equals("") && type.length() > 0 && type.equals("URL")) {
                            Uri uri = getIntent().getData();
                            Intent browserIntent = new Intent(Intent.ACTION_VIEW, uri);
                            startActivity(browserIntent);
                        }*/
                    }
                }
            }
        } catch (Exception e) {
            Log.e("MainActivity", "onResume: " + "notification message");
            e.printStackTrace();
        }
    }

    public static void showMessageDialog(Context mContext, String title, String message) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);
        alertDialog.setPositiveButton(
                "OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub
                        dialog.cancel();
                    }
                });
        alertDialog.show();
    }

    private void setSpinnerData() {
        mydbAccountNew = new DBHelperAccountNew(getActivity());
        final ArrayList<HomeAccoutList> homeAccoutListArrayList = mydbAccountNew.GetAllAccountNew();

        //ArrayAdapter<HomeAccoutList> adapter = new ArrayAdapter<HomeAccoutList>(getActivity(),  android.R.layout.simple_spinner_dropdown_item, homeAccoutListArrayList);
        ArrayAdapter<bankname> adapter = new ArrayAdapter<bankname>(getActivity(), android.R.layout.simple_spinner_dropdown_item, mData);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spChangeBank.setAdapter(adapter);
        spChangeBank.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener() {
            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, Object item) {
                Log.e("smsBankingFragment==>", " onItemSelected:" + position);
                //editorBank = sharedPreferences.edit();

                bank_name = mData.get(position).getB_name();
                DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getActivity());
                databaseAccess.open();
                MDetail = databaseAccess.getBalance_details(bank_name);

                if (MDetail.size() > 0) {

                    int sbank_id = MDetail.get(0).getB_id();
                    String bank_url = MDetail.get(0).getB_netbank();
                    String bank_short = MDetail.get(0).getB_short();


                    editorBank.putString("bank", "select");
                    editorBank.putString("bank_name", bank_name);
                    editorBank.putString("bank_url", bank_url);
                    editorBank.putString("bank_short", bank_short);
                    editorBank.putString("bank_id", String.valueOf(sbank_id));
                    editorBank.commit();

                    drawerActivity.toolbar.setTitle(bank_name);
                    drawerActivity.bank_name = bank_name;
                    //spChangeBank.setText(bank_name);

                    databaseAccess.close();

                    bank_change = "select";
                    txtbank_id = String.valueOf(sbank_id);
                    txtbank_short = bank_short;

                }
            }
        });
        /*spChangeBank.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if(++check>1 && position>0){
                    Log.e("smsBankingFragment==>", " onItemSelected:"+position);
                    //editorBank = sharedPreferences.edit();

                    bank_name = homeAccoutListArrayList.get(position).full_name;
                    DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getActivity());
                    databaseAccess.open();
                    MDetail = databaseAccess.getBalance_details(bank_name);

                    if(MDetail.size()>0 && position>0) {

                        int sbank_id = MDetail.get(0).getB_id();
                        String bank_url = MDetail.get(0).getB_netbank();
                        String bank_short = MDetail.get(0).getB_short();

                        editorBank.putString("bank", "select");
                        editorBank.putString("bank_name", bank_name);
                        editorBank.putString("bank_url", bank_url);
                        editorBank.putString("bank_short", bank_short);
                        editorBank.putString("bank_id", String.valueOf(sbank_id));
                        editorBank.commit();

                        drawerActivity.toolbar.setTitle(bank_name);
                        drawerActivity.bank_name=bank_name;
                        databaseAccess.close();
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });*/
    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        if (getActivity() != null) {
            ActivityManager manager = (ActivityManager) getActivity().getSystemService(Context.ACTIVITY_SERVICE);
            if (manager != null) {
                for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                    if (serviceClass.getName().equals(service.service.getClassName())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public void onDestroyView() {
        EventBus.getDefault().unregister(this);
        super.onDestroyView();
    }


    @Subscribe
    public void OnSmsList(final SmsList smsList) {
        isCountRunning = false;
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    account_passbook.setVisibility(View.VISIBLE);
                    mLoading.setVisibility(View.GONE);
//                    mCancel.setVisibility(View.GONE);
                    homeAccoutLists.clear();
                    allTransactionList.clear();
                    homeAccoutLists.addAll(smsList.getHomeAccoutLists());
                    allTransactionList.addAll(smsList.getAllTransactionList());

//                    StoreValue.SetFirstime("OK", "Ok");
//                    CommonFun.IsAllSmsmFill = "AllFill";
                    pbLoading.setVisibility(View.GONE);

                    if (DialogProgress != null) {
                        DialogProgress.dismiss();
                    }

                    //  HomeScreen Account
//                    CallHomeScreenAllAccoutNew();
                    CallNewHomeAccount();
                }
            });
        }

    }


    private void CallNewHomeAccount() {
        pbLoading.setVisibility(View.GONE);
        homeAccoutLists.clear();
        ArrayList<HomeAccoutList> homeAccoutListArrayList = mydbAccountNew.GetAllAccountNew();
        homeAccoutLists.addAll(homeAccoutListArrayList);
        if (homeAccoutLists.size() > 0) {
            if(navBalance!=null)
            navBalance.setText("\u20B9" + calculateTotalBal(homeAccoutListArrayList));
            allAccountListNewAdapter = new AllAccountListNewAdapter(activity, homeAccoutLists);
            allAccountListNewAdapter.RegisterInterface(BoxviewFragment.this);
            rvAccountList.setAdapter(allAccountListNewAdapter);
            allAccountListNewAdapter.notifyDataSetChanged();
        }

        //bank_change = preferences.getString("bank", "no_select");


        /*if(homeAccoutListArrayList.size()>0) {
            bank_name = homeAccoutListArrayList.get(0).full_name;
            DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getActivity());
            databaseAccess.open();
            MDetail = databaseAccess.getBalance_details(bank_name);

            if(bank_change.equalsIgnoreCase("no_select")) {
                int sbank_id = MDetail.get(0).getB_id();
                String bank_n = MDetail.get(0).getB_name();
                String bank_url = MDetail.get(0).getB_netbank();
                String bank_short = MDetail.get(0).getB_short();

                editorBank.putString("bank", "select");
                editorBank.putString("bank_name", bank_n);
                editorBank.putString("bank_url", bank_url);
                editorBank.putString("bank_short", bank_short);
                editorBank.putString("bank_id", String.valueOf(sbank_id));
                editorBank.commit();

                drawerActivity.toolbar.setTitle(bank_name);
                drawerActivity.bank_name=bank_name;
            }
            databaseAccess.close();
        }*/


    }


    private String calculateTotalBal(ArrayList<HomeAccoutList> homeAccoutListArrayList) {
        double total = 0;
        for (HomeAccoutList homeAccount : homeAccoutListArrayList) {
            String bal = homeAccount.FinalAccountBalance;
            if (!TextUtils.isEmpty(bal)) {
                bal = bal.replace(",", "");
                double v = Double.parseDouble(bal);
                total += v;
            }
        }

        String s = String.valueOf(total);

        if (s.contains(".")) {
            String afterPoint = s.substring(s.indexOf(".") + 1);
            if (afterPoint.length() > 2) {
                DecimalFormat decim = new DecimalFormat("#,##,###.##");
                return decim.format(total);
            }
        }
        DecimalFormat decim = new DecimalFormat("#,##,###.##");
        return decim.format(total);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public static void readDirect() {
        navController.navigate(R.id.nav_box);
    }

    private Dialog DialogProgress = null;
    private ProgressBar progress_horizontal;
    private TextView tvValue;
    private int mycound = 0;
    private int TotalCount = 0;


    private class MyTaskNewAccount extends AsyncTask<Integer, Integer, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            allAccountModelHistories = new ArrayList<>();
            CallProgress();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            StoreValue.SetFirstime("OK", "Ok");
            CommonFun.IsAllSmsmFill = "AllFill";
            pbLoading.setVisibility(View.GONE);

            if (DialogProgress != null) {
                DialogProgress.dismiss();
            }

            //  HomeScreen Account
            CallHomeScreenAllAccoutNew();


            //   Account History
//            AccountHistory();


        }

        @Override
        protected String doInBackground(Integer... params) {
            Uri message = Uri.parse("content://sms/inbox");
            ContentResolver cr = activity.getContentResolver();
            Cursor c = cr.query(message, null, null, null, null);

            int totalSMS = 0;
            if (c != null) {
                totalSMS = c.getCount();
            }
            TotalCount = totalSMS;
            if (progress_horizontal != null) {
                progress_horizontal.setMax(totalSMS);
            }
            JSONArray jsonArray = ReadJsonFile.GetAssetsFileGetDataJsonArray(activity, "sms/rulestmp");
            if (c != null && c.moveToFirst()) {
                for (int i = 0; i < totalSMS; i++) {
                    //                    String id = c.getString(c.getColumnIndexOrThrow("_id"));
                    String BankNameTitle = c.getString(c.getColumnIndexOrThrow("address"));
                    String body = c.getString(c.getColumnIndexOrThrow("body"));
                    //                    String read = c.getString(c.getColumnIndexOrThrow("read"));
                    //                    String date = c.getString(c.getColumnIndexOrThrow("date"));
                    String datestr = c.getString(c.getColumnIndexOrThrow("date"));
                    //                    String type = c.getString(c.getColumnIndexOrThrow("type"));
                    //                    String person = c.getString(c.getColumnIndexOrThrow("person"));

                    long dateV = Long.parseLong(datestr);
                    CheckisTransactionSms(jsonArray, BankNameTitle, body, dateV);

                    try {
                        publishProgress(i);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    c.moveToNext();

                }
                c.close();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            Log.e("onProgressUpdate==>?", values[0] + "");
            if (tvValue != null) {
                mycound++;
                Log.e("my Count", mycound + "");
                tvValue.setText(mycound + "/ " + TotalCount);
            }
            if (progress_horizontal != null) {
                progress_horizontal.setProgress(mycound);
            }
        }
    }

    private void AccountHistory() {
        for (int i = 0; i < allAccountModelHistories.size(); i++) {
            AllAccountModelHistory alldata = allAccountModelHistories.get(i);
            String TitleDateHistory = alldata.getTitleDate();
            String dateValHistory = alldata.getDate();
            String AccountNo = alldata.getAccountno();
            String AccountAmount = alldata.getAccountamount();
            String CheckIsDebitCredit = alldata.getCreditdebit();
            String FinalDescription = alldata.getFinalDescription();
            String TransferFrom = alldata.getTransferFrom();
            try {
                dbHelperAccountHistory.InsertHistory(TitleDateHistory, dateValHistory, AccountNo, AccountAmount,
                        CheckIsDebitCredit, FinalDescription, TransferFrom);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        allAccountModelHistories = new ArrayList<>();
        allAccountModelHistories.addAll(dbHelperAccountHistory.GetHistory());
    }

    private void CallAccountHistoryAddDb() {
        for (int i = 0; i < allAccountModelHistories.size(); i++) {
            AllAccountModelHistory alldata = allAccountModelHistories.get(i);
            String TitleDateHistory = alldata.getTitleDate();
            String dateValHistory = alldata.getDate();
            String AccountNo = alldata.getAccountno();
            String AccountAmount = alldata.getAccountamount();
            String CheckIsDebitCredit = alldata.getCreditdebit();
            String FinalDescription = alldata.getFinalDescription();
            String TransferFrom = alldata.getTransferFrom();

            try {
                dbHelperAccountHistory.InsertHistory(TitleDateHistory, dateValHistory, AccountNo, AccountAmount,
                        CheckIsDebitCredit, FinalDescription, TransferFrom);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    private void CallHomeScreenAllAccoutNew() {
        for (int i = 0; i < homeAccoutLists.size(); i++) {
            HomeAccoutList alldata = homeAccoutLists.get(i);
            try {
                mydbAccountNew.InsertAccount(alldata);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        for (int i = 0; i < allTransactionList.size(); i++) {
            HomeAccoutList alldata = allTransactionList.get(i);
            try {
                mydbAccountNew.InsertTransaction(alldata);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        CallNewHomeAccount();

    }

    private void CheckisTransactionSms(JSONArray jsonArray, String bankNameTitle, String body, long dateV) {
        JSONObject jsonObject;
        JSONArray senderss;
        int mObjectPosition = 999;

        SimpleDateFormat formatterAccount = new SimpleDateFormat("dd-MMM-yy");
        SimpleDateFormat FormateMontHistory = new SimpleDateFormat("MMMM");
        SimpleDateFormat formatterHistory = new SimpleDateFormat("dd MMMM yyyy, hh:mm aa");

        HomeAccoutList homeAccount = new HomeAccoutList();

        if (!TextUtils.isEmpty(bankNameTitle)) {
            if (jsonArray != null) {
                for (int i = 0; i < jsonArray.length(); i++) {
                    jsonObject = jsonArray.optJSONObject(i);
                    senderss = jsonObject.optJSONArray("senders");
                    if (senderss != null) {
                        for (int j = 0; j < senderss.length(); j++) {
                            try {
                                String SenderName = senderss.get(j).toString();
                                if (bankNameTitle.toLowerCase().contains(SenderName.toLowerCase())) {
                                    mObjectPosition = i;
                                    homeAccount.full_name = jsonObject.getString("full_name");
                                    break;
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
            if (mObjectPosition != 999) {
                try {
                    getTransectionDetails(homeAccount, body, jsonArray.getJSONObject(mObjectPosition));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }


        homeAccount.dateValAccount = formatterAccount.format(new Date(dateV));
        homeAccount.DateTransactionHistory = FormateMontHistory.format(new Date(dateV));
        homeAccount.dateValHistory = formatterHistory.format(new Date(dateV));

        // Account List
        if (!homeAccount.account_type.equalsIgnoreCase("phone")) {
            if (!TextUtils.isEmpty(homeAccount.FinalAccountBalance) || homeAccount.account_type.equalsIgnoreCase("prepaid")) {
                if (!TextUtils.isEmpty(homeAccount.full_name)) {
                    if (!TextUtils.isEmpty(homeAccount.FinalAccountNo)) {
                        if (homeAccount.FinalAccountNo.length() > 4) {
                            homeAccount.FinalAccountNo = homeAccount.FinalAccountNo.substring(homeAccount.FinalAccountNo.length() - 4);
                        }
                        if (tempAccountNo.size() != 0) {
                            if (!tempAccountNo.contains(homeAccount.FinalAccountNo)) {
                                boolean isF = false;
                                for (int i = 0; i < tempAccountNo.size() && !isF; i++) {
                                    if (tempAccountNo.get(i).length() > homeAccount.FinalAccountNo.length()) {
                                        if (tempAccountNo.get(i).contains(homeAccount.FinalAccountNo)) {
                                            isF = true;
                                            homeAccount.FinalAccountNo = tempAccountNo.get(i);
                                        }
                                    } else {
                                        if (homeAccount.FinalAccountNo.contains(tempAccountNo.get(i))) {
                                            isF = true;
                                            homeAccount.FinalAccountNo = tempAccountNo.get(i);
                                        }
                                    }
                                }
                                if (!isF) {
                                    homeAccoutLists.add(homeAccount);
                                    tempAccountNo.add(homeAccount.FinalAccountNo);
                                }
                            }
                        } else {
                            homeAccoutLists.add(homeAccount);
                            tempAccountNo.add(homeAccount.FinalAccountNo);
                        }
                    } else {
                        if (!tempAccountNo.contains(homeAccount.full_name)) {
                            homeAccoutLists.add(homeAccount);
                            tempAccountNo.add(homeAccount.full_name);
                        }
                    }
                }
            }
        }


        // Account History
        if (!TextUtils.isEmpty(homeAccount.full_name)) {
            if (!TextUtils.isEmpty(homeAccount.amount)) {
                String amount = homeAccount.amount.replaceAll(",", "");
                homeAccount.amount = amount;
//                if (homeAccount.FinalAccountNo.length() > 4) {
//                    homeAccount.FinalAccountNo = homeAccount.FinalAccountNo.substring(homeAccount.FinalAccountNo.length() - 4);
//                }

                if (TextUtils.isEmpty(homeAccount.transactionDesc)) {
                    if (!TextUtils.isEmpty(homeAccount.mTransactionType)) {
                        homeAccount.transactionDesc = getTransactionDesc(homeAccount.mTransactionType);
                    } else if (!TextUtils.isEmpty(homeAccount.txn_type)) {
                        homeAccount.transactionDesc = getTransactionDesc(homeAccount.txn_type);
                    } else {
                        homeAccount.transactionDesc = "Unknown Transaction";
                    }
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("atm") ||
                        homeAccount.transactionDesc.equalsIgnoreCase("debit_atm")) {
                    homeAccount.transactionDesc = "ATM withdrawal";
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("debit") ||
                        homeAccount.transactionDesc.equalsIgnoreCase("debit_card")) {
                    homeAccount.transactionDesc = "Debit Card Transaction";
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("credit_card")) {
                    homeAccount.transactionDesc = "Credit Card Transaction";
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("credit_card_bill")) {
                    homeAccount.transactionDesc = "Credit Card Bill";
                }

                if (!TextUtils.isEmpty(homeAccount.transactionPos)) {
                    homeAccount.finalTransactionDesc = homeAccount.transactionPos;
                } else if (homeAccount.transactionDescs.size() != 0) {
                    for (String s : homeAccount.transactionDescs) {
                        if (!TextUtils.isEmpty(s)) {
                            homeAccount.finalTransactionDesc = s;
                            break;
                        }
                    }
                }
                allTransactionList.add(homeAccount);
            }
        }
    }


    private void getTransectionDetails(HomeAccoutList homeAccount, String body, JSONObject jsonObject) {

        int posID = -1, amountId = -1, ruleId = -1, dateId = -1, eventNameId = -1, eventLocationId = -1, eventInfoId = -1;

        try {
            BankName = jsonObject.optString("full_name");
            JSONArray patternsary = jsonObject.optJSONArray("patterns");
            if (patternsary != null) {
                boolean isPatternMatch = false;
                for (int jj = 0; jj < patternsary.length() && !isPatternMatch; jj++) {
                    JSONObject jsonObjectt = patternsary.optJSONObject(jj);
                    String Regx = jsonObjectt.optString("regex");

                    Pattern regEx = Pattern.compile(Regx);
                    Matcher m = regEx.matcher(body);
                    if (m.find()) {
                        isPatternMatch = true;
                        homeAccount.account_type = jsonObjectt.optString("account_type");
                        homeAccount.sms_type = jsonObjectt.optString("sms_type");
                        String data_fields = jsonObjectt.optString("data_fields");
                        JSONObject obj_data_fields = new JSONObject(data_fields);

                        String typeKey = getTypeKey(homeAccount.sms_type);
                        if (!TextUtils.isEmpty(typeKey) && obj_data_fields.has(typeKey)) {
                            homeAccount.mTransactionType = obj_data_fields.optString(typeKey);
                        } else {
                            if (obj_data_fields.has("transaction_type_rule") &&
                                    obj_data_fields.getJSONObject("transaction_type_rule").has("rules")) {

                                ruleId = obj_data_fields.getJSONObject("transaction_type_rule").getInt("group_id");
                                String ruleValue = m.group(ruleId);
                                JSONArray transaction_type_rules = obj_data_fields.getJSONObject("transaction_type_rule").getJSONArray("rules");
                                boolean isFound = false;
                                JSONObject ruleObj = null;
                                for (int i = 0; i < transaction_type_rules.length() && !isFound; i++) {
                                    ruleObj = transaction_type_rules.getJSONObject(i);
                                    String value = ruleObj.getString("value");
                                    if (value.equalsIgnoreCase(ruleValue)) {
                                        isFound = true;
                                    }
                                }
                                if (ruleObj != null) {
                                    if (ruleObj.has("pos_override")) {
                                        homeAccount.transactionDesc = ruleObj.getString("pos_override");
                                    }
                                    if (ruleObj.has("txn_type")) {
                                        homeAccount.txn_type = ruleObj.getString("txn_type");
                                        if (homeAccount.txn_type.equalsIgnoreCase("debit_atm")) {
                                            homeAccount.isAtmWithDraw = true;
                                        }
                                    }
                                }

                            }
                        }

                        if (obj_data_fields.has("amount")) {
                            if (obj_data_fields.getJSONObject("amount").has("group_id")) {
                                amountId = obj_data_fields.getJSONObject("amount").getInt("group_id");
                                homeAccount.amount = m.group(amountId);  //AccountAmount
                            } else if (obj_data_fields.getJSONObject("amount").has("group_ids")) {
                                JSONArray ids = obj_data_fields.getJSONObject("amount").getJSONArray("group_ids");
                                for (int i = 0; i < ids.length(); i++) {
                                    homeAccount.amounts.add(m.group(ids.getInt(i)));
                                }
                            }
                            if (obj_data_fields.getJSONObject("amount").has("txn_direction")) {
                                homeAccount.isDebited = false;
                            }
                        }
//                        ArrayList<String> values = new ArrayList<>();
//                        if (homeAccount.amount.equalsIgnoreCase("7,999.00")) {
//
//                            int count = m.groupCount();
//                            for (int c = 0; c < count; c++) {
//                                String v = m.group(c);
//                                values.add(v);
//                            }
//                        }

                        if (obj_data_fields.has("date")) {
                            if (obj_data_fields.getJSONObject("date").has("use_sms_time")) {
                                homeAccount.use_sms_time = obj_data_fields.getJSONObject("date").getBoolean("use_sms_time");
                            } else if (obj_data_fields.getJSONObject("date").has("formats")) {
                                JSONArray array = obj_data_fields.getJSONObject("date").getJSONArray("formats");
                                for (int i = 0; i < array.length(); i++) {
                                    String format = array.getJSONObject(i).getString("format");
                                    homeAccount.dateFormats.add(format);
                                }
                                if (obj_data_fields.getJSONObject("date").has("group_id")) {
                                    dateId = obj_data_fields.getJSONObject("date").getInt("group_id");
                                    homeAccount.date = m.group(dateId);  // account_Date
                                } else if (obj_data_fields.getJSONObject("date").has("group_ids")) {
                                    JSONArray ids = obj_data_fields.getJSONObject("date").getJSONArray("group_ids");
                                    for (int i = 0; i < ids.length(); i++) {
                                        homeAccount.dates.add(m.group(ids.getInt(i)));
                                    }
                                }
                            }
                        }
//                        if (TextUtils.isEmpty(homeAccount.transactionDesc)) {
//                            getDataFromDataFields(obj_data_fields, "pos", homeAccount.transactionDesc, posID, homeAccount.transactionDescs, m);
//                        }

                        if (obj_data_fields.has("pos")) {
                            if (obj_data_fields.getJSONObject("pos").has("value")) {
                                homeAccount.transactionDesc = obj_data_fields.getJSONObject("pos").getString("value");
                            }
                            if (obj_data_fields.getJSONObject("pos").has("group_id")) {
                                posID = obj_data_fields.getJSONObject("pos").getInt("group_id");
                                homeAccount.transactionPos = m.group(posID);
                            } else if (obj_data_fields.getJSONObject("pos").has("group_ids")) {
                                JSONArray ids = obj_data_fields.getJSONObject("pos").getJSONArray("group_ids");
                                for (int i = 0; i < ids.length(); i++) {
                                    homeAccount.transactionDescs.add(m.group(ids.getInt(i)));
                                }
                            }

                        }


                        if (homeAccount.sms_type.equalsIgnoreCase("event")) {
                            getDataFromDataFields(obj_data_fields, "name", homeAccount.eventName, eventNameId, homeAccount.eventNames, m);
                            getDataFromDataFields(obj_data_fields, "event_info", homeAccount.eventInfo, eventInfoId, homeAccount.eventInfos, m);
                            getDataFromDataFields(obj_data_fields, "event_location", homeAccount.eventLocation, eventLocationId, homeAccount.eventLocations, m);
                        }

                        // Account No
                        JSONObject objpan = obj_data_fields.optJSONObject("pan");
                        String pan = "";
                        if (objpan != null) {
                            if (objpan.has("value")) {
                                homeAccount.panValue = objpan.getString("value");
                            }
                            pan = objpan.optString("group_id");
                        }
                        // pan
                        if (!TextUtils.isEmpty(pan)) {
                            homeAccount.FinalAccountNo = m.group(Integer.parseInt(pan));
                        }

                        // Account Balance
                        JSONObject objaccount_balance = obj_data_fields.optJSONObject("account_balance");
                        String account_balance = "";
                        if (objaccount_balance != null) {
                            account_balance = objaccount_balance.optString("group_id");
                        }
                        // Account Balance
                        if (!TextUtils.isEmpty(account_balance)) {
                            if (TextUtils.isDigitsOnly(account_balance)) {
                                homeAccount.FinalAccountBalance = m.group(Integer.parseInt(account_balance));
                            }
                        }

                        if (!TextUtils.isEmpty(homeAccount.mTransactionType) && homeAccount.mTransactionType.equalsIgnoreCase("credit")) {
                            homeAccount.isDebited = false;
                        }

                    }

                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private String getTypeKey(String sms_type) {
        return sms_type + "_type";
    }


    private void getDataFromDataFields(JSONObject obj_data_fields, String key, String mainValue, int mainId, ArrayList<String> valuesArray, Matcher m) {
        try {
            if (obj_data_fields.has(key)) {
                if (obj_data_fields.getJSONObject(key).has("value")) {
                    mainValue = obj_data_fields.getJSONObject(key).getString("value");
                } else {
                    if (obj_data_fields.getJSONObject(key).has("group_id")) {
                        mainId = obj_data_fields.getJSONObject(key).getInt("group_id");
                        mainValue = m.group(mainId);
                    } else if (obj_data_fields.getJSONObject(key).has("group_ids")) {
                        JSONArray ids = obj_data_fields.getJSONObject(key).getJSONArray("group_ids");
                        for (int i = 0; i < ids.length(); i++) {
                            valuesArray.add(m.group(ids.getInt(i)));
                        }
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private String getTransactionDesc(String transactionType) {
        String transactionDesc = "";
        switch (transactionType) {
            case "balance":
                transactionDesc = "Your Account Balance";
                break;
            case "upi":
                transactionDesc = "UPI Transaction";
                break;
            case "debit_card":
                transactionDesc = "Debit Card Transaction";
                break;
            case "net_banking":
                transactionDesc = "Net Banking";
                break;
            case "credit":
                transactionDesc = "Credited to your Account";
                break;
            case "cheque":
                transactionDesc = "Cheque Transaction";
                break;
            case "debit_atm":
                transactionDesc = "ATM withdrawal";
                break;
            case "credit_card":
                transactionDesc = "Credit Card Transaction";
                break;
            case "credit_card_bill":
                transactionDesc = "Credit Card Bill";
                break;
            case "loan_emi":
                transactionDesc = "Loan EMI";
                break;
            case "mobile_bill":
                transactionDesc = "Mobile Bill";
                break;
            case "debit_prepaid":
                transactionDesc = "Prepaid Debit Card Transaction";
                break;
            case "bill":
                transactionDesc = "Bill";
                break;
            case "internate_bill":
                transactionDesc = "Internet Bill";
                break;
            case "electricity_bill":
                transactionDesc = "Electricity Bill";
                break;
            case "insurance_premium":
                transactionDesc = "Insurance Premium";
                break;
            case "gas_bill":
                transactionDesc = "Gas Bill";
                break;
        }
        return transactionDesc;
    }


    private void CallProgress() {
        DialogProgress = new Dialog(activity);
        DialogProgress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        DialogProgress.getWindow().setBackgroundDrawable(null);
        DialogProgress.setContentView(R.layout.layout_loding_allbg);
        DialogProgress.getWindow().setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT);
        DialogProgress.setCancelable(false);
        DialogProgress.setCanceledOnTouchOutside(false);

        tvValue = DialogProgress.findViewById(R.id.value123);
        progress_horizontal = DialogProgress.findViewById(R.id.progress_horizontal);

        DialogProgress.show();
    }

    private void CallFilterDataMultiviewType() {
        Log.e("cashModelHistories", cashModelHistories.size() + "");
        for (int i = 0; i < cashModelHistories.size(); i++) {
            CashModelHistory alldata = cashModelHistories.get(i);
            String TitleDateCash = alldata.getTitleDate();
            String dateValCash = alldata.getDate();
            String AccountNo = alldata.getAccountno();
            String AccountAmount = alldata.getAccountamount();
            String CheckIsDebitCredit = alldata.getCreditdebit();
            String BankName = alldata.getBankName();
            try {
                mydbCash.InsertCash(TitleDateCash, dateValCash, AccountNo, AccountAmount,
                        CheckIsDebitCredit, BankName);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        ArrayList<CashModelHistory> db = new ArrayList<>();
        db.addAll(mydbCash.GetCash());
        Log.e("cashModelHistoriesDB", db.size() + "");

    }


    private String extractMerchantNameFromSMSMy(String mMessage) {
        String MarchantFound = "";
        try {
            Pattern regEx = Pattern.compile("(?i)(?:\\sInfo.\\s*)([A-Za-z0-9*]*\\s?-?\\s?[A-Za-z0-9*]*\\s?-?\\.?)");
            // Find instance of pattern matches
            Matcher m = regEx.matcher(mMessage);
            if (m.find()) {
                String mMerchantName = m.group();
                mMerchantName = mMerchantName.replaceAll("^\\s+|\\s+$", "");//trim from start and end
                mMerchantName = mMerchantName.replace("Info.", "");
                MarchantFound = mMerchantName;
            } else {
                MarchantFound = "";
            }
        } catch (Exception e) {
            MarchantFound = "";
        }

        return MarchantFound;
    }


    @Override
    public void ClickActiveDeactive(final int position, final int color) {
        Log.e("PositionAccount", position + "");

        if (homeAccoutLists.size() > 0) {
            if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {
                InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) getActivity(), false, new Function1<Boolean, Unit>() {
                    @Override
                    public Unit invoke(Boolean aBoolean) {
                        openAccountHistory(homeAccoutLists.get(position),color);
                        return null;
                    }
                });
            } else {
                openAccountHistory(homeAccoutLists.get(position),color);
            }
        }
    }

    private void openAccountHistory(HomeAccoutList homeAccout,int color) {
        Intent i = new Intent(getActivity(), AccountHisotryActivity.class);
        i.putExtra("OBJ", homeAccout);
        i.putExtra("color", color);
        startActivity(i);
    }

    @Override
    public void ClickBusinessOrPersion(int position) {
        if (allAccountModels.size() > 0) {
            boolean isActivinactive = allAccountModels.get(position).isBusinessOrPersion();
            if (isActivinactive) {
                allAccountModels.get(position).setBusinessOrPersion(false);
            } else {
                allAccountModels.get(position).setBusinessOrPersion(true);
            }

            if (allAccountListAdapter != null) {
                allAccountListAdapter.notifyDataSetChanged();
            }
        }
    }


    private String CallGetTransferFrom(String body) {
        String TransferFrom = "";
        for (int i = 0; i < AllBankingTransferFrom.size(); i++) {
            String FromTransfer = AllBankingTransferFrom.get(i);
            if (body.contains(FromTransfer)) {
                TransferFrom = FromTransfer;
                Log.e("MatchTransfer", FromTransfer);
            }
        }
        return TransferFrom;
    }


}