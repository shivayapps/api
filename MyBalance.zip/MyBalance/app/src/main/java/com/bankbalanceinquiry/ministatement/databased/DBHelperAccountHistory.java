package com.bankbalanceinquiry.ministatement.databased;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.bankbalanceinquiry.ministatement.model.AllAccountModelHistory;

import java.util.ArrayList;
import java.util.HashMap;

public class DBHelperAccountHistory extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "MyDBNameHISTORY.db";
    public static final String CONTACTS_TABLE_NAME = "HISTORY";
    public static final String CONTACTS_COLUMN_NAME = "name";
    private HashMap hp;

    public DBHelperAccountHistory(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table HISTORY " +
                "(id integer primary key,TitleDateHistory,dateValHistory,AccountNo,AccountAmount,CheckIsDebitCredit,FinalDescription,TransferFrom)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS HISTORY");
        onCreate(db);
    }

    public void InsertHistory(String TitleDateHistory, String dateValHistory,
                           String AccountNo, String AccountAmount,
                           String CheckIsDebitCredit, String FinalDescription,String TransferFrom) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("TitleDateHistory", TitleDateHistory);
        contentValues.put("dateValHistory", dateValHistory);
        contentValues.put("AccountNo", AccountNo);
        contentValues.put("AccountAmount", AccountAmount);
        contentValues.put("CheckIsDebitCredit", CheckIsDebitCredit);
        contentValues.put("FinalDescription", FinalDescription);
        contentValues.put("TransferFrom", TransferFrom);
        db.insert("HISTORY", null, contentValues);
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from HISTORY where id=" + id + "", null);
        return res;
    }

    public int numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, CONTACTS_TABLE_NAME);
        return numRows;
    }

    public void DeleteAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from " + CONTACTS_TABLE_NAME);
    }



    public Integer deleteContact(String OwnerId) {
      /*  SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("HISTORY",
                "id = ? ",
                new String[]{Integer.toString(id)});*/
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("HISTORY",
                "OwnerId = ? ",
                new String[]{OwnerId});
    }


    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from HISTORY", null);
        return res;
    }

    public ArrayList<AllAccountModelHistory> GetHistory() {
        ArrayList<AllAccountModelHistory> ownerDetails = new ArrayList<AllAccountModelHistory>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from HISTORY", null);
        if (res.getCount() == 0) {

        } else {
            while (res.moveToNext()) {
                String TitleDateHistory = res.getString(res.getColumnIndex("TitleDateHistory"));
                String dateValHistory = res.getString(res.getColumnIndex("dateValHistory"));
                String AccountNo = res.getString(res.getColumnIndex("AccountNo"));
                String AccountAmount = res.getString(res.getColumnIndex("AccountAmount"));
                String CheckIsDebitCredit = res.getString(res.getColumnIndex("CheckIsDebitCredit"));
                String FinalDescription = res.getString(res.getColumnIndex("FinalDescription"));
                String TransferFrom = res.getString(res.getColumnIndex("TransferFrom"));

                ownerDetails.add(new AllAccountModelHistory(TitleDateHistory, dateValHistory,
                        AccountNo, AccountAmount,
                        CheckIsDebitCredit, FinalDescription, TransferFrom));
            }
        }
        return ownerDetails;
    }
}
