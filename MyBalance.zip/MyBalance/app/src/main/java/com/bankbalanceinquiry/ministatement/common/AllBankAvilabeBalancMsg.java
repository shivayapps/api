package com.bankbalanceinquiry.ministatement.common;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.model.AvilabeBalanceModel;

import java.util.ArrayList;

public class AllBankAvilabeBalancMsg {

    public static ArrayList<AvilabeBalanceModel> avilabeBalanceModels = new ArrayList<>();

    public static ArrayList<AvilabeBalanceModel> AddAvilableMsg() {
        avilabeBalanceModels.clear();
        avilabeBalanceModels.add(new AvilabeBalanceModel("Dena Bank", "on date", "Available Clear Bal is Rs", "BX-BKDENA", R.drawable.ic_nb_dena));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Kotak Bank", "on", "Avl bal is Rs", "VK-KOTAKB", R.drawable.ic_nb_kotak));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Kotak Bank", "on", "Avl bal is Rs", "TM-KOTAKB", R.drawable.ic_nb_kotak));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Kotak Bank", "on", "Avl bal is Rs", "AD-KOTAKB", R.drawable.ic_nb_kotak));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Kotak Bank", "on", "Avl bal is Rs", "QP-KOTAKB", R.drawable.ic_nb_kotak));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Kotak Bank", "on", "Avl bal is Rs", "VM-KOTAKB", R.drawable.ic_nb_kotak));
        avilabeBalanceModels.add(new AvilabeBalanceModel("ICICI Bank", "on", "Available Balance is INR", "VM-ICICIB", R.drawable.ic_nb_icici));
        avilabeBalanceModels.add(new AvilabeBalanceModel("ICICI Bank", "on", "Available Balance is INR", "AD-ICICIB", R.drawable.ic_nb_icici));
        avilabeBalanceModels.add(new AvilabeBalanceModel("ICICI Bank", "on", "Available Balance is INR", "JD-ICICIB", R.drawable.ic_nb_icici));
        avilabeBalanceModels.add(new AvilabeBalanceModel("ICICI Bank", "on", "Available Balance: INR", "VM-ICICIB", R.drawable.ic_nb_icici));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Central Bank", "on", "Total Bal: Rs.", "VK-CENTBK", R.drawable.ic_nb_cent));
        //avilabeBalanceModels.add(new AvilabeBalanceModel("CENTRAL", "on", "CR Bal: Rs."));
        avilabeBalanceModels.add(new AvilabeBalanceModel("SBI Group Bank", "on", "Avl Bal Rs", "VK-CBSSBI", R.drawable.ic_nb_sbi));
        avilabeBalanceModels.add(new AvilabeBalanceModel("SBI Group Bank", "on", "Avl Bal Rs", "BW-SCISMS", R.drawable.ic_nb_sbi));
        avilabeBalanceModels.add(new AvilabeBalanceModel("SBI Group Bank", "on", "Avl Bal Rs", "BZ-ATMSBI", R.drawable.ic_nb_sbi));
        avilabeBalanceModels.add(new AvilabeBalanceModel("SBI Group Bank", "on", "Avl Bal Rs", "BP-ATMSBI", R.drawable.ic_nb_sbi));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Axis Bank", "on", "Avbl Bal", "AM-AxisBk", R.drawable.ic_nb_axis));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Axis Bank", "on", "balance is Rs", "VM-AxisBk", R.drawable.ic_nb_axis));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Axis Bank", "on", "balance is Rs", "VK-AxisBk", R.drawable.ic_nb_axis));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Axis Bank", "on", "balance is Rs", "BH-AxisBk", R.drawable.ic_nb_axis));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Axis Bank", "on", "balance is Rs", "VMAxisBk", R.drawable.ic_nb_axis));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Bank of Baroda", "As on", "is Rs.", "AX-BOBSMS", R.drawable.ic_nb_bob));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Citibank", "on", "Avbl Bal INR", "Citibank", R.drawable.ic_nb_citi));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Yes Bank", "on", "Tot Avbl Bal-INR", "AD-YESBNK", R.drawable.ic_nb_yes));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Punjab National Bank", "on", "Tot Avbl Bal-INR", "IM-PNBSMS", R.drawable.ic_nb_pnb));
        avilabeBalanceModels.add(new AvilabeBalanceModel("Paytm Bank", "on", "Avl Bal Rs.", "AX-PAYTMB", R.drawable.ic_nb_pnb));
        return avilabeBalanceModels;
    }

    public static ArrayList<String> GetTransperFrom() {
        ArrayList<String> alldata = new ArrayList<>();
        alldata.add("UPI");
        alldata.add("NEFT");
        alldata.add("INFT");
        alldata.add("IMPS");
        alldata.add("Cash");
        return alldata;
    }

    public static ArrayList<BankNameLogo> getBankNameAndLogo() {
        ArrayList<BankNameLogo> bankNameLogos = new ArrayList<>();

        bankNameLogos.add(new BankNameLogo("SBI", R.drawable.ic_bank_logo_sbi));
        bankNameLogos.add(new BankNameLogo("BOB", R.drawable.ic_nb_bob));
        bankNameLogos.add(new BankNameLogo("IDB", R.drawable.ic_nb_idb));
        bankNameLogos.add(new BankNameLogo("CBI", R.drawable.ic_nb_cent));
        bankNameLogos.add(new BankNameLogo("HDF", R.drawable.ic_nb_hdfc));
        bankNameLogos.add(new BankNameLogo("CNB", R.drawable.ic_nb_citi));
        bankNameLogos.add(new BankNameLogo("AXB", R.drawable.ic_nb_axis));
        bankNameLogos.add(new BankNameLogo("KMB", R.drawable.ic_nb_kotak));
        bankNameLogos.add(new BankNameLogo("YBL", R.drawable.ic_nb_yes));
        bankNameLogos.add(new BankNameLogo("YBL", R.drawable.ic_nb_pnb));
        bankNameLogos.add(new BankNameLogo("BOB", R.drawable.ic_nb_bob));
        bankNameLogos.add(new BankNameLogo("CNB", R.drawable.ic_nb_canrabank));
        bankNameLogos.add(new BankNameLogo("BOI", R.drawable.ic_nb_boi));
        bankNameLogos.add(new BankNameLogo("CRB", R.drawable.ic_nb_bcrb));
        bankNameLogos.add(new BankNameLogo("UOB", R.drawable.ic_nb_union));
        bankNameLogos.add(new BankNameLogo("VJB", R.drawable.ic_nb_bob));
        bankNameLogos.add(new BankNameLogo("SIB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("HSB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("BKDENA", R.drawable.ic_nb_dena));

        bankNameLogos.add(new BankNameLogo("HSB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("FBL", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("IOB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("IDF", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("DLB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("ABN", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("ALB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("ANB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("ANZ", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("BOM", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("PLC", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("INB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("BMB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("BAND", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("SRC", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("CBP", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("SCB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("SBJ", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("DB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("SYB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("DLB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("UBI", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("KTB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("CUB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("IIB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("JSB", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("ICI", R.drawable.ic_nb_sindb));
        bankNameLogos.add(new BankNameLogo("TMB", R.drawable.ic_nb_sindb));

        return bankNameLogos;
    }

    public static ArrayList<String> GetAvilabeBalanceArrayList() {
        ArrayList<String> alldata = new ArrayList<>();
        alldata.add("Available Clear Bal is Rs.");
        alldata.add("Avbl Bal: Rs.");
        alldata.add("Avl bal is Rs");
        alldata.add("Available Balance is INR");
        alldata.add("Total Bal: Rs.");
        alldata.add("Avl Bal Rs");
        alldata.add("balance is Rs");
        alldata.add("Balance is Rs");
        alldata.add("balance is Rs");
        alldata.add("is Rs.");
        alldata.add("Avbl Bal INR");
        alldata.add("Avbl Bal Rs");
        alldata.add("Tot Avbl Bal-INR");
        alldata.add("Avl Bal Rs.");
        alldata.add("Avlbal Rs");
        alldata.add("Avbl Bal is Rs");
        alldata.add("Avl Bal Rs");
        alldata.add("Bal is Rs");
        alldata.add("Total Bal: Rs.");
        alldata.add("Available Balance: INR");
        alldata.add("Avbl Bal");
        //alldata.add("Available");
        return alldata;
    }

}
