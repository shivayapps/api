package com.bankbalanceinquiry.ministatement.newmodel;

import java.io.Serializable;
import java.util.ArrayList;

public class HomeAccoutList implements Serializable {

    public String full_name = "";
    public String account_type = "";
    public String sms_type = "";
    public String FinalAccountBalance = "";
    public String FinalAccountNo = "";
    public String body = "";

    public ArrayList<String> transactionDescs = new ArrayList<>();
    public ArrayList<String> dates = new ArrayList<>();
    public ArrayList<String> amounts = new ArrayList<>();
    public ArrayList<String> eventNames = new ArrayList<>();
    public ArrayList<String> eventLocations = new ArrayList<>();
    public ArrayList<String> eventInfos = new ArrayList<>();
    public ArrayList<String> dateFormats = new ArrayList<>();

    public String panValue = "";
    public String mTransactionType = "";
    public String transactionDesc = "";
    public String transactionPos = "";
    public String date = "";
    public String amount = "";
    public String eventName = "";
    public String eventLocation = "";
    public String eventInfo = "";

    public String txn_type = "";

    public boolean isDebited = true;
    public boolean isAtmWithDraw = false;
    public boolean use_sms_time = false;


    public String finalTransactionDesc = "";
    public String dateValAccount, DateTransactionHistory, dateValHistory;
    public int GetTitleType = 1;
    public boolean isSectionHeader = false;
    public ArrayList<String> CreditedData=new ArrayList<>();
    public ArrayList<String> DebitedData=new ArrayList<>();

    @Override
    public String toString() {
        return full_name;
    }

}
