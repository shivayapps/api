package com.bankbalanceinquiry.ministatement.currencies.viewmodel.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import com.bankbalanceinquiry.ministatement.currencies.repository.Database
import com.bankbalanceinquiry.ministatement.currencies.repository.ExchangeRatesRepository
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.*

class ExchangeRatesViewModel(application: Application) : AndroidViewModel(application) {

    private var repository: ExchangeRatesRepository = ExchangeRatesRepository(application)

    private var dbLiveItems: LiveData<com.bankbalanceinquiry.ministatement.currencies.model.ExchangeRates?>
    private val liveError = repository.getError()

    private var isUpdating: LiveData<Boolean> = repository.isUpdating()

    /*
     * items =======================================================================================
     */

    init {
        // only update if data is old: https://github.com/Formicka/exchangerate.host
        // "Rates are updated around midnight UTC every working day."

        //val currentTime = LocalDateTime.now(ZoneId.of("UTC"))
        val currentTime = Date(System.currentTimeMillis())
        val cachedDate = Database.getInstance(application).getDate()

        dbLiveItems =
            when {
                // first run: fetch data
                cachedDate == null -> repository.getExchangeRates()
                // also fetch if stored date is before the current date
//                cachedDate
//                    .plusDays(1)
//                    .atStartOfDay()
//                    .plusHours(1) // add 1 hour to be sure: "…AROUND midnight…"
//                    .isBefore(currentTime) -> repository.getExchangeRates()
                // else just use the cached value
                else -> Database.getInstance(application).getExchangeRates()
            }
    }

    fun getExchangeRate(): LiveData<com.bankbalanceinquiry.ministatement.currencies.model.ExchangeRates?> {
        val liveItems = MediatorLiveData<com.bankbalanceinquiry.ministatement.currencies.model.ExchangeRates?>()
        liveItems.addSource(dbLiveItems) { exchangeRates ->
            exchangeRates?.let {
                liveItems.value = exchangeRates
            }
        }
        return liveItems
    }

    fun forceUpdateExchangeRate() {
        if (isUpdating.value != true)
            dbLiveItems = repository.getExchangeRates()
    }

    /*
     * error =======================================================================================
     */

    fun getError(): LiveData<String?> = liveError

    fun isUpdating(): LiveData<Boolean> = isUpdating

}
