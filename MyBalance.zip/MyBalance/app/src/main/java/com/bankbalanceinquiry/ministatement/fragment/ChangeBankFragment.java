package com.bankbalanceinquiry.ministatement.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.adapter.listBankAdapter;
import com.bankbalanceinquiry.ministatement.database.DatabaseAccess;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.model.bankname;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;

import java.util.ArrayList;
import java.util.List;

import static com.bankbalanceinquiry.ministatement.activity.drawerActivity.toolbar;

public class ChangeBankFragment extends Fragment {

    View root;
    public static ListView custom_list_view;
    com.bankbalanceinquiry.ministatement.adapter.listBankAdapter listBankAdapter;
    List<bankname> mData;
    private DBHelperAccountNew mydbAccountNew;
    private DatabaseAccess databaseAccess;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_changebank, container, false);

        toolbar.setTitle(getContext().getResources().getString(R.string.menu_change));
        custom_list_view = (ListView) root.findViewById(R.id.custom_list_view);

        databaseAccess = DatabaseAccess.getInstance(getActivity());
        databaseAccess.open();
        mydbAccountNew = new DBHelperAccountNew(getActivity());
        //mData = databaseAccess.getList();

        ArrayList<HomeAccoutList> homeAccoutListArrayList = mydbAccountNew.GetAllAccountNew();
        mData=sortBank(homeAccoutListArrayList);

        databaseAccess.close();
        String[] bankColor_array = getActivity().getResources().getStringArray(R.array.listcolors);

        listBankAdapter = new listBankAdapter(getActivity(), mData, bankColor_array);
        custom_list_view.setAdapter(listBankAdapter);

        Log.e("Size---)", "" + mData.size());
        toolbar.setTitle(R.string.app_name);


        return root;
    }


    private List<bankname> sortBank(ArrayList<HomeAccoutList> homeAccoutList){
        List<bankname> mHomeBank=new ArrayList<>();
        for (int i=0;i<homeAccoutList.size();i++){
            mHomeBank.addAll(databaseAccess.getBalance_details(homeAccoutList.get(i).full_name));
        }

        /*for (int i=0;i<mHomeBank.size();i++){
            for (int j=i;j<mHomeBank.size();j++){
                if(!mHomeBank.get(i).getB_name().equalsIgnoreCase(mHomeBank.get(j).getB_name())){
                    mHomeBank.remove(i);
                }
            }
        }*/
        return mHomeBank;
    }

    public void onbackPressed() {
        super.getActivity().onBackPressed();
    }
}
