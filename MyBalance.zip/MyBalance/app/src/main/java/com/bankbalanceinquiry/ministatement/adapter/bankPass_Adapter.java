package com.bankbalanceinquiry.ministatement.adapter;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.model.passBook;

import java.util.List;

public class bankPass_Adapter extends RecyclerView.Adapter<bankPass_Adapter.Viewholder>
{
    Context mContext;
    List<passBook> pData;
    public bankPass_Adapter(FragmentActivity activity, List<passBook> pData)
    {
        this.mContext=activity;
        this.pData=pData;

    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.passbook_layout,null);

        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, int position) {

        try
        {
            holder.pass_decription.setText(pData.get(position).getPass_dec());
            holder.pass_date.setText(pData.get(position).getPass_date());

//            if(pData.get(position).getPass_amount().matches("null"))
//            {
//                holder.pass_amount.setText("\u20B9"+"0");
//            }
//            else
//            {
                holder.pass_amount.setText("\u20B9"+pData.get(position).getPass_amount());
           // }

            Log.e("fDescri-==)",""+pData.get(position).getPass_dec());
            Log.e("fAmount-==)",""+pData.get(position).getPass_amount());
            Log.e("fdate-==)",""+pData.get(position).getPass_date());
            Log.e("fWhich-==)",""+pData.get(position).getPass_which());


            holder.pass_perform.setText(pData.get(position).getPass_which());

            String img=pData.get(position).getPass_which();

            if(img.matches("Dr"))
            {
                holder.img_which.setImageResource(R.drawable.debit);
                holder.pass_perform.setTextColor(Color.RED);
            }
            else
            {
                holder.img_which.setImageResource(R.drawable.credit);
                holder.pass_perform.setTextColor(Color.GREEN);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return pData.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder
    {
        TextView pass_decription,pass_date,pass_perform,pass_amount;
        ImageView img_which;
        public Viewholder(@NonNull View itemView)
        {
            super(itemView);

            img_which=(ImageView)itemView.findViewById(R.id.img_which);
            pass_decription=(TextView) itemView.findViewById(R.id.pass_decription);
            pass_date=(TextView) itemView.findViewById(R.id.pass_date);
            pass_perform=(TextView) itemView.findViewById(R.id.pass_perform);
            pass_amount=(TextView) itemView.findViewById(R.id.pass_amount);
        }
    }
}
