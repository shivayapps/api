package com.gallery.photo.image.video.ui.activity

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ActivitySettingBinding
import com.gallery.photo.image.video.ui.activity.setting.FeedBackActivity
import com.gallery.photo.image.video.ui.activity.setting.LanguageActivity
import com.gallery.photo.image.video.ui.dialog.ThemeDialog
import com.gallery.photo.image.video.ui.model.LanguageData
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.MyApplication
import com.gallery.photo.image.video.utils.Preferences

class SettingActivity : BaseActivity() {

    lateinit var binding: ActivitySettingBinding
    var languageList: ArrayList<LanguageData> = ArrayList()
    lateinit var preferences: Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        preferences = Preferences(this)
        val bundle2 = Bundle()
        bundle2.putString("Setting", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        intListener()
        binding.loutToolbar.txtTitle.text = getString(R.string.setting)
        binding.loutToolbar.icSelect.visibility = View.GONE
        binding.loutToolbar.ivDone.visibility = View.INVISIBLE

        binding.tvAppVersion.text = getAppVersion()
        val selectPos = preferences.getSelectLanguage()
        getLanList()
        binding.tvLanguage.text =
            if (selectPos == 0) getString(R.string.Default) else languageList[selectPos].name
    }

    var languageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                setResult(RESULT_OK)
                recreate()
                Constant.isChangeLanguage = true
            }
        }


    private fun intListener() {
        binding.loutToolbar.icBack.setOnClickListener { finish() }
        binding.llTheme.setOnClickListener {
            val themeDialog = ThemeDialog(updateListener = {
                val intent = Intent(this, SettingActivity::class.java)
                setResult(RESULT_OK)
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
            })
            themeDialog.show(supportFragmentManager, themeDialog.tag)
        }
        binding.llLanguage.setOnClickListener {
            languageLauncher.launch(Intent(this, LanguageActivity::class.java))
        }
        binding.llClearCache.setOnClickListener { }
        binding.llFeedback.setOnClickListener {
            startActivity(Intent(this, FeedBackActivity::class.java))
        }
        binding.llRate.setOnClickListener {
            showRateDialog()
        }
        binding.llShare.setOnClickListener {
            try {
                val sendIntent = Intent()
                sendIntent.action = Intent.ACTION_SEND
                sendIntent.putExtra(
                    Intent.EXTRA_TEXT,
                    "Check out the App at: https://play.google.com/store/apps/details?id=$packageName"
                )
                sendIntent.type = "text/plain"
                MyApplication.disabledOpenAds()
                startActivity(sendIntent)
            } catch (e: Exception) {

            }
        }
        binding.llPrivacyPolicy.setOnClickListener {
            openPrivacyPolicy()
        }

    }

    private fun getLanList() {
        languageList.add(
            LanguageData(
                getString(R.string.english),
                "en"
//                , ContextCompat.getDrawable(this, R.drawable.english)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.spanish),
                "es"
//                , ContextCompat.getDrawable(this, R.drawable.spanish)
            )
        )
        languageList.add(
            LanguageData(
                getString(R.string.german),
                "de"
//                , ContextCompat.getDrawable(this, R.drawable.german)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.french),
                "fr"
//                , ContextCompat.getDrawable(this, R.drawable.french)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.russian),
                "ru"
//                , ContextCompat.getDrawable(this, R.drawable.russian)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.hindi),
                "hi"
//                , ContextCompat.getDrawable(this, R.drawable.hindi)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.filipino),
                "fil"
//                , ContextCompat.getDrawable(this, R.drawable.filipino)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.chinese),
                "zh"
//                , ContextCompat.getDrawable(this, R.drawable.chinese)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.italian),
                "it"
//                , ContextCompat.getDrawable(this, R.drawable.italian)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.turkish),
                "in"
//                , ContextCompat.getDrawable(this, R.drawable.turkish)
            )
        )

    }

}