package com.gallery.photo.image.video.ui.activity.itro

import android.content.Intent
import android.os.Bundle
import com.gallery.photo.image.video.databinding.ActivityStartBinding
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.ui.activity.HomeActivity
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences

class StartActivity : BaseActivity() {

    lateinit var preferences: Preferences
    lateinit var binding: ActivityStartBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        inti()
    }

    private fun inti() {
        val bundle2 = Bundle()
        bundle2.putString("Start", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        preferences = Preferences(this)
        binding.btnAllow.setOnClickListener {
            preferences.putStart(true)
            setNext()
        }
        loadNativeAdsStart(binding.frameNative)
    }

    private fun setNext() {
        val intent =  if (!checkStoragePermission())
            Intent(this, PermissionActivity::class.java)
        else
            Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish()
    }

}