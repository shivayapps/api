package com.gallery.photo.image.video.ui.activity.edit

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.AdapterView
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import android.widget.Toast
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.customView.CustomSpinner
import com.gallery.photo.image.video.databinding.ActivityDoodleBinding
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.ui.adapter.edit.ColorAdapter
import com.gallery.photo.image.video.ui.adapter.edit.SelectDoodleAdapter
import com.gallery.photo.image.video.ui.dialog.ProgressDialog
import com.gallery.photo.image.video.ui.model.edit.EditData
import com.gallery.photo.image.video.utils.Constant
import io.reactivex.annotations.NonNull
import ja.burhanrashid52.photoeditor.OnPhotoEditorListener
import ja.burhanrashid52.photoeditor.PhotoEditor
import ja.burhanrashid52.photoeditor.ViewType
import ja.burhanrashid52.photoeditor.shape.ShapeBuilder
import ja.burhanrashid52.photoeditor.shape.ShapeType


class DoodleActivity : BaseActivity(), OnPhotoEditorListener {

    lateinit var binding: ActivityDoodleBinding

    var imagePath = ""
    var saveImageName = ""
    lateinit var mPhotoEditor: PhotoEditor
    private lateinit var mShapeBuilder: ShapeBuilder
    lateinit var spinnerAdapter: SelectDoodleAdapter
    var optionList: ArrayList<EditData> = ArrayList()
    var spinnerPos = -1
    var addViewTotal = 0
    var addViewShow = 0
    var isCallRedo = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDoodleBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        val bundle2 = Bundle()
        bundle2.putString("EditDoodle", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        intListener()
        setSelectButton(binding.btnBrush)
        setUndoRedoView(0)
        binding.loutToolbar.loutUndoRedo.visibility = View.VISIBLE
        binding.loutToolbar.txtTitle.visibility = View.GONE

        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        saveImageName = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_NAME) ?: ""

//        val matchParent = RelativeLayout.LayoutParams.MATCH_PARENT
//        binding.photoEditorView.source.layoutParams = RelativeLayout.LayoutParams(matchParent, matchParent)
//        binding.photoEditorView.source.requestLayout()
//        binding.photoEditorView.source.scaleType = ImageView.ScaleType.FIT_XY;

        mPhotoEditor = PhotoEditor.Builder(this, binding.photoEditorView)
            .setPinchTextScalable(false) // set flag to make text scalable when pinch
            //.setDefaultTextTypeface(mTextRobotoTf)
            //.setDefaultEmojiTypeface(mEmojiTypeFace)
            .build() // build photo editor sdk

//        PhotoEditor.Builder(this,  binding.photoEditorView).build()
        mPhotoEditor.setOnPhotoEditorListener(this)
        mPhotoEditor.setBrushDrawingMode(true)
        mShapeBuilder = ShapeBuilder()
//        onColorChanged(R.color.white_color)
        onOpacityChanged(255)
        mPhotoEditor.setShape(mShapeBuilder)

        val width = getScreenWidth()
        val bitmap = getBitmapFromFilePath(imagePath)
        if (bitmap != null) {
            if (bitmap.width < width) {
                Thread {
                    val ratio: Float = bitmap.width / bitmap.height.toFloat()
                    val height = (width / ratio).toInt()
                    val newBitmap =
                        Glide.with(this.applicationContext).asBitmap()
                            .load(imagePath)
                            .submit(width, height)
                            .get()
                    binding.photoEditorView.source.setImageBitmap(newBitmap)
                }.start()
            } else
                binding.photoEditorView.source.setImageBitmap(bitmap)

        } else
            binding.photoEditorView.source.setImageBitmap(bitmap)

//        Glide
//            .with(this)
//            .asBitmap()
//            .load(imagePath)
//            .diskCacheStrategy(DiskCacheStrategy.NONE)
//            .skipMemoryCache(true)
//            .into(object : CustomTarget<Bitmap>() {
//                override fun onResourceReady(
//                    resource: Bitmap,
//                    transition: Transition<in Bitmap>?
//                ) {
//                    binding.photoEditorView.source.setImageBitmap(resource)
//
//                }
//
//                override fun onLoadCleared(placeholder: Drawable?) {
//
//                }
//            })

        setSpinnerData()
        setColorAdapter()

    }

    private fun setColorAdapter() {
        val colorAdapter = ColorAdapter(this, clickListener = {
            onColorChanged(it)
        })
        binding.recyclerView.adapter = colorAdapter
        onColorChanged(colorAdapter.colorList[0])
    }

    private fun setSpinnerData() {
        optionList.add(
            EditData(
                getString(R.string.color),
                ContextCompat.getDrawable(this, R.drawable.ic_color)
            )
        )
        optionList.add(
            EditData(
                getString(R.string.size),
                ContextCompat.getDrawable(this, R.drawable.ic_size)
            )
        )
        optionList.add(
            EditData(
                getString(R.string.opacity),
                ContextCompat.getDrawable(this, R.drawable.ic_opacity)
            )
        )

        spinnerAdapter = SelectDoodleAdapter(this, optionList)
        binding.spinner.adapter = spinnerAdapter
        binding.spinner.setSelection(0)

        binding.spinner.onPopUpOpenedListener = { spinner: CustomSpinner ->
            // called when the pop-up is opened
            Log.e("SpinnerTag", "onPopUp Opened")
//            rotationAngle = if (rotationAngle == 0f) 180f else 0f
//            binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
        }

        binding.spinner.onPopUpClosedListener = { spinner: CustomSpinner ->
            // called when the pop-up is closed
            Log.e("SpinnerTag", "onPopUp Closed")
//            rotationAngle = if (rotationAngle == 0f) 180f else 0f
//            binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
        }

        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position != -1)
                    binding.txtItemSpinner.text = optionList[position].name

                if (spinnerPos != position) {
                    spinnerPos = position

                    when (spinnerPos) {
                        0 -> {
                            binding.shapeOpacity.visibility = View.GONE
                            binding.shapeSize.visibility = View.GONE
                            binding.recyclerView.visibility = View.VISIBLE
                        }

                        1 -> {
                            binding.shapeSize.visibility = View.VISIBLE
                            binding.shapeOpacity.visibility = View.GONE
                            binding.recyclerView.visibility = View.GONE
                        }

                        2 -> {
                            binding.shapeOpacity.visibility = View.VISIBLE
                            binding.shapeSize.visibility = View.GONE
                            binding.recyclerView.visibility = View.GONE
                        }
                    }
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
            }

        }

    }

    fun onColorChanged(colorCode: Int) {
        mPhotoEditor.setShape(mShapeBuilder.withShapeColor(colorCode))
    }

    fun onOpacityChanged(opacity: Int) {
        mPhotoEditor.setShape(mShapeBuilder.withShapeOpacity(opacity))
    }

    fun onShapeSizeChanged(shapeSize: Int) {
        mPhotoEditor.setShape(mShapeBuilder.withShapeSize(shapeSize.toFloat()))
    }

    private fun intListener() {
        binding.loutToolbar.icBack.setOnClickListener { onBackPressed() }
        binding.loutToolbar.icDone.setOnClickListener {
            binding.loutToolbar.icDone.isEnabled = false
            val progressDialog = ProgressDialog(this, getString(R.string.saving))
            progressDialog.show()

            mPhotoEditor.saveAsFile(getSaveEditPath(saveImageName), object :
                PhotoEditor.OnSaveListener {
                override fun onSuccess(@NonNull imagePath: String) {
                    Log.e("PhotoEditor", "Image Saved Successfully $imagePath")
                    val intent = Intent()
                    intent.putExtra(Constant.EXTRA_EDIT_SAVE_IMAGE, imagePath)
                    setResult(RESULT_OK, intent)
                    progressDialog.dismiss()
                    finish()
                }

                override fun onFailure(@NonNull exception: Exception) {
                    Log.e("PhotoEditor", "Failed to save Image")
                    binding.loutToolbar.icDone.isEnabled = true
                    progressDialog.dismiss()
                    Toast.makeText(
                        this@DoodleActivity,
                        getString(R.string.image_editing_failed),
                        Toast.LENGTH_SHORT
                    )
                        .show()
                }
            })
        }

        binding.btnBrush.setOnClickListener {
            setSelectButton(binding.btnBrush)
            setShareType(ShapeType.Brush)
        }
        binding.btnLine.setOnClickListener {
            setSelectButton(binding.btnLine)
            setShareType(ShapeType.Line)
        }
        binding.btnArrow.setOnClickListener {
            setSelectButton(binding.btnArrow)
            setShareType(ShapeType.Arrow())
        }
        binding.btnRectangle.setOnClickListener {
            setSelectButton(binding.btnRectangle)
            setShareType(ShapeType.Rectangle)
        }
        binding.btnCircle.setOnClickListener {
            setSelectButton(binding.btnCircle)
            setShareType(ShapeType.Oval)
        }

        binding.loutToolbar.icUndo.setOnClickListener {
            if (addViewShow > 0) {
                mPhotoEditor.undo()
            }
        }
        binding.loutToolbar.icRedo.setOnClickListener {
            if (addViewShow < addViewTotal) {
                isCallRedo = true
                mPhotoEditor.redo()
            }
        }

        binding.shapeSize.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, i: Int, b: Boolean) {
                onShapeSizeChanged(i)
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {

            }

        })

        binding.shapeOpacity.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, i: Int, b: Boolean) {
                onOpacityChanged(i)
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {

            }

        })
    }

    private fun setSelectButton(button: AppCompatImageView) {
        setUnSelectAll()
        button.background = ContextCompat.getDrawable(this, R.drawable.bg_squre_select)
        button.setColorFilter(
            ContextCompat.getColor(this@DoodleActivity, R.color.black_text),
            PorterDuff.Mode.SRC_IN
        )

    }

    private fun setUnSelectAll() {
        val drawable = ContextCompat.getDrawable(this, R.drawable.bg_squre)
        val color = ContextCompat.getColor(this@DoodleActivity, R.color.home_unSelect_tab_icon)

        binding.btnBrush.background = drawable
        binding.btnRectangle.background = drawable
        binding.btnLine.background = drawable
        binding.btnArrow.background = drawable
        binding.btnCircle.background = drawable

        binding.btnBrush.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.btnRectangle.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.btnLine.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.btnArrow.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.btnCircle.setColorFilter(color, PorterDuff.Mode.SRC_IN)

    }

    private fun setShareType(shapeType: ShapeType) {
        mPhotoEditor.setShape(mShapeBuilder.withShapeType(shapeType))
    }


    override fun onAddViewListener(viewType: ViewType?, numberOfAddedViews: Int) {
        Log.e("EDITTAG", "onAddViewListener numberOfAddedViews $numberOfAddedViews")
        if (isCallRedo)
            isCallRedo = false
        else
            addViewTotal++
        setUndoRedoView(numberOfAddedViews)
    }

    private fun setUndoRedoView(numberOfAddedViews: Int) {
        addViewShow = numberOfAddedViews
        val visibleColor = ContextCompat.getColor(this@DoodleActivity, R.color.black_text)
        val unVisibleColor = ContextCompat.getColor(this@DoodleActivity, R.color.grayText)
        binding.loutToolbar.icUndo.setColorFilter(
            if (numberOfAddedViews == 0) unVisibleColor else visibleColor,
            PorterDuff.Mode.SRC_IN
        )

        binding.loutToolbar.icRedo.setColorFilter(
            if (numberOfAddedViews == addViewTotal) unVisibleColor else visibleColor,
            PorterDuff.Mode.SRC_IN
        )
    }

    override fun onEditTextChangeListener(rootView: View?, text: String?, colorCode: Int) {

    }

    override fun onRemoveViewListener(viewType: ViewType?, numberOfAddedViews: Int) {
        Log.e("EDITTAG", "onRemoveViewListener numberOfAddedViews $numberOfAddedViews")
        setUndoRedoView(numberOfAddedViews)
    }

    override fun onStartViewChangeListener(viewType: ViewType?) {
        Log.e("EDITTAG", "onRemoveViewListener onStartViewChangeListener ${viewType.toString()}")
    }

    override fun onStopViewChangeListener(viewType: ViewType?) {
        Log.e("EDITTAG", "onRemoveViewListener onStopViewChangeListener ${viewType.toString()}")
    }

    override fun onTouchSourceImage(event: MotionEvent?) {
        Log.e("EDITTAG", "onRemoveViewListener onTouchSourceImage ${event.toString()}")
    }
}