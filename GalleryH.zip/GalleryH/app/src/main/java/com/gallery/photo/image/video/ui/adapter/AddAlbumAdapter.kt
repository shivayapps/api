package com.gallery.photo.image.video.ui.adapter

import android.content.Context
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.shape.MaterialShapeDrawable
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ItemAddAlbumBinding
import com.gallery.photo.image.video.ui.model.AlbumData

class AddAlbumAdapter(
    var context: Context,
    var list: ArrayList<AlbumData>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<AddAlbumAdapter.ViewHolder>() {

    var selectPos = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemAddAlbumBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.tvName.text = list[position].title

        if (selectPos == position)
            holder.binding.ivSelect.setImageDrawable(
                ContextCompat.getDrawable(
                    context,
                    R.drawable.ic_check_on
                )
            )
        else
            holder.binding.ivSelect.setImageDrawable(
                ContextCompat.getDrawable(
                    context,
                    R.drawable.ic_check_off
                )
            )

        val albumData = list[position]
        holder.binding.tvCount.visibility = if (albumData.isCustomAlbum) View.GONE else View.VISIBLE
        holder.binding.icAddAlbum.visibility = if (albumData.isCustomAlbum) View.VISIBLE else View.GONE

        if (albumData.pictureData.isNotEmpty()) {
            holder.binding.tvCount.text = "${albumData.pictureData.size}"

            Glide.with(context.applicationContext).load(albumData.pictureData[0].filePath)
              .into(holder.binding.image)

        } else {
            holder.binding.tvCount.text = "0"
            val materialShapeDrawable = MaterialShapeDrawable(holder.binding.image.shapeAppearanceModel)
            materialShapeDrawable.fillColor = ColorStateList.valueOf(ContextCompat.getColor(context,R.color.add_album_bg))
            holder.binding.image.setImageDrawable(materialShapeDrawable)
        }

        holder.binding.root.setOnClickListener {
            val p = selectPos
            selectPos = position
            clickListener(position)
            notifyItemChanged(selectPos)
            if (p != -1)
                notifyItemChanged(p)
        }
    }

    class ViewHolder(var binding: ItemAddAlbumBinding) : RecyclerView.ViewHolder(binding.root) {

    }
}