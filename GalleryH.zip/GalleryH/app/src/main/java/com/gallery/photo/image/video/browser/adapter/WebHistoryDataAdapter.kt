package com.gallery.photo.image.video.browser.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.browser.database.DataBaseClass
import com.gallery.photo.image.video.browser.model.Secure_MediaDataModal
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date

class WebHistoryDataAdapter constructor(
    historyArrayList: ArrayList<Secure_MediaDataModal>,
    activity: Activity?,
    view: View,
    tag: Int,
    val clickListener: (url: String) -> Unit,
    val deleteListener: () -> Unit
) : RecyclerView.Adapter<WebHistoryDataAdapter.MyViewHolder>() {
    var historyArrayList: ArrayList<Secure_MediaDataModal>
    var activity: Activity?
    var name: String = "asd"
    var currentDateTimeString: String
    var yesterday: String
    var view: View
    var isNumberMatch: Boolean = false
    var secureDataBaseClass: DataBaseClass
    var tag: Int

    init {
        secureDataBaseClass = DataBaseClass(activity, activity!!)
        this.tag = tag
        this.historyArrayList = historyArrayList
        this.view = view
        this.activity = activity
        val ddd = Date()
        val formatter2 = SimpleDateFormat("dd-MMM-yyyy")
        currentDateTimeString = formatter2.format(ddd)
        val cal: Calendar = Calendar.getInstance()
        cal.add(Calendar.DATE, -1)
        cal.time
        val dateFormat: DateFormat = SimpleDateFormat("dd-MMM-yyyy")
        yesterday = dateFormat.format(cal.time)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view: View =
            LayoutInflater.from(activity).inflate(R.layout.item_history_layouts, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val secureMediaDataModal: Secure_MediaDataModal = historyArrayList.get(position)
        if (tag == 0) {
            if (!isNumberMatch) {
                if ((name == secureMediaDataModal.number)) {
                    holder.tv_title.visibility = View.GONE
                } else {
                    holder.tv_title.visibility = View.VISIBLE
                    name = secureMediaDataModal.number.toString()
                }
            }
            if (historyArrayList.size == position + 1) {
                isNumberMatch = true
            }
            if (secureMediaDataModal.number
                    .equals("" + currentDateTimeString, ignoreCase = true)
            ) {
                holder.tv_title.text = activity!!.getString(R.string.today)
            } else if (secureMediaDataModal.number.equals("" + yesterday, ignoreCase = true)) {
                holder.tv_title.text = activity!!.getString(R.string.Yesterday)
            } else {
                holder.tv_title.text = secureMediaDataModal.number
            }
        }
        if (secureMediaDataModal.name!!.contains("https://www.facebook.com/")) {
            holder.iv_icon.setImageResource(R.drawable.ic_facebook_browser)
        } else if (secureMediaDataModal.name!!.contains("https://www.instagram.com/")) {
            holder.iv_icon.setImageResource(R.drawable.ic_instagram_browser)
        } else if (secureMediaDataModal.name!!.contains("https://www.flickr.com/")) {
            holder.iv_icon.setImageResource(R.drawable.ic_flickr_browser)
        } else if (secureMediaDataModal.name!!.contains("https://m.imdb.com/")) {
            holder.iv_icon.setImageResource(R.drawable.ic_imdb_browser)
        } else if (secureMediaDataModal.name!!.contains("https://twitter.com/")) {
            holder.iv_icon.setImageResource(R.drawable.ic_twitch_browser)
        } else {
            holder.iv_icon.setImageResource(R.drawable.ic_google_browser)
        }
        if (secureMediaDataModal.path == null) {
            holder.tv_url_title.text = secureMediaDataModal.name
        } else {
            holder.tv_url_title.text = secureMediaDataModal.path
        }
        holder.tv_url.text = secureMediaDataModal.name
        holder.itemView.setOnClickListener {
//            val ll_search: LinearLayout = view.findViewById(R.id.ll_search)
//            val ll_media: LinearLayout = view.findViewById(R.id.ll_media)
//            val ll_main: LinearLayout = view.findViewById(R.id.ll_mains)
//            val ll_history: LinearLayout = view.findViewById(R.id.ll_history)
//            ll_main.visibility = View.VISIBLE
//            ll_history.visibility = View.GONE
//            val webs: WebView = view.findViewById(R.id.webs)
//            ll_search.visibility = View.GONE
//            ll_search.visibility = View.GONE
//            webs.visibility = View.VISIBLE
//            ll_media.visibility = View.GONE
//            webs.visibility = View.VISIBLE
            val url: String = holder.tv_url.text.toString().trim { it <= ' ' }
            clickListener(url)
//            webs.loadUrl(url)
        }
        holder.iv_delete.setOnClickListener {
            if (tag == 0) {
                secureDataBaseClass.deleteHistory(secureMediaDataModal.id)
            } else {
                secureDataBaseClass.deleteBookMark(secureMediaDataModal.name!!)
            }
            historyArrayList.removeAt(position)
            deleteListener()
//            if (historyArrayList.size == 0) {
//                val c: TextView = view.findViewById(R.id.tv_clears)
//                val nodata: ImageView = view.findViewById(R.id.nodats)
//                c.visibility = View.GONE
//                nodata.visibility = View.VISIBLE
//                val recyclerView: RecyclerView = view.findViewById(R.id.rv_history)
//                recyclerView.visibility = View.GONE
//            }
            notifyDataSetChanged()

        }
    }

    override fun getItemCount(): Int {
        return historyArrayList.size
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }

    inner class MyViewHolder constructor(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tv_title: TextView
        var tv_url_title: TextView
        var tv_url: TextView
        var iv_icon: ImageView
        var iv_delete: ImageView
        var view: View

        init {
            tv_title = itemView.findViewById(R.id.tv_title)
            tv_url_title = itemView.findViewById(R.id.tv_url_title)
            tv_url = itemView.findViewById(R.id.tv_url)
            iv_icon = itemView.findViewById(R.id.iv_icon)
            iv_delete = itemView.findViewById(R.id.iv_delete)
            view = itemView.findViewById(R.id.view)
        }
    }
}