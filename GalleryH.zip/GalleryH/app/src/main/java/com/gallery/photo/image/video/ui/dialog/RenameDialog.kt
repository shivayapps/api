package com.gallery.photo.image.video.ui.dialog

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Point
import android.media.MediaScannerConnection
import android.media.MediaScannerConnection.OnScanCompletedListener
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.widget.addTextChangedListener
import com.bumptech.glide.Glide
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogRenameBinding
import com.gallery.photo.image.video.ui.event.RenameEvent
import com.gallery.photo.image.video.ui.model.PictureData
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class RenameDialog(
    var mContext: Activity,
    var pictureData: PictureData,
    var isResize: Boolean = false,
    val positiveBtnClickListener: (renamePath: String, oldPath: String) -> Unit,
    val updateImageListener: () -> Unit
) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogRenameBinding
    var preferences: Preferences = Preferences(mContext)
    lateinit var firebaseAnalytics: FirebaseAnalytics
    var oldName = ""
    var type = ""
    var currentWidth = 0
    var currentHeight = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogRenameBinding.inflate(layoutInflater, container, false)
        intView()
        intListener()
        return bindingDialog.root
    }


    private fun intView() {
        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("Rename", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_dialog, bundle2)

        val separated: List<String> = pictureData.fileName.split(".")
        oldName = separated[0]
        type = separated[1]
        Log.e("", "oldName $oldName")
        bindingDialog.edtName.setText(oldName)
        bindingDialog.edtName.requestFocus()

        bindingDialog.tvTitle.text =
            if (isResize) mContext.getString(R.string.Resize) else mContext.getString(R.string.Rename)
        bindingDialog.btnRename.text =
            if (isResize) mContext.getString(R.string.ok) else mContext.getString(R.string.Rename)
        bindingDialog.loutResize.visibility = if (isResize) View.VISIBLE else View.GONE

        if (isResize) {
            val size = pictureData.filePath.getImageResolution()
            bindingDialog.edtWidth.setText("${size.x}")
            bindingDialog.edtHeight.setText("${size.y}")
            currentWidth = size.x
            currentHeight = size.y
            val ratio: Float = currentWidth / currentHeight.toFloat()
            Log.e(
                "ResizeTAG",
                "currentWidth-> $currentWidth  currentHeight-> $currentHeight ratio-> $ratio"
            )

            bindingDialog.edtWidth.addTextChangedListener {
                if (bindingDialog.edtWidth.hasFocus()) {
                    var width = getViewValue(bindingDialog.edtWidth)
                    Log.e("ResizeTAG", "edtW addTextChanged width-> $width")
                    if (width > currentWidth) {
                        bindingDialog.edtWidth.setText(currentWidth.toString())
                        width = currentWidth
                        Log.e("ResizeTAG", "edtW addTextChanged if width-> $width")
                    }
                    Log.e("ResizeTAG", "edtW addTextChanged Height-> ${(width / ratio).toInt()}")
                    bindingDialog.edtHeight.setText((width / ratio).toInt().toString())
                }
            }

            bindingDialog.edtHeight.addTextChangedListener {
                if (bindingDialog.edtHeight.hasFocus()) {
                    var height = getViewValue(bindingDialog.edtHeight)
                    Log.e("ResizeTAG", "edtH addTextChanged height-> $height")
                    if (height > currentHeight) {
                        bindingDialog.edtHeight.setText(currentHeight.toString())
                        height = currentHeight
                        Log.e("ResizeTAG", "edtH addTextChanged if height-> $height")
                    }

                    Log.e("ResizeTAG", "edtH addTextChanged width-> ${(height * ratio).toInt()}")
                    bindingDialog.edtWidth.setText((height * ratio).toInt().toString())
                }
            }
        }
    }

    private fun intListener() {
        bindingDialog.edtName.addTextChangedListener {
            bindingDialog.icClear.visibility = if (bindingDialog.edtName.text?.trim().toString()
                    .isNotEmpty()
            ) View.VISIBLE else View.GONE
        }
        bindingDialog.icClear.setOnClickListener {
            bindingDialog.edtName.setText("")
        }
        bindingDialog.btnCancel.setOnClickListener { dismiss() }

        bindingDialog.btnRename.setOnClickListener {
            val width = getViewValue(bindingDialog.edtWidth)
            val height = getViewValue(bindingDialog.edtHeight)
            if (isResize)
                if ((width <= 0 || height <= 0)) {
                    Toast.makeText(
                        mContext,
                        mContext.getString(R.string.validation_resolution),
                        Toast.LENGTH_SHORT
                    ).show()
                    return@setOnClickListener
                }

            val newSize = Point(width, height)

            val strNewFileName = bindingDialog.edtName.text.toString().trim()
            if (strNewFileName.isNotEmpty()) {
                val renameFile = File(pictureData.filePath.replace(oldName, strNewFileName))
                if (!renameFile.exists() || oldName == strNewFileName) {
                    if (oldName != strNewFileName) {
                        val renamePath = renameFile(strNewFileName, type)
                        if (renamePath.isNotEmpty()) {
                            if (isResize && width != currentWidth && height != currentHeight) {
                                val progressDialog = ProgressDialog(mContext)
                                dismiss()
                                progressDialog.show()
                                Thread {
                                    val newBitmap =
                                        Glide.with(mContext.applicationContext).asBitmap()
                                            .load(renamePath)
                                            .submit(newSize.x, newSize.y)
                                            .get()
                                    var resizeImage = resizeImage(newBitmap, renamePath)
                                    mContext.runOnUiThread {
                                        setRename(pictureData.filePath, renamePath)
                                        progressDialog.dismiss()
                                        Toast.makeText(
                                            mContext,
                                            mContext.getString(R.string.rename_successfully),
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        positiveBtnClickListener(renamePath, pictureData.filePath)
                                    }
                                }.start()
                            } else {
                                setRename(pictureData.filePath, renamePath)
                                dismiss()
                                Toast.makeText(
                                    mContext,
                                    mContext.getString(R.string.rename_successfully),
                                    Toast.LENGTH_SHORT
                                ).show()
                                positiveBtnClickListener(renamePath, pictureData.filePath)
                            }
                        } else {
                            dismiss()
                            Toast.makeText(
                                mContext,
                                mContext.getString(R.string.failed),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        if (isResize && width != currentWidth && height != currentHeight) {
                            val progressDialog = ProgressDialog(mContext)
                            dismiss()
                            progressDialog.show()
                            Thread {
                                val newBitmap =
                                    Glide.with(mContext.applicationContext).asBitmap().load(pictureData.filePath)
                                        .submit(newSize.x, newSize.y)
                                        .get()
                                var resizeImage = resizeImage(newBitmap, pictureData.filePath)
                                mContext.runOnUiThread {
                                    progressDialog.dismiss()
                                    updateImageListener()
                                }
                            }.start()
                        } else
                            dismiss()

                    }
                } else {
                    Toast.makeText(
                        mContext,
                        mContext.getString(R.string.rename_validation2),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else
                Toast.makeText(
                    mContext,
                    mContext.getString(R.string.rename_validation),
                    Toast.LENGTH_SHORT
                ).show()
        }
    }

    private fun getViewValue(view: EditText): Int {
        val textValue = view.text.toString().trim()
        return if (textValue.isEmpty()) 0 else textValue.toInt()
    }

    private fun setRename(oldPath: String, renamePath: String) {
        EventBus.getDefault().post(RenameEvent(oldPath, renamePath))
        val list = preferences.getFavoriteList()
        if (list.contains(oldPath)) {
            list.remove(oldPath)
            list.add(0, renamePath)
            preferences.setFavoriteList(list)
        }
    }

    private fun renameFile(strNewFileName: String, type: String): String {

        var renamed = false
        val renameFilePath: String =
            File(pictureData.filePath).parent.toString() + File.separator + strNewFileName + "." + type
        val oldFile: File = File(pictureData.filePath)
        val renameFile = File(renameFilePath)
        renamed = oldFile.renameTo(renameFile)

        MediaScannerConnection.scanFile(context, arrayOf<String>(renameFile.path), null,
            OnScanCompletedListener { path: String?, uri: Uri? -> })

        MediaScannerConnection.scanFile(context, arrayOf<String>(oldFile.path), null,
            OnScanCompletedListener { path: String?, uri: Uri? -> })

        if (renamed)
            return renameFilePath

        return ""
    }

    fun String.getImageResolution(): Point {
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(this, options)

        val width = options.outWidth
        val height = options.outHeight
        return if (width > 0 && height > 0) {
            Point(options.outWidth, options.outHeight)
        } else {
            Point(0, 0)
        }
    }

    fun resizeImage(bitmap: Bitmap, imagePath: String): String? {

        val imageFile = File(imagePath)
        if (imageFile.exists()) {
            imageFile.delete()
            val deleteUrl = FileProvider.getUriForFile(
                mContext,
                "${mContext.packageName}.provider", imageFile
            )
            val contentResolver = mContext.contentResolver
            contentResolver.delete(deleteUrl, null, null)

            MediaScannerConnection.scanFile(
                mContext,
                arrayOf(imageFile.path),
                null
            ) { path: String?, uri: Uri? -> }
        }

        try {
            val stream = FileOutputStream(imageFile)
            bitmap.compress(imageFile.path.getCompressionFormat(), 100, stream)

            val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
            val contentUri = Uri.fromFile(imageFile)
            mediaScanIntent.data = contentUri
            mContext.sendBroadcast(mediaScanIntent)

            stream.flush()
            stream.close()

            MediaScannerConnection.scanFile(
                mContext, arrayOf<String>(imageFile.path), null
            ) { path, uri ->
            }
            return imagePath
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return null
    }

    fun String.getFilenameExtension() = substring(lastIndexOf(".") + 1)
    fun String.getCompressionFormat() = when (getFilenameExtension().lowercase()) {
        "png" -> Bitmap.CompressFormat.PNG
        "webp" -> Bitmap.CompressFormat.WEBP
        else -> Bitmap.CompressFormat.JPEG
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}

