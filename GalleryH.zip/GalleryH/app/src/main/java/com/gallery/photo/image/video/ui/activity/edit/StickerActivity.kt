package com.gallery.photo.image.video.ui.activity.edit

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.customView.stickerPackage.DrawableSticker
import com.gallery.photo.image.video.databinding.ActivityStickerBinding
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.ui.adapter.edit.StickerAdapter
import com.gallery.photo.image.video.ui.adapter.edit.StickerTabAdapter
import com.gallery.photo.image.video.ui.dialog.ProgressDialog
import com.gallery.photo.image.video.ui.model.edit.StickerData
import com.gallery.photo.image.video.utils.Constant

class StickerActivity : BaseActivity() {

    lateinit var binding: ActivityStickerBinding
    var stickerTabList: ArrayList<StickerData> = ArrayList()
    lateinit var tabAdapter: StickerTabAdapter
    var imagePath = ""
    var saveImageName = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStickerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        val bundle2 = Bundle()
        bundle2.putString("EditSticker", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        binding.loutToolbar.txtTitle.text = getString(R.string.Sticker)

        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        saveImageName = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_NAME) ?: ""

//        Glide.with(this)
//            .load(imagePath)
//            .diskCacheStrategy(DiskCacheStrategy.NONE)
//            .skipMemoryCache(true)
//            .into(binding.mainImg)

        val bitmap = getBitmapFromFilePath(imagePath)
        binding.mainImg.setImageBitmap(bitmap)
        binding.stickerView.setMainImage(binding.mainImg)
        binding.stickerView.setMainBitmap(bitmap)

//        Glide
//            .with(this)
//            .asBitmap()
//            .load(imagePath)
//            .into(object : CustomTarget<Bitmap>() {
//                override fun onResourceReady(
//                    resource: Bitmap,
//                    transition: Transition<in Bitmap>?
//                ) {
//                    binding.stickerView.setMainImage(binding.mainImg)
//                    binding.stickerView.setMainBitmap(resource)
//
//                }
//
//                override fun onLoadCleared(placeholder: Drawable?) {
//
//                }
//            })
//

        setTabAdapter()
        intListener()

    }

    private fun intListener() {
        binding.loutToolbar.icBack.setOnClickListener { onBackPressed() }
        binding.loutToolbar.icDone.setOnClickListener {
            val progressDialog = ProgressDialog(this, getString(R.string.saving))
            progressDialog.show()
            Thread {
                try {
                    val bitmap = binding.stickerView.createBitmap()
                    val imagePath = saveEditImage(bitmap, saveImageName)
                    runOnUiThread {
                        if (imagePath != null) {
                            val intent = Intent()
                            intent.putExtra(Constant.EXTRA_EDIT_SAVE_IMAGE, imagePath)
                            setResult(RESULT_OK, intent)
                        }
                        progressDialog.dismiss()
                        finish()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        progressDialog.dismiss()
                        Toast.makeText(
                            this,
                            getString(R.string.image_editing_failed),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }.start()
        }
    }

    private fun setTabAdapter() {
        stickerTabList.add(
            StickerData(
                getString(R.string.animation),
                resources.obtainTypedArray(R.array.sticker_animation)
            )
        )
        stickerTabList.add(
            StickerData(
                getString(R.string.animal),
                resources.obtainTypedArray(R.array.sticker_animal)
            )
        )
        stickerTabList.add(
            StickerData(
                getString(R.string.celebration),
                resources.obtainTypedArray(R.array.sticker_celebration)
            )
        )
        stickerTabList.add(
            StickerData(
                getString(R.string.food),
                resources.obtainTypedArray(R.array.sticker_food)
            )
        )
        stickerTabList.add(
            StickerData(
                getString(R.string.fruit),
                resources.obtainTypedArray(R.array.sticker_fruit)
            )
        )
        stickerTabList.add(
            StickerData(
                getString(R.string.other),
                resources.obtainTypedArray(R.array.sticker_other)
            )
        )
        setStickerData(0)
        tabAdapter = StickerTabAdapter(this, stickerTabList, clickListener = {
            setStickerData(it)
        })
        binding.rvTab.adapter = tabAdapter

    }

    private fun setStickerData(pos: Int) {
        val stickerEmojiList = stickerTabList[pos].stickerList
        val adapter = StickerAdapter(this, stickerEmojiList, clickListener = {
            val drawable = stickerEmojiList.getDrawable(it)
            binding.stickerView.addSticker(
                com.gallery.photo.image.video.customView.stickerPackage.DrawableSticker(
                    drawable
                )
            )
        })
        binding.recyclerView.adapter = adapter
    }

}