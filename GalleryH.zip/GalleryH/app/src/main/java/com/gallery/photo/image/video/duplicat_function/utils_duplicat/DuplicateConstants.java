package com.gallery.photo.image.video.duplicat_function.utils_duplicat;

import com.drew.imaging.FileType;
import com.drew.imaging.FileTypeDetector;
import com.gallery.photo.image.video.ui.model.PictureData;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;


public class DuplicateConstants {
    public static boolean isAllSelect = true;
    public static long itemSize = 0;
    public static long date_long = 00;
    public static ArrayList<String> selectArrayList = new ArrayList<>();
    public static ArrayList<PictureData> mSelList = new ArrayList<>();
    public static ArrayList<Integer> itemPositionArray = new ArrayList<>();

    public static final String FILE_PROCESSING_COUNT = "FILE_PROCESSING_COUNT";
    public static final String FILE_PROCESSING_MESSAGE = "FILE_PROCESSING_MESSAGE";

    public static String LAST_SCAN_DUP_COUNTS = null;

    public static final String SCAN_TYPE = "scan_type";
    public static final String SHARED_PREF_FILE_PATH = "com.recoverdata.deletedata.secondduplicatdecodedemo.DUPLICATE_DATA";
    public static final String WORKFLOW_TAG = "duplicate_scan_worker";
    public static final String WORKFLOW_TAG_PERIODIC = "duplicate_scan_worker_periodic";
    private static SimpleDateFormat dateFormat;
    public static final String[] VIDEO_FILE_EXTS = {"mp4", "3gp", "wmv", "webm","mkv"};
    public static final String[] AUDIO_FILE_EXTS = {"mp3", "mid", "wav", "pcm", "m4a", "wma", "aac", "flac", "xmf", "mxmf", "ota", "imy", "ogg","opus"};
    static final String[] IMAGE_FILE_EXTS = {"jpg", "jpeg", "gif", "tif", "bmp", "png", "tiff", "jif", "jp2", "jpx", "j2k", "j2c", "webp"};
    public static Set<String> SUPPORTED_IMAGE_FILE_EXTS_SET = new HashSet(Arrays.asList(IMAGE_FILE_EXTS));
    public static Set<String> SUPPORTED_VIDEO_FILE_EXTS_SET = new HashSet(Arrays.asList(VIDEO_FILE_EXTS));
    public static Set<String> SUPPORTED_AUDIO_FILE_EXTS_SET = new HashSet(Arrays.asList(AUDIO_FILE_EXTS));

    public static String DONT_SELECT_FIRST = "DONT_SELECT_FIRST";
    public static String DONT_SELECT_LAST = "DONT_SELECT_LAST";
    public static String SELECT_ALL = "SELECT_ALL";

    public static final Set<FileType> SUPPORTED_IMAGE_FILES = new HashSet();
    public static final Set<FileType> SUPPORTED_VIDEO_FILES = new HashSet();
    public static final Set<FileType> SUPPORTED_AUDIO_FILES = new HashSet();

    
    public interface Type {
        public static final String ALL = "all";
        public static final String AUDIO = "audio";
        public static final String IMAGE = "image";
        public static final String OTHER = "other";
        public static final String VIDEO = "video";
    }

    static {
        FileType[] values;
        for (FileType fileType : FileType.values()) {
            if (fileType.getMimeType() != null) {
                String lowerCase = fileType.getMimeType().toLowerCase();
                if (lowerCase.startsWith(Type.IMAGE)) {
                    SUPPORTED_IMAGE_FILES.add(fileType);
                } else if (lowerCase.startsWith(Type.VIDEO)) {
                    SUPPORTED_VIDEO_FILES.add(fileType);
                } else if (lowerCase.startsWith(Type.AUDIO)) {
                    SUPPORTED_AUDIO_FILES.add(fileType);
                }
            }
        }
        LAST_SCAN_DUP_COUNTS = "lastScanDupFileCounts";
        dateFormat = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss a", Locale.getDefault());
    }

    public static String getExt(String str) {
        return FilenameUtil.getExtension(str);
    }

    public static boolean isVideoFile(String str) {
        return SUPPORTED_VIDEO_FILE_EXTS_SET.contains(getExt(str));
    }

    public static boolean isImageFile(String str) {
        return SUPPORTED_IMAGE_FILE_EXTS_SET.contains(getExt(str));
    }

    public static boolean isAudioFile(String str) {
        return SUPPORTED_AUDIO_FILE_EXTS_SET.contains(getExt(str));
    }

    public static String getFileType(String str) {
        if (isImageFile(str)) {
            return Type.IMAGE;
        }
        if (isVideoFile(str)) {
            return Type.VIDEO;
        }
        if (isAudioFile(str)) {
            return Type.AUDIO;
        }
        try {
            FileType detectFileType = FileTypeDetector.detectFileType(new BufferedInputStream(new FileInputStream(str)));
            return SUPPORTED_IMAGE_FILES.contains(detectFileType) ? Type.IMAGE : SUPPORTED_VIDEO_FILES.contains(detectFileType) ? Type.VIDEO : SUPPORTED_AUDIO_FILES.contains(detectFileType) ? Type.AUDIO : Type.OTHER;
        } catch (Exception unused) {
            return Type.OTHER;
        }
    }

    public static List<Set<String>> mergeFileSets(List<Set<String>> list, List<Set<String>> list2) {
        HashSet hashSet = new HashSet();
        for (Set<String> set : list) {
            for (Set<String> set2 : list2) {
                if (!hashSet.contains(set2)) {
                    Iterator<String> it = set2.iterator();
                    while (true) {
                        if (!it.hasNext()) {
                            break;
                        } else if (set.contains(it.next())) {
                            set.addAll(set2);
                            hashSet.add(set2);
                            break;
                        }
                    }
                }
            }
        }
        for (Set<String> set3 : list2) {
            if (!hashSet.contains(set3)) {
                list.add(set3);
            }
        }
        return list;
    }

    public static String fileSizeToString(long j) {
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        double d = j;
        if (d >= Math.pow(10.0d, 9.0d)) {
            StringBuilder sb = new StringBuilder();
            double pow = Math.pow(10.0d, 9.0d);
            Double.isNaN(d);
            sb.append(decimalFormat.format(d / pow));
            sb.append(" GB");
            return sb.toString();
        } else if (d >= Math.pow(10.0d, 6.0d)) {
            StringBuilder sb2 = new StringBuilder();
            double pow2 = Math.pow(10.0d, 6.0d);
            Double.isNaN(d);
            sb2.append(decimalFormat.format(d / pow2));
            sb2.append(" MB");
            return sb2.toString();
        } else if (d >= Math.pow(10.0d, 3.0d)) {
            StringBuilder sb3 = new StringBuilder();
            double pow3 = Math.pow(10.0d, 3.0d);
            Double.isNaN(d);
            sb3.append(decimalFormat.format(d / pow3));
            sb3.append(" KB");
            return sb3.toString();
        } else {
            return j + " Bytes";
        }
    }

    public static String format(Date date) {
        return date != null ? dateFormat.format(date) : "None";
    }

    public static Map<Integer, String> smartSelectMap() {
        HashMap hashMap = new HashMap();
        hashMap.put(0, SELECT_ALL);
        hashMap.put(1, DONT_SELECT_FIRST);
        hashMap.put(2, DONT_SELECT_LAST);
        return hashMap;
    }
}
