package com.gallery.photo.image.video.ui.activity.setting

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ActivityLanguageBinding
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.ui.activity.HomeActivity
import com.gallery.photo.image.video.ui.activity.itro.PermissionActivity
import com.gallery.photo.image.video.ui.activity.itro.StartActivity
import com.gallery.photo.image.video.ui.adapter.LangungeAdapter
import com.gallery.photo.image.video.ui.model.LanguageData
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences

class LanguageActivity : BaseActivity() {

    lateinit var binding: ActivityLanguageBinding
    var selectPos = 0
    lateinit var adapter: LangungeAdapter
    var isOpenFromSplash: Boolean = false
    lateinit var preferences: Preferences
    var languageList: ArrayList<LanguageData> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLanguageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inti()
    }

    private fun inti() {
        preferences = Preferences(this)
        binding.loutToolbar.txtTitle.text = getString(R.string.language)
        binding.loutToolbar.ivDone.visibility = View.VISIBLE

        val bundle2 = Bundle()
        bundle2.putString("Language", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        loadNativeAdsLanguage(binding.frameNative)

        if (intent != null)
            isOpenFromSplash = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, false)

        getLanList()
        intiListener()

        binding.loutToolbar.icBack.visibility = if (isOpenFromSplash) View.INVISIBLE else View.VISIBLE

        selectPos = preferences.getSelectLanguage()
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = LangungeAdapter(this,
            languageList,
            clickListener = {
                selectPos = it
            })
        adapter.selectPos = selectPos
        binding.recyclerView.adapter = adapter
        binding.recyclerView.scrollToPosition(selectPos)
    }

    private fun updateViews(languageCode: String) {
        com.gallery.photo.image.video.utils.LocaleHelper.setLocale(this, languageCode)
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            finish()
        }

        binding.loutToolbar.ivDone.setOnClickListener {
            preferences.setSelectLanguage(selectPos)
            preferences.putLanguage(true)
            updateViews(languageList[selectPos].languageCode)
            if (isOpenFromSplash) {

                val intent1 = if (!preferences.isStar())
                    Intent(this, StartActivity::class.java)
                else if (!checkStoragePermission())
                    Intent(this, PermissionActivity::class.java)
                else
                    Intent(this, HomeActivity::class.java)

                startActivity(intent1)
            } else
                setResult(RESULT_OK)
            finish()

        }
    }

    private fun getLanList() {
        languageList.add(
            LanguageData(
                getString(R.string.english),
                "en"
//                , ContextCompat.getDrawable(this, R.drawable.english)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.spanish),
                "es"
//                , ContextCompat.getDrawable(this, R.drawable.spanish)
            )
        )
        languageList.add(
            LanguageData(
                getString(R.string.german),
                "de"
//                ,ContextCompat.getDrawable(this, R.drawable.german)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.french),
                "fr"
//                , ContextCompat.getDrawable(this, R.drawable.french)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.russian),
                "ru"
//                , ContextCompat.getDrawable(this, R.drawable.russian)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.hindi),
                "hi"
//                , ContextCompat.getDrawable(this, R.drawable.hindi)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.filipino),
                "fil"
//                , ContextCompat.getDrawable(this, R.drawable.filipino)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.chinese),
                "zh"
//                , ContextCompat.getDrawable(this, R.drawable.chinese)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.italian),
                "it"
//                , ContextCompat.getDrawable(this, R.drawable.italian)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.turkish),
                "in"
//                , ContextCompat.getDrawable(this, R.drawable.turkish)
            )
        )

    }
}