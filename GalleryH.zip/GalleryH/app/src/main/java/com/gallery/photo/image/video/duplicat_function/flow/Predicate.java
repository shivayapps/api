package com.gallery.photo.image.video.duplicat_function.flow;

@FunctionalInterface

public interface Predicate<T> {
    boolean test(T t);
}
