package com.gallery.photo.image.video.duplicat_function.core_class;

import android.content.Context;

import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.gallery.photo.image.video.duplicat_function.utils_duplicat.StorageManager;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.StorageManager;

import java.io.File;
import java.util.Set;

public class FileDeleteWorker extends Worker {
    public static final String FILES_DELETED = "FILES_DELETED";
    public static final String MEMORY_RECLAIMED = "MEMORY_RECLAIMED";
    private int deletedFileCount;
    StorageManager storageManager;

    public FileDeleteWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);

        this.deletedFileCount = 0;
        this.storageManager = new StorageManager(context);
    }

    @Override 
    public Result doWork() {
        Set<String> filesToBeDeleted = this.storageManager.getFilesToBeDeleted();
        long j = 0;
        if (filesToBeDeleted == null || filesToBeDeleted.isEmpty()) {
            return Result.success(new Data.Builder().putLong(FILES_DELETED, 0L).putLong(MEMORY_RECLAIMED, 0L).build());
        }
        long j2 = 0;
        for (String str : filesToBeDeleted) {
            if (isStopped()) {
                break;
            }
            File file = new File(str);
            if (file.exists() && file.isFile()) {
                long length = file.length();
                if (file.delete()) {
                    j += length;
                    j2++;
                    Data.Builder builder = new Data.Builder();
                    int i = this.deletedFileCount + 1;
                    this.deletedFileCount = i;
                    setProgressAsync(builder.putInt(FILES_DELETED, i).build());
                }
            }
        }
        return Result.success(new Data.Builder().putLong(FILES_DELETED, j2).putLong(MEMORY_RECLAIMED, j).build());
    }
}
