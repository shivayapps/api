package com.gallery.photo.image.video.ui.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.Window
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogProgressBinding

class ProgressDialog(
    var mContext: Context,
    var title: String = ""
) :
    Dialog(mContext, R.style.Dialog) {

    lateinit var bindingDialog: DialogProgressBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        setCancelable(false)
        setCanceledOnTouchOutside(false)
        bindingDialog = DialogProgressBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        intView()

    }

    private fun intView() {
        bindingDialog.tvTitle.visibility = if (title.isEmpty()) View.GONE else View.VISIBLE
        if (title.isNotEmpty())
            bindingDialog.tvTitle.text = title
    }

}