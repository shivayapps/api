package com.gallery.photo.image.video.ui.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogRateBinding
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences

class RateUsDialog(val submitListener: (rating: Float) -> Unit, val cancelListener: () -> Unit) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogRateBinding
    lateinit var preferences: Preferences
    lateinit var firebaseAnalytics: FirebaseAnalytics

    var themeValue = 0


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogRateBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("RateUs", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_dialog, bundle2)

        preferences = Preferences(requireActivity())
        themeValue = preferences.getThemeValue()

//        bindingDialog.animationView.visibility = View.GONE
//        bindingDialog.animationView.pauseAnimation()

        bindingDialog.btnSubmit.setTextColor(
            ContextCompat.getColor(
                requireActivity(), R.color.grayText
            )
        )

        val emojiStr =
            if (bindingDialog.simpleRatingBar.rating == 5f) getString(R.string.emoji_2) else getString(R.string.emoji_1)
        val msgPop =
            if (bindingDialog.simpleRatingBar.rating == 5f) getString(R.string.rate_5_did) else getString(R.string.rate_best)
//        bindingDialog.tvPopMsg.text = "$msgPop $emojiStr"

        intListener()
    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
            cancelListener()
        }
        bindingDialog.btnSubmit.setOnClickListener {
            if (bindingDialog.simpleRatingBar.rating != 0.0f) {
                dismiss()
                submitListener(bindingDialog.simpleRatingBar.rating)
            }
        }
        bindingDialog.simpleRatingBar.setOnRatingChangeListener { ratingBar, rating, fromUser ->
            if (rating == 0f) {
                bindingDialog.btnSubmit.setTextColor(
                    ContextCompat.getColor(
                        requireActivity(), R.color.grayText
                    )
                )
            } else {
                bindingDialog.btnSubmit.setTextColor(
                    ContextCompat.getColor(
                        requireActivity(), R.color.white
                    )
                )
            }

            val emojiStr =
                if (rating == 5f) getString(R.string.emoji_2) else getString(R.string.emoji_1)
            val msgPop =
                if (rating == 5f) getString(R.string.rate_5_did) else getString(R.string.rate_best)
//            bindingDialog.tvPopMsg.text = "$msgPop $emojiStr"
//            bindingDialog.tvPopMsgEmoji.text = emojiStr

            when (rating) {
                1.0f -> {
                    bindingDialog.tvTitle.text = getString(R.string.rateTitle1)
                    bindingDialog.tvMsg.text = getString(R.string.rateMsg1)

//                    bindingDialog.animationEmoji.pauseAnimation()
//                    bindingDialog.animationEmoji.setAnimation(R.raw.rate_1_star)
//                    bindingDialog.animationEmoji.playAnimation()

//                    bindingDialog.animationView.visibility = View.GONE
//                    bindingDialog.animationView.pauseAnimation()
                }

                2.0f -> {
                    bindingDialog.tvTitle.text = getString(R.string.rateTitle2)
                    bindingDialog.tvMsg.text = getString(R.string.rateMsg2)

//                    bindingDialog.animationEmoji.pauseAnimation()
//                    bindingDialog.animationEmoji.setAnimation(R.raw.rate_2_star)
//                    bindingDialog.animationEmoji.playAnimation()

//                    bindingDialog.animationView.visibility = View.GONE
//                    bindingDialog.animationView.pauseAnimation()
                }

                3.0f -> {
                    bindingDialog.tvTitle.text = getString(R.string.rateTitle3)
                    bindingDialog.tvMsg.text = getString(R.string.rateMsg3)

//                    bindingDialog.animationEmoji.pauseAnimation()
//                    bindingDialog.animationEmoji.setAnimation(R.raw.rate_3_star)
//                    bindingDialog.animationEmoji.playAnimation()

//                    bindingDialog.animationView.visibility = View.GONE
//                    bindingDialog.animationView.pauseAnimation()
                }

                4.0f -> {
                    bindingDialog.tvTitle.text = getString(R.string.rateTitle4)
                    bindingDialog.tvMsg.text = getString(R.string.rateMsg4)

//                    bindingDialog.animationEmoji.pauseAnimation()
//                    bindingDialog.animationEmoji.setAnimation(R.raw.rate_4_star)
//                    bindingDialog.animationEmoji.playAnimation()

//                    bindingDialog.animationView.visibility = View.GONE
//                    bindingDialog.animationView.pauseAnimation()
                }

                5.0f -> {
                    bindingDialog.tvTitle.text = getString(R.string.rateTitle5)
                    bindingDialog.tvMsg.text = getString(R.string.rateMsg5)

//                    bindingDialog.animationEmoji.pauseAnimation()
//                    bindingDialog.animationEmoji.setAnimation(R.raw.rate_5_star)
//                    bindingDialog.animationEmoji.playAnimation()

//                    bindingDialog.animationView.visibility = View.VISIBLE
//                    bindingDialog.animationView.pauseAnimation()
//                    bindingDialog.animationView.playAnimation()
                }

                else -> {
                    bindingDialog.tvTitle.text = getString(R.string.rateTitle)
                    bindingDialog.tvMsg.text = getString(R.string.rateMsg)

//                    bindingDialog.animationEmoji.pauseAnimation()
//                    bindingDialog.animationEmoji.setAnimation(R.raw.rate_5_star)
//                    bindingDialog.animationEmoji.playAnimation()

//                    bindingDialog.animationView.visibility = View.GONE
//                    bindingDialog.animationView.pauseAnimation()

                }

            }

        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}