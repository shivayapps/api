package com.gallery.photo.image.video.ui.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ItemHeaderBinding
import com.gallery.photo.image.video.databinding.ItemPictureBinding
import com.gallery.photo.image.video.duplicat_function.model_class.DataItem
import com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem
import com.gallery.photo.image.video.duplicat_function.model_class.Item
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants

class DuplicateImagesAdapter(
    private val activity: Activity,
    private var items: MutableList<com.gallery.photo.image.video.duplicat_function.model_class.Item>,
    private val fileType: String,
    val headerSelectListener: (pos: Int) -> Unit,
    val clickListener: (pos: Int) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder?>() {

    fun setData(list: MutableList<com.gallery.photo.image.video.duplicat_function.model_class.Item>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, i: Int): RecyclerView.ViewHolder {
        if (i != 0) {
            if (i == 1) {
                return ListViewHolder(
                    ItemPictureBinding.inflate(
                        LayoutInflater.from(parent.context),
                        parent,
                        false
                    )
                )
            }
        }
        return HeaderViewHolder(
            ItemHeaderBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(
        viewHolder: RecyclerView.ViewHolder,
        @SuppressLint("RecyclerView") i: Int
    ) {
        val itemViewType = viewHolder!!.itemViewType
        if (itemViewType == 0) {
            (viewHolder as HeaderViewHolder?)!!.bind(
                items[i] as com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem, i
            )
        } else if (itemViewType == 1) {
            (viewHolder as ListViewHolder?)!!.bind(items[i] as DataItem, i)
        } else if (itemViewType != 2) {

        } else {

        }

    }

    override fun getItemViewType(i: Int): Int {
        if (items[i] is com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem) {
            return 0
        }
        return if (IMAGE_VIDEO_TYPE_SET.contains(fileType)) 1 else 2
    }

    override fun getItemCount(): Int {
        return items.size
    }

    inner class ListViewHolder(val binding: ItemPictureBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(dataItem: DataItem, position: Int) {

            Glide.with(activity.applicationContext).load(dataItem.filePath)
                .placeholder(R.color.place_holder).into(binding.image)

            binding.icFavourite.visibility = View.GONE

            if (dataItem.isSelected) {
                binding.icUnSelect.visibility = View.VISIBLE
                binding.icSelect.visibility = View.VISIBLE
            } else {
                binding.icUnSelect.visibility = View.VISIBLE
                binding.icSelect.visibility = View.GONE
            }


            binding.loutMain.setOnClickListener { view: View? ->
                clickListener(position)
//                if (!DetailActivity.isBack) {
//                    if (dataItem.isSelected) {
//                        DuplicateConstants.isAllSelect = false
//                        DuplicateConstants.itemSize =
//                            DuplicateConstants.itemSize - File(dataItem.filePath).length()
//                        for (s in DuplicateConstants.selectArrayList.indices) {
//                            if (DuplicateConstants.selectArrayList[s] == dataItem.filePath) {
//                                DuplicateConstants.selectArrayList.removeAt(s)
////                                showLogDirect("--------------------${DuplicateConstants.selectArrayList.size}")
//                                DuplicateConstants.itemPositionArray.remove(position)
//                                DuplicateConstants.mSelList.remove(
//                                    PictureData(
//                                        filePath = dataItem.filePath ?: "",
//                                        fileName = dataItem.fileName ?: "",
//                                        fileSize = dataItem.fileSizeLong,
//                                        date = dataItem.fileDate,
//                                        dateTaken = dataItem.fileDate
//                                    )
//                                )
//                                onSelectCheck.setCheckButtons(dataItem, position)
//                                break
//                            }
//                        }
//                        binding.icSelect.visibility = View.GONE
//                        dataItem.isSelected = false
//                    } else {
//                        DuplicateConstants.itemSize =
//                            DuplicateConstants.itemSize + File(dataItem.filePath).length()
//                        DuplicateConstants.isAllSelect = false
//                        DuplicateConstants.selectArrayList.add(dataItem.filePath)
//                        DuplicateConstants.itemPositionArray.add(position)
//                        DuplicateConstants.mSelList.add(
//                            PictureData(
//                                filePath = dataItem.filePath ?: "",
//                                fileName = dataItem.fileName ?: "",
//                                fileSize = dataItem.fileSizeLong,
//                                date = dataItem.fileDate,
//                                dateTaken = dataItem.fileDate
//                            )
//                        )
//                        dataItem.isSelected = true
//                        binding.icSelect.visibility = View.VISIBLE
////                        showLogDirect("--------------------${DuplicateConstants.selectArrayList.size}")
//                        onSelectCheck.setCheckButtons(dataItem, position)
//                    }
//                }
            }
        }
    }

    inner class HeaderViewHolder(val binding: ItemHeaderBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(headerItem: com.gallery.photo.image.video.duplicat_function.model_class.HeaderItem, position: Int) {
            binding.txtHeader.text = headerItem.title
            binding.btnSelect.visibility = View.VISIBLE
            binding.btnSelect.text =
                if (headerItem.isSelected) activity.getString(R.string.deselect) else activity.getString(
                    R.string.select_all
                )
            binding.btnSelect.setOnClickListener {
                headerSelectListener(position)
            }
        }
    }

    companion object {
        private var IMAGE_VIDEO_TYPE_SET: HashSet<String> = HashSet()

        init {
            val hashSet = HashSet<String>()
            IMAGE_VIDEO_TYPE_SET = hashSet
            hashSet.add(com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants.Type.IMAGE)
            IMAGE_VIDEO_TYPE_SET.add(com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants.Type.VIDEO)
        }
    }

}
