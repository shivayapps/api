package com.gallery.photo.image.video.ui.activity.itro

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Build.VERSION
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Window
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
//import com.ads.module.open.AdconfigApplication
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ActivityPermissionBinding
import com.gallery.photo.image.video.databinding.DialogPermissionDeniedBinding
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.ui.activity.HomeActivity
import com.gallery.photo.image.video.utils.Constant

class PermissionActivity : BaseActivity() {

    lateinit var binding: ActivityPermissionBinding
    var isOpenCameraPermission: Boolean = false
    var handler: Handler = Handler(Looper.myLooper()!!)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inti()
    }

    private fun inti() {
        if (intent != null)
            isOpenCameraPermission =
                intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_CAMERA_PERMISSION, false)

        val bundle2 = Bundle()
        bundle2.putString("Permission", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        loadNativeAdsPermission(binding.frameNative)

        if (isOpenCameraPermission) {
            binding.txtMsg.text = getString(R.string.permission_camera_msg)
            binding.ivImage.setImageDrawable(
                ContextCompat.getDrawable(
                    this,
                    R.drawable.ic_camera_permisson
                )
            )
        } else {
            binding.txtMsg.text = getString(R.string.permission_msg)
            binding.ivImage.setImageDrawable(
                ContextCompat.getDrawable(
                    this,
                    R.drawable.ic_permission_img
                )
            )
            if (checkStoragePermission())
                startNextScreen()
        }
        binding.btnAllow.setOnClickListener {
//            if (isPermissionOpen()) {
//                AdconfigApplication.disabledOpenAds()
//            }
            if (!isOpenCameraPermission && VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    requestNotification()
                } else requestStoragePermission()
            } else {
                requestPermission()
            }
        }
    }

    private fun requestNotification() {
        val list: ArrayList<String> = ArrayList()
        if (VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(android.Manifest.permission.POST_NOTIFICATIONS)
        }

        Dexter.withContext(this@PermissionActivity)
            .withPermissions(
                list
            )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    report?.let {
                        requestStoragePermission()
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<PermissionRequest>?,
                    token: PermissionToken?
                ) {
                    token?.continuePermissionRequest()
                }
            }).check()
    }

    private fun startNextScreen() {
//        AdconfigApplication.disabledOpenAds()
        if (!isOpenCameraPermission) {
            val intent = Intent(this, HomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }
        setResult(RESULT_OK)
        finish()
    }

    private fun requestPermission() {

        val list: ArrayList<String> = ArrayList()
        if (isOpenCameraPermission)
            list.add(android.Manifest.permission.CAMERA)
        else
            list.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
        Dexter.withContext(this@PermissionActivity)
            .withPermissions(
                list
            )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    report?.let {
                        if (report.areAllPermissionsGranted()) {
                            startNextScreen()
                        } else if (report.isAnyPermissionPermanentlyDenied) {
                            showPermissionDeniedDialog()
                        } else {
                            Toast.makeText(
                                this@PermissionActivity,
                                if (isOpenCameraPermission) getString(R.string.permission_camera_toast_msg) else getString(
                                    R.string.permission_toast_msg
                                ),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<PermissionRequest>?,
                    token: PermissionToken?
                ) {
                    token?.continuePermissionRequest()
                }
            }).check()

    }

    var permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            if (checkStoragePermission())
                startNextScreen()
            else
                requestPermission()
        }

    var permissionActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (VERSION.SDK_INT >= Build.VERSION_CODES.R) if (Environment.isExternalStorageManager()) {
            startNextScreen()
        } else {
            Toast.makeText(
                this,
                getString(R.string.permission_toast_msg),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun requestStoragePermission() {
        if (VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.addCategory("android.intent.category.DEFAULT")
                intent.data =
                    Uri.parse(String.format("package:%s", applicationContext.packageName))
//                AdconfigApplication.disabledOpenAds()
                permissionActivityResultLauncher.launch(intent)
                handler.postDelayed(checkSettingOn, 1000)
            } catch (e: Exception) {
                val intent = Intent()
                intent.action = Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
//                AdconfigApplication.disabledOpenAds()
                permissionActivityResultLauncher.launch(intent)
                handler.postDelayed(checkSettingOn, 1000)
            }
        }
    }

    var checkSettingOn: Runnable = object : Runnable {
        override fun run() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                return
            } else {
                if (Environment.isExternalStorageManager()) {
                    startNextScreen()
                    return
                }
                handler.postDelayed(this, 200)
            }
        }
    }

    private fun showPermissionDeniedDialog() {
        val dialogBinding = DialogPermissionDeniedBinding.inflate(layoutInflater)
        val dialog = Dialog(this, R.style.Theme_Dialog)
        dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setContentView(dialogBinding.root)
        dialog.show()

        dialogBinding.btnOK.setOnClickListener {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            val uri = Uri.fromParts("package", packageName, null)
            intent.data = uri
//            AdconfigApplication.disabledOpenAds()
            permissionLauncher.launch(intent)
        }

        dialogBinding.btnCancel.setOnClickListener {
            dialog.dismiss()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(checkSettingOn)
    }
}