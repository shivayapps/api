package com.gallery.photo.image.video.utils

//import com.ads.module.open.AdconfigApplication
import android.app.Activity
import android.os.Handler
import android.os.Looper
import androidx.multidex.MultiDexApplication
import com.adconfig.AdsConfig
import com.adconfig.adsutil.openad.AppOpenApplication
import com.google.android.gms.tasks.Task
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.analytics
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.ui.activity.itro.SplashActivity


class MyApplication : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {
//class MyApplication: MultiDexApplication() {

    private lateinit var firebaseAnalytics: FirebaseAnalytics
    var firebaseRemoteConfig: FirebaseRemoteConfig? = null

    override fun onCreate() {
        super.onCreate()
        isAppIsRunning = false

        FirebaseApp.initializeApp(this)
        firebaseAnalytics = Firebase.analytics
        firebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
        remoteConfig = firebaseRemoteConfig as FirebaseRemoteConfig

        AdsConfig.builder()
            .setIsDebug(true)
            .isEnableAds(true)
            .isEnableOpenAds(true)
            .setTestDeviceId("VKDFV98HGNIEJ9NNUVCSNDL80928RKL0")
            .setAdmobInterClick(2)
//            .setAdmobInterstitialAdId("ca-app-pub-2750800778809761/6579918502")
            .setAdmobInterstitialAdId(getString(R.string.inter_ad_unit_id))
//            .setAdmobAppOpenId("ca-app-pub-2750800778809761/1021852955")
            .setAdmobAppOpenId(getString(R.string.open_ad_unit_id))
//            .setAdmobBannerId("ca-app-pub-2750800778809761/9206081840")
            .setAdmobBannerId(getString(R.string.banner_ad_unit_id))
//            .setAdmobNativeId("ca-app-pub-2750800778809761/9353421501")
            .setAdmobNativeId(getString(R.string.native_ad_unit_id))
//            .setAdmobRewardId("ca-app-pub-2750800778809761/1710357902")
            .setAdmobRewardId(getString(R.string.rewarded_interstitial_ad_unit_id))
            .build(this)
        setAppLifecycleListener(this)
        initMobileAds()

        fireBaseConfigGet()
    }
    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (fCurrentActivity is SplashActivity) return false
        else if (isOpenAdHide) {
            enabledOpenAds()
            return false
        }
        return true
    }


    companion object {
        var isOpenHomeScreen = false
        var isAppIsRunning: Boolean = false
        lateinit var remoteConfig: FirebaseRemoteConfig
        var clickCount: Int = 0
        val clickInterval: Long = 60 * 1000 // 1 minute in milliseconds
        var lastClickTime: Long = 0

        var isOpenAdHide = false

        fun disabledOpenAds() {
            isOpenAdHide = true
        }

        fun enabledOpenAds() {
            Handler(Looper.getMainLooper()).postDelayed({ isOpenAdHide = false }, 500)
        }
    }
    private fun fireBaseConfigGet() {
        try {
            remoteConfig.setConfigSettingsAsync(
                FirebaseRemoteConfigSettings.Builder()
                    .setMinimumFetchIntervalInSeconds(0)
                    .setFetchTimeoutInSeconds(3)
                    .build()
            )

            remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)
            remoteConfig.fetch(0)
                .addOnCompleteListener { task: Task<Void?> ->
                    var errorString = ""
                    if (task.isSuccessful) {
                        remoteConfig.fetchAndActivate()
                        errorString = " task is successful  "

                    } else {
                        errorString = "task is canceled"
                    }
                }
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }
}