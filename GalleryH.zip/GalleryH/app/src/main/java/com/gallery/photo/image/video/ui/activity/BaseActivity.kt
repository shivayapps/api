package com.gallery.photo.image.video.ui.activity

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.AssetManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.DisplayMetrics
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatDelegate
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
//import com.ads.module.adutills.AdUtils
import androidx.appcompat.app.AppCompatActivity
//import com.ads.module.adutills.BaseActivityPermission
//import com.ads.module.adutills.NativeLoadWithShows
//import com.ads.module.adutills.SessionHelper
//import com.ads.module.open.AdconfigApplication
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.ui.activity.setting.FeedBackActivity
import com.gallery.photo.image.video.ui.dialog.RateUsDialog
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.MyApplication
import com.gallery.photo.image.video.utils.Preferences
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

open class BaseActivity : AppCompatActivity() {

    var themeType = 0
    lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation =
            if (Build.VERSION.SDK_INT < 9) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        themeType = Preferences(this).getThemeValue()
        firebaseAnalytics = FirebaseAnalytics.getInstance(this)
        setAppTheme()
    }

    override fun onResume() {
        super.onResume()
        setAppTheme()
    }

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(
            com.gallery.photo.image.video.utils.LocaleHelper.onAttach(
                base, "en"
            )
        )
    }

    fun getAppVersion(): String? {
        try {
            val packageInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                packageManager.getPackageInfo(packageName, 0)
//                packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                packageManager.getPackageInfo(packageName, 0)
            }
            return packageInfo.versionName
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }
        return null
    }

    fun getScreenWidth(): Int {
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val displayMetrics = DisplayMetrics()
//        windowManager.defaultDisplay.getMetrics(displayMetrics)
//        return displayMetrics.widthPixels
        return windowManager.defaultDisplay.width
    }

    fun loadNativeAdsStart(view: FrameLayout) {
//        val adValue = SessionHelper(this).getStringData(SessionHelper.NATIVE_AD_1)
//        view.visibility = View.VISIBLE
//        if (adValue.equals("0", ignoreCase = true)) { // Banner
//            AdUtils().loadMediumBanner(this, view)
//        } else if (adValue.equals("1", ignoreCase = true)) { // Native
//            NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, view, 1)
//            NativeLoadWithShows(this).showNativeBottomAlways(this, view)
//        } else view.visibility = View.GONE
    }

    fun loadNativeAdsLanguage(view: FrameLayout) {
        view.visibility = View.VISIBLE
//        NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, view, 2)
//        NativeLoadWithShows(this).showNativeBigAlways(this, view)
    }

    fun loadNativeAdsPermission(view: FrameLayout) {
//        val adValue = SessionHelper(this).getStringData(SessionHelper.NATIVE_AD_2)
//        view.visibility = View.VISIBLE
//        if (adValue.equals("0", ignoreCase = true)) { // Banner
//            AdUtils().loadMediumBanner(this, view)
//        } else if (adValue.equals("1", ignoreCase = true)) { // Native
//            NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, view, 3)
//            NativeLoadWithShows(this).showNativeTopAlways(this, view)
//        } else view.visibility = View.GONE
    }

    fun loadNativeAdsHome(view: FrameLayout) {
//        val adValue = SessionHelper(this).getStringData(SessionHelper.NATIVE_AD_3)
//        view.visibility = View.VISIBLE
//        if (adValue.equals("0", ignoreCase = true)) { // Banner
//            AdUtils().loadMediumBanner(this, view)
//        } else if (adValue.equals("1", ignoreCase = true)) { // Native
//            NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, view, 3)
//            NativeLoadWithShows(this).showNativeTopAlways(this, view)
//        } else view.visibility = View.GONE
    }

    fun loadNativeAdsAlbumImageList(view: FrameLayout) {
//        val adValue = SessionHelper(this).getStringData(SessionHelper.NATIVE_AD_4)
//        view.visibility = View.VISIBLE
//        if (adValue.equals("0", ignoreCase = true)) { // Banner
//            AdUtils().loadMediumBanner(this, view)
//        } else if (adValue.equals("1", ignoreCase = true)) { // Native
//            NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, view, 1)
//            NativeLoadWithShows(this).showNativeBottomAlways(this, view)
//        } else view.visibility = View.GONE
    }

    fun loadNativeAdsAlbumBrowser(view: FrameLayout) {
//        val adValue = SessionHelper(this).getStringData(SessionHelper.NATIVE_AD_5)
//        view.visibility = View.VISIBLE
//        if (adValue.equals("0", ignoreCase = true)) { // Banner
//            AdUtils().loadMediumBanner(this, view)
//        } else if (adValue.equals("1", ignoreCase = true)) { // Native
//            NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, view, 1)
//            NativeLoadWithShows(this).showNativeBottomAlways(this, view)
//        } else view.visibility = View.GONE
    }

    public fun setAppTheme() {
        when (themeType) {
            Constant.THEME_LIGHT -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }

            Constant.THEME_DARK -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
        }
    }

    fun getBitmapFromDrawable(myDrawable: Drawable?): Bitmap {

        if (myDrawable is BitmapDrawable) {
            return myDrawable.bitmap
        }

//        val bitmap =   if(myDrawable!!.intrinsicWidth <= 0 || myDrawable.intrinsicHeight <= 0) {
//            Bitmap.createBitmap(20, 20, Bitmap.Config.ARGB_8888)
//        } else {
//            Bitmap.createBitmap(myDrawable.intrinsicWidth,myDrawable.intrinsicHeight, Bitmap.Config.ARGB_8888)
//        }
        val width = myDrawable?.intrinsicWidth ?: 0
        val height = myDrawable?.intrinsicHeight ?: 0
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        myDrawable?.setBounds(0, 0, width, height)
        myDrawable?.draw(canvas)
        return bitmap

    }

    fun getBitmapFromFilePath(filePath: String): Bitmap? {
        try {
            val options = BitmapFactory.Options()
            options.inPreferredConfig = Bitmap.Config.ARGB_8888
            return BitmapFactory.decodeFile(filePath, options)
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun listAssetFilesInFolder(folderName: String): Array<String> {
        val assetManager: AssetManager = assets

        return try {
            assetManager.list(folderName) ?: arrayOf()
        } catch (e: IOException) {
            e.printStackTrace()
            arrayOf()
        }
    }

    fun getDrawableFromFile(context: Context, filePath: String): Drawable? {
        try {
            val file = File(filePath)
            if (file.exists()) {
                val bitmap = BitmapFactory.decodeFile(filePath)

                return BitmapDrawable(context.resources, bitmap)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    fun openPrivacyPolicy() {
        val url = getPrivacyPolicy()
        if (url != null && url.isNotEmpty()) {
            try {
                val builder: CustomTabsIntent.Builder = CustomTabsIntent.Builder()
                builder.setToolbarColor(ContextCompat.getColor(this, R.color.white))
                MyApplication.disabledOpenAds()
                val customTabsIntent: CustomTabsIntent = builder.build()
                customTabsIntent.intent.setPackage("com.android.chrome")
                customTabsIntent.launchUrl(this, Uri.parse(url))

            } catch (e: Exception) {
                val i = Intent(Intent.ACTION_VIEW)
                i.data = Uri.parse(url)
                MyApplication.disabledOpenAds()
                startActivity(i)
            }
        }
    }



    fun getSaveEditPath(saveImageName: String): String {
        val dir = File(cacheDir.absolutePath)
        if (!dir.exists()) dir.mkdirs()

        val pictureFile = File(dir.path + "/" + saveImageName)
        if (pictureFile.exists()) {
            pictureFile.delete()
            MediaScannerConnection.scanFile(
                this@BaseActivity, arrayOf(pictureFile.path), null
            ) { path, uri ->

            }
        }
        return pictureFile.path
    }

    fun saveEditImage(bitmap: Bitmap, saveImageName: String, quality: Int = 70): String? {
        val dir = File(cacheDir.absolutePath + "/Edit")
        if (!dir.exists()) dir.mkdirs()

        val pictureFile = File(dir.path + "/" + saveImageName)
        if (pictureFile.exists()) {
            pictureFile.delete()
            MediaScannerConnection.scanFile(
                this@BaseActivity, arrayOf(pictureFile.path), null
            ) { path, uri ->

            }
        }
        var out: FileOutputStream? = null
        try {
            out = FileOutputStream(pictureFile.path)
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
            val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
            val contentUri = Uri.fromFile(pictureFile)
            mediaScanIntent.data = contentUri
            sendBroadcast(mediaScanIntent)
            MediaScannerConnection.scanFile(
                this@BaseActivity, arrayOf(pictureFile.path), null
            ) { path, uri ->

            }
            return pictureFile.path
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    fun showRateDialog(isOpenFromHomeBackPress: Boolean = false) {
        val mailId = getReviewEmail()

        val rateDialog = RateUsDialog(submitListener = {
            Preferences(this).putStart(true)
//            rateDoneReviewCounter()
            if (it == 5.0f) {
                MyApplication.disabledOpenAds()

                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("http://play.google.com/store/apps/details?id=$packageName")
                    )
                )
                if (isOpenFromHomeBackPress) {
                    finishAffinity()
                    MyApplication.isAppIsRunning = false
//                    AdconfigApplication.adConfigFinishAffinity()
                }
            } else {
                startActivity(Intent(this, FeedBackActivity::class.java))
//                val i = Intent(Intent.ACTION_SEND)
//                i.type = "message/rfc822"
//                i.putExtra(Intent.EXTRA_EMAIL, arrayOf(mailId))
//                i.putExtra(
//                    Intent.EXTRA_SUBJECT,
//                    "${getString(R.string.app_name)} ${getString(R.string.feedback)}"
//                )
//                i.putExtra(Intent.EXTRA_TEXT, "")
//                i.setPackage("com.google.android.gm")
//
//                try {
//                    MyApplication.disabledOpenAds()
//                    startActivity(Intent.createChooser(i, getString(R.string.Send_mail)))
//                    if (isOpenFromHomeBackPress) {
//                        finishAffinity()
//                        AdconfigApplication.adConfigFinishAffinity()
//                        MyApplication.isAppIsRunning = false
//                    }
//                } catch (ex: ActivityNotFoundException) {
//                    Toast.makeText(
//                        this@BaseActivity, getString(R.string.not_installed), Toast.LENGTH_SHORT
//                    ).show()
//                }
            }

        }, cancelListener = {
            if (isOpenFromHomeBackPress) {
//                minusReviewCounter()
                finishAffinity()
//                AdconfigApplication.adConfigFinishAffinity()
                MyApplication.isAppIsRunning = false
            }
        })

        rateDialog.show(supportFragmentManager, rateDialog.tag)
    }

    fun getPrivacyPolicy(): String {
        return ""
    }
    fun getReviewEmail(): String {
        return ""
    }

    fun checkStoragePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            val result = ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_EXTERNAL_STORAGE
            )
            val result1 = ContextCompat.checkSelfPermission(
                this, Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED
        }
    }

    fun checkCameraPermission(): Boolean {
        val result = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        )
        return result == PackageManager.PERMISSION_GRANTED
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        val view = currentFocus
        val ret = super.dispatchTouchEvent(event)
        if (view is EditText) {
            val w = currentFocus
            val scrcoords = IntArray(2)
            if (w != null) {
                w.getLocationOnScreen(scrcoords)
                val x = event.rawX + w.left - scrcoords[0]
                val y = event.rawY + w.top - scrcoords[1]
                if (event.action == 1 && (x < w.left || x >= w.right || y < w.top || y > w.bottom)) {
                    val systemService = getSystemService(Context.INPUT_METHOD_SERVICE)
                    val imm = systemService as InputMethodManager
                    val currentFocus = window.currentFocus
                    imm.hideSoftInputFromWindow(currentFocus!!.windowToken, 0)
                }
            }
        }
        return ret
    }
}