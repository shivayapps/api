package com.gallery.photo.image.video.ui.activity

import android.app.WallpaperManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.core.content.FileProvider
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ActivityWallpaperBinding
import com.gallery.photo.image.video.ui.dialog.SetWallpaperDialog
import com.gallery.photo.image.video.utils.Constant
import java.io.File


class WallpaperActivity : BaseActivity() {

    lateinit var binding: ActivityWallpaperBinding
    var imagePath = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWallpaperBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()

        intListener()

    }


    private fun intView() {
        binding.progressBar.visibility = android.view.View.GONE
        val bundle2 = Bundle()
        bundle2.putString("WallPaperEdit", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        imagePath = intent.getStringExtra(Constant.EXTRA_WALL_PAPER).toString()

//        binding.displayImage.controller.settings
//            .setMaxZoom(7f).doubleTapZoom = 3f

//        Glide.with(this).load(imagePath)
//            .diskCacheStrategy(DiskCacheStrategy.NONE)
//            .skipMemoryCache(true).into(binding.displayImage)
//        binding.clipView.setImageSrc(imagePath)

        val imageUri = FileProvider.getUriForFile(
            this, "$packageName.provider",
            File(imagePath)
        )
        binding.cropView.setImageUriAsync(imageUri)
        binding.cropView.apply {
            val newAspectRatio = Pair(9f, 16f)
            setAspectRatio(newAspectRatio.first.toInt(), newAspectRatio.second.toInt())
        }
    }

    override fun onBackPressed() {
        if (binding.progressBar.visibility != View.VISIBLE)
            super.onBackPressed()
    }

    private fun intListener() {
        binding.btnApply.setOnClickListener {
            val bitmap = binding.cropView.croppedImage
            if (bitmap != null)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    showSeAsDialog(bitmap)
                } else {

                    val wallpaperManager = WallpaperManager.getInstance(this)
                    wallpaperManager.setBitmap(getResizeImage(bitmap))
                    finish()
                }
        }
    }

    private fun getResizeImage(image: Bitmap): Bitmap {
        val width = getScreenWidth()
        val iWidth= image.width
        val iHeight= image.height
        if (iWidth > width) {
            val ratio: Float = iWidth / iHeight.toFloat()
            val height = (width / ratio).toInt()
            return Bitmap.createScaledBitmap(image, width, height, false)
        }
        return image
    }

    private fun showSeAsDialog(bitmap: Bitmap) {
        val wallpaperManager = WallpaperManager.getInstance(this)
        val setWallpaperDialog = SetWallpaperDialog {

            when (it) {
                1 -> {
                    binding.btnApply.isEnabled = false
                    binding.progressBar.visibility = android.view.View.VISIBLE
                    binding.tvBtnTitle.text = getString(R.string.applying)
                    Thread {
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                wallpaperManager.setBitmap(
                                    getResizeImage(bitmap),
                                    null,
                                    true,
                                    WallpaperManager.FLAG_LOCK
                                )
                            } else {
                                wallpaperManager.setBitmap(getResizeImage(bitmap))
                            }
                            runOnUiThread {
                                Toast.makeText(
                                    this,
                                    getString(R.string.wallpaper_success),
                                    Toast.LENGTH_SHORT
                                )
                                    .show()
                                finish()
                            }
                        } catch (e: Exception) {
                            runOnUiThread {
                                Toast.makeText(
                                    this,
                                    getString(R.string.out_of_memory_error),
                                    Toast.LENGTH_SHORT
                                )
                                    .show()
                                finish()
                            }
                        }
                    }.start()
                }

                2 -> {
                    binding.btnApply.isEnabled = false
                    binding.progressBar.visibility = android.view.View.VISIBLE
                    binding.tvBtnTitle.text = getString(R.string.applying)
                    Thread {
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                wallpaperManager.setBitmap(
                                    getResizeImage(bitmap),
                                    null,
                                    true,
                                    WallpaperManager.FLAG_SYSTEM
                                )
                            } else {
                                wallpaperManager.setBitmap(getResizeImage(bitmap))
                            }
                            runOnUiThread {
                                Toast.makeText(
                                    this,
                                    getString(R.string.wallpaper_success),
                                    Toast.LENGTH_SHORT
                                )
                                    .show()
                                finish()
                            }
                        } catch (e: Exception) {
                            runOnUiThread {
                                Toast.makeText(
                                    this,
                                    getString(R.string.out_of_memory_error),
                                    Toast.LENGTH_SHORT
                                )
                                    .show()
                                finish()
                            }
                        }
                    }.start()
                }

                3 -> {
                    binding.btnApply.isEnabled = false
                    binding.progressBar.visibility = android.view.View.VISIBLE
                    binding.tvBtnTitle.text = getString(R.string.applying)

                    Thread {
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                wallpaperManager.setBitmap(
                                    getResizeImage(bitmap),
                                    null,
                                    true,
                                    WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                                )
                            } else {
                                wallpaperManager.setBitmap(getResizeImage(bitmap))
                            }
                            runOnUiThread {
                                Toast.makeText(
                                    this,
                                    getString(R.string.wallpaper_success),
                                    Toast.LENGTH_SHORT
                                )
                                    .show()
                                finish()
                            }
                        } catch (e: Exception) {
                            runOnUiThread {
                                Toast.makeText(
                                    this,
                                    getString(R.string.out_of_memory_error),
                                    Toast.LENGTH_SHORT
                                )
                                    .show()
                                finish()
                            }
                        }
                    }.start()
                }
            }
        }
        setWallpaperDialog.show(supportFragmentManager, setWallpaperDialog.tag)
    }
}