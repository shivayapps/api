package com.gallery.photo.image.video.browser.model

import de.mrapp.android.tabswitcher.Tab

data class BrowserTab(var tabTitle: String, var tab: Tab? = null)
