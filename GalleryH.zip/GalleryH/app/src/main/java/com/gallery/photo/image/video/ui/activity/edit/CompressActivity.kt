package com.gallery.photo.image.video.ui.activity.edit

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.Formatter
import android.util.Log
import android.view.View
import android.widget.Toast
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.customView.SeekArc
import com.gallery.photo.image.video.databinding.ActivityCompressBinding
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.ui.event.RenameEvent
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.ImageUtils
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import java.io.File

class CompressActivity : BaseActivity() {

    lateinit var binding: ActivityCompressBinding
    var imagePath = ""
    var mHandler = Handler(Looper.myLooper()!!)
    var animationTime = 15
    var imageCompress: Boolean = false
    var currentSize = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCompressBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        val bundle2 = Bundle()
        bundle2.putString("EditCompress", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        intListener()
        binding.txtSpaceSaved.visibility = View.GONE
        binding.loutConvert.visibility = View.GONE
        binding.btnDone.visibility = View.GONE
        binding.tvProgress.visibility = View.VISIBLE
        binding.animationView.visibility = View.GONE
        imagePath = intent.getStringExtra(Constant.EXTRA_IMAGE_PATH) ?: ""
        binding.tvProgress.text = "${binding.seekBar.progress}%"

        currentSize = File(imagePath).length()

        binding.tvCurrentSize.text = Formatter.formatShortFileSize(
            this@CompressActivity,
            File(imagePath).length()
        )

        GlobalScope.launch {
            Log.e(
                "CompressTag",
                "CurrentSize ${
                    Formatter.formatShortFileSize(
                        this@CompressActivity,
                        File(imagePath).length()
                    )
                }"
            )
            val isComPress =
                com.gallery.photo.image.video.utils.ImageUtils()
                    .getCompressedBitmap(imagePath, this@CompressActivity, currentSize)
            if (isComPress)
                EventBus.getDefault().post(RenameEvent(imagePath, imagePath, true))
            runOnUiThread {
                if (isComPress)
                    setImageCompress()
                else {
                    imageCompress = false
                    Toast.makeText(
                        this@CompressActivity,
                        getString(R.string.failed),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    override fun onBackPressed() {
        if (imageCompress)
            super.onBackPressed()
    }

    private fun intListener() {
        binding.btnDone.setOnClickListener {
            setResult(RESULT_OK)
            finish()
        }
        binding.seekBar.setOnSeekArcChangeListener(object : com.gallery.photo.image.video.customView.SeekArc.OnSeekArcChangeListener {
            override fun onProgressChanged(seekArc: com.gallery.photo.image.video.customView.SeekArc?, progress: Int, fromUser: Boolean) {
                binding.tvProgress.text = "$progress%"
            }

            override fun onStartTrackingTouch(seekArc: com.gallery.photo.image.video.customView.SeekArc?) {

            }

            override fun onStopTrackingTouch(seekArc: com.gallery.photo.image.video.customView.SeekArc?) {

            }
        })
    }

    private fun setImageCompress() {
        startAnimation()
        val resize = currentSize - File(imagePath).length()
        binding.tvResizeSize.text = Formatter.formatShortFileSize(
            this@CompressActivity,
            File(imagePath).length()
        )
        binding.txtSpaceSaved.text = "${
            Formatter.formatShortFileSize(
                this@CompressActivity,
                resize
            )
        } ${getString(R.string.space_saved)}"
        Log.e(
            "CompressTag",
            "size ${Formatter.formatShortFileSize(this@CompressActivity, File(imagePath).length())}"
        )
        setResult(RESULT_OK)
    }

    private fun startAnimation() {
        binding.seekBar.progress = binding.seekBar.progress + 5
        if (mHandler != null) mHandler.removeCallbacks(animationTask)
        mHandler.postDelayed(animationTask, animationTime.toLong())
    }

    private val animationTask: Runnable = object : Runnable {
        override fun run() {
            if (binding.seekBar.progress < 100) {
                binding.seekBar.progress = binding.seekBar.progress + 5
                mHandler.postDelayed(this, animationTime.toLong())
            } else {
                imageCompress = true
                binding.seekBar.setShowThumb(false)
                binding.seekBar.progress = 0
                binding.txtSpaceSaved.visibility = View.VISIBLE
                binding.loutConvert.visibility = View.VISIBLE
                binding.btnDone.visibility = View.VISIBLE
                binding.tvProgress.visibility = View.GONE
                binding.animationView.visibility = View.VISIBLE
                binding.animationView.playAnimation()
                stopAnimation()
            }
        }
    }

    private fun stopAnimation() {
        if (mHandler != null) mHandler.removeCallbacks(animationTask)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAnimation()
    }

}
