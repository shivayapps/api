package com.gallery.photo.image.video.ui.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogPrivateMenuBinding
import com.gallery.photo.image.video.utils.Constant

class PrivateMenuDialog(val clickListener: (type: Int) -> Unit) : BottomSheetDialogFragment() {

    lateinit var binding: DialogPrivateMenuBinding
    lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DialogPrivateMenuBinding.inflate(layoutInflater, container, false)
        intView()
        return binding.root
    }

    private fun intView() {
        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("PrivateMenu", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_dialog, bundle2)

        intListener()

    }

    private fun intListener() {
        binding.btnChangePass.setOnClickListener {
            dismiss()
            clickListener(1)
        }
        binding.btnChangeQue.setOnClickListener {
            dismiss()
            clickListener(2)
        }
        binding.btnChangeLockStyle.setOnClickListener {
            dismiss()
            clickListener(3)
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}