package com.gallery.photo.image.video.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.util.Log;

import java.io.File;
import java.io.IOException;

public class ImageUtils {
    public Boolean getCompressedBitmap(String imagePath, Context context, long imageSize) {
        boolean isCompress = false;
        Bitmap scaledBitmap = null;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;

        float maxHeight = options.outHeight;
        float maxWidth = options.outWidth;
        Log.e("CompressTag", "getCompressedBitmap maxWidth-> " + maxWidth + " maxHeight-> " + maxHeight);

        ExifInterface exif = null;
        try {
            exif = new ExifInterface(imagePath);

            int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);
            scaledBitmap = rotateBitmap(BitmapFactory.decodeFile(imagePath), orientation);

            File imageFile = new File(imagePath);
            if (imageFile.exists()) {
                Log.e("CompressTag", "scaledBitmap Width-> " + scaledBitmap.getWidth() + " Height-> " + scaledBitmap.getHeight());
                int quality = 80;
                long MB = 1000000;
                if (imageSize < MB)
                    quality = 80;
                else if (imageSize < (MB * 2))
                    quality = 75;
                else if (imageSize < (MB * 3))
                    quality = 68;
                else if (imageSize < (MB * 4))
                    quality = 60;
                else if (imageSize < (MB * 5))
                    quality = 50;
                else if (imageSize < (MB * 6))
                    quality = 40;
                else if (imageSize < (MB * 7))
                    quality = 35;
                else
                    quality = 25;

                isCompress = new Utils().saveCompressImage(context, imageFile, scaledBitmap, quality);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return isCompress;
    }

    private Bitmap rotateBitmap(Bitmap bitmap, int orientation) {
        Matrix matrix = new Matrix();
        if (orientation == ExifInterface.ORIENTATION_ROTATE_90)
            matrix.postRotate(90f);
        else if (orientation == ExifInterface.ORIENTATION_ROTATE_180)
            matrix.postRotate(180f);
        else if (orientation == ExifInterface.ORIENTATION_ROTATE_270)
            matrix.postRotate(270f);

        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }


}
