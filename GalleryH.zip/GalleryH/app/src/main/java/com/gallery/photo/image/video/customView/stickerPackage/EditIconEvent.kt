package com.gallery.photo.image.video.customView.stickerPackage

import android.view.MotionEvent

class EditIconEvent(private val listener:(stickerView: com.gallery.photo.image.video.customView.stickerPackage.StickerView?)->Unit) :
    com.gallery.photo.image.video.customView.stickerPackage.StickerIconEvent {
    override fun onActionDown(stickerView: com.gallery.photo.image.video.customView.stickerPackage.StickerView?, event: MotionEvent?) {

    }

    override fun onActionMove(stickerView: com.gallery.photo.image.video.customView.stickerPackage.StickerView?, event: MotionEvent?) {
    }

    override fun onActionUp(stickerView: com.gallery.photo.image.video.customView.stickerPackage.StickerView?, event: MotionEvent?) {
        listener(stickerView)
     }
}