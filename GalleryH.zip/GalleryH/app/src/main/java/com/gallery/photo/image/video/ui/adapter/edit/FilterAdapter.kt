package com.gallery.photo.image.video.ui.adapter.edit

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.databinding.ItemFilterBinding
import com.gallery.photo.image.video.ui.model.edit.FilterItem

class FilterAdapter(
    var context: Context,
    var filterList: ArrayList<FilterItem>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<FilterAdapter.ViewHolder>() {

    var selectPos = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemFilterBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return filterList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.tvTitle.text = filterList[position].filter.name

        holder.binding.ivImageSelect.visibility =
            if (selectPos == position) View.VISIBLE else View.GONE

        holder.binding.ivImage.setImageBitmap(filterList[position].bitmap)

        holder.binding.root.setOnClickListener {
            val p = selectPos
            selectPos = position
            clickListener(position)
            notifyItemChanged(selectPos)
            if (p != -1)
                notifyItemChanged(p)
        }
    }

    class ViewHolder(var binding: ItemFilterBinding) : RecyclerView.ViewHolder(binding.root) {

    }
}