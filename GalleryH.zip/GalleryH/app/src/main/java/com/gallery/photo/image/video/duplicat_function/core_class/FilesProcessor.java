package com.gallery.photo.image.video.duplicat_function.core_class;

import android.content.Context;

import androidx.lifecycle.MutableLiveData;

import com.gallery.photo.image.video.duplicat_function.flow.Flow;
import com.gallery.photo.image.video.duplicat_function.flow.Predicate;
import com.gallery.photo.image.video.duplicat_function.model_class.DFile;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.DupFileFilter;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.FileScanWorker;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.ImageMetadataExtractor;
import com.gallery.photo.image.video.duplicat_function.model_class.DFile;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.DupFileFilter;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.DuplicateConstants;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.FileScanWorker;
import com.gallery.photo.image.video.duplicat_function.utils_duplicat.ImageMetadataExtractor;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class FilesProcessor {
    private final DupFileFilter dupFileFiler;
    private ThreadPoolExecutor executor;
    private FileScanWorker.ProgressProgressListener progressProgressListener;
    private final String root;
    private boolean stopped;
    private int totalFilesToProcess;
    private static final int NUMBER_OF_CORES = Runtime.getRuntime().availableProcessors();
    private final AtomicInteger TASK_COMPLETED_TRACKER = new AtomicInteger();
    private final Map<Long, Set<DFile>> filesBySize = new ConcurrentHashMap();
    private final List<DFile> imagesWithOriginalDate = Collections.synchronizedList(new ArrayList());

    public static MutableLiveData<String> pathObserver = new MutableLiveData<>();

    public void setProgressProgressListener(FileScanWorker.ProgressProgressListener progressProgressListener) {
        this.progressProgressListener = progressProgressListener;
    }

    public boolean isStopped() {
        return this.stopped;
    }

    public void setStopped(boolean z) {
        this.stopped = z;
    }

    public FilesProcessor(Context context, String str, String str2, boolean z) {
        int i = NUMBER_OF_CORES;
        this.executor = new ThreadPoolExecutor(i * 2, i * 2, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue());
        this.root = str;
        this.dupFileFiler = new DupFileFilter(str2, z, new HashSet());
    }

    public Set<Set<DFile>> traverse() {
        File[] listFiles;
        LinkedList linkedList = new LinkedList();
        linkedList.offer(new File(this.root));
        while (!linkedList.isEmpty()) {
            if (isStopped()) {
                linkedList.clear();
                this.executor.shutdown();
                return null;
            }
            File file = (File) linkedList.poll();
            if (file != null && (listFiles = file.listFiles(this.dupFileFiler)) != null) {
                for (File file2 : listFiles) {
                    if (file2.isDirectory()) {
//                        Log.e("Condition_1+++++++>", "Executed!");
//                        Log.e("Condition_1+++++++>", ""+file2.getPath());
                        linkedList.offer(file2);

                    } else if (file2.length() <= 100000000) {
//                        Log.e("Condition_2+++++++>", "Executed!");
//                        Log.e("Condition_2+++++++>", ""+file2.getPath());
                        this.totalFilesToProcess++;
                        this.executor.execute(new Handler(file2));
                    }
                }
            }
        }
        waitAndTerminalExecutor();
        HashSet hashSet = new HashSet(Flow.of(this.filesBySize.values()).filter(new Predicate<Set<DFile>>() {
            @Override
            public boolean test(Set<DFile> dFiles) {
                 return dFiles.size() > 1;
            }
        }).toList());
        if (this.imagesWithOriginalDate.size() > 0) {
            hashSet.add(new HashSet(this.imagesWithOriginalDate));
        }
        return hashSet;
    }

    private void waitAndTerminalExecutor() {
        while (filedProcessingGap() > 20) {
            try {
                Thread.sleep(1000L);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if (filedProcessingGap() > 0) {
            try {
                Thread.sleep(1000L);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        this.executor.shutdown();
    }

    private int filedProcessingGap() {
        return this.totalFilesToProcess - this.TASK_COMPLETED_TRACKER.get();
    }

    private class Handler implements Runnable {
        private final File file;

        Handler(File file) {
            this.file = file;
        }

        @Override 
        public void run() {
            Date photoTakenDateIfAvailable;
            Long valueOf = Long.valueOf(this.file.length());
            Set hashSet = FilesProcessor.this.filesBySize.containsKey(valueOf) ? FilesProcessor.this.filesBySize.get(valueOf) : new HashSet();
            DFile dFile = DFile.toDFile(this.file);
            dFile.setSize(file.length());
            if (DuplicateConstants.Type.IMAGE.equals(dFile.getType()) && valueOf.longValue() < 3000000 && (photoTakenDateIfAvailable = ImageMetadataExtractor.getPhotoTakenDateIfAvailable(this.file)) != null) {

                dFile.setPhotoTakenAt(photoTakenDateIfAvailable.getTime());
                FilesProcessor.this.imagesWithOriginalDate.add(dFile);
            }

            pathObserver.postValue(dFile.getPath());
//            Log.e("Fileeeeeeeeeeeee:::::::::::::::", ""+dFile.getPath());
            hashSet.add(dFile);
            FilesProcessor.this.filesBySize.put(valueOf, hashSet);
            int andIncrement = FilesProcessor.this.TASK_COMPLETED_TRACKER.getAndIncrement();
            if ((andIncrement < 50 || andIncrement % 20 == 0) && FilesProcessor.this.progressProgressListener != null) {
                FilesProcessor.this.progressProgressListener.setProcessedFileCount(andIncrement);
            }
        }
    }
}
