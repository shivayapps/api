package com.gallery.photo.image.video.browser.dialog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.browser.adapter.TabAdapter
import com.gallery.photo.image.video.browser.model.BrowserTab
import com.gallery.photo.image.video.databinding.DialogBrowserTabBinding
import com.gallery.photo.image.video.ui.dialog.ConfirmationDialog
import com.gallery.photo.image.video.utils.Constant
import de.mrapp.android.tabswitcher.TabSwitcher

class TabListDialog(
    var mContext: Context,
    var browserList: ArrayList<BrowserTab>,
    var tabSwitcher: TabSwitcher,
    val addTabBtnClickListener: () -> Unit,
    val openNewTabTabBtnClickListener: (pos: Int) -> Unit,
    val deleteTabTabBtnClickListener: (pos: Int) -> Unit,
    val allDeleteTabTabBtnClickListener: () -> Unit,
) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogBrowserTabBinding
    var adapter: TabAdapter? = null
    var tabList: ArrayList<BrowserTab> = ArrayList()
    lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogBrowserTabBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("BrowserTabList", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_dialog, bundle2)


        tabList.addAll(browserList)
        adapter = TabAdapter(mContext, tabList, tabSwitcher.selectedTabIndex, clickListener = {
            dismiss()
            openNewTabTabBtnClickListener(it)
        }, deleteListener = {
            deleteTabTabBtnClickListener(it)
            tabList.removeAt(it)
            adapter?.notifyDataSetChanged()
            noDataView()
            if (tabList.size != 0) {
                adapter?.selectPos = tabSwitcher.selectedTabIndex
                adapter?.notifyDataSetChanged()
            }
        })
        bindingDialog.recyclerView.adapter = adapter

        noDataView()

        bindingDialog.icClose.setOnClickListener { dismiss() }
        bindingDialog.icAdd.setOnClickListener {
            dismiss()
            addTabBtnClickListener()
        }
        bindingDialog.icDelete.setOnClickListener {
            val deleteDialog = ConfirmationDialog(
                mContext,
                getString(R.string.Delete),
                getString(R.string.remove_all_tabs),
                getString(R.string.Delete),
                positiveBtnClickListener = {
                    allDeleteTabTabBtnClickListener()
                    dismiss()
                }
            )
            deleteDialog.show(childFragmentManager, deleteDialog.tag)
        }

    }

    private fun noDataView() {
        if (tabList.size != 0) {
            bindingDialog.recyclerView.visibility = View.VISIBLE
            bindingDialog.icDelete.visibility = View.VISIBLE
            bindingDialog.tvNoData.visibility = View.GONE
        } else {
            bindingDialog.recyclerView.visibility = View.GONE
            bindingDialog.icDelete.visibility = View.GONE
            bindingDialog.tvNoData.visibility = View.VISIBLE
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)

}