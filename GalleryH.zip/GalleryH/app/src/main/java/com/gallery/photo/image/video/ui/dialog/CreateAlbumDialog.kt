package com.gallery.photo.image.video.ui.dialog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogCreateAlbumBinding
import com.gallery.photo.image.video.utils.Constant
import java.io.File

class CreateAlbumDialog(
    var mContext: Context,
    val createPathListener: (path: String) -> Unit,
    var isOpenFromMenu: Boolean = false
) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogCreateAlbumBinding
    lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogCreateAlbumBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        val bundle2 = Bundle()
        bundle2.putString("CreateAlbum", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_dialog, bundle2)

        bindingDialog.icClear.visibility = View.GONE
        intListener()
    }

    private fun intListener() {
        bindingDialog.edtAlbumName.addTextChangedListener {
            bindingDialog.icClear.visibility =
                if (bindingDialog.edtAlbumName.text?.trim().toString()
                        .isNotEmpty()
                ) View.VISIBLE else View.GONE
        }

        bindingDialog.icClear.setOnClickListener {
            bindingDialog.edtAlbumName.setText("")
        }
        bindingDialog.btnCreate.setOnClickListener {
            val albumName = bindingDialog.edtAlbumName.text.trim()
            if (albumName.isNotEmpty()) {
                val file =
                    File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).path + File.separator + albumName)
                if (!file.exists()) {
                    if (!isOpenFromMenu)
                        file.mkdirs()
                    dismiss()
                    createPathListener(file.path)
                } else
                    Toast.makeText(
                        mContext,
                        mContext.getString(R.string.create_validation2),
                        Toast.LENGTH_SHORT
                    ).show()
            } else
                Toast.makeText(
                    mContext,
                    mContext.getString(R.string.create_validation),
                    Toast.LENGTH_SHORT
                ).show()
        }
        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}