package com.gallery.photo.image.video.ui.activity.edit

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Point
import android.graphics.PorterDuff
import android.os.Bundle
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ActivityEditImageBinding
import com.gallery.photo.image.video.ui.activity.BaseActivity
import com.gallery.photo.image.video.ui.dialog.ConfirmationDialog
import com.gallery.photo.image.video.ui.dialog.ProgressDialog
import com.gallery.photo.image.video.ui.event.CopyMoveEvent
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.StorageUtils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date

class EditImageActivity : BaseActivity() {

    lateinit var binding: ActivityEditImageBinding
    var imagePath = ""
    var mainImagePath = ""
    var saveImageName = ""
    var isEditImage = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditImageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        val bundle2 = Bundle()
        bundle2.putString("EditImageHome", Constant.event_open)
        firebaseAnalytics.logEvent(Constant.event_activity, bundle2)

        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        mainImagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        binding.loutToolbar.txtTitle.text = getString(R.string.editor)
        setImageDoneColor()
        val width = getScreenWidth()
//        Log.e("EditTag", "width $width")

        imageLoad()
        intListener()

        val timeStamp = SimpleDateFormat("HHmmss_ddMyy").format(Date())
        saveImageName = "IMG_$timeStamp.jpg"
        Thread {
            val size = mainImagePath.getImageResolution()
            Log.e("EditTag", "width $width imageWidth ${size.x}")
            if (size.x > width) {

                Log.e("EditTag", "resize image")
                val ratio: Float = size.x / size.y.toFloat()
                val height = (width / ratio).toInt()
                val newBitmap =
                    Glide.with(this.applicationContext).asBitmap()
                        .load(mainImagePath)
                        .submit(width, height)
                        .get()
                val imageResizePath = saveEditImage(newBitmap, "IMG_Resize$timeStamp.jpg", 40)
                if (!imageResizePath.isNullOrEmpty())
                    imagePath = imageResizePath
                runOnUiThread {
                    Log.e("EditTag", "resize image successfully")
                }
            }
        }.start()
    }

    private fun imageLoad() {
        Glide.with(this)
            .load(imagePath)
            .diskCacheStrategy(DiskCacheStrategy.NONE)
            .skipMemoryCache(true)
            .into(binding.imageDisplay)
    }

    var editLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val path = result.data?.getStringExtra(Constant.EXTRA_EDIT_SAVE_IMAGE)
                if (path != null) {
                    imagePath = path
                    isEditImage = true
                }
                imageLoad()
                setImageDoneColor()
            }
        }

    fun String.getImageResolution(): Point {
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(this, options)

        val width = options.outWidth
        val height = options.outHeight
        return if (width > 0 && height > 0) {
            Point(options.outWidth, options.outHeight)
        } else {
            Point(0, 0)
        }
    }

    private fun setImageDoneColor() {
        val selectColor = ContextCompat.getColor(
            this,
//            if (mainImagePath != imagePath) R.color.black_text else R.color.grayText
            if (isEditImage) R.color.black_text else R.color.grayText
        )
        binding.loutToolbar.icDone.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)

    }

    override fun onBackPressed() {
        if (isEditImage) {
            val hideDialog = ConfirmationDialog(
                this,
                getString(R.string.discard),
                getString(R.string.exit_edit_msg),
                getString(R.string.ok),
                positiveBtnClickListener = {
                    super.onBackPressed()
                })
            hideDialog.show(supportFragmentManager, hideDialog.tag)
        } else
            super.onBackPressed()
    }

    private fun intListener() {
        binding.loutToolbar.icBack.setOnClickListener { onBackPressed() }
        binding.loutToolbar.icDone.setOnClickListener {
            binding.loutToolbar.icDone.isEnabled = false
            if (mainImagePath.isNotEmpty() && imagePath.isNotEmpty() && isEditImage) {
                saveImage()
            } else
                binding.loutToolbar.icDone.isEnabled = true
        }

        binding.btnFilter.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    FilterActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }

        binding.btnAdjust.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    AdjustActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }

        binding.btnCrop.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    CropActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }

        binding.btnDoodle.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    DoodleActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }

        binding.btnSticker.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    StickerActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }
    }

    private fun saveImage() {
        val copyFiles = java.util.ArrayList<String>()
        val targetFolder = File(Constant.EDIT_PATH)
        if (!targetFolder.exists())
            targetFolder.mkdirs()

        val progressDialog = ProgressDialog(this, getString(R.string.saving))
        progressDialog.show()

        Observable.fromCallable {
            val copyFile = File(imagePath)
            if (copyFile.exists()) {
                val copyFileName = copyFile.name
                val targetPath = targetFolder.path + File.separator + copyFileName
                val targetFile = File(targetPath)
                if (targetFile.exists()) {
                    val separated =
                        copyFile.name.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }
                            .toTypedArray()
                    val name = separated[0]
                    val type = separated[1]
                    val newPath2 =
                        targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + "." + type
                    val file2 = File(newPath2)
                    val isCopied: Boolean =
                        com.gallery.photo.image.video.utils.StorageUtils.copyFile(
                            copyFile,
                            file2,
                            this
                        )
                    if (isCopied) {
                        copyFiles.add(file2.path)
                    }
                } else {
                    val isCopied: Boolean =
                        com.gallery.photo.image.video.utils.StorageUtils.copyFile(
                            copyFile,
                            targetFile,
                            this
                        )
                    if (isCopied) {
                        copyFiles.add(targetFile.path)
                    }

                }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    EventBus.getDefault().post(
                        CopyMoveEvent(
                            copyFiles,
                            targetFolder.name,
                            targetFolder.absolutePath,
                            ArrayList()
                        )
                    )
                    progressDialog.dismiss()
                    finish()
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {

                    EventBus.getDefault().post(
                        CopyMoveEvent(
                            copyFiles,
                            targetFolder.name,
                            targetFolder.absolutePath,
                            ArrayList()
                        )
                    )
                    progressDialog.dismiss()
                    finish()
                }
            }
    }
}