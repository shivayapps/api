package com.adconfig.adsutil.admob

object AdmobTestIds {
    const val App_Open = "ca-app-pub-3940256099942544/3419835294"
    const val Adaptive_Banner = "ca-app-pub-3940256099942544/9214589741"
    const val Banner = "ca-app-pub-3940256099942544/6300978111"
    const val Interstitial = "ca-app-pub-3940256099942544/1033173712"
    //const val Interstitial_Video = "ca-app-pub-3940256099942544/8691691433"
    const val Rewarded = "ca-app-pub-3940256099942544/5224354917"
    const val Rewarded_Interstitial = "ca-app-pub-3940256099942544/5354046379"
    const val Native_Advanced = "ca-app-pub-3940256099942544/2247696110"
    //const val Native_Advanced_Video = "ca-app-pub-3940256099942544/1044960115"
}