package com.example.pr2.retrofit

import com.example.pr2.model.Model
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {

    // Get current weather data
    @GET("posts")
    fun getData(): Call<List<Model>>
}