package com.example.pr2.model;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import java.util.List;

public class DataViewModel extends AndroidViewModel {
    private Repository repository;
    public LiveData<List<Model>> getAllModels;

    public DataViewModel(@NonNull Application application) {
        super(application);
        repository=new Repository(application);
        getAllModels=repository.getAllModel();
    }

    public void insert(List<Model> models){
        repository.insert(models);
    }

    public LiveData<List<Model>> getAllModels()
    {
        return getAllModels;
    }
}