package com.example.pr2.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.example.pr2.R
//import com.example.pr2.model.Data
import com.example.pr2.model.Model

class ModelAdapter(var listModel: List<Model>,val listner:ClickListener) : RecyclerView.Adapter<ModelAdapter.ViewHolder>() {

    interface ClickListener{
        fun onClick(operation:Int,model: Model)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ModelAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_view, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ModelAdapter.ViewHolder, position: Int) {
        val data = listModel[position]
        holder.tvTitle.text=data.title
        holder.tvBody.text=data.body

        holder.btnEdit.setOnClickListener {
            listner.onClick(0,data)
        }
        holder.btnDelete.setOnClickListener {
            listner.onClick(1,data)
        }

    }

    override fun getItemCount(): Int {
        return listModel.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTitle = itemView.findViewById<TextView>(R.id.tvTitle)
        val tvBody = itemView.findViewById<TextView>(R.id.tvBody)
        val btnEdit = itemView.findViewById<Button>(R.id.btnEdit)
        val btnDelete = itemView.findViewById<Button>(R.id.btnDelete)
    }


}
