package com.example.pr2.model

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.SerializedName;

@Entity(tableName = "model")
data class Model(
    @PrimaryKey @SerializedName("id") val id:Int,
    @SerializedName("userId") val userId:Int,
    @SerializedName("title") var title:String,
    @SerializedName("body") val body:String
//    var listModel: ArrayList<Data>
)
//data class Data(
//    val userId:Int,
//    val id:Int,
//    val title:String,
//    val body:String
//)
