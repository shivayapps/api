package com.example.pr2.model;

import android.app.Application;
import android.os.AsyncTask;
import androidx.lifecycle.LiveData;
import java.util.List;

public class Repository {
    public ModelDao modelDao;
    public LiveData<List<Model>> getAllModel;
    private ModelDatabase database;
    
    public Repository(Application application){
        database=ModelDatabase.getInstance(application);
        modelDao=database.getModelDao();
        getAllModel =modelDao.getModels();

    }

    public void insert(List<Model> cats){
        new InsertAsyncTask(modelDao).execute(cats);
    }
    public void deleteAll(){
        new DeleteAllAsyncTask(modelDao).execute();
    }
    public void delete(int id){
        new DeleteAsyncTask(modelDao).execute(id);
    }
    public void update(Model model){
        new UpdateAsyncTask(modelDao).execute(model);
    }

    public LiveData<List<Model>> getAllModel(){
        return getAllModel;
    }
    private static class DeleteAllAsyncTask extends AsyncTask<Void,Void,Void>{
        private ModelDao modelDao;

        public DeleteAllAsyncTask(ModelDao modelDao)
        {
            this.modelDao=modelDao;
        }
        @Override
        protected Void doInBackground(Void... voids) {
            modelDao.deleteAll();
            return null;
        }
    }
    private static class DeleteAsyncTask extends AsyncTask<Integer,Void,Void>{
        private ModelDao modelDao;

        public DeleteAsyncTask(ModelDao modelDao)
        {
            this.modelDao=modelDao;
        }

        @Override
        protected Void doInBackground(Integer... integers) {
            modelDao.delete(integers[0]);
            return null;
        }

    }
    private static class UpdateAsyncTask extends AsyncTask<Model,Void,Void>{
        private ModelDao modelDao;

        public UpdateAsyncTask(ModelDao modelDao)
        {
            this.modelDao=modelDao;
        }

        @Override
        protected Void doInBackground(Model... models) {
            modelDao.update(models[0].getTitle(),models[0].getId());
            return null;
        }

    }
    private static class InsertAsyncTask extends AsyncTask<List<Model>,Void,Void>{
        private ModelDao modelDao;

        public InsertAsyncTask(ModelDao modelDao)
        {
            this.modelDao=modelDao;
        }
        @Override
        protected Void doInBackground(List<Model>... lists) {
            modelDao.insert(lists[0]);
            return null;
        }
    }

}