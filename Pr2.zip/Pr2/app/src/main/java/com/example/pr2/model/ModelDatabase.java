package com.example.pr2.model;

import android.content.Context;
import android.os.AsyncTask;
import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;
@Database(entities = {Model.class},version = 1)
public abstract class ModelDatabase extends RoomDatabase {

    private static final String DATABASE_NAME = "model";
    public abstract ModelDao getModelDao();
    public static volatile ModelDatabase INSTANCE = null;

    public static ModelDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (ModelDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context, ModelDatabase.class, DATABASE_NAME)
                            .fallbackToDestructiveMigration()
                            .addCallback(callback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    public static Callback callback = new Callback() {
        @Override
        public void onOpen(@NonNull SupportSQLiteDatabase db) {
            super.onOpen(db);
            new PopulateDbAsyn(INSTANCE);
        }
    };

    static  class  PopulateDbAsyn extends AsyncTask<Void,Void,Void>{
        private ModelDao modelDao;
        public PopulateDbAsyn(ModelDatabase catDatabase)
        {
            modelDao =catDatabase.getModelDao();
        }
        @Override
        protected Void doInBackground(Void... voids) {
            modelDao.deleteAll();
            return null;
        }
    }
}