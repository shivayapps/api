package com.example.pr2

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pr2.adapter.ModelAdapter
import com.example.pr2.model.DataViewModel
import com.example.pr2.model.Model
import com.example.pr2.model.Repository
import com.example.pr2.retrofit.MainViewModel


class MainActivity : AppCompatActivity() {


    private lateinit var mainViewModel: MainViewModel
    private lateinit var rvData: RecyclerView
    private val TAG="MainActivity"
    private var repository: Repository? = null
    private var dataViewModel: DataViewModel? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnSubmit = findViewById<Button>(R.id.btnSubmit)
        val btnReset = findViewById<Button>(R.id.btnReset)

        rvData = findViewById<RecyclerView>(R.id.rvData)
        rvData.layoutManager=LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
        repository=Repository(application);
        mainViewModel = MainViewModel()
        subscribe()

        btnReset.setOnClickListener {
            repository?.deleteAll()
//            mainViewModel.getData()
        }
        btnSubmit.setOnClickListener {
            mainViewModel.getData()
        }

        dataViewModel = ViewModelProvider(this)[DataViewModel::class.java]

        dataViewModel?.allModels!!.observe(this
        ) { value ->
            Log.e(TAG,"allModels:$value")
            rvData.adapter = ModelAdapter(value,object :ModelAdapter.ClickListener{
                override fun onClick(operation:Int,model: Model) {
                    if(operation==0) {
                        confirmDialog(model)
                    } else if (operation==1) {
                        repository?.delete(model.id)
                    }
                }
            })
        }
    }

    private fun confirmDialog(model:Model){
        val builder = AlertDialog.Builder(this)
            .create()
        val view = layoutInflater.inflate(R.layout.dialog_view,null)
        val etTitle = view.findViewById<EditText>(R.id.etTitle)
        val btnCancel = view.findViewById<Button>(R.id.btnCancel)
        val btnUpdate = view.findViewById<Button>(R.id.btnUpdate)
        builder.setView(view)

        etTitle.setText(model.title)

        btnCancel.setOnClickListener {
            builder.dismiss()
        }
        btnUpdate.setOnClickListener {
            val title=etTitle.text
            model.title=title.toString()

            repository?.update(model)
            builder.dismiss()
        }
        builder.setCanceledOnTouchOutside(false)
        builder.show()
    }


    private fun subscribe() {
        mainViewModel.isLoading.observe(this) { isLoading ->
            // Is sending the API request
            Log.e(TAG,"isLoading:$isLoading")
        }

        mainViewModel.isError.observe(this) { isError ->
            // Encountered an error in the process
            Log.e(TAG,"isError:$isError")
        }

        mainViewModel.modelData.observe(this) { modelData ->
            // Display weather data to the UI
            Log.e(TAG,"setResultText:Ok")
            repository?.insert(modelData)
        }
    }

}