package com.example.pr2.model;

import androidx.room.Dao;

import androidx.lifecycle.LiveData;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import java.util.List;

@Dao
public interface ModelDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(List<Model> model);

    @Query("SELECT DISTINCT * FROM model")
    LiveData<List<Model>> getModels();

    @Query("UPDATE model SET title=:title WHERE id = :id")
    void update(String title, int id);

    @Query("DELETE FROM model WHERE id = :id")
    void delete(int id);

    @Query("DELETE FROM model")
    void deleteAll();
}