plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
    id("kotlin-parcelize")
    id("com.google.firebase.crashlytics")
//    id("com.google.devtools.ksp")
//    id("org.jetbrains.kotlin.kapt")
}

android {
    namespace = "com.locationstamp.camera"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.gpsmapcamera.watermark"
        minSdk = 24
        targetSdk = 35
        versionCode = 3
        versionName = "1.0.2"
        multiDexEnabled = true

        setProperty("archivesBaseName", "gpsmapcamera-v${versionName}")
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }

    //flavorDimensions += "ReleaseAd"
    flavorDimensions += "default"

    productFlavors {
        create("TestAd") {
            //dimension = "ReleaseAd"
            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")
            resValue("string", "banner_camera", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_gallery", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_template", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_full_screen", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_map", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "native_language", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "inter_all", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "open_splash", "ca-app-pub-3940256099942544/9257395921")
            resValue("string", "open_all", "ca-app-pub-3940256099942544/9257395921")
        }

        create("ReleaseAd") {
            isDefault = true
            //dimension = "ReleaseAd"
            resValue("string", "ads_application_id", "ca-app-pub-2750800778809761~8122369610")
            resValue("string", "banner_camera", "ca-app-pub-2750800778809761/3716506152")
            resValue("string", "banner_gallery", "ca-app-pub-2750800778809761/3033694462")
            resValue("string", "banner_template", "ca-app-pub-2750800778809761/4694507911")
            resValue("string", "banner_full_screen", "ca-app-pub-2750800778809761/5258217334")
            resValue("string", "banner_map", "ca-app-pub-2750800778809761/3286660116")
            resValue("string", "native_language", "ca-app-pub-2750800778809761/5384773058")
            resValue("string", "inter_all", "ca-app-pub-2750800778809761/4071691388")
            resValue("string", "open_splash", "ca-app-pub-2750800778809761/9922783869")
            resValue("string", "open_all", "ca-app-pub-2750800778809761/1123531200")
        }
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.activity:activity:1.9.2")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

    implementation("com.google.android.material:material:1.12.0")
    implementation("com.github.bumptech.glide:glide:4.16.0")

    implementation("com.otaliastudios.opengl:egloo:0.6.1")
    implementation("com.google.android.gms:play-services-tasks:17.2.1")
    implementation("androidx.exifinterface:exifinterface:1.3.3")

    // Map and Location
    implementation("com.google.android.gms:play-services-location:21.3.0")
    implementation("com.google.android.gms:play-services-maps:19.0.0")
    implementation("com.google.maps.android:android-maps-utils:3.8.2")

    // CameraX
    val cameraxVersion = "1.5.1"
    implementation("androidx.camera:camera-camera2:$cameraxVersion")
    implementation("androidx.camera:camera-lifecycle:$cameraxVersion")
    implementation("androidx.camera:camera-view:$cameraxVersion")

    implementation("com.google.guava:guava:31.0.1-android")
    implementation("com.android.volley:volley:1.2.1")
    implementation("com.github.Dhaval2404:ColorPicker:2.3")
    implementation("androidx.multidex:multidex:2.0.1")

    // Firebase
    implementation(platform("com.google.firebase:firebase-bom:32.2.3"))
    implementation("com.google.firebase:firebase-config-ktx")
    implementation("com.google.firebase:firebase-analytics-ktx")
    implementation("com.google.firebase:firebase-crashlytics-ktx")
    implementation("com.google.firebase:firebase-messaging-ktx")

    // Ads
    implementation("com.google.android.gms:play-services-ads:23.0.0")
    implementation(project(":ads"))

    // Lifecycle
    val lifecycleVersion = "2.6.2"
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:$lifecycleVersion")
    implementation("androidx.lifecycle:lifecycle-process:$lifecycleVersion")
    annotationProcessor("androidx.lifecycle:lifecycle-compiler:$lifecycleVersion")

    // Others
    implementation("com.facebook.shimmer:shimmer:0.5.0")
    implementation("com.github.zhpanvip:viewpagerindicator:1.2.2")
    implementation("com.google.android.play:app-update-ktx:2.1.0")
    implementation("com.google.android.play:review-ktx:2.0.1")
    implementation("com.github.ome450901:SimpleRatingBar:1.5.1")
}
