package com.locationstamp.camera.models

data class PageItem(val layoutResId: Int)
