package com.locationstamp.camera

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.adconfig.AdsConfig
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.WelcomeBackActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.locationstamp.camera.activities.AppPermissionActivity
import com.locationstamp.camera.activities.SplashActivity


class MyApplication : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {

    override fun onCreate() {
        super.onCreate()

        context = this
        FirebaseApp.initializeApp(applicationContext)
        FirebaseCrashlytics.getInstance()
            .setCrashlyticsCollectionEnabled(!BuildConfig.VERSION_NAME.contains("test"));
        val appOpenId = getString(R.string.open_all)
        AdsConfig.builder()
            .setTestDeviceId("0")
            .setAdmobAppOpenId(appOpenId)
            .build(this)

        setAppLifecycleListener(this)
        initMobileAds()

    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (fCurrentActivity is SplashActivity) {
            Log.d("AppOpenCheck", "Activity is AdActivity, returning false")
            return false
        } else if (fCurrentActivity is AppPermissionActivity) {
            return false
        } else if (AdsConfig.isSystemDialogOpen) {
            Handler(Looper.getMainLooper()).postDelayed({
                AdsConfig.isSystemDialogOpen = false
            }, 2000)
            return false
        }
        return true
    }

    override fun onActivityCreated(fCurrentActivity: Activity, savedInstanceState: Bundle?) {

    }

    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
                if (OpenAdHelper.isAdAvailable()) {
                    val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
                    intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
                    fCurrentActivity.startActivity(intent)
                }
            }
    }

    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {
    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {
    }

    companion object {
        lateinit var context: Context
    }

}