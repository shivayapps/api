package com.locationstamp.camera.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.locationstamp.camera.MyApplication
import com.locationstamp.camera.R
import com.locationstamp.camera.adapters.LanguageAdapter
import com.locationstamp.camera.databinding.ActivityLanguageBinding
import com.locationstamp.camera.extentions.baseConfig
import com.locationstamp.camera.helpers.AppUtils
import com.locationstamp.camera.helpers.EXTRA_IS_OPEN_FROM_SPLASH
import com.locationstamp.camera.helpers.activity_tag
import com.locationstamp.camera.helpers.open_tag
import com.locationstamp.camera.models.LanguageData

class LanguageActivity : BaseActivity() {

    lateinit var binding: ActivityLanguageBinding
    var selectPos = 0
    lateinit var adapter: LanguageAdapter
    var isOpenFromSplash: Boolean = false
    var languageList: ArrayList<LanguageData> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLanguageBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        //hideNavigationBar()
        AppUtils.logAdapterMessages(
            this@LanguageActivity,
            activity_tag,
            open_tag,
            LanguageActivity::class.java.simpleName.toString()
        )
        init()
        loadNative()
    }

    private fun init() {
        if (intent != null)
            isOpenFromSplash = intent.getBooleanExtra(EXTRA_IS_OPEN_FROM_SPLASH, false)

        getLanList()
        initListener()

        binding.icBack.visibility = if (isOpenFromSplash) View.GONE else View.VISIBLE

//        selectPos = preferences.getSelectLanguage()
        selectPos = baseConfig.selectLanguage
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = LanguageAdapter(
            this,
            languageList,
            clickListener = {
                selectPos = it
            })
        adapter.selectPos = selectPos
        binding.recyclerView.adapter = adapter
    }

    private fun updateViews(languageCode: String) {
        com.locationstamp.camera.helpers.LocaleHelper.setLocale(this, languageCode)
    }

    private fun loadNative() {
//        val nativeADs = PreLoadNativeAds(this)
//        nativeADs.showLoadingLayoutForNative(binding.flNative, NativeAdSize.Big)
//        MyApplication.nativeAdsFiles.observe(this, androidx.lifecycle.Observer { native ->
//            if (native != null) {
//                nativeADs.showNative(binding.flNative, native, NativeAdSize.Big)
//            } else {
//                if (nativeADs.checkAdsIsOn() && MyApplication.isNativeLoading)
//                    binding.flNative.visibility = View.VISIBLE
//                else
//                    binding.flNative.visibility = View.GONE
//            }
//        })

        Log.e("loadHomeBanner", "loadNativeAd")
        val adId = getString(R.string.native_language)
        NativeAdHelper(
            this,
            binding.flNative,
            binding.flNative,
            NativeLayoutType.NativeBig,
            adId, { isLoaded, nativeAd ->
                runOnUiThread {
//                if (!isLoaded) {
//                    binding.adsGuid.setGuidelinePercent(1.0f)
//                } else {
//                    binding.adsGuid.setGuidelinePercent(0.56f)
//                }
                }
            }
        ).loadAd();
    }

    private fun initListener() {
        binding.icBack.setOnClickListener {
            finish()
        }

        binding.ivDone.setOnClickListener {
            AdsConfig.showInterstitialAd(this, {
                if (it) doneMethod()
                else doneMethod()
            })

        }
    }

    private fun doneMethod() {
        //            preferences.setSelectLanguage(selectPos)
        baseConfig.selectLanguage = selectPos
        //            preferences.putLanguage(true)
        baseConfig.languageScreenShow = 1
        baseConfig.selectLanguageString = languageList[selectPos].name
        updateViews(languageList[selectPos].languageCode)
        if (isOpenFromSplash) {

            Log.w("msg", "initListener: " + baseConfig.introScreenShow)
            val intent1 = if (baseConfig.introScreenShow == 0) {
                Intent(this, IntroActivity::class.java)
            } else if (!baseConfig.checkAllPermissions(this@LanguageActivity)) {
                Intent(this, PermissionActivity::class.java)
            } else {
                Intent(this, CameraActivity::class.java)
            }

            startActivity(intent1)
        } else {
            //                setResult(RESULT_OK)
            val intent = Intent(this, CameraActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(intent)
        }
        finish()
    }

    private fun getLanList() {
        languageList.add(
            LanguageData(
                getString(R.string.english),
                "en"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.spanish),
                "es"
            )
        )
        languageList.add(
            LanguageData(
                getString(R.string.german),
                "de"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.french),
                "fr"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.portuguese),
                "pt"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.hindi),
                "hi"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.swedish),
                "sv"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.norwegian),
                "no"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.italian),
                "it"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.dutch),
                "nl"
            )
        )

    }
}