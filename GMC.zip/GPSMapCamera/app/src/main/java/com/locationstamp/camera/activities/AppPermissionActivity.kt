package com.locationstamp.camera.activities

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.locationstamp.camera.R
import com.locationstamp.camera.databinding.ActivityPermissionBinding
import com.locationstamp.camera.extentions.baseConfig
import com.locationstamp.camera.helper.LogUtils
import com.locationstamp.camera.helper.activity_tag
import com.locationstamp.camera.helper.open_tag

class AppPermissionActivity : BaseActivity() {
    private lateinit var binding: ActivityPermissionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //hideNavigationBar()
        LogUtils.logAdapterMessages(
            this@AppPermissionActivity,
            activity_tag,
            open_tag,
            AppPermissionActivity::class.java.simpleName.toString()
        )
        initData()
        allClicks()
        loadIntAds()
    }

    private fun loadIntAds() {
        val adId = getString(R.string.inter_all)
        AdmobIntersAdImpl().load(this, adId)
    }

    private fun initData() {
        if (checkCameraPermissions()) {
            binding.tbCameraPer.isChecked = true
        }
        if (checkLocationPermissions()) {
            binding.tbLocationPer.isChecked = true
        }
        if (checkMediaPermissions()) {
            binding.tbMediaPer.isChecked = true
        }
    }

    private fun allClicks() {
        binding.apply {
            clCameraPer.setOnClickListener {
                tbCameraPer.toggle()
                if (checkCameraPermissions()) {
                    tbCameraPer.isChecked = true
                } else {
                    requestCameraPermission()
                }
            }

            clLocationPer.setOnClickListener {
                tbLocationPer.toggle()
                if (checkLocationPermissions()) {
                    tbLocationPer.isChecked = true
                } else {
                    requestLocationPermission()
                }
            }

            clMediaPer.setOnClickListener {
                tbMediaPer.toggle()
                if (checkMediaPermissions()) {
                    tbMediaPer.isChecked = true
                } else {
                    requestMediaPermission()
                }
            }

            tvAllowAccess.setOnClickListener {
                if (checkCameraPermissions() && checkLocationPermissions() && checkMediaPermissions()) {
                    AdsConfig.showInterstitialAd(this@AppPermissionActivity) {
                        if (it) baseConfig.isNeedInterAd = false

                        startActivity(Intent(this@AppPermissionActivity, CameraActivity::class.java))
                        finish()
                    }
                }
            }
        }
    }


    private val cameraPermissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            val granted = permissions.entries.all { it.value }
            if (!checkCameraPermissions()) {
                binding.tbCameraPer.isChecked = false
            }
            if (granted) {
            } else {
                val permanentlyDenied = permissions.entries.any { (perm, granted) ->
                    !granted && !ActivityCompat.shouldShowRequestPermissionRationale(this, perm)
                }

                if (permanentlyDenied) {
                    showPermissionSettingsDialog()
                } else {
                    // User just denied without "Don't ask again"
                }
            }
        }

    private fun requestCameraPermission() {
        val permissions =
            arrayOf(
                Manifest.permission.CAMERA
            )

        cameraPermissionsLauncher.launch(permissions)
    }


    private val locationPermissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            val granted = permissions.entries.all { it.value }
            if (!checkLocationPermissions()) {
                binding.tbLocationPer.isChecked = false
            }
            if (granted) {
            } else {
                val permanentlyDenied = permissions.entries.any { (perm, granted) ->
                    !granted && !ActivityCompat.shouldShowRequestPermissionRationale(this, perm)
                }

                if (permanentlyDenied) {
                    showPermissionSettingsDialog()
                } else {
                    // User just denied without "Don't ask again"
                }
            }
        }

    private fun requestLocationPermission() {
        val permissions =
            arrayOf(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
            )

        locationPermissionsLauncher.launch(permissions)
    }

    private val mediaPermissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            val granted = permissions.entries.all { it.value }
            if (!checkMediaPermissions()) {
                binding.tbMediaPer.isChecked = false
            }
            if (granted) {
            } else {
                val permanentlyDenied = permissions.entries.any { (perm, granted) ->
                    !granted && !ActivityCompat.shouldShowRequestPermissionRationale(this, perm)
                }

                if (permanentlyDenied) {
                    showPermissionSettingsDialog()
                } else {
                    // User just denied without "Don't ask again"
                }
            }
        }


    fun requestMediaPermission() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES
                //, Manifest.permission.READ_MEDIA_VIDEO
                //, Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        }

        mediaPermissionsLauncher.launch(permissions)
    }


    private fun checkCameraPermissions(): Boolean {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            return true
        }
        return false
    }

    private fun checkLocationPermissions(): Boolean {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            return true
        }
        return false
    }

    private fun checkMediaPermissions(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_MEDIA_IMAGES
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                return true
            } else {
                return false
            }
        } else {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
                == PackageManager.PERMISSION_GRANTED
            ) {
                return true
            } else {
                return false
            }
        }
    }


    fun showPermissionSettingsDialog() {
        val alertDialogBuilder = AlertDialog.Builder(this)
        alertDialogBuilder.setTitle("Permissions Required")
            .setMessage(
                "You have forcefully denied some of the required permissions " +
                        "for this action. Please open settings, go to permissions and allow them."
            )
            .setPositiveButton(
                "Settings"
            ) { dialog, which ->
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
            .setNegativeButton(
                "Cancel"
            ) { dialog, which -> }
            .setCancelable(false)
            .create()
            .show()
    }

//    override fun onRequestPermissionsResult(
//        requestCode: Int,
//        permissions: Array<String>,
//        grantResults: IntArray
//    ) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
//        if (permissions.isEmpty()) {
//            return
//        }
//        var allPermissionsGranted = true
//        if (grantResults.isNotEmpty()) {
//            Log.w("msg", "onRequestPermissionsResult:1 " + grantResults.size)
//            for (grantResult in grantResults) {
//                if (grantResult != PackageManager.PERMISSION_GRANTED) {
//                    Log.w("msg", "onRequestPermissionsResult:2 ")
//                    allPermissionsGranted = false
//                    break
//                }
//            }
//        }
//        if (!allPermissionsGranted) {
//            Log.w("msg", "onRequestPermissionsResult:3 ")
//
//            var somePermissionsForeverDenied = false
//            for (permission in permissions) {
//                if (!checkCameraPermissions()) {
//                    binding.tbCameraPer.isChecked = false
//                }
//                if (!checkLocationPermissions()) {
//                    binding.tbLocationPer.isChecked = false
//                }
//                if (!checkMediaPermissions()) {
//                    binding.tbMediaPer.isChecked = false
//                }
//                if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
//                    //denied
//                    Log.e("denied", permission)
//                } else {
//                    if (ActivityCompat.checkSelfPermission(
//                            this,
//                            permission
//                        ) == PackageManager.PERMISSION_GRANTED
//                    ) {
//                        //allowed
//                        Log.e("allowed", permission)
//                    } else {
//                        //set to never ask again
//                        Log.e("set to never ask again", permission)
//                        somePermissionsForeverDenied = true
//                    }
//                }
//            }
//            if (somePermissionsForeverDenied) {
//                Log.w("msg", "onRequestPermissionsResult:4 ")
//                val alertDialogBuilder = AlertDialog.Builder(this)
//                alertDialogBuilder.setTitle("Permissions Required")
//                    .setMessage(
//                        "You have forcefully denied some of the required permissions " +
//                                "for this action. Please open settings, go to permissions and allow them."
//                    )
//                    .setPositiveButton(
//                        "Settings"
//                    ) { dialog, which ->
//                        val intent = Intent(
//                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
//                            Uri.fromParts("package", packageName, null)
//                        )
//                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//                        startActivity(intent)
//                    }
//                    .setNegativeButton(
//                        "Cancel"
//                    ) { dialog, which -> }
//                    .setCancelable(false)
//                    .create()
//                    .show()
//            }
//        } else {
//            Log.w("msg", "onRequestPermissionsResult:5 ")
//            when (requestCode) {
//                PERMISSION_REQUEST_CODE_CAMERA -> {
//                    if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                        // Permission was granted, you can now access the file
//                        binding.tbCameraPer.isChecked = true
////                    Toast.makeText(this@PermissionActivity, getString(R.string.camera_access), Toast.LENGTH_SHORT).show()
//                    } else {
//                        binding.tbCameraPer.isChecked = false
//                    }
//                }
//
//                PERMISSION_REQUEST_CODE_LOCATION -> {
//                    if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
//                        binding.tbLocationPer.isChecked = true
////                    Toast.makeText(this@PermissionActivity, getString(R.string.location_access), Toast.LENGTH_SHORT).show()
//                    } else {
//                        binding.tbLocationPer.isChecked = false
//                    }
//                }
//
//                PERMISSION_REQUEST_CODE_MEDIA -> {
//                    if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
//                        binding.tbMediaPer.isChecked = true
////                    Toast.makeText(this@PermissionActivity, getString(R.string.location_access), Toast.LENGTH_SHORT).show()
//                    } else {
//                        binding.tbMediaPer.isChecked = false
//                    }
//                }
//            }
//        }
//    }

    override fun onResume() {
        super.onResume()
        if (checkCameraPermissions()) {
            binding.tbCameraPer.isChecked = true
        }
        if (checkLocationPermissions()) {
            binding.tbLocationPer.isChecked = true
        }
        if (checkMediaPermissions()) {
            binding.tbMediaPer.isChecked = true
        }
        if (checkCameraPermissions() && checkLocationPermissions() && checkMediaPermissions()) {
            binding.tvAllowAccess.alpha = 1.0f
        } else {
            binding.tvAllowAccess.alpha = 0.5f
        }
    }
}