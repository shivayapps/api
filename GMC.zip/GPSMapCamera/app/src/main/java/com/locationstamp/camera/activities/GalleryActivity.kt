package com.locationstamp.camera.activities

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.locationstamp.camera.R
import com.locationstamp.camera.adapters.ImageGridAdapter
import com.locationstamp.camera.databinding.ActivityGalleryBinding
import com.locationstamp.camera.extentions.AdCache
import com.locationstamp.camera.extentions.beGone
import com.locationstamp.camera.extentions.beVisible
import com.locationstamp.camera.helpers.isOnline
import com.locationstamp.camera.listeners.OnImageClick
import java.io.File


class GalleryActivity : BaseActivity(), OnImageClick {
    private lateinit var imageList: MutableList<String>
    private lateinit var binding: ActivityGalleryBinding
    private lateinit var imageGridAdapter: ImageGridAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityGalleryBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        //hideNavigationBar()

        allClicks()
        loadAdapterData()
//        loadBanner()
    }

    private fun loadAdapterData() {
        imageList = mutableListOf()
        loadImagesFromGallery()

        imageGridAdapter = ImageGridAdapter(imageList, this)
        binding.recyclerView.apply {
            layoutManager = GridLayoutManager(this@GalleryActivity, 2) // Adjust spanCount as needed
            adapter = imageGridAdapter
        }
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    private fun loadBanner() {
        val adId = getString(R.string.banner_gallery)
        BannerAdHelper.showBanner(
            this, binding.flNative, binding.flNative, adId,
            AdCache.galleryAdView, { isLoaded, adView, message ->
                mAdView = adView
                AdCache.galleryAdView = adView
                isAdLoaded = isLoaded
            })
    }

    private fun allClicks() {
        binding.ivBack.setOnClickListener {
            finish()
        }
    }

    private fun loadImagesFromGallery() {
        val projection = arrayOf(MediaStore.Images.Media.DATA)
//        val folderPath = "/path/to/gallery/folder" // Replace with your desired folder path
        val root = Environment.getExternalStorageDirectory().toString()
        val folderPath = File("$root/DCIM/GPSCameraImages")
        val cursor = contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projection,
            MediaStore.Images.Media.DATA + " like ? ",
            arrayOf("%$folderPath%"),
            null
        )

        cursor?.use {
            while (it.moveToNext()) {
                val imagePath = it.getString(it.getColumnIndex(MediaStore.Images.Media.DATA))
                imageList.add(imagePath)
            }
        }
        if (imageList.size != 0) {
            binding.tvNoImage.beGone()
            loadBanner()
        } else {
            binding.tvNoImage.beVisible()
        }

        // Set up ViewPager2 adapter
//        val adapter = ImagePagerAdapter(imageList.sortedDescending())
//        binding.viewPager.adapter = adapter
    }

    override fun onImgClick(position: Int) {
        val intent = Intent(this, ImageShowActivity::class.java).apply {
            putExtra("selectedImage", position)
        }
//        startActivity(intent)
        startActivityForResult(intent, 202)
    }

    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 202) {
            if (resultCode == RESULT_OK) {
                val result = data!!.getBooleanExtra("isRefreshNeed", false)
                val position = data.getIntExtra("refreshPosition", 0)
                if (result) {
                    imageList.removeAt(position)
                    imageGridAdapter.notifyDataSetChanged()
                }
            }
            if (resultCode == RESULT_CANCELED) {
                // Write your code if there's no result
            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

}