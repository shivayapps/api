package com.locationstamp.camera.activities

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.locationstamp.camera.R
import com.locationstamp.camera.databinding.ActivityMapDataBinding
import com.locationstamp.camera.extentions.baseConfig
import androidx.activity.enableEdgeToEdge
import androidx.core.app.ActivityCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapFragment
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.MarkerOptions
import com.locationstamp.camera.helpers.AppUtils
import com.locationstamp.camera.helpers.activity_tag
import com.locationstamp.camera.helpers.open_tag
import com.locationstamp.camera.services.GpsTracker
import java.util.Locale

class MapDataActivity : BaseActivity(), OnMapReadyCallback {

    private lateinit var binding: ActivityMapDataBinding
    private lateinit var googleMap: GoogleMap
    private var isAutomatic = true
    private var restrictArea: Double = 0.5 // 2 km
    private var isCircleAdded = false
    private var zoomLevel: Float = 16f // 2 km
    private lateinit var fusedLocationClient: FusedLocationProviderClient


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapDataBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        isAutomatic = baseConfig.isAutomatic
        userLatitude = baseConfig.userLatitude
        userLongitude = baseConfig.userLongitude
        userAddress = baseConfig.userAddress
        address1 = baseConfig.address1
        address2 = baseConfig.address2
        address3 = baseConfig.address3

        binding.toggleMode.isChecked = isAutomatic

        binding.etAddressLine1.setText(address1)
        binding.etAddressLine2.setText(address2)
        binding.etAddressLine3.setText(address3)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map_data) as SupportMapFragment
        mapFragment.getMapAsync(this)

        allClicks()
    }

    private fun allClicks() {
        binding.ivBack.setOnClickListener { finish() }
        binding.ivDone.setOnClickListener {
            saveData()
        }

        binding.toggleMode.setOnCheckedChangeListener { _, isChecked ->
            isAutomatic = isChecked
            if (isAutomatic) {
                getUserLocation()
                googleMap.uiSettings.setAllGesturesEnabled(false)
            } else {
                googleMap.uiSettings.setAllGesturesEnabled(true)
                Toast.makeText(this, "Manual mode: Move map to set location", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun saveData() {
        baseConfig.isAutomatic = isAutomatic
        baseConfig.userLatitude = userLatitude
        baseConfig.userLongitude = userLongitude

        address1 = binding.etAddressLine1.text.toString()
        address2 = binding.etAddressLine2.text.toString()
        address3 = binding.etAddressLine3.text.toString()
        userAddress = "$address1, $address2, $address3"

        baseConfig.userAddress = userAddress
        baseConfig.address1 = binding.etAddressLine1.text.toString()
        baseConfig.address2 = binding.etAddressLine2.text.toString()
        baseConfig.address3 = binding.etAddressLine3.text.toString()

        if (!isAutomatic) {
            CameraActivity.tempLatitude = userLatitude.toDouble()
            CameraActivity.tempLongitude = userLongitude.toDouble()
            CameraActivity.tempAddress = userAddress
        }
        onBackPressed()
    }

    private fun restrictMapToRadius(googleMap: GoogleMap, center: LatLng, radiusInMeters: Double) {
        isCircleAdded = true
        googleMap.setOnMapLoadedCallback {
            googleMap.addCircle(
                CircleOptions().center(center).radius(radiusInMeters * 1000).strokeColor(Color.RED).strokeWidth(4f).fillColor(0x2200FF00) // green with transparency
            )
        }

        // Approximate radius in degrees (not perfect for poles, but good for general use)
        val latDistance = radiusInMeters / 111.0
        val lngDistance = radiusInMeters / (111.0 * Math.cos(Math.toRadians(center.latitude)))

        val southwest = LatLng(center.latitude - latDistance, center.longitude - lngDistance)
        val northeast = LatLng(center.latitude + latDistance, center.longitude + lngDistance)

        val bounds = LatLngBounds(southwest, northeast)

        // ✅ Restrict camera movement
        googleMap.setLatLngBoundsForCameraTarget(bounds)

        // ✅ Optional: limit zoom so user can’t zoom too far out/in
        googleMap.setMinZoomPreference(14f)  // set your min zoom
        googleMap.setMaxZoomPreference(18F)

    }


    override fun onMapReady(gMap: GoogleMap) {
        googleMap = gMap
        googleMap.uiSettings.isMyLocationButtonEnabled = false
        if (isAutomatic) {
            googleMap.uiSettings.setAllGesturesEnabled(false)
        } else {
            googleMap.uiSettings.setAllGesturesEnabled(true)
        }

        getUserLocation()

        googleMap.setOnCameraIdleListener {
            zoomLevel = googleMap.cameraPosition.zoom
            Log.e("MapData", "zoom:$zoomLevel")
            //if (!isAutomatic) {
            val center = googleMap.cameraPosition.target
            Log.i("MapData", "onMapReady.isAutomatic:$isAutomatic")

            userLatitude = center.latitude
            userLongitude = center.longitude
            updateLatLong(center)
            updateAddress(center)
            //}
        }


    }


    var userAddress: String = ""
    var address1: String = ""
    var address2: String = ""
    var address3: String = ""
    var userLatitude: Double = 0.0
    var userLongitude: Double = 0.0
//    private fun getUserLocation1() {
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1001)
//            return
//        }
//
//        val gpsTracker = GpsTracker(this@MapDataActivity)
//        gpsTracker.getCurrentLocation()
//        val currentLatitude = gpsTracker.getLatitude()
//        val currentLongitude = gpsTracker.getLongitude()
//        val latLng = LatLng(currentLatitude, currentLongitude)
//        if (!isCircleAdded) restrictMapToRadius(
//            googleMap, latLng, restrictArea
//        )
//
//        if (isAutomatic) {
//            userLatitude = currentLatitude
//            userLongitude = currentLongitude
//            val latLng = LatLng(userLatitude, userLongitude)
//            googleMap.animateCamera(
//                CameraUpdateFactory.newLatLngZoom(latLng, 17f)
//            )
//            updateLatLong(latLng)
//            updateAddress(latLng)
//
//
//            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
//                if (location != null) {
////                if (isAutomatic) {
//                    userLatitude = location.latitude
//                    userLongitude = location.longitude
////                }
//                    //googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 17f))
//                    val latLng = LatLng(userLatitude, userLongitude)
//
//
////                if (isAutomatic) {
//                    Log.i("MapData", "getUserLocation.isAutomatic:$isAutomatic")
//                    Log.i("MapData", "getUserLocation.Automatic")
////                }
//                }
//            }
//        } else {
//            userLatitude = baseConfig.userLatitude
//            userLongitude = baseConfig.userLongitude
//
//            val latLng = LatLng(baseConfig.userLatitude, baseConfig.userLongitude)
//            Log.i("MapData", "getUserLocation.Manually")
//            Log.i("MapData", "getUserLocation.userLatitude:${baseConfig.userLatitude}")
//            Log.i("MapData", "getUserLocation.userLongitude:${baseConfig.userLongitude}")
//            googleMap.animateCamera(
//                CameraUpdateFactory.newLatLngZoom(latLng, 17f)
//            )
//            updateLatLong(latLng)
//            binding.etAddressLine1.setText(baseConfig.address1)
//            binding.etAddressLine2.setText(baseConfig.address2)
//            binding.etAddressLine3.setText(baseConfig.address3)
//        }
//    }

    private fun getUserLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1001)
            return
        }

        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
//                if (isAutomatic) {
                userLatitude = location.latitude
                userLongitude = location.longitude
//                }
                //googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 17f))
                val latLng = LatLng(userLatitude, userLongitude)

                if (!isCircleAdded)
                    restrictMapToRadius(
                        googleMap,
                        LatLng(location.latitude, location.longitude),
                        restrictArea
                    )

//                if (isAutomatic) {
                Log.i("MapData", "getUserLocation.isAutomatic:$isAutomatic")
                Log.i("MapData", "getUserLocation.Automatic")
                if (isAutomatic) {
                    googleMap.animateCamera(
                        CameraUpdateFactory.newLatLngZoom(latLng, 17f)
                    )
                    updateLatLong(latLng)
                    updateAddress(latLng)
                } else {
                    val latLng = LatLng(baseConfig.userLatitude, baseConfig.userLongitude)
                    Log.i("MapData", "getUserLocation.Manually")
                    Log.i("MapData", "getUserLocation.userLatitude:${baseConfig.userLatitude}")
                    Log.i("MapData", "getUserLocation.userLongitude:${baseConfig.userLongitude}")
                    googleMap.animateCamera(
                        CameraUpdateFactory.newLatLngZoom(latLng, 17f)
                    )
                    updateLatLong(latLng)
                    binding.etAddressLine1.setText(baseConfig.address1)
                    binding.etAddressLine2.setText(baseConfig.address2)
                    binding.etAddressLine3.setText(baseConfig.address3)
                }
//                }
            }
        }

//        if (isAutomatic) {
//        } else {
//        }
    }


    private fun updateLatLong(latLng: LatLng) {
//        binding.etLat.setText(latLng.latitude.toString())
        binding.etLat.setText(String.format("%.5f", latLng.latitude))
//        binding.etLong.setText(latLng.longitude.toString())
        binding.etLong.setText(String.format("%.5f", latLng.longitude))
    }

    private fun updateAddress(latLng: LatLng) {
        try {
            val geocoder = Geocoder(this, Locale.getDefault())
            val addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)
//            Log.i("MapData", "addresses:$addresses")
            if (!addresses.isNullOrEmpty()) {
                val addr = addresses[0]

                val addressLine = addr.getAddressLine(0) ?: ""
                val subLocality = addr.subLocality ?: ""
                val locality = addr.locality ?: ""
                val adminArea = addr.adminArea ?: ""
                val postalCode = addr.postalCode ?: ""
                val featureName = addr.featureName ?: ""
                val countryName = addr.countryName ?: ""
//                Log.i("MapData", "addresses.getAddressLine:${addressLine}")
//                Log.i("MapData", "addresses.subLocality:${subLocality}")
//                Log.i("MapData", "addresses.locality:${locality}")
//                Log.i("MapData", "addresses.adminArea:${adminArea}")
//                Log.i("MapData", "addresses.postalCode:${postalCode}")
//                Log.i("MapData", "addresses.featureName:${featureName}")
//                Log.i("MapData", "addresses.countryName:${countryName}")

                address1 = addressLine
                address2 = ("$subLocality, $locality").trim().trim(',').trim()
                address3 = "$adminArea, $countryName, $postalCode"
                address1 = address1.replace(subLocality, "")
                address1 = address1.replace(locality, "")
                address1 = address1.replace(adminArea, "")
                address1 = address1.replace(postalCode, "")
                address1 = address1.replace(countryName, "")
                address1 = address1.replace("  ", "")

                val parts = address1.split(",").map { it.trim() }.filter { it.isNotEmpty() }

                address1 = parts.joinToString(", ")

//                binding.etAddressLine1.setText(addr.thoroughfare ?: "")
//                binding.etAddressLine2.setText(addr.locality ?: "")
//                binding.etAddressLine3.setText(addr.adminArea ?: "")
                binding.etAddressLine1.setText(address1)
                binding.etAddressLine2.setText(address2)
                binding.etAddressLine3.setText(address3)

                userAddress = "$address1, $address2, $address3"

//                Log.i("MapData", "addresses.address1:${address1}")
//                Log.i("MapData", "addresses.address2:${address2}")
//                Log.i("MapData", "addresses.address3:${address3}")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}


//class MapDataActivity : BaseActivity(), OnMapReadyCallback {
//    private lateinit var binding: ActivityMapDataBinding
//    private lateinit var googleMap: GoogleMap
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        binding = ActivityMapDataBinding.inflate(layoutInflater)
//        enableEdgeToEdge()
//        setContentView(binding.root)
//        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
//            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
//            insets
//        }
//
//        AppUtils.logAdapterMessages(
//            this@MapDataActivity,
//            activity_tag,
//            open_tag,
//            MapDataActivity::class.java.simpleName.toString()
//        )
//        hideNavigationBar()
//        val mapFragment = fragmentManager.findFragmentById(R.id.map_data) as MapFragment
//        mapFragment.getMapAsync(this)
//
//        initData()
//        allClicks()
//    }
//
//    private fun initData() {
//        binding.tvDateData.text = baseConfig.getCurrentDateFormatted()
//        binding.tvLatData.text = "Lat: " + CameraActivity.tempLatitude
//        binding.tvLongData.text = "Lon: " + CameraActivity.tempLongitude
//        binding.tvAddressData.text = CameraActivity.tempAddress
//        binding.tvNoteData.text = "Note: " + baseConfig.lastNote
//        binding.tvTimeData.text = baseConfig.formatDateTimeWithColon()
//    }
//
//    private fun allClicks() {
//        binding.ivBack.setOnClickListener {
//            finish()
//        }
//    }
//
//    override fun onMapReady(gMap: GoogleMap) {
//        googleMap = gMap
//
//        googleMap.mapType = baseConfig.stampMapType
//        try {
//            googleMap.isMyLocationEnabled = false
//        } catch (se: SecurityException) {
//            // Handle the security exception here
//        }
//
//        // Edit the following settings as needed
//        googleMap.isTrafficEnabled = true
//        googleMap.isIndoorEnabled = true
//        googleMap.isBuildingsEnabled = true
//        googleMap.uiSettings.setAllGesturesEnabled(false)
//
//        val placeLocation = LatLng(CameraActivity.tempLatitude, CameraActivity.tempLongitude) // Replace with your actual coordinates
////        val placeMarker = googleMap.addMarker(
////            MarkerOptions().position(placeLocation)
////                .title("YOU ARE HERE")
////        )
//        googleMap.moveCamera(CameraUpdateFactory.newLatLng(placeLocation))
//        googleMap.animateCamera(CameraUpdateFactory.zoomTo(17.0f), 1000, null)
////        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(baseConfig.lastLatitude.toDouble(), baseConfig.lastLatitude.toDouble()), 15.0f))
//
//        googleMap.setOnCameraMoveListener {
//
//        }
//    }
//}