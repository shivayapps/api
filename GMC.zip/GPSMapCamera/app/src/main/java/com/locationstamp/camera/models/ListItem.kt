package com.locationstamp.camera.models

data class ListItem(/*val imageResId: Int,*/ val text: String)
