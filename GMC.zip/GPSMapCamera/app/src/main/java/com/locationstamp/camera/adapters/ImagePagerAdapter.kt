package com.locationstamp.camera.adapters

import android.app.Activity
import android.app.Dialog
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.webkit.MimeTypeMap
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.locationstamp.camera.R
import com.locationstamp.camera.activities.ImageShowActivity
import com.locationstamp.camera.databinding.CustomDeleteDialogBinding
import java.io.File


class ImagePagerAdapter(private val context: Context, private val activity: Activity, private val imageList: List<String>) :
    RecyclerView.Adapter<ImagePagerAdapter.ImageViewHolder>() {
    private lateinit var bindingDialog: CustomDeleteDialogBinding

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.item_image, parent, false)
        val inflater = LayoutInflater.from(parent.context)
        bindingDialog = CustomDeleteDialogBinding.inflate(inflater, parent, false)

        return ImageViewHolder(view)
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        val imagePath = imageList[position]
        Glide.with(holder.itemView.context)
            .load(imagePath)
            .into(holder.imageView)

        holder.ivDelete.setOnClickListener {
            deleteDialog(context, imagePath, position)
        }
        holder.ivShare.setOnClickListener {
            shareFile(context, imagePath)
        }
    }

    override fun getItemCount(): Int {
        return imageList.size
    }

    inner class ImageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.imageView)
        val ivDelete: ImageView = itemView.findViewById(R.id.ivDelete)
        val ivShare: ImageView = itemView.findViewById(R.id.ivShare)
    }

    private fun deleteDialog(context: Context, imagePath: String, position: Int) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val window = dialog.window
        window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.setCancelable(true)
//        val dialogBinding = CustomDeleteDialogBinding.inflate(layoutInflater)
        dialog.setContentView(bindingDialog.root)
        bindingDialog.tvActionCancel.setOnClickListener {
            dialog.dismiss()
        }
        bindingDialog.tvActionOk.setOnClickListener {
            deleteFile(context, imagePath, position)
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun deleteFile(context: Context, filePath: String, position: Int) {
        val contentResolver: ContentResolver = context.contentResolver
        contentResolver.delete(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            MediaStore.Images.ImageColumns.DATA + "=?", arrayOf<String>(filePath)
        )
        val returnIntent = Intent()
        returnIntent.putExtra("isRefreshNeed", true)
        returnIntent.putExtra("refreshPosition", position)
        activity.setResult(AppCompatActivity.RESULT_OK, returnIntent)
//        activity.finish()
        ImageShowActivity.imageShowActivity?.finish()
    }

    private fun shareFile(context: Context, filePath: String) {
        val file = File(filePath)
        val shareUri = FileProvider.getUriForFile(
            context,
            context.packageName + ".provider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = getMimeTypeFromFilePath(file.path)
        intent.putExtra(Intent.EXTRA_STREAM, shareUri)
        try {
//            MyApplication().disabledOpenAds()
            context.startActivity(
                Intent.createChooser(
                    intent,
                    context.getString(R.string.share_with)
                )
            )
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(
                context,
                context.getString(R.string.no_supported_image),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun getMimeTypeFromFilePath(filePath: String): String? {
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(getFilenameExtension(filePath))
    }

    private fun getFilenameExtension(path: String): String {
        return path.substring(path.lastIndexOf(".") + 1)
    }

}