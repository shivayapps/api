package com.locationstamp.camera.cameraview.video.encoding;

/**
 * Indicates that some action is being executed on the encoder thread.
 */
public @interface EncoderThread {}
