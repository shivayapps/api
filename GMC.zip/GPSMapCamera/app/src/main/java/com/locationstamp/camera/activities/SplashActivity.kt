package com.locationstamp.camera.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.locationstamp.camera.MyApplication
import com.locationstamp.camera.R
import com.locationstamp.camera.databinding.ActivitySplashBinding
import com.locationstamp.camera.extentions.baseConfig
import com.locationstamp.camera.helpers.AppUtils
import com.locationstamp.camera.helpers.EXTRA_IS_OPEN_FROM_SPLASH
import com.locationstamp.camera.helpers.activity_tag
import com.locationstamp.camera.helpers.open_tag

class SplashActivity : BaseActivity() {
    private lateinit var binding: ActivitySplashBinding
    private var DURATION: Long = 500

    override fun onCreate(savedInstanceState: Bundle?) {
//        AdconfigApplication.isNeedSplashCalled = true
        /*if (MyApplication.isAppIsRunning) {
//            AdconfigApplication.adConfigFinishAffinity()
        } else {
            MyApplication.isAppIsRunning = true
        }*/
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
                enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        AppUtils.logAdapterMessages(
            this@SplashActivity,
            activity_tag,
            open_tag,
            SplashActivity::class.java.simpleName.toString()
        )

        //hideNavigationBar()
        nextIntentMethod()
//        nativeLoad()
        loadIntAds()
    }

//    fun nativeLoad() {
//        Log.e("msg", "NativeTag nativeLoad ${MyApplication.nativeAdsFiles.value == null}")
//        PreLoadNativeAds(this).loadNative(
//            onNativeLoadListener = {
//                MyApplication.nativeAdsFiles.postValue(it)
//                Log.e("msg", "NativeTag onNativeLoadListener ")
//            })
//    }

    private fun loadIntAds() {
        val adId = getString(R.string.inter_all)
        AdmobIntersAdImpl().load(this, adId)
    }

    private fun nextIntentMethod() {
        Handler(Looper.getMainLooper()).postDelayed({
//            Log.w("msg", "introScreenShow: " + baseConfig.introScreenShow)
            if(baseConfig.languageScreenShow == 0) {
//                baseConfig.languageScreenShow = 1
                startActivity(Intent(this, LanguageActivity::class.java).putExtra(EXTRA_IS_OPEN_FROM_SPLASH, true))
            } else if(baseConfig.introScreenShow == 0) {
//                baseConfig.introScreenShow = 1
                startActivity(Intent(this, IntroActivity::class.java))
            } else if(!baseConfig.checkAllPermissions(this@SplashActivity)) {
                startActivity(Intent(this, PermissionActivity::class.java))
            } else {
                startActivity(Intent(this, CameraActivity::class.java))
            }
            finish()
        }, DURATION)
    }

    /*private fun hideNavigationBar() {
        // Check if the device is running Android 11 or higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Get the WindowInsetsController
            val windowInsetsController = window.insetsController

            // Hide the navigation bar
            windowInsetsController?.hide(WindowInsets.Type.navigationBars())

            // To make the navigation bar appear temporarily when swiping from the edge of the screen
            // you can use the following line:
            windowInsetsController?.systemBarsBehavior =
                WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        } else {
            // For devices running below Android 11, you can still use the deprecated flag
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        }
    }*/

}