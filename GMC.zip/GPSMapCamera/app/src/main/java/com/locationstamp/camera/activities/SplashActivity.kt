package com.locationstamp.camera.activities

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd
import com.locationstamp.camera.R
import com.locationstamp.camera.databinding.ActivitySplashBinding
import com.locationstamp.camera.extentions.baseConfig
import com.locationstamp.camera.helper.LogUtils
import com.locationstamp.camera.helper.EXTRA_IS_OPEN_FROM_SPLASH
import com.locationstamp.camera.helper.activity_tag
import com.locationstamp.camera.helper.open_tag

class SplashActivity : BaseActivity() {

    private lateinit var countDownTimer: CountDownTimer
    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val splashScreenDuration = 2000L

        LogUtils.logAdapterMessages(
            this@SplashActivity,
            activity_tag,
            open_tag,
            SplashActivity::class.java.simpleName.toString()
        )
        var splashCounter = baseConfig.splashCounter
        splashCounter++
        baseConfig.splashCounter = splashCounter
        initAdSize()
//        loadIntAds()

        Log.e("SplashTag", "appOpenCounter:${splashCounter}")
        val appOpenId = getString(R.string.open_splash)
        Log.e("SplashTag", "AdmobAppOpenId:${appOpenId}")
        if (splashCounter % 3 == 0) {
            Log.e("SplashTag", "appOpenCounter%7-true")
            createTimerSec()
            OpenAdHelper.loadOpenAdId(this, {
                countDownTimer.cancel()
                isShowOpenAd { isLoaded ->//onAdClosed
                    if (!isLoaded) {
                        splashCounter--
                        baseConfig.splashCounter = splashCounter
                    } else {
                        baseConfig.isNeedInterAd = false
                    }
                    gotoMainScreen()
                }
            }, appOpenId)
        } else {
            Log.e("SplashTag", "appOpenCounter%2-else")
            Handler(Looper.getMainLooper()).postDelayed({
                gotoMainScreen()
            }, splashScreenDuration)
        }

        //hideNavigationBar()
//        nextIntentMethod()
//        nativeLoad()
    }

    private fun gotoMainScreen() {
        if (baseConfig.languageScreenShow == 0) {
//                baseConfig.languageScreenShow = 1
            startActivity(Intent(this, LanguageSelectionActivity::class.java).putExtra(EXTRA_IS_OPEN_FROM_SPLASH, true))
        } else if (baseConfig.introScreenShow == 0) {
//                baseConfig.introScreenShow = 1
            startActivity(Intent(this, OnboardingActivity::class.java))
        } else if (!baseConfig.checkAllPermissions(this@SplashActivity)) {
            startActivity(Intent(this, AppPermissionActivity::class.java))
        } else {
            startActivity(Intent(this, CameraActivity::class.java))
        }
        finish()
    }

    private fun createTimerSec() {
        val totalTimeMillis = 6
        countDownTimer = object : CountDownTimer(totalTimeMillis * 1000L, 1000) {
            override fun onTick(l: Long) {

            }

            override fun onFinish() {
                gotoMainScreen()
            }
        }
        countDownTimer.start()
    }

    private fun initAdSize() {
        val display = windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val widthPixels = outMetrics.widthPixels.toFloat()

        val density = outMetrics.density
        val adWidth = (widthPixels / density).toInt()

        AdsParameters(this@SplashActivity).adWidth=adWidth
    }

//    private fun loadIntAds() {
//        val adId = getString(R.string.inter_all)
//        AdmobIntersAdImpl().load(this, adId)
//    }

//    private fun nextIntentMethod() {
//        Handler(Looper.getMainLooper()).postDelayed({
////            Log.w("msg", "introScreenShow: " + baseConfig.introScreenShow)
//            if (baseConfig.languageScreenShow == 0) {
////                baseConfig.languageScreenShow = 1
//                startActivity(Intent(this, LanguageActivity::class.java).putExtra(EXTRA_IS_OPEN_FROM_SPLASH, true))
//            } else if (baseConfig.introScreenShow == 0) {
////                baseConfig.introScreenShow = 1
//                startActivity(Intent(this, IntroActivity::class.java))
//            } else if (!baseConfig.checkAllPermissions(this@SplashActivity)) {
//                startActivity(Intent(this, PermissionActivity::class.java))
//            } else {
//                startActivity(Intent(this, CameraActivity::class.java))
//            }
//            finish()
//        }, DURATION)
//    }


}