package com.locationstamp.camera.activities

import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.locationstamp.camera.R
import com.locationstamp.camera.adapters.ImageGalleryAdapter
import com.locationstamp.camera.databinding.ActivityMediaGalleryBinding
import com.locationstamp.camera.extentions.AdCache
import com.locationstamp.camera.extentions.baseConfig
import com.locationstamp.camera.extentions.beGone
import com.locationstamp.camera.extentions.beVisible
import java.io.File


class MediaGalleryActivity : BaseActivity() {
    companion object{
        lateinit var imageList: MutableList<String>
    }
    private lateinit var binding: ActivityMediaGalleryBinding
    private lateinit var imageGalleryAdapter: ImageGalleryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMediaGalleryBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        //hideNavigationBar()

        allClicks()
        loadAdapterData()
//        loadBanner()
    }

    private fun loadAdapterData() {
        imageList = mutableListOf()
        loadImagesFromGallery()

        imageGalleryAdapter = ImageGalleryAdapter(imageList, { position->
            val intent = Intent(this, ImagePreviewActivity::class.java).apply {
                putExtra("selectedImage", position)
            }
            startActivityForResult(intent, 202)
        })
        binding.recyclerView.apply {
            layoutManager = GridLayoutManager(this@MediaGalleryActivity, 2) // Adjust spanCount as needed
            adapter = imageGalleryAdapter
        }
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    private fun loadBanner() {
        val adId = getString(R.string.banner_gallery)
        BannerAdHelper.showBanner(
            this, binding.flNative, binding.flNative, adId,
            AdCache.galleryAdView, { isLoaded, adView, message ->
                mAdView = adView
                AdCache.galleryAdView = adView
                isAdLoaded = isLoaded
            })
    }

//    override fun onDestroy() {
//        super.onDestroy()
//        mAdView?.destroy()
//    }

    private fun loadInterAd() {
        if (baseConfig.isNeedInterAd) {
            val interAdId = getString(R.string.inter_all)
            AdmobIntersAdImpl().load(this, interAdId)
        } else {
            checkReInter {
                if (it) {
                    val interAdId = getString(R.string.inter_all)
                    AdmobIntersAdImpl().load(this, interAdId)
                    baseConfig.isNeedInterAd = true
                }
            }
        }
    }

    private fun allClicks() {
        binding.ivBack.setOnClickListener {
            finish()
        }
    }

    private fun loadImagesFromGallery() {
        val folder = File(getExternalFilesDir(null), "MapStamp")
        if (!folder.exists()) {
            binding.tvNoImage.beVisible()
            return
        }
        val files = folder.listFiles { file -> file.extension.lowercase() == "jpeg" || file.extension.lowercase() == "jpg" }
        imageList.clear()
        if (files != null && files.isNotEmpty()) {
            imageList.addAll(files.map { it.absolutePath }.sortedDescending())
            binding.tvNoImage.beGone()
            loadBanner()
        } else {
            binding.tvNoImage.beVisible()
        }
        loadInterAd()
    }

    private fun loadImagesFromGallery0() {
        val projection = arrayOf(MediaStore.Images.Media.DATA)
//        val folderPath = "/path/to/gallery/folder" // Replace with your desired folder path
//        val root = Environment.getExternalStorageDirectory().toString()
//        val folderPath = File("$root/MapStamp")
        val folderPath = File(getExternalFilesDir(null), "MapStamp")
        val cursor = contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projection,
            MediaStore.Images.Media.DATA + " like ? ",
            arrayOf("%$folderPath%"),
            null
        )

        cursor?.use {
            while (it.moveToNext()) {
                val imagePath = it.getString(it.getColumnIndex(MediaStore.Images.Media.DATA))
                imageList.add(imagePath)
            }
        }
        if (imageList.size != 0) {
            binding.tvNoImage.beGone()
            loadBanner()
        } else {
            binding.tvNoImage.beVisible()
        }
        loadInterAd()

        // Set up ViewPager2 adapter
//        val adapter = ImagePagerAdapter(imageList.sortedDescending())
//        binding.viewPager.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 202) {
            if (resultCode == RESULT_OK) {
                val result = data!!.getBooleanExtra("isRefreshNeed", false)
                val position = data.getIntExtra("refreshPosition", 0)
                if (result) {
                    imageList.removeAt(position)
                    imageGalleryAdapter.notifyDataSetChanged()
                }
            }
            if (resultCode == RESULT_CANCELED) {
                // Write your code if there's no result
            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

}