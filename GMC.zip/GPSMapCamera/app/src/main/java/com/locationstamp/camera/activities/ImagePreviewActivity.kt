package com.locationstamp.camera.activities

import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.locationstamp.camera.R
import com.locationstamp.camera.adapters.ImageSliderAdapter
import com.locationstamp.camera.databinding.ActivityImagePreviewBinding
import com.locationstamp.camera.extentions.AdCache
import com.locationstamp.camera.extentions.baseConfig
import com.locationstamp.camera.extentions.beGone
import com.locationstamp.camera.extentions.beVisible
import java.io.File

class ImagePreviewActivity : BaseActivity() {

//    private lateinit var imageList: MutableList<String>
    private lateinit var binding: ActivityImagePreviewBinding
    private lateinit var pagerAdapter: ImageSliderAdapter
    private var position = 0

    companion object {
        var imageShowActivity: ImagePreviewActivity? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImagePreviewBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        //hideNavigationBar()
        imageShowActivity = this
        position = intent.getIntExtra("selectedImage", 0)
        //MediaGalleryActivity.imageList = mutableListOf()

        allClicks()
        loadInterAd()
        loadBanner()
        pagerAdapter = ImageSliderAdapter(this@ImagePreviewActivity, this@ImagePreviewActivity, getImageList()) /*{ position ->
            // Open ViewPager2 with clicked image
            binding.viewPager.setCurrentItem(position, true)
        }*/

        binding.viewPager.adapter = pagerAdapter
        binding.viewPager.setCurrentItem(position, false)
    }

    private fun allClicks() {
        binding.ivBack.setOnClickListener {
            finish()
        }
    }
    private fun loadInterAd() {
        if (baseConfig.isNeedInterAd) {
            val interAdId = getString(R.string.inter_all)
            AdmobIntersAdImpl().load(this, interAdId)
        } else {
            checkReInter {
                if (it) {
                    val interAdId = getString(R.string.inter_all)
                    AdmobIntersAdImpl().load(this, interAdId)
                    baseConfig.isNeedInterAd = true
                }
            }
        }
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    private fun loadBanner() {
        val adId = getString(R.string.banner_full_screen)
        BannerAdHelper.showBanner(
            this, binding.flNative, binding.flNative, adId,
            AdCache.fullScreeAdView, { isLoaded, adView, message ->
                mAdView = adView
                AdCache.fullScreeAdView = adView
                isAdLoaded = isLoaded
            })
    }

    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
//    override fun onDestroy() {
//        super.onDestroy()
//        mAdView?.destroy()
//    }


    private fun getImageList() :List<String> {
        return MediaGalleryActivity.imageList
//        val folder = File(getExternalFilesDir(null), "MapStamp")
////        if (!folder.exists()) {
////            binding.tvNoImage.beVisible()
////            return
////        }
//        val files = folder.listFiles { file -> file.extension.lowercase() == "jpeg" || file.extension.lowercase() == "jpg" }
//        imageList.clear()
//        if (files != null && files.isNotEmpty()) {
//            imageList.addAll(files.map { it.absolutePath }.sortedDescending())
////            binding.tvNoImage.beGone()
//        } else {
////            binding.tvNoImage.beVisible()
//        }
    }

//    private fun getImageList0(): List<String> {
//        val projection = arrayOf(MediaStore.Images.Media.DATA)
////        val root = Environment.getExternalStorageDirectory().toString()
//        val folderPath = File(getExternalFilesDir(null), "MapStamp")
////        val folderPath = File("$root/MapStamp")
//        val cursor = contentResolver.query(
//            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
//            projection,
//            MediaStore.Images.Media.DATA + " like ? ",
//            arrayOf("%$folderPath%"),
//            null
//        )
//
//        cursor?.use {
//            while (it.moveToNext()) {
//                val imagePath = it.getString(it.getColumnIndex(MediaStore.Images.Media.DATA))
//                imageList.add(imagePath)
//            }
//        }
//
//        return imageList
//    }


}