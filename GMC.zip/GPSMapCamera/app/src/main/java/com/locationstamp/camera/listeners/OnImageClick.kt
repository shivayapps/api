package com.locationstamp.camera.listeners

interface OnImageClick {
    fun onImgClick(position: Int)
}