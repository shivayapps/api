package com.locationstamp.camera.activities

import android.app.Dialog
import android.graphics.Typeface
import android.os.Bundle
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import com.locationstamp.camera.R
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.locationstamp.camera.databinding.CustomMaptypeDialogBinding
import com.locationstamp.camera.databinding.CustomNoteDialogBinding
import com.locationstamp.camera.databinding.CustomRadiogroupDialogBinding
import com.locationstamp.camera.extentions.baseConfig
import com.locationstamp.camera.extentions.beVisibleIf
import com.locationstamp.camera.helper.ACCURACY_FORMAT_FOOT
import com.locationstamp.camera.helper.ACCURACY_FORMAT_METER
import com.locationstamp.camera.helper.ALTITUDE_FORMAT_FOOT
import com.locationstamp.camera.helper.ALTITUDE_FORMAT_METER
import com.locationstamp.camera.helper.DATE_FORMAT_EIGHT
import com.locationstamp.camera.helper.DATE_FORMAT_EIGHT_CONST
import com.locationstamp.camera.helper.DATE_FORMAT_FIVE
import com.locationstamp.camera.helper.DATE_FORMAT_FIVE_CONST
import com.locationstamp.camera.helper.DATE_FORMAT_FOUR
import com.locationstamp.camera.helper.DATE_FORMAT_FOUR_CONST
import com.locationstamp.camera.helper.DATE_FORMAT_NINE
import com.locationstamp.camera.helper.DATE_FORMAT_NINE_CONST
import com.locationstamp.camera.helper.DATE_FORMAT_ONE
import com.locationstamp.camera.helper.DATE_FORMAT_ONE_CONST
import com.locationstamp.camera.helper.DATE_FORMAT_SEVEN
import com.locationstamp.camera.helper.DATE_FORMAT_SEVEN_CONST
import com.locationstamp.camera.helper.DATE_FORMAT_SIX
import com.locationstamp.camera.helper.DATE_FORMAT_SIX_CONST
import com.locationstamp.camera.helper.DATE_FORMAT_TEN
import com.locationstamp.camera.helper.DATE_FORMAT_TEN_CONST
import com.locationstamp.camera.helper.DATE_FORMAT_THREE
import com.locationstamp.camera.helper.DATE_FORMAT_THREE_CONST
import com.locationstamp.camera.helper.DATE_FORMAT_TWO
import com.locationstamp.camera.helper.DATE_FORMAT_TWO_CONST
//import com.locationstamp.camera.helpers.FONT_HIND
//import com.locationstamp.camera.helpers.FONT_INTER
//import com.locationstamp.camera.helpers.FONT_POPPINS
//import com.locationstamp.camera.helpers.FONT_ROBOTO
//import com.locationstamp.camera.helpers.FONT_SF
import com.locationstamp.camera.helper.FONT_SOURCECODEPRO
import com.locationstamp.camera.helper.FONT_ROBOTOCONDENSED
import com.locationstamp.camera.helper.FONT_OPENSANS
import com.locationstamp.camera.helper.FONT_NOTOSANSDISPLAY
import com.locationstamp.camera.helper.FONT_IBMPLEXSANS
import com.locationstamp.camera.helper.FONT_INTER
import com.locationstamp.camera.helper.FONT_POPPINS
import com.locationstamp.camera.helper.FONT_ROBOTO
import com.locationstamp.camera.helper.FONT_SF_UI
import com.locationstamp.camera.helper.FONT_SIZE_EXTRA_SMALL
import com.locationstamp.camera.helper.FONT_SIZE_LARGE
import com.locationstamp.camera.helper.FONT_SIZE_MEDIUM
import com.locationstamp.camera.helper.FONT_SIZE_SMALL
import com.locationstamp.camera.helper.LATLONG_DECIMAL
import com.locationstamp.camera.helper.LATLONG_DECIMAL_MINUTES
import com.locationstamp.camera.helper.LATLONG_DECIMAL_MINUTES_SECONDS
import com.locationstamp.camera.helper.LATLONG_DEGREE
import com.locationstamp.camera.helper.LATLONG_DEGREE_MICRO
import com.locationstamp.camera.helper.LATLONG_DEGREE_MINUTES_SECONDS
import com.locationstamp.camera.helper.MAP_HYBRID
import com.locationstamp.camera.helper.MAP_NORMAL
import com.locationstamp.camera.helper.MAP_SATELLITE
import com.locationstamp.camera.helper.MAP_TERRAIN
import com.locationstamp.camera.helper.PRESSURE_FORMAT_HPA
import com.locationstamp.camera.helper.PRESSURE_FORMAT_INHG
import com.locationstamp.camera.helper.PRESSURE_FORMAT_MMHG
//import com.locationstamp.camera.helpers.STAMP_BOTTOM
//import com.locationstamp.camera.helpers.STAMP_TOP
import com.locationstamp.camera.helper.TEMPLATE_POSITION
import com.locationstamp.camera.helper.TIMEZONE_FORMAT_FIVE
import com.locationstamp.camera.helper.TIMEZONE_FORMAT_FOUR
import com.locationstamp.camera.helper.TIMEZONE_FORMAT_ONE
import com.locationstamp.camera.helper.TIMEZONE_FORMAT_SIX
import com.locationstamp.camera.helper.TIMEZONE_FORMAT_THREE
import com.locationstamp.camera.helper.TIMEZONE_FORMAT_TWO
import com.locationstamp.camera.helper.WEATHER_FORMAT_CELSIUS
import com.locationstamp.camera.helper.WEATHER_FORMAT_FAHRENHEIT
import com.locationstamp.camera.helper.WIND_FORMAT_KMH
import com.locationstamp.camera.helper.WIND_FORMAT_KT
import com.locationstamp.camera.helper.WIND_FORMAT_MPH
import com.locationstamp.camera.helper.WIND_FORMAT_MS
import com.locationstamp.camera.models.RadioItem
import com.github.dhaval2404.colorpicker.MaterialColorPickerDialog
import com.locationstamp.camera.databinding.ActivityTemplateEditorBinding
import com.locationstamp.camera.helper.LogUtils
import com.locationstamp.camera.helper.activity_tag
import com.locationstamp.camera.helper.open_tag
import java.util.Calendar
import java.util.Locale


class TemplateEditorActivity : BaseActivity() {
    private lateinit var typefaceCustom: Typeface
    private var fontSize: Float = 12.0f
    private var newLayoutView: View? = null
    private var templatePosition = 0
    private lateinit var binding: ActivityTemplateEditorBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTemplateEditorBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        LogUtils.logAdapterMessages(
            this@TemplateEditorActivity,
            activity_tag,
            open_tag,
            TemplateEditorActivity::class.java.simpleName.toString()
        )
        //hideNavigationBar()
        getExtras()
        initChanges()
        allClicks()
        allToggleClick()
        loadInterAd()
//        templateChange()
    }

    private fun loadInterAd() {
        if (baseConfig.isNeedInterAd) {
            val interAdId = getString(R.string.inter_all)
            AdmobIntersAdImpl().load(this, interAdId)
        } else {
            checkReInter {
                if (it) {
                    val interAdId = getString(R.string.inter_all)
                    AdmobIntersAdImpl().load(this, interAdId)
                    baseConfig.isNeedInterAd = true
                }
            }
        }
    }
    override fun onBackPressed() {
        if (baseConfig.isNeedInterAd) {
            AdsConfig.showInterstitialAd(this@TemplateEditorActivity) {
                if (it) baseConfig.isNeedInterAd = false
                finish()
            }
        } else {
            super.onBackPressed()
        }
    }
    private fun getExtras() {
        fontSize = baseConfig.getTextSize(this@TemplateEditorActivity)
        typefaceCustom = when (baseConfig.stampFontStyle) {
            0 -> Typeface.createFromAsset(assets, "font/sourcecodepro_regular.ttf")
            1 -> Typeface.createFromAsset(assets, "font/robotocondensed.ttf")
            2 -> Typeface.createFromAsset(assets, "font/opensans.ttf")
            3 -> Typeface.createFromAsset(assets, "font/notosansdisplay.ttf")
            4 -> Typeface.createFromAsset(assets, "font/ibmplexsans.ttf")
            5 -> Typeface.createFromAsset(assets, "font/inter_medium.ttf")
            6 -> Typeface.createFromAsset(assets, "font/poppins_medium.ttf")
            7 -> Typeface.createFromAsset(assets, "font/roboto_medium.ttf")
            8 -> Typeface.createFromAsset(assets, "font/sf_ui_medium.otf")
            else -> Typeface.createFromAsset(assets, "font/sourcecodepro_regular.ttf")
        }


        templatePosition = intent.getIntExtra(TEMPLATE_POSITION, 0)

        val container = binding.framePreview
        val newLayout = if (templatePosition == 0) {
            R.layout.template_layout_1
        } else if (templatePosition == 1) {
            R.layout.template_layout_2
        } else if (templatePosition == 2) {
            R.layout.template_layout_3
        } else if (templatePosition == 3) {
            R.layout.template_layout_4
        } /*else if (templatePosition == 4) {
            R.layout.template_layout_5
        } */else {
            R.layout.template_layout_1
        }

        val inflater = LayoutInflater.from(this)
        container.removeAllViews() // Remove the current layout
        newLayoutView = inflater.inflate(newLayout, container, true)
        templateChange(newLayoutView!!)
    }

    private fun templateChange(newLayoutView: View) {
        newLayoutView.apply {
            findViewById<CardView>(R.id.cv_map).beVisibleIf(baseConfig.showMap)
            findViewById<ImageView>(R.id.iv_map_template).setImageDrawable(baseConfig.getMapTypeImage(this@TemplateEditorActivity))
            findViewById<TextView>(R.id.tv_address_template).apply {
                beVisibleIf(baseConfig.showAddress)
                text = CameraActivity.tempAddress
                setTextColor(baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_lat_long_template).apply {
                beVisibleIf(baseConfig.showLatLong)
                text = baseConfig.formatLatLong(
                    CameraActivity.tempLatitude,
                    CameraActivity.tempLongitude
                )
                setTextColor(baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_plus_code_template).apply {
                beVisibleIf(baseConfig.showPlusCode)
                text = "Plus code:" + baseConfig.stampPlusCode
                setTextColor(baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_note_template).apply {
                beVisibleIf(baseConfig.showNote)
                text = "Note: " + baseConfig.lastNote
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_time_template).apply {
                beVisibleIf(baseConfig.showDateTime)
                text = baseConfig.dateFormat
                setTextColor(baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_time_zone_template).apply {
                beVisibleIf(baseConfig.showTimeZone)
                text = baseConfig.getTimezoneText()
                setTextColor(baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
//            findViewById<ImageView>(R.id.iv_logo_template).apply {
//                beVisibleIf(baseConfig.showLogo)
//            }
            findViewById<TextView>(R.id.tv_altitude_template).apply {
                beVisibleIf(baseConfig.showAltitude)
                text = "Altitude:" + baseConfig.getAltitudeText(this@TemplateEditorActivity)
                setTextColor(baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_accuracy_template).apply {
                beVisibleIf(baseConfig.showAccuracy)
                text = "Accuracy:" + baseConfig.getAccuracyText(this@TemplateEditorActivity)
                setTextColor(baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_weather_template).apply {
                beVisibleIf(baseConfig.showWeather)
                text = "" + baseConfig.getWeatherText(this@TemplateEditorActivity)
                setTextColor(baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_wind_template).apply {
                beVisibleIf(baseConfig.showWind)
                text = "" + baseConfig.getWindText(this@TemplateEditorActivity)
                setTextColor(baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_pressure_template).apply {
                beVisibleIf(baseConfig.showPressure)
                text = "" + baseConfig.getPressureText(this@TemplateEditorActivity)
                setTextColor(baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_humidity_template).apply {
                beVisibleIf(baseConfig.showHumidity)
                text = "" + CameraActivity.tempHumidity
                setTextColor(baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
        }
    }

    private fun templateTextSizeChange() {
        fontSize = baseConfig.getTextSize(this@TemplateEditorActivity)
        newLayoutView.apply {
            findViewById<TextView>(R.id.tv_address_template).setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            findViewById<TextView>(R.id.tv_lat_long_template).setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            findViewById<TextView>(R.id.tv_plus_code_template).setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            findViewById<TextView>(R.id.tv_note_template).setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            findViewById<TextView>(R.id.tv_time_template).setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            findViewById<TextView>(R.id.tv_time_zone_template).setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            findViewById<TextView>(R.id.tv_altitude_template).setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            findViewById<TextView>(R.id.tv_accuracy_template).setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            findViewById<TextView>(R.id.tv_weather_template).setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            findViewById<TextView>(R.id.tv_wind_template).setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            findViewById<TextView>(R.id.tv_pressure_template).setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            findViewById<TextView>(R.id.tv_humidity_template).setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
        }
    }

    private fun templateTextColorChange() {
        newLayoutView.apply {
            findViewById<TextView>(R.id.tv_address_template).setTextColor(baseConfig.stampColor)
            findViewById<TextView>(R.id.tv_lat_long_template).setTextColor(baseConfig.stampColor)
            findViewById<TextView>(R.id.tv_plus_code_template).setTextColor(baseConfig.stampColor)
            findViewById<TextView>(R.id.tv_time_template).setTextColor(baseConfig.stampColor)
            findViewById<TextView>(R.id.tv_time_zone_template).setTextColor(baseConfig.stampColor)
            findViewById<TextView>(R.id.tv_altitude_template).setTextColor(baseConfig.stampColor)
            findViewById<TextView>(R.id.tv_accuracy_template).setTextColor(baseConfig.stampColor)
            findViewById<TextView>(R.id.tv_weather_template).setTextColor(baseConfig.stampColor)
            findViewById<TextView>(R.id.tv_wind_template).setTextColor(baseConfig.stampColor)
            findViewById<TextView>(R.id.tv_pressure_template).setTextColor(baseConfig.stampColor)
            findViewById<TextView>(R.id.tv_humidity_template).setTextColor(baseConfig.stampColor)
        }
    }

    private fun templateTextStyleChange() {
        val typeface = when (baseConfig.stampFontStyle) {
            0 -> Typeface.createFromAsset(assets, "font/sourcecodepro_regular.ttf")
            1 -> Typeface.createFromAsset(assets, "font/robotocondensed.ttf")
            2 -> Typeface.createFromAsset(assets, "font/opensans.ttf")
            3 -> Typeface.createFromAsset(assets, "font/notosansdisplay.ttf")
            4 -> Typeface.createFromAsset(assets, "font/ibmplexsans.ttf")
            5 -> Typeface.createFromAsset(assets, "font/inter_medium.ttf")
            6 -> Typeface.createFromAsset(assets, "font/poppins_medium.ttf")
            7 -> Typeface.createFromAsset(assets, "font/roboto_medium.ttf")
            8 -> Typeface.createFromAsset(assets, "font/sf_ui_medium.otf")
            else -> Typeface.createFromAsset(assets, "font/sourcecodepro_regular.ttf")
        }
        newLayoutView.apply {
            findViewById<TextView>(R.id.tv_address_template).typeface = typeface
            findViewById<TextView>(R.id.tv_lat_long_template).typeface = typeface
            findViewById<TextView>(R.id.tv_plus_code_template).typeface = typeface
            findViewById<TextView>(R.id.tv_note_template).typeface = typeface
            findViewById<TextView>(R.id.tv_time_template).typeface = typeface
            findViewById<TextView>(R.id.tv_time_zone_template).typeface = typeface
            findViewById<TextView>(R.id.tv_altitude_template).typeface = typeface
            findViewById<TextView>(R.id.tv_accuracy_template).typeface = typeface
            findViewById<TextView>(R.id.tv_weather_template).typeface = typeface
            findViewById<TextView>(R.id.tv_wind_template).typeface = typeface
            findViewById<TextView>(R.id.tv_pressure_template).typeface = typeface
            findViewById<TextView>(R.id.tv_humidity_template).typeface = typeface
        }
    }

    private fun initChanges() {
        binding.apply {
            tvStampSizeValue.text = baseConfig.getFontSizeText(this@TemplateEditorActivity)
//            tvStampPositionValue.text = baseConfig.getStampPositionText(this@TemplateEditActivity)
            tvStampFontValue.text = baseConfig.getStampFontText(this@TemplateEditorActivity)
            tvMapTypeValue.setImageDrawable(baseConfig.getMapTypeIcon(this@TemplateEditorActivity))
            tvLatLongValue.text = baseConfig.getLatLongText(this@TemplateEditorActivity)
            tvPlusCodeValue.text = baseConfig.stampPlusCode
            tvDateTimeValue.text = baseConfig.dateFormat
            tvNoteHashtagValue.text = "Note: " + baseConfig.lastNote
            tvTimeZoneValue.text = baseConfig.getTimezoneText()
            tvWeatherValue.text = baseConfig.getWeatherText(this@TemplateEditorActivity)
            tvAltitudeValue.text = baseConfig.getAltitudeText(this@TemplateEditorActivity)
            tvAccuracyValue.text = baseConfig.getAccuracyText(this@TemplateEditorActivity)
            tvWindValue.text = baseConfig.getWindText(this@TemplateEditorActivity)
            tvPressureValue.text = baseConfig.getPressureText(this@TemplateEditorActivity)
            tvHumidityValue.text = CameraActivity.tempHumidity

            tbMapType.isChecked = baseConfig.showMap
            tbAddress.isChecked = baseConfig.showAddress
            tbLatLong.isChecked = baseConfig.showLatLong
            tbPlusCode.isChecked = baseConfig.showPlusCode
            tbDateTime.isChecked = baseConfig.showDateTime
            tbTimeZone.isChecked = baseConfig.showTimeZone
//            tbLogo.isChecked = baseConfig.showLogo
            tbNoteHashtag.isChecked = baseConfig.showNote
            tbWeather.isChecked = baseConfig.showWeather
            tbWind.isChecked = baseConfig.showWind
            tbHumidity.isChecked = baseConfig.showHumidity
            tbPressure.isChecked = baseConfig.showPressure
            tbAltitude.isChecked = baseConfig.showAltitude
            tbAccuracy.isChecked = baseConfig.showAccuracy
        }
    }

    private fun allClicks() {
        binding.ivBack.setOnClickListener { finish() }
        binding.ivSave.setOnClickListener { finish() }
        binding.clMapType.setOnClickListener {
            val items = arrayListOf(
                RadioItem(MAP_NORMAL, getString(R.string.normal)),
                RadioItem(MAP_SATELLITE, getString(R.string.satellite)),
                RadioItem(MAP_TERRAIN, getString(R.string.terrain)),
                RadioItem(MAP_HYBRID, getString(R.string.hybrid))
            )
            launchMapTypeDialog(getString(R.string.map_type), items, baseConfig.stampMapType) {
                baseConfig.stampMapType = it as Int
                binding.tvMapTypeValue.setImageDrawable(baseConfig.getMapTypeIcon(this@TemplateEditorActivity))
                newLayoutView?.findViewById<ImageView>(R.id.iv_map_template)?.setImageDrawable(baseConfig.getMapTypeImage(this@TemplateEditorActivity))
            }
        }
        binding.clLatLong.setOnClickListener {
            val items = arrayListOf(
                RadioItem(LATLONG_DECIMAL, getString(R.string.decimal)),
                RadioItem(LATLONG_DEGREE, getString(R.string.decimal_degree)),
                RadioItem(LATLONG_DEGREE_MICRO, getString(R.string.decimal_degree_micro)),
                RadioItem(LATLONG_DECIMAL_MINUTES, getString(R.string.decimal_minutes)),
                RadioItem(LATLONG_DEGREE_MINUTES_SECONDS, getString(R.string.degree_minutes_seconds)),
                RadioItem(LATLONG_DECIMAL_MINUTES_SECONDS, getString(R.string.decimal_minutes_seconds))
            )
            launchRadioGroupDialog(getString(R.string.latlong), items, baseConfig.stampLatLongFormat) {
                baseConfig.stampLatLongFormat = it as Int
                binding.tvLatLongValue.text = baseConfig.getLatLongText(this@TemplateEditorActivity)
                newLayoutView?.findViewById<TextView>(R.id.tv_lat_long_template)?.text = baseConfig.formatLatLong(CameraActivity.tempLatitude, CameraActivity.tempLongitude)
            }
        }
        binding.clDateTime.setOnClickListener {
            val items = arrayListOf(
                RadioItem(DATE_FORMAT_ONE_CONST, formatDateSample(DATE_FORMAT_ONE)),
                RadioItem(DATE_FORMAT_TWO_CONST, formatDateSample(DATE_FORMAT_TWO)),
                RadioItem(DATE_FORMAT_THREE_CONST, formatDateSample(DATE_FORMAT_THREE)),
                RadioItem(DATE_FORMAT_FOUR_CONST, formatDateSample(DATE_FORMAT_FOUR)),
                RadioItem(DATE_FORMAT_FIVE_CONST, formatDateSample(DATE_FORMAT_FIVE)),
                RadioItem(DATE_FORMAT_SIX_CONST, formatDateSample(DATE_FORMAT_SIX)),
                RadioItem(DATE_FORMAT_SEVEN_CONST, formatDateSample(DATE_FORMAT_SEVEN)),
                RadioItem(DATE_FORMAT_EIGHT_CONST, formatDateSample(DATE_FORMAT_EIGHT)),
                RadioItem(DATE_FORMAT_NINE_CONST, formatDateSample(DATE_FORMAT_NINE)),
                RadioItem(DATE_FORMAT_TEN_CONST, formatDateSample(DATE_FORMAT_TEN))
            )
            launchRadioGroupDialog(getString(R.string.latlong), items, baseConfig.stampDateFormat) {
                baseConfig.stampDateFormat = it as Int
                binding.tvDateTimeValue.text = baseConfig.dateFormat
                newLayoutView?.findViewById<TextView>(R.id.tv_time_template)?.text = baseConfig.dateFormat
            }
        }
        binding.clNoteHashtag.setOnClickListener {
            addNoteDialog()
        }
        binding.clTimeZone.setOnClickListener {
            val timezoneFormats = baseConfig.getTimezoneFormats()
            val items = arrayListOf(
                RadioItem(TIMEZONE_FORMAT_ONE, timezoneFormats[0]),
                RadioItem(TIMEZONE_FORMAT_TWO, timezoneFormats[1]),
                RadioItem(TIMEZONE_FORMAT_THREE, timezoneFormats[2]),
                RadioItem(TIMEZONE_FORMAT_FOUR, timezoneFormats[3]),
                RadioItem(TIMEZONE_FORMAT_FIVE, timezoneFormats[4]),
                RadioItem(TIMEZONE_FORMAT_SIX, timezoneFormats[5])
            )
            launchRadioGroupDialog(getString(R.string.time_zone), items, baseConfig.stampTimezone) {
                baseConfig.stampTimezone = it as Int
                binding.tvTimeZoneValue.text = baseConfig.getTimezoneText()
                newLayoutView?.findViewById<TextView>(R.id.tv_time_zone_template)?.text = baseConfig.getTimezoneText()
            }
        }
        binding.clWeather.setOnClickListener {
            val weatherFormats = baseConfig.getWeatherFormats()
            val items = arrayListOf(
                RadioItem(WEATHER_FORMAT_CELSIUS, weatherFormats[0]),
                RadioItem(WEATHER_FORMAT_FAHRENHEIT, weatherFormats[1])
            )
            launchRadioGroupDialog(getString(R.string.weather), items, baseConfig.weatherType) {
                baseConfig.weatherType = it as Int
                binding.tvWeatherValue.text = baseConfig.getWeatherText(this@TemplateEditorActivity)
                newLayoutView?.findViewById<TextView>(R.id.tv_weather_template)?.text = "Weather:" + baseConfig.getWeatherText(this@TemplateEditorActivity)
            }
        }
        binding.clWind.setOnClickListener {
            val windFormats = baseConfig.getWindFormats()
            val items = arrayListOf(
                RadioItem(WIND_FORMAT_KMH, windFormats[0]),
                RadioItem(WIND_FORMAT_MPH, windFormats[1]),
                RadioItem(WIND_FORMAT_MS, windFormats[2]),
                RadioItem(WIND_FORMAT_KT, windFormats[3])
            )
            launchRadioGroupDialog(getString(R.string.wind), items, baseConfig.windType) {
                baseConfig.windType = it as Int
                binding.tvWindValue.text = baseConfig.getWindText(this@TemplateEditorActivity)
                newLayoutView?.findViewById<TextView>(R.id.tv_wind_template)?.text = "Wind:" + baseConfig.getWindText(this@TemplateEditorActivity)
            }
        }
        binding.clPressure.setOnClickListener {
            val pressureFormats = baseConfig.getPressureFormats()
            val items = arrayListOf(
                RadioItem(PRESSURE_FORMAT_HPA, pressureFormats[0]),
                RadioItem(PRESSURE_FORMAT_MMHG, pressureFormats[1]),
                RadioItem(PRESSURE_FORMAT_INHG, pressureFormats[2])
            )
            launchRadioGroupDialog(getString(R.string.pressure), items, baseConfig.pressureType) {
                baseConfig.pressureType = it as Int
                binding.tvPressureValue.text = baseConfig.getPressureText(this@TemplateEditorActivity)
                newLayoutView?.findViewById<TextView>(R.id.tv_pressure_template)?.text = "Pressure:" + baseConfig.getPressureText(this@TemplateEditorActivity)
            }
        }
        binding.clAltitude.setOnClickListener {
            val altitudeFormats = baseConfig.getAltitudeFormats()
            val items = arrayListOf(
                RadioItem(ALTITUDE_FORMAT_METER, altitudeFormats[0]),
                RadioItem(ALTITUDE_FORMAT_FOOT, altitudeFormats[1])
            )
            launchRadioGroupDialog(getString(R.string.altitude), items, baseConfig.altitudeType) {
                baseConfig.altitudeType = it as Int
                binding.tvAltitudeValue.text = baseConfig.getAltitudeText(this@TemplateEditorActivity)
                newLayoutView?.findViewById<TextView>(R.id.tv_altitude_template)?.text = "Altitude:" + baseConfig.getAltitudeText(this@TemplateEditorActivity)
            }
        }
        binding.clAccuracy.setOnClickListener {
            val accuracyFormats = baseConfig.getAccuracyFormats()
            val items = arrayListOf(
                RadioItem(ACCURACY_FORMAT_METER, accuracyFormats[0]),
                RadioItem(ACCURACY_FORMAT_FOOT, accuracyFormats[1])
            )
            launchRadioGroupDialog(getString(R.string.accuracy), items, baseConfig.accuracyType) {
                baseConfig.accuracyType = it as Int
                binding.tvAccuracyValue.text = baseConfig.getAccuracyText(this@TemplateEditorActivity)
                newLayoutView?.findViewById<TextView>(R.id.tv_altitude_template)?.text = "Altitude:" + baseConfig.getAccuracyText(this@TemplateEditorActivity)
            }
        }
        binding.clStampSize.setOnClickListener {
            val items = arrayListOf(
                RadioItem(FONT_SIZE_SMALL, getString(R.string.small)),
                RadioItem(FONT_SIZE_MEDIUM, getString(R.string.medium)),
                RadioItem(FONT_SIZE_LARGE, getString(R.string.large)),
                RadioItem(FONT_SIZE_EXTRA_SMALL, getString(R.string.extra_small))
            )
            launchRadioGroupDialog(getString(R.string.stamp_size), items, baseConfig.fontSize) {
                baseConfig.fontSize = it as Int
                binding.tvStampSizeValue.text = baseConfig.getFontSizeText(this@TemplateEditorActivity)
                templateTextSizeChange()
            }
        }
//        binding.clStampPosition.setOnClickListener {
//            val items = arrayListOf(
//                RadioItem(STAMP_TOP, getString(R.string.top)),
//                RadioItem(STAMP_BOTTOM, getString(R.string.bottom))
//            )
//            launchRadioGroupDialog(getString(R.string.stamp_position), items, baseConfig.stampPosition) {
//                baseConfig.stampPosition = it as Int
//                binding.tvStampPositionValue.text = baseConfig.getStampPositionText(this@TemplateEditActivity)
//            }
//        }
        binding.clStampFont.setOnClickListener {
            val items = arrayListOf(
//                RadioItem(FONT_HIND, getString(R.string.hind)),
//                RadioItem(FONT_INTER, getString(R.string.inter)),
//                RadioItem(FONT_ROBOTO, getString(R.string.roboto)),
//                RadioItem(FONT_SF, getString(R.string.sf_ui_text)),
//                RadioItem(FONT_POPPINS, getString(R.string.poppins))
                         RadioItem(FONT_SOURCECODEPRO,getString(R.string.font_sourcecodepro)),
                         RadioItem(FONT_ROBOTOCONDENSED,getString(R.string.font_robotocondensed)),
                         RadioItem(FONT_OPENSANS,getString(R.string.font_opensans)),
                         RadioItem(FONT_NOTOSANSDISPLAY,getString(R.string.font_notosansdisplay)),
                         RadioItem(FONT_IBMPLEXSANS,getString(R.string.font_ibmplexsans)),
                         RadioItem(FONT_INTER,getString(R.string.font_inter)),
                         RadioItem(FONT_POPPINS,getString(R.string.font_poppins)),
                         RadioItem(FONT_ROBOTO,getString(R.string.font_roboto)),
                         RadioItem(FONT_SF_UI,getString(R.string.font_sf_ui))
            )
            launchRadioGroupDialog(getString(R.string.font_style), items, baseConfig.stampFontStyle) {
                baseConfig.stampFontStyle = it as Int
                binding.tvStampFontValue.text = baseConfig.getStampFontText(this@TemplateEditorActivity)
                templateTextStyleChange()
            }
        }
        binding.clStampColor.setOnClickListener {
            pickColorDialog()
        }
    }

    private fun allToggleClick() {
        binding.apply {
            /*tbMapType.setOnCheckedChangeListener { _, isChecked ->
                Toast.makeText(this@TemplateEditActivity, R.string.can_not_change, Toast.LENGTH_SHORT).show()
            }*/
            /*tbMapType.setOnClickListener {
                if(tbMapType.isChecked) {
                    !tbMapType.isChecked
                } else {
                    tbMapType.isChecked
                }
                baseConfig.showMap = tbMapType.isChecked
                newLayoutView?.findViewById<CardView>(R.id.cv_map)?.beVisibleIf(baseConfig.showMap)
            }*/
            tbAddress.setOnClickListener {
                if (tbAddress.isChecked) {
                    !tbAddress.isChecked
                } else {
                    tbAddress.isChecked
                }
                baseConfig.showAddress = tbAddress.isChecked
                newLayoutView?.findViewById<TextView>(R.id.tv_address_template)?.beVisibleIf(baseConfig.showAddress)
            }
            /*tbLatLong.setOnClickListener {
                if (tbLatLong.isChecked) {
                    !tbLatLong.isChecked
                } else {
                    tbLatLong.isChecked
                }
                baseConfig.showLatLong = tbLatLong.isChecked
                newLayoutView?.findViewById<TextView>(R.id.tv_lat_long_template)?.beVisibleIf(baseConfig.showLatLong)
            }*/
            tbPlusCode.setOnClickListener {
                if (tbPlusCode.isChecked) {
                    !tbPlusCode.isChecked
                } else {
                    tbPlusCode.isChecked
                }
                baseConfig.showPlusCode = tbPlusCode.isChecked
                newLayoutView?.findViewById<TextView>(R.id.tv_plus_code_template)?.beVisibleIf(baseConfig.showPlusCode)
            }
            /*tbDateTime.setOnClickListener {
                if (tbDateTime.isChecked) {
                    !tbDateTime.isChecked
                } else {
                    tbDateTime.isChecked
                }
                baseConfig.showDateTime = tbDateTime.isChecked
                newLayoutView?.findViewById<TextView>(R.id.tv_time_template)?.beVisibleIf(baseConfig.showDateTime)
            }*/
            tbTimeZone.setOnClickListener {
                if (tbTimeZone.isChecked) {
                    !tbTimeZone.isChecked
                } else {
                    tbTimeZone.isChecked
                }
                baseConfig.showTimeZone = tbTimeZone.isChecked
                newLayoutView?.findViewById<TextView>(R.id.tv_time_zone_template)?.beVisibleIf(baseConfig.showTimeZone)
            }
//            tbLogo.setOnClickListener {
//                if (tbLogo.isChecked) {
//                    !tbLogo.isChecked
//                } else {
//                    tbLogo.isChecked
//                }
//                baseConfig.showLogo = tbLogo.isChecked
//                newLayoutView?.findViewById<ImageView>(R.id.iv_logo_template)?.beVisibleIf(baseConfig.showLogo)
//            }
            tbNoteHashtag.setOnClickListener {
                if (tbNoteHashtag.isChecked) {
                    !tbNoteHashtag.isChecked
                } else {
                    tbNoteHashtag.isChecked
                }
                baseConfig.showNote = tbNoteHashtag.isChecked
                newLayoutView?.findViewById<TextView>(R.id.tv_note_template)?.beVisibleIf(baseConfig.showNote)
            }
            tbWeather.setOnClickListener {
                if (tbWeather.isChecked) {
                    !tbWeather.isChecked
                } else {
                    tbWeather.isChecked
                }
                baseConfig.showWeather = tbWeather.isChecked
                newLayoutView?.findViewById<TextView>(R.id.tv_weather_template)?.beVisibleIf(baseConfig.showWeather)
            }
            tbWind.setOnClickListener {
                if (tbWind.isChecked) {
                    !tbWind.isChecked
                } else {
                    tbWind.isChecked
                }
                baseConfig.showWind = tbWind.isChecked
                newLayoutView?.findViewById<TextView>(R.id.tv_wind_template)?.beVisibleIf(baseConfig.showWind)
            }
            tbHumidity.setOnClickListener {
                if (tbHumidity.isChecked) {
                    !tbHumidity.isChecked
                } else {
                    tbHumidity.isChecked
                }
                baseConfig.showHumidity = tbHumidity.isChecked
                newLayoutView?.findViewById<TextView>(R.id.tv_humidity_template)?.beVisibleIf(baseConfig.showHumidity)
            }
            tbPressure.setOnClickListener {
                if (tbPressure.isChecked) {
                    !tbPressure.isChecked
                } else {
                    tbPressure.isChecked
                }
                baseConfig.showPressure = tbPressure.isChecked
                newLayoutView?.findViewById<TextView>(R.id.tv_pressure_template)?.beVisibleIf(baseConfig.showPressure)
            }
            tbAltitude.setOnClickListener {
                if (tbAltitude.isChecked) {
                    !tbAltitude.isChecked
                } else {
                    tbAltitude.isChecked
                }
                baseConfig.showAltitude = tbAltitude.isChecked
                newLayoutView?.findViewById<TextView>(R.id.tv_altitude_template)?.beVisibleIf(baseConfig.showAltitude)
            }
            tbAccuracy.setOnClickListener {
                if (tbAccuracy.isChecked) {
                    !tbAccuracy.isChecked
                } else {
                    tbAccuracy.isChecked
                }
                baseConfig.showAccuracy = tbAccuracy.isChecked
                newLayoutView?.findViewById<TextView>(R.id.tv_accuracy_template)?.beVisibleIf(baseConfig.showAccuracy)
            }
        }
    }

    /*private fun pickColorDialog() {
        ColorPickerDialogBuilder
            .with(this@TemplateEditActivity)
            .setTitle("Choose color")
            .initialColor(R.color.dialog_bg_color)
            .wheelType(ColorPickerView.WHEEL_TYPE.FLOWER)
            .density(12)
            .setOnColorSelectedListener(object : OnColorSelectedListener {
                override fun onColorSelected(selectedColor: Int) {
                    //                        Toast(this@TemplateEditActivity, "onColorSelected: 0x" + Integer.toHexString(selectedColor)).show()
                    Log.w("msg", "onColorSelected: " + Integer.toHexString(selectedColor))
                }
            })
            .setPositiveButton(R.string.ok, object : ColorPickerClickListener {
                override fun onClick(
                    dialog: DialogInterface?,
                    selectedColor: Int,
                    allColors: Array<Int?>?
                ) {
                    //                        changeBackgroundColor(selectedColor)
                }
            })
            .setNegativeButton(
                R.string.cancel,
                DialogInterface.OnClickListener { dialog, which -> })
            .build()
            .show()
    }*/

    private fun pickColorDialog() {
        /*ColorPickerDialog
            .Builder(this)        				// Pass Activity Instance
            .setTitle("Pick Theme")           	// Default "Choose Color"
            .setColorShape(ColorShape.SQAURE)   // Default ColorShape.CIRCLE
            .setDefaultColor(R.color.white)     // Pass Default Color
            .setColorListener { color, colorHex ->
                // Handle Color Selection
                Log.w("msg", "pickColorDialog: " + color)
            }
            .show()*/

        MaterialColorPickerDialog
            .Builder(this@TemplateEditorActivity)
            .setTitle(R.string.choose_color)
//            .setTickColorPerCard(true)

            // Option 1: Pass Hex Color Codes
            .setColors(arrayListOf("#ffffff", "#ffbe76", "#ff7979", "#badc58", "#dff9fb", "#7ed6df", "#e056fd", "#686de0", "#30336b", "#95afc0"))

            // Option 2: Pass Hex Color Codes from string.xml
            //.setColors(resources.getStringArray(R.array.themeColorHex))

            // Option 3: Pass color array from colors.xml
//            .setColorRes(resources.getIntArray(R.array.themeColors))

            .setColorListener { color, colorHex ->
                // Handle Color Selection
                baseConfig.stampColor = color
                templateTextColorChange()
            }
            .show()
    }

    private fun formatDateSample(format: String): String {
        val cal = Calendar.getInstance(Locale.ENGLISH)
        cal.timeInMillis = System.currentTimeMillis()
        return DateFormat.format(format, cal).toString()
    }

    private fun launchRadioGroupDialog(title: String, items: ArrayList<RadioItem>, checkedItemId: Int = -1, callback: (newValue: Any) -> Unit) {
        var selectedItemId = -1
        var dialog = Dialog(this@TemplateEditorActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val window = dialog.window
        window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.setCancelable(true)
        val dialogBinding = CustomRadiogroupDialogBinding.inflate(layoutInflater)
        dialog.setContentView(dialogBinding.root)
        dialogBinding.tvTitle.text = title
        dialogBinding.dialogRadioGroup.apply {
            for (i in 0 until items.size) {
                val radioButton = (layoutInflater.inflate(R.layout.radio_button, null) as RadioButton).apply {
                    text = items[i].title
                    isChecked = items[i].id == checkedItemId
                    id = i
                    setOnClickListener {
                        callback(items[i].value)
                        dialog.dismiss()
                    }
                }

                if (items[i].id == checkedItemId) {
                    selectedItemId = i
                }

                addView(radioButton, RadioGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
        }
        dialog.show()
    }

    private fun launchMapTypeDialog(title: String, items: ArrayList<RadioItem>, checkedItemId: Int = -1, callback: (newValue: Any) -> Unit) {
        var selectedItemId = -1
        var dialog = Dialog(this@TemplateEditorActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val window = dialog.window
        window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.setCancelable(true)
        val dialogBinding = CustomMaptypeDialogBinding.inflate(layoutInflater)
        dialog.setContentView(dialogBinding.root)
        dialogBinding.tvTitle.text = title

        dialogBinding.radioGroup.check(baseConfig.stampMapType)
        dialogBinding.radioNormal.isChecked = items[0].id == checkedItemId
        dialogBinding.radioSatellite.isChecked = items[1].id == checkedItemId
        dialogBinding.radioTerrain.isChecked = items[2].id == checkedItemId
        dialogBinding.radioHybrid.isChecked = items[3].id == checkedItemId
        dialogBinding.radioNormal.setOnClickListener {
            callback(items[0].value)
            if (items[0].id == checkedItemId) {
                selectedItemId = 0
            }
            dialog.dismiss()
        }
        dialogBinding.radioSatellite.setOnClickListener {
            callback(items[1].value)
            if (items[1].id == checkedItemId) {
                selectedItemId = 1
            }
            dialog.dismiss()
        }
        dialogBinding.radioTerrain.setOnClickListener {
            callback(items[2].value)
            if (items[2].id == checkedItemId) {
                selectedItemId = 2
            }
            dialog.dismiss()
        }
        dialogBinding.radioHybrid.setOnClickListener {
            callback(items[3].value)
            if (items[3].id == checkedItemId) {
                selectedItemId = 3
            }
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun addNoteDialog() {
        val dialog = Dialog(this@TemplateEditorActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val window = dialog.window
        window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.setCancelable(true)
        val dialogBinding = CustomNoteDialogBinding.inflate(layoutInflater)
        dialog.setContentView(dialogBinding.root)
        dialogBinding.tvActionCancel.setOnClickListener {
            dialog.dismiss()
        }
        dialogBinding.tvActionOk.setOnClickListener {
            if (dialogBinding.etDesc.text.isNullOrEmpty()) {
                Toast.makeText(this@TemplateEditorActivity, getString(R.string.add_note_attention), Toast.LENGTH_SHORT).show()
            } else {
                baseConfig.lastNote = dialogBinding.etDesc.text.toString()
                binding.tvNoteHashtagValue.text = "Note: " + baseConfig.lastNote
                newLayoutView?.findViewById<TextView>(R.id.tv_note_template)?.text = "Note: " + baseConfig.lastNote
                dialog.dismiss()
            }
        }

        dialog.show()
    }

    override fun onResume() {
//        Log.w("msg", "onResume:templateEdit ")
//        templateChange(newLayoutView!!)
        super.onResume()
    }

}