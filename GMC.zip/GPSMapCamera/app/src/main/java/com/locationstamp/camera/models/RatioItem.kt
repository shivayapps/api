package com.locationstamp.camera.models

data class RatioItem(val width: Int, val height: Int)
