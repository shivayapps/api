package com.locationstamp.camera.listeners

//interface OnItemClick {
//    fun onClick()
//}