package com.locationstamp.camera.helpers

interface ScanningResultListener {
    fun onScanned(result: String)
}