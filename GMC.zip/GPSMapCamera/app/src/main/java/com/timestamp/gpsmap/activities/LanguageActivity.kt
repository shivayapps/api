package com.timestamp.gpsmap.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.timestamp.gpsmap.MyApplication
import com.timestamp.gpsmap.R
import com.timestamp.gpsmap.adapters.LanguageAdapter
import com.timestamp.gpsmap.adloaders.InterstitialAdLoader
import com.timestamp.gpsmap.adloaders.NativeAdSize
import com.timestamp.gpsmap.adloaders.PreLoadNativeAds
import com.timestamp.gpsmap.databinding.ActivityLanguageBinding
import com.timestamp.gpsmap.extentions.baseConfig
import com.timestamp.gpsmap.helpers.AppUtils
import com.timestamp.gpsmap.helpers.EXTRA_IS_OPEN_FROM_SPLASH
import com.timestamp.gpsmap.helpers.activity_tag
import com.timestamp.gpsmap.helpers.open_tag
import com.timestamp.gpsmap.models.LanguageData

class LanguageActivity : BaseActivity() {

    lateinit var binding: ActivityLanguageBinding
    var selectPos = 0
    lateinit var adapter: LanguageAdapter
    var isOpenFromSplash: Boolean = false
    var languageList: ArrayList<LanguageData> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLanguageBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        hideNavigationBar()
        AppUtils.logAdapterMessages(
            this@LanguageActivity,
            activity_tag,
            open_tag,
            LanguageActivity::class.java.simpleName.toString()
        )
        init()
        loadNative()
    }

    private fun init() {
        if (intent != null)
            isOpenFromSplash = intent.getBooleanExtra(EXTRA_IS_OPEN_FROM_SPLASH, false)

        getLanList()
        initListener()

        binding.icBack.visibility = if (isOpenFromSplash) View.GONE else View.VISIBLE

//        selectPos = preferences.getSelectLanguage()
        selectPos = baseConfig.selectLanguage
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = LanguageAdapter(
            this,
            languageList,
            clickListener = {
                selectPos = it
            })
        adapter.selectPos = selectPos
        binding.recyclerView.adapter = adapter
    }

    private fun updateViews(languageCode: String) {
        com.timestamp.gpsmap.helpers.LocaleHelper.setLocale(this, languageCode)
    }

    private fun loadNative() {
        val nativeADs = PreLoadNativeAds(this)
        nativeADs.showLoadingLayoutForNative(binding.flNative, NativeAdSize.Big)
        MyApplication.nativeAdsFiles.observe(this, androidx.lifecycle.Observer { native ->
            if (native != null) {
                nativeADs.showNative(binding.flNative, native, NativeAdSize.Big)
            } else {
                if (nativeADs.checkAdsIsOn() && MyApplication.isNativeLoading)
                    binding.flNative.visibility = View.VISIBLE
                else
                    binding.flNative.visibility = View.GONE
            }
        })
    }

    private fun initListener() {
        binding.icBack.setOnClickListener {
            finish()
        }

        binding.ivDone.setOnClickListener {
            InterstitialAdLoader(this@LanguageActivity).showFullScreenAds(
                this,
                object :
                    InterstitialAdLoader.AdFinishWithControlListener {
                    override fun adFinished() {
                        doneMethod()
                    }
                })
        }
    }

    private fun doneMethod() {
        //            preferences.setSelectLanguage(selectPos)
        baseConfig.selectLanguage = selectPos
        //            preferences.putLanguage(true)
        baseConfig.languageScreenShow = 1
        baseConfig.selectLanguageString = languageList[selectPos].name
        updateViews(languageList[selectPos].languageCode)
        if (isOpenFromSplash) {

            Log.w("msg", "initListener: " + baseConfig.introScreenShow)
            val intent1 = /*if (baseConfig.introScreenShow == 0 ) {
                        Intent(this, IntroActivity::class.java)
                    } else*/ if (!baseConfig.checkAllPermissions(this@LanguageActivity)) {
                Intent(this, PermissionActivity::class.java)
            } else {
                Intent(this, CameraActivity::class.java)
            }

            startActivity(intent1)
        } else {
            //                setResult(RESULT_OK)
            val intent = Intent(this, CameraActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(intent)
        }
        finish()
    }

    private fun getLanList() {
        languageList.add(
            LanguageData(
                getString(R.string.english),
                "en",
                ContextCompat.getDrawable(this, R.drawable.ic_english_lang)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.spanish),
                "es",
                ContextCompat.getDrawable(this, R.drawable.ic_spanish_lang)
            )
        )
        languageList.add(
            LanguageData(
                getString(R.string.german),
                "de",
                ContextCompat.getDrawable(this, R.drawable.ic_germen_lang)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.french),
                "fr",
                ContextCompat.getDrawable(this, R.drawable.ic_french_lang)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.portuguese),
                "pt",
                ContextCompat.getDrawable(this, R.drawable.ic_portuguese_lang)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.hindi),
                "hi",
                ContextCompat.getDrawable(this, R.drawable.ic_hindi_lang)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.swedish),
                "sv",
                ContextCompat.getDrawable(this, R.drawable.ic_swedish_lang)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.norwegian),
                "no",
                ContextCompat.getDrawable(this, R.drawable.ic_norwegian_lang)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.italian),
                "it",
                ContextCompat.getDrawable(this, R.drawable.ic_italian_lang)
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.dutch),
                "nl",
                ContextCompat.getDrawable(this, R.drawable.ic_dutch_lang)
            )
        )

    }
}