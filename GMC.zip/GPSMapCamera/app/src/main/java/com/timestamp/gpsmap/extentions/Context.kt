package com.timestamp.gpsmap.extentions

import android.app.Activity
import android.content.Context
import android.widget.Toast
import com.timestamp.gpsmap.helpers.Config
import com.timestamp.gpsmap.helpers.PREFS_KEY

fun Context.getSharedPrefs() = getSharedPreferences(PREFS_KEY, Context.MODE_PRIVATE)

fun Context.toast(id: Int, length: Int = Toast.LENGTH_SHORT) {
    doToast(this, getString(id), length)
}

private fun doToast(context: Context, message: String, length: Int) {
    if (context is Activity) {
        if (!context.isFinishing && !context.isDestroyed) {
            Toast.makeText(context, message, length).show()
        }
    } else {
        Toast.makeText(context, message, length).show()
    }
}

val Context.baseConfig: Config get() = Config.newInstance(this)

