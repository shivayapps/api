package com.timestamp.gpsmap.adloaders

enum class NativeAdSize {
    Small, Medium, Big
}