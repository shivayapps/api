package com.timestamp.gpsmap

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.OnLifecycleEvent
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.multidex.MultiDexApplication
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
//import com.google.firebase.FirebaseApp
//import com.google.firebase.analytics.FirebaseAnalytics
//import com.google.firebase.analytics.ktx.analytics
//import com.google.firebase.ktx.Firebase
//import com.google.firebase.messaging.FirebaseMessaging
//import com.google.firebase.remoteconfig.FirebaseRemoteConfig
//import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.timestamp.gpsmap.adloaders.AdStaticData
import com.timestamp.gpsmap.helpers.EventKeys
import java.util.Date

class MyApplication : MultiDexApplication(), Application.ActivityLifecycleCallbacks,
    LifecycleObserver {

//    private lateinit var firebaseAnalytics: FirebaseAnalytics
//    var firebaseRemoteConfig: FirebaseRemoteConfig? = null
    private lateinit var appOpenAdManager: AppOpenAdManager
    private var currentActivity: Activity? = null
    private val LOG_TAG = "MyApplication"

    override fun onCreate() {
        super.onCreate()

        context = this

        registerActivityLifecycleCallbacks(this)
        MobileAds.initialize(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
        appOpenAdManager = AppOpenAdManager()
        isAppIsRunning = false

//        FirebaseApp.initializeApp(this)
//        firebaseAnalytics = Firebase.analytics
//        firebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
//        remoteConfig = firebaseRemoteConfig as FirebaseRemoteConfig
        getFireBaseConfig()
        getFireBaseToken()
    }

    private fun getFireBaseToken() {
//        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
//            if (!task.isSuccessful) {
//                Log.w("FIREBASE_TOKEN", "Fetching FCM registration token failed", task.exception)
//                return@OnCompleteListener
//            }
//
//            // Get new FCM registration token
//            val token = task.result
//
//            // Log and toast
////                    val msg = getString(R.string.msg_token_fmt, token)
//            Log.d("FIREBASE_TOKEN","FIREBASE_TOKEN: " + token)
////                    Toast.makeText(baseContext, msg, Toast.LENGTH_SHORT).show()
//        })
    }


//    fun getFirebaseAnalytics(): FirebaseAnalytics {
//        return firebaseAnalytics
//    }

    private fun getFireBaseConfig() {
//        try {
//            remoteConfig.setConfigSettingsAsync(
//                FirebaseRemoteConfigSettings.Builder()
//                    .setMinimumFetchIntervalInSeconds(0)
//                    .setFetchTimeoutInSeconds(3)
//                    .build()
//            )
//            Log.e("TAG" + "fireBaseConfigGet: ", "send req")
//            remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)
//            remoteConfig.fetch(0)
//                .addOnCompleteListener { task: Task<Void?> ->
//                    var errorString = ""
//                    if (task.isSuccessful) {
//                        remoteConfig.fetchAndActivate()
//                        errorString = " task is successful  "
//
//                    } else {
//                        errorString = "task is canceled"
//                    }
//                    Log.e("msg", " mFirebaseRemoteConfigis_ errorString ---------$errorString")
//                }
//        } catch (e: java.lang.Exception) {
//            e.printStackTrace()
//        }
    }

    companion object {
        lateinit var context: Context
//        lateinit var remoteConfig: FirebaseRemoteConfig
        var isAppIsRunning: Boolean = false
        var isOpenAdHide = false // to prevent open ad after click on privacy policy(etc.)
        var isOpenAdHideInterstitial = false // to prevent open ad overlay with interstitial ad
        var isSplashResumeOn = false // to prevent open ad in splash
        var isNativeLoading = false
        var nativeAdsFiles = MutableLiveData<NativeAd?>()
    }


    /** LifecycleObserver method that shows the app open ad when the app moves to foreground. */
    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    fun onMoveToForeground() {
        // Show the ad (if available) when the app moves to foreground.
//        currentActivity?.let { appOpenAdManager.showAdIfAvailable(it) }
        if(isOpenAdHide) {
            isOpenAdHide = false
        } else if(isOpenAdHideInterstitial) {

        } else if(isSplashResumeOn) {
            isSplashResumeOn = false
        } else {
            currentActivity?.let { appOpenAdManager.showAdIfAvailable(it) }
        }
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) { }

    override fun onActivityStarted(activity: Activity) {
        if (!appOpenAdManager.isShowingAd) {
            currentActivity = activity
        }
    }

    override fun onActivityResumed(activity: Activity) {}

    override fun onActivityPaused(activity: Activity) {}

    override fun onActivityStopped(activity: Activity) {}

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

    override fun onActivityDestroyed(activity: Activity) {}

    fun showAdIfAvailable(activity: Activity, onShowAdCompleteListener: OnShowAdCompleteListener) {
        // We wrap the showAdIfAvailable to enforce that other classes only interact with MyApplication
        // class.
        appOpenAdManager.showAdIfAvailable(activity, onShowAdCompleteListener)
    }

    fun loadAd(activity: Activity) {
        // We wrap the loadAd to enforce that other classes only interact with MyApplication
        // class.
//        if(!remoteConfig.getBoolean(EventKeys.isOpenAdEnable)) {
//            appOpenAdManager.loadAd(activity)
//        }
    }

    interface OnShowAdCompleteListener {
        fun onShowAdComplete()
    }


    private inner class AppOpenAdManager {
        private var appOpenAd: AppOpenAd? = null
        private var isLoadingAd = false
        var isShowingAd = false

        /** Keep track of the time an app open ad is loaded to ensure you don't show an expired ad. */
        private var loadTime: Long = 0

        /**
         * Load an ad.
         *
         * @param context the context of the activity that loads the ad
         */
        fun loadAd(context: Context) {
            // Do not load ad if there is an unused ad or one is already loading.
            if (isLoadingAd || isAdAvailable()) {
                return
            }

            isLoadingAd = true
            val request = AdRequest.Builder().build()
            AppOpenAd.load(
                context,
                AdStaticData.getOpenAdId(this@MyApplication),
                request,
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    /**
                     * Called when an app open ad has loaded.
                     *
                     * @param ad the loaded app open ad.
                     */
                    override fun onAdLoaded(ad: AppOpenAd) {
                        appOpenAd = ad
                        isLoadingAd = false
                        loadTime = Date().time
                        Log.w(LOG_TAG, "onAdLoaded.")
                    }

                    /**
                     * Called when an app open ad has failed to load.
                     *
                     * @param loadAdError the error.
                     */
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        isLoadingAd = false
                        Log.w(LOG_TAG, "onAdFailedToLoad: " + loadAdError.message)
                        reLoadAd(context)
                    }
                }
            )
        }

        fun reLoadAd(context: Context) {
            // Do not load ad if there is an unused ad or one is already loading.
            if (isLoadingAd || isAdAvailable()) {
                return
            }

            isLoadingAd = true
            val request = AdRequest.Builder().build()
            AppOpenAd.load(
                context,
                AdStaticData.getOpenAdReloadId(this@MyApplication),
                request,
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    /**
                     * Called when an app open ad has loaded.
                     *
                     * @param ad the loaded app open ad.
                     */
                    override fun onAdLoaded(ad: AppOpenAd) {
                        appOpenAd = ad
                        isLoadingAd = false
                        loadTime = Date().time
                        Log.w(LOG_TAG, "onAdLoaded.")
                    }

                    /**
                     * Called when an app open ad has failed to load.
                     *
                     * @param loadAdError the error.
                     */
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        isLoadingAd = false
                        Log.w(LOG_TAG, "onAdFailedToLoad: " + loadAdError.message)
                    }
                }
            )
        }

        /** Check if ad was loaded more than n hours ago. */
        private fun wasLoadTimeLessThanNHoursAgo(numHours: Long): Boolean {
            val dateDifference: Long = Date().time - loadTime
            val numMilliSecondsPerHour: Long = 3600000
            return dateDifference < numMilliSecondsPerHour * numHours
        }

        /** Check if ad exists and can be shown. */
        private fun isAdAvailable(): Boolean {
            // Ad references in the app open beta will time out after four hours, but this time limit
            // may change in future beta versions. For details, see:
            // https://support.google.com/admob/answer/9341964?hl=en
            return appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4)
        }

        /**
         * Show the ad if one isn't already showing.
         *
         * @param activity the activity that shows the app open ad
         */
        fun showAdIfAvailable(activity: Activity) {
            showAdIfAvailable(
                activity,
                object : OnShowAdCompleteListener {
                    override fun onShowAdComplete() {
                        // Empty because the user will go back to the activity that shows the ad.
                    }
                }
            )
        }

        /**
         * Show the ad if one isn't already showing.
         *
         * @param activity the activity that shows the app open ad
         * @param onShowAdCompleteListener the listener to be notified when an app open ad is complete
         */
        fun showAdIfAvailable(activity: Activity, onShowAdCompleteListener: OnShowAdCompleteListener) {
            // If the app open ad is already showing, do not show the ad again.
            if (isShowingAd) {
                Log.w(LOG_TAG, "The app open ad is already showing.")
                return
            }

            // If the app open ad is not available yet, invoke the callback.
            if (!isAdAvailable()) {
                Log.w(LOG_TAG, "The app open ad is not ready yet.")
                onShowAdCompleteListener.onShowAdComplete()
                loadAd(activity)
                return
            }

            Log.w(LOG_TAG, "Will show ad.")

            appOpenAd?.fullScreenContentCallback =
                object : FullScreenContentCallback() {
                    /** Called when full screen content is dismissed. */
                    override fun onAdDismissedFullScreenContent() {
                        // Set the reference to null so isAdAvailable() returns false.
                        appOpenAd = null
                        isShowingAd = false
                        Log.w(LOG_TAG, "onAdDismissedFullScreenContent.")

                        onShowAdCompleteListener.onShowAdComplete()
                        loadAd(activity)

                    }

                    /** Called when fullscreen content failed to show. */
                    override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                        appOpenAd = null
                        isShowingAd = false
                        Log.w(LOG_TAG, "onAdFailedToShowFullScreenContent: " + adError.message)

                        onShowAdCompleteListener.onShowAdComplete()
                        loadAd(activity)
                    }

                    /** Called when fullscreen content is shown. */
                    override fun onAdShowedFullScreenContent() {
                        Log.w(LOG_TAG, "onAdShowedFullScreenContent.")
                    }
                }
            isShowingAd = true
            appOpenAd?.show(activity)
        }
    }

    fun adConfigFinishAffinity() {
        isSplashResumeOn = true
    }

    fun openAdHide() {
        isOpenAdHide = true
    }
}