package com.timestamp.gpsmap.services;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

//import com.google.firebase.messaging.FirebaseMessagingService;
//import com.google.firebase.messaging.RemoteMessage;
import com.timestamp.gpsmap.R;
import com.timestamp.gpsmap.activities.SplashActivity;

import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

//public class FirebaseNotificationService extends FirebaseMessagingService {
//    private NotificationManager mNM = null;
//    private String TAG = "FIREBASE_NOTIFICATION";
//
//    @Override
//    public void onCreate() {
//        super.onCreate();
//        mNM = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
//    }
//    @Override
//    public void onDeletedMessages() {
//        super.onDeletedMessages();
//        int NOTIFICATION = 0;
//        mNM.cancel(NOTIFICATION);
//    }
//    @Override
//    public void onNewToken(@NonNull String token) {
//        super.onNewToken(token);
//    }
//
//    @SuppressLint("NewApi")
//    @Override
//    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
//        super.onMessageReceived(remoteMessage);
//        try {
//            showNotification(remoteMessage);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//    private void showNotification(RemoteMessage remoteMessage) {
//        ExecutorService executor = Executors.newSingleThreadExecutor();
//        Handler handler = new Handler(Looper.getMainLooper());
//
//        executor.execute(() -> {
//
//            String imageUrl, mActivityName = "";
//            Intent intent = new Intent();
//            Bitmap bitmap = null;
//            //Background work here
//            try {
//                String title = remoteMessage.getNotification().getTitle(); //get title
//                String message = remoteMessage.getNotification().getBody(); //get message
//                imageUrl = String.valueOf(remoteMessage.getNotification().getImageUrl());
//
//                Log.w(TAG, "FNS Message Notification Title: " + title);
//                Log.w(TAG, "FNS Message Notification Body: " + message);
//                Log.w(TAG, "FNS Message Notification imageUrl: " + imageUrl);
//                String activity_name;
//                try {
//                    Map<String, String> params = remoteMessage.getData();
//                    JSONObject object = new JSONObject(params);
////                    activity_name = object.getString(ConstantsKt.ACTIVITY_NAME);
//                } catch (Exception throwable) {
//                    throwable.printStackTrace();
//                }
//                intent = new Intent(this, SplashActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                if (imageUrl != null) {
//                    bitmap = getBitmapFromURL(imageUrl);
//                } else {
//                    bitmap = null;
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//
//            Intent finalIntent = intent;
//            Bitmap finalBitmap = bitmap;
//            handler.post(() -> {
//                NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), "1")
//                        .setContentTitle(remoteMessage.getNotification().getTitle())
//                        .setContentText(remoteMessage.getNotification().getBody())
//                        .setLargeIcon(BitmapFactory.decodeResource(this.getResources(), R.drawable.ic_notification))
//                        .setTicker(getString(R.string.app_name))
//                        .setAutoCancel(true)
//                        .setChannelId("1")
//                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
//                        .setLargeIcon(finalBitmap)
//                        .setStyle(new NotificationCompat.BigPictureStyle().bigPicture(finalBitmap).bigLargeIcon(finalBitmap));
//                NotificationManager notificationManager;
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                    NotificationChannel mChannel = new NotificationChannel("1", "1", NotificationManager.IMPORTANCE_HIGH);
//                    notificationManager = getSystemService(NotificationManager.class);
//                    if (notificationManager != null) {
//                        notificationManager.createNotificationChannel(mChannel);
//                    }
//                } else {
//                    notificationManager =
//                            (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//                }
//                builder.setSmallIcon(R.drawable.ic_notification);
//                finalIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
//                PendingIntent pendingIntent;
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
//                    pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, finalIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
//                } else {
//                    pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, finalIntent, PendingIntent.FLAG_UPDATE_CURRENT);
//                }
//                builder.setContentIntent(pendingIntent);
//                builder.setDefaults(Notification.DEFAULT_ALL);
//                if (notificationManager != null)
//                    notificationManager.notify(4, builder.build());
//            });
//        });
//    }
//    private Bitmap getBitmapFromURL(String strURL) {
//        Log.w(TAG, "getBitmapFromURL strURL: " + strURL);
//        try {
//            if (!strURL.equals("null")) {
//                URL url = new URL(strURL);
//                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//                connection.setDoInput(true);
//                connection.connect();
//                InputStream input = connection.getInputStream();
//                return BitmapFactory.decodeStream(input);
//            }
//            return null;
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }
//}
//
//
