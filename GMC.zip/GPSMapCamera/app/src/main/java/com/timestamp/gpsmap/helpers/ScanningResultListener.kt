package com.timestamp.gpsmap.helpers

interface ScanningResultListener {
    fun onScanned(result: String)
}