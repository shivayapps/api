package com.timestamp.gpsmap.listeners

//interface OnItemClick {
//    fun onClick()
//}