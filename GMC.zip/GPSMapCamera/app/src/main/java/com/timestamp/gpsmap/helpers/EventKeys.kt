package com.timestamp.gpsmap.helpers

class EventKeys {
    companion object {

        const val adIdsJson: String = "adIdsJson"
        const val isOpenAdEnable: String = "isOpenAdEnable"
        const val isBannerAdEnable: String = "isBannerAdEnable"
        const val isNativeAdEnable: String = "isNativeAdEnable"
        const val isInterstitialAdEnable: String = "isInterstitialAdEnable"
        const val redirectLink: String = "redirectLink"

    }
}