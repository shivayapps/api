package com.timestamp.gpsmap.activities

import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.util.Size
import android.view.OrientationEventListener
import android.view.Surface
import android.view.View
import android.view.Window
import android.webkit.URLUtil
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.TorchState
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.timestamp.gpsmap.R
import com.timestamp.gpsmap.databinding.ActivityBarcodeScanningBinding
import com.timestamp.gpsmap.databinding.ScannerDetailDialogBinding
import com.timestamp.gpsmap.extentions.baseConfig
import com.timestamp.gpsmap.extentions.beVisibleIf
import com.timestamp.gpsmap.helpers.ScanningResultListener
import com.timestamp.gpsmap.helpers.ZXingBarcodeAnalyzer
import com.google.common.util.concurrent.ListenableFuture
import com.timestamp.gpsmap.helpers.AppUtils
import com.timestamp.gpsmap.helpers.activity_tag
import com.timestamp.gpsmap.helpers.open_tag
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class BarcodeScanningActivity : com.timestamp.gpsmap.activities.BaseActivity() {
    private lateinit var binding: ActivityBarcodeScanningBinding
    private lateinit var cameraProviderFuture: ListenableFuture<ProcessCameraProvider>
    private lateinit var cameraExecutor: ExecutorService
    private var flashEnabled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBarcodeScanningBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        AppUtils.logAdapterMessages(
            this@BarcodeScanningActivity,
            activity_tag,
            open_tag,
            BarcodeScanningActivity::class.java.simpleName.toString()
        )
        hideNavigationBar()

        cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        // Initialize our background executor
        cameraExecutor = Executors.newSingleThreadExecutor()

        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            bindPreview(cameraProvider)
        }, ContextCompat.getMainExecutor(this))

        binding.overlay.post {
            binding.overlay.setViewFinder()
        }
    }

    private fun bindPreview(cameraProvider: ProcessCameraProvider?) {

        if (isDestroyed || isFinishing) {
            //This check is to avoid an exception when trying to re-bind use cases but user closes the activity.
            //java.lang.IllegalArgumentException: Trying to create use case mediator with destroyed lifecycle.
            return
        }

        cameraProvider?.unbindAll()

        val preview: Preview = Preview.Builder()
            .build()

        val cameraSelector: CameraSelector = CameraSelector.Builder()
            .requireLensFacing(CameraSelector.LENS_FACING_BACK)
            .build()

        val imageAnalysis = ImageAnalysis.Builder()
            .setTargetResolution(Size(binding.cameraPreview.width, binding.cameraPreview.height))
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()

        val orientationEventListener = object : OrientationEventListener(this as Context) {
            override fun onOrientationChanged(orientation: Int) {
                // Monitors orientation values to determine the target rotation value
                val rotation: Int = when (orientation) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }

                imageAnalysis.targetRotation = rotation
            }
        }
        orientationEventListener.enable()

        class ScanningListener : ScanningResultListener {
            override fun onScanned(result: String) {
                runOnUiThread {
                    imageAnalysis.clearAnalyzer()
                    cameraProvider?.unbindAll()
                    Log.w("msg", "onScanned: " + result)
                    /*ScannerResultDialog.newInstance(
                        result,
                        object : ScannerResultDialog.DialogDismissListener {
                            override fun onDismiss() {
                                bindPreview(cameraProvider)
                            }
                        })
                        .show(supportFragmentManager, ScannerResultDialog::class.java.simpleName)*/
                    launchDialog(result, cameraProvider)
                }
            }
        }

        var analyzer = ZXingBarcodeAnalyzer(ScanningListener())
        imageAnalysis.setAnalyzer(cameraExecutor, analyzer)

        preview.setSurfaceProvider(binding.cameraPreview.surfaceProvider)

        val camera =
            cameraProvider?.bindToLifecycle(this, cameraSelector, imageAnalysis, preview)

        if (camera?.cameraInfo?.hasFlashUnit() == true) {
            binding.ivFlashControl.visibility = View.VISIBLE

            binding.ivFlashControl.setOnClickListener {
                camera.cameraControl.enableTorch(!flashEnabled)
            }

            camera.cameraInfo.torchState.observe(this) {
                it?.let { torchState ->
                    if (torchState == TorchState.ON) {
                        flashEnabled = true
                        binding.ivFlashControl.setImageResource(R.drawable.ic_flash_on_icon)
                    } else {
                        flashEnabled = false
                        binding.ivFlashControl.setImageResource(R.drawable.ic_flash_off_icon)
                    }
                }
            }
        }
    }

    private fun launchDialog(result: String, cameraProvider: ProcessCameraProvider?) {
        val dialog = Dialog(this@BarcodeScanningActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val window = dialog.window
        window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.setCancelable(true)
        val dialogBinding = ScannerDetailDialogBinding.inflate(layoutInflater)
        dialog.setContentView(dialogBinding.root)
        dialogBinding.edtResult.text = result
        dialogBinding.tvActionRedirect.apply {
            beVisibleIf(URLUtil.isValidUrl(result))
            setOnClickListener {
                baseConfig.openWebsiteIntent(this@BarcodeScanningActivity, result)
                dialog.dismiss()
            }
        }
        dialogBinding.tvActionCancel.setOnClickListener {
            dialog.dismiss()
        }
        dialogBinding.tvActionCopy.setOnClickListener {
            val clipboard = ContextCompat.getSystemService(this@BarcodeScanningActivity, ClipboardManager::class.java)
            val clip = ClipData.newPlainText("label",result)
            clipboard?.setPrimaryClip(clip)
            Toast.makeText(this@BarcodeScanningActivity, R.string.copy_clipboard, Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }
        dialog.setOnDismissListener {
            bindPreview(cameraProvider)
        }
        dialog.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Shut down our background executor
        cameraExecutor.shutdown()
    }
}