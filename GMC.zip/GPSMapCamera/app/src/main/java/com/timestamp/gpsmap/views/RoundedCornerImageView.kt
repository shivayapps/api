package com.timestamp.gpsmap.views

import android.content.Context
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatImageView
import com.timestamp.gpsmap.R

class RoundedCornerImageView : AppCompatImageView {
    private val path = Path()
    private val rectF = RectF(0f, 0f, 0f, 0f)
    private var cornerRadius = 10f // Adjust this value for the desired corner radius

    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init(context, attrs)
    }

    constructor(context: Context, attrs: AttributeSet, defStyle: Int) : super(context, attrs, defStyle) {
        init(context, attrs)
    }

    private fun init(context: Context, attrs: AttributeSet) {
        val typedArray = context.obtainStyledAttributes(attrs, R.styleable.RoundedCornerImageView)
        cornerRadius = typedArray.getDimension(R.styleable.RoundedCornerImageView_cornerRadius, cornerRadius)
        typedArray.recycle()
    }

    override fun onDraw(canvas: Canvas) {
        path.reset()
        rectF.set(0f, 0f, width.toFloat(), height.toFloat())
        path.addRoundRect(rectF, cornerRadius, cornerRadius, Path.Direction.CW)
        canvas.clipPath(path)
        super.onDraw(canvas)
    }
}
