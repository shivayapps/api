package com.timestamp.gpsmap.models

data class PageItem(val layoutResId: Int)
