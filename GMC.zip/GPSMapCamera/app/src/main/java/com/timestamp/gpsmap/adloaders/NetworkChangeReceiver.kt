package com.timestamp.gpsmap.adloaders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager


class NetworkChangeReceiver @JvmOverloads constructor(private val onNetworkStatusChange: OnNetworkStatusChange? = null) : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        try {
            onNetworkStatusChange?.isOnline(isOnline(context))
        } catch (e: NullPointerException) {
            e.printStackTrace()
        }

    }

    private fun isOnline(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val netInfo = cm.activeNetworkInfo
            //should check null because in airplane mode it will be null
            netInfo != null && netInfo.isConnected
        } catch (e: NullPointerException) {
            e.printStackTrace()
            false
        }

    }

    interface OnNetworkStatusChange {
        fun isOnline(isOnline: Boolean)
    }
}