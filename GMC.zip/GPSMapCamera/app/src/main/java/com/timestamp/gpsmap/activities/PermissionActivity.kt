package com.timestamp.gpsmap.activities

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import androidx.core.app.ActivityCompat
import com.timestamp.gpsmap.databinding.ActivityPermissionBinding
import com.timestamp.gpsmap.extentions.beGone
import com.timestamp.gpsmap.extentions.beVisible
import com.timestamp.gpsmap.helpers.AppUtils
import com.timestamp.gpsmap.helpers.activity_tag
import com.timestamp.gpsmap.helpers.open_tag

class PermissionActivity : BaseActivity() {
    private lateinit var binding: ActivityPermissionBinding
    val PERMISSION_REQUEST_CODE = 999
    val PERMISSION_REQUEST_CODE_CAMERA = 1
    val PERMISSION_REQUEST_CODE_LOCATION = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        hideNavigationBar()
        AppUtils.logAdapterMessages(
            this@PermissionActivity,
            activity_tag,
            open_tag,
            PermissionActivity::class.java.simpleName.toString()
        )
        initData()
        allClicks()
    }

    private fun initData() {
        if(checkCameraPermissions()) {
            binding.tbCameraPer.isChecked = true
        }
        if(checkLocationPermissions()) {
            binding.tbLocationPer.isChecked = true
        }
    }

    private fun allClicks() {
        binding.apply {
            clCameraPer.setOnClickListener {
                tbCameraPer.toggle()
                if(checkCameraPermissions()) {
                    tbCameraPer.isChecked = true
                } else {
                    requestCameraPermission()
                }
            }
            clLocationPer.setOnClickListener {
                tbLocationPer.toggle()
                if (checkLocationPermissions()) {
                    tbLocationPer.isChecked = true
                } else {
                    requestLocationPermission()
                }

            }
            tvAllowAccess.setOnClickListener {
                if(checkCameraPermissions() && checkLocationPermissions()) {
                    startActivity(Intent(this@PermissionActivity, CameraActivity::class.java))
                    finish()
                }
            }
        }
    }

    private fun requestCameraPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.CAMERA
            ),
            PERMISSION_REQUEST_CODE_CAMERA
        )
    }

    private fun requestLocationPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
            ),
            PERMISSION_REQUEST_CODE_LOCATION
        )
    }

    private fun checkCameraPermissions(): Boolean {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            return true
        }
        return false
    }

    private fun checkLocationPermissions(): Boolean {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            return true
        }
        return false
    }


    /*override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            PERMISSION_REQUEST_CODE_CAMERA -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission was granted, you can now access the file
                    binding.tbCameraPer.isChecked = true
//                    Toast.makeText(this@PermissionActivity, getString(R.string.camera_access), Toast.LENGTH_SHORT).show()
                } else {
                    binding.tbCameraPer.isChecked = false
                }
            }
            PERMISSION_REQUEST_CODE_LOCATION -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    binding.tbLocationPer.isChecked = true
//                    Toast.makeText(this@PermissionActivity, getString(R.string.location_access), Toast.LENGTH_SHORT).show()
                } else {
                    binding.tbLocationPer.isChecked = false
                }
            }
        }
    }*/

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (permissions.isEmpty()) {
            return
        }
        var allPermissionsGranted = true
        if (grantResults.isNotEmpty()) {
            Log.w("msg", "onRequestPermissionsResult:1 " + grantResults.size)
            for (grantResult in grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    Log.w("msg", "onRequestPermissionsResult:2 ")
                    allPermissionsGranted = false
                    break
                }
            }
        }
        if (!allPermissionsGranted) {
            Log.w("msg", "onRequestPermissionsResult:3 ")

            var somePermissionsForeverDenied = false
            for (permission in permissions) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    binding.tbCameraPer.isChecked = false
                }
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    binding.tbLocationPer.isChecked = false
                }
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission!!)) {
                    //denied
                    Log.e("denied", permission)
                } else {
                    if (ActivityCompat.checkSelfPermission(
                            this,
                            permission
                        ) == PackageManager.PERMISSION_GRANTED
                    ) {
                        //allowed
                        Log.e("allowed", permission)
                    } else {
                        //set to never ask again
                        Log.e("set to never ask again", permission)
                        somePermissionsForeverDenied = true
                    }
                }
            }
            if (somePermissionsForeverDenied) {
                Log.w("msg", "onRequestPermissionsResult:4 ")
                val alertDialogBuilder = AlertDialog.Builder(this)
                alertDialogBuilder.setTitle("Permissions Required")
                    .setMessage(
                        "You have forcefully denied some of the required permissions " +
                                "for this action. Please open settings, go to permissions and allow them."
                    )
                    .setPositiveButton(
                        "Settings"
                    ) { dialog, which ->
                        val intent = Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", packageName, null)
                        )
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                    }
                    .setNegativeButton(
                        "Cancel"
                    ) { dialog, which -> }
                    .setCancelable(false)
                    .create()
                    .show()
            }
        } else {
            Log.w("msg", "onRequestPermissionsResult:5 ")
            when (requestCode) {
                PERMISSION_REQUEST_CODE_CAMERA -> {
                    if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        // Permission was granted, you can now access the file
                        binding.tbCameraPer.isChecked = true
//                    Toast.makeText(this@PermissionActivity, getString(R.string.camera_access), Toast.LENGTH_SHORT).show()
                    } else {
                        binding.tbCameraPer.isChecked = false
                    }
                }
                PERMISSION_REQUEST_CODE_LOCATION -> {
                    if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                        binding.tbLocationPer.isChecked = true
//                    Toast.makeText(this@PermissionActivity, getString(R.string.location_access), Toast.LENGTH_SHORT).show()
                    } else {
                        binding.tbLocationPer.isChecked = false
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if(checkCameraPermissions()){
            binding.tbCameraPer.isChecked = true
        }
        if(checkLocationPermissions()){
            binding.tbLocationPer.isChecked = true
        }
        if(checkCameraPermissions() && checkLocationPermissions()) {
            binding.tvAllowAccess.beVisible()
        } else {
            binding.tvAllowAccess.beGone()
        }
    }
}