package com.timestamp.gpsmap.adapters

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.timestamp.gpsmap.R
import com.timestamp.gpsmap.activities.CameraActivity
import com.timestamp.gpsmap.activities.TemplateEditActivity
import com.timestamp.gpsmap.extentions.baseConfig
import com.timestamp.gpsmap.extentions.beGone
import com.timestamp.gpsmap.extentions.beGoneIf
import com.timestamp.gpsmap.extentions.beVisible
import com.timestamp.gpsmap.extentions.beVisibleIf
import com.timestamp.gpsmap.helpers.TEMPLATE_POSITION
import com.timestamp.gpsmap.models.PageItem

class TemplateAdapter(
    private val context: Context,
    private val items: List<PageItem>,
    val onPageSelected: (pos: Int) -> Unit,
    //val listener : OnItemClick
) :
    RecyclerView.Adapter<TemplateAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val includedTemplate: FrameLayout = itemView.findViewById(R.id.includedTemplate)
//        val highlight: View? = itemView.findViewById(R.id.highlight)
//        val cvMap: CardView? = itemView.findViewById(R.id.cv_map)
//        val ivMapTemplate: ImageView? = itemView.findViewById(R.id.iv_map_template)
//        val tvAddress: TextView? = itemView.findViewById(R.id.tv_address_template)
//        val tvLatLong: TextView? = itemView.findViewById(R.id.tv_lat_long_template)
//        val tvPlusCode: TextView? = itemView.findViewById(R.id.tv_plus_code_template)
//        val tvNote: TextView? = itemView.findViewById(R.id.tv_note_template)
//        val tvTime: TextView? = itemView.findViewById(R.id.tv_time_template)
//        val tvTimeZone: TextView? = itemView.findViewById(R.id.tv_time_zone_template)
//        val ivLogo: ImageView? = itemView.findViewById(R.id.iv_logo_template)
//        val tvAltitude: TextView? = itemView.findViewById(R.id.tv_altitude_template)
//        val tvAccuracy: TextView? = itemView.findViewById(R.id.tv_accuracy_template)
//        val tvWeather: TextView? = itemView.findViewById(R.id.tv_weather_template)
//        val tvWind: TextView? = itemView.findViewById(R.id.tv_wind_template)
//        val tvPressure: TextView? = itemView.findViewById(R.id.tv_pressure_template)
//        val tvHumidity: TextView? = itemView.findViewById(R.id.tv_humidity_template)
    }

    //    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
//        val layoutInflater = LayoutInflater.from(parent.context)
//        val layoutResId = items[viewType].layoutResId
//        val itemView = layoutInflater.inflate(layoutResId, parent, false)
//        return ViewHolder(itemView)
//    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val itemView = layoutInflater.inflate(R.layout.template_item, parent, false)

        val holder = ViewHolder(itemView)

        LayoutInflater.from(context).inflate(items[viewType].layoutResId, holder.includedTemplate, true)

        return holder
    }

    var selectedPos = RecyclerView.NO_POSITION
    fun setCurrentItem(position: Int, isSelected: Boolean) {
        notifyItemChanged(selectedPos)
//        notifyItemChanged(selectedPos, "REMOVE_HIGHLIGHT")
        selectedPos = position
        notifyItemChanged(selectedPos)
//        notifyItemChanged(selectedPos, "ADD_HIGHLIGHT")
    }

//    override fun onBindViewHolder(
//        holder: ViewHolder,
//        position: Int,
//        payloads: MutableList<Any>
//    ) {
//
//        if (payloads.isNotEmpty()) {
//            if (payloads.contains("REMOVE_HIGHLIGHT")) {
//                holder.itemView.apply {
//                    findViewById<View>(R.id.highlight).beGone()
//                    //findViewById<View>(R.id.highlight).beGoneIf(selectedPos == position)
//                }
//            } else if (payloads.contains("ADD_HIGHLIGHT")) {
//                holder.itemView.apply {
//                    findViewById<View>(R.id.highlight).beVisible()
//                    //findViewById<View>(R.id.highlight).beVisibleIf(selectedPos == position)
//                }
//            }
//        } else {
//            onBindViewHolder(holder, position)
//        }
//    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        val pageItem = items[position]
        //LayoutInflater.from(context).inflate(pageItem.layoutResId, holder.includedTemplate, true)

        // You can perform any view setup here if needed
//        holder.itemView.findViewById<ImageView>(R.id.iv_edit_template).setOnClickListener {
//            context.startActivity(Intent(context, TemplateEditActivity::class.java).putExtra(TEMPLATE_POSITION, position))
//        }
        holder.itemView.setOnClickListener {
            onPageSelected.invoke(position)
        }
        //context.startActivity(Intent(context, TemplateEditActivity::class.java).putExtra(TEMPLATE_POSITION, position))
        //}
//        holder.itemView.findViewById<TextView>(R.id.iv_edit_template).beVisibleIf(context.baseConfig.templateSelected == position)
//        holder.itemView.findViewById<TextView>(R.id.tvSetTemplate).beGoneIf(context.baseConfig.templateSelected == position)
//        holder.itemView.findViewById<TextView>(R.id.tvSetTemplate).setOnClickListener {
//        holder.itemView.setOnClickListener {
//            onPageSelected.invoke(position)
//        }

        var fontSize = context.baseConfig.getTextSize(context)
        val typefaceCustom = when (context.baseConfig.stampFontStyle) {
            0 -> Typeface.createFromAsset(context.assets, "font/sourcecodepro_regular.ttf")
            1 -> Typeface.createFromAsset(context.assets, "font/robotocondensed.ttf")
            2 -> Typeface.createFromAsset(context.assets, "font/opensans.ttf")
            3 -> Typeface.createFromAsset(context.assets, "font/notosansdisplay.ttf")
            4 -> Typeface.createFromAsset(context.assets, "font/ibmplexsans.ttf")
            else -> Typeface.createFromAsset(context.assets, "font/sourcecodepro_regular.ttf")
        }

//        if (context.baseConfig.stampPosition == 0) {
//            holder.itemView.findViewById<View>(R.id.flTopBottom).alightParentTopIs(true)
//        } else {
//            holder.itemView.findViewById<View>(R.id.flTopBottom).alightParentBottomIs(true)
//        }

        //holder.itemView.findViewById<View>(R.id.includedTemplate).apply {
        holder.itemView.apply {

//            holder.itemView.apply {
//                findViewById<View>(R.id.highlight).beGone()
//                //findViewById<View>(R.id.highlight).beGoneIf(selectedPos == position)
//            }
            findViewById<View>(R.id.highlight).beVisibleIf(selectedPos == position)
            findViewById<CardView>(R.id.cv_map).beVisibleIf(context.baseConfig.showMap)
            findViewById<ImageView>(R.id.iv_map_template).setImageDrawable(context.baseConfig.getMapTypeImage(context))
            findViewById<TextView>(R.id.tv_address_template).apply {
                beVisibleIf(context.baseConfig.showAddress)
                text = CameraActivity.tempAddress
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_lat_long_template).apply {
                beVisibleIf(context.baseConfig.showLatLong)
                text = context.baseConfig.formatLatLong(
                    CameraActivity.tempLatitude,
                    CameraActivity.tempLongitude
                )
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_plus_code_template).apply {
                beVisibleIf(context.baseConfig.showPlusCode)
                text = "Plus code:" + context.baseConfig.stampPlusCode
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_note_template).apply {
                beVisibleIf(context.baseConfig.showNote)
                text = "Note: " + context.baseConfig.lastNote
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_time_template).apply {
                beVisibleIf(context.baseConfig.showDateTime)
                text = context.baseConfig.dateFormat
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_time_zone_template).apply {
                beVisibleIf(context.baseConfig.showTimeZone)
                text = context.baseConfig.getTimezoneText()
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
//            findViewById<ImageView>(R.id.iv_logo_template).apply {
//                beVisibleIf(context.baseConfig.showLogo)
//            }
            findViewById<TextView>(R.id.tv_altitude_template).apply {
                beVisibleIf(context.baseConfig.showAltitude)
                text = "Altitude:" + context.baseConfig.getAltitudeText(context)
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_accuracy_template).apply {
                beVisibleIf(context.baseConfig.showAccuracy)
                text = "Accuracy:" + context.baseConfig.getAccuracyText(context)
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_weather_template).apply {
                beVisibleIf(context.baseConfig.showWeather)
                text = "Weather:" + context.baseConfig.getWeatherText(context)
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_wind_template).apply {
                beVisibleIf(context.baseConfig.showWind)
                text = "Wind:" + context.baseConfig.getWindText(context)
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_pressure_template).apply {
                beVisibleIf(context.baseConfig.showPressure)
                text = "Pressure:" + context.baseConfig.getPressureText(context)
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
            findViewById<TextView>(R.id.tv_humidity_template).apply {
                beVisibleIf(context.baseConfig.showHumidity)
                text = "Humidity:" + CameraActivity.tempHumidity
                setTextColor(context.baseConfig.stampColor)
                typeface = typefaceCustom
                setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
            }
        }


    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun getItemViewType(position: Int): Int {
        // Return the viewType (position) as it corresponds to the layout resource ID
        return position
    }

    infix fun View.alightParentBottomIs(aligned: Boolean) {
        Log.w("msg", "alightParentBottomIs: " + aligned)
        val layoutParams = this.layoutParams as? RelativeLayout.LayoutParams
        if (aligned) {
            (this.layoutParams as? RelativeLayout.LayoutParams)?.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM)
        } else {
            (this.layoutParams as? RelativeLayout.LayoutParams)?.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, 0)
        }
        this.layoutParams = layoutParams
    }

    infix fun View.alightParentTopIs(aligned: Boolean) {
        Log.w("msg", "alightParentTopIs: " + aligned)
        val layoutParams = this.layoutParams as? RelativeLayout.LayoutParams
        if (aligned) {
            (this.layoutParams as? RelativeLayout.LayoutParams)?.addRule(RelativeLayout.ALIGN_PARENT_TOP)
        } else {
            (this.layoutParams as? RelativeLayout.LayoutParams)?.addRule(RelativeLayout.ALIGN_PARENT_TOP, 0)
        }
        this.layoutParams = layoutParams
    }

    /*override fun getItemId(position: Int): Long {
        return super.getItemId(position)
    }*/
}