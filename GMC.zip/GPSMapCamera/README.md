## Version:1.0.0[04-09-2025]
```
- Gps Map Camera
```
google.com, pub-2750800778809761, DIRECT, f08c47fec0942fa0