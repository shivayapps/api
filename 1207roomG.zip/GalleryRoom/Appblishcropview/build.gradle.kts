plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.jetbrains.kotlin.android)
//    alias(libs.plugins.maven.publish)
}

android {
    namespace = "com.appblish.cropview"
    compileSdk = 36

    defaultConfig {
         minSdk = 24
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    implementation("io.reactivex.rxjava2:rxjava:2.2.21")
}

//afterEvaluate {
//    publishing {
//        publications {
//            create<MavenPublication>("v1") {
//                groupId = "com.appblish.cropview"
//                artifactId = "v1"
//                version = "1.0.1"
//                artifact("./build/outputs/aar/Appblishcropview-release.aar")
//            }
//        }
//        repositories {
//            maven {
//                name = "GitLab"
//                url = uri("https://gitlab.com/api/v4/projects/79435441/packages/maven")
//                credentials {
//                    username = "AppblishCropview"
//                    password = "gldt-HH86nBjZhTuFevQ-xDy2"
//                }
//            }
//        }
//    }
//}