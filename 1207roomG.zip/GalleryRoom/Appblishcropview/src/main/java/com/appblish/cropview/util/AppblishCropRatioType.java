package com.appblish.cropview.util;

public enum AppblishCropRatioType {

    R1_1(1, 1, "1:1"),
    R4_5(4, 5, "4:5"),
    R9_16(9, 16, "9:16"),
    R4_3(4, 3, "4:3"),
    R16_6(16, 6, "16:6"),
    R16_8(16, 8, "16:8"),
    R16_5(16, 5, "16:5"),
    R2_3(2, 3, "2:3"),
    R5_7(5, 7, "5:7"),
    R5_4(5, 4, "5:4"),
    R3_4(3, 4, "3:4"),
    R3_2(3, 2, "3:2"),
    R1_2(1, 2, "1:2"),
    R16_9(16, 9, "16:9"),
    A4(10, 16, "A4"),
    A5(10, 16, "A5"),
    MOVIE(16, 7, "16:7");

    private final int width;
    private final int height;
    private final String ratioText;

    AppblishCropRatioType(int width, int height, String ratioText) {
        this.width = width;
        this.height = height;
        this.ratioText = ratioText;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public String getRatioText() {
        return ratioText;
    }
}
