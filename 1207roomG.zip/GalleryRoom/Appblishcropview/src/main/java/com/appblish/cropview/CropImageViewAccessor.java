package com.appblish.cropview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.RectF;
import android.net.Uri;
import android.view.animation.Interpolator;

import com.appblish.cropview.callback.CropCallback;
import com.appblish.cropview.callback.LoadCallback;
import com.appblish.cropview.callback.SaveCallback;
import com.appblish.cropview.util.CropMode;
import com.appblish.cropview.util.RotateDegrees;
import com.appblish.cropview.util.ShowMode;
 import io.reactivex.Completable;
import io.reactivex.Single;


public class CropImageViewAccessor {

    // Private instance of CropImageView to keep it encapsulated
    private final AppblishCropImageView appblishCropImageView;

    private CropImageViewAccessor(AppblishCropImageView appblishCropImageView) {
        this.appblishCropImageView = appblishCropImageView;
    }

    public static CropImageViewAccessor create(Context context) {
        AppblishCropImageView view = new AppblishCropImageView(context);
        return new CropImageViewAccessor(view);
    }

    public static CropImageViewAccessor wrap(AppblishCropImageView appblishCropImageView) {
        return new CropImageViewAccessor(appblishCropImageView);
    }

    // Delegated methods from CropImageView - all public methods are exposed here for controlled access

    public Bitmap getImageBitmap() {
        return appblishCropImageView.getImageBitmap();
    }

    public void setImageBitmap(Bitmap bitmap) {
        appblishCropImageView.setImageBitmap(bitmap);
    }

    public void setImageResource(int resId) {
        appblishCropImageView.setImageResource(resId);
    }

    public void setImageDrawable(android.graphics.drawable.Drawable drawable) {
        appblishCropImageView.setImageDrawable(drawable);
    }

    public void setImageURI(Uri uri) {
        appblishCropImageView.setImageURI(uri);
    }

    public void startLoad(Uri sourceUri, LoadCallback callback) {
        appblishCropImageView.startLoad(sourceUri, callback);
    }

    public void loadAsync(Uri sourceUri, LoadCallback callback) {
        appblishCropImageView.loadAsync(sourceUri, callback);
    }

    public void loadAsync(Uri sourceUri, boolean useThumbnail, RectF initialFrameRect, LoadCallback callback) {
        appblishCropImageView.loadAsync(sourceUri, useThumbnail, initialFrameRect, callback);
    }

    public Completable loadAsCompletable(Uri sourceUri) {
        return appblishCropImageView.loadAsCompletable(sourceUri);
    }

    public Completable loadAsCompletable(Uri sourceUri, boolean useThumbnail, RectF initialFrameRect) {
        return appblishCropImageView.loadAsCompletable(sourceUri, useThumbnail, initialFrameRect);
    }

    public AppblishLoadRequest load(Uri sourceUri) {
        return appblishCropImageView.load(sourceUri);
    }



    public void rotateImage(RotateDegrees degrees, int durationMillis) {
        appblishCropImageView.rotateImage(degrees, durationMillis);
    }

    public void rotateImage(RotateDegrees degrees) {
        appblishCropImageView.rotateImage(degrees);
    }

    public Bitmap getCroppedBitmap() {
        return appblishCropImageView.getCroppedBitmap();
    }

    public Bitmap getCircularBitmap(Bitmap square) {
        return appblishCropImageView.getCircularBitmap(square);
    }

    public void startCrop(Uri saveUri, CropCallback cropCallback, SaveCallback saveCallback) {
        appblishCropImageView.startCrop(saveUri, cropCallback, saveCallback);
    }

    public void cropAsync(Uri sourceUri, CropCallback cropCallback) {
        appblishCropImageView.cropAsync(sourceUri, cropCallback);
    }

    public void cropAsync(CropCallback cropCallback) {
        appblishCropImageView.cropAsync(cropCallback);
    }

    public Single<Bitmap> cropAsSingle(Uri sourceUri) {
        return appblishCropImageView.cropAsSingle(sourceUri);
    }

    public Single<Bitmap> cropAsSingle() {
        return appblishCropImageView.cropAsSingle();
    }

    public AppblishCropRequest crop(Uri sourceUri) {
        return appblishCropImageView.crop(sourceUri);
    }

    public void saveAsync(Uri saveUri, Bitmap image, SaveCallback saveCallback) {
        appblishCropImageView.saveAsync(saveUri, image, saveCallback);
    }

    public Single<Uri> saveAsSingle(Bitmap bitmap, Uri saveUri) {
        return appblishCropImageView.saveAsSingle(bitmap, saveUri);
    }

    public SaveRequest save(Bitmap bitmap) {
        return appblishCropImageView.save(bitmap);
    }

    public RectF getActualCropRect() {
        return appblishCropImageView.getActualCropRect();
    }

    public void setCropMode(CropMode mode, int durationMillis) {
        appblishCropImageView.setCropMode(mode, durationMillis);
    }

    public void setCropMode(CropMode mode) {
        appblishCropImageView.setCropMode(mode);
    }

    public void setCustomRatio(int ratioX, int ratioY, int durationMillis) {
        appblishCropImageView.setCustomRatio(ratioX, ratioY, durationMillis);
    }

    public void setCustomRatio(int ratioX, int ratioY) {
        appblishCropImageView.setCustomRatio(ratioX, ratioY);
    }

    public void setCustomRatioText(String ratioText) {
        appblishCropImageView.setCustomRatioText(ratioText);
    }

    public void setOverlayColor(int overlayColor) {
        appblishCropImageView.setOverlayColor(overlayColor);
    }

    public void setFrameColor(int frameColor) {
        appblishCropImageView.setFrameColor(frameColor);
    }

    public void setHandleColor(int handleColor) {
        appblishCropImageView.setHandleColor(handleColor);
    }

    public void setGuideColor(int guideColor) {
        appblishCropImageView.setGuideColor(guideColor);
    }

    public void setBackgroundColor(int bgColor) {
        appblishCropImageView.setBackgroundColor(bgColor);
    }

    public void setMinFrameSizeInDp(int minDp) {
        appblishCropImageView.setMinFrameSizeInDp(minDp);
    }

    public void setMinFrameSizeInPx(int minPx) {
        appblishCropImageView.setMinFrameSizeInPx(minPx);
    }

    public void setHandleSizeInDp(int handleDp) {
        appblishCropImageView.setHandleSizeInDp(handleDp);
    }

    public void setTouchPaddingInDp(int paddingDp) {
        appblishCropImageView.setTouchPaddingInDp(paddingDp);
    }

    public void setGuideShowMode( ShowMode mode) {
        appblishCropImageView.setGuideShowMode(mode);
    }

    public void setHandleShowMode( ShowMode mode) {
        appblishCropImageView.setHandleShowMode(mode);
    }

    public void setFrameStrokeWeightInDp(int weightDp) {
        appblishCropImageView.setFrameStrokeWeightInDp(weightDp);
    }

    public void setGuideStrokeWeightInDp(int weightDp) {
        appblishCropImageView.setGuideStrokeWeightInDp(weightDp);
    }

    public void setCropEnabled(boolean enabled) {
        appblishCropImageView.setCropEnabled(enabled);
    }

    public void setEnabled(boolean enabled) {
        appblishCropImageView.setEnabled(enabled);
    }

    public void setInitialFrameScale(float initialScale) {
        appblishCropImageView.setInitialFrameScale(initialScale);
    }

    public void setAnimationEnabled(boolean enabled) {
        appblishCropImageView.setAnimationEnabled(enabled);
    }

    public void setAnimationDuration(int durationMillis) {
        appblishCropImageView.setAnimationDuration(durationMillis);
    }

    public void setInterpolator(Interpolator interpolator) {
        appblishCropImageView.setInterpolator(interpolator);
    }

    public void setDebug(boolean debug) {
        appblishCropImageView.setDebug(debug);
    }

    public void setLoggingEnabled(boolean enabled) {
        appblishCropImageView.setLoggingEnabled(enabled);
    }

    public void setOutputWidth(int outputWidth) {
        appblishCropImageView.setOutputWidth(outputWidth);
    }

    public void setOutputHeight(int outputHeight) {
        appblishCropImageView.setOutputHeight(outputHeight);
    }

    public void setOutputMaxSize(int maxWidth, int maxHeight) {
        appblishCropImageView.setOutputMaxSize(maxWidth, maxHeight);
    }

    public void setCompressFormat(Bitmap.CompressFormat format) {
        appblishCropImageView.setCompressFormat(format);
    }

    public void setCompressQuality(int quality) {
        appblishCropImageView.setCompressQuality(quality);
    }

    public void setHandleShadowEnabled(boolean handleShadowEnabled) {
        appblishCropImageView.setHandleShadowEnabled(handleShadowEnabled);
    }

    public boolean isCropping() {
        return appblishCropImageView.isCropping();
    }

    public Uri getSourceUri() {
        return appblishCropImageView.getSourceUri();
    }

    public Uri getSaveUri() {
        return appblishCropImageView.getSaveUri();
    }

    public boolean isSaving() {
        return appblishCropImageView.isSaving();
    }

    /**
     * Get the underlying CropImageView instance (for advanced use, e.g., adding to layouts).
     * Note: This method is provided for cases where direct access is necessary (e.g., in XML layouts),
     * but it's recommended to use the accessor methods for safety.
     * @return The encapsulated CropImageView instance.
     */
    public AppblishCropImageView getCropImageView() {
        return appblishCropImageView;
    }

    // Additional security: You can add validation, logging, or access control here if needed.
    // For example, log method calls or restrict certain operations based on conditions.
}