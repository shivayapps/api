package com.appblish.cropview;

import android.graphics.Bitmap;
import android.net.Uri;

import com.appblish.cropview.callback.CropCallback;

import io.reactivex.Single;


public class AppblishCropRequest {

    private AppblishCropImageView appblishCropImageView;
    private Uri sourceUri;
    private int outputWidth;
    private int outputHeight;
    private int outputMaxWidth;
    private int outputMaxHeight;

    public AppblishCropRequest(AppblishCropImageView appblishCropImageView, Uri sourceUri) {
        this.appblishCropImageView = appblishCropImageView;
        this.sourceUri = sourceUri;
    }

    public AppblishCropRequest outputWidth(int outputWidth) {
        this.outputWidth = outputWidth;
        this.outputHeight = 0;
        return this;
    }

    public AppblishCropRequest outputHeight(int outputHeight) {
        this.outputHeight = outputHeight;
        this.outputWidth = 0;
        return this;
    }

    public AppblishCropRequest outputMaxWidth(int outputMaxWidth) {
        this.outputMaxWidth = outputMaxWidth;
        return this;
    }

    public AppblishCropRequest outputMaxHeight(int outputMaxHeight) {
        this.outputMaxHeight = outputMaxHeight;
        return this;
    }

    private void build() {
        if (outputWidth > 0) appblishCropImageView.setOutputWidth(outputWidth);
        if (outputHeight > 0) appblishCropImageView.setOutputHeight(outputHeight);
        appblishCropImageView.setOutputMaxSize(outputMaxWidth, outputMaxHeight);
    }

    public void execute(CropCallback cropCallback) {
        build();
        appblishCropImageView.cropAsync(sourceUri, cropCallback);
    }

    public Single<Bitmap> executeAsSingle() {
        build();
        return appblishCropImageView.cropAsSingle(sourceUri);
    }
}
