package com.appblish.cropview;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.RectF;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.animation.Interpolator;
import android.widget.FrameLayout;
import androidx.annotation.Nullable;


import com.appblish.cropview.callback.CropCallback;
import com.appblish.cropview.callback.LoadCallback;
import com.appblish.cropview.callback.SaveCallback;
import com.appblish.cropview.util.CropMode;
import com.appblish.cropview.util.RotateDegrees;
import com.appblish.cropview.util.ShowMode;

import io.reactivex.Completable;
import io.reactivex.Single;

public class AppblishCropView extends FrameLayout {

    private CropImageViewAccessor accessor;

    public AppblishCropView(Context context) {
        super(context);
        init(context, null);
    }

    public AppblishCropView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public AppblishCropView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context, @Nullable AttributeSet attrs) {
        accessor = CropImageViewAccessor.create(context);
        addView(accessor.getCropImageView());

        if (attrs != null) {
            TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.Appblish_CropImageView, 0, 0);
            try {
                // Crop mode
                int cropModeInt = ta.getInt(R.styleable.Appblish_CropImageView_appblish_crop_mode, 3);
                CropMode mode = CropMode.SQUARE;
                for (CropMode m : CropMode.values()) {
                    if (m.getId() == cropModeInt) {
                        mode = m;
                        break;
                    }
                }
                accessor.setCropMode(mode);

                // Colors
                accessor.setBackgroundColor(ta.getColor(R.styleable.Appblish_CropImageView_appblish_background_color, 0x00000000));
                accessor.setOverlayColor(ta.getColor(R.styleable.Appblish_CropImageView_appblish_overlay_color, 0xBB000000));
                accessor.setFrameColor(ta.getColor(R.styleable.Appblish_CropImageView_appblish_frame_color, 0xFFFFFFFF));
                accessor.setHandleColor(ta.getColor(R.styleable.Appblish_CropImageView_appblish_handle_color, 0xFFFFFFFF));
                accessor.setGuideColor(ta.getColor(R.styleable.Appblish_CropImageView_appblish_guide_color, 0xBBFFFFFF));

                // Show modes
                int guideShowModeInt = ta.getInt(R.styleable.Appblish_CropImageView_appblish_guide_show_mode, 1);
                ShowMode guideMode = ShowMode.SHOW_ALWAYS;
                for (ShowMode m : ShowMode.values()) {
                    if (m.getId() == guideShowModeInt) {
                        guideMode = m;
                        break;
                    }
                }
                accessor.setGuideShowMode(guideMode);

                int handleShowModeInt = ta.getInt(R.styleable.Appblish_CropImageView_appblish_handle_show_mode, 1);
                ShowMode handleMode = ShowMode.SHOW_ALWAYS;
                for (ShowMode m : ShowMode.values()) {
                    if (m.getId() == handleShowModeInt) {
                        handleMode = m;
                        break;
                    }
                }
                accessor.setHandleShowMode(handleMode);

                // Sizes (convert px to dp)
                float density = getResources().getDisplayMetrics().density;
                accessor.setHandleSizeInDp((int) (ta.getDimensionPixelSize(R.styleable.Appblish_CropImageView_appblish_handle_size, (int) (14 * density)) / density));
                accessor.setTouchPaddingInDp((int) (ta.getDimensionPixelSize(R.styleable.Appblish_CropImageView_appblish_touch_padding, 0) / density));
                accessor.setMinFrameSizeInDp((int) (ta.getDimensionPixelSize(R.styleable.Appblish_CropImageView_appblish_min_frame_size, (int) (50 * density)) / density));
                accessor.setFrameStrokeWeightInDp((int) (ta.getDimensionPixelSize(R.styleable.Appblish_CropImageView_appblish_frame_stroke_weight, (int) (1 * density)) / density));
                accessor.setGuideStrokeWeightInDp((int) (ta.getDimensionPixelSize(R.styleable.Appblish_CropImageView_appblish_guide_stroke_weight, (int) (1 * density)) / density));

                // Other settings
                accessor.setCropEnabled(ta.getBoolean(R.styleable.Appblish_CropImageView_appblish_crop_enabled, true));
                accessor.setInitialFrameScale(ta.getFloat(R.styleable.Appblish_CropImageView_appblish_initial_frame_scale, 1.0f));
                accessor.setAnimationEnabled(ta.getBoolean(R.styleable.Appblish_CropImageView_appblish_animation_enabled, true));
                accessor.setAnimationDuration(ta.getInt(R.styleable.Appblish_CropImageView_appblish_animation_duration, 100));
                accessor.setHandleShadowEnabled(ta.getBoolean(R.styleable.Appblish_CropImageView_appblish_handle_shadow_enabled, true));

            } finally {
                ta.recycle();
            }
        }
    }

    public CropImageViewAccessor getAccessor() {
        return accessor;
    }

    public void setCustomRatioText(String ratioText) {
        accessor.setCustomRatioText(ratioText);
    }

    // Direct access methods for all public methods in CropImageViewAccessor
    public Bitmap getImageBitmap() {
        return accessor.getImageBitmap();
    }

    public void setImageBitmap(Bitmap bitmap) {
        accessor.setImageBitmap(bitmap);
    }

    public void setImageResource(int resId) {
        accessor.setImageResource(resId);
    }

    public void setImageDrawable(android.graphics.drawable.Drawable drawable) {
        accessor.setImageDrawable(drawable);
    }


    public void setCropMode(CropMode mode) {
        accessor.setCropMode(mode);
    }


    public void setImageURI(Uri uri) {
        accessor.setImageURI(uri);
    }

    public void startLoad(Uri sourceUri, LoadCallback callback) {
        accessor.startLoad(sourceUri, callback);
    }

    public void loadAsync(Uri sourceUri, LoadCallback callback) {
        accessor.loadAsync(sourceUri, callback);
    }

    public void loadAsync(Uri sourceUri, boolean useThumbnail, RectF initialFrameRect, LoadCallback callback) {
        accessor.loadAsync(sourceUri, useThumbnail, initialFrameRect, callback);
    }

    public Completable loadAsCompletable(Uri sourceUri) {
        return accessor.loadAsCompletable(sourceUri);
    }

    public Completable loadAsCompletable(Uri sourceUri, boolean useThumbnail, RectF initialFrameRect) {
        return accessor.loadAsCompletable(sourceUri, useThumbnail, initialFrameRect);
    }

    public AppblishLoadRequest load(Uri sourceUri) {
        return accessor.load(sourceUri);
    }

    public void rotateImage(RotateDegrees degrees, int durationMillis) {
        accessor.rotateImage(degrees, durationMillis);
    }

    public void rotateImage(RotateDegrees degrees) {
        accessor.rotateImage(degrees);
    }

    public Bitmap getCroppedBitmap() {
        return accessor.getCroppedBitmap();
    }

    public Bitmap getCircularBitmap(Bitmap square) {
        return accessor.getCircularBitmap(square);
    }

    public void startCrop(Uri saveUri, CropCallback cropCallback, SaveCallback saveCallback) {
        accessor.startCrop(saveUri, cropCallback, saveCallback);
    }

    public void cropAsync(Uri sourceUri, CropCallback cropCallback) {
        accessor.cropAsync(sourceUri, cropCallback);
    }

    public void cropAsync(CropCallback cropCallback) {
        accessor.cropAsync(cropCallback);
    }

    public Single<Bitmap> cropAsSingle(Uri sourceUri) {
        return accessor.cropAsSingle(sourceUri);
    }

    public Single<Bitmap> cropAsSingle() {
        return accessor.cropAsSingle();
    }

    public AppblishCropRequest crop(Uri sourceUri) {
        return accessor.crop(sourceUri);
    }

    public void saveAsync(Uri saveUri, Bitmap image, SaveCallback saveCallback) {
        accessor.saveAsync(saveUri, image, saveCallback);
    }

    public Single<Uri> saveAsSingle(Bitmap bitmap, Uri saveUri) {
        return accessor.saveAsSingle(bitmap, saveUri);
    }

    public SaveRequest save(Bitmap bitmap) {
        return accessor.save(bitmap);
    }

    public RectF getActualCropRect() {
        return accessor.getActualCropRect();
    }



    public void setCustomRatio(int ratioX, int ratioY, int durationMillis) {
        accessor.setCustomRatio(ratioX, ratioY, durationMillis);
    }

    public void setCustomRatio(int ratioX, int ratioY) {
        accessor.setCustomRatio(ratioX, ratioY);
    }



    public void setOverlayColor(int overlayColor) {
        accessor.setOverlayColor(overlayColor);
    }

    public void setFrameColor(int frameColor) {
        accessor.setFrameColor(frameColor);
    }

    public void setHandleColor(int handleColor) {
        accessor.setHandleColor(handleColor);
    }

    public void setGuideColor(int guideColor) {
        accessor.setGuideColor(guideColor);
    }

    public void setBackgroundColor(int bgColor) {
        accessor.setBackgroundColor(bgColor);
    }

    public void setMinFrameSizeInDp(int minDp) {
        accessor.setMinFrameSizeInDp(minDp);
    }

    public void setMinFrameSizeInPx(int minPx) {
        accessor.setMinFrameSizeInPx(minPx);
    }

    public void setHandleSizeInDp(int handleDp) {
        accessor.setHandleSizeInDp(handleDp);
    }

    public void setTouchPaddingInDp(int paddingDp) {
        accessor.setTouchPaddingInDp(paddingDp);
    }



    public void setFrameStrokeWeightInDp(int weightDp) {
        accessor.setFrameStrokeWeightInDp(weightDp);
    }

    public void setGuideStrokeWeightInDp(int weightDp) {
        accessor.setGuideStrokeWeightInDp(weightDp);
    }

    public void setCropEnabled(boolean enabled) {
        accessor.setCropEnabled(enabled);
    }

    public void setEnabled(boolean enabled) {
        accessor.setEnabled(enabled);
    }

    public void setInitialFrameScale(float initialScale) {
        accessor.setInitialFrameScale(initialScale);
    }

    public void setAnimationEnabled(boolean enabled) {
        accessor.setAnimationEnabled(enabled);
    }

    public void setAnimationDuration(int durationMillis) {
        accessor.setAnimationDuration(durationMillis);
    }

    public void setInterpolator(Interpolator interpolator) {
        accessor.setInterpolator(interpolator);
    }

    public void setDebug(boolean debug) {
        accessor.setDebug(debug);
    }

    public void setLoggingEnabled(boolean enabled) {
        accessor.setLoggingEnabled(enabled);
    }

    public void setOutputWidth(int outputWidth) {
        accessor.setOutputWidth(outputWidth);
    }

    public void setOutputHeight(int outputHeight) {
        accessor.setOutputHeight(outputHeight);
    }

    public void setOutputMaxSize(int maxWidth, int maxHeight) {
        accessor.setOutputMaxSize(maxWidth, maxHeight);
    }

    public void setCompressFormat(Bitmap.CompressFormat format) {
        accessor.setCompressFormat(format);
    }

    public void setCompressQuality(int quality) {
        accessor.setCompressQuality(quality);
    }

    public void setHandleShadowEnabled(boolean handleShadowEnabled) {
        accessor.setHandleShadowEnabled(handleShadowEnabled);
    }

    public boolean isCropping() {
        return accessor.isCropping();
    }

    public Uri getSourceUri() {
        return accessor.getSourceUri();
    }

    public Uri getSaveUri() {
        return accessor.getSaveUri();
    }

    public boolean isSaving() {
        return accessor.isSaving();
    }

}