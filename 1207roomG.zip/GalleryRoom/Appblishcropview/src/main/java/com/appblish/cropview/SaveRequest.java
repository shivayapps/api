package com.appblish.cropview;

import android.graphics.Bitmap;
import android.net.Uri;

import com.appblish.cropview.callback.SaveCallback;

import io.reactivex.Single;

public class SaveRequest {

    private AppblishCropImageView appblishCropImageView;
    private Bitmap image;
    private Bitmap.CompressFormat compressFormat;
    private int compressQuality = -1;

    public SaveRequest(AppblishCropImageView appblishCropImageView, Bitmap image) {
        this.appblishCropImageView = appblishCropImageView;
        this.image = image;
    }

    public SaveRequest compressFormat(Bitmap.CompressFormat compressFormat) {
        this.compressFormat = compressFormat;
        return this;
    }

    public SaveRequest compressQuality(int compressQuality) {
        this.compressQuality = compressQuality;
        return this;
    }

    private void build() {
        if (compressFormat != null) {
            appblishCropImageView.setCompressFormat(compressFormat);
        }
        if (compressQuality >= 0) {
            appblishCropImageView.setCompressQuality(compressQuality);
        }
    }

    public void execute(Uri saveUri, SaveCallback callback) {
        build();
        appblishCropImageView.saveAsync(saveUri, image, callback);
    }

    public Single<Uri> executeAsSingle(Uri saveUri) {
        build();
        return appblishCropImageView.saveAsSingle(image, saveUri);
    }
}
