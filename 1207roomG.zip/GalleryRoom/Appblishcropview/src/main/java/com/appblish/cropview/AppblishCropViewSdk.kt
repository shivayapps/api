package com.appblish.cropview

import android.graphics.Bitmap
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.net.Uri
import android.view.animation.Interpolator
import com.appblish.cropview.callback.CropCallback
import com.appblish.cropview.callback.LoadCallback
import com.appblish.cropview.callback.SaveCallback
import com.appblish.cropview.util.CropMode
import com.appblish.cropview.util.RotateDegrees
import io.reactivex.Completable
import io.reactivex.Single

object AppblishCropViewSdk {

    private var view: AppblishCropView? = null

    fun init(appblishCropView: AppblishCropView) {
        view = appblishCropView
    }

    private fun v(): AppblishCropView {
        return view ?: throw IllegalStateException("AppblishCropViewSdk not initialized")
    }

    /* -------- Image -------- */

    fun getImageBitmap(): Bitmap? = v().imageBitmap

    fun setImageBitmap(bitmap: Bitmap) {
        v().setImageBitmap(bitmap)
    }

    fun setImageResource(resId: Int) {
        v().setImageResource(resId)
    }

    fun setCropMode(mode: CropMode?){
        v().setCropMode(mode)
    }

    fun setImageDrawable(drawable: Drawable) {
        v().setImageDrawable(drawable)
    }

    fun setImageURI(uri: Uri) {
        v().setImageURI(uri)
    }

    /* -------- Load -------- */

    fun startLoad(uri: Uri, callback: LoadCallback) {
        v().startLoad(uri, callback)
    }

    fun loadAsync(uri: Uri, callback: LoadCallback) {
        v().loadAsync(uri, callback)
    }

    fun loadAsync(
        uri: Uri,
        useThumbnail: Boolean,
        initialFrameRect: RectF?,
        callback: LoadCallback
    ) {
        v().loadAsync(uri, useThumbnail, initialFrameRect, callback)
    }

    fun loadAsCompletable(uri: Uri): Completable =
        v().loadAsCompletable(uri)

    fun loadAsCompletable(
        uri: Uri,
        useThumbnail: Boolean,
        initialFrameRect: RectF?
    ): Completable =
        v().loadAsCompletable(uri, useThumbnail, initialFrameRect)

    fun load(uri: Uri): AppblishLoadRequest =
        v().load(uri)

    /* -------- Rotate -------- */

    fun rotateImage(degrees: RotateDegrees, durationMillis: Int) {
        v().rotateImage(degrees, durationMillis)
    }

    fun rotateImage(degrees: RotateDegrees) {
        v().rotateImage(degrees)
    }

    fun rotateM90D() {
        v().rotateImage(RotateDegrees.ROTATE_M90D)
    }

    fun rotate90D() {
        v().rotateImage(RotateDegrees.ROTATE_90D)
    }

    /* -------- Crop -------- */

    fun getCroppedBitmap(): Bitmap =
        v().getCroppedBitmap()

    fun getCircularBitmap(square: Bitmap): Bitmap =
        v().getCircularBitmap(square)

    fun startCrop(
        saveUri: Uri,
        cropCallback: CropCallback,
        saveCallback: SaveCallback
    ) {
        v().startCrop(saveUri, cropCallback, saveCallback)
    }

    fun cropAsync(uri: Uri, callback: CropCallback) {
        v().cropAsync(uri, callback)
    }

    fun cropAsync(callback: CropCallback) {
        v().cropAsync(callback)
    }

    fun cropAsSingle(uri: Uri): Single<Bitmap> =
        v().cropAsSingle(uri)

    fun cropAsSingle(): Single<Bitmap> =
        v().cropAsSingle()

    fun crop(uri: Uri): AppblishCropRequest =
        v().crop(uri)

    /* -------- Save -------- */

    fun saveAsync(uri: Uri, bitmap: Bitmap, callback: SaveCallback) {
        v().saveAsync(uri, bitmap, callback)
    }

    fun saveAsSingle(bitmap: Bitmap, uri: Uri): Single<Uri> =
        v().saveAsSingle(bitmap, uri)

    fun save(bitmap: Bitmap): SaveRequest =
        v().save(bitmap)

    /* -------- Config -------- */

    fun setCustomRatioText(text: String) {
        v().setCustomRatioText(text)
    }

    fun setCustomRatio(x: Int, y: Int, durationMillis: Int) {
        v().setCustomRatio(x, y, durationMillis)
    }

    fun setCustomRatio(x: Int, y: Int) {
        v().setCustomRatio(x, y)
    }

    fun setOverlayColor(color: Int) = v().setOverlayColor(color)
    fun setFrameColor(color: Int) = v().setFrameColor(color)
    fun setHandleColor(color: Int) = v().setHandleColor(color)
    fun setGuideColor(color: Int) = v().setGuideColor(color)
    fun setBackgroundColor(color: Int) = v().setBackgroundColor(color)

    fun setMinFrameSizeInDp(dp: Int) = v().setMinFrameSizeInDp(dp)
    fun setMinFrameSizeInPx(px: Int) = v().setMinFrameSizeInPx(px)
    fun setHandleSizeInDp(dp: Int) = v().setHandleSizeInDp(dp)
    fun setTouchPaddingInDp(dp: Int) = v().setTouchPaddingInDp(dp)

    fun setFrameStrokeWeightInDp(dp: Int) = v().setFrameStrokeWeightInDp(dp)
    fun setGuideStrokeWeightInDp(dp: Int) = v().setGuideStrokeWeightInDp(dp)

    fun setCropEnabled(enabled: Boolean) = v().setCropEnabled(enabled)

    //    fun setEnabled(enabled: Boolean) = v().isEnabled = enabled
    fun setInitialFrameScale(scale: Float) = v().setInitialFrameScale(scale)
    fun setAnimationEnabled(enabled: Boolean) = v().setAnimationEnabled(enabled)
    fun setAnimationDuration(duration: Int) = v().setAnimationDuration(duration)
    fun setInterpolator(interpolator: Interpolator) = v().setInterpolator(interpolator)

    fun setDebug(debug: Boolean) = v().setDebug(debug)
    fun setLoggingEnabled(enabled: Boolean) = v().setLoggingEnabled(enabled)

    fun setOutputWidth(width: Int) = v().setOutputWidth(width)
    fun setOutputHeight(height: Int) = v().setOutputHeight(height)
    fun setOutputMaxSize(maxWidth: Int, maxHeight: Int) =
        v().setOutputMaxSize(maxWidth, maxHeight)

    fun setCompressFormat(format: Bitmap.CompressFormat) =
        v().setCompressFormat(format)

    fun setCompressQuality(quality: Int) =
        v().setCompressQuality(quality)

    fun setHandleShadowEnabled(enabled: Boolean) =
        v().setHandleShadowEnabled(enabled)

    /* -------- State -------- */

    fun isCropping(): Boolean = v().isCropping
    fun isSaving(): Boolean = v().isSaving
    fun getSourceUri(): Uri? = v().sourceUri
    fun getSaveUri(): Uri? = v().saveUri
    fun getActualCropRect(): RectF = v().actualCropRect
}