package com.appblish.cropview.callback;

public interface Callback {
    void onError(Throwable e);
}
