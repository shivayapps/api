package com.appblish.cropview;

import android.graphics.RectF;
import android.net.Uri;

import com.appblish.cropview.callback.LoadCallback;

import io.reactivex.Completable;

public class AppblishLoadRequest {

    private float initialFrameScale;
    private RectF initialFrameRect;
    private boolean useThumbnail;
    private AppblishCropImageView appblishCropImageView;
    private Uri sourceUri;

    public AppblishLoadRequest(AppblishCropImageView appblishCropImageView, Uri sourceUri) {
        this.appblishCropImageView = appblishCropImageView;
        this.sourceUri = sourceUri;
    }

    public AppblishLoadRequest initialFrameScale(float initialFrameScale) {
        this.initialFrameScale = initialFrameScale;
        return this;
    }

    public AppblishLoadRequest initialFrameRect(RectF initialFrameRect) {
        this.initialFrameRect = initialFrameRect;
        return this;
    }

    public AppblishLoadRequest useThumbnail(boolean useThumbnail) {
        this.useThumbnail = useThumbnail;
        return this;
    }

    public void execute(LoadCallback callback) {
        if (initialFrameRect == null) {
            appblishCropImageView.setInitialFrameScale(initialFrameScale);
        }
        appblishCropImageView.loadAsync(sourceUri, useThumbnail, initialFrameRect, callback);
    }

    public Completable executeAsCompletable() {
        if (initialFrameRect == null) {
            appblishCropImageView.setInitialFrameScale(initialFrameScale);
        }
        return appblishCropImageView.loadAsCompletable(sourceUri, useThumbnail, initialFrameRect);
    }
}
