package com.appblish.cropview.callback;

public interface LoadCallback extends Callback {
    void onSuccess();
}
