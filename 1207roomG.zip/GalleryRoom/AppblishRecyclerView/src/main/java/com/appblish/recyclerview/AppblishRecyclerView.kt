package com.appblish.recyclerview

import android.content.Context
import android.util.AttributeSet
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator

open class AppblishRecyclerView : RecyclerView {
    constructor(context: Context) : super(context) {
        optimize()
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        optimize()
    }

    private fun optimize() {
        // Improves view reuse
        setItemViewCacheSize(30)
        (itemAnimator as? SimpleItemAnimator)
            ?.supportsChangeAnimations = false
        itemAnimator = null
        recycledViewPool.setMaxRecycledViews(0, 30)
    }


    fun isClassPresentAtRuntime(className: String): Boolean {
        return try {
            Class.forName(className, false, javaClass.classLoader)
            true
        } catch (e: Throwable) {
            false
        }
    }
}
