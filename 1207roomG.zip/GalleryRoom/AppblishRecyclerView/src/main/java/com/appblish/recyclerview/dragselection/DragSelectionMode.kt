package com.appblish.recyclerview.dragselection

import androidx.annotation.Keep

@Keep
enum class DragSelectionMode {
    /** Grid-safe linear range selection (recommended) */
    RANGE,

    /** Touch-based selection (select what finger passes over) */
    TOUCH
}