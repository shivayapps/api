package com.appblish.recyclerview.dragselection

import android.view.GestureDetector
import android.view.MotionEvent
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class FastDragSelection<T>(
    private val rv: RecyclerView,
    private val adapter: BaseSelectableAdapter<T, *>
) : RecyclerView.OnItemTouchListener {

    private var dragging = false
    private var lastTouchedPos = RecyclerView.NO_POSITION

    // RANGE mode state
    private var startPos = RecyclerView.NO_POSITION
    private var lastRange: IntRange? = null

    // Auto-scroll state
    private var autoScrollDy = 0
    private var autoScrollActive = false

    private val detector = GestureDetector(
        rv.context,
        object : GestureDetector.SimpleOnGestureListener() {

            override fun onLongPress(e: MotionEvent) {
                if (!adapter.isSelectionEnabled()) return
                val child = rv.findChildViewUnder(e.x, e.y) ?: return
                val pos = rv.getChildAdapterPosition(child)
                if (pos == RecyclerView.NO_POSITION) return

                dragging = true

                when (adapter.getDragSelectionMode()) {
                    DragSelectionMode.RANGE -> {
                        startPos = pos
                        lastRange = pos..pos
                        adapter.selectFromDrag(pos)
                    }

                    DragSelectionMode.TOUCH -> {
                        adapter.toggleFromDrag(pos)
                    }
                }
            }
        }
    )

    override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
        detector.onTouchEvent(e)
        return dragging
    }

    override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {
        if (!adapter.isSelectionEnabled()) {
            reset()
            return
        }


        if (!dragging) {
            reset()
            return
        }

        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                if (rv.layoutManager is GridLayoutManager) {
                    val child = rv.findChildViewUnder(e.x, e.y) ?: return
                    val pos = rv.getChildAdapterPosition(child)
                    if (pos == RecyclerView.NO_POSITION) return

                    when (adapter.getDragSelectionMode()) {
                        DragSelectionMode.RANGE -> updateRange(pos)
                        DragSelectionMode.TOUCH -> adapter.toggleFromDrag(pos)
                    }

                    updateAutoScroll(e.y)
                } else {
                    val pos = getAdapterPositionFromY(e.y)
                    if (pos != RecyclerView.NO_POSITION) {
                        lastTouchedPos = pos
                        when (adapter.getDragSelectionMode()) {
                            DragSelectionMode.RANGE -> updateRange(pos)
                            DragSelectionMode.TOUCH -> adapter.toggleFromDrag(pos)
                        }
                    }
                    updateAutoScroll(e.y)
                }

            }

            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> reset()
        }
    }

    // --------------------------------------------------
    // RANGE MODE LOGIC
    // --------------------------------------------------

    private fun updateRange(currentPos: Int) {
        if (rv.layoutManager is GridLayoutManager) {

            if (startPos == RecyclerView.NO_POSITION) return

            val newRange =
                if (currentPos >= startPos) startPos..currentPos
                else currentPos..startPos

            val oldRange = lastRange

            newRange.forEach { pos ->
                if (oldRange == null || !oldRange.contains(pos)) {
                    adapter.selectFromDrag(pos)
                }
            }

            oldRange?.forEach { pos ->
                if (!newRange.contains(pos)) {
                    adapter.toggleSelection(pos)
                }
            }

            lastRange = newRange

        } else {

            if (startPos == RecyclerView.NO_POSITION) return

            val newRange =
                if (currentPos >= startPos) startPos..currentPos
                else currentPos..startPos

            val oldRange = lastRange ?: IntRange.EMPTY

            // Select new items
            for (pos in newRange) {
                if (!oldRange.contains(pos)) {
                    adapter.selectFromDrag(pos)
                }
            }

            // Deselect removed items
            for (pos in oldRange) {
                if (!newRange.contains(pos)) {
                    adapter.deselectFromDrag(pos) // 🔥 explicit
                }
            }

            lastRange = newRange
        }

    }

    // --------------------------------------------------
    // 🔥 SMOOTH AUTO-SCROLL (FIX)
    // --------------------------------------------------

    private fun updateAutoScroll(y: Float) {
        val height = rv.height
        val edge = height * 0.25f

        autoScrollDy = when {
            y < edge -> {
                val ratio = (edge - y) / edge
                (-ratio * MAX_SCROLL_SPEED).toInt()
            }

            y > height - edge -> {
                val ratio = (y - (height - edge)) / edge
                (ratio * MAX_SCROLL_SPEED).toInt()
            }

            else -> 0
        }

        if (autoScrollDy != 0 && !autoScrollActive) {
            autoScrollActive = true
            rv.postOnAnimation(autoScrollRunnable)
        }
    }

    private val autoScrollRunnable = object : Runnable {
        override fun run() {
            if (!dragging || autoScrollDy == 0) {
                autoScrollActive = false
                return
            }
            rv.scrollBy(0, autoScrollDy)
            rv.postOnAnimation(this)
        }
    }

    // --------------------------------------------------
    // RESET
    // --------------------------------------------------

    fun reset() {
        dragging = false
        startPos = RecyclerView.NO_POSITION
        lastRange = null
        autoScrollDy = 0
        autoScrollActive = false
    }

    override fun onRequestDisallowInterceptTouchEvent(
        disallowIntercept: Boolean
    ) = Unit

    companion object {
        private const val MAX_SCROLL_SPEED = 60 // px per frame (tuned)
    }

    private fun getAdapterPositionFromY(y: Float): Int {
        val lm = rv.layoutManager ?: return RecyclerView.NO_POSITION

        val view = rv.findChildViewUnder(rv.width / 2f, y)
            ?: return when (lm) {
                is LinearLayoutManager -> {
                    if (y < 0) lm.findFirstVisibleItemPosition()
                    else lm.findLastVisibleItemPosition()
                }

                else -> RecyclerView.NO_POSITION
            }

        return rv.getChildAdapterPosition(view)
    }
}


