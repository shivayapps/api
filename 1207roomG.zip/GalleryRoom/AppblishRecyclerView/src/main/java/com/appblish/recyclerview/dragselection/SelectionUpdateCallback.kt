package com.appblish.recyclerview.dragselection

interface SelectionUpdateCallback {

    /** Called whenever selected count changes */
    fun onSelectionCountChanged(
        selectedCount: Int,
        selectionActive: Boolean
    )
}
