package com.appblish.recyclerview.dragselection


import android.view.View
import androidx.recyclerview.widget.RecyclerView

abstract class BaseSelectableAdapter<T, VH : RecyclerView.ViewHolder>(
    val recyclerView: RecyclerView,
    val dragSelectionMode: DragSelectionMode
) : RecyclerView.Adapter<VH>() {

    // ------------------------------------------------
    // Internal state
    // ------------------------------------------------
    private var selectionCallback: SelectionUpdateCallback? = null

    private val selectedKeys = LinkedHashSet<Long>()
    private var selectionMode = false
    val fastScroller = FastDragSelection(recyclerView, this)

    init {
        setHasStableIds(true)
        recyclerView.addOnItemTouchListener(
            fastScroller
        )
    }

    // ------------------------------------------------
    // REQUIRED FROM CHILD
    // ------------------------------------------------

    abstract fun getItemAt(position: Int): T?
    abstract fun getItemKey(item: T): Long
    abstract fun isSelectable(item: T): Boolean
    abstract fun isHeader(position: Int): Boolean
    abstract fun isSelectionEnabled(): Boolean

    /** Bind normal content */
    abstract fun bindItem(holder: VH, item: T, position: Int)

    /** Bind selection UI (activated / checkbox / overlay) */
    abstract fun bindSelection(holder: VH, item: T, position: Int, selected: Boolean)

    /** Open item when not in selection mode */
    abstract fun onItemOpen(item: T, position: Int, view: View)
    abstract fun onSelectionModeUpdate()

    // ------------------------------------------------
    // Selection mode
    // ------------------------------------------------

    fun isSelectionActive(): Boolean = selectionMode

    private fun enterSelectionMode() {
        if (!selectionMode) {
            onSelectionModeUpdate()
        }
        selectionMode = true
    }

    fun setSelectionUpdateCallback(callback: SelectionUpdateCallback?) {
        this.selectionCallback = callback
    }

    fun enableSelectionMode() {
        selectionMode = true
        selectedKeys.clear()
        notifyItemRangeChanged(0, itemCount, PAYLOAD)
        notifySelectionChanged()
        onSelectionModeUpdate()// 🔥
    }

    fun clearSelectionAndExit() {
        selectionMode = false
        selectedKeys.clear()
        notifyItemRangeChanged(0, itemCount, PAYLOAD)
        notifySelectionChanged()
        onSelectionModeUpdate()// 🔥
        fastScroller.reset()
    }

    fun toggleSelectionAll() {
        if (isAllSelectedItems()) {
            unselectAllItems()
        } else {
            selectAllItems()
        }
    }

    // ------------------------------------------------
    // Section helpers (BASE OWNED)
    // ------------------------------------------------

    protected fun getSectionRange(headerPosition: Int): IntRange? {
        if (!isHeader(headerPosition)) return null

        val start = headerPosition + 1
        if (start >= itemCount) return null

        var end = start
        while (end < itemCount && !isHeader(end)) {
            end++
        }
        return start until end
    }

    fun isSectionFullySelected(headerPosition: Int): Boolean {
        val range = getSectionRange(headerPosition) ?: return false
        return !range.isEmpty() && range.all { isItemSelected(it) }
    }

    // ------------------------------------------------
    // Click handling (adapter owned)
    // ------------------------------------------------

    private fun handleClick(holder: VH) {
        val pos = holder.bindingAdapterPosition
        if (pos == RecyclerView.NO_POSITION) return

        // Header click
        if (isHeader(pos)) {
            if (selectionMode) {
                toggleSectionSelection(pos)
            }
            return
        }

        val item = getItemAt(pos) ?: return

        if (selectionMode) {
            toggleSelection(pos)
        } else {
            onItemOpen(item, pos, holder.itemView)
        }
    }

    // ------------------------------------------------
    // Selection operations
    // ------------------------------------------------

    fun toggleSelection(position: Int) {
        val item = getItemAt(position) ?: return
        if (!isSelectable(item)) return

        enterSelectionMode()

        val key = getItemKey(item)
        val selected =
            if (selectedKeys.contains(key)) {
                selectedKeys.remove(key)
                false
            } else {
                selectedKeys.add(key)
                true
            }

        notifyItemChanged(position, PAYLOAD)
        notifyHeaderForChild(position)
        notifySelectionChanged()   // 🔥
    }

    internal fun selectFromDrag(position: Int) {
        val item = getItemAt(position) ?: return
        if (!isSelectable(item)) return

        enterSelectionMode()

        if (selectedKeys.add(getItemKey(item))) {
            notifyItemChanged(position, PAYLOAD)
            notifyHeaderForChild(position)
            notifySelectionChanged()   // 🔥

        }
    }

    // ------------------------------------------------
    // Section selection (HEADER)
    // ------------------------------------------------

    fun toggleSectionSelection(headerPosition: Int) {
        val range = getSectionRange(headerPosition) ?: return

        val shouldSelect = range.any { !isItemSelected(it) }
        enterSelectionMode()

        var changed = false

        for (i in range) {
            val item = getItemAt(i) ?: continue
            if (!isSelectable(item)) continue

            val key = getItemKey(item)
            val didChange =
                if (shouldSelect) selectedKeys.add(key)
                else selectedKeys.remove(key)

            if (didChange) {
                notifyItemChanged(i, PAYLOAD)
                changed = true
            }
        }

        notifyItemChanged(headerPosition, PAYLOAD)

        if (changed) notifySelectionChanged()   // 🔥
    }


    fun selectAllItems() {
        enterSelectionMode()
        var changed = false

        for (i in 0 until itemCount) {
            val item = getItemAt(i) ?: continue
            if (!isSelectable(item)) continue

            if (selectedKeys.add(getItemKey(item))) {
                notifyItemChanged(i, PAYLOAD)
                changed = true
            }
        }

        if (changed) notifySelectionChanged()   // 🔥
    }

    fun unselectAllItems() {
        if (selectedKeys.isEmpty()) return

        selectedKeys.clear()
        notifyItemRangeChanged(0, itemCount, PAYLOAD)
        notifySelectionChanged()   // 🔥
    }

    fun isAllSelectedItems(): Boolean {
        var selectableCount = 0

        for (i in 0 until itemCount) {
            val item = getItemAt(i) ?: continue
            if (!isSelectable(item)) continue

            selectableCount++
        }

        return selectableCount > 0 && selectedKeys.size == selectableCount
    }

    // ------------------------------------------------
    // Selected item helpers
    // ------------------------------------------------

    fun getSelectedItems(): List<T> =
        (0 until itemCount)
            .mapNotNull { getItemAt(it) }
            .filter { isSelectable(it) && selectedKeys.contains(getItemKey(it)) }

    fun getSelectedCount(): Int = selectedKeys.size

    fun isItemSelected(position: Int): Boolean {
        val item = getItemAt(position) ?: return false
        return isSelectable(item) && selectedKeys.contains(getItemKey(item))
    }

    internal fun getDragSelectionMode(): DragSelectionMode =
        dragSelectionMode

    internal fun toggleFromDrag(position: Int) {
        val item = getItemAt(position) ?: return
        if (!isSelectable(item)) return

        enterSelectionMode()

        val key = getItemKey(item)
        val changed =
            if (selectedKeys.contains(key)) {
                selectedKeys.remove(key)
                true
            } else {
                selectedKeys.add(key)
                true
            }

        if (changed) {
            notifyItemChanged(position, PAYLOAD)
            notifyHeaderForChild(position)
            notifySelectionChanged()
        }
    }

    // ------------------------------------------------
    // Header update helper
    // ------------------------------------------------

    private fun notifyHeaderForChild(childPosition: Int) {
        var headerPos = childPosition - 1
        while (headerPos >= 0 && !isHeader(headerPos)) {
            headerPos--
        }
        if (headerPos >= 0) {
            notifyItemChanged(headerPos, PAYLOAD)
        }
    }

    private fun notifySelectionChanged() {
        selectionCallback?.onSelectionCountChanged(
            selectedKeys.size,
            selectionMode
        )
    }

    // ------------------------------------------------
    // RecyclerView binding
    // ------------------------------------------------

    override fun getItemId(position: Int): Long =
        getItemKey(getItemAt(position)!!)

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItemAt(position) ?: return

        holder.itemView.setOnClickListener {
            handleClick(holder)
        }

        bindItem(holder, item, position)

        val selected =
            if (isHeader(position)) isSectionFullySelected(position)
            else isItemSelected(position)

        bindSelection(holder, item, position, selected)
    }

    override fun onBindViewHolder(
        holder: VH,
        position: Int,
        payloads: MutableList<Any>
    ) {
        val item = getItemAt(position) ?: return
        if (payloads.contains(PAYLOAD)) {
            val selected =
                if (isHeader(position)) isSectionFullySelected(position)
                else isItemSelected(position)
            bindSelection(holder, item, position, selected)
        } else {
            onBindViewHolder(holder, position)
        }
    }

    companion object {
        private const val PAYLOAD = "selection_payload"
    }

    internal fun deselectFromDrag(position: Int) {
        if (isHeader(position)) return

        val item = getItemAt(position) ?: return
        if (!isSelectable(item)) return

        val key = getItemKey(item)

        if (selectedKeys.remove(key)) {
            notifyItemChanged(position, PAYLOAD)
            notifyHeaderForChild(position)
            notifySelectionChanged()
        }
    }
}
