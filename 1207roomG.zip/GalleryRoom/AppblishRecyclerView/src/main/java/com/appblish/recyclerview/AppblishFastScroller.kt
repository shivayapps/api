package com.appblish.recyclerview

import android.animation.Animator
import android.annotation.SuppressLint
import android.content.Context
import android.content.res.TypedArray
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.util.AttributeSet
import android.util.Log
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewPropertyAnimator
import android.view.ViewTreeObserver
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.annotation.DimenRes
import androidx.annotation.Keep
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import androidx.core.widget.TextViewCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class AppblishFastScroller @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : RelativeLayout(context, attrs, defStyleAttr) {

    companion object {
        private const val TAG: String = "RVFastScroller"
        private const val DARK_GREY = 0xFF333333.toInt()
    }

    enum class FastScrollDirection(val value: Int) { HORIZONTAL(1), VERTICAL(0) }

    private enum class PopupPosition(val value: Int) { BEFORE_TRACK(0), AFTER_TRACK(1) }

    private object Defaults {
        val popupDrawableInt: Int = android.R.drawable.dialog_holo_light_frame
        val handleDrawableInt: Int = android.R.drawable.bottom_bar
        val handleHeight: Int = R.dimen.appblish_default_handle_height
        val handleWidth: Int = R.dimen.appblish_default_handle_width
        val textStyle: Int = android.R.style.TextAppearance_Material_Body1
        val popupPosition: PopupPosition = PopupPosition.BEFORE_TRACK
        val fastScrollDirection: FastScrollDirection = FastScrollDirection.VERTICAL
        const val isFixedSizeHandle: Boolean = false
        const val isFastScrollEnabled: Boolean = true
        const val animationDuration: Long = 100
        const val popupVisibilityDuration = 200L
        const val handleVisibilityDuration: Int = 1000
        const val trackMargin: Int = 0
    }

    // Publicizable properties
    var trackDrawable: Drawable?
        set(value) {
            trackView.background = value
        }
        get() = trackView.background

    var popupDrawable: Drawable?
        set(value) {
            popupTextView.background = value
        }
        get() = popupTextView.background

    var handleDrawable: Drawable?
        set(value) {
            handleImageView.setImageDrawable(requireNotNull(value))
        }
        get() = handleImageView.drawable


    private var isFixedSizeHandle: Boolean = Defaults.isFixedSizeHandle
    var isFastScrollEnabled: Boolean = Defaults.isFastScrollEnabled

    lateinit var popupTextView: TextView
    private var currentPopupItemPosition = -1

    var trackMarginStart: Int = 0
        set(value) {
            field = value; setTrackMargin()
        }
    var trackMarginEnd: Int = 0
        set(value) {
            field = value; setTrackMargin()
        }

    var fastScrollDirection: FastScrollDirection = Defaults.fastScrollDirection
        set(value) {
            field = value; alignTrackAndHandle()
        }

    var handleWidth: Int = LayoutParams.WRAP_CONTENT
        set(value) {
            field = value; refreshHandleImageViewSize()
        }
    var handleHeight: Int = LayoutParams.WRAP_CONTENT
        set(value) {
            field = value; refreshHandleImageViewSize()
        }

    var handleVisibilityDuration: Int = -1

    // New setting: rows to skip per jump. Default 2 (jump every 2 rows).
    var rowSkipSize: Int = 5
        set(value) {
            field = max(1, value)
        }

    private var dynamicRowSkip = rowSkipSize
    private var lastDragPos = 0f
    private var dragStartPos = 0f
    private var lastDragTime = 0L

    private val MAX_COLUMNS = 6
    private val MAX_ROW_SKIP = 5

    // Internal views & state
    private var popupPosition: PopupPosition = Defaults.popupPosition
    private lateinit var handleImageView: AppCompatImageView
    private lateinit var trackView: LinearLayout
    private lateinit var recyclerView: RecyclerView
    private var popupAnimationRunnable: kotlinx.coroutines.Runnable
    private var isEngaged = false
    private var handleStateListener: HandleStateListener? = null
    private var previousTotalVisibleItem = 0
    private var hideHandleJob: Job? = null

    // Coroutine scope for jobs (cancel on detach)
    private val mainScope = MainScope()

    // Patch fields
    private var lastSpanCount = -1 // detects changes in GridLayoutManager spans

    // Consider trackView padding when computing length (fixes padded RecyclerViews)
    private val trackLength: Float
        get() = if (fastScrollDirection == FastScrollDirection.VERTICAL)
            (trackView.height - trackView.paddingTop - trackView.paddingBottom).toFloat().coerceAtLeast(1f)
        else
            (trackView.width - trackView.paddingLeft - trackView.paddingRight).toFloat().coerceAtLeast(1f)

    private val handleLength: Float
        get() = if (fastScrollDirection == FastScrollDirection.VERTICAL) handleImageView.height.toFloat() else handleImageView.width.toFloat()

    private val popupLength: Float
        get() = if (fastScrollDirection == FastScrollDirection.VERTICAL) popupTextView.height.toFloat() else popupTextView.width.toFloat()

    var calculateScrollPositionManually = false
    var fullContentHeight = 0
    private var scrollOffset = 0

    private val attribs: TypedArray? = attrs?.let {
        context.theme.obtainStyledAttributes(it, R.styleable.FastScrollerAppblish, 0, 0)
    }

    init {
        addPopupLayout()
        addThumbAndTrack()

        attribs?.let { a ->
            try {
                popupPosition = Defaults.popupPosition
                fastScrollDirection = Defaults.fastScrollDirection

                isFixedSizeHandle = a.getBoolean(
                    R.styleable.FastScrollerAppblish_handleHasFixedSizeAppblish,
                    Defaults.isFixedSizeHandle
                )

                isFastScrollEnabled = a.getBoolean(
                    R.styleable.FastScrollerAppblish_fastScrollEnabledAppblish,
                    Defaults.isFastScrollEnabled
                )

                trackView.background = a.getDrawable(R.styleable.FastScrollerAppblish_trackDrawableAppblish)

                alignTrackAndHandle()
                alignPopupLayout()

                popupTextView.background = a.getDrawable(R.styleable.FastScrollerAppblish_popupDrawableAppblish)
                    ?: context.getDrawable(Defaults.popupDrawableInt)

                handleDrawable = a.getDrawable(R.styleable.FastScrollerAppblish_handleDrawableAppblish)
                    ?: context.getDrawable(Defaults.handleDrawableInt)

                // fallback defaults
                popupTextView.background = if (a.hasValue(R.styleable.FastScrollerAppblish_popupDrawableAppblish)) {
                    loadDrawableFromAttributes(R.styleable.FastScrollerAppblish_popupDrawableAppblish)
                } else {
                    ContextCompat.getDrawable(context, Defaults.popupDrawableInt)
                }

                handleDrawable = (loadDrawableFromAttributes(R.styleable.FastScrollerAppblish_handleDrawableAppblish)
                    ?: ContextCompat.getDrawable(context, Defaults.handleDrawableInt))

                handleVisibilityDuration = a.getInt(
                    R.styleable.FastScrollerAppblish_handleVisibilityDurationAppblish,
                    Defaults.handleVisibilityDuration
                )

                handleHeight = a.getDimensionPixelSize(
                    R.styleable.FastScrollerAppblish_handleHeightAppblish,
                    loadDimenFromResource(Defaults.handleHeight)
                )

                handleWidth = a.getDimensionPixelSize(
                    R.styleable.FastScrollerAppblish_handleWidthAppblish,
                    loadDimenFromResource(Defaults.handleWidth)
                )

                trackMarginStart = a.getDimensionPixelSize(
                    R.styleable.FastScrollerAppblish_trackMarginStartAppblish,
                    Defaults.trackMargin
                )

                trackMarginEnd = a.getDimensionPixelSize(
                    R.styleable.FastScrollerAppblish_trackMarginEndAppblish,
                    Defaults.trackMargin
                )

                TextViewCompat.setTextAppearance(
                    popupTextView,
                    a.getResourceId(
                        R.styleable.FastScrollerAppblish_popupTextStyleAppblish,
                        Defaults.textStyle
                    )
                )
            } finally {
                a.recycle()
            }
        }
        popupAnimationRunnable = Runnable { popupTextView.animateVisibility(false) }
    }

    override fun onDetachedFromWindow() {
        mainScope.cancel()
        detachFastScrollerFromRecyclerView()
        super.onDetachedFromWindow()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onFinishInflate() {
        super.onFinishInflate()
        handleImageView.visibility = GONE
        // If a RecyclerView was added as child in XML, attach it
        if (childCount > 2) {
            for (i in 2 until childCount) {
                val child = getChildAt(i)
                if (child is RecyclerView) {
                    removeView(child)
                    addView(child, 0)
                    attachFastScrollerToRecyclerView(child)
                }
            }
        }
        post {
            if (isFastScrollEnabled) {
                handleImageView.setOnTouchListener(internalTouchListener)
                trackView.setOnTouchListener(internalTouchListener)
            }
        }
    }

    // ---- Layout inflaters ----
    private fun addThumbAndTrack() {
        trackView = LinearLayout(context).apply {
            id = R.id.trackViewAppblish
            layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT).also {
                it.addRule(ALIGN_PARENT_END) // track placed at end (right)
            }
        }
        handleImageView = AppCompatImageView(context).apply {
            id = R.id.thumbAppblishIV
            layoutParams = LayoutParams(handleWidth, handleHeight)
            scaleType = ImageView.ScaleType.CENTER_CROP
            minimumWidth = handleWidth
            minimumHeight = handleHeight
        }
        addView(trackView)
        addView(handleImageView)
    }

    private fun addPopupLayout() {
        popupTextView = TextView(context).apply {
            id = R.id.fastscrollPopupAppblish
            visibility = View.GONE
            layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
        }
        addView(popupTextView)
    }

    // ---- Touch handling ----
    @SuppressLint("ClickableViewAccessibility")
    private val internalTouchListener = OnTouchListener { _, event ->
        if (!::recyclerView.isInitialized) return@OnTouchListener false
        val loc = IntArray(2)
        trackView.getLocationInWindow(loc)
        val xAbs = loc[0];
        val yAbs = loc[1]
        val touchAction = event.actionMasked
        when (touchAction) {
            MotionEvent.ACTION_DOWN -> {
                requestDisallowInterceptTouchEvent(true)
                if (!adapterDataObserver.isInitialized()) registerDataObserver()
                isEngaged = true
                if (isFastScrollEnabled) {
                    handleStateListener?.onEngaged()
                    popupTextView.animateVisibility(true)
                }
                handleImageView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                true
            }

            MotionEvent.ACTION_MOVE -> {
                requestDisallowInterceptTouchEvent(true)
                val handleOffset = handleLength / 2f
                val relPos = if (fastScrollDirection == FastScrollDirection.VERTICAL)
                    event.rawY - yAbs - handleOffset else event.rawX - xAbs - handleOffset
                updateDynamicRowSkip(relPos)
                if (isFastScrollEnabled) {
                    // stop flings/smooth scrolls immediately
                    recyclerView.stopScrollImmediately()

                    // move handle UI
                    moveHandle(relPos)

                    // compute new target position
                    val position = recyclerView.computePositionForOffsetAndScroll(relPos)

                    // jump instantly (no smooth scroll)
                    (recyclerView.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(position, 0)

                    handleStateListener?.onDragged(
                        if (fastScrollDirection == FastScrollDirection.VERTICAL) handleImageView.y else handleImageView.x,
                        position
                    )

                    updateTextInPopup(min((recyclerView.adapter?.itemCount ?: 0) - 1, position))
                } else {
                    val lm = recyclerView.layoutManager as? LinearLayoutManager
                    if (lm?.orientation == RecyclerView.HORIZONTAL) recyclerView.scrollBy(relPos.toInt(), 0)
                    else recyclerView.scrollBy(0, relPos.toInt())
                }
                true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dynamicRowSkip = rowSkipSize
                lastDragTime = 0L
                lastDragPos = 0f
                isEngaged = false
                if (isFastScrollEnabled) {
                    handleStateListener?.onReleased()
                    recyclerView.stopScrollImmediately()
                    postDelayed(popupAnimationRunnable, Defaults.popupVisibilityDuration)
                }
                performClick()
                true
            }

            else -> false
        }
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    // ---- Layout & alignment ----
    private fun alignPopupLayout() {
        val lp = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
        popupTextView.layoutParams = lp
        post { requestLayout() }
    }

    private fun alignTrackAndHandle() {
        // Always align track to parent END (right) — RTL mode A keeps handle on right
        val lpTrack = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT).also {
            it.addRule(ALIGN_PARENT_END)
        }
        trackView.layoutParams = lpTrack

        val lpHandle = LayoutParams(handleWidth, handleHeight).also {
            it.addRule(ALIGN_PARENT_END)
        }
        handleImageView.layoutParams = lpHandle

        // Run positioning after layout is measured
        post {
            // if not measured yet, use a one-shot global layout listener
            if (trackView.width == 0 || handleImageView.width == 0 || popupTextView.width == 0) {
                val listener = object : ViewTreeObserver.OnGlobalLayoutListener {
                    override fun onGlobalLayout() {
                        positionHandleAndPopup()
                        try {
                            trackView.viewTreeObserver.removeOnGlobalLayoutListener(this)
                        } catch (_: Exception) {
                        }
                    }
                }
                try {
                    trackView.viewTreeObserver.addOnGlobalLayoutListener(listener)
                } catch (_: Exception) {
                    positionHandleAndPopup()
                }
            } else {
                positionHandleAndPopup()
            }
            if (::recyclerView.isInitialized) onScrollListener.onScrolled(recyclerView, 0, 0)
        }
    }

    /**
     * Position the handle on the RIGHT edge of the track and popup to the LEFT of the handle.
     * RTL mode A: handle stays on right even for RTL locales.
     */
    private fun positionHandleAndPopup() {
        // Ensure measured
        if (trackView.width == 0) {
            post { positionHandleAndPopup() }; return
        }
        if (handleImageView.width == 0) {
            handleImageView.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED)
        }
        if (popupTextView.width == 0) {
            popupTextView.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED)
        }

        val handleW = handleImageView.measuredWidth.takeIf { it > 0 } ?: handleWidth
        val handleH = handleImageView.measuredHeight.takeIf { it > 0 } ?: handleHeight
        handleImageView.minimumWidth = handleW
        handleImageView.minimumHeight = handleH

        val popupW = popupTextView.measuredWidth.takeIf { it > 0 } ?: 0
        val gap = dpToPx(8f)

        // PERFECT RIGHT ALIGN (always)
        val trackRight = trackView.right
        handleImageView.x = (trackRight - handleW).toFloat()

        // Popup left of handle
        popupTextView.x = (handleImageView.x - popupW - gap).coerceAtLeast(0f)

        // Vertical align (keep same Y as handle)
        popupTextView.y = handleImageView.y
    }

    private fun setTrackMargin() {
        (trackView.layoutParams as? MarginLayoutParams)?.let {
//            it.marginStart = trackMarginStart
//            it.marginEnd = trackMarginEnd
            trackView.setPadding(0, trackMarginStart, 0, trackMarginEnd)
        }
    }

    private fun refreshHandleImageViewSize() {
        handleImageView.layoutParams = LayoutParams(handleWidth, handleHeight)
    }

    // ---- Helper: show/hide animations & popup follow logic ----
    private fun View.animateVisibility(makeVisible: Boolean = true) {
        if (makeVisible) {
            visibility = View.VISIBLE
            scaleX = 1f; scaleY = 1f
        } else {
            animate().scaleX(0f).setDuration(Defaults.animationDuration).withEndAction { visibility = View.GONE }
            animate().scaleY(0f).setDuration(Defaults.animationDuration)
        }
    }

    // ---- Adapter observer ----
    private val adapterDataObserver = lazy {
        object : RecyclerView.AdapterDataObserver() {
            override fun onChanged() {
                super.onChanged()
                previousTotalVisibleItem = 0
                currentPopupItemPosition = -1
            }

            override fun onItemRangeRemoved(positionStart: Int, itemCount: Int) {
                super.onItemRangeRemoved(positionStart, itemCount)
                previousTotalVisibleItem = 0
                currentPopupItemPosition = -1
            }
        }
    }

    private fun registerDataObserver() {
        recyclerView.adapter?.registerAdapterDataObserver(adapterDataObserver.value)
    }

    // ---- Scroll listener ----
    private val onScrollListener = object : RecyclerView.OnScrollListener() {
        override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
            super.onScrolled(rv, dx, dy)
            if (!::recyclerView.isInitialized) return

            detectSpanChange()

            if (isEngaged && isFastScrollEnabled) return

            scrollOffset += dy
            val layoutManager = rv.layoutManager as? LinearLayoutManager
            val orientation = layoutManager?.orientation ?: RecyclerView.VERTICAL

            val (range, extent, offset) = when (orientation) {
                RecyclerView.HORIZONTAL -> Triple(
                    rv.computeHorizontalScrollRange(),
                    rv.computeHorizontalScrollExtent(),
                    rv.computeHorizontalScrollOffset()
                )

                RecyclerView.VERTICAL -> {
                    if (calculateScrollPositionManually) {
                        Triple(fullContentHeight, rv.computeVerticalScrollExtent(), scrollOffset)
                    } else {
                        Triple(rv.computeVerticalScrollRange(), rv.computeVerticalScrollExtent(), rv.computeVerticalScrollOffset())
                    }
                }

                else -> Triple(0, 0, 0)
            }

            if (extent >= range) {
                // non-scrollable
                handleImageView.animateVisibility(false)
                trackView.isEnabled = false
                handleImageView.isEnabled = false
                return
            } else {
                if ((dy != 0 && orientation == RecyclerView.VERTICAL) || (dx != 0 && orientation == RecyclerView.HORIZONTAL)) {
                    handleImageView.animateVisibility(true)
                    handleImageView.isEnabled = true
                    trackView.isEnabled = true
                }
            }

            val availableTrackLength = extent.toFloat() - handleLength
            val scrollPositionPercent = if (range - extent == 0) 0f else (offset.toFloat() / (range - extent))
            val finalOffset = availableTrackLength * scrollPositionPercent

            if ((dy != 0 && orientation == RecyclerView.VERTICAL) || (dx != 0 && orientation == RecyclerView.HORIZONTAL)) {
                moveHandle(finalOffset)
            }
        }
    }

    private fun initImpl() {
        registerDataObserver()
        recyclerView.addOnScrollListener(onScrollListener)
    }

    // ---- Public attach/detach ----
    @Keep
    fun attachFastScrollerToRecyclerView(rv: RecyclerView) {
        this.recyclerView = rv
        initImpl()
        post {
            val lm = recyclerView.layoutManager
            if (lm is GridLayoutManager) lastSpanCount = lm.spanCount
            // ensure initial positions computed
            alignTrackAndHandle()
            onScrollListener.onScrolled(recyclerView, 0, 0)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    fun detachFastScrollerFromRecyclerView() {
        if (adapterDataObserver.isInitialized()) {
            try {
                recyclerView.adapter?.unregisterAdapterDataObserver(adapterDataObserver.value)
            } catch (_: Exception) {
            }
        }
        handleImageView.setOnTouchListener(null)
        trackView.setOnTouchListener(null)
        try {
            recyclerView.removeOnScrollListener(onScrollListener)
        } catch (_: Exception) {
        }
    }

    // ---- Popup update hooks ----
    private fun updateTextInPopup(position: Int) {
        if (position == currentPopupItemPosition) return
        currentPopupItemPosition = position
        when (val adapter = recyclerView.adapter) {
            null -> throw IllegalAccessException("No adapter found")
            is OnPopupTextUpdate -> popupTextView.text = adapter.onChange(position).toString()
            is OnPopupViewUpdate -> adapter.onUpdate(position, popupTextView)
            else -> popupTextView.visibility = View.GONE
        }
    }

    // ---- Position math ----
    private fun RecyclerView.computePositionForOffsetAndScroll(relativeRawPos: Float): Int {
        val layoutManager = layoutManager ?: return RecyclerView.NO_POSITION
        val itemCount = adapter?.itemCount ?: return RecyclerView.NO_POSITION

        if (layoutManager is GridLayoutManager) {
            return computePositionForOffsetAndScrollGrid(relativeRawPos)
        }

        // Ensure trackRange positive
        val trackRange = (trackLength - handleLength).coerceAtLeast(1f)
        val pct = (relativeRawPos / trackRange).coerceIn(0f, 1f)

        // Linear fallback
        if (layoutManager is LinearLayoutManager) {
            val position = (pct * itemCount).roundToInt().coerceIn(0, itemCount - 1)
            return position
        }

        return 0
    }

    /**
     * Grid logic (NO headers):
     * - Uses rowSkipSize to group rows
     * - Maps drag percentage -> target jump group -> first item of that row
     */
    private fun RecyclerView.computePositionForOffsetAndScrollGrid(
        relativePos: Float
    ): Int {
        val adapter = adapter ?: return 0
        val itemCount = adapter.itemCount
        if (itemCount == 0) return 0

        val lm = layoutManager as? GridLayoutManager ?: return 0
        val span = lm.spanCount.takeIf { it > 0 } ?: 1

        val trackRange = (trackLength - handleLength).coerceAtLeast(1f)
        val pct = (relativePos / trackRange).coerceIn(0f, 1f)

        // Total rows in grid
        val totalRows = (itemCount + span - 1) / span

        val rowStep = max(1, dynamicRowSkip)
        val totalJumpRows = (totalRows + rowStep - 1) / rowStep

        val jumpRowIndex =
            (pct * totalJumpRows).toInt().coerceIn(0, totalJumpRows - 1)

        // Actual target row
        val targetRow =
            (jumpRowIndex * rowStep).coerceIn(0, totalRows - 1)

        // First item of that row
        val targetPos = targetRow * span

        return targetPos.coerceIn(0, itemCount - 1)
    }

    fun getRowSkipSize(spanCount: Int): Int {
        if (spanCount <= 0) return 1

        return when {
            spanCount >= MAX_COLUMNS -> MAX_ROW_SKIP
            else -> {
                val ratio = spanCount.toFloat() / MAX_COLUMNS
                max(1, (MAX_ROW_SKIP * ratio).toInt())
            }
        }
    }

    private fun getSpanAcceleration(span: Int): Float {
        return when {
            span >= 6 -> 3.2f
            span == 5 -> 2.8f
            span == 4 -> 2.4f
            span == 3 -> 1.9f
            span == 2 -> 1.4f
            else -> 1.0f
        }
    }

    private fun updateDynamicRowSkip(currentPos: Float) {
        val now = SystemClock.uptimeMillis()

        if (lastDragTime == 0L) {
            dragStartPos = currentPos
            lastDragPos = currentPos
            lastDragTime = now
            dynamicRowSkip = rowSkipSize
            return
        }

        val dt = (now - lastDragTime).coerceAtLeast(1)
        val delta = kotlin.math.abs(currentPos - lastDragPos)

        // 1️⃣ Speed → logarithmic (Pixel style)
        val speed = delta / dt
        val logSpeed = ln(1 + speed * 6f)

        // 2️⃣ Distance → farther drag = faster
        val distanceFactor =
            kotlin.math.abs(currentPos - dragStartPos) / trackLength

        // 3️⃣ Span-based acceleration
        val span =
            (recyclerView.layoutManager as? GridLayoutManager)?.spanCount ?: 1
        val spanFactor = getSpanAcceleration(span)

        val accel =
            (logSpeed * 0.6f) + (distanceFactor * 0.9f)

        dynamicRowSkip =
            (rowSkipSize + accel * spanFactor)
                .toInt()
                .coerceIn(1, MAX_ROW_SKIP)

        lastDragPos = currentPos
        lastDragTime = now
    }

    // ---- Span change detection ----
    private fun detectSpanChange() {
        val lm = recyclerView.layoutManager as? GridLayoutManager ?: return
        if (lastSpanCount != lm.spanCount) {
            lastSpanCount = lm.spanCount
            previousTotalVisibleItem = 0
            currentPopupItemPosition = -1
            scrollOffset = 0
            post { onScrollListener.onScrolled(recyclerView, 0, 0) }
        }
    }

    // ---- Visibility & movement helpers ----
    private fun moveHandle(offset: Float) {
        post {
            handleImageView.scaleX = 1f; handleImageView.scaleY = 1f
        }

        // prevent hiding while dragging; debounce hide only when not engaged
        hideHandleJob?.cancel()
        hideHandleJob = mainScope.launch {
            delay(handleVisibilityDuration.toLong().coerceAtLeast(0L))
            if (!isEngaged) handleImageView.animateVisibility(false)
        }

        // position handle within track bounds
        moveViewToRelativePositionWithBounds(handleImageView, offset)

        // popup should follow handle (left of handle) — RTL mode A keeps popup left
        positionPopupRelativeToHandle()
    }

    private fun positionPopupRelativeToHandle() {
        // small gap between handle and popup
        val gap = dpToPx(8f)
        if (fastScrollDirection == FastScrollDirection.VERTICAL) {
            popupTextView.y = handleImageView.y.coerceIn(0f, trackLength - popupTextView.height.toFloat())
            // RTL mode A — popup always on LEFT of handle
            popupTextView.x = (handleImageView.x - popupTextView.width - gap).coerceAtLeast(0f)
        } else {
            popupTextView.x = handleImageView.x.coerceIn(0f, trackLength - popupTextView.width.toFloat())
            popupTextView.y = (handleImageView.y - popupTextView.height - gap).coerceAtLeast(0f)
        }
    }

    private fun moveViewToRelativePositionWithBounds(view: View, finalOffset: Float) {
        if (fastScrollDirection == FastScrollDirection.HORIZONTAL) {
            val minX = 0f
            val maxX = trackLength - view.width.toFloat()
            view.x = min(max(finalOffset, minX), maxX)
        } else {
            val minY = 0f
            val maxY = trackLength - view.height.toFloat()
            view.y = min(max(finalOffset, minY), maxY)
        }
    }

    // ---- Utilities ----
    private inline fun ViewPropertyAnimator.onAnimationCancelled(crossinline body: () -> Unit) {
        setListener(object : Animator.AnimatorListener {
            override fun onAnimationRepeat(p0: Animator) {}
            override fun onAnimationEnd(p0: Animator) {}
            override fun onAnimationStart(p0: Animator) {}
            override fun onAnimationCancel(p0: Animator) {
                body()
            }
        })
    }

    private fun loadDimenFromResource(@DimenRes dimenSize: Int): Int = resources.getDimensionPixelSize(dimenSize)
    private fun loadDrawableFromAttributes(styleId: Int) = attribs?.getDrawable(styleId)
    private fun isRTLLayout() = resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL

    private fun dpToPx(dp: Float): Float = dp * resources.displayMetrics.density


    @Keep
    interface OnPopupViewUpdate {
        fun onUpdate(position: Int, popupTextView: TextView)
    }

    @Keep
    interface OnPopupTextUpdate {
        fun onChange(position: Int): CharSequence
    }

    @Keep
    interface HandleStateListener {
        fun onEngaged() {}
        fun onDragged(offset: Float, position: Int) {}
        fun onReleased() {}
    }

    private fun log(message: String = "") {
        Log.d(TAG, message)
    }

    // ---- FIX: stop RecyclerView flings / smooth scrollers immediately ----
    private fun RecyclerView.stopScrollImmediately() {
        try {
            this.stopScroll()
            val flingerField = RecyclerView::class.java.getDeclaredField("mViewFlinger")
            flingerField.isAccessible = true
            val flinger = flingerField.get(this)
            val stopMethod = flinger.javaClass.getDeclaredMethod("stop")
            stopMethod.isAccessible = true
            stopMethod.invoke(flinger)
        } catch (_: Exception) {
        }
    }

}