plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.jetbrains.kotlin.android)
    id("maven-publish")
}

android {
    namespace = "com.appblish.recyclerview"
    compileSdk = 36

    defaultConfig {
        minSdk = 30
        consumerProguardFiles("consumer-rules.pro")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
}

//afterEvaluate {
//
//    publishing {
//        publications {
//            create<MavenPublication>("v2") {
//                groupId = "com.appblish.fastscroll.recyclerview"
//                artifactId = "v2"
//                version = "1.0.7"
//                artifact("./build/outputs/aar/AppblishRecyclerView-release.aar")
//            }
//        }
//        repositories {
//            maven {
//                name = "GitLab"
//                url = uri("https://gitlab.com/api/v4/projects/77980561/packages/maven")
//                credentials {
//                    username = "AppblishRecyclerview"
//                    password = "gldt-U_HCzT1Jstd-7GJYj9c6"
//                }
//            }
//        }
//    }
//}