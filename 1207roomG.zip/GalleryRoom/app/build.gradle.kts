plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
    id("com.google.devtools.ksp")
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
    id("kotlin-parcelize")
}

base {
    archivesName.set("Incredible-Gallery")
}
android {
    namespace = "gallery.photogallery.photoeditor.galleryapp"
    compileSdk = 36

    defaultConfig {
        applicationId = "gallery.photogallery.photoeditor.galleryapp"
        minSdk = 30
        targetSdk = 36
        versionCode = 3
        versionName = "1.3"
        vectorDrawables.useSupportLibrary = true

        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
        }
    }
    bundle {
        language {
            enableSplit = false
        }
    }
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
        isCoreLibraryDesugaringEnabled = true
    }


    buildFeatures {
        buildConfig = true
        viewBinding = true
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    dexOptions {
        javaMaxHeapSize = "8G"
    }


    flavorDimensions("default")
    productFlavors {
        create("TestAd") {
            isDefault = true
        }

        create("LiveAd") {

        }
    }

}

dependencies {

    implementation("io.github.ParkSangGwon:tedpermission-normal:3.4.2")// Normal
    implementation(libs.androidx.asynclayoutinflater)
    implementation(libs.androidx.media3.common.ktx)
    coreLibraryDesugaring(libs.desugar.jdk.libs)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.biometric.ktx)
    api(libs.gson)
    implementation(libs.android.sdp)
    implementation(libs.android.ssp)
    implementation(libs.eventbus)

    implementation(libs.services.maps)
    implementation(libs.services.location)

    // Firebase
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.analytics)
    implementation(libs.firebase.crashlytics)
    implementation(libs.firebase.config)
    implementation(libs.firebase.perf)
    implementation(libs.firebase.messaging)

    implementation(libs.androidx.lifecycle.viewmodel.ktx)
    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.lottie)
    implementation(libs.roundedimageview)

    implementation(libs.androidx.lifecycle.runtime.ktx)

    implementation(libs.review.ktx)
    implementation(libs.app.update.ktx)
    implementation(libs.simpleratingbar)

    implementation(libs.photoview)
    implementation(libs.androidx.transition)
    implementation(libs.rxandroid)
    implementation(libs.rxjava)

    implementation(libs.joda.time)
    implementation(libs.gestureviews)

    implementation(libs.androidx.lifecycle.service)
    implementation(libs.android.gif.drawable)


    //noinspection KaptUsageInsteadOfKsp
//    implementation(project(":Places"))
    implementation(project(":box"))
    implementation(project(":GalleryCoreV2"))
    implementation(project(":Appblishplayer"))

    implementation(project(":Memories"))
    implementation(project(":Cleaner"))
    implementation(project(":MediaLoader"))
    implementation(project(":collagemaker"))
    implementation(project(":Appblishcropview"))
    implementation(project(":AppblishRecyclerView"))
    implementation(project(":Editor"))

    implementation("com.github.bumptech.glide:recyclerview-integration:5.0.5")
    implementation("com.github.bumptech.glide:glide:5.0.5")
    implementation("jp.wasabeef:glide-transformations:4.3.0")
    implementation("androidx.work:work-runtime-ktx:2.11.1")

//    implementation("com.appblish:permissions:1.0.0")
////    implementation("com.appblish.gallery:box:1.1.3")
//    implementation("com.appblish.cropview:v1:1.0.1")
//    implementation("com.appblish.fastscroll.recyclerview:v2:1.0.7")
//    implementation("com.appblish.collage:v1:1.0.1")
//    implementation("com.appblish.media.loader:v2:1.0.6")
//    implementation("com.appblish.cleaner:v2:1.1.0")
//    implementation("com.appblish.story.memories:v2:1.0.9")
//    implementation("com.appblish.videoplayer:v2:1.0.2")
//    implementation("com.appblish.gallery.core:v2:1.1.6")


    implementation("androidx.media3:media3-exoplayer:1.9.2")
    implementation("androidx.media3:media3-exoplayer-dash:1.9.2")
    implementation("androidx.media3:media3-ui:1.9.2")
    implementation("androidx.media3:media3-session:1.9.2")

}