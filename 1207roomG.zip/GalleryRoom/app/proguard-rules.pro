-dontwarn com.gallery.editor.utils.**
-dontwarn org.xmlpull.v1.**
-dontwarn android.content.**
-dontwarn org.kxml2.io.**
-dontwarn com.facebook.**
-dontwarn com.google.android.gms.common.**
-keep class android.content.**
-keep class org.xmlpull.v1.**
-keep class org.kxml2.io.**
-keep class com.facebook.**

-keepclassmembernames,allowoptimization,allowshrinking class player.phonograph.ui.** extends androidx.lifecycle.ViewModel {public <methods>;}
# ViewModel's empty constructor is considered to be unused by proguard
-keepclassmembers class * extends androidx.lifecycle.ViewModel {
    <init>(...);
}
-keepclasseswithmembers,allowobfuscation public class <1> {
    public <init>();
}
-keepclassmembers,allowshrinking,allowobfuscation class * extends androidx.lifecycle.AndroidViewModel {
    <init>(android.app.Application);
}
-keep class org.apache.tika.** { *; }
-dontwarn org.apache.tika.**

# adjust
-keep class org.wysaid.nativePort.** { *; }
#-keep class io.objectbox.** { *; }
-keepattributes *Annotation*
##---------------Begin: proguard configuration for Dagger Hilt ----------
#-keepnames @dagger.hilt.android.lifecycle.HiltViewModel class * extends androidx.lifecycle.ViewModel
#-keep @dagger.hilt.* class * { *; }
#-keep class dagger.hilt.** { *; }
#-keepclasseswithmembernames class * { @dagger.hilt.* <methods>; }
#-keepclasseswithmembernames class * { @dagger.hilt.* <fields>; }

# Keep Coil's generated code and prevent its metadata from being obfuscated.
-keep class coil.** { *; }
-keep class coil.request.** { *; }
-keepclassmembers class coil.** { *; }

# Keep Kotlin coroutines related metadata to prevent reflection issues.
-keepattributes *Annotation*
-keep class kotlinx.coroutines.** { *; }

# If you're using OkHttp with Coil, keep OkHttp classes
-keep class okhttp3.** { *; }

# If you’re using Glide’s integration in Coil (optional):
-keep class com.bumptech.glide.** { *; }

-dontwarn org.xmlpull.v1.**
-dontwarn org.kxml2.io.**
-dontwarn android.content.res.**
-dontwarn org.slf4j.impl.StaticLoggerBinder

-keep class org.xmlpull.** { *; }
-keepclassmembers class org.xmlpull.** { *; }
# Keep all ML Kit classes
-keep class com.google.mlkit.** { *; }

# Keep Google Play Services classes
-keep class com.google.android.gms.** { *; }

# Keep Firebase classes
-keep class com.google.firebase.** { *; }

# Prevent stripping metadata for ML Kit models

# Keep internal ML Kit classes, including the LibraryVersion class
-keep class com.google.mlkit.common.sdkinternal.** { *; }

# Keep internal annotations and methods used by ML Kit
-keep @com.google.mlkit.common.internal.** class *
-keepclassmembers class * {
    @com.google.mlkit.common.internal.** *;
}
-keepattributes Signature

# For using GSON @Expose annotation
-keepattributes *Annotation*

# Gson specific classes
-dontwarn sun.misc.**
#-keep class com.google.gson.stream.** { *; }

# Application classes that will be serialized/deserialized over Gson
-keep class com.google.gson.examples.android.model.** { <fields>; }

# Prevent proguard from stripping interface information from TypeAdapter, TypeAdapterFactory,
# JsonSerializer, JsonDeserializer instances (so they can be used in @JsonAdapter)
-keep class * extends com.google.gson.TypeAdapter
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer

# Prevent R8 from leaving Data object members always null
-keepclassmembers,allowobfuscation class * {
  @com.google.gson.annotations.SerializedName <fields>;
}

# Retain generic signatures of TypeToken and its subclasses with R8 version 3.0 and higher.
-keep,allowobfuscation,allowshrinking class com.google.gson.reflect.TypeToken
-keep,allowobfuscation,allowshrinking class * extends com.google.gson.reflect.TypeToken

-keep class coil.** { *; }
-keep class okhttp3.** { *; }
-keep class okhttp3.internal.** { *; }
-keep class okio.** { *; }
-keep class androidx.core.graphics.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn androidx.core.graphics.**

# Keep Coil core and transformations
-keep class coil.** { *; }
-keepclassmembers class coil.** { *; }

# Keep OkHttp and Kotlin metadata used by Coil
-keep class okhttp3.** { *; }
-dontwarn okhttp3.**

# If you use BlurTransformation or other transformations
-keep class coil.transform.** { *; }

############################################
# MediaPipe Vision Tasks
############################################

# Keep MediaPipe core
-keep class com.google.mediapipe.** { *; }
-dontwarn com.google.mediapipe.**

# MediaPipe native bindings
-keep class com.google.mediapipe.framework.** { *; }
-dontwarn com.google.mediapipe.framework.**

# Keep Task APIs (FaceLandmarker, etc.)
-keep class com.google.mediapipe.tasks.** { *; }
-dontwarn com.google.mediapipe.tasks.**

# Keep Protobuf used internally by MediaPipe
-keep class com.google.protobuf.** { *; }
-dontwarn com.google.protobuf.**

############################################
# ML Kit (Image Labeling)
############################################

-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**

############################################
# Tensor / Native helpers (used internally)
############################################

-dontwarn org.tensorflow.**
-dontwarn org.checkerframework.**
-dontwarn javax.annotation.**

############################################
# Room Database
############################################

# Keep Room annotations
-keep class androidx.room.** { *; }
-dontwarn androidx.room.**

# Keep entities
-keepclassmembers class * {
    @androidx.room.* <fields>;
}

############################################
# WorkManager
############################################

-keep class androidx.work.** { *; }
-dontwarn androidx.work.**

############################################
# Kotlin Metadata (IMPORTANT)
############################################

-keep class kotlin.Metadata { *; }

############################################
# Prevent stripping of native methods
############################################

-keepclasseswithmembernames class * {
    native <methods>;
}

############################################
# Optional: Reduce log noise
############################################

-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
}


# --- Joda-Time ---
-keep class org.joda.time.** { *; }
-dontwarn org.joda.time.**

# --- Joda-Convert (REQUIRED) ---
-keep class org.joda.convert.** { *; }
-dontwarn org.joda.convert.**

# Keep Google Play Services common annotations
-keep class com.google.android.gms.common.annotation.** { *; }

# Keep all Google Play Services annotations (safe option)
-keep class com.google.android.gms.common.annotation.KeepName { *; }
-keep @com.google.android.gms.common.annotation.KeepName class *

# Keep Play Core KTX SAM wrappers (Kotlin synthetic classes)
-keep class com.google.android.play.core.ktx.** { *; }

# Keep Google Tasks (used by Play Core)
-keep class com.google.android.gms.tasks.** { *; }

# Keep all WorkManager workers
# ===============================
# Media3 (ExoPlayer) - Core
# ===============================
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Keep PlayerView & UI components
-keep class androidx.media3.ui.** { *; }

# Keep ExoPlayer implementation
-keep class androidx.media3.exoplayer.** { *; }

# Keep Common module
-keep class androidx.media3.common.** { *; }
-keep class androidx.media3.ui.** { *; }

# ===============================
# Prevent stripping of enums
# ===============================
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}