package gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog

import android.os.Bundle
import android.text.format.DateFormat
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogDateTimeBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.applySystemBarAppearanceByTheme
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.DATE_FORMAT_EIGHT
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.DATE_FORMAT_FIVE
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.DATE_FORMAT_FOUR
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.DATE_FORMAT_ONE
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.DATE_FORMAT_SEVEN
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.DATE_FORMAT_SIX
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.DATE_FORMAT_THREE
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.DATE_FORMAT_TWO
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Preferences
import java.util.Calendar


class DateTimeDialog() : BottomSheetDialogFragment() {

    private var _binding: DialogDateTimeBinding? = null
    private val binding get() = _binding!!

    var updateListener: (() -> Unit)? = null

    companion object {
        fun newInstance(updateListener: () -> Unit): DateTimeDialog {
            val mDialog = DateTimeDialog()
            mDialog.updateListener = updateListener
            return mDialog
        }
    }

    override fun getTheme(): Int = R.style.CustomBottomSheetDialog

    val preferences: Preferences by lazy { Preferences(requireActivity()) }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = DialogDateTimeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        dialog?.applySystemBarAppearanceByTheme()

        intView()
        intListener()
    }

    private fun intView() {
        binding.apply {
            changeDateTimeDialogRadioOne.text = formatDateSample(DATE_FORMAT_ONE)
            changeDateTimeDialogRadioTwo.text = formatDateSample(DATE_FORMAT_TWO)
            changeDateTimeDialogRadioThree.text = formatDateSample(DATE_FORMAT_THREE)
            changeDateTimeDialogRadioFour.text = formatDateSample(DATE_FORMAT_FOUR)
            changeDateTimeDialogRadioFive.text = formatDateSample(DATE_FORMAT_FIVE)
            changeDateTimeDialogRadioSix.text = formatDateSample(DATE_FORMAT_SIX)
            changeDateTimeDialogRadioSeven.text = formatDateSample(DATE_FORMAT_SEVEN)
            changeDateTimeDialogRadioEight.text = formatDateSample(DATE_FORMAT_EIGHT)

            cbTime24hFormat.isChecked = preferences.use24HourFormat

            val formatButton = when (preferences.dateFormat) {
                DATE_FORMAT_ONE -> changeDateTimeDialogRadioOne
                DATE_FORMAT_TWO -> changeDateTimeDialogRadioTwo
                DATE_FORMAT_THREE -> changeDateTimeDialogRadioThree
                DATE_FORMAT_FOUR -> changeDateTimeDialogRadioFour
                DATE_FORMAT_FIVE -> changeDateTimeDialogRadioFive
                DATE_FORMAT_SIX -> changeDateTimeDialogRadioSix
                DATE_FORMAT_SEVEN -> changeDateTimeDialogRadioSeven
                else -> changeDateTimeDialogRadioEight
            }
            formatButton.isChecked = true
        }
    }

    private fun formatDateSample(format: String): String {
//        val cal = Calendar.getInstance(Locale.ENGLISH)
        val cal = Calendar.getInstance()
//        cal.timeInMillis = timeSample
        val strFormat = DateFormat.format(format, cal).toString().trim()
        Log.e("formatDateSample", "format>>$format<<, strFormat>>$strFormat<<")
        return "$strFormat "
    }

    private fun intListener() {
        binding.btnCancel.setOnClickListener {
            dismiss()
        }
        binding.btnOK.setOnClickListener {
            preferences.dateFormat = when (binding.grpDateFormat.checkedRadioButtonId) {
                binding.changeDateTimeDialogRadioOne.id -> DATE_FORMAT_ONE
                binding.changeDateTimeDialogRadioTwo.id -> DATE_FORMAT_TWO
                binding.changeDateTimeDialogRadioThree.id -> DATE_FORMAT_THREE
                binding.changeDateTimeDialogRadioFour.id -> DATE_FORMAT_FOUR
                binding.changeDateTimeDialogRadioFive.id -> DATE_FORMAT_FIVE
                binding.changeDateTimeDialogRadioSix.id -> DATE_FORMAT_SIX
                binding.changeDateTimeDialogRadioSeven.id -> DATE_FORMAT_SEVEN
                else -> DATE_FORMAT_EIGHT
            }

            preferences.use24HourFormat = binding.cbTime24hFormat.isChecked
            dismiss()
            updateListener?.invoke()
        }
    }
}