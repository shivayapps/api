package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation

import android.view.View
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs


class FadePageTransformer : ViewPager2.PageTransformer {
    override fun transformPage(page: View, position: Float) {
        page.translationX = -position * page.width

        page.alpha = (1 - abs(position.toDouble())).toFloat()
    }
    /*override fun transformPage(view: View, position: Float) {
         view.translationX = view.width * -position

         view.alpha = if (position <= -1f || position >= 1f) {
             0f
         } else if (position == 0f) {
             1f
         } else {
             1f - Math.abs(position)
         }
     }*/
    /*override fun transformPage(view: View, position: Float) {
        view.apply {
            alpha = 1 - kotlin.math.abs(position) // Fade effect
            translationX = view.width * -position // Ensure proper positioning
            scaleX = 1 - kotlin.math.abs(position) * 0.1f // Optional scaling effect
            scaleY = 1 - kotlin.math.abs(position) * 0.1f
        }
    }*/
}
