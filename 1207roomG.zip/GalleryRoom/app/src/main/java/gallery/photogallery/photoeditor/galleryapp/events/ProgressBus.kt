package gallery.photogallery.photoeditor.galleryapp.events

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

object ProgressBus {

    private val _progressFlow = MutableStateFlow(ProgressState(0, 0))
    val progressFlow: StateFlow<ProgressState> = _progressFlow

    fun update(current: Int, total: Int) {
        _progressFlow.value = ProgressState(current, total)
    }

    data class ProgressState(val current: Int, val total: Int)
}
