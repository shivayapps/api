package gallery.photogallery.photoeditor.galleryapp.collage.adapters

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
 import com.appblish.collagemaker.utils.AppblishCollageBrushColorAsset
import gallery.photogallery.photoeditor.galleryapp.R

class TextColorAdapter(
    private val context: Context,
    private val onColorSelected: (SquareView) -> Unit
) : RecyclerView.Adapter<TextColorAdapter.ViewHolder>() {

    var selectedSquareIndex = -1
    private val squareViewList: MutableList<SquareView> = ArrayList()

    init {
        val listColorBrush = AppblishCollageBrushColorAsset.listColorBrush()
        for (i in 0 until listColorBrush.size - 2) {
            squareViewList.add(
                SquareView(
                    Color.parseColor(listColorBrush[i]),
                    true
                )
            )
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_color_text, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val squareView = squareViewList[position]

        if (squareView.isColor) {
            holder.image_view_square.setBackgroundColor(squareView.drawableId)
        } else {
            holder.image_view_square.setBackgroundResource(squareView.drawableId)
        }

        if (position==0){
            holder.viewSelected.visibility = View.VISIBLE
            if (selectedSquareIndex == position){
                holder.viewSelected.setImageResource(R.drawable.primary_border3)
            }else{
                holder.viewSelected.setImageResource(R.drawable.gray_border3)

            }
        }else{
            holder.viewSelected.setImageResource(R.drawable.primary_border3)
            holder.viewSelected.visibility =
                if (selectedSquareIndex == position) View.VISIBLE else View.GONE
        }

//
//        holder.viewSelected.visibility =
//            if (selectedSquareIndex == position) View.VISIBLE else View.GONE
    }

    override fun getItemCount(): Int = squareViewList.size

    fun setSelectedColorIndex(index: Int) {
        selectedSquareIndex = index
        notifyDataSetChanged()
    }

    inner class ViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView), View.OnClickListener {

        val squareView: View = itemView.findViewById(R.id.square_view)
        val viewSelected: ImageView = itemView.findViewById(R.id.view_selected)
        val image_view_square: ImageView = itemView.findViewById(R.id.image_view_square)
        val wrapSquareView: ConstraintLayout =
            itemView.findViewById(R.id.constraint_layout_wrapper_square_view)

        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View?) {
            val position = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                selectedSquareIndex = position
                onColorSelected(squareViewList[position])
                notifyDataSetChanged()
            }
        }
    }

    data class SquareView(
        val drawableId: Int,
        val isColor: Boolean = false
    )
}
