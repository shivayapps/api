package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.Looper
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.annotation.ChecksSdkIntAtLeast
import androidx.core.animation.doOnEnd
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.data.model.MemoriesMusicModel

const val NOMEDIA = ".nomedia"
const val RECYCLE_BIN_PATH = "Android2/.system/.gallery/.Recyclebin"
const val PRIVATE_MEDIA_PATH = "Android2/.system/.gallery/.Private/"
const val RECOVER_PATH = "Gallery/Recover"
const val PRIVACY_POLICY = "https://sites.google.com/gameadzone.com/incredible-gallery/"
const val CLICK_HOLD = 500

val memoryToneList = listOf(
    R.raw.tone_1,
    R.raw.tone_2,
    R.raw.tone_3,
    R.raw.tone_4,
    R.raw.tone_5,
    R.raw.tone_6,
    R.raw.tone_7,
    R.raw.tone_8,
    R.raw.tone_9,
    R.raw.tone_10,
)

fun getMemoriesMusicList(): ArrayList<MemoriesMusicModel> {
    return ArrayList<MemoriesMusicModel>().apply {
        add(MemoriesMusicModel(R.raw.tone_1, "Enjoy-the-morning", "1:00", "16.6Kb", "256kbps", imagePath = "image_music/img_tone_1.png"))
        add(MemoriesMusicModel(R.raw.tone_2, "Good-mood-leads-to-success", "00:30", "18.0KB", "256kbps", imagePath = "image_music/img_tone_2.png"))
        add(MemoriesMusicModel(R.raw.tone_3, "Happy-family", "00:45", "14.2KB", "256kbps", imagePath = "image_music/img_tone_3.png"))
        add(MemoriesMusicModel(R.raw.tone_4, "Sandy-vibe-summer", "00:42", "18.KB", "256kbps", imagePath = "image_music/img_tone_4.png"))
        add(MemoriesMusicModel(R.raw.tone_5, "Travel-in-time", "00:30", "17.1KB", "256kbps", imagePath = "image_music/img_tone_5.png"))
        add(MemoriesMusicModel(R.raw.tone_6, "Upbeat-music", "1:00", "12.1KB", "256kbps", imagePath = "image_music/img_tone_6.png"))
        add(MemoriesMusicModel(R.raw.tone_7, "Valentine-love-piano", "14.1KB", "1MB", "256kbps", imagePath = "image_music/img_tone_7.png"))
        add(MemoriesMusicModel(R.raw.tone_8, "Acoustic-guitar", "00:58", "11.7KB", "256kbps", imagePath = "image_music/img_tone_8.png"))
        add(MemoriesMusicModel(R.raw.tone_9, "Advanced technologies", "17.1KB", "1MB", "256kbps", imagePath = "image_music/img_tone_9.png"))
        add(MemoriesMusicModel(R.raw.tone_10, "A-new-life", "00:52", "15.1KB", "256kbps", imagePath = "image_music/img_tone_9.png"))
    }
}

val photoExtensions: Array<String>
    get() = arrayOf(
        ".jpg",
        ".png",
        ".jpeg",
        ".bmp",
        ".webp",
        ".heic",
        ".heif",
        ".apng",
        ".avif"
    )
val videoExtensions: Array<String>
    get() = arrayOf(
        ".mp4",
        ".mkv",
        ".webm",
        ".avi",
        ".3gp",
        ".mov",
        ".m4v",
        ".3gpp"
    )
val audioExtensions: Array<String>
    get() = arrayOf(
        ".mp3",
        ".wav",
        ".wma",
        ".ogg",
        ".m4a",
        ".opus",
        ".flac",
        ".aac",
        ".m4b"
    )
val rawExtensions: Array<String>
    get() = arrayOf(
        ".dng",
        ".orf",
        ".nef",
        ".arw",
        ".rw2",
        ".cr2",
        ".cr3"
    )

val extensionsSupportingEXIF: Array<String>
    get() = arrayOf(
        ".jpg",
        ".jpeg",
        ".png",
        ".webp",
        ".dng"
    )
val extra: Array<String>
    get() = arrayOf(
        ".gif",
    )

val normalizeRegex = "\\p{InCombiningDiacriticalMarks}+".toRegex()

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.N)
fun isNougatPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N

@SuppressLint("ObsoleteSdkInt")
fun isAndroid11() = Build.VERSION.SDK_INT == Build.VERSION_CODES.R

fun isAboveAndroid11() = Build.VERSION.SDK_INT > Build.VERSION_CODES.R

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.N_MR1)
fun isNougatMR1Plus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.O)
fun isOreoPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.O_MR1)
fun isOreoMr1Plus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.P)
fun isPiePlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.Q)
fun isQPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.R)
fun isRPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.S)
fun isSPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.TIRAMISU)
fun isTiramisuPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
fun isUpsideDownCakePlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE

const val SHOW_ALL =
    "show_all"                           // display images and videos from all folders together

const val MAX_CLOSE_DOWN_GESTURE_DURATION = 300

const val SLIDESHOW_SLIDE_DURATION = 500L
const val SLIDESHOW_FADE_DURATION = 1500L

// slideshow animations
const val SLIDESHOW_ANIMATION_NONE = 0
const val SLIDESHOW_ANIMATION_SLIDE = 1
const val SLIDESHOW_ANIMATION_FADE = 2

const val CLICK_MAX_DURATION = 150
const val CLICK_MAX_DISTANCE = 100
const val DRAG_THRESHOLD = 8
const val SHORT_ANIMATION_DURATION = 150L
val DARK_GREY = 0xFF333333.toInt()

fun getDateFormats() = arrayListOf(
    "--MM-dd",
    "yyyy-MM-dd",
    "yyyyMMdd",
    "yyyy.MM.dd",
    "yy-MM-dd",
    "yyMMdd",
    "yy.MM.dd",
    "yy/MM/dd",
    "MM-dd",
    "MMdd",
    "MM/dd",
    "MM.dd"
)

const val DATE_FORMAT_ONE = "dd.MM.yyyy"
const val DATE_FORMAT_TWO = "dd/MM/yyyy"
const val DATE_FORMAT_THREE = "MM/dd/yyyy"
const val DATE_FORMAT_FOUR = "yyyy-MM-dd"
const val DATE_FORMAT_FIVE = "d MMMM yyyy"
const val DATE_FORMAT_SIX = "MMMM d yyyy"
const val DATE_FORMAT_SEVEN = "MM-dd-yyyy"
const val DATE_FORMAT_EIGHT = "dd-MM-yyyy"
const val DATE_FORMAT_NINE = "yyyyMMdd"
const val DATE_FORMAT_TEN = "yyyy.MM.dd"
const val DATE_FORMAT_ELEVEN = "yy-MM-dd"
const val DATE_FORMAT_TWELVE = "yyMMdd"
const val DATE_FORMAT_THIRTEEN = "yy.MM.dd"
const val DATE_FORMAT_FOURTEEN = "yy/MM/dd"
const val HIDE_FOLDER_NAME = ".Private"
const val RECENT_DELETE_FOLDER_NAME = ".RecentlyDeleted"
const val TIME_FORMAT_12 = "hh:mm a"
const val TIME_FORMAT_24 = "HH:mm"

const val MAX_COLUMN_COUNT_ALBUM = 6
const val MAX_COLUMN_COUNT_PICTURE = 8
const val FAST_FORWARD_VIDEO_MS = 10000

const val LOW_TILE_DPI = 160
const val NORMAL_TILE_DPI = 220
const val WEIRD_TILE_DPI = 240
const val HIGH_TILE_DPI = 280

const val TYPE_IMAGES = 1
const val TYPE_VIDEOS = 2
const val TYPE_GIFS = 8
//const val TYPE_RAWS = 8
//const val TYPE_SVGS = 16
//const val TYPE_PORTRAITS = 32

//const val IS_LARGE_MEDIA = "isLargeMedia"
//const val IS_SCREEN_SHOT = "isScreenShot"

const val MEMORY_CROSS_FADE_DURATION = 0


//fun getDefaultFileFilter() = TYPE_IMAGES or TYPE_VIDEOS or TYPE_GIFS or TYPE_RAWS or TYPE_SVGS
fun getDefaultFileFilter() = TYPE_IMAGES or TYPE_VIDEOS or TYPE_GIFS

fun isOnMainThread() = Looper.myLooper() == Looper.getMainLooper()

fun ensureBackgroundThread(callback: () -> Unit) {
    if (isOnMainThread()) {
        Thread {
            callback()
        }.start()
    } else {
        callback()
    }
}


object Constant {


    var BORDER_WIDTH: Int = 4

    var FORMAT_IMAGE = ImageTypeList()

    var INSTAGRAM: String = "com.instagram.android"

    var MESSENGER: String = "com.facebook.orca"

    var TWITTER: String = "com.twitter.android"

    var WHATSAPP: String = "com.whatsapp"

    var FACEBOOK: String = "com.facebook.katana"

    var GMAIL: String = "com.google.android.gm"


    class ImageTypeList internal constructor() : ArrayList<String?>() {
        init {
            add(".PNG")
            add(".JPEG")
            add(".jpg")
            add(".png")
            add(".jpeg")
            add(".JPG")
        }
    }

    val Context.isInstagramInstalled: Boolean
        get() = isAppInstalled(this, INSTAGRAM)

    val Context.isFacebookInstalled: Boolean
        get() = isAppInstalled(this, FACEBOOK)

    val Context.isMessengerInstalled: Boolean
        get() = isAppInstalled(this, MESSENGER)

    val Context.isTwitterInstalled: Boolean
        get() = isAppInstalled(this, TWITTER)

    val Context.isWhatsAppInstalled: Boolean
        get() = isAppInstalled(this, WHATSAPP)

    fun isAppInstalled(context: Context, packageName: String?): Boolean {
        try {
            val packageInfo = context.packageManager.getPackageInfo(packageName!!, 0)
            return true
        } catch (e: PackageManager.NameNotFoundException) {
            return false
        }
    }


    val ROOT_DIR_PATH = "/storage/emulated/0"
    val EXTRA_SELECT_TYPE: String = "select_type"
    val PREF_NAME: String = "Gallery"
    val PREF_ALBUM_CREATED: String = "album_created"
    val PREF_KEY_THEME: String = "key_is_theme"
    const val PREF_KEY_DELETE_BEHAVIOR: String = "PREF_KEY_DELETE_BEHAVIOR"
    val PREFS_FOLDER_GROUP_TYPE: String = "folder_group_type"
    val PREFS_FOLDER_GROUP_ORDER: String = "folder_group_order"
    val PREFS_FOLDER_SORT_TYPE: String = "folder_sort_type"
    val PREFS_FOLDER_SORT_ORDER: String = "folder_sort_order"
    val GROUP_BY: String = "group_by"
    val GROUP_ORDER_BY: String = "group_order_by"
    val PREFS_SORT_TYPE: String = "sort_type"
    val PREFS_SORT_ORDER: String = "sort_order"
    val FILTER_MEDIA: String = "filter_media"
    val PREFS_GRID_COUNT: String = "grid_count"
    val PREFS_ALBUM_GRID_COUNT: String = "album_grid_count"
    val PREFS_GRID_SHOW: String = "is_grid"
    val PREFS_SHOW_FILE_COUNT: String = "SHOW_FILE_COUNT"
    val PREF_PASSCODE: String = "passcode"
    val PREF_PATTERN: String = "Pattern"
    val PREF_SECURITY_SET: String = "security_set"
    val PREF_SECURITY_QUESTION: String = "security_question"

    val PREF_SECURITY_ANS: String = "security_ans"
    val ALLOW_DOWN_GESTURE: String = "allow_down_gesture"
    val HIDE_UI_ON_FULL_SCREEN: String = "hide_ui_on_full_screen"
    val ALLOW_PHOTO_GESTURES: String = "allow_photo_gestures"
    val ALLOW_VIDEO_GESTURES = "allow_video_gestures"
    val AUTOPLAY_VIDEOS = "autoplay_videos"
    val OPEN_VIDEOS_ON_SEPARATE_SCREEN = "open_videos_on_separate_screen"
    val BOTTOM_ACTIONS = "bottom_actions"
    val ALLOW_ZOOMING_IMAGES: String = "allow_zooming_images"
    val SHOW_HIGHEST_QUALITY: String = "show_highest_quality"
    val ALLOW_ONE_TO_ONE_ZOOM = "allow_one_to_one_zoom"
    val ALLOW_ROTATING_WITH_GESTURES = "allow_rotating_with_gestures"
    val BLACK_BACKGROUND = "dark_background"
    val pref_theme_badge = "pref_theme_badge"
    val pref_cal_manage_badge = "pref_cal_manage_badge"
    val pref_caller_card_badge = "pref_caller_card_badge"
    val pref_rate_app = "pref_rate_app"
    val SHARED_PREFS_EXCLUDE_LIST: String = "excluded_list"
    val SHARED_PREFS_INCLUDE_LIST: String = "included_list"

    val TYPE_EXCLUDED = "excluded_folders"
    val TYPE_INCLUDED = "included_folders"

    val LAST_VIDEO_POSITION_PREFIX = "last_video_position_"
    val REMEMBER_LAST_VIDEO_POSITION = "remember_last_video_position"
    val LOOP_VIDEOS = "loop_videos"

    val SCREEN_ROTATION = "screen_rotation"

    // rotations
    val ROTATE_BY_SYSTEM_SETTING = 0
    val ROTATE_BY_DEVICE_ROTATION = 1
    val ROTATE_BY_ASPECT_RATIO = 2

    val SHOW_EXTENDED_DETAILS = "show_extended_details"
    val EXTENDED_DETAILS = "extended_details"
    val HIDE_EXTENDED_DETAILS = "hide_extended_details"

    val EXTRA_IS_OPEN_FROM_SPLASH: String = "extra_isIntroduction"

    val EXT_NAME = 1
    val EXT_PATH = 2
    val EXT_SIZE = 4
    val EXT_RESOLUTION = 8
    val EXT_LAST_MODIFIED = 16
    val EXT_DATE_TAKEN = 32
    val EXT_CAMERA_MODEL = 64
    val EXT_EXIF_PROPERTIES = 128
    val EXT_DURATION = 256
    val EXT_ARTIST = 512
    val EXT_ALBUM = 1024
    val EXT_GPS = 2048

    val GROUP_BY_NONE = 1
    val GROUP_BY_LAST_MODIFIED_DAILY = 2
    val GROUP_BY_DATE_TAKEN_DAILY = 4
    val GROUP_BY_FILE_TYPE = 8
    val GROUP_BY_EXTENSION = 16
    val GROUP_BY_FOLDER = 32
    val GROUP_BY_LAST_MODIFIED_MONTHLY = 64
    val GROUP_BY_DATE_TAKEN_MONTHLY = 128

    //    val GROUP_DESCENDING = 1024
    val GROUP_SHOW_FILE_COUNT = 2048

    val SORT_NAME: Int = 1
    val SORT_PATH: Int = 2
    val SORT_SIZE: Int = 3
    val SORT_LAST_MODIFIED: Int = 4
    val SORT_DATE_TAKEN: Int = 5

    val ORDER_ASCENDING: Int = 1
    val ORDER_DESCENDING: Int = 2

    const val THEME_SYSTEM: Int = 0
    const val THEME_LIGHT: Int = 1
    const val THEME_DARK: Int = 2

    const val DELETE_BEHAVIOR_ADD_TO_RECYCLE_BIN: Int = 2
    const val DELETE_BEHAVIOR_PRESENTLY_DELETE: Int = 1
    const val DELETE_BEHAVIOR_ALWAYS_ASK: Int = 0

    var selectedPosition: Int = 0
    val EXTRA_DISPLAY_POS: String = "displayPos"
    val EXTRA_IS_OPEN_CAMERA_PERMISSION: String = "IsOpenCameraPer"
    val EXTRA_OPEN_TYPE_QUE: String = "OPEN_TYPE_QUE"
    val EXTRA_IS_OPEN_ALBUM: String = "isOpenAlbum"

    //    val EXTRA_IS_OPEN_PRIVATE: String = "isOpenPrivate"
    val EXTRA_IS_OPEN_RECENTLY_DELETE: String = "isOpenRecentlyDelete"
    val EXTRA_RESET_PASS: String = "resetPass"
    val EXTRA_CHANGE_PASS: String = "ChangePass"
    val EXTRA_CHANGE_EMAIL: String = "ChangeEmail"
    val EXTRA_CHANGE_LOCK_STYLE: String = "ChangeLockStyle"

    //    val EXTRA_LOCK_STYLE: String = "LockStyle"
    val EXTRA_WALL_PAPER: String = "wall_paper"
    val EXTRA_IMAGE_PATH: String = "IMAGE_PATH"
    val EXTRA_ALBUM_PATH: String = "album_path"
    val EXTRA_EDIT_IMAGE_PATH: String = "editImagePath"
    val EXTRA_EDIT_IMAGE_NAME: String = "editImageName"

    //    val EXTRA_EDIT_SAVE_IMAGE: String = "imagePath"
    val EXTRA_OPEN_URL: String = "openUrl"
    val EXTRA_IS_OPEN_HISTORY: String = "IS_OPEN_HISTORY"
    val EXTRA_BROWSER_URL: String = "extra_Browser_url"


    val PREF_SLIDE_TIME: String = "pref_slide_time"
    val PREF_SLIDE_EFFECT: String = "pref_slide_effect"
    val PREF_SLIDE_INCLUDE_VIDEO: String = "pref_slide_include_video"
    val PREF_SLIDE_INCLUDE_GIF: String = "pref_slide_include_gif"
    val PREF_SLIDE_RANDOM_ORDER: String = "pref_slide_random_order"
    val PREF_SLIDE_BACKWARD: String = "pref_slide_backward"
    val PREF_SLIDE_LOOP: String = "pref_slide_loop"

//    val HIDE_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).path + "/.Gallery/" + HIDE_FOLDER_NAME
//    val EDIT_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).path + "/Gallery/Edit"
//    val DELETE_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).path + "/.Gallery/" + RECENT_DELETE_FOLDER_NAME

    val ROOT_PATH = Environment.getExternalStorageDirectory().path
    val HIDE_PATH = "$ROOT_PATH/.Gallery/$HIDE_FOLDER_NAME"
    val DELETE_PATH = "$ROOT_PATH/.Gallery/$RECENT_DELETE_FOLDER_NAME"

    val EDIT_PATH = "$ROOT_PATH/Gallery/Edit"
    val RECOVER_PATH = "$ROOT_PATH/Gallery/Recover"
//    val SCREEN_SHOT_PATH = Environment.getExternalStorageDirectory().path + "/Gallery"

    var isChangeLanguage: Boolean = false
    var isReCreateHomeSS: Boolean = false

    const val ASPECT_RATIO_FREE = 0
    const val ASPECT_RATIO_CENTER = 7
    const val ASPECT_RATIO_1_1 = 1
    const val ASPECT_RATIO_3_4 = 2
    const val ASPECT_RATIO_4_3 = 3
    const val ASPECT_RATIO_9_16 = 4
    const val ASPECT_RATIO_2_3 = 5
    const val ASPECT_RATIO_3_2 = 6
    const val ASPECT_RATIO_ONE_ONE = 1
    const val ASPECT_RATIO_FOUR_THREE = 2
    const val ASPECT_RATIO_SIXTEEN_NINE = 3
    const val ASPECT_RATIO_OTHER = 4

    const val SELECT_TYPE_CRATE_ALBUM = 1
    const val SELECT_TYPE_HIDE = 2

    enum class AnimationTypes(val id: Int, val value: String) {
        NONE(0, "None"),
        ZOOM_IN(1, "ZoomIn"),
        ZOOM_OUT(2, "ZoomOut"),
        DEPTH_SLIDE(3, "Depth Slide"),
        CUBE_IN(4, "CubeIn"),
        CUBE_OUT(5, "CubeOut"),
        FLIP_HORIZONTAL(6, "Flip Horizontal"),
        FLIP_VERTICAL(7, "Flip Vertical"),
        FOREGROUND_TO_BACKGROUND(8, "ForegroundToBackground"),
        BACKGROUND_TO_FOREGROUND(9, "BackgroundToForeground"),
        ROTATE_UP(10, "Rotate Up"),
        ROTATE_DOWN(11, "Rotate Down"),
        GATE(12, "Gate"),
        TOSS(13, "Toss");
//        FIDGET_SPINNER("FidgetSpinner")
    }

    @ChecksSdkIntAtLeast(api = Build.VERSION_CODES.N)
    fun isNougatPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N

    @ChecksSdkIntAtLeast(api = Build.VERSION_CODES.N_MR1)
    fun isNougatMR1Plus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1

    @ChecksSdkIntAtLeast(api = Build.VERSION_CODES.O)
    fun isOreoPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O

    @ChecksSdkIntAtLeast(api = Build.VERSION_CODES.Q)
    fun isQPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

    @ChecksSdkIntAtLeast(api = Build.VERSION_CODES.R)
    fun isRPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

    @ChecksSdkIntAtLeast(api = Build.VERSION_CODES.S)
    fun isSPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    @ChecksSdkIntAtLeast(api = Build.VERSION_CODES.TIRAMISU)
    fun isTiramisuPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

    @ChecksSdkIntAtLeast(api = Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
    fun isUpsideDownCakePlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE


    fun startZoomAnimation(view: View) {
        val scaleUpX = ObjectAnimator.ofFloat(view, "scaleX", 1f, 0.9f)
        val scaleUpY = ObjectAnimator.ofFloat(view, "scaleY", 1f, 0.9f)
        val scaleDownX = ObjectAnimator.ofFloat(view, "scaleX", 0.9f, 1f)
        val scaleDownY = ObjectAnimator.ofFloat(view, "scaleY", 0.9f, 1f)

        val scaleUpSet = AnimatorSet().apply {
            playTogether(scaleUpX, scaleUpY)
            duration = 500
            interpolator = LinearInterpolator()
        }

        val scaleDownSet = AnimatorSet().apply {
            playTogether(scaleDownX, scaleDownY)
            duration = 500
            interpolator = LinearInterpolator()
        }

        val animatorSet = AnimatorSet()
        animatorSet.playSequentially(scaleUpSet, scaleDownSet)

        animatorSet.doOnEnd { animatorSet.start() }
        animatorSet.start()
    }


}