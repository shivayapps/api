package gallery.photogallery.photoeditor.galleryapp.viewlayout

import android.content.Intent
import android.widget.ImageView
import androidx.lifecycle.lifecycleScope
import com.appblish.box.api.util.MediaDataState
import com.appblish.gallery.core.v2.api.model.PlaceListItem
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import gallery.photogallery.photoeditor.galleryapp.activities.CleanerScanActivity
import gallery.photogallery.photoeditor.galleryapp.activities.HiddenAlbumActivity
import gallery.photogallery.photoeditor.galleryapp.activities.MainActivity
import gallery.photogallery.photoeditor.galleryapp.activities.PlacesActivity
import gallery.photogallery.photoeditor.galleryapp.activities.SettingActivity
import gallery.photogallery.photoeditor.galleryapp.activities.TrashActivity
import gallery.photogallery.photoeditor.galleryapp.collage.activities.CollageImageSelectionActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.FragmentExploreBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.SetLockActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.VerifyLockActivityBaseActivity
import kotlinx.coroutines.launch

class ExploreLayout(private val mainActivity: MainActivity, private val binding: FragmentExploreBinding) {
    private val lifecycleScope = mainActivity.lifecycleScope
    private val sharedViewModel = mainActivity.sharedViewModel
    private fun getString(resId: Int) = mainActivity.getString(resId)

    fun setupViews() {
        init()
    }

    private fun init() {
        observablePlaces()
        setupListener()
    }

    private fun setupListener() {
        binding.llTrash.setOnClickListener {
            mainActivity.checkStoragePermission {
                if (it) {
                    mainActivity.startActivity(Intent(mainActivity, TrashActivity::class.java))
                }
            }

        }
        binding.llPrivate.setOnClickListener {
            mainActivity.checkStoragePermission {
                if (it) {
                    if (mainActivity.preferences.getSetPass()) {
                        val intent = Intent(mainActivity, VerifyLockActivityBaseActivity::class.java)
                        mainActivity.startActivity(intent)
                    } else {
                        val intent = Intent(mainActivity, SetLockActivity::class.java)
                        intent.putExtra("setResultCode", 100)
                        mainActivity.lockActivityResultLauncher.launch(intent)
                    }
                }
            }

        }

        binding.ivSetting.setOnClickListener {
            val intent = Intent(mainActivity, SettingActivity::class.java)
            mainActivity.startActivity(intent)
        }
        binding.llCollage.setOnClickListener {
            mainActivity.checkStoragePermission {
                if (it) {
                    val intent = Intent(mainActivity, CollageImageSelectionActivity::class.java)
                    mainActivity.startActivity(intent)
                }
            }

        }

        binding.llClear.setOnClickListener {
            mainActivity.checkStoragePermission {
                if (it) {
                    val intent = Intent(mainActivity, CleanerScanActivity::class.java)
                    mainActivity.startActivity(intent)
                }
            }

        }

        binding.cardGrid.setOnClickListener {
            val intent = Intent(mainActivity, PlacesActivity::class.java)
            intent.putExtra("ARG_POSITION", false)
            mainActivity.startActivity(intent)
        }

        binding.cardMap.setOnClickListener {
            val intent = Intent(mainActivity, PlacesActivity::class.java)
            intent.putExtra("ARG_POSITION", true)
            mainActivity.startActivity(intent)
        }

    }

    fun launchPrivate() {
        val intent = Intent(mainActivity, HiddenAlbumActivity::class.java)
        mainActivity.startActivity(intent)
    }

    private fun observableCategories() {
        lifecycleScope.launch {
            /* sharedViewModel.categoriesStateFlow.collect {
                 when (it) {
                     DataState.Empty -> {
                         fetchCategories(emptyList())
                     }

                     DataState.Loading -> {
                     }

                     is DataState.Success -> {
                         fetchCategories(it.data as List<CategoryAlbumModel>)
                     }
                 }
             }*/
        }
    }


    fun observablePlaces() {
        lifecycleScope.launch {
            when (val state = sharedViewModel.getPlacesFlow()) {
                MediaDataState.Loading -> {
                    binding.llNoDataPlces.apply {
                        beVisible()

                    }
                }

                is MediaDataState.Progress -> {
                    if (state.percent % 20 == 0) {
                        sharedViewModel.fetchPlacesItems()
                    }
                }

                is MediaDataState.Success -> {
                    fetchPlaces(state.data)
                }

                MediaDataState.Empty -> {
                    fetchPlaces(emptyList())
                }
            }
        }
    }

    fun getPlacesList() = binding.csPlaces.tag as? List<PlaceListItem>
    private fun fetchPlaces(placesAlbums: List<PlaceListItem>) {
        lifecycleScope.launch {
            if (placesAlbums.isNotEmpty()) {
                if (placesAlbums == binding.csPlaces.tag) return@launch
                binding.csPlaces.tag = placesAlbums
                binding.csPlaces.beVisible()
                binding.llNoDataPlces.beGone()

                val imageViews = listOf(
                    binding.image1,
                    binding.image2,
                    binding.image3,
                    binding.image4
                )

                placesAlbums.take(4).forEachIndexed { index, album ->
                    album.mediaList.getOrNull(0)?.let { mediaRow ->
                        imageViews[index].apply {
                            loadGridImage(mediaRow.mediaPath, mediaRow.mediaDate)
                            scaleType = ImageView.ScaleType.CENTER_CROP

                        }
                    }
                }
            } else {
                binding.csPlaces.beGone()
                binding.llNoDataPlces.beVisible()
            }
        }
    }
}