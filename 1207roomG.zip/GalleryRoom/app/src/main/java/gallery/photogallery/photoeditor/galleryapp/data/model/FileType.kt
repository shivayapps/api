package gallery.photogallery.photoeditor.galleryapp.data.model

enum class FileType(val id: Long) {
    ALL(0),
    Image(1),
    Video(2),
    Gif(3)
}