package gallery.photogallery.photoeditor.galleryapp.old.ui.main.remote

import android.content.Context
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.getThemeSharedPrefs
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.PRIVACY_POLICY


class ClientConfigPref(val context: Context) {
    protected val prefs = context.getThemeSharedPrefs()

    companion object {
        fun newInstance(context: Context) = ClientConfigPref(context)
    }



    var privacyPolicy: String
        get() = prefs.getString("PREF_PRIVACY_POLICY", PRIVACY_POLICY) ?: PRIVACY_POLICY
        set(privacyPolicy) = prefs.edit().putString("PREF_PRIVACY_POLICY", privacyPolicy).apply()

    var feedbackEmail: String
        get() = prefs.getString("PREF_FEEDBACK_EMAIL", "pigames2019@gmail.com") ?: "pigames2019@gmail.com"
        set(feedbackEmail) = prefs.edit().putString("PREF_FEEDBACK_EMAIL", feedbackEmail).apply()

    var reviewEmail: String
        get() = prefs.getString("PREF_reviewEmail", "pigames2019@gmail.com") ?: "pigames2019@gmail.com"
        set(callerCardAdType) = prefs.edit().putString("PREF_reviewEmail", callerCardAdType).apply()


    var moreApps: String
        get() = prefs.getString("PREF_moreApps", "") ?: ""
        set(moreApps) = prefs.edit().putString("PREF_moreApps", moreApps).apply()
    var appUpdate: String
        get() = prefs.getString("PREF_appUpdate", "") ?: ""
        set(moreApps) = prefs.edit().putString("PREF_appUpdate", moreApps).apply()

    var bottomNavigationDefaultScrollHide: Boolean
        get() = prefs.getBoolean("bottomNavigationDefaultScrollHide", true) ?: false
        set(value) = prefs.edit().putBoolean("bottomNavigationDefaultScrollHide", value).apply()

    var bottomNavigationScrollMode: Boolean
        get() = prefs.getBoolean("bottomNavigationScrollMode", bottomNavigationDefaultScrollHide)
        set(value) = prefs.edit().putBoolean("bottomNavigationScrollMode", value).apply()


    var appDefaultConfig: String
        get() = prefs.getString("appDefaultConfig", "") ?: ""
        set(adIdsTest) = prefs.edit().putString("appDefaultConfig", adIdsTest).apply()

    var appRedirectConfig: String
        get() = prefs.getString("appRedirectConfig", "") ?: ""
        set(moreApps) = prefs.edit().putString("appRedirectConfig", moreApps).apply()

}