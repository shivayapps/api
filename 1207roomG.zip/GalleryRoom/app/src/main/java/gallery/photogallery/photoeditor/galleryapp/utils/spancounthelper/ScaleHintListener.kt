package gallery.photogallery.photoeditor.galleryapp.utils.spancounthelper

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.core.graphics.createBitmap
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt


class ScaleHintListener(
    context: Context,
    private val recyclerView: RecyclerView,
    private val layoutManager: GridLayoutManager,
    private val overlayContainer: FrameLayout,
    private val ghostCardView: MaterialCardView,
    private val ghostImageView: ImageView,
    private val gridHelperView: GridHelperView,
    private val imageViewExtractor: (View) -> ImageView?,
    private val onUpdateSpan: (Int) -> Unit,
    private val dimLayer: View,
    private val spanHintText: TextView,
    private val landingCircle: View,
    private val minSpan: Int = 2,
    private val maxSpan: Int = 8
) : View.OnTouchListener {

    private val scaleDetector: ScaleGestureDetector

    // STATE LOCK
    private var isInteractionActive = false
    private var isScaling = false

    private var currentScale = 1.0f
    private var startSpan = 0
    private var pivotX = -1F
    private var pivotY = -1F

    // UX Tracking
    private var lastHapticSpan = 0
    private var hiddenGridItem: View? = null
    private val ghostOriginalRect = Rect()
    private val displayMetrics = context.resources.displayMetrics
    private val screenCenterX = displayMetrics.widthPixels / 2f
    private val screenCenterY = displayMetrics.heightPixels / 2f
    private var isScrollingFast = false

    init {
        scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {

                // 1. Get Coordinates First
                val px = detector.focusX
                val py = detector.focusY
                val viewUnderFinger = recyclerView.findChildViewUnder(px, py) ?: return false
                val holder = recyclerView.getChildViewHolder(viewUnderFinger)

                // 2. CHECK HEADER (Adjust '1' to your actual header viewType)
                if (holder.itemViewType == 0) {
                    return false // Ignore gesture entirely
                }

                // 3. LOCK THE RECYCLERVIEW
                isInteractionActive = true
                isScaling = true

                // Set Pivot
                pivotX = px
                pivotY = py

                // CRITICAL: Lock RecyclerView
                recyclerView.requestDisallowInterceptTouchEvent(true)
                recyclerView.suppressLayout(true)

                currentScale = 1.0f
                startSpan = layoutManager.spanCount
                lastHapticSpan = startSpan

                setupGhost(viewUnderFinger)

                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (!isScaling) return false

                val maxScaleLimit = startSpan.toFloat() / minSpan.toFloat()
                val minScaleLimit = startSpan.toFloat() / maxSpan.toFloat()

                var newScale = currentScale * detector.scaleFactor
                if (newScale > maxScaleLimit) newScale = maxScaleLimit
                if (newScale < minScaleLimit) newScale = minScaleLimit
                currentScale = newScale

                ghostCardView.scaleX = currentScale
                ghostCardView.scaleY = currentScale

                // 3D Tilt
                val tiltStrength = 15f
                val tiltY = (screenCenterX - detector.focusX) / screenCenterX * tiltStrength
                val tiltX = (detector.focusY - screenCenterY) / screenCenterY * tiltStrength
                ghostCardView.rotationY = tiltY
                ghostCardView.rotationX = tiltX

                // Depth
                val depthFactor = 1.0f - (min(Math.abs(currentScale - 1f), 1f) * 0.05f)
                recyclerView.scaleX = depthFactor
                recyclerView.scaleY = depthFactor
                recyclerView.alpha = 0.5f + (depthFactor * 0.5f)

                updateUXFeedback()
                updateGridVisuals()

                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {

            }
        })
        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                super.onScrollStateChanged(rv, newState)

                // Disable pinch zoom during fast scroll / fling
                isScrollingFast = newState == RecyclerView.SCROLL_STATE_SETTLING
                if (newState != RecyclerView.SCROLL_STATE_IDLE) {
                    isScrollingFast = false
                }
            }
        })
    }

    override fun onTouch(v: View, event: MotionEvent): Boolean {
        if (isScrollingFast) {
            return false   // Ignore pinch zoom
        }
        // 2) Only allow interaction when exactly TWO fingers are down
        if (event.pointerCount >= 2) {
            scaleDetector.onTouchEvent(event)
        }


        if (isInteractionActive) {
            if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) {
                if (isScaling) {
                    finishInteraction()

                } else {
                    // Safety: If active but not scaling (edge case), force cleanup
                    cleanup()
                }
            }
            return true
        }
        return false
    }

    private fun setupGhost(target: View) {
        hiddenGridItem = target
        target.getGlobalVisibleRect(ghostOriginalRect)
        val overlayRect = Rect()
        overlayContainer.getGlobalVisibleRect(overlayRect)
        ghostOriginalRect.offset(-overlayRect.left, -overlayRect.top)

        val sourceImg = imageViewExtractor(target)
//        val bitmap = sourceImg?.toBitmap()
        // Safety check if imageview is missing
        if (sourceImg != null && sourceImg.drawable != null) {
            ghostImageView.setImageDrawable(sourceImg.drawable)
        }

        val params = ghostCardView.layoutParams as FrameLayout.LayoutParams
        params.width = ghostOriginalRect.width()
        params.height = ghostOriginalRect.height()
        params.leftMargin = ghostOriginalRect.left
        params.topMargin = ghostOriginalRect.top
        ghostCardView.layoutParams = params
        ghostCardView.pivotX = pivotX - ghostOriginalRect.left
        ghostCardView.pivotY = pivotY - ghostOriginalRect.top
        ghostCardView.translationX = 0f
        ghostCardView.translationY = 0f
        ghostCardView.scaleX = 1f
        ghostCardView.scaleY = 1f
        ghostCardView.rotationX = 0f
        ghostCardView.rotationY = 0f
        ghostCardView.radius = 0f
        ghostCardView.cardElevation = 0f

        val cornerAnim = ValueAnimator.ofFloat(0f, 40f)
        cornerAnim.addUpdateListener { ghostCardView.radius = it.animatedValue as Float }
        cornerAnim.duration = 200
        cornerAnim.start()

        val elevationAnim = ValueAnimator.ofFloat(0f, 50f)
        elevationAnim.addUpdateListener { ghostCardView.cardElevation = it.animatedValue as Float }
        elevationAnim.duration = 200
        elevationAnim.start()

        overlayContainer.visibility = View.VISIBLE
        hiddenGridItem?.alpha = 0f
        dimLayer.alpha = 0f
        dimLayer.animate().alpha(1f).setDuration(250).start()
        gridHelperView.alpha = 0f
        gridHelperView.animate().alpha(1f).setDuration(250).start()
        spanHintText.alpha = 0f
        spanHintText.scaleX = 0.8f
        spanHintText.scaleY = 0.8f
        spanHintText.text = "$startSpan Columns"
        spanHintText.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(250).start()
        updateGridVisuals()
    }

    private fun updateUXFeedback() {
        var currentProposedSpan = (startSpan / currentScale).roundToInt()
        currentProposedSpan = max(minSpan, min(currentProposedSpan, maxSpan))
        if (currentProposedSpan != lastHapticSpan) {
            recyclerView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING)
            gridHelperView.flash()
            spanHintText.text = "$currentProposedSpan Columns"
            spanHintText.animate().cancel()
            spanHintText.scaleX = 1.4f
            spanHintText.scaleY = 1.4f
            spanHintText.animate().scaleX(1f).scaleY(1f).setDuration(300).setInterpolator(OvershootInterpolator(2.0f)).start()
            lastHapticSpan = currentProposedSpan
        }
    }

    private fun updateGridVisuals() {
        val visualW = ghostOriginalRect.width() * currentScale
        val visualH = ghostOriginalRect.height() * currentScale
        val pX = ghostCardView.pivotX + ghostOriginalRect.left
        val pY = ghostCardView.pivotY + ghostOriginalRect.top
        val visualLeft = pX - (ghostCardView.pivotX * currentScale)
        val visualTop = pY - (ghostCardView.pivotY * currentScale)
        val currentRect = RectF(visualLeft, visualTop, visualLeft + visualW, visualTop + visualH)
        gridHelperView.updateGrid(currentRect)
    }

    private fun finishInteraction() {

        // Reset Background
        recyclerView.animate()
            .scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(300)
            .setInterpolator(OvershootInterpolator(1.0f))
            .start()

        // Fade out UX
        dimLayer.animate().alpha(0f).setDuration(250).start()
        gridHelperView.animate().alpha(0f).setDuration(250).start()
        spanHintText.animate().alpha(0f).translationY(50f).setDuration(200).start()

        // Reset 3D
        ghostCardView.animate().rotationX(0f).rotationY(0f).setDuration(300).start()

        // Flatten Card
        val cornerAnim = ValueAnimator.ofFloat(ghostCardView.radius, 0f)
        cornerAnim.addUpdateListener { ghostCardView.radius = it.animatedValue as Float }
        cornerAnim.duration = 300
        cornerAnim.start()

        val elevationAnim = ValueAnimator.ofFloat(ghostCardView.cardElevation, 0f)
        elevationAnim.addUpdateListener { ghostCardView.cardElevation = it.animatedValue as Float }
        elevationAnim.duration = 300
        elevationAnim.start()

        // Update Layout
        var newSpan = (startSpan / currentScale).roundToInt()
        newSpan = max(minSpan, min(newSpan, maxSpan))
        val isChanged = newSpan != startSpan

        // Unlock layout for update
        recyclerView.suppressLayout(false)

        if (isChanged) {
            layoutManager.spanCount = newSpan
            onUpdateSpan.invoke(newSpan)
            recyclerView.adapter?.notifyItemRangeChanged(0, recyclerView.adapter!!.itemCount)
            if (hiddenGridItem != null) {
                val pos = recyclerView.getChildAdapterPosition(hiddenGridItem!!)
                layoutManager.scrollToPosition(pos)
            }
        }

        // Fly Home
        recyclerView.post { animateToNewPosition() }
    }

    private fun animateToNewPosition() {
        val adapterPos = if (hiddenGridItem != null) recyclerView.getChildAdapterPosition(hiddenGridItem!!) else 0
        val holder = recyclerView.findViewHolderForAdapterPosition(adapterPos)

        // --- FIX IS HERE ---
        val targetView = holder?.itemView ?: hiddenGridItem

        // SAFETY CHECK: If we absolutely cannot find the view (e.g. scrolled off screen),
        // we MUST call cleanup() immediately, otherwise the app freezes.
        if (targetView == null) {
            cleanup()
            return
        }

        val destRect = Rect()
        targetView.getGlobalVisibleRect(destRect)
        val overlayRect = Rect()
        overlayContainer.getGlobalVisibleRect(overlayRect)
        destRect.offset(-overlayRect.left, -overlayRect.top)

        val targetScaleX = destRect.width().toFloat() / ghostOriginalRect.width().toFloat()
        val targetScaleY = destRect.height().toFloat() / ghostOriginalRect.height().toFloat()

        ghostCardView.animate()
            .x(destRect.left.toFloat() - (ghostCardView.width * (1 - targetScaleX)) / 2)
            .y(destRect.top.toFloat() - (ghostCardView.height * (1 - targetScaleY)) / 2)
            .scaleX(targetScaleX)
            .scaleY(targetScaleY)
            .withStartAction {
                ghostCardView.pivotX = ghostCardView.width / 2f
                ghostCardView.pivotY = ghostCardView.height / 2f
                updateGridVisuals()
                val visualLeft = ghostOriginalRect.left + (ghostCardView.pivotX) - (ghostCardView.pivotX * currentScale)
                val visualTop = ghostOriginalRect.top + (ghostCardView.pivotY) - (ghostCardView.pivotY * currentScale)
                ghostCardView.x = visualLeft
                ghostCardView.y = visualTop
                ghostCardView.scaleX = currentScale
                ghostCardView.scaleY = currentScale
            }
            .setDuration(400)
            .setInterpolator(OvershootInterpolator(1.0f))
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    playLandingRipple(destRect)
                    cleanup()
                }

                // Extra Safety: If animation gets cancelled
                override fun onAnimationCancel(animation: Animator) {
                    cleanup()
                }
            })
            .start()
    }

    private fun playLandingRipple(rect: Rect) {
        val params = landingCircle.layoutParams as FrameLayout.LayoutParams
        params.width = rect.width()
        params.height = rect.height()
        params.leftMargin = rect.left
        params.topMargin = rect.top
        landingCircle.layoutParams = params

        landingCircle.scaleX = 1.0f
        landingCircle.scaleY = 1.0f
        landingCircle.alpha = 1.0f
        landingCircle.visibility = View.VISIBLE

        landingCircle.animate()
            .scaleX(1.6f)
            .scaleY(1.6f)
            .alpha(0f)
            .setDuration(400)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    private fun cleanup() {
        // Reset internal state
        pivotX = -1F
        pivotY = -1F

        overlayContainer.visibility = View.GONE
        hiddenGridItem?.alpha = 1f
        hiddenGridItem = null
        ghostCardView.scaleX = 1f
        ghostCardView.scaleY = 1f
        ghostCardView.translationX = 0f
        ghostCardView.translationY = 0f
        ghostCardView.rotationX = 0f
        ghostCardView.rotationY = 0f
        spanHintText.translationY = 0f
        landingCircle.visibility = View.GONE

        // UNLOCK INTERACTIONS
        isInteractionActive = false
        isScaling = false
        recyclerView.requestDisallowInterceptTouchEvent(false)

    }


    fun View.toBitmap(): Bitmap {
        this.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        this.layout(0, 0, this.measuredWidth, this.measuredHeight)

        val bitmap = createBitmap(this.measuredWidth, this.measuredHeight)
        val canvas = Canvas(bitmap)
        this.draw(canvas)
        return bitmap
    }
}