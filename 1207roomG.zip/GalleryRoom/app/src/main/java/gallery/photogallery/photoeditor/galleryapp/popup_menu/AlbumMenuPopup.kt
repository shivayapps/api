package gallery.photogallery.photoeditor.galleryapp.popup_menu

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupWindow
import gallery.photogallery.photoeditor.galleryapp.activities.MainActivity
import gallery.photogallery.photoeditor.galleryapp.activities.SettingActivity
import gallery.photogallery.photoeditor.galleryapp.activities.TrashActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.PopupAlbumMenuBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.ColumnsCountDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.CreateNewAlbumDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.SortByDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.dpToPx
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.SelectAlbumImageActivity
import gallery.photogallery.photoeditor.galleryapp.utils.RESET_ALBUM_GRID
import gallery.photogallery.photoeditor.galleryapp.utils.sendIntentEvent
import androidx.core.graphics.drawable.toDrawable

class AlbumMenuPopup(private val mainActivity: BaseActivity) {

    fun show(anchor: View) {

        val context = anchor.context
        val binding = PopupAlbumMenuBinding.inflate(
            LayoutInflater.from(context)
        )

        val popup = PopupWindow(
            binding.root,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        ).apply {
            elevation = 12f
            isOutsideTouchable = true
            setBackgroundDrawable(Color.TRANSPARENT.toDrawable())
        }

        binding.btnList.beVisibleIf(context.appPref.albumAsGrid)
        binding.btnGrid.beVisibleIf(!context.appPref.albumAsGrid)
        binding.btnDisplayedColumns.beVisibleIf(context.appPref.albumAsGrid)

        binding.btnCreateAlbum.setOnClickListener {
            popup.dismiss()
            (context as? MainActivity)?.checkStoragePermission {
                if (it) {
                    CreateNewAlbumDialog { newAlbum ->
                        context.startActivity(
                            SelectAlbumImageActivity.createIntentImageSelect(
                                context, newAlbum, true
                            )
                        )
                    }.show(mainActivity.supportFragmentManager, "CreateAlbumBottomSheet")
                }
            }
        }

        binding.btnSortBy.setOnClickListener {
            popup.dismiss()
            SortByDialog {
                mainActivity.sharedViewModel.fetchMedia()
            }.show(mainActivity.supportFragmentManager, "BottomSheet")
        }

        binding.btnList.setOnClickListener {
            context.appPref.albumAsGrid = false
            sendIntentEvent(RESET_ALBUM_GRID)
            popup.dismiss()
        }

        binding.btnGrid.setOnClickListener {
            context.appPref.albumAsGrid = true
            sendIntentEvent(RESET_ALBUM_GRID)
            popup.dismiss()
        }

        binding.btnDisplayedColumns.setOnClickListener {
            popup.dismiss()
            ColumnsCountDialog(true).show(mainActivity.supportFragmentManager, "BottomSheet")
        }

        binding.btnRecycleBin.setOnClickListener {
            popup.dismiss()
            context.startActivity(
                Intent(context, TrashActivity::class.java)
            )
        }

        binding.btnSetting.setOnClickListener {
            popup.dismiss()
            context.startActivity(
                Intent(context, SettingActivity::class.java)
            )
        }

        binding.root.measure(
            View.MeasureSpec.UNSPECIFIED,
            View.MeasureSpec.UNSPECIFIED
        )

        val popupWidth = binding.root.measuredWidth
        val marginRight = 6.dpToPx(context)

        val xOffset = anchor.width - popupWidth - marginRight

        popup.showAsDropDown(anchor, xOffset, 0)

        popup.showAsDropDown(anchor)
    }
}
