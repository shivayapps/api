package gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialogactivity

import android.os.Bundle
import android.view.Gravity
import androidx.appcompat.app.AppCompatActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.StoragePermissionDialogBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding

class PermissionDialogActivity : AppCompatActivity() {

    private val binding by viewBinding(StoragePermissionDialogBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        window.setGravity(Gravity.CENTER)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.btnOkay.setOnClickListener {
            setResult(RESULT_OK)
            finish()

        }
        binding.btnCancel.setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }

}
