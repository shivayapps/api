package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.appblish.gallery.core.v2.api.model.AlbumListItem
import com.appblish.gallery.core.v2.api.model.AlbumModel
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import com.appblish.recyclerview.dragselection.BaseSelectableAdapter
import com.appblish.recyclerview.dragselection.DragSelectionMode
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemAlbumGridBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemAlbumListBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemHeaderDividerBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isGif
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isVideoFast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.lastClickTS
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.CLICK_HOLD
import java.io.File

class AlbumListAdapter(
    recyclerView: RecyclerView,
    val onAlbumSelect: (AlbumModel) -> Unit,
) : BaseSelectableAdapter<AlbumListItem, RecyclerView.ViewHolder>(recyclerView, DragSelectionMode.RANGE) {
    private val albumList = ArrayList<AlbumListItem>()

    companion object {
        const val HEADER = 0
        const val ALBUM = 1
    }

    fun submitList(list: List<AlbumListItem>) {
        albumList.clear()
        albumList.addAll(list)
        notifyDataSetChanged()
    }


    fun getItem(position: Int): AlbumListItem = albumList[position]

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        if (holder is AlbumViewHolder) {
            Glide.with(holder.binding.imageAlbum.context).clear(holder.binding.imageAlbum)
        }
        if (holder is AlbumListViewHolder) {
            Glide.with(holder.binding.imageAlbum.context).clear(holder.binding.imageAlbum)
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int,
    ): RecyclerView.ViewHolder {
        return when (viewType) {
            HEADER -> {
                val binding = ItemHeaderDividerBinding.inflate(
                    android.view.LayoutInflater.from(parent.context), parent, false
                )
                HeaderViewHolder(binding)
            }

            ALBUM -> {
                if (parent.context.appPref.albumAsGrid) {
                    val binding = ItemAlbumGridBinding.inflate(
                        android.view.LayoutInflater.from(parent.context), parent, false
                    )
                    AlbumViewHolder(binding)
                } else {
                    val binding = ItemAlbumListBinding.inflate(
                        android.view.LayoutInflater.from(parent.context), parent, false
                    )
                    AlbumListViewHolder(binding)
                }

            }

            else -> {
                throw IllegalArgumentException("Invalid view type")
            }
        }
    }

    override fun getItemAt(position: Int): AlbumListItem? {
        return albumList.getOrNull(position)
    }

    override fun getItemKey(item: AlbumListItem): Long {
        return item.id
    }

    override fun isSelectable(item: AlbumListItem): Boolean {
        return item is AlbumListItem.Album && !item.albumBox.isCustom
    }

    override fun isHeader(position: Int): Boolean {
        return albumList[position] is AlbumListItem.Header
    }

    override fun isSelectionEnabled() = true

    override fun bindItem(holder: RecyclerView.ViewHolder, item: AlbumListItem, position: Int) {
        when (holder) {
            is AlbumViewHolder -> {
                holder.bind(item)
            }

            is AlbumListViewHolder -> {
                holder.bind(item)
            }

            is HeaderViewHolder -> {
                holder.bind(item as AlbumListItem.Header)
            }
        }
    }

    override fun bindSelection(holder: RecyclerView.ViewHolder, item: AlbumListItem, position: Int, selected: Boolean) {
        holder.itemView.isActivated = selected
        if (!isSelectable(item)) return
        when (holder) {
            is AlbumViewHolder -> {
                if (isSelectionActive()) {
                    holder.binding.icUnSelect.visibility = View.VISIBLE
                    holder.binding.icSelect.visibility =
                        if (selected) View.VISIBLE else View.GONE
                } else {
                    holder.binding.icUnSelect.visibility = View.GONE
                    holder.binding.icSelect.visibility = View.GONE
                }
            }

            is AlbumListViewHolder -> {
                if (isSelectionActive()) {
                    holder.binding.icUnSelect.visibility = View.VISIBLE
                    holder.binding.icSelect.visibility =
                        if (selected) View.VISIBLE else View.GONE
                } else {
                    holder.binding.icUnSelect.visibility = View.GONE
                    holder.binding.icSelect.visibility = View.GONE
                }
            }

        }
    }


    override fun getItemViewType(position: Int): Int {
        return if (albumList[position] is AlbumListItem.Header) {
            HEADER
        } else {
            ALBUM
        }
    }

    override fun getItemCount(): Int = albumList.size

    fun selectAll() {
        selectAllItems()
        notifyDataSetChanged()
    }

    fun unSelectAll() {
        unselectAllItems()
        notifyDataSetChanged()
    }

    fun isSelectAll() = isAllSelectedItems()


    inner class AlbumViewHolder(val binding: ItemAlbumGridBinding) :
        RecyclerView.ViewHolder(binding.root) {

        @SuppressLint("SetTextI18n")
        fun bind(albumListItem: AlbumListItem) {
            val album = albumListItem as AlbumListItem.Album
            val albumData = album.albumBox
            binding.apply {
                icPin.beVisibleIf(albumData.isPinned)
                Log.e("AlbumListViewHolder", "bind: ${album.albumBox.bucketPath}  ${albumData.isPinned}")

                txtTitle.text = getAlbumTitle(root.context, albumData.bucketName)

                txtCount.text = "${albumData.mediaList.size} ${root.context.getString(R.string.items)}"
                ivRecentIcon.beGone()
                imageAlbum.beVisible()
                Log.e("CheckSortingAlbum", "bind: ${album.mediaPath} ${album.albumBox.mediaList.first().mediaSize}")

                val context = imageAlbum.context
                val coverPath = context.preferences.getCoverImage(albumData.bucketPath)
                if (coverPath.isNotEmpty()) {
                    imageAlbum.loadGridImage(coverPath, File(coverPath).lastModified())
                    icVideo.beVisibleIf(coverPath.isVideoFast())
                    ivGif.beVisibleIf(coverPath.isGif())

                } else {
                    imageAlbum.loadGridImage(album.mediaPath, album.mediaDate)
                    ivGif.beVisibleIf(album.mediaPath.isGif())
                    icVideo.beVisibleIf(album.mediaPath.isVideoFast())
                }
                if (albumData.bucketName == "recent") {
                    ivRecentIcon.beVisible()
                }

                if (isSelectionActive() && !albumData.isCustom) {
                    icUnSelect.visibility = View.VISIBLE
                    icSelect.visibility =
                        if (isItemSelected(bindingAdapterPosition)) View.VISIBLE else View.GONE
                } else {
                    icUnSelect.visibility = View.GONE
                    icSelect.visibility = View.GONE
                }

            }
        }
    }

    override fun onItemOpen(item: AlbumListItem, position: Int, view: View) {
        if (System.currentTimeMillis() - lastClickTS > CLICK_HOLD) {
            lastClickTS = System.currentTimeMillis()
            if (item is AlbumListItem.Album) {
                onAlbumSelect(item.albumBox)
            }
        }
    }

    override fun onSelectionModeUpdate() {
        notifyDataSetChanged()
    }

    inner class AlbumListViewHolder(var binding: ItemAlbumListBinding) :
        RecyclerView.ViewHolder(binding.root) {
        @SuppressLint("SetTextI18n")
        fun bind(albumListItem: AlbumListItem) {
            val album = albumListItem as AlbumListItem.Album
            val albumData = album.albumBox
            binding.apply {
                icPin.beVisibleIf(albumData.isPinned)
                Log.e("AlbumListViewHolder", "bind: ${album.albumBox.bucketPath}  ${albumData.isPinned}")
                txtTitle.text = getAlbumTitle(root.context, albumData.bucketName)

                txtCount.text = "${album.mediaCount} ${root.context.getString(R.string.items)}"
                ivRecentIcon.beGone()
                imageAlbum.beVisible()

                if (albumData.bucketName == "recent") {
                    ivRecentIcon.beVisible()
                }

                val context = imageAlbum.context

                val coverPath = context.preferences.getCoverImage(albumData.bucketPath)
                if (coverPath.isNotEmpty()) {
                    imageAlbum.loadGridImage(coverPath, File(coverPath).lastModified())
                    icVideo.beVisibleIf(coverPath.isVideoFast())
                    ivGif.beVisibleIf(coverPath.isGif())

                } else {
                    imageAlbum.loadGridImage(album.mediaPath, album.mediaDate)
                    ivGif.beVisibleIf(album.mediaPath.isGif())
                    icVideo.beVisibleIf(album.mediaPath.isVideoFast())
                }

                if (isSelectionActive() && !albumData.isCustom) {
                    icUnSelect.visibility = View.VISIBLE
                    icSelect.visibility =
                        if (isItemSelected(bindingAdapterPosition)) View.VISIBLE else View.GONE
                } else {
                    icUnSelect.visibility = View.GONE
                    icSelect.visibility = View.GONE
                }
            }
        }
    }

    class HeaderViewHolder(private val binding: ItemHeaderDividerBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(header: AlbumListItem.Header) {
            binding.txtHeader.text = header.header
        }
    }

    private fun getAlbumTitle(context: Context, title: String): String {
        return when (title) {
            "all_videos" -> {
                context.getString(R.string.all_videos)
            }

            "recent" -> {
                context.getString(R.string.recent)
            }

            "favorite" -> {
                context.getString(R.string.Favorite)
            }

            "more_album" -> {
                context.getString(R.string.more_album)
            }

            "recent_videos" -> {
                context.getString(R.string.recent)
            }

            else -> {
                title
            }
        }
    }

}