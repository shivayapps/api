package gallery.photogallery.photoeditor.galleryapp.bottomSheet

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.biometric.BiometricManager
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogBiometricErrorBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.applySystemBarAppearanceByTheme

class BiometricErrorDialog(
    var mContext: Context,
    val btnClickListener: (isEnable: Boolean) -> Unit,
) : BottomSheetDialogFragment() {

    private var _binding: DialogBiometricErrorBinding? = null
    private val binding get() = _binding!!


    override fun getTheme(): Int = R.style.CustomBottomSheetDialog


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = DialogBiometricErrorBinding.inflate(inflater, container, false)
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        dialog?.applySystemBarAppearanceByTheme()

        intView()
    }

    override fun dismiss() {
        super.dismiss()
        btnClickListener.invoke(false)
    }


    private fun intView() {
        val isSupportWithErrorInfo = isSupportWithErrorInfo(
            mContext,
            BiometricManager.Authenticators.BIOMETRIC_STRONG,
        )
        binding.txtMsg.text = isSupportWithErrorInfo.second
        binding.btnCancel.setOnClickListener { dismiss() }
        binding.btnOk.setOnClickListener {
            dismiss()
            btnClickListener.invoke(true)
        }
    }

    fun isSupportWithErrorInfo(
        ctx: Context,
        type: Int,
    ): Pair<Boolean, String?> {
        val biometricManager = BiometricManager.from(ctx)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val authStatusCode = biometricManager.canAuthenticate(type)

            Log.e("BiometricManager", "isSupportWithErrorInfo\nauthStatusCode:$authStatusCode\n,type:$type")

            when (authStatusCode) {
                BiometricManager.BIOMETRIC_STATUS_UNKNOWN, BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED, BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE,
                    -> {
                    return Pair(false, mContext.getString(R.string.device_unsupported))
                }

                BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> {
                    return Pair(false, mContext.getString(R.string.setting_biometric_error_hardware_unavailable))
                }

                BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED -> {
                    return Pair(false, mContext.getString(R.string.setting_biometric_error_not_secure))
                }

                BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                    return Pair(false, mContext.getString(R.string.setting_biometric_error_none_enrolled))
                }

                else -> return Pair(true, null)
            }
        } else return Pair(false, mContext.getString(R.string.device_unsupported))
    }

}