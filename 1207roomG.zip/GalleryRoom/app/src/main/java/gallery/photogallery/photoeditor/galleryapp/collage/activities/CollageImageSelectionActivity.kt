package gallery.photogallery.photoeditor.galleryapp.collage.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.util.MediaDataState
import com.appblish.gallery.core.v2.api.core.GallerySdkV2
import com.appblish.gallery.core.v2.api.model.AlbumListItem
import com.appblish.gallery.core.v2.api.model.AlbumModel
import com.appblish.gallery.core.v2.api.model.MediaModel
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.CollageAlbumAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.CollageImageAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.PreviewBottomAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.PreviewPagerAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.SelectedAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.utils.CollageConst
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityCollageImageSelectionBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import kotlinx.coroutines.launch

class CollageImageSelectionActivity : BaseActivity() {
    private val binding by viewBinding(ActivityCollageImageSelectionBinding::inflate)

    private lateinit var collageAlbumAdapter: CollageAlbumAdapter
    private lateinit var collageImageAdapter: CollageImageAdapter
    private lateinit var selectedAdapter: SelectedAdapter
    var isCheck = false
    var isCheckPreview = false
    var checkRelace = false
    private lateinit var previewPagerAdapter: PreviewPagerAdapter
    private lateinit var previewBottomAdapter: PreviewBottomAdapter

    // all media (from Media flow)
    private var allMediaList: List<MediaModel> = emptyList()

    // currently visible album media
    private var currentMediaList: List<MediaModel> = emptyList()

    // mediaId -> count
    private val selectedMap = LinkedHashMap<Long, Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        enableEdgeToEdge()
        binding.root.setPadding(0, 0, 0, navigationBarHeight)
        binding.main.setPadding(0, statusBarHeight, 0, 0)
        checkRelace = intent.getBooleanExtra("checkRelace", false)
        initAdapters()
        clickEvents()
        setupRecyclerViews()
        observeAlbums()

        onBackPressedDispatcher.addCallback(
            this, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {

                    handleBackEvent()
                }
            })

    }

    private fun handleBackEvent() {

        if (binding.albumDropdown.isVisible) {
            binding.albumDropdown.beGone()
            binding.imArrow.setImageResource(R.drawable.ic_selection_down)
            return
        }

        if (checkRelace) {
            checkRelace = false
            val resultIntent = Intent().apply {
                putExtra("saved_image_path", "")
            }
            setResult(RESULT_OK, resultIntent)
            finish()
            return
        }
        if (binding.previewContainer.isVisible) {
            binding.previewContainer.beGone()
            binding.llMain.beVisible()
        } else {
//            startActivity(Intent(this@CollageImageSelectionActivity, MainActivity::class.java))
            finish()
        }
    }

    private fun updatePreviewAdapters() {
        val selected = getSelectedImages()
        previewPagerAdapter.submit(selected)
        previewBottomAdapter.submit(selected)
    }


    // ---------------- INIT ----------------

    private fun initAdapters() {
        collageAlbumAdapter = CollageAlbumAdapter { item ->
            if (item is AlbumListItem.Album) {
                loadAlbumMedia(item.albumBox)
                binding.tvTitle.text = item.albumBox.bucketName
                binding.albumDropdown.beGone()
            }
        }


        collageImageAdapter = CollageImageAdapter(
            checkRelace, selectedMap, onAdd = { media ->
                Log.i("initAdapters1233", "initAdapters: " + media.mediaBox.mediaUri)
                if (checkRelace) {
                    checkRelace = false
                    val resultIntent = Intent().apply {
                        putExtra("saved_image_path", media.mediaBox.mediaUri)
                    }
                    setResult(RESULT_OK, resultIntent)
                    finish()
                } else {
                    handleAdd(media)
                }

            },
            onRemove = { media -> handleRemove(media) },
            onPreview = { pos ->


                binding.previewContainer.beVisible()
                binding.llMain.beGone()
                binding.rLayoutPreview.beGone()
                binding.llAddImage.beVisible()
                previewImageAdapter(emptyList(), pos)
            })

        selectedAdapter = SelectedAdapter { media ->
            removeSelectedImage(media)
        }
    }

    private fun clickEvents() {


        binding.ivClearAllSelection.setOnClickListener {
            clearAllList()

        }


        binding.ivBackPreview.setOnClickListener {
            handleBackEvent()
        }
        binding.llAddPreview.setOnClickListener {
            val pos = binding.previewViewPager.currentItem

            val media = getSelectedImages()[pos]
            handleAdd(media)
            updatePreviewAdapters()
        }


        binding.llAddImage.setOnClickListener {
            val pos = binding.previewViewPager.currentItem

            val media = currentMediaList[pos]
            handleAdd(media)
        }

        binding.tvPreview.setOnClickListener {

            val selected = getSelectedImages()
            if (selected.isEmpty()) return@setOnClickListener

            // UI toggle
            binding.previewContainer.beVisible()
            binding.llMain.beGone()
            binding.rLayoutPreview.beVisible()
            binding.llAddImage.beGone()


            // ---------------- VIEW PAGER ADAPTER ----------------
            previewImageAdapter(selected.toMutableList(), 0)


            // ---------------- BOTTOM PREVIEW ADAPTER ----------------
            previewBottomAdapter = PreviewBottomAdapter { pos ->
                binding.previewViewPager.currentItem = pos
            }

            binding.rvPreviewBottom.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
            binding.rvPreviewBottom.adapter = previewBottomAdapter
            previewBottomAdapter.submit(selected)
        }




        binding.llAlbum.setOnClickListener {
            if (binding.albumDropdown.isVisible) {
                binding.albumDropdown.beGone()
                binding.imArrow.setImageResource(R.drawable.ic_selection_down)

            } else {
                binding.albumDropdown.beVisible()
                binding.imArrow.setImageResource(R.drawable.ic_selection_up)

            }

        }


        binding.ivBack.setOnClickListener {
            handleBackEvent()
        }

        binding.ivCalculateSize.setOnClickListener {

            if (isCheck) {
                binding.ivCalculateSize.setImageDrawable(
                    ContextCompat.getDrawable(this, R.drawable.ic_check_off)
                )
                isCheck = false
                binding.tvSize.beGone()
            } else {
                binding.ivCalculateSize.setImageDrawable(
                    ContextCompat.getDrawable(this, R.drawable.ic_check_right)
                )
                isCheck = true
                binding.tvSize.beVisible()
            }

        }

        binding.ivCalculateSizePreview.setOnClickListener {

            if (isCheckPreview) {
                binding.ivCalculateSizePreview.setImageDrawable(
                    ContextCompat.getDrawable(this, R.drawable.ic_check_off)
                )
                isCheckPreview = false
                binding.tvSizePreview.beGone()
            } else {
                binding.ivCalculateSizePreview.setImageDrawable(
                    ContextCompat.getDrawable(this, R.drawable.ic_check_right)
                )
                isCheckPreview = true
                binding.tvSizePreview.beVisible()
            }

        }

        binding.ivDone.setOnClickListener {
            if (getSelectedImages().size >= 2) {
                startActivity(Intent(this@CollageImageSelectionActivity, CollageActivity::class.java).putStringArrayListExtra("KEY_DATA_RESULT", getSelectedImagePaths() as ArrayList<String?>?))
                finish()
            } else {
                Toast.makeText(this@CollageImageSelectionActivity, getString(R.string.select_minimum_2_images_to_continue), Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun previewImageAdapter(currentList: List<MediaModel>, pos: Int) {
        if (currentList.isEmpty()) {
            previewPagerAdapter = PreviewPagerAdapter(currentMediaList as MutableList<MediaModel>, onAdd = { media ->
                handleAdd(media)
                updatePreviewAdapters()
            }, onRemove = { media ->
                handleRemove(media)
                updatePreviewAdapters()
            })
            binding.previewViewPager.adapter = previewPagerAdapter

        } else {

            previewPagerAdapter = PreviewPagerAdapter(currentList as MutableList<MediaModel>, onAdd = { media ->
                handleAdd(media)
                updatePreviewAdapters()
            }, onRemove = { media ->
                handleRemove(media)
                updatePreviewAdapters()
            })
            binding.previewViewPager.adapter = previewPagerAdapter
        }

        binding.previewViewPager.setCurrentItem(pos, false)

    }

    private fun handleAdd(media: MediaModel) {
        val id = media.mediaBox.mediaId
        val total = selectedMap.values.sum()
        if (total >= 9) {
            Toast.makeText(this, getString(R.string.max_9_images_allowed), Toast.LENGTH_SHORT).show()
            return
        }
        selectedMap[id] = (selectedMap[id] ?: 0) + 1

        refreshUI()
    }

    private fun handleRemove(media: MediaModel) {
        val id = media.mediaBox.mediaId
        val count = selectedMap[id] ?: return
        if (count == 1) {
            selectedMap.remove(id)
        } else {
            selectedMap[id] = count - 1
        }
        Log.i("handleRemove", "handleRemove: ")

        refreshUI()
    }

    private fun removeSelectedImage(media: MediaModel) {
        val mediaId = media.mediaBox.mediaId
        val count = selectedMap[mediaId] ?: return
        if (count == 1) {
            selectedMap.remove(mediaId)
        } else {
            selectedMap[mediaId] = count - 1
        }

        Log.i("handleRemove", "removeSelectedImage: ")

        refreshUI()
    }

    fun clearAllList() {
        selectedMap.clear()
        refreshUI()
    }

    private fun setupRecyclerViews() {

        binding.rvAlbums.apply {
            layoutManager = LinearLayoutManager(
                this@CollageImageSelectionActivity

            )
            adapter = collageAlbumAdapter
        }

        binding.rvImages.apply {
            layoutManager = GridLayoutManager(
                this@CollageImageSelectionActivity, 3
            )
            adapter = collageImageAdapter
        }

        binding.rvSelected.apply {
            layoutManager = LinearLayoutManager(
                this@CollageImageSelectionActivity, RecyclerView.HORIZONTAL, false
            )
            adapter = selectedAdapter
        }
    }

    fun setAlbumList(state: MediaDataState<List<AlbumListItem>>) {
        when (state) {
            is MediaDataState.Success -> {
                val albumsAll = state.data.filterIsInstance<AlbumListItem.Album>()
                allMediaList = ArrayList(albumsAll.flatMap { it.albumBox.mediaList }).filter { it.isImage }
                val allImagesAlbum = AlbumListItem.Album(
                    albumBox = AlbumModel(
                        albumId = 0L, // new ID
                        bucketPath = "ALL_IMAGES",
                        bucketName = "All Images",
                        mediaList = ArrayList(allMediaList),
                        lastModified = System.currentTimeMillis(),
                        isPinned = false,
                        isCustom = false,
                    )
                )
                val filteredList = ArrayList<AlbumListItem>(32)
                filteredList.add(0, allImagesAlbum)
                for (album in albumsAll.asSequence()) {
                    val albumMedias = album.albumBox.mediaList.filter { it.isImage }
                    val allImagesAlbum = AlbumListItem.Album(
                        albumBox = AlbumModel(
                            albumId = album.id, // new ID
                            bucketPath = album.albumBox.bucketPath,
                            bucketName = album.albumBox.bucketName,
                            mediaList = ArrayList(albumMedias),
                            lastModified = System.currentTimeMillis(),
                            isPinned = false,
                            isCustom = false,
                        )
                    )
                    if (albumMedias.isNotEmpty())
                        filteredList.add(allImagesAlbum)
                }

                // 4️⃣ Submit to adapter
                collageAlbumAdapter.submitList(filteredList)
                binding.tvTitle.text = allImagesAlbum.albumBox.bucketName
                loadAlbumMedia(allImagesAlbum.albumBox)
            }

            else -> Unit
        }
    }

    private fun observeAlbums() {
        lifecycleScope.launch {
            setAlbumList(GallerySdkV2.get().getAllAlbumList())
        }
    }


    // ---------------- LOAD ALBUM MEDIA ----------------

    private fun loadAlbumMedia(album: AlbumModel) {
        currentMediaList = album.mediaList
        collageImageAdapter.submit(currentMediaList)
        collageImageAdapter.notifyDataSetChanged()
    }

    // ---------------- REFRESH UI ----------------

    private fun refreshUI() {
        collageImageAdapter.notifyDataSetChanged()
        selectedAdapter.submit(getSelectedImages())

        val total = getSelectedImages().size
        binding.tvSelectionCount.text = getString(R.string.select_9_photos, total)
        binding.tvTitlePreview.text = getString(R.string.select_photos, total)

        if (total == 0) {
            binding.llSelectList.beGone()
        } else {
            binding.llSelectList.beVisible()
        }

        val totalSize = getTotalSelectedSize()

        binding.tvSize.text = CollageConst.formatSize(totalSize)
        binding.tvSizePreview.text = CollageConst.formatSize(totalSize)

    }

    // ---------------- BUILD SELECTED LIST ----------------

    private fun getSelectedImages(): List<MediaModel> {
        val result = mutableListOf<MediaModel>()

        selectedMap.forEach { (mediaId, count) ->
            val media = allMediaList.firstOrNull {
                it.mediaBox.mediaId == mediaId
            } ?: return@forEach

            repeat(count) {
                result.add(media)
            }
        }
        return result
    }


    private fun getTotalSelectedSize(): Long {
        var totalSize = 0L

        selectedMap.forEach { (mediaId, count) ->
            val media = allMediaList.firstOrNull {
                it.mediaBox.mediaId == mediaId
            } ?: return@forEach

            val size = media.mediaBox.mediaSize
            totalSize += size * count
        }

        return totalSize
    }


    fun getSelectedImagePaths(): List<String> {
        val paths = mutableListOf<String>()

        selectedMap.forEach { (mediaId, count) ->
            val media = allMediaList.firstOrNull {
                it.mediaBox.mediaId == mediaId
            } ?: return@forEach

            val path = media.mediaBox.mediaPath
            repeat(count) {
                paths.add(path)
            }
        }
        return paths
    }


}

