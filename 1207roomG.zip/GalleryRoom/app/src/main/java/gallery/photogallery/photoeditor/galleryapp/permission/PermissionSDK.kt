package gallery.photogallery.photoeditor.galleryapp.permission


import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.core.net.toUri
import com.gun0912.tedpermission.PermissionListener
import com.gun0912.tedpermission.normal.TedPermission
import gallery.photogallery.photoeditor.galleryapp.permission.PermissionCallback

object PermissionSDK {
    @androidx.annotation.RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private val notificationPermission = Manifest.permission.POST_NOTIFICATIONS

    private val readLogPermission = Manifest.permission.READ_CALL_LOG
    private val writeLogPermission = Manifest.permission.WRITE_CALL_LOG
    private val readMessagePermission = Manifest.permission.READ_SMS
    private val readExternalStoragePermission = Manifest.permission.READ_EXTERNAL_STORAGE
    private val writeExternalStoragePermission = Manifest.permission.WRITE_EXTERNAL_STORAGE

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private val readMediaImagePermission = Manifest.permission.READ_MEDIA_IMAGES

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private val readMediaVideoPermission = Manifest.permission.READ_MEDIA_VIDEO

    private val accessMediaLocationVideoPermission = Manifest.permission.ACCESS_MEDIA_LOCATION

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private val readMediaAudioPermission = Manifest.permission.READ_MEDIA_AUDIO

    @RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
    private val readMediaUserSelectedPermission = Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED

    private val accessFineLocationPermission = Manifest.permission.ACCESS_FINE_LOCATION

    private val accessCoarseLocationPermission = Manifest.permission.ACCESS_COARSE_LOCATION

    private val readPhonePermission = Manifest.permission.READ_PHONE_STATE

    private lateinit var manageAllFilesLauncher: ActivityResultLauncher<Intent>


    @androidx.annotation.RequiresApi(Build.VERSION_CODES.TIRAMISU)
    fun hasNotificationPermission(context: Context): Boolean {
        return ActivityCompat.checkSelfPermission(
            context,
            notificationPermission
        ) == PackageManager.PERMISSION_GRANTED
    }

    @androidx.annotation.RequiresApi(Build.VERSION_CODES.TIRAMISU)
    fun askNotificationPermission(activity: Activity, callback: PermissionCallback = PermissionCallback()) {
        if (isPermissionRationale(activity, notificationPermission)) {
            callback.onPermissionRationale()
        } else {
            askPermission(activity, notificationPermission) {
                callback.onPermissionResult(it)
            }
        }
    }

    fun askReadPhoneStatePermission(activity: Activity, callback: PermissionCallback) {
        if (isPermissionRationale(activity, readPhonePermission)) {
            callback.onPermissionRationale()
        } else {
            askPermission(activity, readPhonePermission) {
                callback.onPermissionResult(it)
            }
        }
    }

    fun askMediaPermission(activity: Activity, callback: PermissionCallback) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (isPermissionRationale(activity, readMediaImagePermission)) {
                callback.onPermissionRationale()
            } else {
                askPermission(activity, readMediaImagePermission, readMediaVideoPermission, accessMediaLocationVideoPermission) {
                    if (hasLimitedPhotoAccess(activity)) {
                        callback.onLimitedAccess()
                    } else {
                        callback.onPermissionResult(it)
                    }
                }
            }
        } else {
            if (isPermissionRationale(activity, readExternalStoragePermission)) {
                callback.onPermissionRationale()
            } else {
                askPermission(activity, readExternalStoragePermission, writeExternalStoragePermission, accessMediaLocationVideoPermission) {
                    callback.onPermissionResult(it)
                }
            }
        }
    }

    fun hasLimitedPhotoAccess(context: Context): Boolean {
        if (isExternalStorageManager()) {
            return false
        }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) { // Android 14+
            val isReadSelectedGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            ) == PackageManager.PERMISSION_GRANTED

            val isReadAllPhotosGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED

            val isReadAllVideosGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.READ_MEDIA_VIDEO
            ) == PackageManager.PERMISSION_GRANTED

            isReadSelectedGranted && !isReadAllPhotosGranted && !isReadAllVideosGranted
        } else {
            false
        }
    }

    fun registerPermissionCallback(activity: AppCompatActivity, callback: PermissionCallback = PermissionCallback()) {
        manageAllFilesLauncher =
            activity.registerForActivityResult(
                ActivityResultContracts.StartActivityForResult()
            ) {
                if (isExternalStorageManager()) {
                    callback.onPermissionResult(true)
                } else {
                    callback.onPermissionResult(false)

                }
            }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    fun requestAllFilePermission(activity: Activity) {

        try {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
            intent.addCategory("android.intent.category.DEFAULT")
            intent.data = "package:${activity.packageName}".toUri()
            intent.flags = Intent.FLAG_ACTIVITY_NO_HISTORY or FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            manageAllFilesLauncher.launch(intent)
        } catch (e: Exception) {
            val intent = Intent()
            intent.action = Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
            intent.flags = Intent.FLAG_ACTIVITY_NO_HISTORY or FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            manageAllFilesLauncher.launch(intent)
        }
    }

    private fun isPermissionRationale(activity: Activity, permission: String): Boolean {
        val permissionCount = getAskCount(activity, permission)
        val isRationale = ActivityCompat.shouldShowRequestPermissionRationale(
            activity,
            permission
        )
        if (!isRationale && permissionCount == 0) {
            return false
        }
        return !isRationale
    }


    fun isReadMediaPermission(context: Context): Boolean {
        if (isExternalStorageManager()) {
            return true
        } else return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val result = ContextCompat.checkSelfPermission(
                context, Manifest.permission.READ_MEDIA_IMAGES
            )
            val result1 = ContextCompat.checkSelfPermission(
                context, Manifest.permission.READ_MEDIA_VIDEO
            )
            result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED
        } else {
            val result = ContextCompat.checkSelfPermission(
                context, Manifest.permission.READ_EXTERNAL_STORAGE
            )
            val result1 = ContextCompat.checkSelfPermission(
                context, Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED
        }
    }

    fun isExternalStorageManager(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            false
        }
    }

    private const val PREF_PERMISSION = "appblish_permission_pref"

    private fun getAskCount(context: Context, permission: String): Int {
        return context.getSharedPreferences(PREF_PERMISSION, Context.MODE_PRIVATE)
            .getInt(permission, 0)
    }

    private fun incrementAskCount(context: Context, permission: String) {
        val pref = context.getSharedPreferences(PREF_PERMISSION, Context.MODE_PRIVATE)
        pref.edit {
            putInt(permission, getAskCount(context, permission) + 1)
        }
    }

    // By Chirag Run Time Permission
    private fun askPermission(
        activity: Activity,
        vararg permissions: String, // Dynamic permissions
        callback: (Boolean) -> Unit,
    ) {

        val permissionListener: PermissionListener = object : PermissionListener {
            override fun onPermissionGranted() {
                callback(true)
            }

            override fun onPermissionDenied(deniedPermissions: List<String>) {
                callback(false)
            }
        }

        TedPermission.create().setPermissionListener(permissionListener)
            .setPermissions(*permissions) // Spread operator
            .check()

        permissions.forEach { incrementAskCount(activity, it) }
    }
}