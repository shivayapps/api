package gallery.photogallery.photoeditor.galleryapp.activities

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.adaptor.MyLanguageAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityNewLanguageSelectBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog.LoadingDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.checkMediaPermission
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isDarkMode
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import kotlinx.coroutines.launch
import java.util.Locale

class NewLanguageSelectActivity : AppCompatActivity() {
    private val binding by viewBinding(ActivityNewLanguageSelectBinding::inflate)
    private lateinit var loadingDialog: LoadingDialog


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        loadingDialog = LoadingDialog(this)
        setContentView(binding.root)
        lifecycleScope.launch {
            Log.e("TEXT_TAG", "setContentView: done")
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.isAppearanceLightStatusBars = !isDarkMode()
            controller.isAppearanceLightNavigationBars = !isDarkMode()
            binding.bindingLanguage.llToolbar.setPadding(0, statusBarHeight, 0, 0)
            binding.bindingLanguage.llHandLottie.setPadding(0, statusBarHeight, 0, 0)
            binding.bindingLanguage.root.setPadding(0, 0, 0, navigationBarHeight)
            setUpLanguages()
            doChange(preferences.getSelectedLang(this@NewLanguageSelectActivity))
            binding.bindingLanguage.ivBack.beGone()

            if (intent.hasExtra("isFromSettingToOpen")) {
                binding.bindingLanguage.ivBack.beVisible()
            } else {
                onBackPressedDispatcher.addCallback(this@NewLanguageSelectActivity) {
                    preferences.setSelectedLang("default")
                    setLocale(preferences.getSelectedLang(this@NewLanguageSelectActivity))
                    languageDone()
                }
            }
        }
    }


    private fun openMainScreen() {
        launchMainActivity()
    }


    private fun doChange(selectedLanguage: String) {
        setLocale(selectedLanguage)
        updateLan(selectedLanguage)
        if (selectedLanguage == "ar" || selectedLanguage == "ur" || selectedLanguage == "fa") {
            binding.bindingLanguage.tvTitle.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            binding.bindingLanguage.tvTitle.gravity = Gravity.END
        } else {
            binding.bindingLanguage.tvTitle.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            binding.bindingLanguage.tvTitle.gravity = Gravity.START
        }

    }

    fun setLocale(languageCode: String) {
        val locale = Locale(languageCode)
        Locale.setDefault(locale)
        val config = Configuration()
        config.setLocale(locale)
        resources.updateConfiguration(config, resources.displayMetrics)
    }

    private fun updateLan(selectedLanguage: String) {
        val locale = Locale(selectedLanguage)
        Locale.setDefault(locale)
        val config = Configuration()
        config.setLocale(locale)
        resources.updateConfiguration(config, resources.displayMetrics)
        binding.bindingLanguage.tvTitle.text = resources.getString(R.string.select_language)
//        binding.bindingLanguage.tvTitle.text = resources.getString(R.string.app_language)

    }

    private fun setUpLanguages() {
        val myLanguageAdapter = MyLanguageAdapter(this)
        binding.bindingLanguage.rvLanguage.adapter = myLanguageAdapter
        myLanguageAdapter.setOnItemClickListener {
            doChange(if (myLanguageAdapter.selectedLanguage == "default") preferences.defaultLanguage else myLanguageAdapter.selectedLanguage)
        }
        binding.bindingLanguage.ivDone.setOnClickListener {
            val selectedLanguage = myLanguageAdapter.selectedLanguage
            if (selectedLanguage.isEmpty()) {
                Toast.makeText(this, getString(R.string.please_select_language), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            preferences.setSelectedLang(selectedLanguage)
            setLocale(preferences.getSelectedLang(this))
            languageDone()
        }

        binding.bindingLanguage.ivBack.setOnClickListener {
            finish()
        }
    }

    private fun languageDone() {
        afterLanguageDone()
    }

    private fun afterLanguageDone() {
        openMainScreen()
    }


    private fun launchMainActivity() {
        if (intent.hasExtra("isFromSettingToOpen")) {
            startActivity(Intent(this@NewLanguageSelectActivity, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            })
            finish()
        } else {
            if (checkMediaPermission()) {
                startActivity(Intent(this@NewLanguageSelectActivity, MainActivity::class.java).putExtras(intent))
            } else {
                startActivity(Intent(this@NewLanguageSelectActivity, PermissionActivity::class.java).putExtras(intent))
            }
            finish()
        }
    }


    fun showLoadingDialog(message: String = "") {
        if (::loadingDialog.isInitialized) {
            if (!loadingDialog.isShowing) {
                loadingDialog.show()
                if (message.isNotEmpty()) {
                    loadingDialog.setTitle(message)
                }
            }

        }
    }

    fun updateMessageLoadingDialog(message: String) {
        if (::loadingDialog.isInitialized && !isDestroyed && !isFinishing) {
            if (loadingDialog.isShowing) {
                loadingDialog.setTitle(message)
            }
        }
    }

    fun hideLoadingDialog() {
        if (::loadingDialog.isInitialized) {
            if (loadingDialog.isShowing) {
                loadingDialog.dismiss()
            }

        }
    }
}