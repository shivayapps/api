package gallery.photogallery.photoeditor.galleryapp

import android.annotation.SuppressLint
import android.app.Application
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import com.appblish.box.api.core.BoxSDK
//import com.appblish.box.api.model.MyObjectBox
import com.appblish.gallery.core.v2.api.core.GallerySdkV2
import com.appblish.story.memories.api.core.MemorySDK
import com.bumptech.glide.Glide
import com.bumptech.glide.MemoryCategory
import com.cleaner.v2.api.core.CleanerSDK
import com.google.firebase.FirebaseApp
import gallery.photogallery.photoeditor.galleryapp.old.storyview.ExoPlayerCache
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.memoryToneList
import gallery.photogallery.photoeditor.galleryapp.remote.RemoteConfigFast
import gallery.photogallery.photoeditor.galleryapp.remote.RemoteConfigManager
import gallery.photogallery.photoeditor.galleryapp.utils.NetworkObserver

class App : Application() {
    var intentMapData = HashMap<String, Any>()
    val appViewModelStoreOwner = AppViewModelStoreOwner()

    companion object {
        @SuppressLint("StaticFieldLeak")
        lateinit var instance: App
    }

    @OptIn(UnstableApi::class)
    override fun onCreate() {
        super.onCreate()
        instance = this
        Glide.get(this).setMemoryCategory(MemoryCategory.HIGH)
        Log.e("GalleryApp", "onCreate: ")
        initGallerySDK()
        NetworkObserver.initialize(this)
        ExoPlayerCache.init(this)
        RemoteConfigManager.fireBaseConfigGet(this)
        RemoteConfigFast.init(this)
        FirebaseApp.initializeApp(this)
    }


    override fun onTerminate() {
        super.onTerminate()
        Log.e("GalleryApp", "onTerminate: ")
    }

    private fun initGallerySDK() {
//        val store = MyObjectBox.builder()
//            .androidContext(this)
//            .build()
        BoxSDK.init(this)
        GallerySdkV2.initialize(this, "Gallery1")
        CleanerSDK.initialize(this)
        MemorySDK.initialize(
            appContext = this, prefName = "MemoryPref",
            listOf(0),
            memoryToneList,
            listOf(0)
        )
    }

    override fun onLowMemory() {
        super.onLowMemory()
        Glide.get(this).clearMemory()
    }
}