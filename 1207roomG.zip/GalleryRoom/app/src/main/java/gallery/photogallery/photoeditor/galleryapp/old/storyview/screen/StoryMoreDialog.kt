package gallery.photogallery.photoeditor.galleryapp.old.storyview.screen

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogStoryMoreBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction

class StoryMoreDialog : DialogFragment() {

    private var _binding: DialogStoryMoreBinding? = null
    private val binding get() = _binding!!

    var clickListener: ((type: String) -> Unit)? = null

    companion object {
        var dateTime = ""
        fun newInstance(dateTime: String, clickListener: (type: String) -> Unit): StoryMoreDialog {
            val dialog = StoryMoreDialog()
            dialog.clickListener = clickListener
            this.dateTime = dateTime
            return dialog
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogStoryMoreBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(requireContext().getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }
        init()
        return dialog
    }

    private fun init() {
        binding.tvText.text = dateTime
        binding.llViewDay.setOnClickListener {
            clickListener?.invoke("ViewDay")
            dismiss()
        }
        binding.llShare.setOnClickListener {
            dismiss()
            clickListener?.invoke("Share")
        }
        binding.llRemove.setOnClickListener {
            clickListener?.invoke("Remove")
            dismiss()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        clickListener?.invoke("Dismiss")
    }
}