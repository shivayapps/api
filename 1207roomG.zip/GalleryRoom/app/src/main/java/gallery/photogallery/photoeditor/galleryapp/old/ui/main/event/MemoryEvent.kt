package gallery.photogallery.photoeditor.galleryapp.old.ui.main.event

import org.greenrobot.eventbus.EventBus


data class MemoryEvent(val type: String, val data: Any? = null)

const val GO_TO_PHOTO = "GO_TO_PHOTO"
const val REMOVE_STORY_PHOTO = "REMOVE_STORY_PHOTO"
const val REMOVE_STORY = "REMOVE_STORY"

fun sendMemoryEvent(type: String, data: Any? = null) {
    EventBus.getDefault().post(MemoryEvent(type, data))
}

