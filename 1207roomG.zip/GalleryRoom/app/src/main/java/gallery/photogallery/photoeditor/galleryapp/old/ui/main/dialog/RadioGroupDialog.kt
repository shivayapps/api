package gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.core.content.ContextCompat
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.NewImageViewerActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogRadioGroupBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.RadioItem

class RadioGroupDialog(
    private val contextDialog: Context,
    val items: ArrayList<RadioItem>,
    private val checkedItemId: Int = -1,
    val updateListener: (pos: Int) -> Unit
) :
    Dialog(contextDialog) {

    lateinit var binding: DialogRadioGroupBinding
    private var wasInit = false
    private var selectedItemId = -1


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.CENTER)
        binding = DialogRadioGroupBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }


    private fun intView() {

        binding.grpOption.apply {
            for (i in 0 until items.size) {
                val radioButton = (layoutInflater.inflate(R.layout.radio_button, null) as RadioButton).apply {
                    text = items[i].title
                    isChecked = items[i].id == checkedItemId
                    id = i
                    setTextColor(ContextCompat.getColor(context, R.color.white_color))
                    if (contextDialog is NewImageViewerActivity) {
                        setTextColor(Color.WHITE)
                    }
                    buttonDrawable = ContextCompat.getDrawable(context, R.drawable.ic_custom_check)
                    setOnClickListener { itemSelected(i) }
                }

                if (items[i].id == checkedItemId) {
                    selectedItemId = i
                }

                addView(radioButton, RadioGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
        }
        wasInit = true
    }

    private fun itemSelected(checkedId: Int) {
        if (wasInit) {
            dismiss()
            updateListener(items[checkedId].id)
        }
    }
}