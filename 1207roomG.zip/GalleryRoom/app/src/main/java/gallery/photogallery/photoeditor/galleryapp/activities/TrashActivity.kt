package gallery.photogallery.photoeditor.galleryapp.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.ScrollGate
import com.appblish.box.api.util.AppblishEvent
import com.appblish.box.api.util.MediaDataState
import com.appblish.recyclerview.dragselection.SelectionUpdateCallback
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.adaptor.RecycleMediaAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityTrashBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.PopupTrashMenuBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.dpToPx
import gallery.photogallery.photoeditor.galleryapp.extentions.showDeleteDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.custom.SwitchButton
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.PopupWindowHelper
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File

class TrashActivity : BaseActivity(), View.OnClickListener {
    private val binding by viewBinding(ActivityTrashBinding::inflate)

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        binding.root.setPadding(0, statusBarHeight, 0, navigationBarHeight)
        registerEventBus(this)
        initAdaptor()
        initClick()
        setListeners()
    }

    private fun initClick() {
        binding.rvTrash.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING ||
                    newState == RecyclerView.SCROLL_STATE_SETTLING
                ) {
                    ScrollGate.onScrollStart()
                } else {
                    ScrollGate.onScrollStop()
                }
            }
        })
        binding.icSelectAll.setOnClickListener(this)
        binding.ivClose.setOnClickListener(this)
        binding.ivBack.setOnClickListener(this)
        observableMedia()
    }

    @SuppressLint("SetTextI18n")
    private fun observableMedia() {
        lifecycleScope.launch {
            when (val state = sharedViewModel.getRecycleBinStateFlow()) {
                MediaDataState.Empty -> {
                    binding.loutNoData.beVisible()
                    binding.fastScroller.beGone()
                    binding.flTrashMore.beGone()
                    binding.tvCount.text = "0 " + resources.getString(R.string.items)
                    getRecycleMediaAdapter()?.submitList(emptyList())
                }

                MediaDataState.Loading -> {

                }

                is MediaDataState.Success -> {
                    val list = state.data
                    setMedia(list.flatMap { it.mediaFiles })
                }

                is MediaDataState.Progress -> {}
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            AppblishEvent.ALL_RECYCLE_BIN_LOADED -> {
                observableMedia()
            }

        }
    }

    private fun initAdaptor() {
        if (binding.rvTrash.adapter == null) {
            val recycleMediaAdapter = RecycleMediaAdapter(binding.rvTrash, sharedViewModel.isDeleteMediaAfter30Day()) {
                onFileClick(it)
            }
            binding.rvTrash.adapter = recycleMediaAdapter
            binding.rvTrash.layoutManager = GridLayoutManager(this, appPref.mediaGrid)
            recycleMediaAdapter.setSelectionUpdateCallback(
                object : SelectionUpdateCallback {
                    override fun onSelectionCountChanged(
                        selectedCount: Int,
                        selectionActive: Boolean,
                    ) {
                        updateSelection()
                    }
                }
            )
        }
    }

    @SuppressLint("SetTextI18n")
    fun setMedia(list: List<File>) {
        Log.e("setMedia", "setMedia: ${list.size}")
        binding.tvCount.text = list.size.toString() + " " + resources.getString(R.string.items)
        binding.flTrashMore.beVisible()
        getRecycleMediaAdapter()?.submitList(list)
    }

    fun onFileClick(file: File) {
        val listOfFile = getRecycleMediaAdapter()?.getAllPath() ?: emptyList()
        val index = listOfFile.indexOf(file)
        sharedViewModel.imageViewerList.clear()
        sharedViewModel.imageViewerList.addAll(listOfFile.map { it.absolutePath })
        startActivity(Intent(this, NewImageViewerActivity::class.java).apply {
            putExtra("startPosition", index)
            putExtra("ACTIVITY_NAME", "TrashActivity")
        })
    }

    @SuppressLint("SetTextI18n")
    fun updateSelection() {
        val recycleMediaAdapter = getRecycleMediaAdapter() ?: return
        binding.clSelection.beVisibleIf(recycleMediaAdapter.isSelectionActive())
        binding.btmSelectionView.beVisibleIf(recycleMediaAdapter.isSelectionActive())
        binding.photoToolbar.beVisibleIf(!recycleMediaAdapter.isSelectionActive())
        binding.tvTitleSelection.text = "${recycleMediaAdapter.getSelectedCount()} " + resources.getString(R.string.selected)

        if (recycleMediaAdapter.isSelectAll()) {
            binding.icSelectAll.setImageResource(R.drawable.vec_selected_bg)
        } else {
            binding.icSelectAll.setImageResource(R.drawable.vec_unselected_bg)
        }
    }


    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        val recycleMediaAdapter = getRecycleMediaAdapter() ?: return
        if (recycleMediaAdapter.isSelectionActive()) {
            disableSelection()
        } else {
            finish()
        }
    }

    override fun onClick(view: View?) {
        when (view) {
            binding.ivBack -> {
                onBackPressed()
            }

            binding.icSelectAll -> {
                val recycleMediaAdapter = getRecycleMediaAdapter() ?: return
                if (recycleMediaAdapter.isSelectAll()) {
                    recycleMediaAdapter.unSelectAll()
                } else {
                    recycleMediaAdapter.selectAll()
                }
            }


            binding.ivClose -> {
                binding.icSelectAll.isSelected = false
                binding.icSelectAll.setColorFilter(ContextCompat.getColor(this, R.color.app_text_color))
                disableSelection()
            }
        }
    }

    private fun onTrashPopUpMenuBar(view: View) {

        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopupTrashMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)

        view.post {
            popUpBinding.root.measure(
                View.MeasureSpec.UNSPECIFIED,
                View.MeasureSpec.UNSPECIFIED
            )

            val popupWidth = popUpBinding.root.measuredWidth

            val location = IntArray(2)
            view.getLocationOnScreen(location)

            val screenWidth = resources.displayMetrics.widthPixels

            val rightMargin = 16.dpToPx(this)   // custom extension below

            val x = screenWidth - popupWidth - rightMargin
            val y = location[1] + view.height

            popupWindow.showAtLocation(view, Gravity.NO_GRAVITY, x, y)

            popUpBinding.run {
                cbDeleteAfter30Days.setChecked(sharedViewModel.isDeleteMediaAfter30Day())


                btnSelect.setOnClickListener {
                    popupWindow.dismiss()
                    val explorePhotosAdapter = getRecycleMediaAdapter() ?: return@setOnClickListener
                    explorePhotosAdapter.enableSelectionMode()
                }

                btnRestoreAllFiles.setOnClickListener {
                    popupWindow.dismiss()
                    val recycleMediaAdapter = getRecycleMediaAdapter() ?: return@setOnClickListener
                    val allFiles = recycleMediaAdapter.getAllPath()
                    restoreMedia(allFiles, false)
                }

                btnEmptyTrash.setOnClickListener {
                    popupWindow.dismiss()
                    setEmptyTrash()
                }


                cbDeleteAfter30Days.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
                    override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                        sharedViewModel.setDeleteMediaAfter30Day(isChecked)
                        val recycleMediaAdapter = getRecycleMediaAdapter() ?: return
                        recycleMediaAdapter.isDeletedAfter30Day = isChecked
                        if (isChecked) {
                            sharedViewModel.fetchRecycleBin()
                        } else {
                            recycleMediaAdapter.notifyDataSetChanged()
                        }
                    }
                })
            }
        }
    }

    private fun setEmptyTrash() {
        showDeleteDialog(
            title = getString(R.string.empty_trash),
            subTitle = getString(R.string.this_will_delete_all_trash_in_the_gallery),
            positiveRes = R.string.delete,
            onDeleteClick = {
                sharedViewModel.setEmptyTrash {
                    toast(getString(R.string.your_trash_is_now_empty))
                }
            })
    }

    private fun setListeners() {
        binding.flTrashMore.setOnClickListener {
            onTrashPopUpMenuBar(it)
        }

        binding.btnRestore.setOnClickListener {
            val recycleMediaAdapter = getRecycleMediaAdapter() ?: return@setOnClickListener
            val selectedFile = recycleMediaAdapter.getSelectedItems()

            showDeleteDialog(
                title = getString(R.string.restore_msg),
                positiveRes = R.string.yes,
                onDeleteClick = {
                    restoreMedia(selectedFile, false)
                    disableSelection()
                })
        }

        binding.btnDelete.setOnClickListener {
            val recycleMediaAdapter = getRecycleMediaAdapter() ?: return@setOnClickListener
            val selectedFile = recycleMediaAdapter.getSelectedItems()

            showDeleteDialog(
                title = getString(R.string.delete_permanently),
                subTitle = getString(R.string.permanently_delete_msg),
                positiveRes = R.string.delete,
                onDeleteClick = {
                    deletePermanentFolderFiles(selectedFile.map { it.absolutePath })
                    disableSelection()
                })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterEventBus(this)
    }


    private fun getRecycleMediaAdapter() = binding.rvTrash.adapter as? RecycleMediaAdapter

    fun disableSelection() {
        val albumAdaptor = getRecycleMediaAdapter() ?: return
        albumAdaptor.clearSelectionAndExit()
        updateSelection()
    }
}