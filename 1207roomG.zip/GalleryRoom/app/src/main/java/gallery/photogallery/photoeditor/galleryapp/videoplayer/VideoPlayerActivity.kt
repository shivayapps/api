package gallery.photogallery.photoeditor.galleryapp.videoplayer

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.isGone
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.util.UnstableApi
import com.app.blish.player.api.VideoPlayerSDK
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityVideoPlayerBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.SpeedDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.isVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import kotlinx.coroutines.launch

@UnstableApi
class VideoPlayerActivity : AppCompatActivity() {
    private val binding by viewBinding(ActivityVideoPlayerBinding::inflate)

    @SuppressLint("WrongConstant")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        VideoPlayerSDK.setUpPlayer(this, binding.playerView)
        requestedOrientation = VideoPlayerSDK.getPref(this).getScreenOrientation()
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = false
        findViewById<View>(R.id.clTopBar).setPadding(0, statusBarHeight, 0, 0)
        findViewById<View>(R.id.exo_bottom_bar).setPadding(0, 0, 0, navigationBarHeight)
        updatePaddingBasedOnOrientation()
        setupOrientation()
        setupLock()
        setupUnLock()
        setListeners()
        initView()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updatePaddingBasedOnOrientation()
    }

    private fun updatePaddingBasedOnOrientation() {
        val orientation = resources.configuration.orientation
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Log.d("updatePaddingBasedOnOrientation", "Landscape")
            findViewById<View>(R.id.flBottomOptions).setPadding(0, 0, navigationBarHeight, 0)
            findViewById<View>(R.id.exo_bottom_bar).setPadding(0, 0, 0, 0)


        } else if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            Log.d("updatePaddingBasedOnOrientation", "Portrait")
            findViewById<View>(R.id.flBottomOptions).setPadding(0, 0, 0, 0)
            findViewById<View>(R.id.exo_bottom_bar).setPadding(0, 0, 0, navigationBarHeight)


        }
        updateOrientationIcon()
    }


    fun updateOrientationIcon() {
        val exo_rotation: ImageButton = findViewById(R.id.exo_rotation)
        val orientation = resources.configuration.orientation
        val screenOrientation = VideoPlayerSDK.getPref(this).getScreenOrientation()
        exo_rotation.setImageResource(R.drawable.vec_orientation_auto)

        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if (screenOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
                exo_rotation.setImageResource(R.drawable.vec_orientation_landscape)
            }

        } else if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            if (screenOrientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
                exo_rotation.setImageResource(R.drawable.vec_orientation_portrait)
            }
        }
    }

    fun setupOrientation() {
        val exo_rotation: ImageButton = findViewById(R.id.exo_rotation)
        exo_rotation.setOnClickListener {
            val orientation = resources.configuration.orientation
            val screenOrientation = VideoPlayerSDK.getPref(this).getScreenOrientation()
            if (screenOrientation != ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED) {
                if (orientation == Configuration.ORIENTATION_PORTRAIT && screenOrientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    VideoPlayerSDK.getPref(this).setScreenOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)

                } else if (orientation == Configuration.ORIENTATION_LANDSCAPE && screenOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    VideoPlayerSDK.getPref(this).setScreenOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
                }
            } else {
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    VideoPlayerSDK.getPref(this).setScreenOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)

                } else if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    VideoPlayerSDK.getPref(this).setScreenOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)

                }
            }

            updateOrientationIcon()
        }
    }

    fun setListeners() {
        findViewById<ImageButton>(R.id.exo_aspect_ratio).setOnClickListener {
            VideoPlayerSDK.get().fitScreen {
                updateRatio(findViewById<ImageButton>(R.id.exo_aspect_ratio))
            }
        }
        val ivDay: ImageView = findViewById(R.id.ivDay)
        ivDay.setOnClickListener {
            if (binding.nightMode.isVisible) {
                binding.nightMode.isGone = true
                ivDay.setImageResource(R.drawable.ic_play_day)
            } else {
                ivDay.setImageResource(R.drawable.ic_play_night)
                binding.nightMode.beVisible()
            }
        }

        findViewById<View>(R.id.audioTrack).setOnClickListener {
            audioSelect()
        }

        findViewById<View>(R.id.playback_speed).setOnClickListener {
            openSpeedDialog()
        }

        findViewById<View>(R.id.icBack).setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
        findViewById<ImageButton>(R.id.exo_pip).setOnClickListener {
            VideoPlayerSDK.get().enterPipMode()
        }
        lifecycleScope.launch {
            VideoPlayerSDK.get().brightnessUpdate.observe(this@VideoPlayerActivity) { value ->
                binding.brightnessIcon.text = value.toString()
                binding.llBrightness.visibility = View.VISIBLE
            }

            VideoPlayerSDK.get().volumeUpdate.observe(this@VideoPlayerActivity) { value ->
                binding.volumeIcon.text = value.toString()
                binding.llVolume.visibility = View.VISIBLE
            }

            VideoPlayerSDK.get().touchUp.observe(this@VideoPlayerActivity) {
                // handle touch up
                binding.llBrightness.visibility = View.GONE
                binding.llVolume.visibility = View.GONE
            }

            VideoPlayerSDK.get().controllerVisibilityChange.observe(this@VideoPlayerActivity) { isVisible ->
                if (isVisible) {
                    WindowInsetsControllerCompat(window, window.decorView).apply {
                        show(WindowInsetsCompat.Type.statusBars())
                        show(WindowInsetsCompat.Type.navigationBars())
                    }
                } else {
                    WindowInsetsControllerCompat(window, window.decorView).apply {
                        hide(WindowInsetsCompat.Type.statusBars())
                        hide(WindowInsetsCompat.Type.navigationBars())
                    }
                }
            }
        }

    }


    fun setupLock() {
        val exo_lock: ImageButton = findViewById(R.id.exo_lock)
        val exo_unlock: ImageButton = findViewById(R.id.exo_unlock)
        exo_lock.setOnClickListener {
            findViewById<View>(R.id.exo_bottom_bar).beGone()
            findViewById<View>(R.id.clTopBar).beGone()
            exo_unlock.beVisible()
            VideoPlayerSDK.get().lockPlayer()
        }
    }

    fun setupUnLock() {
        val exo_unlock: ImageButton = findViewById(R.id.exo_unlock)
        exo_unlock.setOnClickListener {
            findViewById<View>(R.id.clTopBar).beVisible()
            findViewById<View>(R.id.exo_bottom_bar).beVisible()
            exo_unlock.beGone()
            VideoPlayerSDK.get().unlockPlayer()
        }
    }

    fun updateRatio(btn: ImageButton) {
        val cropText: TextView = findViewById(R.id.cropText)
        if (VideoPlayerSDK.get().isResizeModeFill()) {
            btn.setImageResource(R.drawable.ic_play_fit)
            cropText.visibility = View.VISIBLE
            cropText.text = getString(R.string.full_screen)
            Handler(Looper.getMainLooper()).postDelayed({
                cropText.visibility = View.GONE
            }, 1000)
        } else {
            btn.setImageResource(R.drawable.ic_play_full)
            cropText.visibility = View.VISIBLE
            cropText.text = getString(R.string.fit)
            Handler(Looper.getMainLooper()).postDelayed({
                cropText.visibility = View.GONE
            }, 1000)
        }

    }


    fun initView() {
        val popupSeekPos = intent.getLongExtra("video_position", 0L)
        val videoUri = intent?.data
        if (videoUri != null) {
            VideoPlayerSDK.get().playVideo(videoUri, popupSeekPos)
            val exo_title: TextView = findViewById(R.id.exo_title)
            exo_title.text = VideoPlayerSDK.get().getFileName(videoUri)
        } else {
            Toast.makeText(this, "Video not found", Toast.LENGTH_SHORT).show()
        }
    }


    private fun openSpeedDialog() {
        val dialog = SpeedDialog(VideoPlayerSDK.get().getCurrentPlaybackSpeed())
        dialog.speedListener = { speed ->
            Log.d("SpeedDialog", "Selected speed: $speed")
            VideoPlayerSDK.get().setPaybackSpeed(speed)
        }
        dialog.show(supportFragmentManager, "SpeedDialog")
    }


    private fun audioSelect() {
        val audioItems = VideoPlayerSDK.get().getAvailableAudioTracks()
        if (audioItems.isEmpty()) {
            Toast.makeText(this, "No audio tracks available", Toast.LENGTH_SHORT).show()
            return
        }

        val dialog = AudioTrackDialog(
            audioList = audioItems.map { it.displayName },
            onTrackSelected = { position ->
                VideoPlayerSDK.get().setPreferredAudioLanguage(audioItems[position].languageCode)
            },
            onDisableAudio = {
                VideoPlayerSDK.get().disableAudio()
            }
        )

        dialog.show(supportFragmentManager, "AudioTrackDialog")
    }

    var isPlaying = false
    override fun onPause() {
        super.onPause()
        if (!isInPictureInPictureMode) {
            isPlaying = VideoPlayerSDK.get().isPlaying()
            VideoPlayerSDK.get().pausePlayer()
        }
    }

    override fun onResume() {
        super.onResume()
        if (isPlaying) {
            isPlaying = false
            VideoPlayerSDK.get().resumePlayer()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        VideoPlayerSDK.get().releasePlayer()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        VideoPlayerSDK.get().releasePlayer()
        VideoPlayerSDK.setUpPlayer(this, binding.playerView)
        initView()
    }
}