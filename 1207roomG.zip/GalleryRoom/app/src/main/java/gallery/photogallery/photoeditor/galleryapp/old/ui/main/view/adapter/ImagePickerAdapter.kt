package gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.MediaBox
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import gallery.photogallery.photoeditor.galleryapp.databinding.PhotoItemGridBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf

class ImagePickerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    var selectedItems = ArrayList<MediaBox>()
    var onSelectionUpdate: (() -> Unit)? = null
    private val medias = mutableListOf<MediaBox>()
    fun submitList(list: List<MediaBox>) {
        medias.clear()
        medias.addAll(list)
        notifyDataSetChanged()
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding =
            PhotoItemGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PictureViewHolder(binding)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val pictureViewHolder = holder as PictureViewHolder
        pictureViewHolder.bind(medias[position])
    }


    override fun getItemCount(): Int {
        return medias.size
    }

    inner class PictureViewHolder(var binding: PhotoItemGridBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(mediaTransactionModel: MediaBox) {
            val mediaEntity = mediaTransactionModel
            val path = mediaEntity.mediaPath
            binding.mediumThumbnail.loadGridImage(path, mediaEntity.mediaDate)

            try {
                binding.ivGif.beVisibleIf(
                    mediaEntity.mediaPath.endsWith(
                        "gif", true
                    )
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }

            if (mediaEntity.isVideoCheck()) {
                binding.icVideo.visibility = View.VISIBLE
            } else {
                binding.icVideo.visibility = View.GONE
            }
            binding.icUnSelect.visibility = View.VISIBLE
            binding.icSelect.visibility = if (selectedItems.contains(mediaTransactionModel)) View.VISIBLE else View.GONE
            itemView.setOnClickListener {
                if (selectedItems.contains(mediaTransactionModel)) {
                    selectedItems.remove(mediaTransactionModel)
                } else {
                    selectedItems.add(mediaTransactionModel)
                }
                onSelectionUpdate?.invoke()
                notifyItemChanged(bindingAdapterPosition)
            }
        }
    }

}