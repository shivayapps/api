package gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities//package gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities
//
//
//import android.Manifest
//import android.content.Intent
//import android.content.res.ColorStateList
//import android.content.res.Configuration
//import android.graphics.Color
//import android.net.Uri
//import android.os.Build
//import android.os.Bundle
//import android.os.Environment
//import android.provider.Settings
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import android.widget.Toast
//import androidx.activity.result.contract.ActivityResultContracts
//import androidx.annotation.RequiresApi
//import androidx.core.content.ContextCompat
//import androidx.recyclerview.widget.GridLayoutManager
//import androidx.recyclerview.widget.RecyclerView
//import gallery.photogallery.photoeditor.galleryapp.R
//import gallery.photogallery.photoeditor.galleryapp.old.ads.GoogleNativeAdHelper
//import gallery.photogallery.photoeditor.galleryapp.old.ads.MainInterAdManager
//import gallery.photogallery.photoeditor.galleryapp.old.ads.getAppLanguageNative
//import gallery.photogallery.photoeditor.galleryapp.old.ads.isAdsNotShowOnResume
//import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityPermissionBinding
//import gallery.photogallery.photoeditor.galleryapp.databinding.LanguageItemBinding
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog.PermissionDescriptionDialog
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.applyColorFilter
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.clientConfigPref
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.delayExecution
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.getAppPrimaryColor
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Preferences
//import com.gun0912.tedpermission.PermissionListener
//import com.gun0912.tedpermission.normal.TedPermission
//
//import java.util.Locale
//import javax.inject.Inject
//
//
//
//class PermissionActivity : BaseActivity() {
//    private val binding by viewBinding(ActivityPermissionBinding::inflate)
//
//    @Inject
//    lateinit var preferences: Preferences
//    var selectedLanguage = ""
//
//    @RequiresApi(Build.VERSION_CODES.R)
//    var permissionActivityResultLauncher = registerForActivityResult(
//        ActivityResultContracts.StartActivityForResult()
//    ) {
//        binding.permissionBar.visibility = View.VISIBLE
//        delayExecution(600) {
//            if (Environment.isExternalStorageManager()) {
//                startNextScreen()
//            } else {
//                binding.permissionBar.visibility = View.GONE
//            }
//        }
////        countDownTimerOverlay.cancel()
//    }
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        if (preferences.selectedLanguage.isEmpty()) {
//            MainInterAdManager.loadLanguageInter(this)
//        }
//        super.onCreate(savedInstanceState)
//        setContentView(binding.root)
//        binding.root.setPadding(0, 0, 0, navigationBarHeight)
//        binding.mainCoordinator.setPadding(0, statusBarHeight, 0, 0)
//        if (checkMediaPermission()) {
//            startNextScreen()
//        }
//        init()
//
//    }
//
//    private fun init() {
//        if (clientConfigPref.adsEnable) {
//            binding.adView.beVisible()
//            loadNative()
//        } else {
//            binding.adView.beGone()
//        }
//
//        binding.tvPermissionDesc.setOnClickListener {
//            val bottomSheet = PermissionDescriptionDialog()
//            bottomSheet.show(supportFragmentManager, bottomSheet.tag)
//        }
//        binding.btnAllow.setOnClickListener {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
//                intent.addCategory("android.intent.category.DEFAULT")
//                intent.data = Uri.parse("package:$packageName")
//                if (intent.resolveActivity(packageManager) != null) {
//                    requestCameraAndAllFilePermission()
//                } else {
//                    requestALLPermission()
//                }
//
//            } else {
//                requestALLPermission()
//            }
//        }
//        setUpLanguages()
//    }
//
//    private fun setUpLanguages() {
//
//        val languages = resources.getStringArray(R.array.language_text)
//        val languageCodes = resources.getStringArray(R.array.language_code)
//
//        val spanCount = /*if (clientConfigPref.languageAdType == "small") 1 else*/ 2
//
//        binding.rvLanguage.layoutManager = GridLayoutManager(this, spanCount)
//        binding.rvLanguage.adapter = MyAdapter(
//            this, languages.toList(), languageCodes.toList()
//        )
//        selectedLanguage = preferences.selectedLanguage.ifEmpty { "" }
//        binding.ivDone.setOnClickListener {
//            // selectedLanguage = appPref.selectedLanguage
//            if (selectedLanguage.isEmpty()) {
//                Toast.makeText(this, getString(R.string.please_select_language), Toast.LENGTH_SHORT).show()
//                return@setOnClickListener
//            }
//            if (preferences.selectedLanguage.isEmpty()) {
//                MainInterAdManager.showLanguageInter(this) {
//                    moveNext(languageCodes, languages)
//                }
//            } else {
//                moveNext(languageCodes, languages)
//            }
//        }
//    }
//
//
//    private fun moveNext(languageCodes: Array<String>, languages: Array<String>) {
//        preferences.selectedLanguage = selectedLanguage
//        val lastIndex = languageCodes.indexOf(selectedLanguage)
//        if (lastIndex == -1) {
//            preferences.selectedLanguageName = "English"
//        } else {
//            preferences.selectedLanguageName = languages[lastIndex]
//        }
//        setLocale(selectedLanguage)
//        startNextScreen()
//    }
//
//    private fun showLoader() {
////        if (isFromSplash) {
//        binding.determinateBar.visibility = View.VISIBLE
////            binding.ivBack.visibility = View.GONE
//        binding.ivDone.visibility = View.GONE
//        Toast.makeText(
//            this, getString(R.string.setting_up_language), Toast.LENGTH_SHORT
//        ).show()
//        delayExecution(1000) {
//            doChange()
//        }
//
////        } else {
////            doChange()
////        }
//    }
//
//    private fun doChange() {
//        binding.determinateBar.visibility = View.INVISIBLE
//        binding.ivDone.visibility = View.VISIBLE
//        setLocale(selectedLanguage)
//        updateLan()
//        binding.ivDone.text = getString(R.string.next)
//
//    }
//
//    private fun updateLan() {
//        val locale = Locale(selectedLanguage)
//        Locale.setDefault(locale)
//        val config = Configuration()
//        config.setLocale(locale)
//        resources.updateConfiguration(config, resources.displayMetrics)
//        binding.tvTitle.text = resources.getString(R.string.select_language)
//
//    }
//
//    class MyAdapter(
//        val activity: PermissionActivity,
//        private val languages: List<String>,
//        private val languageCodes: List<String>,
//    ) : RecyclerView.Adapter<MyAdapter.MyViewHolder>() {
//
//        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
//            val binding = LanguageItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
//            return MyViewHolder(binding)
//        }
//
//        override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
//            with(holder) {
//                with(binding) {
//                    tvLanguage.text = languages[position]
//                    tvLanguage.setTextColor(ContextCompat.getColor(activity, R.color.black))
//
//                    radio.isChecked = activity.selectedLanguage == languageCodes[position]
//                    if (radio.isChecked) {
//                        radio.buttonTintList = ColorStateList.valueOf(Color.WHITE)
//                        tvLanguage.setTextColor(Color.WHITE)
//                        llMain.background.applyColorFilter(activity.getAppPrimaryColor())
//                    } else {
//                        radio.buttonTintList = ColorStateList.valueOf(Color.GRAY)
//                        llMain.background.applyColorFilter(ContextCompat.getColor(activity, R.color.bg_color))
//                    }
//                    radio.setOnClickListener {
//                        selectedLanguage(position)
//                    }
//                    itemView.setOnClickListener {
//                        selectedLanguage(position)
//                    }
//                }
//            }
//        }
//
//        override fun getItemCount(): Int {
//            return languages.size
//        }
//
//        private fun selectedLanguage(position: Int) {
//            val lastIndex = languageCodes.indexOf(activity.selectedLanguage)
//            activity.selectedLanguage = languageCodes[position]
//
//            if (lastIndex != -1) {
//                notifyItemChanged(lastIndex)
//            }
//            notifyItemChanged(position)
//            activity.showLoader()
//        }
//
//        inner class MyViewHolder(val binding: LanguageItemBinding) : RecyclerView.ViewHolder(binding.root)
//    }
//
//    private fun loadNative() {
//
//        GoogleNativeAdHelper(this, binding.frameNative, "large", getAppLanguageNative()) { isLoaded ->
//            if (isLoaded) {
////                binding.adView.visibility = View.GONE
//                binding.rvLanguage.setPadding(0, 0, 0, binding.frameNative.measuredHeight + 10)
//            } else {
//                binding.adView.visibility = View.GONE
//                binding.rvLanguage.setPadding(0, 0, 0, 20)
//            }
//        }.loadAd()
//
////        binding.inNative.cvRoot.setCardBackgroundColor(getAppBackgroundColor())
////        binding.inNative.adCallToAction2.background.applyColorFilter(getAppPrimaryColor())
////        binding.inNative.shimmerView.startShimmer()
//
////        delayExecution(500) {
////            AdmobNative.preLoad(this, { isLoaded, nativeAd ->
////                showAds(nativeAd)
////            }, getAppLanguageNative())
////        }
//    }
//
//    private fun requestALLPermission() {
//        val permissionListener: PermissionListener = object : PermissionListener {
//            override fun onPermissionGranted() {
//                startNextScreen()
//            }
//
//            override fun onPermissionDenied(deniedPermissions: List<String>) {
//            }
//        }
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//            TedPermission.create()
//                .setPermissionListener(permissionListener)
//                .setDeniedMessage("If you reject permission,you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]")
//                .setPermissions(
//                    Manifest.permission.READ_EXTERNAL_STORAGE,
//                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
//                    Manifest.permission.ACCESS_MEDIA_LOCATION
//                )
//                .check()
//        } else {
//            TedPermission.create()
//                .setPermissionListener(permissionListener)
//                .setDeniedMessage("If you reject permission,you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]")
//                .setPermissions(
//                    Manifest.permission.READ_EXTERNAL_STORAGE,
//                    Manifest.permission.WRITE_EXTERNAL_STORAGE
//                )
//                .check()
//        }
//    }
//
//    @RequiresApi(Build.VERSION_CODES.R)
//    private fun requestCameraAndAllFilePermission() {
//        if (Environment.isExternalStorageManager()) {
//            startNextScreen()
//        } else {
//            requestAllFile()
//        }
//    }
//
//    private fun startNextScreen() {
//        binding.permissionBar.visibility = View.INVISIBLE
//        if (preferences.selectedLanguage.isEmpty()) {
//            newMediaRepository.fetchAllMediaFromDevice()
//            binding.laySwitcher.displayedChild = 1
////            val intent = Intent(
////                this,
////                LanguageSelectionActivity::class.java
////            ).putExtras(intent)
////            startActivity(intent)
////            finish()
//        } else {
//            val intent = Intent(this, HomeActivity::class.java).putExtras(intent)
//            startActivity(intent)
//            finish()
//        }
//
//    }
//
////    val countDownTimerOverlay: CountDownTimer = object : CountDownTimer(50000L, 1) {
////        @RequiresApi(Build.VERSION_CODES.R)
////        override fun onTick(l: Long) {
////            if (Environment.isExternalStorageManager()) {
////                cancel()
////                startNextScreen()
////            }
////        }
////
////        override fun onFinish() {}
////    }
//
//    @RequiresApi(Build.VERSION_CODES.R)
//    private fun requestAllFile() {
//        try {
//            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
//            intent.addCategory("android.intent.category.DEFAULT")
//            intent.data = Uri.parse("package:$packageName")
////            countDownTimerOverlay.start()
//            permissionActivityResultLauncher.launch(intent)
//            isAdsNotShowOnResume = true
//        } catch (e: Exception) {
//            val intent = Intent()
//            intent.action = Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
////            countDownTimerOverlay.start()
//            permissionActivityResultLauncher.launch(intent)
//            isAdsNotShowOnResume = true
//        }
//    }
//
//}