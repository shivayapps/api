package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.MediaBox
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemPictureBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory.ManageMemoryActivity

class MemoryImagesAdapter(var context: Context) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    var selectedItems = ArrayList<MediaBox>()
    private val diffUtil = object : DiffUtil.ItemCallback<MediaBox>() {
        override fun areItemsTheSame(oldItem: MediaBox, newItem: MediaBox):
                Boolean {
            return (oldItem.mediaId == newItem.mediaId)

        }

        override fun areContentsTheSame(oldItem: MediaBox, newItem: MediaBox):
                Boolean {
            return (oldItem == newItem)
        }
    }

    val asyncListDiffer = AsyncListDiffer(this, diffUtil)
    fun saveData(dataResponse: List<MediaBox>) {
        asyncListDiffer.submitList(kotlin.collections.ArrayList(dataResponse))
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding =
            ItemPictureBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PictureViewHolder(binding)
    }
    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)

        if (holder is PictureViewHolder) {
            Glide.with(holder.binding.image.context).clear(holder.binding.image)
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder
        val pictureViewHolder = holder as PictureViewHolder
        val memoryMediaModel: MediaBox = asyncListDiffer.currentList[position]
        holder.itemView.tag = memoryMediaModel
        holder.binding.image.loadGridImage(memoryMediaModel.mediaPath, memoryMediaModel.mediaDate)
        pictureViewHolder.binding.icVideo.visibility = View.GONE
        pictureViewHolder.binding.clVideoDuration.visibility = View.GONE
        pictureViewHolder.binding.icUnSelect.visibility = View.VISIBLE
        pictureViewHolder.binding.icSelect.visibility = if (selectedItems.contains(memoryMediaModel)) View.VISIBLE else View.GONE
        pictureViewHolder.itemView.setOnClickListener {
            if (selectedItems.contains(memoryMediaModel)) {
                selectedItems.remove(memoryMediaModel)
            } else {
                selectedItems.add(memoryMediaModel)
            }
            (context as? ManageMemoryActivity)?.updateSelection()
            notifyItemChanged(position)
        }
    }


    override fun getItemCount(): Int {
        return asyncListDiffer.currentList.size
    }

    class PictureViewHolder(var binding: ItemPictureBinding) :
        RecyclerView.ViewHolder(binding.root)

}