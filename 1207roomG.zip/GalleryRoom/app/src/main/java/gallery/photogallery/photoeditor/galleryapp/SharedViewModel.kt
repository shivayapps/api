package gallery.photogallery.photoeditor.galleryapp

import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appblish.box.api.model.AlbumSortType
import com.appblish.box.api.model.MainMediaFilter
import com.appblish.box.api.model.MediaBox
import com.appblish.box.api.model.MediaGroupBy
import com.appblish.box.api.model.MediaSortType
import com.appblish.box.api.model.SortOrder
import com.appblish.box.api.util.MediaDataState
import com.appblish.gallery.core.v2.api.core.FireOperationCallback
import com.appblish.gallery.core.v2.api.core.GallerySdkV2
import com.appblish.gallery.core.v2.api.model.AlbumListItem
import com.appblish.gallery.core.v2.api.model.MediaListItem
import com.appblish.gallery.core.v2.api.model.MediaModel
import com.appblish.gallery.core.v2.api.model.PlaceListItem
import com.appblish.gallery.core.v2.api.model.TimeLineAlbumModel
import com.appblish.story.memories.api.core.MemorySDK
import com.appblish.story.memories.api.model.MemoryBox
import com.cleaner.v2.api.core.CleanerSDK
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.checkMediaPermission
import gallery.photogallery.photoeditor.galleryapp.permission.PermissionSDK
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

class SharedViewModel : ViewModel() {

    val appContext by lazy { App.instance }
    var imageViewerList = ArrayList<String>()
    fun getRecycleBinStateFlow() = GallerySdkV2.get().getRecycleBinList()
    fun getPrivateStateFlow() = GallerySdkV2.get().getPrivateList()
    fun getPrivateRecycleBinStateFlow() = GallerySdkV2.get().getPrivateRecycleBinList()
    fun getTimelineFlow() = GallerySdkV2.get().getTimelineList()

    fun getDuplicateMediaFlow() = CleanerSDK.get().getDuplicateMedias()
    fun getLargeVideMediaFlow() = CleanerSDK.get().getLargeVideos()
    fun getScreenshotMediaFlow() = CleanerSDK.get().getScreenshotMedias()
    fun getPlacesFlow() = GallerySdkV2.get().getAllPlaces()
    fun fetchPlacesItems() = GallerySdkV2.get().fetchPlacesItems()


    fun fetchMedia() {
        if (appContext.checkMediaPermission()) {
            Log.e("GalleryRepository", "SharedViewModel fetchMedia: ")
            GallerySdkV2.get().fetchMedia()
            if (PermissionSDK.isReadMediaPermission(appContext)) {
                CleanerSDK.get().fetchMedia()
                viewModelScope.launch {
                    delay(2000)
                    MemorySDK.get().fetchMedia()
                }
            }
        }
    }


    fun fetchAfterFirstFetch() {
        MemorySDK.get().fetchMedia()
    }

    fun fetchStories() {
        MemorySDK.get().fetchStories()
    }


    fun fetchMemories() {
        MemorySDK.get().fetchMemories()
    }

    fun checkMediaExist() {
        if (PermissionSDK.isExternalStorageManager()) {
            GallerySdkV2.get().checkMediaExist()
        }
    }

    fun searchMemories(string: String): List<MemoryBox> {
        return MemorySDK.get().search(string)
    }


    fun fetchSearch(string: String, callback: (List<MediaModel>) -> Unit) {
        GallerySdkV2.get().search(string, callback)
    }

    fun searchTimeline(string: String): List<TimeLineAlbumModel> {
        return GallerySdkV2.get().searchTimeline(string)
    }

    fun searchPlaces(string: String): List<PlaceListItem> {
        return GallerySdkV2.get().searchPlaces(string)
    }

    fun fetchCategories() {
        /* viewModelScope.launch {
             val result = withContext(IO) {
                 val db = GalleryMediaDatabase.getInstance(appContext)
                 CategoryAlbumRepository(db.CategoryDao())
                     .loadTopCategoryAlbums()
             }
             _categoriesStateFlow.value = DataState.Success(result)
         }*/
    }

    fun addPinnedAlbum(pinnedList: List<String>) {
        GallerySdkV2.get().addPinnedAlbum(pinnedList)
    }

    fun removePinnedAlbum(pinnedList: List<String>) {
        GallerySdkV2.get().removePinnedAlbum(pinnedList)
    }


    fun refreshMedia() {
        GallerySdkV2.get().refreshMedia()
    }

    fun fetchRecycleBin() {
        GallerySdkV2.get().fetchRecycleBin()
    }

    fun fetchPrivateRecycleBin() {
        GallerySdkV2.get().fetchPrivateRecycleBin()
    }

    fun fetchPrivate() {
        GallerySdkV2.get().fetchPrivate()
    }


    suspend fun fetchAllAlbumBox(): List<AlbumListItem> {
        return GallerySdkV2.get().fetchAllAlbumBox()
    }


    fun getPrivateMediaAlbum(directoryPath: String): MediaDataState<List<File>> {
        return GallerySdkV2.get().getPrivateMediaAlbum(directoryPath)
    }

    suspend fun fetchAlbumMedia(folderPath: String): MediaDataState<List<MediaListItem>> {
        return GallerySdkV2.get().getAlbumMedia(folderPath)
    }

    suspend fun fetchAllVideoAlbumMedia(folderPath: String): MediaDataState<List<MediaListItem>> {
        return GallerySdkV2.get().getAllVideoAlbumMedia(folderPath)
    }

    suspend fun fetchTimelineMediaBox(path: String): MediaDataState<List<MediaListItem>> {
        return GallerySdkV2.get().getTimelineMediaBox(path)
    }

    fun checkNewMedia() {
        GallerySdkV2.get().checkNewMedia {
            if (it) {
                fetchMedia()
            }
        }
    }


    fun getMainMediaFilter(): MainMediaFilter {
        return GallerySdkV2.get().getMainMediaFilter()
    }

    fun setMainMediaFilter(mainMediaFilter: MainMediaFilter) {
        GallerySdkV2.get().setMainMediaFilter(mainMediaFilter)
    }

    fun getAlbumSortType(): AlbumSortType {
        return GallerySdkV2.get().getAlbumSortType()
    }

    fun setAlbumSortType(albumSortType: AlbumSortType) {
        GallerySdkV2.get().setAlbumSortType(albumSortType)
    }


    fun getAlbumSortOrder(): SortOrder {
        return GallerySdkV2.get().getAlbumSortOrder()
    }

    fun setAlbumSortOrder(albumSortType: SortOrder) {
        GallerySdkV2.get().setAlbumSortOrder(albumSortType)
    }


    fun getMediaSortOrder(): SortOrder {
        return GallerySdkV2.get().getMediaSortOrder()
    }

    fun setMediaSortOrder(albumSortType: SortOrder) {
        GallerySdkV2.get().setMediaSortOrder(albumSortType)
    }


    fun getMediaSortType(): MediaSortType {
        return GallerySdkV2.get().getMediaSortType()
    }

    fun setMediaSortType(mediaSortType: MediaSortType) {
        GallerySdkV2.get().setMediaSortType(mediaSortType)
    }

    fun getMediaGroupBy(): MediaGroupBy {
        return GallerySdkV2.get().getMediaGroupBy()
    }

    fun setMediaGroupBy(mediaGroupBy: MediaGroupBy) {
        GallerySdkV2.get().setMediaGroupBy(mediaGroupBy)
    }

    fun getMediaGroupByOrder(): SortOrder {
        return GallerySdkV2.get().getMediaGroupByOrder()
    }

    fun setMediaGroupByOrder(sortOrder: SortOrder) {
        GallerySdkV2.get().setMediaGroupByOrder(sortOrder)
    }

    fun copyFiles(mediaPathList: List<String>, destinationDir: String, callbacks: FireOperationCallback) {
        GallerySdkV2.get().copyFiles(mediaPathList, destinationDir, callbacks)
    }

    fun moveFiles(mediaPathList: List<String>, destinationDir: String, callbacks: FireOperationCallback) {
        GallerySdkV2.get().moveFiles(mediaPathList, destinationDir, callbacks)
    }

    fun moveToPrivateOrRecycleBin(mediaPathList: List<String>, isPrivate: Boolean, callbacks: FireOperationCallback) {
        if (isPrivate) {
            GallerySdkV2.get().moveToPrivate(mediaPathList, callbacks)
        } else {
            GallerySdkV2.get().moveToRecycleBin(mediaPathList, callbacks)
        }
    }

    fun restoreFromPrivateOrRecycleBin(files: List<File>, isPrivate: Boolean, destinationDir: String, callbacks: FireOperationCallback) {
        if (isPrivate) {
            GallerySdkV2.get().restoreFromPrivate(files, destinationDir, callbacks)
        } else {
            GallerySdkV2.get().restoreFromRecycleBin(files, destinationDir, callbacks)
        }
    }

    fun restoreFromPrivateRecycleBin(files: List<File>, callbacks: FireOperationCallback) {
        GallerySdkV2.get().restoreFromPrivateRecycleBin(files, callbacks)
    }

    fun deleteFiles(mediaList: List<String>, callbacks: FireOperationCallback) {
        GallerySdkV2.get().deleteFiles(mediaList, callbacks)
    }

    fun deleteFromPrivate(mediaList: List<String>, callbacks: FireOperationCallback) {
        GallerySdkV2.get().deleteFromPrivate(mediaList, callbacks)
    }

    fun fetchAllMediaBox(callback: (List<MediaBox>) -> Unit) {
        GallerySdkV2.get().fetchAllMediaBox(callback)
    }

    fun addToFav(mediaPathList: List<String>) {
        GallerySdkV2.get().addToFavourite(mediaPathList) {
            refreshMedia()
        }
    }

    fun removeToFav(mediaPathList: List<String>) {
        GallerySdkV2.get().removeFromFavourite(mediaPathList) {
            refreshMedia()
        }
    }

    fun isFavourite(paths: String): Boolean {
        return GallerySdkV2.get().isFavourite(paths)
    }

    fun getFilePathFromURI(paths: Uri): String {
        return GallerySdkV2.get().getFilePathFromURI(paths)
    }

    fun getFileURIFromPath(paths: String): Uri? {
        return GallerySdkV2.get().getFileURIFromPath(paths)
    }

    fun getFileURIFromPathString(paths: String): String {
        return GallerySdkV2.get().getFileURIFromPathString(paths)
    }

    suspend fun getAllMediaPaths(): List<String> {
        return GallerySdkV2.get().getAllMediaPaths()
    }

    fun renameAlbum(oldAlbumPath: String, newAlbumName: String, callback: (Boolean) -> Unit) {
        GallerySdkV2.get().renameAlbum(oldAlbumPath, newAlbumName, callback)
    }

    fun resizeMedia(mediaPath: String, reqWidth: Int, reqHeight: Int, callback: (Boolean) -> Unit) {
        GallerySdkV2.get().resizeMedia(mediaPath, reqWidth, reqHeight, callback)
    }

    fun resizeMedia(mediaPath: String, reqWidth: Int, reqHeight: Int, newFileName: String, keepOriginal: Boolean, callback: (Boolean, String) -> Unit) {
        GallerySdkV2.get().resizeMedia(mediaPath, reqWidth, reqHeight, newFileName, keepOriginal, callback)
    }

    fun rotateMedia(mediaPath: String, degrees: Float, callback: (Boolean) -> Unit) {
        GallerySdkV2.get().rotateMedia(mediaPath, degrees, callback)
    }

    fun renameMedia(oldAlbumPath: String, newAlbumName: String, callback: (Boolean) -> Unit) {
        GallerySdkV2.get().renameMedia(oldAlbumPath, newAlbumName, callback)
    }

    fun deleteStoryMedia(storyId: Long, storyMedia: MediaBox) {
        MemorySDK.get().deleteStoryMedia(storyId, storyMedia) {
            fetchStories()
        }
    }

    fun updateMemoryFavourite(memoryId: Long, isFavorite: Boolean) {
        if (isFavorite) {
            MemorySDK.get().addToFavourite(memoryId) {
                fetchMemories()
            }
        } else {
            MemorySDK.get().removeFromFavourite(memoryId) {
                fetchMemories()
            }
        }

    }


    fun updateMemoryTitle(memoryId: Long, title: String, callback: () -> Unit = {}) {
        MemorySDK.get().updateMemoryTitle(memoryId, title) {
            fetchMemories()
            callback.invoke()
        }

    }

    fun updateMemoryMusic(memoryId: Long, rawId: Int, callback: () -> Unit = {}) {
        MemorySDK.get().updateMemoryMusic(memoryId, rawId) {
            fetchMemories()
            callback.invoke()
        }
    }


    fun updateMemoryColor(memoryId: Long, coverPathMedia: MediaBox) {
        Log.e("MemoryRepository", "updateMemoryColor: $memoryId ${coverPathMedia.mediaPath}")
        MemorySDK.get().updateMemoryCover(memoryId, coverPathMedia) {
            fetchMemories()
        }

    }

    fun updateStorySeen(storyId: Long, seenStoryMedia: MediaBox) {
        MemorySDK.get().updateStorySeen(storyId, seenStoryMedia) {
            fetchStories()
        }
    }

    fun updateMemorySeen(memoryId: Long) {
        MemorySDK.get().updateMemorySeen(memoryId) {
            fetchMemories()
        }
    }

    fun updateMemoryMedia(memoryId: Long, mediaList: List<MediaBox>, callback: () -> Unit) {
        MemorySDK.get().updateMemoryMedia(memoryId, mediaList) {
            fetchMemories()
            callback.invoke()
        }

    }

    fun createMemory(memoryTitle: String, mediaList: List<MediaBox>, callback: () -> Unit) {
        MemorySDK.get().createMemory(memoryTitle, mediaList) {
            fetchMemories()
            callback.invoke()
        }

    }

    fun deleteMemory(memoryId: Long) {
        MemorySDK.get().deleteMemory(memoryId) {
            fetchMemories()
        }

    }

    fun setDeleteMediaAfter30Day(isChecking: Boolean) {
        GallerySdkV2.get().setDeleteMediaAfter30Day(isChecking)
    }

    fun isDeleteMediaAfter30Day(): Boolean {
        return GallerySdkV2.get().isDeleteMediaAfter30Day()
    }

    fun setDeletePrivateMediaAfter30Day(isChecking: Boolean) {
        GallerySdkV2.get().setDeletePrivateMediaAfter30Day(isChecking)
    }

    fun isDeletePrivateMediaAfter30Day(): Boolean {
        return GallerySdkV2.get().isDeletePrivateMediaAfter30Day()
    }

    fun setEmptyTrash(callback: () -> Unit) {
        GallerySdkV2.get().emptyRecycleBin(callback)
    }

    fun setEmptyPrivateTrash(callback: () -> Unit) {
        GallerySdkV2.get().emptyPrivateRecycleBin(callback)
    }
}