package gallery.photogallery.photoeditor.galleryapp.old.storyview.customview

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.Priority
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemStoryShareBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible

class ShareStoryAdapter(
    var data: List<String>,
    var pos: Int,
    var callback: (String?, Int) -> Unit,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    inner class ItemStory(val binding: ItemStoryShareBinding) :
        RecyclerView.ViewHolder(binding.root)

    val selectedItems: ArrayList<String> = ArrayList()


    override fun getItemViewType(position: Int): Int {
        return position
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        return ItemStory(
            ItemStoryShareBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount() = data.size

    override fun onBindViewHolder(
        holderPayLoad: RecyclerView.ViewHolder,
        position: Int,
        payloads: MutableList<Any>,
    ) {
        if (payloads.isNotEmpty()) {
            if (holderPayLoad is ItemStory) {
                val dataPos = data[position]
                if (selectedItems.contains(dataPos)) {
//                    holderPayLoad.binding.icUnSelect.visibility = View.GONE
                    holderPayLoad.binding.icSelect.visibility = View.VISIBLE
                } else {
//                    holderPayLoad.binding.icUnSelect.visibility = View.VISIBLE
                    holderPayLoad.binding.icSelect.visibility = View.GONE
                }
            }
        } else {
            super.onBindViewHolder(holderPayLoad, position, payloads)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val dataPos = data[position]
        if (holder is ItemStory) {
            val ctx = holder.binding.image.context
//            val options = RequestOptions()
//                .skipMemoryCache(false)
//                .priority(Priority.IMMEDIATE)
//                .diskCacheStrategy(DiskCacheStrategy.RESOURCE).format(DecodeFormat.PREFER_ARGB_8888)

            Glide.with(ctx)
                .load(dataPos)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .transform(CenterCrop(), RoundedCorners(22))
                .into(holder.binding.image)

            val displayMetrics = holder.binding.image.context.resources.displayMetrics
            val screenWidth = displayMetrics.widthPixels - 300
            Log.e("viewFlipperShare", "screenWidth:  $screenWidth")

            val params = holder.binding.image.layoutParams
            params.width = screenWidth
            holder.binding.image.layoutParams = params

            if (pos == position && !selectedItems.contains(dataPos)) {
                selectedItems.add(dataPos)
            }

            if (selectedItems.contains(dataPos)) {
                holder.binding.icSelect.beVisible()
            } else {
                holder.binding.icSelect.beGone()
            }

            holder.binding.image.setOnClickListener {
                if (selectedItems.contains(dataPos)) {
                    selectedItems.remove(dataPos)
                    callback.invoke(null, selectedItems.size)
                } else {
                    selectedItems.add(dataPos)
                    callback.invoke(dataPos, selectedItems.size)
                }
                notifyItemChanged(position, "changes")

            }
        }
    }

}