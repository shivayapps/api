package gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.appblish.box.api.util.AppblishEvent
import com.appblish.box.api.util.MediaDataState
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.adaptor.ExtraPlacesAlbumAdapter
import gallery.photogallery.photoeditor.galleryapp.adaptor.ExtraTimelineAlbumAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityExtraAlbumBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode


class ExtraAlbumActivity : BaseActivity(), View.OnClickListener {

    companion object {
        private const val ARGS_FOLDER = "ARGS_FOLDER"
        private const val ARGS_FOLDER_TITLE = "ARGS_FOLDER_TITLE"

        fun createPlacesIntent(context: Context, folderTitle: String): Intent {
            return Intent(context, ExtraAlbumActivity::class.java).putExtra(ARGS_FOLDER, "places").putExtra(ARGS_FOLDER_TITLE, folderTitle)
        }

        fun createTimeLineIntent(context: Context, folderTitle: String): Intent {
            return Intent(context, ExtraAlbumActivity::class.java).putExtra(ARGS_FOLDER, "timeline").putExtra(ARGS_FOLDER_TITLE, folderTitle)
        }

    }

    private val binding by viewBinding(ActivityExtraAlbumBinding::inflate)

    val textColor by lazy { ContextCompat.getColor(this, R.color.black_text) }
    private var folderTitle = ""
    private val extraTimelineAlbumAdapter by lazy { ExtraTimelineAlbumAdapter(this) }
    private val extraPlacesAlbumAdapter by lazy { ExtraPlacesAlbumAdapter(this) }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        if (!EventBus.getDefault().isRegistered(this)) EventBus.getDefault().register(this)
        binding.root.setPadding(0, 0, 0, navigationBarHeight)
        binding.mainContainer.setPadding(0, statusBarHeight, 0, 0)
        registerEventBus(this)
        folderTitle = intent.getStringExtra(ARGS_FOLDER_TITLE).toString()
        binding.txtTitle.text = folderTitle
        initClick()
        setRV()
        setData()

    }

    private fun initClick() {
        binding.ivBack.setOnClickListener(this)
    }

    private fun setRV() {
        initSpanCountHelper()
        if (folderTitle == ContextCompat.getString(this, R.string.places)) {
            binding.timeLineRecycler.adapter = extraPlacesAlbumAdapter
            extraPlacesAlbumAdapter.submitList(emptyList())
        } else {
            binding.timeLineRecycler.adapter = extraTimelineAlbumAdapter
            extraTimelineAlbumAdapter.submitList(emptyList())
        }

    }

    private fun setData() {
        if (folderTitle == ContextCompat.getString(this, R.string.places)) {
            setPlacesAlbum()
        } else {
            setTimeLineAlbum()
        }
    }

    private fun setTimeLineAlbum() {
        lifecycleScope.launch {
            when (val state = sharedViewModel.getTimelineFlow()) {
                MediaDataState.Empty -> {
                    extraTimelineAlbumAdapter.submitList(emptyList())
                }

                MediaDataState.Loading -> {}

                is MediaDataState.Success -> {
                    extraTimelineAlbumAdapter.submitList(state.data)
                }

                is MediaDataState.Progress -> {}
            }
        }

    }

    private fun setPlacesAlbum() {
        lifecycleScope.launch {
            when (val state = sharedViewModel.getPlacesFlow()) {
                is MediaDataState.Empty -> {
                    extraPlacesAlbumAdapter.submitList(emptyList())
                }

                is MediaDataState.Loading -> {}

                is MediaDataState.Success -> {
                    extraPlacesAlbumAdapter.submitList(state.data)
                }

                is MediaDataState.Progress -> {}
            }
        }
    }

    private fun initSpanCountHelper() {
        if (appPref.albumAsGrid) {
            val layoutManager = GridLayoutManager(this, appPref.albumGrid)
            binding.timeLineRecycler.layoutManager = layoutManager
        } else {
            val layoutManager = LinearLayoutManager(this)
            binding.timeLineRecycler.layoutManager = layoutManager
        }
        binding.timeLineRecycler.scheduleLayoutAnimation()
    }

    override fun onClick(view: View?) {
        when (view) {
            binding.ivBack -> {
                onBackPressed()
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            AppblishEvent.ALL_TIME_LINE_LOADED -> {
                setTimeLineAlbum()
            }

            AppblishEvent.ALL_PLACES_LOADED -> {
                setPlacesAlbum()
            }

        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterEventBus(this)
    }

    override fun onBackPressed() {
        finish()
    }
}
