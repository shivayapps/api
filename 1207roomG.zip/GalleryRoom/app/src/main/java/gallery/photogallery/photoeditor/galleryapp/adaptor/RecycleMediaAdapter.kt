package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.util.toAlbumId
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import com.appblish.recyclerview.dragselection.BaseSelectableAdapter
import com.appblish.recyclerview.dragselection.DragSelectionMode
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.PrivateTrashActivity
import gallery.photogallery.photoeditor.galleryapp.activities.TrashActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.PhotoItemGridBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isVideoFast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.lastClickTS
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.CLICK_HOLD
import java.io.File
import java.util.concurrent.TimeUnit

class RecycleMediaAdapter(
    recyclerView: RecyclerView,
    var isDeletedAfter30Day: Boolean,
    val onFileClick: (File) -> Unit
) : BaseSelectableAdapter<File, RecyclerView.ViewHolder>(recyclerView, DragSelectionMode.RANGE) {

    val medias = mutableListOf<File>()
    fun submitList(list: List<File>) {
        medias.clear()
        medias.addAll(list)
        notifyDataSetChanged()
    }

    fun getAllPath() = medias

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding =
            PhotoItemGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PictureViewHolder(binding)
    }

    override fun getItemAt(position: Int): File? {
        return medias.getOrNull(position)
    }

    override fun getItemKey(item: File): Long {
        return item.absolutePath.toAlbumId()
    }

    override fun isSelectable(item: File): Boolean {
        return true
    }

    override fun isHeader(position: Int): Boolean {
        return false

    }

    override fun isSelectionEnabled(): Boolean {
        return true
    }

    override fun bindItem(holder: RecyclerView.ViewHolder, item: File, position: Int) {
        val pictureViewHolder = holder as PictureViewHolder
        pictureViewHolder.bind(medias[position])
    }

    override fun bindSelection(holder: RecyclerView.ViewHolder, item: File, position: Int, selected: Boolean) {
        val pictureViewHolder = holder as PictureViewHolder
        if (isSelectionActive()) {
            pictureViewHolder.binding.icUnSelect.visibility = View.VISIBLE
            pictureViewHolder.binding.icSelect.visibility = if (selected) View.VISIBLE else View.GONE
        } else {
            pictureViewHolder.binding.icUnSelect.visibility = View.GONE
            pictureViewHolder.binding.icSelect.visibility = View.GONE
        }
    }

    override fun onItemOpen(item: File, position: Int, view: View) {
        if (System.currentTimeMillis() - lastClickTS > CLICK_HOLD) {
            lastClickTS = System.currentTimeMillis()
            onFileClick.invoke(item)
        }
    }

    override fun onSelectionModeUpdate() {
        notifyDataSetChanged()
    }


    override fun getItemCount(): Int {
        return medias.size
    }

    fun selectAll() {
        selectAllItems()
    }

    fun unSelectAll() {
        unselectAllItems()
    }

    fun isSelectAll() = isAllSelectedItems()


    inner class PictureViewHolder(var binding: PhotoItemGridBinding) :
        RecyclerView.ViewHolder(binding.root) {
        @SuppressLint("SetTextI18n")
        fun bind(file: File) {
            val path = file.absolutePath
            val date = file.lastModified()
            val current = System.currentTimeMillis()
            val diffMillis = current - date
            val diffDays = TimeUnit.MILLISECONDS.toDays(diffMillis)
            val remainingDays = (30 - diffDays).coerceAtLeast(0)
            binding.mediumThumbnail.loadGridImage(path, date)
            binding.tvRemainingDays.text = "$remainingDays ${binding.tvRemainingDays.context.getString(R.string.days)}"
            val isVisibleDeletedAfter = isDeletedAfter30Day && (binding.tvRemainingDays.context is TrashActivity || binding.tvRemainingDays.context is PrivateTrashActivity)
            binding.tvRemainingDays.beVisibleIf(isVisibleDeletedAfter)

            try {
                binding.ivGif.beVisibleIf(
                    path.endsWith(
                        "gif", true
                    )
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }

            if (path.isVideoFast()) {
                binding.icVideo.visibility = View.VISIBLE
            } else {
                binding.icVideo.visibility = View.GONE
            }
            if (isSelectionActive()) {
                binding.icUnSelect.visibility = View.VISIBLE
                binding.icSelect.visibility = if (isItemSelected(bindingAdapterPosition)) View.VISIBLE else View.GONE
            } else {
                binding.icUnSelect.visibility = View.GONE
                binding.icSelect.visibility = View.GONE
            }
            binding.root.transitionName = path
        }
    }

}