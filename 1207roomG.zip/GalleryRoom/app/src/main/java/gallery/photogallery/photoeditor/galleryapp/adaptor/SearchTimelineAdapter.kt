package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.annotation.SuppressLint
import android.content.Context
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.appblish.gallery.core.v2.api.model.TimeLineAlbumModel
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemAlbumGridBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone

class SearchTimelineAdapter(val context: Context, val onClick: (TimeLineAlbumModel) -> Unit) : RecyclerView.Adapter<SearchTimelineAdapter.AlbumGridViewHolder>() {

    class AlbumGridViewHolder(var binding: ItemAlbumGridBinding) : RecyclerView.ViewHolder(binding.root)

    val font = ResourcesCompat.getFont(context, R.font.lato_regular)
    private val diffUtil = object : DiffUtil.ItemCallback<TimeLineAlbumModel>() {
        override fun areItemsTheSame(oldItem: TimeLineAlbumModel, newItem: TimeLineAlbumModel): Boolean {
            return oldItem.mediaRows == newItem.mediaRows && oldItem.title == newItem.title
        }

        override fun areContentsTheSame(oldItem: TimeLineAlbumModel, newItem: TimeLineAlbumModel): Boolean {
            return oldItem.mediaRows.size == newItem.mediaRows.size && oldItem.title == newItem.title
        }

    }
    val asyncListDiffer = AsyncListDiffer(this, diffUtil)
    fun saveData(dataResponse: List<TimeLineAlbumModel>) {
        asyncListDiffer.submitList(ArrayList(dataResponse))
    }

    fun getItem(pos: Int): TimeLineAlbumModel {
        return asyncListDiffer.currentList[pos]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlbumGridViewHolder {
        val binding = ItemAlbumGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        val width = parent.measuredWidth / 3.8
        binding.root.layoutParams.width = width.toInt()
        return AlbumGridViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return asyncListDiffer.currentList.size
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: AlbumGridViewHolder, position: Int) {
        val albumData: TimeLineAlbumModel = asyncListDiffer.currentList[position] as TimeLineAlbumModel
        holder.itemView.tag = albumData
        holder.binding.icPin.beGone()
        holder.binding.txtCount.beGone()
        holder.binding.txtTitle.gravity = Gravity.CENTER
        holder.binding.txtTitle.typeface = font
        holder.binding.txtTitle.text = albumData.title
        holder.binding.txtCount.text = albumData.mediaRows.size.toString()
        val realPlacesPhotosModel = albumData.mediaRows[0]
        holder.binding.imageAlbum.loadGridImage(realPlacesPhotosModel.mediaPath, realPlacesPhotosModel.mediaDate)
        holder.binding.icUnSelect.visibility = View.GONE
        holder.binding.icSelect.visibility = View.GONE
        holder.binding.icSelect.visibility = View.GONE
        holder.binding.txtTitle.text = when (albumData.title.lowercase()) {
            /*"recent" -> {
               holder.binding.ivRecent.setImageResource(R.drawable.vec_recent)
               holder.binding.ivRecent.visibility = View.VISIBLE
               holder.binding.root.context.getString(R.string.recent)
            }*/

            /*            "favorite" -> {
            //                holder.binding.ivRecent.setImageResource(R.drawable.vec_fav)
            //                holder.binding.ivRecent.visibility = View.VISIBLE
                            holder.binding.root.context.getString(R.string.Favorite)
                        }*/

            "all_videos" -> holder.binding.root.context.getString(R.string.all_videos)
            "last_week" -> holder.binding.root.context.getString(R.string.last_week)
            "last_month" -> holder.binding.root.context.getString(R.string.last_month)
            "this_year" -> holder.binding.root.context.getString(R.string.this_year)
            else -> albumData.title
        }
        holder.itemView.setOnClickListener {
            onClick.invoke(albumData)
        }
    }

}