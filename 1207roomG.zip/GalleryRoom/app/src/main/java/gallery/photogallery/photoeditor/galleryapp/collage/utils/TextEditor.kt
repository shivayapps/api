package gallery.photogallery.photoeditor.galleryapp.collage.utils

import com.appblish.collagemaker.appblish.AppblishCollageText

interface TextEditor {
        fun onBackButton()
        fun onDone(appblishText: AppblishCollageText)
    }