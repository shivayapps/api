package gallery.photogallery.photoeditor.galleryapp.dialogs


import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import com.appblish.box.api.model.AlbumSortType
import com.appblish.box.api.model.SortOrder
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogAlbumSortingBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity

class SortByDialog(private val updateListener: (() -> Unit)?) : DialogFragment() {
    private var _binding: DialogAlbumSortingBinding? = null
    private val binding get() = _binding!!
    private lateinit var safeContext: Context
    private val baseActivity: BaseActivity
        get() = requireActivity() as BaseActivity

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogAlbumSortingBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        initView()
        clickListener()

        return dialog
    }

    private fun initView() {
        when (baseActivity.sharedViewModel.getAlbumSortType()) {
            AlbumSortType.NAME -> binding.rbName.isChecked = true
            AlbumSortType.PATH -> binding.rbPath.isChecked = true
            AlbumSortType.SIZE -> binding.rbSize.isChecked = true
            AlbumSortType.LAST_MODIFIED -> binding.rbLastModified.isChecked = true
        }
        when (baseActivity.sharedViewModel.getAlbumSortOrder()) {
            SortOrder.ASCENDING -> binding.rbAscending.isChecked = true
            SortOrder.DESCENDING -> binding.rbDescending.isChecked = true
        }
    }

    private fun clickListener() {
        binding.btnCancel.setOnClickListener {
            dismiss()
        }
        binding.btnOK.setOnClickListener {
            val selectedRadioButtonId: Int = binding.grpOption.checkedRadioButtonId
            val selectedRadioButtonIdOrder: Int = binding.grpOrder.checkedRadioButtonId
            val albumSortType = when (selectedRadioButtonId) {
                binding.rbName.id -> AlbumSortType.NAME
                binding.rbPath.id -> AlbumSortType.PATH
                binding.rbSize.id -> AlbumSortType.SIZE
                binding.rbLastModified.id -> AlbumSortType.LAST_MODIFIED
                else -> AlbumSortType.NAME
            }
            baseActivity.sharedViewModel.setAlbumSortType(albumSortType)

            val albumSortOrder = when (selectedRadioButtonIdOrder) {
                binding.rbAscending.id -> SortOrder.ASCENDING
                binding.rbDescending.id -> SortOrder.DESCENDING
                else -> SortOrder.DESCENDING
            }
            baseActivity.sharedViewModel.setAlbumSortOrder(albumSortOrder)

            dismiss()
            updateListener?.invoke()
        }
    }
}