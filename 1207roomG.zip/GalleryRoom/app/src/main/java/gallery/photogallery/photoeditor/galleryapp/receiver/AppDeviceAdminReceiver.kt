package gallery.photogallery.photoeditor.galleryapp.receiver

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import gallery.photogallery.photoeditor.galleryapp.utils.UPDATE_PROTECTION
import gallery.photogallery.photoeditor.galleryapp.utils.sendIntentEvent


class AppDeviceAdminReceiver : DeviceAdminReceiver() {
    private val TAG = "DeviceAdmin"
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        Log.e(TAG, "onDisableRequested: ${intent.action}")
        sendIntentEvent(UPDATE_PROTECTION)
    }

}