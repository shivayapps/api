package gallery.photogallery.photoeditor.galleryapp.collage.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
 import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.collage.utils.FontFileAsset


class FontAdapter(
    private val context: Context,
    private val lstFonts: List<String>,
    private val onItemClick: (position: Int) -> Unit // callback lambda
) : RecyclerView.Adapter<FontAdapter.ViewHolder>() {

    var selectedItem = 0
        private set

    override fun getItemViewType(position: Int): Int = position

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_font, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        FontFileAsset.setFontByName(context, holder.font, lstFonts[position])

        val backgroundRes = if (selectedItem != position) {
            R.drawable.shape_round_img
        } else {
            R.drawable.border_black_view
        }

        holder.wrapperFontItems.background = ContextCompat.getDrawable(context, backgroundRes)
    }

    override fun getItemCount(): Int = lstFonts.size

    fun setSelectedItem(position: Int) {
        val previousSelected = selectedItem
        selectedItem = position
        notifyItemChanged(previousSelected)
        notifyItemChanged(selectedItem)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val font: TextView = itemView.findViewById(R.id.text_view_font_item)
        val wrapperFontItems: ConstraintLayout =
            itemView.findViewById(R.id.constraint_layout_wrapper_font_item)

        init {
            itemView.setOnClickListener {
                setSelectedItem(adapterPosition)
                onItemClick(adapterPosition)
            }
        }
    }
}
