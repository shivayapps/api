package gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory

import android.animation.AnimatorSet
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.MediaBox
import com.appblish.medialoader.AppblishImageLoader.loadFullBlur
import com.appblish.medialoader.AppblishImageLoader.loadFullImage
import gallery.photogallery.photoeditor.galleryapp.databinding.FragmentMemoryDisplayBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.startZoomInZoomOut

class NewMemoryPagerAdapter(private val activity: MemoryViewerActivity, private val mediaList: List<MediaBox>) :
    RecyclerView.Adapter<NewMemoryPagerAdapter.ViewHolder>() {
    inner class ViewHolder(val binding: FragmentMemoryDisplayBinding) : RecyclerView.ViewHolder(binding.root)

    private val viewHolderMap = HashMap<Int, ViewHolder>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(FragmentMemoryDisplayBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun getItemCount(): Int {
        return mediaList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        viewHolderMap[position] = holder
        val memoryMediaModel = mediaList[position]
        holder.binding.image.loadFullImage(memoryMediaModel.mediaPath, memoryMediaModel.mediaDate) {
            val isCenterCropNew = (it.intrinsicWidth < it.intrinsicHeight && it.intrinsicHeight >= it.intrinsicWidth * 0.3)
            if (isCenterCropNew) {
                holder.binding.image.scaleType = ImageView.ScaleType.CENTER_CROP
            } else {
                holder.binding.image.scaleType = ImageView.ScaleType.FIT_CENTER
            }
        }
        holder.binding.imageViewBack.loadFullBlur(memoryMediaModel.mediaPath, memoryMediaModel.mediaDate)

        holder.binding.root.setOnClickListener {
            activity.optionToggle()
        }
    }

    fun startZoomInZoomOut(position: Int, isPlaying: Boolean) {
        viewHolderMap[position]?.binding?.image?.startZoomInZoomOut(isPlaying)
    }

    fun pauseResumeZoomInZoomOut(position: Int, isPause: Boolean) {
        (viewHolderMap[position]?.binding?.image?.tag as? AnimatorSet)?.apply {
            if (isPause) {
                pause()
            } else {
                start()
            }
        }
    }


}