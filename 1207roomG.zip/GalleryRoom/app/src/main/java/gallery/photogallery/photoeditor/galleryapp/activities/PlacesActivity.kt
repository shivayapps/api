package gallery.photogallery.photoeditor.galleryapp.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.ScrollGate
import com.appblish.box.api.util.AppblishEvent
import com.appblish.box.api.util.MediaDataState
import com.appblish.gallery.core.v2.api.core.GallerySdkV2
import com.appblish.gallery.core.v2.api.model.PlaceListItem
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.adaptor.PlacesGridAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityPlacesBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.fadeIn
import gallery.photogallery.photoeditor.galleryapp.extentions.fadeOut
import gallery.photogallery.photoeditor.galleryapp.extentions.getMarkerOptions
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.tablayout.loge
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class PlacesActivity : BaseActivity() {
    private val binding by viewBinding(ActivityPlacesBinding::inflate)
    private val isLoadGrid by lazy { intent.getBooleanExtra("ARG_POSITION", false) }
    private val placesGridAdapter by lazy {
        PlacesGridAdapter(onPlaceClick = {
            val intent = Intent(this, PlacesOpenActivity::class.java)
            intent.putExtra("placeTitle", it.title)
            startActivity(intent)
        })
    }

    var placesPhotoGroupList = emptyList<PlaceListItem>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        binding.mapFullScreen.onCreate(savedInstanceState)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        GallerySdkV2.get().stopPlacesScanning()
        registerEventBus(this)
        ScrollGate.onScrollStart()
        init()
        clickListener()
    }


    private fun init() {

        if (isLoadGrid) {
            // Load Map
            binding.txtTitle.setText(R.string.places)
            binding.loutTab.setCurrentItem(1)

            binding.directoriesFastScroller.beGone()
            binding.cardMapFullScreen.beVisible()
        } else {
            // Load Grid
            binding.txtTitle.setText(R.string.Grid)
            binding.loutTab.setCurrentItem(0)

            binding.directoriesFastScroller.beVisible()
            binding.cardMapFullScreen.beGone()
        }
        observablePlaces()
    }

    private fun observablePlaces() {
        lifecycleScope.launch {
            val state = withContext(Dispatchers.IO) {
                sharedViewModel.getPlacesFlow()
            }
            when (state) {
                is MediaDataState.Empty -> {

                }

                MediaDataState.Loading -> {

                }

                is MediaDataState.Progress -> {

                }

                is MediaDataState.Success -> {
                    setMedias(state.data)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (isRequireRefetch) {
            isRequireRefetch = false
            observablePlaces()
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            AppblishEvent.ALL_PLACES_LOADED -> {
                if (isPause) {
                    isRequireRefetch = true
                } else {
                    observablePlaces()
                }

            }
        }
    }


    private fun clickListener() {

        binding.loutTab.observeIndexChange { _, toIndex, _, _ ->
            "getIndex: $toIndex".loge()
            if (toIndex == 0) {
                // Load Grid
                binding.txtTitle.setText(R.string.Grid)
                binding.cardMapFullScreen.fadeOut {
                    binding.directoriesFastScroller.fadeIn()
                }
            } else {
                // Load Map
                binding.txtTitle.setText(R.string.places)

                binding.directoriesFastScroller.fadeOut {
                    binding.cardMapFullScreen.fadeIn()
                }
            }
        }

        binding.rvPlacesGrid.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING ||
                    newState == RecyclerView.SCROLL_STATE_SETTLING
                ) {
                    ScrollGate.onScrollStart()
                } else {
                    ScrollGate.onScrollStop()
                }
            }
        })

        binding.ivBack.setOnClickListener {
            finish()
        }
    }

    private fun setMedias(items: List<PlaceListItem>) {
        if (binding.rvPlacesGrid.adapter == null) {
            val layoutManager = GridLayoutManager(this, 3)
            binding.rvPlacesGrid.layoutManager = layoutManager
            binding.rvPlacesGrid.adapter = placesGridAdapter
        }

        placesGridAdapter.submitList(items)
        binding.rvPlacesGrid.post {
            placesPhotoGroupList = items
            lifecycleScope.launch {
                delay(500)
                initMapData()
            }

        }

    }


    private var googleMap: GoogleMap? = null
    private fun initMapData() {
        if (googleMap != null) {
            updateMap()
        } else {
            binding.mapFullScreen.getMapAsync { map ->
                googleMap = map
                googleMap?.setOnMarkerClickListener { marker ->
                    val markerTag = marker.tag as? String ?: ""
                    val intent = Intent(this, PlacesOpenActivity::class.java)
                    intent.putExtra("placeTitle", markerTag)
                    startActivity(intent)
                    true
                }
                updateMap()
            }
        }


    }

    var markJob: Job? = null
    fun updateMap() {
        googleMap?.clear()
        markJob?.cancel()
        markJob = CoroutineScope(Dispatchers.IO).launch {
            if (placesPhotoGroupList.isNotEmpty()) {
                val album = placesPhotoGroupList[0]
                val markerOption = getMarkerOptions(album)
                if (markerOption != null) {
                    runOnUiThread {
                        val lat = placesPhotoGroupList[0].mediaList[0].mediaBox.latitude
                        val lng = placesPhotoGroupList[0].mediaList[0].mediaBox.longitude
                        if (lat != 0.0 && lng != 0.0) {
                            val location = LatLng(lat, lng)
                            val marker = googleMap?.addMarker(markerOption)
                            marker?.tag = album.title
                            googleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 10f))
                            googleMap?.animateCamera(CameraUpdateFactory.zoomIn())
                            googleMap?.animateCamera(CameraUpdateFactory.zoomTo(10f), 2000, null);
                        }
                    }
                }
            }
        }
        prepareOtherMarker()
    }

    private fun prepareOtherMarker() {
        CoroutineScope(Dispatchers.IO).launch {
            val list = ArrayList(placesPhotoGroupList)
            if (list.isNotEmpty()) {
                list.removeAt(0)
                list.forEach {
                    val markerOption = getMarkerOptions(it)
                    if (markerOption != null) {
                        runOnUiThread {
                            val marker = googleMap?.addMarker(markerOption)
                            marker?.tag = it.title
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ScrollGate.onScrollStop()
        unregisterEventBus(this)
    }

}