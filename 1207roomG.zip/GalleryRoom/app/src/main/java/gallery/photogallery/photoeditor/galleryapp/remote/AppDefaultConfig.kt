package gallery.photogallery.photoeditor.galleryapp.remote

import android.content.Context
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.clientConfigPref
import org.json.JSONObject


object AppDefaultConfig {
    private fun getJson(context: Context): JSONObject? {
        try {
            return JSONObject(context.clientConfigPref.appDefaultConfig)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    fun isAdEnabled(): Boolean {
        return RemoteConfigFast.getBoolean("adsEnable", false)
    }

    fun isSplashAppOpenAdEnabled(): Boolean {
        return RemoteConfigFast.getBoolean("splashAppOpenAdEnabled", false) && isAdEnabled()
    }

    fun isSplashNativeEnabled(): Boolean {
        return RemoteConfigFast.getBoolean("languageNativeAdEnabled", false) && isAdEnabled()
    }

    fun isLanguageInterAdEnabled(): Boolean {
        return RemoteConfigFast.getBoolean("languageInterAdEnabled", false) && isAdEnabled()
    }

    fun isShowInterAdOnLanguage(): Boolean {
        return RemoteConfigFast.getBoolean("showInterAdOnLanguage", false) && isAdEnabled()

    }

    fun isLanguageInterLoadShow(): Boolean {
        return RemoteConfigFast.getBoolean("languageInterLoadShow", false) && isAdEnabled()
    }

    fun isIntroScreenEnabled(): Boolean {
        return RemoteConfigFast.getBoolean("introScreenEnabled", false)

    }

    fun isIntroScreenBeforeLanguage(): Boolean {
        return RemoteConfigFast.getBoolean("introScreenBeforeLanguage", false)

    }

    fun isPermissionScreenEnabled(): Boolean {
        return RemoteConfigFast.getBoolean("permissionScreenEnabled", false)
    }

    fun isLanguageNativeBig(): Boolean {
        return RemoteConfigFast.getBoolean("languageNativeBig", false)

    }

    fun getLanguageInterLoaderText(): String {
        return RemoteConfigFast.getString("languageInterLoaderText", "Setting up language")
    }

    fun isListFirstNativeEnabled(): Boolean {
        return RemoteConfigFast.getBoolean("listFirstNativeEnabled", false)

    }

    fun isListSecondNativeEnabled(): Boolean {
        return RemoteConfigFast.getBoolean("listSecondNativeEnabled", false)
    }

    fun isThreadNativeEnabled(): Boolean {
        return RemoteConfigFast.getBoolean("threadNativeEnabled", false)
    }
    fun isHomeBottomBanner(context: Context): Boolean {
        return RemoteConfigFast.getString("homeBottomAd", "native") == "banner"
    }

    fun isFirstFlow(context: Context): Boolean {
        try {
            val jsonObjFamily = getJson(context)
            return jsonObjFamily!!.getInt("appFlow") == 1
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    fun getUserAgreement(context: Context): String {
        try {
            val jsonObjFamily = getJson(context)
            return jsonObjFamily!!.getString("userAgreement")
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return ""
    }

    fun getPrivacyPolicy(context: Context): String {
        try {
            val jsonObjFamily = getJson(context)
            return jsonObjFamily!!.getString("privacyPolicy")
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return ""
    }

    fun getFeedbackEmail(context: Context): String {
        try {
            val jsonObjFamily = getJson(context)
            return jsonObjFamily!!.getString("feedbackEmail")
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return ""
    }

}