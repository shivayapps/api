package gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipDescription
import android.content.ContentUris
import android.content.Context
import android.content.Context.ACTIVITY_SERVICE
import android.content.Context.NOTIFICATION_SERVICE
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Point
import android.graphics.PorterDuff
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.MediaStore.Files
import android.provider.MediaStore.Images
import android.provider.MediaStore.Video
import android.provider.Settings
import android.system.ErrnoException
import android.system.Os
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.annotation.WorkerThread
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.createBitmap
import androidx.core.net.toUri
import androidx.exifinterface.media.ExifInterface
import com.appblish.box.api.model.MediaBox
import gallery.photogallery.photoeditor.galleryapp.permission.PermissionSDK
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.SetWallpaperActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.CustomMarkerBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.remote.ClientConfigPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant.RECOVER_PATH
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.ensureBackgroundThread
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.isOnMainThread
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

val Context.clientConfigPref: ClientConfigPref
    get() = ClientConfigPref.newInstance(
        applicationContext
    )
val Context.appPref: Preferences
    get() = Preferences(
        applicationContext
    )
val Context.preferences: Preferences
    get() = Preferences(
        applicationContext
    )


fun Context.getThemeSharedPrefs() = getSharedPreferences("THEME_PREF", Context.MODE_PRIVATE)

fun Context.checkStoragePermission(): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        val result = ContextCompat.checkSelfPermission(
            this, Manifest.permission.READ_EXTERNAL_STORAGE
        )
        val result1 = ContextCompat.checkSelfPermission(
            this, Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
        result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED
    }
}

val Context.navigationBarOnSide: Boolean get() = usableScreenSize.x < realScreenSize.x && usableScreenSize.x > usableScreenSize.y
val Context.navigationBarOnBottom: Boolean get() = usableScreenSize.y < realScreenSize.y
val Context.navigationBarHeight: Int get() = newNavigationBarHeight
val Context.navigationBarWidth: Int get() = if (navigationBarOnSide) navigationBarSize.x else 0

val Context.navigationBarSize: Point
    get() = when {
        navigationBarOnSide -> Point(newNavigationBarHeight, usableScreenSize.y)
        navigationBarOnBottom -> Point(usableScreenSize.x, newNavigationBarHeight)
        else -> Point()
    }

val Context.newNavigationBarHeight: Int
    get() {
        var navigationBarHeight = 0
        val resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        if (resourceId > 0) {
            navigationBarHeight = resources.getDimensionPixelSize(resourceId)
        }
        return navigationBarHeight
    }

val Context.statusBarHeight: Int
    get() {
        var statusBarHeight = 0
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resourceId > 0) {
            statusBarHeight = resources.getDimensionPixelSize(resourceId)
        }
        return statusBarHeight
    }

val Context.actionBarHeight: Int
    get() {
        val styledAttributes = theme.obtainStyledAttributes(intArrayOf(android.R.attr.actionBarSize))
        val actionBarHeight = styledAttributes.getDimension(0, 0f)
        styledAttributes.recycle()
        return actionBarHeight.toInt()
    }

val Context.usableScreenSize: Point
    get() {
        val size = Point()
        windowManager.defaultDisplay.getSize(size)
        return size
    }

val Context.realScreenSize: Point
    get() {
        val size = Point()
        windowManager.defaultDisplay.getRealSize(size)
        return size
    }
val Context.windowManager: WindowManager get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager
val Context.icPlayIconSize: Int
    get() {
        val dir = resources.getDimension(com.intuit.sdp.R.dimen._30sdp)
        return dir.toInt()
    }

fun Context.shareFilesList(activity: Context, uris: List<Uri>) {
    val intent = Intent(Intent.ACTION_SEND_MULTIPLE)
    intent.type = "*/*"
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
    intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
    intent.addFlags(FLAG_ACTIVITY_NEW_TASK)
    try {
        activity.startActivity(
            Intent.createChooser(
                intent,
                activity.getString(R.string.share_with)
            )
        )
    } catch (e: Exception) {
        e.printStackTrace()
        activity.toast(e.message.toString())
    }
}

fun Context.shareFilesList(filePath: String) {
    val uri = FileProvider.getUriForFile(
        this, this.packageName + ".provider", File(filePath)
    )
    val intent = Intent(Intent.ACTION_SEND)
    if (filePath.isImageFast()) {
        intent.type = "image/*"
    } else if (filePath.isVideoFast()) {
        intent.type = "video/*"
    } else {
        intent.type = "*/*"
    }
    intent.putExtra(Intent.EXTRA_STREAM, uri)
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    startActivity(
        Intent.createChooser(
            intent, getString(R.string.share_with)
        )
    )
}

fun Context.isPackageInstalled(pkgName: String): Boolean {
    return try {
        packageManager.getPackageInfo(pkgName, 0)
        true
    } catch (e: Exception) {
        false
    }
}


fun Context.cancelNotification(notifyId: Int) {
    val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    notificationManager.cancel(notifyId)
}


fun Context.createAllMediaStoreDirectory(): File {
    val file = File(filesDir, "MyDatabase/AllMediaStore")
    if (!file.exists()) {
        file.mkdirs()
    }
    return file
}

fun Context.createFavMediaStoreDirectory(): File {
    val file = File(filesDir, "MyDatabase/FavMediaStore")
    if (!file.exists()) {
        file.mkdirs()
    }
    return file
}

fun Context.createPlaceMediaStoreDirectory(): File {
    val file = File(filesDir, "MyDatabase/PlaceMediaStore")
    if (!file.exists()) {
        file.mkdirs()
    }
    return file
}

fun Context.createCategoryMediaStoreDirectory(): File {
    val file = File(filesDir, "MyDatabase/CategoryMediaStore")
    if (!file.exists()) {
        file.mkdirs()
    }
    return file
}

fun Context.createRecycleDatabaseDirectory(): File {
    val file = File(filesDir, "MyDatabase/RecycleDatabase")
    if (!file.exists()) {
        file.mkdirs()
    }
    return file
}

fun Context.createHiddenMediaDatabaseDirectory(): File {
    val file = File(filesDir, "MyDatabase/HiddenMediaDatabase")
    if (!file.exists()) {
        file.mkdirs()
    }
    return file
}

fun Context.createDeletedMediaDatabaseDirectory(): File {
    val file = File(filesDir, "MyDatabase/DeletedMediaDatabase")
    if (!file.exists()) {
        file.mkdirs()
    }
    return file
}

fun Context.createMemoriesMediaDatabaseDirectory(): File {
    val file = File(filesDir, "MyDatabase/MemoriesMediaStore")
    if (!file.exists()) {
        file.mkdirs()
    }
    return file
}

fun Context.createRecycleBinDirectory(): String {
    val file = File(filesDir, "RecycleBin")
    if (!file.exists()) {
        file.mkdirs()
    }
    return file.absolutePath
}

fun Context.createPrivateDirectory(): String {
    val file = File(Environment.getExternalStorageDirectory(), "Private")
    if (!file.exists()) {
        file.mkdirs()
    }
    return file.absolutePath
}

fun Context.createRecoverDirectory(): String {
    val file = File(Environment.getExternalStorageDirectory(), RECOVER_PATH)
    if (!file.exists()) {
        file.mkdirs()
    }
    return file.absolutePath
}


@SuppressLint("SetTextI18n")
fun Context.getMarkerBitmapFromView(photoPath: String, size: Int, lastModified: String): Bitmap? {
    try {
        val markerBinding = CustomMarkerBinding.inflate(LayoutInflater.from(this))
        markerBinding.txtCount.text = "$size"
        val options = BitmapFactory.Options().apply {
            inSampleSize = 30
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        val bitmap = BitmapFactory.decodeFile(photoPath, options)
        markerBinding.profileImage.setImageBitmap(bitmap)

        markerBinding.root.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        markerBinding.root.layout(
            0, 0, markerBinding.root.measuredWidth, markerBinding.root.measuredHeight
        )
        markerBinding.root.buildDrawingCache()
        val returnedBitmap = createBitmap(markerBinding.root.measuredWidth, markerBinding.root.measuredHeight)
        val canvas = Canvas(returnedBitmap)
        canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN)
        val drawable = markerBinding.root.background
        drawable?.draw(canvas)
        markerBinding.root.draw(canvas)
        return returnedBitmap
    } catch (e: Exception) {
        e.printStackTrace()

    }
    return null
}


fun Context.isDarkMode(): Boolean {
    return resources.getBoolean(R.bool.isDarkMode)
}

fun Context.isUsingSystemHasDarkTheme() = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_YES != 0


fun String.isFileExists(): Boolean {
    return try {
        Os.lstat(this) // Only checks if the file exists, no extra overhead
        true
    } catch (e: ErrnoException) {
        false
    }
}

fun Context.hasOverlayPermission(): Boolean {
    return Settings.canDrawOverlays(this)
}

fun Context.hasCallStatePermission(): Boolean {
    return ContextCompat.checkSelfPermission(
        this, Manifest.permission.READ_PHONE_STATE
    ) == PackageManager.PERMISSION_GRANTED
}

fun Context.hasNotificationPermission(): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(
            this, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    } else {
        true
    }
}

fun Context.showErrorToast(msg: String, length: Int = Toast.LENGTH_LONG) {
    toast(String.format(getString(R.string.error), msg), length)
}

fun Context.showErrorToast(exception: Exception, length: Int = Toast.LENGTH_LONG) {
    showErrorToast(exception.toString(), length)
}

fun Context.toast(id: Int, length: Int = Toast.LENGTH_SHORT) {
    toast(getString(id), length)
}

fun Context.toast(msg: String, length: Int = Toast.LENGTH_SHORT) {
    try {
        if (isOnMainThread()) {
            doToast(this, msg, length)
        } else {
            Handler(Looper.getMainLooper()).post {
                doToast(this, msg, length)
            }
        }
    } catch (e: Exception) {
    }
}

private fun doToast(context: Context, message: String, length: Int) {
    if (context is Activity) {
        if (!context.isFinishing && !context.isDestroyed) {
            Toast.makeText(context, message, length).show()
        }
    } else {
        Toast.makeText(context, message, length).show()
    }
}

fun Context.openPrivacyPolicy() {
    try {
        val url = clientConfigPref.privacyPolicy
        if (url.isNotBlank() && (url.startsWith("http://") || url.startsWith("https://"))) {
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, url.toUri())
                startActivity(browserIntent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {

            Toast.makeText(this, "Invalid or empty link", Toast.LENGTH_SHORT).show()
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

fun Context.shareApp() {
    val sendIntent = Intent(Intent.ACTION_SEND)
    sendIntent.setAction(Intent.ACTION_SEND)
    sendIntent.setType("text/plain")
    var appUrl = "https://play.google.com/store/apps/details?id=$packageName"
    appUrl = ("Download now " + getString(R.string.app_name)) + " : " + appUrl
    sendIntent.putExtra(
        Intent.EXTRA_TEXT, appUrl
    )
    sendIntent.setType("text/plain")
    startActivity(sendIntent)
}

/*fun Activity.setAs(filePath: String) {
    ensureBackgroundThread {
        val newUri = getFinalUriFromPath(filePath, "gallery.photogallery.photoeditor.galleryapp") ?: return@ensureBackgroundThread
        Intent().apply {
            action = Intent.ACTION_ATTACH_DATA
            setDataAndType(newUri, getUriMimeType(filePath, newUri))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val chooser = Intent.createChooser(this, getString(R.string.set_as))
            isAdsNotShowOnResume = true
            try {
                startActivityForResult(chooser, 101)
            } catch (e: ActivityNotFoundException) {
                toast(R.string.no_app_found)
            } catch (e: Exception) {
                showErrorToast(e)
            }
        }
    }

}*/

fun Activity.setAs(filePath: String) {
    ensureBackgroundThread {
        val newUri = getFinalUriFromPath(filePath, "gallery.photogallery.photoeditor.galleryapp") ?: return@ensureBackgroundThread
        val intent = Intent(this, SetWallpaperActivity::class.java)
        intent.putExtra("image_uri", newUri) // imageUri: Uri from gallery, etc.
        startActivity(intent)
    }
}


fun Context.getFinalUriFromPath(path: String, applicationId: String): Uri? {
    val uri = try {
        ensurePublicUri(path, applicationId)
    } catch (e: Exception) {
        //showErrorToast(e)
        return null
    }

    if (uri == null) {
        toast(R.string.unknown_error_occurred)
        return null
    }

    return uri
}

fun Context.getUriMimeType(path: String, newUri: Uri): String {
    var mimeType = path.getMimeType()
    if (mimeType.isEmpty()) {
        mimeType = getMimeTypeFromUri(newUri)
    }
    return mimeType
}

fun Context.getMimeTypeFromUri(uri: Uri): String {
    var mimetype = uri.path?.getMimeType() ?: ""
    if (mimetype.isEmpty()) {
        try {
            mimetype = contentResolver.getType(uri) ?: ""
        } catch (e: IllegalStateException) {
        }
    }
    return mimetype
}

fun Context.ensurePublicUri(path: String, applicationId: String): Uri? {
    val uri = Uri.parse(path)
    return if (uri.scheme == "content") {
        uri
    } else {
        val newPath = if (uri.toString().startsWith("/")) uri.toString() else uri.path
        val file = File(newPath)
        getFilePublicUri(file, applicationId)
    }
}

fun Context.getFilePublicUri(file: File, applicationId: String): Uri {
    var uri = if (file.isMediaFile()) {
        getMediaContentUri(file.absolutePath)
    } else {
        getMediaContent(file.absolutePath, Files.getContentUri("external"))
    }

    if (uri == null) {
        uri = FileProvider.getUriForFile(this, "$applicationId.provider", file)
    }

    return uri!!
}

fun Context.getMediaContent(path: String, uri: Uri): Uri? {
    val projection = arrayOf(Images.Media._ID)
    val selection = Images.Media.DATA + "= ?"
    val selectionArgs = arrayOf(path)
    try {
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(Images.Media._ID)).toString()
                return Uri.withAppendedPath(uri, id)
            }
        }
    } catch (e: Exception) {
    }
    return null
}

fun Context.getMediaContentUri(path: String): Uri? {
    val uri = when {
        path.isImageFast() -> Images.Media.EXTERNAL_CONTENT_URI
        path.isVideoFast() -> Video.Media.EXTERNAL_CONTENT_URI
        else -> Files.getContentUri("external")
    }
    return getMediaContent(path, uri)
}


fun BaseActivity.showResizeDialog(objectMediaModel: MediaBox, callback: (MediaBox) -> Unit) {

}

@WorkerThread
fun getLensIntentForImageUri(uri: Uri): Intent {
    val intent = Intent()
    intent.setPackage("com.google.ar.lens")
    return getShareIntentForImageUri(uri, intent)
}

private fun getShareIntentForImageUri(uri: Uri, mIntent: Intent): Intent {
    var intent = Intent()
    if (mIntent != null) {
        intent = mIntent
    }
    val clipData = ClipData(
        ClipDescription("content", arrayOf("image/png")), ClipData.Item(uri)
    )
    intent.setAction(Intent.ACTION_SEND).setComponent(null).addFlags(FLAG_ACTIVITY_NEW_TASK).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        .setType("image/png")
        .putExtra(Intent.EXTRA_STREAM, uri).clipData = clipData
    return Intent.createChooser(intent, null).addFlags(FLAG_ACTIVITY_NEW_TASK)
//        return intent
}


fun getExifImageDimensions(filePath: String): Pair<Int, Int>? {
    return try {
        try {
            val exif = ExifInterface(filePath)
            val width = exif.getAttributeInt(ExifInterface.TAG_IMAGE_WIDTH, 0)
            val height = exif.getAttributeInt(ExifInterface.TAG_IMAGE_LENGTH, 0)
            if (width > 0 && height > 0) Pair(width, height) else null
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    } catch (e: OutOfMemoryError) {
        e.printStackTrace()
        null
    }
}

val DEFAULT_DOUBLE_TAP_ZOOM = 2f
private val SAME_ASPECT_RATIO_THRESHOLD = 0.01
val Context.portrait get() = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
fun Context.getDoubleTapZoomScale(width: Int, height: Int): Float {
    val metrics = DisplayMetrics()
    windowManager.defaultDisplay.getRealMetrics(metrics)
    val mScreenWidth = metrics.widthPixels
    val mScreenHeight = metrics.heightPixels
    val bitmapAspectRatio = height / width.toFloat()
    val screenAspectRatio = mScreenHeight / mScreenWidth.toFloat()

    return if (abs(bitmapAspectRatio - screenAspectRatio) < SAME_ASPECT_RATIO_THRESHOLD) {
        DEFAULT_DOUBLE_TAP_ZOOM
    } else if (portrait && bitmapAspectRatio <= screenAspectRatio) {
        mScreenHeight / height.toFloat()
    } else if (portrait && bitmapAspectRatio > screenAspectRatio) {
        mScreenWidth / width.toFloat()
    } else if (!portrait && bitmapAspectRatio >= screenAspectRatio) {
        mScreenWidth / width.toFloat()
    } else if (!portrait && bitmapAspectRatio < screenAspectRatio) {
        mScreenHeight / height.toFloat()
    } else {
        DEFAULT_DOUBLE_TAP_ZOOM
    }
}


fun Context.getFileName(count: Int, dir: String, strName: String, extension: String): File {
    var i = count
    var name = strName
    var check = File(dir, name)
    if (check.exists()) {
        i++
        if (name.contains(".")) {
            if (name.indexOf(".") > 0) {
                name = name.substring(0, name.lastIndexOf(".")) + "(" + i + ")" + ".$extension"
            }
        } else {
            name = "$name($i)"
        }
        check = getFileName(i, dir, name, extension)
    }
    return check
}

fun Context.startDeletedMediaScanner() {
    /* val workManager = WorkManager.getInstance(this)
     val builder = OneTimeWorkRequestBuilder<DeleteFileWorker>()
     workManager.enqueue(builder.build())*/
//    DeleteFileWorker(this).doWork()

}

fun Context.commonPrefix(strings: List<String>): String {
    if (strings.isEmpty()) return ""
    return strings.reduce { acc, string -> acc.commonPrefixWith(string) }
}

fun Context.isAppInBackground(): Boolean {
    var isInBackground = true
    try {
        val am = (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager)
        val runningProcesses = am.runningAppProcesses
        for (processInfo in runningProcesses) {
            if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                for (activeProcess in processInfo.pkgList) {
                    if (activeProcess == getPackageName()) {
                        isInBackground = false
                    }
                }
            }
        }
    } catch (e: java.lang.Exception) {
        e.printStackTrace()
        return true
    }
    return isInBackground
}

fun Context.getVideoResolution(path: String): Point? {
    var point = try {
        val retriever = MediaMetadataRetriever()
//        if (isRestrictedSAFOnlyRoot(path)) {
//            retriever.setDataSource(this, getAndroidSAFUri(path))
//        } else {
        retriever.setDataSource(path)
//        }

        val width =
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
        val height =
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
        Point(width, height)
    } catch (ignored: Exception) {
        null
    }

    if (point == null && path.startsWith("content://", true)) {
        try {
            val fd = contentResolver.openFileDescriptor(Uri.parse(path), "r")?.fileDescriptor
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(fd)
            val width =
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
            val height =
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!
                    .toInt()
            point = Point(width, height)
        } catch (ignored: Exception) {
        }
    }

    return point
}

private fun Context.isServiceRunning(serviceClass: Class<*>): Boolean {
    val activityManager =
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager)
    for (service in activityManager!!.getRunningServices(Int.MAX_VALUE)) {
        if (serviceClass.name == service.service.className) {
            return true
        }
    }
    return false
}


fun Context.getLimitedScreenSize(context: Context): Pair<Int, Int> {
    return Pair((context.realScreenSize.x * 0.7).toInt(), (context.realScreenSize.y * 0.7).toInt())
}

fun Context.getLimitedScreenSize(limitPx: Int = 2048): Pair<Int, Int> {
    val metrics = resources.displayMetrics
    val maxW = metrics.widthPixels
    val maxH = metrics.heightPixels

    // ensure some headroom for UI overlays + very large displays
    val w = max(1, maxW.coerceAtMost(limitPx))
    val h = max(1, maxH.coerceAtMost(limitPx))
    return w to h
}

fun Context.getStringForLocale(resId: Int, locale: Locale): String {
    val config = Configuration(resources.configuration)
    config.setLocale(locale)

    val localizedContext = createConfigurationContext(config)
    return localizedContext.resources.getString(resId)
}

fun String.areDigitsOnly() = matches(Regex("[0-9]+"))

/*
fun Context.getDataColumn(
    uri: Uri, selection: String? = null, selectionArgs: Array<String>? = null
): String? {
    try {
        val projection = arrayOf(MediaStore.Files.FileColumns.DATA)
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                val data = cursor.getStringValue(MediaStore.Files.FileColumns.DATA)
                if (data != "null") {
                    return data
                }
            }
        }
    } catch (e: Exception) {
    }
    return null
}*/

fun Context.checkMediaPermission(): Boolean {
    return PermissionSDK.isReadMediaPermission(this) || PermissionSDK.hasLimitedPhotoAccess(this)
}

fun Context.getRealPathFromURI(uri: Uri): String? {
    if (uri.scheme == "file") {
        return uri.path
    }

    if (isDownloadsDocument(uri)) {
        val id = DocumentsContract.getDocumentId(uri)
        if (id.areDigitsOnly()) {
            val newUri = ContentUris.withAppendedId(
                Uri.parse("content://downloads/public_downloads"), id.toLong()
            )
            val path = getDataColumn(newUri)
            if (path != null) {
                return path
            }
        }
    } else if (isExternalStorageDocument(uri)) {
        val documentId = DocumentsContract.getDocumentId(uri)
        val parts = documentId.split(":")
        if (parts[0].equals("primary", true)) {
            return "${Environment.getExternalStorageDirectory().absolutePath}/${parts[1]}"
        }
    } else if (isMediaDocument(uri)) {
        val documentId = DocumentsContract.getDocumentId(uri)
        val split = documentId.split(":").dropLastWhile { it.isEmpty() }.toTypedArray()
        val type = split[0]

        val contentUri = when (type) {
            "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }

        val selection = "_id=?"
        val selectionArgs = arrayOf(split[1])
        val path = getDataColumn(contentUri, selection, selectionArgs)
        if (path != null) {
            return path
        }
    }

    return getDataColumn(uri)
}

fun Context.getDataColumn(
    uri: Uri, selection: String? = null, selectionArgs: Array<String>? = null,
): String? {
    try {
        val projection = arrayOf(MediaStore.Files.FileColumns.DATA)
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                val data = cursor.getStringValue(MediaStore.Files.FileColumns.DATA)
                if (data != "null") {
                    return data
                }
            }
        }
    } catch (e: Exception) {
    }
    return null
}

private fun isMediaDocument(uri: Uri) = uri.authority == "com.android.providers.media.documents"

private fun isDownloadsDocument(uri: Uri) =
    uri.authority == "com.android.providers.downloads.documents"

private fun isExternalStorageDocument(uri: Uri) =
    uri.authority == "com.android.externalstorage.documents"

fun Context.createFirebaseDefaultChannel() {
    val notificationManager =
        getSystemService(NOTIFICATION_SERVICE) as NotificationManager
    notificationManager.deleteNotificationChannel(getString(R.string.default_notification_channel_id))

    val mChannel = NotificationChannel(
        getString(R.string.default_notification_channel_id),
        getString(R.string.default_notification_channel_id),
        NotificationManager.IMPORTANCE_LOW
    )
    notificationManager.createNotificationChannel(mChannel)
}

fun Context.getAppVersionCode(): Long {
    return try {
        val packageInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.getPackageInfo(
                packageName,
                PackageManager.PackageInfoFlags.of(0)
            )
        } else {
            @Suppress("DEPRECATION")
            packageManager.getPackageInfo(packageName, 0)
        }

        packageInfo.longVersionCode
    } catch (e: Exception) {
        e.printStackTrace()
        -1L
    }
}

