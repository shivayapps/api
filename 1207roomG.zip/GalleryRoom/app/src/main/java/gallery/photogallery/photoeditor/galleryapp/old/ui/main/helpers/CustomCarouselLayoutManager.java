package gallery.photogallery.photoeditor.galleryapp.old.ui.main.helpers;

import android.content.Context;
import android.view.View;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class CustomCarouselLayoutManager extends LinearLayoutManager {
    public CustomCarouselLayoutManager(Context context, int orientation, boolean reverseLayout) {
        super(context, orientation, reverseLayout);
    }

    @Override
    public int scrollHorizontallyBy(int dx, RecyclerView.Recycler recycler, RecyclerView.State state) {

        int orientation = getOrientation();

        if (orientation == HORIZONTAL) {
            int scrolled = super.scrollHorizontallyBy(dx, recycler, state);

            float minifyAmount = 0.25f;
            float minifyDistance = 0.25f;

            float parentMidpoint = getWidth() / 2.f;
            float d0 = 0.f;
            float d1 = parentMidpoint * minifyDistance;
            float s0 = 1.f;
            float s1 = 1.f - minifyAmount;

            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);

                float childMidpoint = (getDecoratedLeft(child) + getDecoratedRight(child)) / 2.f;
                float d = Math.min(d1, Math.abs(parentMidpoint - childMidpoint));
                float scaleFactor = s0 + (s1 - s0) * (d - d0) / (d1 - d0);

                child.setScaleX(scaleFactor);
                child.setScaleY(scaleFactor);
            }

            return scrolled;
        } else {
            return 0;
        }
    }

    @Override
    public void onLayoutChildren(RecyclerView.Recycler recycler, RecyclerView.State state) {
        super.onLayoutChildren(recycler, state);
        scrollHorizontallyBy(0, recycler, state);


    }

    public int getCenterItemPosition() {
        float parentMidpoint = getWidth() / 2.f; // RecyclerView's center
        int closestPosition = -1;
        float closestDistance = Float.MAX_VALUE;

        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child != null) {
                // Calculate the center of the child view
                float childMidpoint = (getDecoratedLeft(child) + getDecoratedRight(child)) / 2.f;
                float distanceFromCenter = Math.abs(parentMidpoint - childMidpoint);

                // Update the closest position if this child is closer
                if (distanceFromCenter < closestDistance) {
                    closestDistance = distanceFromCenter;
                    closestPosition = getPosition(child);
                }
            }
        }

        return closestPosition;
    }

}
