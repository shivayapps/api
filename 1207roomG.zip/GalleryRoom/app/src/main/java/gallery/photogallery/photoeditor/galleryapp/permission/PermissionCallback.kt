package gallery.photogallery.photoeditor.galleryapp.permission

data class PermissionCallback(
    val onPermissionResult: (granted: Boolean) -> Unit = {},
    val onLimitedAccess: () -> Unit = {},
    val onPermissionRationale: () -> Unit = { },
)
