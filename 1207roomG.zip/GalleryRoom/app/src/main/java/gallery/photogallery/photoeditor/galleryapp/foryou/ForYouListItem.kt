package gallery.photogallery.photoeditor.galleryapp.foryou

import com.appblish.story.memories.api.model.MemoryBox

sealed class ForYouListItem {
    data class Memory(val memory: MemoryBox) : ForYouListItem()
    object Header : ForYouListItem()
}