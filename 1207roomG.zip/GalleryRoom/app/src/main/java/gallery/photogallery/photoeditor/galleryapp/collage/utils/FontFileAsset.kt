package gallery.photogallery.photoeditor.galleryapp.collage.utils
import android.content.Context
import android.graphics.Typeface
import android.widget.TextView

object FontFileAsset {

    fun setFontByName(context: Context, textView: TextView, name: String) {
        val assetManager = context.assets
        textView.typeface = Typeface.createFromAsset(assetManager, "fonts/$name")
    }

    fun getListFonts(): List<String> {
        return listOf(
            "0.ttf",
            "1.ttf",
            "2.otf",
            "3.ttf",
            "4.ttf",
            "5.ttf",
            "6.otf",
            "7.ttf",
            "8.ttf",
            "9.ttf",
            "10.ttf",
            "11.ttf",
            "12.ttf",
            "13.ttf",
            "14.ttf",
            "15.ttf",
            "16.ttf",
            "17.ttf",
            "18.ttf",
            "19.ttf"
        )
    }
}