package gallery.photogallery.photoeditor.galleryapp.activities

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.core.view.WindowCompat
import androidx.core.view.isVisible
import androidx.interpolator.view.animation.FastOutSlowInInterpolator
import androidx.lifecycle.lifecycleScope
import com.appblish.box.api.DeviceMediaFetcher
import com.appblish.box.api.model.MediaBox
import com.appblish.box.api.util.AppblishEvent
import com.appblish.gallery.core.v2.api.core.GallerySdkV2
import com.appblish.gallery.core.v2.api.model.AlbumModel
import com.appblish.gallery.core.v2.api.model.MediaModel
import gallery.photogallery.photoeditor.galleryapp.permission.PermissionSDK
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import com.google.firebase.messaging.FirebaseMessaging
import com.google.gson.Gson
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityMainBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.PopAlbumMenuBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.PopBottomMenuBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.AlbumDetailsDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.ConfirmationDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.PhotosDetailsDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.RedirectCommonDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.RedirectDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.RenameAlbumDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.RenamePhotosDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.ResizeDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.dpToPx
import gallery.photogallery.photoeditor.galleryapp.extentions.editPhoto
import gallery.photogallery.photoeditor.galleryapp.extentions.hideIndicator
import gallery.photogallery.photoeditor.galleryapp.extentions.showIndicator
import gallery.photogallery.photoeditor.galleryapp.old.job.MediaContentObserver.Companion.registerContentObserver
import gallery.photogallery.photoeditor.galleryapp.old.job.MediaContentObserver.Companion.unregisterContentObserver
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.GO_TO_PHOTO
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.MemoryEvent
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.checkMediaPermission
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.clientConfigPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isDarkMode
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.setAs
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.shareFilesList
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant.isAppInstalled
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.PopupWindowHelper
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.SetLockActivity
import gallery.photogallery.photoeditor.galleryapp.remote.AppRedirectConfig
import gallery.photogallery.photoeditor.galleryapp.remote.AppRedirectionConfig
import gallery.photogallery.photoeditor.galleryapp.remote.RedirectItem
import gallery.photogallery.photoeditor.galleryapp.utils.RESET_ALBUM_GRID
import gallery.photogallery.photoeditor.galleryapp.utils.RESET_MEDIA
import gallery.photogallery.photoeditor.galleryapp.utils.START_SCANNING
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import gallery.photogallery.photoeditor.galleryapp.viewlayout.AlbumLayout
import gallery.photogallery.photoeditor.galleryapp.viewlayout.AllMediaLayout
import gallery.photogallery.photoeditor.galleryapp.viewlayout.ExploreLayout
import gallery.photogallery.photoeditor.galleryapp.viewlayout.ForYouLayout
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class MainActivity : BaseActivity() {
    private val binding by viewBinding(ActivityMainBinding::inflate)
    private val albumLayout by lazy { AlbumLayout(this, binding.albumFragment) }
    private val allMediaLayout by lazy { AllMediaLayout(this, binding.allMediaFragment) }
    private val forYouLayout by lazy { ForYouLayout(this, binding.forYouFragment) }
    private val exploreLayout by lazy { ExploreLayout(this, binding.exploreFragment) }
    private var lastBackPressedTime = 0L
    val lockActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            if (result.data != null) {
                exploreLayout.launchPrivate()

            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.main.setPadding(0, statusBarHeight, 0, navigationBarHeight)
        preferences.isMoveToHome = true
        registerEventBus(this)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = !isDarkMode()
        controller.isAppearanceLightNavigationBars = !isDarkMode()
        window?.navigationBarColor = ContextCompat.getColor(this, R.color.app_background)
        if (checkMediaPermission()) {
            initView()
        } else {
            binding.mainViewFlipper.beGone()
            binding.permissionFragment.beVisible()
        }
        clickListener()
        checkUpdate()
        AppRedirectionConfig.handleRedirectFromCache(application) { config, dialogKey, dialog ->
            showRedirectDialog(config, dialogKey, dialog)
        }

    }

    private fun clickListener() {
        binding.llAlbumFragment.setOnClickListener {
            updateNavUI(0)
        }

        binding.llAllMediaFragment.setOnClickListener {
            updateNavUI(1)
        }

        binding.llMemoriesFragment.setOnClickListener {
            updateNavUI(2)
        }

        binding.llMoreFragment.setOnClickListener {
            updateNavUI(3)
        }

        onBackPressedDispatcher.addCallback {
            onBack()
        }
    }


    private fun updateNavUI(selectedIndex: Int) {
        binding.mainViewFlipper.displayedChild = selectedIndex
        val items = listOf(
            binding.llAlbumFragment,
            binding.llAllMediaFragment,
            binding.llMemoriesFragment,
            binding.llMoreFragment
        )

        items.forEachIndexed { index, item ->
            val isSelected = index == selectedIndex

            item.isSelected = isSelected

            val icon = item.getChildAt(0) as ImageView
            val text = item.getChildAt(1) as TextView
            val indicator = item.getChildAt(2) as View

            icon.isSelected = isSelected
            text.isSelected = isSelected
            indicator.isSelected = isSelected

            // Icon animation
            icon.animate()
                .translationY(if (isSelected) -3f else 0f)
                .scaleX(if (isSelected) 1.05f else 1f)
                .scaleY(if (isSelected) 1.05f else 1f)
                .setDuration(240)
                .setInterpolator(FastOutSlowInInterpolator())
                .start()

            // Text animation
            text.animate()
                .alpha(if (isSelected) 1f else 0.7f)
                .setDuration(220)
                .start()

            animateIndicator(indicator, isSelected)
        }
    }

    private fun animateIndicator(indicator: View, selected: Boolean) {
        if (selected) {
            indicator.showIndicator()
        } else {
            indicator.hideIndicator()
        }
    }

    @SuppressLint("MissingSuperCall", "GestureBackNavigation")
    override fun onBackPressed() {
        onBack()
    }

    fun onBack() {
        when {
            binding.albumSelectionView.isVisible -> albumLayout.disableSelection()
            binding.clMediaSelectionView.isVisible -> allMediaLayout.disableSelection()
            binding.mainViewFlipper.displayedChild != 0 -> {
                updateNavUI(0)
            }

            else -> {
                val currentTime = System.currentTimeMillis()
                if (currentTime - lastBackPressedTime < 2000) {
                    finish()
                } else {
                    lastBackPressedTime = currentTime
                    Toast.makeText(this, getString(R.string.press_back_again_to_exit), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    private fun initView() {
        binding.mainViewFlipper.beVisible()
        binding.permissionFragment.beGone()
        lifecycleScope.launch {
            setupAlbums()
            setupAllMedias()
            setupForYou()
            setupExplore()
            updateNavUI(0)
            sharedViewModel.fetchStories()
            sharedViewModel.fetchMemories()
            GallerySdkV2.get().startPlaceScanning(this@MainActivity)
            registerContentObserver(this@MainActivity)
            handleIntent(intent)
            updateToken()
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            RESET_MEDIA -> {
                allMediaLayout.resetMedia()
            }

            RESET_ALBUM_GRID -> {
                albumLayout.resetAlbum()
            }

            DeviceMediaFetcher.FIRST_FETCH_DONE -> {
                if (PermissionSDK.isReadMediaPermission(this)) {
                    sharedViewModel.fetchAfterFirstFetch()
                    GallerySdkV2.get().startPlaceScanning(this)
                    sharedViewModel.checkMediaExist()

                }
            }

            AppblishEvent.ALL_MEDIA_LOADED -> {
                allMediaLayout.observableMedia()
            }

            AppblishEvent.ALL_ALBUM_LOADED -> {
                albumLayout.observableAlbum()
            }

            AppblishEvent.ALL_PLACES_LOADED -> {
                exploreLayout.observablePlaces()
            }

            AppblishEvent.ALL_MEMORIES_LOADED -> {
                forYouLayout.observableMemories()
            }

            AppblishEvent.ALL_STORIES_LOADED -> {
                forYouLayout.observableStories()
            }

            START_SCANNING -> {
                GallerySdkV2.get().startPlaceScanning(this)
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMemoryEvent(event: MemoryEvent) {
        when (event.type) {
            GO_TO_PHOTO -> {
                lifecycleScope.launch {
                    delay(300)
                    val mediaBox = event.data as MediaBox
                    updateNavUI(1)
                    delay(300)
                    allMediaLayout.findPhotoPosition(mediaBox.mediaPath)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (PermissionSDK.isReadMediaPermission(this)) {
            sharedViewModel.checkNewMedia()
        }
        forYouLayout.checkNotificationPermission()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterEventBus(this)
        unregisterContentObserver(this)
    }

    private var allMediaHideResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            hideAllMediaFromMedia()
        }
    }

    private var albumHideResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            hideMediaFromAlbum()
        }
    }

    @SuppressLint("InlinedApi")
    fun afterPermission() {
        sharedViewModel.fetchMedia()
        initView()
        if (!PermissionSDK.hasNotificationPermission(this)) {
            PermissionSDK.askNotificationPermission(this)
        }
    }

    lateinit var appUpdateManager: AppUpdateManager
    private var installStateUpdatedListener: InstallStateUpdatedListener? = null
    private fun checkUpdate() {
        lifecycleScope.launch {
            delay(500)
            checkForAppUpdate()
        }
    }

    private fun checkForAppUpdate() {
        appUpdateManager = AppUpdateManagerFactory.create(this)
        val appUpdateInfoTask = appUpdateManager.appUpdateInfo
        appUpdateInfoTask.addOnSuccessListener { appUpdateInfo ->
            Log.e("checkForAppUpdate", "checkForAppUpdate: " + "update")
            try {
                if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE) {
                    appUpdateManager.startUpdateFlowForResult(
                        appUpdateInfo, AppUpdateType.FLEXIBLE, this, 11100
                    )


                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        installStateUpdatedListener = InstallStateUpdatedListener { state ->
            if (state.installStatus() == InstallStatus.DOWNLOADED) {
                popupSnackbarForCompleteUpdate()
            }
        }
        appUpdateManager.registerListener(installStateUpdatedListener!!)
    }

    private fun popupSnackbarForCompleteUpdate() {
        Snackbar.make(
            binding.root, "An update has just been downloaded.", Snackbar.LENGTH_INDEFINITE
        ).apply {
            setAction("RESTART") {
                if (::appUpdateManager.isInitialized) {
                    appUpdateManager.completeUpdate()
                }
            }
            setActionTextColor(ContextCompat.getColor(this@MainActivity, R.color.color_primary))
            show()
        }
    }


    private fun setupAlbums() {
        albumLayout.setupViews()
    }

    fun updateAlbumFragmentSelection() {
        val enableSelection = albumLayout.isSelectionActive() ?: false
        binding.llCustomBottomNav.beVisibleIf(!enableSelection)
        binding.albumSelectionView.beVisibleIf(enableSelection)
        val folderList = albumLayout.getSelectedAlbums() ?: emptyList()
        val pinListHashSet = folderList.filter { it.isPinned }.map { it.bucketPath }
        val albumPathSet = folderList.map { it.bucketPath }.toHashSet()
        val remainToPin = albumPathSet.filter { it !in pinListHashSet }

        if (remainToPin.isNotEmpty() || albumPathSet.isEmpty()) {
            binding.tvTitleAlbumPin.text = getString(R.string.pin)
            binding.ivAlbumPin.setImageResource(R.drawable.vec_album_pin)
        } else {
            binding.tvTitleAlbumPin.text = getString(R.string.unpin)
            binding.ivAlbumPin.setImageResource(R.drawable.vec_album_unpin)
        }

        binding.clPin.setOnClickListener {
            if (folderList.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            if (remainToPin.isNotEmpty()) {
                sharedViewModel.addPinnedAlbum(remainToPin)
            } else {
                val removed = folderList.map { it.bucketPath }
                sharedViewModel.removePinnedAlbum(removed)
            }
            sharedViewModel.refreshMedia()
            albumLayout.disableSelection()
        }

        binding.clDelete.setOnClickListener {
            if (folderList.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            checkStoragePermission {
                if (it) {
                    val allMedias = folderList.flatMap { it.mediaList.map { it.mediaPath } }
                    deleteMedia(allMedias) {
                        albumLayout.disableSelection()
                    }
                }
            }

        }

        binding.clHide.setOnClickListener {
            if (folderList.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }

            checkStoragePermission {
                if (it) {
                    if (preferences.getSetPass()) {
                        hideMediaFromAlbum()
                    } else {
                        val intent = Intent(this, SetLockActivity::class.java)
                        intent.putExtra("setResultCode", 101)
                        albumHideResult.launch(intent)
                    }
                }
            }
        }

        binding.clMore.setOnClickListener {
            if (folderList.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            showAlbumDropDown(it, folderList)
        }
    }

    private fun hideMediaFromAlbum() {
        val dialog = ConfirmationDialog(
            this,
            ContextCompat.getString(this, R.string.hide),
            ContextCompat.getString(this, R.string.confirmation_hide_item),
            ContextCompat.getString(this, R.string.no),
            ContextCompat.getString(this, R.string.yes),
            ContextCompat.getColor(this, R.color.white_color)
        ) {
            val getListFromAlbum = albumLayout.getSelectedAlbums() ?: emptyList()
            val allMedias = getListFromAlbum.flatMap { it.mediaList.map { it.mediaPath } }
            hideMediaFolder(allMedias) {
                albumLayout.disableSelection()
            }
        }
        dialog.show(supportFragmentManager, "ConfirmationDialog")
    }


    private fun showAlbumDropDown(view: View, folderList: List<AlbumModel>) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopAlbumMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)
        val isAllCustom = folderList.all { it.isCustom }
        popUpBinding.menuRename.beVisibleIf(folderList.size == 1 && !isAllCustom)
        popUpBinding.menuSetAs.beGone()

        popUpBinding.root.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )

        val popupWidth = popUpBinding.root.measuredWidth
        val popupHeight = popUpBinding.root.measuredHeight
        val marginRight = 10.dpToPx(this)

        val location = IntArray(2)
        view.getLocationOnScreen(location)

        val screenWidth = resources.displayMetrics.widthPixels

        val x = screenWidth - popupWidth - marginRight

        val gap = 8.dpToPx(this)

        val y = location[1] - popupHeight - gap

        popupWindow.showAtLocation(
            view,
            Gravity.TOP or Gravity.START,
            x,
            y
        )

        popUpBinding.run {
            loutMain.setOnClickListener {
                popupWindow.dismiss()
                Log.e("btmSelectionView", "loutMain: ")
            }

            menuRename.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        val renameAlbumDialog = RenameAlbumDialog(this@MainActivity)
                        renameAlbumDialog.bucketPath = folderList.first().bucketPath
                        renameAlbumDialog.positiveBtnClickListener = { renamedFile, oldFile ->
                            albumLayout.disableSelection()
                            showLoadingDialog()
                            sharedViewModel.renameAlbum(oldFile.absolutePath, renamedFile.name) {
                                hideLoadingDialog()
                                if (it) {
                                    sharedViewModel.fetchMedia()
                                }
                            }
                        }
                        renameAlbumDialog.show(supportFragmentManager, "RenameAlbumDialog")
                    }
                }
            }

            menuInfo.setOnClickListener {
                popupWindow.dismiss()

                val mediaCount = folderList.flatMap { it.mediaList }.count()
                val mediaSize = folderList.flatMap { it.mediaList }.sumOf { it.mediaSize }
                AlbumDetailsDialog
                    .newInstance(
                        bucketPath = folderList.map { it.bucketPath },
                        mediaCount = mediaCount,
                        mediaTotalSize = mediaSize
                    )
                    .show(supportFragmentManager, "AlbumDetailsBottomSheet")
            }

            menuCopy.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        Log.e("StuckOnAlbum", "showAlbumDropDown: start")
                        requestAlbumPicker(emptyArray()) {
                            if (it.isNotEmpty()) {
                                albumLayout.disableSelection()
                                copyFolderFiles(folderList.flatMap { it.mediaList.map { it.mediaPath } }, it)
                            }
                        }
                    }
                }
            }

            menuMove.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        requestAlbumPicker(folderList.map { it.bucketPath }.toTypedArray()) {
                            if (it.isNotEmpty()) {
                                albumLayout.disableSelection()
                                moveFolderFiles(folderList.flatMap { it.mediaList.map { it.mediaPath } }, it)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun setupAllMedias() {
        allMediaLayout.setupViews()
    }

    fun updatePhotoFragmentSelection() {
        val enableSelection = allMediaLayout.isSelectionActive()
        binding.llCustomBottomNav.beVisibleIf(!enableSelection)
        binding.clMediaSelectionView.beVisibleIf(enableSelection)
        val mediaListItemMedia = allMediaLayout.getSelectedMedias()

        binding.clShareMedia.setOnClickListener {
            if (mediaListItemMedia.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            shareImages()
            allMediaLayout.disableSelection()
        }

        binding.clDeleteMedia.setOnClickListener {
            if (mediaListItemMedia.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            checkStoragePermission {
                if (it) {
                    val mediaPathList = mediaListItemMedia.map { it.mediaPath }
                    deleteMedia(mediaPathList) {
                        allMediaLayout.disableSelection()
                    }
                }
            }
        }

        binding.clHideMedia.setOnClickListener {
            if (mediaListItemMedia.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }

            checkStoragePermission {
                if (it) {
                    if (preferences.getSetPass()) {
                        hideAllMediaFromMedia()
                    } else {
                        val intent = Intent(this, SetLockActivity::class.java)
                        intent.putExtra("setResultCode", 101)
                        allMediaHideResult.launch(intent)
                    }
                }
            }
        }

        binding.clMoreMedia.setOnClickListener {
            if (mediaListItemMedia.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            showPhotoDropDown(it, mediaListItemMedia)
        }
    }

    fun shareImages() {
        val shareItems = allMediaLayout.getSelectedMedias() ?: emptyList()
        if (shareItems.size > 200) {
            toast(getString(R.string.select_up_to_200_items))
        }
        val uris = ArrayList<Uri?>()
        uris.addAll(shareItems.map {
            it.mediaUri.toUri()
        })
        shareFilesList(this, uris.filterNotNull())
    }

    private fun showPhotoDropDown(view: View, mediaBoxes: List<MediaModel>) {


        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)

        val isAllFav = mediaBoxes.all { it.isFavourite }
        val isSingleSelection = mediaBoxes.count() == 1

        val isVideo = mediaBoxes.any { it.isVideo }
        val isGif = mediaBoxes.any { it.isGif }

        popUpBinding.menuAddFavourite.beVisibleIf(!isAllFav)
        popUpBinding.menuRemoveFavourite.beVisibleIf(isAllFav)

        popUpBinding.menuSetAs.beVisibleIf(isSingleSelection && !isVideo && !isGif)
        popUpBinding.menuEdit.beVisibleIf(isSingleSelection && !isVideo && !isGif)
        popUpBinding.menuResize.beVisibleIf(isSingleSelection && !isVideo && !isGif)
        popUpBinding.menuRename.beVisibleIf(isSingleSelection && !isVideo && !isGif)


        popUpBinding.root.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )

        val popupWidth = popUpBinding.root.measuredWidth
        val popupHeight = popUpBinding.root.measuredHeight
        val marginRight = 10.dpToPx(this)

        val location = IntArray(2)
        view.getLocationOnScreen(location)

        val screenWidth = resources.displayMetrics.widthPixels

        val x = screenWidth - popupWidth - marginRight

        val gap = 8.dpToPx(this)

        val y = location[1] - popupHeight - gap

        popupWindow.showAtLocation(
            view,
            Gravity.TOP or Gravity.START,
            x,
            y
        )

//        popupWindow.showAsPopUp(view, yoff = -20, xoff = 20)
        popUpBinding.run {
            loutMain.setOnClickListener {
                popupWindow.dismiss()
            }
            popUpBinding.menuRename.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        val renameFileDialog = RenamePhotosDialog(this@MainActivity)
                        renameFileDialog.filePath = mediaBoxes.first().mediaPath
                        renameFileDialog.positiveBtnClickListener = { renamedFile, oldFile ->
                            allMediaLayout.disableSelection()
                            showLoadingDialog()
                            sharedViewModel.renameMedia(oldFile.absolutePath, renamedFile.name) {
                                hideLoadingDialog()
                                if (it) {
                                    sharedViewModel.fetchMedia()
                                }
                            }
                        }
                        renameFileDialog.show(supportFragmentManager, "RenamePhotosDialog")
                    }
                }
            }
            popUpBinding.menuResize.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        val mediaPath = mediaBoxes.first().mediaPath
                        val renameFileDialog = ResizeDialog(this@MainActivity, mediaPath) { w, h, name, keepOriginal ->
                            allMediaLayout.disableSelection()
                            showLoadingDialog()
                            sharedViewModel.resizeMedia(mediaPath, w, h, name, keepOriginal) { b, path ->
                                hideLoadingDialog()
                                if (b) {
                                    sharedViewModel.fetchMedia()
                                }
                            }
                        }

                        renameFileDialog.show(supportFragmentManager, "ResizeDialog")
                    }
                }
            }
            menuAddFavourite.setOnClickListener {
                popupWindow.dismiss()
                sharedViewModel.addToFav(mediaBoxes.map { it.mediaPath })
                allMediaLayout.disableSelection()
            }

            menuRemoveFavourite.setOnClickListener {
                popupWindow.dismiss()
                sharedViewModel.removeToFav(mediaBoxes.map { it.mediaPath })
                allMediaLayout.disableSelection()
            }

            menuEdit.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        val mediaPath = mediaBoxes.first().mediaPath
                        allMediaLayout.disableSelection()
                        editPhoto(mediaPath)
                    }
                }
            }

            menuSetAs.setOnClickListener {
                popupWindow.dismiss()
                val filePath = mediaBoxes.map { it.mediaPath }
                setAs(filePath.single())
            }


            menuInfo.setOnClickListener {
                popupWindow.dismiss()
                PhotosDetailsDialog(mediaBoxes.map { it.mediaPath }).show(supportFragmentManager, "PhotosDetailsDialog")
            }

            menuCopy.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        requestAlbumPicker(emptyArray()) {
                            if (it.isNotEmpty()) {
                                allMediaLayout.disableSelection()
                                copyFolderFiles(mediaBoxes.map { it.mediaPath }, it)
                            }
                        }
                    }
                }

            }

            menuMove.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        requestAlbumPicker(emptyArray()) {
                            if (it.isNotEmpty()) {
                                allMediaLayout.disableSelection()
                                moveFolderFiles(mediaBoxes.map { it.mediaPath }, it)
                            }
                        }
                    }
                }

            }
        }

    }

    private fun hideAllMediaFromMedia() {
        val dialog = ConfirmationDialog(
            this,
            ContextCompat.getString(this, R.string.hide),
            ContextCompat.getString(this, R.string.confirmation_hide_item),
            ContextCompat.getString(this, R.string.no),
            ContextCompat.getString(this, R.string.yes),
            ContextCompat.getColor(this, R.color.white_color)
        ) {
            val getListFromAllMedia = allMediaLayout.getSelectedMedias() ?: emptyList()
            val mediaPathList = getListFromAllMedia.map { it.mediaPath }
            hideMediaFolder(mediaPathList) {
                allMediaLayout.disableSelection()
            }
        }
        dialog.show(supportFragmentManager, "ConfirmationDialog")
    }

    private fun setupForYou() {
        forYouLayout.setupViews()
    }

    private fun setupExplore() {
        exploreLayout.setupViews()
    }
    private fun updateToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) {
                return@OnCompleteListener
            }

            val token = task.result
            Log.e("TAG", "uploadToken: $token")
        })
    }

    private fun handleIntent(intent: Intent) {
        if (intent.hasExtra("screen")) {
            val screen = intent.getStringExtra("screen")
            if (screen.equals("map")) {
                val list = exploreLayout.getPlacesList() ?: emptyList()
                if (list.isNotEmpty()) {
                    val intent = Intent(this, PlacesActivity::class.java)
                    intent.putExtra("ARG_POSITION", true)
                    startActivity(intent)
                } else {
                    lifecycleScope.launch {
                        delay(500)
                        updateNavUI(3)
                    }
                }

            } else if (screen.equals("language")) {
                startActivity(
                    Intent(this@MainActivity, NewLanguageSelectActivity::class.java)
                        .putExtra("isFromSettingToOpen", true)
                )
            } else if (screen.equals("cleaner")) {
                startActivity(Intent(this, CleanerScanActivity::class.java))
            } else if (screen.equals("setting")) {
                startActivity(Intent(this, SettingActivity::class.java))
            } /*else if (screen.equals("categories")) {
                val list = newMediaRepository.getMomentAlbumList()
                if (list.isNotEmpty()) {
                    startActivity(Intent(this, MomentActivity::class.java))
                }
            }*/ else if (screen.equals("memoryTab")) {
                lifecycleScope.launch {
                    delay(500)
                    updateNavUI(2)
                }
            }
        }

    }

    lateinit var appRedirectDialog: Dialog

    private fun showRedirectDialog(
        config: AppRedirectConfig,
        key: String,
        model: RedirectItem,
    ) {
        if (isAppInstalled(this, config.package_name)) {
            val json = application.clientConfigPref.appRedirectConfig
            val config = Gson().fromJson(json, AppRedirectConfig::class.java)

            val installedModel = config.dialogs["installed_redirect"] ?: return

            Log.d("APP", "App is installed --> " + installedModel.title)

            if (model.isNeedToShow) {
                appRedirectDialog =
                    RedirectCommonDialog(this, installedModel, "installed", config.package_name)
                appRedirectDialog.setCancelable(installedModel.isCancelable)
                appRedirectDialog.setCanceledOnTouchOutside(installedModel.isCancelable)
                appRedirectDialog.setOnDismissListener {}
                appRedirectDialog.show()
            }

        } else {
            when (key) {
                "optional_redirect" -> {
                    if (model.isNeedToShow) {
                        appRedirectDialog =
                            RedirectDialog(this, model, config.package_name, config.app_icon)
                        appRedirectDialog.setCancelable(model.isCancelable)
                        appRedirectDialog.setCanceledOnTouchOutside(model.isCancelable)
                        appRedirectDialog.setOnDismissListener {}
                        appRedirectDialog.show()
                    }
                }

                "important_redirect" -> {
                    if (model.isNeedToShow) {
                        appRedirectDialog =
                            RedirectCommonDialog(this, model, "important", config.package_name)
                        appRedirectDialog.setCancelable(model.isCancelable)
                        appRedirectDialog.setCanceledOnTouchOutside(model.isCancelable)
                        appRedirectDialog.setOnDismissListener {}
                        appRedirectDialog.show()
                    }
                }

                "mandatory_redirect" -> {


                    if (model.isNeedToShow) {
                        appRedirectDialog =
                            RedirectCommonDialog(this, model, "mandatory", config.package_name)
                        appRedirectDialog.setCancelable(model.isCancelable)
                        appRedirectDialog.setCanceledOnTouchOutside(model.isCancelable)
                        appRedirectDialog.setOnDismissListener {}
                        appRedirectDialog.show()
                    }
                }

            }
        }
    }
}