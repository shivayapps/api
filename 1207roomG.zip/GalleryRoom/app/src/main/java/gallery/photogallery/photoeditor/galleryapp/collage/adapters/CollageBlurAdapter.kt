package gallery.photogallery.photoeditor.galleryapp.collage.adapters

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemBackgroundBinding

class CollageBlurAdapter(
    private val context: Context,
    var stringList: ArrayList<Drawable> = ArrayList(),  // Pass string list here
    private val onBackgroundSelected: (position: Int, path: Drawable?) -> Unit // send path instead of SquareView
) : RecyclerView.Adapter<CollageBlurAdapter.ViewHolder>() {

    var selectedIndexCheck = RecyclerView.NO_POSITION

    /* ---------- ADAPTER ---------- */

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemBackgroundBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(stringList[position], position)
    }

    override fun getItemCount(): Int = stringList.size

    /* ---------- VIEW HOLDER ---------- */

    inner class ViewHolder(
        private val binding: ItemBackgroundBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.imageViewSquare.visibility = View.GONE
        }

        fun bind(item: Drawable, position: Int) {
            with(binding) {

                    squareView.visibility = View.GONE
                    imageViewSquare.visibility = View.VISIBLE


                Glide.with(context).load(item).into(imageViewSquare)


                viewSelected.visibility =
                    if (position == selectedIndexCheck) View.VISIBLE else View.GONE

                root.setOnClickListener {
                    val pos = adapterPosition
                    if (pos == RecyclerView.NO_POSITION) return@setOnClickListener

                    selectedIndexCheck = pos
                    onBackgroundSelected(pos, stringList[pos]) // send path
                    notifyDataSetChanged()
                }
            }
        }
    }

    fun setSelectedIndex(index: Int) {
        selectedIndexCheck = index
        notifyDataSetChanged()
    }
}
