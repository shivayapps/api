package gallery.photogallery.photoeditor.galleryapp.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.appblish.box.api.model.MediaBox
import com.appblish.story.memories.api.core.MemorySDK
import com.appblish.story.memories.api.model.MemoryBox
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.adaptor.MemoryCoverPickerAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivitySelectAlbumBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isDarkMode
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory.MemoryViewerActivity
import kotlinx.coroutines.launch

class SelectMemoryCoverActivity : BaseActivity(), View.OnClickListener {

    private val binding by viewBinding(ActivitySelectAlbumBinding::inflate)

    var memoryListItem: MemoryBox? = null
    val memoryId by lazy { intent.getLongExtra("memoryId", 0) }
    private val imagePickerAdapter by lazy { MemoryCoverPickerAdapter() }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        enableEdgeToEdge()
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = !isDarkMode()
        controller.isAppearanceLightNavigationBars = !isDarkMode()
        window?.navigationBarColor = ContextCompat.getColor(this, R.color.app_background)
        binding.root.setPadding(0, statusBarHeight, 0, navigationBarHeight)
        binding.ivNew.beGone()
        binding.btnDone.beGone()
        initClick()
        observableMedia()
    }


    private fun initClick() {
        binding.ivBack.setOnClickListener(this)
        binding.btnDone.setOnClickListener(this)

    }

    override fun onClick(view: View?) {
        when (view) {
            binding.ivBack -> {
                finish()
            }
        }
    }

    private fun observableMedia() {
        lifecycleScope.launch {
            MemorySDK.get().getMemoryBox(memoryId) {
                memoryListItem = it
                setMedia(memoryListItem!!.mediaList)
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun setMedia(mediaList: List<MediaBox>) {
        lifecycleScope.launch {
            Log.e("TAG", "mediaList: ${mediaList.size}")
            if (binding.mediaRecycler.adapter == null) {
                binding.mediaRecycler.adapter = imagePickerAdapter
                binding.mediaRecycler.layoutManager = GridLayoutManager(this@SelectMemoryCoverActivity, 3)
                val coverImage = memoryListItem!!.coverImage
                imagePickerAdapter.selectedItems.add(mediaList.find { it.mediaPath == coverImage }!!)
                imagePickerAdapter.onSelectionUpdate = {
                    val firstMedia = imagePickerAdapter.selectedItems.first()
                    sharedViewModel.updateMemoryColor(memoryListItem!!.memoryId, firstMedia)
                    if (intent.hasExtra("fromViewer")) {
                        MemorySDK.get().getMemoryBox(memoryId) {
                            setResult(RESULT_OK)
                            Intent(this@SelectMemoryCoverActivity, MemoryViewerActivity::class.java).apply {
                                putExtra("memoryId", memoryListItem!!.memoryId)
                                startActivity(this)
                            }
                            finish()
                        }
                    } else {
                        finish()
                    }
                }
            }
            imagePickerAdapter.submitList(mediaList)
        }
    }


}