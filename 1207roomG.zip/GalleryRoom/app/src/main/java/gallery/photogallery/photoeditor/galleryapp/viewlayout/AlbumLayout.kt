package gallery.photogallery.photoeditor.galleryapp.viewlayout

import android.annotation.SuppressLint
import android.content.Intent
import android.util.Log
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.MainMediaFilter
import com.appblish.box.api.model.ScrollGate
import com.appblish.box.api.util.MediaDataState
import com.appblish.gallery.core.v2.api.core.GallerySdkV2
import com.appblish.gallery.core.v2.api.model.AlbumListItem
import com.appblish.gallery.core.v2.api.model.AlbumModel
import com.appblish.medialoader.AppblishImageLoader.setupGlidePreLoader
import com.appblish.medialoader.PreloadItem
import gallery.photogallery.photoeditor.galleryapp.permission.PermissionSDK
import com.appblish.recyclerview.dragselection.SelectionUpdateCallback
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.AllVideosActivity
import gallery.photogallery.photoeditor.galleryapp.activities.ExplorePhotosActivity
import gallery.photogallery.photoeditor.galleryapp.activities.MainActivity
import gallery.photogallery.photoeditor.galleryapp.adaptor.AlbumListAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.FragmentAlbumBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.restart
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.popup_menu.AlbumMenuPopup
import gallery.photogallery.photoeditor.galleryapp.utils.spancounthelper.ScaleHintListener
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AlbumLayout(private val mainActivity: MainActivity, private val binding: FragmentAlbumBinding) {
    private val lifecycleScope = mainActivity.lifecycleScope
    private val sharedViewModel = mainActivity.sharedViewModel
    private fun getString(resId: Int) = mainActivity.getString(resId)

    fun setupViews() {
        init()
        setListeners()
    }

    private fun init() {
        binding.rvAlbum.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                val first = if (recyclerView.layoutManager is GridLayoutManager) {
                    val layoutManager = recyclerView.layoutManager as GridLayoutManager
                    layoutManager.findFirstCompletelyVisibleItemPosition()
                } else {
                    val layoutManager = recyclerView.layoutManager as LinearLayoutManager
                    layoutManager.findFirstCompletelyVisibleItemPosition()
                }
                if (first <= 1) {
                    binding.ivScrollTop.beGone()
                } else {
                    if (first >= 8) {
                        binding.ivScrollTop.beVisible()
                    }
                }
            }

            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING ||
                    newState == RecyclerView.SCROLL_STATE_SETTLING
                ) {
                    ScrollGate.onScrollStart()
                } else {
                    ScrollGate.onScrollStop()
                }
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    lifecycleScope.launch {
                        delay(600)
                        binding.ivScrollTop.beGone()
                    }
                }
            }
        })
        binding.incPermission.tvAllow.setOnClickListener {
            mainActivity.requestManageAllFile {
                mainActivity.startActivity(Intent(mainActivity, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                })
            }
        }
        initSpanCountHelper()
        observableAlbum()
    }

    fun resetAlbum() {
        getAlbumAdaptor()?.fastScroller?.let {
            binding.rvAlbum.removeOnItemTouchListener(it)
        }
        binding.rvAlbum.adapter = null
        initSpanCountHelper()
        observableAlbum()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initSpanCountHelper() {
        if (mainActivity.appPref.albumAsGrid) {
            val layoutManager = GridLayoutManager(mainActivity, mainActivity.appPref.albumGrid)
            binding.rvAlbum.layoutManager = layoutManager
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    return if (getAlbumAdaptor()?.getItem(position) is AlbumListItem.Header) {
                        mainActivity.appPref.albumGrid
                    } else {
                        1
                    }
                }
            }

            val listener = ScaleHintListener(
                context = mainActivity,
                recyclerView = binding.rvAlbum,
                layoutManager = layoutManager,
                ghostCardView = binding.ghostCardView,
                ghostImageView = binding.ghostImageView,
                gridHelperView = binding.gridHelperView,
                spanHintText = binding.spanHintText,
                landingCircle = binding.landingCircle,
                overlayContainer = binding.overlayContainer,
                imageViewExtractor = { itemView ->
                    itemView.findViewById(R.id.imageAlbum)
                },
                onUpdateSpan = { span ->
                    mainActivity.appPref.albumGrid = span
                },
                dimLayer = binding.dimLayer,
                minSpan = 2,
                maxSpan = 6
            )
            Log.e("ScaleHintListener", "ScaleHintListener")

            binding.rvAlbum.setOnTouchListener(listener)
            binding.rvAlbum.scheduleLayoutAnimation()
        } else {
            Log.e("ScaleHintListener", "ScaleHintListener null")
            val layoutManager = LinearLayoutManager(mainActivity)
            binding.rvAlbum.setOnTouchListener(null)
            binding.rvAlbum.layoutManager = layoutManager
            binding.rvAlbum.scheduleLayoutAnimation()
        }

    }


    fun observableAlbum() {
        setAlbumList(GallerySdkV2.get().getAllAlbumList())
    }

    private fun setAlbumList(state: MediaDataState<List<AlbumListItem>>) {
        when (sharedViewModel.getMainMediaFilter()) {
            MainMediaFilter.ALL -> binding.tvAlbumAll2.text = getString(R.string.all)
            MainMediaFilter.PHOTOS -> binding.tvAlbumAll2.text = getString(R.string.photos)
            MainMediaFilter.VIDEO -> binding.tvAlbumAll2.text = getString(R.string.videos)
            MainMediaFilter.GIF -> binding.tvAlbumAll2.text = getString(R.string.gifs)
        }
        binding.llLimitedAccess.beVisibleIf(PermissionSDK.hasLimitedPhotoAccess(mainActivity))
        when (state) {
            MediaDataState.Empty -> {
                binding.loutNoData.beVisible()
                binding.rlData.beVisible()
                binding.rlMediaData.beGone()
                binding.llLoader.beGone()
                setAlbums(emptyList())
            }

            MediaDataState.Loading -> {
                binding.rlData.beGone()
                binding.llLoader.beVisible()
                binding.lavLoader.restart()
                setAlbums(emptyList())
            }

            is MediaDataState.Success -> {
                binding.rlData.beVisible()
                binding.rlMediaData.beVisible()
                binding.llLoader.beGone()
                binding.loutNoData.beGone()
                binding.lavLoader.cancelAnimation()
                setAlbums(state.data)
            }

            is MediaDataState.Progress -> {

            }
        }
    }

    private fun setListeners() {
        binding.ivClose.setOnClickListener {
            val albumAdaptor = getAlbumAdaptor() ?: return@setOnClickListener
            if (albumAdaptor.isSelectionActive()) {
                disableSelection()
            }
        }

        binding.ivDropDown.setOnClickListener {
            mainActivity.showHomeMenuFilter(binding.tvAlbumAll2)
        }

        binding.ivAlbumSearch.setOnClickListener {
            mainActivity.onSearchClick()
        }

        binding.ivAlbumCamera.setOnClickListener {
            mainActivity.openCamera()
        }

        binding.flAlbumMore.setOnClickListener {
            AlbumMenuPopup(mainActivity).show(it)

        }

        binding.ivScrollTop.setOnClickListener {
            scrollToTop()
        }

        binding.icSelectAll.setOnClickListener {
            val albumAdaptor = getAlbumAdaptor() ?: return@setOnClickListener
            if (albumAdaptor.isSelectAll()) {
                albumAdaptor.unSelectAll()
            } else {
                albumAdaptor.selectAll()
            }
        }
    }

    private fun scrollToTop() {
        binding.rvAlbum.post {
            binding.rvAlbum.scrollToPosition(0)
        }

    }

    private fun initAdaptor() {
        if (binding.rvAlbum.adapter == null) {
            binding.rvAlbum.recycledViewPool.clear()
            val albumAdaptor = AlbumListAdapter(binding.rvAlbum) {
                onAlbumSelect(it)
            }
            binding.rvAlbum.adapter = albumAdaptor

            albumAdaptor.setSelectionUpdateCallback(
                object : SelectionUpdateCallback {
                    override fun onSelectionCountChanged(
                        selectedCount: Int,
                        selectionActive: Boolean
                    ) {
                        updateSelections()
                    }
                }
            )
        }
    }

    private fun setAlbums(albums: List<AlbumListItem>) {
        lifecycleScope.launch {
            binding.rvAlbum.recycledViewPool.clear()
            Log.e("TAG", "setAlbums: ${albums.size}")
            initAdaptor()
            binding.rvAlbum.post {
                getAlbumAdaptor()?.submitList(albums)
            }
            val list = albums.mapNotNull {
                if (it is AlbumListItem.Album) {
                    PreloadItem.Media(it.mediaPath, it.mediaDate)
                } else null
            }
            binding.rvAlbum.setupGlidePreLoader(mainActivity, list, false)
        }
    }

    private fun getAlbumAdaptor() = binding.rvAlbum.adapter as? AlbumListAdapter


    fun disableSelection() {
        val albumAdaptor = getAlbumAdaptor() ?: return
        albumAdaptor.clearSelectionAndExit()
        updateSelections()
    }

    @SuppressLint("SetTextI18n")
    fun updateSelections() {
        val albumAdaptor = getAlbumAdaptor() ?: return
        val enableSelection = getAlbumAdaptor()?.isSelectionActive() ?: false
        binding.clSelection.beVisibleIf(enableSelection)
        binding.albumToolbar.beVisibleIf(!enableSelection)
        binding.tvTitleSelection.text = "${albumAdaptor.getSelectedCount()} " + getString(R.string.selected)
        if (albumAdaptor.isSelectAll()) {
            binding.icSelectAll.setImageResource(R.drawable.vec_selected_bg)
        } else {
            binding.icSelectAll.setImageResource(R.drawable.vec_unselected_bg)
        }
        mainActivity.updateAlbumFragmentSelection()
    }


    fun onAlbumSelect(albumModel: AlbumModel) {
        if (albumModel.bucketPath == "all_videos") {
            val intent = Intent(mainActivity, AllVideosActivity::class.java)
            intent.putExtra("BUCKET_PATH", albumModel.bucketPath)
            intent.putExtra("BUCKET_SIZE", albumModel.mediaList.size)
            mainActivity.startActivity(intent)
        } else {
            val intent = Intent(mainActivity, ExplorePhotosActivity::class.java)
            intent.putExtra("BUCKET_PATH", albumModel.bucketPath)
            intent.putExtra("BUCKET_SIZE", albumModel.mediaList.size)
            mainActivity.startActivity(intent)
        }

    }

    fun getSelectedAlbums() = getAlbumAdaptor()?.getSelectedItems()?.filterIsInstance<AlbumListItem.Album>()?.map { it.albumBox }
    fun isSelectionActive() = getAlbumAdaptor()?.isSelectionActive() ?: false
}