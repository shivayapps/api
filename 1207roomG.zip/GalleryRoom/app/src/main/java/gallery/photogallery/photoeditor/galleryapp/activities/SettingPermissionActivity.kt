package gallery.photogallery.photoeditor.galleryapp.activities

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight

class SettingPermissionActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setFinishOnTouchOutside(true)
        setContentView(R.layout.activity_setting_permission)
        findViewById<View>(R.id.flMain).setOnClickListener { finish() }
        findViewById<View>(R.id.lout_bottom).setPadding(
            0, 0, 0, findViewById<View>(R.id.lout_bottom).paddingBottom + navigationBarHeight
        )
        Handler(Looper.myLooper()!!).postDelayed({
            finish()
        }, 1500)
    }
}