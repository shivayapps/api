package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.BottomSheetNoFingerprintBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction

class NoFingerprintDialog : DialogFragment() {
    private var _binding: BottomSheetNoFingerprintBinding? = null

    private val binding get() = _binding!!
    private lateinit var safeContext: Context

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = BottomSheetNoFingerprintBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER) // remove if you want center dialog
        }
        clickListener()
        return dialog
    }

    private fun clickListener() {
        binding.btnCancel.setOnClickListener {
            dismiss()
        }

        binding.btnOpenSettings.setOnClickListener {
            dismiss()
            startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
        }
    }
}