package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation

import android.view.View
import androidx.viewpager2.widget.ViewPager2

import kotlin.math.abs


class ZoomIn : ViewPager2.PageTransformer {

    override fun transformPage(view: View, positon: Float) {
        val scale: Float = if (positon < 0) positon + 1f else abs(1f - positon)
        view.scaleX = scale
        view.scaleY = scale
        view.pivotX = view.width * 0.5f
        view.pivotY = view.height * 0.5f
        view.alpha = if (positon < -1f || positon > 1f) 0f else 1f - (scale - 1f)
    }

}