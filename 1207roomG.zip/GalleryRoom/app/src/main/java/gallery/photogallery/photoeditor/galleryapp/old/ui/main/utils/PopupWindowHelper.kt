package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils

import android.content.res.Resources
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.PopupWindow
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.newNavigationBarHeight
import kotlin.math.roundToInt

class PopupWindowHelper(private val popupView: View, val isHideNavigation: Boolean = false) {
    private var mPopupWindow: PopupWindow? = null

    fun showAsDropDown(anchor: View?) {
        mPopupWindow!!.showAsDropDown(anchor)
    }

    fun update() {
//        initPopupWindow(TYPE_MATCH_PARENT);
        mPopupWindow!!.update()
    }

    fun showAsDropDown(anchor: View?, xoff: Int, yoff: Int) {
        initPopupWindow(TYPE_MATCH_PARENT)
        mPopupWindow!!.showAsDropDown(anchor, xoff, yoff)
    }

    fun showAtLocation(parent: View?, gravity: Int, x: Int, y: Int) {
        initPopupWindow(TYPE_WRAP_CONTENT)
        mPopupWindow!!.showAtLocation(parent, gravity, x, y)
    }

    fun dismiss() {
        if (mPopupWindow!!.isShowing) {
            mPopupWindow!!.dismiss()
        }
    }

    @JvmOverloads
    fun showAsPopUp(anchor: View, xoff: Int = 0, yoff: Int = 0, mGravity: Int? = Gravity.TOP) {
        initPopupWindow(TYPE_WRAP_CONTENT)
        popupView.measure(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val height = popupView.measuredHeight
        val location = IntArray(2)
        anchor.getLocationInWindow(location)

        val gravity = mGravity ?: Gravity.TOP
        mPopupWindow!!.showAtLocation(
            anchor,
            gravity,
            location[0] + xoff,
            location[1] - height + yoff
        )
    }

    @JvmOverloads
    fun showAsPopUp2(anchor: View, xoff: Int = 0, yoff: Int = 0, mGravity: Int? = Gravity.TOP) {
        initPopupWindow(TYPE_WRAP_CONTENT)
        popupView.measure(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val height = popupView.measuredHeight
        val location = IntArray(2)
        anchor.getLocationInWindow(location)

        val gravity = mGravity ?: Gravity.TOP
        mPopupWindow!!.showAtLocation(
            anchor,
            gravity,
            location[0] + xoff,
            location[1] - height + anchor.context.newNavigationBarHeight + yoff
        )
    }


    fun showFromBottom(anchor: View?) {
        initPopupWindow(TYPE_MATCH_PARENT)
        mPopupWindow!!.animationStyle = R.style.AnimationFromButtom
        mPopupWindow!!.showAtLocation(anchor, Gravity.LEFT or Gravity.BOTTOM, 0, 0)
    }

    fun showFromTop(anchor: View?) {
        initPopupWindow(TYPE_MATCH_PARENT)
        mPopupWindow!!.animationStyle = R.style.AnimationFromTop
        mPopupWindow!!.showAtLocation(anchor, Gravity.LEFT or Gravity.TOP, 0, statusBarHeight)
    }

    /**
     * touch outside dismiss the popupwindow, default is ture
     *
     * @param isCancelable
     */
    fun setCancelable(isCancelable: Boolean) {
        if (isCancelable) {
            mPopupWindow!!.isOutsideTouchable = true
            mPopupWindow!!.isFocusable = true
        } else {
            mPopupWindow!!.isOutsideTouchable = false
            mPopupWindow!!.isFocusable = false
        }
    }

    fun initPopupWindow(type: Int) {
        if (type == TYPE_WRAP_CONTENT) {
            mPopupWindow = PopupWindow(
                popupView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        } else if (type == TYPE_MATCH_PARENT) {
            mPopupWindow = PopupWindow(
                popupView,
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        mPopupWindow!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        mPopupWindow!!.animationStyle = R.style.FadePopupAnimation
        if (isHideNavigation) {
            if (isAboveAndroid11()) {
                mPopupWindow!!.contentView.systemUiVisibility = (
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        )
            }
        }

        setCancelable(true)
    }

    private val statusBarHeight: Int
        get() = (25 * Resources.getSystem().displayMetrics.density).roundToInt()

    companion object {
        private const val TYPE_WRAP_CONTENT = 0
        private const val TYPE_MATCH_PARENT = 1
    }
}
