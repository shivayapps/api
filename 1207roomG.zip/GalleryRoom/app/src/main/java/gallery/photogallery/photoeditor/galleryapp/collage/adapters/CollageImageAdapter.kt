package gallery.photogallery.photoeditor.galleryapp.collage.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.appblish.gallery.core.v2.api.model.MediaModel
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemImageBinding


class CollageImageAdapter(
    private val checkRelace: Boolean,
    private val selectedMap: LinkedHashMap<Long, Int>,
    private val onAdd: (MediaModel) -> Unit,
    private val onPreview: (pos : Int) -> Unit,
    private val onRemove: (MediaModel) -> Unit
) : RecyclerView.Adapter<CollageImageAdapter.VH>() {

    private val list = mutableListOf<MediaModel>()

    fun submit(data: List<MediaModel>) {
        list.clear()
        list.addAll(data)
        notifyDataSetChanged()
    }

    class VH(val binding: ItemImageBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemImageBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return VH(binding)
    }


    override fun onBindViewHolder(holder: VH, position: Int) {
        val media = list[position]
        val entity = media.mediaBox
        val mediaId = entity.mediaId

        with(holder.binding) {


            if (checkRelace){
                ivPreview.visibility=View.GONE
            }else{
                ivPreview.visibility=View.VISIBLE
            }
            Glide.with(ivImage.context)
                .load(entity.mediaPath)
                .centerCrop()
                .into(ivImage)

            val countValue = selectedMap[mediaId] ?: 0

            if (countValue > 0) {
                tvCount.text = countValue.toString()
                tvCount.visibility = View.VISIBLE

                ivRemove.setImageDrawable(
                    ContextCompat.getDrawable(root.context, R.drawable.ic_toggle_remove)
                )
                ivImageSelect.visibility = View.VISIBLE
            } else {
                tvCount.visibility = View.GONE

                ivRemove.setImageDrawable(
                    ContextCompat.getDrawable(root.context, R.drawable.ic_check_off)
                )
                ivImageSelect.visibility = View.GONE
            }

            // Add / toggle
            ivImage.setOnClickListener {
                onAdd(media)
            }

            ivPreview.setOnClickListener { onPreview(position) }
            // Remove
            ivRemove.setOnClickListener {
                onRemove(media)
            }
        }
    }

    override fun getItemCount(): Int = list.size
}
