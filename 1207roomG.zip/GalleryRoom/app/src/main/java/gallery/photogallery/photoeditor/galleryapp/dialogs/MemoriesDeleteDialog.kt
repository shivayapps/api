package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogDeleteMemoryBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction

class MemoriesDeleteDialog : DialogFragment() {
    private var _binding: DialogDeleteMemoryBinding? = null
    private val binding get() = _binding!!
    private lateinit var safeContext: Context
    var hideRecycle: Boolean = false
    var btnClickListener: (() -> Unit)? = null
    var btnCancelListener: (() -> Unit)? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    companion object {
        fun newInstance(btnClickListener: (() -> Unit)?, btnCancelListener: (() -> Unit)?, hideRecycle: Boolean = false): MemoriesDeleteDialog {
            val deleteDialog = MemoriesDeleteDialog()
            deleteDialog.btnClickListener = btnClickListener
            deleteDialog.btnCancelListener = btnCancelListener
            deleteDialog.hideRecycle = hideRecycle
            return deleteDialog
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogDeleteMemoryBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        clickListener()
        return dialog
    }
    private fun clickListener() {
        binding.txtRestoredMsg.visibility = View.GONE
        if (hideRecycle) binding.btnDelete.visibility = View.GONE

        binding.btnCancel.setOnClickListener { dismiss() }
        binding.btnDelete.setOnClickListener {
            dismiss()
            btnClickListener?.invoke()

        }
        binding.btnPermanent.setOnClickListener {
            dismiss()
            btnCancelListener?.invoke()
        }
        dialog?.setOnCancelListener {
            btnCancelListener?.invoke()
        }
    }
}