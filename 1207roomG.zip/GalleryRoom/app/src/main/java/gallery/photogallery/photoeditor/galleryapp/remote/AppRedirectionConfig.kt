package gallery.photogallery.photoeditor.galleryapp.remote

import android.app.Application
import android.util.Log
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.gson.Gson
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.clientConfigPref

object AppRedirectionConfig {

    fun getAppRedirectionConfig(myApp: Application, remoteConfig: FirebaseRemoteConfig) {
        try {
            remoteConfig.fetchAndActivate().addOnCompleteListener { task ->
                if (!task.isSuccessful) return@addOnCompleteListener

                val json = remoteConfig.getString("app_redirect_config")
                if (json.isEmpty()) return@addOnCompleteListener
                myApp.clientConfigPref.appRedirectConfig = json
            }
        } catch (e: Exception) {
            e.printStackTrace()
            myApp.clientConfigPref.appRedirectConfig = ""
        }
    }

    fun handleRedirectFromCache(
        myApp: Application,
        callBack: (config: AppRedirectConfig, dialogKey: String, dialog: RedirectItem) -> Unit
    ) {
        val json = myApp.clientConfigPref.appRedirectConfig ?: return

        try {
            val config = Gson().fromJson(json, AppRedirectConfig::class.java)

            if (!config.enabled) return

            val dialogKey = config.active_dialog
            val dialog = config.dialogs[dialogKey] ?: return

            if (!dialog.isNeedToShow) return
            callBack.invoke(config, dialogKey, dialog)
        } catch (e: Exception) {
            Log.e("AppRedirect", "Parse error", e)
        }
    }
}

data class RedirectItem(
    val isNeedToShow: Boolean = false,
    val isCancelable: Boolean = true,
    val title: String = "",
    val description: String = "",
    val button_text: String = "",
)

data class AppRedirectConfig(
    val enabled: Boolean = false,
    val active_dialog: String = "",
    val package_name: String = "",
    val app_icon: String = "",
    val dialogs: Map<String, RedirectItem> = emptyMap(),
)
