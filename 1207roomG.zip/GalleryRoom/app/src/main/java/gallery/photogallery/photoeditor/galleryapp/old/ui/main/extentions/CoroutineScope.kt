package gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions

import android.app.Activity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

fun Activity.launchIO(callback: () -> Unit) {
    CoroutineScope(Dispatchers.IO).launch {
        callback.invoke()
    }
}