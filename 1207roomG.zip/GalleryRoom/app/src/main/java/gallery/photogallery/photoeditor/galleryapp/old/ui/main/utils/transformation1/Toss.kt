package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation1

import android.view.View
import androidx.viewpager.widget.ViewPager
import kotlin.math.abs
import kotlin.math.max


class Toss : ViewPager.PageTransformer {

    override fun transformPage(view: View, position: Float) {
        view.translationX = -position * view.width
        view.cameraDistance = 20000f

        if (position < 0.5 && position > -0.5) {
            view.visibility = View.VISIBLE
        } else {
            view.visibility = View.INVISIBLE
        }

        when {
            position < -1 -> {
                view.alpha = 0f
            }

            position <= 0 -> {
                view.alpha = 1f
                view.scaleX = max(0.4f, 1 - abs(position))
                view.scaleY = max(0.4f, 1 - abs(position))
                view.rotationX = 1080 * (1 - abs(position) + 1)
                view.translationY = -1000 * abs(position)
            }

            position <= 1 -> {
                view.alpha = 1f
                view.scaleX = max(0.4f, 1 - abs(position))
                view.scaleY = max(0.4f, 1 - abs(position))
                view.rotationX = -1080 * (1 - abs(position) + 1)
                view.translationY = -1000 * abs(position)
            }

            else -> {
                view.alpha = 0f
            }
        }
    }

}