package gallery.photogallery.photoeditor.galleryapp.collage.fragments


import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.RelativeLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import gallery.photogallery.photoeditor.galleryapp.collage.utils.FlipDirection
import gallery.photogallery.photoeditor.galleryapp.collage.utils.ImageFlipper
import com.appblish.cropview.AppblishCropView
import com.appblish.cropview.AppblishCropViewSdk
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.AspectAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.utils.CollageConst.getAllRatios
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog.LoadingDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CropFragment : DialogFragment() {

    private var bitmap: Bitmap? = null
    private var onCropPhoto: ((Bitmap) -> Unit)? = null

    lateinit var cropImageView: AppblishCropView
      private var loadingDialog: LoadingDialog? = null

    companion object {
        private const val TAG = "CropFragment"

        fun show(
            appCompatActivity: AppCompatActivity,
            bitmap: Bitmap,
            onCropPhoto: (Bitmap) -> Unit
        ): CropFragment {
            val fragment = CropFragment()
            fragment.bitmap = bitmap
            fragment.onCropPhoto = onCropPhoto
            fragment.show(appCompatActivity.supportFragmentManager, TAG)
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        dialog?.window?.attributes?.windowAnimations = R.style.DialogAnimation
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundDrawable(ColorDrawable(-0x1000000)) // black
        }
    }

    @SuppressLint("WrongConstant")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        dialog?.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog?.window?.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )


        val view = inflater.inflate(R.layout.fragment_crop_collage, container, false)

         cropImageView = view.findViewById(R.id.crop_image_view)

        val userRatioList = getAllRatios()


        val aspectAdapter = AspectAdapter(ratioList = userRatioList, includeFreeRatio = true) { _, ratioText ->

            try {
                AppblishCropViewSdk.setCustomRatioText(ratioText)
//                cropImageView.setCustomRatioText(ratioText)
            } catch (_: NumberFormatException) {
            }
        }

        val recyclerViewRatio: RecyclerView = view.findViewById(R.id.recycler_view_ratio)
        recyclerViewRatio.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        recyclerViewRatio.adapter = aspectAdapter



        AppblishCropViewSdk.init(cropImageView)
        AppblishCropViewSdk.setCustomRatioText(userRatioList[0].type.ratioText)
//        cropImageView.setCustomRatioText(userRatioList[0].type.ratioText)

        view.findViewById<View>(R.id.relativeLayoutRotate).setOnClickListener {
            AppblishCropViewSdk.rotateM90D()
        }

        view.findViewById<View>(R.id.relativeLayouRotate90).setOnClickListener {
            AppblishCropViewSdk.rotate90D()
        }

        view.findViewById<View>(R.id.relativeLayoutVFlip).setOnClickListener {
            AppblishCropViewSdk.setImageBitmap(ImageFlipper.flip(AppblishCropViewSdk.getImageBitmap(), FlipDirection.VERTICAL))
//             cropImageView.imageBitmap =  ImageFlipper.flip(cropImageView.accessor.imageBitmap, FlipDirection.VERTICAL)
        }

        view.findViewById<View>(R.id.relativeLayoutHFlip).setOnClickListener {
            AppblishCropViewSdk.setImageBitmap(ImageFlipper.flip(AppblishCropViewSdk.getImageBitmap(), FlipDirection.HORIZONTAL))

//            cropImageView.imageBitmap =  ImageFlipper.flip(cropImageView.accessor.imageBitmap, FlipDirection.HORIZONTAL)
        }

        view.findViewById<View>(R.id.imageViewSaveCrop).setOnClickListener {
             saveCroppedImage()
        }


        view.findViewById<View>(R.id.imageViewCloseCrop).setOnClickListener {
            dismiss()
        }

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        AppblishCropViewSdk.setImageBitmap(bitmap!!)
//        cropImageView.imageBitmap = bitmap
    }

    private fun mLoading(show: Boolean) {
        if (show){
            showLoading()
        }else{
            hideLoading()
        }
    }

    private fun saveCroppedImage() {
        mLoading(true)

        // Launch coroutine on background thread
        lifecycleScope.launch(Dispatchers.IO) {
            val croppedBitmap: Bitmap = AppblishCropViewSdk.getCroppedBitmap()

            // Switch to Main thread to update UI
            withContext(Dispatchers.Main) {
                mLoading(false)

                onCropPhoto?.invoke(croppedBitmap) // call lambda
                dismiss()
            }
        }
    }




    private fun showLoading(message: String = "Please wait...") {

        if (loadingDialog == null) {
            loadingDialog = LoadingDialog(requireActivity())
        }

        loadingDialog?.setMessage(message)

        if (loadingDialog?.isShowing == false) {
            loadingDialog?.show()
        }
    }


    private fun hideLoading() {
        loadingDialog?.let {
            if (it.isShowing) {
                it.dismiss()
            }
        }
    }





}

