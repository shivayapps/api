package gallery.photogallery.photoeditor.galleryapp.activities

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.addCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import gallery.photogallery.photoeditor.galleryapp.App
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.SharedViewModel
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivitySplashBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.checkMediaPermission
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isDarkMode
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.SetLockActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.VerifyLockActivityBaseActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale


class SplashActivity : AppCompatActivity() {
    private val binding by viewBinding(ActivitySplashBinding::inflate)
    private var isReady = false
    val TAG = "SplashActivityTag"
    protected val sharedViewModel = ViewModelProvider(App.instance.appViewModelStoreOwner)[SharedViewModel::class.java]

    override fun attachBaseContext(newBase: Context) {
        val preferences = Preferences(newBase)
        val languageCodes = newBase.resources.getStringArray(R.array.language_code)
        val langCode = languageCodes.find {
            Locale.getDefault().language.lowercase().contains(it.lowercase())
        } ?: ""
        if (langCode.isEmpty()) {
            preferences.defaultLanguage = "en"
        } else {
            preferences.defaultLanguage = Locale.getDefault().language.lowercase()
        }
        super.attachBaseContext(newBase)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!isTaskRoot && intent.hasCategory(Intent.CATEGORY_LAUNCHER) && (intent.action != null) && intent.action.equals(
                Intent.ACTION_MAIN
            )
        ) {
            finish()
            return
        }
        enableEdgeToEdge()
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = !isDarkMode()
        controller.isAppearanceLightNavigationBars = !isDarkMode()
        window?.navigationBarColor = ContextCompat.getColor(this@SplashActivity, R.color.app_background)
        binding.root.setPadding(0, 0, 0, navigationBarHeight)
        setContentView(binding.root)

        initView()
        clickListener()
    }

    private fun initView() {
        lifecycleScope.launch {
            if (checkMediaPermission()) {
                sharedViewModel.fetchMedia()
                sharedViewModel.checkMediaExist()
            }


            if (preferences.selectedLanguage.isNotEmpty() && preferences.isMoveToHome) {
                preferences.splashCounter++
                preferences.appOpenCounter++
                openMainScreen()
                return@launch
            }

            moveAhead()
        }
    }

    private fun clickListener() {
        onBackPressedDispatcher.addCallback(this) {

        }
    }

    private fun moveAhead() {
        if (!isReady) {
            Log.e("TEXT_TAG", "moveAhead: Done")
            isReady = true
            preferences.splashCounter++
            preferences.appOpenCounter++
            loadScreen()
        }
    }

    fun loadScreen() {
        lifecycleScope.launch {
            delay(500)
            openLanguageScreen()
        }
    }

    private fun openShortcut() {
        when (intent.getStringExtra("id")) {
            "id_favourite" -> {
                val intent = Intent(this, ExplorePhotosActivity::class.java)
                intent.putExtra("BUCKET_PATH", "favorite")
                startActivity(intent)
                finish()
            }

            "id_recycle_bin" -> {
                startActivity(Intent(this, TrashActivity::class.java))
                finish()
            }

            "id_private" -> {
                val intentPrivate = if (preferences.getSetPass()) {
                    Intent(this@SplashActivity, VerifyLockActivityBaseActivity::class.java)
                } else {
                    val intent = Intent(this@SplashActivity, SetLockActivity::class.java)
                    intent.putExtra("setResultCode", 1111)
                    intent
                }
                startActivity(intentPrivate)
                finish()

            }

            "id_cleaner" -> {
//                startActivity(Intent(this@SplashActivity, JunkScanActivityBaseActivity::class.java))
                finish()

            }

            else -> {
                loadScreen()
            }
        }

    }

    private fun openLanguageScreen() {
        if (preferences.selectedLanguage.isEmpty()) {
            startActivity(Intent(this, NewLanguageSelectActivity::class.java))
        } else if (preferences.isMoveToHome) {
            startActivity(Intent(this, MainActivity::class.java).putExtras(intent))
        } else {
            startActivity(Intent(this, PermissionActivity::class.java))
        }
        finish()
    }

    private fun openMainScreen() {
        startActivity(Intent(this@SplashActivity, MainActivity::class.java).putExtras(intent))
        finish()
    }
}