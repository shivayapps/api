package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import com.appblish.box.api.model.MediaGroupBy
import com.appblish.box.api.model.SortOrder
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogGroupBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity

class GroupByDialog(private val updateListener: (() -> Unit)?) : DialogFragment() {
    private var _binding: DialogGroupBinding? = null
    private val binding get() = _binding!!
    private lateinit var safeContext: Context
    private val baseActivity: BaseActivity
        get() = requireActivity() as BaseActivity


    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogGroupBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER) // remove if you want center dialog
        }

        initView()
        clickListener()

        return dialog
    }

    private fun initView() {
        val groupBy = baseActivity.sharedViewModel.getMediaGroupBy()
        val groupOrder = baseActivity.sharedViewModel.getMediaGroupByOrder()
        when (groupBy) {
            MediaGroupBy.NO_GROUP -> binding.groupingDialogRadioNoGroup.isChecked = true
            MediaGroupBy.LAST_MODIFIED -> binding.groupingDialogRadioLastModified.isChecked = true
            MediaGroupBy.FILE_TYPE -> binding.groupingDialogRadioFileType.isChecked = true
            MediaGroupBy.EXTENSION -> binding.groupingDialogRadioExtension.isChecked = true
            MediaGroupBy.FOLDER -> binding.groupingDialogRadioFolder.isChecked = true
        }
        when (groupOrder) {
            SortOrder.ASCENDING -> binding.rbAscending.isChecked = true
            SortOrder.DESCENDING -> binding.rbDescending.isChecked = true
        }

    }

    private fun clickListener() {
        binding.btnCancel.setOnClickListener {
            dismiss()
        }
        binding.btnOK.setOnClickListener {
            val selectedRadioButtonId: Int = binding.grpOption.checkedRadioButtonId
            val selectedRadioButtonIdOrder: Int = binding.grpOrder.checkedRadioButtonId
            val mediaGroupBy = when (selectedRadioButtonId) {
                binding.groupingDialogRadioNoGroup.id -> MediaGroupBy.NO_GROUP
                binding.groupingDialogRadioLastModified.id -> MediaGroupBy.LAST_MODIFIED
                binding.groupingDialogRadioFileType.id -> MediaGroupBy.FILE_TYPE
                binding.groupingDialogRadioExtension.id -> MediaGroupBy.EXTENSION
                binding.groupingDialogRadioFolder.id -> MediaGroupBy.FOLDER
                else -> MediaGroupBy.NO_GROUP
            }
            baseActivity.sharedViewModel.setMediaGroupBy(mediaGroupBy)

            val sortOrder = when (selectedRadioButtonIdOrder) {
                binding.rbAscending.id -> SortOrder.ASCENDING
                binding.rbDescending.id -> SortOrder.DESCENDING
                else -> SortOrder.DESCENDING
            }
            baseActivity.sharedViewModel.setMediaGroupByOrder(sortOrder)
            dismiss()
            updateListener?.invoke()
        }
    }
}