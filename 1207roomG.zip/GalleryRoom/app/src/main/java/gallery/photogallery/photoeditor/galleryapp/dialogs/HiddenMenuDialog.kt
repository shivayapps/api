package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.databinding.BottomSheetHidenMenuBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.custom.SwitchButton
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isBiometricIdAvailable
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isSupportWithErrorInfo

class HiddenMenuDialog(
    private val onItemClick: (type: Int) -> Unit
) : DialogFragment() {
    private var _binding: BottomSheetHidenMenuBinding? = null
    private val binding get() = _binding!!
    private lateinit var safeContext: Context
    private var isFingerprintAvailable = Pair(false, "")

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = BottomSheetHidenMenuBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        intView()
        clickListener()
        return dialog
    }

    private fun intView() {
        val isSupportFingerprint = safeContext.isBiometricIdAvailable()
        isFingerprintAvailable = activity!!.isSupportWithErrorInfo(safeContext, BiometricManager.Authenticators.BIOMETRIC_STRONG)
        binding.sbFingerprint.beVisibleIf(isSupportFingerprint)

        binding.sbFingerprint.isChecked = safeContext.appPref.enableFingerprint && isFingerprintAvailable.first
    }

    private fun clickListener() {
        binding.llChangePassword.setOnClickListener {
            onItemClick.invoke(1)
            dismiss()
        }

        binding.llChangeSecurity.setOnClickListener {
            onItemClick.invoke(2)
            dismiss()
        }

        binding.llPrivateTrash.setOnClickListener {
            onItemClick.invoke(3)
            dismiss()
        }

        binding.sbFingerprint.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                dismiss()
                if (isChecked) {
                    onItemClick.invoke(31)
                } else {
                    onItemClick.invoke(32)
                }
            }
        })
    }
}