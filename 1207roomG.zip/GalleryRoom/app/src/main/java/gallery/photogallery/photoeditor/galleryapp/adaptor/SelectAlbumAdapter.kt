package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.appblish.gallery.core.v2.api.model.AlbumListItem
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.SelectAlbumActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemAlbumGridBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemAlbumListBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isGif
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isVideoFast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import java.io.File

class SelectAlbumAdapter(private val activity: SelectAlbumActivity) :
    ListAdapter<AlbumListItem, RecyclerView.ViewHolder>(selectAlbumDiffUtil) {

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        if (holder is AlbumViewHolder) {
            Glide.with(holder.binding.imageAlbum.context).clear(holder.binding.imageAlbum)
        }
        if (holder is AlbumListViewHolder) {
            Glide.with(holder.binding.imageAlbum.context).clear(holder.binding.imageAlbum)
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int,
    ): RecyclerView.ViewHolder {
        return if (activity.appPref.albumAsGrid) {
            val binding = ItemAlbumGridBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
            AlbumViewHolder(binding)
        } else {
            val binding = ItemAlbumListBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
            AlbumListViewHolder(binding)
        }
    }

    override fun onBindViewHolder(
        holder: RecyclerView.ViewHolder, position: Int,
    ) {
        when (holder) {
            is AlbumViewHolder -> holder.bind(currentList[position])
            is AlbumListViewHolder -> holder.bind(currentList[position])
        }
    }

    fun getSelectionAlbum(): HashSet<AlbumListItem> {
        val selectionIndex = HashSet<AlbumListItem>()
        currentList.forEachIndexed { index, item ->
            if (item is AlbumListItem.Album && !item.albumBox.isCustom) {
                selectionIndex.add(item)
            }
        }
        return selectionIndex
    }


    inner class AlbumViewHolder(
        val binding: ItemAlbumGridBinding,
    ) : RecyclerView.ViewHolder(binding.root) {

        @SuppressLint("SetTextI18n")
        fun bind(item: AlbumListItem) {
            val album = item as AlbumListItem.Album
            val data = album.albumBox

            binding.apply {
                icPin.beVisibleIf(data.isPinned)
                txtTitle.text = data.bucketName
                txtCount.text = "${album.mediaCount} ${root.context.getString(R.string.items)}"

                val context = imageAlbum.context
                val coverPath = context.preferences.getCoverImage(data.bucketPath)

                imageAlbum.beVisible()
                ivRecentIcon.beGone()

                if (coverPath.isNotEmpty()) {
                    imageAlbum.loadGridImage(coverPath, File(coverPath).lastModified())
                    icVideo.beVisibleIf(coverPath.isVideoFast())
                    ivGif.beVisibleIf(coverPath.isGif())
                } else {
                    imageAlbum.loadGridImage(album.mediaPath, album.mediaDate)
                    icVideo.beVisibleIf(album.mediaPath.isVideoFast())
                    ivGif.beVisibleIf(album.mediaPath.isGif())
                }

                if (data.bucketName == "recent") {
                    ivRecentIcon.beVisible()
                }

                // 🔥 CHECK ICON LOGIC (IMPORTANT)
                icUnSelect.beVisible() // always visible


                root.setOnClickListener {
                    selectItem(item)
                }

                root.setOnLongClickListener {
                    selectItem(item)
                    true
                }
            }
        }
    }

    fun selectItem(item: AlbumListItem.Album) {
        activity.selectAlbum(item.albumBox.bucketPath)
    }

    inner class AlbumListViewHolder(
        val binding: ItemAlbumListBinding,
    ) : RecyclerView.ViewHolder(binding.root) {

        @SuppressLint("SetTextI18n")
        fun bind(item: AlbumListItem) {
            val album = item as AlbumListItem.Album
            val data = album.albumBox

            binding.apply {
                icPin.beVisibleIf(data.isPinned)
                txtTitle.text = data.bucketName
                txtCount.text = "${data.mediaList.size} ${root.context.getString(R.string.items)}"

                val context = imageAlbum.context
                val coverPath = context.preferences.getCoverImage(data.bucketPath)
                ivRecentIcon.beGone()
                imageAlbum.beVisible()

                if (coverPath.isNotEmpty()) {
                    imageAlbum.loadGridImage(coverPath, File(coverPath).lastModified())
                    icVideo.beVisibleIf(coverPath.isVideoFast())
                    ivGif.beVisibleIf(coverPath.isGif())
                } else {
                    val mediaPath = data.mediaList.first().mediaPath
                    val mediaDate = data.mediaList.first().mediaDate
                    imageAlbum.loadGridImage(mediaPath, mediaDate)
                    icVideo.beVisibleIf(mediaPath.isVideoFast())
                    ivGif.beVisibleIf(mediaPath.isGif())
                }

                icUnSelect.beVisible()


                root.setOnClickListener {
                    selectItem(item)
                }

                root.setOnLongClickListener {
                    selectItem(item)
                    true
                }
            }
        }
    }

}

val selectAlbumDiffUtil = object : DiffUtil.ItemCallback<AlbumListItem>() {
    override fun areItemsTheSame(
        oldItem: AlbumListItem, newItem: AlbumListItem,
    ): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(
        oldItem: AlbumListItem, newItem: AlbumListItem,
    ): Boolean {
        return oldItem == newItem
    }
}