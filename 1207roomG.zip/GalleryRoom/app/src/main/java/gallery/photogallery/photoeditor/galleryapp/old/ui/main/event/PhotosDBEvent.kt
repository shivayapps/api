package gallery.photogallery.photoeditor.galleryapp.old.ui.main.event

import org.greenrobot.eventbus.EventBus


data class PhotosDBEvent(val type: String, val data: Any? = null)

const val UPDATE_MEDIA_DATA_PHOTO = "UPDATE_MEDIA_DATA_PHOTO"
fun sendPhotosDBEvent(type: String, data: Any? = null) {
    EventBus.getDefault().post(PhotosDBEvent(type, data))
}


