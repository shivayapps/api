package gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogExitBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isDarkMode
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.newNavigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.isAboveAndroid11

class ExitBottomDialog(val activity: Activity) : Dialog(activity) {
    lateinit var dialogBinding: DialogExitBinding

    companion object {
        fun newInstance(activity: Activity): ExitBottomDialog {
            val menuDialog = ExitBottomDialog(activity)
            return menuDialog
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        dialogBinding = DialogExitBinding.inflate(layoutInflater)
        setContentView(dialogBinding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )

        dialogBinding.clExitBtn.setPadding(0, 0, 0, activity.newNavigationBarHeight)
        intView()

    }

    override fun show() {
        super.show()
        if (isAboveAndroid11()) {
            window?.apply {

                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                decorView.systemUiVisibility = (
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        )
            }
        }

        window?.navigationBarColor = ContextCompat.getColor(activity, R.color.dialogBg)
        val controller = WindowCompat.getInsetsController(window!!, window!!.decorView)
        controller.isAppearanceLightNavigationBars = !activity.isDarkMode()

    }


    private fun intView() {

    }
}