package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.annotation.SuppressLint
import android.content.Context
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.appblish.gallery.core.v2.api.model.PlaceListItem
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemAlbumGridBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone


class SearchPlacesAdaptor(val context: Context, val onClick: (PlaceListItem) -> Unit) : RecyclerView.Adapter<SearchPlacesAdaptor.AlbumGridViewHolder>() {

    class AlbumGridViewHolder(var binding: ItemAlbumGridBinding) : RecyclerView.ViewHolder(binding.root)

    private val diffUtil = object : DiffUtil.ItemCallback<PlaceListItem>() {
        override fun areItemsTheSame(oldItem: PlaceListItem, newItem: PlaceListItem): Boolean {
            return oldItem.title == newItem.title
        }

        override fun areContentsTheSame(oldItem: PlaceListItem, newItem: PlaceListItem): Boolean {
            return oldItem.mediaList.size == newItem.mediaList.size && oldItem.title == newItem.title
        }

    }
    val asyncListDiffer = AsyncListDiffer(this, diffUtil)
    fun saveData(dataResponse: List<PlaceListItem>) {
        asyncListDiffer.submitList(ArrayList(dataResponse))
    }

    fun getItem(pos: Int): PlaceListItem {
        return asyncListDiffer.currentList[pos]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlbumGridViewHolder {
        val binding = ItemAlbumGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        val width = parent.measuredWidth / 3.8
        binding.root.layoutParams.width = width.toInt()
        return AlbumGridViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return asyncListDiffer.currentList.size
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: AlbumGridViewHolder, position: Int) {
        val albumData: PlaceListItem = asyncListDiffer.currentList[position] as PlaceListItem
        holder.itemView.tag = albumData
        holder.binding.icPin.beGone()
        holder.binding.txtCount.beGone()
        holder.binding.txtTitle.gravity = Gravity.CENTER
        holder.binding.txtTitle.text = albumData.title
        holder.binding.txtCount.text = albumData.mediaList.size.toString()
        val realPlacesPhotosModel = albumData.mediaList[0]
        holder.binding.imageAlbum.loadGridImage(realPlacesPhotosModel.mediaPath, realPlacesPhotosModel.mediaDate)
        holder.binding.icUnSelect.visibility = View.GONE
        holder.binding.icSelect.visibility = View.GONE
        holder.binding.icSelect.visibility = View.GONE
        holder.itemView.setOnClickListener {
            onClick.invoke(albumData)
        }
    }

}