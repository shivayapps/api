package gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory

import android.os.Bundle
import android.os.Parcelable
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.viewpager.widget.PagerAdapter
import com.appblish.story.memories.api.model.StoryBox


class NewStoryPagerAdapter(val activity: NewStoryActivity, fm: FragmentManager, var selectedPosition: Int, var media: List<StoryBox>) : FragmentStatePagerAdapter(fm) {
    private val fragments = HashMap<Int, StoryPagerImageFragment>()
    override fun getCount() = media.size

    fun updateMedia(media: List<StoryBox>) {
        this.media = media
        notifyDataSetChanged()
    }

    override fun getItem(position: Int): Fragment {
        val pictureData = media[position]
        return StoryPagerImageFragment.newInstance(pictureData, position == selectedPosition)
    }

    override fun getItemPosition(item: Any) = PagerAdapter.POSITION_NONE

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val fragment = super.instantiateItem(container, position) as StoryPagerImageFragment
        fragments[position] = fragment
        return fragment
    }

    override fun destroyItem(container: ViewGroup, position: Int, any: Any) {
        fragments.remove(position)
        super.destroyItem(container, position, any)
    }

    fun getCurrentFragment(position: Int) = fragments[position]

    fun toggleFullscreen(isFullscreen: Boolean) {
        /*  for ((pos, fragment) in fragments) {
              fragment.fullscreenToggled(isFullscreen)
          }*/
    }

    // try fixing TransactionTooLargeException crash on Android Nougat, tip from https://stackoverflow.com/a/43193425/1967672
    override fun saveState(): Parcelable? {
        val bundle = super.saveState() as Bundle?
        bundle?.putParcelableArray("states", null)
        return bundle
    }

    fun pauseAllProgress() {
        fragments.values.forEach { it.pauseProgress() }
    }

    fun updateMusicIcon() {
        fragments.values.forEach { it.updateMusicIcon() }
    }

    fun releaseVideoPlayer() {
        fragments.values.forEach { it.releaseVideoPlayer() }
    }

    fun resumeProgress() {
        fragments.values.forEach { it.resumeProgress() }
    }

    fun startProgress(position: Int) {
        fragments[position]?.startStoryProgress()
    }

    fun playVideo(position: Int) {
        fragments[position]?.playVideo(true)
    }

    fun onLongPressCalled(position: Int) {
        fragments[position]?.onLongPressCalled()
    }

    fun clickPrevious(position: Int) {
        fragments[position]?.clickPrevious()
    }

    fun clickNext(position: Int) {
        fragments[position]?.clickNext()
    }
}
