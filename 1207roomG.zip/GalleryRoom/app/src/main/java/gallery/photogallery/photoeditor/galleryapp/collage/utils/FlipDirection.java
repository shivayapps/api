package gallery.photogallery.photoeditor.galleryapp.collage.utils;

public enum FlipDirection {
    VERTICAL,
    HORIZONTAL
}
