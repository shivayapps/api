package gallery.photogallery.photoeditor.galleryapp.videoplayer

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemAudioTrackBinding

class AudioTrackAdapter(
    private val list: List<String>,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<AudioTrackAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemAudioTrackBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAudioTrackBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun getItemCount() = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.tvAudioName.text = list[position]
        holder.binding.root.setOnClickListener {
            onClick(position)
        }
    }
}