package gallery.photogallery.photoeditor.galleryapp.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.ScrollGate
import com.appblish.box.api.util.AppblishEvent
import com.appblish.box.api.util.MediaDataState
import com.appblish.gallery.core.v2.api.core.GallerySdkV2
import com.appblish.gallery.core.v2.api.model.MediaModel
import com.appblish.gallery.core.v2.api.model.PlacesMediaListItem
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.bottomsheet.BottomSheetBehavior
import gallery.photogallery.photoeditor.galleryapp.adaptor.PlacesOpenAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityPlacesOpenBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.getMarkerBitmapFromView
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.utils.START_SCANNING
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.sendIntentEvent
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class PlacesOpenActivity : BaseActivity() {

    private val binding by viewBinding(ActivityPlacesOpenBinding::inflate)
    private val placesOpenAdapter by lazy { PlacesOpenAdapter(this) }
    private val placeTitle by lazy { intent.getStringExtra("placeTitle").orEmpty() }
    private lateinit var bottomSheetBehavior: BottomSheetBehavior<View>
    private var isExpanded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        binding.mapView.onCreate(savedInstanceState)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        registerEventBus(this)
        init()
        clickListener()
    }

    private fun setupMapBottomSheet() {
        val screenHeight = resources.displayMetrics.heightPixels

        bottomSheetBehavior = BottomSheetBehavior.from(binding.mapBottomSheet)

        bottomSheetBehavior.apply {
            val height = (screenHeight * 0.30).toInt()
            peekHeight = height
            state = BottomSheetBehavior.STATE_COLLAPSED
            isDraggable = false
            binding.rvPlacesOpen.setPadding(0, 0, 0, height + 10)
        }

        bottomSheetBehavior.addBottomSheetCallback(
            object : BottomSheetBehavior.BottomSheetCallback() {

                override fun onStateChanged(bottomSheet: View, newState: Int) {
                    isExpanded = newState == BottomSheetBehavior.STATE_EXPANDED

                    binding.btnExpand.animate()
                        .rotation(if (isExpanded) 180f else 0f)
                        .setDuration(250)
                        .start()
                }

                override fun onSlide(bottomSheet: View, slideOffset: Float) {}
            }
        )

        binding.btnExpand.setOnClickListener {
            toggleMapSheet()
        }
    }

    private fun toggleMapSheet() {
        val screenHeight = resources.displayMetrics.heightPixels

        if (isExpanded) {
            val height = (screenHeight * 0.30).toInt()
            bottomSheetBehavior.peekHeight = height
            bottomSheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED
            binding.rvPlacesOpen.setPadding(0, 0, 0, height + 10)
        } else {
            val height = (screenHeight * 0.55).toInt()
            bottomSheetBehavior.peekHeight = height
            bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
            binding.rvPlacesOpen.setPadding(0, 0, 0, height + 10)
        }
    }

    private fun init() {

        lifecycleScope.launch {
            binding.txtTitle.text = placeTitle
            setupMapBottomSheet()
            fetchData()
        }
    }

    var fetchJob: Job? = null
    fun fetchData() {
        fetchJob?.cancel()
        fetchJob = lifecycleScope.launch(Dispatchers.IO) {
            val state = GallerySdkV2.get().getPlaces(placeTitle)
            withContext(Dispatchers.Main) {
                if (state is MediaDataState.Success) {
                    setMedias(state.data)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (isRequireRefetch) {
            isRequireRefetch = false
            fetchData()
        }
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            AppblishEvent.ALL_PLACES_LOADED -> {
                if (isPause) {
                    isRequireRefetch = true
                } else {
                    fetchData()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterEventBus(this)
        sendIntentEvent(START_SCANNING)
    }

    private fun clickListener() {

        binding.rvPlacesOpen.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING ||
                    newState == RecyclerView.SCROLL_STATE_SETTLING
                ) {
                    ScrollGate.onScrollStart()
                } else {
                    ScrollGate.onScrollStop()
                }
            }
        })

        binding.ivBack.setOnClickListener {
            finish()
        }
    }

    private fun setMedias(items: List<PlacesMediaListItem>) {
        if (binding.rvPlacesOpen.adapter == null) {
            val spanCount = 3
            val layoutManager = GridLayoutManager(this, spanCount)
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    return when (placesOpenAdapter.getItemViewType(position)) {
                        PlacesOpenAdapter.HEADER -> spanCount // full width
                        PlacesOpenAdapter.MEDIA -> 1
                        else -> 1
                    }
                }
            }

            binding.rvPlacesOpen.layoutManager = layoutManager
            binding.rvPlacesOpen.adapter = placesOpenAdapter
        }

        placesOpenAdapter.submitList(items)
        initMapData(items.filterIsInstance<PlacesMediaListItem.Media>().map { it.mediaModel })
    }

    private var googleMap: GoogleMap? = null
    private fun initMapData(pictures: List<MediaModel>) {
        if (googleMap != null) {
            updateMap(pictures)
        } else {
            binding.mapView.getMapAsync { map ->
                googleMap = map
                googleMap?.setOnMarkerClickListener { marker ->
                    val markerTag = marker.tag as? String ?: ""
                    val intent = Intent(this, PlacesOpenActivity::class.java)
                    intent.putExtra("placeTitle", markerTag)
                    startActivity(intent)
                    true
                }
                updateMap(pictures)
            }
        }


    }

    var markJob: Job? = null

    private fun updateMap(pictures: List<MediaModel>) {
        googleMap?.clear()
        markJob?.cancel()
        markJob = CoroutineScope(Dispatchers.IO).launch {
            var pos = 0
            var latLong: Pair<Double, Double> = Pair(0.0, 0.0)
            pictures.forEachIndexed { index, it ->
                if (it.mediaBox.latitude != 0.0 && it.mediaBox.longitude != 0.0) {
                    latLong = Pair(it.mediaBox.latitude, it.mediaBox.longitude)
                }
                if (latLong.first != 0.0 && latLong.second != 0.0) {
                    pos = index
                    return@forEachIndexed
                }
            }
            withContext(Dispatchers.Main) {
                try {
                    moveCameraAndMarker(latLong, pictures, pos)
                } catch (e: Exception) {
                    Log.e("updateMap", "updateMap: $e")
                }
            }
        }

    }

    private fun moveCameraAndMarker(latLong: Pair<Double, Double>, pictures: List<MediaModel>, pos: Int) {
        if (latLong.first != 0.0 && latLong.second != 0.0) {
            val location = LatLng(latLong.first, latLong.second)
            googleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 10f))
            googleMap?.animateCamera(CameraUpdateFactory.zoomIn());
            googleMap?.animateCamera(CameraUpdateFactory.zoomTo(10f), 2000, null)
            val count = pictures.count { it.mediaBox.latitude != 0.0 && it.mediaBox.longitude != 0.0 }
            val bitmap = getMarkerBitmapFromView(pictures[pos].mediaPath, count, pictures[pos].mediaDate.toString())
            if (bitmap != null) {
                val marker = googleMap?.addMarker(
                    MarkerOptions()
                        .anchor(0.5f, 0.5f)
                        .position(location)
                        .icon(
                            BitmapDescriptorFactory.fromBitmap(
                                bitmap
                            )
                        )
                )
                marker?.tag = pictures[pos].mediaBox.mediaName
            }
        }
    }
}