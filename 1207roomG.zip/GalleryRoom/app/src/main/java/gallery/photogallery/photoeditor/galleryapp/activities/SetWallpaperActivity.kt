package gallery.photogallery.photoeditor.galleryapp.activities

import android.app.WallpaperManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivitySetWallpaperBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.SetWallpaperOptionDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.getParcelable
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import java.io.IOException

class SetWallpaperActivity : BaseActivity(), View.OnClickListener {
    private val binding by viewBinding(ActivitySetWallpaperBinding::inflate)
    private var selectedImageUri: Uri? = null
    private var croppedBitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = false
//        binding.llTop.setPadding(0, statusBarHeight, 0, 0)
//        binding.root.setPadding(0, 0, 0, navigationBarHeight)

        binding.root.setPadding(0, statusBarHeight, 0, navigationBarHeight)
        initView()
        clickListener()
    }

    private fun initView() {
        val intent = intent
        val dataUri: Uri? = intent.data

        selectedImageUri = dataUri
        if (selectedImageUri == null) {
            selectedImageUri = intent.getParcelable("image_uri")
        }

        if (selectedImageUri != null) {

            binding.cropImageView.imageBitmap = MediaStore.Images.Media.getBitmap(contentResolver, selectedImageUri)
            val displayMetrics = resources.displayMetrics
            val screenWidth = displayMetrics.widthPixels
            val screenHeight = displayMetrics.heightPixels
            binding.cropImageView.setCustomRatio(screenWidth, screenHeight)
            Glide.with(this)
                .asBitmap()
                .load(selectedImageUri)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .skipMemoryCache(false)
                .into(object : CustomTarget<Bitmap>() {

                    override fun onResourceReady(
                        resource: Bitmap,
                        transition: Transition<in Bitmap>?,
                    ) {
                        croppedBitmap = resource
                        binding.cropImageView.imageBitmap = resource

                        // use bitmap here
                    }

                    override fun onLoadCleared(placeholder: Drawable?) {
                        // cleanup if needed
                    }
                })
        } else {
            finish()
        }
    }

    private fun clickListener() {
        binding.ivBack.setOnClickListener(this)
        binding.btnCrop.setOnClickListener(this)
    }

    override fun onClick(view: View?) {
        when (view) {
            binding.ivBack -> {
                setResult(RESULT_CANCELED, Intent())
                finish()
            }

            binding.btnCrop -> {
                croppedBitmap = binding.cropImageView.croppedBitmap
                if (selectedImageUri != null) {
                    val setWallpaperDialog = SetWallpaperOptionDialog()
                    setWallpaperDialog.setWallpaperClick = { clickId ->
                        when (clickId) {
                            1 -> setWallpaper(WallpaperManager.FLAG_SYSTEM)
                            2 -> setWallpaper(WallpaperManager.FLAG_LOCK)
                            3 -> setWallpaper(WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
                        }
                    }

                    setWallpaperDialog.show(supportFragmentManager, "ResizeDialog")
                } else {
                    // Toast.makeText(this, "Failed to crop image", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun setWallpaper(flag: Int) {

        showLoadingDialog()
        croppedBitmap?.let { bitmap ->
            try {
                val wallpaperManager = WallpaperManager.getInstance(this)

                wallpaperManager.setBitmap(bitmap, null, true, flag)
                hideLoadingDialog()

//                showToast(getString(R.string.wallpaper_set_successfully))
                finish()

            } catch (e: IOException) {
                hideLoadingDialog()
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}