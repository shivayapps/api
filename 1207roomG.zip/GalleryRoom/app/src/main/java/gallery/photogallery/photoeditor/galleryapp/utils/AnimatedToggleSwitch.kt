package gallery.photogallery.photoeditor.galleryapp.utils


import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat

class AnimatedToggleSwitch @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    // Colors
    private val backgroundColor = 0xFFF4F4F4.toInt()
    private val selectedColor = 0xFF2196F3.toInt()
//    private val borderColor = 0xFF2196F3.toInt()
    private val textColor = 0xFF333333.toInt()
    private val selectedTextColor = 0xFFFFFFFF.toInt()

    // Paint objects
    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = backgroundColor
        style = Paint.Style.FILL
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
//        color = borderColor
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    private val selectorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = selectedColor
        style = Paint.Style.FILL
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 48f
        textAlign = Paint.Align.CENTER
    }

    // Toggle state
    private var isGridSelected = true
    private var animationProgress = 1f // 0 = Map, 1 = Grid
    private var animator: ValueAnimator? = null

    // Labels
    private val leftLabel = "Map"
    private val rightLabel = "Grid"

    // Callback
    var onToggleChanged: ((isGridSelected: Boolean) -> Unit)? = null

    private val rectF = RectF()
    private val selectorRectF = RectF()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val desiredWidth = 600
        val desiredHeight = 180

        val width = resolveSize(desiredWidth, widthMeasureSpec)
        val height = resolveSize(desiredHeight, heightMeasureSpec)

        setMeasuredDimension(width, height)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val width = width.toFloat()
        val height = height.toFloat()
        val cornerRadius = height / 2f

        // Draw background with border
        rectF.set(0f, 0f, width, height)
        canvas.drawRoundRect(rectF, cornerRadius, cornerRadius, backgroundPaint)
//        canvas.drawRoundRect(rectF, cornerRadius, cornerRadius, borderPaint)

        // Calculate selector position based on animation progress
        val selectorWidth = width / 2f
        val padding = 8f
        val selectorLeft = padding + (selectorWidth - padding * 2) * animationProgress
        val selectorRight = selectorLeft + selectorWidth - padding * 2

        // Draw animated selector
        selectorRectF.set(selectorLeft, padding, selectorRight, height - padding)
        canvas.drawRoundRect(
            selectorRectF,
            cornerRadius - padding,
            cornerRadius - padding,
            selectorPaint
        )

        // Draw text labels
        val textY = height / 2f + textPaint.textSize / 3f

        // Left label (Map)
        textPaint.color = if (animationProgress < 0.5f) selectedTextColor else textColor
        canvas.drawText(leftLabel, width / 4f, textY, textPaint)

        // Right label (Grid)
        textPaint.color = if (animationProgress >= 0.5f) selectedTextColor else textColor
        canvas.drawText(rightLabel, width * 3f / 4f, textY, textPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                return true
            }
            MotionEvent.ACTION_UP -> {
                val width = width.toFloat()
                val clickedOnRight = event.x > width / 2f

                if (clickedOnRight != isGridSelected) {
                    isGridSelected = clickedOnRight
                    animateToggle()
                    onToggleChanged?.invoke(isGridSelected)
                }
                performClick()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun animateToggle() {
        animator?.cancel()

        val targetProgress = if (isGridSelected) 1f else 0f

        animator = ValueAnimator.ofFloat(animationProgress, targetProgress).apply {
            duration = 300
            interpolator = DecelerateInterpolator()
            addUpdateListener { animation ->
                animationProgress = animation.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun setGridSelected(selected: Boolean, animate: Boolean = true) {
        if (isGridSelected != selected) {
            isGridSelected = selected
            if (animate) {
                animateToggle()
            } else {
                animationProgress = if (selected) 1f else 0f
                invalidate()
            }
        }
    }

    fun isGridSelected(): Boolean = isGridSelected
}