package gallery.photogallery.photoeditor.galleryapp.extentions

import android.app.Dialog
import android.content.Context
import android.content.Context.WINDOW_SERVICE
import android.content.res.Configuration
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.annotation.StringRes
import androidx.core.view.WindowInsetsControllerCompat
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogCommonDeleteBinding

fun Dialog.applySystemBarAppearanceByTheme() {
    window?.let { window ->
        val isDarkMode =
            (window.context.resources.configuration.uiMode and
                    Configuration.UI_MODE_NIGHT_MASK) ==
                    Configuration.UI_MODE_NIGHT_YES

        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = !isDarkMode
            isAppearanceLightNavigationBars = !isDarkMode
        }
    }
}


fun Context.getScreenWidthFraction(): Int {
    val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    val windowMetrics = windowManager.currentWindowMetrics
    return (windowMetrics.bounds.width() * 0.95f).toInt()
}

fun Context.showDeleteDialog(
    title: String,
    subTitle: String? = null,
    @StringRes positiveRes: Int = R.string.yes,
    onDeleteClick: () -> Unit,
    onCancelClick: (() -> Unit)? = null
) {
    val dialog = Dialog(this)
    val binding = DialogCommonDeleteBinding.inflate(LayoutInflater.from(this))

    dialog.setContentView(binding.root)
    dialog.setCancelable(false)
    dialog.window?.apply {
        setBackgroundDrawableResource(android.R.color.transparent)
        setLayout(
            (resources.displayMetrics.widthPixels * 0.9f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT
        )
    }

    binding.run {
        txtTitle.text = title
        btnDelete.text = getString(positiveRes)
        if (subTitle.isNullOrBlank()) {
            txtSubTitle.visibility = View.GONE
        } else {
            txtSubTitle.visibility = View.VISIBLE
            txtSubTitle.text = subTitle
        }

        btnCancel.setOnClickListener {
            onCancelClick?.invoke()
            dialog.dismiss()
        }

        btnDelete.setOnClickListener {
            onDeleteClick()
            dialog.dismiss()
        }
    }
    dialog.show()
}