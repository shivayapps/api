package gallery.photogallery.photoeditor.galleryapp.helper

import android.util.Base64

object EncryptionHandler {

    fun base64Encode(input: String): String {
        return Base64.encodeToString(input.toByteArray(), Base64.NO_WRAP).replace("=", "").trim()
    }

    fun base64Decode(encoded: String): String {
        try {
            return String(Base64.decode(encoded, Base64.NO_WRAP)).replace("=", "").trim()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return ""
    }


}