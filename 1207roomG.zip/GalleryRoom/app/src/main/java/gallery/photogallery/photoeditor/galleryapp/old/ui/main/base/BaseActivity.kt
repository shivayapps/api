package gallery.photogallery.photoeditor.galleryapp.old.ui.main.base

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.appblish.box.api.model.MainMediaFilter
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.MainActivity
import gallery.photogallery.photoeditor.galleryapp.activities.SearchActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.HomeMenuFilterBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.DeleteDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.getColorCompat
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog.LoadingDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.getRealPathFromURI
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isDarkMode
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant.THEME_DARK
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant.THEME_LIGHT
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.PopupWindowHelper
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Preferences
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Locale


open class BaseActivity : OperationsActivity() {

    var isPortrait = true
    lateinit var loadingDialog: LoadingDialog
    var isRequireRefetch = false
    var isPause = false
    override fun attachBaseContext(newBase: Context) {
        Preferences(newBase).defaultLanguage = Locale.getDefault().language
        super.attachBaseContext(updateLocale(newBase, newBase.preferences.getSelectedLang(newBase)))  // Change locale here
    }

    private fun updateLocale(context: Context, language: String): Context {
        val locale = Locale(language)
        Locale.setDefault(locale)

        val config = Configuration()
        config.setLocale(locale)

        return context.createConfigurationContext(config)
    }

    override fun onResume() {
        super.onResume()
        isPause = false
    }

    override fun onPause() {
        super.onPause()
        isPause = true
    }

    @SuppressLint("SourceLockedOrientationActivity")
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightNavigationBars = !isDarkMode()
        window?.navigationBarColor = ContextCompat.getColor(this, R.color.app_background)
        if (Preferences(this).getThemeValue() == THEME_LIGHT) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        } else if (Preferences(this).getThemeValue() == THEME_DARK) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        }
        if (isPortrait)
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
        setLocale(preferences.getSelectedLang(this))
        super.onCreate(savedInstanceState)
        loadingDialog = LoadingDialog(this)
        if (savedInstanceState != null) {
            sharedViewModel.fetchMedia()
        }
    }

    fun deleteMedia(mediaPathList: List<String>, onComplete: () -> Unit = {}) {

        when (Preferences(this).getDeleteBehavior()) {

            Constant.DELETE_BEHAVIOR_ADD_TO_RECYCLE_BIN -> {
                deleteFolderFiles(mediaPathList, false, onComplete)
            }

            Constant.DELETE_BEHAVIOR_PRESENTLY_DELETE -> {
                deleteFolderFiles(mediaPathList, true, onComplete)
            }

            Constant.DELETE_BEHAVIOR_ALWAYS_ASK -> {
                val deleteDialog = DeleteDialog.newInstance(btnClickListener = { isPermanent ->
                    deleteFolderFiles(mediaPathList, isPermanent, onComplete)
                })
                deleteDialog.show(supportFragmentManager, "DeleteDialog")
            }
        }
    }

    fun hideMediaFolder(mediaPathList: List<String>, onComplete: (List<String>) -> Unit) {
        hideFolderFiles(mediaPathList, onComplete)

    }

    fun showLoadingDialog(message: String = "") {
        if (::loadingDialog.isInitialized && !isDestroyed && !isFinishing) {
            if (!loadingDialog.isShowing) {
                loadingDialog.show()
                loadingDialog.setMessage(message)
            }

        }
    }

    fun updateMessageLoadingDialog(message: String) {
        if (::loadingDialog.isInitialized && !isDestroyed && !isFinishing) {
            if (loadingDialog.isShowing) {
                loadingDialog.setMessage(message)
            }
        }
    }

    fun hideLoadingDialog() {
        if (::loadingDialog.isInitialized && !isDestroyed && !isFinishing) {
            if (loadingDialog.isShowing) {
                loadingDialog.dismiss()
            }

        }
    }


    fun openCamera() {
        try {
            val cameraIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            startActivity(cameraIntent)
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
            toast(getString(R.string.no_app_found))
        }
//        ImagesActivity.start(this)
    }

    fun updateShortcuts() {
        /*   if (!checkMediaPermission()) return
           CoroutineScope(Dispatchers.IO).launch {
               val shortcuts = ArrayList<ShortcutInfo>()
               val favorites = sharedViewModel.getFavPaths()
               if (favorites.isNotEmpty()) {
                   val intent = Intent(this@BaseActivity, SplashActivity::class.java).apply {
                       putExtra("id", "id_favourite")
                       putExtra("fromShortcut", true)
                       action = Intent.ACTION_VIEW
                       addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                   }
                   val shortcut = ShortcutInfo.Builder(this@BaseActivity, "id_favourite")
                       .setShortLabel(getString(R.string.Favorite))
                       .setLongLabel(getString(R.string.Favorite))
                       .setIcon(Icon.createWithResource(this@BaseActivity, R.drawable.vec_shortcut_favorite))
                       .setIntent(intent)
                       .build()
                   shortcuts.add(shortcut)
               }
               val intentBin = Intent(this@BaseActivity, SplashActivity::class.java).apply {
                   putExtra("id", "id_recycle_bin")
                   putExtra("fromShortcut", true)
                   action = Intent.ACTION_VIEW
                   addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
               }
               val shortcutBin = ShortcutInfo.Builder(this@BaseActivity, "id_recycle_bin")
                   .setShortLabel(getString(R.string.recycle_bin))
                   .setLongLabel(getString(R.string.recycle_bin))
                   .setIcon(Icon.createWithResource(this@BaseActivity, R.drawable.vec_shortcut_bin))
                   .setIntent(intentBin)
                   .build()
               shortcuts.add(shortcutBin)


               val intentPrivate = Intent(this@BaseActivity, SplashActivity::class.java).apply {
                   putExtra("id", "id_private")
                   putExtra("fromShortcut", true)
                   action = Intent.ACTION_VIEW
                   addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
               }
               val shortcutPrivate = ShortcutInfo.Builder(this@BaseActivity, "id_private")
                   .setShortLabel(getString(R.string.str_private))
                   .setLongLabel(getString(R.string.str_private))
                   .setIcon(Icon.createWithResource(this@BaseActivity, R.drawable.vec_shortcut_private))
                   .setIntent(intentPrivate)
                   .build()
               shortcuts.add(shortcutPrivate)


               val intentCleaner = Intent(this@BaseActivity, SplashActivity::class.java).apply {
                   putExtra("id", "id_cleaner")
                   putExtra("fromShortcut", true)
                   action = Intent.ACTION_VIEW
                   addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
               }
               val shortcutCleaner = ShortcutInfo.Builder(this@BaseActivity, "id_cleaner")
                   .setShortLabel(getString(R.string.duplicate_photos_shortcusts))
                   .setLongLabel(getString(R.string.duplicate_photos_shortcusts))
                   .setIcon(Icon.createWithResource(this@BaseActivity, R.drawable.vec_shortcut_duplicate))
                   .setIntent(intentCleaner)
                   .build()
               shortcuts.add(shortcutCleaner)

               val shortcutManager = getSystemService(ShortcutManager::class.java)
               withContext(Dispatchers.Main) {
                   shortcutManager?.dynamicShortcuts = shortcuts
               }
           }
   */

    }

    fun showHomeMenuFilter(view: TextView) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = HomeMenuFilterBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)

        view.post {
            val location = IntArray(2)
            view.getLocationOnScreen(location)
            val x = location[0] + view.width - 100
            val y = location[1] + view.height

            popupWindow.showAtLocation(view, Gravity.NO_GRAVITY, x, y)
        }

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        popUpBinding.tvAll.setTextColor(getColorCompat(R.color.color_text))
        popUpBinding.tvPhoto.setTextColor(getColorCompat(R.color.color_text))
        popUpBinding.tvVideo.setTextColor(getColorCompat(R.color.color_text))
        popUpBinding.tvGif.setTextColor(getColorCompat(R.color.color_text))

        when (sharedViewModel.getMainMediaFilter()) {
            MainMediaFilter.ALL -> {
                popUpBinding.tvAll.setTextColor(getColorCompat(R.color.color_primary))
            }

            MainMediaFilter.PHOTOS -> {
                popUpBinding.tvPhoto.setTextColor(getColorCompat(R.color.color_primary))

            }

            MainMediaFilter.VIDEO -> {
                popUpBinding.tvVideo.setTextColor(getColorCompat(R.color.color_primary))
            }

            MainMediaFilter.GIF -> {
                popUpBinding.tvGif.setTextColor(getColorCompat(R.color.color_primary))
            }
        }

        popUpBinding.ivAll.setOnClickListener {
            popupWindow.dismiss()
            sharedViewModel.setMainMediaFilter(MainMediaFilter.ALL)
            view.text = getString(R.string.all)
            sharedViewModel.fetchMedia()

        }

        popUpBinding.ivPhoto.setOnClickListener {
            popupWindow.dismiss()
            sharedViewModel.setMainMediaFilter(MainMediaFilter.PHOTOS)
            view.text = getString(R.string.photos)
            sharedViewModel.fetchMedia()
        }

        popUpBinding.ivVideo.setOnClickListener {
            popupWindow.dismiss()
            sharedViewModel.setMainMediaFilter(MainMediaFilter.VIDEO)
            view.text = getString(R.string.videos)
            sharedViewModel.fetchMedia()
        }

        popUpBinding.ivGif.setOnClickListener {
            popupWindow.dismiss()
            sharedViewModel.setMainMediaFilter(MainMediaFilter.GIF)
            view.text = getString(R.string.gifs)
            sharedViewModel.fetchMedia()
        }
    }

    fun onSearchClick() {
        startActivity(SearchActivity.createIntent(this))
    }

    fun getImagePathFromURI(dataUri: Uri, paths: Set<String>): String? {
        val imagePathOriginal = try {
            var path = try {
                getRealPathFromURI(dataUri)
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
            if (path == null)
                path = sharedViewModel.getFilePathFromURI(dataUri)

            if (path.isEmpty() && dataUri.toString().contains("/storage/")) {
                val pathFromStorage = dataUri.path.toString().substringAfter("storage/")
                path = "/storage/$pathFromStorage"
                if (path !in paths) {
                    path = ""
                }
            }
            path
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
        return imagePathOriginal
    }

    fun getFilePathFromUri(context: Context, uri: Uri): String? {
        val fileName = getFileName(context, uri) ?: return null
        val tempFile = File(context.cacheDir, fileName)

        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(tempFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
            return null
        }

        return tempFile.absolutePath
    }

    fun getFileName(context: Context, uri: Uri): String? {
        var name: String? = null
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index != -1) {
                    name = cursor.getString(index)
                }
            }
        }
        return name
    }

    fun moveToHome() {
        sharedViewModel.fetchMedia()
        startActivity(Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        })
        finish()
    }
}