package gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.HiddenAlbumActivity
import gallery.photogallery.photoeditor.galleryapp.bottomSheet.SecurityQuestionDialog
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivitySetLockBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant.EXTRA_CHANGE_PASS
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Preferences


class SetLockActivity : BaseActivity(), View.OnClickListener {

    private val binding by viewBinding(ActivitySetLockBinding::inflate)

    val preferences: Preferences by lazy { Preferences(this) }
    private lateinit var strPass: StringBuilder
    lateinit var animation: Animation
    private var pin = ""
    private var isFromVerifyPin = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding.llToolbar.setPadding(0, statusBarHeight, 0, 0)
        binding.main.setPadding(0, 0, 0, navigationBarHeight)
        setContentView(binding.root)
        initValues()
        initClick()
    }

    private fun initValues() {
        strPass = StringBuilder()
        animation = AnimationUtils.loadAnimation(this, R.anim.anim_shake)
        isFromVerifyPin = intent.getBooleanExtra("isFromVerifyPin", false)
        binding.tvTitle.text = ContextCompat.getString(this, R.string.set_your_PIN)
    }

    private fun initClick() {
        binding.ivBack.setOnClickListener(this)
        binding.btnNo0.setOnClickListener(this)
        binding.btnNo1.setOnClickListener(this)
        binding.btnNo2.setOnClickListener(this)
        binding.btnNo3.setOnClickListener(this)
        binding.btnNo4.setOnClickListener(this)
        binding.btnNo5.setOnClickListener(this)
        binding.btnNo6.setOnClickListener(this)
        binding.btnNo7.setOnClickListener(this)
        binding.btnNo8.setOnClickListener(this)
        binding.btnNo9.setOnClickListener(this)
        binding.btnClear.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v) {

            binding.ivBack -> {
                finish()
            }

            binding.btnNo0 -> {
                strPass.append("0")
                checkPin()
            }

            binding.btnNo1 -> {
                strPass.append("1")
                checkPin()
            }

            binding.btnNo2 -> {
                strPass.append("2")
                checkPin()
            }

            binding.btnNo3 -> {
                strPass.append("3")
                checkPin()
            }

            binding.btnNo4 -> {
                strPass.append("4")
                checkPin()
            }

            binding.btnNo5 -> {
                strPass.append("5")
                checkPin()
            }

            binding.btnNo6 -> {
                strPass.append("6")
                checkPin()
            }

            binding.btnNo7 -> {
                strPass.append("7")
                checkPin()
            }

            binding.btnNo8 -> {
                strPass.append("8")
                checkPin()
            }

            binding.btnNo9 -> {
                strPass.append("9")
                checkPin()
            }

            binding.btnClear -> {
                if (strPass.isNotEmpty()) strPass.deleteCharAt(strPass.length - 1)
                checkPin()
            }
        }
    }


    private fun checkPin() {
        when (strPass.length) {
            0 -> {
                unSelectDot(binding.p1)
                unSelectDot(binding.p2)
                unSelectDot(binding.p3)
                unSelectDot(binding.p4)
            }

            1 -> {
                selectDot(binding.p1)
                unSelectDot(binding.p2)
                unSelectDot(binding.p3)
                unSelectDot(binding.p4)
            }

            2 -> {
                selectDot(binding.p1)
                selectDot(binding.p2)
                unSelectDot(binding.p3)
                unSelectDot(binding.p4)
            }

            3 -> {
                selectDot(binding.p1)
                selectDot(binding.p2)
                selectDot(binding.p3)
                unSelectDot(binding.p4)
            }

            4 -> {
                selectDot(binding.p1)
                selectDot(binding.p2)
                selectDot(binding.p3)
                selectDot(binding.p4)

                if (pin.isEmpty()) {
                    binding.tvTitle.text = ContextCompat.getString(this, R.string.confirm_your_PIN)
                    pin = strPass.toString()
                    strPass.clear()
                    unSelectDot(binding.p1)
                    unSelectDot(binding.p2)
                    unSelectDot(binding.p3)
                    unSelectDot(binding.p4)
                } else {
                    if (pin == strPass.toString()) {
                        Toast.makeText(
                            this,
                            ContextCompat.getString(this, R.string.PIN_set_successfully),
                            Toast.LENGTH_SHORT
                        ).show()
                        if (intent.hasExtra(EXTRA_CHANGE_PASS)) {
                            preferences.putSetPass(true)
                            preferences.putPass(pin)
                            preferences.putSetQuestion(true)
                            finish()
                        } else
                            setQuestion()
                    } else {
                        Handler(Looper.myLooper()!!).postDelayed({
                            strPass.clear()
                        }, 30)
                        Toast.makeText(
                            this,
                            R.string.PIN_not_match,
                            Toast.LENGTH_SHORT
                        ).show()
                        setErrorAnimation(binding.loutPinDots)
                        unSelectDot(binding.p1)
                        unSelectDot(binding.p2)
                        unSelectDot(binding.p3)
                        unSelectDot(binding.p4)
                    }

                }

            }

        }

    }


    private fun unSelectDot(image: AppCompatImageView) {
        image.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_pass_dot_unfill))
    }

    private fun selectDot(image: AppCompatImageView) {
        image.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_pass_dot_fill))
    }

    private fun setErrorAnimation(view: View) {
        view.startAnimation(animation)
    }

    private fun setQuestion() {
        val securityQuestionDialog = SecurityQuestionDialog.newInstance(this, 1) {
            if (it) {
                preferences.putSetPass(true)
                preferences.putPass(pin)
                preferences.putSetQuestion(true)
                if (isFromVerifyPin) {
//                    startActivity(HiddenMediaActivityBaseActivity.createHiddenMediaIntent(this, 0))
                    startActivity(Intent(this, HiddenAlbumActivity::class.java))
                    finish()
                } else {
                    if (intent.hasExtra("setResultCode") && intent.getIntExtra("setResultCode", 0) == 1111) {
                        startActivity(Intent(this, HiddenAlbumActivity::class.java))
                        finish()
                        updateShortcuts()
                    } else {
                        setResult(RESULT_OK, intent)
                    }
                }
                finish()
            }
        }
        securityQuestionDialog.show(supportFragmentManager, "securityQuestionDialog")
    }

//    override fun onBackPressed() {
//        if (isTaskRoot) {
//            /*startActivity(Intent(this, HomeActivity::class.java).apply {
//                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
//            })*/
//            finish()
//        } else {
//            finish()
//        }
//    }

}