package gallery.photogallery.photoeditor.galleryapp.viewlayout

import android.annotation.SuppressLint
import android.app.ActivityOptions
import android.content.Intent
import android.provider.Settings
import androidx.annotation.OptIn
import androidx.core.app.ActivityOptionsCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.util.UnstableApi
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.ScrollGate
import com.appblish.box.api.util.MediaDataState
import com.appblish.medialoader.AppblishImageLoader
import gallery.photogallery.photoeditor.galleryapp.permission.PermissionSDK
import com.appblish.story.memories.api.core.MemorySDK
import com.appblish.story.memories.api.model.MemoryBox
import com.appblish.story.memories.api.model.StoryBox
import gallery.photogallery.photoeditor.galleryapp.activities.MainActivity
import gallery.photogallery.photoeditor.galleryapp.activities.MemorySearchActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.FragmentForYouBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.CreateMemoryDialog
import gallery.photogallery.photoeditor.galleryapp.foryou.ForYouListItem
import gallery.photogallery.photoeditor.galleryapp.foryou.StoryHorizontalAdapter
import gallery.photogallery.photoeditor.galleryapp.foryou.ThumbAdapterForYou
import gallery.photogallery.photoeditor.galleryapp.old.storyview.ExoPlayerCache
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.hasNotificationPermission
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isVideoFast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory.ManageMemoryActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory.MemoryViewerActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory.NewStoryActivity
import gallery.photogallery.photoeditor.galleryapp.permission.PermissionCallback
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ForYouLayout(private val mainActivity: MainActivity, private val binding: FragmentForYouBinding) {
    private val lifecycleScope = mainActivity.lifecycleScope
    private val sharedViewModel = mainActivity.sharedViewModel
    private fun getString(resId: Int) = mainActivity.getString(resId)

    fun setupViews() {
        init()
        checkNotificationPermission()
    }

    fun checkNotificationPermission() {
        binding.flNotification.root.beVisibleIf(!mainActivity.hasNotificationPermission())
    }

    private fun init() {

        setupRecycler()
        setListeners()
        observableStories()
        observableMemories()
        if (PermissionSDK.hasLimitedPhotoAccess(mainActivity)) {
            binding.llHasLimitedAccess.beVisible()
            binding.memoryView.beGone()
        } else {
            binding.llHasLimitedAccess.beGone()
            binding.memoryView.beVisible()
        }
    }

    private fun setupRecycler() {
        val storiesAdaptor = StoryHorizontalAdapter(
            onClick = { _, position, view ->
                view.transitionName = "story_transition"
                val options = ActivityOptions.makeSceneTransitionAnimation(
                    mainActivity, view, "story_transition"
                )

                Intent(mainActivity, NewStoryActivity::class.java).apply {
                    putExtra("storyPosition", position)
                    mainActivity.startActivity(this, options.toBundle())
                }
            }
        )
        binding.rvStories.apply {
            layoutManager = LinearLayoutManager(mainActivity).apply {
                orientation = RecyclerView.HORIZONTAL
            }
            adapter = storiesAdaptor
            itemAnimator = null // smoother updates
        }

        val memoryAdaptor = ThumbAdapterForYou(
            onMemoryClick = { memory, _, view ->
                val options = ActivityOptionsCompat.makeSceneTransitionAnimation(
                    mainActivity, view, // The shared view
                    "image_transition" // The transition name
                )
                Intent(mainActivity, MemoryViewerActivity::class.java).apply {
                    putExtra("memoryId", memory.memoryId)
                    mainActivity.startActivity(this, options.toBundle())
                }
            },
            onMemoryFilterClick = {
                observableMemories()
            }
        )

        binding.forYouRecycler.apply {
            layoutManager = LinearLayoutManager(mainActivity)
            binding.forYouRecycler.adapter = memoryAdaptor
            itemAnimator = null // smoother updates
            binding.forYouRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                    if (newState == RecyclerView.SCROLL_STATE_DRAGGING ||
                        newState == RecyclerView.SCROLL_STATE_SETTLING
                    ) {
                        ScrollGate.onScrollStop()
                    } else {
                        ScrollGate.onScrollStart()
                    }
                }
            })
        }
    }


    @SuppressLint("NewApi")
    private fun setListeners() {
        binding.flNotification.tvAllow.setOnClickListener {

            if (!PermissionSDK.hasNotificationPermission(mainActivity)) {
                PermissionSDK.askNotificationPermission(
                    mainActivity, PermissionCallback(
                        onPermissionResult = { granted ->
                            if (granted) {
                                binding.flNotification.root.beVisibleIf(!mainActivity.hasNotificationPermission())
                            }
                        },
                        onPermissionRationale = {
                            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                                putExtra(Settings.EXTRA_APP_PACKAGE, mainActivity.packageName)
                            }
                            mainActivity.startActivity(intent)
                        }
                    ))
            }

        }

        binding.ivMemorySearch.setOnClickListener {
            mainActivity.startActivity(MemorySearchActivity.createIntent(mainActivity))
        }

        binding.ivCreateMemory.setOnClickListener {
            showCreateMemory()
        }
        binding.ivMemoryAllow.setOnClickListener {
            mainActivity.requestManageAllFile {
                mainActivity.startActivity(Intent(mainActivity, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                })
            }
        }
    }


    fun observableMemories() {
        lifecycleScope.launch {
            val state = MemorySDK.get().getAllMemories()
            when (state) {
                MediaDataState.Empty -> {
                    binding.llPreparingMemory.beGone()
                    binding.llNoMemory.beVisible()
                }

                MediaDataState.Loading -> {
                    binding.llPreparingMemory.beVisible()
                    binding.llNoMemory.beGone()
                }

                is MediaDataState.Success -> {
                    setMemories(state.data)
                }

                is MediaDataState.Progress -> {}
            }
        }
    }

    fun observableStories() {
        lifecycleScope.launch {
            val state = MemorySDK.get().getAllStories()
            when (state) {
                MediaDataState.Empty -> {
                    binding.rvStories.beGone()
                    binding.llNoStory.beVisible()
                }

                MediaDataState.Loading -> {
                    binding.rvStories.beGone()
                    binding.llNoStory.beVisible()
                }

                is MediaDataState.Success -> {
                    setStories(state.data)
                }

                is MediaDataState.Progress -> {}
            }
        }

    }

    fun setStories(stories: List<StoryBox>) {
        lifecycleScope.launch {
            (binding.rvStories.adapter as? StoryHorizontalAdapter)?.submitList(stories)
            binding.rvStories.beVisible()
            binding.llNoStory.beGone()
            if (binding.rvStories.tag == null && stories.isNotEmpty()) {
                binding.rvStories.tag = 1
                CoroutineScope(Dispatchers.IO).launch {
                    val mediaLists = stories.flatMap { it.mediaList }
                    val mediaListsToPair = mediaLists.mapNotNull {
                        try {
                            Pair(it.mediaPath, it.mediaDate)
                        } catch (_: Exception) {
                            null
                        }
                    }
                    AppblishImageLoader.preCacheImages(
                        mainActivity.applicationContext,
                        mediaListsToPair,
                    ) {

                    }
                }
            }
        }
        cacheVideo(stories)
    }

    fun setMemories(memories: List<MemoryBox>) {
        val memoryStoriesData: ArrayList<ForYouListItem> = ArrayList()
        memoryStoriesData.add(ForYouListItem.Header)
        for (memory in memories.asSequence()) {
            memoryStoriesData.add(ForYouListItem.Memory(memory))
        }
        (binding.forYouRecycler.adapter as? ThumbAdapterForYou)?.submitList(memoryStoriesData)
        binding.forYouRecycler.beVisible()
        binding.llPreparingMemory.beGone()
        binding.llNoMemory.beGone()
        if (binding.forYouRecycler.tag == null && memories.isNotEmpty()) {
            binding.forYouRecycler.tag = 1
            CoroutineScope(Dispatchers.IO).launch {
                val mediaLists = memories.flatMap { it.mediaList }
                val mediaListsToPair = mediaLists.mapNotNull {
                    try {
                        Pair(it.mediaPath, it.mediaDate)
                    } catch (_: Exception) {
                        null
                    }
                }
                AppblishImageLoader.preCacheImages(
                    mainActivity.applicationContext,
                    mediaListsToPair,
                ) {

                }
            }
        }

    }

    @OptIn(UnstableApi::class)
    private fun cacheVideo(stories: List<StoryBox>) {
        CoroutineScope(Dispatchers.IO).launch {
            val videoPaths = stories.flatMap { it.mediaList }.map { it }.filter { it.mediaPath.isVideoFast() }
            videoPaths.forEach {
                ExoPlayerCache.cacheVideo(mainActivity, it.mediaPath)
            }
        }
    }

    private fun showCreateMemory() {
        val createDialog = CreateMemoryDialog()
        createDialog.createListener = { newMemory ->
            mainActivity.startActivity(Intent(mainActivity, ManageMemoryActivity::class.java).apply {
                putExtra("isCreateMemory", true)
                putExtra("title", newMemory)
            })
        }

        createDialog.show(mainActivity.supportFragmentManager, "createDialog.tag")
    }

    fun onResume() {
        binding.flNotification.root.beVisibleIf(!mainActivity.hasNotificationPermission())
    }
}