package gallery.photogallery.photoeditor.galleryapp.old.ui.main.custom

import android.content.Context
import android.util.AttributeSet
import com.google.android.material.imageview.ShapeableImageView

class MySquareImageView : ShapeableImageView {
    var isHorizontalScrolling = false

    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)

    constructor(context: Context, attrs: AttributeSet, defStyle: Int) : super(context, attrs, defStyle)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val spec = if (isHorizontalScrolling) heightMeasureSpec else widthMeasureSpec
        super.onMeasure(spec, spec)
    }
}
