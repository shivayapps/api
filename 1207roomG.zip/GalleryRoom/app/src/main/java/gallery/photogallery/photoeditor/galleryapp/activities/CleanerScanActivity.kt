package gallery.photogallery.photoeditor.galleryapp.activities

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import com.appblish.box.api.util.AppblishEvent
import com.appblish.box.api.util.MediaDataState
import com.cleaner.v2.api.core.CleanerSDK
import com.cleaner.v2.api.model.CleanerListItem
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.collage.utils.CollageConst.formatSize
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityCleanerScanBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.isVisible
import gallery.photogallery.photoeditor.galleryapp.extentions.setColor
import gallery.photogallery.photoeditor.galleryapp.extentions.setFont
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class CleanerScanActivity : BaseActivity() {
    private val binding by viewBinding(ActivityCleanerScanBinding::inflate)
    private var photoBytes = 0L
    private var videoBytes = 0L
    private var screenshotBytes = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContentView(binding.root)
        binding.main.setPadding(0, statusBarHeight, 0, 0)
        registerEventBus(this)
        init()
        clickListener()
    }

    private fun init() {
        CleanerSDK.get().startScanning(this)
        getPhotos()
        getVideo()
        getScreenshots()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            AppblishEvent.CLEANER_PROCESS -> {
                val percent = intent.getIntExtra(AppblishEvent.CLEANER_PROCESS, 0)
                binding.txtAllPercentage.text = "${percent}%"
                binding.llPercentageOne.beVisible()
                binding.llFinishPercentage.beGone()
                if (percent == 100) {
                    binding.llPercentageOne.beGone()
                    binding.llFinishPercentage.beVisible()
                    getPhotos()
                    getVideo()
                    getScreenshots()
                } else {
                    binding.txtPhotos.text = ""
                    binding.txtLargeVideo.text = ""
                    binding.txtScreenshotSize.text = ""
                }
            }

            AppblishEvent.ALL_CLEANER_LOADED -> {
                getPhotos()
                getVideo()
                getScreenshots()
            }
        }
    }

    override fun onBackPressed() {
        CleanerSDK.get().stopScanning()
        super.onBackPressed()
    }

    override fun onDestroy() {
        unregisterEventBus(this)
        CleanerSDK.get().stopScanning()
        super.onDestroy()
    }


    private fun getPhotos() {
        lifecycleScope.launch {
            val state = CleanerSDK.get().getDuplicateMedias()
            when (state) {
                is MediaDataState.Loading -> {
                }

                is MediaDataState.Progress -> {

                }

                is MediaDataState.Success -> {

                    val data = state.data
                    photoBytes = state.data.totalSize()
                    val totalBytes = data
                        .filterIsInstance<CleanerListItem.Header>()
                        .sumOf { it.totalSize }

                    binding.ivPhotosArrow.beVisible()
                    binding.txtPhotos.text = formatSize(totalBytes)
                    binding.txtPhotos.setColor(R.color.color_primary)
                    binding.txtPhotos.setFont(R.font.lato_bold)
                }


                MediaDataState.Empty -> {

                }
            }
        }
    }

    private fun List<CleanerListItem>.totalSize(): Long {
        return filterIsInstance<CleanerListItem.Header>()
            .sumOf { it.totalSize }
    }

    private fun getVideo() {
        lifecycleScope.launch {
            val state = CleanerSDK.get().getLargeVideos()
            when (state) {
                is MediaDataState.Loading -> {
                }

                is MediaDataState.Progress -> {
                }

                is MediaDataState.Success -> {
                    val data = state.data
                    videoBytes = state.data.totalSize()
                    val totalBytes = data
                        .filterIsInstance<CleanerListItem.Header>()
                        .sumOf { it.totalSize }
                    binding.ivRightArrowVideo.beVisible()
                    binding.txtLargeVideo.text = formatSize(totalBytes)
                    binding.txtLargeVideo.setColor(R.color.color_primary)
                    binding.txtLargeVideo.setFont(R.font.lato_bold)
                }


                MediaDataState.Empty -> {}
            }
        }
    }

    private fun getScreenshots() {
        lifecycleScope.launch {
            val state = CleanerSDK.get().getScreenshotMedias()
            when (state) {
                is MediaDataState.Loading -> {
                }

                is MediaDataState.Progress -> {

                }

                is MediaDataState.Success -> {
                    val data = state.data
                    screenshotBytes = state.data.totalSize()
                    val totalBytes = data
                        .filterIsInstance<CleanerListItem.Header>()
                        .sumOf { it.totalSize }


                    binding.ivRightArrowScreenshot.beVisible()
                    binding.txtScreenshotSize.text = formatSize(totalBytes)
                    binding.txtScreenshotSize.setColor(R.color.color_primary)
                    binding.txtScreenshotSize.setFont(R.font.lato_bold)
                }

                MediaDataState.Empty -> {}
            }
        }
    }

    private fun clickListener() {
        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

        binding.llCleanUpPhotos.setOnClickListener {
            if (binding.llPercentageOne.isVisible) {
                toast(getString(R.string.scanning))
                return@setOnClickListener
            }
            val intent = Intent(this, CleanerScanDeleteActivity::class.java)
            intent.putExtra("CLEAN_UP_PHOTO", 1)
            startActivity(intent)
        }

        binding.llCleanLargeVideo.setOnClickListener {
            if (binding.llPercentageOne.isVisible) {
                toast(getString(R.string.scanning))
                return@setOnClickListener
            }
            val intent = Intent(this, CleanerScanDeleteActivity::class.java)
            intent.putExtra("CLEAN_UP_PHOTO", 2)
            startActivity(intent)
        }

        binding.llCleanSS.setOnClickListener {
            if (binding.llPercentageOne.isVisible) {
                toast(getString(R.string.scanning))
                return@setOnClickListener
            }
            val intent = Intent(this, CleanerScanDeleteActivity::class.java)
            intent.putExtra("CLEAN_UP_PHOTO", 3)
            startActivity(intent)
        }
    }
}