package gallery.photogallery.photoeditor.galleryapp.utils.spancounthelper

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class GridHelperView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    // Base transparency
    private var baseAlpha = 80

    private val linePaint = Paint().apply {
        color = 0xFFFFFFFF.toInt()
        alpha = baseAlpha
        style = Paint.Style.STROKE
        strokeWidth = 3f // Thicker for better visuals
    }

    private val fillPaint = Paint().apply {
        color = 0xFFFFFFFF.toInt()
        alpha = 25
        style = Paint.Style.FILL
    }

    private var ghostRect: RectF? = null

    // FLASH ANIMATION: Make grid white for a split second
    fun flash() {
        val animator = ValueAnimator.ofInt(255, baseAlpha)
        animator.duration = 300
        animator.addUpdateListener {
            val alpha = it.animatedValue as Int
            linePaint.alpha = alpha
            // Pulse filled boxes too
            fillPaint.alpha = (alpha * 0.4).toInt()
            invalidate()
        }
        animator.start()
    }

    fun updateGrid(rect: RectF) {
        this.ghostRect = rect
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val rect = ghostRect ?: return
        val w = rect.width()
        val h = rect.height()

        if (w <= 0 || h <= 0) return
        val screenW = width.toFloat()
        val screenH = height.toFloat()

        // Draw Neighbors (Filled)
        canvas.drawRect(rect.left, rect.top - h, rect.right, rect.top, fillPaint) // Top
        canvas.drawRect(rect.left, rect.bottom, rect.right, rect.bottom + h, fillPaint) // Bottom
        canvas.drawRect(rect.left - w, rect.top, rect.left, rect.bottom, fillPaint) // Left
        canvas.drawRect(rect.right, rect.top, rect.right + w, rect.bottom, fillPaint) // Right

        // Draw Grid Lines (Extending Out)
        // Left
        var x = rect.left
        while (x >= 0) {
            canvas.drawLine(x, 0f, x, screenH, linePaint)
            x -= w
        }
        // Right
        x = rect.right
        while (x <= screenW) {
            canvas.drawLine(x, 0f, x, screenH, linePaint)
            x += w
        }
        // Top
        var y = rect.top
        while (y >= 0) {
            canvas.drawLine(0f, y, screenW, y, linePaint)
            y -= h
        }
        // Bottom
        y = rect.bottom
        while (y <= screenH) {
            canvas.drawLine(0f, y, screenW, y, linePaint)
            y += h
        }
    }
}