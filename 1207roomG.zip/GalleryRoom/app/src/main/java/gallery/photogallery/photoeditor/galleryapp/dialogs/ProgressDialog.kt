package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager
import com.appblish.box.api.model.ScrollGate
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogProgressBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.DONE_MEDIA_OPERATION
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.OperationEvent
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.PROGRESS_MEDIA_OPERATION
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class ProgressDialog : DialogFragment() {
    companion object {
        fun show(
            fragmentManager: FragmentManager,
            maxProgress: Int,
            txtTitle: String,
        ) {

            val progressDialog = ProgressDialog()
            progressDialog.arguments = Bundle().apply {
                putInt("maxProgress", maxProgress)
                putString("txtTitle", txtTitle)
            }
            progressDialog.show(fragmentManager, "ProgressDialog")
            ScrollGate.onScrollStart()
        }
    }

    private var _binding: DialogProgressBinding? = null
    private val binding get() = _binding!!

    private val totalCounts: Int by lazy { arguments?.getInt("maxProgress", 0) ?: 0 }
    private val txtTitle: String by lazy { arguments?.getString("txtTitle", "") ?: "" }

    @SuppressLint("SetTextI18n")
    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: OperationEvent) {
        when (event.type) {
            PROGRESS_MEDIA_OPERATION -> {
                val data = event.data as? Pair<Int, Int>
                if (data != null) {
                    setProgress(data.first, data.second)
                    binding.txtProgressCount.text = data.second.toString() + " / " + totalCounts
                    binding.tvPercentage.text = data.first.toString().plus(" %")
                    binding.progressBar.progress = data.first
                    binding.progressBar.max = 100
                    binding.progressBar.isIndeterminate = false
                } else {
                    val data = event.data as? Int
                    if (data != null) {
                        Log.e("PROGRESS_MEDIA_OPERATION", "onMessageEvent: $data")
                        binding.txtProgressCount.text = "$data%"
                        binding.progressBar.progress = data
                        binding.progressBar.max = 100
                        binding.progressBar.isIndeterminate = false
                    }
                }
            }

            DONE_MEDIA_OPERATION -> {
                ScrollGate.onScrollStop()
                if (isAdded)
                    dismiss()
            }
        }

    }

    fun setProgress(progress: Int, size: Int) {
        binding.txtProgressCount.text = (progress - 1).toString() + "/" + size.toString()
        binding.tvPercentage.text = progress.toString().plus(" %")
        binding.progressBar.progress = progress
        binding.progressBar.isIndeterminate = false
        Log.e("ProgressDialog", "setProgress:$progress")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        isCancelable = false
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogProgressBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(requireContext().getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        intView()
        return dialog
    }

    override fun onDestroy() {
        super.onDestroy()
        if (EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().unregister(this)
    }

    private fun intView() {
        binding.progressBar.isIndeterminate = true
        binding.txtTitle.text = txtTitle
        binding.progressBar.progress = 0
        if (totalCounts > 0) binding.progressBar.max = totalCounts
        else binding.progressBar.isIndeterminate = true
    }
}