package gallery.photogallery.photoeditor.galleryapp.old.storyview.utils

interface PageViewOperator {
    fun backPageView()
    fun nextPageView()
}