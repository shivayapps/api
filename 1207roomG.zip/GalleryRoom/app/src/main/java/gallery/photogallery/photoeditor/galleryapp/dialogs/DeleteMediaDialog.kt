package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogDeleteBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.applySystemBarAppearanceByTheme

class DeleteMediaDialog(var btnClickListener: ((isPermanent: Boolean) -> Unit)? = null) : BottomSheetDialogFragment() {

    private var _binding: DialogDeleteBinding? = null
    private val binding get() = _binding!!


    override fun getTheme(): Int = R.style.CustomBottomSheetDialog

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = DialogDeleteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dialog?.applySystemBarAppearanceByTheme()

        initView()
    }

    private fun initView() {
        binding.txtRestoredMsg.visibility = View.GONE
//        binding.btnCancel.setOnClickListener { dismiss() }
        binding.btnTrash.setOnClickListener {
            dismiss()
            btnClickListener?.invoke(false) /*false is trash*/
        }
        binding.btnPermanent.setOnClickListener {
            dismiss()
            btnClickListener?.invoke(true) /*true is delete*/
        }
    }
}