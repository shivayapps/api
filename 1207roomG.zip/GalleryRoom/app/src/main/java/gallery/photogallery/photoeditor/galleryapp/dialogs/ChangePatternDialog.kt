package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.BottomSheetChangePatternBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction

class ChangePatternDialog : DialogFragment() {
    private var _binding: BottomSheetChangePatternBinding? = null

    private val binding get() = _binding!!
    private lateinit var safeContext: Context

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = BottomSheetChangePatternBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER) // remove if you want center dialog
        }
        initView()
        clickListener()
        return dialog
    }

    private fun initView() {
        selectPin()
    }

    private fun selectFingerprint() {
        binding.rbPin.isChecked = false
        binding.rbFingerprint.isChecked = true

//        binding.cardFingerprint.strokeWidth = 6
//        binding.cardFingerprint.strokeColor = "#2979FF".toColorInt()
//        binding.cardFingerprint.setCardBackgroundColor("#FFFFFF".toColorInt())
//
//        binding.cardPin.strokeWidth = 0
//        binding.cardPin.setCardBackgroundColor("#F3F4F6".toColorInt())
//        binding.cardPin.strokeColor = "#DDDDDD".toColorInt()

        binding.cardFingerprint.strokeWidth = 6
        binding.cardFingerprint.strokeColor = ContextCompat.getColor(requireContext(), R.color.color_lock_stroke_finger)
        binding.cardFingerprint.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.color_lock_stroke_finger_bg))

        binding.cardPin.strokeWidth = 0
        binding.cardPin.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.color_lock_stroke_pin_bg))
        binding.cardPin.strokeColor = ContextCompat.getColor(requireContext(), R.color.color_lock_stroke_pin)
    }

    private fun selectPin() {
        binding.rbPin.isChecked = true
        binding.rbFingerprint.isChecked = false

//        binding.cardPin.strokeWidth = 6
//        binding.cardPin.strokeColor = "#2979FF".toColorInt()
//
//        binding.cardFingerprint.strokeWidth = 0
//        binding.cardFingerprint.setCardBackgroundColor("#F3F4F6".toColorInt())
//        binding.cardPin.setCardBackgroundColor("#FFFFFF".toColorInt())
//        binding.cardFingerprint.strokeColor = "#DDDDDD".toColorInt()

        binding.cardPin.strokeWidth = 6
        binding.cardPin.strokeColor = ContextCompat.getColor(requireContext(), R.color.color_lock_stroke_finger)

        binding.cardFingerprint.strokeWidth = 0
        binding.cardFingerprint.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.color_lock_stroke_pin_bg))
        binding.cardPin.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.color_lock_stroke_finger_bg))
        binding.cardFingerprint.strokeColor = ContextCompat.getColor(requireContext(), R.color.color_lock_stroke_pin)
    }

    private fun clickListener() {
        binding.cardPin.setOnClickListener {
            selectPin()
        }

        binding.cardFingerprint.setOnClickListener {
            selectFingerprint()
        }
    }
}