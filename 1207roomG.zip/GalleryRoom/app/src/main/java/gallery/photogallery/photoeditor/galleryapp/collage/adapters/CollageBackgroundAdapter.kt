package gallery.photogallery.photoeditor.galleryapp.collage.adapters


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import gallery.photogallery.photoeditor.galleryapp.R


class CollageBackgroundAdapter(
    private val drawables: List<Int>,
    private val onItemClick: (position: Int,  resId: Int) -> Unit
) : RecyclerView.Adapter<CollageBackgroundAdapter.ViewHolder>() {

    private var selectedIndex = RecyclerView.NO_POSITION

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_background, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val drawable = drawables[position]

        holder.imageViewSquare.visibility = View.VISIBLE
        holder.squareView.visibility = View.GONE
        holder.imageViewSquare.setImageResource(drawable)

        holder.viewSelected.visibility =
            if (position == selectedIndex) View.VISIBLE else View.GONE

        holder.itemView.setOnClickListener {
            setSelectedIndex(position)
            onItemClick(position, drawable)
        }
    }

    override fun getItemCount(): Int = drawables.size

    fun setSelectedIndex(index: Int) {
        if (index == selectedIndex) return

        val oldIndex = selectedIndex
        selectedIndex = index

        if (oldIndex != RecyclerView.NO_POSITION) {
            notifyItemChanged(oldIndex)
        }
        notifyItemChanged(selectedIndex)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageViewSquare: ImageView = itemView.findViewById(R.id.image_view_square)
        val squareView: View = itemView.findViewById(R.id.square_view)
        val viewSelected: View = itemView.findViewById(R.id.view_selected)
    }
}
