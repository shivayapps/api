package gallery.photogallery.photoeditor.galleryapp.popup_menu

import android.content.Intent
import android.content.res.Resources
import android.graphics.Color
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupWindow
import androidx.core.graphics.drawable.toDrawable
import gallery.photogallery.photoeditor.galleryapp.activities.MainActivity
import gallery.photogallery.photoeditor.galleryapp.activities.SettingActivity
import gallery.photogallery.photoeditor.galleryapp.activities.TrashActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.PopupPhotosMenuBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.ColumnsCountDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.GroupByDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.SortByMediaDialog


class PhotosMenuPopup(
    private val mainActivity: MainActivity,
) {

    private var popup: PopupWindow? = null

    fun show(anchor: View) {

        val context = anchor.context
        val binding = PopupPhotosMenuBinding.inflate(
            LayoutInflater.from(context)
        )

        popup = PopupWindow(
            binding.root,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        ).apply {
//            elevation = 12f
            isOutsideTouchable = true
            setBackgroundDrawable(Color.TRANSPARENT.toDrawable())
        }


        binding.btnSortBy.setOnClickListener {
            popup?.dismiss()
            SortByMediaDialog {
                mainActivity.sharedViewModel.fetchMedia()
            }.show(mainActivity.supportFragmentManager, "SortByDialog")
        }

        binding.btnGroupBy.setOnClickListener {
            popup?.dismiss()
            GroupByDialog {
                mainActivity.sharedViewModel.refreshMedia()
            }.show(mainActivity.supportFragmentManager, "GroupByDialog")
        }

        binding.btnDisplayedColumns.setOnClickListener {
            popup?.dismiss()
            ColumnsCountDialog(false).show(mainActivity.supportFragmentManager, "ColumnsCountDialog")
        }

        binding.btnRecycleBin.setOnClickListener {
            popup?.dismiss()
            context.startActivity(
                Intent(context, TrashActivity::class.java)
            )
        }

        binding.btnSetting.setOnClickListener {
            popup?.dismiss()
            context.startActivity(
                Intent(context, SettingActivity::class.java)
            )
        }

        // -------- Show popup --------
        binding.root.measure(
            View.MeasureSpec.UNSPECIFIED,
            View.MeasureSpec.UNSPECIFIED
        )

        val popupWidth = binding.root.measuredWidth
        val marginRight = 16.dpToPx()

        // Get anchor position
        val location = IntArray(2)
        anchor.getLocationOnScreen(location)

        val screenWidth = Resources.getSystem().displayMetrics.widthPixels

        // Calculate X position (from right edge)
        val x = screenWidth - popupWidth - marginRight

        // Show below anchor
        val y = location[1] + anchor.height

        popup?.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y)
    }

    private fun Int.dpToPx(): Int {
        return (this * Resources.getSystem().displayMetrics.density).toInt()
    }
}
