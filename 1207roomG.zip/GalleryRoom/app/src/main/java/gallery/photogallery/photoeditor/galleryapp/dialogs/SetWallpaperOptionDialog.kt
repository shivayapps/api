package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.databinding.BottomSheetWallpaperBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant

class SetWallpaperOptionDialog() : DialogFragment() {
    private var _binding: BottomSheetWallpaperBinding? = null
    private val binding get() = _binding!!

    var setWallpaperClick: ((renameFile: Int) -> Unit)? = null
    private lateinit var safeContext: Context

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = BottomSheetWallpaperBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        clickListener()

        return dialog
    }

    private fun clickListener() {
        binding.rgTheme.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                binding.rbSystem.id -> {
                    setWallpaperClick?.invoke(1)
                }

                binding.rbLight.id -> {
                    Constant.THEME_LIGHT
                    setWallpaperClick?.invoke(2)
                }

                binding.rbDark.id -> {
                    Constant.THEME_DARK
                    setWallpaperClick?.invoke(3)
                }

                else -> return@setOnCheckedChangeListener
            }

            dismiss()
        }
    }
}