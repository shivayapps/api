package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogRenameAlbumBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import java.io.File

class RenameAlbumDialog(val activity: Activity) : DialogFragment() {

    private var _binding: DialogRenameAlbumBinding? = null
    private val binding get() = _binding!!

    var positiveBtnClickListener: ((renameFile: File, oldFile: File) -> Unit)? = null

    //    lateinit var albumModel: AlbumBox
    lateinit var bucketPath: String
    private lateinit var safeContext: Context

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogRenameAlbumBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }

        intView()
        intListener()
        showKeyboard()

        return dialog
    }
    private fun intView() {
        binding.edtName.setText(File(bucketPath).name)
        binding.edtName.requestFocus()
    }

    private fun intListener() {
        binding.edtName.addTextChangedListener {
            binding.icClear.visibility = if (binding.edtName.text?.trim().toString()
                    .isNotEmpty()
            ) View.VISIBLE else View.GONE
        }
        binding.icClear.setOnClickListener {
            binding.edtName.setText("")
        }
        binding.btnCancel.setOnClickListener {
            hideKeyboard()
            dismiss()
        }

        binding.btnRename.setOnClickListener {

            val strNewFileName = binding.edtName.text.toString().trim()
            if (strNewFileName.isNotEmpty()) {
                val oldFile = File(bucketPath)
                if (oldFile.name == strNewFileName) {
                    hideKeyboard()
                    dismiss()
                    return@setOnClickListener
                }
                val renameFile = File(oldFile.parentFile!!.absolutePath, strNewFileName)
                if (!renameFile.exists()) {
                    hideKeyboard()
                    dismiss()
                    positiveBtnClickListener?.invoke(renameFile, oldFile)
                } else {
                    activity.toast(activity.getString(R.string.rename_validation2))
                }
            } else {
                activity.toast(activity.getString(R.string.rename_validation))
            }
        }
    }


    private fun showKeyboard() {
        binding.btnRename.requestFocus()
        val methodManager = (activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(binding.btnRename, InputMethodManager.SHOW_IMPLICIT)
    }

    fun hideKeyboard() {
        binding.edtName.clearFocus()
        binding.btnRename.clearFocus()
        val methodManager = (activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(binding.btnRename.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }


    fun String.getFilenameExtension() = substring(lastIndexOf(".") + 1)
    fun String.getCompressionFormat() = when (getFilenameExtension().lowercase()) {
        "png" -> Bitmap.CompressFormat.PNG
        "webp" -> Bitmap.CompressFormat.WEBP
        else -> Bitmap.CompressFormat.JPEG
    }

}