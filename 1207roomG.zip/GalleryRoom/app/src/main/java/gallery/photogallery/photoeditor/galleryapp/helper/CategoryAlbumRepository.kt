//package gallery.photogallery.photoeditor.galleryapp.helper
//
//import gallery.photogallery.photoeditor.galleryapp.ml.db.ImageLabelWithMediaEntity
//import gallery.photogallery.photoeditor.galleryapp.model.CategoryAlbumModel
//import gallery.photogallery.photoeditor.galleryapp.room.dao.CategoryDao
//import kotlinx.coroutines.*
//import java.util.concurrent.atomic.AtomicReference
//import kotlin.collections.isNullOrEmpty
//
//class CategoryAlbumRepository(
//    private val dao: CategoryDao
//) {
//
//    // Prevent CPU starvation
//    private val CPU_DISPATCHER =
//        Dispatchers.Default.limitedParallelism(2)
//
//    // In-memory cache
//    private val cache =
//        AtomicReference<List<CategoryAlbumModel>?>(null)
//
//    /**
//     * Public API
//     * Safe to call from Main thread
//     */
//    suspend fun loadTopCategoryAlbums(
//        limit: Int = 10
//    ): List<CategoryAlbumModel> {
//
//        // Return cached if available
//        cache.get()?.let { return it }
//
//        return withContext(Dispatchers.IO) {
//
//            // 1️⃣ DB work only
//            val categories = dao.getAllCategoryRemoteEntity()
//            val labels = dao.getAllImageWithLabelsMedia()
//
//            // 2️⃣ CPU heavy work
//            withContext(CPU_DISPATCHER) {
//
//                coroutineContext.ensureActive()
//
//                val labelIndex = buildLabelIndex(labels)
//                val result = ArrayList<CategoryAlbumModel>(limit)
//
//                for (category in categories.asSequence()) {
//                    coroutineContext.ensureActive()
//
//                    val key = category.categoryName.lowercase()
//                    val matched = labelIndex[key]
//
//                    if (!matched.isNullOrEmpty()) {
//                        result.add(
//                            CategoryAlbumModel(
//                                title = category.categoryName,
//                                mediaList = matched
//                            )
//                        )
//
//                        if (result.size == limit) break
//                    }
//                }
//
//                cache.set(result)
//                result
//            }
//        }
//    }
//
//    /**
//     * Clears memory cache
//     */
//    fun clearCache() {
//        cache.set(null)
//    }
//
//    /**
//     * Build O(1) lookup index
//     */
//    private fun buildLabelIndex(
//        labels: List<ImageLabelWithMediaEntity>
//    ): Map<String, MutableList<ImageLabelWithMediaEntity>> {
//
//        val index =
//            HashMap<String, MutableList<ImageLabelWithMediaEntity>>(1024)
//
//        for (label in labels) {
//
//            val entity = label.imageLabelEntity
//
//            entity.mainCategories.forEach { category ->
//                val key = category.lowercase()
//                index.getOrPut(key) { mutableListOf() }.add(label)
//            }
//
//            // Optional: include mainCategory
//            val main = entity.mainCategory.lowercase()
//            index.getOrPut(main) { mutableListOf() }.add(label)
//        }
//
//        return index
//    }
//}
