package gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.hardware.biometrics.BiometricManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.bottomSheet.BiometricErrorDialog
import gallery.photogallery.photoeditor.galleryapp.bottomSheet.SecurityQuestionDialog
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogPrivateMenuBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.custom.SwitchButton
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isBiometricIdAvailable
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isSupportWithErrorInfo
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.newNavigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.isAboveAndroid11
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.SetLockActivity

class PrivateMenuDialog(val activity: AppCompatActivity) : Dialog(activity) {
    lateinit var binding: DialogPrivateMenuBinding
    private lateinit var biometricLauncher: ActivityResultLauncher<Intent>

    companion object {
        fun newInstance(activity: AppCompatActivity): PrivateMenuDialog {
            val menuDialog = PrivateMenuDialog(activity)
            return menuDialog
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        binding = DialogPrivateMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )

        binding.root.setPadding(0, 0, 0, activity.newNavigationBarHeight)
        intView()

    }


    private var isFingerprintAvailable = Pair(false, "")
    private fun intView() {
        biometricLauncher = activity.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            isFingerprintAvailable = activity.isSupportWithErrorInfo(activity, androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG)
            if (isFingerprintAvailable.first) {
                activity.preferences.enableFingerprint = true
            } else {
                activity.preferences.enableFingerprint = false
            }
        }
        val isSupportFingerprint = activity.isBiometricIdAvailable()
        isFingerprintAvailable = activity.isSupportWithErrorInfo(activity, BiometricManager.Authenticators.BIOMETRIC_STRONG)
        binding.btnFingerprint.beVisibleIf(isSupportFingerprint)
        intListener()
    }

    private fun intListener() {
        binding.btnChangePass.setOnClickListener {
            dismiss()
            val intent = Intent(activity, SetLockActivity::class.java)
            intent.putExtra(Constant.EXTRA_CHANGE_PASS, true)
            activity.startActivity(intent)
        }
        binding.btnChangeQue.setOnClickListener {
            dismiss()
            val securityQuestionDialog = SecurityQuestionDialog.newInstance(activity, 0, true, true) {
                if (it) {
                    Toast.makeText(
                        activity, activity.getString(R.string.security_question_changed), Toast.LENGTH_SHORT
                    ).show()
                }
            }
            securityQuestionDialog.show(activity.supportFragmentManager, "securityQuestionDialog")
        }
        binding.sbFingerprint.isChecked = activity.preferences.enableFingerprint && isFingerprintAvailable.first
        binding.sbFingerprint.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                dismiss()
                enableFingure(isChecked)

            }
        })
    }

    private fun enableFingure(isChecked: Boolean) {
        if (isChecked) {
            if (isFingerprintAvailable.first) {
                activity.preferences.enableFingerprint = true
            } else {
                val biometricErrorDialog = BiometricErrorDialog(activity) { isEnable ->
                    if (isEnable) {
                        val enrollIntent = Intent(Settings.ACTION_BIOMETRIC_ENROLL)
                        enrollIntent.putExtra(
                            Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED, androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
                        )
                        biometricLauncher.launch(enrollIntent)
                    } else {
//                                            binding.sbFingerprint.isChecked = false
                        activity.preferences.enableFingerprint = false
                    }

                }
                activity.preferences.enableFingerprint = false
                biometricErrorDialog.show(activity.supportFragmentManager, "BiometricErrorDialog")
            }
        } else {
            activity.preferences.enableFingerprint = false
        }
    }
    override fun show() {
        super.show()
        if (isAboveAndroid11()) {
            window?.apply {

                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                decorView.systemUiVisibility = (
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        )
            }
        }


        window?.navigationBarColor = ContextCompat.getColor(activity, R.color.night_bg_color)
        val controller = WindowCompat.getInsetsController(window!!, window!!.decorView)
        controller.isAppearanceLightNavigationBars = false

    }
}