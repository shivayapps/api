package gallery.photogallery.photoeditor.galleryapp.dialogs

interface SafeDismissable {
    fun safeDismissRedirectDialog()
}
