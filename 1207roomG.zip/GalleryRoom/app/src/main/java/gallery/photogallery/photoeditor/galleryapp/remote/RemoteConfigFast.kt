package gallery.photogallery.photoeditor.galleryapp.remote

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.core.content.edit
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.google.firebase.remoteconfig.remoteConfigSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

object RemoteConfigFast {
    // ----------------------------------
    // CONFIG
    // ----------------------------------
    private const val PREF_NAME = "remote_config_pref"
    private const val DEFAULT_TIMEOUT = 1200L
    private const val PREF_LAST_FETCH = "_last_fetch_time"
    private const val REFRESH_INTERVAL = 6 * 60 * 60 * 1000L // 6h

    // ----------------------------------
    // CORE
    // ----------------------------------
    private lateinit var prefs: SharedPreferences
    private val rc by lazy { FirebaseRemoteConfig.getInstance() }

    // ----------------------------------
    // CACHE
    // ----------------------------------
    val boolCache = ConcurrentHashMap<String, Boolean>()
    private val stringCache = ConcurrentHashMap<String, String>()
    private val jsonCache = ConcurrentHashMap<String, JSONObject?>()

    // ----------------------------------
    // INIT (CALL ONCE)
    // ----------------------------------
    fun init(context: Context) {
        prefs = context.applicationContext
            .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        restoreFromPrefs()
        init()
    }

    // ----------------------------------
    // FIRE-AND-FORGET PRELOAD
    // ----------------------------------
    private fun preloadFast() {
        CoroutineScope(Dispatchers.IO).launch {
            val configSettings = remoteConfigSettings {
                minimumFetchIntervalInSeconds = 0
            }
            rc.setConfigSettingsAsync(configSettings)
            rc.fetchAndActivate()
        }
    }


    private fun shouldRefresh(): Boolean {
        val last = prefs.getLong(PREF_LAST_FETCH, 0L)
        return System.currentTimeMillis() - last > REFRESH_INTERVAL
    }

    fun getString(key: String, fallback: String = ""): String =
        stringCache[key] ?: prefs.getString(key, fallback) ?: fallback

    fun getJson(key: String): JSONObject? {
        jsonCache[key]?.let { return it }
        return prefs.getString(key, null)?.let {
            try {
                JSONObject(it)
            } catch (_: Exception) {
                null
            }
        }
    }

    // ==================================================
    // SINGLE LOAD METHOD
    // ==================================================
    sealed class RcField<T>(val key: String, val fallback: T) {
        class Bool(key: String, fallback: Boolean = false) :
            RcField<Boolean>(key, fallback)

        class Str(key: String, fallback: String = "") :
            RcField<String>(key, fallback)

        class Json(key: String) :
            RcField<JSONObject?>(key, null)
    }

    suspend fun loadFields(
        fields: List<RcField<*>>,
        timeoutMs: Long = DEFAULT_TIMEOUT
    ) = withContext(Dispatchers.IO) {
        loadFieldsAsync(fields)
    }


    // ----------------------------------
    // RESTORE PREFS → MEMORY
    // ----------------------------------
    private fun restoreFromPrefs() {
        prefs.all.forEach { (key, value) ->
            when (value) {
                is Boolean -> boolCache[key] = value
                is String -> {
                    stringCache[key] = value
                    try {
                        jsonCache[key] = JSONObject(value)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)


    fun init() {
        rc.setConfigSettingsAsync(
            FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(0)
                .build()
        )

        // 🔥 background fetch
        preload()
    }

    private fun preload() {
        appScope.launch {
            runCatching {
                rc.fetchAndActivate()
            }
        }
    }

    suspend fun loadFieldsAsync(fields: List<RcField<*>>) {
        runCatching {
            rc.fetchAndActivate().await()
            cacheFields(fields)
        }
    }

    private suspend fun cacheFields(fields: List<RcField<*>>) {
        fields.forEach { field ->
            when (field) {

                is RcField.Bool -> {
                    val v = rc.getBoolean(field.key)
                    boolCache[field.key] = v
                    Log.e("cacheFields", "cacheFields: ${field.key} $v")
                    prefs.edit { putBoolean(field.key, v) }
                }

                is RcField.Str -> {
                    val v = rc.getString(field.key)
                    stringCache[field.key] = v
                    Log.e("cacheFields", "cacheFields: ${field.key} $v")
                    prefs.edit { putString(field.key, v) }
                }

                is RcField.Json -> {
                    val json = rc.getString(field.key)
                        .takeIf { it.isNotBlank() }
                        ?.let { JSONObject(it) }

                    jsonCache[field.key] = json
                    Log.e("cacheFields", "cacheFields: ${field.key} $json")
                    prefs.edit { putString(field.key, json?.toString()) }
                }
            }
        }
    }

    fun getBoolean(key: String, fallback: Boolean) =
        boolCache[key] ?: prefs.getBoolean(key, fallback)
}