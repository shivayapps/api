package gallery.photogallery.photoeditor.galleryapp.utils

import android.content.Intent
import org.greenrobot.eventbus.EventBus

fun registerEventBus(subscriber: Any) {
    if (!EventBus.getDefault().isRegistered(subscriber))
        EventBus.getDefault().register(subscriber)
}

fun unregisterEventBus(subscriber: Any) {
    if (EventBus.getDefault().isRegistered(subscriber))
        EventBus.getDefault().unregister(subscriber)
}

fun sendIntentEvent(type: String) {
    EventBus.getDefault().post(Intent(type))
}

fun sendIntentEvent(intent: Intent) {
    EventBus.getDefault().post(intent)
}

const val START_SCANNING = "START_SCANNING"
const val SHARE_STORY_DONE = "SHARE_STORY_DONE"
const val UPDATE_PROTECTION = "UPDATE_PROTECTION"
const val UPDATE_SELECTION = "UPDATE_SELECTION"
const val UPDATE_ALBUM_SHOW = "UPDATE_ALBUM_SHOW"
const val RESET_ALBUM_GRID = "RESET_ALBUM_GRID"
const val RESET_MEDIA = "RESET_MEDIA"
