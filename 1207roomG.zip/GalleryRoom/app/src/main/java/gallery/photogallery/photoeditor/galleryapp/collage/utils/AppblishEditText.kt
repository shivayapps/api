package gallery.photogallery.photoeditor.galleryapp.collage.utils

import android.content.Context
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.widget.AppCompatEditText
import gallery.photogallery.photoeditor.galleryapp.collage.fragments.TextFragment

class AppblishEditText(
    context: Context,
    attrs: AttributeSet? = null
) : AppCompatEditText(context, attrs) {

    var textFragment: TextFragment? = null

    override fun onKeyPreIme(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK &&
            event.action == KeyEvent.ACTION_UP
        ) {
            val imm =
                context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.hideSoftInputFromWindow(windowToken, 0)

            textFragment?. dismissAndShowSticker()
            return true
        }
        return super.onKeyPreIme(keyCode, event)
    }


}