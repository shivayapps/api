package gallery.photogallery.photoeditor.galleryapp.fragments

import android.content.Context.LAYOUT_INFLATER_SERVICE
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.viewbinding.ViewBinding
import com.appblish.box.api.model.MainMediaFilter
import gallery.photogallery.photoeditor.galleryapp.App
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.SharedViewModel
import gallery.photogallery.photoeditor.galleryapp.databinding.HomeMenuFilterBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getColorCompat
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.PopupWindowHelper

abstract class BaseFragment<VB : ViewBinding> : Fragment() {
    private var _binding: VB? = null
    val binding get() = _binding!!

    abstract fun inflateBinding(inflater: LayoutInflater, container: ViewGroup?): VB

    val sharedViewModel = ViewModelProvider(App.instance.appViewModelStoreOwner)[SharedViewModel::class.java]

    abstract fun setupViews()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?,
    ): View {
        _binding = inflateBinding(inflater, container)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupViews()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    protected fun showHomeMenuFilter(view: TextView) {
        val layoutInflater = requireActivity().getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = HomeMenuFilterBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)

        view.post {
            val location = IntArray(2)
            view.getLocationOnScreen(location)
            val x = location[0] + view.width - 100
            val y = location[1] + view.height

            popupWindow.showAtLocation(view, Gravity.NO_GRAVITY, x, y)
        }

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        popUpBinding.tvAll.setTextColor(requireContext().getColorCompat(R.color.color_text))
        popUpBinding.tvPhoto.setTextColor(requireContext().getColorCompat(R.color.color_text))
        popUpBinding.tvVideo.setTextColor(requireContext().getColorCompat(R.color.color_text))
        popUpBinding.tvGif.setTextColor(requireContext().getColorCompat(R.color.color_text))

        when (sharedViewModel.getMainMediaFilter()) {
            MainMediaFilter.ALL -> {
                popUpBinding.tvAll.setTextColor(requireContext().getColorCompat(R.color.color_primary))
            }

            MainMediaFilter.PHOTOS -> {
                popUpBinding.tvPhoto.setTextColor(requireContext().getColorCompat(R.color.color_primary))

            }

            MainMediaFilter.VIDEO -> {
                popUpBinding.tvVideo.setTextColor(requireContext().getColorCompat(R.color.color_primary))
            }

            MainMediaFilter.GIF -> {
                popUpBinding.tvGif.setTextColor(requireContext().getColorCompat(R.color.color_primary))
            }
        }

        popUpBinding.ivAll.setOnClickListener {
            popupWindow.dismiss()
            sharedViewModel.setMainMediaFilter(MainMediaFilter.ALL)
            view.text = getString(R.string.all)
            sharedViewModel.fetchMedia()

        }

        popUpBinding.ivPhoto.setOnClickListener {
            popupWindow.dismiss()
            sharedViewModel.setMainMediaFilter(MainMediaFilter.PHOTOS)
            view.text = getString(R.string.photos)
            sharedViewModel.fetchMedia()
        }

        popUpBinding.ivVideo.setOnClickListener {
            popupWindow.dismiss()
            sharedViewModel.setMainMediaFilter(MainMediaFilter.VIDEO)
            view.text = getString(R.string.videos)
            sharedViewModel.fetchMedia()
        }

        popUpBinding.ivGif.setOnClickListener {
            popupWindow.dismiss()
            sharedViewModel.setMainMediaFilter(MainMediaFilter.GIF)
            view.text = getString(R.string.gifs)
            sharedViewModel.fetchMedia()
        }
    }

    protected fun onSearchClick() {
//        startActivity(SearchActivity.createIntent(requireActivity()))
    }

    protected fun openCamera() {
        try {
            val cameraIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            startActivity(cameraIntent)
        } catch (_: Exception) {
            requireActivity().toast(getString(R.string.no_app_found))
        }
    }
}