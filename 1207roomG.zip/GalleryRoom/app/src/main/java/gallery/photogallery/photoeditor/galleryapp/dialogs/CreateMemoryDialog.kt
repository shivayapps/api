package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import androidx.core.widget.addTextChangedListener
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogCreateMemoryBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast

class CreateMemoryDialog : BottomSheetDialogFragment() {
    private var _binding: DialogCreateMemoryBinding? = null
    private val binding get() = _binding!!
    var createListener: ((path: String) -> Unit)? = null
    var btnCancelListener: (() -> Unit)? = null
    var existTitle = ""

    init {
        Log.e("TAG", "Init: ")
    }

    private lateinit var safeContext: Context

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogCreateMemoryBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
            setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
            )
        }

        intView()
        intListener()
        return dialog
    }


    private fun intView() {
        binding.icClear.beGone()
//        showKeyboard()
        binding.edtAlbumName.post {
            showKeyboard()
        }
    }

    private fun intListener() {
        if (existTitle.isNotEmpty()) {
            binding.edtAlbumName.setText(existTitle)
        }
        binding.edtAlbumName.addTextChangedListener {
            binding.icClear.beVisibleIf(binding.edtAlbumName.length() > 0)
        }
        binding.icClear.setOnClickListener {
            binding.edtAlbumName.setText("")
        }
        binding.btnCreate.setOnClickListener {
            val albumName = binding.edtAlbumName.text.trim()
            if (albumName.isNotEmpty()) {
                hideKeyboard()
                dismiss()
                createListener?.invoke(albumName.toString())
            } else
                requireContext().toast(getString(R.string.create_validation_memory_name))
        }
        binding.btnCancel.setOnClickListener {
            hideKeyboard()
            dismiss()
            btnCancelListener?.invoke()
        }
        dialog?.setCanceledOnTouchOutside(false)
        dialog?.setOnCancelListener {
            btnCancelListener?.invoke()
        }
    }

    private fun showKeyboard() {
        binding.edtAlbumName.requestFocus()
        val methodManager = (requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(binding.edtAlbumName, InputMethodManager.SHOW_IMPLICIT)
    }

    fun hideKeyboard() {
        binding.edtAlbumName.clearFocus()
        val methodManager = (requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(binding.edtAlbumName.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }
}