package gallery.photogallery.photoeditor.galleryapp.collage.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
 import com.appblish.collagemaker.photofilters.AppblishCollageFilterItem
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemFilterCollageBinding

class CollageFilterAdapter(
    private val context: Context,
    private val filters: List<AppblishCollageFilterItem>,
    private val onFilterSelected: (index: Int, item: AppblishCollageFilterItem) -> Unit
) : RecyclerView.Adapter<CollageFilterAdapter.FilterViewHolder>() {

    var selectedIndex = 0

    /* ---------- ADAPTER ---------- */

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilterViewHolder {
        val binding = ItemFilterCollageBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return FilterViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FilterViewHolder, position: Int) {
        holder.bind(filters[position], position)
    }

    override fun getItemCount(): Int = filters.size

    /* ---------- HELPERS ---------- */

    fun reset() {
        val oldIndex = selectedIndex
        selectedIndex = 0
        notifyItemChanged(oldIndex)
        notifyItemChanged(selectedIndex)
    }

    /* ---------- VIEW HOLDER ---------- */

    inner class FilterViewHolder(
        private val binding: ItemFilterCollageBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: AppblishCollageFilterItem, position: Int) = with(binding) {

            textViewFilterNameFilter.text = item.filter.name
            textViewFilterNameFilter.setTextColor(
                ContextCompat.getColor(context, R.color.white_collage)
            )

            roundImageViewFilterItemFilter.setImageBitmap(item.bitmap)

            viewSelected.visibility =
                if (selectedIndex == position) View.VISIBLE else View.GONE

            root.setOnClickListener {
                val pos = adapterPosition
                if (pos == RecyclerView.NO_POSITION) return@setOnClickListener

                val oldIndex = selectedIndex
                selectedIndex = pos

                onFilterSelected(selectedIndex, filters[selectedIndex])

                // Optimized refresh
                notifyItemChanged(oldIndex)
                notifyItemChanged(selectedIndex)
            }
        }
    }
}
