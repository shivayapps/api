package gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.lifecycle.lifecycleScope
import gallery.photogallery.photoeditor.galleryapp.activities.NewImageViewerActivity
import gallery.photogallery.photoeditor.galleryapp.activities.SplashActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import kotlinx.coroutines.launch

class OpenWithPlayerActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch {
            val intent = intent
            val dataUri: Uri? = intent.data
            if (dataUri != null && appPref.isMoveToHome) {
                val list = sharedViewModel.getAllMediaPaths().toHashSet()
                val imagePathOriginal = getImagePathFromURI(dataUri, list)
                if (!imagePathOriginal.isNullOrEmpty()) {
                    sharedViewModel.imageViewerList.clear()
                    val index = list.indexOf(imagePathOriginal)
                    sharedViewModel.imageViewerList.addAll(list)
                    startActivity(Intent(this@OpenWithPlayerActivity, NewImageViewerActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        putExtra("startPosition", index)
                    })
                    finish()
                } else {
                    try {
                        val imagePath = getFilePathFromUri(this@OpenWithPlayerActivity, dataUri)
                        if (imagePath != null) {
                            startActivity(Intent(this@OpenWithPlayerActivity, WhatsAppImageViewerActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                putExtra("filePath", imagePath)
                            })
                            finish()
                        } else {
                            startActivity(Intent(this@OpenWithPlayerActivity, SplashActivity::class.java))
                            finish()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        startActivity(Intent(this@OpenWithPlayerActivity, SplashActivity::class.java))
                        finish()
                    }
                }


            } else {
                startActivity(Intent(this@OpenWithPlayerActivity, SplashActivity::class.java))
                finish()
            }
        }
    }


}