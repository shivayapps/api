package gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory

import android.animation.Animator
import android.annotation.SuppressLint
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.transition.TransitionInflater
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.appblish.box.api.model.MediaBox
import com.appblish.box.api.model.ScrollGate
import com.appblish.box.api.util.MediaDataState
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import com.appblish.medialoader.AppblishImageLoader.loadListImage
import com.appblish.medialoader.AppblishImageLoader.loadSmallImage
import com.appblish.story.memories.api.core.MemorySDK
import com.appblish.story.memories.api.model.MemoryBox
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.SelectMemoryCoverActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityMemoryMainBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.ImageViewBottomBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.MemoryInsideMenuBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.CreateMemoryDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.MemoriesDeleteDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.MemoriesToneDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.animateAlpha
import gallery.photogallery.photoeditor.galleryapp.old.storyview.screen.ShareStoryActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beInvisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.delayExecution
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.realScreenSize
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.helpers.CustomCarouselLayoutManager
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.tablayout.loge
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.PopupWindowHelper
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.FadeOutTransformationSlow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable.isActive
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MemoryViewerActivity : BaseActivity() {
    private val binding by viewBinding(ActivityMemoryMainBinding::inflate)
    private lateinit var pagerAdapter: NewMemoryPagerAdapter
    private var mediaPlayer: MediaPlayer? = null
    val autoScroll by lazy { AutoScrollCoroutine() }
    val fadeAnimation by lazy { FadeOutTransformationSlow() }
    var isUserScrolling = false
    var isUserPageChange = false
    var isBottomRvScrolling = false
    private var isShowToolbar = false
    private var isPlayingOnPause = false
    var memoryListItem: MemoryBox? = null
    private val mediaPlayPauseListener = {
        val playIcon = ContextCompat.getDrawable(this, R.drawable.ic_play_vec)
        val pauseIcon = ContextCompat.getDrawable(this, R.drawable.ic_pause_vec)
        if (isMediaPlaying()) {
            autoScroll.start()
        } else {
            autoScroll.stop()
        }
        binding.ivPlayPause.setImageDrawable(if (isMediaPlaying()) pauseIcon else playIcon)
        if (::pagerAdapter.isInitialized) pagerAdapter.pauseResumeZoomInZoomOut(binding.imagesPager.currentItem, !isMediaPlaying())
    }

    val memoryId by lazy { intent.getLongExtra("memoryId", 0) }
    private var manageMemoryMedia: ActivityResultLauncher<Intent>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        window.sharedElementEnterTransition = TransitionInflater.from(this).inflateTransition(android.R.transition.move)
        binding.imagesPager.transitionName = "image_transition"
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = false
        manageMemoryMedia = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result: ActivityResult ->
            if (result.resultCode == RESULT_OK) {
                finish()
            }
        }
        MemorySDK.get().getMemoryBox(memoryId) {
            "get tone: $it".loge()
            memoryListItem = it
            runOnUiThread {
                initView()
                setUpPager()
                animateFirstTitle()
                updateView()

            }
        }
    }

    private fun initView() {
        ScrollGate.onScrollStart()
    }

    private fun animateFirstTitle() {
        binding.imagesPager.post {
            binding.bottomShadow.animateAlpha(0f, 1f, 2000)
            binding.llTitle.animateAlpha(0f, 1f, 2000)
            delayExecution(2000) {
                binding.llTitle.animateAlpha(1f, 0f, 1000)
                binding.bottomShadow.animateAlpha(1f, 0f, 1000)
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setUpPager() {
        pagerAdapter = NewMemoryPagerAdapter(
            this, getMediaList()
        )
        binding.imagesPager.adapter = pagerAdapter
        binding.imagesPager.offscreenPageLimit = 3
        fadeAnimation.disable()
        binding.imagesPager.invalidate()
        binding.imagesPager.setPageTransformer(fadeAnimation)
        binding.rlOverlayOption.setPadding(0, statusBarHeight, 0, 0)
        binding.bottomBar.setPadding(0, 0, 0, navigationBarHeight)
        binding.llEndBottomAction.setPadding(0, 0, 0, navigationBarHeight)
        binding.progressBar.max = pagerAdapter.itemCount + 1
        binding.progressBar.progress = 1
        binding.imagesPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                pagerAdapter.startZoomInZoomOut(position, isMediaPlaying())
                if (!isBottomRvScrolling) (binding.rvBottomImages.layoutManager as? CustomCarouselLayoutManager)?.smoothScrollToPosition(
                    binding.rvBottomImages,
                    RecyclerView.State(),
                    position
                )

                binding.progressBar.progress = position + 1
            }

            override fun onPageScrollStateChanged(state: Int) {
                super.onPageScrollStateChanged(state)
                when (state) {
                    ViewPager2.SCROLL_STATE_DRAGGING -> {
                        isUserPageChange = true // User starts interacting
                        autoScroll.stop() // Pause auto-scroll immediately
                    }

                    ViewPager2.SCROLL_STATE_IDLE -> {
                        if (isUserPageChange) {
                            isUserPageChange = false // User interaction stopped
                            // Wait for 1 second before resuming auto-scroll

                            lifecycleScope.launch {
                                delay(1000L) // 1-second delay
                                if (isMediaPlaying()) {
                                    autoScroll.start() // Resume auto-scroll
                                }
                            }
                        }
                    }
                }
            }
        })

        binding.ivBack.setOnClickListener {
            finish()
        }
        binding.ivChangeMusic.setOnClickListener {
            changeMusic()
        }
        binding.ivFav.setOnClickListener {
            makeFavUnFav()
        }
        binding.ivRestartMemory.setOnClickListener {
            binding.rlMemoryEndView.beGone()
            Intent(this, MemoryViewerActivity::class.java).apply {
                putExtra("memoryId", memoryListItem!!.memoryId)
                startActivity(this)
            }
            finish()
        }
        binding.ivExportBottom.setOnClickListener {
            shareMemory()
        }
        binding.ivShareMemory.setOnClickListener {
            shareMemory()
        }
        binding.ivFavBottom.setOnClickListener {
            makeFavUnFav()
        }
        binding.ivMore.setOnClickListener {
            showMemoryMenu(it)
        }
        binding.ivPlayPause.setOnClickListener {
            playerToggle()
        }
        binding.ivMute.tag = 1
        binding.ivMute.setOnClickListener {
            muteToggle()
        }

        binding.ivUpdateMemory.setOnClickListener {
            manageMemoryMedia?.launch(
                Intent(this, ManageMemoryActivity::class.java).putExtra(
                    "memoryId", memoryListItem!!.memoryId
                )
            )
        }
        startPlay()
        delayExecution(500) {
            setBottomImageAdaptor()
            setUpNextWatch()
        }
    }

    private fun updateView() {
        binding.imagesPager.post {
            hideToolbar()
            binding.tvTitle.text = memoryListItem!!.title
            binding.tvTitle2.text = memoryListItem!!.title
            binding.tvSubTitle.text = memoryListItem!!.subTitle
            binding.tvSubTitle2.text = memoryListItem!!.subTitle
            try {
                if (memoryListItem!!.fontId != 0) {
                    // Load the font from the assets folder
                    val typeface = resources.getFont(memoryListItem!!.fontId)

                    binding.tvTitle.typeface = typeface
                    binding.tvTitle2.typeface = typeface
                    binding.tvSubTitle.typeface = typeface
                    binding.tvSubTitle2.typeface = typeface
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (memoryListItem!!.isFavourite) {
                binding.ivFav.setImageResource(R.drawable.vec_favorite_fill)
                binding.ivFavBottom.setImageResource(R.drawable.vec_favorite_fill)
            } else {
                binding.ivFav.setImageResource(R.drawable.vec_favorite_un_fill)
                binding.ivFavBottom.setImageResource(R.drawable.vec_favorite_un_fill)
            }
        }
    }

    private fun makeFavUnFav() {
        sharedViewModel.updateMemoryFavourite(memoryListItem!!.memoryId, !memoryListItem!!.isFavourite)
        MemorySDK.get().getMemoryBox(memoryId) {
            memoryListItem = it
            runOnUiThread {
                updateView()
            }
        }
    }


    private fun shareMemory() {
        val intent = Intent(this, ShareStoryActivity::class.java)
        intent.putExtra("story_pos", binding.imagesPager.currentItem)
        intent.putStringArrayListExtra("story_array", ArrayList(getMediaList().map { it.mediaPath }))
        startActivity(intent)
    }

    private fun getMediaList(): List<MediaBox> {
        return memoryListItem!!.mediaList
    }

    override fun onResume() {
        super.onResume()
        if (isPlayingOnPause) {
            if (!binding.rlMemoryEndView.isVisible()) {
                startPlay()
            } else {
                isPlayingOnPause = false
            }
        }
    }

    override fun onPause() {
        super.onPause()
        isPlayingOnPause = isMediaPlaying()
        if (isMediaPlaying()) {
            pausePlayer()
        }

    }

    fun optionToggle() {
        if (isShowToolbar) {
            hideToolbar()
        } else {
            showToolbar()
        }
    }

    private fun hideToolbar() {
        isShowToolbar = false
        binding.clToolbar.animate().setDuration(300).setInterpolator(AccelerateDecelerateInterpolator()).alpha(0f)
        binding.topShadow.animate().setDuration(300).setInterpolator(AccelerateDecelerateInterpolator()).alpha(0f)
        binding.bottomBar.animate().setDuration(300).setInterpolator(AccelerateDecelerateInterpolator()).alpha(0f)
        binding.bottomBarPadding.animate().setDuration(300).setInterpolator(AccelerateDecelerateInterpolator()).alpha(0f)
            .setListener(object : Animator.AnimatorListener {
                override fun onAnimationStart(animation: Animator) {

                }

                override fun onAnimationEnd(animation: Animator) {
                    binding.bottomBarPadding.beGone()
                    binding.bottomBar.beGone()
                    binding.topShadow.beGone()
                    binding.clToolbar.beGone()
                }

                override fun onAnimationCancel(animation: Animator) {
                }

                override fun onAnimationRepeat(animation: Animator) {
                }

            })

        window?.insetsController?.hide(WindowInsets.Type.navigationBars())
        window?.insetsController?.hide(WindowInsets.Type.statusBars())
    }

    private fun showToolbar() {
        binding.bottomBarPadding.beVisible()
        binding.bottomBar.beVisible()
        binding.topShadow.beVisible()
        binding.clToolbar.beVisible()
        isShowToolbar = true
        binding.clToolbar.animate().setDuration(300).setInterpolator(AccelerateDecelerateInterpolator()).alpha(1f).setListener(null)

        binding.topShadow.animate().setDuration(300).setInterpolator(AccelerateDecelerateInterpolator()).alpha(1f).setListener(null)

        binding.bottomBar.animate().setDuration(300).setInterpolator(AccelerateDecelerateInterpolator()).alpha(1f).setListener(null)
        binding.bottomBarPadding.animate().setDuration(300).setInterpolator(AccelerateDecelerateInterpolator()).alpha(1f).setListener(null)
        window?.insetsController?.show(WindowInsets.Type.navigationBars())
        window?.insetsController?.show(WindowInsets.Type.statusBars())
        binding.llTitle.beGone()
        binding.bottomShadow.beGone()
    }

    private fun showMemoryEndView() {
        if (binding.rlMemoryEndView.tag == 1) {
            finish()
            return
        }
        sharedViewModel.updateMemorySeen(memoryListItem!!.memoryId)
        autoScroll.stop()
        releaseMediaPlayer()
        hideToolbar()
        binding.tvTitleBottom.text = binding.tvTitle.text
        binding.tvSubTitleBottom.text = binding.tvSubTitle.text
        binding.rlMemoryEndView.beVisible()
        binding.rlMemoryEndView.alpha = 0f
        binding.rlMemoryEndView.animate().setDuration(300).setInterpolator(AccelerateDecelerateInterpolator()).alpha(1f)

        binding.llInnerHorizontalScroll.translationX = 250f
        binding.llInnerHorizontalScroll.animate().translationX(0f).alpha(1f).setDuration(400).setInterpolator(DecelerateInterpolator()).start()
        binding.ivEndViewClose.setOnClickListener {
            finish()
        }

    }

    private fun setUpNextWatch() {
        val mediaList = getMediaList()
        if (mediaList.isNotEmpty()) {
            val lastMedia = getMediaList().last()
            binding.ivLastImage.loadListImage(lastMedia.mediaPath, lastMedia.mediaDate)
        }

        lifecycleScope.launch {
            val state = withContext(Dispatchers.IO) {
                MemorySDK.get().getAllMemories()
            }
            when (state) {
                MediaDataState.Empty -> {}
                MediaDataState.Loading -> {}
                is MediaDataState.Success -> {
                    val memories = state.data.toMutableList()
                    memories.removeIf { item -> item.memoryId == memoryListItem!!.memoryId }
                    if (memories.isNotEmpty()) {
                        val sameMedias = memories.filter { item -> item.categoryKey == memoryListItem!!.categoryKey && !item.isSeen }
                        val sameMediaRandom = if (sameMedias.isNotEmpty()) {
                            sameMedias.random()
                        } else {
                            memories.random()
                        }
                        val unSeenMemories = memories.filter { item -> !item.isSeen }
                        val randomMemories = if (unSeenMemories.isNotEmpty()) {
                            val memoriesUnSeen = unSeenMemories.shuffled().shuffled().take(4).toMutableList()
                            try {
                                val remainingMemory = 4 - unSeenMemories.size
                                if (remainingMemory > 0) {
                                    memoriesUnSeen.addAll(memories.shuffled().shuffled().take(remainingMemory))
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                            memoriesUnSeen
                        } else {
                            memories.shuffled().shuffled().take(4)
                        }
                        runOnUiThread {
                            binding.card1.tag = sameMediaRandom

                            setDataToView(binding.tvTitleSuggestion1, binding.tvSubTitleSuggestion1, binding.icCardSuggestion1, sameMediaRandom)
                            binding.card1.setOnClickListener {
                                openNextWatch(binding.card1, sameMediaRandom)
                            }
                            val cardViews = arrayListOf(binding.card2, binding.card3, binding.card4, binding.card5)
                            val imageCardViews = arrayListOf(
                                binding.icCardSuggestion2,
                                binding.icCardSuggestion3,
                                binding.icCardSuggestion4,
                                binding.icCardSuggestion5
                            )
                            val titleViews = arrayListOf(
                                binding.tvTitleSuggestion2,
                                binding.tvTitleSuggestion3,
                                binding.tvTitleSuggestion4,
                                binding.tvTitleSuggestion5
                            )
                            val subTitleViews = arrayListOf(
                                binding.tvSubTitleSuggestion2,
                                binding.tvSubTitleSuggestion3,
                                binding.tvSubTitleSuggestion4,
                                binding.tvSubTitleSuggestion5
                            )
                            cardViews.forEachIndexed { index, view ->
                                view.beInvisible()
                                try {
                                    view.setOnClickListener {
                                        val item = view.tag as MemoryBox
                                        openNextWatch(cardViews[index], item)
                                    }
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                            randomMemories.forEachIndexed { index, item ->
                                cardViews[index].beVisible()
                                cardViews[index].tag = item
                                setDataToView(titleViews[index], subTitleViews[index], imageCardViews[index], item)
                            }
                        }
                    } else {
                        binding.rlMemoryEndView.beGone()
                        binding.rlMemoryEndView.tag = 1
                    }
                }

                is MediaDataState.Progress -> TODO()
            }

        }
    }

    fun setDataToView(tvTitle: TextView, tvSubTitle: TextView, imageView: ImageView, dataPos: MemoryBox) {
        imageView.loadGridImage(dataPos.coverImage, dataPos.coverImageDate)
        tvTitle.text = dataPos.title
        tvSubTitle.text = dataPos.subTitle
        try {
            if (dataPos.fontId != 0) {
                // Load the font from the assets folder
                val typeface = ResourcesCompat.getFont(
                    tvTitle.context,
                    dataPos.fontId
                )
                tvTitle.typeface = typeface
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun openNextWatch(imageView: CardView, item: MemoryBox) {
        val options = ActivityOptionsCompat.makeSceneTransitionAnimation(
            this, imageView, // The shared view
            "image_transition" // The transition name
        )
        Intent(this, MemoryViewerActivity::class.java).apply {
            putExtra("memoryId", item.memoryId)
            startActivity(this, options.toBundle())
            delayExecution(1000) {
                finish()
            }

        }
    }

    private fun changeMusic() {
        MemoriesToneDialog.newInstance(memoryListItem!!.musicRawId) { selectedTone ->
            "getSelected tone: $selectedTone".loge()
            sharedViewModel.updateMemoryMusic(memoryListItem!!.memoryId, selectedTone) {
                resetToStart()
            }
        }.show(supportFragmentManager, "MemoriesToneDialog")

    }


    override fun onDestroy() {
        super.onDestroy()
        releaseMediaPlayer()
        ScrollGate.onScrollStop()
    }


    private fun isMediaPlaying() = mediaPlayer?.isPlaying ?: false
    private fun playerToggle() {
        if (isMediaPlaying()) {
            pausePlayer()
        } else {
            startPlay()
        }
    }

    private fun muteToggle() {
        if (mediaPlayer != null) {
            if (binding.ivMute.tag == 1) {
                mediaPlayer?.setVolume(0f, 0f)
                binding.ivMute.tag = 0
            } else {
                binding.ivMute.tag = 1
                mediaPlayer?.setVolume(1f, 1f)
            }
            binding.ivMute.setImageResource(if (binding.ivMute.tag == 1) R.drawable.ic_music_on else R.drawable.ic_music_off)
        }

    }


    fun releaseMediaPlayer() {
        pausePlayer()
        mediaPlayer?.release()
        mediaPlayer = null
    }

    private fun pausePlayer() {
        mediaPlayer?.pause()
        mediaPlayPauseListener.invoke()
    }

    private fun startPlay() {


        if (mediaPlayer == null && memoryListItem!!.musicRawId != 0) {
            mediaPlayer = MediaPlayer.create(this, memoryListItem!!.musicRawId)
            mediaPlayer?.isLooping = true
            mediaPlayer?.setScreenOnWhilePlaying(true)
        }

        if (mediaPlayer?.isPlaying == false) {
            mediaPlayer?.start()
            mediaPlayPauseListener.invoke()
        }
    }

    private fun resetToStart() {
        MemorySDK.get().getMemoryBox(memoryId) {
            memoryListItem = it
            runOnUiThread {
                binding.rvBottomImages.adapter = null
                isBottomRvScrolling = false
                isUserScrolling = false
                autoScroll.stop()
                setUpPager()
                setBottomImageAdaptor()
                animateFirstTitle()
                releaseMediaPlayer()
                startPlay()
                binding.ivMute.tag = 1
                mediaPlayer?.setVolume(1f, 1f)
                binding.ivMute.setImageResource(R.drawable.ic_music_on)
                binding.rlMemoryEndView.beGone()
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setBottomImageAdaptor() {
        if (binding.rvBottomImages.adapter == null) {
            val startPadding = realScreenSize.x * 0.45
            val mLinearLayoutManager = CustomCarouselLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
            binding.rvBottomImages.layoutManager = mLinearLayoutManager
            val adaptor = BottomRecyclerViewAdaptor(getMediaList())
            binding.rvBottomImages.clearOnScrollListeners()
            binding.rvBottomImages.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    if (isUserScrolling) {
                        val centerItem = mLinearLayoutManager.getCenterItemPosition()
                        if (centerItem != binding.imagesPager.currentItem) {
                            binding.imagesPager.post {
                                if (fadeAnimation.isEnabledFade()) {
                                    fadeAnimation.disable()
                                    binding.imagesPager.invalidate()
                                }
                                binding.imagesPager.setCurrentItem(centerItem, false)
                            }
                        }
                    }
                }

                override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                    super.onScrollStateChanged(recyclerView, newState)

                    when (newState) {
                        RecyclerView.SCROLL_STATE_DRAGGING -> {
                            isUserScrolling = true // User starts interacting
                            isBottomRvScrolling = true // User starts interacting
                            autoScroll.stop() // Pause auto-scroll immediately
                        }

                        RecyclerView.SCROLL_STATE_IDLE -> {
                            if (isBottomRvScrolling) {
                                isBottomRvScrolling = false
                                val centerItem = mLinearLayoutManager.getCenterItemPosition()
                                if (centerItem != binding.imagesPager.currentItem) binding.rvBottomImages.smoothScrollToPosition(centerItem)
                            }

                            if (isUserScrolling) {
                                isUserScrolling = false // User interaction stopped
                                val centerItem = mLinearLayoutManager.getCenterItemPosition()
                                if (isMediaPlaying() && centerItem == 0) {
                                    mediaPlayer?.pause()
                                    mediaPlayer?.seekTo(0)
                                    startPlay()
                                }
                                // Wait for 1 second before resuming auto-scroll
                                lifecycleScope.launch {
                                    delay(1000L)
                                    if (isMediaPlaying()) {
                                        autoScroll.start()
                                    }
                                }


                            }
                        }
                    }
                }
            })
            binding.rvBottomImages.adapter = adaptor
            binding.rvBottomImages.setItemViewCacheSize(50)
            binding.rvBottomImages.setPadding(
                startPadding.toInt(),
                binding.rvBottomImages.paddingTop,
                startPadding.toInt(),
                binding.rvBottomImages.paddingBottom
            )
            binding.rvBottomImages.post {
                binding.rvBottomImages.scheduleLayoutAnimation()
            }
        } else {
            (binding.rvBottomImages.adapter as? BottomRecyclerViewAdaptor)?.images = getMediaList()
            binding.rvBottomImages.scrollToPosition(0)
            binding.rvBottomImages.post {
                binding.rvBottomImages.scheduleLayoutAnimation()
            }
        }


    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        finish()
    }


    override fun finish() {
        if (isTaskRoot) {
            moveToHome()
        } else {
            super.finish()
        }

    }

    private fun showMemoryMenu(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = MemoryInsideMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)
        view.post {
            val location = IntArray(2)
            view.getLocationOnScreen(location) // Get view's location on screen
            val x = location[0] + view.width  // Position to the right of the view
            val y = location[1] + view.height // Same Y position
            popupWindow.showAtLocation(view, Gravity.NO_GRAVITY, x, y)
        }
        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()

        }

        popUpBinding.llManagePhotos.setOnClickListener {
            popupWindow.dismiss()
            binding.ivUpdateMemory.performClick()
        }
        popUpBinding.llChangeCoverImage.setOnClickListener {
            popupWindow.dismiss()
            manageMemoryMedia?.launch(
                Intent(this, SelectMemoryCoverActivity::class.java)
                    .putExtra("memoryId", memoryListItem!!.memoryId)
                    .putExtra("fromViewer", true)
            )

        }

        popUpBinding.llEditTitle.setOnClickListener {
            popupWindow.dismiss()
            val isPlaying = isMediaPlaying()
            pausePlayer()
            val createDialog = CreateMemoryDialog()
            createDialog.existTitle = memoryListItem!!.title
            createDialog.createListener = { newMemory ->
                binding.tvTitle2.text = newMemory
                sharedViewModel.updateMemoryTitle(memoryListItem!!.memoryId, newMemory)
            }
            createDialog.btnCancelListener = {
                if (isPlaying) {
                    playerToggle()
                }
            }

            createDialog.show(supportFragmentManager, "createDialog.tag")

        }
        popUpBinding.llDeleteMemory.setOnClickListener {
            popupWindow.dismiss()
            val isPlaying = isMediaPlaying()
            pausePlayer()
            val deleteDialog = MemoriesDeleteDialog.newInstance(btnClickListener = {
                CoroutineScope(Dispatchers.IO).launch {
                    sharedViewModel.deleteMemory(memoryListItem!!.memoryId)
                    finish()
                }
            }, btnCancelListener = {
                if (isPlaying) {
                    playerToggle()
                }
            })
            deleteDialog.show(supportFragmentManager, "DeleteMemoryDialog")
        }

        delayExecution(3000) {
            popupWindow.dismiss()
        }
    }

    inner class BottomRecyclerViewAdaptor(var images: List<MediaBox>) : RecyclerView.Adapter<BottomRecyclerViewAdaptor.ViewHolder>() {
        inner class ViewHolder(val binding: ImageViewBottomBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            return ViewHolder(ImageViewBottomBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        }

        override fun getItemCount(): Int {
            return images.size
        }


        @SuppressLint("CheckResult")
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.binding.image.loadSmallImage(images[position].mediaPath, images[position].mediaDate)
            holder.binding.image.setOnClickListener {
                binding.imagesPager.post {
                    if (fadeAnimation.isEnabledFade()) {
                        fadeAnimation.disable()
                        binding.imagesPager.invalidate()
                    }
                    binding.imagesPager.setCurrentItem(position, false)
                    if (isMediaPlaying()) {
                        autoScroll.stop()
                        autoScroll.start()
                    }
                }
            }
        }
    }

    inner class AutoScrollCoroutine() {
        private var autoScrollJob: Job? = null

        // Starts the auto-scroll
        fun start(interval: Long = (MemorySDK.get().getStoryOneSlideTime() * 1000).toLong()) {
            autoScrollJob?.cancel()
            autoScrollJob = lifecycleScope.launch {
                while (isActive) {
                    delay(interval)
                    if (!isUserScrolling) {
                        if (binding.imagesPager.adapter != null) {
                            val nextItem = try {
                                (binding.imagesPager.currentItem + 1) % binding.imagesPager.adapter!!.itemCount
                            } catch (e: Exception) {
                                e.printStackTrace()
                                0
                            }
                            if (nextItem == 0) {
                                showMemoryEndView()
                            } else {
                                if (!fadeAnimation.isEnabledFade()) {
                                    fadeAnimation.enable()
                                    binding.imagesPager.invalidate()
                                }
                                binding.imagesPager.setPageTransformer(fadeAnimation)
                                binding.imagesPager.setCurrentItem(nextItem, true)
                            }
                        }
                    }
                }
            }
        }

        // Stops the auto-scroll
        fun stop() {
            autoScrollJob?.cancel()
        }

    }

}

