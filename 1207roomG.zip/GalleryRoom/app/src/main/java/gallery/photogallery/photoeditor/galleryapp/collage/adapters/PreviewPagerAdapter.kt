package gallery.photogallery.photoeditor.galleryapp.collage.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.appblish.gallery.core.v2.api.model.MediaModel
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.R

class PreviewPagerAdapter(
    private val list: MutableList<MediaModel>,
    private val onAdd: (MediaModel) -> Unit,
    private val onRemove: (MediaModel) -> Unit
) : RecyclerView.Adapter<PreviewPagerAdapter.VH>() {

    // 👇 SAFE update method
    fun submit(data: List<MediaModel>) {
        list.clear()
        list.addAll(data)
        notifyDataSetChanged()
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val img: ImageView = view.findViewById(R.id.ivPreview)
     }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_preview_pager, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val media = list[position]
        Glide.with(holder.img)
            .load(media.mediaBox.mediaPath)
            .into(holder.img)
    }

    override fun getItemCount() = list.size
}

