package gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory

import android.annotation.SuppressLint
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.transition.TransitionInflater
import android.view.GestureDetector
import android.view.MotionEvent
import androidx.activity.addCallback
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.viewpager.widget.ViewPager
import com.appblish.box.api.util.MediaDataState
import com.appblish.story.memories.api.core.MemorySDK
import com.appblish.story.memories.api.model.StoryBox
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityNewStoryMainBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.REMOVE_STORY
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.REMOVE_STORY_PHOTO
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.sendMemoryEvent
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.delayExecution
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.utils.SHARE_STORY_DONE
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class NewStoryActivity : BaseActivity() {
    private val binding by viewBinding(ActivityNewStoryMainBinding::inflate)
    private var storyData = emptyList<StoryBox>()
    private val storyPosition by lazy { intent.getIntExtra("storyPosition", 0) }
    private val storyId by lazy { intent.getLongExtra("storyId", 0) }
    private var pagerAdapter: NewStoryPagerAdapter? = null
    private var mediaPlayer: MediaPlayer? = null
    private var isVolumeEnabled = true
    private var isOnCreate = true
    private var isPauseMusic = false
    var isOpenSeen = false
    private val gestureDetector by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onLongPress(e: MotionEvent) {
                super.onLongPress(e)
                pagerAdapter?.onLongPressCalled(binding.viewPagerStory.currentItem)
                pausePlayer()
            }

            override fun onDown(e: MotionEvent): Boolean {
                // Must return true to detect further gestures

                return true
            }


            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                if (e1 == null) return false

                val deltaX = e2.x - e1.x
                val deltaY = e2.y - e1.y
                val absDeltaX = kotlin.math.abs(deltaX)
                val absDeltaY = kotlin.math.abs(deltaY)

                val absVelocityY = kotlin.math.abs(velocityY)

                // Only consider it a vertical swipe if horizontal movement is small
                if (deltaY > 100 && absDeltaY > absDeltaX * 1.5 && absVelocityY > 1000) {
                    // Detected downward swipe
                    finish()
                    return true
                }

                return false
            }

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val screenWidth = binding.viewPagerStory.width
                val tapX = e.x

                val leftBoundary = screenWidth * 0.4f

                when {
                    tapX <= leftBoundary -> {
                        // Tap in left 40%
                        pagerAdapter?.clickPrevious(binding.viewPagerStory.currentItem)
                    }

                    else -> {
                        // Tap in right 60%
                        pagerAdapter?.clickNext(binding.viewPagerStory.currentItem)

                    }
                }
                return super.onSingleTapUp(e)
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch {

            if (intent.hasExtra("isFromNotification")) {
                MemorySDK.get().getStoryBox(storyId) {
                    if (storyData.isEmpty()) {
                        storyData = listOf(it)
                        showStory()
                    }
                }

            } else {
                val state = MemorySDK.get().getAllStories()
                when (state) {
                    MediaDataState.Empty -> {}
                    MediaDataState.Loading -> {
                    }

                    is MediaDataState.Success -> {
                        if (storyData.isEmpty()) {
                            storyData = state.data
                            showStory()
                        }
                    }

                    is MediaDataState.Progress -> {}
                }
            }

        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            SHARE_STORY_DONE -> {
                moveNext()
            }

        }
    }

    private fun showStory() {
        if (storyData.isEmpty()) {
            finish()
            return
        }
        enableEdgeToEdge()
        setContentView(binding.root)
        registerEventBus(this)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = false
        window.sharedElementEnterTransition = TransitionInflater.from(this)
            .inflateTransition(android.R.transition.move)
        binding.viewPagerStory.transitionName = "story_transition"
        setUpPager()
        onBackPressedDispatcher.addCallback {
            finish()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setUpPager() {
        pagerAdapter = NewStoryPagerAdapter(this, supportFragmentManager, storyPosition, storyData)
        binding.viewPagerStory.adapter = pagerAdapter
        binding.viewPagerStory.setCurrentItem(storyPosition, false)
        binding.viewPagerStory.setPageTransformer(false, StoryCubeOutTransformer())
        binding.viewPagerStory.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

            }

            override fun onPageSelected(position: Int) {
                pagerAdapter?.pauseAllProgress()
                pagerAdapter?.startProgress(position)
                pagerAdapter?.releaseVideoPlayer()
                pagerAdapter?.playVideo(position)
                playMusic(position)

            }

            override fun onPageScrollStateChanged(state: Int) {

            }

        })
        binding.viewPagerStory.post {
            delayExecution(500) {
                pagerAdapter?.startProgress(storyPosition)
                playMusic(storyPosition)
            }
        }

        binding.viewPagerStory.setOnTouchListener { _, event ->
            if (!binding.viewPagerStory.isPagingEnabled()) {
                return@setOnTouchListener false
            }
            onPagerTouchEvent(event)
            false
        }
    }

    fun onPagerTouchEvent(event: MotionEvent) {
        gestureDetector.onTouchEvent(event)
        when (event.action) {
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                pagerAdapter?.startProgress(binding.viewPagerStory.currentItem)
                if (isPauseMusic) {
                    resumePlayer()
                    pagerAdapter?.resumeProgress()
                }
            }
        }
    }

    fun disableViewPager() {
        binding.viewPagerStory.setPagingEnabled(false)
        releaseMediaPlayer()
    }

    fun enableViewPager() {
        binding.viewPagerStory.setPagingEnabled(true)
        playMusic(binding.viewPagerStory.currentItem)
    }

    private fun playMusic(position: Int) {

        try {
            val data = storyData[position]
            if (data.isRevisitMovement()) {
                mediaPlayer?.setVolume(0f, 0f)
                releaseMediaPlayer()
            } else {
                if (data.musicRawId != 0) {
                    mediaPlayer = MediaPlayer.create(this, data.musicRawId).apply {
                        isLooping = true
                        start()

                    }
                    if (isVolumeEnabled) {
                        mediaPlayer?.setVolume(1f, 1f)
                    } else {
                        mediaPlayer?.setVolume(0f, 0f)
                    }
                } else {
                    releaseMediaPlayer()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    private fun pausePlayer() {
        isPauseMusic = true
        mediaPlayer?.pause()
    }

    private fun resumePlayer() {
        isPauseMusic = false
        mediaPlayer?.start()
    }

    fun removeStory() {
        sendMemoryEvent(REMOVE_STORY)
    }

    fun removeStoryMedia(filePath: String) {
        sendMemoryEvent(REMOVE_STORY_PHOTO)
    }

    fun moveNext() {
        if (binding.viewPagerStory.adapter != null) {
            val nextItem = (binding.viewPagerStory.currentItem + 1) % binding.viewPagerStory.adapter!!.count
            if (nextItem == 0) {
                onBackPressed()
            } else {
                binding.viewPagerStory.setCurrentItem(nextItem, true)
                playMusic(nextItem)
            }
        }
    }

    fun movePrevious() {
        if (binding.viewPagerStory.adapter != null) {
            val previousItem = binding.viewPagerStory.currentItem - 1
            if (previousItem < 0) {

            } else {
                binding.viewPagerStory.setCurrentItem(previousItem, true)
                playMusic(previousItem)
            }
        }
    }

    /* private fun getMusicResource(music: String): Int {
         return when (music) {
             "tone_1" -> R.raw.tone_1
             "tone_2" -> R.raw.tone_2
             "tone_3" -> R.raw.tone_3
             "tone_4" -> R.raw.tone_4
             "tone_5" -> R.raw.tone_5
             "tone_6" -> R.raw.tone_6
             "tone_7" -> R.raw.tone_7
             "tone_8" -> R.raw.tone_8
             "tone_9" -> R.raw.tone_9
             "tone_10" -> R.raw.tone_10
             "tone_11" -> R.raw.tone_11
             "tone_12" -> R.raw.tone_12
             else -> R.raw.tone_1
         }

     }*/

    fun isVolumeEnabled() = isVolumeEnabled
    fun toggleVolume() {
        if (isVolumeEnabled) {
            isVolumeEnabled = false
            mediaPlayer?.setVolume(0f, 0f)
        } else {
            isVolumeEnabled = true
            mediaPlayer?.setVolume(1f, 1f)
        }
        pagerAdapter?.updateMusicIcon()
    }

    fun togglePlayer() {
        if (mediaPlayer?.isPlaying == true) {
            mediaPlayer?.pause()
        } else {
            mediaPlayer?.start()
        }
    }

    override fun finish() {
        releaseMediaPlayer()
        if (isTaskRoot) {
            moveToHome()

        } else {
            super.finish()
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterEventBus(this)
        releaseMediaPlayer()
    }

    private fun releaseMediaPlayer() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
    }


    override fun onResume() {
        super.onResume()
        if (binding.viewPagerStory.isPagingEnabled()) {
            if (isOnCreate) {
                isOnCreate = false
            } else {
                mediaPlayer?.start()
                pagerAdapter?.startProgress(binding.viewPagerStory.currentItem)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        mediaPlayer?.pause()
        pagerAdapter?.pauseAllProgress()
    }


}