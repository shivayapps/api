package gallery.photogallery.photoeditor.galleryapp.collage.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.appblish.gallery.core.v2.api.model.MediaModel
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.R

class PreviewBottomAdapter(
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<PreviewBottomAdapter.VH>() {

    private val list = mutableListOf<MediaModel>()

    fun submit(data: List<MediaModel>) {
        list.clear()
        list.addAll(data)
        notifyDataSetChanged()
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val img: ImageView = view.findViewById(R.id.ivThumb)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_preview_bottom, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val media = list[position]
        Glide.with(holder.img)
            .load(media.mediaBox.mediaPath)
            .into(holder.img)

        holder.itemView.setOnClickListener {
            onClick(position)
        }
    }

    override fun getItemCount() = list.size
}
