package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.MediaBox
import com.appblish.gallery.core.v2.api.model.MediaListItem
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import com.appblish.recyclerview.dragselection.BaseSelectableAdapter
import com.appblish.recyclerview.dragselection.DragSelectionMode
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemHeaderDividerBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.PhotoItemGridBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf

class ExplorePhotosAdapter(
    recyclerView: RecyclerView,
    val onMediaClick: (MediaBox) -> Unit,
) : BaseSelectableAdapter<MediaListItem, RecyclerView.ViewHolder>(recyclerView, DragSelectionMode.RANGE) {

    private val mediaList = ArrayList<MediaListItem>()

    companion object {
        const val HEADER = 0
        const val ALBUM = 1
    }

    fun submitList(list: ArrayList<MediaListItem>) {
        mediaList.clear()
        mediaList.addAll(list)
        notifyDataSetChanged()
    }

    fun getItem(position: Int): MediaListItem = mediaList[position]
    fun getAllPaths() = mediaList.filterIsInstance<MediaListItem.Media>().map { it.mediaBox.mediaPath }
    fun getAll() = mediaList

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): RecyclerView.ViewHolder {
        return when (viewType) {
            HEADER -> {
                val binding = ItemHeaderDividerBinding.inflate(
                    LayoutInflater.from(parent.context), parent, false
                )
                HeaderViewHolder(binding)
            }

            ALBUM -> {
                val binding = PhotoItemGridBinding.inflate(
                    LayoutInflater.from(parent.context), parent, false
                )
                MediaViewHolder(binding)
            }

            else -> {
                throw IllegalArgumentException("Invalid view type")
            }
        }
    }

    override fun getItemAt(position: Int): MediaListItem? {
        return mediaList.getOrNull(position)
    }

    override fun getItemKey(item: MediaListItem): Long {
        return item.id
    }

    override fun isSelectable(item: MediaListItem): Boolean {
        return item is MediaListItem.Media
    }

    override fun isHeader(position: Int): Boolean {
        return mediaList[position] is MediaListItem.Header
    }

    override fun isSelectionEnabled(): Boolean {
        return true
    }

    override fun bindItem(holder: RecyclerView.ViewHolder, item: MediaListItem, position: Int) {
        if (holder is MediaViewHolder) {
            holder.bind(mediaList[position] as MediaListItem.Media)
        } else if (holder is HeaderViewHolder) {
            holder.bind(mediaList[position] as MediaListItem.Header)
        }
    }

    override fun bindSelection(holder: RecyclerView.ViewHolder, item: MediaListItem, position: Int, selected: Boolean) {
        holder.itemView.isActivated = selected
        if (!isSelectable(item)) return
        when (holder) {
            is MediaViewHolder -> {
                if (isSelectionActive()) {
                    holder.binding.icUnSelect.visibility = View.VISIBLE
                    holder.binding.icSelect.visibility =
                        if (selected) View.VISIBLE else View.GONE
                } else {
                    holder.binding.icUnSelect.visibility = View.GONE
                    holder.binding.icSelect.visibility = View.GONE
                }
            }
        }
    }

    override fun onItemOpen(item: MediaListItem, position: Int, view: View) {
        if (item is MediaListItem.Media)
            onMediaClick.invoke(item.mediaBox)
    }

    override fun onSelectionModeUpdate() {
        notifyDataSetChanged()
    }


    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        if (holder is MediaViewHolder) {
            Glide.with(holder.binding.mediumThumbnail.context).clear(holder.binding.mediumThumbnail)
        }
    }

    override fun getItemViewType(position: Int): Int {
        return if (mediaList[position] is MediaListItem.Header) {
            HEADER
        } else {
            ALBUM
        }
    }

    override fun getItemCount(): Int = mediaList.size

    class HeaderViewHolder(private val binding: ItemHeaderDividerBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(header: MediaListItem.Header) {
            binding.txtHeader.text = header.header
        }
    }

    inner class MediaViewHolder(val binding: PhotoItemGridBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(media: MediaListItem.Media) {
            val mediaTransactionModel = media.mediaBox
            itemView.tag = mediaTransactionModel
            Log.e("CheckSorting", "bind: ${media.mediaBox.mediaPath} ${media.mediaBox.mediaSize}")
            val path = mediaTransactionModel.mediaPath
            binding.mediumThumbnail.loadGridImage(path, mediaTransactionModel.mediaDate)
            binding.icFavourite.beVisibleIf(media.isFavourite)

            if (isSelectionActive()) {
                binding.icUnSelect.visibility = View.VISIBLE
                binding.icSelect.visibility =
                    if (isItemSelected(bindingAdapterPosition)) View.VISIBLE else View.GONE
            } else {
                binding.icUnSelect.visibility = View.GONE
                binding.icSelect.visibility = View.GONE
            }

            try {
                binding.ivGif.beVisibleIf(
                    mediaTransactionModel.mediaPath.endsWith(
                        "gif", true
                    )
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }

            if (media.isVideo) {
                binding.icVideo.visibility = View.VISIBLE
            } else {
                binding.icVideo.visibility = View.GONE
            }

        }
    }
}