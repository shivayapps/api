package gallery.photogallery.photoeditor.galleryapp.old.storyview

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ClippingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.isInitialized

@UnstableApi
object ExoPlayerCache {
    lateinit var simpleCache: SimpleCache

    fun init(context: Context) {
        if (!::simpleCache.isInitialized) {
            val cacheDir = File(context.cacheDir, "exo_cache")
            val evictor = LeastRecentlyUsedCacheEvictor(100 * 1024 * 1024)
            val dbProvider = StandaloneDatabaseProvider(context)
            simpleCache = SimpleCache(cacheDir, evictor, dbProvider)
        }
    }

    fun getCacheFactory(context: Context): DataSource.Factory {
        return CacheDataSource.Factory()
            .setCache(simpleCache)
            .setUpstreamDataSourceFactory(DefaultDataSource.Factory(context))
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    }

    suspend fun cacheVideo(context: Context, filePath: String) {
        val mediaItem = MediaItem.fromUri(Uri.fromFile(File(filePath)))
        val baseSource = ProgressiveMediaSource.Factory(getCacheFactory(context.applicationContext))
            .createMediaSource(mediaItem)

        val clipped = ClippingMediaSource(
            baseSource,
            0,            // start at 0us
            10_000_000    // 10 seconds in microseconds
        )
        withContext(Dispatchers.Main) {
            val preloadPlayer = ExoPlayer.Builder(context.applicationContext).build()
            preloadPlayer.setMediaSource(clipped)
            preloadPlayer.prepare()
            preloadPlayer.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY) {
                        preloadPlayer.release()
                    }
                }
            })
        }
    }
}