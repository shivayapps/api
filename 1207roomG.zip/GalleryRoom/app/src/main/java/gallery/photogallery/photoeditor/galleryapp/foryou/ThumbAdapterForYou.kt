package gallery.photogallery.photoeditor.galleryapp.foryou

import android.content.Context.LAYOUT_INFLATER_SERVICE
import android.content.Intent
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.appblish.medialoader.AppblishImageLoader.loadListImage
import com.appblish.story.memories.api.model.MemoryBox
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.SelectMemoryCoverActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemForYouHeaderBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemMemoryCardBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.MemoryAllFavMenuBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.CreateMemoryDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.MemoriesDeleteDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.MemoriesMenuDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.getColorCompat
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.setOnSingleClickListener
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.PopupWindowHelper

class ThumbAdapterForYou(
    private val onMemoryClick: (MemoryBox, Int, View) -> Unit,
    private val onMemoryFilterClick: () -> Unit,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    val items = ArrayList<ForYouListItem>()

    fun submitList(list: List<ForYouListItem>) {
        items.clear()
        val header = list.filterIsInstance<ForYouListItem.Header>()
        var filterList = if (isFavMemoryShow) list.filterIsInstance<ForYouListItem.Memory>()
            .filter { it.memory.isFavourite } else list.filterIsInstance<ForYouListItem.Memory>()
        if (isFavMemoryShow && filterList.isEmpty()) {
            isFavMemoryShow = false
            filterList = list.filterIsInstance<ForYouListItem.Memory>()
        }
        items.addAll(header)
        items.addAll(filterList)
        notifyDataSetChanged()
    }

    companion object {
        private const val TYPE_MEMORY = 1
        private const val TYPE_HEADER = 2
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        if (holder is MemoryVH) {
            Glide.with(holder.binding.image.context.applicationContext)
                .clear(holder.binding.image)
        }
    }

    class MemoryVH(val binding: ItemMemoryCardBinding) :
        RecyclerView.ViewHolder(binding.root)

    class HeaderVH(val binding: ItemForYouHeaderBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun getItemViewType(position: Int): Int =
        when (items[position]) {
            is ForYouListItem.Memory -> TYPE_MEMORY
            is ForYouListItem.Header -> TYPE_HEADER
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {

            TYPE_MEMORY ->
                MemoryVH(ItemMemoryCardBinding.inflate(inflater, parent, false))

            TYPE_HEADER ->
                HeaderVH(ItemForYouHeaderBinding.inflate(inflater, parent, false))

            else -> error("Invalid type")
        }
    }

    fun getItem(position: Int) = items[position]
    override fun getItemCount(): Int = items.size
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        when (val item = getItem(position)) {


            is ForYouListItem.Memory ->
                bindMemory(holder as MemoryVH, item, position)

            is ForYouListItem.Header ->
                bindHeader(holder as HeaderVH)
        }
    }

    private fun bindHeader(holder: HeaderVH) {
        holder.binding.tvAllFav.text =
            if (isFavMemoryShow) holder.binding.tvAllFav.context.getString(R.string.Favorite) else holder.binding.tvAllFav.context.getString(R.string.all)
        holder.binding.llMemoryDropDown.beVisibleIf(items.filterIsInstance<ForYouListItem.Memory>().any { it.memory.isFavourite })
        holder.binding.llMemoryDropDown.setOnClickListener {
            showMemoryAllFavMenu(it, holder)
        }
    }

    private var isFavMemoryShow = false


    private fun showMemoryAllFavMenu(view: View, holder: HeaderVH) {
        val layoutInflater = view.context.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = MemoryAllFavMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)
        view.post {
            val location = IntArray(2)
            view.getLocationOnScreen(location) // Get view's location on screen
            val x = location[0] + view.width  // Position to the right of the view
            val y = location[1] + view.height            // Same Y position

            popupWindow.showAtLocation(view, Gravity.NO_GRAVITY, x, y)
        }
        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }
        val selectedColor = view.context.getColorCompat(R.color.color_primary)
        val unSelectedColor = view.context.getColorCompat(R.color.app_text_color)

        if (isFavMemoryShow) {
            popUpBinding.tvAll.setTextColor(unSelectedColor)
            popUpBinding.tvPhoto.setTextColor(selectedColor)
        } else {
            popUpBinding.tvAll.setTextColor(selectedColor)
            popUpBinding.tvPhoto.setTextColor(unSelectedColor)
        }
        popUpBinding.llAll.setOnClickListener {
            if (isFavMemoryShow) {
                isFavMemoryShow = false
                popupWindow.dismiss()
                holder.binding.tvAllFav.text =
                    if (isFavMemoryShow) holder.binding.tvAllFav.context.getString(R.string.Favorite) else holder.binding.tvAllFav.context.getString(R.string.all)
                onMemoryFilterClick.invoke()
            } else {
                popupWindow.dismiss()
            }
        }
        popUpBinding.llFav.setOnClickListener {
            if (isFavMemoryShow) {
                popupWindow.dismiss()
            } else {
                isFavMemoryShow = true
                popupWindow.dismiss()
                holder.binding.tvAllFav.text =
                    if (isFavMemoryShow) holder.binding.tvAllFav.context.getString(R.string.Favorite) else holder.binding.tvAllFav.context.getString(R.string.all)
                onMemoryFilterClick.invoke()

            }
        }
    }

    // ----------------------------------------------------------
    // MEMORY BINDER (normal image card)
    // ----------------------------------------------------------
    private fun bindMemory(holder: MemoryVH, item: ForYouListItem.Memory, adapterPos: Int) {
        val path = item.memory.mediaList.first().mediaPath
        val coverImageDate = item.memory.mediaList.first().mediaDate
        holder.binding.image.loadListImage(path, coverImageDate)

        if (item.memory.isFavourite) {
            holder.binding.ivFav.setImageResource(R.drawable.vec_favorite_fill)
        } else {
            holder.binding.ivFav.setImageResource(R.drawable.vec_favorite_un_fill)
        }
        holder.binding.tvTitle.text = item.memory.title
        holder.binding.tvSubTitle.text = item.memory.subTitle
        (holder.binding.ivInfo.context as? BaseActivity)?.let { activity ->
            try {
                if (item.memory.fontId != 0) {
                    // Load the font from the assets folder
                    val typeface = holder.binding.image.context.resources.getFont(item.memory.fontId)
                    // Apply the font to the TextView
                    holder.binding.tvTitle.typeface = typeface
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        holder.binding.ivFav.setOnSingleClickListener {
            (holder.binding.ivInfo.context as? BaseActivity)?.sharedViewModel?.updateMemoryFavourite(item.memory.memoryId, !item.memory.isFavourite)
        }
        holder.binding.ivInfo.setOnSingleClickListener {
            (holder.binding.ivInfo.context as? BaseActivity)?.let {
                showMemoryItemMenu(it, item)
            }

        }
        holder.itemView.setOnClickListener {
            onMemoryClick(item.memory, holder.bindingAdapterPosition, it)
        }

    }


    private fun showMemoryItemMenu(activity: BaseActivity, memory: ForYouListItem.Memory) {
        val dialog = MemoriesMenuDialog.newInstance {
            when (it) {
                1 -> {
                    val createDialog = CreateMemoryDialog()
                    createDialog.existTitle = memory.memory.title
                    createDialog.createListener = { newMemory ->
                        activity.sharedViewModel.updateMemoryTitle(memory.memory.memoryId, newMemory)
                    }
                    createDialog.show(activity.supportFragmentManager, "createDialog.tag")
                }

                2 -> {
                    activity.startActivity(
                        Intent(activity, SelectMemoryCoverActivity::class.java)
                            .putExtra("memoryId", memory.memory.memoryId)
                    )

                }

                3 -> {
                    val deleteDialog = MemoriesDeleteDialog.newInstance(btnClickListener = {
                        activity.sharedViewModel.deleteMemory(memory.memory.memoryId)

                    }, btnCancelListener = {})
                    deleteDialog.show(activity.supportFragmentManager, "DeleteMemoryDialog")
                }
            }
        }

        dialog.show(activity.supportFragmentManager, "MemoriesMenuDialog")
    }
}




