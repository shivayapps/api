package gallery.photogallery.photoeditor.galleryapp.collage.fragments


import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Color
import android.graphics.Shader
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import androidx.annotation.ColorInt
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.appblish.collagemaker.appblish.AppblishCollageText
import gallery.photogallery.photoeditor.galleryapp.collage.utils.TextEditor
 import com.appblish.collagemaker.utils.SystemUtil
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.collage.utils.CollageConst.getAllListTextShadow
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.FontAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.ShadowAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.TextBackgroundAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.TextColorAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.TextureAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.utils.FontFileAsset
import gallery.photogallery.photoeditor.galleryapp.collage.utils.PickerItem
import gallery.photogallery.photoeditor.galleryapp.databinding.FragmentAddTextNewBinding
import kotlin.math.roundToInt

class TextFragment : DialogFragment() {

    companion object {
        const val EXTRA_COLOR_CODE = "extra_color_code"
        const val EXTRA_INPUT_TEXT = "extra_input_text"
        const val TAG = "TextFragment"

        fun show(
            activity: AppCompatActivity, text: String, @ColorInt color: Int
        ): TextFragment {
            val bundle = Bundle().apply {
                putString(EXTRA_INPUT_TEXT, text)
                putInt(EXTRA_COLOR_CODE, color)
            }
            return TextFragment().apply {
                arguments = bundle
                show(activity.supportFragmentManager, TAG)
            }
        }


        fun show(appCompatActivity: AppCompatActivity, addTextProperties: AppblishCollageText?): TextFragment {
            val addTextFragment = TextFragment()
            addTextFragment.setPolishText(addTextProperties)
            addTextFragment.show(appCompatActivity.getSupportFragmentManager(), TAG)
            return addTextFragment
        }

        fun show(activity: AppCompatActivity): TextFragment {
            return show(activity, "Test", ContextCompat.getColor(activity, R.color.black))
        }
    }

    lateinit var appblishText: AppblishCollageText
    private lateinit var textTextureItems: List<PickerItem>
    private lateinit var binding: FragmentAddTextNewBinding
    private lateinit var fontAdapter: FontAdapter
    private lateinit var shadowAdapter: ShadowAdapter
    private lateinit var inputMethodManager: InputMethodManager
    private var textEditor: TextEditor? = null

    // ---------------- Lifecycle ----------------


    fun setPolishText(polishText: AppblishCollageText?) {
        if (polishText != null) {
            appblishText = polishText
        }
    }


    override fun onStart() {
        super.onStart()
        dialog?.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        dialog?.window?.apply {
            requestFeature(Window.FEATURE_NO_TITLE)
            setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        binding = FragmentAddTextNewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        inputMethodManager = requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        setupInitialData()
        setupAdapters()
        setupListeners()

        initPreviewText()
        toggleTextEditEditable(true)
    }

    // ---------------- Setup Methods ----------------

    private fun setupInitialData() {
        if (!::appblishText.isInitialized) {
            appblishText = AppblishCollageText.getDefaultProperties()
        }
        textTextureItems = getTextTextures()
//        binding.addTextEditText.textFragment = this
        highlightFunction(binding.imageViewKeyboard)
    }

    private fun setupAdapters() {

        binding.addTextEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (binding.addTextEditText.lineCount > 3) {
                    binding.addTextEditText.setText(s?.subSequence(0, s.length - 1))
                    binding.addTextEditText.setSelection(binding.addTextEditText.text.length)
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        })


        // Fonts
        binding.recyclerViewFonts.layoutManager = GridLayoutManager(context, 4)
        fontAdapter = FontAdapter(requireContext(), FontFileAsset.getListFonts()) { position ->
            val font = FontFileAsset.getListFonts()[position]
            FontFileAsset.setFontByName(requireContext(), binding.textViewPreviewEffect, font)
            appblishText.fontName = font
            appblishText.fontIndex = position
        }
        binding.recyclerViewFonts.adapter = fontAdapter

        // Shadows
        binding.recyclerViewShadow.layoutManager = GridLayoutManager(context, 4)
        shadowAdapter = ShadowAdapter(requireContext(), getAllListTextShadow()) { _, position ->
            val shadow = getAllListTextShadow()[position]
            binding.textViewPreviewEffect.setShadowLayer(
                shadow.radius.toFloat(), shadow.dx.toFloat(), shadow.dy.toFloat(), shadow.colorShadow
            )
            appblishText.textShadow = shadow
            appblishText.textShadowIndex = position
        }
        binding.recyclerViewShadow.adapter = shadowAdapter

        // Colors
        binding.recyclerViewColor.layoutManager = LinearLayoutManager(context, RecyclerView.HORIZONTAL, false)
        binding.recyclerViewColor.adapter = TextColorAdapter(requireContext()) { squareView ->
            binding.textViewPreviewEffect.setTextColor(squareView.drawableId)
            appblishText.textColor = squareView.drawableId
            binding.textViewPreviewEffect.paint.shader = null
            appblishText.textShader = null
        }

        // Background Colors
        binding.recyclerViewBackground.layoutManager = LinearLayoutManager(context, RecyclerView.HORIZONTAL, false)
        binding.recyclerViewBackground.adapter = TextBackgroundAdapter(requireContext()) { squareView ->
            appblishText.backgroundColor = squareView.drawableId
            appblishText.isShowBackground = true
            binding.checkboxBackground.isChecked = true
            updateBackgroundPreview()
        }


        val adapter = TextureAdapter(textTextureItems) { index, item ->

            val shader = BitmapShader(
                item.bitmap,
                Shader.TileMode.MIRROR,
                Shader.TileMode.MIRROR
            )

            binding.textViewPreviewEffect.apply {
                setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                paint.shader = shader
                invalidate()
            }

            appblishText.textShader = shader
            appblishText.textShaderIndex = index
        }




        binding.recyclerViewTexture.apply {
            layoutManager =
                LinearLayoutManager(requireContext(), RecyclerView.HORIZONTAL, false)
            this.adapter = adapter
        }

    }

    private fun setupListeners() {
        onClickEvent()

        // SeekBars
        binding.seekbarTextOpacity.setOnSeekBarChangeListener(createSeekBarListener { progress ->
            val alpha = 255 - progress
            appblishText.textAlpha = alpha
            binding.textViewSeekBarColor.text = progress.toString()
            binding.textViewPreviewEffect.setTextColor(adjustAlpha(appblishText.textColor, alpha))
        })

        binding.seekbarTextSize.setOnSeekBarChangeListener(createSeekBarListener { progress ->
            val size = if (progress < 15) 15 else progress
            binding.textViewSeekBarSize.text = size.toString()
            binding.textViewPreviewEffect.textSize = size.toFloat()
            appblishText.textSize = size
        })

        binding.seekbarBackgroundOpacity.setOnSeekBarChangeListener(createSeekBarListener { progress ->
            binding.textViewSeekBarBackground.text = progress.toString()
            appblishText.backgroundAlpha = 255 - progress
            updateBackgroundPreview()
        })

        binding.seekbarRadius.setOnSeekBarChangeListener(createSeekBarListener { progress ->
            binding.textViewSeekBarRadius.text = progress.toString()
            appblishText.backgroundBorder = progress
            updateBackgroundPreview()
        })


        binding.seekbarWidth.setOnSeekBarChangeListener(createSeekBarListener { progress ->
            binding.textViewSeekBarWith.text = progress.toString()
            this.appblishText.paddingWidth = progress

            binding.textViewPreviewEffect.setPadding(
                SystemUtil.dpToPx(requireContext(), progress), // Left
                binding.textViewPreviewEffect.paddingTop,      // Top
                SystemUtil.dpToPx(requireContext(), progress), // Right
                binding.textViewPreviewEffect.paddingBottom   // Bottom
            )
        })

        binding.seekbarHeight.setOnSeekBarChangeListener(createSeekBarListener { progress ->
            binding.textViewSeekBarHeight.text = progress.toString()
            this.appblishText.paddingHeight = progress

            binding.textViewPreviewEffect.setPadding(
                binding.textViewPreviewEffect.paddingLeft,      // Left
                SystemUtil.dpToPx(requireContext(), progress),  // Top
                binding.textViewPreviewEffect.paddingRight,     // Right
                SystemUtil.dpToPx(requireContext(), progress)   // Bottom
            )
        })
        // Text Watcher
        binding.addTextEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, i: Int, i2: Int, i3: Int) {}
            override fun onTextChanged(s: CharSequence?, i: Int, i2: Int, i3: Int) {
                val text = s?.toString().orEmpty()
                binding.textViewPreviewEffect.text = text
                appblishText.text = text
            }
        })

        binding.checkboxBackground.setOnCheckedChangeListener { _, isChecked ->
            appblishText.isShowBackground = isChecked
            if (!isChecked) {
                binding.textViewPreviewEffect.setBackgroundResource(0)
            } else {
                updateBackgroundPreview()
            }
        }
    }

    // ---------------- Interaction Logic ----------------

    private fun onClickEvent() {
        openSubMenu(binding.imageViewKeyboard, binding.imageViewKeyboard)
        binding.textViewFont.setOnClickListener {
            toggleFontShadowTabs(showFonts = true)
        }

        binding.textViewShadow.setOnClickListener {
            toggleFontShadowTabs(showFonts = false)
        }

        binding.imageViewAlignLeft.setOnClickListener { setAlignment(2) }
        binding.imageViewAlignCenter.setOnClickListener { setAlignment(4) }
        binding.imageViewAlignRight.setOnClickListener { setAlignment(3) }

        binding.imageViewAdjust.setOnClickListener {
            openSubMenu(binding.imageViewAdjust, binding.scrollViewChangeColorAdjust)
            syncAdjustSeekbars()
        }

        binding.imageViewColor.setOnClickListener {
            openSubMenu(binding.imageViewColor, binding.scrollViewChangeColorLayout)
        }

        binding.imageViewFonts.setOnClickListener {
            openSubMenu(binding.imageViewFonts, binding.llScrollViewChangeFontLayout)
            shadowAdapter.selectedItem = appblishText.fontIndex
            fontAdapter.setSelectedItem(appblishText.fontIndex)
        }

        binding.imageViewKeyboard.setOnClickListener {
            openSubMenu(binding.imageViewKeyboard, binding.imageViewKeyboard)

            keyboardClick()
        }

        binding.imageViewSaveChange.setOnClickListener {
            hideKeyboard(it)
            if (appblishText.text.isNullOrEmpty()) {
                textEditor?.onBackButton()
            } else {
                appblishText.textWidth = binding.textViewPreviewEffect.measuredWidth
                appblishText.textHeight = binding.textViewPreviewEffect.measuredHeight
                textEditor?.onDone(appblishText)
            }


            dismiss()
        }

        binding.imageViewClose.setOnClickListener {
            hideKeyboard(it)
            textEditor?.onBackButton()
            dismiss()
        }
    }

    // ---------------- Helper Methods ----------------

    private fun updateBackgroundPreview() {
        val gd = GradientDrawable().apply {
            cornerRadius = SystemUtil.dpToPx(requireContext(), appblishText.backgroundBorder).toFloat()
            setColor(adjustAlpha(appblishText.backgroundColor, appblishText.backgroundAlpha))
        }
        binding.textViewPreviewEffect.background = gd
    }

    private fun adjustAlpha(color: Int, alpha: Int): Int {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
    }

    private fun setAlignment(alignment: Int) {
        appblishText.textAlign = alignment
        updateAlignmentIcons()
        updatePreviewAlignment()
    }

    private fun updateAlignmentIcons() {

        val selectedColor = ContextCompat.getColor(requireContext(), R.color.color_primary)
        val defaultColor = ContextCompat.getColor(requireContext(), R.color.color_text)

        binding.imageViewAlignLeft.setColorFilter(
            if (appblishText.textAlign == 2) selectedColor else defaultColor
        )

        binding.imageViewAlignCenter.setColorFilter(
            if (appblishText.textAlign == 4) selectedColor else defaultColor
        )

        binding.imageViewAlignRight.setColorFilter(
            if (appblishText.textAlign == 3) selectedColor else defaultColor
        )
    }



    private fun openSubMenu(icon: ImageView, menuLayout: View) {
        hideKeyboard(icon)
        binding.scrollViewChangeColorLayout.visibility = View.GONE
        binding.scrollViewChangeColorAdjust.visibility = View.GONE
        binding.llScrollViewChangeFontLayout.visibility = View.GONE

        menuLayout.visibility = View.VISIBLE

        toggleTextEditEditable(false)
        highlightFunction(icon)
        updateAddTextBottomToolbarHeight(0, false)
    }

    private fun syncAdjustSeekbars() {
        binding.seekbarBackgroundOpacity.progress = 255 - appblishText.backgroundAlpha
        binding.seekbarTextSize.progress = appblishText.textSize
        binding.seekbarRadius.progress = appblishText.backgroundBorder
        binding.seekbarWidth.progress = appblishText.paddingWidth
        binding.seekbarHeight.progress = appblishText.paddingHeight
        binding.seekbarTextOpacity.progress = 255 - appblishText.textAlpha
    }

    private fun toggleFontShadowTabs(showFonts: Boolean) {
        binding.textViewFont.background = if (showFonts) ContextCompat.getDrawable(requireContext(), R.drawable.shape_btn) else null
        binding.textViewShadow.background = if (!showFonts) ContextCompat.getDrawable(requireContext(), R.drawable.shape_btn) else null
        binding.recyclerViewFonts.visibility = if (showFonts) View.VISIBLE else View.GONE
        binding.recyclerViewShadow.visibility = if (!showFonts) View.VISIBLE else View.GONE
    }

    private fun createSeekBarListener(onProgress: (Int) -> Unit): OnSeekBarChangeListener {
        return object : OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, b: Boolean) {
                onProgress(p)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        }
    }

    private fun updatePreviewAlignment() {
        binding.textViewPreviewEffect.textAlignment = appblishText.textAlign
        // Force redraw text to apply alignment changes
        val currentText = binding.textViewPreviewEffect.text.toString()
        binding.textViewPreviewEffect.text = currentText
    }

    private fun hideKeyboard(view: View) {
        inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
    }

    private fun keyboardClick() {
        toggleTextEditEditable(true)
        highlightFunction(binding.imageViewKeyboard)
    }

    private fun toggleTextEditEditable(enable: Boolean) {
        binding.addTextEditText.apply {
            isFocusable = enable
            isFocusableInTouchMode = enable
            isClickable = enable
            if (enable) {
                requestFocus()
                postDelayed({
                    inputMethodManager.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
                }, 200)
            }
        }
    }


    private fun highlightFunction(view: ImageView) {
        binding.viewKeyBoard.visibility = if (view.id == R.id.imageViewKeyboard) View.VISIBLE else View.GONE
        binding.viewFonts.visibility = if (view.id == R.id.imageViewFonts) View.VISIBLE else View.GONE
        binding.viewColor.visibility = if (view.id == R.id.imageViewColor) View.VISIBLE else View.GONE
        binding.viewAdjust.visibility = if (view.id == R.id.imageViewAdjust) View.VISIBLE else View.GONE
    }

    private fun initPreviewText() {
        if (appblishText.isShowBackground) updateBackgroundPreview()

        binding.textViewPreviewEffect.setPadding(
            SystemUtil.dpToPx(requireContext(), appblishText.paddingWidth),
            SystemUtil.dpToPx(requireContext(), appblishText.paddingHeight),
            SystemUtil.dpToPx(requireContext(), appblishText.paddingWidth),
            SystemUtil.dpToPx(requireContext(), appblishText.paddingHeight)
        )

        appblishText.text?.let {
            binding.textViewPreviewEffect.text = it
            binding.addTextEditText.setText(it)
        }

        appblishText.textShader?.let {
            binding.textViewPreviewEffect.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            binding.textViewPreviewEffect.paint.shader = it
        }

        updateAlignmentIcons()
        binding.textViewPreviewEffect.setTextColor(appblishText.textColor)
        binding.textViewPreviewEffect.textSize = appblishText.textSize.toFloat()
        FontFileAsset.setFontByName(requireContext(), binding.textViewPreviewEffect, appblishText.fontName)
        binding.textViewPreviewEffect.invalidate()
    }


    private fun getTextTextures(): List<PickerItem> {
        val items = ArrayList<PickerItem>()

        for (i in 1..42) {
            try {
                val input = requireContext().assets.open("texture/texture_$i.webp")
                val bitmap = BitmapFactory.decodeStream(input)
                val drawable = BitmapDrawable(resources, bitmap)

                items.add(PickerItem.Texture(drawable, bitmap))
            } catch (e: Exception) {
                // skip
            }
        }
        return items
    }


    fun setOnTextEditorListener(listener: TextEditor?) {
        this.textEditor = listener
    }

    fun updateAddTextBottomToolbarHeight(i: Int, isKeyboard: Boolean) {
        Handler(Looper.getMainLooper()).post {
            binding.llBottomText.visibility = if (isKeyboard) View.GONE else View.VISIBLE
        }
    }


    fun dismissAndShowSticker() {
        if (textEditor != null) {
            textEditor!!.onBackButton()
        }
        dismiss()
    }

}
