package gallery.photogallery.photoeditor.galleryapp.activities

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityUninstallProtectionBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.receiver.AppDeviceAdminReceiver
import gallery.photogallery.photoeditor.galleryapp.utils.UPDATE_PROTECTION
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class UninstallProtectionActivity : BaseActivity() {

    private val binding by viewBinding(ActivityUninstallProtectionBinding::inflate)
    private val requestDeviceAdminLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            initView()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding.root.setPadding(0, statusBarHeight, 0, navigationBarHeight)
        setContentView(binding.root)
        registerEventBus(this)
        initView()
        clickListener()
    }

    private fun initView() {
        val isAdminActive = isAdminActive()
        Log.d("DeviceAdmin", "isAdminActive:$isAdminActive")
        binding.tvUninstallProtectionOn.beVisibleIf(isAdminActive)
        binding.tvBtnText.text = getString(if (isAdminActive) R.string.deactivate_protection else R.string.active_protection)
    }

    fun isAdminActive(): Boolean {
        val devicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val componentName = ComponentName(this, AppDeviceAdminReceiver::class.java)
        return devicePolicyManager.isAdminActive(componentName)
    }

    private fun requestDeviceAdminPermission() {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(
                DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                ComponentName(this@UninstallProtectionActivity, AppDeviceAdminReceiver::class.java)
            )
        }
        requestDeviceAdminLauncher.launch(intent)
    }

    private fun removeDeviceAdminPermission() {
        val devicePolicyManager =
            getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

        val componentName =
            ComponentName(this, AppDeviceAdminReceiver::class.java)

        if (devicePolicyManager.isAdminActive(componentName)) {
            devicePolicyManager.removeActiveAdmin(componentName)
        }
    }

    private fun clickListener() {
        binding.llActiveProtection.setOnClickListener {
            val isAdminActive = isAdminActive()
            if (isAdminActive) {
                removeDeviceAdminPermission()
            } else {
                requestDeviceAdminPermission()
            }
        }
        binding.ivBack.setOnClickListener {
            finish()
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            UPDATE_PROTECTION -> {
                lifecycleScope.launch {
                    delay(500)
                    initView()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterEventBus(this)
    }
}