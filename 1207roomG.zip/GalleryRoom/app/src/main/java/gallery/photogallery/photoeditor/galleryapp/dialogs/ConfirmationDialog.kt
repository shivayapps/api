package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ConfirmationDialogBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.applyColorFilter

class ConfirmationDialog(
    val activity: BaseActivity,
    val tvTitle: String,
    val tvSubTitle: String,
    val btnCancel: String,
    val btnPositive: String,
    val btnPositiveColor: Int = 0,
    val isDarkMode: Boolean = false,
    val callback: () -> Unit,
) : DialogFragment() {
    private var _binding: ConfirmationDialogBinding? = null

    private val binding get() = _binding!!
    private lateinit var safeContext: Context

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = ConfirmationDialogBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        initView()
        clickListener()
        return dialog
    }

    private fun initView() {
        if (tvTitle == getString(gallery.photogallery.photoeditor.galleryapp.R.string.hide)) {
            binding.tvTitle.visibility = View.GONE

        } else {
            binding.tvTitle.visibility = View.VISIBLE

        }
        if (isDarkMode) {
            val buttonBg = Color.parseColor("#434343")
            val subText = Color.parseColor("#717171")
            binding.tvTitle.setTextColor(Color.WHITE)
            binding.tvSubTitle.setTextColor(Color.WHITE)
            binding.btnCancel.setTextColor(Color.WHITE)
            binding.txtRestoredMsg.setTextColor(subText)
            binding.btnCancel.background.applyColorFilter(buttonBg)
//            binding.viewPin.background.applyColorFilter(buttonBg)
            val backgroundColor = Color.parseColor("#242527")
            binding.root.background.applyColorFilter(backgroundColor)
        }
        binding.tvTitle.text = tvTitle
        binding.tvSubTitle.text = tvSubTitle
        binding.btnCancel.text = btnCancel
        binding.btnPositive.text = btnPositive
        if (btnPositiveColor != 0) {
            binding.btnPositive.setTextColor(btnPositiveColor)
        }
    }

    private fun clickListener() {
        binding.btnCancel.setOnClickListener { dismiss() }
        binding.btnPositive.setOnClickListener {
            dismiss()
            callback.invoke()
        }
    }
}