package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils

import android.content.Context
import android.content.SharedPreferences
import android.os.Environment
import android.text.format.DateFormat
import androidx.core.content.edit
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant.pref_rate_app
import java.text.SimpleDateFormat
import java.util.Locale

open class Preferences(private var context: Context) {

    fun setVideoPlayPosition(name: String, value: Int) {
        editor.putInt("pos_$name", value)
        editor.apply()
    }

    fun getVideoPlayPosition(name: String): Int {
        return prefs.getInt("pos_$name", 0)
    }


    val prefs: SharedPreferences =
        context.getSharedPreferences(Constant.PREF_NAME, Context.MODE_PRIVATE)
    val editor: SharedPreferences.Editor = prefs.edit()

    var albumAsGrid: Boolean
        get() = prefs.getBoolean("albumAsGrid", true)
        set(albumAsGrid) = prefs.edit().putBoolean("albumAsGrid", albumAsGrid)
            .apply()

    var albumGrid: Int
        get() = prefs.getInt("albumGrid", 3)
        set(albumGrid) = prefs.edit().putInt("albumGrid", albumGrid)
            .apply()

    var mediaGrid: Int
        get() = prefs.getInt("mediaGrid", 3)
        set(mediaGrid) = prefs.edit().putInt("mediaGrid", mediaGrid)
            .apply()

    var onStoryShareDone: Boolean
        get() = prefs.getBoolean("onStoryShareDone", false)
        set(value) = prefs.edit()
            .putBoolean("onStoryShareDone", value).apply()

    var isRequireRefresh: Boolean
        get() = prefs.getBoolean("isRequireRefreshUpdate", true)
        set(welcomeDone) = prefs.edit()
            .putBoolean("isRequireRefreshUpdate", welcomeDone).apply()

    var lastSycTime: Long
        get() = prefs.getLong("lastSycTime", 0)
        set(welcomeDone) = prefs.edit()
            .putLong("lastSycTime", welcomeDone).apply()

    var allowDownGesture: Boolean
        get() = prefs.getBoolean(Constant.ALLOW_DOWN_GESTURE, true)
        set(allowDownGesture) = prefs.edit()
            .putBoolean(Constant.ALLOW_DOWN_GESTURE, allowDownGesture).apply()

    var hideUIOnFullScreen: Boolean
        get() = prefs.getBoolean(Constant.HIDE_UI_ON_FULL_SCREEN, false)
        set(allowDownGesture) = prefs.edit()
            .putBoolean(Constant.HIDE_UI_ON_FULL_SCREEN, allowDownGesture).apply()

    var deleteEmptyFolders: Boolean
        get() = prefs.getBoolean("deleteEmptyFolders", false)
        set(deleteEmptyFolders) = prefs.edit().putBoolean("deleteEmptyFolders", deleteEmptyFolders)
            .apply()

    var use24HourFormat: Boolean
        get() = prefs.getBoolean("USE_24_HOUR_FORMAT", DateFormat.is24HourFormat(context))
        set(use24HourFormat) = prefs.edit().putBoolean("USE_24_HOUR_FORMAT", use24HourFormat)
            .apply()

    var dateFormat: String
        get() = prefs.getString("DATE_FORMAT_NEW", getDefaultDateFormat())!!
        set(dateFormat) = prefs.edit().putString("DATE_FORMAT_NEW", dateFormat).apply()

    private fun getDefaultDateFormat(): String {
        val format = DateFormat.getDateFormat(context)
        val pattern = (format as SimpleDateFormat).toLocalizedPattern()
        return when (pattern.lowercase().replace(" ", "")) {
            "d.M.y" -> DATE_FORMAT_ONE
            "dd/mm/y" -> DATE_FORMAT_TWO
            "mm/dd/y" -> DATE_FORMAT_THREE
            "y-mm-dd" -> DATE_FORMAT_FOUR
            "dmmmmy" -> DATE_FORMAT_FIVE
            "mmmmdy" -> DATE_FORMAT_SIX
            "mm-dd-y" -> DATE_FORMAT_SEVEN
            "dd-mm-y" -> DATE_FORMAT_EIGHT
            else -> DATE_FORMAT_ONE
        }
    }

    var enableFingerprint: Boolean
        get() = prefs.getBoolean("USE_FINGERPRINT", false)
        set(enableFingerprint) = prefs.edit().putBoolean("USE_FINGERPRINT", enableFingerprint)
            .apply()
//    var hideSystemUI: Boolean
//        get() = prefs.getBoolean("HIDE_SYSTEM_UI", false)
//        set(hideSystemUI) = prefs.edit().putBoolean("HIDE_SYSTEM_UI", hideSystemUI).apply()

    var hideVault: Boolean
        get() = prefs.getBoolean("VAULT_VISIBILITY", false)
        set(hideVault) = prefs.edit().putBoolean("VAULT_VISIBILITY", hideVault).apply()
    var hintExclude: Boolean
        get() = prefs.getBoolean("hintExclude", false)
        set(hideVault) = prefs.edit().putBoolean("hintExclude", hideVault).apply()
    var hintRecycle: Boolean
        get() = prefs.getBoolean("hintRecycle", false)
        set(hideVault) = prefs.edit().putBoolean("hintRecycle", hideVault).apply()

    var maxBrightness: Boolean
        get() = prefs.getBoolean("MAX_BRIGHTNESS", false)
        set(maxBrightness) = prefs.edit().putBoolean("MAX_BRIGHTNESS", maxBrightness).apply()

    var keepLastModified: Boolean
        get() = prefs.getBoolean("KEEP_LAST_MODIFIED", true)
        set(keepLastModified) = prefs.edit().putBoolean("KEEP_LAST_MODIFIED", keepLastModified)
            .apply()

    var passwordRetryCount: Int
        get() = prefs.getInt("PASSWORD_RETRY_COUNT", 0)
        set(passwordRetryCount) = prefs.edit().putInt("PASSWORD_RETRY_COUNT", passwordRetryCount)
            .apply()


    var passwordCountdownStartMs: Long
        get() = prefs.getLong("PASSWORD_COUNTDOWN_START_MS", 0L)
        set(passwordCountdownStartMs) = prefs.edit()
            .putLong("PASSWORD_COUNTDOWN_START_MS", passwordCountdownStartMs).apply()

    fun removeLastVideoPosition(path: String) {
        prefs.edit()
            .remove("${Constant.LAST_VIDEO_POSITION_PREFIX}${path.lowercase(Locale.getDefault())}")
            .apply()
    }

    fun saveLastVideoPosition(path: String, value: Int) {
        if (path.isNotEmpty()) {
            prefs.edit().putInt(
                "${Constant.LAST_VIDEO_POSITION_PREFIX}${path.lowercase(Locale.getDefault())}",
                value
            ).apply()
        }
    }

    fun getLastVideoPosition(path: String) = prefs.getInt(
        "${Constant.LAST_VIDEO_POSITION_PREFIX}${
            path.lowercase(
                Locale.getDefault()
            )
        }", 0
    )

    fun getAllLastVideoPositions() = prefs.all.filterKeys {
        it.startsWith(Constant.LAST_VIDEO_POSITION_PREFIX)
    }

    var loopVideos: Boolean
        get() = prefs.getBoolean(Constant.LOOP_VIDEOS, false)
        set(loop) = prefs.edit().putBoolean(Constant.LOOP_VIDEOS, loop).apply()

    var rememberLastVideoPosition: Boolean
        get() = prefs.getBoolean(Constant.REMEMBER_LAST_VIDEO_POSITION, false)
        set(rememberLastVideoPosition) {
            if (!rememberLastVideoPosition) {
                getAllLastVideoPositions().forEach {
                    prefs.edit().remove(it.key).apply()
                }
            }
            prefs.edit()
                .putBoolean(Constant.REMEMBER_LAST_VIDEO_POSITION, rememberLastVideoPosition)
                .apply()
        }

    var screenRotation: Int
        get() = prefs.getInt(Constant.SCREEN_ROTATION, Constant.ROTATE_BY_SYSTEM_SETTING)
        set(screenRotation) = prefs.edit().putInt(Constant.SCREEN_ROTATION, screenRotation).apply()

    var blackBackground: Boolean
        get() = prefs.getBoolean(Constant.BLACK_BACKGROUND, true)
        set(blackBackground) = prefs.edit().putBoolean(Constant.BLACK_BACKGROUND, blackBackground)
            .apply()

    var showExtendedDetails: Boolean
        get() = prefs.getBoolean(Constant.SHOW_EXTENDED_DETAILS, false)
        set(showExtendedDetails) = prefs.edit()
            .putBoolean(Constant.SHOW_EXTENDED_DETAILS, showExtendedDetails).apply()

    var hideExtendedDetails: Boolean
        get() = prefs.getBoolean(Constant.HIDE_EXTENDED_DETAILS, false)
        set(hideExtendedDetails) = prefs.edit()
            .putBoolean(Constant.HIDE_EXTENDED_DETAILS, hideExtendedDetails).apply()

    var extendedDetails: Int
        get() = prefs.getInt(
            Constant.EXTENDED_DETAILS,
            Constant.EXT_RESOLUTION or Constant.EXT_LAST_MODIFIED or Constant.EXT_EXIF_PROPERTIES
        )
        set(extendedDetails) = prefs.edit().putInt(Constant.EXTENDED_DETAILS, extendedDetails)
            .apply()

    var showHighestQuality: Boolean
        get() = prefs.getBoolean(Constant.SHOW_HIGHEST_QUALITY, false)
        set(showHighestQuality) = prefs.edit()
            .putBoolean(Constant.SHOW_HIGHEST_QUALITY, showHighestQuality).apply()

    var allowPhotoGestures: Boolean
        get() = prefs.getBoolean(Constant.ALLOW_PHOTO_GESTURES, false)
        set(allowPhotoGestures) = prefs.edit()
            .putBoolean(Constant.ALLOW_PHOTO_GESTURES, allowPhotoGestures).apply()

    var allowZoomingImages: Boolean
        get() = prefs.getBoolean(Constant.ALLOW_ZOOMING_IMAGES, true)
        set(allowZoomingImages) = prefs.edit()
            .putBoolean(Constant.ALLOW_ZOOMING_IMAGES, allowZoomingImages).apply()

//    var allowInstantChange: Boolean
//        get() = prefs.getBoolean("allow_instant_change", false)
//        set(allowInstantChange) = prefs.edit()
//            .putBoolean("allow_instant_change", allowInstantChange).apply()

    var allowOneToOneZoom: Boolean
        get() = prefs.getBoolean(Constant.ALLOW_ONE_TO_ONE_ZOOM, false)
        set(allowOneToOneZoom) = prefs.edit()
            .putBoolean(Constant.ALLOW_ONE_TO_ONE_ZOOM, allowOneToOneZoom).apply()

    var allowRotatingWithGestures: Boolean
        get() = prefs.getBoolean(Constant.ALLOW_ROTATING_WITH_GESTURES, true)
        set(allowRotatingWithGestures) = prefs.edit()
            .putBoolean(Constant.ALLOW_ROTATING_WITH_GESTURES, allowRotatingWithGestures).apply()
    var isSetLanguage: Boolean
        get() = prefs.getBoolean("isSetLanguage", false)
        set(isSetLanguage) = prefs.edit().putBoolean("isSetLanguage", isSetLanguage).apply()

    fun getCoverImage(album: String): String {
        return prefs.getString("AlbumCover$album", "") ?: ""
    }

    fun setCoverImage(album: String, path: String) {
        editor.putString("AlbumCover$album", path)
        editor.apply()
    }

    var appOpenCounter: Int
        get() = prefs.getInt("appOpenCounter", 0)
        set(value) = prefs.edit().putInt("appOpenCounter", value).apply()

    var splashCounter: Int
        get() = prefs.getInt("splashCounter", 0)
        set(splashCounter) = prefs.edit().putInt("splashCounter", splashCounter).apply()

    var selectedLanguage: String
        get() = prefs.getString("selectedLanguage", "") ?: ""
        set(selectedLanguage) = prefs.edit().putString("selectedLanguage", selectedLanguage).apply()

    fun getSelectedLang(context: Context): String {
        if (selectedLanguage.isEmpty() || selectedLanguage == "default") {
            val languageCodes = context.resources.getStringArray(R.array.language_code)
            return languageCodes.find {
                Locale.getDefault().language.contains(it.lowercase())
            } ?: ""
        }
        return selectedLanguage
    }

    fun setSelectedLang(selectedLanguage: String) {
        this.selectedLanguage = selectedLanguage
    }

    var selectedLanguageName: String
        get() = prefs.getString("selectedLanguageName", "") ?: ""
        set(selectedLanguageName) = prefs.edit().putString("selectedLanguageName", selectedLanguageName).apply()


    fun putTheme(themeValue: Int) {
        editor.putInt(Constant.PREF_KEY_THEME, themeValue)
        editor.apply()
    }

    fun putDeleteBehavior(deleteValue: Int) {
        editor.putInt(Constant.PREF_KEY_DELETE_BEHAVIOR, deleteValue)
        editor.apply()
    }

    fun getDeleteBehavior(): Int {
        return prefs.getInt(Constant.PREF_KEY_DELETE_BEHAVIOR, Constant.DELETE_BEHAVIOR_ALWAYS_ASK)
    }

    fun getThemeValue(): Int {
        return prefs.getInt(Constant.PREF_KEY_THEME, Constant.THEME_SYSTEM)
    }

    var isMediaPermissionRationale: Boolean
        get() = prefs.getBoolean("isMediaPermissionRationale", false)
        set(value) = prefs.edit().putBoolean("isMediaPermissionRationale", value).apply()

    fun setLastAlBumCreated(result: String) {
        editor.putString(Constant.PREF_ALBUM_CREATED, result)
        editor.apply()
    }

    fun removeLastAlBumCreated() {
        editor.remove(Constant.PREF_ALBUM_CREATED)
        editor.apply()
    }

    fun getLastAlBumCreated(): String {
        return prefs.getString(Constant.PREF_ALBUM_CREATED, "") ?: ""
    }

    fun setAlbumSortType(result: Int, folder: String? = "") {
        editor.putInt("${Constant.PREFS_FOLDER_SORT_TYPE}$folder", result)
        editor.apply()
    }

    fun getAlbumSortType(folder: String? = ""): Int {
        return prefs.getInt(
            "${Constant.PREFS_FOLDER_SORT_TYPE}$folder",
            Constant.SORT_LAST_MODIFIED
        )
    }

    fun setSortType(result: Int, folder: String? = "") {
        editor.putInt("${Constant.PREFS_SORT_TYPE}$folder", result)
        editor.apply()
    }

    fun getSortType(folder: String? = ""): Int {
        return prefs.getInt("${Constant.PREFS_SORT_TYPE}$folder", Constant.SORT_LAST_MODIFIED)
    }

    fun setFilterMedia(result: Int) {
        editor.putInt(Constant.FILTER_MEDIA, result)
        editor.apply()
    }

    fun getFilterMedia(): Int {
        return prefs.getInt(Constant.FILTER_MEDIA, getDefaultFileFilter())
    }

    fun setGroupBy(result: Int, folder: String? = "") {
        editor.putInt("${Constant.GROUP_BY}$folder", result)
        editor.apply()
    }

    fun getGroupBy(folder: String? = ""): Int {
//        return prefs.getInt(Constant.GROUP_BY, Constant.GROUP_BY_LAST_MODIFIED_DAILY)
        return prefs.getInt("${Constant.GROUP_BY}$folder", Constant.GROUP_BY_LAST_MODIFIED_DAILY)
    }

//    fun setAlbumGroupType(result: Int) {
//        editor.putInt(Constant.PREFS_FOLDER_GROUP_TYPE, result)
//        editor.apply()
//    }
//    fun getAlbumGroupType(): Int {
//        return prefs.getInt(Constant.PREFS_FOLDER_GROUP_TYPE, Constant.GROUP_BY_LAST_MODIFIED_DAILY)
//    }

    fun setGroupOrderBy(result: Int, folder: String? = "") {
        editor.putInt("${Constant.GROUP_ORDER_BY}$folder", result)
        editor.apply()
    }

    fun getGroupOrderBy(folder: String? = ""): Int {
        return prefs.getInt("${Constant.GROUP_ORDER_BY}$folder", Constant.GROUP_BY_NONE)
    }

    fun setAlbumSortOrder(result: Int, folder: String? = "") {
        editor.putInt("${Constant.PREFS_FOLDER_SORT_ORDER}$folder", result)
        editor.apply()
    }

    fun getAlbumSortOrder(folder: String? = ""): Int {
        return prefs.getInt(
            "${Constant.PREFS_FOLDER_SORT_ORDER}$folder",
            Constant.SORT_LAST_MODIFIED
        )
    }
//    fun setAlbumSortOrder(result: Int) {
//        editor.putInt(Constant.PREFS_FOLDER_SORT_ORDER, result)
//        editor.apply()
//    }
//    fun getAlbumSortOrder(): Int {
//        return prefs.getInt(Constant.PREFS_FOLDER_SORT_ORDER, Constant.ORDER_DESCENDING)
//    }

    fun setInt(key: String, result: Int) {
        editor.putInt(key, result)
        editor.apply()
    }

    fun getInt(key: String, default: Int? = 0): Int {
        return prefs.getInt(key, default!!)
    }

    fun setString(key: String, result: String) {
        editor.putString(key, result)
        editor.apply()
    }

    fun getString(key: String, default: String? = ""): String {
        return prefs.getString(key, default!!) ?: ""
    }

    fun setBoolean(key: String, result: Boolean) {
        editor.putBoolean(key, result)
        editor.apply()
    }

    fun getBoolean(key: String, default: Boolean? = false): Boolean {
        return prefs.getBoolean(key, default!!)
    }

//    fun setAlbumGroupOrder(result: Int) {
//        editor.putInt(Constant.PREFS_FOLDER_GROUP_ORDER, result)
//        editor.apply()
//    }
//    fun getAlbumGroupOrder(): Int {
//        return sharedPreferences.getInt(Constant.PREFS_FOLDER_GROUP_ORDER, Constant.ORDER_DESCENDING)
//    }


    fun setSortOrder(result: Int, folder: String? = "") {
        editor.putInt("${Constant.PREFS_SORT_ORDER}$folder", result)
        editor.apply()
    }

    fun getSortOrder(folder: String? = ""): Int {
        return prefs.getInt("${Constant.PREFS_SORT_ORDER}$folder", Constant.ORDER_DESCENDING)
    }

    fun setGridCount(result: Int, folder: String? = "") {
        editor.putInt("${Constant.PREFS_GRID_COUNT}$folder", result)
        editor.apply()
    }

    fun getGridCount(folder: String? = ""): Int {
        return prefs.getInt("${Constant.PREFS_GRID_COUNT}$folder", 3)
//        return prefs.getInt(Constant.PREFS_GRID_COUNT, 3)
    }

    fun setAlbumGridCount(result: Int) {
        editor.putInt(Constant.PREFS_ALBUM_GRID_COUNT, result)
        editor.apply()
    }

    fun getAlbumGridCount(): Int {
        return prefs.getInt(Constant.PREFS_ALBUM_GRID_COUNT, 3)
    }

    fun putShowGrid(result: Boolean) {
        editor.putBoolean(Constant.PREFS_GRID_SHOW, result)
        editor.apply()
    }

    fun getShowGrid(): Boolean {
        return prefs.getBoolean(Constant.PREFS_GRID_SHOW, true)
    }

    fun putShowFileCount(result: Boolean) {
        editor.putBoolean(Constant.PREFS_SHOW_FILE_COUNT, result)
        editor.apply()
    }

    fun getShowFileCount(): Boolean {
        return prefs.getBoolean(Constant.PREFS_SHOW_FILE_COUNT, false)
    }

//    fun putShowPinLock(result: Boolean) {
//        editor.putBoolean(Constant.PREFS_LOCK_STYLE, result)
//        editor.apply()
//    }
//
//    fun getShowPINLock(): Boolean {
//        return prefs.getBoolean(Constant.PREFS_LOCK_STYLE, true)
//    }

    fun putSetPass(result: Boolean) {
        editor.putBoolean("passcode_set", result)
        editor.apply()
    }

    fun getSetPass(): Boolean {
        return prefs.getBoolean("passcode_set", false)
    }

    fun putPass(result: String) {
        editor.putString(Constant.PREF_PASSCODE, result)
        editor.apply()
    }

    fun getPass(): String? {
        return prefs.getString(Constant.PREF_PASSCODE, "")
    }

//    fun putSetPattern(result: Boolean) {
//        editor.putBoolean(Constant.PREF_PATTERN_SET, result)
//        editor.apply()
//    }
//
//    fun getSetPattern(): Boolean {
//        return prefs.getBoolean(Constant.PREF_PATTERN_SET, false)
//    }

    fun putPattern(result: String) {
        editor.putString(Constant.PREF_PATTERN, result)
        editor.apply()
    }

    fun getPattern(): String? {
        return prefs.getString(Constant.PREF_PATTERN, "")
    }

    fun putSetQuestion(result: Boolean) {
        editor.putBoolean(Constant.PREF_SECURITY_SET, result)
        editor.apply()
    }

    fun getSetQuestion(): Boolean {
        return prefs.getBoolean(Constant.PREF_SECURITY_SET, false)
    }


    fun putSecurityQuestion(result: Int) {
        editor.putInt(Constant.PREF_SECURITY_QUESTION, result)
        editor.apply()
    }

    fun getSecurityQuestion(): Int {
        return prefs.getInt(Constant.PREF_SECURITY_QUESTION, 0)
    }


    fun putAnswerQuestion(result: String) {
        editor.putString(Constant.PREF_SECURITY_ANS, result)
        editor.apply()
    }

    fun getAnswerQuestion(): String? {
        return prefs.getString(Constant.PREF_SECURITY_ANS, "")
    }

    var shouldShowHidden = showHiddenMedia || temporarilyShowHidden

    var showHiddenMedia: Boolean
        get() = prefs.getBoolean("SHOW_HIDDEN_MEDIA", false)
        set(showHiddenFolders) = prefs.edit().putBoolean("SHOW_HIDDEN_MEDIA", showHiddenFolders)
            .apply()

    var temporarilyShowHidden: Boolean
        get() = prefs.getBoolean("TEMPORARILY_SHOW_HIDDEN", false)
        set(temporarilyShowHidden) = prefs.edit()
            .putBoolean("TEMPORARILY_SHOW_HIDDEN", temporarilyShowHidden).apply()

    var temporarilyShowExcluded: Boolean
        get() = prefs.getBoolean("TEMPORARILY_SHOW_EXCLUDED", false)
        set(temporarilyShowExcluded) = prefs.edit()
            .putBoolean("TEMPORARILY_SHOW_EXCLUDED", temporarilyShowExcluded).apply()

    // if a user hides a folder, then enables temporary hidden folder displaying, make sure we show it properly
    var everShownFolders: Set<String>
        get() = prefs.getStringSet("EVER_SHOWN_FOLDERS", getEverShownFolders())!!
        set(everShownFolders) = prefs.edit().putStringSet("EVER_SHOWN_FOLDERS", everShownFolders)
            .apply()

    var internalStoragePath: String
        get() = prefs.getString("INTERNAL_STORAGE_PATH", getDefaultInternalPath())!!
        set(internalStoragePath) = prefs.edit()
            .putString("INTERNAL_STORAGE_PATH", internalStoragePath).apply()

    private fun getDefaultInternalPath() = if (prefs.contains("INTERNAL_STORAGE_PATH")) "" else ""

    private fun getEverShownFolders() = hashSetOf(
        internalStoragePath,
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).absolutePath,
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath,
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath,
        "${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath}/Screenshots",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Images",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Images/Sent",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Video",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Video/Sent",
        "$internalStoragePath/WhatsApp/Media/.Statuses",
        "$internalStoragePath/Android/media/com.whatsapp/WhatsApp/Media",
        "$internalStoragePath/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images",
        "$internalStoragePath/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Video"
    )

    var rateAppDone: Boolean
        get() = prefs.getBoolean(pref_rate_app, false)
        set(value) = prefs.edit().putBoolean(pref_rate_app, value).apply()


    var defaultLanguage: String
        get() = prefs.getString("default_language", Locale.getDefault().language) ?: Locale.getDefault().language
        set(topCities) = prefs.edit().putString("default_language", topCities).apply()

    var callerCardPermissionCheck: Boolean
        get() = prefs.getBoolean("callerCardPermissionCheck", true)
        set(value) = prefs.edit().putBoolean("callerCardPermissionCheck", value).apply()

    var cameraFabEnabled: Boolean
        get() = prefs.getBoolean("cameraFabEnabled", true)
        set(value) = prefs.edit().putBoolean("cameraFabEnabled", value).apply()

    var privateVaultEnabled: Boolean
        get() = prefs.getBoolean("privateVaultEnabled", false)
        set(value) = prefs.edit().putBoolean("privateVaultEnabled", value).apply()


    var isMoveToHome: Boolean
        get() = prefs.getBoolean("isMoveToHome", false)
        set(doneWelcome) = prefs.edit { putBoolean("isMoveToHome", doneWelcome) }




}