package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation

import android.view.View
import androidx.viewpager2.widget.ViewPager2

class DefaultPageTransformer :
    ViewPager2.PageTransformer {
    override fun transformPage(view: View, position: Float) {}
}
