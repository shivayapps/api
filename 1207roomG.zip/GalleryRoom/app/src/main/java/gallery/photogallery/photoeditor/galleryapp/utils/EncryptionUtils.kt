package gallery.photogallery.photoeditor.galleryapp.utils

import android.os.Build
import android.util.Base64
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.Key
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.IvParameterSpec

object EncryptionUtils {

    private const val ALGORITHM = "AES/CBC/PKCS7Padding"
    private const val KEY_SIZE = 256 // AES-256
    private const val IV_SIZE = 16

    fun generateSecretKey(): SecretKey {
        val keyGen = KeyGenerator.getInstance("AES")
        keyGen.init(KEY_SIZE)
        return keyGen.generateKey()
    }

    fun encryptFile(input: File, output: File, secretKey: SecretKey) {
        val cipher = Cipher.getInstance(ALGORITHM)
        val iv = ByteArray(IV_SIZE).also { java.security.SecureRandom().nextBytes(it) }
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, IvParameterSpec(iv))

        FileOutputStream(output).use { fos ->
            fos.write(iv) // store IV at the beginning
            CipherOutputStream(fos, cipher).use { cos ->
                FileInputStream(input).use { fis ->
                    fis.copyTo(cos)
                }
            }
        }
    }

    fun decryptFile(input: File, output: File, secretKey: SecretKey) {
        FileInputStream(input).use { fis ->
            val iv = ByteArray(IV_SIZE)
            fis.read(iv) // read IV from start
            val cipher = Cipher.getInstance(ALGORITHM)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, IvParameterSpec(iv))

            CipherInputStream(fis, cipher).use { cis ->
                FileOutputStream(output).use { fos ->
                    cis.copyTo(fos)
                }
            }
        }
    }
}
