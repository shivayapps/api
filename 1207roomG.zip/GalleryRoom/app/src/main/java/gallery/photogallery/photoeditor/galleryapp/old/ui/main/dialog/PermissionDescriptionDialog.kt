package gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog

import android.app.Dialog
import android.os.Bundle
import android.text.Html
import android.text.method.LinkMovementMethod
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogPermissionDescBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences


class PermissionDescriptionDialog : BottomSheetDialogFragment() {
    companion object {
        fun newInstance(): PermissionDescriptionDialog {
            val dialog = PermissionDescriptionDialog()
            return dialog
        }
    }

    init {
        Log.e("TAG", "Initial PermissionDescriptionDialog: ")
    }

    lateinit var binding: DialogPermissionDescBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = DialogPermissionDescBinding.inflate(layoutInflater, container, false)
        intView()
        return binding.root
    }

    private fun intView() {
        binding.tvPermissionText.text = Html.fromHtml(
            resources.getString(R.string.text_permission_desc),
            Html.FROM_HTML_MODE_COMPACT
        )

        binding.tvLinkText.movementMethod = LinkMovementMethod.getInstance()

        binding.tvLinkText.text = Html.fromHtml(
            resources.getString(R.string.text_permission_desc_link),
            Html.FROM_HTML_MODE_COMPACT
        )

        binding.btnOK.setOnClickListener {
            dismiss()
        }
        val selectedLanguage = requireContext().preferences.getSelectedLang(requireContext())
        if (selectedLanguage == "ar" || selectedLanguage == "ur" || selectedLanguage == "fa") {
            binding.tvLinkText2.gravity = Gravity.END
        } else {
            binding.tvLinkText2.gravity = Gravity.START
        }
    }


    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = BottomSheetDialog(requireContext(), theme)
        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet) as FrameLayout
            BottomSheetBehavior.from(bottomSheet)
                .setState(BottomSheetBehavior.STATE_EXPANDED)
        }
        return dialog
    }
}