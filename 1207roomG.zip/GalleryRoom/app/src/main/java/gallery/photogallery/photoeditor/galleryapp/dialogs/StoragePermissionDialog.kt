package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.StoragePermissionDialogBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction

class StoragePermissionDialog(
    val cancelCallBack: () -> Unit,
    val okCallBack: () -> Unit,
) : DialogFragment() {
    private var _binding: StoragePermissionDialogBinding? = null
    private val binding get() = _binding!!

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = StoragePermissionDialogBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(R.color.transparent)
            setLayout(requireContext().getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        intListener()
        return dialog
    }
    private fun intListener() {
        binding.btnOkay.setOnClickListener {
            dismiss()
            okCallBack.invoke()

        }
        binding.btnCancel.setOnClickListener {
            dismiss()
            cancelCallBack.invoke()
        }
    }
}