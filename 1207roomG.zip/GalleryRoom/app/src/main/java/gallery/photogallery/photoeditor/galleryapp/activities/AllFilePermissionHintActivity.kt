package gallery.photogallery.photoeditor.galleryapp.activities

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AlphaAnimation
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityAllFilePermissionBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding

class AllFilePermissionHintActivity : AppCompatActivity() {
    private val binding by viewBinding(ActivityAllFilePermissionBinding::inflate)



    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(navigationBarStyle = SystemBarStyle.auto(Color.WHITE, Color.WHITE))
        setFinishOnTouchOutside(true)
        setContentView(binding.root)
        fadeContent(binding.root)
//        window?.navigationBarColor = ContextCompat.getColor(this, R.color.colorPrimary)
        binding.flMain.setOnClickListener { finish() }
        binding.loutBottom.setPadding(
            0, 0, 0, binding.loutBottom.paddingBottom + navigationBarHeight
        )

        Handler(Looper.myLooper()!!).postDelayed({
            finish()
        }, 2500)


    }

    private fun fadeContent(view: View) {
        val fadeIn = AlphaAnimation(0f, 1f).apply {
            duration = 500 // Duration in milliseconds
            fillAfter = true
        }
        view.startAnimation(fadeIn)
    }
}