package gallery.photogallery.photoeditor.galleryapp.extentions

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PorterDuff
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.annotation.ColorRes
import androidx.core.content.ContextCompat
import androidx.core.graphics.createBitmap
import androidx.fragment.app.Fragment
import com.airbnb.lottie.LottieAnimationView
import com.appblish.gallery.core.v2.api.model.PlaceListItem
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import gallery.photogallery.photoeditor.galleryapp.databinding.CustomMarkerBinding

fun ComponentActivity.onBackPressedDispatcher(callback: () -> Unit) {
    this.onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            callback()
        }
    })
}

fun Fragment.onBackPress(callback: () -> Unit) {
    requireActivity().onBackPressedDispatcher.addCallback(
        viewLifecycleOwner,
        object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                callback.invoke()
            }
        }
    )
}
fun LottieAnimationView.restart() {
    cancelAnimation()
    progress = 0f
    playAnimation()
}

fun Int.to99Plus(): String = if (this > 99) "99+" else this.toString()


fun Context.getMarkerOptions(album: PlaceListItem): MarkerOptions? {
    val lat = album.mediaList[0].mediaBox.latitude
    val lng = album.mediaList[0].mediaBox.longitude
    if (lat != 0.0 && lng != 0.0) {
        val location = LatLng(lat, lng)
        Log.e("MapExploreActivity", "getImageOnMap:::addMarker==>lat:${lat}, lng:${lng}")
        val bitmap = getMarkerBitmapFromView(album.mediaList[0].mediaPath, album.mediaList.size, album.mediaList[0].mediaDate.toString())
        if (bitmap != null) {
            val marker = MarkerOptions().position(location).icon(
                BitmapDescriptorFactory.fromBitmap(
                    bitmap
                )
            )
            return marker
        }
        return null
    }
    return null
}

@SuppressLint("SetTextI18n")
fun Context.getMarkerBitmapFromView(photoPath: String, size: Int, lastModified: String): Bitmap? {
    try {
        val markerBinding = CustomMarkerBinding.inflate(LayoutInflater.from(this))
        markerBinding.txtCount.text = "$size"
        val options = BitmapFactory.Options().apply {
            inSampleSize = 30
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        val bitmap = BitmapFactory.decodeFile(photoPath, options)
        markerBinding.profileImage.setImageBitmap(bitmap)

        markerBinding.root.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        markerBinding.root.layout(
            0, 0, markerBinding.root.measuredWidth, markerBinding.root.measuredHeight
        )
        markerBinding.root.buildDrawingCache()
        val returnedBitmap = createBitmap(markerBinding.root.measuredWidth, markerBinding.root.measuredHeight)
        val canvas = Canvas(returnedBitmap)
        canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN)
        val drawable = markerBinding.root.background
        drawable?.draw(canvas)
        markerBinding.root.draw(canvas)
        return returnedBitmap
    } catch (e: Exception) {
        e.printStackTrace()

    }
    return null
}

fun Context.getColorCompat(@ColorRes colorRes: Int): Int {
    return ContextCompat.getColor(this, colorRes)
}