package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation1

import android.view.View
import androidx.viewpager.widget.ViewPager


class CubeIn : ViewPager.PageTransformer {

    override fun transformPage(view: View, position: Float) {
        view.pivotX = if (position > 0) 0f else view.width.toFloat()
        view.pivotY = 0f
        view.rotationY = -90f * position
    }

}