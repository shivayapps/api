package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.appblish.gallery.core.v2.api.model.PlaceListItem
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemAlbumGridBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf

class PlacesGridAdapter(private val onPlaceClick: (PlaceListItem) -> Unit) : RecyclerView.Adapter<PlacesGridAdapter.MediaViewHolder>() {
    val items = ArrayList<PlaceListItem>()
    fun submitList(list: List<PlaceListItem>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    fun getItem(position: Int) = items[position]
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MediaViewHolder {
        val binding = ItemAlbumGridBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MediaViewHolder(binding)
    }

    override fun onBindViewHolder(
        holder: MediaViewHolder,
        position: Int,
    ) {
        holder.bind(getItem(position))
    }

    override fun getItemCount(): Int {
        return items.size
    }


    override fun onViewRecycled(holder: MediaViewHolder) {
        super.onViewRecycled(holder)
        Glide.with(holder.binding.mediumThumbnail.context).clear(holder.binding.mediumThumbnail)
    }

    inner class MediaViewHolder(
        val binding: ItemAlbumGridBinding,
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(media: PlaceListItem) {
            if (media.mediaList.isNotEmpty()) {
                binding.imageAlbum.loadGridImage(media.mediaList[0].mediaPath, media.mediaList[0].mediaDate)
                binding.txtTitle.text = media.title
                binding.txtCount.text = media.mediaList.size.toString()
            }
            itemView.setOnClickListener {
                onPlaceClick(media)
            }
        }

        private fun updateSelectionUI(selected: Boolean) {
            binding.icSelect.beVisibleIf(selected)
        }
    }
}