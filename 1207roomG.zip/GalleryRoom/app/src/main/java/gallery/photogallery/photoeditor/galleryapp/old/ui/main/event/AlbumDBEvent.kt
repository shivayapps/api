package gallery.photogallery.photoeditor.galleryapp.old.ui.main.event

import org.greenrobot.eventbus.EventBus


data class AlbumDBEvent(val type: String, val data: Any? = null)


const val ALL_MEDIA_DATABASE_UPDATED = "ALL_MEDIA_DATABASE_UPDATED"
const val UPDATE_MEDIA_DATA_RUNNING = "UPDATE_MEDIA_DATA_RUNNING"
const val UPDATE_MEDIA_DATA_ALBUM = "UPDATE_MEDIA_DATA_ALBUM"
const val UPDATE_PIN_ALBUM = "UPDATE_PIN_ALBUM"
fun sendAlbumDBEvent(type: String, data: Any? = null) {
    EventBus.getDefault().post(AlbumDBEvent(type, data))
}


