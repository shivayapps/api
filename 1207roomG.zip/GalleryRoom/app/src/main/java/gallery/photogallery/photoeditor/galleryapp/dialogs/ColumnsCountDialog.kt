package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.R
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogDisplayColumnsBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.utils.RESET_ALBUM_GRID
import gallery.photogallery.photoeditor.galleryapp.utils.RESET_MEDIA
import gallery.photogallery.photoeditor.galleryapp.utils.sendIntentEvent

class ColumnsCountDialog(private val isShowAlbumTab: Boolean) : DialogFragment() {
    private var _binding: DialogDisplayColumnsBinding? = null
    private val binding get() = _binding!!
    private lateinit var safeContext: Context

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogDisplayColumnsBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        initView()
        clickListener()

        return dialog
    }

    private fun initView() {

        val gridCount = if (isShowAlbumTab) {
            safeContext.appPref.albumGrid
        } else {
            safeContext.appPref.mediaGrid
        }

        when (gridCount) {
            2 -> binding.rb2Columns.isChecked = true
            3 -> binding.rb3Columns.isChecked = true
            4 -> binding.rb4Columns.isChecked = true
            5 -> binding.rb5Columns.isChecked = true
            6 -> binding.rb6Columns.isChecked = true
            else -> binding.rb3Columns.isChecked = true
        }


    }

    private fun clickListener() {
        binding.btnOK.setOnClickListener {
            val selectedRadioButtonId: Int = binding.grpOption.checkedRadioButtonId

            if (isShowAlbumTab) {
                safeContext.appPref.albumGrid = when (selectedRadioButtonId) {
                    binding.rb2Columns.id -> 2
                    binding.rb3Columns.id -> 3
                    binding.rb4Columns.id -> 4
                    binding.rb5Columns.id -> 5
                    binding.rb6Columns.id -> 6
                    else -> 3
                }
                sendIntentEvent(RESET_ALBUM_GRID)
            } else {
                safeContext.appPref.mediaGrid = when (selectedRadioButtonId) {
                    binding.rb2Columns.id -> 2
                    binding.rb3Columns.id -> 3
                    binding.rb4Columns.id -> 4
                    binding.rb5Columns.id -> 5
                    binding.rb6Columns.id -> 6
                    else -> 3
                }
                sendIntentEvent(RESET_MEDIA)
            }



            dismiss()
        }
    }
}