package gallery.photogallery.photoeditor.galleryapp.collage.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.collage.utils.CollageConst
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivitySaveCollageBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.editPhoto
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight

class SaveCollageActivity : BaseActivity() {
    lateinit var binding: ActivitySaveCollageBinding
    var savedImagePath = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySaveCollageBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        binding.root.setPadding(0, 0, 0, navigationBarHeight)
        binding.main.setPadding(0, statusBarHeight, 0, 0)
        setContentView(binding.root)

        savedImagePath = intent.getStringExtra("saved_image_path").toString();

        Glide.with(this)
            .load(savedImagePath)
            .centerCrop()
            .into(binding.ivImage)

        clickEvents()

    }

    private fun clickEvents() {
        binding.ivBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        binding.tvEdit.setOnClickListener {
            checkStoragePermission {
                if (it) {
                    editPhoto(savedImagePath)
                    setResult(RESULT_OK)
                    finish()
                }
            }
        }

        binding.tvCollageMore.setOnClickListener {
            val intent = Intent(this, CollageImageSelectionActivity::class.java)
            startActivity(intent)
            setResult(RESULT_OK)
            finish()

        }
        binding.tvClose.setOnClickListener {
            finish()
        }
        binding.llInstagram.setOnClickListener {

            CollageConst.shareToInstagram(this, savedImagePath)
        }

        binding.llFacebook.setOnClickListener {
            CollageConst.shareToFacebook(this, savedImagePath)
        }
        binding.llWhatsapp.setOnClickListener {
            CollageConst.shareToWhatsApp(this, savedImagePath)
        }
        binding.llOther.setOnClickListener {
            Log.i("clickEvents", "clickEvents: " + savedImagePath)
            CollageConst.shareToOther(this, savedImagePath)
        }
    }
}