package gallery.photogallery.photoeditor.galleryapp.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import com.appblish.gallery.core.v2.api.core.GallerySdkV2
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivitySettingBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.PhotoDeleteBehaviorDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.RateUsDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.ThemeDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.getAppVersion
import gallery.photogallery.photoeditor.galleryapp.extentions.showDeleteDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.custom.SwitchButton
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog.DateTimeDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.openPrivacyPolicy
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.shareApp
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.AdvanceSettingsActivityBaseActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus

class SettingActivity : BaseActivity() {

    private val binding by viewBinding(ActivitySettingBinding::inflate)
    val preferences: Preferences by lazy { Preferences(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        binding.topCoordinator.setPadding(0, statusBarHeight, 0, navigationBarHeight)
        init()
        clickListener()
    }

    private fun setPhotosDeleteBehavior() {
        PhotoDeleteBehaviorDialog.show(
            supportFragmentManager, preferences.getDeleteBehavior()
        ) { selected ->
            preferences.putDeleteBehavior(selected)
            when (selected) {
                Constant.DELETE_BEHAVIOR_ADD_TO_RECYCLE_BIN -> {
                    binding.tvSubTitleDeletePhoto.text = getString(R.string.add_to_trash)
                }

                Constant.DELETE_BEHAVIOR_PRESENTLY_DELETE -> {
                    binding.tvSubTitleDeletePhoto.text = getString(R.string.presently_delete)
                }

                else -> {
                    binding.tvSubTitleDeletePhoto.text = getString(R.string.always_ask)
                }
            }
        }
    }

    private fun setThemeMode() {
        ThemeDialog.show(
            supportFragmentManager, preferences.getThemeValue()
        ) { selected ->
            preferences.putTheme(selected)
            when (selected) {
                Constant.THEME_LIGHT -> {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                    binding.tvSubThemeMode.text = ContextCompat.getString(this, R.string.day_mode)
                }

                Constant.THEME_DARK -> {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                    binding.tvSubThemeMode.text = ContextCompat.getString(this, R.string.night_mode)
                }

                else -> {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
                    binding.tvSubThemeMode.text = ContextCompat.getString(this, R.string.system_default)
                }
            }
        }
    }

    private fun clickListener() {

        binding.ivBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        binding.cbDeleteAfter30Days.setOnClickListener {
            GallerySdkV2.get().setDeleteMediaAfter30Day(binding.cbDeleteAfter30Days.isChecked)
        }


        binding.llLanguage.setOnClickListener {
            startActivity(
                Intent(this@SettingActivity, NewLanguageSelectActivity::class.java)
                    .putExtra("isFromSettingToOpen", true)
            )
        }

        binding.llAdvanceSetting.setOnClickListener {
            startActivity(Intent(this@SettingActivity, AdvanceSettingsActivityBaseActivity::class.java))
        }

        binding.llDateTime.setOnClickListener {
            val dateTimeDialog = DateTimeDialog.newInstance(updateListener = {
                EventBus.getDefault().post("update_grid")
            })
            dateTimeDialog.show(supportFragmentManager, dateTimeDialog.tag)
        }

        binding.llPhotoDeleteBehavior.setOnClickListener {
            setPhotosDeleteBehavior()
        }

        binding.llTheme.setOnClickListener {
            setThemeMode()
        }

        binding.llPrivacyPolicy.setOnClickListener {
            openPrivacyPolicy()
        }

        binding.llRateUs.setOnClickListener {
            RateUsDialog(this).show(supportFragmentManager, "RateUsDialog")
        }

        binding.llShareApp.setOnClickListener {
            shareApp()
        }

        binding.llFeedbackSuggestions.setOnClickListener {
            val intent = Intent(this, FeedbackActivity::class.java)
            startActivity(intent)
        }

        binding.llEmptyRecycleBin.setOnClickListener {
            setEmptyTrash()
        }
    }

    private fun setEmptyTrash() {
        showDeleteDialog(
            title = getString(R.string.empty_trash),
            subTitle = getString(R.string.this_will_delete_all_trash_in_the_gallery),
            positiveRes = R.string.delete,
            onDeleteClick = {
                sharedViewModel.setEmptyTrash {
                    toast(getString(R.string.your_trash_is_now_empty))
                }
            })
    }

    private fun init() {
        val selectLanguage = preferences.selectedLanguage
        val languages = resources.getStringArray(R.array.language_text)
        val languageCodes = resources.getStringArray(R.array.language_code)
        val languageTr = resources.getStringArray(R.array.language_tr)
        val languageStr = if (selectLanguage.isNotEmpty() && selectLanguage != "default") {
            val findIndex = languageCodes.indexOfFirst { it == selectLanguage }
            if (findIndex != -1) {
                "${languages[findIndex]} (${languageTr[findIndex]})"
            } else {
                "${languages[0]} (${languageTr[0]})"
            }
        } else {
            "${languages[0]} (${languageTr[0]})"
        }
        binding.tvLanguage.text = languageStr

        getThemeMode()
        getDeleteBehavior()

        binding.txtVersionCode.text = this.getAppVersion()

        binding.cbDeleteAfter30Days.setChecked(sharedViewModel.isDeleteMediaAfter30Day())
        binding.cbDeleteAfter30Days.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                CoroutineScope(Dispatchers.IO).launch {
                    sharedViewModel.setDeleteMediaAfter30Day(isChecked)
                }
            }
        })
    }

    private fun getThemeMode() {
        when (preferences.getThemeValue()) {
            Constant.THEME_LIGHT -> {
                binding.tvSubThemeMode.text = ContextCompat.getString(this, R.string.day_mode)
            }

            Constant.THEME_DARK -> {
                binding.tvSubThemeMode.text = ContextCompat.getString(this, R.string.night_mode)
            }

            Constant.THEME_SYSTEM -> {
                binding.tvSubThemeMode.text = ContextCompat.getString(this, R.string.system_default)
            }
        }
    }

    private fun getDeleteBehavior() {
        when (preferences.getDeleteBehavior()) {
            Constant.DELETE_BEHAVIOR_ADD_TO_RECYCLE_BIN -> {
                binding.tvSubTitleDeletePhoto.text = getString(R.string.add_to_trash)
            }

            Constant.DELETE_BEHAVIOR_PRESENTLY_DELETE -> {
                binding.tvSubTitleDeletePhoto.text = getString(R.string.presently_delete)
            }

            Constant.DELETE_BEHAVIOR_ALWAYS_ASK -> {
                binding.tvSubTitleDeletePhoto.text = getString(R.string.always_ask)
            }
        }
    }

    override fun onResume() {
        super.onResume()
    }
}