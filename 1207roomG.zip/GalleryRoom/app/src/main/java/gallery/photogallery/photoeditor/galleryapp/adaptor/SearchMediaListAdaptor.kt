package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.appblish.gallery.core.v2.api.model.MediaModel
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.activities.NewImageViewerActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.PhotoItemGridBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf


class SearchMediaListAdaptor(
    private val baseActivity: BaseActivity,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val mediaList = ArrayList<MediaModel>()

    companion object {
        const val HEADER = 0
        const val ALBUM = 1
    }

    fun submitList(list: List<MediaModel>) {
        mediaList.clear()
        mediaList.addAll(list)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = mediaList.size

    override fun getItemViewType(position: Int): Int {
        return ALBUM
    }

    fun getItem(position: Int): MediaModel = mediaList[position]

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        return when (viewType) {

            ALBUM -> {
                MediaViewHolder(
                    PhotoItemGridBinding.inflate(
                        LayoutInflater.from(parent.context),
                        parent,
                        false
                    )
                )
            }

            else -> throw IllegalArgumentException("Invalid view type")
        }
    }

    override fun onBindViewHolder(
        holder: RecyclerView.ViewHolder,
        position: Int
    ) {
        when (holder) {
            is MediaViewHolder ->
                holder.bind(mediaList[position])

        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        if (holder is MediaViewHolder) {
            Glide.with(holder.binding.mediumThumbnail.context)
                .clear(holder.binding.mediumThumbnail)
        }
    }


    inner class MediaViewHolder(
        val binding: PhotoItemGridBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(mediaBox: MediaModel) {
            val path = mediaBox.mediaPath
            binding.mediumThumbnail.loadGridImage(
                path,
                mediaBox.mediaDate
            )
            binding.icUnSelect.visibility = View.GONE
            binding.icSelect.visibility = View.GONE
            binding.icFavourite.beVisibleIf(mediaBox.isFavourite)
            binding.ivGif.beVisibleIf(path.endsWith("gif", true))
            binding.icVideo.visibility =
                if (mediaBox.isVideo) View.VISIBLE else View.GONE

            binding.root.transitionName = path

            binding.root.setOnClickListener {
                val mediaPaths = mediaList.map { it.mediaPath }
                baseActivity.sharedViewModel.imageViewerList =
                    ArrayList(mediaPaths)

                val startPosition = mediaPaths.indexOf(path)

                baseActivity.startActivity(
                    Intent(baseActivity, NewImageViewerActivity::class.java).apply {
                        putExtra("startPosition", startPosition)
                    }
                )
            }

        }
    }
}