package gallery.photogallery.photoeditor.galleryapp.collage.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
 import com.appblish.collagemaker.appblish.AppblishCollageText
import com.appblish.collagemaker.appblish.AppblishCollageTextShadow
import gallery.photogallery.photoeditor.galleryapp.R

class ShadowAdapter(
    private val context: Context,
    private val lstTextShadows: List<AppblishCollageTextShadow>,
    private val onItemClick: ((view: View, position: Int) -> Unit)? = null
) : RecyclerView.Adapter<ShadowAdapter.ViewHolder>() {

    var selectedItem = 0

    override fun getItemViewType(position: Int): Int {
        return position
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context)
            .inflate(R.layout.item_font, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val textShadow = lstTextShadows[position]

        holder.textShadow.setShadowLayer(
            textShadow.radius.toFloat(),
            textShadow.dx.toFloat(),
            textShadow.dy.toFloat(),
            textShadow.colorShadow
        )

        val bgRes = if (selectedItem == position) {
            R.drawable.border_black_view
        } else {
            R.drawable.border_view
        }

        holder.wrapperFontItems.background =
            ContextCompat.getDrawable(context, bgRes)
    }

    override fun getItemCount(): Int {
        return lstTextShadows.size
    }

    inner class ViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView), View.OnClickListener {

        val textShadow: TextView =
            itemView.findViewById(R.id.text_view_font_item)
        val wrapperFontItems: ConstraintLayout =
            itemView.findViewById(R.id.constraint_layout_wrapper_font_item)

        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(view: View) {
            val position = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                onItemClick?.invoke(view, position)
                selectedItem = position
                notifyDataSetChanged()
            }
        }
    }
}
