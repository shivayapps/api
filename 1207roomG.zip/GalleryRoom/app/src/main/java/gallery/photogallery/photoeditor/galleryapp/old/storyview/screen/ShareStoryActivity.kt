package gallery.photogallery.photoeditor.galleryapp.old.storyview.screen

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityShareStoryBinding
import gallery.photogallery.photoeditor.galleryapp.old.storyview.customview.ShareStoryAdapter
import gallery.photogallery.photoeditor.galleryapp.old.storyview.screen.StoryShareDialog.Companion.selectedImageUris
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isDarkMode
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import java.io.File

class ShareStoryActivity : BaseActivity() {

    lateinit var binding: ActivityShareStoryBinding
    private lateinit var memoryStoryAdapter: ShareStoryAdapter
    private var pathList: ArrayList<String> = ArrayList()
    private var currentPreviewPath: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityShareStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.root.setPadding(0, statusBarHeight, 0, navigationBarHeight)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = !isDarkMode()
        controller.isAppearanceLightNavigationBars = !isDarkMode()

        val stringArray = intent.getStringArrayListExtra("story_array")
        val pos = intent.getIntExtra("story_pos", 0)
        if (stringArray != null) {
            pathList.clear()
            pathList = stringArray.distinct().toCollection(ArrayList())

            binding.txtShareTotalCount.text = pathList.count().toString()

            loadImage(pathList[0])
            init(pos)
            clickListener()
        }
    }

    private fun updateSelectAllIcon() {

        val isAllSelected =
            memoryStoryAdapter.selectedItems.size == pathList.size
                    && pathList.isNotEmpty()

        if (isAllSelected) {
            binding.ivSelectAll.setImageResource(
                R.drawable.album_bg_original_p
            )
        } else {
            binding.ivSelectAll.setImageResource(
                R.drawable.album_bg_original_n
            )
        }
    }

    private fun clickListener() {
        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

        binding.icUnSelectFromScreen.setOnClickListener {
            currentPreviewPath?.let { path ->

                if (memoryStoryAdapter.selectedItems.contains(path)) {
                    memoryStoryAdapter.selectedItems.remove(path)
                } else {
                    memoryStoryAdapter.selectedItems.add(path)
                }

                val index = pathList.indexOf(path)
                if (index != -1) {
                    memoryStoryAdapter.notifyItemChanged(index, "changes")
                }

                binding.txtShareSelectCount.text =
                    memoryStoryAdapter.selectedItems.size.toString()

                updateTopIcon()
                updateSelectAllIcon()
            }
        }



        binding.ivSelectAll.setOnClickListener {
            val isAllSelected = memoryStoryAdapter.selectedItems.size == pathList.size
            memoryStoryAdapter.selectedItems.clear()

            if (isAllSelected) {

                binding.ivSelectAll.setImageResource(R.drawable.vec_unselected_bg)
//                currentPreviewPath = null
//                binding.ivSetImage.setImageDrawable(null)

            } else {

                memoryStoryAdapter.selectedItems.addAll(pathList)
                if (pathList.isNotEmpty()) {
                    currentPreviewPath = pathList[0]
                    loadImage(currentPreviewPath.orEmpty())
                }

                binding.ivSelectAll.setImageResource(R.drawable.album_bg_original_p)
            }
            binding.txtShareSelectCount.text =
                memoryStoryAdapter.selectedItems.size.toString()

            memoryStoryAdapter.notifyDataSetChanged()

            updateTopIcon()
            updateSelectAllIcon()
        }

        binding.llShare.setOnClickListener {
            selectedImageUris.clear()
            for (path in memoryStoryAdapter.selectedItems) {
                val file = File(path)
                val uri = FileProvider.getUriForFile(
                    this,
                    "${packageName}.provider",
                    file
                )
                selectedImageUris.add(uri)
            }
            selectedImageUris.distinct()

            if (selectedImageUris.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            val dialog = StoryShareDialog.newInstance {
                when (it) {
                    "Share" -> {

                    }
                }
            }
            dialog.show(supportFragmentManager, "SHARE_STORY")
        }
    }

    private fun loadImage(loadUrl: String) {
        Glide.with(this)
            .load(loadUrl)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .transform(CenterCrop(), RoundedCorners(30))
            .transition(DrawableTransitionOptions.withCrossFade(300))
            .into(binding.ivSetImage)
    }

    private fun updateTopIcon() {

        if (currentPreviewPath != null && memoryStoryAdapter.selectedItems.contains(currentPreviewPath)
        ) {
            binding.icUnSelectFromScreen.setImageResource(R.drawable.album_bg_original_p)
        } else {
            binding.icUnSelectFromScreen.setImageResource(R.drawable.album_bg_original_n)
        }
    }

    private fun init(pos: Int) {
        memoryStoryAdapter = ShareStoryAdapter(pathList, pos) { selectedPath, count ->

            if (selectedPath != null) {
                currentPreviewPath = selectedPath
                loadImage(selectedPath)
            }

            binding.txtShareSelectCount.text = count.toString()
            binding.txtShareTotalCount.text = pathList.size.toString()

            updateTopIcon()
            updateSelectAllIcon()
        }

        binding.rvStory.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        binding.rvStory.adapter = memoryStoryAdapter
        binding.rvStory.scrollToPosition(pos)

        if (pathList.isNotEmpty()) {

            memoryStoryAdapter.selectedItems.clear()

            currentPreviewPath = pathList[pos]  // select based on passed position
            memoryStoryAdapter.selectedItems.add(currentPreviewPath!!)

            loadImage(currentPreviewPath!!)

            binding.txtShareSelectCount.text = "1"
            binding.txtShareTotalCount.text = pathList.size.toString()

            memoryStoryAdapter.notifyItemChanged(pos, "changes")

            updateTopIcon()
            updateSelectAllIcon()
        }

        if (intent.hasExtra("selectAll")) {
            binding.ivSelectAll.performClick()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::memoryStoryAdapter.isInitialized)
            memoryStoryAdapter.selectedItems.clear()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}


