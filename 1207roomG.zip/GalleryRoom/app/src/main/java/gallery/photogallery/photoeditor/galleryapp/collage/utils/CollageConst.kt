package gallery.photogallery.photoeditor.galleryapp.collage.utils

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.FileProvider
import com.appblish.collagemaker.appblish.AppblishCollageTextShadow

import com.appblish.collagemaker.utils.AppblishCollageRatioType
import com.appblish.collagemaker.utils.AppblishCollageRatioUiModel
import gallery.photogallery.photoeditor.galleryapp.R
import java.io.File

object CollageConst {

    fun getAllListTextShadow(): List<AppblishCollageTextShadow> {
        val list = ArrayList<AppblishCollageTextShadow>()

        list.add(AppblishCollageTextShadow(0, 0, 0, -16711681))
        list.add(AppblishCollageTextShadow(8, 4, 4, Color.parseColor("#FFFFFF")))
        list.add(AppblishCollageTextShadow(8, 4, 4, Color.parseColor("#000000")))
        list.add(AppblishCollageTextShadow(8, 4, 4, Color.parseColor("#FF0000")))
        list.add(AppblishCollageTextShadow(8, 4, 4, Color.parseColor("#FF3C00")))
        list.add(AppblishCollageTextShadow(8, 4, 4, Color.parseColor("#FFAA00")))
        list.add(AppblishCollageTextShadow(8, 4, 4, Color.parseColor("#D9FF00")))
        list.add(AppblishCollageTextShadow(8, 4, 4, Color.parseColor("#08FF00")))
        list.add(AppblishCollageTextShadow(8, 4, 4, Color.parseColor("#00FFA6")))
        list.add(AppblishCollageTextShadow(8, 4, 4, Color.parseColor("#0099FF")))
        list.add(AppblishCollageTextShadow(8, 4, 4, Color.parseColor("#0022FF")))
        list.add(AppblishCollageTextShadow(8, 4, 4, Color.parseColor("#7700FF")))
        list.add(AppblishCollageTextShadow(8, 4, 4, Color.parseColor("#D900FF")))
        list.add(AppblishCollageTextShadow(8, 4, 4, Color.parseColor("#FF0099")))
        list.add(AppblishCollageTextShadow(8, 4, 4, Color.parseColor("#FF0048")))

        list.add(AppblishCollageTextShadow(8, -4, -4, Color.parseColor("#FFFFFF")))
        list.add(AppblishCollageTextShadow(8, -4, -4, Color.parseColor("#000000")))
        list.add(AppblishCollageTextShadow(8, -4, -4, Color.parseColor("#FF0000")))
        list.add(AppblishCollageTextShadow(8, -4, -4, Color.parseColor("#FF3C00")))
        list.add(AppblishCollageTextShadow(8, -4, -4, Color.parseColor("#FFAA00")))
        list.add(AppblishCollageTextShadow(8, -4, -4, Color.parseColor("#D9FF00")))
        list.add(AppblishCollageTextShadow(8, -4, -4, Color.parseColor("#08FF00")))
        list.add(AppblishCollageTextShadow(8, -4, -4, Color.parseColor("#00FFA6")))
        list.add(AppblishCollageTextShadow(8, -4, -4, Color.parseColor("#0099FF")))
        list.add(AppblishCollageTextShadow(8, -4, -4, Color.parseColor("#0022FF")))
        list.add(AppblishCollageTextShadow(8, -4, -4, Color.parseColor("#7700FF")))
        list.add(AppblishCollageTextShadow(8, -4, -4, Color.parseColor("#D900FF")))
        list.add(AppblishCollageTextShadow(8, -4, -4, Color.parseColor("#FF0099")))
        list.add(AppblishCollageTextShadow(8, -4, -4, Color.parseColor("#FF0048")))
        list.add(AppblishCollageTextShadow(8, -4, 4, Color.parseColor("#FFFFFF")))
        list.add(AppblishCollageTextShadow(8, -4, 4, Color.parseColor("#000000")))
        list.add(AppblishCollageTextShadow(8, -4, 4, Color.parseColor("#FF0000")))
        list.add(AppblishCollageTextShadow(8, -4, 4, Color.parseColor("#FF3C00")))
        list.add(AppblishCollageTextShadow(8, -4, 4, Color.parseColor("#FFAA00")))
        list.add(AppblishCollageTextShadow(8, -4, 4, Color.parseColor("#D9FF00")))
        list.add(AppblishCollageTextShadow(8, -4, 4, Color.parseColor("#08FF00")))
        list.add(AppblishCollageTextShadow(8, -4, 4, Color.parseColor("#00FFA6")))
        list.add(AppblishCollageTextShadow(8, -4, 4, Color.parseColor("#0099FF")))
        list.add(AppblishCollageTextShadow(8, -4, 4, Color.parseColor("#0022FF")))
        list.add(AppblishCollageTextShadow(8, -4, 4, Color.parseColor("#7700FF")))
        list.add(AppblishCollageTextShadow(8, -4, 4, Color.parseColor("#D900FF")))
        list.add(AppblishCollageTextShadow(8, -4, 4, Color.parseColor("#FF0099")))
        list.add(AppblishCollageTextShadow(8, -4, 4, Color.parseColor("#FF0048")))
        list.add(AppblishCollageTextShadow(8, 4, -4, Color.parseColor("#FFFFFF")))
        list.add(AppblishCollageTextShadow(8, 4, -4, Color.parseColor("#000000")))
        list.add(AppblishCollageTextShadow(8, 4, -4, Color.parseColor("#FF0000")))
        list.add(AppblishCollageTextShadow(8, 4, -4, Color.parseColor("#FF3C00")))
        list.add(AppblishCollageTextShadow(8, 4, -4, Color.parseColor("#FFAA00")))
        list.add(AppblishCollageTextShadow(8, 4, -4, Color.parseColor("#D9FF00")))
        list.add(AppblishCollageTextShadow(8, 4, -4, Color.parseColor("#08FF00")))
        list.add(AppblishCollageTextShadow(8, 4, -4, Color.parseColor("#00FFA6")))
        list.add(AppblishCollageTextShadow(8, 4, -4, Color.parseColor("#0099FF")))
        list.add(AppblishCollageTextShadow(8, 4, -4, Color.parseColor("#0022FF")))
        list.add(AppblishCollageTextShadow(8, 4, -4, Color.parseColor("#7700FF")))
        list.add(AppblishCollageTextShadow(8, 4, -4, Color.parseColor("#D900FF")))
        list.add(AppblishCollageTextShadow(8, 4, -4, Color.parseColor("#FF0099")))
        list.add(AppblishCollageTextShadow(8, 4, -4, Color.parseColor("#FF0048")))
        return list
    }

    @JvmStatic
    fun getAllRatios(): List<AppblishCollageRatioUiModel> = ratioList

    private val ratioList: List<AppblishCollageRatioUiModel> by lazy {
        listOf(

            AppblishCollageRatioUiModel(AppblishCollageRatioType.R1_1, R.drawable.ic_instagram, R.drawable.ic_instagram, "IG 1:1"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R4_5, R.drawable.ic_instagram, R.drawable.ic_instagram, "IG 4:5"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R9_16, R.drawable.ic_instagram, R.drawable.ic_instagram, "IG Story"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R4_3, R.drawable.ic_fb, R.drawable.ic_fb, "Facebook\nPost"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R16_6, R.drawable.ic_fb, R.drawable.ic_fb, "Facebook\nCover"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R16_8, R.drawable.ic_x, R.drawable.ic_x, "X Post"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R16_5, R.drawable.ic_x, R.drawable.ic_x, "X Header"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R2_3, R.drawable.ic_pinterest, R.drawable.ic_pinterest, "Pinterest\nPost"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.A4, R.drawable.ic_crop_a4, R.drawable.ic_crop_a4, "A4"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.A5, R.drawable.ic_crop_a5, R.drawable.ic_crop_a5, "A5"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R5_4, R.drawable.ic_crop_5_4, R.drawable.ic_crop_5_4, "5:4"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R3_4, R.drawable.ic_crop_3_4, R.drawable.ic_crop_3_4, "3:4"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R2_3, R.drawable.ic_crop_2_3, R.drawable.ic_crop_2_3, "2:3"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R9_16, R.drawable.ic_crop_9_16, R.drawable.ic_crop_9_16, "9:16"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R4_3, R.drawable.ic_crop_4_3, R.drawable.ic_crop_4_3, "4:3"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R3_2, R.drawable.ic_crop_3_2, R.drawable.ic_crop_3_2, "3:2"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R1_2, R.drawable.ic_crop_5_4, R.drawable.ic_crop_5_4, "1:2"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.R16_9, R.drawable.ic_crop_16_9, R.drawable.ic_crop_16_9, "16:9"),
            AppblishCollageRatioUiModel(AppblishCollageRatioType.MOVIE, R.drawable.ic_movie, R.drawable.ic_movie, "Movie")
        )
    }



    @JvmStatic
    fun setLoading(
        activity: Activity?,
        loadingView: View?,
        isLoading: Boolean
    ) {
        if (activity == null || loadingView == null) return

        if (isLoading) {
            activity.window.setFlags(
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            )
            loadingView.visibility = View.VISIBLE
        } else {
            activity.window.clearFlags(
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            )
            loadingView.visibility = View.GONE
        }
    }


    fun shareToOther(context: Context, imagePath: String) {

        val originalFile = File(imagePath)
        if (!originalFile.exists()) {
            Toast.makeText(context, "File not found", Toast.LENGTH_SHORT).show()
            return
        }

         val cacheFile = File(context.cacheDir, originalFile.name)
        originalFile.copyTo(cacheFile, overwrite = true)

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.provider",
            cacheFile
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("", uri)   // ✅ SAFE VERSION
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        context.startActivity(Intent.createChooser(intent, "Share via"))
    }




    fun shareToFacebook(context: Context, imagePath: String) {
        val uri = getImageUri(context, imagePath)

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            setPackage("com.facebook.katana")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Facebook not installed", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareToInstagram(context: Context, imagePath: String) {
        val uri = getImageUri(context, imagePath)

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            setPackage("com.instagram.android")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Instagram not installed", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareToWhatsApp(context: Context, imagePath: String) {
        val uri = getImageUri(context, imagePath)

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "WhatsApp not installed", Toast.LENGTH_SHORT).show()
        }
    }
    fun getImageUri(context: Context, imagePath: String): Uri {
        val imageFile = File(imagePath)
        return FileProvider.getUriForFile(
            context,
            context.packageName + ".provider",
            imageFile
        )
    }


     fun formatSize(bytes: Long): String {
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0

        return when {
            gb >= 1 -> String.format("%.2f GB", gb)
            mb >= 1 -> String.format("%.2f MB", mb)
            else -> String.format("%.2f KB", kb)
        }
    }



}