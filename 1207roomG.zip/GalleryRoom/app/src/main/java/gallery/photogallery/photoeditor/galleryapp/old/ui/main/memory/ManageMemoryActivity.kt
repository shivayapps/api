package gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.appblish.box.api.model.MediaBox
import com.appblish.story.memories.api.core.MemorySDK
import com.appblish.story.memories.api.model.MemoryBox
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.adaptor.MemoryImagesAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityMamoryImageBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ManageMemoryActivity : BaseActivity(), View.OnClickListener {
    private val binding by viewBinding(ActivityMamoryImageBinding::inflate)
    var memoryListItem: MemoryBox? = null
    val allMediaAdaptor by lazy { MemoryImagesAdapter(this) }
    val memoryId by lazy { intent.getLongExtra("memoryId", 0) }
    val isCreateMemory by lazy { intent.getBooleanExtra("isCreateMemory", false) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.photoToolbar.setPadding(0, statusBarHeight, 0, 0)
        binding.root.setPadding(0, 0, 0, navigationBarHeight)
        lifecycleScope.launch {
            if (isCreateMemory) {
                initClick()
                setPhotosData()
            } else {
                MemorySDK.get().getMemoryBox(memoryId) {
                    memoryListItem = it
                    runOnUiThread {
                        initClick()
                        setPhotosData()
                    }
                }

            }
        }
    }

    private fun initClick() {
        binding.tvAlbumName.text = memoryListItem?.title ?: intent.getStringExtra("title")
        binding.ivBack.setOnClickListener(this)
        binding.btnDone.setOnClickListener(this)
        val layoutManager = GridLayoutManager(this, 3)
        binding.rvMedias.layoutManager = layoutManager
        binding.rvMedias.adapter = allMediaAdaptor
    }

    override fun onClick(view: View?) {
        when (view) {
            binding.ivBack -> {
                finish()
            }

            binding.btnDone -> {
                val selectedItems = allMediaAdaptor.selectedItems
                if (selectedItems.size < MemorySDK.get().getMinMemoryMedia()) {
                    val str = "${getString(R.string.please_select_more_then)} ${MemorySDK.get().getMinMemoryMedia()} ${getString(R.string.photos)}"
                    toast(str)
                    return
                }
                val maxImages = MemorySDK.get().getLongMemoryMaxPhotos()
                if (selectedItems.size > maxImages) {
                    toast(resources.getString(R.string.max_images_allowed, maxImages))
                    return
                }
                if (isCreateMemory) {
                    sharedViewModel.createMemory(intent.getStringExtra("title") ?: "", selectedItems) {
                        finish()
                    }
                } else {
                    sharedViewModel.updateMemoryMedia(memoryListItem!!.memoryId, selectedItems) {
                        setResult(RESULT_OK)
                        Intent(this, MemoryViewerActivity::class.java).apply {
                            putExtra("memoryId", memoryListItem!!.memoryId)
                            startActivity(this)
                        }
                        finish()
                    }
                }

            }
        }
    }

    fun updateSelection() {

    }


    private fun setPhotosData() {
        lifecycleScope.launch(Dispatchers.IO) {
            val selectedHashList = memoryListItem?.mediaList?.map { it.mediaPath }?.toSet() ?: emptyList<String>()
            MemorySDK.get().fetchAllMemoryMediaBox(memoryListItem) {
                allMediaAdaptor.selectedItems.clear()
                val newList = ArrayList<MediaBox>()
                it.forEach { mediaBox ->
                    if (mediaBox.mediaPath in selectedHashList) {
                        allMediaAdaptor.selectedItems.add(mediaBox)
                    } else {
                        newList.add(mediaBox)
                    }
                }
                newList.addAll(0, ArrayList(allMediaAdaptor.selectedItems))
                runOnUiThread {
                    allMediaAdaptor.saveData(newList)
                }
            }
        }
    }
}
