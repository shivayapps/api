package gallery.photogallery.photoeditor.galleryapp.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.addCallback
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import gallery.photogallery.photoeditor.galleryapp.permission.PermissionSDK
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityPermissionBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog.PermissionDescriptionDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import kotlinx.coroutines.launch

class PermissionActivity : BaseActivity() {
    private val binding by viewBinding(ActivityPermissionBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        initView()
        clickListener()
    }

    private fun initView() {
        lifecycleScope.launch {
            Log.e("TEXT_TAG", "setContentView: done")
            binding.root.setPadding(0, statusBarHeight, 0, navigationBarHeight)

        }
    }

    private fun clickListener() {
        onBackPressedDispatcher.addCallback(this@PermissionActivity) {
            binding.btnAllow.performClick()
        }

        binding.tvPermissionDesc.setOnClickListener {
            val bottomSheet = PermissionDescriptionDialog()
            bottomSheet.show(supportFragmentManager, bottomSheet.tag)
        }

        binding.btnAllow.setOnClickListener {
            requestManageAllFile {
                launchMainActivity()
            }
        }

        binding.llHint.setOnClickListener {
            binding.btnAllow.performClick()
        }

        binding.llLottie.setOnClickListener {
            binding.btnAllow.performClick()
        }
    }

    private fun launchMainActivity() {
        if (isFinishing || isDestroyed) return
        countDownTimerOverlay?.cancel()
        if (PermissionSDK.isReadMediaPermission(this)) {
            sharedViewModel.fetchMedia()
        }
        startActivity(Intent(this@PermissionActivity, MainActivity::class.java).putExtras(intent))
        finish()
    }
}