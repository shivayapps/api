package gallery.photogallery.photoeditor.galleryapp.bottomSheet

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogSecurityQuestionBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences

class SecurityQuestionDialog(val activity: Activity) : DialogFragment() {

    private var _binding: DialogSecurityQuestionBinding? = null
    private val binding get() = _binding!!

    var type: Int = 0
    var isChangePass: Boolean = false
    var isForgotPassOpen: Boolean = false
    var updateListener: ((isSuccess: Boolean) -> Unit)? = null

    companion object {
        fun newInstance(
            activity: Activity,
            type: Int = 0,//1-> Reset, 0->Set Question
            isChangePass: Boolean = false,
            isForgotPassOpen: Boolean = false,
            updateListener: (isSuccess: Boolean) -> Unit,
        ): SecurityQuestionDialog {
            val securityQuestionDialog = SecurityQuestionDialog(activity)
            securityQuestionDialog.type = type
            securityQuestionDialog.isChangePass = isChangePass
            securityQuestionDialog.isForgotPassOpen = isForgotPassOpen
            securityQuestionDialog.updateListener = updateListener

            securityQuestionDialog.setCancelable(isForgotPassOpen)

            securityQuestionDialog.isCancelable = true
            return securityQuestionDialog
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogSecurityQuestionBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(requireContext().getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }

        intView()
        intListener()
        return dialog
    }

    private fun intView() {
        val adapter = SpinnerQueAdapter(activity, activity.resources.getStringArray(R.array.security_question))
        binding.questionSpinner.adapter = adapter

        /* if (type == 1) {
             bindingDialog.questionSpinner.setSelection(preferences.getSecurityQuestion())
         }*/
        /* if (isChangePass) {
             bindingDialog.securityAnswer.setText(preferences.getAnswerQuestion())
         }*/
    }

    private fun intListener() {
        binding.btnOK.setOnClickListener {
            val answer = binding.securityAnswer.text.toString()
            if (binding.questionSpinner.selectedItemPosition == 0)
                Toast.makeText(
                    activity,
                    activity.getString(R.string.PleaseSelectQue),
                    Toast.LENGTH_SHORT
                ).show()
            else if (answer.isEmpty()) {
                Toast.makeText(
                    activity,
                    activity.getString(R.string.PleaseSelectQue),
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                hideSoftKeyboard()
                if (isChangePass) {
                    activity.preferences.putSecurityQuestion(binding.questionSpinner.selectedItemPosition)
                    activity.preferences.putAnswerQuestion(answer)
                    Toast.makeText(
                        activity,
                        activity.getString(R.string.Question_change_successfully),
                        Toast.LENGTH_SHORT
                    ).show()

                    updateListener?.invoke(true)
                    dismiss()

                } else if (!activity.preferences.getSetQuestion()) {
                    activity.preferences.putSetQuestion(true)
                    activity.preferences.putSecurityQuestion(binding.questionSpinner.selectedItemPosition)
                    activity.preferences.putAnswerQuestion(answer)

                    updateListener?.invoke(true)
                    dismiss()

                } else {
                    if (binding.questionSpinner.selectedItemPosition == activity.preferences.getSecurityQuestion()) {
                        if (activity.preferences.getAnswerQuestion().equals(answer)) {
                            updateListener?.invoke(true)
                            dismiss()
                        } else {
                            Toast.makeText(
                                activity,
                                R.string.msg_security_ans,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else Toast.makeText(
                        activity,
                        R.string.msg_security_que,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    fun hideSoftKeyboard() {
        val inputMethodManager = activity.getSystemService(AppCompatActivity.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(binding.securityAnswer.windowToken, 0)
    }

    class SpinnerQueAdapter(
        private val context: Context,
        private val itemList: Array<String>,
    ) :
        BaseAdapter() {
        override fun getCount(): Int {
            return itemList.size
        }

        override fun getItem(position: Int): Any {
            return itemList[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view: View
            val viewHolder: ViewHolder

            if (convertView == null) {
                view = LayoutInflater.from(context).inflate(R.layout.item_spinner_que, parent, false)
                viewHolder = ViewHolder(view)
                view.tag = viewHolder
            } else {
                view = convertView
                viewHolder = view.tag as ViewHolder
            }

            val item = itemList[position]
            viewHolder.itemTextView.text = item
            viewHolder.itemTextView.setTextColor(ContextCompat.getColor(context, R.color.color_text))
//            viewHolder.itemTextView.visibility = if (position == 0) View.GONE else View.VISIBLE

            return view
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view: View
            val viewHolder: ViewHolder

            if (convertView == null) {
                view = LayoutInflater.from(context).inflate(R.layout.item_spinner_que, parent, false)
                viewHolder = ViewHolder(view)
                view.tag = viewHolder
            } else {
                view = convertView
                viewHolder = view.tag as ViewHolder
            }

            val item = itemList[position]
            viewHolder.itemTextView.text = item
            if (position == 0)
                viewHolder.itemTextView.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.color_text
                    )
                )
            else {
                viewHolder.itemTextView.setTextColor(ContextCompat.getColor(context, R.color.color_text))
//                viewHolder.itemTextView.setTextColor(Color.WHITE)
            }

            return view
        }


        private class ViewHolder(view: View) {
            val itemTextView: TextView = view.findViewById(R.id.txtItem)
        }
    }
}