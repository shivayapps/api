package gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogHintNavigationBinding

class HintDialogNavigationBar(
    var activity: Activity,
    var title: String,
    var resId: Int,
    val updateListener: () -> Unit
) : Dialog(activity) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        setCancelable(false)
        setCanceledOnTouchOutside(false)
        bindingDialog = DialogHintNavigationBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
        intListener()
    }

    lateinit var bindingDialog: DialogHintNavigationBinding
    private fun intView() {
        bindingDialog.tvtitle.text = title
        bindingDialog.ivHint.setImageResource(resId)
    }

    private fun intListener() {
        bindingDialog.btnPositive.setOnClickListener {
            dismiss()
            updateListener.invoke()
        }
    }
}

