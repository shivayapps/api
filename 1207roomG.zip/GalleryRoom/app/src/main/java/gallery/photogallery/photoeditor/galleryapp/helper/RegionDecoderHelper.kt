package gallery.photogallery.photoeditor.galleryapp.helper

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import java.io.File
import java.io.FileInputStream
import kotlin.math.max

object RegionDecoderHelper {

    /**
     * Decode a rectangular tile from a large image file.
     * rect must be inside the image bounds.
     * inSampleSize reduces size of decoded tile (1 = full).
     */
    fun decodeRegion(filePath: String, rect: Rect, inSampleSize: Int = 1): Bitmap? {
        return try {
            FileInputStream(File(filePath)).use { fis ->
                val decoder = BitmapRegionDecoder.newInstance(fis, false)
                val opts = BitmapFactory.Options().apply {
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                    this.inSampleSize = max(1, inSampleSize)
                }
                decoder?.decodeRegion(rect, opts)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
