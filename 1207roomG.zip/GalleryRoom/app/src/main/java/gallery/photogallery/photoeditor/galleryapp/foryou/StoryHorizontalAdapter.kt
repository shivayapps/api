package gallery.photogallery.photoeditor.galleryapp.foryou

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import com.appblish.story.memories.api.model.StoryBox
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemStoryCardBinding

object StoryDiff : DiffUtil.ItemCallback<StoryBox>() {
    override fun areItemsTheSame(
        oldItem: StoryBox,
        newItem: StoryBox
    ): Boolean {
        return oldItem.storyId == newItem.storyId
    }

    override fun areContentsTheSame(
        oldItem: StoryBox,
        newItem: StoryBox
    ): Boolean = oldItem == newItem
}

class StoryHorizontalAdapter(
    private val onClick: (StoryBox, Int, View) -> Unit
) : ListAdapter<StoryBox, StoryHorizontalAdapter.VH>(StoryDiff) {

    inner class VH(val binding: ItemStoryCardBinding) :
        RecyclerView.ViewHolder(binding.root) {

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        return VH(
            ItemStoryCardBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)
        var indexOfLastSeen = item.mediaSeenList.size
        val isAllSeen = item.mediaSeenList.size == item.mediaList.size
        if (isAllSeen) {
            indexOfLastSeen = 0
        }
        val path = try {
            item.mediaList[indexOfLastSeen]
        } catch (e: Exception) {
            e.printStackTrace()
            item.mediaList.first()
        }.mediaPath
        val date = item.mediaList.first().mediaDate
        holder.binding.image.loadGridImage(path, date)
        holder.binding.tvStoryTitle.text = item.title
        holder.itemView.setOnClickListener { onClick(item, holder.bindingAdapterPosition, it) }
        if (isAllSeen) {
            holder.itemView.alpha = 0.6f
        } else {
            holder.itemView.alpha = 1f
        }
    }
}

