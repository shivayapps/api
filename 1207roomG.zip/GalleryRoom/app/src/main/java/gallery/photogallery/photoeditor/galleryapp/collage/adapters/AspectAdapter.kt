package gallery.photogallery.photoeditor.galleryapp.collage.adapters

import android.content.res.ColorStateList
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.widget.ImageViewCompat
import androidx.recyclerview.widget.RecyclerView
import com.appblish.collagemaker.utils.AppblishCollageRatioUiModel
 import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.collage.utils.CollageConst.getAllRatios
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemCropBinding

class AspectAdapter(
    private val ratioList: List<AppblishCollageRatioUiModel>, // pass from activity

    private val includeFreeRatio: Boolean = true,
    private val onRatioSelected: (AppblishCollageRatioUiModel, String) -> Unit // Callback function
) : RecyclerView.Adapter<AspectAdapter.ViewHolder>() {

    private var lastSelectedView = 0
    lateinit var selectedRatio: AppblishCollageRatioUiModel

    val userRatioList = getAllRatios()


    // Filtering logic
    private val displayRatios = if (includeFreeRatio) userRatioList else userRatioList.filter { it.title != "Free" }


    init {
        if (displayRatios.isNotEmpty()) {
            Log.i("displayRatios", ": " + displayRatios.size)
            selectedRatio = displayRatios[0]
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemCropBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val model = displayRatios[position]
        val isSelected = position == lastSelectedView

        holder.binding.apply {
            textViewFilterName.text = model.title

            imageViewAspectRatio.setImageResource(model.icon)

            // Update UI based on selection state
            if (isSelected) {
                ImageViewCompat.setImageTintList(
                    imageViewAspectRatio,
                    ColorStateList.valueOf(
                        ContextCompat.getColor(root.context, R.color.color_primary)
                    )
                )
                 textViewFilterName.setTextColor(ContextCompat.getColor(root.context, R.color.color_primary))
            } else {

                ImageViewCompat.setImageTintList(
                    imageViewAspectRatio,
                    ColorStateList.valueOf(
                        ContextCompat.getColor(root.context, R.color.color_text)
                    )
                )
                 textViewFilterName.setTextColor(ContextCompat.getColor(root.context, R.color.color_text))
            }

            // Click Logic
            root.setOnClickListener {
                val currentPos = holder.adapterPosition
                if (currentPos != RecyclerView.NO_POSITION && currentPos != lastSelectedView) {
                    val oldPos = lastSelectedView
                    lastSelectedView = currentPos
                    selectedRatio = displayRatios[lastSelectedView]

                    // Call the callback
                    onRatioSelected(selectedRatio, selectedRatio.type.ratioText)

                    // Efficient UI update
                    notifyItemChanged(oldPos)
                    notifyItemChanged(lastSelectedView)
                }
            }
        }
    }

    override fun getItemCount(): Int = displayRatios.size

    fun resetSelection() {
        val oldPos = lastSelectedView
        lastSelectedView = -1
        if (oldPos != -1) notifyItemChanged(oldPos)
    }

    inner class ViewHolder(val binding: ItemCropBinding) : RecyclerView.ViewHolder(binding.root)
}