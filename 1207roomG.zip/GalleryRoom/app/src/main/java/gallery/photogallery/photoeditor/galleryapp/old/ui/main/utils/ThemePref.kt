package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils

import android.content.Context
import androidx.core.content.ContextCompat
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.getThemeSharedPrefs


class ThemePref(val context: Context) {
    protected val prefs = context.getThemeSharedPrefs()

    companion object {
        fun newInstance(context: Context) = ThemePref(context)
    }

    var appTextColor: Int
        get() = prefs.getInt(
            "APP_TEXT_COLOR", ContextCompat.getColor(context, R.color.app_text_color)
        )
        set(textColor) = prefs.edit().putInt("APP_TEXT_COLOR", textColor).apply()

    var appSubTextColor: Int
        get() = prefs.getInt(
            "APP_SUB_TEXT_COLOR", ContextCompat.getColor(context, R.color.app_sub_text_color)
        )
        set(textColor) = prefs.edit().putInt("APP_SUB_TEXT_COLOR", textColor).apply()

    var appBackgroundColor: Int
        get() = prefs.getInt(
            "APP_BACKGROUND_COLOR", ContextCompat.getColor(context, R.color.app_background)
        )
        set(backgroundColor) = prefs.edit().putInt("APP_BACKGROUND_COLOR", backgroundColor).apply()

    var appSubBackgroundColor: Int
        get() = prefs.getInt(
            "APP_SUB_BACKGROUND_COLOR", ContextCompat.getColor(context, R.color.app_sub_background)
        )
        set(backgroundColor) = prefs.edit().putInt("APP_SUB_BACKGROUND_COLOR", backgroundColor).apply()

    var appPrimaryColor: Int
        get() = prefs.getInt(
            "APP_PRIMARY_COLOR", ContextCompat.getColor(context, R.color.color_primary)
        )
        set(backgroundColor) = prefs.edit().putInt("APP_PRIMARY_COLOR", backgroundColor).apply()
}