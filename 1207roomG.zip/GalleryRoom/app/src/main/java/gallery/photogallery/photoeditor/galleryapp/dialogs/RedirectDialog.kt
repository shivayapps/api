package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogRedirectBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant.THEME_DARK
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant.THEME_LIGHT
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant.isAppInstalled
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Preferences
import gallery.photogallery.photoeditor.galleryapp.remote.RedirectItem

class RedirectDialog(
    private val activity: BaseActivity,
    private val appRedirectModel: RedirectItem,
    private val package_name: String,
    private val app_icon: String,
) : Dialog(activity), SafeDismissable {

    private lateinit var binding: DialogRedirectBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
        window?.setGravity(Gravity.CENTER)
        window?.navigationBarColor =
            ContextCompat.getColor(activity, R.color.dialogBg)

        binding = DialogRedirectBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Glide.with(context).load(app_icon).into(binding.imgTopIcon)

        val marginDp = 25
        val width = activity.resources.displayMetrics.widthPixels -
                (marginDp * 2 * activity.resources.displayMetrics.density).toInt()

        window?.setLayout(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT
        )

        setCancelable(appRedirectModel.isCancelable)

        bindData()
        setupClicks()
    }

    private fun bindData() {
        binding.txtTitle.text = appRedirectModel.title
        binding.txtDescription.text = appRedirectModel.description

        binding.btnOK.text = appRedirectModel.button_text

        binding.btnClose.visibility =
            if (appRedirectModel.isCancelable) View.VISIBLE else View.GONE

        when (Preferences(activity).getThemeValue()) {
            THEME_LIGHT -> {
                binding.icRedirectDialogCover.visibility = View.VISIBLE
            }

            THEME_DARK -> {
                binding.icRedirectDialogCover.visibility = View.GONE
            }
        }
    }

    private fun setupClicks() {
        binding.btnOK.setOnClickListener {
            launchAppStore()
            //   if (appRedirectModel.isCancelable) {
            //   dismiss()
            //   }
        }

        binding.btnClose.setOnClickListener {
            dismiss()
        }
    }

    override fun safeDismissRedirectDialog() {
        try {
            if (isShowing) {
                val isInstalled = isAppInstalled(activity, package_name)

                if ((isInstalled || appRedirectModel.isCancelable)) {
                    dismiss()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private fun launchAppStore() {
        val url = "https://play.google.com/store/apps/details?id=${package_name}"

        try {
            val intent = Intent(Intent.ACTION_VIEW, url.toUri()).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activity.startActivityForResult(intent, 8585)
        } catch (e: Exception) {
            try {
                val fallback = Intent(
                    Intent.ACTION_VIEW,
                    "market://details?id=${package_name}".toUri()
                )
                activity.startActivity(fallback)
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
        }
    }
}
