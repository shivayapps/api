package gallery.photogallery.photoeditor.galleryapp.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.MediaBox
import com.appblish.box.api.model.ScrollGate
import com.appblish.box.api.util.AppblishEvent
import com.appblish.box.api.util.MediaDataState
import com.appblish.gallery.core.v2.api.model.MediaListItem
import com.appblish.recyclerview.dragselection.SelectionUpdateCallback
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.adaptor.ExplorePhotosAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityExplorePhotosBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.PopBottomMenuBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.PopUpExploreMenuBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.ColumnsCountDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.ConfirmationDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.PhotosDetailsDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.RenameAlbumDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.RenamePhotosDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.ResizeDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.SortByMediaDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.editPhoto
import gallery.photogallery.photoeditor.galleryapp.extentions.onBackPressedDispatcher
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.getFilenameFromPath
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isFileExists
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.setAs
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.shareFilesList
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.PopupWindowHelper
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.SetLockActivity
import gallery.photogallery.photoeditor.galleryapp.utils.RESET_MEDIA
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.spancounthelper.ScaleHintListener
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class ExplorePhotosActivity : BaseActivity() {

    private val binding by viewBinding(ActivityExplorePhotosBinding::inflate)
    private val isVideo by lazy { intent.getBooleanExtra("IS_VIDEO", false) }


    private var getBucketPath: String = ""
    private var getBucketSize = 0

    private lateinit var layoutManager: GridLayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding.root.setPadding(0, 0, 0, navigationBarHeight)
        setContentView(binding.root)
        getBucketPath = intent.getStringExtra("BUCKET_PATH") ?: ""
        getBucketSize = intent.getIntExtra("BUCKET_SIZE", 0)
        initView()
        registerEventBus(this)
        clickListener()
    }

    private fun initView() {
        binding.llTop.setPadding(0, statusBarHeight, 0, 0)
        binding.tvCount.text = getBucketSize.toString()
        binding.rvAllMedia.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING ||
                    newState == RecyclerView.SCROLL_STATE_SETTLING
                ) {
                    ScrollGate.onScrollStart()
                } else {
                    ScrollGate.onScrollStop()
                }
            }
        })
        initAdaptor()
        setAlbumTitle()
        initSpanCountHelper()
        observableMedia()
    }

    private fun initAdaptor() {
        if (binding.rvAllMedia.adapter == null) {
            val albumAdaptor = ExplorePhotosAdapter(binding.rvAllMedia) {
                onMediaSelectSelect(it)

            }
            binding.rvAllMedia.adapter = albumAdaptor
            albumAdaptor.setSelectionUpdateCallback(
                object : SelectionUpdateCallback {
                    override fun onSelectionCountChanged(
                        selectedCount: Int,
                        selectionActive: Boolean
                    ) {
                        updateExploreSelections()
                    }
                }
            )
        }
    }

    fun onMediaSelectSelect(mediaBox: MediaBox) {
        val allMediaAdaptor = getExplorePhotosAdapter() ?: return
        val mediaPaths = allMediaAdaptor.getAllPaths()

        sharedViewModel.imageViewerList =
            ArrayList(mediaPaths)
        val startPosition = mediaPaths.indexOf(mediaBox.mediaPath)
        startActivity(
            Intent(this, NewImageViewerActivity::class.java).apply {
                putExtra("startPosition", startPosition)
            }
        )
    }

    private fun setAlbumTitle() {
        binding.tvAlbumName.text = when (getBucketPath?.getFilenameFromPath()) {
            "all_videos" -> {
                ContextCompat.getString(this, R.string.all_videos)
            }

            "recent" -> {
                ContextCompat.getString(this, R.string.recent)
            }

            "favorite" -> {
                ContextCompat.getString(this, R.string.Favorite)
            }

            "more_album" -> {
                ContextCompat.getString(this, R.string.more_album)
            }

            "recent_videos" -> {
                ContextCompat.getString(this, R.string.recent)
            }

            else -> {
                getBucketPath?.getFilenameFromPath()
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initSpanCountHelper() {
        layoutManager = GridLayoutManager(this, appPref.mediaGrid)
        binding.rvAllMedia.layoutManager = layoutManager
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (getExplorePhotosAdapter()?.getItem(position) is MediaListItem.Header) {
                    appPref.mediaGrid
                } else {
                    1
                }
            }
        }

        val listener = ScaleHintListener(
            context = this,
            recyclerView = binding.rvAllMedia,
            layoutManager = layoutManager,
            ghostCardView = binding.ghostCardView,
            ghostImageView = binding.ghostImageView,
            gridHelperView = binding.gridHelperView,
            spanHintText = binding.spanHintText,
            landingCircle = binding.landingCircle,
            overlayContainer = binding.overlayContainer,
            imageViewExtractor = { itemView ->
                itemView.findViewById(R.id.medium_thumbnail)

            },
            onUpdateSpan = { span ->
                appPref.mediaGrid = span
            },
            dimLayer = binding.dimLayer,
            minSpan = 2,
            maxSpan = 6
        )
        binding.rvAllMedia.setOnTouchListener(listener)
    }

    var fetchJob: Job? = null
    private fun observableMedia() {
        fetchJob?.cancel()
        fetchJob = lifecycleScope.launch(Dispatchers.IO) {
            val state = if (isVideo) sharedViewModel.fetchAllVideoAlbumMedia(getBucketPath.orEmpty()) else sharedViewModel.fetchAlbumMedia(getBucketPath.orEmpty())
            withContext(Dispatchers.Main) {
                if (state is MediaDataState.Success) {
                    binding.llLoader.beGone()
                    setMedia(state.data)
                }
                if (state is MediaDataState.Empty) {
                    setMedia(emptyList())
                }
            }
        }
    }

    private fun setMedia(mediaList: List<MediaListItem>) {
        lifecycleScope.launch {
            initAdaptor()
            getExplorePhotosAdapter()?.submitList(ArrayList(mediaList))
            binding.tvCount.text = mediaList.filterIsInstance<MediaListItem.Media>().count().toString()
            if (mediaList.isEmpty()) {
                binding.llNoDataFound.beVisible()
            } else {
                binding.llNoDataFound.beGone()
            }
        }
    }

    @SuppressLint("SetTextI18n")
    fun updateExploreSelections() {
        val explorePhotosAdapter = getExplorePhotosAdapter() ?: return
        val enableSelection = getExplorePhotosAdapter()?.isSelectionActive() ?: false
        binding.clSelection.beVisibleIf(enableSelection)
        binding.albumToolbar.beVisibleIf(!enableSelection)

        binding.tvTitleSelection.text = "${explorePhotosAdapter.getSelectedCount()} " + resources.getString(R.string.selected)

        if (explorePhotosAdapter.isAllSelectedItems()) {
            binding.icSelectAll.setImageResource(R.drawable.vec_selected_bg)
        } else {
            binding.icSelectAll.setImageResource(R.drawable.vec_unselected_bg)
        }
        updateMediaSelection()
    }

    fun disableSelection() {
        val explorePhotosAdapter = getExplorePhotosAdapter() ?: return
        explorePhotosAdapter.clearSelectionAndExit()
        updateExploreSelections()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            RESET_MEDIA -> {
                val mediaList = getExplorePhotosAdapter()?.getAll() ?: return
                binding.rvAllMedia.adapter = null
                initAdaptor()
                initSpanCountHelper()
                getExplorePhotosAdapter()?.submitList(mediaList)
            }


            AppblishEvent.ALL_ALBUM_LOADED -> {
                observableMedia()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterEventBus(this)
    }

    private fun clickListener() {

        onBackPressedDispatcher {
            val explorePhotosAdapter = getExplorePhotosAdapter() ?: return@onBackPressedDispatcher
            if (explorePhotosAdapter.isSelectionActive()) {
                disableSelection()
            } else {
                finish()
            }
        }

        binding.ivClose.setOnClickListener {
            val explorePhotosAdapter = getExplorePhotosAdapter() ?: return@setOnClickListener
            if (explorePhotosAdapter.isSelectionActive()) {
                disableSelection()
            } else
                finish()
        }

        binding.ivBack.setOnClickListener {
            finish()
        }

        binding.icSelectAll.setOnClickListener {
            val explorePhotosAdapter = getExplorePhotosAdapter() ?: return@setOnClickListener
            explorePhotosAdapter.toggleSelectionAll()
        }

        binding.flExploreMore.setOnClickListener {
            showMenuExplore(binding.flExploreMore)
        }
    }

    private fun showMenuExplore(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopUpExploreMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)
        popUpBinding.menuRename.beVisibleIf(getBucketPath!!.isFileExists())
        view.post {
            val location = IntArray(2)
            view.getLocationOnScreen(location)
            val x = location[0] + view.width + 100
            val y = location[1] + view.height

            popupWindow.showAtLocation(view, Gravity.NO_GRAVITY, x, y)

            popUpBinding.run {
                menuSelect.setOnClickListener {
                    popupWindow.dismiss()
                    val explorePhotosAdapter = getExplorePhotosAdapter() ?: return@setOnClickListener
                    explorePhotosAdapter.enableSelectionMode()
                }
                menuSortBy.setOnClickListener {
                    popupWindow.dismiss()
                    Log.e("btmSelectionView", "menuSortBy: ")
                    SortByMediaDialog {
                        sharedViewModel.fetchMedia()
                    }.show(supportFragmentManager, "SortByDialog")
                }

                menuColumnCount.setOnClickListener {
                    popupWindow.dismiss()
                    Log.e("btmSelectionView", "menuColumnCount: ")
                    ColumnsCountDialog(false).show(supportFragmentManager, "ColumnsCountDialog")
                }

                menuHide.setOnClickListener {
                    popupWindow.dismiss()
                    Log.e("btmSelectionView", "menuColumnCount: ")
                    checkStoragePermission {
                        if (it) {
                            if (preferences.getSetPass()) {
                                hideMediaFromAlbum()
                            } else {
                                val intent = Intent(this@ExplorePhotosActivity, SetLockActivity::class.java)
                                intent.putExtra("setResultCode", 101)
                                albumHideResult.launch(intent)
                            }
                        }
                    }
                }

                menuRename.setOnClickListener {
                    popupWindow.dismiss()
                    Log.e("btmSelectionView", "menuColumnCount: ")
                    checkStoragePermission {
                        if (it) {
                            val renameAlbumDialog = RenameAlbumDialog(this@ExplorePhotosActivity)
                            renameAlbumDialog.bucketPath = getBucketPath.toString()
                            renameAlbumDialog.positiveBtnClickListener = { renamedFile, oldFile ->
                                showLoadingDialog()
                                sharedViewModel.renameAlbum(oldFile.absolutePath, renamedFile.name) {
                                    hideLoadingDialog()
                                    if (it) {
                                        sharedViewModel.fetchMedia()
                                        getBucketPath = renamedFile.path
                                        observableMedia()
                                        runOnUiThread {
                                            setAlbumTitle()
                                        }
                                    }
                                }
                            }
                            renameAlbumDialog.show(supportFragmentManager, "RenameAlbumDialog")
                        }
                    }
                }
                menuSlideShow.setOnClickListener {
                    popupWindow.dismiss()
                    val explorePhotosAdapter = getExplorePhotosAdapter() ?: return@setOnClickListener
                    sharedViewModel.imageViewerList.clear()
                    sharedViewModel.imageViewerList.addAll(explorePhotosAdapter.getAllPaths())
                    startActivity(Intent(this@ExplorePhotosActivity, NewImageViewerActivity::class.java).apply {
                        putExtra("startPosition", 0)
                        putExtra("ACTIVITY_NAME", "ExplorePhotosActivity")

                    })
                }
            }
        }
    }


    private fun shareImages() {
        val explorePhotosAdapter = getExplorePhotosAdapter() ?: return
        val mediaList = explorePhotosAdapter.getSelectedItems()
        if (mediaList.isEmpty()) {
            toast(getString(R.string.please_select_item))
            return
        }
        val uris = ArrayList<Uri>()
        uris.addAll(explorePhotosAdapter.getSelectedItems().filterIsInstance<MediaListItem.Media>().map {
            it.mediaBox.mediaUri.toUri()
        })
        shareFilesList(this, uris.filterNotNull())
    }

    private fun updateMediaSelection() {
        val explorePhotosAdapter = getExplorePhotosAdapter() ?: return

        val enableSelection = explorePhotosAdapter.isSelectionActive() ?: false
        binding.albumSelectionView.beVisibleIf(enableSelection)
        val folderList = explorePhotosAdapter.getSelectedItems().filterIsInstance<MediaListItem.Media>()

        binding.clShare.setOnClickListener {
            if (folderList.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            shareImages()

            disableSelection()
        }

        binding.clDelete.setOnClickListener {
            if (folderList.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            val mediaPathList = folderList.map { it.mediaBox.mediaPath }
            deleteMedia(mediaPathList) {
                disableSelection()
            }
        }

        binding.clHide.setOnClickListener {
            if (folderList.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }

            checkStoragePermission {
                if (it) {
                    if (preferences.getSetPass()) {
                        hideAllMediaFromMedia()
                    } else {
                        val intent = Intent(this, SetLockActivity::class.java)
                        intent.putExtra("setResultCode", 101)
                        allMediaHideResult.launch(intent)
                    }
                }
            }
        }

        binding.clMore.setOnClickListener {
            if (folderList.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            showPhotoDropDown(it, folderList)
        }
    }

    private fun showPhotoDropDown(view: View, photosList: List<MediaListItem.Media>) {
//        val getMediaBox = selectedItems.map { it }

        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)

        val isSingleSelection = photosList.count() == 1

        val isVideo = photosList.any { it.mediaBox.isVideoCheck() }
        val isGif = photosList.any { it.mediaBox.isGifCheck() }

        popUpBinding.run {
            menuSetAs.beVisibleIf(isSingleSelection && !isVideo && !isGif)
            menuEdit.beVisibleIf(isSingleSelection && !isVideo && !isGif)
            menuResize.beVisibleIf(isSingleSelection && !isVideo && !isGif)
            menuRename.beVisibleIf(isSingleSelection && !isVideo && !isGif)

            popupWindow.showAsPopUp(view, yoff = -20, xoff = 20)

            val isAllFav = photosList.all { it.isFavourite }
            popUpBinding.menuAddFavourite.beVisibleIf(!isAllFav)
            popUpBinding.menuRemoveFavourite.beVisibleIf(isAllFav)

            loutMain.setOnClickListener {
                popupWindow.dismiss()
            }

            menuRename.setOnClickListener {
                disableSelection()
                checkStoragePermission {
                    if (it) {
                        val renameFileDialog = RenamePhotosDialog(this@ExplorePhotosActivity)
                        renameFileDialog.filePath = photosList.first().mediaBox.mediaPath
                        renameFileDialog.positiveBtnClickListener = { renamedFile, oldFile ->

                            showLoadingDialog()
                            sharedViewModel.renameMedia(oldFile.absolutePath, renamedFile.name) {
                                hideLoadingDialog()
                                if (it) {
                                    sharedViewModel.fetchMedia()
                                }
                            }
                        }
                        renameFileDialog.show(supportFragmentManager, "RenamePhotosDialog")
                    }
                }
            }

            menuEdit.setOnClickListener {
                popupWindow.dismiss()
                val mediaPath: String? = photosList
                    .firstOrNull()
                    ?.mediaBox
                    ?.mediaPath
                if (!mediaPath.isNullOrEmpty())
                    editPhoto(mediaPath)

            }


            menuResize.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        val mediaPath = photosList.first().mediaBox.mediaPath
                        val renameFileDialog = ResizeDialog(this@ExplorePhotosActivity, mediaPath) { w, h, name, keepOriginal ->
                            disableSelection()
                            showLoadingDialog()
                            sharedViewModel.resizeMedia(mediaPath, w, h, name, keepOriginal) { b, path ->
                                hideLoadingDialog()
                                if (b) {
                                    sharedViewModel.fetchMedia()
                                }
                            }
                        }

                        renameFileDialog.show(supportFragmentManager, "ResizeDialog")
                    }
                }
            }

            menuInfo.setOnClickListener {
                popupWindow.dismiss()
//                AllMediaDetailsBottomSheet(allMediaFragment).show(supportFragmentManager, "AlbumDetailsBottomSheet")
                Log.e("btmSelectionView", "menuInfo: ")
                val mediaPathList = photosList.map { it.mediaBox.mediaPath }
                disableSelection()
                PhotosDetailsDialog(mediaPathList).show(supportFragmentManager, "PhotosDetailsDialog")
            }

            menuCopy.setOnClickListener {
                popupWindow.dismiss()
                Log.e("btmSelectionView", "menuCopy: ")
                checkStoragePermission {
                    if (it) {
                        val list = photosList.map { it.mediaBox.mediaPath }
                        requestAlbumPicker(emptyArray()) {
                            if (it.isNotEmpty()) {
                                copyFolderFiles(list, it)
                                disableSelection()
                            }
                        }
                    }
                }
            }

            menuMove.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        Log.e("btmSelectionView", "menuMove: ")
                        val list = photosList.map { it.mediaBox.mediaPath }
                        requestAlbumPicker(emptyArray()) {
                            if (it.isNotEmpty()) {
                                moveFolderFiles(list, it)
                                disableSelection()
                            }
                        }
                    }
                }

            }

            menuAddFavourite.setOnClickListener {
                popupWindow.dismiss()
                Log.e("btmSelectionView", "menuAddFavourite: ")
                sharedViewModel.addToFav(photosList.map { it.mediaBox.mediaPath })
                disableSelection()
            }

            menuRemoveFavourite.setOnClickListener {
                popupWindow.dismiss()
                Log.e("btmSelectionView", "menuRemoveFavourite: ")
                sharedViewModel.removeToFav(photosList.map { it.mediaBox.mediaPath })
                disableSelection()
            }
            menuSetAs.setOnClickListener {
                popupWindow.dismiss()
                val filePath = photosList.map { it.mediaBox.mediaPath }
                setAs(filePath.single())
            }
        }


    }


    private var allMediaHideResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            hideAllMediaFromMedia()
        }
    }

    private fun hideAllMediaFromMedia() {
        val dialog = ConfirmationDialog(
            this,
            ContextCompat.getString(this, R.string.hide),
            ContextCompat.getString(this, R.string.confirmation_hide_item),
            ContextCompat.getString(this, R.string.no),
            ContextCompat.getString(this, R.string.yes),
            ContextCompat.getColor(this, R.color.white_color)
        ) {
            val explorePhotosAdapter = getExplorePhotosAdapter() ?: return@ConfirmationDialog
            val selectedItems = explorePhotosAdapter.getSelectedItems().filterIsInstance<MediaListItem.Media>().map { it.mediaBox.mediaPath }
            hideMediaFolder(selectedItems) {
                disableSelection()
            }
        }
        dialog.show(supportFragmentManager, "ConfirmationDialog")

    }

    private var albumHideResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            hideMediaFromAlbum()
        }
    }

    private fun hideMediaFromAlbum() {
        val dialog = ConfirmationDialog(
            this,
            ContextCompat.getString(this, R.string.hide),
            ContextCompat.getString(this, R.string.confirmation_hide_item),
            ContextCompat.getString(this, R.string.no),
            ContextCompat.getString(this, R.string.yes),
            ContextCompat.getColor(this, R.color.white_color)
        ) {
            val explorePhotosAdapter = getExplorePhotosAdapter() ?: return@ConfirmationDialog
            hideMediaFolder(explorePhotosAdapter.getAllPaths()) {
            }
        }
        dialog.show(supportFragmentManager, "ConfirmationDialog")
    }

    fun getExplorePhotosAdapter() = binding.rvAllMedia.adapter as? ExplorePhotosAdapter

}