package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.R
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogCreateAlbumBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import java.io.File

class CreateNewAlbumDialog(var createPathListener: ((path: String) -> Unit)? = null) : DialogFragment() {
    private var _binding: DialogCreateAlbumBinding? = null
    private val binding get() = _binding!!
    private lateinit var safeContext: Context

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogCreateAlbumBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }

        intView()
        clickListener()

        return dialog
    }

    private fun clickListener() {
        binding.edtAlbumName.addTextChangedListener {
            binding.icClear.beVisibleIf(binding.edtAlbumName.length() > 0)
        }

        binding.icClear.setOnClickListener {
            binding.edtAlbumName.setText("")
        }

        binding.btnCreate.setOnClickListener {
            val albumName = binding.edtAlbumName.text.trim()
            if (albumName.isNotEmpty()) {
                val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).path + File.separator + albumName)
                if (!file.exists()) {
                    file.mkdirs()
                    createPathListener?.invoke(file.path)
                    dismiss()
                } else {
                    activity?.toast(getString(gallery.photogallery.photoeditor.galleryapp.R.string.create_validation2))
                }
            } else {
                activity?.toast(getString(gallery.photogallery.photoeditor.galleryapp.R.string.create_validation))

            }


        }

        binding.btnCancel.setOnClickListener {
            hideKeyboard()
            dismiss()
        }
    }

    private fun showKeyboard() {
        binding.edtAlbumName.requestFocus()
        val methodManager = (activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(binding.edtAlbumName, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard() {
        binding.edtAlbumName.clearFocus()
        val methodManager = (activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(binding.edtAlbumName.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun intView() {
        showKeyboard()
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}