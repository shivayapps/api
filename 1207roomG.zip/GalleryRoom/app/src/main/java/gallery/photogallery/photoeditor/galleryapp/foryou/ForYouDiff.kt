package gallery.photogallery.photoeditor.galleryapp.foryou

import androidx.recyclerview.widget.DiffUtil


object ForYouDiff : DiffUtil.ItemCallback<ForYouListItem>() {

    override fun areItemsTheSame(old: ForYouListItem, new: ForYouListItem): Boolean {
        return when {
            old is ForYouListItem.Memory && new is ForYouListItem.Memory ->
                old.memory == new.memory

            else -> false
        }
    }

    override fun areContentsTheSame(old: ForYouListItem, new: ForYouListItem): Boolean {
        return old == new
    }
}

