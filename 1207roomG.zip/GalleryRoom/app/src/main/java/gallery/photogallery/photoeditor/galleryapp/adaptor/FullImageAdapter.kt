package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.animation.ValueAnimator
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import androidx.core.animation.doOnEnd
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.appblish.medialoader.AppblishImageLoader.loadFullImage
import com.bumptech.glide.Glide
import com.github.chrisbanes.photoview.PhotoView
import gallery.photogallery.photoeditor.galleryapp.activities.NewImageViewerActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.ImageviewImageBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.playVideo
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isGif
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isVideoFast
import java.io.File

class FullImageAdapter(
    val newImageViewerActivity: NewImageViewerActivity,
    val allowZoomingImages: Boolean,
    val onScaleChanged: (Boolean) -> Unit
) : ListAdapter<String, RecyclerView.ViewHolder>(fullImageDiffUtil) {


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): RecyclerView.ViewHolder {
        val binding = ImageviewImageBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return FullImageViewHolder(binding)
    }

    override fun onBindViewHolder(
        holder: RecyclerView.ViewHolder,
        position: Int,
    ) {
        if (holder is FullImageViewHolder) {
            holder.bind(currentList[position], allowZoomingImages, onScaleChanged)
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        if (holder is FullImageViewHolder) {
            Glide.with(holder.binding.photoView.context.applicationContext).clear(holder.binding.photoView)
        }
    }


    inner class FullImageViewHolder(val binding: ImageviewImageBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(media: String, allowZoomingImages: Boolean, onScaleChanged: (Boolean) -> Unit) {
            itemView.tag = media
            val file = File(media)
            if (media.isGif()) {
                binding.gifView.setImageURI(Uri.fromFile(file))
                binding.gifView.beVisible()
                binding.icVideo.beGone()
                binding.gesturesView.beGone()
                binding.photoView.isZoomable = false
            } else {

                binding.photoView.loadFullImage(media, file.lastModified())
                binding.icVideo.beVisibleIf(media.isVideoFast())
                if (media.isVideoFast()) {
                    binding.gifView.beVisible()
                    binding.icVideo.beVisible()
                    binding.gesturesView.beGone()
                    binding.photoView.isZoomable = false
                } else {
                    // ---- IMAGE ----
                    binding.gifView.beGone()
                    binding.icVideo.beGone()
                    binding.gesturesView.beGone()
                    binding.photoView.isZoomable = true
                }
            }


            // Get screen size
            val displayMetrics = itemView.context.resources.displayMetrics
            val screenWidth = displayMetrics.widthPixels
            val screenHeight = displayMetrics.heightPixels

            // Decode image bounds only (fast, no memory load)
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeFile(media, options)

            val imageWidth = options.outWidth
            val imageHeight = options.outHeight

            val maxZoom = if (allowZoomingImages) {
                calculateMaxZoom(imageWidth, imageHeight, screenWidth, screenHeight)
            } else {
                3.0f
            }

            binding.photoView.apply {
                minimumScale = .975f
                mediumScale = minOf(1.75f, maxZoom - 1f)
                maximumScale = maxZoom

                /* setOnScaleChangeListener { scale, _, _ ->
                     val currentScale = binding.photoView.scale
 //                    onScaleChanged(scale <= 1f)
                     onScaleChanged(currentScale <= 1.0f)
                 }*/
                binding.photoView.post {
                    binding.photoView.setOnScaleChangeListener { _, _, _ ->
                        onScaleChanged(binding.photoView.scale <= 1f)
                        Log.e("photoView", "bind: " + binding.photoView.scale.toString())
                    }
                }

            }

            binding.icVideo.setOnClickListener {
                newImageViewerActivity.playVideo(media)
            }


        }

        private fun calculateMaxZoom(
            imageWidth: Int, imageHeight: Int, screenWidth: Int, screenHeight: Int
        ): Float {
            val widthRatio = imageWidth.toFloat() / screenWidth
            val heightRatio = imageHeight.toFloat() / screenHeight

            val maxRatio = maxOf(widthRatio, heightRatio)

            return when {
                maxRatio <= 1.2f -> 3f   // small images
                maxRatio <= 3f -> 6f   // medium
                maxRatio <= 5.0f -> 12f   // large
                else -> 15f              // very large images
            }
        }

    }

    fun rotateItem(position: Int, recyclerView: RecyclerView, callback: (Float) -> Unit) {
        val media = currentList[position]
        recyclerView.findViewHolderForAdapterPosition(position)?.let { holder ->
            if (holder is FullImageViewHolder) {
                rotatePhotoViewFinal(
                    photoView = holder.binding.photoView,
                    path = media,
                    callback
                )

            }
        }

    }

    fun afterRotate(position: Int, recyclerView: RecyclerView) {
        val media = currentList[position]
        recyclerView.findViewHolderForAdapterPosition(position)?.let { holder ->
            if (holder is FullImageViewHolder) {
                val file = File(media)
                holder.binding.photoView.loadFullImage(media, file.lastModified())
            }
        }
    }

    val transformMap = mutableMapOf<String, Float>()
    fun rotatePhotoViewFinal(
        photoView: PhotoView,
        path: String,
        callback: (Float) -> Unit
    ) {


        val current = transformMap[path]
        val startRotation = current ?: 0f
        val endRotation = (startRotation + 90f) % 360f


        /* ---------- ROTATION ---------- */
        ValueAnimator.ofFloat(startRotation, endRotation).apply {
            duration = 220
            interpolator = DecelerateInterpolator()

            addUpdateListener {
                photoView.setRotationTo(it.animatedValue as Float)
            }

            doOnEnd {
                photoView.setRotationTo(endRotation)
                photoView.setScale(1f, true)
                callback.invoke(endRotation)

            }
        }.start()
    }

}

val fullImageDiffUtil = object : DiffUtil.ItemCallback<String>() {
    override fun areItemsTheSame(
        oldItem: String, newItem: String,
    ): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(
        oldItem: String, newItem: String,
    ): Boolean {
        return oldItem == newItem
    }

}
