package gallery.photogallery.photoeditor.galleryapp.collage.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.appblish.gallery.core.v2.api.model.AlbumListItem
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemCollageListAlbumBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemHeaderBinding

class CollageAlbumAdapter(
    private val onClick: (AlbumListItem) -> Unit
) : ListAdapter<AlbumListItem, RecyclerView.ViewHolder>(Diff()) {

    companion object {
        private const val TYPE_HEADER = 0
        private const val TYPE_ALBUM = 1
    }

    override fun getItemViewType(position: Int): Int {
        return when (getItem(position)) {
            is AlbumListItem.Header -> TYPE_HEADER
            is AlbumListItem.Album -> TYPE_ALBUM
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {

        return when (viewType) {
            TYPE_HEADER -> {
                val binding = ItemHeaderBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
                HeaderVH(binding)
            }

            else -> {
                val binding = ItemCollageListAlbumBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
                AlbumVH(binding)
            }
        }
    }

    override fun onBindViewHolder(
        holder: RecyclerView.ViewHolder,
        position: Int
    ) {
        when (val item = getItem(position)) {

            is AlbumListItem.Header -> {
                (holder as HeaderVH).bind(item)
            }

            is AlbumListItem.Album -> {
                (holder as AlbumVH).bind(item)
                holder.itemView.setOnClickListener {
                    onClick(item)
                }
            }
        }
    }

    // ---------------- VIEW HOLDERS ----------------

    class HeaderVH(
        private val binding: ItemHeaderBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: AlbumListItem.Header) {
            binding.headerTitle.text = item.header
        }
    }

    class AlbumVH(
        private val binding: ItemCollageListAlbumBinding,
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: AlbumListItem.Album) {
            val album = item.albumBox


            with(binding) {
                albumTitle.text = album.bucketName
                albumCount.text = album.mediaList.size.toString()
                coverImage.loadGridImage(album.mediaList.first().mediaPath, album.mediaList.first().mediaDate)
            }
        }
    }

    // ---------------- DIFF ----------------

    class Diff : DiffUtil.ItemCallback<AlbumListItem>() {

        override fun areItemsTheSame(
            oldItem: AlbumListItem,
            newItem: AlbumListItem
        ): Boolean = oldItem.id == newItem.id

        override fun areContentsTheSame(
            oldItem: AlbumListItem,
            newItem: AlbumListItem
        ): Boolean = oldItem == newItem
    }
}

