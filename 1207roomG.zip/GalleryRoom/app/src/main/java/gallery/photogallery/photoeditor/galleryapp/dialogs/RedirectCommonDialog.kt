package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogRedirectCommonBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant.THEME_DARK
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant.THEME_LIGHT
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant.isAppInstalled
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Preferences
import gallery.photogallery.photoeditor.galleryapp.remote.RedirectItem

class RedirectCommonDialog(
    private val activity: BaseActivity,
    private val appRedirectModel: RedirectItem,
    private val dialogType: String,
    private val package_name: String = "",
) : Dialog(activity), SafeDismissable {

    private lateinit var binding: DialogRedirectCommonBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
        window?.setGravity(Gravity.CENTER)
        window?.navigationBarColor =
            ContextCompat.getColor(activity, R.color.dialogBg)

        binding = DialogRedirectCommonBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val marginDp = 25
        val width = activity.resources.displayMetrics.widthPixels -
                (marginDp * 2 * activity.resources.displayMetrics.density).toInt()

        window?.setLayout(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT
        )

        setCancelable(appRedirectModel.isCancelable)
        bindData()
        setupClicks()
    }

    private fun bindData() {
        // Title & description
        binding.txtTitle.text = appRedirectModel.title
        binding.txtDescription.text = appRedirectModel.description

        // Button text
        binding.btnOK.text = appRedirectModel.button_text


        // Close button visibility
        binding.btnClose.visibility =
            if (appRedirectModel.isCancelable) View.VISIBLE else View.GONE


        when (dialogType) {

            "installed" -> {
                binding.btnOK.setBackgroundResource(R.drawable.btn_bg_round)
                binding.imgTopIcon.setImageResource(R.drawable.ic_installed)
            }

            "important" -> {

                binding.btnOK.setBackgroundResource(R.drawable.btn_bg_round)
                binding.imgTopIcon.setImageResource(R.drawable.ic_important)
            }

            "mandatory" -> {
                binding.btnOK.setBackgroundResource(R.drawable.btn_redirect_danger)
                binding.imgTopIcon.setImageResource(R.drawable.ic_mandatory)
            }
        }

        when (Preferences(activity).getThemeValue()) {
            THEME_LIGHT -> {
                binding.icRedirectDialogCover.visibility = View.VISIBLE
            }

            THEME_DARK -> {
                binding.icRedirectDialogCover.visibility = View.GONE
            }
        }

        /* appRedirectModel.icon_url.let {
         Glide.with(context)
             .load(appRedirectModel.icon_url)
             .transform(
                 CenterCrop(),
                 RoundedCorners(activity.resources.getDimensionPixelSize(com.intuit.sdp.R.dimen._10sdp))
             )
             .diskCacheStrategy(DiskCacheStrategy.ALL)
             .into(binding.imgTopIcon)
     }*/
    }

    override fun safeDismissRedirectDialog() {
        try {
            if (isShowing) {
                val isInstalled = isAppInstalled(activity, package_name)

                if ((isInstalled || appRedirectModel.isCancelable)) {
                    dismiss()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupClicks() {
        binding.btnOK.setOnClickListener {

            when (dialogType) {

                "installed" -> {
                    val opened = openInstalledApp(activity, package_name)
                    if (!opened) {
                        launchAppStore()
                    } else {
                        dismiss()
                    }
                }

                "important" -> {
                    launchAppStore()
                }

                "mandatory" -> {
                    launchAppStore()
                }
            }

            // if (appRedirectModel.isCancelable) {
            //    dismiss()
            //   }


        }

        binding.btnClose.setOnClickListener {
            dismiss()
        }
    }

    private fun openInstalledApp(activity: BaseActivity, packageName: String?): Boolean {
        if (packageName.isNullOrEmpty()) return false

        return try {
            val intent = activity.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                try {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    activity.startActivity(intent)
                    true
                } catch (e: Exception) {
                    false
                }
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }


    private fun launchAppStore() {
        val url = "https://play.google.com/store/apps/details?id=${package_name}"

        try {
            val intent = Intent(Intent.ACTION_VIEW, url.toUri()).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activity.startActivityForResult(intent, 8585)
        } catch (e: Exception) {
            try {
                val fallback = Intent(
                    Intent.ACTION_VIEW,
                    "market://details?id=${package_name}".toUri()
                )
                activity.startActivity(fallback)
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
        }
    }
}
