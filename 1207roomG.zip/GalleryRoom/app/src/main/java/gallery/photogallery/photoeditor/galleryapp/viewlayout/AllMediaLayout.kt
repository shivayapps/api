package gallery.photogallery.photoeditor.galleryapp.viewlayout

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Intent
import android.util.Log
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.animation.doOnEnd
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.MainMediaFilter
import com.appblish.box.api.model.MediaBox
import com.appblish.box.api.model.ScrollGate
import com.appblish.box.api.util.MediaDataState
import com.appblish.gallery.core.v2.api.core.GallerySdkV2
import com.appblish.gallery.core.v2.api.model.MediaListItem
import com.appblish.medialoader.AppblishImageLoader.setupGlidePreLoader
import com.appblish.medialoader.PreloadItem
import gallery.photogallery.photoeditor.galleryapp.permission.PermissionSDK
import com.appblish.recyclerview.dragselection.SelectionUpdateCallback
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.MainActivity
import gallery.photogallery.photoeditor.galleryapp.activities.NewImageViewerActivity
import gallery.photogallery.photoeditor.galleryapp.adaptor.MediaListAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.FragmentAllMediaBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.restart
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.popup_menu.PhotosMenuPopup
import gallery.photogallery.photoeditor.galleryapp.utils.spancounthelper.ScaleHintListener
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AllMediaLayout(private val mainActivity: MainActivity, private val binding: FragmentAllMediaBinding) {
    private val lifecycleScope = mainActivity.lifecycleScope
    private val sharedViewModel = mainActivity.sharedViewModel
    private fun getString(resId: Int) = mainActivity.getString(resId)

    fun setupViews() {
        init()
        setListeners()
    }

    private fun init() {
        initAdaptor()
        initSpanCountHelper()
        observableMedia()
    }

    private fun formatDateTime(timeMillis: Long): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        return sdf.format(Date(timeMillis))
    }

    private fun setListeners() {

        binding.ivDropDown.setOnClickListener {
            mainActivity.showHomeMenuFilter(binding.tvAlbumAll2)
        }

        binding.ivClose.setOnClickListener {
            val mediaListAdapter = getMediaListAdapter() ?: return@setOnClickListener
            if (mediaListAdapter.isSelectionActive()) {
                disableSelection()
            }
        }

        binding.ivAlbumCamera.setOnClickListener {
            mainActivity.openCamera()
        }

        binding.flAlbumMore.setOnClickListener {
            showMenu(it)
        }

        binding.icSelectAll.setOnClickListener {
            val mediaListAdapter = getMediaListAdapter() ?: return@setOnClickListener
            if (mediaListAdapter.isSelectAll()) {
                mediaListAdapter.unSelectAll()
            } else {
                mediaListAdapter.selectAll()
            }
        }

        binding.ivPhotosSearch.setOnClickListener {
            mainActivity.onSearchClick()
        }

        binding.rvAllMedia.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING ||
                    newState == RecyclerView.SCROLL_STATE_SETTLING
                ) {
                    ScrollGate.onScrollStart()
                } else {
                    ScrollGate.onScrollStop()
                }
            }

            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                val layoutManager = recyclerView.layoutManager as GridLayoutManager
                val firstVisible = layoutManager.findFirstVisibleItemPosition()

                if (firstVisible == RecyclerView.NO_POSITION || firstVisible == 0) {
                    binding.txtFloatingDate.beGone()
                    return
                }
                val mediaListAdapter = getMediaListAdapter() ?: return

                when (val item = mediaListAdapter.getItem(firstVisible)) {
                    is MediaListItem.Header -> {
                        binding.txtFloatingDate.text = item.header
                    }

                    is MediaListItem.Media -> {
                        val dateTime = item.mediaBox.mediaDate
                        binding.txtFloatingDate.text = formatDateTime(dateTime)
                    }
                }

                binding.txtFloatingDate.beVisible()
            }
        })
        binding.incPermission.tvAllow.setOnClickListener {
            mainActivity.requestManageAllFile {
                mainActivity.startActivity(Intent(mainActivity, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                })
            }
        }
    }

    private fun showMenu(view: View) {
        PhotosMenuPopup(mainActivity).show(view)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initSpanCountHelper() {
        val layoutManager = GridLayoutManager(mainActivity, mainActivity.appPref.mediaGrid)
        binding.rvAllMedia.layoutManager = layoutManager
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                val mediaListAdapter = getMediaListAdapter()
                return if (mediaListAdapter?.getItem(position) is MediaListItem.Header) {
                    mainActivity.appPref.mediaGrid
                } else {
                    1
                }
            }
        }

        val listener = ScaleHintListener(
            context = mainActivity,
            recyclerView = binding.rvAllMedia,
            layoutManager = layoutManager,
            ghostCardView = binding.ghostCardView,
            ghostImageView = binding.ghostImageView,
            gridHelperView = binding.gridHelperView,
            spanHintText = binding.spanHintText,
            landingCircle = binding.landingCircle,
            overlayContainer = binding.overlayContainer,
            imageViewExtractor = { itemView ->
                itemView.findViewById(R.id.medium_thumbnail)

            },
            onUpdateSpan = { span ->
                mainActivity.appPref.mediaGrid = span
            },
            dimLayer = binding.dimLayer,
            minSpan = 2,
            maxSpan = 6
        )
        binding.rvAllMedia.setOnTouchListener(listener)
    }

    fun observableMedia() {
        lifecycleScope.launch {
            setMediaList(GallerySdkV2.get().getAllMediaList())
        }
    }

    private fun setMediaList(state: MediaDataState<List<MediaListItem>>) {
        when (sharedViewModel.getMainMediaFilter()) {
            MainMediaFilter.ALL -> binding.tvAlbumAll2.text = getString(R.string.all)
            MainMediaFilter.PHOTOS -> binding.tvAlbumAll2.text = getString(R.string.photos)
            MainMediaFilter.VIDEO -> binding.tvAlbumAll2.text = getString(R.string.videos)
            MainMediaFilter.GIF -> binding.tvAlbumAll2.text = getString(R.string.gifs)
        }
        binding.llLimitedAccess.beVisibleIf(PermissionSDK.hasLimitedPhotoAccess(mainActivity))
        when (state) {
            MediaDataState.Empty -> {
                binding.loutNoData.beVisible()
                binding.llLoader.beGone()
                setMedia(emptyList())
            }

            MediaDataState.Loading -> {
                binding.loutNoData.beGone()
                binding.llLoader.beVisible()
                binding.lavLoader.restart()
                setMedia(emptyList())
            }

            is MediaDataState.Success -> {
                binding.loutNoData.beGone()
                binding.llLoader.beGone()
                binding.lavLoader.cancelAnimation()
                setMedia(state.data)
            }

            is MediaDataState.Progress -> {}
        }
    }

    private fun setMedia(mediaList: List<MediaListItem>) {
        lifecycleScope.launch {
            binding.rvAllMedia.recycledViewPool.clear()
            Log.e("mediaList", "setMedia: ${mediaList.size}")
            binding.rvAllMedia.post {
                initAdaptor()
                binding.rvAllMedia.post {
                    getMediaListAdapter()?.submitList(ArrayList(mediaList))
                }
                val list = mediaList.map {
                    when (it) {
                        is MediaListItem.Header -> {
                            PreloadItem.Header()
                        }

                        is MediaListItem.Media -> {
                            PreloadItem.Media(it.mediaBox.mediaPath, it.mediaBox.mediaDate)
                        }
                    }
                }
                binding.rvAllMedia.setupGlidePreLoader(mainActivity, list, false)
            }
        }

    }

    @SuppressLint("SetTextI18n")
    fun updateSelections() {
        val allMediaAdaptor = getMediaListAdapter() ?: return
        val enableSelection = getMediaListAdapter()?.isSelectionActive() ?: false
        binding.clSelection.beVisibleIf(enableSelection)
        binding.albumToolbar.beVisibleIf(!enableSelection)
        binding.tvTitleSelection.text = "${allMediaAdaptor.getSelectedCount()} " + getString(R.string.selected)

        if (allMediaAdaptor.isSelectAll()) {
            binding.icSelectAll.setImageResource(R.drawable.vec_selected_bg)
        } else {
            binding.icSelectAll.setImageResource(R.drawable.vec_unselected_bg)
        }
        mainActivity.updatePhotoFragmentSelection()

    }

    fun disableSelection() {
        val allMediaAdaptor = getMediaListAdapter() ?: return
        allMediaAdaptor.clearSelectionAndExit()
        updateSelections()
    }

    fun resetMedia() {
        binding.rvAllMedia.adapter = null
        init()
    }


    private fun initAdaptor() {
        if (binding.rvAllMedia.adapter == null) {
            val albumAdaptor = MediaListAdapter(binding.rvAllMedia) {
                onMediaSelectSelect(it)
            }
            binding.rvAllMedia.adapter = albumAdaptor
            albumAdaptor.setSelectionUpdateCallback(
                object : SelectionUpdateCallback {
                    override fun onSelectionCountChanged(
                        selectedCount: Int,
                        selectionActive: Boolean
                    ) {
                        updateSelections()
                    }
                }
            )
        }
    }

    fun onMediaSelectSelect(mediaBox: MediaBox) {
        val allMediaAdaptor = getMediaListAdapter() ?: return
        val mediaPaths = allMediaAdaptor.getAllPaths()

        sharedViewModel.imageViewerList =
            ArrayList(mediaPaths)
        val startPosition = mediaPaths.indexOf(mediaBox.mediaPath)
        mainActivity.startActivity(
            Intent(mainActivity, NewImageViewerActivity::class.java).apply {
                putExtra("startPosition", startPosition)
            }
        )
    }

    fun getMediaListAdapter() = binding.rvAllMedia.adapter as? MediaListAdapter

    fun isSelectionActive() = getMediaListAdapter()?.isSelectionActive() ?: false

    fun getSelectedMedias() = getMediaListAdapter()?.getSelectedItems()?.filterIsInstance<MediaListItem.Media>()?.map { it.mediaModel } ?: emptyList()

    fun findPhotoPosition(filePath: String) {
        val pos = getMediaListAdapter()?.getIndex(filePath) ?: 0
        binding.rvAllMedia.scrollToPosition(pos)

        binding.rvAllMedia.post {
            val viewHolder = binding.rvAllMedia.findViewHolderForLayoutPosition(pos)
            if (viewHolder != null) {
                startZoomAnimation(viewHolder.itemView, .5f)
            }
        }
    }

    private fun startZoomAnimation(view: View, minScale: Float = 0.9f) {
        val scaleUpX = ObjectAnimator.ofFloat(view, "scaleX", 1f, minScale)
        val scaleUpY = ObjectAnimator.ofFloat(view, "scaleY", 1f, minScale)
        val scaleDownX = ObjectAnimator.ofFloat(view, "scaleX", minScale, 1f)
        val scaleDownY = ObjectAnimator.ofFloat(view, "scaleY", minScale, 1f)

        val scaleUpSet = AnimatorSet().apply {
            playTogether(scaleUpX, scaleUpY)
            duration = 300
            interpolator = LinearInterpolator()
        }

        val scaleDownSet = AnimatorSet().apply {
            playTogether(scaleDownX, scaleDownY)
            duration = 300
            interpolator = LinearInterpolator()
        }

        val animatorSet = AnimatorSet()
        animatorSet.playSequentially(scaleUpSet, scaleDownSet)

        animatorSet.doOnEnd { }
        animatorSet.start()
    }
}