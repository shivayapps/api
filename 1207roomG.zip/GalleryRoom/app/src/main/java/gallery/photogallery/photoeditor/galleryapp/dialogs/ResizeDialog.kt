package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Point
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogResizeBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import java.io.File

class ResizeDialog(
    var activity: BaseActivity,
    val mediaPath: String,
    val callback: (Int, Int, String, Boolean) -> Unit,
) : DialogFragment() {
    private var _binding: DialogResizeBinding? = null
    private val binding get() = _binding!!
    private var currentWidth = 0
    private var currentHeight = 0
    private var fileName = ""
    private lateinit var safeContext: Context

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogResizeBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
            setGravity(Gravity.CENTER)
        }
        intView()
        intListener()
        showKeyboard()
        return dialog
    }

    @SuppressLint("SetTextI18n")
    private fun intView() {
        val file = File(mediaPath)
        fileName = file.name.substring(0, file.name.lastIndexOf("."))
        binding.edtName.setText(fileName)
        val size = mediaPath.getImageResolution()
        binding.edtWidth.setText("${size.x}")
        binding.edtHeight.setText("${size.y}")
        currentWidth = size.x
        currentHeight = size.y
        val ratio: Float = currentWidth / currentHeight.toFloat()
        binding.edtWidth.requestFocus()
        binding.edtWidth.addTextChangedListener {
            if (binding.edtWidth.hasFocus()) {
                var width = getViewValue(binding.edtWidth, currentWidth)
                if (width > currentWidth) {
                    binding.edtWidth.setText(currentWidth.toString())
                    width = currentWidth
                }
                binding.edtHeight.setText((width / ratio).toInt().toString())
            }
        }

        binding.edtHeight.addTextChangedListener {
            if (binding.edtHeight.hasFocus()) {
                var height = getViewValue(binding.edtHeight, currentHeight)
                if (height > currentHeight) {
                    binding.edtHeight.setText(currentHeight.toString())
                    height = currentHeight
                }

                Log.e("ResizeTAG", "edtH addTextChanged width-> ${(height * ratio).toInt()}")
                binding.edtWidth.setText((height * ratio).toInt().toString())
            }
        }
    }

    private fun intListener() {
        binding.btnCancel.setOnClickListener {
            hideKeyboard()
            dismiss()
        }

        binding.icClear.setOnClickListener {
            binding.edtName.setText("")
        }

        binding.btnResize.setOnClickListener {
            val width = getViewValue(binding.edtWidth, currentWidth)
            val height = getViewValue(binding.edtHeight, currentHeight)
            if ((width <= 0 || height <= 0)) {
                Toast.makeText(activity, ContextCompat.getString(activity, R.string.validation_resolution), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val fileName = binding.edtName.text.toString().trim()
            if (fileName.isEmpty()) {
                Toast.makeText(activity, ContextCompat.getString(activity, R.string.please_enter_file_name), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            callback.invoke(width, height, fileName, binding.checkKeepOriginal.isChecked)
            hideKeyboard()
            dismiss()
        }
    }

    private fun showKeyboard() {
        binding.edtWidth.requestFocus()
        val methodManager = (activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(binding.edtWidth, InputMethodManager.SHOW_IMPLICIT)
    }

    fun hideKeyboard() {
//        currentFocus?.clearFocus()
        binding.btnResize.clearFocus()
        binding.edtName.clearFocus()
        binding.edtWidth.clearFocus()
        binding.edtHeight.clearFocus()
        val methodManager = (activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(binding.btnResize.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun getViewValue(view: EditText, defaultValue: Int): Int {
        try {
            val textValue = view.text.toString().trim()
            return if (textValue.isEmpty()) 0 else textValue.toInt()
        } catch (e: Exception) {
            e.printStackTrace()
            return defaultValue
        }
    }

    private fun String.getImageResolution(): Point {
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(this, options)

        val width = options.outWidth
        val height = options.outHeight
        return if (width > 0 && height > 0) {
            Point(options.outWidth, options.outHeight)
        } else {
            Point(0, 0)
        }
    }
}