package gallery.photogallery.photoeditor.galleryapp.collage.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.appblish.gallery.core.v2.api.model.MediaModel
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.R

class SelectedAdapter(
    private val onRemove: (MediaModel) -> Unit
) : RecyclerView.Adapter<SelectedAdapter.VH>() {

    private val list = mutableListOf<MediaModel>()

    fun submit(data: List<MediaModel>) {
        list.clear()
        list.addAll(data)
        notifyDataSetChanged()
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val img: ImageView = view.findViewById(R.id.ivSelected)
        val remove: ImageView = view.findViewById(R.id.ivRemove)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_selected, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val media = list[position]
        val entity = media.mediaBox

        Glide.with(holder.img.context)
            .load(entity.mediaPath)
            .centerCrop()
            .into(holder.img)

        holder.remove.setOnClickListener {
            onRemove(media)
        }
    }

    override fun getItemCount(): Int = list.size
}

