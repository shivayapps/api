package gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.lifecycle.lifecycleScope
import gallery.photogallery.photoeditor.galleryapp.permission.PermissionSDK
import gallery.photogallery.photoeditor.galleryapp.activities.SplashActivity
import gallery.photogallery.photoeditor.galleryapp.extentions.editPhoto
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import kotlinx.coroutines.launch

class OpenWithEditorActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch {
            val intent = intent
            val dataUri: Uri? = intent.data
            if (dataUri != null && appPref.isMoveToHome) {
                val list = sharedViewModel.getAllMediaPaths().toHashSet()
                val imagePathOriginal = getImagePathFromURI(dataUri, list)
                if (!imagePathOriginal.isNullOrEmpty()) {
                    if (PermissionSDK.isExternalStorageManager()) {
                        editPhoto(imagePathOriginal)
                    } else {
                        startActivity(Intent(this@OpenWithEditorActivity, WhatsAppImageViewerActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                            putExtra("filePath", imagePathOriginal)
                            putExtra("editPhoto", true)
                        })

                    }
                    finish()
                } else {
                    try {
                        val imagePath = getFilePathFromUri(this@OpenWithEditorActivity, dataUri)
                        if (imagePath != null) {
                            startActivity(Intent(this@OpenWithEditorActivity, WhatsAppImageViewerActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                putExtra("filePath", imagePath)
                                putExtra("editPhoto", true)
                            })
                            finish()
                        } else {
                            startActivity(Intent(this@OpenWithEditorActivity, SplashActivity::class.java))
                            finish()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        startActivity(Intent(this@OpenWithEditorActivity, SplashActivity::class.java))
                        finish()
                    }
                }


            } else {
                startActivity(Intent(this@OpenWithEditorActivity, SplashActivity::class.java))
                finish()
            }
        }
    }
}
