package gallery.photogallery.photoeditor.galleryapp.activities

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.inputmethod.InputMethodManager
import androidx.core.app.ActivityOptionsCompat
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.appblish.box.api.util.AppblishEvent.ALL_MEMORIES_LOADED
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivitySearchMemoryBinding
import gallery.photogallery.photoeditor.galleryapp.foryou.ForYouListItem
import gallery.photogallery.photoeditor.galleryapp.foryou.ThumbAdapterForYou
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory.MemoryViewerActivity
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class MemorySearchActivity : BaseActivity() {
    companion object {
        fun createIntent(context: Context): Intent {
            return Intent(context, MemorySearchActivity::class.java)
        }
    }

    private val binding by viewBinding(ActivitySearchMemoryBinding::inflate)

    private val searchMemoryAdapter by lazy {
        ThumbAdapterForYou(
            { memory, filterClick, view ->
                val options = ActivityOptionsCompat.makeSceneTransitionAnimation(
                    this, view, // The shared view
                    "image_transition" // The transition name
                )
                Intent(this, MemoryViewerActivity::class.java).apply {
                    putExtra("memoryId", memory.memoryId)
                    startActivity(this, options.toBundle())
                }
            },
            {},
        )
    }

    private val searchHandle = Handler(Looper.getMainLooper())
    private val searchRunnable = Runnable {
        search()
    }

    private var mediaJob: Job? = null

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.root.setPadding(0, 0, 0, navigationBarHeight)
        binding.mainContainer.setPadding(0, statusBarHeight, 0, 0)
        registerEventBus(this)
        showKeyboard()
        setListeners()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            ALL_MEMORIES_LOADED -> {
                search()
            }
        }
    }

    private fun setListeners() {
        binding.ivBack.setOnClickListener {
            onBackPressed()
        }
        binding.icSearchClear.setOnClickListener {
            binding.edtSearch.setText("")
        }
        binding.edtSearch.addTextChangedListener {
            binding.icSearchClear.beVisibleIf(binding.edtSearch.length() > 0)
            searchHandle.removeCallbacks(searchRunnable)
            searchHandle.postDelayed(searchRunnable, 500)
        }
    }

    private fun setPhotosData(pictures: List<ForYouListItem>) {
        binding.memoryRecycler.recycledViewPool.clear()
        val layoutManager = LinearLayoutManager(
            this,
            LinearLayoutManager.VERTICAL,
            false
        )

        binding.memoryRecycler.layoutManager = layoutManager
        binding.memoryRecycler.adapter = searchMemoryAdapter
        searchMemoryAdapter.submitList(pictures)

    }

    fun checkNoData() {
        if (binding.memoryRecycler.adapter?.itemCount == 0 && binding.edtSearch.text.isNotEmpty()) {
            binding.loutNoData.beVisible()
        } else {
            binding.loutNoData.beGone()
        }
    }

    private fun search() {
        performSearch(binding.edtSearch.text.toString().trim())
    }

    fun performSearch(queryRaw: String) {
        val query = queryRaw.trim()
        if (query.isEmpty()) {
            setPhotosData(emptyList())
            return
        }

        val queryLower = query.lowercase()

        mediaJob?.cancel()
        mediaJob = lifecycleScope.launch(Dispatchers.Default) {
            val list = sharedViewModel.searchMemories(queryLower).asSequence()
                .filter { it.title.contains(queryLower, ignoreCase = true) }
                .toList()

            val result: List<ForYouListItem> = list.map { ForYouListItem.Memory(it) }

            withContext(Dispatchers.Main.immediate) {
                setPhotosData(result)
                checkNoData()
            }
        }

    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        hideKeyboard()
        finish()
    }

    override fun onResume() {
        super.onResume()
        search()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterEventBus(this)
    }

    private fun showKeyboard() {
        binding.edtSearch.requestFocus()
        val methodManager = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(binding.edtSearch, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard() {
        binding.edtSearch.clearFocus()
        val methodManager = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(binding.edtSearch.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }
}