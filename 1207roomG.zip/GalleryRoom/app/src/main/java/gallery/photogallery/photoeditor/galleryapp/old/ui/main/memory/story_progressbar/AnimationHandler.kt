package gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory.story_progressbar

internal abstract class AnimationHandler(fromValue: Float, toValue: Float, durationInMillis: Long) {
    var listener: AnimationChangeListener? = null
    abstract fun cancel()
    abstract fun start()
}

internal fun interface AnimationChangeListener {
    fun onChange(value: Float)
}