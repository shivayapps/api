package gallery.photogallery.photoeditor.galleryapp.collage.utils

import android.graphics.Bitmap
import android.graphics.drawable.Drawable

sealed class PickerItem {
    data class Texture(
        val drawable: Drawable,
        val bitmap: Bitmap
    ) : PickerItem()
}
