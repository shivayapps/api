package gallery.photogallery.photoeditor.galleryapp.data.model

data class MemoriesMusicModel(
    val filePath: Int,
    val fileName: String,
    val duration: String,
    val fileSize: String,
    val fileRate: String,
    val imagePath: String,
    val isStatic: Boolean = true,
)