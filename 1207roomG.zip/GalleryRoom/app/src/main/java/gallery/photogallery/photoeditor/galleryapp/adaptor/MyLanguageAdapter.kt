package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.LanguageItemBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.getAppPrimaryColor
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.getStringForLocale
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import java.util.Locale

class MyLanguageAdapter(var context: Context) : RecyclerView.Adapter<MyLanguageAdapter.MyViewHolder>() {
    private val languages = context.resources.getStringArray(R.array.language_text)
    private val languageCodes = context.resources.getStringArray(R.array.language_code)
    private val languageTr = context.resources.getStringArray(R.array.language_tr)

    private var filteredLanguages = languages.toList()
    private var filteredLanguageCodes = languageCodes.toList()
    private var filteredLanguageTr = languageTr.toList()
    var selectedLanguage = ""


    init {
        selectedLanguage = context.preferences.selectedLanguage.ifEmpty { "default" }
    }

    fun getSelectedPosition(): Int {
        return languageCodes.indexOfFirst { it == selectedLanguage }
    }

    var clickListener: ((pos: Int) -> Unit)? = null
    fun setOnItemClickListener(listener: (pos: Int) -> Unit) {
        clickListener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = LanguageItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        with(holder) {
            with(binding) {
                val languageCode = filteredLanguageCodes[position]
                if (selectedLanguage == languageCode) {
                    llMain.setBackgroundResource(R.drawable.shape_lan_stroke_selected)
                } else {
                    llMain.setBackgroundResource(R.drawable.shape_lan_stroke_de_selected)
                }

                if (languageCode == "default") {
                    tvLanguage.text = context.getStringForLocale(R.string.txt_default, Locale(context.preferences.defaultLanguage))
                    tvLanguageTr.text = "(" + context.getStringForLocale(R.string.txt_system_default, Locale(context.preferences.defaultLanguage)) + ")"
                } else {
                    tvLanguage.text = filteredLanguages[position]
                    tvLanguageTr.text = "(" + filteredLanguageTr[position] + ")"
                }

                tvLanguage.setTextColor(ContextCompat.getColor(context, R.color.black))
//                ivFlag.setImageResource(filteredFlagRes[position])
                radio.isChecked = selectedLanguage == languageCode
                if (radio.isChecked) {
                    radio.buttonTintList = ColorStateList.valueOf(context.getAppPrimaryColor())
                } else {
                    radio.buttonTintList = ColorStateList.valueOf(Color.GRAY)
                }
                radio.setOnClickListener {
                    selectedLanguage(position)
                }
                itemView.setOnClickListener {
                    selectedLanguage(position)
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return filteredLanguages.size
    }


    private fun selectedLanguage(position: Int) {
        val lastIndex = filteredLanguageCodes.indexOf(selectedLanguage)
        selectedLanguage = filteredLanguageCodes[position]

        if (lastIndex != -1) {
            notifyItemChanged(lastIndex)
        }
        notifyItemChanged(position)
        clickListener?.invoke(position)
    }


    fun filterList(query: String) {
        filteredLanguages = if (query.isEmpty()) {
            languages.toList()
        } else {
            languages.filter { it.contains(query, ignoreCase = true) }
        }

        // AppblishCollageFilter other arrays to match the languages filter
        filteredLanguageCodes = filteredLanguages.map { language ->
            languageCodes[languages.indexOf(language)]
        }

        filteredLanguageTr = filteredLanguages.map { language ->
            languageTr[languages.indexOf(language)]
        }



        notifyDataSetChanged()

    }

    inner class MyViewHolder(val binding: LanguageItemBinding) : RecyclerView.ViewHolder(binding.root)
}