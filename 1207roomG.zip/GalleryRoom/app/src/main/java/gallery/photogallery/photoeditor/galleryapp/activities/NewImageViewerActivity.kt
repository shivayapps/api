package gallery.photogallery.photoeditor.galleryapp.activities

import android.animation.Animator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.GestureDetector
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.size
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import androidx.viewpager2.widget.ViewPager2
import com.airbnb.lottie.LottieCompositionFactory
import com.appblish.box.api.util.AppblishEvent
import com.appblish.medialoader.AppblishImageLoader.setupGlidePreLoader
import com.appblish.medialoader.PreloadItem
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.adaptor.FullImageAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityFullImageViewerBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.PopMenuViewerImageBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.ConfirmationDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.DeleteDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.PhotosDetailsDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.RenamePhotosDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.ResizeDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.editPhoto
import gallery.photogallery.photoeditor.galleryapp.extentions.showDeleteDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.custom.ActionImageView
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog.SlideShowDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.DONE_MEDIA_OPERATION
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.OperationEvent
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.REPLACE_MEDIA_OPERATION
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.getLensIntentForImageUri
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.getNameWithoutExtension
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isGif
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isImageFast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isPackageInstalled
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isPortrait
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isVideoFast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.setAs
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.setOnSingleClickListener
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.setOnSingleClickListenerOneSec
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.shareFilesList
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.tablayout.loge
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.PopupWindowHelper
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.SLIDESHOW_ANIMATION_NONE
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.SLIDESHOW_FADE_DURATION
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.isAboveAndroid11
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.BackgroundToForeground
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.CubeIn
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.CubeOut
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.DefaultPageTransformer
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.DepthSlide
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.FidgetSpinner
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.FlipHorizontal
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.FlipVertical
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.ForegroundToBackground
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.Gate
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.RotateDown
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.RotateUp
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.Toss
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.ZoomIn
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.ZoomOut
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.SetLockActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import kotlin.math.abs

class NewImageViewerActivity : BaseActivity() {
    private val binding by viewBinding(ActivityFullImageViewerBinding::inflate)
    var selectedMedias = ArrayList<String>()
    val LENS_PACKAGE = "com.google.ar.lens"
    val LENS_ACTIVITY = "com.google.vr.apps.ornament.app.lens.LensLauncherActivity"
    private val activityName by lazy { intent.getStringExtra("ACTIVITY_NAME") }

    internal val imageViewerList
        get() = sharedViewModel.imageViewerList

    internal val currentPath
        get() = imageViewerList[currentItem]

    internal val currentItem
        get() = binding.imagesPager.currentItem

    internal val isItemSelected
        get() = selectedMedias.contains(currentPath)

    private var isIdle = true
    var isLensInstalled = false
    var isShowToolbar = true

    private val hideUiHandler = Handler(Looper.getMainLooper())
    private val hideUiRunnable = Runnable {
        if (isShowToolbar) {
            hideToolbar()
        }
    }
    private lateinit var tapGestureDetector: GestureDetector

    private val isSelectionEnable: Boolean by lazy { getApp().intentMapData["isSelectionEnable"] as? Boolean ?: false }
    private val startPosition: Int by lazy { intent.getIntExtra("startPosition", 0) }
    private var canDismiss = true
    val fullImageAdapter by lazy {
        FullImageAdapter(this, preferences.allowZoomingImages) { isNotZoomed ->
            // Callback from adapter: true if not zoomed, false if zoomed
            canDismiss = isNotZoomed
            manageViewPager()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updatePaddingBasedOnOrientation()
    }

    private var allMediaHideResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            hideAllMediaFromMedia()
        }
    }

    private var mRandomSlideshowStopped = false
    var mSlideshowInterval = 3000
    private var mSlideshowMoveBackwards = false
    private var mIsSlideshowActive = false
    private var mSlideshowHandler = Handler()

    @SuppressLint("WrongConstant")
    override fun onCreate(savedInstanceState: Bundle?) {
        isPortrait = false
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        updatePaddingBasedOnOrientation()
        if (!EventBus.getDefault().isRegistered(this)) EventBus.getDefault().register(this)
        window.statusBarColor = ContextCompat.getColor(this, android.R.color.transparent)
        window.navigationBarColor = ContextCompat.getColor(this, R.color.dark_bg_color)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (isAboveAndroid11()) {
            controller.hide(WindowInsets.Type.navigationBars())
            controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = false

        initView()
        clickListener()
        initPager()
        setUpLensIcon()
        if (preferences.hideUIOnFullScreen) {
            scheduleAutoHide()
        }
        if (activityName == "ExplorePhotosActivity") {
            val slideshowDialog = SlideShowDialog(this@NewImageViewerActivity, updateListener = {
                startSlideShow()
            })
            slideshowDialog.show(supportFragmentManager, slideshowDialog.tag)
        }
    }

    private fun initPager() {
        binding.imagesPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)

                manageViewerFromActivity()
                setSelection()
                scheduleSwipe()
            }

            override fun onPageScrollStateChanged(state: Int) {
                super.onPageScrollStateChanged(state)
                isIdle = state == ViewPager.SCROLL_STATE_IDLE
            }
        })

    }

    private fun isTouchInsideView(view: View, event: MotionEvent): Boolean {
        val location = IntArray(2)
        view.getLocationOnScreen(location)

        val x = event.rawX.toInt()
        val y = event.rawY.toInt()

        return x >= location[0] && x <= location[0] + view.width && y >= location[1] && y <= location[1] + view.height
    }


    private fun clickListener() {
        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

        tapGestureDetector = GestureDetector(
            this, object : GestureDetector.SimpleOnGestureListener() {
                override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                    if (isTouchInsideView(binding.clToolbar, e) || isTouchInsideView(binding.llBottom, e) || isTouchInsideView(binding.btnLens, e)) {
                        return false   // Ignore tap
                    }

                    handleViewerTap()
                    return true
                }


                override fun onFling(
                    e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float,
                ): Boolean {
                    if (e1 == null || e2 == null) return false

                    val deltaY = e2.y - e1.y  // Positive: down swipe, Negative: up swipe
                    val deltaX = e2.x - e1.x
                    val absDeltaY = abs(deltaY)
                    val absDeltaX = abs(deltaX)

                    // Check for vertical down swipe: Y distance > X distance, deltaY > 0 (down), and meets increased thresholds
                    if (absDeltaY > absDeltaX && deltaY > 0 && absDeltaY > 200 && abs(velocityY) > 1000) {
                        if (canDismiss && preferences.allowDownGesture) {  // Only dismiss if not zoomed
                            dismissWithAnimation()
                            return true  // Consume the event
                        }
                    }
                    return false  // Let other gestures handle (e.g., PhotoView pan or ViewPager swipe)
                }
            })
    }

    private fun dismissWithAnimation() {/*  // Add fade-out animation before finishing
          val fadeOut = ObjectAnimator.ofFloat(binding.root, "alpha", 1f, 0f)
          fadeOut.duration = 0
          fadeOut.addListener(object : AnimatorListenerAdapter() {
              override fun onAnimationEnd(animation: Animator) {
                  onBackPressed()
              }
          })
          fadeOut.start()*/
        finish()
        overridePendingTransition(0, 0)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        tapGestureDetector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun manageViewPager() {
        binding.imagesPager.isUserInputEnabled = canDismiss
    }

    fun handleViewerTap() {
        if (activityName == "TrashActivity" || activityName == "PrivateTrashActivity" || activityName == "ExploreHiddenAlbumActivity") {
            return
        }
        if (preferences.hideUIOnFullScreen) {

            if (isShowToolbar) {
                // UI is visible → hide immediately on tap
                cancelAutoHide()
                hideToolbar()
            } else {
                // UI is hidden → show and auto-hide again
                showToolbar()
                scheduleAutoHide()
            }

        } else {
            toggleFullScreen()
        }
    }

    private fun updatePaddingBasedOnOrientation() {
        val orientation = resources.configuration.orientation
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Log.d("Orientation", "Landscape")
            if (!isAboveAndroid11()) {
                binding.root.setPadding(0, 0, navigationBarHeight, 0)
            }
            binding.clToolbar.setPadding(0, statusBarHeight, 0, 0)

        } else if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            Log.d("Orientation", "Portrait")
            if (!isAboveAndroid11()) {
                Log.d("Orientation", "Portrait 1")
                binding.root.setPadding(0, 0, 0, navigationBarHeight)
            }

            binding.clToolbar.setPadding(0, statusBarHeight, 0, 0)
        }
    }

    private fun showPhotoDropDown(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopMenuViewerImageBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)
        val selectedLanguage = appPref.getSelectedLang(this)
        if (selectedLanguage == "ar" || selectedLanguage == "ur" || selectedLanguage == "fa") {
            popupWindow.showAsPopUp2(view, mGravity = Gravity.START or Gravity.TOP)
        } else {
            popupWindow.showAsPopUp2(view, mGravity = Gravity.END or Gravity.TOP)
        }

        val imageUri = if (currentPath.isImageFast()) sharedViewModel.getFileURIFromPathString(currentPath) else ""
        popUpBinding.run {
            menuPrint.beGone()
            menuSetAs.beVisibleIf(currentPath.isImageFast())
            menuResize.beVisibleIf(currentPath.isImageFast())
            loutMain.setOnClickListener {
                popupWindow.dismiss()
                Log.e("btmSelectionView", "loutMain: ")
            }

            menuSetAs.setOnClickListener {
                popupWindow.dismiss()
                Log.e("btmSelectionView", "menuSetAs: ")
                setAs(currentPath)

            }


            menuResize.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        val renameFileDialog = ResizeDialog(this@NewImageViewerActivity, currentPath) { w, h, name, keepOriginal ->
                            showLoadingDialog()
                            val index = imageViewerList.indexOf(currentPath)
                            sharedViewModel.resizeMedia(currentPath, w, h, name, keepOriginal) { b, path ->
                                hideLoadingDialog()
                                if (it) {
                                    sharedViewModel.fetchMedia()
                                    runOnUiThread {
                                        imageViewerList[index] = path
                                        fullImageAdapter.notifyItemChanged(index)
                                        if (imageViewerList.isNotEmpty()) {
                                            binding.tvImageName.text = File(path).getNameWithoutExtension()
                                        } else {
                                            onBackPressed()
                                        }
                                    }

                                }
                            }
                        }
                        renameFileDialog.show(supportFragmentManager, "ResizeDialog")
                    }
                }
            }

            menuRename.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        val renameFileDialog = RenamePhotosDialog(this@NewImageViewerActivity)
                        renameFileDialog.filePath = currentPath
                        renameFileDialog.positiveBtnClickListener = { renamedFile, oldFile ->
                            val index = imageViewerList.indexOf(currentPath)
                            showLoadingDialog()
                            sharedViewModel.renameMedia(oldFile.absolutePath, renamedFile.name) {
                                hideLoadingDialog()
                                if (it) {
                                    sharedViewModel.fetchMedia()
                                    runOnUiThread {
                                        imageViewerList[index] = renamedFile.path
                                        if (imageViewerList.isNotEmpty()) {
                                            binding.tvImageName.text = renamedFile.getNameWithoutExtension()
                                        } else {
                                            onBackPressed()
                                        }
                                    }
                                }
                            }
                        }
                        renameFileDialog.show(supportFragmentManager, "RenamePhotosDialog")
                    }
                }

            }

            menuOpenWith.setOnClickListener {
                popupWindow.dismiss()
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(imageUri.toUri(), "image/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                if (currentPath.isVideoFast()) {
                    intent.setDataAndType(imageUri.toUri(), "video/*")
                }
                val chooser = Intent.createChooser(intent, "Open with")
                startActivity(chooser)
            }

            menuSlideShow.setOnClickListener {
                Log.e("btmSelectionView", "slideShow: ")
                popupWindow.dismiss()
                val slideshowDialog = SlideShowDialog(this@NewImageViewerActivity, updateListener = {
                    startSlideShow()
                })
                slideshowDialog.show(supportFragmentManager, slideshowDialog.tag)
            }

            menuCopy.setOnClickListener {
                popupWindow.dismiss()
                Log.e("btmSelectionView", "menuCopy: ")
                checkStoragePermission {
                    if (it) {
                        requestAlbumPicker(emptyArray()) {
                            if (it.isNotEmpty()) {
                                copyFolderFiles(listOf(currentPath), it)
                            }
                        }
                    }
                }
            }

            menuMove.setOnClickListener {
                popupWindow.dismiss()
                Log.e("btmSelectionView", "menuMove: ")
                checkStoragePermission {
                    if (it) {
                        requestAlbumPicker(emptyArray()) {
                            if (it.isNotEmpty()) {
                                moveFolderFiles(listOf(currentPath), it) {
                                    imageViewerList.remove(currentPath)
                                    if (imageViewerList.isNotEmpty()) {
                                        binding.imagesPager.adapter?.notifyDataSetChanged()
                                        setupPreLoader()
                                    } else {
                                        onBackPressed()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    }

    private fun manageViewerFromActivity() {
        val file = File(currentPath)
        binding.tvImageName.text = file.getNameWithoutExtension()
        if (currentPath.isImageFast()) {
            binding.btmSelectionImageView.enableEdit(true)
        } else {
            binding.btmSelectionImageView.enableEdit(false)
        }

        if (activityName == "TrashActivity" || activityName == "PrivateTrashActivity" || activityName == "ExploreHiddenAlbumActivity") {
            binding.ivFav.beGone()
            binding.ivRotate.beGone()
            binding.btnLens.beGone()
            binding.llBottom.beGone()
            binding.btmSelectionView.beVisible()
        } else {
            binding.ivFav.beVisible()
            binding.ivRotate.beVisibleIf(currentPath.isImageFast())
            binding.btnLens.beVisible()
            binding.llBottom.beVisible()
            binding.btmSelectionView.beGone()

            val isFav2 = sharedViewModel.isFavourite(currentPath)
            if (isFav2) {
                binding.ivFav.setImageResource(R.drawable.vec_favorite_fill)
            } else {
                binding.ivFav.setImageResource(R.drawable.vec_favorite_un_fill)
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun initView() {
        if (imageViewerList.isEmpty()) {
            finish()
            return
        }


        binding.imagesPager.adapter = fullImageAdapter
        fullImageAdapter.submitList(imageViewerList)
        binding.imagesPager.offscreenPageLimit = 2
        binding.imagesPager.setCurrentItem(startPosition, false)
        binding.imagesPager.transitionName = currentPath
        manageViewerFromActivity()
        binding.ivSelect.setOnClickListener {
            selectedMedias.remove(currentPath)
            if (isItemSelected) {
                binding.ivSelect.beVisible()
                binding.ivUnSelect.beGone()
            } else {
                binding.ivSelect.beGone()
                binding.ivUnSelect.beVisible()
            }
            binding.tvImageName.text = selectedMedias.size.toString() + " " + resources.getString(R.string.selected)
        }

        binding.ivUnSelect.setOnClickListener {
            selectedMedias.add(currentPath)
            if (isItemSelected) {
                binding.ivSelect.beVisible()
                binding.ivUnSelect.beGone()
            } else {
                binding.ivSelect.beGone()
                binding.ivUnSelect.beVisible()
            }
            binding.tvImageName.text = selectedMedias.size.toString() + " " + resources.getString(R.string.selected)

        }

        binding.btmSelectionImageView.callBack = {
            when (it) {
                ActionImageView.EDIT -> {
                    editPhoto(currentPath)

                }

                ActionImageView.SHARE -> {

                    val uri = FileProvider.getUriForFile(
                        this, "$packageName.provider", File(currentPath)
                    )
                    shareFilesList(this, listOf(uri))
                }

                ActionImageView.DELETE -> {
                    checkStoragePermission {
                        if (it) {
                            deleteMedia(listOf(currentPath)) {
                                imageViewerList.remove(currentPath)
                                if (imageViewerList.isNotEmpty()) {
                                    binding.imagesPager.adapter?.notifyDataSetChanged()
                                } else {
                                    onBackPressed()
                                }
                            }
                        }
                    }

                }

                ActionImageView.HIDE -> {
                    checkStoragePermission {
                        if (it) {
                            if (preferences.getSetPass()) {
                                hideAllMediaFromMedia()
                            } else {
                                val intent = Intent(this, SetLockActivity::class.java)
                                intent.putExtra("setResultCode", 101)
                                allMediaHideResult.launch(intent)
                            }
                        }
                    }

                }

                ActionImageView.MORE -> {
                    showPhotoDropDown(binding.llBottom)
                }

                else -> {}
            }
        }

        setSelection()
        binding.ivFav.setOnSingleClickListener {
            lifecycleScope.launch {
                if (activityName == "TrashActivity" || activityName == "PrivateTrashActivity" || activityName == "ExploreHiddenAlbumActivity") {

                } else {
                    val isFav = sharedViewModel.isFavourite(currentPath)
                    if (isFav) {
                        binding.ivFav.setImageResource(R.drawable.vec_favorite_un_fill)
                        binding.ivFav.isEnabled = true
                        sharedViewModel.removeToFav(listOf(currentPath))
                    } else {
                        binding.ivFav.isEnabled = false
                        sharedViewModel.addToFav(listOf(currentPath))
                        val lottieAnimationView = binding.ivFav
                        LottieCompositionFactory.fromAsset(this@NewImageViewerActivity, "favorite.json").addListener { composition ->
                            if (composition != null) {
                                lottieAnimationView.setComposition(composition)
                                lottieAnimationView.playAnimation()
                                lottieAnimationView.addAnimatorListener(object : Animator.AnimatorListener {
                                    override fun onAnimationStart(animation: Animator) {
                                    }

                                    override fun onAnimationEnd(animation: Animator) {
                                        binding.ivFav.setImageResource(R.drawable.vec_favorite_fill)
                                    }

                                    override fun onAnimationCancel(animation: Animator) {
                                    }

                                    override fun onAnimationRepeat(animation: Animator) {
                                    }
                                })
                            }
                        }
                        delay(500)
                        binding.ivFav.isEnabled = true
                    }
                }

            }
        }

        binding.ivInfo.setOnClickListener {
            PhotosDetailsDialog(listOf(currentPath)).show(supportFragmentManager, "PhotosDetailsDialog")
        }

        binding.ivRotate.setOnSingleClickListenerOneSec {
            checkStoragePermission {
                if (it) {
                    val position = binding.imagesPager.currentItem
                    val recyclerView = binding.imagesPager.getChildAt(0) as RecyclerView
                    fullImageAdapter.rotateItem(position, recyclerView) {
                        sharedViewModel.rotateMedia(currentPath, it) {
                            sharedViewModel.fetchMedia()
                            runOnUiThread {
                                fullImageAdapter.afterRotate(position, recyclerView)
                            }
                        }
                    }
                }
            }
        }


        binding.btnLens.setOnClickListener {
            try {
                val uri = FileProvider.getUriForFile(
                    this, "${packageName}.provider", File(currentPath)
                )
                startActivity(getLensIntentForImageUri(uri))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        binding.imagesPager.post {
            setupPreLoader()
        }


        binding.btnRestore.setOnClickListener {
            val selectedFile = File(currentPath)

            showDeleteDialog(
                title = getString(R.string.restore_msg), positiveRes = R.string.yes, onDeleteClick = {
                    val isPrivateRecycleBin = activityName == "PrivateTrashActivity"
                    if (isPrivateRecycleBin) {
                        restoreFromPrivateRecycleBin(listOf(selectedFile)) {
                            imageViewerList.remove(currentPath)
                            if (imageViewerList.isNotEmpty()) {
                                binding.imagesPager.adapter?.notifyDataSetChanged()
                            } else {
                                onBackPressed()
                            }
                        }
                    } else {
                        val isRecycleBin = activityName == "TrashActivity"
                        restoreMedia(listOf(selectedFile), !isRecycleBin) {
                            imageViewerList.remove(currentPath)
                            if (imageViewerList.isNotEmpty()) {
                                binding.imagesPager.adapter?.notifyDataSetChanged()
                            } else {
                                onBackPressed()
                            }
                        }
                    }
                })
        }

        binding.btnDelete.setOnClickListener {
//            val selectedFile = File(currentPath)
            if (activityName == "TrashActivity" || activityName == "PrivateTrashActivity") {
                showDeleteDialog(
                    title = getString(R.string.delete_permanently),
                    subTitle = getString(R.string.permanently_delete_msg),
                    positiveRes = R.string.delete,
                    onDeleteClick = {
                        deletePermanentFolderFiles(listOf(currentPath)) {
                            imageViewerList.remove(currentPath)
                            if (imageViewerList.isNotEmpty()) {
                                binding.imagesPager.adapter?.notifyDataSetChanged()
                            } else {
                                onBackPressed()
                            }
                        }

                    })

            } else {
                val deleteDialog = DeleteDialog.newInstance(btnClickListener = { isPermanent ->
                    if (isPermanent) {
                        deletePermanentFolderFiles(listOf(currentPath)) {
                            imageViewerList.remove(currentPath)
                            if (imageViewerList.isNotEmpty()) {
                                binding.imagesPager.adapter?.notifyDataSetChanged()
                            } else {
                                onBackPressed()
                            }
                        }
                    } else {
                        deleteFromPrivate(listOf(currentPath)) {
                            imageViewerList.remove(currentPath)
                            if (imageViewerList.isNotEmpty()) {
                                binding.imagesPager.adapter?.notifyDataSetChanged()
                            } else {
                                onBackPressed()
                            }
                        }
                    }
                })
                deleteDialog.show(supportFragmentManager, "DeleteDialog")

            }

        }
        if (activityName == "ExploreHiddenAlbumActivity") {
            binding.tvRestore.text = getString(R.string.unhide)
        } else {
            binding.tvRestore.text = getString(R.string.restore)
        }

    }

    private fun hideAllMediaFromMedia() {
        val dialog = ConfirmationDialog(
            this,
            ContextCompat.getString(this, R.string.hide),
            ContextCompat.getString(this, R.string.confirmation_hide_item),
            ContextCompat.getString(this, R.string.no),
            ContextCompat.getString(this, R.string.yes),
            ContextCompat.getColor(this, R.color.white_color)
        ) {
            hideMediaFolder(listOf(currentPath)) {
                imageViewerList.remove(currentPath)
                if (imageViewerList.isNotEmpty()) {
                    binding.imagesPager.adapter?.notifyDataSetChanged()
                } else {
                    onBackPressed()
                }
            }
        }
        dialog.show(supportFragmentManager, "ConfirmationDialog")

    }

    private fun scheduleAutoHide() {
        hideUiHandler.removeCallbacks(hideUiRunnable)
        hideUiHandler.postDelayed(hideUiRunnable, 1000L)
    }

    private fun cancelAutoHide() {
        hideUiHandler.removeCallbacks(hideUiRunnable)
    }

    fun toggleFullScreen() {
        if (isShowToolbar) {
            hideToolbar()
        } else {
            showToolbar()
        }
        stopSlideshow()
    }

    private fun startSlideShow() {
        hideToolbar()
        if (!isDestroyed) {
            val effect = appPref.getInt(Constant.PREF_SLIDE_EFFECT)

            if (appPref.getInt(Constant.PREF_SLIDE_EFFECT) != SLIDESHOW_ANIMATION_NONE) {
                setSlideAnimation(effect)
            }

            mRandomSlideshowStopped = false
            mSlideshowInterval = appPref.getInt(Constant.PREF_SLIDE_TIME, 1)
            mSlideshowMoveBackwards = appPref.getBoolean(Constant.PREF_SLIDE_BACKWARD)
            mIsSlideshowActive = true
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            scheduleSwipe()
        }

    }

    private fun scheduleSwipe() {
        mSlideshowHandler.removeCallbacksAndMessages(null)
        Log.d("PhotoVideoActivity", "scheduleSwipe : $mIsSlideshowActive $mSlideshowInterval")
        if (mIsSlideshowActive && !isDestroyed) {
            if (currentPath.isImageFast() || currentPath.isGif() || currentPath.isPortrait()) {
                mSlideshowHandler.postDelayed({
                    if (mIsSlideshowActive && !isDestroyed) {
                        swipeToNextMedium()
                    }
                }, mSlideshowInterval * 1000L)
            }
        }
    }

    private fun setSlideAnimation(animationType: Int) {
        when (animationType) {
            Constant.AnimationTypes.NONE.id -> {
                binding.imagesPager.setPageTransformer(ZoomIn())
                binding.imagesPager.setPageTransformer(ZoomIn())
            }

            Constant.AnimationTypes.ZOOM_IN.id -> {
                binding.imagesPager.setPageTransformer(ZoomIn())
            }

            Constant.AnimationTypes.ZOOM_OUT.id -> {
                binding.imagesPager.setPageTransformer(ZoomOut())
            }

            Constant.AnimationTypes.DEPTH_SLIDE.id -> {
                binding.imagesPager.setPageTransformer(DepthSlide())
            }

            Constant.AnimationTypes.CUBE_IN.id -> {
                binding.imagesPager.setPageTransformer(CubeIn())
            }

            Constant.AnimationTypes.CUBE_OUT.id -> {
                binding.imagesPager.setPageTransformer(CubeOut())
            }

            Constant.AnimationTypes.FLIP_HORIZONTAL.id -> {
                binding.imagesPager.setPageTransformer(FlipHorizontal())
            }

            Constant.AnimationTypes.FLIP_VERTICAL.id -> {
                binding.imagesPager.setPageTransformer(FlipVertical())
            }

            Constant.AnimationTypes.ROTATE_UP.id -> {
                binding.imagesPager.setPageTransformer(RotateUp())
            }

            Constant.AnimationTypes.ROTATE_DOWN.id -> {
                binding.imagesPager.setPageTransformer(RotateDown())
            }

            Constant.AnimationTypes.FOREGROUND_TO_BACKGROUND.id -> {
                binding.imagesPager.setPageTransformer(ForegroundToBackground())
            }

            Constant.AnimationTypes.BACKGROUND_TO_FOREGROUND.id -> {
                binding.imagesPager.setPageTransformer(BackgroundToForeground())
            }

            Constant.AnimationTypes.TOSS.id -> {
                binding.imagesPager.setPageTransformer(Toss())
            }

            Constant.AnimationTypes.GATE.id -> {
                binding.imagesPager.setPageTransformer(Gate())
            }

            else -> {
                binding.imagesPager.setPageTransformer(FidgetSpinner())
            }
        }
    }

    private fun goToNextMedium(forward: Boolean) {
        Log.d("PhotoVideoActivity", "goToNextMedium : $forward")
        val oldPosition = binding.imagesPager.currentItem
        val newPosition = if (mRandomSlideshowStopped) imageViewerList.indexOf(imageViewerList.random()) else if (forward) oldPosition + 1 else oldPosition - 1
        if (newPosition == -1 || newPosition > (binding.imagesPager.adapter?.itemCount ?: -1) - 1) {
            slideshowEnded(forward)
        } else {
            binding.imagesPager.setCurrentItem(newPosition, false)
        }
    }

    private fun swipeToNextMedium() {
        if (appPref.getInt(Constant.PREF_SLIDE_EFFECT) == SLIDESHOW_ANIMATION_NONE) {
            goToNextMedium(!mSlideshowMoveBackwards)
        } else {
            animatePagerTransition(!mSlideshowMoveBackwards)
        }
    }

    private fun slideshowEnded(forward: Boolean) {
        if (appPref.getBoolean(Constant.PREF_SLIDE_LOOP)) {
            if (forward) {
                binding.imagesPager.setCurrentItem(0, false)
            } else {
                binding.imagesPager.setCurrentItem(binding.imagesPager.size - 1, false)
            }
        } else {
            stopSlideshow()
        }
    }

    private fun stopSlideshow() {
        if (mIsSlideshowActive) {
            binding.imagesPager.setPageTransformer(DefaultPageTransformer())
            mIsSlideshowActive = false
            mRandomSlideshowStopped = false
            mSlideshowHandler.removeCallbacksAndMessages(null)
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

            if (appPref.getBoolean(Constant.PREF_SLIDE_RANDOM_ORDER)) {
                mRandomSlideshowStopped = true
            }
        }
    }

    private fun animatePagerTransition(forward: Boolean) {
        Log.d("PhotoVideoActivity", "animatePagerTransition : animatePagerTransition")
        val oldPosition = binding.imagesPager.currentItem
        val animator = ValueAnimator.ofInt(0, binding.imagesPager.width)
        animator.addListener(object : Animator.AnimatorListener {
            override fun onAnimationEnd(animation: Animator) {
                if (binding.imagesPager.isFakeDragging) {
                    try {
                        binding.imagesPager.endFakeDrag()
                    } catch (ignored: Exception) {
                        stopSlideshow()
                    }

                    if (binding.imagesPager.currentItem == oldPosition) {
                        slideshowEnded(forward)
                    }
                }
            }

            override fun onAnimationCancel(animation: Animator) {
                binding.imagesPager.endFakeDrag()
            }

            override fun onAnimationStart(animation: Animator) {}

            override fun onAnimationRepeat(animation: Animator) {}
        })

        animator.duration = SLIDESHOW_FADE_DURATION

        animator.addUpdateListener(object : ValueAnimator.AnimatorUpdateListener {
            var oldDragPosition = 0
            override fun onAnimationUpdate(animation: ValueAnimator) {
                if (binding.imagesPager.isFakeDragging) {
                    val dragPosition = animation.animatedValue as Int
                    val dragOffset = dragPosition - oldDragPosition
                    oldDragPosition = dragPosition
                    try {
                        binding.imagesPager.fakeDragBy(dragOffset * (if (forward) -1f else 1f))
                    } catch (e: Exception) {
                        stopSlideshow()
                    }
                }
            }
        })

        binding.imagesPager.beginFakeDrag()
        animator.start()
    }

    private fun hideToolbar() {
        isShowToolbar = false
        binding.clToolbar.animate().setDuration(100).setInterpolator(AccelerateDecelerateInterpolator())
            .translationY(-binding.clToolbar.height.toFloat())

        binding.llBottom.animate().setDuration(100).setInterpolator(AccelerateDecelerateInterpolator())
            .translationY(binding.llBottom.height.toFloat())
        binding.btnLens.animate().setDuration(100).setInterpolator(AccelerateDecelerateInterpolator())
            .translationY(binding.btnLens.height.toFloat() + resources.getDimension(com.intuit.sdp.R.dimen._50sdp) + binding.llBottom.height.toFloat())
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.statusBars())
        }
    }

    private fun showToolbar() {
        isShowToolbar = true
        binding.clToolbar.beVisible()
        binding.clToolbar.animate().setInterpolator(AccelerateDecelerateInterpolator()).translationY(0f)

        binding.llBottom.beVisible()
        binding.llBottom.animate().setInterpolator(AccelerateDecelerateInterpolator()).translationY(0f)

        binding.btnLens.beVisibleIf(isLensInstalled)
        if (isLensInstalled) {
            binding.btnLens.animate().setInterpolator(AccelerateDecelerateInterpolator()).translationY(0f)
        }
        WindowInsetsControllerCompat(
            window, window.decorView
        ).show(WindowInsetsCompat.Type.statusBars())
    }


    private fun setUpLensIcon() {
        val lensIntent = Intent.makeMainActivity(ComponentName(LENS_PACKAGE, LENS_ACTIVITY))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        if (packageManager.resolveActivity(lensIntent, 0) == null) return
        isLensInstalled = isPackageInstalled(LENS_PACKAGE)
    }

    @SuppressLint("SetTextI18n")
    fun setSelection() {/* if (isSelectionEnable) {
             binding.ivFav.beGone()
             if (isItemSelected) {
                 binding.ivSelect.beVisible()
                 binding.ivUnSelect.beGone()
             } else {
                 binding.ivSelect.beGone()
                 binding.ivUnSelect.beVisible()
             }
             binding.tvImageName.text =
                 selectedMedias.size.toString() + " " + resources.getString(R.string.selected)
         } else {
             binding.ivFav.beVisible()
             binding.ivSelect.beGone()
             binding.ivUnSelect.beGone()
         }*/
    }

    override fun onDestroy() {
        super.onDestroy()
        if (EventBus.getDefault().isRegistered(this)) EventBus.getDefault().unregister(this)
        hideUiHandler.removeCallbacksAndMessages(null)
//        sharedViewModel.imageViewerList.clear()
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            AppblishEvent.ALL_MEDIA_LOADED -> {
//                fullImageAdapter.notifyDataSetChanged()
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: OperationEvent) {
        Log.e("TAG", "onMessageEvent: ${event.type}")
        when (event.type) {
            DONE_MEDIA_OPERATION -> {/* if (event.data != "copy" && event.data != "edit") {
                     try {
                         val recyclerView = binding.imagesPager.getChildAt(0) as RecyclerView
                         recyclerView.recycledViewPool.clear()
                         recyclerView.stopScroll()
                     } catch (e: Exception) {
                         e.printStackTrace()
                     }
                     (imagesModelList as ArrayList<ObjectMediaModel>).removeAt(currentItem)
                     imagesAdapter?.updateMedia(ArrayList(imagesModelList))
                     if (imagesAdapter?.count == 0) {
                         finish()
                     }

                 }*/
            }

            REPLACE_MEDIA_OPERATION -> {
                if (event.data == currentPath) {
                    finish()
                }

            }

        }
    }

    private fun setupPreLoader() {
        lifecycleScope.launch {
            try {
                val list = withContext(Dispatchers.IO) {
                    imageViewerList.map { PreloadItem.Media(it, File(it).lastModified()) }
                }
                (binding.imagesPager.getChildAt(0) as? RecyclerView)?.setupGlidePreLoader(this@NewImageViewerActivity, list, true)
            } catch (e: Exception) {
                "setupPreLoader---->: ${e.message}".loge()
            }
        }
    }

    override fun onBackPressed() {
        if (isTaskRoot) {
            moveToHome()
        } else {
            super.onBackPressed()
        }
    }
}