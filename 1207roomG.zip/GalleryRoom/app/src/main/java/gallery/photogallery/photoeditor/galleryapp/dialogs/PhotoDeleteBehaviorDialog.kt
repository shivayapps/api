package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogPhotoDeleteBehaviorBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant

class PhotoDeleteBehaviorDialog : DialogFragment() {
    private var _binding: DialogPhotoDeleteBehaviorBinding? = null
    private val binding get() = _binding!!

    var behaviorListener: ((selected: Int) -> Unit)? = null

    private val selected: Int by lazy {
        arguments?.getInt("selected", Constant.DELETE_BEHAVIOR_ALWAYS_ASK)
            ?: Constant.DELETE_BEHAVIOR_ALWAYS_ASK
    }
    private var currentSelected: Int = Constant.DELETE_BEHAVIOR_ALWAYS_ASK


    companion object {
        fun show(
            fragmentManager: FragmentManager,
            selected: Int = Constant.DELETE_BEHAVIOR_ALWAYS_ASK,
            themeListener: (selected: Int) -> Unit,
        ) {
            val themeDialog = PhotoDeleteBehaviorDialog()
            themeDialog.behaviorListener = themeListener
            themeDialog.arguments = Bundle().apply {
                putInt("selected", selected)
            }
            themeDialog.show(fragmentManager, "themeModeDialog")
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogPhotoDeleteBehaviorBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(R.color.transparent)
            setLayout(requireContext().getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }
        intView()
        clickListener()
        return dialog
    }

    private fun intView() {
        currentSelected = selected

        when (selected) {
            Constant.DELETE_BEHAVIOR_ADD_TO_RECYCLE_BIN -> binding.rbAddToRecycle.isChecked = true
            Constant.DELETE_BEHAVIOR_PRESENTLY_DELETE -> binding.rbPresentlyDelete.isChecked = true
            Constant.DELETE_BEHAVIOR_ALWAYS_ASK -> binding.rbAlwaysAsk.isChecked = true
        }
    }

    private fun clickListener() {
        binding.grpOption.setOnCheckedChangeListener { _, checkedId ->
            currentSelected = when (checkedId) {
                binding.rbAddToRecycle.id -> Constant.DELETE_BEHAVIOR_ADD_TO_RECYCLE_BIN
                binding.rbPresentlyDelete.id -> Constant.DELETE_BEHAVIOR_PRESENTLY_DELETE
                binding.rbAlwaysAsk.id -> Constant.DELETE_BEHAVIOR_ALWAYS_ASK
                else -> return@setOnCheckedChangeListener
            }

            behaviorListener?.invoke(currentSelected)
            dismiss()
        }
    }
}