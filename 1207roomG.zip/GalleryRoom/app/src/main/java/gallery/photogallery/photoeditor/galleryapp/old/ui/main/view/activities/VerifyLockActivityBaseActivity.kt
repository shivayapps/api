package gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.widget.AppCompatImageView
import androidx.biometric.BiometricManager
import androidx.core.content.ContextCompat
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.HiddenAlbumActivity
import gallery.photogallery.photoeditor.galleryapp.bottomSheet.SecurityQuestionDialog
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivitySetLockBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isSupportWithErrorInfo
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.showBiometricPrompt
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Preferences
class VerifyLockActivityBaseActivity : BaseActivity(), View.OnClickListener {
    private val binding by viewBinding(ActivitySetLockBinding::inflate)

    val preferences: Preferences by lazy { Preferences(this) }
    private lateinit var strPass: StringBuilder
    private var pin = ""
    lateinit var animation: Animation

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        binding.main.setPadding(0, statusBarHeight, 0, navigationBarHeight)
        initValues()
        initClick()
    }

    private fun initValues() {
        strPass = StringBuilder()
        animation = AnimationUtils.loadAnimation(this, R.anim.anim_shake)

        pin = preferences.getPass().toString()

        binding.tvTitle.text = ContextCompat.getString(this, R.string.enter_your_PIN)
        binding.forgot.beVisible()
    }

    private fun initClick() {
        binding.btnNo0.setOnClickListener(this)
        binding.btnNo1.setOnClickListener(this)
        binding.btnNo2.setOnClickListener(this)
        binding.btnNo3.setOnClickListener(this)
        binding.btnNo4.setOnClickListener(this)
        binding.btnNo5.setOnClickListener(this)
        binding.btnNo6.setOnClickListener(this)
        binding.btnNo7.setOnClickListener(this)
        binding.btnNo8.setOnClickListener(this)
        binding.btnNo9.setOnClickListener(this)
        binding.btnClear.setOnClickListener(this)
        binding.forgot.setOnClickListener(this)
        binding.ivBack.setOnClickListener(this)

        val isFingerprintAvailable = isSupportWithErrorInfo(this, BiometricManager.Authenticators.BIOMETRIC_STRONG)
        if (preferences.enableFingerprint && isFingerprintAvailable.first) {
            Handler(Looper.getMainLooper()).postDelayed({
                startAndroidxBiometricManager()
            }, 700)
        }
    }

    private fun startAndroidxBiometricManager() {

        showBiometricPrompt(successCallback = { icSuccess ->
            if (icSuccess) {
                setPasswordSuccess()
            }
        }, failureCallback = { icFailed: Boolean, errorCode: Int, errString: CharSequence ->
            Log.e("BiometricManager", "\nicFailed:$icFailed,\nerrorCode:$errorCode,errString:$errString")
            Toast.makeText(this, getString(R.string.authentication_failed), Toast.LENGTH_SHORT).show()
        })

    }

    private fun setPasswordSuccess() {
        strPass.append(pin)
        checkPin()
    }

    override fun onClick(v: View?) {
        when (v) {
            binding.btnNo0 -> {
                strPass.append("0")
                checkPin()
            }

            binding.btnNo1 -> {
                strPass.append("1")
                checkPin()
            }

            binding.btnNo2 -> {
                strPass.append("2")
                checkPin()
            }

            binding.btnNo3 -> {
                strPass.append("3")
                checkPin()
            }

            binding.btnNo4 -> {
                strPass.append("4")
                checkPin()
            }

            binding.btnNo5 -> {
                strPass.append("5")
                checkPin()
            }

            binding.btnNo6 -> {
                strPass.append("6")
                checkPin()
            }

            binding.btnNo7 -> {
                strPass.append("7")
                checkPin()
            }

            binding.btnNo8 -> {
                strPass.append("8")
                checkPin()
            }

            binding.btnNo9 -> {
                strPass.append("9")
                checkPin()
            }

            binding.btnClear -> {
                if (strPass.isNotEmpty()) strPass.deleteCharAt(strPass.length - 1)
                checkPin()
            }

            binding.forgot -> {
                setQuestion()
            }

            binding.ivBack -> {
                finish()
            }
        }
    }


    private fun checkPin() {
        when (strPass.length) {
            0 -> {
                unSelectDot(binding.p1)
                unSelectDot(binding.p2)
                unSelectDot(binding.p3)
                unSelectDot(binding.p4)
            }

            1 -> {
                selectDot(binding.p1)
                unSelectDot(binding.p2)
                unSelectDot(binding.p3)
                unSelectDot(binding.p4)
            }

            2 -> {
                selectDot(binding.p1)
                selectDot(binding.p2)
                unSelectDot(binding.p3)
                unSelectDot(binding.p4)
            }

            3 -> {
                selectDot(binding.p1)
                selectDot(binding.p2)
                selectDot(binding.p3)
                unSelectDot(binding.p4)
            }

            4 -> {
                selectDot(binding.p1)
                selectDot(binding.p2)
                selectDot(binding.p3)
                selectDot(binding.p4)

                if (pin == strPass.toString()) {
                    startActivity(Intent(this, HiddenAlbumActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(
                        this,
                        R.string.wrong_pin,
                        Toast.LENGTH_SHORT
                    ).show()
                    strPass.clear()
                    setErrorAnimation(binding.loutPinDots)
                    unSelectDot(binding.p1)
                    unSelectDot(binding.p2)
                    unSelectDot(binding.p3)
                    unSelectDot(binding.p4)
                }

            }

        }

    }

    private fun unSelectDot(image: AppCompatImageView) {
        image.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_pass_dot_unfill))
    }

    private fun selectDot(image: AppCompatImageView) {
        image.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_pass_dot_fill))
    }

    private fun setErrorAnimation(view: View) {
        view.startAnimation(animation)
    }

    private fun setQuestion() {
        val securityQuestionDialog = SecurityQuestionDialog.newInstance(this, 1, false, true) {
            if (it) {
                preferences.putSetPass(false)
                preferences.putPass("")
                preferences.putSetQuestion(false)
                preferences.putAnswerQuestion("")
                startActivity(Intent(this, SetLockActivity::class.java).putExtra("isFromVerifyPin", true))
                finish()
            }
        }
        securityQuestionDialog.show(supportFragmentManager, "securityQuestionDialog")
    }

//    override fun onBackPressed() {
//        if (isTaskRoot) {
//            /* startActivity(Intent(this, HomeActivity::class.java).apply {
//                 addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
//             })*/
//            finish()
//        } else {
//            finish()
//        }
//    }

    override fun onDestroy() {
        super.onDestroy()
    }
}