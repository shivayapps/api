package gallery.photogallery.photoeditor.galleryapp.activities

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.PopupWindow
import androidx.activity.enableEdgeToEdge
import androidx.core.graphics.drawable.toDrawable
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityFeedbackBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.PopUpFeebackReasonBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.clientConfigPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding

class FeedbackActivity : BaseActivity() {

    private val binding by viewBinding(ActivityFeedbackBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        binding.root.setPadding(0, statusBarHeight, 0, navigationBarHeight)

        initView()
        initListener()
    }

    private fun initView() {

    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initListener() {

        binding.tvSelectedReason.setOnClickListener {
            onPopupMenuReason(binding.tvSelectedReason)
        }

        binding.btnSubmit.setOnClickListener {
            handleSendClick()
        }

        binding.ivBack.setOnClickListener {
            finish()
        }

        binding.etDesc.setOnTouchListener(View.OnTouchListener { v, event ->
            if (binding.etDesc.hasFocus()) {
                v.parent.requestDisallowInterceptTouchEvent(true)
                when (event.action and MotionEvent.ACTION_MASK) {
                    MotionEvent.ACTION_SCROLL -> {
                        v.parent.requestDisallowInterceptTouchEvent(false)
                        return@OnTouchListener true
                    }
                }
            }
            false
        })
    }

    private fun onPopupMenuReason(view: View) {

        val inflater = LayoutInflater.from(this)
        val popUpBinding = PopUpFeebackReasonBinding.inflate(inflater)

        val popupWindow = PopupWindow(
            popUpBinding.root,
            view.width,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        ).apply {
            elevation = 1f
            isOutsideTouchable = true
            setBackgroundDrawable(Color.TRANSPARENT.toDrawable())
        }

        popupWindow.showAsDropDown(view, 0, 8.dpToPx(this))

        popUpBinding.run {
            ivFeedbackOne.setOnClickListener {
                binding.tvSelectedReason.text = getString(R.string.photo_viewer_issues)
                popupWindow.dismiss()
            }

            ivFeedbackTwo.setOnClickListener {
                binding.tvSelectedReason.text = getString(R.string.private_folder_new)
                popupWindow.dismiss()
            }

            ivFeedbackThree.setOnClickListener {
                binding.tvSelectedReason.text = getString(R.string.bugs_amp_app_crashes)
                popupWindow.dismiss()
            }

            ivFeedbackFour.setOnClickListener {
                binding.tvSelectedReason.text = getString(R.string.photo_editing_issues)
                popupWindow.dismiss()
            }

            ivFeedbackFive.setOnClickListener {
                binding.tvSelectedReason.text = getString(R.string.performance_issues)
                popupWindow.dismiss()
            }

            ivFeedbackSix.setOnClickListener {
                binding.tvSelectedReason.text = getString(R.string.duplicate_photos_new)
                popupWindow.dismiss()
            }

            ivFeedbackSeven.setOnClickListener {
                binding.tvSelectedReason.text = getString(R.string.security_amp_pin_lock_issues)
                popupWindow.dismiss()
            }

            ivFeedbackOther.setOnClickListener {
                binding.tvSelectedReason.text = getString(R.string.others)
                popupWindow.dismiss()
            }
        }
    }

    fun Int.dpToPx(context: Context): Int {
        return (this * context.resources.displayMetrics.density).toInt()
    }

    private fun handleSendClick() {
        val messageSend = binding.etDesc.text.toString()

        if (binding.tvSelectedReason.text == getString(R.string.please_selected)) {
            toast(getString(R.string.please_select_categories))
            return
        }
        if (messageSend.isEmpty()) {
            toast(getString(R.string.please_describe_your_problem))
            return
        }

        val mailId = getReviewEmail()
        email(
            emailTo = mailId, subject = "${getString(R.string.app_name)}_${binding.tvSelectedReason.text}", emailText = "\n$messageSend"
        )
    }

    private fun getReviewEmail(): String {
        return clientConfigPref.reviewEmail
    }

    private fun email(
        emailTo: String,
        subject: String,
        emailText: String,
    ) {
        val emailIntent = Intent(Intent.ACTION_SEND_MULTIPLE)
        emailIntent.type = "message/rfc822"
        emailIntent.setPackage("com.google.android.gm")
        emailIntent.putExtra(Intent.EXTRA_EMAIL, arrayOf(emailTo))
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject)
        emailIntent.putExtra(Intent.EXTRA_TEXT, emailText)
        val uris = ArrayList<Uri>()
        emailIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        startActivity(Intent.createChooser(emailIntent, "Send mail..."))
        binding.etDesc.text.clear()
        finish()
    }
}