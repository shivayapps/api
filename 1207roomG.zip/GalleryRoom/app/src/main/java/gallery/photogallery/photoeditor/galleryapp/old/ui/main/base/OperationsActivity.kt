package gallery.photogallery.photoeditor.galleryapp.old.ui.main.base

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.appblish.box.api.model.Mode
import com.appblish.gallery.core.v2.api.core.FileTask
import com.appblish.gallery.core.v2.api.core.FireOperationCallback
import gallery.photogallery.photoeditor.galleryapp.App
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.SelectAlbumActivity
import gallery.photogallery.photoeditor.galleryapp.dialogs.ProgressDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.DONE_MEDIA_OPERATION
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.PROGRESS_MEDIA_OPERATION
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.sendOperationEvent
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File


open class OperationsActivity : BasePermissionActivity() {

    fun getApp() = applicationContext as App
    private var albumPickerLauncher: ActivityResultLauncher<Intent>? = null
    private var albumPickerCallback: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        albumPickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val destinationDir = result.data?.getStringExtra("select_path")
                if (!destinationDir.isNullOrEmpty()) {
                    albumPickerCallback?.invoke(destinationDir)
                }
            }
        }
    }

    fun requestAlbumPicker(selectedPaths: Array<String>, callback: (String) -> Unit) {
        albumPickerCallback = callback
        albumPickerLauncher?.launch(SelectAlbumActivity.createIntent(this, selectedPaths))
    }

    fun copyFolderFiles(mediaPathList: List<String>, destinationDir: String, onComplete: () -> Unit = {}) {
        checkStoragePermission {
            if (it) {
                ProgressDialog.show(
                    supportFragmentManager,
                    mediaPathList.size,
                    getString(R.string.Copying),
                )
                val callbacks = FireOperationCallback(
                    onFileStart = {

                    },
                    onFileProgress = { _, _, _ ->

                    },
                    onFileComplete = { file, ok, _, _ ->
                        Log.e("StorageActivityTAG", "copyFolderFiles: ${file.name} $ok")
                    },
                    onOverallProgress = { percentage, fileComplete ->
                        Log.e("StorageActivityTAG", "percentage: $percentage ")
//                sendOperationEvent(PROGRESS_MEDIA_OPERATION, percentage)
                        sendOperationEvent(PROGRESS_MEDIA_OPERATION, Pair(percentage, fileComplete))
                    },
                    onAllCompleted = { ok ->
                        Log.e("StorageActivityTAG", "onAllCompleted:  $ok")
                        lifecycleScope.launch {
                            delay(200)
                            sendOperationEvent(DONE_MEDIA_OPERATION, "copy")
                            sharedViewModel.fetchMedia()
                            onComplete.invoke()
                        }

                    }
                )
                sharedViewModel.copyFiles(mediaPathList, destinationDir, callbacks)
            }
        }

    }

    fun moveFolderFiles(mediaPathList: List<String>, destinationDir: String, onComplete: () -> Unit = {}) {
        checkStoragePermission {
            if (it) {
                ProgressDialog.show(
                    supportFragmentManager,
                    mediaPathList.size,
                    getString(R.string.Moving),
                )
                val callbacks = FireOperationCallback(
                    onFileStart = {

                    },
                    onFileProgress = { _, _, _ ->

                    },
                    onFileComplete = { file, ok, _, _ ->
                        Log.e("StorageActivityTAG", "copyFolderFiles: ${file.name} $ok")
                    },
                    onOverallProgress = { percentage, fileComplete ->
                        Log.e("StorageActivityTAG", "percentage: $percentage ")
//                sendOperationEvent(PROGRESS_MEDIA_OPERATION, percentage)
                        sendOperationEvent(PROGRESS_MEDIA_OPERATION, Pair(percentage, fileComplete))
                    },
                    onAllCompleted = { ok ->
                        Log.e("StorageActivityTAG", "onAllCompleted:  $ok")
                        lifecycleScope.launch {
                            delay(200)
                            sendOperationEvent(DONE_MEDIA_OPERATION, "copy")
                            sharedViewModel.fetchMedia()
                            sharedViewModel.fetchStories()
                            sharedViewModel.fetchMemories()
                            onComplete.invoke()
                        }

                    }
                )
                sharedViewModel.moveFiles(mediaPathList, destinationDir, callbacks)
            }
        }

    }

    fun deleteFolderFiles(mediaPathList: List<String>, isPermanent: Boolean, onComplete: () -> Unit = {}) {
        checkStoragePermission {
            if (it) {
                ProgressDialog.show(
                    supportFragmentManager,
                    mediaPathList.size,
                    if (isPermanent) getString(R.string.deleting) else getString(R.string.trashing),
                )
                val callbacks = FireOperationCallback(
                    onFileStart = {

                    },
                    onFileProgress = { _, _, _ ->

                    },
                    onFileComplete = { file, ok, _, _ ->
                        Log.e("StorageActivityTAG", "copyFolderFiles: ${file.name} $ok")

                    },
                    onOverallProgress = { percentage, fileComplete ->
                        Log.e("StorageActivityTAG", "percentage: $percentage ")
//                sendOperationEvent(PROGRESS_MEDIA_OPERATION, percentage)
                        sendOperationEvent(PROGRESS_MEDIA_OPERATION, Pair(percentage, fileComplete))

                    },
                    onAllCompleted = { ok ->
                        Log.e("StorageActivityTAG", "onAllCompleted:  $ok")
                        lifecycleScope.launch {
                            delay(200)
                            onComplete.invoke()
                            sendOperationEvent(DONE_MEDIA_OPERATION, "delete")
                            sharedViewModel.fetchMedia()
                            sharedViewModel.fetchStories()
                            sharedViewModel.fetchMemories()
                        }
                    }
                )
                if (isPermanent) {
                    sharedViewModel.deleteFiles(mediaPathList, callbacks)
                } else {
                    sharedViewModel.moveToPrivateOrRecycleBin(mediaPathList, false, callbacks)
                }
            }
        }

    }

    fun deletePermanentFolderFiles(mediaList: List<String>, callback: () -> Unit = {}) {
        checkStoragePermission {
            if (it) {
                ProgressDialog.show(
                    supportFragmentManager,
                    mediaList.size,
                    getString(R.string.Deleting),
                )
                lifecycleScope.launch {
                    val tasks = mediaList.mapNotNull { mediaItem ->
                        val filePath = mediaItem
                        if (filePath.isNotEmpty()) {
                            FileTask(File(filePath), null, Mode.DELETE)
                        } else {
                            null
                        }
                    }

                    Log.e("StorageActivityTAG", "copyFolderFiles: tasks ${tasks.size}")
                    val callback = FireOperationCallback(
                        onFileStart = {

                        },
                        onFileProgress = { file, written, total ->

                        },
                        onFileComplete = { file, ok, srcFile, err ->
                            Log.e("StorageActivityTAG", "copyFolderFiles: ${file.name} $ok")

                        },
                        onOverallProgress = { percentage, fileComplete ->
                            Log.e("StorageActivityTAG", "percentage: $percentage ")
                            sendOperationEvent(PROGRESS_MEDIA_OPERATION, Pair(percentage, fileComplete))
                        },
                        onAllCompleted = { ok ->
                            Log.e("StorageActivityTAG", "onAllCompleted:  $ok")
                            lifecycleScope.launch {
                                delay(200)
                                sendOperationEvent(DONE_MEDIA_OPERATION, "copy")
                                sharedViewModel.fetchRecycleBin()
                                sharedViewModel.fetchPrivate()
                                callback.invoke()
                            }

                        }
                    )
                    sharedViewModel.deleteFiles(mediaList, callback)
                }
            }
        }

    }

    fun deleteFromPrivate(mediaList: List<String>, callback: () -> Unit = {}) {
        checkStoragePermission {
            if (it) {
                ProgressDialog.show(
                    supportFragmentManager,
                    mediaList.size,
                    getString(R.string.Deleting),
                )
                lifecycleScope.launch {
                    val tasks = mediaList.mapNotNull { mediaItem ->
                        val filePath = mediaItem
                        if (filePath.isNotEmpty()) {
                            FileTask(File(filePath), null, Mode.DELETE)
                        } else {
                            null
                        }
                    }

                    Log.e("StorageActivityTAG", "copyFolderFiles: tasks ${tasks.size}")
                    val callback = FireOperationCallback(
                        onFileStart = {

                        },
                        onFileProgress = { file, written, total ->

                        },
                        onFileComplete = { file, ok, srcFile, err ->
                            Log.e("StorageActivityTAG", "copyFolderFiles: ${file.name} $ok")

                        },
                        onOverallProgress = { percentage, fileComplete ->
                            Log.e("StorageActivityTAG", "percentage: $percentage ")
//                    sendOperationEvent(PROGRESS_MEDIA_OPERATION, percentage)
                            sendOperationEvent(PROGRESS_MEDIA_OPERATION, Pair(percentage, fileComplete))
                        },
                        onAllCompleted = { ok ->
                            Log.e("StorageActivityTAG", "onAllCompleted:  $ok")
                            lifecycleScope.launch {
                                delay(200)
                                sendOperationEvent(DONE_MEDIA_OPERATION, "copy")
                                sharedViewModel.fetchRecycleBin()
                                sharedViewModel.fetchPrivate()
                                callback.invoke()
                            }

                        }
                    )
                    sharedViewModel.deleteFromPrivate(mediaList, callback)
                }
            }
        }

    }

    fun restoreMedia(files: List<File>, isPrivate: Boolean, callback: () -> Unit = {}) {
        checkStoragePermission {
            if (it) {
                ProgressDialog.show(
                    supportFragmentManager,
                    files.size,
                    getString(R.string.Restoring),
                )

                val callbacks = FireOperationCallback(
                    onFileStart = {

                    },
                    onFileProgress = { file, written, total ->

                    },
                    onFileComplete = { file, ok, srcFile, err ->
                        Log.e("StorageActivityTAG", "copyFolderFiles: ${file.name} $ok")

                    },
                    onOverallProgress = { percentage, fileComplete ->
                        Log.e("StorageActivityTAG", "percentage: $percentage ")
//                sendOperationEvent(PROGRESS_MEDIA_OPERATION, percentage)
                        sendOperationEvent(PROGRESS_MEDIA_OPERATION, Pair(percentage, fileComplete))
                    },
                    onAllCompleted = { ok ->

                        lifecycleScope.launch {
                            delay(200)
                            sendOperationEvent(DONE_MEDIA_OPERATION, "private")
                            sharedViewModel.fetchMedia()
                            if (isPrivate) {
                                sharedViewModel.fetchPrivate()
                            } else {
                                sharedViewModel.fetchRecycleBin()
                            }
                            callback.invoke()
                        }

                    }
                )
                sharedViewModel.restoreFromPrivateOrRecycleBin(files, isPrivate, "", callbacks)
            }
        }

    }

    fun restoreFromPrivateRecycleBin(files: List<File>, callback: () -> Unit = {}) {
        checkStoragePermission {
            if (it) {
                ProgressDialog.show(
                    supportFragmentManager,
                    files.size,
                    getString(R.string.Restoring),
                )

                val callbacks = FireOperationCallback(
                    onFileStart = {

                    },
                    onFileProgress = { file, written, total ->

                    },
                    onFileComplete = { file, ok, srcFile, err ->
                        Log.e("StorageActivityTAG", "copyFolderFiles: ${file.name} $ok")

                    },
                    onOverallProgress = { percentage, fileComplete ->
                        Log.e("StorageActivityTAG", "percentage: $percentage ")
//                sendOperationEvent(PROGRESS_MEDIA_OPERATION, percentage)
                        sendOperationEvent(PROGRESS_MEDIA_OPERATION, Pair(percentage, fileComplete))
                    },
                    onAllCompleted = { ok ->
                        Log.e("StorageActivityTAG", "onAllCompleted:  $ok")
                        lifecycleScope.launch {
                            delay(200)
                            sendOperationEvent(DONE_MEDIA_OPERATION, "private")
                            sharedViewModel.fetchPrivate()
                            callback.invoke()
                        }

                    }
                )
                sharedViewModel.restoreFromPrivateRecycleBin(files, callbacks)
            }
        }

    }

    fun hideFolderFiles(mediaPathList: List<String>, onComplete: (List<String>) -> Unit) {
        checkStoragePermission {
            if (it) {
                ProgressDialog.show(
                    supportFragmentManager,
                    mediaPathList.size,
                    getString(R.string.hiding),
                )
                val callbacks = FireOperationCallback(
                    onFileStart = {

                    },
                    onFileProgress = { file, written, total ->

                    },
                    onFileComplete = { file, ok, srcFile, err ->
                        Log.e("StorageActivityTAG", "copyFolderFiles: ${file.name} $ok")

                    },
                    onOverallProgress = { percentage, fileComplete ->
                        Log.e("StorageActivityTAG", "percentage: $percentage ")
//                sendOperationEvent(PROGRESS_MEDIA_OPERATION, percentage)
                        sendOperationEvent(PROGRESS_MEDIA_OPERATION, Pair(percentage, fileComplete))
                    },
                    onAllCompleted = { ok ->
                        Log.e("StorageActivityTAG", "onAllCompleted:  $ok")
                        lifecycleScope.launch {
                            onComplete.invoke(mediaPathList)
                            delay(200)
                            sendOperationEvent(DONE_MEDIA_OPERATION, "private")
                            sharedViewModel.fetchMedia()
                            sharedViewModel.fetchStories()
                            sharedViewModel.fetchMemories()
                        }

                    }
                )
                sharedViewModel.moveToPrivateOrRecycleBin(mediaPathList, true, callbacks)
            }
        }

    }

}