package gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities

import android.annotation.SuppressLint
import android.os.Bundle
import com.app.blish.player.api.VideoPlayerSDK
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityAdvanceSettingsBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.ChangePatternDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.NoFingerprintDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.custom.SwitchButton
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog.HintDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog.HintDialogNavigationBar
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.clientConfigPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Preferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus


class AdvanceSettingsActivityBaseActivity : BaseActivity() {
    private val binding by viewBinding(ActivityAdvanceSettingsBinding::inflate)

    val preferences: Preferences by lazy { Preferences(this) }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.root.setPadding(0, statusBarHeight, 0, navigationBarHeight)

        init()
        initVideoPref()
        CoroutineScope(Dispatchers.IO).launch {
//            val preferences = preferencesRepository.playerPreferences.first()
            runOnUiThread {
//                initVideoPref(playerPrefs)
            }
        }
    }

    private fun init() {
        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

        binding.llFingerprint.setOnClickListener {
            NoFingerprintDialog().show(supportFragmentManager, "NoFingerprintDialog")
        }

        binding.llChangeUnlock.setOnClickListener {
            ChangePatternDialog().show(supportFragmentManager, "ChangePatternDialog")
        }

        binding.sbHideSystem.isChecked = preferences.hideUIOnFullScreen
        binding.sbHideSystem.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.hideUIOnFullScreen = isChecked
            }
        })
        binding.sbAllowClosing.isChecked = preferences.allowDownGesture
        binding.sbAllowClosing.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.allowDownGesture = isChecked
            }
        })
        binding.sbAllowRotatingGestures.isChecked = preferences.allowRotatingWithGestures
        binding.sbAllowRotatingGestures.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.allowRotatingWithGestures = isChecked
            }
        })
        binding.sbAllowDoubleTaps.isChecked = preferences.allowOneToOneZoom
        binding.sbAllowDoubleTaps.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.allowOneToOneZoom = isChecked
            }
        })

        binding.sbAllowDeepZooming.isChecked = preferences.allowZoomingImages
        binding.sbAllowDeepZooming.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.allowZoomingImages = isChecked
            }
        })
        binding.sbHighestQuality.isChecked = preferences.showHighestQuality
        binding.sbHighestQuality.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.showHighestQuality = isChecked
            }
        })
        binding.sbPhotoBrightness.isChecked = preferences.allowPhotoGestures
        binding.sbPhotoBrightness.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.allowPhotoGestures = isChecked
            }
        })
        binding.sbBlackBackground.isChecked = preferences.blackBackground
        binding.sbBlackBackground.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.blackBackground = isChecked
            }
        })
        binding.sbDeleteEmptyFolders.isChecked = preferences.deleteEmptyFolders
        binding.sbDeleteEmptyFolders.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.deleteEmptyFolders = isChecked
            }
        })
        binding.sbKeepLastModified.isChecked = preferences.keepLastModified
        binding.sbKeepLastModified.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.keepLastModified = isChecked
            }
        })

        binding.tvSubEdited.text = getEditBehaviorText()
        binding.clEdited.setOnClickListener {

        }



        binding.sbHideCamera.isChecked = preferences.cameraFabEnabled
        binding.sbHideCamera.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                if (!binding.sbHideCamera.isChecked) {
                    val hintDialog = HintDialog(
                        this@AdvanceSettingsActivityBaseActivity,
                        getString(R.string.hide_camera),
                        R.drawable.ic_hint_camera,
                        updateListener = {
                            preferences.cameraFabEnabled = false
                        })
                    hintDialog.show()
                } else {
                    preferences.cameraFabEnabled = true
                }
            }
        })

        binding.sbHidePrivate.isChecked = preferences.privateVaultEnabled
        binding.sbHidePrivate.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.privateVaultEnabled = binding.sbHidePrivate.isChecked
            }
        })

        binding.sbHideNavigation.isChecked = clientConfigPref.bottomNavigationScrollMode
        binding.sbHideNavigation.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                if (!binding.sbHideNavigation.isChecked) {
                    val hintDialog = HintDialogNavigationBar(
                        this@AdvanceSettingsActivityBaseActivity,
                        getString(R.string.hide_navigation),
                        R.drawable.bottom_nativigation_hint,
                        updateListener = {
                            clientConfigPref.bottomNavigationScrollMode = false
                            EventBus.getDefault().post("updateNavigationVisibility")
                        })
                    hintDialog.show()
                } else {
                    clientConfigPref.bottomNavigationScrollMode = true
                }
            }
        })

        binding.clManage.setOnClickListener {
            startActivity(ExcludeDirectoryActivityBaseActivity.createExcludeManageIntent(this))
        }
    }

    private fun initVideoPref() {
        binding.sbMaxBrightness.setChecked(preferences.maxBrightness)
        binding.sbMaxBrightness.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                preferences.maxBrightness = isChecked
            }
        })

        /* binding.sbPlayVideos.setChecked(preferences.autoplay)
         binding.sbPlayVideos.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
             override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                 CoroutineScope(Dispatchers.IO).launch {
                     preferences.autoplay = isChecked
                 }
             }
         })*/

        binding.sbRememberVideoPosition.setChecked(VideoPlayerSDK.getPref(this).isRememberPlayback())
        binding.sbRememberVideoPosition.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                VideoPlayerSDK.getPref(this@AdvanceSettingsActivityBaseActivity).setRememberPlayback(isChecked)
            }
        })

        binding.sbControlVideo.setChecked(VideoPlayerSDK.getPref(this).isUseSwipeControl())
        binding.sbControlVideo.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                VideoPlayerSDK.getPref(this@AdvanceSettingsActivityBaseActivity).setUseSwipeControl(isChecked)

            }
        })

        binding.sbZoomControl.setChecked(VideoPlayerSDK.getPref(this).isUseZoomControl())
        binding.sbZoomControl.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                VideoPlayerSDK.getPref(this@AdvanceSettingsActivityBaseActivity).setUseZoomControl(isChecked)

            }
        })
        /*
                binding.sbFullScreenMode.setChecked(preferences.fullScreenMode)
                binding.sbFullScreenMode.setOnCheckedChangeListener(object : SwitchButton.OnCheckedChangeListener {
                    override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                        preferences.fullScreenMode = isChecked
                    }
                })*/

    }

    private fun getEditBehaviorText() = "Save Copy"


    @SuppressLint("GestureBackNavigation")
    override fun onBackPressed() {
        finish()
    }
}