package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.adaptor.MemoriesToneAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogMemoriesToneBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.getMemoriesMusicList

class MemoriesToneDialog : DialogFragment() {
    private var _binding: DialogMemoriesToneBinding? = null
    private val binding get() = _binding!!
    private var onToneSelected: ((Int) -> Unit)? = null
    private var currentTone: Int = 0

    companion object {
        fun newInstance(
            currentTone: Int,
            listener: (Int) -> Unit,
        ): MemoriesToneDialog {
            val dialog = MemoriesToneDialog()
            dialog.currentTone = currentTone
            dialog.onToneSelected = listener
            return dialog
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogMemoriesToneBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(gallery.photogallery.photoeditor.galleryapp.R.color.transparent)
            setLayout(requireContext().getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER) // remove if you want center dialog
        }

        intView()
        return dialog
    }

    private fun intView() {
        val toneAdapter = MemoriesToneAdapter(
            selectedTonePath = currentTone
        ) { selectedTone ->
            currentTone = selectedTone.filePath
            onToneSelected?.invoke(selectedTone.filePath)
            dismiss()
        }

        binding.rvMemoriesTone.adapter = toneAdapter

        toneAdapter.submitList(getMemoriesMusicList())
    }
}