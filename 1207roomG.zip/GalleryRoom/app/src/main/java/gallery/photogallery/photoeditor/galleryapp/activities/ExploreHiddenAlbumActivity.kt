package gallery.photogallery.photoeditor.galleryapp.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.ScrollGate
import com.appblish.box.api.util.AppblishEvent
import com.appblish.box.api.util.MediaDataState
import com.appblish.recyclerview.dragselection.SelectionUpdateCallback
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.adaptor.RecycleMediaAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityExploreHiddenAlbumBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.DeleteDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.showDeleteDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.getFilenameFromPath
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File

class ExploreHiddenAlbumActivity : BaseActivity(), View.OnClickListener {
    private val binding by viewBinding(ActivityExploreHiddenAlbumBinding::inflate)
    private val directoryPath by lazy { intent.getStringExtra("directoryPath") ?: "" }
    private val directorySize by lazy { intent.getIntExtra("directorySize", 0) }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        enableEdgeToEdge()
        binding.root.setPadding(0, statusBarHeight, 0, navigationBarHeight)
        initLayoutManager()
        initClick()
        setListeners()
    }

    private fun initLayoutManager() {

        if (binding.mediaRecycler.adapter == null) {
            binding.mediaRecycler.layoutManager = GridLayoutManager(this, 3)
            val albumAdaptor = RecycleMediaAdapter(binding.mediaRecycler, sharedViewModel.isDeleteMediaAfter30Day()) {
                onFileClick(it)
            }
            binding.mediaRecycler.adapter = albumAdaptor

            albumAdaptor.setSelectionUpdateCallback(
                object : SelectionUpdateCallback {
                    override fun onSelectionCountChanged(
                        selectedCount: Int,
                        selectionActive: Boolean
                    ) {
                        updateSelection()
                    }
                }
            )
        }
    }


    private fun initClick() {
        binding.tvAlbumName.text = directoryPath.getFilenameFromPath()
        binding.tvCount.text = directorySize.toString() + " " + resources.getString(R.string.items)
        binding.mediaRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING ||
                    newState == RecyclerView.SCROLL_STATE_SETTLING
                ) {
                    ScrollGate.onScrollStart()
                } else {
                    ScrollGate.onScrollStop()
                }
            }
        })
        binding.icSelectAll.setOnClickListener(this)
        binding.ivClose.setOnClickListener(this)
        binding.ivBack.setOnClickListener(this)
        registerEventBus(this)
        observableMedia()
    }

    @SuppressLint("SetTextI18n")
    private fun observableMedia() {
        lifecycleScope.launch {
            val state = withContext(Dispatchers.IO) {
                sharedViewModel.getPrivateMediaAlbum(directoryPath)
            }
            when (state) {
                MediaDataState.Empty -> {
                    setMedia(emptyList())
                }

                MediaDataState.Loading -> {
                }

                is MediaDataState.Success -> {
                    setMedia(state.data)
                }

                is MediaDataState.Progress -> {}
            }
        }
    }

    @SuppressLint("SetTextI18n")
    fun setMedia(list: List<File>) {
        Log.e("setMedia", "setMedia: ${list.size}")
        binding.tvCount.text = list.size.toString() + " " + resources.getString(R.string.items)
        getRecycleMediaAdapter()?.submitList(list)
        binding.loutNoData.beVisibleIf(list.isEmpty())
    }

    fun onFileClick(file: File) {
        val listOfFile = getRecycleMediaAdapter()?.getAllPath() ?: emptyList()
        val index = listOfFile.indexOf(file)
        sharedViewModel.imageViewerList.clear()
        sharedViewModel.imageViewerList.addAll(listOfFile.map { it.absolutePath })
        startActivity(Intent(this, NewImageViewerActivity::class.java).apply {
            putExtra("startPosition", index)
            putExtra("ACTIVITY_NAME", "ExploreHiddenAlbumActivity")
        })
    }

    @SuppressLint("SetTextI18n")
    fun updateSelection() {
        val recycleMediaAdapter = getRecycleMediaAdapter() ?: return
        binding.clSelection.beVisibleIf(recycleMediaAdapter.isSelectionActive())
        binding.btmSelectionView.beVisibleIf(recycleMediaAdapter.isSelectionActive())
        binding.photoToolbar.beVisibleIf(!recycleMediaAdapter.isSelectionActive())
        binding.tvTitleSelection.text = "${recycleMediaAdapter.getSelectedCount()} " + resources.getString(R.string.selected)

        if (recycleMediaAdapter.isSelectAll()) {
            binding.icSelectAll.setImageResource(R.drawable.vec_selected_bg)
        } else {
            binding.icSelectAll.setImageResource(R.drawable.vec_unselected_bg)
        }
    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        val recycleMediaAdapter = getRecycleMediaAdapter() ?: return
        if (recycleMediaAdapter.isSelectionActive()) {
            disableSelection()
        } else {
            finish()
        }
    }

    override fun onClick(view: View?) {
        when (view) {
            binding.ivBack -> {
                onBackPressed()
            }

            binding.icSelectAll -> {
                val recycleMediaAdapter = getRecycleMediaAdapter() ?: return
                if (recycleMediaAdapter.isSelectAll()) {
                    recycleMediaAdapter.unSelectAll()
                } else {
                    recycleMediaAdapter.selectAll()
                }
            }


            binding.ivClose -> {
                binding.icSelectAll.isSelected = false
                binding.icSelectAll.setColorFilter(ContextCompat.getColor(this, R.color.app_text_color))
                disableSelection()
            }
        }
    }

    private fun setListeners() {
        binding.btnRestore.setOnClickListener {
            val recycleMediaAdapter = getRecycleMediaAdapter() ?: return@setOnClickListener
            val selectedFile = recycleMediaAdapter.getSelectedItems()
            showDeleteDialog(
                title = getString(R.string.restore_msg),
                positiveRes = R.string.unhide,
                onDeleteClick = {
                    restoreMedia(selectedFile, true)
                    disableSelection()
                })

        }

        binding.btnDelete.setOnClickListener {
            val recycleMediaAdapter = getRecycleMediaAdapter() ?: return@setOnClickListener
            val selectedFile = recycleMediaAdapter.getSelectedItems()
            val deleteDialog = DeleteDialog.newInstance(btnClickListener = { isPermanent ->
                if (isPermanent) {
                    deleteFolderFiles(selectedFile.map { it.absolutePath }, true)
                } else {
                    deleteFromPrivate(selectedFile.map { it.absolutePath })
                }
                disableSelection()
            })
            deleteDialog.show(supportFragmentManager, "DeleteDialog")
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            AppblishEvent.ALL_PRIVATE_LOADED -> {
                observableMedia()
            }

        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterEventBus(this)
    }
    private fun getRecycleMediaAdapter() = binding.mediaRecycler.adapter as? RecycleMediaAdapter


    fun disableSelection() {
        val albumAdaptor = getRecycleMediaAdapter() ?: return
        albumAdaptor.clearSelectionAndExit()
        updateSelection()
    }
}