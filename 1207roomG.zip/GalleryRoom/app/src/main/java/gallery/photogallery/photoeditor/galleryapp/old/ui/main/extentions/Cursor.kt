package gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions

import android.database.Cursor
import kotlin.contracts.ExperimentalContracts
import kotlin.contracts.contract

fun Cursor.getStringValue(key: String) = getString(getColumnIndex(key))

fun Cursor.getStringValueOrNull(key: String) =
    if (isNull(getColumnIndex(key))) null else getString(getColumnIndex(key))

fun Cursor.getIntValue(key: String) = getInt(getColumnIndex(key))

fun Cursor.getIntValueOrNull(key: String) =
    if (isNull(getColumnIndex(key))) null else getInt(getColumnIndex(key))

fun Cursor.getLongValue(key: String) = getLong(getColumnIndex(key))

fun Cursor.getLongValueOrNull(key: String) =
    if (isNull(getColumnIndex(key))) null else getLong(getColumnIndex(key))

fun Cursor.getBlobValue(key: String) = getBlob(getColumnIndex(key))

fun <T : Any> List<T?>.fastFilterNotNull(): List<T> {
    val target = ArrayList<T>(size)
    fastForEach {
        if ((it) != null) target += (it)
    }
    return target
}
@OptIn(ExperimentalContracts::class)
inline fun <T> List<T>.fastForEach(action: (T) -> Unit) {
    contract { callsInPlace(action) }
    for (index in indices) {
        val item = get(index)
        action(item)
    }
}