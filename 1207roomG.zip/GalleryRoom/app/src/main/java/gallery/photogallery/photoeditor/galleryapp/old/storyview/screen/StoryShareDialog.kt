package gallery.photogallery.photoeditor.galleryapp.old.storyview.screen

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.content.res.AppCompatResources
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogStoryShareBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class StoryShareDialog : BottomSheetDialogFragment() {


    lateinit var binding: DialogStoryShareBinding
    var clickListener: ((type: String) -> Unit)? = null
    private lateinit var appNames: ArrayList<String>
    private lateinit var appPackageNames: ArrayList<String>
    private lateinit var appIcons: ArrayList<Drawable>

    companion object {
        var selectedImageUris = ArrayList<Uri>()

        fun newInstance(clickListener: (type: String) -> Unit): StoryShareDialog {
            val dialog = StoryShareDialog()
            dialog.clickListener = clickListener
            return dialog
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DialogStoryShareBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val layoutParams = binding.clMainTop.layoutParams
        layoutParams?.height = 1000
        binding.clMainTop.layoutParams = layoutParams

        initClick()
        shareData()
    }

    @SuppressLint("SetTextI18n")
    private fun initClick() {
        binding.tvSelectedItem.text = requireActivity().resources.getString(R.string.Share) + " " + selectedImageUris.size.toString() + " " + requireActivity().resources.getString(R.string.photos)
    }

    private fun shareData() {
        appNames = ArrayList()
        appPackageNames = ArrayList()
        appIcons = ArrayList()


        val shareIntent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "image/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, selectedImageUris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val packageManager = requireActivity().packageManager
        val resolveInfoList: List<ResolveInfo> = packageManager.queryIntentActivities(shareIntent, PackageManager.MATCH_DEFAULT_ONLY)

        for (resolveInfo in resolveInfoList) {
            val appName = resolveInfo.loadLabel(packageManager).toString()
            val appPackage = resolveInfo.activityInfo.packageName
            val appIcon = resolveInfo.loadIcon(packageManager)

            if (appName.lowercase() != "bluetooth") {
                appNames.add(appName)
                appPackageNames.add(appPackage)
                appIcons.add(appIcon)
            }
        }

        if (appNames.size > 7) {
            appNames = ArrayList(appNames.subList(0, 7))
            appPackageNames = ArrayList(appPackageNames.subList(0, 7))
            appIcons = ArrayList(appIcons.subList(0, 7))
        }

        appNames.add("Other")
        appPackageNames.add("")
        appIcons.add(requireActivity().getDrawable(R.drawable.vec_other_story)!!)
        appNames.distinct()
        appPackageNames.distinct()
        appIcons.distinct()

        val adapter = AppGridAdapter(requireActivity(), appNames, appIcons)
        binding.gridView.adapter = adapter

        binding.gridView.setOnItemClickListener { _, _, position, _ ->

            if (position == appNames.size - 1) {
                shareFiles()
            } else {
                val selectedAppPackageName = appPackageNames[position]
                val selectedIntent = Intent(shareIntent).apply {
                    setPackage(selectedAppPackageName)
                }
                startActivity(selectedIntent)
            }
        }
    }

    private fun shareFiles() {
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "image/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, selectedImageUris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            requireContext().startActivity(
                Intent.createChooser(intent, requireContext().getString(R.string.share_with))
            )
        } catch (_: Exception) {
        }
    }


    override fun getTheme(): Int = R.style.PrivateBottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)

    override fun onDestroy() {
        super.onDestroy()
        clickListener?.invoke("Dismiss")
    }

}


class AppGridAdapter(
    private val context: Activity,
    private val appNames: ArrayList<String>,
    private val appIcons: ArrayList<Drawable>
) : android.widget.BaseAdapter() {

    override fun getCount(): Int {
        return appNames.size
    }

    override fun getItem(position: Int): Any {
        return appNames[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.grid_item_app, parent, false)

        val appNameTextView = view.findViewById<TextView>(R.id.app_name)
        val appIconImageView = view.findViewById<ImageView>(R.id.app_icon)

        appNameTextView.text = appNames[position]
        appIconImageView.setImageDrawable(appIcons[position])

        if (position == appNames.size - 1) {
//            appNameTextView.text = getStr(R.string.other)
            appNameTextView.text = "Other"
//            appIconImageView.setImageResource(R.drawable.ic_other_story)
            val vectorDrawable = AppCompatResources.getDrawable(context, R.drawable.vec_other_story)
            appIconImageView.setImageDrawable(vectorDrawable)
        }


        return view
    }
}