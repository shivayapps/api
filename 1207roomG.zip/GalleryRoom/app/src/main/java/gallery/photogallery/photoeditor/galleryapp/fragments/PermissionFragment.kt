package gallery.photogallery.photoeditor.galleryapp.fragments

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import gallery.photogallery.photoeditor.galleryapp.permission.PermissionSDK
import gallery.photogallery.photoeditor.galleryapp.activities.MainActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.FragmentPermissionBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.checkMediaPermission
import gallery.photogallery.photoeditor.galleryapp.permission.PermissionCallback
import kotlinx.coroutines.launch

class PermissionFragment : BaseFragment<FragmentPermissionBinding>() {

    override fun inflateBinding(inflater: LayoutInflater, container: ViewGroup?) = FragmentPermissionBinding.inflate(inflater, container, false)
    override fun onAttach(context: Context) {
        super.onAttach(context)

    }

    override fun setupViews() {
        init()
    }

    private fun init() {
        binding.incAllFileAccess.ivAllow.setOnClickListener {
            (requireActivity() as? MainActivity)?.let { activity ->
                PermissionSDK.askMediaPermission(
                    requireActivity(), PermissionCallback(
                        onPermissionResult = { granted ->
                            if (granted) {
                                activity.afterPermission()
                            }
                        },
                        onLimitedAccess = {
                            activity.afterPermission()
                        },
                        onPermissionRationale = {
                            activity.requestManageAllFile {
                                sharedViewModel.fetchMedia()
                                startActivity(Intent(activity, MainActivity::class.java).apply {
                                    flags =
                                        Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                                })
                                activity.finish()
                            }
                        }

                    ))
            }


        }
        lifecycleScope.launch {
            if (!requireActivity().checkMediaPermission()) {
                (requireActivity() as? MainActivity)?.let { activity ->
                    PermissionSDK.askMediaPermission(
                        requireActivity(), PermissionCallback(
                            onPermissionResult = { granted ->
                                if (granted) {
                                    activity.afterPermission()
                                }
                            },
                            onLimitedAccess = {
                                activity.afterPermission()
                            },
                            onPermissionRationale = {
                            }

                        ))
                }
            }
        }
    }


}
