package gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions

import android.content.Context
import android.os.SystemClock
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewTreeObserver
import android.widget.TextView
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.SHORT_ANIMATION_DURATION
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

fun View.beInvisibleIf(beInvisible: Boolean) = if (beInvisible) beInvisible() else beVisible()

fun View.beVisibleIf(beVisible: Boolean) = if (beVisible) beVisible() else beGone()

fun View.beGoneIf(beGone: Boolean) = beVisibleIf(!beGone)

fun View.beInvisible() {
    visibility = View.INVISIBLE
}

fun View.beVisible() {
    visibility = View.VISIBLE
}


fun View.beGone() {
    visibility = View.GONE
}


fun View.onGlobalLayout(callback: () -> Unit) {
    viewTreeObserver?.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
        override fun onGlobalLayout() {
            if (viewTreeObserver != null) {
                viewTreeObserver.removeOnGlobalLayoutListener(this)
                callback()
            }
        }
    })
}

fun View.isVisible() = visibility == View.VISIBLE

fun View.isInvisible() = visibility == View.INVISIBLE

fun View.isGone() = visibility == View.GONE

fun View.performHapticFeedback() = performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING)

fun View.fadeIn() {
    animate().alpha(1f).setDuration(SHORT_ANIMATION_DURATION).withStartAction { beVisible() }.start()
}

fun View.fadeOut() {
    animate().alpha(0f).setDuration(SHORT_ANIMATION_DURATION).withEndAction { beGone() }.start()
}

fun View.sendFakeClick(x: Float, y: Float) {
    val uptime = SystemClock.uptimeMillis()
    val event = MotionEvent.obtain(uptime, uptime, MotionEvent.ACTION_DOWN, x, y, 0)
    dispatchTouchEvent(event)
    event.action = MotionEvent.ACTION_UP
    dispatchTouchEvent(event)
}

fun File.getNameWithoutExtension(): String {
    return if (name.contains(".")) name.substring(0, name.lastIndexOf(".")) else name
}

fun File.md5(): String {
    val md: MessageDigest = MessageDigest.getInstance("MD5")
    val fis = FileInputStream(this)
    val buffer = ByteArray(8192)
    var read: Int
    while (fis.read(buffer).also { read = it } != -1) {
        md.update(buffer, 0, read)
    }
    val hashBytes: ByteArray = md.digest()
    val sb = StringBuilder()
    for (hashByte in hashBytes) {
        sb.append(((hashByte.toInt() and 0xff) + 0x100).toString(16).substring(1))
    }
    fis.close()
    return sb.toString()
}
var lastClickTS: Long = 0
fun View.setOnSingleClickListener(callback: (View) -> Unit) {
    setOnClickListener {
        if (System.currentTimeMillis() - lastClickTS > 300) {
            lastClickTS = System.currentTimeMillis()
            callback(this)
        }
    }
}

var lastClickTSOneSec: Long = 0
fun View.setOnSingleClickListenerOneSec(callback: (View) -> Unit) {
    setOnClickListener {
        if (System.currentTimeMillis() - lastClickTSOneSec > 1000) {
            lastClickTSOneSec = System.currentTimeMillis()
            callback(this)
        }
    }
}


fun TextView.setLanguageRTL() {
    if (context.isRTLLanguage()) {
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        gravity = Gravity.END
    } else {
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        gravity = Gravity.START
    }
}

fun Context.isRTLLanguage(): Boolean {
    val selectedLanguage = preferences.getSelectedLang(this)
    return selectedLanguage.contains("ar") || selectedLanguage.contains("fa") || selectedLanguage.contains("ur") || selectedLanguage.contains("iw")
}

//fun View.setupViewBackground(context: Context) {
//    background = if (context.baseConfig.isUsingSystemTheme) {
//        resources.getDrawable(R.drawable.selector_clickable_you)
//    } else {
//        resources.getDrawable(R.drawable.selector_clickable)
//    }
//}
