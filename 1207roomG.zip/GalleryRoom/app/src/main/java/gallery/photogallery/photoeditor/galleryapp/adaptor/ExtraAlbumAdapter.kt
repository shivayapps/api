package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.appblish.gallery.core.v2.api.model.TimeLineAlbumModel
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.TimelineExploreActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemAlbumGridBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemAlbumListBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.ExtraAlbumActivity

class ExtraTimelineAlbumAdapter(
    val context: ExtraAlbumActivity
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val ALBUM = 1
    }

    private val items = ArrayList<TimeLineAlbumModel>()

    fun submitList(list: List<TimeLineAlbumModel>) {
        items.clear()
        items.addAll(list.filterIsInstance<TimeLineAlbumModel>())
        notifyDataSetChanged()
    }

    fun getItem(position: Int): TimeLineAlbumModel =
        items[position]

    override fun getItemCount(): Int = items.size

    override fun getItemViewType(position: Int): Int = ALBUM

    // -----------------------------
    // Adapter
    // -----------------------------
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {

        return if (context.appPref.albumAsGrid) {
            val binding = ItemAlbumGridBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
            AlbumViewHolder(binding)
        } else {
            val binding = ItemAlbumListBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
            AlbumListViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is AlbumViewHolder -> holder.bind(getItem(position))
            is AlbumListViewHolder -> holder.bind(getItem(position))
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        when (holder) {
            is AlbumViewHolder ->
                Glide.with(holder.binding.imageAlbum.context)
                    .clear(holder.binding.imageAlbum)

            is AlbumListViewHolder ->
                Glide.with(holder.binding.imageAlbum.context)
                    .clear(holder.binding.imageAlbum)
        }
    }


    // -----------------------------
    // ViewHolders
    // -----------------------------
    inner class AlbumViewHolder(
        val binding: ItemAlbumGridBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        @SuppressLint("SetTextI18n")
        fun bind(item: TimeLineAlbumModel) {
            val album = item.mediaRows

            binding.apply {
                txtTitle.text = getAlbumTitle(context, item.title)
                txtCount.text = "${album.size} ${root.context.getString(R.string.items)}"

                val context = imageAlbum.context
                binding.imageAlbum.loadGridImage(
                    album[0].mediaPath,
                    album[0].mediaDate
                )
                root.setOnClickListener {
                    val intent = Intent(context, TimelineExploreActivity::class.java).apply {
                        putExtra("BUCKET_PATH", item.title)
                        putExtra("BUCKET_SIZE", item.mediaRows.size)
                    }
                    context.startActivity(intent)
                }
            }
        }
    }

    inner class AlbumListViewHolder(
        val binding: ItemAlbumListBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        @SuppressLint("SetTextI18n")
        fun bind(item: TimeLineAlbumModel) {
            val album = item.mediaRows

            binding.apply {
                txtTitle.text = getAlbumTitle(context, item.title)
                txtCount.text = "${album.size} ${root.context.getString(R.string.items)}"

                binding.imageAlbum.loadGridImage(
                    album[0].mediaPath,
                    album[0].mediaDate
                )

                root.setOnClickListener {
                    val intent = Intent(context, TimelineExploreActivity::class.java).apply {
                        putExtra("BUCKET_PATH", item.title)
                        putExtra("BUCKET_SIZE", item.mediaRows.size)

                    }
                    context.startActivity(intent)
                }

            }
        }
    }

    // -----------------------------
    // Utils
    // -----------------------------
    private fun getAlbumTitle(context: ExtraAlbumActivity, title: String): String =
        when (title) {
            "all_videos" -> ContextCompat.getString(context, R.string.all_videos)
            "last_week" -> ContextCompat.getString(context, R.string.last_week)
            "last_month" -> ContextCompat.getString(context, R.string.last_month)
            "this_year" -> ContextCompat.getString(context, R.string.this_year)
            else -> title
        }
}
