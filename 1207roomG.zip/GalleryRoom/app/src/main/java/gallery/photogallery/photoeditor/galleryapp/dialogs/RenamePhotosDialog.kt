package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogRenameFileBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import java.io.File

class RenamePhotosDialog(val activity: Activity) : DialogFragment() {

    private var _binding: DialogRenameFileBinding? = null
    private val binding get() = _binding!!

    var positiveBtnClickListener: ((renameFile: File, oldFile: File) -> Unit)? = null
    lateinit var filePath: String
    lateinit var fileName: String

    private lateinit var safeContext: Context

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogRenameFileBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }

        if (::filePath.isInitialized) {
            dialog.setCanceledOnTouchOutside(false)
            showKeyboard()
            intView()
            intListener()
        } else {
            dismiss()
        }

        return dialog
    }


    private fun intView() {
        val file = File(filePath)
        fileName = file.name.substring(0, file.name.lastIndexOf("."))
        binding.edtName.setText(fileName)
        binding.edtName.requestFocus()
    }

    private fun intListener() {
        binding.edtName.addTextChangedListener {
            binding.icClear.visibility = if (binding.edtName.text?.trim().toString()
                    .isNotEmpty()
            ) View.VISIBLE else View.GONE
        }
        binding.icClear.setOnClickListener {
            binding.edtName.setText("")
        }
        binding.btnCancel.setOnClickListener {
            hideKeyboard()
            dismiss()
        }

        binding.btnRename.setOnClickListener {
            val strNewFileName = binding.edtName.text.toString().trim()
            if (strNewFileName.isNotEmpty()) {
                val oldFile = File(filePath)
                if (oldFile.name == strNewFileName) {
                    hideKeyboard()
                    dismiss()
                    return@setOnClickListener
                }
                val file = File(filePath)
                val renameFile = File(oldFile.parentFile!!.absolutePath, "${strNewFileName}.${file.extension}")
                if (!renameFile.exists()) {
                    hideKeyboard()
                    dismiss()
                    positiveBtnClickListener?.invoke(renameFile, oldFile)

                } else {
                    activity.toast(activity.getString(R.string.rename_validation2))
                }
            } else {
                activity.toast(activity.getString(R.string.rename_validation))
            }
        }
    }

    private fun showKeyboard() {
        binding.btnRename.requestFocus()
        val methodManager = (activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(binding.btnRename, InputMethodManager.SHOW_IMPLICIT)
    }

    fun hideKeyboard() {
        binding.edtName.clearFocus()
        binding.btnRename.clearFocus()
        val methodManager = (activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(binding.btnRename.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }
}