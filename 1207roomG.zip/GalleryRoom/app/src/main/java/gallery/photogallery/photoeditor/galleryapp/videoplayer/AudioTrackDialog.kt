package gallery.photogallery.photoeditor.galleryapp.videoplayer

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.LinearLayoutManager
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogAudioTrackBinding

class AudioTrackDialog(
    private val audioList: List<String>,
    private val onTrackSelected: (Int) -> Unit,
    private val onDisableAudio: () -> Unit
) : DialogFragment() {

    private var _binding: DialogAudioTrackBinding? = null
    private val binding get() = _binding!!

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        _binding = DialogAudioTrackBinding.inflate(layoutInflater)

        val dialog = AlertDialog.Builder(requireContext())
            .setView(binding.root)
            .create()

        binding.recyclerAudio.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerAudio.adapter =
            AudioTrackAdapter(audioList) { position ->
                onTrackSelected(position)
                dismiss()
            }

        binding.btnDisable.setOnClickListener {
            onDisableAudio()
            dismiss()
        }

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        return dialog
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onStart() {
        super.onStart()

        dialog?.window?.apply {

            // Remove default white background
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            // Dim amount control
            setDimAmount(0.6f)

            // Width
            setLayout(
                requireContext().resources.displayMetrics.widthPixels - 100,
                WindowManager.LayoutParams.WRAP_CONTENT
            )

            setGravity(Gravity.CENTER)
        }
    }
}