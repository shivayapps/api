package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Point
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.os.Environment
import android.text.format.Formatter
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import com.google.common.base.Strings.commonPrefix
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogAlbumDeatilsBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isVideoFast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PhotosDetailsDialog(
    private val paths: List<String>,
) : DialogFragment() {

    private var _binding: DialogAlbumDeatilsBinding? = null
    private val binding get() = _binding!!

    var positiveBtnClickListener: ((renameFile: File, oldFile: File) -> Unit)? = null

    private lateinit var safeContext: Context

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext(), theme)
        _binding = DialogAlbumDeatilsBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        intView()
        clickListener()
        return dialog
    }

    @SuppressLint("SetTextI18n")
    private fun intView() {

        if (paths.isEmpty()) {
            dismiss()
            return
        }

        val files = paths.mapNotNull { path ->
            val file = File(path)
            if (file.exists()) file else null
        }

        if (files.isEmpty()) {
            dismiss()
            return
        }

        if (files.size == 1) {
            val file = files.first()

            binding.txtName.text = file.name
            if (file.parent.startsWith(Environment.getExternalStorageDirectory().absolutePath)) {
                binding.txtPath.text = file.parent
                binding.llPath.beVisible()
            } else {
                binding.llPath.beGone()
            }

            binding.txtTime.text = SimpleDateFormat("dd/MM/yyyy, hh:mm aa", Locale.ENGLISH).format(Date(file.lastModified()))
            val path = file.absolutePath
            val size = if (path.isVideoFast()) {
                path.getVideoResolution()
            } else {
                path.getImageResolution()
            }
            binding.txtResolution.text = "${size.x} x ${size.y}"
        } else {
            binding.llFileName.beGone()
            binding.llResolution.beGone()
            binding.llFileTime.beGone()
            val isPathShow = paths.any { it.startsWith(Environment.getExternalStorageDirectory().absolutePath) }
            if (isPathShow) {
                binding.txtPath.text = commonPrefix(paths)
                binding.llPath.beVisible()
            } else {
                binding.llPath.beGone()
            }
        }

        binding.txtSize.text = Formatter.formatShortFileSize(
            requireContext(),
            files.sumOf { it.length() }
        )

        binding.txtFileCount.text = paths.size.toString()
    }

    fun commonPrefix(paths: List<String>): String {
        if (paths.isEmpty()) return ""

        var prefix = paths.first()

        for (i in 1 until paths.size) {
            prefix = commonPrefix(prefix, paths[i])
            if (prefix.isEmpty()) break
        }

        return prefix
    }

    private fun clickListener() {
        binding.btnOK.setOnClickListener {
            dismiss()
        }
    }

    private fun String.getImageResolution(): Point {
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(this, options)

        val width = options.outWidth
        val height = options.outHeight
        return if (width > 0 && height > 0) {
            Point(options.outWidth, options.outHeight)
        } else {
            Point(0, 0)
        }
    }

    private fun String.getVideoResolution(): Point {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this)

            val width = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toInt() ?: 0

            val height = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toInt() ?: 0

            return Point(width, height)
        } finally {
            retriever.release()
        }
    }
}