package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.data.model.MemoriesMusicModel
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemMemoriesToneBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible

class MemoriesToneAdapter(
    private var selectedTonePath: Int,
    private val onToneClick: (MemoriesMusicModel) -> Unit,
) : RecyclerView.Adapter<MemoriesToneAdapter.ToneViewHolder>() {

    private val toneList = ArrayList<MemoriesMusicModel>()

    fun submitList(list: ArrayList<MemoriesMusicModel>) {
        toneList.clear()
        toneList.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ToneViewHolder {
        val binding = ItemMemoriesToneBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ToneViewHolder(binding)
    }

    override fun getItemCount(): Int = toneList.size

    override fun onBindViewHolder(holder: ToneViewHolder, position: Int) {
        holder.bind(toneList[position])
    }

    inner class ToneViewHolder(private val binding: ItemMemoriesToneBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: MemoriesMusicModel) {

            binding.txtSongName.text = item.fileName
            binding.txtSongDetails.text =
                "${item.duration} | ${item.fileSize} | ${item.fileRate}"

            val inputStream = binding.root.context.assets.open(item.imagePath)
            val drawable = Drawable.createFromStream(inputStream, null)
            binding.tvSongCover.setImageDrawable(drawable)

            if (item.filePath == selectedTonePath) {
                binding.tvSelected.beVisible()
                binding.lottieMusic.beVisible()
//                binding.tvSongCover.beGone()

                binding.root.background =
                    ContextCompat.getDrawable(binding.root.context, R.drawable.bg_corner)
                binding.root.backgroundTintList =
                    ColorStateList.valueOf(Color.parseColor("#F3F7FF"))

                binding.tvSongCover.setColorFilter(
                    Color.parseColor("#80000000"),
                    PorterDuff.Mode.SRC_ATOP
                )
                binding.txtSongName.setTextColor(Color.parseColor("#262626"))

            } else {
//                binding.root.backgroundTintList =
//                    ColorStateList.valueOf(Color.parseColor("#80F3F3F3"))
                binding.txtSongName.setTextColor(ContextCompat.getColor(binding.txtSongName.context, R.color.color_text))
                binding.root.setBackgroundColor(Color.TRANSPARENT)
                binding.tvSelected.beGone()
                binding.lottieMusic.beGone()
                binding.tvSongCover.beVisible()
            }

            binding.root.setOnClickListener {

                val previousTone = selectedTonePath
                selectedTonePath = item.filePath

                // refresh whole list (simple & safe)
                notifyDataSetChanged()

                onToneClick.invoke(item)
            }
        }
    }
}
