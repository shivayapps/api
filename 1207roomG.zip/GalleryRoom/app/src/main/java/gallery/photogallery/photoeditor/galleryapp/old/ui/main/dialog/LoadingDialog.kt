package gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import gallery.photogallery.photoeditor.galleryapp.databinding.LoadingDialogBinding

class LoadingDialog(
    activity: Activity
) : Dialog(activity) {
    var binding: LoadingDialogBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.CENTER)
        binding = LoadingDialogBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        window?.setLayout(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        setCancelable(false)
    }

    fun setMessage(message: String) {
        if (message.isNotEmpty()) {
            binding?.tvTitle?.text = message
        }
    }
}