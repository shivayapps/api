package gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory

import androidx.annotation.Keep

@Keep
data class MusicModel(val filePath: String, val fileName: String, val duration: String, val fileSize: String, val fileRate: String, val isStatic: Boolean = true)
//
//class MusicAdaptor(val context: Context, val withMediaModel: MemoryWithMedia, val list: List<MusicModel>, val onAddClick: (MusicModel) -> Unit) : RecyclerView.Adapter<MusicAdaptor.ViewHolder>() {
//    private var mediaPlayer: MediaPlayer? = null
//    var lastPlayPosition = -1
//
//    inner class ViewHolder(val binding: ItemMemoryMusicBinding) : RecyclerView.ViewHolder(binding.root)
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
//        return ViewHolder(ItemMemoryMusicBinding.inflate(LayoutInflater.from(parent.context), parent, false))
//    }
//
//    override fun getItemCount() = list.size
//
//    @SuppressLint("SetTextI18n")
//    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        val musicModel = list[position]
//        holder.binding.tvTitle.text = musicModel.fileName
//        holder.binding.tvTitle2.text = "${musicModel.duration} | ${musicModel.fileSize} | ${musicModel.fileRate}"
//        holder.binding.ivSelect.setImageResource(R.drawable.ic_music_add)
//        if (musicModel.filePath == withMediaModel.memory.music) {
//            holder.binding.ivSelect.setImageResource(R.drawable.ic_music_check)
//        }
//        if (lastPlayPosition == position) {
//            holder.binding.tvTitle.setTextColor(ContextCompat.getColor(context, R.color.color_primary))
//            holder.binding.ivMusic.beGone()
//            holder.binding.ivMusicPlay.beVisible()
//        } else {
//            holder.binding.tvTitle.setTextColor(ContextCompat.getColor(context, R.color.black_text))
//            holder.binding.ivMusic.beVisible()
//            holder.binding.ivMusicPlay.beGone()
//        }
//        holder.binding.ivSelect.setOnClickListener {
//            releaseMediaPlayer()
//            onAddClick.invoke(musicModel)
//        }
//        holder.binding.llMain.setOnClickListener {
//            lastPlayPosition = position
//            notifyDataSetChanged()
//            playMusic(musicModel)
//        }
//    }
//
//    fun playMusic(musicModel: MusicModel) {
//        releaseMediaPlayer()
//        if (musicModel.isStatic) {
//            mediaPlayer = MediaPlayer.create(context, getMusicResource(musicModel)).apply {
//                start()                // Start playback
//            }
//        } else {
//            val filePath = musicModel.filePath
//            if (File(filePath).exists()) {
//                mediaPlayer = MediaPlayer().apply {
//                    setDataSource(filePath) // Set the file path
//                    prepare()              // Prepare the MediaPlayer
//                    start()                // Start playback
//                }
//            }
//        }
//    }
//
//    fun releaseMediaPlayer() {
//        mediaPlayer?.stop()
//        mediaPlayer?.release()
//        mediaPlayer = null
//    }
//
//    private fun getMusicResource(musicModel: MusicModel): Int {
//        return when (musicModel.filePath) {
//            "tone_1" -> R.raw.tone_1
//            "tone_2" -> R.raw.tone_2
//            "tone_3" -> R.raw.tone_3
//            "tone_4" -> R.raw.tone_4
//            "tone_5" -> R.raw.tone_5
//            "tone_6" -> R.raw.tone_6
//            "tone_7" -> R.raw.tone_7
//            "tone_8" -> R.raw.tone_8
//            "tone_9" -> R.raw.tone_9
//            "tone_10" -> R.raw.tone_10
//            "tone_11" -> R.raw.tone_11
//            "tone_12" -> R.raw.tone_12
//            else -> R.raw.tone_1
//        }
//
//    }
//}