package gallery.photogallery.photoeditor.galleryapp.extentions

import android.content.Context
import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.os.Build
import android.os.Parcelable
import android.util.Log
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.TextView
import androidx.annotation.ColorRes
import androidx.annotation.FontRes
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.isGone
import androidx.core.view.isVisible
import com.google.gson.GsonBuilder
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import java.util.Calendar
import java.util.Date
import java.util.Locale

fun Context.formatSize(bytes: Long): String {
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0

    return when {
        gb >= 1 -> String.format(Locale.ENGLISH, "%.2f GB", gb)
        mb >= 1 -> String.format(Locale.ENGLISH, "%.2f MB", mb)
        kb >= 1 -> String.format(Locale.ENGLISH, "%.2f KB", kb)
        else -> "$bytes B"
    }
}

fun TextView.setColor(
    @ColorRes colorRes: Int,
) {
    setTextColor(ContextCompat.getColor(context, colorRes))
}


fun TextView.setFont(
    @FontRes fontRes: Int,
) {
    typeface = ResourcesCompat.getFont(context, fontRes)
}

fun Context.logJson(tag: String, obj: Any) {
    val json = GsonBuilder().setPrettyPrinting().create().toJson(obj)
    json.chunked(3000).forEachIndexed { index, chunk ->
        Log.e(tag, "Part ${index + 1}: $chunk")
    }
}

fun Long.toRelativeDate(): String {
    val calendar = Calendar.getInstance()
    val todayStart = calendar.apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    val yesterdayStart = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, -1)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    return when {
        this >= todayStart -> "Today"
        this >= yesterdayStart -> "Yesterday"
        else -> SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault()).format(Date(this))
    }
}


fun View.fadeIn() {
    if (isVisible) return
    alpha = 0f
    translationY = 20f
    beVisible()
    animate()
        .alpha(1f)
        .translationY(0f)
        .setDuration(250)
        .setInterpolator(DecelerateInterpolator())
        .start()
}

fun View.fadeOut(onEnd: (() -> Unit)? = null) {
    if (isGone) return
    animate()
        .alpha(0f)
        .translationY(20f)
        .setDuration(200)
        .setInterpolator(AccelerateInterpolator())
        .withEndAction {
            beGone()
            onEnd?.invoke()
        }
        .start()
}


inline fun <reified T : Parcelable> Intent.getParcelable(key: String): T? {
    return try {
        if (extras != null) {
            extras?.classLoader = T::class.java.classLoader
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getParcelableExtra(key, T::class.java)
        } else {
            @Suppress("DEPRECATION")
            getParcelableExtra(key) as? T
        }
    } catch (e: Exception) {
        Log.e("IntentExt", "Failed to getParcelable for key=$key: ${e.localizedMessage}", e)
        null
    }
}

fun Context.getAppVersion(): String {
    return try {
        val pInfo = packageManager.getPackageInfo(packageName, 0)
        pInfo.versionName ?: "Unknown"
    } catch (_: Exception) {
        "Unknown"
    }
}

fun Int.dpToPx(context: Context): Int {
    return (this * context.resources.displayMetrics.density).toInt()
}
