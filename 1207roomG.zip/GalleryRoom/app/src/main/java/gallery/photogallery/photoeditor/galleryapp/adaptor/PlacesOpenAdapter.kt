package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.appblish.gallery.core.v2.api.model.PlacesMediaListItem
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.activities.NewImageViewerActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemHeaderDividerBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.PhotoItemGridBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf


class PlacesOpenAdapter(val baseActivity: BaseActivity) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    val currentList = ArrayList<PlacesMediaListItem>()
    val selectedItems = HashSet<PlacesMediaListItem.Media>()

    fun submitList(list: List<PlacesMediaListItem>) {
        currentList.clear()
        currentList.addAll(list)
        notifyDataSetChanged()
    }

    companion object {
        const val HEADER = 0
        const val MEDIA = 1
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): RecyclerView.ViewHolder {
        return when (viewType) {
            HEADER -> {
                val binding = ItemHeaderDividerBinding.inflate(
                    LayoutInflater.from(parent.context), parent, false
                )
                HeaderViewHolder(binding)
            }

            else -> {
                val binding = PhotoItemGridBinding.inflate(
                    LayoutInflater.from(parent.context), parent, false
                )
                MediaViewHolder(binding)
            }
        }
    }

    override fun onBindViewHolder(
        holder: RecyclerView.ViewHolder,
        position: Int,
    ) {
        when (val item = currentList[position]) {
            is PlacesMediaListItem.Header -> (holder as HeaderViewHolder).bind(item)
            is PlacesMediaListItem.Media -> (holder as MediaViewHolder).bind(item)
        }
    }


    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        if (holder is MediaViewHolder) {
            Glide.with(holder.binding.mediumThumbnail.context).clear(holder.binding.mediumThumbnail)
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (currentList[position]) {
            is PlacesMediaListItem.Header -> HEADER
            is PlacesMediaListItem.Media -> MEDIA
        }
    }

    override fun getItemCount(): Int {
        return currentList.size
    }

    class HeaderViewHolder(private val binding: ItemHeaderDividerBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(header: PlacesMediaListItem.Header) {
            binding.txtHeader.text = header.header
        }
    }

    inner class MediaViewHolder(val binding: PhotoItemGridBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: PlacesMediaListItem.Media) {
            val media = item.mediaModel.mediaBox
            itemView.tag = media

            binding.mediumThumbnail.loadGridImage(
                media.mediaPath,
                media.mediaDate
            )

            binding.icFavourite.beVisibleIf(item.mediaModel.isFavourite)
            binding.icVideo.beVisibleIf(media.isVideoCheck())
            binding.root.transitionName = media.mediaPath
            itemView.setOnClickListener {
                val mediaListPaths = currentList.filterIsInstance<PlacesMediaListItem.Media>().map { it.mediaModel.mediaBox.mediaPath }
                baseActivity.sharedViewModel.imageViewerList.clear()
                baseActivity.sharedViewModel.imageViewerList.addAll(mediaListPaths)
                val startPosition = mediaListPaths.indexOf(item.mediaModel.mediaBox.mediaPath)
                baseActivity.startActivity(Intent(baseActivity, NewImageViewerActivity::class.java).apply {
                    putExtra("startPosition", startPosition)
                })
            }
        }
    }
}

