package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.util.toAlbumId
import com.appblish.gallery.core.v2.api.model.FolderWithMedia
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import com.appblish.recyclerview.dragselection.BaseSelectableAdapter
import com.appblish.recyclerview.dragselection.DragSelectionMode
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemAlbumGridBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isVideoFast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.lastClickTS
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.CLICK_HOLD

class HiddenAlbumMediaAdapter(
    recyclerView: RecyclerView,
    val onFileClick: (FolderWithMedia) -> Unit
) : BaseSelectableAdapter<FolderWithMedia, RecyclerView.ViewHolder>(recyclerView, DragSelectionMode.RANGE) {

    private val medias = mutableListOf<FolderWithMedia>()
    fun submitList(list: List<FolderWithMedia>) {
        medias.clear()
        medias.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding =
            ItemAlbumGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PictureViewHolder(binding)
    }

    override fun getItemAt(position: Int): FolderWithMedia? {
        return medias.getOrNull(position)
    }

    override fun getItemKey(item: FolderWithMedia): Long {
        return item.folderPath.toAlbumId()
    }

    override fun isSelectable(item: FolderWithMedia): Boolean {
        return true
    }

    override fun isHeader(position: Int): Boolean {
        return false
    }

    override fun isSelectionEnabled(): Boolean {
        return true
    }

    override fun bindItem(holder: RecyclerView.ViewHolder, item: FolderWithMedia, position: Int) {
        val pictureViewHolder = holder as PictureViewHolder
        pictureViewHolder.bind(medias[position])
    }

    override fun bindSelection(holder: RecyclerView.ViewHolder, item: FolderWithMedia, position: Int, selected: Boolean) {
        val pictureViewHolder = holder as PictureViewHolder
        if (isSelectionActive()) {
            pictureViewHolder.binding.icUnSelect.visibility = View.VISIBLE
            pictureViewHolder.binding.icSelect.visibility = if (selected) View.VISIBLE else View.GONE
        } else {
            pictureViewHolder.binding.icUnSelect.visibility = View.GONE
            pictureViewHolder.binding.icSelect.visibility = View.GONE
        }
    }

    override fun onItemOpen(item: FolderWithMedia, position: Int, view: View) {
        if (System.currentTimeMillis() - lastClickTS > CLICK_HOLD) {
            lastClickTS = System.currentTimeMillis()
            onFileClick.invoke(item)
        }
    }

    override fun onSelectionModeUpdate() {
        notifyDataSetChanged()
    }


    override fun getItemCount(): Int {
        return medias.size
    }

    fun selectAll() {
        selectAllItems()
    }

    fun unSelectAll() {
        unselectAllItems()
    }

    fun isSelectAll() = isAllSelectedItems()


    inner class PictureViewHolder(var binding: ItemAlbumGridBinding) :
        RecyclerView.ViewHolder(binding.root) {
        @SuppressLint("SetTextI18n")
        fun bind(folderWithMedia: FolderWithMedia) {
            val file = folderWithMedia.mediaFiles.first()
            val path = file.absolutePath
            binding.imageAlbum.loadGridImage(path, file.lastModified())
            binding.txtTitle.text = folderWithMedia.folderName
            binding.txtCount.text = "${folderWithMedia.mediaFiles.size} ${binding.root.context.getString(R.string.items)}"

            try {
                binding.ivGif.beVisibleIf(
                    path.endsWith(
                        "gif", true
                    )
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }

            if (path.isVideoFast()) {
                binding.icVideo.visibility = View.VISIBLE
            } else {
                binding.icVideo.visibility = View.GONE
            }
            if (isSelectionActive()) {
                binding.icUnSelect.visibility = View.VISIBLE
                binding.icSelect.visibility = if (isItemSelected(bindingAdapterPosition)) View.VISIBLE else View.GONE
            } else {
                binding.icUnSelect.visibility = View.GONE
                binding.icSelect.visibility = View.GONE
            }
        }
    }

}