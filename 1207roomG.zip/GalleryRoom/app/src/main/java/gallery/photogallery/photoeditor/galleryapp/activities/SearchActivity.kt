package gallery.photogallery.photoeditor.galleryapp.activities

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.inputmethod.InputMethodManager
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.util.AppblishEvent
import com.appblish.box.api.util.MediaDataState
import com.appblish.gallery.core.v2.api.model.MediaModel
import com.appblish.gallery.core.v2.api.model.PlaceListItem
import com.appblish.gallery.core.v2.api.model.TimeLineAlbumModel
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.adaptor.SearchMediaListAdaptor
import gallery.photogallery.photoeditor.galleryapp.adaptor.SearchPlacesAdaptor
import gallery.photogallery.photoeditor.galleryapp.adaptor.SearchTimelineAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivitySearchBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGoneIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.ExtraAlbumActivity
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class SearchActivity : BaseActivity() {
    companion object {
        fun createIntent(context: Context): Intent {
            return Intent(context, SearchActivity::class.java)
        }
    }

    private val binding by viewBinding(ActivitySearchBinding::inflate)

    private val searchPlacesAdaptor by lazy { SearchPlacesAdaptor(this, ::onPlaceClick) }
    private val searchTimelineAdapter by lazy { SearchTimelineAdapter(this, ::onTimelineClick) }
    private val searchMediaAdapter by lazy { SearchMediaListAdaptor(this) }

    private val searchHandle = Handler(Looper.getMainLooper())
    private val searchRunnable = Runnable {
        search()
    }

    val placesList = ArrayList<PlaceListItem>()
    val timeLineList = ArrayList<TimeLineAlbumModel>()

    private var mediaJob: Job? = null
    private var placeJob: Job? = null
    private var timelineJob: Job? = null

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.root.setPadding(0, 0, 0, navigationBarHeight)
        binding.mainContainer.setPadding(0, statusBarHeight, 0, 0)
        registerEventBus(this)
        showKeyboard()
        observablePlaces()
        observableTimeLine()
        setListeners()
    }

    private fun observableTimeLine() {
        lifecycleScope.launch {
            when (val state = sharedViewModel.getTimelineFlow()) {
                MediaDataState.Empty -> {
                    timeLineList.clear()
                    setTimeLineAlbum(emptyList())
                }

                MediaDataState.Loading -> {

                }

                is MediaDataState.Success -> {
                    timeLineList.clear()
                    timeLineList.addAll(state.data)
                    if (timeLineList.size > 10) {
                        setTimeLineAlbum(timeLineList.take(10))
                    } else {
                        setTimeLineAlbum(timeLineList)
                    }
                }

                is MediaDataState.Progress -> {}
            }
        }
    }

    private fun setTimeLineAlbum(realAlbumModels: List<TimeLineAlbumModel>) {
        if (binding.timeLineRecycler.adapter == null) {
            binding.timeLineRecycler.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
            binding.timeLineRecycler.adapter = searchTimelineAdapter
        }
        binding.llTimeLine.beGoneIf(realAlbumModels.isEmpty())
        searchTimelineAdapter.saveData(realAlbumModels)
        binding.txtAllTimeLine.setOnClickListener {
            startActivity(ExtraAlbumActivity.createTimeLineIntent(this, getString(R.string.time)))
        }
    }

    private fun observablePlaces() {
        lifecycleScope.launch {
            when (val state = sharedViewModel.getPlacesFlow()) {
                is MediaDataState.Empty -> {
                    placesList.clear()
                    setPlacesAlbum(emptyList())
                }

                is MediaDataState.Loading -> {

                }

                is MediaDataState.Success -> {
                    placesList.clear()
                    placesList.addAll(state.data)
                    if (placesList.size > 10) {
                        setPlacesAlbum(placesList.take(10))
                    } else {
                        setPlacesAlbum(placesList)
                    }
                }

                else -> {}
            }
        }
    }

    private fun setPlacesAlbum(placesAlbums: List<PlaceListItem>) {
        binding.llPlaces.beGoneIf(placesAlbums.isEmpty())

        Log.e("setPlacesAlbum", "fetchPlaces: placesAlbums ${placesAlbums.size}")
        if (placesAlbums.isNotEmpty()) {
            if (binding.placesRecycler.adapter == null) {
                binding.placesRecycler.layoutManager = LinearLayoutManager(this@SearchActivity, RecyclerView.HORIZONTAL, false)
                binding.placesRecycler.adapter = searchPlacesAdaptor
            }
            searchPlacesAdaptor.saveData(placesAlbums)
            binding.txtAllPlaces.setOnClickListener {
                startActivity(ExtraAlbumActivity.createPlacesIntent(this@SearchActivity, getString(R.string.places)))
            }
        }
    }

    private fun setListeners() {
        binding.ivBack.setOnClickListener {
            onBackPressed()
        }
        binding.icSearchClear.setOnClickListener {
            binding.edtSearch.setText("")
        }
        binding.edtSearch.addTextChangedListener {
            binding.icSearchClear.beVisibleIf(binding.edtSearch.length() > 0)
            searchHandle.removeCallbacks(searchRunnable)
            searchHandle.postDelayed(searchRunnable, 500)
        }
    }

    private fun setPhotosData(pictures: List<MediaModel>) {
        binding.pictureRecycler.recycledViewPool.clear()
        if (binding.pictureRecycler.adapter == null) {
            binding.pictureRecycler.apply {
                val gridlayoutManager = GridLayoutManager(this@SearchActivity, appPref.mediaGrid)
                layoutManager = gridlayoutManager
                adapter = searchMediaAdapter
            }
        }
        binding.pictureRecycler.beVisibleIf(pictures.isNotEmpty())
        searchMediaAdapter.submitList(pictures)
        checkNoData()
    }

    fun checkNoData() {
        val noMedia = searchMediaAdapter.itemCount == 0
        val noPlaces = searchPlacesAdaptor.itemCount == 0
        val noTimeline = searchTimelineAdapter.itemCount == 0

        binding.loutNoData.beVisibleIf(noMedia && noPlaces && noTimeline && binding.edtSearch.text.isNotEmpty())
    }

    private fun onPlaceClick(placeListItem: PlaceListItem) {
        val intent = Intent(this, PlacesOpenActivity::class.java)
        intent.putExtra("placeTitle", placeListItem.title)
        startActivity(intent)
    }


    private fun onTimelineClick(timeLineAlbumModel: TimeLineAlbumModel) {
        val intent = Intent(this, TimelineExploreActivity::class.java)
        intent.putExtra("BUCKET_PATH", timeLineAlbumModel.title)
        intent.putExtra("BUCKET_SIZE", timeLineAlbumModel.mediaRows.size)
        startActivity(intent)

    }

    private fun search() {
        performSearch(binding.edtSearch.text.toString().trim())
    }

    fun performSearch(queryRaw: String) {
        val query = queryRaw.trim()
        if (query.isEmpty()) {
            setPhotosData(emptyList())
            setPlacesAlbum(placesList)
            setTimeLineAlbum(timeLineList)
            binding.loutNoData.beGone()

            return
        }

        val queryLower = query.lowercase() // ✅ compute once

        mediaJob?.cancel()
        placeJob?.cancel()
        timelineJob?.cancel()

        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                sharedViewModel.fetchSearch(queryLower) {
                    val result = it
                    runOnUiThread {
                        setPhotosData(result)
                    }
                }
            }
        }

        // ⚡ PLACES SEARCH
        placeJob = lifecycleScope.launch(Dispatchers.Default) {
            val result = sharedViewModel.searchPlaces(queryLower)

            withContext(Dispatchers.Main.immediate) {
                setPlacesAlbum(result)
                checkNoData()
            }
        }

        // ⚡ TIMELINE SEARCH
        timelineJob = lifecycleScope.launch(Dispatchers.Default) {
            val result = sharedViewModel.searchTimeline(queryLower)

            withContext(Dispatchers.Main.immediate) {
                setTimeLineAlbum(result)
                checkNoData()
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            AppblishEvent.ALL_TIME_LINE_LOADED -> {
                observableTimeLine()
            }

            AppblishEvent.ALL_PLACES_LOADED -> {
                observablePlaces()
            }
        }
    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        hideKeyboard()
        finish()
    }

    override fun onResume() {
        super.onResume()
        search()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterEventBus(this)
    }

    private fun showKeyboard() {
        binding.edtSearch.requestFocus()
        val methodManager = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(binding.edtSearch, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard() {
        binding.edtSearch.clearFocus()
        val methodManager = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(binding.edtSearch.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }
}