package gallery.photogallery.photoeditor.galleryapp.dialogs


import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import com.appblish.box.api.model.MediaSortType
import com.appblish.box.api.model.SortOrder
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogAlbumSortingBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity

class SortByMediaDialog(private val updateListener: (() -> Unit)?) : DialogFragment() {
    private var _binding: DialogAlbumSortingBinding? = null
    private val binding get() = _binding!!
    private val baseActivity: BaseActivity
        get() = requireActivity() as BaseActivity


    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogAlbumSortingBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(R.color.transparent)
            setLayout(baseActivity.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        initView()
        clickListener()

        return dialog
    }

    private fun initView() {
        when (baseActivity.sharedViewModel.getMediaSortType()) {
            MediaSortType.NAME -> binding.rbName.isChecked = true
            MediaSortType.PATH -> binding.rbPath.isChecked = true
            MediaSortType.SIZE -> binding.rbSize.isChecked = true
            MediaSortType.LAST_MODIFIED -> binding.rbLastModified.isChecked = true
        }
        when (baseActivity.sharedViewModel.getMediaSortOrder()) {
            SortOrder.ASCENDING -> binding.rbAscending.isChecked = true
            SortOrder.DESCENDING -> binding.rbDescending.isChecked = true
        }
    }

    private fun clickListener() {
        binding.btnCancel.setOnClickListener {
            dismiss()
        }
        binding.btnOK.setOnClickListener {
            val selectedRadioButtonId: Int = binding.grpOption.checkedRadioButtonId
            val selectedRadioButtonIdOrder: Int = binding.grpOrder.checkedRadioButtonId
            val mediaSortType = when (selectedRadioButtonId) {
                binding.rbName.id -> MediaSortType.NAME
                binding.rbPath.id -> MediaSortType.PATH
                binding.rbSize.id -> MediaSortType.SIZE
                binding.rbLastModified.id -> MediaSortType.LAST_MODIFIED
                else -> MediaSortType.NAME
            }
            baseActivity.sharedViewModel.setMediaSortType(mediaSortType)

            val sortOrder = when (selectedRadioButtonIdOrder) {
                binding.rbAscending.id -> SortOrder.ASCENDING
                binding.rbDescending.id -> SortOrder.DESCENDING
                else -> SortOrder.DESCENDING
            }
            baseActivity.sharedViewModel.setMediaSortOrder(sortOrder)

            dismiss()
            updateListener?.invoke()
        }
    }
}