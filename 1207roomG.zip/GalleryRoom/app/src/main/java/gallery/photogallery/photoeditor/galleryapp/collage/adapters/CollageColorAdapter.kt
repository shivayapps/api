package gallery.photogallery.photoeditor.galleryapp.collage.adapters

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
 import androidx.recyclerview.widget.RecyclerView
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemBackgroundBinding

class CollageColorAdapter(
    private val context: Context,
    private val colors: List<String>,
    private val onColorSelected: (index: Int, colorInt: Int) -> Unit
) : RecyclerView.Adapter<CollageColorAdapter.ViewHolder>() {

    private var selectedIndex = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemBackgroundBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(position)
    }

    override fun getItemCount(): Int = colors.size

    inner class ViewHolder(
        private val binding: ItemBackgroundBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(position: Int) = with(binding) {

            val colorInt = Color.parseColor(colors[position])

            // Show color view only
            squareView.visibility = View.GONE
            imageViewSquare.visibility = View.VISIBLE
            imageViewSquare.setBackgroundColor(colorInt)

            if (position==0){
                viewSelected.visibility = View.VISIBLE
                if (selectedIndex == position){
                    viewSelected.setImageResource(R.drawable.primary_border3)
                }else{
                    viewSelected.setImageResource(R.drawable.gray_border3)

                }
            }else{
                viewSelected.visibility =
                    if (selectedIndex == position) View.VISIBLE else View.GONE
            }


            root.setOnClickListener {
                val pos = adapterPosition
                if (pos == RecyclerView.NO_POSITION) return@setOnClickListener

                val oldIndex = selectedIndex
                selectedIndex = pos

                onColorSelected(pos, Color.parseColor(colors[pos]))

                notifyItemChanged(oldIndex)
                notifyItemChanged(pos)
            }
        }
    }

    fun setSelectedIndex(index: Int) {
        val oldIndex = selectedIndex
        selectedIndex = index
        notifyItemChanged(oldIndex)
        notifyItemChanged(index)
    }
}
