package gallery.photogallery.photoeditor.galleryapp.old.ui.main.event

import org.greenrobot.eventbus.EventBus


data class OperationEvent(val type: String, val data: Any? = null)


const val PROGRESS_MEDIA_OPERATION = "PROGRESS_MEDIA_OPERATION"
const val DONE_MEDIA_OPERATION = "DONE_MEDIA_OPERATION"
const val REPLACE_MEDIA_OPERATION = "REPLACE_MEDIA_OPERATION"
fun sendOperationEvent(type: String, data: Any? = null) {
    EventBus.getDefault().post(OperationEvent(type, data))
}


