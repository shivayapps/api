package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation1

import android.view.View
import androidx.viewpager.widget.ViewPager

class DefaultPageTransformer :
    ViewPager.PageTransformer {
    override fun transformPage(view: View, position: Float) {}
}
