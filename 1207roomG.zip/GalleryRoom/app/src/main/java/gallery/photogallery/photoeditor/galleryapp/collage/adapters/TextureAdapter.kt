package gallery.photogallery.photoeditor.galleryapp.collage.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import gallery.photogallery.photoeditor.galleryapp.collage.utils.PickerItem
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemTextureBinding

class TextureAdapter(
    private val items: List<PickerItem>,
    private val onItemClick: (position: Int, item: PickerItem.Texture) -> Unit
) : RecyclerView.Adapter<TextureAdapter.TextureViewHolder>() {

    private var selectedPosition = RecyclerView.NO_POSITION

    inner class TextureViewHolder(
        val binding: ItemTextureBinding
    ) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TextureViewHolder {
        val binding = ItemTextureBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return TextureViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TextureViewHolder, position: Int) {
        val item = items[position] as PickerItem.Texture

        with(holder.binding) {
            ivTexture.setImageDrawable(item.drawable)

            viewSelected.visibility =
                if (selectedPosition == position) View.VISIBLE else View.INVISIBLE

            root.setOnClickListener {
                val oldPos = selectedPosition
                selectedPosition = position

                if (oldPos != RecyclerView.NO_POSITION) {
                    notifyItemChanged(oldPos)
                }
                notifyItemChanged(selectedPosition)

                onItemClick(position, item)
            }
        }
    }

    override fun getItemCount(): Int = items.size
}
