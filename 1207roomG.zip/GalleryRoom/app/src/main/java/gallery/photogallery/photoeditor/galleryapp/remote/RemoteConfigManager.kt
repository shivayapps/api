package gallery.photogallery.photoeditor.galleryapp.remote

import android.app.Application
import android.util.Log
import com.appblish.story.memories.api.core.MemorySDK
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.clientConfigPref

object RemoteConfigManager {
    fun fireBaseConfigGet(myApp: Application) {
        try {
            val remoteConfig = FirebaseRemoteConfig.getInstance()
            remoteConfig.reset()
            remoteConfig.setConfigSettingsAsync(
                FirebaseRemoteConfigSettings.Builder()
                    .setMinimumFetchIntervalInSeconds(0)
                    .setFetchTimeoutInSeconds(10)
                    .build()
            )
            remoteConfig.fetchAndActivate()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {

                        setClintConfig(myApp, remoteConfig)
                    }
                }
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    fun firebaseFirstTime(myApp: Application, callback: () -> Unit) {
        try {
            val remoteConfig = FirebaseRemoteConfig.getInstance()
            val configSettings = FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(0) // Force fetch every time
                .build()
            remoteConfig.setConfigSettingsAsync(configSettings)
            remoteConfig.fetchAndActivate()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        setClintConfig(myApp, remoteConfig)
                        callback.invoke()
                    } else {
                        callback.invoke()
                    }

                }

        } catch (e: java.lang.Exception) {
            e.printStackTrace()
            callback.invoke()
        }
    }

    private fun setClintConfig(myApp: Application, remoteConfig: FirebaseRemoteConfig) {
        try {

            val appDefaultConfig = remoteConfig.getString("app_default_config")
            if (appDefaultConfig.isNotEmpty())
                myApp.clientConfigPref.appDefaultConfig = appDefaultConfig

            val moreApps = remoteConfig.getString("moreApps")
            if (moreApps.isNotEmpty())
                myApp.clientConfigPref.moreApps = moreApps

            val appUpdate = remoteConfig.getString("appUpdate")
            if (appUpdate.isNotEmpty())
                myApp.clientConfigPref.appUpdate = appUpdate

            Log.d("RemoteConfigManager", "setClintConfig: adIdsTest ${myApp.clientConfigPref.appDefaultConfig}")

            val appMemoryCategory = remoteConfig.getString("appMemoryCategory")
            Log.d("RemoteConfigManager", "setClintConfig: appMemoryCategory ${appMemoryCategory}")
            if (appMemoryCategory.isNotEmpty())
                MemorySDK.get().initMemoryCategoryRemote(appMemoryCategory)

            val appMemoryConfig = remoteConfig.getString("appMemoryConfig")
            Log.d("RemoteConfigManager", "setClintConfig: appMemoryConfig ${appMemoryConfig}")
            if (appMemoryConfig.isNotEmpty()) {
                MemorySDK.get().saveConfig(appMemoryConfig)
            }

            val appCategories = remoteConfig.getString("appCategories")
            Log.d("RemoteConfigManager", "setClintConfig: appCategories ${appCategories}")

            if (appCategories.isNotEmpty())
                insertCategory(myApp, appCategories)

            AppRedirectionConfig.getAppRedirectionConfig(myApp, remoteConfig)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private fun insertCategory(myApp: Application, appCategories: String) {
        /* CoroutineScope(Dispatchers.IO).launch {
             try {
                 val entities: List<CategoryRemoteEntity> = parseCategoriesFast2(appCategories)
                 val db = GalleryMediaDatabase.getInstance(myApp)
                 val categoryDao = db.CategoryDao()
                 categoryDao.insertAll(entities)
                 Log.d("RemoteConfigManager", "setClintConfig:insertCategory entities ${entities.size}")

             } catch (e: Exception) {
                 e.printStackTrace()
                 Log.d("RemoteConfigManager", "setClintConfig:insertCategory ${e.message}")
             }
         }*/
    }

}