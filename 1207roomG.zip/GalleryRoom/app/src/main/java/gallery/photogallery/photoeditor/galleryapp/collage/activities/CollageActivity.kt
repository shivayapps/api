package gallery.photogallery.photoeditor.galleryapp.collage.activities


import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.collagemaker.appblish.AppblishCollageText
import com.appblish.collagemaker.appblish.AppblishCollageTextView
import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout
import com.appblish.collagemaker.interfaces.AppblishCollageBlurCallback
import com.appblish.collagemaker.interfaces.AppblishCollageOnStickerOperationListener
import com.appblish.collagemaker.photofilters.imageprocessors.FilterThumbnailsManager
import com.appblish.collagemaker.sdk.AppblishEditorSdk
import com.appblish.collagemaker.sdk.AppblishSaveSdk
import com.appblish.collagemaker.sdk.AppblishTextSdk
import com.appblish.collagemaker.sticker.Sticker
import com.appblish.collagemaker.utils.AppblishCollageAspectRatio
import com.appblish.collagemaker.utils.AppblishCollageUtils
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.AspectAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.CollageBackgroundAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.CollageBlurAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.CollageColorAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.GridAdapter
import gallery.photogallery.photoeditor.galleryapp.collage.fragments.CropFragment
import gallery.photogallery.photoeditor.galleryapp.collage.fragments.FilterFragment
import gallery.photogallery.photoeditor.galleryapp.collage.fragments.TextFragment
import gallery.photogallery.photoeditor.galleryapp.collage.utils.CollageConst.getAllRatios
import gallery.photogallery.photoeditor.galleryapp.collage.utils.TextEditor
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityCollageBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.ConfirmationDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import kotlinx.coroutines.launch

class CollageActivity : BaseActivity() {
    lateinit var binding: ActivityCollageBinding
    var appblishLayout: AppblishCollageLayout? = null
    var aspectRatio: AppblishCollageAspectRatio? = null
    var borderRadius: Float = 0f
    var padding: Float = 0f
    var stringList: MutableList<String?>? = null
    private var deviceHeight = 0
    var deviceWidth: Int = 0
    var ratioText = ""
    var textEditor: TextEditor? = null
    var addTextFragment: TextFragment? = null

    var blurredBitmapSelect: Bitmap? = null
    private var resIdSelect: Int = 0
    private var colorIntSelect: Int = 0
    private var resIdSelectSave: Int = 0
    private var colorIntSelectSave: Int = 0
    private var backgroundResourceMode: Int = 0
    var blurredBitmapSelectSave: Bitmap? = null


    val onStickerOperationListener =
        object : AppblishCollageOnStickerOperationListener {

            override fun onStickerDrag(sticker: Sticker) {
            }

            override fun onStickerFlip(sticker: Sticker) {
            }

            override fun onStickerTouchedDown(sticker: Sticker) {
            }

            override fun onStickerZoom(sticker: Sticker) {
            }

            override fun onTouchDownBeauty(f: Float, f2: Float) {
            }

            override fun onTouchDragBeauty(f: Float, f2: Float) {
            }

            override fun onTouchUpBeauty(f: Float, f2: Float) {
            }

            override fun onAddSticker(sticker: Sticker) {
                // seekbarSticker.visibility = View.VISIBLE
                // seekbarSticker.progress = sticker.alpha
            }

            override fun onStickerSelected(sticker: Sticker) {
                // seekbarSticker.visibility = View.VISIBLE
                // seekbarSticker.progress = sticker.alpha
            }

            override fun onStickerDeleted(sticker: Sticker) {
                // seekbarSticker.visibility = View.GONE
            }

            override fun onStickerTouchOutside() {
                // seekbarSticker.visibility = View.GONE
            }

            override fun onStickerDoubleTap(sticker: Sticker) {
                if (sticker is AppblishCollageTextView) {
                    sticker.isShow = false
                    AppblishEditorSdk.setHandlingSticker(null)
                    Log.i("onStickerDoubleTap", "onStickerDoubleTap: " + (sticker as AppblishCollageTextView).polishText)
                    addTextFragment = TextFragment.Companion.show(this@CollageActivity, (sticker as AppblishCollageTextView).polishText)
                    textEditor = object : TextEditor {


                        override fun onBackButton() {
                            AppblishEditorSdk.showLastHandlingSticker()
                        }

                        override fun onDone(appblishText: AppblishCollageText) {
                            AppblishEditorSdk.getStickers().remove(AppblishEditorSdk.getLastHandlingSticker())
                            AppblishEditorSdk.addSticker(AppblishCollageTextView(this@CollageActivity, appblishText))

                        }
                    }
                    addTextFragment!!.setOnTextEditorListener(textEditor)
                }
            }

        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCollageBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        binding.root.setPadding(0, 0, 0, navigationBarHeight)
        binding.mainViewLinear.setPadding(0, statusBarHeight, 0, 0)

        setContentView(binding.root)
        AppblishEditorSdk.init(binding.collageView)
        // Get device dimensions
        deviceWidth = resources.displayMetrics.widthPixels
        deviceHeight = resources.displayMetrics.heightPixels

        // Receive selected image paths
        stringList = intent.getStringArrayListExtra("KEY_DATA_RESULT")
        setLoading(true)
        collageViewSet()
        adapterDataSet()
        onclickEvent()
        onSeekBarEvent()

        onBackPressedDispatcher.addCallback(this@CollageActivity) {

            // 1️⃣ If TextFragment is open
            if (addTextFragment != null && addTextFragment!!.isAdded) {
                supportFragmentManager.popBackStack()
                addTextFragment = null
                Log.i("onCreateBackPress", "addTextFragment: ")
                return@addCallback
            }

            // 2️⃣ If CropFragment is open
            val cropFragment =
                supportFragmentManager.findFragmentByTag("CropFragment")
            if (cropFragment != null) {
                Log.i("onCreateBackPress", "cropFragment: ")

                supportFragmentManager.popBackStack()
                return@addCallback
            }

            // 3️⃣ If FilterFragment is open
            val filterFragment =
                supportFragmentManager.findFragmentByTag("FilterFragment")
            if (filterFragment != null) {
                Log.i("onCreateBackPress", "filterFragment: ")

                supportFragmentManager.popBackStack()
                return@addCallback
            }

            Log.i(
                "onCreateBackPress",
                "onCreate: " + binding.constraintLayoutChangeBackground.isVisible + " " + binding.constraintLayoutChangeLayout.isVisible + " " + binding.constraintLayoutConfirmText.isVisible
            )
            // 4️⃣ If background/layout panels are open
            if (binding.constraintLayoutChangeBackground.visibility == View.VISIBLE ||
                binding.constraintLayoutChangeLayout.visibility == View.VISIBLE ||
                binding.recyclerViewToolsCollage.visibility == View.VISIBLE ||
                binding.constraintLayoutConfirmText.visibility == View.VISIBLE
            ) {
                closeAllPanels()
                return@addCallback
            }

            Log.i("onCreateBackPress", "finish: ")

            // 5️⃣ Nothing open → finish activity
            confirmDialog()
        }

    }

    private fun onSeekBarEvent() {

        AppblishEditorSdk.setCircleColor(
            Color.BLACK
        );

        // Padding seekbar
        binding.seekbarBorder.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                AppblishEditorSdk.setCollagePadding(progress.toFloat())
                binding.tvSeekbarPadding.text = progress.toString()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Radius seekbar
        binding.seekbarRadius.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                AppblishEditorSdk.setCollageRadian(progress.toFloat())
                binding.tvSeekbarRadius.text = progress.toString()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun collageViewSet() {

        AppblishEditorSdk.setAppInitializeList(stringList!!) { success ->
            if (success) {
                setLoading(false)
                Log.d("INIT", "Initialize success")
            } else {
                setLoading(false)
                Log.d("INIT", "Initialize failed")
            }
        }
//        AppblishEditorSdk.setAppInitializeList(stringList!!)


        // Enable interactions
        AppblishEditorSdk.setTouchEnable(true)
        AppblishEditorSdk.setNeedDrawLine(false)
        AppblishEditorSdk.setNeedDrawOuterLine(false)

        // Default collage styling
        AppblishEditorSdk.setLineSize(4)
        AppblishEditorSdk.setCollagePadding(6f)
        AppblishEditorSdk.setCollageRadian(15f)
        AppblishEditorSdk.setLineColor(ContextCompat.getColor(this, R.color.black))
        AppblishEditorSdk.setSelectedLineColor(ContextCompat.getColor(this, R.color.color_primary))
        AppblishEditorSdk.setHandleBarColor(ContextCompat.getColor(this, R.color.color_primary))
        AppblishEditorSdk.setAnimateDuration(300)


        // When a collage piece is selected
        AppblishEditorSdk.setOnAppblishSelectedListener { _, position ->
            binding.recyclerViewToolsCollage.visibility = View.VISIBLE
            binding.llBottomTools.visibility = View.GONE
            Log.i("Collage", "Selected position: $position")
        }

        // When unselected
        AppblishEditorSdk.setOnAppblishUnSelectedListener {
            binding.recyclerViewToolsCollage.visibility = View.GONE
            binding.llBottomTools.visibility = View.VISIBLE
        }


        AppblishEditorSdk.setOnStickerOperationListener(onStickerOperationListener);
    }

    private fun adapterDataSet() {
        // ---- Layout adapter ----
        val collageAdapter = GridAdapter()
        collageAdapter.onLayoutSelected = { layout, pos ->
            AppblishEditorSdk.updateLayout(pos, stringList!!)
        }

        binding.recyclerViewCollage.apply {
            layoutManager = LinearLayoutManager(this@CollageActivity, RecyclerView.HORIZONTAL, false)
            adapter = collageAdapter
        }

        collageAdapter.refreshData(
            AppblishCollageUtils.getCollageLayouts(stringList?.size ?: 0), emptyList()
        )


        val userRatioList = getAllRatios()

        // ---- Aspect ratio adapter ----
        ratioText = userRatioList[0].type.ratioText
        AppblishEditorSdk.setAspectRatio(userRatioList[0].type.ratioText)

        Log.i("adapterDataSet", "adapterDataSet: " + userRatioList[0].type.ratioText)

        val ratioAdapter = AspectAdapter(ratioList = userRatioList, includeFreeRatio = true) { aspect, ratioText ->
            AppblishEditorSdk.setAspectRatio(ratioText)
//            this.ratioText=ratioText

        }

        binding.recyclerViewRatio.apply {
            layoutManager = LinearLayoutManager(this@CollageActivity, RecyclerView.HORIZONTAL, false)
            adapter = ratioAdapter
        }

        // ---- Background Color adapter ----
        val colorList = AppblishEditorSdk.listColorBrush()

        val colorAdapter = CollageColorAdapter(
            context = this, colors = colorList
        ) { index, colorInt ->
            AppblishEditorSdk.setBackgroundColor(colorInt)
            colorIntSelect = colorInt
            backgroundResourceMode = 0
//            AppblishEditorSdk.setBackgroundResourceMode(0)
        }

        binding.recyclerViewColor.adapter = colorAdapter


        // ---- Gradient adapter ----
        val gradientAdapter = CollageBackgroundAdapter(AppblishEditorSdk.getGradientDrawables(this)) { pos, resId ->
            AppblishEditorSdk.setBackgroundResorce(resId)
            resIdSelect = resId
            backgroundResourceMode = 1
//            AppblishEditorSdk.setBackgroundResourceMode(1)
//            AppblishEditorSdk.invalidate()
        }
        binding.recyclerViewGradient.adapter = gradientAdapter


    }

    private fun onclickEvent() {

        binding.llFilter.setOnClickListener {
            loadFilterBitmapForCurrentPiece()
        }

        binding.imageViewCloseText.setOnClickListener {
            binding.constraintLayoutConfirmText.visibility = View.GONE
            binding.constraintLayoutConfirmSaveText.visibility = View.GONE
            binding.constraintSaveControl.visibility = View.VISIBLE
            binding.llBottomTools.visibility = View.VISIBLE
            AppblishEditorSdk.setTouchEnable(true)
            AppblishEditorSdk.setLocked(true)
            binding.relativeLayoutAddText.visibility = View.GONE
            setVisibleSave()
            if (!AppblishEditorSdk.getStickers().isEmpty()) {
                AppblishEditorSdk.getStickers().clear()
            }
            AppblishEditorSdk.setHandlingSticker(null)
        }

        binding.imageViewCloseBackground.setOnClickListener {
            Log.i("onclickEvent", "onclickEvent: " + AppblishEditorSdk.getBackgroundResourceMode())

            binding.llBottomTools.visibility = View.VISIBLE
            binding.constraintLayoutChangeBackground.visibility = View.GONE

            setVisibleSave()

            if (AppblishEditorSdk.getBackgroundResourceMode() == 0) {
                AppblishEditorSdk.setBackgroundColor(colorIntSelectSave)

            } else if (AppblishEditorSdk.getBackgroundResourceMode() == 1) {
                AppblishEditorSdk.setBackgroundResorce(resIdSelectSave)
            } else if (AppblishEditorSdk.getBackgroundResourceMode() == 2) {
                blurredBitmapSelectSave?.let { bitmap ->
                    AppblishEditorSdk.setBackground(
                        BitmapDrawable(resources, bitmap)
                    )
                }
            } else {
                AppblishEditorSdk.setBackgroundColor(Color.TRANSPARENT)
            }

        }

        binding.imageViewExit.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
        binding.llCrop.setOnClickListener {
            CropFragment.show(
                appCompatActivity = this, bitmap = (AppblishEditorSdk.getAppblishGrid().drawable as BitmapDrawable).bitmap
            ) { croppedBitmap ->
                AppblishEditorSdk.replace(croppedBitmap, "")
            }
        }

        binding.llReplace.setOnClickListener {
            var intent = Intent(this@CollageActivity, CollageImageSelectionActivity::class.java)
            intent.putExtra("checkRelace", true)
            singleImageLauncher.launch(intent)
        }

        binding.tvSave.setOnClickListener {
            saveCollage()
        }

        binding.imageViewCloseLayer.setOnClickListener {
            binding.constraintLayoutChangeLayout.visibility = View.GONE
            binding.recyclerViewCollage.visibility = View.GONE
            binding.llBottomTools.visibility = View.VISIBLE
            //                    setVisibleSave();
            AppblishEditorSdk.updateLayout(appblishLayout!!)
            AppblishEditorSdk.setCollagePadding(padding)
            AppblishEditorSdk.setCollageRadian(borderRadius)
            AppblishEditorSdk.setAspectRatio(ratioText)
            AppblishEditorSdk.setLocked(true)
            AppblishEditorSdk.setTouchEnable(true)
        }

        binding.linearLayoutBorder.setOnClickListener {
            setBorder()
        }

        binding.linearLayoutCollage.setOnClickListener {
            setLayer()
        }

        binding.linearLayoutRatio.setOnClickListener {
            setRatio()
        }

        binding.imageViewSaveLayer.setOnClickListener {
            binding.constraintLayoutChangeLayout.visibility = View.GONE
            binding.llBottomTools.visibility = View.VISIBLE
            binding.constraintSaveControl.visibility = View.VISIBLE
            appblishLayout = AppblishEditorSdk.getAppblishLayout()
            borderRadius = AppblishEditorSdk.getCollageRadian()
            padding = AppblishEditorSdk.getCollagePadding()
            AppblishEditorSdk.setLocked(true)
            AppblishEditorSdk.setTouchEnable(true)
            aspectRatio = AppblishEditorSdk.getAspectRatio()
        }


        binding.llCollage.setOnClickListener {
            binding.constraintLayoutChangeLayout.visibility = View.VISIBLE
            binding.recyclerViewCollage.visibility = View.VISIBLE
            binding.llBottomTools.visibility = View.GONE
            binding.recyclerViewRatio.visibility = View.GONE
            appblishLayout = AppblishEditorSdk.getAppblishLayout()
            aspectRatio = AppblishEditorSdk.getAspectRatio()
            borderRadius = AppblishEditorSdk.getCollageRadian()
            padding = AppblishEditorSdk.getCollagePadding()
            (binding.recyclerViewCollage.adapter as GridAdapter).setSelectedIndex(-1)
            binding.recyclerViewCollage.adapter!!.notifyDataSetChanged()
            (binding.recyclerViewRatio.adapter as? AspectAdapter)?.resetSelection()
            binding.recyclerViewRatio.adapter!!.notifyDataSetChanged()
            AppblishEditorSdk.setLocked(false)
            AppblishEditorSdk.setTouchEnable(false)
            setLayer()
        }

        binding.ivCloseToolsCollage.setOnClickListener {
            AppblishEditorSdk.clearSelectedLine()
            binding.recyclerViewToolsCollage.visibility = View.GONE
            binding.llBottomTools.visibility = View.VISIBLE
        }

        binding.llRotate.setOnClickListener {
            AppblishEditorSdk.rotate(90.0f);
        }

        binding.llHorizontal.setOnClickListener {
            AppblishEditorSdk.flipHorizontally();
        }

        binding.llVertical.setOnClickListener {
            AppblishEditorSdk.flipVertically();
        }

        binding.llTextView.setOnClickListener {
            binding.constraintSaveControl.visibility = View.GONE
            binding.llBottomTools.visibility = View.GONE
            AppblishEditorSdk.setTouchEnable(false)
            AppblishEditorSdk.setLocked(false)
            openTextFragment()
            binding.constraintLayoutConfirmText.visibility = View.VISIBLE
            binding.constraintLayoutConfirmSaveText.visibility = View.VISIBLE
            binding.relativeLayoutAddText.visibility = View.VISIBLE
        }

        binding.imageViewSaveText.setOnClickListener {
            binding.llBottomTools.visibility = View.VISIBLE
            binding.relativeLayoutAddText.visibility = View.GONE
            binding.constraintLayoutConfirmText.visibility = View.GONE
            binding.constraintLayoutConfirmSaveText.visibility = View.GONE
            AppblishEditorSdk.setHandlingSticker(null)
            AppblishEditorSdk.setLocked(true)
            binding.relativeLayoutAddText.visibility = View.GONE
            setVisibleSave()
        }


        binding.llSocialMedia.setOnClickListener {
            binding.constraintLayoutChangeLayout.visibility = View.VISIBLE
            binding.recyclerViewCollage.visibility = View.VISIBLE
            binding.llBottomTools.visibility = View.GONE
            appblishLayout = AppblishEditorSdk.getAppblishLayout()
            aspectRatio = AppblishEditorSdk.getAspectRatio()
            borderRadius = AppblishEditorSdk.getCollageRadian()
            padding = AppblishEditorSdk.getCollagePadding()
            (binding.recyclerViewCollage.adapter as GridAdapter).setSelectedIndex(-1)
            binding.recyclerViewCollage.adapter!!.notifyDataSetChanged()
            (binding.recyclerViewRatio.adapter as? AspectAdapter)?.resetSelection()
            binding.recyclerViewRatio.adapter!!.notifyDataSetChanged()
            AppblishEditorSdk.setLocked(false)
            AppblishEditorSdk.setTouchEnable(false)
            setRatio()
        }

        binding.relativeLayoutAddText.setOnClickListener(View.OnClickListener { view: View? ->
            AppblishEditorSdk.setHandlingSticker(null)
            openTextFragment()
        })

        binding.llPadding.setOnClickListener {
            binding.constraintLayoutChangeLayout.visibility = View.VISIBLE
            binding.recyclerViewCollage.visibility = View.VISIBLE
            binding.llBottomTools.visibility = View.GONE
            appblishLayout = AppblishEditorSdk.getAppblishLayout()
            aspectRatio = AppblishEditorSdk.getAspectRatio()
            borderRadius = AppblishEditorSdk.getCollageRadian()
            padding = AppblishEditorSdk.getCollagePadding()
            (binding.recyclerViewCollage.adapter as GridAdapter).setSelectedIndex(-1)
            binding.recyclerViewCollage.adapter!!.notifyDataSetChanged()
            (binding.recyclerViewRatio.adapter as? AspectAdapter)?.resetSelection()
            binding.recyclerViewRatio.adapter!!.notifyDataSetChanged()
            AppblishEditorSdk.setLocked(false)
            AppblishEditorSdk.setTouchEnable(false)
            setBorder()
        }

        binding.llBg.setOnClickListener {
            binding.constraintLayoutChangeBackground.visibility = View.VISIBLE
            binding.llBottomTools.visibility = View.GONE
            binding.recyclerViewToolsCollage.visibility = View.GONE
            AppblishEditorSdk.setLocked(false)
            AppblishEditorSdk.setTouchEnable(false)
            binding.constraintSaveControl.visibility = View.GONE

            setBackgroundColor()

        }

        binding.linearLayoutGradient.setOnClickListener {
            setBackgroundGradient()
        }

        binding.linearLayoutBlur.setOnClickListener {
            selectBackgroundBlur()
        }

        binding.linearLayoutColor.setOnClickListener {
            setBackgroundColor()
        }

        binding.imageViewSaveBackground.setOnClickListener {

            blurredBitmapSelectSave = blurredBitmapSelect
            resIdSelectSave = resIdSelect
            colorIntSelectSave = colorIntSelect
            binding.llBottomTools.visibility = View.VISIBLE
            AppblishEditorSdk.setBackgroundResourceMode(backgroundResourceMode)
            binding.constraintLayoutChangeBackground.visibility = View.GONE
            setVisibleSave()
        }

    }

    fun setBackgroundColor() {
        binding.recyclerViewColor.scrollToPosition(0)
        (binding.recyclerViewColor.adapter as CollageColorAdapter).setSelectedIndex(-1)
        binding.recyclerViewColor.adapter!!.notifyDataSetChanged()
        binding.recyclerViewColor.visibility = View.VISIBLE
        binding.recyclerViewGradient.visibility = View.GONE
        binding.recyclerViewBlur.visibility = View.GONE
        binding.textViewColor.setTextColor(ContextCompat.getColor(this, R.color.color_text))
        binding.textViewGradient.setTextColor(ContextCompat.getColor(this, R.color.text_grey))
        binding.textViewBlur.setTextColor(ContextCompat.getColor(this, R.color.text_grey))
        binding.viewColor.visibility = View.VISIBLE
        binding.viewGradient.visibility = View.INVISIBLE
        binding.viewBlur.visibility = View.INVISIBLE
    }

    fun setLoading(loaderLayout: Boolean) {
        if (loaderLayout) {
            window.setFlags(16, 16)
            showLoadingDialog()
            return
        }
        window.clearFlags(16)
        hideLoadingDialog()
    }

    fun setLayer() {
        binding.recyclerViewCollage.visibility = View.VISIBLE
        binding.recyclerViewRatio.visibility = View.GONE
        binding.linearLayoutPadding.visibility = View.GONE
        binding.textViewCollage.setTextColor(ContextCompat.getColor(this, R.color.color_text))
        binding.textViewBorder.setTextColor(ContextCompat.getColor(this, R.color.text_grey))
        binding.textViewRatio.setTextColor(ContextCompat.getColor(this, R.color.text_grey))
        binding.viewCollage.visibility = View.VISIBLE
        binding.viewBorder.visibility = View.INVISIBLE
        binding.viewRatio.visibility = View.INVISIBLE
    }

    fun setBorder() {
        binding.recyclerViewCollage.visibility = View.GONE
        binding.recyclerViewRatio.visibility = View.GONE
        binding.linearLayoutPadding.visibility = View.VISIBLE
        binding.textViewCollage.setTextColor(ContextCompat.getColor(this, R.color.text_grey))
        binding.textViewBorder.setTextColor(ContextCompat.getColor(this, R.color.color_text))
        binding.textViewRatio.setTextColor(ContextCompat.getColor(this, R.color.text_grey))
        binding.viewCollage.visibility = View.INVISIBLE
        binding.viewBorder.visibility = View.VISIBLE
        binding.viewRatio.visibility = View.INVISIBLE
        binding.seekbarBorder.progress = AppblishEditorSdk.getCollagePadding().toInt()
        binding.seekbarRadius.progress = AppblishEditorSdk.getCollageRadian().toInt()
    }

    fun setRatio() {
        binding.recyclerViewCollage.visibility = View.GONE
        binding.recyclerViewRatio.visibility = View.VISIBLE
        binding.linearLayoutPadding.visibility = View.GONE
        binding.textViewCollage.setTextColor(ContextCompat.getColor(this, R.color.text_grey))
        binding.textViewBorder.setTextColor(ContextCompat.getColor(this, R.color.text_grey))
        binding.textViewRatio.setTextColor(ContextCompat.getColor(this, R.color.color_text))
        binding.viewCollage.visibility = View.INVISIBLE
        binding.viewBorder.visibility = View.INVISIBLE
        binding.viewRatio.visibility = View.VISIBLE
    }

    fun setVisibleSave() {
        binding.constraintSaveControl.visibility = View.VISIBLE
        AppblishEditorSdk.setLocked(true)
        AppblishEditorSdk.setTouchEnable(true)
    }

    fun setBackgroundGradient() {
        binding.recyclerViewGradient.scrollToPosition(0)
        (binding.recyclerViewGradient.adapter as CollageBackgroundAdapter).setSelectedIndex(-1)
        binding.recyclerViewGradient.adapter!!.notifyDataSetChanged()
        binding.recyclerViewColor.visibility = View.GONE
        binding.recyclerViewGradient.visibility = View.VISIBLE
        binding.recyclerViewBlur.visibility = View.GONE
        binding.textViewColor.setTextColor(ContextCompat.getColor(this, R.color.text_grey))
        binding.textViewGradient.setTextColor(ContextCompat.getColor(this, R.color.color_text))
        binding.textViewBlur.setTextColor(ContextCompat.getColor(this, R.color.text_grey))
        binding.viewColor.visibility = View.INVISIBLE
        binding.viewGradient.visibility = View.VISIBLE
        binding.viewBlur.visibility = View.INVISIBLE
    }

    fun selectBackgroundBlur() {
        // ---- Blur adapter ----

        val arrayList: ArrayList<Drawable> = ArrayList()
        for (drawable in AppblishEditorSdk.getAppblishGrids()) {
            arrayList.add(drawable.drawable)
        }

        val blurAdapter = CollageBlurAdapter(
            context = this, stringList = arrayList
        ) { position, drawable ->
            AppblishEditorSdk.setBackgroundBlurGrid(this, drawable!!, object : AppblishCollageBlurCallback {
                override fun onBlurSuccess(blurredBitmap: Bitmap) {
                    Log.d("blurCheck", "Blur success!")
                    blurredBitmapSelect = blurredBitmap

                }

                override fun onBlurFailed(e: Exception) {
                    Log.e("blurCheck", "Blur failed", e)
                }
            })
            backgroundResourceMode = 2

//            AppblishEditorSdk.setBackgroundResourceMode(2)

        }
        binding.recyclerViewBlur.adapter = blurAdapter

        (binding.recyclerViewBlur.adapter as CollageBlurAdapter).setSelectedIndex(-1)
        binding.recyclerViewColor.visibility = View.GONE
        binding.recyclerViewGradient.visibility = View.GONE
        binding.recyclerViewBlur.visibility = View.VISIBLE
        binding.textViewColor.setTextColor(ContextCompat.getColor(this, R.color.text_grey))
        binding.textViewGradient.setTextColor(ContextCompat.getColor(this, R.color.text_grey))
        binding.textViewBlur.setTextColor(ContextCompat.getColor(this, R.color.color_text))
        binding.viewColor.visibility = View.INVISIBLE
        binding.viewGradient.visibility = View.INVISIBLE
        binding.viewBlur.visibility = View.VISIBLE
    }

    private fun openTextFragment() {
        addTextFragment = TextFragment.Companion.show(this)

        textEditor = object : TextEditor {
            override fun onDone(addTextProperties: AppblishCollageText) {
                AppblishTextSdk.create(
                    applicationContext, addTextProperties
                )
                AppblishEditorSdk.addTextSticker()
            }

            override fun onBackButton() {
                if (AppblishEditorSdk.getStickers().isEmpty()) {
                    onBackPressed()
                }
            }
        }

        addTextFragment?.setOnTextEditorListener(textEditor)
    }

    fun saveCollage() {
        setLoading(true)
        val random = (0..1000).random()
        val folderPath = "${Environment.getExternalStorageDirectory()}/Pictures/Collages"
        val fileName = "MyCustomCollage_${System.currentTimeMillis()}_$random.png"

        AppblishSaveSdk.saveCollage(this, binding.collageView, folderPath, fileName, object : AppblishSaveSdk.SaveCallback {
            override fun onSaved(filePath: String?) {
                if (filePath != null) {
                    Toast.makeText(this@CollageActivity, "Saved at $filePath", Toast.LENGTH_SHORT).show()
                    val resultIntent = Intent(this@CollageActivity, SaveCollageActivity::class.java).apply {
                        putExtra("saved_image_path", filePath)
                    }
                    saveActivityLauncher.launch(resultIntent)
                    setLoading(false)

                } else {
                    Toast.makeText(this@CollageActivity, "Failed to save collage", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    var saveActivityLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            finish()
        }
    }

    private fun loadFilterBitmapForCurrentPiece() {

        setLoading(true)

        val bitmap = (AppblishEditorSdk.getAppblishGrid().drawable as BitmapDrawable).bitmap

        FilterThumbnailsManager().loadFilters(
            context = this, sourceBitmap = bitmap
        ) { filterLists ->
            setLoading(false)
            FilterFragment.Companion.show(
                activity = this, bitmap = bitmap, list = filterLists
            ) { filteredBitmap ->
                setLoading(false)
                AppblishEditorSdk.replace(filteredBitmap, "")
            }
        }
    }

    private val singleImageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->

        if (result.resultCode == RESULT_OK) {
            val data = result.data
            val savedPath = data!!.getStringExtra("saved_image_path")
            Log.i("savedPath", ": " + savedPath)
            if (savedPath!!.isNotEmpty()) {
                lifecycleScope.launch {
                    val bitmap = AppblishSaveSdk.loadBitmapFromUri(this@CollageActivity, savedPath!!.toUri())
                    AppblishEditorSdk.replace(bitmap!!, "")
                }
            }

        }
    }


    private fun closeAllPanels() {
        binding.constraintLayoutChangeBackground.visibility = View.GONE
        binding.constraintLayoutChangeLayout.visibility = View.GONE
        binding.constraintLayoutConfirmText.visibility = View.GONE
        binding.recyclerViewToolsCollage.visibility = View.GONE
        binding.constraintLayoutConfirmSaveText.visibility = View.GONE

        binding.llBottomTools.visibility = View.VISIBLE
        binding.constraintSaveControl.visibility = View.VISIBLE

        AppblishEditorSdk.setLocked(true)
        AppblishEditorSdk.setTouchEnable(true)
    }

    fun confirmDialog() {
        try {
            val dialog = ConfirmationDialog(
                this,
                ContextCompat.getString(this, R.string.hide),
                ContextCompat.getString(this, R.string.are_you_sure_you_want_to_discard_your_changes),
                ContextCompat.getString(this, R.string.cancel),
                ContextCompat.getString(this, R.string.discard),
                ContextCompat.getColor(this, R.color.white_color)
            ) {

                //            startActivity(Intent(this@CollageActivity, MainActivity::class.java))
                finish()
            }
            dialog.show(supportFragmentManager, "ConfirmationDialog")
        } catch (e: Exception) {
        }
    }

}