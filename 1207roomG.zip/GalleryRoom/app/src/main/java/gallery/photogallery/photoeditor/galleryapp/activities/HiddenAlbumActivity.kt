package gallery.photogallery.photoeditor.galleryapp.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.ScrollGate
import com.appblish.box.api.util.AppblishEvent
import com.appblish.box.api.util.MediaDataState
import com.appblish.gallery.core.v2.api.model.FolderWithMedia
import com.appblish.recyclerview.dragselection.SelectionUpdateCallback
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.adaptor.HiddenAlbumMediaAdapter
import gallery.photogallery.photoeditor.galleryapp.bottomSheet.BiometricErrorDialog
import gallery.photogallery.photoeditor.galleryapp.bottomSheet.SecurityQuestionDialog
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityPrivateAlbumBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.DeleteDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.HiddenMenuDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.showDeleteDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isDarkMode
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isSupportWithErrorInfo
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.tablayout.loge
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.SelectAlbumImageActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.SetLockActivity
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class HiddenAlbumActivity : BaseActivity(), View.OnClickListener {
    private val binding by viewBinding(ActivityPrivateAlbumBinding::inflate)
    private var isFingerprintAvailable = Pair(false, "")

    private lateinit var layoutManager: GridLayoutManager

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        enableEdgeToEdge()
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = !isDarkMode()
        controller.isAppearanceLightNavigationBars = !isDarkMode()
        window?.navigationBarColor = ContextCompat.getColor(this, R.color.app_background)
        binding.root.setPadding(0, statusBarHeight, 0, navigationBarHeight)
        registerEventBus(this)
        initLayoutManager()
        initClick()
        setListeners()
    }

    private fun initLayoutManager() {
        if (binding.mediaRecycler.adapter == null) {
            binding.mediaRecycler.layoutManager = GridLayoutManager(this, 3)
            val albumAdaptor = HiddenAlbumMediaAdapter(binding.mediaRecycler) {
                onFileClick(it)
            }
            binding.mediaRecycler.adapter = albumAdaptor

            albumAdaptor.setSelectionUpdateCallback(
                object : SelectionUpdateCallback {
                    override fun onSelectionCountChanged(
                        selectedCount: Int,
                        selectionActive: Boolean,
                    ) {
                        updateSelection()
                    }
                }
            )
        }
    }

    private fun initClick() {
        binding.mediaRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING ||
                    newState == RecyclerView.SCROLL_STATE_SETTLING
                ) {
                    ScrollGate.onScrollStart()
                } else {
                    ScrollGate.onScrollStop()
                }
            }
        })
        binding.icSelectAll.setOnClickListener(this)
        binding.ivClose.setOnClickListener(this)
        binding.ivBack.setOnClickListener(this)
        binding.ivImportPlus.setOnClickListener(this)
        binding.btnImport.setOnClickListener(this)
        observableMedia()
    }

    @SuppressLint("SetTextI18n")
    private fun observableMedia() {
        lifecycleScope.launch {
            when (val state = sharedViewModel.getPrivateStateFlow()) {
                MediaDataState.Empty -> {
                    binding.loutNoData.beVisible()
                    binding.fastScroller.beGone()
                    binding.tvCount.text = "0 " + resources.getString(R.string.items)
                    binding.ivImportPlus.beGone()
                    getHiddenAlbumMediaAdapter()?.submitList(emptyList())
                }

                MediaDataState.Loading -> {
                }

                is MediaDataState.Success -> {
                    val list = state.data
                    setMedia(list)
                }

                is MediaDataState.Progress -> {}
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            AppblishEvent.ALL_PRIVATE_LOADED -> {
                observableMedia()
            }

        }
    }

    @SuppressLint("SetTextI18n")
    fun setMedia(list: List<FolderWithMedia>) {
        Log.e("setMedia", "setMedia: ${list.size}")
        binding.tvCount.text = list.size.toString() + " " + resources.getString(R.string.items)

        if (list.isEmpty()) {
            binding.loutNoData.beVisible()
            binding.fastScroller.beGone()
        } else {
            binding.loutNoData.beGone()
            binding.fastScroller.beVisible()
        }
        binding.ivImportPlus.beVisibleIf(list.isNotEmpty())
        getHiddenAlbumMediaAdapter()?.submitList(list)
    }

    fun onFileClick(folderWithMedia: FolderWithMedia) {
        Intent(this, ExploreHiddenAlbumActivity::class.java).apply {
            putExtra("directoryPath", folderWithMedia.folderPath)
            putExtra("directorySize", folderWithMedia.mediaFiles.size)
            startActivity(this)
        }
    }

    @SuppressLint("SetTextI18n")
    fun updateSelection() {
        val hiddenAlbumMediaAdapter = getHiddenAlbumMediaAdapter() ?: return
        val flagEnable = hiddenAlbumMediaAdapter.isSelectionActive()
        binding.photoToolbar.beVisibleIf(!flagEnable)
        binding.clSelection.beVisibleIf(flagEnable)
        binding.btmSelectionView.beVisibleIf(flagEnable)
        binding.tvTitleSelection.text = "${hiddenAlbumMediaAdapter.getSelectedCount()} " + resources.getString(R.string.selected)
        if (hiddenAlbumMediaAdapter.isSelectAll()) {
            binding.icSelectAll.setImageResource(R.drawable.vec_selected_bg)
        } else {
            binding.icSelectAll.setImageResource(R.drawable.vec_unselected_bg)
        }
    }


    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        val hiddenAlbumMediaAdapter = getHiddenAlbumMediaAdapter() ?: return
        if (hiddenAlbumMediaAdapter.isSelectionActive()) {
            disableSelection()
        } else {
            finish()
        }
    }

    override fun onClick(view: View?) {
        when (view) {
            binding.ivBack -> {
                onBackPressed()
            }

            binding.icSelectAll -> {
                val albumAdaptor = getHiddenAlbumMediaAdapter() ?: return
                if (albumAdaptor.isSelectAll()) {
                    albumAdaptor.unSelectAll()
                } else {
                    albumAdaptor.selectAll()
                }
            }

            binding.btnImport, binding.ivImportPlus -> {
                startActivity(
                    SelectAlbumImageActivity.createIntentImageSelect(
                        this, "HiddenAlbumActivity", true
                    )
                )
            }

            binding.ivClose -> {
                binding.icSelectAll.isSelected = false
                binding.icSelectAll.setColorFilter(ContextCompat.getColor(this, R.color.app_text_color))
                disableSelection()
            }
        }
    }

    private fun setListeners() {
        binding.btnRestore.setOnClickListener {
            val selectedFile = getHiddenAlbumMediaAdapter()?.getSelectedItems() ?: emptyList()

            showDeleteDialog(
                title = getString(R.string.are_you_sure_you_want_to_unhide_these_file),
                positiveRes = R.string.unhide,
                onDeleteClick = {
                    restoreMedia(selectedFile.flatMap { it.mediaFiles }, true)
                    disableSelection()
                })
        }

        binding.btnDelete.setOnClickListener {
            val selectedFile = getHiddenAlbumMediaAdapter()?.getSelectedItems() ?: emptyList()


            val deleteDialog = DeleteDialog.newInstance(btnClickListener = { isPermanent ->
                if (isPermanent) {
                    deleteFolderFiles(selectedFile.flatMap { it.mediaFiles }.map { it.absolutePath }, true)
                } else {
                    deleteFromPrivate(selectedFile.flatMap { it.mediaFiles }.map { it.absolutePath })
                }
                disableSelection()
            })
            deleteDialog.show(supportFragmentManager, "DeleteDialog")
        }

        binding.ivMore.setOnClickListener {
            HiddenMenuDialog { getClick ->
                when (getClick) {
                    1 -> {
                        "click: $getClick".loge()
                        val intent = Intent(this, SetLockActivity::class.java)
                        intent.putExtra(Constant.EXTRA_CHANGE_PASS, true)
                        startActivity(intent)
                    }

                    2 -> setQuestion()

                    3 -> startActivity(Intent(this, PrivateTrashActivity::class.java))

                    31 -> enableFingure(true)  //Fingerprint Enable

                    32 -> enableFingure(false)  //Fingerprint Disable
                }
            }.show(supportFragmentManager, "AlbumDetailsBottomSheet")
        }

        binding.llUninstallProtection.setOnClickListener {
            val intent = Intent(this, UninstallProtectionActivity::class.java)
            startActivity(intent)
        }
    }

    private fun setQuestion() {
        val securityQuestionDialog = SecurityQuestionDialog.newInstance(this, 0, true, true) {
            if (it) {
                Toast.makeText(
                    this, "Security question changed", Toast.LENGTH_SHORT
                ).show()
            }
        }
        securityQuestionDialog.show(supportFragmentManager, "securityQuestionDialog")
    }

    private fun enableFingure(isChecked: Boolean) {
        if (isChecked) {
            if (isFingerprintAvailable.first) {
                preferences.enableFingerprint = true
            } else {
                val biometricErrorDialog = BiometricErrorDialog(this) { isEnable ->
                    if (isEnable) {
                        val enrollIntent = Intent(Settings.ACTION_BIOMETRIC_ENROLL)
                        enrollIntent.putExtra(
                            Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED, BiometricManager.Authenticators.BIOMETRIC_STRONG
                        )
                        biometricLauncher.launch(enrollIntent)
                    } else {
                        preferences.enableFingerprint = false
                    }
                }
                preferences.enableFingerprint = false
                biometricErrorDialog.show(supportFragmentManager, "BiometricErrorDialog")
            }
        } else {
            preferences.enableFingerprint = false
        }
    }

    private var biometricLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        isFingerprintAvailable = isSupportWithErrorInfo(this, BiometricManager.Authenticators.BIOMETRIC_STRONG)
        preferences.enableFingerprint = isFingerprintAvailable.first
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterEventBus(this)
    }

    private fun getHiddenAlbumMediaAdapter() = binding.mediaRecycler.adapter as? HiddenAlbumMediaAdapter

    fun disableSelection() {
        val albumAdaptor = getHiddenAlbumMediaAdapter() ?: return
        albumAdaptor.clearSelectionAndExit()
        updateSelection()
    }
}