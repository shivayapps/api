package gallery.photogallery.photoeditor.galleryapp.adaptor

import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import com.bumptech.glide.Glide
import com.cleaner.v2.api.model.CleanerListItem
import com.cleaner.v2.api.model.CleanerMediaSizeCategory
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemHeaderDividerSelectionBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemPhotoGridSelectionBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isVideoFast

class CleanerScanDeleteAdapter(private val isType: Int) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    var items = ArrayList<CleanerListItem>()
    val selectedItems = HashSet<String>()
    var onSelectionChanged: ((count: Int, totalSize: Long) -> Unit)? = null

    private var selectionEnabled = true

    fun submitList(list: List<CleanerListItem>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    companion object {
        const val HEADER = 1
        const val MEDIA = 2
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): RecyclerView.ViewHolder {
        return when (viewType) {
            HEADER -> {
                val binding = ItemHeaderDividerSelectionBinding.inflate(
                    LayoutInflater.from(parent.context), parent, false
                )
                HeaderViewHolder(binding)
            }

            MEDIA -> {
                val binding = ItemPhotoGridSelectionBinding.inflate(
                    LayoutInflater.from(parent.context), parent, false
                )
                MediaViewHolder(binding)
            }

            else -> {
                throw IllegalArgumentException("Invalid view type")
            }
        }
    }

    fun setSelectionEnabled(enabled: Boolean, clearExisting: Boolean = true) {
        selectionEnabled = enabled

        if (!enabled && clearExisting) {
            selectedItems.clear()
            notifySelectionChanged()
            notifyDataSetChanged()
        }
    }

    override fun onBindViewHolder(
        holder: RecyclerView.ViewHolder,
        position: Int,
    ) {
        when (holder) {
            is HeaderViewHolder ->
                holder.bind(items[position] as CleanerListItem.Header)

            is MediaViewHolder ->
                holder.bind(items[position] as CleanerListItem.CleanerMedia)
        }
    }

    fun getSelectedMedia(): List<CleanerListItem.CleanerMedia> {
        return items
            .filterIsInstance<CleanerListItem.CleanerMedia>()
            .filter { selectedItems.contains(it.mediaBox.mediaPath) }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        if (holder is MediaViewHolder) {
            Glide.with(holder.binding.mediumThumbnail.context).clear(holder.binding.mediumThumbnail)
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (items[position]) {
            is CleanerListItem.Header -> HEADER
            is CleanerListItem.CleanerMedia -> MEDIA
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

    private fun formatText(input: String): String {
        return input
            .replace("_", " ")
            .lowercase()
            .replaceFirstChar { it.uppercase() }
    }

    fun CleanerMediaSizeCategory.toDisplayText(): String {
        return when (this) {
            CleanerMediaSizeCategory.ABOVE_10_GB -> "Above 10 GB"

            CleanerMediaSizeCategory.FROM_10_GB_TO_5_GB -> "5 GB - 10 GB"

            CleanerMediaSizeCategory.FROM_5_GB_TO_1_GB -> "1 GB - 5 GB"

            CleanerMediaSizeCategory.FROM_1_GB_TO_500_MB -> "500 MB - 1 GB"

            CleanerMediaSizeCategory.FROM_500_MB_TO_200_MB -> "200 MB - 500 MB"

            CleanerMediaSizeCategory.FROM_200_MB_TO_100_MB -> "100 MB - 200 MB"

            CleanerMediaSizeCategory.FROM_100_MB_TO_50_MB -> "50 MB - 100 MB"

            CleanerMediaSizeCategory.FROM_50_MB_TO_10_MB -> "10 MB - 50 MB"

            CleanerMediaSizeCategory.FROM_10_MB_TO_5_MB -> "5 MB - 10 MB"

            CleanerMediaSizeCategory.FROM_5_MB_TO_1_MB -> "1 MB - 5 MB"
        }
    }

    fun clearSelection() {
        selectedItems.clear()
        notifyDataSetChanged()
        notifySelectionChanged()
    }

    fun applySmartSelection() {
        // Smart selection ONLY for isType == 1
        if (isType != 1) return

        selectedItems.clear()

        var index = 0
        while (index < items.size) {
            val item = items[index]

            if (item is CleanerListItem.Header) {
                val mediaItems = mutableListOf<CleanerListItem.CleanerMedia>()

                // collect media under this header
                var j = index + 1
                while (j < items.size && items[j] !is CleanerListItem.Header) {
                    val media = items[j] as CleanerListItem.CleanerMedia
                    mediaItems.add(media)
                    j++
                }

                // SMART RULE:
                // first item UNSELECTED, rest SELECTED
                if (mediaItems.size > 1) {
                    mediaItems.drop(1).forEach {
                        selectedItems.add(it.mediaBox.mediaPath)
                    }
                }

                index = j
            } else {
                index++
            }
        }

        notifyDataSetChanged()
        notifySelectionChanged()
    }

    inner class HeaderViewHolder(private val binding: ItemHeaderDividerSelectionBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(header: CleanerListItem.Header) {

            when (isType) {
                1 -> {
                    binding.txtHeader.text = formatText(header.title)
                }

                2 -> {
                    binding.txtHeader.text = header.sizeCategory.toDisplayText()
                }

                3 -> {
                    binding.txtHeader.text = formatText(header.title)
                }
            }


            val headerPosition = absoluteAdapterPosition
            if (headerPosition == RecyclerView.NO_POSITION) return

            val mediaItems = getMediaUnderHeader(headerPosition)

            val allSelected = mediaItems.isNotEmpty() &&
                    mediaItems.all { selectedItems.contains(it.mediaBox.mediaPath) }

            binding.icSelect.isSelected = allSelected

            binding.icSelect.setImageResource(
                if (allSelected) R.drawable.vec_selected_bg
                else R.drawable.vec_unselected_bg
            )

            binding.llSelect.setOnClickListener {
                // handled from adapter instead
                toggleSelectAll(getAbsoluteAdapterPosition())
                notifySelectionChanged()
            }
        }

        private fun getMediaUnderHeader(headerPosition: Int): List<CleanerListItem.CleanerMedia> {
            val list = mutableListOf<CleanerListItem.CleanerMedia>()

            for (i in headerPosition + 1 until items.size) {
                val item = items[i]
                if (item is CleanerListItem.Header) break
                if (item is CleanerListItem.CleanerMedia) list.add(item)
            }
            return list
        }

        private fun toggleSelectAll(headerPosition: Int) {
            if (headerPosition == RecyclerView.NO_POSITION) return

            val mediaItems = mutableListOf<CleanerListItem.CleanerMedia>()

            // Collect media items under this header
            for (i in headerPosition + 1 until items.size) {
                val item = items[i]
                if (item is CleanerListItem.Header) break
                if (item is CleanerListItem.CleanerMedia) {
                    mediaItems.add(item)
                }
            }

            // Check if all are already selected
            val allSelected = mediaItems.all {
                selectedItems.contains(it.mediaBox.mediaPath)
            }

            if (allSelected) {
                // UNSELECT all
                mediaItems.forEach {
                    selectedItems.remove(it.mediaBox.mediaPath)
                }
            } else {
                // SELECT all
                mediaItems.forEach {
                    selectedItems.add(it.mediaBox.mediaPath)
                }
            }

//            binding.icSelect.beVisibleIf(allSelected)

            notifyItemRangeChanged(
                headerPosition + 1,
                mediaItems.size
            )

            notifyItemChanged(headerPosition) // update header icon
        }
    }

    fun getMediaList() = items.filterIsInstance<CleanerListItem.CleanerMedia>().map { it.mediaBox }
    fun isSelectAll() = getMediaList().size == selectedItems.size

    fun selectAll() {
        val mediaList = getMediaList().map { it.mediaPath }
        selectedItems.clear()
        selectedItems.addAll(mediaList)
        notifyDataSetChanged()
        notifySelectionChanged()
    }

    fun unselectAll() {

        selectedItems.clear()
        notifyDataSetChanged()
        notifySelectionChanged()
    }

    private fun notifySelectionChanged() {
        val selectedMedia = getSelectedMedia()
        val totalSize = selectedMedia.sumOf { it.mediaBox.mediaSize }
        onSelectionChanged?.invoke(selectedMedia.size, totalSize)
    }


    inner class MediaViewHolder(val binding: ItemPhotoGridSelectionBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(media: CleanerListItem.CleanerMedia) {
            val path = media.mediaBox.mediaPath
            binding.mediumThumbnail.loadGridImage(path, media.mediaBox.mediaDate)

            val size = Formatter.formatShortFileSize(itemView.context, media.mediaBox.mediaSize)
            binding.tvVideoDuration.text = size

            val isSelected = selectedItems.contains(path)
            updateSelectionUI(isSelected)

            try {
                binding.ivGif.beVisibleIf(
                    path.endsWith(
                        "gif", true
                    )
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }

            if (path.isVideoFast()) {
                binding.icVideo.visibility = View.VISIBLE
            } else {
                binding.icVideo.visibility = View.GONE
            }

            itemView.setOnClickListener {
                toggleSelection(media)
                notifySelectionChanged()
            }
        }

        private fun toggleSelection(media: CleanerListItem.CleanerMedia) {
            val path = media.mediaBox.mediaPath

            if (selectedItems.contains(path)) {
                selectedItems.remove(path)
            } else {
                selectedItems.add(path)
            }

            notifyItemChanged(absoluteAdapterPosition)
            notifyHeaderForPosition(absoluteAdapterPosition)
        }

        private fun notifyHeaderForPosition(position: Int) {
            if (position == RecyclerView.NO_POSITION) return

            for (i in position downTo 0) {
                if (items[i] is CleanerListItem.Header) {
                    notifyItemChanged(i)
                    break
                }
            }
        }

        private fun updateSelectionUI(selected: Boolean) {
            binding.icSelect.beVisibleIf(selected)
//           binding.selectionOverlay.beVisibleIf(selected)
        }
    }

}




