package gallery.photogallery.photoeditor.galleryapp.activities

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.appblish.gallery.core.v2.api.model.AlbumListItem
import gallery.photogallery.photoeditor.galleryapp.adaptor.SelectAlbumAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivitySelectAlbumBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.CreateNewAlbumDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isDarkMode
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import kotlinx.coroutines.launch

class SelectAlbumActivity : BaseActivity(), View.OnClickListener {

    companion object {
        private const val ARGS_SELECTED_FOLDER_PATH = "ARGS_SELECTED_FOLDER_PATH"

        fun createIntent(context: Context, selectedFolderPath: Array<String>): Intent {
            return Intent(context, SelectAlbumActivity::class.java).apply {
                putExtra(ARGS_SELECTED_FOLDER_PATH, selectedFolderPath)
            }
        }
    }

    private val selectedFolderPath: Array<String> by lazy {
        val folderPath = intent.getStringArrayExtra(ARGS_SELECTED_FOLDER_PATH)
        folderPath ?: arrayOf()
    }
    private val binding by viewBinding(ActivitySelectAlbumBinding::inflate)
    private val selectAlbumAdaptor by lazy { SelectAlbumAdapter(this) }


    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = !isDarkMode()
        setContentView(binding.root)
        Log.e("StuckOnAlbum", "SelectAlbumActivity: start")

        binding.root.setPadding(0, statusBarHeight, 0, navigationBarHeight)
        initSpanCountHelper()
        initClick()
        observableTimeLine()
    }


    private fun observableTimeLine() {
        lifecycleScope.launch {
            Log.e("StuckOnAlbum", "observableTimeLine: start")
            val list = sharedViewModel.fetchAllAlbumBox()
            Log.e("StuckOnAlbum", "observableTimeLine: done")
            val filterList = list.filterIsInstance<AlbumListItem.Album>().filter { it.albumBox.bucketPath !in selectedFolderPath }
            setAlbums(filterList)
        }
    }

    private fun setAlbums(albums: List<AlbumListItem.Album>) {
        lifecycleScope.launch {
            Log.e("TAG", "setAlbums: ${albums.size}")
            if (binding.mediaRecycler.adapter == null) {
                binding.mediaRecycler.adapter = selectAlbumAdaptor
            }
            selectAlbumAdaptor.submitList(albums)
        }
    }

    private fun initSpanCountHelper() {
        if (appPref.albumAsGrid) {
            val layoutManager = GridLayoutManager(this, appPref.albumGrid)
            binding.mediaRecycler.layoutManager = layoutManager
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    return if (selectAlbumAdaptor.currentList[position] is AlbumListItem.Header) {
                        appPref.albumGrid
                    } else {
                        1
                    }
                }
            }
            binding.mediaRecycler.scheduleLayoutAnimation()
        } else {
            val layoutManager = LinearLayoutManager(this)
            binding.mediaRecycler.setOnTouchListener(null)
            binding.mediaRecycler.layoutManager = layoutManager
            binding.mediaRecycler.scheduleLayoutAnimation()
        }

    }

    private fun initClick() {
        binding.ivBack.setOnClickListener(this)
        binding.btnDone.setOnClickListener(this)
        binding.ivNew.setOnClickListener(this)
    }

    override fun onClick(view: View?) {
        when (view) {
            binding.ivBack -> {
                setResult(RESULT_CANCELED, Intent())
                finish()
            }

            binding.btnDone -> {

            }

            binding.ivNew -> {
                checkStoragePermission {
                    CreateNewAlbumDialog { newAlbum ->
                        selectAlbum(newAlbum)
                    }.show(supportFragmentManager, "CreateAlbumBottomSheet")
                }
            }
        }
    }

    fun selectAlbum(path: String) {
        val intent = Intent()
        intent.putExtra("select_path", path)
        setResult(RESULT_OK, intent)
        finish()
    }


}