package gallery.photogallery.photoeditor.galleryapp.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.MediaBox
import com.appblish.box.api.model.ScrollGate
import com.appblish.box.api.util.AppblishEvent
import com.appblish.box.api.util.MediaDataState
import com.appblish.gallery.core.v2.api.model.MediaListItem
import com.appblish.gallery.core.v2.api.model.MediaModel
import com.appblish.recyclerview.dragselection.SelectionUpdateCallback
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.adaptor.MediaListAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityTimelineExploreBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.PopBottomMenuBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.ConfirmationDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.PhotosDetailsDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.RenamePhotosDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.ResizeDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.editPhoto
import gallery.photogallery.photoeditor.galleryapp.extentions.onBackPressedDispatcher
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.getFilenameFromPath
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.setAs
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.shareFilesList
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.PopupWindowHelper
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.SetLockActivity
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.spancounthelper.ScaleHintListener
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class TimelineExploreActivity : BaseActivity() {
    private val binding by viewBinding(ActivityTimelineExploreBinding::inflate)
    private val getBucketPath by lazy { intent.getStringExtra("BUCKET_PATH") }
    private val getBucketSize by lazy { intent.getStringExtra("BUCKET_SIZE") }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding.root.setPadding(0, 0, 0, navigationBarHeight)
        setContentView(binding.root)
        registerEventBus(this)
        initView()
        clickListener()
    }

    private fun initView() {
        binding.llTop.setPadding(0, statusBarHeight, 0, 0)
        binding.tvCount.text = getBucketSize.toString() + " " + resources.getString(R.string.items)

        binding.rvAllMedia.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING ||
                    newState == RecyclerView.SCROLL_STATE_SETTLING
                ) {
                    ScrollGate.onScrollStart()
                } else {
                    ScrollGate.onScrollStop()
                }
            }
        })

        binding.tvAlbumName.text = getBucketPath?.getFilenameFromPath()
        binding.tvAlbumName.text = when (getBucketPath?.getFilenameFromPath()?.lowercase()) {
            "last_week" -> ContextCompat.getString(this, R.string.last_week)
            "last_month" -> ContextCompat.getString(this, R.string.last_month)
            "this_year" -> ContextCompat.getString(this, R.string.this_year)

            else -> getBucketPath?.getFilenameFromPath()
        }
        initAdaptor()
        initSpanCountHelper()
        observableMedia()
    }

    private fun initAdaptor() {
        if (binding.rvAllMedia.adapter == null) {
            val albumAdaptor = MediaListAdapter(binding.rvAllMedia) {
                onMediaSelectSelect(it)
            }
            binding.rvAllMedia.adapter = albumAdaptor
            albumAdaptor.setSelectionUpdateCallback(
                object : SelectionUpdateCallback {
                    override fun onSelectionCountChanged(
                        selectedCount: Int,
                        selectionActive: Boolean
                    ) {
                        updateExploreSelections()
                    }
                }
            )
        }
    }

    fun onMediaSelectSelect(mediaBox: MediaBox) {
        val allMediaAdaptor = getMediaListAdapter() ?: return
        val mediaPaths = allMediaAdaptor.getAllPaths()

        sharedViewModel.imageViewerList =
            ArrayList(mediaPaths)
        val startPosition = mediaPaths.indexOf(mediaBox.mediaPath)
        startActivity(
            Intent(this, NewImageViewerActivity::class.java).apply {
                putExtra("startPosition", startPosition)
            }
        )
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initSpanCountHelper() {
        val layoutManager = GridLayoutManager(this, appPref.mediaGrid)
        binding.rvAllMedia.layoutManager = layoutManager
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                val mediaListAdapter = getMediaListAdapter()
                return if (mediaListAdapter?.getItem(position) is MediaListItem.Header) {
                    appPref.mediaGrid
                } else {
                    1
                }
            }
        }

        val listener = ScaleHintListener(
            context = this,
            recyclerView = binding.rvAllMedia,
            layoutManager = layoutManager,
            ghostCardView = binding.ghostCardView,
            ghostImageView = binding.ghostImageView,
            gridHelperView = binding.gridHelperView,
            spanHintText = binding.spanHintText,
            landingCircle = binding.landingCircle,
            overlayContainer = binding.overlayContainer,
            imageViewExtractor = { itemView ->
                itemView.findViewById(R.id.medium_thumbnail)

            },
            onUpdateSpan = { span ->
                appPref.mediaGrid = span
            },
            dimLayer = binding.dimLayer,
            minSpan = 2,
            maxSpan = 6
        )
        binding.rvAllMedia.setOnTouchListener(listener)
    }

    private fun observableMedia() {
        lifecycleScope.launch {
            val state = withContext(Dispatchers.IO) {
                sharedViewModel.fetchTimelineMediaBox(getBucketPath ?: "")
            }
            when (state) {
                MediaDataState.Empty -> {
                    getMediaListAdapter()?.submitList(emptyList())
                }

                MediaDataState.Loading -> {
                    binding.llLoader.beVisible()
                    getMediaListAdapter()?.submitList(emptyList())
                }

                is MediaDataState.Success -> {
                    binding.llLoader.beGone()
                    setMedia(state.data)

                }

                is MediaDataState.Progress -> {}
            }
        }

    }

    private fun setMedia(mediaList: List<MediaListItem>) {
        lifecycleScope.launch {
            getMediaListAdapter()?.submitList(mediaList)
            binding.tvCount.text = getMediaListAdapter()?.getAllPaths()?.count().toString() ?: ""
        }
    }


    @SuppressLint("SetTextI18n")
    fun updateExploreSelections() {
        val exploreTimelineAdapter = getMediaListAdapter() ?: return
        val enableSelection = exploreTimelineAdapter.isSelectionActive()
        binding.clSelection.beVisibleIf(enableSelection)
        binding.btmSelectionView.beVisibleIf(enableSelection)
        binding.albumToolbar.beVisibleIf(!enableSelection)

        binding.tvTitleSelection.text = "${exploreTimelineAdapter.getSelectedCount()} " + resources.getString(R.string.selected)
        updatePhotoFragmentSelection()
        if (exploreTimelineAdapter.isSelectAll()) {
            binding.icSelectAll.setImageResource(R.drawable.vec_selected_bg)
        } else {
            binding.icSelectAll.setImageResource(R.drawable.vec_unselected_bg)
        }
    }


    fun disableSelection() {
        val allMediaAdaptor = getMediaListAdapter() ?: return
        allMediaAdaptor.clearSelectionAndExit()
        updateExploreSelections()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            AppblishEvent.ALL_TIME_LINE_LOADED -> {
                observableMedia()
            }
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        unregisterEventBus(this)
    }

    private fun clickListener() {
        onBackPressedDispatcher {
            val exploreTimelineAdapter = getMediaListAdapter() ?: return@onBackPressedDispatcher
            if (exploreTimelineAdapter.isSelectionActive()) {
                disableSelection()
            } else {
                finish()
            }
        }

        binding.ivClose.setOnClickListener {
            val exploreTimelineAdapter = getMediaListAdapter() ?: return@setOnClickListener
            if (exploreTimelineAdapter.isSelectionActive()) {
                disableSelection()
            } else
                finish()
        }

        binding.ivBack.setOnClickListener {
            finish()
        }

        binding.icSelectAll.setOnClickListener {
            val mediaListAdapter = getMediaListAdapter() ?: return@setOnClickListener
            if (mediaListAdapter.isSelectAll()) {
                mediaListAdapter.unSelectAll()
            } else {
                mediaListAdapter.selectAll()
            }
        }
    }

    private fun shareImages() {
        val explorePhotosAdapter = getMediaListAdapter() ?: return
        val mediaList = explorePhotosAdapter.getSelectedItems()
        if (mediaList.isEmpty()) {
            toast(getString(R.string.please_select_item))
            return
        }
        val uris = ArrayList<Uri>()
        uris.addAll(explorePhotosAdapter.getSelectedItems().filterIsInstance<MediaListItem.Media>().map {
            it.mediaBox.mediaUri.toUri()
        })
        shareFilesList(this, uris.filterNotNull())
    }

    fun updatePhotoFragmentSelection() {
        binding.clShare.setOnClickListener {
            val explorePhotosAdapter = getMediaListAdapter() ?: return@setOnClickListener
            val selectedItems = explorePhotosAdapter.getSelectedItems()
            if (selectedItems.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            shareImages()
            disableSelection()
        }

        binding.clDelete.setOnClickListener {
            val explorePhotosAdapter = getMediaListAdapter() ?: return@setOnClickListener
            val selectedItems = explorePhotosAdapter.getSelectedItems()
            if (selectedItems.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }

            val mediaPathList = selectedItems.filter { it is MediaListItem.Media }.map {
                (it as MediaListItem.Media).mediaBox.mediaPath
            }
            deleteMedia(mediaPathList) {
                disableSelection()
            }
        }

        binding.clHide.setOnClickListener {
            val explorePhotosAdapter = getMediaListAdapter() ?: return@setOnClickListener
            val selectedItems = explorePhotosAdapter.getSelectedItems()
            if (selectedItems.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            checkStoragePermission {
                if (it) {

                    if (preferences.getSetPass()) {
                        hideAllMediaFromMedia()
                    } else {
                        val intent = Intent(this, SetLockActivity::class.java)
                        intent.putExtra("setResultCode", 101)
                        allMediaHideResult.launch(intent)
                    }
                }
            }
        }

        binding.clMore.setOnClickListener {
            val explorePhotosAdapter = getMediaListAdapter() ?: return@setOnClickListener
            val selectedItems = explorePhotosAdapter.getSelectedItems().filterIsInstance<MediaListItem.Media>().map { it.mediaModel }
            if (selectedItems.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            showPhotoDropDown(it, selectedItems)
        }
    }

    private fun showPhotoDropDown(view: View, mediaBoxes: List<MediaModel>) {

        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)

        val isAllFav = mediaBoxes.all { it.isFavourite }
        val isSingleSelection = mediaBoxes.count() == 1

        val isVideo = mediaBoxes.any { it.isVideo }
        val isGif = mediaBoxes.any { it.isGif }

        popUpBinding.menuAddFavourite.beVisibleIf(!isAllFav)
        popUpBinding.menuRemoveFavourite.beVisibleIf(isAllFav)

        popUpBinding.menuSetAs.beVisibleIf(isSingleSelection && !isVideo && !isGif)
        popUpBinding.menuEdit.beVisibleIf(isSingleSelection && !isVideo && !isGif)
        popUpBinding.menuResize.beVisibleIf(isSingleSelection && !isVideo && !isGif)
        popUpBinding.menuRename.beVisibleIf(isSingleSelection && !isVideo && !isGif)

        popupWindow.showAsPopUp(view, yoff = -20, xoff = 20)
        popUpBinding.run {
            loutMain.setOnClickListener {
                popupWindow.dismiss()
            }
            popUpBinding.menuRename.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        val renameFileDialog = RenamePhotosDialog(this@TimelineExploreActivity)
                        renameFileDialog.filePath = mediaBoxes.first().mediaPath
                        renameFileDialog.positiveBtnClickListener = { renamedFile, oldFile ->
                            disableSelection()
                            showLoadingDialog()
                            sharedViewModel.renameMedia(oldFile.absolutePath, renamedFile.name) {
                                hideLoadingDialog()
                                if (it) {
                                    sharedViewModel.fetchMedia()
                                }
                            }
                        }
                        renameFileDialog.show(supportFragmentManager, "RenamePhotosDialog")
                    }
                }
            }
            popUpBinding.menuResize.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        val mediaPath = mediaBoxes.first().mediaPath
                        val renameFileDialog = ResizeDialog(this@TimelineExploreActivity, mediaPath) { w, h, name, keepOriginal ->
                            disableSelection()
                            showLoadingDialog()
                            sharedViewModel.resizeMedia(mediaPath, w, h, name, keepOriginal) { b, path ->
                                hideLoadingDialog()
                                if (b) {
                                    sharedViewModel.fetchMedia()
                                }
                            }
                        }

                        renameFileDialog.show(supportFragmentManager, "ResizeDialog")
                    }
                }
            }
            menuAddFavourite.setOnClickListener {
                popupWindow.dismiss()
                sharedViewModel.addToFav(mediaBoxes.map { it.mediaPath })
                disableSelection()
            }

            menuRemoveFavourite.setOnClickListener {
                popupWindow.dismiss()
                sharedViewModel.removeToFav(mediaBoxes.map { it.mediaPath })
                disableSelection()
            }

            menuEdit.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        val mediaPath = mediaBoxes.first().mediaPath
                        disableSelection()
                        editPhoto(mediaPath)
                    }
                }
            }

            menuSetAs.setOnClickListener {
                popupWindow.dismiss()
                val filePath = mediaBoxes.map { it.mediaPath }
                setAs(filePath.single())
            }


            menuInfo.setOnClickListener {
                popupWindow.dismiss()
                PhotosDetailsDialog(mediaBoxes.map { it.mediaPath }).show(supportFragmentManager, "PhotosDetailsDialog")
            }

            menuCopy.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        requestAlbumPicker(emptyArray()) {
                            if (it.isNotEmpty()) {
                                disableSelection()
                                copyFolderFiles(mediaBoxes.map { it.mediaPath }, it)
                            }
                        }
                    }
                }

            }

            menuMove.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        requestAlbumPicker(emptyArray()) {
                            if (it.isNotEmpty()) {
                                disableSelection()
                                moveFolderFiles(mediaBoxes.map { it.mediaPath }, it)
                            }
                        }
                    }
                }

            }
        }

    }

    private var allMediaHideResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            hideAllMediaFromMedia()
        }
    }

    private fun hideAllMediaFromMedia() {
        val dialog = ConfirmationDialog(
            this,
            ContextCompat.getString(this, R.string.hide),
            ContextCompat.getString(this, R.string.confirmation_hide_item),
            ContextCompat.getString(this, R.string.no),
            ContextCompat.getString(this, R.string.yes),
            ContextCompat.getColor(this, R.color.white_color)
        ) {
            val explorePhotosAdapter = getMediaListAdapter() ?: return@ConfirmationDialog
            val selectedItems = explorePhotosAdapter.getSelectedItems()
            val list = selectedItems.map { it as MediaListItem.Media }.map { it.mediaBox.mediaPath }
            hideMediaFolder(list) {
                disableSelection()
            }
        }
        dialog.show(supportFragmentManager, "ConfirmationDialog")


    }

    fun getMediaListAdapter() = binding.rvAllMedia.adapter as? MediaListAdapter
}