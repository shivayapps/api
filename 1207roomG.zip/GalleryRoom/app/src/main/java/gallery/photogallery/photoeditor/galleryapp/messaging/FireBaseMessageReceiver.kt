package gallery.photogallery.photoeditor.galleryapp.messaging

import android.app.Notification.VISIBILITY_PUBLIC
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.legacy.content.WakefulBroadcastReceiver
import com.appblish.story.memories.api.core.MemorySDK
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.SplashActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.realScreenSize
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory.MemoryViewerActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory.NewStoryActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory.memoryTitles
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory.storyTitles
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class FireBaseMessageReceiver : WakefulBroadcastReceiver() {

    private val TAG = "FireBaseMessageReceiver"
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.extras != null) {
            for (key in intent.extras!!.keySet()) {
                val value = intent.extras!!.get(key)
                Log.e(TAG, "MessagingAlarmReceiver-value:key:$key==>${value.toString()}")
                if (key.equals("action") && value != null && value == "open") {
                    val screen: String = intent.extras?.get("screen").toString()
                    val title: String = intent.extras?.get("google.c.a.c_l").toString()
                    val body: String = intent.extras?.get("gcm.notification.body").toString()
                    Handler(Looper.getMainLooper()).postDelayed({
                        cancelFCMDefaultNotification(context)
                        sendNotification(context, title, body, screen)
                    }, 1000)

                    break
                }
                if (key.equals("action") && value != null && value == "memory") {
                    val type: String = intent.extras?.get("type").toString()
                    val image: String = intent.extras?.get("gcm.notification.image").toString()
                    val title: String = intent.extras?.get("google.c.a.c_l").toString()
                    val body: String = intent.extras?.get("gcm.notification.body").toString()
                    Handler(Looper.getMainLooper()).postDelayed({
                        cancelFCMDefaultNotification(context)
                        showMemoryStoryNotification(context, title, body, type, image)
                    }, 1000)

                    break
                }
                if (key.equals("action") && value != null && value == "story") {
                    val type: String = intent.extras?.get("type").toString()
                    val image: String = intent.extras?.get("gcm.notification.image").toString()
                    val title: String = intent.extras?.get("google.c.a.c_l").toString()
                    val body: String = intent.extras?.get("gcm.notification.body").toString()
                    Handler(Looper.getMainLooper()).postDelayed({
                        cancelFCMDefaultNotification(context)
                        showMemoryStoryNotification(context, title, body, type, image)
                    }, 1000)

                    break
                }
                /*
                if (key.equals("action") && value != null && value == "AppOpenFlow") {
                    try {
                        context.appPref.openLanguage = intent.extras?.get("language").toString().toBoolean()
                        context.appPref.showCallerCard = intent.extras?.get("callercad").toString().toBoolean()
                        context.appPref.openApp = intent.extras?.get("appopen").toString().toBoolean()
                        context.appPref.languageInterAdTimeOut = intent.extras?.get("inter_timeout").toString().toInt()
                        context.appPref.splashAppOpenTimeOut = intent.extras?.get("appopen_timeout").toString().toInt()
                        context.appPref.notificationLanguageNative = intent.extras?.get("language_native").toString()
                        context.appPref.notificationLanguageInter = intent.extras?.get("language_inter").toString()
                        context.appPref.splashAppOpen = intent.extras?.get("appopen_id").toString()
                        val title: String = intent.extras?.get("google.c.a.c_l").toString()
                        val body: String = intent.extras?.get("gcm.notification.body").toString()
                        Handler(Looper.getMainLooper()).postDelayed({
                            cancelFCMDefaultNotification(context)
                            sendNotification(context, title, body, "AppOpenFlow")
                        }, 1000)
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Log.e("AppOpenFlow", "onReceive: ${e.message}")
                    }
                    break
                }*/
            }
        }
    }

    private fun cancelFCMDefaultNotification(context: Context) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notifications: Array<StatusBarNotification> = notificationManager.activeNotifications

        Log.e(TAG, "notifications Size: " + notifications.size)
        notifications.forEach {
            Log.e(
                TAG,
                "data : ${it.id} -- ${it.key} -- ${it.tag} -- ${it.notification.extras} -- ${it.notification.extras["title"]}" + " channelid --> " + it.notification.channelId
            )
            if ((it.tag != null && it.tag.contains(
                    "fcm",
                    ignoreCase = true
                )) || it.notification.channelId.equals(
                    "silentFirebase",
                    ignoreCase = true
                ) || it.notification.channelId.equals(
                    "fcm_fallback_notification_channel",
                    ignoreCase = true
                ) || it.notification.channelId.equals(
                    "fcm_notification",
                    ignoreCase = true
                )
            ) {
                notificationManager.cancel(it.tag, it.id)
            }
        }


    }

    private fun sendNotification(context: Context, title: String, body: String, mActivityName: String) {
        Log.e(TAG, "onMessageReceived title==>> ${mActivityName}")
        var intent = Intent(context, SplashActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .setAction("FINISH_AFFINITY")
        intent.putExtra("isFromNotification", true)
        intent.putExtra("screen", mActivityName)
        val pendingIntent = PendingIntent.getActivity(context, 1, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationBuilder = NotificationCompat.Builder(context, "GalleryNotification")
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true).setOnlyAlertOnce(true)

        notificationBuilder.setVibrate(LongArray(0))

        notificationBuilder.setChannelId("GalleryNotification")
        val mChannel = NotificationChannel(
            "GalleryNotification",
            "GalleryNotification",
            NotificationManager.IMPORTANCE_HIGH
        )
        mChannel.description = "Notifications are info related."
        mChannel.lockscreenVisibility = VISIBILITY_PUBLIC
        mChannel.enableLights(true)
        mChannel.lightColor = Color.RED
        mChannel.enableVibration(true)
        mChannel.setShowBadge(true)
        mChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
        notificationBuilder.setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
        notificationManager.createNotificationChannel(mChannel)
        notificationManager.notify(mActivityName.hashCode(), notificationBuilder.build())
    }

    private fun showMemoryStoryNotification(context: Context, title: String, body: String, type: String, image: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (type == "same_day") {
                    val storyBox = MemorySDK.get().getStoryForNotification()
                    if (storyBox != null) {
                        showStoryNotification(context, storyTitles.random(), storyBox.title, storyBox.storyId, storyBox.mediaList.first().mediaPath)
                    } else {
                        showStoryNotification(context, title, body, null, image)
                    }
                } else if (type == "random") {
                    val memoryBox = MemorySDK.get().getMemoryForNotification()
                    if (memoryBox != null) {
                        showMemoryNotification(context, memoryTitles.random(), "${memoryBox.title} - ${memoryBox.subTitle}", memoryBox.memoryId, memoryBox.coverImage)
                    } else {
                        showMemoryNotification(context, title, body, null, image)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    suspend fun showStoryNotification(context: Context, title: String, body: String, storyId: Long?, image: String) {
        val bitmap = try {
            if (!image.startsWith("http")) {
                BitmapFactory.decodeFile(image)
            } else {
                Glide.with(context)
                    .asBitmap()
                    .load(image)
                    .override((context.realScreenSize.x * 0.7).toInt())
                    .submit()
                    .get()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }

        var intent = if (storyId != null) Intent(context, NewStoryActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .setAction("FINISH_AFFINITY")
            .putExtra("storyId", storyId)
        else
            Intent(context, SplashActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .setAction("FINISH_AFFINITY")
                .putExtra("screen", "memoryTab")

        intent.putExtra("isFromNotification", true)
        val pendingIntent = PendingIntent.getActivity(context, 1, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationBuilder = NotificationCompat.Builder(context, "StoryNotification")
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true).setOnlyAlertOnce(true)
        if (bitmap != null) {
            val style = NotificationCompat.BigPictureStyle().bigPicture(bitmap)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                style.showBigPictureWhenCollapsed(true)
            }
            notificationBuilder.setStyle(style)
        }
        notificationBuilder.setVibrate(LongArray(0))

        notificationBuilder.setChannelId("StoryNotification")
        val mChannel = NotificationChannel(
            "StoryNotification",
            "StoryNotification",
            NotificationManager.IMPORTANCE_HIGH
        )
        mChannel.description = "Notifications are info related."
        mChannel.lockscreenVisibility = VISIBILITY_PUBLIC
        mChannel.enableLights(true)
        mChannel.lightColor = Color.RED
        mChannel.enableVibration(true)
        mChannel.setShowBadge(true)
        mChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
        notificationBuilder.setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
        notificationManager.createNotificationChannel(mChannel)
        cancelFCMDefaultNotification(context)
        notificationManager.notify(storyId.hashCode(), notificationBuilder.build())
    }

    suspend fun showMemoryNotification(context: Context, title: String, body: String, memoryId: Long?, image: String) {
        val bitmap = try {
            if (!image.startsWith("http")) {
                BitmapFactory.decodeFile(image)
            } else {
                Glide.with(context)
                    .asBitmap()
                    .load(image)
                    .override((context.realScreenSize.x * 0.7).toInt())
                    .submit()
                    .get()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }


        var intent = if (memoryId != null) Intent(context, MemoryViewerActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .setAction("FINISH_AFFINITY")
            .putExtra("memoryId", memoryId)
        else
            Intent(context, SplashActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .setAction("FINISH_AFFINITY")
                .putExtra("screen", "memoryTab")

        intent.putExtra("isFromNotification", true)
        val pendingIntent = PendingIntent.getActivity(context, 1, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationBuilder = NotificationCompat.Builder(context, "StoryNotification")
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true).setOnlyAlertOnce(true)
        if (bitmap != null) {
            val style = NotificationCompat.BigPictureStyle().bigPicture(bitmap)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                style.showBigPictureWhenCollapsed(true)
            }
            notificationBuilder.setStyle(style)
        }
        notificationBuilder.setVibrate(LongArray(0))

        notificationBuilder.setChannelId("MemoryNotification")
        val mChannel = NotificationChannel(
            "MemoryNotification",
            "MemoryNotification",
            NotificationManager.IMPORTANCE_HIGH
        )
        mChannel.description = "Notifications are info related."
        mChannel.lockscreenVisibility = VISIBILITY_PUBLIC
        mChannel.enableLights(true)
        mChannel.lightColor = Color.RED
        mChannel.enableVibration(true)
        mChannel.setShowBadge(true)
        mChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
        notificationBuilder.setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
        notificationManager.createNotificationChannel(mChannel)
        cancelFCMDefaultNotification(context)
        notificationManager.notify(memoryId.hashCode(), notificationBuilder.build())
    }
}