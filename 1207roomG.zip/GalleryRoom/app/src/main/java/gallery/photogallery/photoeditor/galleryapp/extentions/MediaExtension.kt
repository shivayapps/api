package gallery.photogallery.photoeditor.galleryapp.extentions

import android.app.Activity
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
 import com.editify_editor.photo.editor.activities.PolishEditorActivity
import com.editify_editor.photo.editor.polish.PolishPickerView
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.videoplayer.VideoPlayerActivity

fun BaseActivity.playVideo(filePath: String) {
    val uri = sharedViewModel.getFileURIFromPath(filePath)
    uri?.let {
        playVideo(uri)
    }
}


@OptIn(UnstableApi::class)
fun Activity.playVideo(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW, uri, this, VideoPlayerActivity::class.java)
        intent.flags = FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)

}

fun BaseActivity.editPhoto(path: String, clearTask: Boolean = false) {
    checkStoragePermission {
        if (it) {
            val intent = Intent(this, PolishEditorActivity::class.java)
            intent.putExtra(PolishPickerView.KEY_SELECTED_PHOTOS, path)
            if (clearTask) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            }
            startActivity(intent)
        }
    }
}