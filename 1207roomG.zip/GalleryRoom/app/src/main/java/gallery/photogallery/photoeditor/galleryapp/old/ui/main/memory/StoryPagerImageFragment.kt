package gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ImageView
import androidx.annotation.OptIn
import androidx.fragment.app.Fragment
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.appblish.box.api.model.MediaBox
import com.appblish.medialoader.AppblishImageLoader.loadFullBlur
import com.appblish.medialoader.AppblishImageLoader.loadFullImage
import com.appblish.story.memories.api.core.MemorySDK
import com.appblish.story.memories.api.model.StoryBox
import com.bumptech.glide.Glide
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.activities.ShareStoryTrasActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.StoryImageItemBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.StoryItemViewerBinding
import gallery.photogallery.photoeditor.galleryapp.old.storyview.ExoPlayerCache
import gallery.photogallery.photoeditor.galleryapp.old.storyview.screen.ShareStoryActivity
import gallery.photogallery.photoeditor.galleryapp.old.storyview.screen.StoryMoreDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.GO_TO_PHOTO
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.sendMemoryEvent
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.delayExecution
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isImageFast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isVideoFast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.memory.story_progressbar.MultiProgressBar
import java.io.File
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

class StoryPagerImageFragment : Fragment() {
    lateinit var binding: StoryItemViewerBinding
    private var storyMemoryWithMediaModel: StoryBox? = null
    private var isHigh: Boolean = false
    private var isShowToolbar = false
    private val storyOneSlideTime by lazy { MemorySDK.get().getStoryOneSlideTime() }
    private val imageAdaptor by lazy { ImageAdaptor(this, storyMemoryWithMediaModel?.title) }
    private var simpleExoPlayer: ExoPlayer? = null

    companion object {
        @JvmStatic
        fun newInstance(param: StoryBox, high: Boolean) =
            StoryPagerImageFragment().apply {
                storyMemoryWithMediaModel = param
                isHigh = high
            }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = StoryItemViewerBinding.inflate(layoutInflater, container, false)
        binding.clToolbar.setPadding(0, requireActivity().statusBarHeight, 0, 0)
        binding.llMusic.setPadding(0, 0, 0, requireActivity().navigationBarHeight)
        hideToolbar()
        return binding.root
    }


    fun isStoryShareShowOnEnd() = isAdded && ((requireActivity().intent.hasExtra("isFromNotification")) || (!requireActivity().preferences.onStoryShareDone && imageAdaptor.itemCount > 3))
    private fun isLastItem() = binding.viewPager2.currentItem >= imageAdaptor.itemCount - 1

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (storyMemoryWithMediaModel != null) {
            binding.viewPager2.adapter = imageAdaptor
            imageAdaptor.updateMedia(storyMemoryWithMediaModel!!.mediaList)
            binding.storyProgressBar.setSingleDisplayTime(storyOneSlideTime.toFloat())
            binding.storyProgressBar.setProgressStepsCount(imageAdaptor.itemCount)
            binding.viewPager2.offscreenPageLimit = 3
            binding.viewPager2.isUserInputEnabled = false
            binding.viewPager2.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    super.onPageSelected(position)
                    val mediaBox = imageAdaptor.getStoryMedia(position)
                    updateSeen(mediaBox)
                }
            })
            updateTitle()
            updateMusicIcon()
            binding.storyProgressBar.setListener(object : MultiProgressBar.ProgressStepChangeListener {
                override fun onProgressStepChange(newStep: Int) {
                    if (newStep <= imageAdaptor.itemCount - 1) {
                        if (binding.btnNext.isVisible()) {
                            binding.viewPager2.tag = newStep
                            binding.viewPager2.setCurrentItem(newStep, false)
                            updateTitle()
                        }
                    } else {
                        if (isStoryShareShowOnEnd()) {
                            showShare()
                        }
                    }
                }

            })
            binding.storyProgressBar.setFinishListener(object : MultiProgressBar.ProgressFinishListener {
                override fun onProgressFinished() {
                    if (!isStoryShareShowOnEnd()) {
                        if (isAdded) {
                            (requireActivity() as? NewStoryActivity)?.moveNext()
                        }
                    } else {
                        showShare()
                    }
                }
            })
            binding.ivClose.setOnClickListener { requireActivity().finish() }
            binding.ivMusic.setOnClickListener {
                (requireActivity() as? NewStoryActivity)?.toggleVolume()
            }
            binding.ivMore.setOnClickListener {
                pauseProgress()
                (requireActivity() as? NewStoryActivity)?.togglePlayer()
                simpleExoPlayer?.pause()
                val dialog = StoryMoreDialog.newInstance(binding.storyDisplayTime.text.toString()) {
                    when (it) {
                        "Share" -> {
                            shareStory()
                        }

                        "Remove" -> {
                            val storyMedia = imageAdaptor.getMedia(binding.viewPager2.currentItem)
                            (requireActivity() as? NewStoryActivity)?.sharedViewModel?.deleteStoryMedia(storyMemoryWithMediaModel!!.storyId, storyMedia)
                            if (imageAdaptor.itemCount == 1) {
                                (requireActivity() as? NewStoryActivity)?.finish()
                            } else {
                                imageAdaptor.removeMedia(storyMedia.mediaPath)
                                binding.storyProgressBar.setProgressStepsCount(imageAdaptor.itemCount)
                                if (isLastItem()) {
                                    binding.viewPager2.currentItem = binding.viewPager2.currentItem--
                                }
                                startStoryProgress()

                            }
                        }

                        "ViewDay" -> {
                            requireActivity().finish()
                            sendMemoryEvent(GO_TO_PHOTO, imageAdaptor.getStoryMedia(binding.viewPager2.currentItem))
                        }

                        "Dismiss" -> {
                            (requireActivity() as? NewStoryActivity)?.togglePlayer()
                            startStoryProgress()
                            simpleExoPlayer?.playWhenReady = true
                        }
                    }
                }
                dialog.show(childFragmentManager, "GO_TO_PHOTO")
            }
            var indexOfLastSeen = storyMemoryWithMediaModel!!.mediaSeenList.size
            val isAllSeen = storyMemoryWithMediaModel!!.mediaSeenList.size == storyMemoryWithMediaModel!!.mediaList.size
            if (isAllSeen) {
                indexOfLastSeen = 0
            }
            (requireActivity() as? NewStoryActivity)?.isOpenSeen = false
            binding.viewPager2.setCurrentItem(indexOfLastSeen, false)
            playVideo(false)
        }

    }

    fun playVideo(isPlayWhenReady: Boolean) {
        requireActivity().delayExecution(200) {
            if (!isAdded) return@delayExecution
            val filePath = imageAdaptor.getStoryMedia(binding.viewPager2.currentItem).mediaPath
            if (filePath.isVideoFast()) {
                (binding.viewPager2.adapter as? ImageAdaptor)?.playVideo(filePath, isPlayWhenReady)
            }
        }
    }

    fun clickPrevious() {
        if (isLastItem()) {
            movePrevious()
        } else {
            movePrevious()
        }
    }

    fun clickNext() {
        if (isLastItem()) {
            if (isStoryShareShowOnEnd()) {
                showShare()
            } else {
                moveNext()
            }
        } else {
            moveNext()
        }
    }

    private fun showShare() {
        requireActivity().preferences.onStoryShareDone = true
        binding.storyDisplayTime.beGone()
        binding.storyDisplayTitle.beGone()
        binding.llMusic.beGone()
        binding.ivMore.beGone()
        binding.btnNext.beGone()
        binding.btnPrevious.beGone()
        (requireActivity() as? NewStoryActivity)?.disableViewPager()
        requireActivity().delayExecution(500) {
            binding.storyProgressBar.pause()
        }
        startActivity(Intent(requireActivity(), ShareStoryTrasActivity::class.java).apply {
            putExtra("isTaskRootCheck", requireActivity().isTaskRoot)
            putExtra("storyId", storyMemoryWithMediaModel!!.storyId)
        })
    }

    private fun shareStory(selectAll: Boolean = false) {
        val storiesPath: ArrayList<String> = ArrayList()
        imageAdaptor.getMediaList().forEach {
            storiesPath.add(it.mediaPath)
        }
        val intent = Intent(requireActivity(), ShareStoryActivity::class.java)
        intent.putExtra("story_pos", binding.viewPager2.currentItem)
        intent.putStringArrayListExtra("story_array", storiesPath)
        if (selectAll) {
            intent.putExtra("selectAll", true)
        }
        startActivity(intent)

    }

    private fun moveNext() {
        binding.btnNext.beVisible()
        binding.btnPrevious.beVisible()
        if (binding.viewPager2.adapter != null) {
            val nextItem = (binding.viewPager2.currentItem + 1) % binding.viewPager2.adapter!!.itemCount
            if (nextItem == 0) {
                (requireActivity() as? NewStoryActivity)?.moveNext()
            } else {
                binding.viewPager2.setCurrentItem(nextItem, false)
                startStoryProgress()
            }
        }
    }

    private fun movePrevious() {
        if (binding.viewPager2.adapter != null) {
            val previousItem = binding.viewPager2.currentItem - 1
            if (previousItem < 0) {
                (requireActivity() as? NewStoryActivity)?.movePrevious()
            } else {
                binding.viewPager2.setCurrentItem(previousItem, false)
                startStoryProgress()
            }
        }
    }

    fun updateMusicIcon() {
        if (!isAdded) return
        if (requireActivity() is NewStoryActivity) {
            val newStoryActivity = requireActivity() as NewStoryActivity
            binding.ivMusic.setImageResource(if (newStoryActivity.isVolumeEnabled()) R.drawable.ic_music_on else R.drawable.ic_music_off)
            val filePath = imageAdaptor.getStoryMedia(binding.viewPager2.currentItem).mediaPath
            if (filePath.isVideoFast()) {
                if (newStoryActivity.isVolumeEnabled()) {
                    simpleExoPlayer?.volume = 1f
                } else {
                    simpleExoPlayer?.volume = 0f
                }
            }
        }
    }

    fun updateTitle() {
        binding.storyDisplayTitle.text = storyMemoryWithMediaModel!!.title
        val currentFile = imageAdaptor.getMedia(binding.viewPager2.currentItem)
        val timestamp: Long = currentFile.mediaDate
        val formattedDate = longToDateString(timestamp)
        val result = formattedDate.substringBefore(" ")
        val dateTime = convertDateFormat(result)
        binding.storyDisplayTime.text = dateTime
    }

    private fun longToDateString(timestamp: Long): String {
        val date = Date(timestamp)
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        return formatter.format(date)
    }

    private fun convertDateFormat(dateString: String): String {
        val inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US)
        val outputFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.US)
        val date = LocalDate.parse(dateString, inputFormatter)
        return date.format(outputFormatter)
    }

    fun onLongPressCalled() {
        hideToolbar()
        pauseProgress()
    }

    fun startStoryProgress() {
        showToolbar()
        binding.storyProgressBar.pause()
        binding.storyProgressBar.start(binding.viewPager2.currentItem)
        val filePath = imageAdaptor.getStoryMedia(binding.viewPager2.currentItem).mediaPath
        if (filePath.isVideoFast()) {
            simpleExoPlayer?.playWhenReady = true
            updateMusicIcon()
        }
    }

    fun pauseProgress() {
        binding.storyProgressBar.pause()
        simpleExoPlayer?.playWhenReady = false
    }

    fun resumeProgress() {
        simpleExoPlayer?.playWhenReady = true
    }

    private fun loadImage(storyImage: ImageView, storyImageBlur: ImageView, filePath: String) {
        val lastModified = File(filePath).lastModified()
        if (filePath.isVideoFast()) {
            storyImage.scaleType = ImageView.ScaleType.CENTER_CROP
            storyImageBlur.beGone()
        } else {
            storyImageBlur.loadFullBlur(filePath, lastModified)
            storyImageBlur.beVisible()
        }
        storyImage.loadFullImage(filePath, lastModified) {
            val isCenterCrop = (it.intrinsicWidth < it.intrinsicHeight && it.intrinsicHeight >= it.intrinsicWidth * 0.3)
            if (isCenterCrop) {
                storyImage.scaleType = ImageView.ScaleType.CENTER_CROP
            } else {
                storyImage.scaleType = ImageView.ScaleType.FIT_CENTER
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()

    }

    private fun hideToolbar() {
        if (!isAdded) return
        isShowToolbar = false
        binding.clToolbar.animate()
            .setDuration(300)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .alpha(0f)

        binding.topShadow.animate()
            .setDuration(300)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .alpha(0f)

        binding.bottomShadow.animate()
            .setDuration(300)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .alpha(0f)

        binding.llMusic.animate()
            .setDuration(300)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .alpha(0f)
        requireActivity().window?.insetsController?.hide(WindowInsets.Type.navigationBars())
        requireActivity().window?.insetsController?.hide(WindowInsets.Type.statusBars())
    }

    private fun showToolbar() {
        if (!isAdded) return
        isShowToolbar = true
        binding.clToolbar.animate()
            .setDuration(300)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .alpha(1f)

        binding.topShadow.animate()
            .setDuration(300)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .alpha(1f)

        binding.bottomShadow.animate()
            .setDuration(300)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .alpha(1f)

        binding.llMusic.animate()
            .setDuration(300)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .alpha(1f)
        requireActivity().window?.insetsController?.show(WindowInsets.Type.navigationBars())
        requireActivity().window?.insetsController?.show(WindowInsets.Type.statusBars())
    }

    class ImageAdaptor(private val storyPagerImageFragment: StoryPagerImageFragment, val title: String?) : RecyclerView.Adapter<ImageAdaptor.ViewHolder>() {

        private val holders = mutableListOf<ViewHolder>()
        private var mediaList = ArrayList<MediaBox>()
        fun updateMedia(mediaList: List<MediaBox>) {
            this.mediaList = ArrayList(mediaList)
            if (this.mediaList.isEmpty()) {
                storyPagerImageFragment.requireActivity().finish()
            }
            notifyDataSetChanged()
        }

        fun removeMedia(filePath: String) {
            this.mediaList.removeIf { it.mediaPath == filePath }
            if (this.mediaList.isEmpty()) {
                storyPagerImageFragment.requireActivity().finish()
            }
            notifyDataSetChanged()
        }

        fun getStoryMedia(position: Int) = mediaList[position]
        fun getMedia(position: Int) = mediaList[position]
        fun getMediaList() = mediaList

        inner class ViewHolder(val binding: StoryImageItemBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            return ViewHolder(StoryImageItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)).also {
                holders.add(it)
            }
        }

        override fun onViewRecycled(holder: ImageAdaptor.ViewHolder) {
            super.onViewRecycled(holder)
            try {
                val photoView = getImageView(holder.bindingAdapterPosition)
                photoView?.let {
                    Glide.with(storyPagerImageFragment.requireActivity().applicationContext).clear(it)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }


        fun getImageView(position: Int): ImageView? {
            try {
                val viewHolder = holders.firstOrNull {
                    it.bindingAdapterPosition == position
                }
                val viewBinding = StoryImageItemBinding.bind(viewHolder!!.itemView)
                return viewBinding.storyImage
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return null
        }

        fun getViewBinding(position: Int): StoryImageItemBinding? {
            try {
                val viewHolder = holders.firstOrNull {
                    it.bindingAdapterPosition == position
                }
                return StoryImageItemBinding.bind(viewHolder!!.itemView)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return null
        }

        override fun getItemCount() = mediaList.size

        @SuppressLint("ClickableViewAccessibility")
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            with(holder) {
                try {
                    val realPhotosModel = mediaList[position].mediaPath
                    storyPagerImageFragment.loadImage(binding.storyImage, binding.storyImageBlur, realPhotosModel)
                    if (realPhotosModel.isImageFast()) {
                        binding.storyDisplayVideo.beGone()
                    }

                    binding.tvStoryTitle.text = title
                    binding.image.scaleType = ImageView.ScaleType.CENTER_CROP
                    binding.tvSkip.setOnClickListener {
                        storyPagerImageFragment.moveNext()
                        (storyPagerImageFragment.requireActivity() as? NewStoryActivity)?.enableViewPager()
                        binding.llShareMemory.beGone()
                    }
                    binding.tvShare.setOnClickListener {
                        (storyPagerImageFragment.requireActivity() as? NewStoryActivity)?.let {
                            storyPagerImageFragment.shareStory(true)
                        }

                    }
                    binding.storyDisplayVideo.setOnTouchListener { _, event ->
                        (storyPagerImageFragment.requireActivity() as? NewStoryActivity)?.onPagerTouchEvent(event)
                        true
                    }
                } catch (e: Exception) {
                    e.printStackTrace()

                }
            }
        }

        fun showShare(position: Int) {
            getViewBinding(position)?.llShareMemory?.beVisible()
        }

        @OptIn(UnstableApi::class)
        fun playVideo(filePath: String, isPlayWhenReady: Boolean) {
            storyPagerImageFragment.releaseVideoPlayer()
            storyPagerImageFragment.simpleExoPlayer = ExoPlayer.Builder(storyPagerImageFragment.requireContext().applicationContext).build()
            val mediaItem = MediaItem.fromUri(filePath)
            getViewBinding(0)?.let {
                it.storyDisplayVideo.player = storyPagerImageFragment.simpleExoPlayer
                it.storyDisplayVideo.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                storyPagerImageFragment.simpleExoPlayer?.apply {
                    val mediaSource = ProgressiveMediaSource.Factory(
                        ExoPlayerCache.getCacheFactory(storyPagerImageFragment.requireContext().applicationContext)
                    ).createMediaSource(mediaItem)
                    setMediaSource(mediaSource)
                    volume = if (isPlayWhenReady) 1f else 0f
                    seekTo(0)
                    playWhenReady = isPlayWhenReady
                    addListener(object : Player.Listener {
                        override fun onPlaybackStateChanged(state: Int) {
                            when (state) {
                                Player.STATE_BUFFERING -> {
                                    // Video is buffering, you can show a loading spinner or do nothing
                                    // You may optionally show a loading view here
                                }

                                Player.STATE_READY -> {
                                    // Once the player is ready, show the player view
                                    it.storyDisplayVideo.beVisible()
                                    it.storyImage.animate()
                                        .setDuration(300)
                                        .setInterpolator(AccelerateDecelerateInterpolator())
                                        .alpha(0f)
                                }

                                Player.STATE_ENDED -> {
                                    it.storyImage.beVisible()
                                    // Optionally handle video end (replay, etc.)
                                }

                                Player.STATE_IDLE -> {
                                }
                            }
                        }
                    })
                    prepare()
                }
            }
        }

    }

    fun releaseVideoPlayer() {
        simpleExoPlayer?.stop()
        simpleExoPlayer?.release()
        simpleExoPlayer = null
        imageAdaptor.getViewBinding(0)?.let {
            it.storyImage.beVisible()
            it.storyImage.alpha = 1f
        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        releaseVideoPlayer()
    }

    private fun updateSeen(mediaBox: MediaBox) {
        (requireActivity() as? NewStoryActivity)?.sharedViewModel?.updateStorySeen(storyMemoryWithMediaModel!!.storyId, mediaBox)
    }
}