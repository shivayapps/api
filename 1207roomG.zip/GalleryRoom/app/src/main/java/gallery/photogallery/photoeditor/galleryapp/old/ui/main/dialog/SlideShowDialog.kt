package gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogSlideshowBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.RadioItem
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Preferences

class SlideShowDialog(private val context: Context, val updateListener: () -> Unit) : DialogFragment() {

    private var _binding: DialogSlideshowBinding? = null
    private val binding get() = _binding!!

    lateinit var preferences: Preferences
    private var slideEffect = 0
    private var slideTime = 1

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogSlideshowBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(requireContext().getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        intView()
        return dialog
    }

    @SuppressLint("SetTextI18n")
    private fun intView() {
        preferences = Preferences(requireActivity())
        slideEffect = preferences.getInt(Constant.PREF_SLIDE_EFFECT)
        slideTime = preferences.getInt(Constant.PREF_SLIDE_TIME, 1)

        intListener()

        binding.checkVideo.isChecked = preferences.getBoolean(Constant.PREF_SLIDE_INCLUDE_VIDEO)
        binding.checkGif.isChecked = preferences.getBoolean(Constant.PREF_SLIDE_INCLUDE_GIF)
        binding.checkRandom.isChecked = preferences.getBoolean(Constant.PREF_SLIDE_RANDOM_ORDER)
        binding.checkBackward.isChecked = preferences.getBoolean(Constant.PREF_SLIDE_BACKWARD)
        binding.checkLoop.isChecked = preferences.getBoolean(Constant.PREF_SLIDE_LOOP)
        binding.edtTime.text = "${slideTime}s"

        binding.tvEffect.text = Constant.AnimationTypes.entries[slideEffect].value

        binding.tvEffect.setOnClickListener {
            val items: ArrayList<RadioItem> = ArrayList()
            for (effect in Constant.AnimationTypes.entries) {
                items.add(RadioItem(effect.id, effect.value))
            }
            val radioGroupDialog = RadioGroupDialog(context, items, slideEffect) {
                slideEffect = it
                preferences.setInt(Constant.PREF_SLIDE_EFFECT, slideEffect)
                binding.tvEffect.text = items[slideEffect].title
            }
            radioGroupDialog.show()
        }

        binding.icMinus.setOnClickListener {
            if (slideTime > 1) {
                slideTime -= 1
                binding.edtTime.text = "${slideTime}s"
            }
        }

        binding.icPlus.setOnClickListener {
            slideTime += 1
            binding.edtTime.text = "${slideTime}s"
        }
    }
    private fun intListener() {
        binding.btnCancel.setOnClickListener {
            dismiss()
        }
        binding.btnOK.setOnClickListener {
            preferences.setBoolean(
                Constant.PREF_SLIDE_INCLUDE_VIDEO,
                binding.checkVideo.isChecked
            )
            preferences.setBoolean(
                Constant.PREF_SLIDE_INCLUDE_GIF,
                binding.checkGif.isChecked
            )
            preferences.setBoolean(
                Constant.PREF_SLIDE_RANDOM_ORDER,
                binding.checkRandom.isChecked
            )
            preferences.setBoolean(
                Constant.PREF_SLIDE_BACKWARD,
                binding.checkBackward.isChecked
            )
            preferences.setBoolean(Constant.PREF_SLIDE_LOOP, binding.checkLoop.isChecked)

            preferences.setInt(Constant.PREF_SLIDE_EFFECT, slideEffect)
            preferences.setInt(Constant.PREF_SLIDE_TIME, slideTime)
            dismiss()
            updateListener()
        }
    }
}