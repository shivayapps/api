package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import gallery.photogallery.photoeditor.galleryapp.permission.PermissionSDK
import gallery.photogallery.photoeditor.galleryapp.R

object NotificationHelper {

    fun createNotificationChannel(context: Context, title: String, message: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel("gallery_channel", title, importance).apply {
                description = message
            }
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    @SuppressLint("MissingPermission")
    fun submitNotification(context: Context, title: String, message: String, progress: Int) {
        val notificationManager = NotificationManagerCompat.from(context)

        val notification =
            NotificationCompat.Builder(context, "gallery_channel")
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()

        if (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                PermissionSDK.hasNotificationPermission(context)
            } else {
                true
            }
        ) {
            notificationManager.notify(111, notification)
        }
    }

    @SuppressLint("MissingPermission")
    fun submitProgressNotification(context: Context, title: String, message: String, progress: Int) {
        val notificationManager = NotificationManagerCompat.from(context)
        var m = 100
        var p = progress
        if (progress < 0) {
            m = 0
            p = 0
        }

        val notification =
            NotificationCompat.Builder(context, "gallery_channel")
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_delete)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setProgress(m, p, false)
                .build()

        if (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                PermissionSDK.hasNotificationPermission(context)
            } else {
                true
            }
        ) {
            notificationManager.notify(111, notification)
        }
    }

}