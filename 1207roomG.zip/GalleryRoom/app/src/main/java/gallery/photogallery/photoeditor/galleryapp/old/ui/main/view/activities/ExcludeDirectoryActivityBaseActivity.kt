package gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityExcludeDirectoryBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding


class ExcludeDirectoryActivityBaseActivity : BaseActivity() {

    companion object {
        fun createExcludeManageIntent(context: Context): Intent {
            return Intent(context, ExcludeDirectoryActivityBaseActivity::class.java)
        }
    }

    private val binding by viewBinding(ActivityExcludeDirectoryBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.root.setPadding(0, 0, 0, navigationBarHeight)
        binding.clToolbar.setPadding(0, statusBarHeight, 0, 0)
        initView()
    }

    private fun initView() {
        getData()
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        intListener()
    }

    private fun intListener() {
        binding.ivBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun getData() {
       /* CoroutineScope(Dispatchers.IO).launch {
            val dirList = AllMediaBoxOperations.getExcludeFolderList(getApp())
            runOnUiThread {
                binding.recyclerView.adapter = ExcludeDirectoryAdapter(this@ExcludeDirectoryActivity, dirList)
                setEmptyData()
            }
        }*/
    }

    fun setEmptyData() {
        if (binding.recyclerView.adapter!!.itemCount != 0) {
            binding.recyclerView.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.llBottom.beVisible()
        } else {
            binding.recyclerView.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.llBottom.beGone()
        }
    }
}
