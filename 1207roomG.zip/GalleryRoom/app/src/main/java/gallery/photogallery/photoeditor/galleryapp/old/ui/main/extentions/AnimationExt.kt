package gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.widget.ImageView

fun ImageView.startZoomInZoomOut(isPlaying: Boolean = true) {
    if (scaleX == 2f) {

// Zoom out animation (scale down)
        val zoomOutAnimator = ObjectAnimator.ofFloat(this, "scaleX", 1.05f, 1f)
        zoomOutAnimator.duration = 4600
        val zoomOutYAnimator = ObjectAnimator.ofFloat(this, "scaleY", 1.05f, 1f)
        zoomOutYAnimator.duration = 4600
        val animatorSet = AnimatorSet()
        animatorSet.playTogether(zoomOutAnimator, zoomOutYAnimator)
        tag = animatorSet
        if (isPlaying) {
            animatorSet.start()
        }
    } else {
        // Zoom in animation (scale up)
        val zoomInAnimator = ObjectAnimator.ofFloat(this, "scaleX", 1f, 1.05f)
        zoomInAnimator.duration = 4600

        val zoomInYAnimator = ObjectAnimator.ofFloat(this, "scaleY", 1f, 1.05f)
        zoomInYAnimator.duration = 4600
// You can play the animations together
        val animatorSet = AnimatorSet()
        animatorSet.playTogether(zoomInAnimator, zoomInYAnimator)
        tag = animatorSet
        if (isPlaying) {
            animatorSet.start()
        }
    }

}