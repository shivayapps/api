package gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions

import android.content.Context
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.ThemePref

val Context.themePref: ThemePref get() = ThemePref(applicationContext)
fun Context.getAppBackgroundColor() = themePref.appBackgroundColor
fun Context.getAppSubBackgroundColor() = themePref.appSubBackgroundColor
fun Context.getAppTextColor() = themePref.appTextColor
fun Context.getAppSubTextColor() = themePref.appSubTextColor
fun Context.getAppPrimaryColor() = themePref.appPrimaryColor