package gallery.photogallery.photoeditor.galleryapp.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.ScrollGate
import com.appblish.box.api.util.AppblishEvent
import com.appblish.box.api.util.MediaDataState
import com.cleaner.v2.api.model.CleanerListItem
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.adaptor.CleanerScanDeleteAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityCleanerScanDeleteBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.showDeleteDialog
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.util.Locale

class CleanerScanDeleteActivity : BaseActivity() {
    private val binding by viewBinding(ActivityCleanerScanDeleteBinding::inflate)
    private val cleanerOption by lazy { intent.getIntExtra("CLEAN_UP_PHOTO", 0) }
    private val cleanerScanDeleteAdapter by lazy { CleanerScanDeleteAdapter(isType = cleanerOption) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.main)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        registerEventBus(this)
        init()
        clickListener()
    }

    private fun init() {

        when (cleanerOption) {
            1 -> {
                binding.txtTitle.text = getString(R.string.clean_up_similar_photos)

                binding.ivSmartChoice.beVisible()
                binding.txtSmartChoice.beVisible()
                lifecycleScope.launch {
                    val state = sharedViewModel.getDuplicateMediaFlow()
                    when (state) {
                        is MediaDataState.Loading -> {
                        }

                        is MediaDataState.Progress -> {

                        }

                        is MediaDataState.Success -> {
                            val data = state.data
                            runOnUiThread {
                                setMedias(data)
                            }
                        }

                        MediaDataState.Empty -> {}
                    }
                }

            }

            2 -> {
                binding.txtTitle.text = getString(R.string.clean_up_large_video_files)
                lifecycleScope.launch {
                    val state = sharedViewModel.getLargeVideMediaFlow()
                    when (state) {
                        is MediaDataState.Loading -> {
                        }

                        is MediaDataState.Progress -> {

                        }

                        is MediaDataState.Success -> {
                            val data = state.data
                            setMedias(data)
                        }

                        MediaDataState.Empty -> {}
                    }
                }
            }

            3 -> {
                binding.txtTitle.text = getString(R.string.clean_up_screenshots)
                lifecycleScope.launch {
                    val state = sharedViewModel.getScreenshotMediaFlow()
                    when (state) {
                        is MediaDataState.Loading -> {
                        }

                        is MediaDataState.Progress -> {

                        }

                        is MediaDataState.Success -> {
                            val data = state.data
                            setMedias(data)
                        }

                        MediaDataState.Empty -> {}
                    }
                }
            }
        }

        binding.rvClearMedia.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING || newState == RecyclerView.SCROLL_STATE_SETTLING) {
                    ScrollGate.onScrollStart()
                } else {
                    ScrollGate.onScrollStop()
                }
            }
        })

    }

    private fun setMedias(items: List<CleanerListItem>) {
        if (binding.rvClearMedia.adapter == null) {
            val spanCount = 3

            val layoutManager = GridLayoutManager(this, spanCount)
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    return when (cleanerScanDeleteAdapter.getItemViewType(position)) {
                        CleanerScanDeleteAdapter.HEADER -> spanCount // full width
                        CleanerScanDeleteAdapter.MEDIA -> 1
                        else -> 1
                    }
                }
            }
            binding.rvClearMedia.layoutManager = layoutManager
            binding.rvClearMedia.adapter = cleanerScanDeleteAdapter
        }

        cleanerScanDeleteAdapter.submitList(items)

        if (items.isEmpty()) {
            finish()
        }
    }


    var isSmartEnabled = false

    private fun clickListener() {

        //        onBackPressedDispatcher {
        //            if (cleanerScanDeleteAdapter.getSelectedCount() != 0) {
        //                cleanerScanDeleteAdapter.setSelectionEnabled(false)
        //            } else {
        //                finish()
        //            }
        //        }
        //
        binding.ivBack.setOnClickListener {
            finish()
        }

        binding.ivSmartChoice.setOnClickListener {
            isSmartEnabled = !isSmartEnabled

            val iconRes = if (isSmartEnabled) {
                R.drawable.vec_selected_bg
            } else {
                R.drawable.vec_unselected_bg
            }

            binding.ivSmartChoice.setImageResource(iconRes)

            with(cleanerScanDeleteAdapter) {
                if (isSmartEnabled) applySmartSelection() else clearSelection()
            }
        }

        cleanerScanDeleteAdapter.onSelectionChanged = { count, totalSize ->
            binding.btnDelete.text = "${getString(R.string.delete)} ${formatSize(totalSize)}"
            if (cleanerScanDeleteAdapter.isSelectAll()) {
                binding.icSelectAll.setImageResource(R.drawable.vec_selected_bg)
            } else {
                binding.icSelectAll.setImageResource(R.drawable.vec_unselected_bg)
            }
        }

        binding.btnDelete.setOnClickListener {
            if (cleanerScanDeleteAdapter.selectedItems.isNotEmpty()) {
                showDeleteDialog(
                    title = getString(R.string.are_you_sure_you_want_to_delete_the_selected_media),
                    subTitle = "",
                    positiveRes = R.string.delete,
                    onDeleteClick = {
                        val selectedMedia = cleanerScanDeleteAdapter.getSelectedMedia().map { it.mediaBox.mediaPath }
                        deleteFolderFiles(selectedMedia, true)
                        binding.btnDelete.text = "${getString(R.string.delete)} ${formatSize(0L)}"
                    })
            } else {
                toast(getString(R.string.please_select_at_least_one_photo))
            }
        }
        binding.icSelectAll.setOnClickListener {
            if (cleanerScanDeleteAdapter.isSelectAll()) {
                cleanerScanDeleteAdapter.unselectAll()
            } else {
                cleanerScanDeleteAdapter.selectAll()

            }
        }
    }

    private fun formatSize(bytes: Long): String {
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0

        return when {
            gb >= 1 -> String.format(Locale.ENGLISH, "%.2f GB", gb)
            mb >= 1 -> String.format(Locale.ENGLISH, "%.2f MB", mb)
            kb >= 1 -> String.format(Locale.ENGLISH, "%.2f KB", kb)
            else -> ""
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            AppblishEvent.ALL_CLEANER_LOADED -> {
                init()
            }
        }
    }

    override fun onDestroy() {
        unregisterEventBus(this)
        super.onDestroy()
    }
}