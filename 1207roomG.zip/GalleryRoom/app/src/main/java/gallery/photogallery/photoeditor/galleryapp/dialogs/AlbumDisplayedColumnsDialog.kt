package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogDisplayColumnsBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.utils.UPDATE_ALBUM_SHOW
import gallery.photogallery.photoeditor.galleryapp.utils.sendIntentEvent

class AlbumDisplayedColumnsDialog() : DialogFragment() {
    init {
        Log.e("TAG", "Init: ")
    }

    private var _binding: DialogDisplayColumnsBinding? = null

    private val binding get() = _binding!!

    companion object {
        fun newInstance(): AlbumDisplayedColumnsDialog {
            val groupDialog = AlbumDisplayedColumnsDialog()
            return groupDialog
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogDisplayColumnsBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(gallery.photogallery.photoeditor.galleryapp.R.color.transparent)
            setLayout(requireContext().getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER) // remove if you want center dialog
        }

        intView()
        return dialog
    }


    private fun intView() {
        val gridCount = requireContext().appPref.albumGrid
        intListener()

        when (gridCount) {
            2 -> binding.rb2Columns.isChecked = true
            3 -> binding.rb3Columns.isChecked = true
            4 -> binding.rb4Columns.isChecked = true
            5 -> binding.rb5Columns.isChecked = true
            6 -> binding.rb6Columns.isChecked = true
            else -> binding.rb3Columns.isChecked = true
        }
        binding.rb5Columns.beGone()
        binding.rb6Columns.beGone()
    }

    private fun intListener() {
        binding.btnOK.setOnClickListener {
            val selectedRadioButtonId: Int = binding.grpOption.checkedRadioButtonId
            requireContext().appPref.albumGrid = when (selectedRadioButtonId) {
                binding.rb2Columns.id -> 2
                binding.rb3Columns.id -> 3
                binding.rb4Columns.id -> 4
                else -> 3
            }
            sendIntentEvent(UPDATE_ALBUM_SHOW)
            dismiss()
        }
    }
}