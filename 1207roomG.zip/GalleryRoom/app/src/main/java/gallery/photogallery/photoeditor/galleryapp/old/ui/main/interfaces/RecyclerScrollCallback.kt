package gallery.photogallery.photoeditor.galleryapp.old.ui.main.interfaces

interface RecyclerScrollCallback {
    fun onScrolled(scrollY: Int)
}
