package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation

import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.viewpager2.widget.ViewPager2
import gallery.photogallery.photoeditor.galleryapp.R

class FadeOutTransformationSlow : ViewPager2.PageTransformer {

    private var isEnabled = true

    override fun transformPage(page: View, position: Float) {
        if (!isEnabled) {
            page.alpha = 1f
            page.translationX = 0f
            return
        }

        page.translationX = -position * page.width
        val targetAlpha = 1 - kotlin.math.abs(position)

        if (position in -1f..1f) {
            val lastAlpha = page.getTag(R.id.page_last_alpha) as? Float ?: -1f
            if (lastAlpha != targetAlpha) {
                page.animate()
                    .alpha(targetAlpha)
                    .setDuration(800)
                    .setInterpolator(DecelerateInterpolator())
                    .start()

                page.setTag(R.id.page_last_alpha, targetAlpha)
            }
        } else {
            page.alpha = 0f
            page.setTag(R.id.page_last_alpha, 0f)
        }
    }

    fun enable() {
        isEnabled = true
    }

    fun disable() {
        isEnabled = false
    }

    fun isEnabledFade() = isEnabled

}

