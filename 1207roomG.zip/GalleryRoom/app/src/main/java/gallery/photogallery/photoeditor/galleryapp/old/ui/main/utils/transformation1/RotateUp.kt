package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation1

import android.view.View
import androidx.viewpager.widget.ViewPager


class RotateUp : ViewPager.PageTransformer {

    override fun transformPage(view: View, position: Float) {
        val width = view.width
        val height = view.height
        val rotation = -15f * position * -1.25f

        view.pivotX = width * 0.5f
        view.pivotY = height.toFloat()
        view.rotation = rotation
    }

}