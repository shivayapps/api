package gallery.photogallery.photoeditor.galleryapp.old.job

import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import com.appblish.gallery.core.v2.api.core.GallerySdkV2
import java.util.Locale

class MediaContentObserver(
    val handler: Handler, private val context: Context
) : ContentObserver(handler) {
    val NOTIFY_NO_DELAY: Int = 1 shl 15
    val screenshotsPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_SCREENSHOTS).absolutePath
    var urifetch: Uri? = null

    val runnable = Runnable {
        urifetch?.let {
            Log.d("MediaContentObserver", "Change detected at URI: 1")
            if (it.toString().contains(MediaStore.Images.Media.EXTERNAL_CONTENT_URI.toString()) || it.toString().contains(MediaStore.Video.Media.EXTERNAL_CONTENT_URI.toString())) {
                Log.d("MediaContentObserver", "Change detected at URI: 2")
                if (isScreenshotUri(context, it)) {
                    Log.d("MediaContentObserver", "Change detected at URI: 3")

                    fetchNewMediaInsert(it)
                }
            }
        }
    }

    override fun onChange(selfChange: Boolean, uri: Uri?, flags: Int) {
        super.onChange(selfChange, uri, flags)
        Log.d("MediaContentObserver", "Change detected at flags uri: ${flags}")
        urifetch = uri
        handler.removeCallbacks(runnable)
        handler.postDelayed(runnable, 2000)
    }

    override fun onChange(selfChange: Boolean, uri: Uri?) {
        super.onChange(selfChange, uri)
        Log.d("MediaContentObserver", "Change detected at URI: $uri $selfChange")

    }

    companion object {
        var mediaContentObserver: MediaContentObserver? = null
        fun registerContentObserver(context: Context) {
            val contentResolver = context.contentResolver
            mediaContentObserver = MediaContentObserver(Handler(Looper.getMainLooper()), context)

            contentResolver.registerContentObserver(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, mediaContentObserver!!
            )

        }

        fun unregisterContentObserver(context: Context) {
            if (mediaContentObserver != null) {
                val contentResolver = context.contentResolver
                contentResolver.unregisterContentObserver(
                    mediaContentObserver!!
                )

            }
        }
    }

    fun fetchNewMediaInsert(uri: Uri) {
        try {
            GallerySdkV2.get().checkNewMedia {
                GallerySdkV2.get().fetchMedia()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun isScreenshotUri(context: Context, uri: Uri): Boolean {
        try {
            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                MediaStore.Images.Media.DISPLAY_NAME,
            )

            val cursor = context.contentResolver.query(
                uri,
                projection,
                null,
                null,
                null
            )

            cursor?.use {
                if (it.moveToFirst()) {
                    // Check for the "Screenshots" folder
                    val pathIndex = it.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
                    val titleIndex = it.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                    val title = it.getString(titleIndex)
                    val path = it.getString(pathIndex)
                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    Log.d("MediaContentObserver", "Change detected at URI: 4 $bucketPath")
                    Log.d("MediaContentObserver", "Change detected at URI: 5 $screenshotsPath")
                    if (bucketPath.lowercase(Locale.getDefault()).contains("screenshots") || bucketPath.lowercase(Locale.getDefault()).contains("camera")) {
                        return true
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }
}
