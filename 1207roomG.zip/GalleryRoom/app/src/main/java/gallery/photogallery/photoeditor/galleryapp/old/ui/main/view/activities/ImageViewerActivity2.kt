package gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities//package gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities
//
//import android.annotation.SuppressLint
//import android.content.Context
//import android.content.Intent
//import android.graphics.Bitmap
//import android.graphics.Color
//import android.graphics.drawable.ColorDrawable
//import android.media.MediaPlayer
//import android.os.Bundle
//import android.util.Log
//import android.view.LayoutInflater
//import android.view.ViewGroup
//import android.view.animation.AccelerateDecelerateInterpolator
//import android.widget.ImageView
//import androidx.activity.enableEdgeToEdge
//import androidx.core.content.ContextCompat
//import androidx.core.view.WindowCompat
//import androidx.core.view.doOnPreDraw
//import androidx.lifecycle.lifecycleScope
//import androidx.recyclerview.widget.LinearLayoutManager
//import androidx.recyclerview.widget.RecyclerView
//import androidx.viewpager2.widget.ViewPager2
//import com.bumptech.glide.Glide
//import com.bumptech.glide.load.DataSource
//import com.bumptech.glide.load.MultiTransformation
//import com.bumptech.glide.load.engine.DiskCacheStrategy
//import com.bumptech.glide.load.engine.GlideException
//import com.bumptech.glide.request.RequestListener
//import com.bumptech.glide.request.target.Target
//import com.bumptech.glide.signature.ObjectKey
//import gallery.photogallery.photoeditor.galleryapp.R
//import gallery.photogallery.photoeditor.galleryapp.database.greenDAO.objectbox.allmedia.ObjectMemoryModel
//import gallery.photogallery.photoeditor.galleryapp.database.greenDAO.objectbox.memories.MemoriesBoxOperations
//import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityImageViewerBinding
//import gallery.photogallery.photoeditor.galleryapp.databinding.ImageViewBottomBinding
//import gallery.photogallery.photoeditor.galleryapp.databinding.ItemImageViewerBinding
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.custom.CustomAnimatedImageViewMemory
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.MEMORY_ITEM_UPDATE
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.MemoryEvent
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.event.sendMemoryEvent
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.delayExecution
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.realScreenSize
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.startZoomInZoomOut
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.helpers.CustomCarouselLayoutManager
//import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation.FadePageTransformer
//import com.google.android.material.transition.platform.MaterialContainerTransformSharedElementCallback
//import jp.wasabeef.glide.transformations.BlurTransformation
//import jp.wasabeef.glide.transformations.ColorFilterTransformation
//import kotlinx.coroutines.CoroutineScope
//import kotlinx.coroutines.Dispatchers
//import kotlinx.coroutines.Job
//import kotlinx.coroutines.delay
//import kotlinx.coroutines.isActive
//import kotlinx.coroutines.launch
//import org.greenrobot.eventbus.Subscribe
//import org.greenrobot.eventbus.ThreadMode
//
//
//class ImageViewerActivity2 : BaseActivity() {
//    companion object {
//        fun startActivity(context: Context, options: Bundle? = null) {
//            val intent = Intent(context, ImageViewerActivity2::class.java)
//            context.startActivity(intent, options)
//        }
//    }
//
//
//    private val binding by viewBinding(ActivityImageViewerBinding::inflate)
//    private var mediaPlayer: MediaPlayer? = null
//    val autoScroll by lazy { AutoScrollCoroutine() }
//    var isUserScrolling = false
//    private var isShowToolbar = false
//    private lateinit var memoryModel: ObjectMemoryModel
//
//    private val mediaPlayPauseListener = {
//        val playIcon = ContextCompat.getDrawable(this, R.drawable.ic_play_vec)
//        val pauseIcon = ContextCompat.getDrawable(this, R.drawable.ic_pause_vec)
//        if (isMediaPlaying()) {
//            autoScroll.start()
//        } else {
//            autoScroll.stop()
//        }
//        binding.ivPlayPause.setImageDrawable(if (isMediaPlaying()) pauseIcon else playIcon)
//    }
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
////        postponeEnterTransition()
//        enableEdgeToEdge()
//        setContentView(binding.root)
//        memoryModel = (getApp().intentMap["memory"] as? ObjectMemoryModel) ?: return
//        val controller = WindowCompat.getInsetsController(window, window.decorView)
//        controller.isAppearanceLightNavigationBars = false
//        window.sharedElementEnterTransition = null
//        setEnterSharedElementCallback(MaterialContainerTransformSharedElementCallback())
//        initViews()
//        setupPager()
//    }
//
//    @SuppressLint("ClickableViewAccessibility")
//    private fun initViews() {
//        binding.clToolbar.setPadding(0, statusBarHeight, 0, 0)
//        binding.bottomBar.setPadding(0, 0, 0, navigationBarHeight)
//        binding.tvTitle.text = memoryModel.title
//        binding.tvSubTitle.text = memoryModel.subTitle
//        if (memoryModel.isFavorite()) {
//            binding.ivFav.setImageResource(R.drawable.vec_favorite_fill)
//        } else {
//            binding.ivFav.setImageResource(R.drawable.vec_favorite_un_fill)
//        }
//        binding.ivFav.setOnClickListener {
//            if (memoryModel.isFavorite()) {
//                memoryModel.setFavorite(0)
//            } else {
//                memoryModel.setFavorite(1)
//            }
//            if (memoryModel.isFavorite()) {
//                binding.ivFav.setImageResource(R.drawable.vec_favorite_fill)
//            } else {
//                binding.ivFav.setImageResource(R.drawable.vec_favorite_un_fill)
//            }
//            CoroutineScope(Dispatchers.IO).launch {
//                MemoriesBoxOperations.update(getApp(), memoryModel)
//                sendMemoryEvent(MEMORY_ITEM_UPDATE, memoryModel)
//            }
//        }
//
//
//
//        binding.ivPlayPause.setOnClickListener {
//            playerToggle()
//        }
//        binding.ivMute.tag = 1
//        binding.ivMute.setOnClickListener {
//            muteToggle()
//        }
//
//        binding.ivBack.setOnClickListener {
//            onBackPressedDispatcher.onBackPressed()
//        }
//        binding.ivUpdateMemory.setOnClickListener {
//            startActivity(Intent(this, MemoryImagesActivity::class.java))
//        }
//    }
//
//    private fun setupPager() {
//        binding.viewPager.offscreenPageLimit = 10
//        binding.viewPager.adapter = ImagePagerAdapter(0)
//        // Postpone transition until the view is fully ready
//        supportPostponeEnterTransition()
//        binding.viewPager.doOnPreDraw {
//            supportStartPostponedEnterTransition()
//            startPlay()
//            delayExecution(500) {
//                setBottomImageAdaptor()
//                autoScroll.start()
//            }
//        }
//        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
//            override fun onPageSelected(position: Int) {
//                super.onPageSelected(position)
//                (binding.rvBottomImages.layoutManager as? CustomCarouselLayoutManager)?.smoothScrollToPosition(binding.rvBottomImages, RecyclerView.State(), position)
//                val viewHolder = (binding.viewPager.adapter as? ImagePagerAdapter)?.getViewHolder(position)
//                viewHolder?.binding?.image?.startZoomInZoomOut()
//            }
//
//            override fun onPageScrollStateChanged(state: Int) {
//                when (state) {
//                    ViewPager2.SCROLL_STATE_DRAGGING -> {
//                        isUserScrolling = true // User starts interacting
//                        autoScroll.stop() // Pause auto-scroll immediately
//                    }
//
//                    ViewPager2.SCROLL_STATE_IDLE -> {
//                        if (isUserScrolling) {
//                            isUserScrolling = false // User interaction stopped
//                            // Wait for 1 second before resuming auto-scroll
//                            lifecycleScope.launch {
//                                delay(1000L) // 1-second delay
//                                autoScroll.start() // Resume auto-scroll
//                            }
//                        }
//                    }
//                }
//            }
//        })
//        binding.viewPager.setCurrentItem(0, false)
//        binding.viewPager.setPageTransformer(FadePageTransformer())
//    }
//
//    private fun isMediaPlaying() = mediaPlayer?.isPlaying ?: false
//    private fun playerToggle() {
//        if (isMediaPlaying()) {
//            pausePlayer()
//        } else {
//            startPlay()
//        }
//    }
//
//    private fun muteToggle() {
//        if (mediaPlayer != null) {
//            if (binding.ivMute.tag == 1) {
//                mediaPlayer?.setVolume(0f, 0f)
//                binding.ivMute.tag = 0
//            } else {
//                binding.ivMute.tag = 1
//                mediaPlayer?.setVolume(1f, 1f)
//            }
//            binding.ivMute.setImageResource(if (binding.ivMute.tag == 1) R.drawable.ic_music_on else R.drawable.ic_music_off)
//        }
//
//    }
//
//    private fun pausePlayer() {
//        mediaPlayer?.pause()
//        mediaPlayPauseListener.invoke()
//    }
//
//    private fun startPlay() {
//        if (mediaPlayer == null) {
//            mediaPlayer = MediaPlayer.create(this, R.raw.tone_2)
//            mediaPlayer!!.isLooping = true
//            mediaPlayer!!.setScreenOnWhilePlaying(true)
//        } else if (mediaPlayer?.isPlaying == false) {
//            mediaPlayer?.start()
//            mediaPlayPauseListener.invoke()
//        }
//    }
//
//
//    private fun optionToggle() {
//        if (isShowToolbar) {
//            hideToolbar()
//        } else {
//            showToolbar()
//        }
//    }
//
//    private fun hideToolbar() {
//        isShowToolbar = false
//        binding.clToolbar.animate()
//            .setDuration(300)
//            .setInterpolator(AccelerateDecelerateInterpolator())
//            .alpha(0f)
//        binding.topShadow.animate()
//            .setDuration(300)
//            .setInterpolator(AccelerateDecelerateInterpolator())
//            .alpha(0f)
//        binding.bottomBar.animate()
//            .setDuration(300)
//            .setInterpolator(AccelerateDecelerateInterpolator())
//            .alpha(0f)
//    }
//
//    private var hideHandleJob: Job? = null
//    private fun showToolbar() {
//        isShowToolbar = true
//        binding.clToolbar.animate()
//            .setDuration(300)
//            .setInterpolator(AccelerateDecelerateInterpolator())
//            .alpha(1f)
//
//        binding.topShadow.animate()
//            .setDuration(300)
//            .setInterpolator(AccelerateDecelerateInterpolator())
//            .alpha(1f)
//
//        binding.bottomBar.animate()
//            .setDuration(300)
//            .setInterpolator(AccelerateDecelerateInterpolator())
//            .alpha(1f)
//
//        showToolbarAfterTimer()
//    }
//
//    private fun showToolbarAfterTimer() {
//        /* hideHandleJob?.cancel()
//         hideHandleJob = CoroutineScope(Dispatchers.Main).launch {
//             delay(3000)
//             if (isUserScrolling) {
//                 showToolbarAfterTimer()
//             } else if (isShowToolbar) {
//                 hideToolbar()
//             }
//         }*/
//    }
//
//    @SuppressLint("ClickableViewAccessibility")
//    private fun setBottomImageAdaptor() {
//        val adaptor = BottomRecyclerViewAdaptor()
//        val startPadding = realScreenSize.x * 0.45
//        val mLinearLayoutManager = CustomCarouselLayoutManager(this@ImageViewerActivity2, LinearLayoutManager.HORIZONTAL, false)
//        binding.rvBottomImages.layoutManager = mLinearLayoutManager
//        binding.rvBottomImages.adapter = adaptor
//        binding.rvBottomImages.setPadding(startPadding.toInt(), binding.rvBottomImages.paddingTop, startPadding.toInt(), binding.rvBottomImages.paddingBottom)
//        binding.rvBottomImages.post {
//            binding.rvBottomImages.scheduleLayoutAnimation()
//        }
//        binding.rvBottomImages.addOnScrollListener(object : RecyclerView.OnScrollListener() {
//            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
//                super.onScrolled(recyclerView, dx, dy)
//                if (isUserScrolling) {
//                    Log.e("scrollHorizontallyBy", "SCROLL_STATE_DRAGGING: " + mLinearLayoutManager.getCenterItemPosition())
//                    val centerItem = mLinearLayoutManager.getCenterItemPosition()
//                    if (centerItem != binding.viewPager.currentItem) {
//                        binding.viewPager.setCurrentItem(centerItem, false)
//                    }
//                }
//            }
//
//            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
//                super.onScrollStateChanged(recyclerView, newState)
//
//                when (newState) {
//                    RecyclerView.SCROLL_STATE_DRAGGING -> {
//                        isUserScrolling = true // User starts interacting
//                        autoScroll.stop() // Pause auto-scroll immediately
//                    }
//
//                    RecyclerView.SCROLL_STATE_IDLE -> {
//                        if (isUserScrolling) {
//                            isUserScrolling = false // User interaction stopped
//                            // Wait for 1 second before resuming auto-scroll
//                            lifecycleScope.launch {
//                                delay(1000L) // 1-second delay
//                                autoScroll.start() // Resume auto-scroll
//                            }
//                        }
//                    }
//                }
//            }
//        })
//    }
//
//    @Subscribe(threadMode = ThreadMode.MAIN)
//    fun onMemoryEvent(event: MemoryEvent) {
//        when (event.type) {
//            MEMORY_ITEM_UPDATE -> {
//                releaseMediaPlayer()
//                recreate()
//            }
//        }
//    }
//
//    override fun onBackPressed() {
//        supportFinishAfterTransition()
//        super.onBackPressed()
//    }
//
//    inner class ImagePagerAdapter(val initialPosition: Int) : RecyclerView.Adapter<ImagePagerAdapter.ImageViewHolder>() {
//        inner class ImageViewHolder(val binding: ItemImageViewerBinding) : RecyclerView.ViewHolder(binding.root)
//
//        private val viewHolderMap = mutableMapOf<Int, ImageViewHolder>()
//        fun getViewHolder(position: Int) = viewHolderMap[position]
//        override fun onViewRecycled(holder: ImageViewHolder) {
//            super.onViewRecycled(holder)
//            Glide.with(holder.binding.image.context).clear(holder.binding.image)
//            Glide.with(holder.binding.imageViewBack.context).clear(holder.binding.imageViewBack)
//        }
//
//        private var loupeMap = hashMapOf<Int, CustomAnimatedImageViewMemory>()
//
//        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
//            val binding = ItemImageViewerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
//            return ImageViewHolder(binding)
//        }
//
//        override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
//            viewHolderMap[position] = holder
//            val model = memoryModel.medias[position]
//            val count = appPref.getGridCount()
//            holder.binding.image.tag = model
//            holder.binding.root.background = ColorDrawable(Color.BLACK)
//            loadImage(holder, model.filePath, holder.binding.root, position, model.filePath + model.dateModified + "full" + count)
//            holder.binding.image.setOnClickListener {
//                optionToggle()
//            }
//        }
//
//        override fun getItemCount() = memoryModel.medias.size
//        private fun loadImage(holder: ImageViewHolder, filePath: String, container: ViewGroup, position: Int, signature: String) {
//            Glide.with(holder.binding.image.context)
//                .asBitmap()
//                .load(filePath)
//                .centerCrop()
//                .signature(ObjectKey(signature))
//                .skipMemoryCache(false)
//                .diskCacheStrategy(DiskCacheStrategy.ALL)
//                .listener(object : RequestListener<Bitmap> {
//                    override fun onLoadFailed(
//                        e: GlideException?,
//                        model: Any?,
//                        target: Target<Bitmap>,
//                        isFirstResource: Boolean
//                    ): Boolean {
//
//                        return false
//                    }
//
//                    override fun onResourceReady(
//                        resource: Bitmap,
//                        model: Any,
//                        target: Target<Bitmap>,
//                        dataSource: DataSource,
//                        isFirstResource: Boolean
//                    ): Boolean {
//                        try {
//                            holder.binding.image.transitionName = filePath
//                            container.background = ColorDrawable(Color.BLACK)
//
//                            /* val animatedImageView = createAnimatedImageView(holder.binding.image, container) {
//                                 useFlingToDismissGesture = false
//                                 useDragToDismiss = false
//
//                                 setOnViewTranslateListener(
//                                     onClick = {
//
//                                     },
//                                     onStart = { },
//                                     onRestore = { },
//                                     onDismiss = { finishAfterTransition() }
//                                 )
//                             }*/
//
////                            loupeMap[position] = animatedImageView
//
//                            /*if (position == initialPosition) {
//                                setEnterSharedElementCallback(object : SharedElementCallback() {
//                                    override fun onMapSharedElements(
//                                        names: MutableList<String>?,
//                                        sharedElements: MutableMap<String, View>?
//                                    ) {
//                                        names ?: return
//                                        holder.binding.image.transitionName = filePath
//                                        sharedElements?.clear()
//                                        sharedElements?.put(holder.binding.image.transitionName, holder.binding.image)
//                                    }
//                                })
//                                startPostponedEnterTransition()
//                            }*/
//                        } catch (e: Exception) {
//                            e.printStackTrace()
//                        }
//                        return false
//                    }
//
//                })
//                .into(holder.binding.image)
//
//            val darknessValue = (0.5f.coerceIn(0f, 1f) * 255).toInt()
//
//            // MultiTransformation for blur + dark overlay
//            val multiTransformation = MultiTransformation(
//                BlurTransformation(25), // Apply blur
//                ColorFilterTransformation(Color.argb(darknessValue, 0, 0, 0)) // Apply dark overlay
//            )
//            Glide.with(this@ImageViewerActivity2)
//                .asBitmap()
//                .load(filePath)
//                .override(400)
//                .signature(ObjectKey(signature + "blur"))
//                .skipMemoryCache(false)
//                .centerCrop()// Replace with your image URL or Bitmap
//                .transform(multiTransformation)
//                .diskCacheStrategy(DiskCacheStrategy.ALL)
//                .listener(object : RequestListener<Bitmap> {
//                    override fun onLoadFailed(
//                        e: GlideException?,
//                        model: Any?,
//                        target: Target<Bitmap>,
//                        isFirstResource: Boolean
//                    ): Boolean {
//                        return false
//                    }
//
//                    override fun onResourceReady(
//                        resource: Bitmap,
//                        model: Any,
//                        target: Target<Bitmap>,
//                        dataSource: DataSource,
//                        isFirstResource: Boolean
//                    ): Boolean {
////                            container.background = resource.toDrawable(resources)
//                        holder.binding.imageViewBack.setImageBitmap(resource)
//                        return false
//                    }
//
//                })// Set blur radius (1 to 25)
//                .into(holder.binding.imageViewBack)
//        }
//
//        fun clear() {
//            loupeMap.forEach {
//                val animatedImageView = it.value
//                animatedImageView.cleanup()
//            }
//            loupeMap.clear()
//        }
//
//        fun createAnimatedImageView(
//            imageView: ImageView,
//            container: ViewGroup,
//            config: CustomAnimatedImageViewMemory.() -> Unit = { }
//        ): CustomAnimatedImageViewMemory {
//            return CustomAnimatedImageViewMemory.create(imageView, container, config)
//        }
//
//    }
//
//
//    override fun onPause() {
//        super.onPause()
//        if (isMediaPlaying()) {
//            pausePlayer()
//        }
//    }
//
//    override fun onDestroy() {
//        super.onDestroy()
//        releaseMediaPlayer()
//    }
//
//    private fun releaseMediaPlayer() {
//        pausePlayer()
//        mediaPlayer?.release()
//        mediaPlayer = null
//    }
//
//    inner class BottomRecyclerViewAdaptor : RecyclerView.Adapter<BottomRecyclerViewAdaptor.ViewHolder>() {
//        inner class ViewHolder(val binding: ImageViewBottomBinding) : RecyclerView.ViewHolder(binding.root)
//
//        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
//            return ViewHolder(ImageViewBottomBinding.inflate(LayoutInflater.from(parent.context), parent, false))
//        }
//
//        override fun getItemCount(): Int {
//            return memoryModel.medias.size
//        }
//
//        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//            Glide.with(holder.binding.image.context).load(memoryModel.medias[position].filePath).override(holder.binding.image.width, holder.binding.image.height).skipMemoryCache(false).centerCrop().into(holder.binding.image)
//        }
//    }
//
//    inner class AutoScrollCoroutine() {
//        private var autoScrollJob: Job? = null
//
//        // Starts the auto-scroll
//        fun start(interval: Long = 4500L) {
//            autoScrollJob?.cancel()
//            autoScrollJob = lifecycleScope.launch {
//                while (isActive) {
//                    delay(interval)
//                    if (!isUserScrolling) {
//                        val nextItem = (binding.viewPager.currentItem + 1) % binding.viewPager.adapter!!.itemCount
//                        binding.viewPager.setCurrentItem(nextItem, true)
//                    }
//
//                }
//            }
//        }
//
//        // Stops the auto-scroll
//        fun stop() {
//            autoScrollJob?.cancel()
//        }
//
//        // Directly sets the current item
//        fun setCurrentItem(item: Int, smoothScroll: Boolean = true) {
//            binding.viewPager.setCurrentItem(item, smoothScroll)
//        }
//    }
//
//}
//
