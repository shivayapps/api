package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation1

import android.view.View
import androidx.viewpager.widget.ViewPager


class CubeOut : ViewPager.PageTransformer {
    override fun transformPage(view: View, position: Float) {
        view.pivotX = if (position < 0f) view.width.toFloat() else 0f
        view.pivotY = view.height * 0.5f
        view.rotationY = 90f * position
    }
}