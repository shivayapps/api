package gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowInsetsController
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.biometric.auth.AuthPromptCallback
import androidx.biometric.auth.AuthPromptHost
import androidx.biometric.auth.Class2BiometricAuthPrompt
import androidx.fragment.app.FragmentActivity
import androidx.viewbinding.ViewBinding
import gallery.photogallery.photoeditor.galleryapp.R


inline fun <T : ViewBinding> Activity.viewBinding(crossinline bindingInflater: (LayoutInflater) -> T) =
    lazy(LazyThreadSafetyMode.NONE) {
        bindingInflater.invoke(layoutInflater)
    }

fun Activity.delayExecution(millis: Long, callback: () -> Unit) {
    Handler(Looper.myLooper()!!).postDelayed({
        callback()
    }, millis)
}

fun Context.isBiometricIdAvailable(): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        when (BiometricManager.from(this)
            .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)) {
            BiometricManager.BIOMETRIC_SUCCESS, BiometricManager.BIOMETRIC_STATUS_UNKNOWN, BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> true
            else -> false
        }
    } else false
}

fun Activity.isSupportWithErrorInfo(
    ctx: Context,
    type: Int,
): Pair<Boolean, String> {
    val biometricManager = BiometricManager.from(ctx)

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        val authStatusCode = biometricManager.canAuthenticate(type)
        Log.e(
            "BiometricManager",
            "isSupportWithErrorInfo\nauthStatusCode:$authStatusCode\n,type:$type"
        )

        if (authStatusCode == BiometricManager.BIOMETRIC_STATUS_UNKNOWN ||
            authStatusCode == BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED ||
            authStatusCode == BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE
        ) {
//            return Pair(false, "Device_unsupported")
            return Pair(false, getString(R.string.device_unsupported))
        } else if (authStatusCode == BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE) {
            return Pair(false, getString(R.string.setting_biometric_error_hardware_unavailable))
        } else if (authStatusCode == BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED) {
            return Pair(false, getString(R.string.setting_biometric_error_not_secure))
        } else if (authStatusCode == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED) {
            return Pair(false, getString(R.string.setting_biometric_error_none_enrolled))
        }


//        if (!isKeyguardSecure(ctx)) {
//            return Pair(false, ctx.getString(R.string.setting_biometric_error_pin_not_set))
//        }
//        if (!isSecureHardware()) {
//            return Pair(false, "isSecureHardware ${ctx.getString(R.string.setting_biometric_error_not_secure)}")
//        }
//        if (RootUtil.isDeviceRooted) {
//            return Pair(false, ctx.getString(R.string.setting_biometric_error_rooted))
//        }

        return Pair(true, "")
    } else {
        return Pair(false, getString(R.string.setting_biometric_error_hardware_unavailable))
    }
}

fun Activity.showBiometricPrompt(
    successCallback: (icSuccess: Boolean) -> Unit,
    failureCallback: (icFailed: Boolean, errorCode: Int, errString: CharSequence) -> Unit
) {
    val ctx = this
    Class2BiometricAuthPrompt.Builder(getText(R.string.authenticate), getText(R.string.cancel))
        .build()
        .startAuthentication(
            AuthPromptHost(this as FragmentActivity),
            object : AuthPromptCallback() {
                override fun onAuthenticationSucceeded(activity: FragmentActivity?, result: BiometricPrompt.AuthenticationResult) {
                    successCallback.invoke(true)
                }

                override fun onAuthenticationError(activity: FragmentActivity?, errorCode: Int, errString: CharSequence) {
                    val isCanceledByUser = errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON || errorCode == BiometricPrompt.ERROR_USER_CANCELED
                    if (!isCanceledByUser) {
                        Toast.makeText(ctx, errString.toString(), Toast.LENGTH_SHORT).show()
                    }
                    failureCallback.invoke(false, errorCode, errString)
                }

                override fun onAuthenticationFailed(activity: FragmentActivity?) {
                    successCallback.invoke(false)
                }
            }
        )
}


fun Activity.hideStatusBar(window: Window) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        window.insetsController?.hide(WindowInsetsController.BEHAVIOR_SHOW_BARS_BY_SWIPE)
    } else {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }
}


fun Activity.showStatusBar(window: Window) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        window.insetsController?.show(WindowInsetsController.BEHAVIOR_SHOW_BARS_BY_SWIPE)
    } else {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }
}

fun String.isDocumentContains() = contains("document", ignoreCase = true)
        || contains("paper", ignoreCase = true)
        || contains("bill", ignoreCase = true)
        || contains("passbook", ignoreCase = true)
        || contains("invoice", ignoreCase = true)
        || contains("notebook", ignoreCase = true)
        || contains("tickets", ignoreCase = true)
        || contains("passport", ignoreCase = true)
        || contains("Aadhaar", ignoreCase = true)
        || contains("PAN", ignoreCase = true)
        || contains("Licence", ignoreCase = true)
        || contains("cheques", ignoreCase = true)
        || contains("certificate", ignoreCase = true)
        || contains("handwritten note", ignoreCase = true)