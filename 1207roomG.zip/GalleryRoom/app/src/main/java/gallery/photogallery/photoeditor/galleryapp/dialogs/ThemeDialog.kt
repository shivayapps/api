package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogThemeBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Constant

class ThemeDialog : DialogFragment() {

    private var _binding: DialogThemeBinding? = null
    private val binding get() = _binding!!
    var themeListener: ((selected: Int) -> Unit)? = null
    private lateinit var safeContext: Context
    private val selected: Int by lazy {
        arguments?.getInt("selected", Constant.THEME_SYSTEM)
            ?: Constant.THEME_SYSTEM
    }
    private var currentSelected: Int = Constant.THEME_SYSTEM

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    companion object {
        fun show(
            fragmentManager: FragmentManager,
            selected: Int = Constant.THEME_SYSTEM,
            themeListener: (selected: Int) -> Unit,
        ) {
            val themeDialog = ThemeDialog()
            themeDialog.themeListener = themeListener
            themeDialog.arguments = Bundle().apply {
                putInt("selected", selected)
            }
            themeDialog.show(fragmentManager, "themeModeDialog")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogThemeBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        intView(selected)

        clickListener()
        return dialog
    }


    private fun intView(selected: Int) {
        currentSelected = selected

        when (selected) {
            Constant.THEME_SYSTEM -> binding.rbSystem.isChecked = true
            Constant.THEME_LIGHT -> binding.rbLight.isChecked = true
            Constant.THEME_DARK -> binding.rbDark.isChecked = true
        }
    }

    private fun clickListener() {
        binding.rgTheme.setOnCheckedChangeListener { _, checkedId ->
            currentSelected = when (checkedId) {
                binding.rbSystem.id -> {
                    Constant.THEME_SYSTEM
                }
                binding.rbLight.id -> Constant.THEME_LIGHT
                binding.rbDark.id -> Constant.THEME_DARK

                else -> return@setOnCheckedChangeListener
            }

            themeListener?.invoke(currentSelected)
            dismiss()
        }
    }
}