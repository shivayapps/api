package gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities

import android.annotation.SuppressLint
import android.content.res.Configuration
import android.os.Bundle
import android.util.Log
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.appblish.medialoader.AppblishImageLoader.loadFullImage
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityWhatsAppImageViewerBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.PhotosDetailsDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.editPhoto
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.getNameWithoutExtension
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isImageFast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isVideoFast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.shareFilesList
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import java.io.File

class WhatsAppImageViewerActivity : BaseActivity() {
    private val binding by viewBinding(ActivityWhatsAppImageViewerBinding::inflate)
    private val currentPath by lazy { intent.getStringExtra("filePath") ?: "" }
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updatePaddingBasedOnOrientation()
    }


    private var isShowToolbar = true

    override fun onCreate(savedInstanceState: Bundle?) {
        isPortrait = false
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        updatePaddingBasedOnOrientation()
        window.statusBarColor = ContextCompat.getColor(this, android.R.color.transparent)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = false
        initView()
    }

    private fun updatePaddingBasedOnOrientation() {
        val orientation = resources.configuration.orientation
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Log.d("Orientation", "Landscape")
            binding.root.setPadding(0, 0, navigationBarHeight, 0)
            binding.clToolbar.setPadding(0, statusBarHeight, 0, 0)

        } else if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            Log.d("Orientation", "Portrait")
            binding.root.setPadding(0, 0, 0, navigationBarHeight)
            binding.clToolbar.setPadding(0, statusBarHeight, 0, 0)

        }
    }

    @SuppressLint("SetTextI18n")
    private fun initView() {
        val file = File(currentPath)
        binding.photoView.loadFullImage(currentPath, file.lastModified())
        binding.icVideo.beVisibleIf(currentPath.isVideoFast())
        binding.photoView.isZoomable = currentPath.isImageFast()
        binding.photoView.setOnViewTapListener { _, _, _ ->
            toggleFullScreen()
        }

        binding.tvImageName.text = file.getNameWithoutExtension()

        if (currentPath.isImageFast()) {
            enableEdit(true)
        } else {
            enableEdit(false)
        }

        binding.ivInfo.setOnClickListener {
            PhotosDetailsDialog(listOf(currentPath)).show(supportFragmentManager, "PhotosDetailsDialog")

        }

        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

        binding.clShareOpenWidth.setOnClickListener {
            shareFilesList(currentPath)
        }

        binding.clShareOpenWidth.setOnClickListener {
            shareFilesList(currentPath)
        }
        binding.clEditOpenWidth.setOnClickListener {
            editPhoto(currentPath)
            finish()
        }
        if (intent.hasExtra("editPhoto")) {
            binding.clEditOpenWidth.performClick()
        }
    }

    fun enableEdit(enableEdit: Boolean) {
        if (enableEdit) {
            binding.clEditOpenWidth.alpha = 1.0f
            binding.clEditOpenWidth.isClickable = true
        } else {
            binding.clEditOpenWidth.alpha = 0.5f
            binding.clEditOpenWidth.isClickable = false
        }
    }


    private fun toggleFullScreen() {
        if (isShowToolbar) {
            hideToolbar()
        } else {
            showToolbar()
        }
    }


    private fun hideToolbar() {
        isShowToolbar = false
        binding.clToolbar.animate().setDuration(100).setInterpolator(AccelerateDecelerateInterpolator()).translationY(-binding.clToolbar.height.toFloat())
        binding.llBottom.animate().setDuration(100).setInterpolator(AccelerateDecelerateInterpolator()).translationY(binding.llBottom.height.toFloat())
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_DEFAULT
        }
    }


    private fun showToolbar() {
        isShowToolbar = true
        binding.clToolbar.beVisible()
        binding.clToolbar.animate().setInterpolator(AccelerateDecelerateInterpolator()).translationY(0f)

        binding.llBottom.beVisible()
        binding.llBottom.animate().setInterpolator(AccelerateDecelerateInterpolator()).translationY(0f)


        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.statusBars())
    }


    override fun onDestroy() {
        super.onDestroy()
    }

    @SuppressLint("GestureBackNavigation")
    override fun onBackPressed() {
        if (isTaskRoot) {
            moveToHome()
        } else {
            super.onBackPressed()
        }
    }
}