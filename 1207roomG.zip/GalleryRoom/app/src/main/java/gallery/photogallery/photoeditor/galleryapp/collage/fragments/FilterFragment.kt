package gallery.photogallery.photoeditor.galleryapp.collage.fragments

import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.appblish.collagemaker.photofilters.AppblishCollageFilterItem
import gallery.photogallery.photoeditor.galleryapp.collage.adapters.CollageFilterAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.FragmentFilterBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.dialog.LoadingDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class FilterFragment : DialogFragment() {

    private var loadingDialog: LoadingDialog? = null

    private var _binding: FragmentFilterBinding? = null
    private val binding get() = _binding!!

    private var bitmap: Bitmap? = null
    private var lstFilterBitmap: MutableList<AppblishCollageFilterItem> = mutableListOf()
    private var onFilterSavePhoto: ((Bitmap) -> Unit)? = null


    companion object {
        private const val TAG = "FilterFragment"

        fun show(
            activity: AppCompatActivity,
            bitmap: Bitmap,
            list: List<AppblishCollageFilterItem>,
            onFilterSavePhoto: (Bitmap) -> Unit
        ): FilterFragment {
            return FilterFragment().apply {
                this.bitmap = bitmap
                this.lstFilterBitmap = list.toMutableList()
                this.onFilterSavePhoto = onFilterSavePhoto
                show(activity.supportFragmentManager, TAG)
            }
        }
    }

    /* ---------- LIFECYCLE ---------- */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        dialog?.window?.requestFeature(1)
        dialog?.window?.setFlags(1024, 1024)

        _binding = FragmentFilterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupUI()
        setupRecycler()
        setupClicks()
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundDrawable(ColorDrawable(0xFF000000.toInt()))
         }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        lstFilterBitmap.clear()
        _binding = null
    }

    /* ---------- SETUP ---------- */

    private fun setupUI() {
        binding.textViewTitle.text = "FILTER"
        binding.imageViewPreview.setImageBitmap(bitmap)
    }

    private fun setupRecycler() {

        val adapter = CollageFilterAdapter(
            requireContext(),
            lstFilterBitmap
        ) { _, filterItem ->
            setLoading(true)

            loadBitmapWithFilter(filterItem)
        }

        binding.recyclerViewFilterAll.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            this.adapter = adapter
        }
    }

    private fun setupClicks() {
        binding.imageViewSaveFilter.setOnClickListener {
            val resultBitmap =
                (binding.imageViewPreview.drawable as BitmapDrawable).bitmap
            onFilterSavePhoto?.invoke(resultBitmap)
            dismiss()
        }

        binding.imageViewCloseFilter.setOnClickListener {
            dismiss()
        }
    }

    /* ---------- FILTER APPLY ---------- */

    private fun loadBitmapWithFilter(filterItem: AppblishCollageFilterItem) {
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {

            filterItem.filter.applyFilter(
                inputBitmap = bitmap!!,
                filter = filterItem.filter,
                onDone = { resultBitmap ->
                    launch(Dispatchers.Main) {
                        setLoading(false)

                        binding.imageViewPreview.setImageBitmap(resultBitmap)
                    }
                },
                onError = {
                    it.printStackTrace()
                }
            )
        }
    }



    fun setLoading(loaderLayout: Boolean) {
        if (loaderLayout){
            showLoading()
        }else{
            hideLoading()
        }
    }



    private fun showLoading(message: String = "Please wait...") {

        if (loadingDialog == null) {
            loadingDialog = LoadingDialog(requireActivity())
        }

        loadingDialog?.setMessage(message)

        if (loadingDialog?.isShowing == false) {
            loadingDialog?.show()
        }
    }


    private fun hideLoading() {
        loadingDialog?.let {
            if (it.isShowing) {
                it.dismiss()
            }
        }
    }

}
