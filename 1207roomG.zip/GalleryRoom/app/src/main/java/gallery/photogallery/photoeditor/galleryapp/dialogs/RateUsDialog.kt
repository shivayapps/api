package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.core.net.toUri
import androidx.fragment.app.DialogFragment
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogRateUsBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.clientConfigPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import java.io.File
import java.lang.ref.WeakReference

class RateUsDialog(private val activity: Activity) : DialogFragment() {
    private var _binding: DialogRateUsBinding? = null
    private val binding get() = _binding!!

    var positiveBtnClickListener: ((renameFile: File, oldFile: File) -> Unit)? = null

    private lateinit var safeContext: Context

    override fun onAttach(context: Context) {
        super.onAttach(context)
        safeContext = context
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogRateUsBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(safeContext.getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        clickListener()
        return dialog
    }

    private fun clickListener() {

        binding.llGood.setOnClickListener {
            showInAppRateDialog()
        }

        binding.llNotReally.setOnClickListener {
            launchEmail()
        }
    }

    private fun launchEmail() {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "message/rfc822"
        i.putExtra(Intent.EXTRA_EMAIL, arrayOf(activity.clientConfigPref.reviewEmail))
        i.putExtra(
            Intent.EXTRA_SUBJECT,
            "${activity.getString(R.string.app_name)} Feedback"
        )
        i.putExtra(Intent.EXTRA_TEXT, "")
        i.setPackage("com.google.android.gm")
        try {
            activity.startActivity(Intent.createChooser(i, "Send mail"))
        } catch (_: ActivityNotFoundException) {
            //activity.toast(getString(R.string.not_installed))
        }
    }

    private fun showInAppRateDialog() {
        val reviewManager = ReviewManagerFactory.create(activity)
        val activityRef = WeakReference(activity)
        val requestReview = reviewManager.requestReviewFlow()
        requestReview.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    showInAppRateDialogInternal(
                        reviewManager,
                        activity,
                        task.result
                    )
                }
            } else {
//                log.error(task.exception)
            }
        }
    }

    private fun showInAppRateDialogInternal(
        reviewManager: ReviewManager,
        activity: Activity,
        reviewInfo: ReviewInfo,
    ) {
        val reviewFlow = reviewManager.launchReviewFlow(activity, reviewInfo)
        val activityRef = WeakReference(activity)
        reviewFlow.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                activity.preferences.rateAppDone = true
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    launchAppStore(activity)
                }
            } else {
//                log.error(task.exception)
            }
        }
    }

    private fun launchAppStore(activity: Activity) {
        activity.startActivity(
            Intent(
                Intent.ACTION_VIEW,
                "http://play.google.com/store/apps/details?id=${activity.packageName}".toUri()
            )
        )
    }
}