package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogMemoryItemMenuBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.Preferences
class MemoriesMenuDialog : DialogFragment() {
    companion object {
        fun newInstance(clickListener: ((type: Int) -> Unit)?): MemoriesMenuDialog {
            val dialog = MemoriesMenuDialog()
            dialog.clickListener = clickListener
            return dialog
        }
    }
    private var _binding: DialogMemoryItemMenuBinding? = null
    private val binding get() = _binding!!

    var clickListener: ((type: Int) -> Unit)? = null

    val preferences: Preferences by lazy { Preferences(requireContext()) }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val dialog = Dialog(requireContext())
        _binding = DialogMemoryItemMenuBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(requireContext().getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        initView()
        return dialog
    }

    private fun initView() {
        initListener()
    }

    private fun initListener() {

        binding.btnEditTitle.setOnClickListener {
            dismiss()
            clickListener?.invoke(1)
        }

        binding.btnChangeCover.setOnClickListener {
            dismiss()
            clickListener?.invoke(2)
        }

        binding.btnDeleteMemory.setOnClickListener {
            dismiss()
            clickListener?.invoke(3)
        }
    }
}
