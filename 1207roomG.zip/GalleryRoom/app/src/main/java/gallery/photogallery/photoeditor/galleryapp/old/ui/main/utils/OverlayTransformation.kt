package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils//package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils
//
//import android.graphics.Bitmap
//import android.graphics.Canvas
//import android.graphics.drawable.Drawable
//import com.bumptech.glide.load.engine.bitmap_recycle.BitmapPool
//import com.bumptech.glide.load.resource.bitmap.BitmapTransformation
//import java.security.MessageDigest
//
//class OverlayTransformation(private val overlayBitmap: Drawable?, val size: Int) : BitmapTransformation() {
//    override fun updateDiskCacheKey(messageDigest: MessageDigest) {
//        messageDigest.update("drawable_overlay_transformation".toByteArray(Charsets.UTF_8))
//    }
//
//    override fun transform(pool: BitmapPool, toTransform: Bitmap, outWidth: Int, outHeight: Int): Bitmap {
//        val result = Bitmap.createBitmap(toTransform.width, toTransform.height, toTransform.config!!)
//        val canvas = Canvas(result)
//        canvas.drawBitmap(toTransform, 0f, 0f, null)
//        overlayBitmap?.let {
//            val bitmap = drawableToBitmap(overlayBitmap, size)
//            val left = (toTransform.width - bitmap.width) / 2
//            val top = (toTransform.height - bitmap.height) / 2
//            canvas.drawBitmap(bitmap, left.toFloat(), top.toFloat(), null)
//        }
//        return result
//    }
//
//    private fun drawableToBitmap(drawable: Drawable, size: Int): Bitmap {
//        val bitmap = Bitmap.createBitmap(
//            size,
//            size,
//            Bitmap.Config.ARGB_8888
//        )
//        val canvas = Canvas(bitmap)
//        drawable.setBounds(0, 0, canvas.width, canvas.height)
//        drawable.draw(canvas)
//        return bitmap
//    }
//}