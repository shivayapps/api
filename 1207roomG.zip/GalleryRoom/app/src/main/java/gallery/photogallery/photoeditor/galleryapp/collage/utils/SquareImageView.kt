package gallery.photogallery.photoeditor.galleryapp.collage.utils

import android.content.Context
import android.graphics.Outline
import android.util.AttributeSet
import android.view.View
import android.view.ViewOutlineProvider
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.withStyledAttributes
import gallery.photogallery.photoeditor.galleryapp.R
import kotlin.let


class SquareImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : AppCompatImageView(context, attrs, defStyleAttr) {

    var hwRatio: Float = 1f
        private set

    private var cornerRadius: Float = 0f

    init {
        attrs?.let {
            context.withStyledAttributes(
                it,
                R.styleable.SquareImageView
            ) {

                hwRatio = getFloat(
                    R.styleable.SquareImageView_hwRatio,
                    1f
                )

                cornerRadius = getDimension(
                    R.styleable.SquareImageView_cornerRadius,
                    0f
                )

            }
        }

        scaleType = ScaleType.CENTER_CROP
        clipToOutline = cornerRadius > 0f

        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                if (cornerRadius > 0f) {
                    outline.setRoundRect(
                        0,
                        0,
                        view.width,
                        view.height,
                        cornerRadius
                    )
                } else {
                    outline.setRect(0, 0, view.width, view.height)
                }
            }
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val height = (width * hwRatio).toInt()
        setMeasuredDimension(width, height)
    }

    /** 🔹 Update ratio dynamically */
    fun setXyRatio(ratio: Float) {
        if (hwRatio != ratio) {
            hwRatio = ratio
            requestLayout()
        }
    }

    /** 🔹 Update corner radius dynamically */
    fun setCornerRadius(radius: Float) {
        if (cornerRadius != radius) {
            cornerRadius = radius
            clipToOutline = cornerRadius > 0f
            invalidateOutline()
        }
    }
}

