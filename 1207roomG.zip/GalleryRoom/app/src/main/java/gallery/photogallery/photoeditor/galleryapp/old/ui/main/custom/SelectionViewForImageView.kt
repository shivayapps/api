package gallery.photogallery.photoeditor.galleryapp.old.ui.main.custom

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AppCompatActivity.LAYOUT_INFLATER_SERVICE
import androidx.constraintlayout.widget.ConstraintLayout
import gallery.photogallery.photoeditor.galleryapp.activities.TrashActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.LayoutSelectionImageViewBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.PopBottomMenuBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGoneIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.PopupWindowHelper
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.WhatsAppImageViewerActivity

enum class ActionImageView {
    SHARE,
    DELETE,
    DELETE_RECYCLER,
    DELETE_HIDDEN,
    HIDE,
    EDIT,
    MORE,
    RESTORE_RECYCLER,
    RESTORE_HIDDEN,

}

class SelectionViewForImageView : ConstraintLayout, View.OnClickListener {

    var callBack: ((ActionImageView) -> Unit)? = null

    var binding: LayoutSelectionImageViewBinding = LayoutSelectionImageViewBinding.inflate(LayoutInflater.from(context), this, true)

    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)

    override fun onFinishInflate() {
        super.onFinishInflate()

        when (context) {


            is TrashActivity -> {
                binding.llSelectionRecycler.beVisible()
                binding.llSelection.beGone()
            }


            is WhatsAppImageViewerActivity -> {
                binding.llSelectionHidden.beGone()
                binding.llSelection.beGone()
                binding.llOpenWidth.beVisible()

            }

            else -> {
                binding.llSelection.beVisible()
                binding.llSelectionRecycler.beGone()
            }
        }

        initListeners()

    }

    fun enableEdit(enableEdit: Boolean) {
        if (enableEdit) {
            binding.clEdit.alpha = 1.0f
            binding.clEditOpenWidth.alpha = 1.0f
            binding.clEdit.isClickable = true
            binding.clEditOpenWidth.isClickable = true
        } else {
            binding.clEdit.alpha = 0.5f
            binding.clEditOpenWidth.alpha = 0.5f
            binding.clEdit.isClickable = false
            binding.clEditOpenWidth.isClickable = false
        }
    }

    fun hideShowMore(isHide: Boolean) {
        binding.clEditOpenWidth.beGoneIf(isHide)
    }

    private fun initListeners() {
        binding.clShare.setOnClickListener(this)
        binding.clDelete.setOnClickListener(this)
        binding.clHide.setOnClickListener(this)
        binding.clEdit.setOnClickListener(this)
        binding.clMore.setOnClickListener(this)
        binding.clRestore.setOnClickListener(this)
        binding.clDeleteRecycler.setOnClickListener(this)
        binding.clUnHide.setOnClickListener(this)
        binding.clDeleteHidden.setOnClickListener(this)
        binding.clShareOpenWidth.setOnClickListener(this)
        binding.clEditOpenWidth.setOnClickListener(this)
    }

    override fun onClick(view: View?) {
        when (view) {
            binding.clShare, binding.clShareOpenWidth -> {
                callBack?.invoke(ActionImageView.SHARE)
            }

            binding.clDelete -> {
                callBack?.invoke(ActionImageView.DELETE)
            }

            binding.clDeleteRecycler -> {
                callBack?.invoke(ActionImageView.DELETE_RECYCLER)
            }

            binding.clHide -> {
                callBack?.invoke(ActionImageView.HIDE)
            }

            binding.clEdit, binding.clEditOpenWidth -> {
                callBack?.invoke(ActionImageView.EDIT)
            }

            binding.clMore -> {
                callBack?.invoke(ActionImageView.MORE)
            }

            binding.clRestore -> {
                callBack?.invoke(ActionImageView.RESTORE_RECYCLER)
            }

            binding.clUnHide -> {
                callBack?.invoke(ActionImageView.RESTORE_HIDDEN)
            }

            binding.clDeleteHidden -> {
                callBack?.invoke(ActionImageView.DELETE_HIDDEN)
            }
        }
    }

    fun showDropDown() {
        val layoutInflater = context.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)

        val popupWindow = PopupWindowHelper(popUpBinding.root)

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
            Log.e("btmSelectionView", "loutMain: ")
        }

//        popUpBinding.menuRename.setOnClickListener {
//            popupWindow.dismiss()
//            Log.e("btmSelectionView", "menuRename: ")
//        }

//        popUpBinding.menuCover.setOnClickListener {
        Log.e("btmSelectionView", "menuCover: ")
//            popUpBinding.llMain.beGone()
//            popUpBinding.llCover.beVisible()
//            popupWindow.dismiss()
//            popupWindow.showAsPopUp(view, mGravity = Gravity.END or Gravity.TOP)
//            popupWindow.showAsPopUp(binding.root, mGravity = Gravity.END or Gravity.TOP)
//        }

//        popUpBinding.selectPhoto.setOnClickListener {
//            popupWindow.dismiss()
//            Log.e("btmSelectionView", "selectPhoto: ")
//        }
//        popUpBinding.useDefault.setOnClickListener {
//            popupWindow.dismiss()
//            Log.e("btmSelectionView", "useDefault: ")
//        }

        popUpBinding.menuEdit.setOnClickListener {
            popupWindow.dismiss()
            Log.e("btmSelectionView", "menuEdit: ")
        }

        popUpBinding.menuSetAs.setOnClickListener {
            popupWindow.dismiss()
            Log.e("btmSelectionView", "menuSetAs: ")
        }

        popUpBinding.menuResize.setOnClickListener {
            popupWindow.dismiss()
        }

        popUpBinding.menuAddFavourite.setOnClickListener {
            popupWindow.dismiss()
            Log.e("btmSelectionView", "menuAddFavourite: ")
        }

//        popUpBinding.menuRemoveFavourite.setOnClickListener {
//            popupWindow.dismiss()
//            Log.e("btmSelectionView", "menuRemoveFavourite: ")
//        }

        popUpBinding.menuInfo.setOnClickListener {
            popupWindow.dismiss()
            Log.e("btmSelectionView", "menuInfo: ")
        }

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
            Log.e("btmSelectionView", "menuCopy: ")
        }

        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
            Log.e("btmSelectionView", "menuMove: ")
        }

//        popupWindow.showAsPopUp(view, mGravity = Gravity.END or Gravity.TOP)
//        popupWindow.showAsPopUp(binding.root, mGravity = Gravity.END or Gravity.TOP)

        val selectedLanguage = context.preferences.getSelectedLang(context)
        if (selectedLanguage == "ar" || selectedLanguage == "ur" || selectedLanguage == "fa") {
            popupWindow.showAsPopUp(binding.root, mGravity = Gravity.START or Gravity.TOP)
        } else {
            popupWindow.showAsPopUp(binding.root, mGravity = Gravity.END or Gravity.TOP)
        }

    }
}