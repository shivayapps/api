package gallery.photogallery.photoeditor.galleryapp.collage.fragments

data class AlbumItem(
    val albumId: String,
    val albumName: String
)


