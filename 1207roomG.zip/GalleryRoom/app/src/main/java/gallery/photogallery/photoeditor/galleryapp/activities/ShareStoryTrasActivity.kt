package gallery.photogallery.photoeditor.galleryapp.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.addCallback
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.appblish.medialoader.AppblishImageLoader.loadGridImage
import com.appblish.story.memories.api.core.MemorySDK
import com.appblish.story.memories.api.model.StoryBox
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityShareStoryTransBinding
import gallery.photogallery.photoeditor.galleryapp.old.storyview.screen.ShareStoryActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding

import gallery.photogallery.photoeditor.galleryapp.utils.SHARE_STORY_DONE
import gallery.photogallery.photoeditor.galleryapp.utils.sendIntentEvent
import kotlinx.coroutines.launch

class ShareStoryTrasActivity : BaseActivity() {
    private val storyId by lazy { intent.getLongExtra("storyId", 0) }
    private val isTaskRootCheck by lazy { intent.getBooleanExtra("isTaskRootCheck", false) }
    private val binding by viewBinding(ActivityShareStoryTransBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = false
        lifecycleScope.launch {
            MemorySDK.get().getStoryBox(storyId) {
                loadMedia(it)
            }
            onBackPressedDispatcher.addCallback {
                if (isTaskRoot) {
                    moveToHome()
                } else {
                    sendIntentEvent(Intent().putExtra(SHARE_STORY_DONE, storyId))
                    finish()
                }
            }
        }
    }

    private fun loadMedia(storyBox: StoryBox) {
        val mediaBox = storyBox.mediaList.first()
        binding.image.loadGridImage(mediaBox.mediaPath, mediaBox.mediaDate)
        binding.tvStoryTitle.text = storyBox.title
        binding.tvShare.setOnClickListener {
            val storiesPath: ArrayList<String> = ArrayList()
            storyBox.mediaList.forEach {
                storiesPath.add(it.mediaPath)
            }
            val intent = Intent(this, ShareStoryActivity::class.java)
            intent.putExtra("story_pos", 0)
            intent.putStringArrayListExtra("story_array", storiesPath)
            intent.putExtra("selectAll", true)
            startActivity(intent)
        }
        binding.tvSkip.setOnClickListener {
            if (isTaskRootCheck) {
                moveToHome()
            } else {
                setResult(RESULT_OK)
                finish()
            }
        }
    }
}