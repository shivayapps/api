package gallery.photogallery.photoeditor.galleryapp.collage.adapters

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup

import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.appblish.collagemaker.appblish.AppblishCollageSquareView
import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ItemCollageBinding
import java.util.ArrayList

class GridAdapter : RecyclerView.Adapter<GridAdapter.GridViewHolder>() {

    var onLayoutSelected: ((AppblishCollageLayout, Int) -> Unit)? = null

    private var selectedIndex = 0
    private var bitmapData: List<Bitmap> = ArrayList()
    private var layoutData: List<AppblishCollageLayout> = ArrayList()

    /* ---------- ADAPTER ---------- */

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GridViewHolder {
        val binding = ItemCollageBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return GridViewHolder(binding)
    }

    override fun onBindViewHolder(
        holder: GridViewHolder,
        @SuppressLint("RecyclerView") position: Int
    ) {
        holder.bind(layoutData[position], position)
    }

    override fun getItemCount(): Int = layoutData.size

    /* ---------- DATA ---------- */

    fun refreshData(layouts: List<AppblishCollageLayout>, bitmaps: List<Bitmap>) {
        layoutData = layouts
        bitmapData = bitmaps
        notifyDataSetChanged()
    }

    fun setSelectedIndex(index: Int) {
        selectedIndex = index
        notifyDataSetChanged()
    }

    /* ---------- VIEW HOLDER ---------- */

    inner class GridViewHolder(
        private val binding: ItemCollageBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        val squareCollageView: AppblishCollageSquareView = binding.squareCollageView

        fun bind(collageLayout: AppblishCollageLayout, position: Int) {

            squareCollageView.apply {
                setNeedDrawLine(true)
                setNeedDrawOuterLine(true)
                setTouchEnable(false)
                setLineSize(6)
                setAppblishLayout(collageLayout)
                setLineColor(ContextCompat.getColor(context, R.color.color_text))

                // Selection background
                setBackgroundColor(
                    if (selectedIndex == position)
                        Color.parseColor("#196AED")
                    else
                        0
                )
            }

            binding.root.setOnClickListener {
                onLayoutSelected?.invoke(collageLayout, position)

                val oldPos = selectedIndex
                selectedIndex = position
                notifyItemChanged(oldPos)
                notifyItemChanged(selectedIndex)
            }

            // Add bitmap previews
//            if (bitmapData.isNotEmpty()) {
//                val size = bitmapData.size
//                if (collageLayout.areaCount > size) {
//                    for (i in 0 until collageLayout.areaCount) {
//                        squareCollageView.addAppblishCollage(bitmapData[i % size])
//                    }
//                } else {
//                    squareCollageView.addPieces(bitmapData)
//                }
//            }
        }
    }
}
