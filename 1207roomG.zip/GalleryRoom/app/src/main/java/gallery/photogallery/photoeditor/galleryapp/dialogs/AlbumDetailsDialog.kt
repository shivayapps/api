package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.os.Bundle
import android.text.format.Formatter
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogAlbumDeatilsBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.getFilenameFromPath
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AlbumDetailsDialog : DialogFragment() {
    private var _binding: DialogAlbumDeatilsBinding? = null
    private val binding get() = _binding!!

    var positiveBtnClickListener: ((renameFile: File, oldFile: File) -> Unit)? = null

    private var albumPathList: List<String> = emptyList()
    private var mediaCount: Int = 0
    private var mediaTotalSize: Long = 0

    companion object {
        private const val ARG_FOLDER_LIST = "arg_folder_list"
        private const val ARG_MEDIA_COUNT = "ARG_MEDIA_COUNT"
        private const val ARG_TOTAL_SIZE = "ARG_TOTAL_SIZE"

        fun newInstance(bucketPath: List<String>, mediaCount: Int, mediaTotalSize: Long): AlbumDetailsDialog {
            return AlbumDetailsDialog().apply {
                arguments = Bundle().apply {
                    putStringArrayList(ARG_FOLDER_LIST, ArrayList(bucketPath))
                    putInt(ARG_MEDIA_COUNT, mediaCount)
                    putLong(ARG_TOTAL_SIZE, mediaTotalSize)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        albumPathList = arguments?.getStringArrayList(ARG_FOLDER_LIST) ?: arrayListOf()
        mediaCount = arguments?.getInt(ARG_MEDIA_COUNT, 0) ?: 0
        mediaTotalSize = arguments?.getLong(ARG_TOTAL_SIZE, 0) ?: 0L
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogAlbumDeatilsBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(requireContext().getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }

        intView()
        clickListener()
        return dialog
    }

    private fun intView() {
        if (albumPathList.isEmpty()) {
            dismiss()
            return
        }
        if (albumPathList.size == 1) {
            val file = File(albumPathList.first())
            binding.txtName.text = file.name
            binding.txtPath.text = file.parent
            binding.txtTime.text = SimpleDateFormat("dd/MM/yyyy, hh:mm aa", Locale.ENGLISH).format(Date(file.lastModified()))
            binding.llResolution.beGone()
            binding.txtFileCount.text = mediaCount.toString()
            binding.txtSize.text = Formatter.formatShortFileSize(
                requireContext(),
                mediaTotalSize
            )
        } else {
            binding.txtName.text = albumPathList.map { it.getFilenameFromPath() }.joinToString(", ")
            binding.llPath.beGone()
            binding.llResolution.beGone()
            binding.llFileTime.beGone()
            binding.txtSize.text = Formatter.formatShortFileSize(
                requireContext(),
                mediaTotalSize
            )
            binding.txtFileCount.text = mediaCount.toString()
        }

    }


    private fun clickListener() {
        binding.btnOK.setOnClickListener {
            dismiss()
        }
    }

}