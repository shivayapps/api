package gallery.photogallery.photoeditor.galleryapp.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import androidx.activity.addCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.appblish.box.api.model.ScrollGate
import com.appblish.box.api.util.AppblishEvent
import com.appblish.box.api.util.MediaDataState
import com.appblish.gallery.core.v2.api.core.GallerySdkV2
import com.appblish.gallery.core.v2.api.model.AlbumListItem
import com.appblish.gallery.core.v2.api.model.AlbumModel
import com.appblish.medialoader.AppblishImageLoader.setupGlidePreLoader
import com.appblish.medialoader.PreloadItem
import com.appblish.recyclerview.dragselection.SelectionUpdateCallback
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.adaptor.AlbumListAdapter
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivityAllVideosBinding
import gallery.photogallery.photoeditor.galleryapp.databinding.PopAlbumMenuBinding
import gallery.photogallery.photoeditor.galleryapp.dialogs.AlbumDetailsDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.ConfirmationDialog
import gallery.photogallery.photoeditor.galleryapp.dialogs.RenameAlbumDialog
import gallery.photogallery.photoeditor.galleryapp.extentions.restart
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisible
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.preferences
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.PopupWindowHelper
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities.SetLockActivity
import gallery.photogallery.photoeditor.galleryapp.utils.registerEventBus
import gallery.photogallery.photoeditor.galleryapp.utils.spancounthelper.ScaleHintListener
import gallery.photogallery.photoeditor.galleryapp.utils.unregisterEventBus
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class AllVideosActivity : BaseActivity() {
    private val binding by viewBinding(ActivityAllVideosBinding::inflate)
    private var getBucketPath: String? = ""
    private var getBucketSize = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.main.setPadding(0, statusBarHeight, 0, navigationBarHeight)
        registerEventBus(this)
        initView()
        setListeners()
    }


    @SuppressLint("MissingSuperCall", "GestureBackNavigation")
    override fun onBackPressed() {
        onBack()
    }

    fun onBack() {
        finish()
    }


    private fun initView() {
        lifecycleScope.launch {
            getBucketPath = intent.getStringExtra("BUCKET_PATH")
            getBucketSize = intent.getIntExtra("BUCKET_SIZE", 0)
            binding.tvCount.text = getBucketSize.toString() + " " + resources.getString(R.string.items)
            binding.rvAlbum.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    val first = if (recyclerView.layoutManager is GridLayoutManager) {
                        val layoutManager = recyclerView.layoutManager as GridLayoutManager
                        layoutManager.findFirstCompletelyVisibleItemPosition()
                    } else {
                        val layoutManager = recyclerView.layoutManager as LinearLayoutManager
                        layoutManager.findFirstCompletelyVisibleItemPosition()
                    }
                    if (first <= 1) {
                        binding.ivScrollTop.beGone()
                    } else {
                        if (first >= 8) {
                            binding.ivScrollTop.beVisible()
                        }
                    }
                }

                override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                    if (newState == RecyclerView.SCROLL_STATE_DRAGGING ||
                        newState == RecyclerView.SCROLL_STATE_SETTLING
                    ) {
                        ScrollGate.onScrollStart()
                    } else {
                        ScrollGate.onScrollStop()
                    }
                    if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                        lifecycleScope.launch {
                            delay(600)
                            binding.ivScrollTop.beGone()
                        }
                    }
                }
            })

            initSpanCountHelper()
            observableAlbum()
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onIntentEvent(intent: Intent) {
        when (intent.action) {
            AppblishEvent.ALL_VIDEO_ALBUM_LOADED -> {
                observableAlbum()
            }
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        unregisterEventBus(this)
    }


    private var albumHideResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            hideMediaFromAlbum()
        }
    }


    @SuppressLint("ClickableViewAccessibility")
    private fun initSpanCountHelper() {
        if (appPref.albumAsGrid) {
            val layoutManager = GridLayoutManager(this, appPref.albumGrid)
            binding.rvAlbum.layoutManager = layoutManager
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    return if (getAlbumAdaptor()?.getItem(position) is AlbumListItem.Header) {
                        appPref.albumGrid
                    } else {
                        1
                    }
                }
            }

            val listener = ScaleHintListener(
                context = this,
                recyclerView = binding.rvAlbum,
                layoutManager = layoutManager,
                ghostCardView = binding.ghostCardView,
                ghostImageView = binding.ghostImageView,
                gridHelperView = binding.gridHelperView,
                spanHintText = binding.spanHintText,
                landingCircle = binding.landingCircle,
                overlayContainer = binding.overlayContainer,
                imageViewExtractor = { itemView ->
                    itemView.findViewById(R.id.imageAlbum)
                },
                onUpdateSpan = { span ->
                    appPref.albumGrid = span
                },
                dimLayer = binding.dimLayer,
                minSpan = 2,
                maxSpan = 6
            )
            Log.e("ScaleHintListener", "ScaleHintListener")

            binding.rvAlbum.setOnTouchListener(listener)
            binding.rvAlbum.scheduleLayoutAnimation()
        } else {
            Log.e("ScaleHintListener", "ScaleHintListener null")
            val layoutManager = LinearLayoutManager(this)
            binding.rvAlbum.setOnTouchListener(null)
            binding.rvAlbum.layoutManager = layoutManager
            binding.rvAlbum.scheduleLayoutAnimation()
        }

    }


    fun observableAlbum() {
        setAlbumList(GallerySdkV2.get().getAllVideosList())
    }

    fun setAlbumList(state: MediaDataState<List<AlbumListItem>>) {
        when (state) {
            MediaDataState.Empty -> {
                binding.loutNoData.beVisible()
                binding.rlData.beVisible()
                binding.rlMediaData.beGone()
                binding.llLoader.beGone()
                setAlbums(emptyList())
            }

            MediaDataState.Loading -> {
                binding.rlData.beGone()
                binding.llLoader.beVisible()
                binding.lavLoader.restart()
                setAlbums(emptyList())
            }

            is MediaDataState.Success -> {
                binding.rlData.beVisible()
                binding.rlMediaData.beVisible()
                binding.llLoader.beGone()
                binding.loutNoData.beGone()
                binding.lavLoader.cancelAnimation()
                setAlbums(state.data)
            }

            is MediaDataState.Progress -> {

            }
        }
    }

    private fun setListeners() {
        onBackPressedDispatcher.addCallback {
            onBack()
        }
        binding.ivBack.setOnClickListener {
            onBack()
        }
        binding.ivClose.setOnClickListener {
            val albumAdaptor = getAlbumAdaptor() ?: return@setOnClickListener
            if (albumAdaptor.isSelectionActive()) {
                disableSelection()
            }
        }

        binding.ivScrollTop.setOnClickListener {
            scrollToTop()
        }

        binding.icSelectAll.setOnClickListener {
            val albumAdaptor = getAlbumAdaptor() ?: return@setOnClickListener
            if (albumAdaptor.isSelectAll()) {
                albumAdaptor.unSelectAll()
            } else {
                albumAdaptor.selectAll()
            }
        }
    }

    private fun scrollToTop() {
        val layoutManager = binding.rvAlbum.layoutManager as? GridLayoutManager
        if (layoutManager != null) {
            binding.rvAlbum.scrollToPosition(0)
        }
    }

    private fun initAdaptor() {
        if (binding.rvAlbum.adapter == null) {
            val albumAdaptor = AlbumListAdapter(binding.rvAlbum) {
                onAlbumSelect(it)
            }
            binding.rvAlbum.adapter = albumAdaptor

            albumAdaptor.setSelectionUpdateCallback(
                object : SelectionUpdateCallback {
                    override fun onSelectionCountChanged(
                        selectedCount: Int,
                        selectionActive: Boolean
                    ) {
                        updateSelections()
                    }
                }
            )
        }
    }

    private fun setAlbums(albums: List<AlbumListItem>) {
        lifecycleScope.launch {
            binding.rvAlbum.recycledViewPool.clear()
            Log.e("TAG", "setAlbums: ${albums.size}")
            binding.tvCount.text = albums.filterIsInstance<AlbumListItem.Album>().filter { !it.albumBox.isCustom }.flatMap { it.albumBox.mediaList }.count().toString()
            initAdaptor()
            binding.rvAlbum.post {
                getAlbumAdaptor()?.submitList(albums)
            }
            val list = albums.mapNotNull {
                if (it is AlbumListItem.Album) {
                    PreloadItem.Media(it.mediaPath, it.mediaDate)
                } else null
            }
            binding.rvAlbum.setupGlidePreLoader(this@AllVideosActivity, list, false)
        }
    }

    private fun getAlbumAdaptor() = binding.rvAlbum.adapter as? AlbumListAdapter


    fun disableSelection() {
        val albumAdaptor = getAlbumAdaptor() ?: return
        albumAdaptor.clearSelectionAndExit()
        updateSelections()
    }

    @SuppressLint("SetTextI18n")
    fun updateSelections() {
        val albumAdaptor = getAlbumAdaptor() ?: return
        val enableSelection = getAlbumAdaptor()?.isSelectionActive() ?: false
        binding.clSelection.beVisibleIf(enableSelection)
        binding.albumToolbar.beVisibleIf(!enableSelection)
        binding.tvTitleSelection.text = "${albumAdaptor.getSelectedCount()} " + getString(R.string.selected)
        if (albumAdaptor.isSelectAll()) {
            binding.icSelectAll.setImageResource(R.drawable.vec_selected_bg)
        } else {
            binding.icSelectAll.setImageResource(R.drawable.vec_unselected_bg)
        }
        updateAlbumFragmentSelection()
    }


    fun onAlbumSelect(albumModel: AlbumModel) {
        val intent = Intent(this, ExplorePhotosActivity::class.java)
        intent.putExtra("BUCKET_PATH", albumModel.bucketPath)
        intent.putExtra("BUCKET_SIZE", albumModel.mediaList.size)
        intent.putExtra("IS_VIDEO", true)
        startActivity(intent)
    }

    fun getSelectedAlbums() = getAlbumAdaptor()?.getSelectedItems()?.filterIsInstance<AlbumListItem.Album>()?.map { it.albumBox }
    fun isSelectionActive() = getAlbumAdaptor()?.isSelectionActive() ?: false

    fun updateAlbumFragmentSelection() {
        val enableSelection = isSelectionActive() ?: false
        binding.albumSelectionView.beVisibleIf(enableSelection)
        val folderList = getSelectedAlbums() ?: emptyList()
        val pinListHashSet = folderList.filter { it.isPinned }.map { it.bucketPath }
        val albumPathSet = folderList.map { it.bucketPath }.toHashSet()
        val remainToPin = albumPathSet.filter { it !in pinListHashSet }

        if (remainToPin.isNotEmpty() || albumPathSet.isEmpty()) {
            binding.tvTitleAlbumPin.text = getString(R.string.pin)
            binding.ivAlbumPin.setImageResource(R.drawable.vec_album_pin)
        } else {
            binding.tvTitleAlbumPin.text = getString(R.string.unpin)
            binding.ivAlbumPin.setImageResource(R.drawable.vec_album_unpin)
        }

        binding.clPin.setOnClickListener {
            if (folderList.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            if (remainToPin.isNotEmpty()) {
                sharedViewModel.addPinnedAlbum(remainToPin)
            } else {
                val removed = folderList.map { it.bucketPath }
                sharedViewModel.removePinnedAlbum(removed)
            }
            sharedViewModel.refreshMedia()
            disableSelection()
        }

        binding.clDelete.setOnClickListener {
            if (folderList.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            checkStoragePermission {
                if (it) {
                    val allMedias = folderList.flatMap { it.mediaList.map { it.mediaPath } }
                    deleteMedia(allMedias) {
                        disableSelection()
                    }
                }
            }

        }

        binding.clHide.setOnClickListener {
            if (folderList.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }

            checkStoragePermission {
                if (it) {
                    if (preferences.getSetPass()) {
                        hideMediaFromAlbum()
                    } else {
                        val intent = Intent(this, SetLockActivity::class.java)
                        intent.putExtra("setResultCode", 101)
                        albumHideResult.launch(intent)
                    }
                }
            }
        }

        binding.clMore.setOnClickListener {
            if (folderList.isEmpty()) {
                toast(getString(R.string.please_select_item))
                return@setOnClickListener
            }
            showAlbumDropDown(it, folderList)
        }
    }

    private fun hideMediaFromAlbum() {
        val dialog = ConfirmationDialog(
            this,
            ContextCompat.getString(this, R.string.hide),
            ContextCompat.getString(this, R.string.confirmation_hide_item),
            ContextCompat.getString(this, R.string.no),
            ContextCompat.getString(this, R.string.yes),
            ContextCompat.getColor(this, R.color.white_color)
        ) {
            val getListFromAlbum = getSelectedAlbums() ?: emptyList()
            val allMedias = getListFromAlbum.flatMap { it.mediaList.map { it.mediaPath } }
            hideMediaFolder(allMedias) {
                disableSelection()
            }
        }
        dialog.show(supportFragmentManager, "ConfirmationDialog")
    }

    private fun showAlbumDropDown(view: View, folderList: List<AlbumModel>) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopAlbumMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)
        popUpBinding.menuRename.beVisibleIf(folderList.size == 1)
        popUpBinding.menuSetAs.beGone()

        popupWindow.showAsPopUp(view, yoff = -20, xoff = 20)
        popUpBinding.run {
            loutMain.setOnClickListener {
                popupWindow.dismiss()
                Log.e("btmSelectionView", "loutMain: ")
            }

            menuRename.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        val renameAlbumDialog = RenameAlbumDialog(this@AllVideosActivity)
                        renameAlbumDialog.bucketPath = folderList.first().bucketPath
                        renameAlbumDialog.positiveBtnClickListener = { renamedFile, oldFile ->
                            disableSelection()
                            showLoadingDialog()
                            sharedViewModel.renameAlbum(oldFile.absolutePath, renamedFile.name) {
                                hideLoadingDialog()
                                if (it) {
                                    sharedViewModel.fetchMedia()
                                }
                            }
                        }
                        renameAlbumDialog.show(supportFragmentManager, "RenameAlbumDialog")
                    }
                }
            }

            menuInfo.setOnClickListener {
                popupWindow.dismiss()

                val mediaCount = folderList.flatMap { it.mediaList }.count()
                val mediaSize = folderList.flatMap { it.mediaList }.sumOf { it.mediaSize }
                AlbumDetailsDialog
                    .newInstance(
                        bucketPath = folderList.map { it.bucketPath },
                        mediaCount = mediaCount,
                        mediaTotalSize = mediaSize
                    )
                    .show(supportFragmentManager, "AlbumDetailsBottomSheet")
            }

            menuCopy.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        requestAlbumPicker(folderList.map { it.bucketPath }.toTypedArray()) {
                            if (it.isNotEmpty()) {
                                disableSelection()
                                copyFolderFiles(folderList.flatMap { it.mediaList.map { it.mediaPath } }, it)
                            }
                        }
                    }
                }
            }

            menuMove.setOnClickListener {
                popupWindow.dismiss()
                checkStoragePermission {
                    if (it) {
                        requestAlbumPicker(folderList.map { it.bucketPath }.toTypedArray()) {
                            if (it.isNotEmpty()) {
                                disableSelection()
                                moveFolderFiles(folderList.flatMap { it.mediaList.map { it.mediaPath } }, it)
                            }
                        }
                    }
                }
            }
        }
    }
}