package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogSpeedBinding

class SpeedDialog(val speedCheck: Float) : DialogFragment() {

    private var _binding: DialogSpeedBinding? = null
    private val binding get() = _binding!!

    // Public callback
    var speedListener: ((Float) -> Unit)? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogSpeedBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)



        dialog.window?.apply {
            setBackgroundDrawableResource(R.color.transparent)
            setLayout(
                requireContext().resources.displayMetrics.widthPixels - 100,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
            setGravity(Gravity.CENTER)
        }

        initView()
        return dialog
    }

    private fun initView() {

        binding.speedSlider.value = speedCheck
        binding.ivClose.setOnClickListener {
            dismiss()
        }

        // Slider change listener
        binding.speedSlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) {
                speedListener?.invoke(value)
            }
        }

        // Preset buttons
        binding.speed05.setOnClickListener { setSpeed(0.5f) }
        binding.speed10.setOnClickListener { setSpeed(1.0f) }
        binding.speed15.setOnClickListener { setSpeed(1.5f) }
        binding.speed20.setOnClickListener { setSpeed(2.0f) }
    }

    private fun setSpeed(value: Float) {
        binding.speedSlider.value = value
        speedListener?.invoke(value)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onStart() {
        super.onStart()

        dialog?.window?.apply {

            // Remove default white background
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            // Dim amount control
            setDimAmount(0.6f)

            // Width
            setLayout(
                requireContext().resources.displayMetrics.widthPixels - 100,
                WindowManager.LayoutParams.WRAP_CONTENT
            )

            setGravity(Gravity.CENTER)
        }
    }

}