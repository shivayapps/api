package gallery.photogallery.photoeditor.galleryapp.dialogs

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import gallery.photogallery.photoeditor.galleryapp.activities.ExploreHiddenAlbumActivity
import gallery.photogallery.photoeditor.galleryapp.activities.HiddenAlbumActivity
import gallery.photogallery.photoeditor.galleryapp.activities.TrashActivity
import gallery.photogallery.photoeditor.galleryapp.databinding.DialogDeleteBinding
import gallery.photogallery.photoeditor.galleryapp.extentions.getScreenWidthFraction
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf

class DeleteDialog() : DialogFragment() {
    private var _binding: DialogDeleteBinding? = null
    private val binding get() = _binding!!
    var btnClickListener: ((isPermanent: Boolean) -> Unit)? = null

    companion object {
        fun newInstance(btnClickListener: ((isPermanent: Boolean) -> Unit)?): DeleteDialog {
            val deleteDialog = DeleteDialog()
            deleteDialog.btnClickListener = btnClickListener
            return deleteDialog
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        _binding = DialogDeleteBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.apply {
            setBackgroundDrawableResource(gallery.photogallery.photoeditor.galleryapp.R.color.transparent)
            setLayout(requireContext().getScreenWidthFraction(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER) // remove if you want center dialog
        }

        intView()
        return dialog
    }

    private fun intView() {
        binding.txtRestoredMsg.beVisibleIf(
            requireContext() is HiddenAlbumActivity ||
                    requireContext() is ExploreHiddenAlbumActivity ||
                    requireContext() is TrashActivity
        )

        binding.btnTrash.setOnClickListener {
            dismiss()
            btnClickListener?.invoke(false)
        }

        binding.btnPermanent.setOnClickListener {
            dismiss()
            btnClickListener?.invoke(true)
        }
    }
}