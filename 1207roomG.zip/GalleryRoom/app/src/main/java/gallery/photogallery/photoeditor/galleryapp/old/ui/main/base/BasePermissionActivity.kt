package gallery.photogallery.photoeditor.galleryapp.old.ui.main.base

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import androidx.lifecycle.ViewModelProvider
import gallery.photogallery.photoeditor.galleryapp.App
import gallery.photogallery.photoeditor.galleryapp.SharedViewModel
import gallery.photogallery.photoeditor.galleryapp.activities.AllFilePermissionHintActivity
import gallery.photogallery.photoeditor.galleryapp.dialogs.StoragePermissionDialog
import gallery.photogallery.photoeditor.galleryapp.permission.PermissionSDK
import java.util.Locale

open class BasePermissionActivity : AppCompatActivity() {
    val sharedViewModel = ViewModelProvider(App.instance.appViewModelStoreOwner)[SharedViewModel::class.java]

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
    }


    fun setLocale(languageCode: String) {
        val locale = Locale(languageCode)
        Locale.setDefault(locale)
        val config = Configuration()
        config.setLocale(locale)
        resources.updateConfiguration(config, resources.displayMetrics)

    }


    var countDownTimerOverlay: CountDownTimer? = null

    @SuppressLint("UseKtx")
    fun requestManageAllFile(autoRedirect: (Boolean) -> Unit) {
        storagePermissionCallback = autoRedirect
        try {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
            intent.addCategory("android.intent.category.DEFAULT")
            intent.data = "package:$packageName".toUri()
            storagePermissionLauncher.launch(intent)
        } catch (e: Exception) {
            val intent = Intent()
            intent.action = Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
            storagePermissionLauncher.launch(intent)
        }
        countDownTimerOverlay?.cancel()
        countDownTimerOverlay = object : CountDownTimer(1000000L, 500) {
            override fun onTick(l: Long) {
                if (Environment.isExternalStorageManager()) {
                    cancel()
                    autoRedirect.invoke(true)
                }
            }

            override fun onFinish() {}
        }
        countDownTimerOverlay!!.start()
        Handler(Looper.myLooper()!!).postDelayed({
            startActivity(Intent(this, AllFilePermissionHintActivity::class.java))
        }, 300)
    }

    var storagePermissionCallback: ((Boolean) -> Unit)? = null

    private val storagePermissionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (PermissionSDK.isExternalStorageManager()) {
            storagePermissionCallback?.invoke(true)
        } else {
            storagePermissionCallback?.invoke(false)
        }
    }

    fun requestAllFilePermission(callback: (Boolean) -> Unit) {
        storagePermissionCallback = callback
        try {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
            intent.addCategory("android.intent.category.DEFAULT")
            intent.data = "package:$packageName".toUri()
            storagePermissionLauncher.launch(intent)
        } catch (e: Exception) {
            val intent = Intent()
            intent.action = Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
            storagePermissionLauncher.launch(intent)
        }

    }

    fun checkStoragePermission(callback: (Boolean) -> Unit) {
        if (PermissionSDK.isExternalStorageManager()) {
            callback.invoke(true)
        } else {
            val dialog = StoragePermissionDialog( cancelCallBack = {
                callback.invoke(false)
            }, okCallBack = {
                requestAllFilePermission(callback)
            })
            dialog.show(supportFragmentManager, "StoragePermissionDialog")
        }
    }
}