package gallery.photogallery.photoeditor.galleryapp.old.ui.main.utils.transformation1

import android.view.View
import androidx.viewpager.widget.ViewPager


class RotateDown : ViewPager.PageTransformer {

    override fun transformPage(view: View, position: Float) {
        val width = view.width
        val rotation = -15f * position

        view.pivotX = width * 0.5f
        view.pivotY = 0f
        view.translationX = 0f
        view.rotation = rotation
    }

}