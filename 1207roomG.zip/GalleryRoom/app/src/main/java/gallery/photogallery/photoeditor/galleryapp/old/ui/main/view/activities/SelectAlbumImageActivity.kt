package gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.activities

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.appblish.box.api.model.MediaBox
import gallery.photogallery.photoeditor.galleryapp.R
import gallery.photogallery.photoeditor.galleryapp.databinding.ActivitySelectAlbumBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.base.BaseActivity
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.appPref
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beGone
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.beVisibleIf
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.isDarkMode
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.navigationBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.statusBarHeight
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.toast
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.extentions.viewBinding
import gallery.photogallery.photoeditor.galleryapp.old.ui.main.view.adapter.ImagePickerAdapter
import kotlinx.coroutines.launch

class SelectAlbumImageActivity : BaseActivity(), View.OnClickListener {

    companion object {
        private const val ARGS_FOLDER_PATH = "ARGS_FOLDER_PATH"
        private const val ARGS_ACTION = "ARGS_ACTION"
        private const val ARGS_IS_MULTI_SELECT = "ARGS_IS_MULTI_SELECT"


        fun createIntentImageSelect(context: Context, folderPath: String, isMultiSelect: Boolean = true): Intent {
            return Intent(context, SelectAlbumImageActivity::class.java).apply {
                putExtra(ARGS_FOLDER_PATH, folderPath)
                putExtra(ARGS_IS_MULTI_SELECT, isMultiSelect)
                putExtra(ARGS_ACTION, "select_images")
            }

        }

    }

    private val folderPath: String by lazy { intent.getStringExtra(ARGS_FOLDER_PATH) ?: "" }
    private val isMultiSelect: Boolean by lazy { intent.getBooleanExtra(ARGS_IS_MULTI_SELECT, false) }
    private val imagePickerAdapter by lazy { ImagePickerAdapter() }
    private val binding by viewBinding(ActivitySelectAlbumBinding::inflate)


    val textColor by lazy { ContextCompat.getColor(this, R.color.black_text) }
    val primaryColor by lazy { ContextCompat.getColor(this, R.color.color_primary) }


    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        enableEdgeToEdge()
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = !isDarkMode()
        controller.isAppearanceLightNavigationBars = !isDarkMode()
        window?.navigationBarColor = ContextCompat.getColor(this, R.color.app_background)
        binding.root.setPadding(0, statusBarHeight, 0, navigationBarHeight)
        initUI()
        initClick()
        observableMedia()
    }

    private fun initUI() {
        binding.ivNew.beGone()
        binding.btnDone.text = if (folderPath == "HiddenAlbumActivity") {
            ContextCompat.getString(this, R.string.str_import)
        } else {
            ContextCompat.getString(this, R.string.ok)
        }
    }


    private fun initClick() {
        binding.ivBack.setOnClickListener(this)
        binding.btnDone.setOnClickListener(this)
        binding.btnDone.beVisibleIf(isMultiSelect)
    }

    override fun onClick(view: View?) {
        when (view) {
            binding.ivBack -> {
                setResult(RESULT_CANCELED, Intent())
                finish()
            }

            binding.btnDone -> {
                val list = imagePickerAdapter.selectedItems.map { it.mediaPath }
                if (list.isEmpty()) {
                    toast(getString(R.string.please_select_item))
                    return
                }
                if (folderPath == "HiddenAlbumActivity") {
                    hideMediaFolder(list) {
                        finish()
                    }
                } else {
                    copyFolderFiles(list, folderPath) {
                        finish()
                    }
                }
            }
        }
    }

    private fun observableMedia() {
        lifecycleScope.launch {
            sharedViewModel.fetchAllMediaBox { list ->
                setMedia(list)
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun setMedia(mediaList: List<MediaBox>) {
        lifecycleScope.launch {
            Log.e("TAG", "mediaList: ${mediaList.size}")
            if (binding.mediaRecycler.adapter == null) {
                binding.mediaRecycler.adapter = imagePickerAdapter
                binding.mediaRecycler.layoutManager = GridLayoutManager(this@SelectAlbumImageActivity, appPref.mediaGrid)
                imagePickerAdapter.onSelectionUpdate = {
                    if (isMultiSelect) {
                        binding.btnDone.beVisibleIf(imagePickerAdapter.selectedItems.isNotEmpty())
                        binding.btnDone.text = if (folderPath == "HiddenAlbumActivity") {
                            ContextCompat.getString(this@SelectAlbumImageActivity, R.string.str_import) + " (" + "${imagePickerAdapter.selectedItems.size}" + ")"
                        } else {
                            ContextCompat.getString(this@SelectAlbumImageActivity, R.string.ok) + " (" + "${imagePickerAdapter.selectedItems.size}" + ")"
                        }
//                        binding.btnDone.text = "${getString(R.string.ok)} (${imagePickerAdapter.selectedItems.size})"
                    } else {
                        finish()
                    }
                }
            }
            imagePickerAdapter.submitList(mediaList)
        }
    }


}
