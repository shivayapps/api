package com.appblish.collagemaker.sdk

import android.content.Context
import android.graphics.Canvas
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import com.appblish.collagemaker.appblish.AppblishCollageText
import com.appblish.collagemaker.appblish.AppblishCollageTextView
import com.appblish.collagemaker.appblish.AppblishCollageTextShadow
import com.appblish.collagemaker.sticker.Sticker

object AppblishTextSdk {

    private var textView: AppblishCollageTextView? = null


    fun create(
        context: Context,
        textProps: AppblishCollageText
    ) {
        textView = AppblishCollageTextView(context, textProps)
    }


    internal fun obtainSticker(): Sticker {
        return textView
            ?: throw IllegalStateException("TextSdk not initialized")
    }

    internal fun getSticker(): Sticker {
        if (textView == null) {
            throw IllegalStateException("TextSdk not initialized")
        }
        return textView!!
    }


    private fun check() {
        if (textView == null) {
            throw IllegalStateException("AppblishTextSdk not initialized")
        }
    }

    // =========================
    // Draw / Lifecycle
    // =========================
    fun draw(canvas: Canvas) {
        check()
        textView!!.draw(canvas)
    }

    fun release() {
        check()
        textView!!.release()
    }

    // =========================
    // Alpha
    // =========================
    fun getAlpha(): Int {
        check()
        return textView!!.alpha
    }

    fun setAlpha(alpha: Int) {
        check()
        textView!!.setAlpha(alpha)
    }

    // =========================
    // Drawable
    // =========================
    fun getDrawable(): Drawable {
        check()
        return textView!!.drawable
    }

    fun setDrawable(drawable: Drawable) {
        check()
        textView!!.setDrawable(drawable)
    }

    // =========================
    // Text
    // =========================
    fun getText(): String? {
        check()
        return textView!!.text
    }

    fun setText(text: String?) {
        check()
        textView!!.setText(text)
    }

    // =========================
    // Size
    // =========================
    fun getWidth(): Int {
        check()
        return textView!!.width
    }

    fun getHeight(): Int {
        check()
        return textView!!.height
    }

    fun setTextWidth(width: Int) {
        check()
        textView!!.setTextWidth(width)
    }

    fun setTextHeight(height: Int) {
        check()
        textView!!.setTextHeight(height)
    }

    // =========================
    // Resize
    // =========================
    fun resizeText() {
        check()
        textView!!.resizeText()
    }

    // =========================
    // Background
    // =========================
    fun setBackgroundColor(color: Int) {
        check()
        textView!!.setBackgroundColor(color)
    }

    fun setBackgroundAlpha(alpha: Int) {
        check()
        textView!!.setBackgroundAlpha(alpha)
    }

    fun setBackgroundBorder(border: Int) {
        check()
        textView!!.setBackgroundBorder(border)
    }

    fun setShowBackground(show: Boolean) {
        check()
        textView!!.setShowBackground(show)
    }

    // =========================
    // Padding
    // =========================
    fun setPaddingWidth(padding: Int) {
        check()
        textView!!.setPaddingWidth(padding)
    }

    // =========================
    // Text Style
    // =========================
    fun setTextColor(color: Int) {
        check()
        textView!!.setTextColor(color)
    }

    fun setTextAlpha(alpha: Int) {
        check()
        textView!!.setTextAlpha(alpha)
    }

    fun setTextSize(sizeSp: Int) {
        check()
        textView!!.setTextSize(sizeSp)
    }

    fun setTypeface(typeface: Typeface?) {
        check()
        textView!!.setTypeface(typeface)
    }

    fun setTextAlign(align: Int) {
        check()
        textView!!.setTextAlign(align)
    }

    // =========================
    // Shadow / Shader
    // =========================
    fun setTextShadow(shadow: AppblishCollageTextShadow?) {
        check()
        textView!!.setTextShadow(shadow)
    }

    fun setTextShader(shader: Shader?) {
        check()
        textView!!.setTextShare(shader)
    }
}