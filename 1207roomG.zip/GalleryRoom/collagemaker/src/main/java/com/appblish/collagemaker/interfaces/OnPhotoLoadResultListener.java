package com.appblish.collagemaker.interfaces;

public interface OnPhotoLoadResultListener {
    void onResult(boolean success);
}
