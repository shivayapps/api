package com.appblish.collagemaker.roundedimage;

import android.content.Context;
import android.util.AttributeSet;



public class CollageRoundedImageView extends CollageShaderImageView {
    private CollageRoundedShader shader;
    public CollageRoundedImageView(Context context) {
        super(context);
    }

    public CollageRoundedImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CollageRoundedImageView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    public CollageShaderHelper createImageViewHelper() {
        shader = new CollageRoundedShader();
        return shader;
    }

    public final int getRadius() {
        if(shader != null) {
            return shader.getRadius();
        }
        return 0;
    }

    public final void setRadius(final int radius) {
        if(shader != null) {
            shader.setRadius(radius);
            invalidate();
        }
    }

}