package com.appblish.collagemaker.appblishlayout.straight;


import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLine;

public class NineStraightLayout extends NumberStraightLayout {
    public NineStraightLayout(StraightCollageLayout straightPuzzleLayout, boolean z) {
        super(straightPuzzleLayout, z);
    }

    public NineStraightLayout(int i) {
        super(i);
    }

    public int getThemeCount() {
        return 8;
    }

    public void layout() {
        switch (this.theme) {
            case 0:
                cutAreaEqualPart(0, 2, 2);
                return;
            case 1:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.75f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.33333334f);
                cutAreaEqualPart(2, 4, AppblishCollageLine.Direction.HORIZONTAL);
                cutAreaEqualPart(0, 4, AppblishCollageLine.Direction.HORIZONTAL);
                return;
            case 2:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.75f);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.33333334f);
                cutAreaEqualPart(2, 4, AppblishCollageLine.Direction.VERTICAL);
                cutAreaEqualPart(0, 4, AppblishCollageLine.Direction.VERTICAL);
                return;
            case 3:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.75f);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.33333334f);
                cutAreaEqualPart(2, 3, AppblishCollageLine.Direction.VERTICAL);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.75f);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.33333334f);
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.VERTICAL);
                return;
            case 4:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.75f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.33333334f);
                cutAreaEqualPart(2, 3, AppblishCollageLine.Direction.HORIZONTAL);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.75f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.33333334f);
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.HORIZONTAL);
                return;
            case 5:
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.VERTICAL);
                addLine(2, AppblishCollageLine.Direction.HORIZONTAL, 0.75f);
                addLine(2, AppblishCollageLine.Direction.HORIZONTAL, 0.33333334f);
                cutAreaEqualPart(1, 3, AppblishCollageLine.Direction.HORIZONTAL);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.75f);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.33333334f);
                return;
            case 6:
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.HORIZONTAL);
                addLine(2, AppblishCollageLine.Direction.VERTICAL, 0.75f);
                addLine(2, AppblishCollageLine.Direction.VERTICAL, 0.33333334f);
                cutAreaEqualPart(1, 3, AppblishCollageLine.Direction.VERTICAL);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.75f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.33333334f);
                return;
            case 7:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                cutAreaEqualPart(1, 1, 3);
                return;
            default:
                return;
        }
    }

    public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
        return new NineStraightLayout((StraightCollageLayout) appblishLayout, true);
    }
}
