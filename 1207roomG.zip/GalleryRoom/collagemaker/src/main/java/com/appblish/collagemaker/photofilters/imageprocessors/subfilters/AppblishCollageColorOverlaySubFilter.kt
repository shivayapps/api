package com.appblish.collagemaker.photofilters.imageprocessors.subfilters

import android.graphics.Bitmap
import com.appblish.collagemaker.photofilters.imageprocessors.ImageProcessor
import com.appblish.collagemaker.photofilters.imageprocessors.SubFilter

class AppblishCollageColorOverlaySubFilter(
    private val colorOverlayDepth: Int,
    private val colorOverlayRed: Float,
    private val colorOverlayGreen: Float,
    private val colorOverlayBlue: Float
) : SubFilter {
    override fun process(inputImage: Bitmap?): Bitmap {
        return ImageProcessor.doColorOverlay(
            colorOverlayDepth, colorOverlayRed, colorOverlayGreen, colorOverlayBlue, inputImage
        )
    }

    override var tag: Any
        get() = Companion.tag
        set(tag) {
            Companion.tag = tag as String
        }

    companion object {
        private var tag = ""
    }
}
