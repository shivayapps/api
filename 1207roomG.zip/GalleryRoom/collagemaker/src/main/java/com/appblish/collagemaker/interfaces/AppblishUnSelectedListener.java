package com.appblish.collagemaker.interfaces;

public interface AppblishUnSelectedListener {
            void onAppblishUnSelected();
        }