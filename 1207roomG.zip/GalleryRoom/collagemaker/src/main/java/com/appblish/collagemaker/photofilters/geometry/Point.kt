package com.appblish.collagemaker.photofilters.geometry

class Point(var x: Float, var y: Float)
