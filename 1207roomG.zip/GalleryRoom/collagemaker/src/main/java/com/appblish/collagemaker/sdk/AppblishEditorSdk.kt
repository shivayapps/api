package com.appblish.collagemaker.sdk

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.drawable.Drawable
import com.appblish.collagemaker.appblish.AppblishCollageView
import com.appblish.collagemaker.appblish.AppblishCollageStickerView
import com.appblish.collagemaker.appblish.grid.AppblishCollageGrid
import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout
import com.appblish.collagemaker.interfaces.AppblishSelectedListener
import com.appblish.collagemaker.interfaces.AppblishUnSelectedListener
import com.appblish.collagemaker.interfaces.AppblishCollageBlurCallback
import com.appblish.collagemaker.interfaces.AppblishCollageOnStickerOperationListener
import com.appblish.collagemaker.sticker.Sticker
import com.appblish.collagemaker.utils.AppblishCollageAspectRatio

object AppblishEditorSdk {

    private var view: AppblishCollageView? = null

    fun init(appblishCollageView: AppblishCollageView) {
        view = appblishCollageView
    }

    private fun check() {
        if (view == null) {
            throw IllegalStateException("AppblishEditorSdk not initialized")
        }
    }

    // =========================
    // Init / Reset
    // =========================
    fun reset() { check(); view!!.reset() }
    fun clearAppblish() { check(); view!!.clearAppblish() }
    fun clearHandling() { check(); view!!.clearHandling() }
    fun clearSelectedLine() { check(); view!!.clearSelectedLine() }
    fun clearHandlingPieces() { check(); view!!.clearHandlingPieces() }

    // =========================
    // Initialize
    // =========================
//    fun setAppInitializeList(list: MutableList<String?>) {
//        check(); view!!.setAppInitializeList(list)
//    }

    fun setAppInitializeList(
        list: MutableList<String?>,
        callback: (Boolean) -> Unit
    ) {
        check()

        val safeList = list.filterNotNull()

        view?.setAppInitializeList(safeList) { success ->
            callback(success)
        }
    }


    // =========================
    // Layout
    // =========================
    fun updateLayout(layout: AppblishCollageLayout) {
        check(); view!!.updateLayout(layout)
    }

    fun updateLayout(position: Int, list: MutableList<String?>) {
        check(); view!!.updateLayout(position, list)
    }

    fun setCollageLayout(info: AppblishCollageLayout.Info) {
        check(); view!!.setCollageLayout(info)
    }

    fun setAppblishLayout(layout: AppblishCollageLayout) {
        check(); view!!.appblishLayout = layout
    }

    fun getAppblishLayout(): AppblishCollageLayout {
        check(); return view!!.appblishLayout
    }

    // =========================
    // Grid
    // =========================
    fun getAppblishGrid(): AppblishCollageGrid {
        check(); return view!!.appblishGrid
    }

    fun setAppblishGrid(grid: AppblishCollageGrid) {
        check(); view!!.appblishGrid = grid
    }

    fun getAppblishGrids(): List<AppblishCollageGrid> {
        check(); return view!!.appblishGrids
    }

    // =========================
    // Pieces
    // =========================
    fun addPieces(bitmaps: List<Bitmap>) {
        check(); view!!.addPieces(bitmaps)
    }

    fun addBitmap(bitmap: Bitmap) {
        check(); view!!.addAppblishCollage(bitmap)
    }

    fun addDrawable(drawable: Drawable) {
        check(); view!!.addAppblishCollage(drawable)
    }

    fun setBackground(drawable: Drawable?) {
        view!!.setLayoutBackground(drawable)
    }
    fun setLayoutBackground(drawable: Drawable) {
        check(); view!!.setLayoutBackground(drawable)
    }

    fun addDrawable(drawable: Drawable, matrix: Matrix) {
        check(); view!!.addAppblishCollage(drawable, matrix)
    }

    fun addDrawable(drawable: Drawable, matrix: Matrix, path: String) {
        check(); view!!.addAppblishCollage(drawable, matrix, path)
    }

    fun replace(bitmap: Bitmap, path: String) {
        check(); view!!.replace(bitmap, path)
    }

    fun replaceDrawable(drawable: Drawable, path: String) {
        check(); view!!.replaceUri(drawable, path)
    }

    // =========================
    // Transform
    // =========================
    fun flipHorizontally() { check(); view!!.flipHorizontally() }
    fun flipVertically() { check(); view!!.flipVertically() }
    fun rotate(degree: Float) { check(); view!!.rotate(degree) }

    // =========================
    // Touch
    // =========================
    fun setTouchEnable(enable: Boolean) {
        check(); view!!.setTouchEnable(enable)
    }

    // =========================
    // Aspect Ratio
    // =========================
    fun setAspectRatio(ratio: String) {
        check(); view!!.setAspectRatio(ratio)
    }

    fun getAspectRatio(): AppblishCollageAspectRatio {
        check(); return view!!.aspectRatio
    }

    // =========================
    // Animation
    // =========================
    fun setAnimateDuration(duration: Int) {
        check(); view!!.setAnimateDuration(duration)
    }

    // =========================
    // Lines
    // =========================
    fun setNeedDrawLine(enable: Boolean) {
        check(); view!!.setNeedDrawLine(enable)
    }

    fun setNeedDrawOuterLine(enable: Boolean) {
        check(); view!!.setNeedDrawOuterLine(enable)
    }

    fun setLineColor(color: Int) {
        check(); view!!.setLineColor(color)
    }

    fun setLineSize(size: Int) {
        check(); view!!.setLineSize(size)
    }

    fun setSelectedLineColor(color: Int) {
        check(); view!!.setSelectedLineColor(color)
    }

    fun setHandleBarColor(color: Int) {
        check(); view!!.setHandleBarColor(color)
    }

    // =========================
    // Padding / Radian
    // =========================
    fun setCollagePadding(padding: Float) {
        check(); view!!.collagePadding = padding
    }

    fun getCollagePadding(): Float {
        check(); return view!!.collagePadding
    }

    fun setCollageRadian(radian: Float) {
        check(); view!!.collageRadian = radian
    }

    fun getCollageRadian(): Float {
        check(); return view!!.collageRadian
    }

    // =========================
    // Background
    // =========================
    fun setBackgroundColor(color: Int) {
        check(); view!!.setBackgroundColor(color)
    }

    fun setBackgroundResorce(resId: Int) {
        check(); view!!.setBackgroundResorce(resId)
    }

    fun setBackgroundResourceMode(mode: Int) {
        check(); view!!.backgroundResourceMode = mode
    }

    fun getBackgroundResourceMode(): Int {
        check(); return view!!.backgroundResourceMode
    }

    fun setBackgroundBlurGrid(
        context: Context,
        path: Drawable,
        callback: AppblishCollageBlurCallback?
    ) {
        check()
        view!!.setBackgroundBlurGrid(context, path, callback)
    }

    // =========================
    // Selection
    // =========================
    fun setOnAppblishSelectedListener(listener: AppblishSelectedListener) {
        check(); view!!.setOnAppblishSelectedListener(listener)
    }


    fun setLocked(boolean: Boolean){
        view!!.setLocked(boolean)

    }
    fun setHandlingSticker(sticker: Sticker?) {
        view!!.setHandlingSticker(sticker)
    }


    fun getStickers(): MutableList<Sticker?> {
        return view!!.stickers
    }
    fun setOnAppblishUnSelectedListener(listener: AppblishUnSelectedListener) {
        check(); view!!.setOnAppblishUnSelectedListener(listener)
    }

 fun checklistClear( ) {
        check(); view!!.checklistClear()
    }


    fun addSticker(sticker: Sticker): AppblishCollageStickerView {
        return view!!.addSticker(sticker, 1)
    }

    fun getLastHandlingSticker(): Sticker? {
        return view!!.lastHandlingSticker
    }
    fun showLastHandlingSticker() {
        return view!!.showLastHandlingSticker()
    }

    fun addTextSticker() {
        check()
        view!!.addSticker(AppblishTextSdk.obtainSticker())
    }

    fun updateIconDrawable(tag: String,drawable: Drawable) {
        check()
        view!!.updateIconDrawable(tag,drawable)
    }
    fun setCircleColor(color: Int) {
        check()
        view!!.setCircleColor(color)
    }


    fun setOnStickerOperationListener(onStickerOperationListener2: AppblishCollageOnStickerOperationListener?): AppblishCollageStickerView {
        check()
        view!!.onStickerOperationListener = onStickerOperationListener2
        return view!!
    }



    fun updateIconWithPosition(tag: String,drawable: Drawable,position: Int) {
        check()
        view!!.updateIconWithPosition(tag,drawable,position)
    }




    fun getGradientAssets(context: Context): List<String> {
        return try {
            context.assets.list("gradient")?.toList() ?: emptyList()
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }


    fun getGradientDrawables(context: Context): List<Int> {
        val drawableList = mutableListOf<Int>()

        for (i in 1..64) {
            val resId = context.resources.getIdentifier(
                "gradient_$i",
                "drawable",
                context.packageName
            )

            if (resId != 0) {
                drawableList.add(resId)
            }
        }
        return drawableList
    }

    fun listColorBrush(): List<String> {
        return arrayListOf(
            // FREE
            "#FFFFFF",
            "#BBBBBB",
            "#4E4E4E",
            // "#212121",
            "#000000",
            "#FFD7CD",
            "#F9AB9D",
            "#EC5C60",
            "#CB3243",
            "#CD181F",
            "#FF0000",
            "#FFF2CA",
            "#FDE472",
            "#F3AF59",
            "#FC7F3D",
            "#ED3F0F",
            "#FFF1F1",
            "#FFE1E4",
            "#FFA4B9",
            "#FF679F",
            "#FB2C78",
            "#E7D5E7",
            "#D3A6D8",
            "#BA66AF",
            "#A53B8E",
            "#65218C",
            "#99D2F9",
            "#81ADEA",
            "#2961A9",
            "#0E2E89",
            "#171982",
            "#A5E7F6",
            "#7CE3FF",
            "#00B0D0",
            "#058BC0",
            "#08447E",
            "#DEEEE9",
            "#B3D0C5",
            "#4DAF9D",
            "#21887C",
            "#0F664E",
            "#D3E5A6",
            "#AACE87",
            "#A3AF38",
            "#6D822B",
            "#366131",
            "#E4D9C0",
            "#D6C392",
            "#A3815A",
            "#72462F",
            "#3E3129",

            // PRO 1
            "#A7A7A7",
            "#995452",
            "#E1D6D7",
            "#CCBFD4",
            "#A67C80",
            "#D4D3CF",
            "#7A7185",
            "#6E5055",
            "#666563",
            "#F0E4FB",
            "#EED0D5",
            "#E1CCD1",
            "#C3C9DF",
            "#929493",
            "#807D5C",
            "#E2E4E1",
            "#8596A4",
            "#ECECEC",
            "#96A48C",
            "#AFB0B2",
            "#BEC0BF",
            "#B7C5B3",
            "#A0A7BA",
            "#FFFAF7",
            "#7D8970",

            // PRO 2
            "#FF7063",
            "#FF3274",
            "#3EA2D7",
            "#FFA258",
            "#F22D52",
            "#F2A0B6",
            "#7285F2",
            "#3ADB7C",
            "#F2C4CD",
            "#129AEF",
            "#0278A6",
            "#0D8C39",
            "#5639A5",
            "#A482F4",
            "#4AE3D2",
            "#00D28E",
            "#FA4848",
            "#434882",
            "#730068",
            "#729D38",
            "#C6E377",
            "#022D3C",
            "#900C3F",
            "#FF5733",
            "#FFC300"
        )
    }

}