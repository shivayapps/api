package com.appblish.collagemaker.appblishlayout.straight;


import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLine;

public class ThreeStraightLayout extends NumberStraightLayout {
    public ThreeStraightLayout(StraightCollageLayout straightPuzzleLayout, boolean z) {
        super(straightPuzzleLayout, z);
    }

    public ThreeStraightLayout(int i) {
        super(i);
    }

    public int getThemeCount() {
        return 6;
    }

    public void layout() {
        switch (this.theme) {
            case 0:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                return;
            case 1:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                return;
            case 2:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 3:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 4:
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.HORIZONTAL);
                return;
            case 5:
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.VERTICAL);
                return;
            default:
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.HORIZONTAL);
                return;
        }
    }

    public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
        return new ThreeStraightLayout((StraightCollageLayout) appblishLayout, true);
    }
}
