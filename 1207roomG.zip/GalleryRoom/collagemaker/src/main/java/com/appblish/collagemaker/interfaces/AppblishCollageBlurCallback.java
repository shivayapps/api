package com.appblish.collagemaker.interfaces;

import android.graphics.Bitmap;

public interface AppblishCollageBlurCallback {
    void onBlurSuccess(Bitmap blurredBitmap);
    void onBlurFailed(Exception e);
}
