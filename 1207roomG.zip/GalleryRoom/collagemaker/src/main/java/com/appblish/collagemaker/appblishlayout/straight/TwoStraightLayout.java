package com.appblish.collagemaker.appblishlayout.straight;


import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLine;

public class TwoStraightLayout extends NumberStraightLayout {
    private float mRadio = 0.5f;

    public TwoStraightLayout(StraightCollageLayout straightPuzzleLayout, boolean z) {
        super(straightPuzzleLayout, z);
    }

    public TwoStraightLayout(int i) {
        super(i);
    }

    public int getThemeCount() {
        return 6;
    }

    public void layout() {
        switch (this.theme) {
            case 0:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, this.mRadio);
                return;
            case 1:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, this.mRadio);
                return;
            case 2:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.33333334f);
                return;
            case 3:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.6666667f);
                return;
            case 4:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.33333334f);
                return;
            case 5:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.6666667f);
                return;
            default:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, this.mRadio);
                return;
        }
    }

    public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
        return new TwoStraightLayout((StraightCollageLayout) appblishLayout, true);
    }
}
