package com.appblish.collagemaker.appblishevent;

import android.view.MotionEvent;

import com.appblish.collagemaker.appblish.AppblishCollageStickerView;


public abstract class AbstractFlipEvent implements StickerIconEvent {
    protected abstract int getFlipDirection();

    public void onActionDown(AppblishCollageStickerView paramStickerView, MotionEvent paramMotionEvent) {
    }

    public void onActionMove(AppblishCollageStickerView paramStickerView, MotionEvent paramMotionEvent) {
    }

    public void onActionUp(AppblishCollageStickerView paramStickerView, MotionEvent paramMotionEvent) {
        paramStickerView.flipCurrentSticker(getFlipDirection());
    }
}
