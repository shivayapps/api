package com.appblish.collagemaker.photofilters.imageprocessors.subfilters

import android.graphics.Bitmap
import com.appblish.collagemaker.photofilters.imageprocessors.ImageProcessor
import com.appblish.collagemaker.photofilters.imageprocessors.SubFilter

class AppblishCollageBrightnessSubFilter(brightness: Int) : SubFilter {
    private var brightness: Int = 0

    init {
        this.brightness = brightness
    }

    override fun process(inputImage: Bitmap?): Bitmap {
        return ImageProcessor.doBrightness(brightness, inputImage)
    }

    override var tag: Any
        get() = Companion.tag
        set(tag) {
            Companion.tag = tag as String
        }

    fun changeBrightness(value: Int) {
        this.brightness += value
    }

    companion object {
        private var tag = ""
    }
}
