package com.appblish.collagemaker.interfaces;

import androidx.annotation.NonNull;

import com.appblish.collagemaker.sticker.Sticker;

public interface AppblishCollageOnStickerOperationListener {
        void onAddSticker(@NonNull Sticker sticker);

        void onStickerSelected(@NonNull Sticker sticker);

        void onStickerDeleted(@NonNull Sticker sticker);

        void onStickerDoubleTap(@NonNull Sticker sticker);

        void onStickerDrag(@NonNull Sticker sticker);

        void onStickerFlip(@NonNull Sticker sticker);

        void onStickerTouchOutside();

        void onStickerTouchedDown(@NonNull Sticker sticker);

        void onStickerZoom(@NonNull Sticker sticker);

        void onTouchDownBeauty(float f, float f2);

        void onTouchDragBeauty(float f, float f2);

        void onTouchUpBeauty(float f, float f2);
    }