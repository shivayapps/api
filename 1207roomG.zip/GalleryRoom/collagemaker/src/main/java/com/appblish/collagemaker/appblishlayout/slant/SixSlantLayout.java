package com.appblish.collagemaker.appblishlayout.slant;


import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLine;

public class SixSlantLayout extends NumberSlantLayout {
    public SixSlantLayout(SlantCollageLayout slantPuzzleLayout, boolean z) {
        super(slantPuzzleLayout, z);
    }

    public SixSlantLayout(int i) {
        super(i);
    }

    public int getThemeCount() {
        return 2;
    }

    public void layout() {
        switch (this.theme) {
            case 0:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.33333334f);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.7f, 0.7f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.5f, 0.5f);
                addLine(2, AppblishCollageLine.Direction.HORIZONTAL, 0.3f, 0.3f);
                return;
            case 1:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.33333334f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.3f, 0.3f);
                addLine(2, AppblishCollageLine.Direction.VERTICAL, 0.5f, 0.5f);
                addLine(4, AppblishCollageLine.Direction.VERTICAL, 0.7f, 0.7f);
                return;
            default:
                return;
        }
    }

    public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
        return new SixSlantLayout((SlantCollageLayout) appblishLayout, true);
    }
}
