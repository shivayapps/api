package com.appblish.collagemaker.photofilters.imageprocessors

import android.content.Context
import android.graphics.Bitmap
import com.appblish.collagemaker.R
import com.appblish.collagemaker.photofilters.AppblishCollageFilterItem
import com.appblish.collagemaker.photofilters.AppblishCollageFilterPack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class FilterThumbnailsManager {
    private var filterThumbnails = ArrayList<AppblishCollageFilterItem>(10)
    private var processedThumbnails = ArrayList<AppblishCollageFilterItem>(10)

    fun addThumb(filterItem: AppblishCollageFilterItem) {
        filterThumbnails.add(filterItem)
    }


    fun processThumbs(context: Context): List<AppblishCollageFilterItem> {
        for (thumb in filterThumbnails) {
            // scaling down the image
            val size = context.resources.getDimension(R.dimen.collage_bottom_filters_thumbnail_size)
            thumb.bitmap = Bitmap.createScaledBitmap(
                thumb.bitmap, size.toInt(), size.toInt(), false
            )
            thumb.bitmap = thumb.filter.processFilter(thumb.bitmap)!!
            //cropping circle
//            thumb.bitmap = GeneralUtils.generateCircularBitmap(thumb.bitmap)
            processedThumbnails.add(thumb)
        }

        return processedThumbnails
    }

    fun clearThumbs() {
        filterThumbnails = ArrayList()
        processedThumbnails = ArrayList()
    }



    fun loadFilters(
        context: Context,
        sourceBitmap: Bitmap,
        callback: (List<AppblishCollageFilterItem>) -> Unit
    ) {
        CoroutineScope(Dispatchers.Default).launch {

            val result = mutableListOf<AppblishCollageFilterItem>()
            val size = context.resources
                .getDimension(R.dimen.collage_bottom_filters_thumbnail_size)
                .toInt()

            try {
                // NONE filter
                val noneBitmap = Bitmap.createScaledBitmap(
                    sourceBitmap, size, size, false
                )
                result.add(
                    AppblishCollageFilterItem(
                        noneBitmap,
                        AppblishCollageFilter(context.getString(R.string.collage_None))
                    )
                )

                // Other filters
                val filters = AppblishCollageFilterPack.getFilterPack(context)
                for (filter in filters) {
                    val bmp = Bitmap.createScaledBitmap(
                        sourceBitmap, size, size, false
                    )
                    val filtered = filter.processFilter(bmp)
                    result.add(AppblishCollageFilterItem(filtered!!, filter))
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }

            withContext(Dispatchers.Main) {
                callback(result)
            }
        }
    }

}
