package com.appblish.collagemaker.appblishlayout.straight;


import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLine;

public class SixStraightLayout extends NumberStraightLayout {
    public SixStraightLayout(StraightCollageLayout straightPuzzleLayout, boolean z) {
        super(straightPuzzleLayout, z);
    }

    public SixStraightLayout(int i) {
        super(i);
    }

    public int getThemeCount() {
        return 12;
    }

    public void layout() {
        switch (this.theme) {
            case 0:
                cutAreaEqualPart(0, 2, 1);
                return;
            case 1:
                cutAreaEqualPart(0, 1, 2);
                return;
            case 2:
                addCross(0, 0.6666667f, 0.5f);
                addLine(3, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(2, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                return;
            case 3:
                addCross(0, 0.5f, 0.6666667f);
                addLine(3, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 4:
                addCross(0, 0.5f, 0.33333334f);
                addLine(2, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 5:
                addCross(0, 0.33333334f, 0.5f);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                return;
            case 6:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.8f);
                cutAreaEqualPart(1, 5, AppblishCollageLine.Direction.VERTICAL);
                return;
            case 7:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.25f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.6666667f);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.25f);
                addLine(2, AppblishCollageLine.Direction.VERTICAL, 0.6666667f);
                addLine(4, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                return;
            case 8:
                addCross(0, 0.33333334f);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(4, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 9:
                addCross(0, 0.6666667f, 0.33333334f);
                addLine(3, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 10:
                addCross(0, 0.6666667f);
                addLine(2, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 11:
                addCross(0, 0.33333334f, 0.6666667f);
                addLine(3, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                return;
            case 12:
                addCross(0, 0.33333334f);
                addLine(2, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                return;
            default:
                addCross(0, 0.6666667f, 0.5f);
                addLine(3, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(2, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                return;
        }
    }

    public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
        return new SixStraightLayout((StraightCollageLayout) appblishLayout, true);
    }
}
