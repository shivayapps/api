package com.appblish.collagemaker.appblish;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.appblish.collagemaker.interfaces.AppblishSelectedListener;
import com.appblish.collagemaker.interfaces.AppblishUnSelectedListener;
import com.appblish.collagemaker.R;
import com.appblish.collagemaker.appblish.grid.AppblishCollageArea;
import com.appblish.collagemaker.appblish.grid.AppblishCollageGrid;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLayoutParser;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLine;
import com.appblish.collagemaker.interfaces.OnPhotoLoadResultListener;
import com.appblish.collagemaker.utils.AppblishCollageAspectRatio;
import com.appblish.collagemaker.utils.AppblishCollageMatrixUtils;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;


class AppblishCollageGridView extends AppblishCollageStickerView {
    private static final String TAG = "AppblishGridView";
    public boolean canSwap;
    public ActionMode actionMode;
    public AppblishCollageGrid appblishGrid;
    public AppblishSelectedListener appblishSelectedListener;
    public AppblishCollageGrid prevHandlingappblishGrid;
    public List<AppblishCollageGrid> appblishGrids;
    private Map<AppblishCollageArea, AppblishCollageGrid> appblishAreaGridMap;
    private AppblishCollageAspectRatio aspectRatio;
    private int backgroundResource;
    private RectF rectF;
    private boolean canDrag;
    private boolean canMoveLine;
    private boolean canZoom;
    private float downX;
    private float downY;
    private int duration;
    private int handleBarColor;
    private Paint handleBarPaint;
    private AppblishCollageLine appblishLine;
    private AppblishCollageLayout.Info info;
    private int lineColor;
    private Paint linePaint;
    private int lineSize;
    private PointF midPoint;
    private List<AppblishCollageGrid> appblishGridList;
    private boolean needDrawLine;
    private boolean needDrawOuterLine;
    private boolean appblishMatrix;
    private AppblishUnSelectedListener onAppblishUnSelectedListener;
    private float collagePadding;
    private float collageRadian;
    private float previousDistance;
    private AppblishCollageLayout appblishLayout;
    private boolean quickMode;
    private AppblishCollageGrid replaceAppblishGrid;
    private Paint selectedAreaPaint;
    private int selectedLineColor;
    private Runnable switchToSwapAction;
    private boolean touchEnable;

    public AppblishCollageGridView(Context context) {
        this(context, null);
    }

    public AppblishCollageGridView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public AppblishCollageGridView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.actionMode = ActionMode.NONE;
        this.appblishGrids = new ArrayList();
        this.appblishGridList = new ArrayList();
        this.appblishAreaGridMap = new HashMap();
        this.touchEnable = true;
        this.appblishMatrix = true;
        this.quickMode = false;
        this.canDrag = true;
        this.canMoveLine = true;
        this.canZoom = true;
        this.canSwap = true;
        this.switchToSwapAction = new Runnable() {
            public void run() {
                if (AppblishCollageGridView.this.canSwap) {
                    AppblishCollageGridView.this.actionMode = ActionMode.SWAP;
                    AppblishCollageGridView.this.invalidate();
                }
            }
        };
        init(context, attributeSet);
    }

    @SuppressLint("ResourceType")
    private void init(Context context, AttributeSet attributeSet) {
        int[] PuzzleView = {R.attr.collage_animation_duration, R.attr.collage_handle_bar_color, R.attr.collage_line_color, R.attr.collage_line_size, R.attr.collage_need_draw_line, R.attr.collage_need_draw_outer_line, R.attr.collage_piece_padding, R.attr.collage_radian, R.attr.collage_selected_line_color};
        TypedArray styledAttributes = context.obtainStyledAttributes(attributeSet, PuzzleView);
        this.lineSize = styledAttributes.getInt(3, 4);
        this.lineColor = styledAttributes.getColor(2, -1);
        this.selectedLineColor = styledAttributes.getColor(8, Color.parseColor("#99BBFB"));
        this.handleBarColor = styledAttributes.getColor(1, Color.parseColor("#99BBFB"));
        this.collagePadding = (float) styledAttributes.getDimensionPixelSize(6, 0);
        this.needDrawLine = styledAttributes.getBoolean(4, true);
        this.needDrawOuterLine = styledAttributes.getBoolean(5, true);
        this.duration = styledAttributes.getInt(0, 300);
        this.collageRadian = styledAttributes.getFloat(7, 0.0f);
        styledAttributes.recycle();
        this.rectF = new RectF();
        this.linePaint = new Paint();
        this.linePaint.setAntiAlias(true);
        this.linePaint.setColor(this.lineColor);
        this.linePaint.setStrokeWidth((float) this.lineSize);
        this.linePaint.setStyle(Paint.Style.STROKE);
        this.linePaint.setStrokeJoin(Paint.Join.ROUND);
        this.linePaint.setStrokeCap(Paint.Cap.SQUARE);
        this.selectedAreaPaint = new Paint();
        this.selectedAreaPaint.setAntiAlias(true);
        this.selectedAreaPaint.setStyle(Paint.Style.STROKE);
        this.selectedAreaPaint.setStrokeJoin(Paint.Join.ROUND);
        this.selectedAreaPaint.setStrokeCap(Paint.Cap.ROUND);
        this.selectedAreaPaint.setColor(this.selectedLineColor);
        this.selectedAreaPaint.setStrokeWidth((float) this.lineSize);
        this.handleBarPaint = new Paint();
        this.handleBarPaint.setAntiAlias(true);
        this.handleBarPaint.setStyle(Paint.Style.FILL);
        this.handleBarPaint.setColor(this.handleBarColor);
        this.handleBarPaint.setStrokeWidth((float) (this.lineSize * 3));
        this.midPoint = new PointF();

        initDeviceWidth();
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        resetCollageBounds();
        this.appblishAreaGridMap.clear();
        if (!this.appblishGrids.isEmpty()) {
            for (int i5 = 0; i5 < this.appblishGrids.size(); i5++) {
                AppblishCollageGrid puzzlePiece = this.appblishGrids.get(i5);
                AppblishCollageArea area = this.appblishLayout.getArea(i5);
                puzzlePiece.setArea(area);
                this.appblishAreaGridMap.put(area, puzzlePiece);
                if (this.appblishMatrix) {
                    puzzlePiece.set(AppblishCollageMatrixUtils.generateMatrix(puzzlePiece, 0.0f));
                } else {
                    puzzlePiece.fillArea(this, true);
                }
            }
        }
        invalidate();
    }

    public AppblishCollageAspectRatio getAspectRatio() {
        return this.aspectRatio;
    }

    public void setAspectRatio(AppblishCollageAspectRatio aspectRatio2) {
        this.aspectRatio = aspectRatio2;
    }

    private void resetCollageBounds() {
        this.rectF.left = (float) getPaddingLeft();
        this.rectF.top = (float) getPaddingTop();
        this.rectF.right = (float) (getWidth() - getPaddingRight());
        this.rectF.bottom = (float) (getHeight() - getPaddingBottom());
        if (this.appblishLayout != null) {
            this.appblishLayout.reset();
            this.appblishLayout.setOuterBounds(this.rectF);
            this.appblishLayout.layout();
            this.appblishLayout.setPadding(this.collagePadding);
            this.appblishLayout.setRadian(this.collageRadian);
            if (this.info != null) {
                int size = this.info.lineInfos.size();
                for (int i = 0; i < size; i++) {
                    AppblishCollageLayout.LineInfo lineInfo = this.info.lineInfos.get(i);
                    AppblishCollageLine line = this.appblishLayout.getLines().get(i);
                    line.startPoint().x = lineInfo.startX;
                    line.startPoint().y = lineInfo.startY;
                    line.endPoint().x = lineInfo.endX;
                    line.endPoint().y = lineInfo.endY;
                }
            }
            this.appblishLayout.sortAreas();
            this.appblishLayout.update();
        }
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.appblishLayout != null) {
            this.linePaint.setStrokeWidth((float) this.lineSize);
            this.selectedAreaPaint.setStrokeWidth((float) this.lineSize);
            this.handleBarPaint.setStrokeWidth((float) (this.lineSize * 3));
            int i = 0;
            while (i < this.appblishLayout.getAreaCount() && i < this.appblishGrids.size()) {
                AppblishCollageGrid puzzlePiece = this.appblishGrids.get(i);
                if (!(puzzlePiece == this.appblishGrid && this.actionMode == ActionMode.SWAP) && this.appblishGrids.size() > i) {
                    puzzlePiece.draw(canvas, this.quickMode);
                }
                i++;
            }
            if (this.needDrawOuterLine) {
                for (AppblishCollageLine drawLine : this.appblishLayout.getOuterLines()) {
                    drawLine(canvas, drawLine);
                }
            }
            if (this.needDrawLine) {
                for (AppblishCollageLine drawLine2 : this.appblishLayout.getLines()) {
                    drawLine(canvas, drawLine2);
                }
            }
            if (!(this.appblishGrid == null || this.actionMode == ActionMode.SWAP)) {
                drawSelectedArea(canvas, this.appblishGrid);
            }
            if (this.appblishGrid != null && this.actionMode == ActionMode.SWAP) {
                this.appblishGrid.draw(canvas, 128, this.quickMode);
                if (this.replaceAppblishGrid != null) {
                    drawSelectedArea(canvas, this.replaceAppblishGrid);
                }
            }
        }
    }

    private void drawSelectedArea(Canvas canvas, AppblishCollageGrid appblishCollage) {
        AppblishCollageArea appblishCollageArea = appblishCollage.getArea();
        canvas.drawPath(appblishCollageArea.getAreaPath(), this.selectedAreaPaint);
        for (AppblishCollageLine next : appblishCollageArea.getLines()) {
            if (this.appblishLayout.getLines().contains(next)) {
                PointF[] handleBarPoints = appblishCollageArea.getHandleBarPoints(next);
                canvas.drawLine(handleBarPoints[0].x, handleBarPoints[0].y, handleBarPoints[1].x, handleBarPoints[1].y, this.handleBarPaint);
                canvas.drawCircle(handleBarPoints[0].x, handleBarPoints[0].y, (float) ((this.lineSize * 3) / 2), this.handleBarPaint);
                canvas.drawCircle(handleBarPoints[1].x, handleBarPoints[1].y, (float) ((this.lineSize * 3) / 2), this.handleBarPaint);
            }
        }
    }

    private void drawLine(Canvas canvas, AppblishCollageLine line) {
        canvas.drawLine(line.startPoint().x, line.startPoint().y, line.endPoint().x, line.endPoint().y, this.linePaint);
    }

    public void updateLayout(AppblishCollageLayout appblishLayout) {
        ArrayList<AppblishCollageGrid> arrayList = new ArrayList<>(this.appblishGrids);
        setAppblishLayout(appblishLayout);
        for (AppblishCollageGrid drawable : arrayList) {
            addAppblishCollage(drawable.getDrawable());
        }
        invalidate();
    }

    public void setCollageLayout(AppblishCollageLayout.Info info) {
        this.info = info;
        clearAppblish();
        this.appblishLayout = AppblishCollageLayoutParser.parse(info);
        this.collagePadding = info.padding;
        this.collageRadian = info.radian;
        setBackgroundColor(info.color);
        invalidate();
    }

    public AppblishCollageLayout getAppblishLayout() {
        return this.appblishLayout;
    }

    public void setAppblishLayout(AppblishCollageLayout appblishLayout) {
        clearAppblish();
        this.appblishLayout = appblishLayout;
        appblishLayout.setOuterBounds(this.rectF);
        appblishLayout.layout();
        invalidate();
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!this.touchEnable) {
            return super.onTouchEvent(motionEvent);
        }
        int action = motionEvent.getAction() & 255;
        if (action != 5) {
            switch (action) {
                case 0:
                    this.downX = motionEvent.getX();
                    this.downY = motionEvent.getY();
                    decideActionMode(motionEvent);
                    prepareAction(motionEvent);
                    break;
                case 1:
                case 3:
                    finishAction(motionEvent);
                    this.actionMode = ActionMode.NONE;
                    removeCallbacks(this.switchToSwapAction);
                    break;
                case 2:
                    performAction(motionEvent);
                    if ((Math.abs(motionEvent.getX() - this.downX) > 10.0f || Math.abs(motionEvent.getY() - this.downY) > 10.0f) && this.actionMode != ActionMode.SWAP) {
                        removeCallbacks(this.switchToSwapAction);
                        break;
                    }
            }
        } else {
            this.previousDistance = calculateDistance(motionEvent);
            calculateMidPoint(motionEvent, this.midPoint);
            decideActionMode(motionEvent);
        }
        invalidate();
        return true;
    }

    private void decideActionMode(MotionEvent motionEvent) {
        for (AppblishCollageGrid isAnimateRunning : this.appblishGrids) {
            if (isAnimateRunning.isAnimateRunning()) {
                this.actionMode = ActionMode.NONE;
                return;
            }
        }
        if (motionEvent.getPointerCount() == 1) {
            this.appblishLine = findHandlingLine();
            if (this.appblishLine == null || !this.canMoveLine) {
                this.appblishGrid = findHandlingAppblish();
                if (this.appblishGrid != null && this.canDrag) {
                    this.actionMode = ActionMode.DRAG;
                    postDelayed(this.switchToSwapAction, 500);
                    return;
                }
                return;
            }
            this.actionMode = ActionMode.MOVE;
        } else if (motionEvent.getPointerCount() > 1 && this.appblishGrid != null && this.appblishGrid.contains(motionEvent.getX(1), motionEvent.getY(1)) && this.actionMode == ActionMode.DRAG && this.canZoom) {
            this.actionMode = ActionMode.ZOOM;
        }
    }

    private void prepareAction(MotionEvent motionEvent) {
        switch (this.actionMode) {
            case DRAG:
            case ZOOM:
                this.appblishGrid.record();
                return;
            case MOVE:
                this.appblishLine.prepareMove();
                this.appblishGridList.clear();
                this.appblishGridList.addAll(findNeedChangedPieces());
                for (AppblishCollageGrid next : this.appblishGridList) {
                    next.record();
                    next.setPreviousMoveX(this.downX);
                    next.setPreviousMoveY(this.downY);
                }
                return;
            default:
                return;
        }
    }

    void checklistClear() {
//        Log.i("checklistClear", "checklistClear: ");
//        this.appblishLine = null;
//        this.appblishGridList.clear();

    }

    private void performAction(MotionEvent motionEvent) {
        switch (this.actionMode) {
            case DRAG:
                dragPiece(this.appblishGrid, motionEvent);
                return;
            case ZOOM:
                zoomappblish(this.appblishGrid, motionEvent);
                return;
            case MOVE:
                moveLine(this.appblishLine, motionEvent);
                return;
            case SWAP:
                dragPiece(this.appblishGrid, motionEvent);
                this.replaceAppblishGrid = findReplacePiece(motionEvent);
                return;
            default:
                return;
        }
    }

    private void finishAction(MotionEvent motionEvent) {
        switch (this.actionMode) {
            case DRAG:
                if (this.appblishGrid != null && !this.appblishGrid.isFilledArea()) {
                    this.appblishGrid.moveToFillArea(this);
                }
                if (this.prevHandlingappblishGrid == this.appblishGrid && Math.abs(this.downX - motionEvent.getX()) < 3.0f && Math.abs(this.downY - motionEvent.getY()) < 3.0f) {
                    this.appblishGrid = null;
                }
                this.prevHandlingappblishGrid = this.appblishGrid;
                break;
            case ZOOM:
                if (this.appblishGrid != null && !this.appblishGrid.isFilledArea()) {
                    if (this.appblishGrid.canFilledArea()) {
                        this.appblishGrid.moveToFillArea(this);
                    } else {
                        this.appblishGrid.fillArea(this, false);
                    }
                }
                this.prevHandlingappblishGrid = this.appblishGrid;
                break;
            case SWAP:
                if (!(this.appblishGrid == null || this.replaceAppblishGrid == null)) {
                    swapPiece();
                    this.appblishGrid = null;
                    this.replaceAppblishGrid = null;
                    this.prevHandlingappblishGrid = null;
                    break;
                }
        }
        Log.i("finishAction", "finishAction: ");
        if (this.appblishGrid != null && this.appblishSelectedListener != null) {
            this.appblishSelectedListener.onAppblishSelected(this.appblishGrid, this.appblishGrids.indexOf(this.appblishGrid));
        } else if (this.appblishGrid == null && this.onAppblishUnSelectedListener != null) {
            this.onAppblishUnSelectedListener.onAppblishUnSelected();
        }
        this.appblishLine = null;
        this.appblishGridList.clear();
    }

    public void setPrevHandlingappblishGrid(AppblishCollageGrid puzzlePiece) {
        this.prevHandlingappblishGrid = puzzlePiece;
    }

    private void swapPiece() {
        Drawable drawable = this.appblishGrid.getDrawable();
        String path = this.appblishGrid.getPath();
        this.appblishGrid.setDrawable(this.replaceAppblishGrid.getDrawable());
        this.appblishGrid.setPath(this.replaceAppblishGrid.getPath());
        this.replaceAppblishGrid.setDrawable(drawable);
        this.replaceAppblishGrid.setPath(path);
        this.appblishGrid.fillArea(this, true);
        this.replaceAppblishGrid.fillArea(this, true);
    }

    private void moveLine(AppblishCollageLine line, MotionEvent motionEvent) {
        boolean z;
        if (line != null && motionEvent != null) {
            if (line.direction() == AppblishCollageLine.Direction.HORIZONTAL) {
                z = line.move(motionEvent.getY() - this.downY, 80.0f);
            } else {
                z = line.move(motionEvent.getX() - this.downX, 80.0f);
            }
            if (z) {
                this.appblishLayout.update();
                this.appblishLayout.sortAreas();
                updatePiecesInArea(line, motionEvent);
            }
        }
    }

    private void updatePiecesInArea(AppblishCollageLine line, MotionEvent motionEvent) {
        for (int i = 0; i < this.appblishGridList.size(); i++) {
            this.appblishGridList.get(i).updateWith(motionEvent, line);
        }
    }

    private void zoomappblish(AppblishCollageGrid puzzlePiece, MotionEvent motionEvent) {
        if (puzzlePiece != null && motionEvent != null && motionEvent.getPointerCount() >= 2) {
            float calculateDistance = calculateDistance(motionEvent) / this.previousDistance;
            puzzlePiece.zoomAndTranslate(calculateDistance, calculateDistance, this.midPoint, motionEvent.getX() - this.downX, motionEvent.getY() - this.downY);
        }
    }

    private void dragPiece(AppblishCollageGrid puzzlePiece, MotionEvent motionEvent) {
        if (puzzlePiece != null && motionEvent != null) {
            puzzlePiece.translate(motionEvent.getX() - this.downX, motionEvent.getY() - this.downY);
        }
    }

    public void replace(Bitmap bitmap, String str) {
        BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap);
        bitmapDrawable.setAntiAlias(true);
        bitmapDrawable.setFilterBitmap(true);
        replace(bitmapDrawable, str);
    }

    public void replace(Drawable drawable, String str) {
        if (this.appblishGrid != null) {
            this.appblishGrid.setPath(str);
            this.appblishGrid.setDrawable(drawable);
            this.appblishGrid.set(AppblishCollageMatrixUtils.generateMatrix(this.appblishGrid, 0.0f));
            invalidate();
        }
    }

    public void flipVertically() {
        if (this.appblishGrid != null) {
            this.appblishGrid.postFlipVertically();
            this.appblishGrid.record();
            invalidate();
        }
    }

    public void flipHorizontally() {
        if (this.appblishGrid != null) {
            this.appblishGrid.postFlipHorizontally();
            this.appblishGrid.record();
            invalidate();
        }
    }

    public void rotate(float f) {
        if (this.appblishGrid != null) {
            this.appblishGrid.postRotate(f);
            this.appblishGrid.record();
            invalidate();
        }
    }

    private AppblishCollageGrid findHandlingAppblish() {
        for (AppblishCollageGrid next : this.appblishGrids) {
            if (next.contains(this.downX, this.downY)) {
                return next;
            }
        }
        return null;
    }

    private AppblishCollageLine findHandlingLine() {
        for (AppblishCollageLine next : this.appblishLayout.getLines()) {
            if (next.contains(this.downX, this.downY, 40.0f)) {
                return next;
            }
        }
        return null;
    }

    private AppblishCollageGrid findReplacePiece(MotionEvent motionEvent) {
        for (AppblishCollageGrid next : this.appblishGrids) {
            if (next.contains(motionEvent.getX(), motionEvent.getY())) {
                return next;
            }
        }
        return null;
    }

    private List<AppblishCollageGrid> findNeedChangedPieces() {
        if (this.appblishLine == null) {
            return new ArrayList();
        }
        ArrayList arrayList = new ArrayList();
        for (AppblishCollageGrid next : this.appblishGrids) {
            if (next.contains(this.appblishLine)) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    public float calculateDistance(MotionEvent motionEvent) {
        float x = motionEvent.getX(0) - motionEvent.getX(1);
        float y = motionEvent.getY(0) - motionEvent.getY(1);
        return (float) Math.sqrt((double) ((x * x) + (y * y)));
    }

    private void calculateMidPoint(MotionEvent motionEvent, PointF pointF) {
        pointF.x = (motionEvent.getX(0) + motionEvent.getX(1)) / 2.0f;
        pointF.y = (motionEvent.getY(0) + motionEvent.getY(1)) / 2.0f;
    }

    public void reset() {
        clearAppblish();
        if (this.appblishLayout != null) {
            this.appblishLayout.reset();
        }
    }

    public void clearAppblish() {
        clearHandlingPieces();
        this.appblishGrids.clear();
        invalidate();
    }

    public void clearHandlingPieces() {
        this.appblishLine = null;
        this.appblishGrid = null;
        this.replaceAppblishGrid = null;
        this.appblishGridList.clear();
        invalidate();
    }

    public void addPieces(List<Bitmap> list) {
        for (Bitmap addPiece : list) {
            addAppblishCollage(addPiece);
        }
        postInvalidate();
    }

    public void addAppblishCollage(Bitmap bitmap) {
        BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap);
        bitmapDrawable.setAntiAlias(true);
        bitmapDrawable.setFilterBitmap(true);
        addAppblishCollage(bitmapDrawable, (Matrix) null);
    }

    public void addAppblishCollage(Drawable drawable) {
        addAppblishCollage(drawable, (Matrix) null);
    }

    public void addAppblishCollage(Drawable drawable, Matrix matrix) {
        addAppblishCollage(drawable, matrix, "");
    }

    public void addAppblishCollage(Drawable drawable, Matrix matrix, String str) {
        Matrix matrix2;
        int size = this.appblishGrids.size();
        if (size >= this.appblishLayout.getAreaCount()) {
            Log.e(TAG, "addAppblishCollage: can not add more. the current collage layout can contains " + this.appblishLayout.getAreaCount() + " puzzle piece.");
            return;
        }
        AppblishCollageArea area = this.appblishLayout.getArea(size);
        area.setPadding(this.collagePadding);
        AppblishCollageGrid puzzlePiece = new AppblishCollageGrid(drawable, area, new Matrix());
        if (matrix != null) {
            matrix2 = new Matrix(matrix);
        } else {
            matrix2 = AppblishCollageMatrixUtils.generateMatrix(area, drawable, 0.0f);
        }
        puzzlePiece.set(matrix2);
        puzzlePiece.setAnimateDuration(this.duration);
        puzzlePiece.setPath(str);
        this.appblishGrids.add(puzzlePiece);
        this.appblishAreaGridMap.put(area, puzzlePiece);
        setCollagePadding(this.collagePadding);
        setCollageRadian(this.collageRadian);
        invalidate();
    }

    public AppblishCollageGrid getAppblishGrid() {
        return this.appblishGrid;
    }

    public void setAppblishGrid(AppblishCollageGrid puzzlePiece) {
        this.appblishGrid = puzzlePiece;
    }

    public void setAnimateDuration(int i) {
        this.duration = i;
        for (AppblishCollageGrid animateDuration : this.appblishGrids) {
            animateDuration.setAnimateDuration(i);
        }
    }

    public void setNeedDrawLine(boolean z) {
        this.needDrawLine = z;
        this.appblishGrid = null;
        this.prevHandlingappblishGrid = null;
        invalidate();
    }

    public void setNeedDrawOuterLine(boolean z) {
        this.needDrawOuterLine = z;
        invalidate();
    }

    public void setLineColor(int i) {
        this.lineColor = i;
        this.linePaint.setColor(i);
        invalidate();
    }

    public void setLineSize(int i) {
        this.lineSize = i;
        invalidate();
    }

    public void setSelectedLineColor(int i) {
        this.selectedLineColor = i;
        this.selectedAreaPaint.setColor(i);
        invalidate();
    }

    public void setHandleBarColor(int i) {
        this.handleBarColor = i;
        this.handleBarPaint.setColor(i);
        invalidate();
    }

    public void setTouchEnable(boolean z) {
        this.touchEnable = z;
    }

    public void clearHandling() {
        this.appblishGrid = null;
        this.appblishLine = null;
        this.replaceAppblishGrid = null;
        this.prevHandlingappblishGrid = null;
        this.appblishGridList.clear();
    }

    public int getBackgroundResourceMode() {
        return this.backgroundResource;
    }

    public void setBackgroundResourceMode(int i) {
        this.backgroundResource = i;
    }

    public void setBackgroundColor(int i) {
        super.setBackgroundColor(i);
        if (this.appblishLayout != null) {
            this.appblishLayout.setColor(i);
        }
    }

    public float getCollagePadding() {
        return this.collagePadding;
    }

    public void setCollagePadding(float f) {
        this.collagePadding = f;
        if (this.appblishLayout != null) {
            this.appblishLayout.setPadding(f);
            int size = this.appblishGrids.size();
            for (int i = 0; i < size; i++) {
                AppblishCollageGrid appblishCollage = this.appblishGrids.get(i);
                if (appblishCollage.canFilledArea()) {
                    appblishCollage.moveToFillArea((View) null);
                } else {
                    appblishCollage.fillArea(this, true);
                }
            }
        }
        invalidate();
    }

    public float getCollageRadian() {
        return this.collageRadian;
    }

    public void setCollageRadian(float f) {
        this.collageRadian = f;
        if (this.appblishLayout != null) {
            this.appblishLayout.setRadian(f);
        }
        invalidate();
    }

    public List<AppblishCollageGrid> getAppblishGrids() {
        int size = this.appblishGrids.size();
        ArrayList arrayList = new ArrayList(size);
        this.appblishLayout.sortAreas();
        for (int i = 0; i < size; i++) {
            arrayList.add(this.appblishAreaGridMap.get(this.appblishLayout.getArea(i)));
        }
        return arrayList;
    }

    public void setOnAppblishSelectedListener(AppblishSelectedListener appblishSelectedListener) {
        this.appblishSelectedListener = appblishSelectedListener;
    }

    public void setonAppblishUnSelectedListener(AppblishUnSelectedListener onAppblishUnSelectedListener) {
        this.onAppblishUnSelectedListener = onAppblishUnSelectedListener;
    }

    private enum ActionMode {
        NONE, DRAG, ZOOM, MOVE, SWAP
    }


    public void loadPhoto(
            final List<String> itemList,
            final AppblishCollageLayout layout,
            final OnPhotoLoadResultListener listener
    ) {
        if (itemList == null || itemList.isEmpty()) {
            if (listener != null) listener.onResult(false);
            return;
        }

        if (layout == null) {
            if (listener != null) listener.onResult(false);
            return;
        }

        final int count = Math.min(itemList.size(), layout.getAreaCount());
        final List<Bitmap> bitmapList =
                Collections.synchronizedList(new ArrayList<>());

        final AtomicInteger loadedCount = new AtomicInteger(0);
        final AtomicBoolean hasFailed = new AtomicBoolean(false);

        for (int i = 0; i < count; i++) {

            Glide.with(getContext())
                    .asBitmap()
                    .load("file:///" + itemList.get(i))
                    .override(deviceWidth, deviceWidth)
                    .centerInside()
                    .format(DecodeFormat.PREFER_RGB_565)
                    .into(new CustomTarget<Bitmap>() {

                        @Override
                        public void onResourceReady(
                                @NonNull Bitmap resource,
                                @Nullable Transition<? super Bitmap> transition
                        ) {

                            if (hasFailed.get()) return;

                            bitmapList.add(resource);

                            if (loadedCount.incrementAndGet() == count) {

                                // All loaded successfully
                                if (itemList.size() < layout.getAreaCount()) {
                                    for (int j = 0; j < layout.getAreaCount(); j++) {
                                        addAppblishCollage(bitmapList.get(j % count));
                                    }
                                } else {
                                    addPieces(bitmapList);
                                }

                                if (listener != null) {
                                    listener.onResult(true);
                                }
                            }
                        }

                        @Override
                        public void onLoadFailed(@Nullable Drawable errorDrawable) {
                            hasFailed.set(true);
                            if (listener != null) {
                                listener.onResult(false);
                            }
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {
                            // no-op
                        }
                    });
        }
    }





//    public void loadPhoto(
//            final List<String> itemList,
//            final AppblishCollageLayout layout
//    ) {
//        final ArrayList<Bitmap> bitmapList = new ArrayList<>();
//
//        if (itemList == null || itemList.isEmpty()) return;
//        if (layout == null) return;
//
//        final int count = itemList.size() > layout.getAreaCount()
//                ? layout.getAreaCount()
//                : itemList.size();
//
//        for (int i = 0; i < count; i++) {
//            final int index = i;
//
//            Glide.with(getContext())
//                    .asBitmap()
//                    .load("file:///" + itemList.get(index))
//                    .override(deviceWidth, deviceWidth)
//                    .centerInside()
//                    .format(DecodeFormat.PREFER_RGB_565)
//                    .into(new CustomTarget<Bitmap>() {
//
//                        @Override
//                        public void onResourceReady(
//                                @NonNull Bitmap resource,
//                                @Nullable Transition<? super Bitmap> transition
//                        ) {
//                            Bitmap scaledBitmap = resource;
//
//                            float width = resource.getWidth();
//                            float height = resource.getHeight();
//
//                            float max = Math.max(width / width, height / width);
//
//                            if (max > 1f) {
//                                scaledBitmap = Bitmap.createScaledBitmap(
//                                        resource,
//                                        (int) (width / max),
//                                        (int) (height / max),
//                                        false
//                                );
//                            }
//
//                            bitmapList.add(scaledBitmap);
//
//                            if (bitmapList.size() == count) {
//                                if (itemList.size() < layout.getAreaCount()) {
//                                    for (int j = 0; j < layout.getAreaCount(); j++) {
//                                        addAppblishCollage(
//                                                bitmapList.get(j % count)
//                                        );
//                                    }
//                                } else {
//                                    addPieces(bitmapList);
//                                }
//                            }
//                        }
//
//                        @Override
//                        public void onLoadCleared(@Nullable Drawable placeholder) {
//                            // no-op
//                        }
//                    });
//        }
//    }


    private int deviceWidth;

    private void initDeviceWidth() {
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        deviceWidth = metrics.widthPixels;
    }


    public void clearSelectedLine() {
        actionMode = ActionMode.NONE;

        appblishGrid = null;
        appblishLine = null;
        replaceAppblishGrid = null;
        prevHandlingappblishGrid = null;

        appblishGridList.clear();
        removeCallbacks(switchToSwapAction);

        invalidate();
    }
}
