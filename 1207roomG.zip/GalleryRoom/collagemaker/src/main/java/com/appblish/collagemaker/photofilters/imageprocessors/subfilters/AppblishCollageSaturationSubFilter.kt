package com.appblish.collagemaker.photofilters.imageprocessors.subfilters

import android.graphics.Bitmap
import com.appblish.collagemaker.photofilters.imageprocessors.ImageProcessor
import com.appblish.collagemaker.photofilters.imageprocessors.SubFilter

class AppblishCollageSaturationSubFilter(
    var saturation: Float
) : SubFilter {
    override fun process(inputImage: Bitmap?): Bitmap {
        return ImageProcessor.doSaturation(inputImage, saturation)
    }

    override var tag: Any
        get() = Companion.tag
        set(tag) {
            Companion.tag = tag as String
        }

    fun setLevel(level: Float) {
        this.saturation = level
    }

    companion object {
        private var tag = ""
    }
}
