package com.appblish.collagemaker.appblish.grid;

import android.graphics.RectF;

import com.appblish.collagemaker.appblishlayout.slant.SlantCollageLayout;
import com.appblish.collagemaker.appblishlayout.straight.StraightCollageLayout;


public class AppblishCollageLayoutParser {
    private AppblishCollageLayoutParser() {
    }

    public static AppblishCollageLayout parse(final AppblishCollageLayout.Info info) {
        AppblishCollageLayout appblishLayout;
        if (info.type == 0) {
            appblishLayout = new StraightCollageLayout() {
                public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
                    return null;
                }

                public void layout() {
                    int size = info.steps.size();
                    int i = 0;
                    for (int i2 = 0; i2 < size; i2++) {
                        Step step = info.steps.get(i2);
                        switch (step.type) {
                            case 0:
                                addLine(step.position, step.lineDirection(), info.lines.get(i).getStartRatio());
                                break;
                            case 1:
                                addCross(step.position, step.hRatio, step.vRatio);
                                break;
                            case 2:
                                cutAreaEqualPart(step.position, step.hSize, step.vSize);
                                break;
                            case 3:
                                cutAreaEqualPart(step.position, step.part, step.lineDirection());
                                break;
                            case 4:
                                cutSpiral(step.position);
                                break;
                        }
                        i += step.numOfLine;
                    }
                }
            };
        } else {
            appblishLayout = new SlantCollageLayout() {
                public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
                    return null;
                }

                public void layout() {
                    int size = info.steps.size();
                    for (int i = 0; i < size; i++) {
                        Step step = info.steps.get(i);
                        switch (step.type) {
                            case 0:
                                addLine(step.position, step.lineDirection(), info.lines.get(i).getStartRatio(), info.lines.get(i).getEndRatio());
                                break;
                            case 1:
                                addCross(step.position, 0.5f, 0.5f, 0.5f, 0.5f);
                                break;
                            case 2:
                                cutArea(step.position, step.hSize, step.vSize);
                                break;
                        }
                    }
                }
            };
        }
        appblishLayout.setOuterBounds(new RectF(info.left, info.top, info.right, info.bottom));
        appblishLayout.layout();
        appblishLayout.setColor(info.color);
        appblishLayout.setRadian(info.radian);
        appblishLayout.setPadding(info.padding);
        int size = info.lineInfos.size();
        for (int i = 0; i < size; i++) {
            AppblishCollageLayout.LineInfo lineInfo = info.lineInfos.get(i);
            AppblishCollageLine line = appblishLayout.getLines().get(i);
            line.startPoint().x = lineInfo.startX;
            line.startPoint().y = lineInfo.startY;
            line.endPoint().x = lineInfo.endX;
            line.endPoint().y = lineInfo.endY;
        }
        appblishLayout.sortAreas();
        appblishLayout.update();
        return appblishLayout;
    }
}
