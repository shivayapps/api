package com.appblish.collagemaker.appblish;

import android.content.Context;
import android.graphics.Typeface;

import com.appblish.collagemaker.sticker.Sticker;


public class AppblishCollageTextEditorView {

     AppblishCollageTextView textSticker;



    /* -------------------- CREATE -------------------- */
    public void createText(Context context, AppblishCollageText textModel) {
        textSticker = new AppblishCollageTextView(context, textModel);
    }


    public Sticker getSticker() {
        return textSticker; //
    }

//    public AppblishTextView getSticker() {
//        return textSticker;
//    }

    /* -------------------- TEXT -------------------- */

    public void setText(String text) {
        if (textSticker == null) return;
        textSticker.setText(text).resizeText();
    }

    public String getText() {
        return textSticker != null ? textSticker.getText() : null;
    }

    /* -------------------- STYLE -------------------- */

    public void setTextColor(int color) {
        if (textSticker == null) return;
        textSticker.setTextColor(color).resizeText();
    }



    public void setTextAlpha(int alpha) {
        if (textSticker == null) return;
        textSticker.setTextAlpha(alpha).resizeText();
    }

    public void setTextSize(int sizeSp) {
        if (textSticker == null) return;
        textSticker.setTextSize(sizeSp).resizeText();
    }

    public void setTypeface(Typeface typeface) {
        if (textSticker == null) return;
        textSticker.setTypeface(typeface).resizeText();
    }

    public void setTextAlign(int align) {
        if (textSticker == null) return;
        textSticker.setTextAlign(align).resizeText();
    }

    /* -------------------- BACKGROUND -------------------- */

    public void setShowBackground(boolean show) {
        if (textSticker == null) return;
        textSticker.setShowBackground(show);
    }

    public void setBackgroundColor(int color) {
        if (textSticker == null) return;
        textSticker.setBackgroundColor(color);
    }

    public void setBackgroundAlpha(int alpha) {
        if (textSticker == null) return;
        textSticker.setBackgroundAlpha(alpha);
    }

    public void setBackgroundBorder(int radiusPx) {
        if (textSticker == null) return;
        textSticker.setBackgroundBorder(radiusPx);
    }

    /* -------------------- SHADOW -------------------- */

    public void setTextShadow(AppblishCollageTextShadow shadow) {
        if (textSticker == null) return;
        textSticker.setTextShadow(shadow).resizeText();
    }


    /* -------------------- LIFECYCLE -------------------- */

    public void release() {
        if (textSticker != null) {
            textSticker.release();
            textSticker = null;
        }
    }
}
