package com.appblish.collagemaker.appblishevent;

import android.view.MotionEvent;

import com.appblish.collagemaker.appblish.AppblishCollageStickerView;


public interface StickerIconEvent {
    void onActionDown(AppblishCollageStickerView paramStickerView, MotionEvent paramMotionEvent);

    void onActionMove(AppblishCollageStickerView paramStickerView, MotionEvent paramMotionEvent);

    void onActionUp(AppblishCollageStickerView paramStickerView, MotionEvent paramMotionEvent);
}
