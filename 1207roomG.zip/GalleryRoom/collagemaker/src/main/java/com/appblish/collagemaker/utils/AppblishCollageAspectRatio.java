package com.appblish.collagemaker.utils;


import androidx.annotation.IntRange;


public class AppblishCollageAspectRatio {

    @SuppressWarnings("Range")
    public static final AppblishCollageAspectRatio IMG_SRC = new AppblishCollageAspectRatio(-1, -1);

    private final int width;
    private final int height;

    public AppblishCollageAspectRatio(@IntRange(from = 1) int w, @IntRange(from = 1) int h) {
        this.width = w;
        this.height = h;
    }

    public int getWidth() {
        return width;
    }

    public boolean isSquare() {
        return width == height;
    }

    public int getHeight() {
        return height;
    }

    public float getRatio() {
        return ((float) width) / height;
    }
}
