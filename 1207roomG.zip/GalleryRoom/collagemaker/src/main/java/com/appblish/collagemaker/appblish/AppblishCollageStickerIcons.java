package com.appblish.collagemaker.appblish;


import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;

import com.appblish.collagemaker.appblishevent.StickerIconEvent;
import com.appblish.collagemaker.sticker.DrawableSticker;

import java.util.List;


public class AppblishCollageStickerIcons extends DrawableSticker implements StickerIconEvent {
    public static final String ALIGN = "ALIGN";

    public static final String EDIT = "EDIT";

    public static final String FLIP = "FLIP";

    public static final String DELETE = "DELETE";

    public static final String ROTATE = "ROTATE";

    public static final String SCALE = "SCALE";

    private StickerIconEvent iconEvent;
    private List<AppblishCollageStickerIcons> icons;

    private float iconExtraRadius = 10.0F;

    private float iconRadius = 30.0F;

    private int position = 0;

    private String tag;

    private float x;

    private float y;

    public AppblishCollageStickerIcons(Drawable paramDrawable, int paramInt, String paramString) {
        super(paramDrawable);
        this.position = paramInt;
        this.tag = paramString;
    }

    public void draw(Canvas paramCanvas, Paint paramPaint) {
        paramCanvas.drawCircle(this.x, this.y, this.iconRadius, paramPaint);
        draw(paramCanvas);
    }

    public float getIconRadius() {
        return this.iconRadius;
    }

    public int getPosition() {
        return this.position;
    }

    public String getTag() {
        return this.tag;
    }

    public void setTag(String paramString) {
        this.tag = paramString;
    }

    public float getX() {
        return this.x;
    }

    public void setX(float paramFloat) {
        this.x = paramFloat;
    }

    public float getY() {
        return this.y;
    }

    public void setY(float paramFloat) {
        this.y = paramFloat;
    }

    public void onActionDown(AppblishCollageStickerView paramStickerView, MotionEvent paramMotionEvent) {
        if (this.iconEvent != null)
            this.iconEvent.onActionDown(paramStickerView, paramMotionEvent);
    }

    public void onActionMove(AppblishCollageStickerView paramStickerView, MotionEvent paramMotionEvent) {
        if (this.iconEvent != null)
            this.iconEvent.onActionMove(paramStickerView, paramMotionEvent);
    }

    public void onActionUp(AppblishCollageStickerView paramStickerView, MotionEvent paramMotionEvent) {
        if (this.iconEvent != null)
            this.iconEvent.onActionUp(paramStickerView, paramMotionEvent);
    }

    public void setIconEvent(StickerIconEvent paramStickerIconEvent) {
        this.iconEvent = paramStickerIconEvent;
    }

    public void setIcon(Drawable drawable) {
        setDrawable(drawable);
    }

    public void setPosition(int position) {
        this.position = position;
    }






}
