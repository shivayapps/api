package com.appblish.collagemaker.appblishlayout.slant;


import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLine;

public class ThreeSlantLayout extends NumberSlantLayout {
    public ThreeSlantLayout(SlantCollageLayout slantPuzzleLayout, boolean z) {
        super(slantPuzzleLayout, z);
        this.theme = ((NumberSlantLayout) slantPuzzleLayout).getTheme();
    }

    public ThreeSlantLayout(int i) {
        super(i);
    }

    public int getThemeCount() {
        return 6;
    }

    public void layout() {
        switch (this.theme) {
            case 0:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.56f, 0.44f);
                return;
            case 1:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.56f, 0.44f);
                return;
            case 2:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.56f, 0.44f);
                return;
            case 3:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.56f, 0.44f);
                return;
            case 4:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.44f, 0.56f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.56f, 0.44f);
                return;
            case 5:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.56f, 0.44f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.44f, 0.56f);
                return;
            default:
                return;
        }
    }

    public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
        return new ThreeSlantLayout((SlantCollageLayout) appblishLayout, true);
    }
}
