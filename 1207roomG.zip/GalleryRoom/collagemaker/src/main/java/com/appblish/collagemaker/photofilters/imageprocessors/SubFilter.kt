package com.appblish.collagemaker.photofilters.imageprocessors

import android.graphics.Bitmap

interface SubFilter {
    fun process(inputImage: Bitmap?): Bitmap?

    var tag: Any
}
