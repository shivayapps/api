package com.appblish.collagemaker.appblishlayout.slant;


import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLine;

public class SevenSlantLayout extends NumberSlantLayout {
    public SevenSlantLayout(SlantCollageLayout slantPuzzleLayout, boolean z) {
        super(slantPuzzleLayout, z);
    }

    public SevenSlantLayout(int i) {
        super(i);
    }

    public int getThemeCount() {
        return 2;
    }

    public void layout() {
        if (this.theme == 0) {
            addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.33333334f);
            addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.5f);
            addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f, 0.5f);
            addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.33f, 0.33f);
            addLine(3, AppblishCollageLine.Direction.HORIZONTAL, 0.5f, 0.5f);
            addLine(2, AppblishCollageLine.Direction.HORIZONTAL, 0.5f, 0.5f);
        }
    }

    public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
        return new SevenSlantLayout((SlantCollageLayout) appblishLayout, true);
    }
}
