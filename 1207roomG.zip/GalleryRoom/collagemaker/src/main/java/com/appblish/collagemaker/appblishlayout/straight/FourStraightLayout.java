package com.appblish.collagemaker.appblishlayout.straight;


import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLine;

public class FourStraightLayout extends NumberStraightLayout {
    private static final String TAG = "FourStraightLayout";

    public FourStraightLayout(StraightCollageLayout straightPuzzleLayout, boolean z) {
        super(straightPuzzleLayout, z);
    }

    public FourStraightLayout(int i) {
        super(i);
    }

    public int getThemeCount() {
        return 8;
    }

    public void layout() {
        switch (this.theme) {
            case 0:
                addCross(0, 0.5f);
                return;
            case 1:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.33333334f);
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.VERTICAL);
                return;
            case 2:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.6666667f);
                cutAreaEqualPart(1, 3, AppblishCollageLine.Direction.VERTICAL);
                return;
            case 3:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.33333334f);
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.HORIZONTAL);
                return;
            case 4:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.6666667f);
                cutAreaEqualPart(1, 3, AppblishCollageLine.Direction.HORIZONTAL);
                return;
            case 5:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.6666667f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.33333334f);
                return;
            case 6:
                cutAreaEqualPart(0, 4, AppblishCollageLine.Direction.HORIZONTAL);
                return;
            case 7:
                cutAreaEqualPart(0, 4, AppblishCollageLine.Direction.VERTICAL);
                return;
            default:
                cutAreaEqualPart(0, 4, AppblishCollageLine.Direction.HORIZONTAL);
                return;
        }
    }

    public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
        return new FourStraightLayout((StraightCollageLayout) appblishLayout, true);
    }
}
