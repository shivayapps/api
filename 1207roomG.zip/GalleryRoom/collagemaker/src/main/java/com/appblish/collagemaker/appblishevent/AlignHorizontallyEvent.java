package com.appblish.collagemaker.appblishevent;

import android.view.MotionEvent;

import com.appblish.collagemaker.appblish.AppblishCollageStickerView;


public class AlignHorizontallyEvent implements StickerIconEvent {
    public void onActionDown(AppblishCollageStickerView paramStickerView, MotionEvent paramMotionEvent) {
    }

    public void onActionMove(AppblishCollageStickerView paramStickerView, MotionEvent paramMotionEvent) {
    }

    public void onActionUp(AppblishCollageStickerView paramStickerView, MotionEvent paramMotionEvent) {
        paramStickerView.alignHorizontally();
    }
}
