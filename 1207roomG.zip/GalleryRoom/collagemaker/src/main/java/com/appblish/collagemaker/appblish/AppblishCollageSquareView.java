package com.appblish.collagemaker.appblish;

import android.content.Context;
import android.util.AttributeSet;

public class AppblishCollageSquareView extends AppblishCollageGridView {
    public AppblishCollageSquareView(Context context) {
        super(context);
    }

    public AppblishCollageSquareView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public AppblishCollageSquareView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }


    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        if (measuredWidth > measuredHeight) {
            measuredWidth = measuredHeight;
        }
        setMeasuredDimension(measuredWidth, measuredWidth);
    }
}
