package com.appblish.collagemaker.interfaces;

public interface OnInitializeResultListener {
    void onResult(boolean success);
}
