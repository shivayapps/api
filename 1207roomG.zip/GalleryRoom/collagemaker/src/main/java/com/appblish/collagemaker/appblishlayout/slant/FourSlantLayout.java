package com.appblish.collagemaker.appblishlayout.slant;


import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLine;

public class FourSlantLayout extends NumberSlantLayout {
    public FourSlantLayout(int i) {
        super(i);
    }

    public FourSlantLayout(AppblishCollageLayout puzzleLayout, boolean z) {
        super((SlantCollageLayout) puzzleLayout, z);
    }

    public int getThemeCount() {
        return 6;
    }

    public void layout() {
        switch (this.theme) {
            case 0:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.3f, 0.3f);
                addLine(2, AppblishCollageLine.Direction.VERTICAL, 0.7f, 0.7f);
                return;
            case 1:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.3f, 0.3f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.7f, 0.7f);
                return;
            case 2:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.6666667f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.6666667f, 0.6666667f);
                addLine(2, AppblishCollageLine.Direction.VERTICAL, 0.6666667f, 0.6666667f);
                return;
            case 3:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.33333334f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.33333334f, 0.33333334f);
                addLine(2, AppblishCollageLine.Direction.VERTICAL, 0.33333334f, 0.33333334f);
                return;
            case 4:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.33333334f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.5f, 0.5f);
                return;
            case 5:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.33333334f);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.5f, 0.5f);
                return;
            case 6:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.7f, 0.3f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.3f, 0.5f);
                addLine(2, AppblishCollageLine.Direction.VERTICAL, 0.5f, 0.7f);
                return;
            default:
                return;
        }
    }

    public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
        return new FourSlantLayout(appblishLayout, true);
    }
}
