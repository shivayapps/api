package com.appblish.collagemaker.utils;



public class AppblishCollageRatioUiModel {

    private final AppblishCollageRatioType type;
    private final int icon;
    private final int selectedIcon;
    private final String title;
    private final boolean visible;

    // Constructor
    public AppblishCollageRatioUiModel(AppblishCollageRatioType type, int icon, int selectedIcon, String title) {
        this(type, icon, selectedIcon, title, true); // default visible = true
    }

    public AppblishCollageRatioUiModel(AppblishCollageRatioType type, int icon, int selectedIcon, String title, boolean visible) {
        this.type = type;
        this.icon = icon;
        this.selectedIcon = selectedIcon;
        this.title = title;
        this.visible = visible;
    }

    // Getters
    public AppblishCollageRatioType getType() {
        return type;
    }

    public int getIcon() {
        return icon;
    }

    public int getSelectedIcon() {
        return selectedIcon;
    }

    public String getTitle() {
        return title;
    }

    public boolean isVisible() {
        return visible;
    }

    // Optional: toString (like Kotlin data class)
    @Override
    public String toString() {
        return "RatioUiModel{" +
                "type=" + type +
                ", icon=" + icon +
                ", selectedIcon=" + selectedIcon +
                ", title='" + title + '\'' +
                ", visible=" + visible +
                '}';
    }

    // Optional: equals and hashCode if needed
}
