package com.appblish.collagemaker.appblish;

import android.graphics.Shader;

import java.util.List;

public class AppblishCollageText {
    private int backgroundAlpha;
    private int backgroundBorder;
    private int backgroundColor;
    private int backgroundColorIndex;
    private int fontIndex;
    private String fontName;
    private boolean isShowBackground;
    private int paddingHeight;
    private int paddingWidth;
    private String text;
    private int textAlign;
    private int textAlpha;
    private int textColor;
    private int textColorIndex;
    private int textHeight;
    private Shader textShader;
    private int textShaderIndex;
    private AppblishCollageTextShadow textShadow;
    private int textShadowIndex;
    private int textSize;
    private int textWidth;



    public static AppblishCollageText getDefaultProperties() {
        AppblishCollageText appblishText = new AppblishCollageText();
        appblishText.setTextSize(30);
        appblishText.setTextAlign(4);
        appblishText.setFontName("0.ttf");
        appblishText.setTextColor(-1);
        appblishText.setTextAlpha(255);
        appblishText.setBackgroundAlpha(255);
        appblishText.setPaddingWidth(12);
        appblishText.setTextShaderIndex(7);
        appblishText.setBackgroundColorIndex(21);
        appblishText.setTextColorIndex(16);
        appblishText.setFontIndex(0);
        appblishText.setShowBackground(false);
        appblishText.setBackgroundBorder(8);
        appblishText.setTextAlign(4);
        return appblishText;
    }


    public static List<AppblishCollageTextShadow> getLstTextShadow(List<AppblishCollageTextShadow> sourceList) {
        return sourceList;
    }

    public int getTextColorIndex() {
        return this.textColorIndex;
    }

    public void setTextColorIndex(int i) {
        this.textColorIndex = i;
    }

    public int getTextShaderIndex() {
        return this.textShaderIndex;
    }

    public void setTextShaderIndex(int i) {
        this.textShaderIndex = i;
    }

    public int getBackgroundColorIndex() {
        return this.backgroundColorIndex;
    }

    public void setBackgroundColorIndex(int i) {
        this.backgroundColorIndex = i;
    }

    public int getFontIndex() {
        return this.fontIndex;
    }

    public void setFontIndex(int i) {
        this.fontIndex = i;
    }

    public int getTextShadowIndex() {
        return this.textShadowIndex;
    }

    public void setTextShadowIndex(int i) {
        this.textShadowIndex = i;
    }

    public AppblishCollageTextShadow getTextShadow() {
        return this.textShadow;
    }

    public void setTextShadow(AppblishCollageTextShadow textShadow2) {
        this.textShadow = textShadow2;
    }

    public int getBackgroundBorder() {
        return this.backgroundBorder;
    }

    public void setBackgroundBorder(int i) {
        this.backgroundBorder = i;
    }

    public int getTextHeight() {
        return this.textHeight;
    }

    public void setTextHeight(int i) {
        this.textHeight = i;
    }

    public int getTextWidth() {
        return this.textWidth;
    }

    public void setTextWidth(int i) {
        this.textWidth = i;
    }

    public int getPaddingWidth() {
        return this.paddingWidth;
    }

    public void setPaddingWidth(int i) {
        this.paddingWidth = i;
    }

    public int getPaddingHeight() {
        return this.paddingHeight;
    }

    public void setPaddingHeight(int i) {
        this.paddingHeight = i;
    }

    public int getTextSize() {
        return this.textSize;
    }

    public void setTextSize(int i) {
        this.textSize = i;
    }

    public int getTextColor() {
        return this.textColor;
    }

    public void setTextColor(int i) {
        this.textColor = i;
    }

    public int getTextAlpha() {
        return this.textAlpha;
    }

    public void setTextAlpha(int i) {
        this.textAlpha = i;
    }

    public Shader getTextShader() {
        return this.textShader;
    }

    public void setTextShader(Shader shader) {
        this.textShader = shader;
    }

    public String getText() {
        return this.text;
    }

    public void setText(String str) {
        this.text = str;
    }

    public int getTextAlign() {
        return this.textAlign;
    }

    public void setTextAlign(int i) {
        this.textAlign = i;
    }

    public String getFontName() {
        return this.fontName;
    }

    public void setFontName(String str) {
        this.fontName = str;
    }

    public int getBackgroundColor() {
        return this.backgroundColor;
    }

    public void setBackgroundColor(int i) {
        this.backgroundColor = i;
    }

    public boolean isShowBackground() {
        return this.isShowBackground;
    }

    public void setShowBackground(boolean z) {
        this.isShowBackground = z;
    }

    public int getBackgroundAlpha() {
        return this.backgroundAlpha;
    }

    public void setBackgroundAlpha(int i) {
        this.backgroundAlpha = i;
    }

}
