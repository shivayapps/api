package com.appblish.collagemaker.photofilters

import android.content.Context
import com.appblish.collagemaker.R
import com.appblish.collagemaker.photofilters.geometry.Point
import com.appblish.collagemaker.photofilters.imageprocessors.AppblishCollageFilter
import com.appblish.collagemaker.photofilters.imageprocessors.subfilters.AppblishCollageBrightnessSubFilter
import com.appblish.collagemaker.photofilters.imageprocessors.subfilters.AppblishCollageColorOverlaySubFilter
import com.appblish.collagemaker.photofilters.imageprocessors.subfilters.AppblishCollageContrastSubFilter
import com.appblish.collagemaker.photofilters.imageprocessors.subfilters.AppblishCollageSaturationSubFilter
import com.appblish.collagemaker.photofilters.imageprocessors.subfilters.AppblishCollageToneCurveSubFilter
import com.appblish.collagemaker.photofilters.imageprocessors.subfilters.AppblishCollageVignetteSubFilter

object AppblishCollageFilterPack {
    /***
     * the filter pack,
     * @param context
     * @return list of filters
     */
    fun getFilterPack(context: Context): List<AppblishCollageFilter> {
        val filters: MutableList<AppblishCollageFilter> = ArrayList()
        filters.add(getAweStruckVibeFilter(context))
        filters.add(getClarendon(context))
        filters.add(getOldManFilter(context))
        filters.add(getMarsFilter(context))
        filters.add(getRiseFilter(context))
        filters.add(getAprilFilter(context))
        filters.add(getAmazonFilter(context))
        filters.add(getStarLitFilter(context))
        filters.add(getNightWhisperFilter(context))
        filters.add(getLimeStutterFilter(context))
        filters.add(getHaanFilter(context))
        filters.add(getBlueMessFilter(context))
        filters.add(getAdeleFilter(context))
        filters.add(getCruzFilter(context))
        filters.add(getMetropolis(context))
        filters.add(getAudreyFilter(context))
        return filters
    }

    fun getStarLitFilter(context: Context): AppblishCollageFilter {
        val rgbKnots = arrayOfNulls<Point>(8)
        rgbKnots[0] = Point(0f, 0f)
        rgbKnots[1] = Point(34f, 6f)
        rgbKnots[2] = Point(69f, 23f)
        rgbKnots[3] = Point(100f, 58f)
        rgbKnots[4] = Point(150f, 154f)
        rgbKnots[5] = Point(176f, 196f)
        rgbKnots[6] = Point(207f, 233f)
        rgbKnots[7] = Point(255f, 255f)
        val filter = AppblishCollageFilter()
        filter.name = context.getString(R.string.collage_starlit)
        filter.addSubFilter(AppblishCollageToneCurveSubFilter(rgbKnots, null, null, null))
        return filter
    }

    fun getBlueMessFilter(context: Context): AppblishCollageFilter {
        val redKnots = arrayOfNulls<Point>(8)
        redKnots[0] = Point(0f, 0f)
        redKnots[1] = Point(86f, 34f)
        redKnots[2] = Point(117f, 41f)
        redKnots[3] = Point(146f, 80f)
        redKnots[4] = Point(170f, 151f)
        redKnots[5] = Point(200f, 214f)
        redKnots[6] = Point(225f, 242f)
        redKnots[7] = Point(255f, 255f)
        val filter = AppblishCollageFilter()
        filter.name = context.getString(R.string.collage_bluemess)
        filter.addSubFilter(AppblishCollageToneCurveSubFilter(null, redKnots, null, null))
        filter.addSubFilter(AppblishCollageBrightnessSubFilter(30))
        filter.addSubFilter(AppblishCollageContrastSubFilter(1f))
        return filter
    }

    fun getAweStruckVibeFilter(context: Context): AppblishCollageFilter {
        val rgbKnots = arrayOfNulls<Point>(5)
        rgbKnots[0] = Point(0f, 0f)
        rgbKnots[1] = Point(80f, 43f)
        rgbKnots[2] = Point(149f, 102f)
        rgbKnots[3] = Point(201f, 173f)
        rgbKnots[4] = Point(255f, 255f)

        val redKnots = arrayOfNulls<Point>(5)
        redKnots[0] = Point(0f, 0f)
        redKnots[1] = Point(125f, 147f)
        redKnots[2] = Point(177f, 199f)
        redKnots[3] = Point(213f, 228f)
        redKnots[4] = Point(255f, 255f)


        val greenKnots = arrayOfNulls<Point>(6)
        greenKnots[0] = Point(0f, 0f)
        greenKnots[1] = Point(57f, 76f)
        greenKnots[2] = Point(103f, 130f)
        greenKnots[3] = Point(167f, 192f)
        greenKnots[4] = Point(211f, 229f)
        greenKnots[5] = Point(255f, 255f)


        val blueKnots = arrayOfNulls<Point>(7)
        blueKnots[0] = Point(0f, 0f)
        blueKnots[1] = Point(38f, 62f)
        blueKnots[2] = Point(75f, 112f)
        blueKnots[3] = Point(116f, 158f)
        blueKnots[4] = Point(171f, 204f)
        blueKnots[5] = Point(212f, 233f)
        blueKnots[6] = Point(255f, 255f)

        val filter = AppblishCollageFilter()
        filter.name = context.getString(R.string.collage_struck)
        filter.addSubFilter(AppblishCollageToneCurveSubFilter(rgbKnots, redKnots, greenKnots, blueKnots))
        return filter
    }

    fun getLimeStutterFilter(context: Context): AppblishCollageFilter {
        val blueKnots = arrayOfNulls<Point>(3)
        blueKnots[0] = Point(0f, 0f)
        blueKnots[1] = Point(165f, 114f)
        blueKnots[2] = Point(255f, 255f)
        val filter = AppblishCollageFilter()
        filter.name = context.getString(R.string.collage_lime)
        filter.addSubFilter(AppblishCollageToneCurveSubFilter(null, null, null, blueKnots))
        return filter
    }

    fun getNightWhisperFilter(context: Context): AppblishCollageFilter {
        val rgbKnots = arrayOfNulls<Point>(3)
        rgbKnots[0] = Point(0f, 0f)
        rgbKnots[1] = Point(174f, 109f)
        rgbKnots[2] = Point(255f, 255f)

        val redKnots = arrayOfNulls<Point>(4)
        redKnots[0] = Point(0f, 0f)
        redKnots[1] = Point(70f, 114f)
        redKnots[2] = Point(157f, 145f)
        redKnots[3] = Point(255f, 255f)

        val greenKnots = arrayOfNulls<Point>(3)
        greenKnots[0] = Point(0f, 0f)
        greenKnots[1] = Point(109f, 138f)
        greenKnots[2] = Point(255f, 255f)

        val blueKnots = arrayOfNulls<Point>(3)
        blueKnots[0] = Point(0f, 0f)
        blueKnots[1] = Point(113f, 152f)
        blueKnots[2] = Point(255f, 255f)

        val filter = AppblishCollageFilter()
        filter.name = context.getString(R.string.collage_whisper)
        filter.addSubFilter(AppblishCollageContrastSubFilter(1.5f))
        filter.addSubFilter(AppblishCollageToneCurveSubFilter(rgbKnots, redKnots, greenKnots, blueKnots))
        return filter
    }

    fun getAmazonFilter(context: Context): AppblishCollageFilter {
        val blueKnots = arrayOfNulls<Point>(6)
        blueKnots[0] = Point(0f, 0f)
        blueKnots[1] = Point(11f, 40f)
        blueKnots[2] = Point(36f, 99f)
        blueKnots[3] = Point(86f, 151f)
        blueKnots[4] = Point(167f, 209f)
        blueKnots[5] = Point(255f, 255f)
        val filter = AppblishCollageFilter(context.getString(R.string.collage_amazon))
        filter.addSubFilter(AppblishCollageContrastSubFilter(1.2f))
        filter.addSubFilter(AppblishCollageToneCurveSubFilter(null, null, null, blueKnots))
        return filter
    }

    fun getAdeleFilter(context: Context): AppblishCollageFilter {
        val filter = AppblishCollageFilter(context.getString(R.string.collage_adele))
        filter.addSubFilter(AppblishCollageSaturationSubFilter(-100f))
        return filter
    }

    fun getCruzFilter(context: Context): AppblishCollageFilter {
        val filter = AppblishCollageFilter(context.getString(R.string.collage_cruz))
        filter.addSubFilter(AppblishCollageSaturationSubFilter(-100f))
        filter.addSubFilter(AppblishCollageContrastSubFilter(1.3f))
        filter.addSubFilter(AppblishCollageBrightnessSubFilter(20))
        return filter
    }

    fun getMetropolis(context: Context): AppblishCollageFilter {
        val filter = AppblishCollageFilter(context.getString(R.string.collage_metropolis))
        filter.addSubFilter(AppblishCollageSaturationSubFilter(-1f))
        filter.addSubFilter(AppblishCollageContrastSubFilter(1.7f))
        filter.addSubFilter(AppblishCollageBrightnessSubFilter(70))
        return filter
    }

    fun getAudreyFilter(context: Context): AppblishCollageFilter {
        val filter = AppblishCollageFilter(context.getString(R.string.collage_audrey))
        val redKnots = arrayOfNulls<Point>(3)
        redKnots[0] = Point(0f, 0f)
        redKnots[1] = Point(124f, 138f)
        redKnots[2] = Point(255f, 255f)

        filter.addSubFilter(AppblishCollageSaturationSubFilter(-100f))
        filter.addSubFilter(AppblishCollageContrastSubFilter(1.3f))
        filter.addSubFilter(AppblishCollageBrightnessSubFilter(20))
        filter.addSubFilter(AppblishCollageToneCurveSubFilter(null, redKnots, null, null))
        return filter
    }

    fun getRiseFilter(context: Context): AppblishCollageFilter {
        val blueKnots = arrayOfNulls<Point>(4)
        blueKnots[0] = Point(0f, 0f)
        blueKnots[1] = Point(39f, 70f)
        blueKnots[2] = Point(150f, 200f)
        blueKnots[3] = Point(255f, 255f)

        val redKnots = arrayOfNulls<Point>(4)
        redKnots[0] = Point(0f, 0f)
        redKnots[1] = Point(45f, 64f)
        redKnots[2] = Point(170f, 190f)
        redKnots[3] = Point(255f, 255f)

        val filter = AppblishCollageFilter(context.getString(R.string.collage_rise))
        filter.addSubFilter(AppblishCollageContrastSubFilter(1.9f))
        filter.addSubFilter(AppblishCollageBrightnessSubFilter(60))
        filter.addSubFilter(AppblishCollageVignetteSubFilter(context, 200))
        filter.addSubFilter(AppblishCollageToneCurveSubFilter(null, redKnots, null, blueKnots))
        return filter
    }

    fun getMarsFilter(context: Context): AppblishCollageFilter {
        val filter = AppblishCollageFilter(context.getString(R.string.collage_mars))
        filter.addSubFilter(AppblishCollageContrastSubFilter(1.5f))
        filter.addSubFilter(AppblishCollageBrightnessSubFilter(10))
        return filter
    }

    fun getAprilFilter(context: Context): AppblishCollageFilter {
        val blueKnots = arrayOfNulls<Point>(4)
        blueKnots[0] = Point(0f, 0f)
        blueKnots[1] = Point(39f, 70f)
        blueKnots[2] = Point(150f, 200f)
        blueKnots[3] = Point(255f, 255f)

        val redKnots = arrayOfNulls<Point>(4)
        redKnots[0] = Point(0f, 0f)
        redKnots[1] = Point(45f, 64f)
        redKnots[2] = Point(170f, 190f)
        redKnots[3] = Point(255f, 255f)

        val filter = AppblishCollageFilter(context.getString(R.string.collage_april))
        filter.addSubFilter(AppblishCollageContrastSubFilter(1.5f))
        filter.addSubFilter(AppblishCollageBrightnessSubFilter(5))
        filter.addSubFilter(AppblishCollageVignetteSubFilter(context, 150))
        filter.addSubFilter(AppblishCollageToneCurveSubFilter(null, redKnots, null, blueKnots))
        return filter
    }

    fun getHaanFilter(context: Context): AppblishCollageFilter {
        val greenKnots = arrayOfNulls<Point>(3)
        greenKnots[0] = Point(0f, 0f)
        greenKnots[1] = Point(113f, 142f)
        greenKnots[2] = Point(255f, 255f)

        val filter = AppblishCollageFilter(context.getString(R.string.collage_haan))
        filter.addSubFilter(AppblishCollageContrastSubFilter(1.3f))
        filter.addSubFilter(AppblishCollageBrightnessSubFilter(60))
        filter.addSubFilter(AppblishCollageVignetteSubFilter(context, 200))
        filter.addSubFilter(AppblishCollageToneCurveSubFilter(null, null, greenKnots, null))
        return filter
    }

    fun getOldManFilter(context: Context): AppblishCollageFilter {
        val filter = AppblishCollageFilter(context.getString(R.string.collage_oldman))
        filter.addSubFilter(AppblishCollageBrightnessSubFilter(30))
        filter.addSubFilter(AppblishCollageSaturationSubFilter(0.8f))
        filter.addSubFilter(AppblishCollageContrastSubFilter(1.3f))
        filter.addSubFilter(AppblishCollageVignetteSubFilter(context, 100))
        filter.addSubFilter(AppblishCollageColorOverlaySubFilter(100, .2f, .2f, .1f))
        return filter
    }

    fun getClarendon(context: Context): AppblishCollageFilter {
        val redKnots = arrayOfNulls<Point>(4)
        redKnots[0] = Point(0f, 0f)
        redKnots[1] = Point(56f, 68f)
        redKnots[2] = Point(196f, 206f)
        redKnots[3] = Point(255f, 255f)


        val greenKnots = arrayOfNulls<Point>(4)
        greenKnots[0] = Point(0f, 0f)
        greenKnots[1] = Point(46f, 77f)
        greenKnots[2] = Point(160f, 200f)
        greenKnots[3] = Point(255f, 255f)


        val blueKnots = arrayOfNulls<Point>(4)
        blueKnots[0] = Point(0f, 0f)
        blueKnots[1] = Point(33f, 86f)
        blueKnots[2] = Point(126f, 220f)
        blueKnots[3] = Point(255f, 255f)

        val filter = AppblishCollageFilter(context.getString(R.string.collage_clarendon))
        filter.addSubFilter(AppblishCollageContrastSubFilter(1.5f))
        filter.addSubFilter(AppblishCollageBrightnessSubFilter(-10))
        filter.addSubFilter(AppblishCollageToneCurveSubFilter(null, redKnots, greenKnots, blueKnots))
        return filter
    }
}
