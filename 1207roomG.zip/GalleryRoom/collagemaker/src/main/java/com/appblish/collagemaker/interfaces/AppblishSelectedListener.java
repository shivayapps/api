package com.appblish.collagemaker.interfaces;

import com.appblish.collagemaker.appblish.grid.AppblishCollageGrid;

public interface AppblishSelectedListener  {
            void onAppblishSelected(AppblishCollageGrid appblishCollage, int i);
        }