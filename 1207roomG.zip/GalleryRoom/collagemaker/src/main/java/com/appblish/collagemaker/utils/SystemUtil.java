package com.appblish.collagemaker.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;

public class SystemUtil {
    public static int dpToPx(Context context, int i) {
        return (int) (((float) i) * context.getResources().getDisplayMetrics().density);
    }

}
