package com.appblish.collagemaker.photofilters.imageprocessors

import android.graphics.Bitmap

class AppblishCollageFilter {
    private var subFilters: MutableList<SubFilter>? = ArrayList()
    var name: String? = null

    constructor(filter: AppblishCollageFilter) {
        this.subFilters = filter.subFilters
    }

    constructor()

    constructor(name: String?) {
        this.name = name
    }


    fun addSubFilter(subFilter: SubFilter) {
        subFilters!!.add(subFilter)
    }


    fun addSubFilters(subFilterList: List<SubFilter>?) {
        subFilters!!.addAll(subFilterList!!)
    }


    fun getSubFilters(): List<SubFilter> {
        if (subFilters == null || subFilters!!.isEmpty()) return ArrayList(0)
        return ArrayList(subFilters)
    }


    fun clearSubFilters() {
        subFilters!!.clear()
    }

    fun removeSubFilterWithTag(tag: String) {
        val iterator = subFilters!!.iterator()
        while (iterator.hasNext()) {
            val subFilter = iterator.next()
            if (subFilter.tag == tag) {
                iterator.remove()
            }
        }
    }


    fun getSubFilterByTag(tag: String): SubFilter? {
        for (subFilter in subFilters!!) {
            if (subFilter.tag == tag) {
                return subFilter
            }
        }
        return null
    }

    fun applyFilter(
        inputBitmap: Bitmap,
        filter: AppblishCollageFilter,
        onDone: (Bitmap) -> Unit,
        onError: ((Throwable) -> Unit)? = null
    ) {
        try {
            val safeBitmap = inputBitmap.copy(Bitmap.Config.ARGB_8888, true)
            val output = filter.processFilter(safeBitmap) ?: safeBitmap
            onDone(output)
        } catch (e: Exception) {
            onError?.invoke(e)
        }
    }



    fun processFilter(inputImage: Bitmap?): Bitmap? {
        var outputImage = inputImage
        if (outputImage != null) {
            for (subFilter in subFilters!!) {
                try {
                    outputImage = subFilter.process(outputImage)
                } catch (oe: OutOfMemoryError) {
                    System.gc()
                    try {
                        outputImage = subFilter.process(outputImage)
                    } catch (ignored: OutOfMemoryError) {
                    }
                }
            }
        }

        return outputImage
    }
}
