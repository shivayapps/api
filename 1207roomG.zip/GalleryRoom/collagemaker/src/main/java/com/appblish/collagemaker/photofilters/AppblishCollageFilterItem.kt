package com.appblish.collagemaker.photofilters

import android.graphics.Bitmap
import androidx.annotation.Keep
import com.appblish.collagemaker.photofilters.imageprocessors.AppblishCollageFilter

@Keep
data class AppblishCollageFilterItem(var bitmap: Bitmap, val filter: AppblishCollageFilter)