package com.appblish.collagemaker.appblishlayout.straight;


import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLine;

public class OneStraightLayout extends NumberStraightLayout {
    public OneStraightLayout(StraightCollageLayout straightPuzzleLayout, boolean z) {
        super(straightPuzzleLayout, z);
    }

    public OneStraightLayout(int i) {
        super(i);
    }

    public int getThemeCount() {
        return 6;
    }

    public void layout() {
        switch (this.theme) {
            case 100:
                cutAreaEqualPart(1, 1, 1);

            case 0:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 1:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                return;
            case 2:
                addCross(0, 0.5f);
                return;
            case 3:
                cutAreaEqualPart(0, 2, 1);
                return;
            case 4:
                cutAreaEqualPart(0, 1, 2);
                return;
            case 5:
                cutAreaEqualPart(0, 2, 2);
                return;
            default:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
        }
    }

    public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
        return new OneStraightLayout((StraightCollageLayout) appblishLayout, true);
    }
}
