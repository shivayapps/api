package com.appblish.collagemaker.appblishlayout.straight;


import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLine;

public class EightStraightLayout extends NumberStraightLayout {
    public EightStraightLayout(StraightCollageLayout straightPuzzleLayout, boolean z) {
        super(straightPuzzleLayout, z);
    }


    public EightStraightLayout(int i) {
        super(i);
    }

    public int getThemeCount() {
        return 11;
    }

    public void layout() {
        switch (this.theme) {
            case 0:
                cutAreaEqualPart(0, 3, 1);
                return;
            case 1:
                cutAreaEqualPart(0, 1, 3);
                return;
            case 2:
                cutAreaEqualPart(0, 4, AppblishCollageLine.Direction.VERTICAL);
                addLine(3, AppblishCollageLine.Direction.HORIZONTAL, 0.8f);
                addLine(2, AppblishCollageLine.Direction.HORIZONTAL, 0.6f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.4f);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.2f);
                return;
            case 3:
                cutAreaEqualPart(0, 4, AppblishCollageLine.Direction.HORIZONTAL);
                addLine(3, AppblishCollageLine.Direction.VERTICAL, 0.8f);
                addLine(2, AppblishCollageLine.Direction.VERTICAL, 0.6f);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.4f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.2f);
                return;
            case 4:
                cutAreaEqualPart(0, 4, AppblishCollageLine.Direction.VERTICAL);
                addLine(3, AppblishCollageLine.Direction.HORIZONTAL, 0.2f);
                addLine(2, AppblishCollageLine.Direction.HORIZONTAL, 0.4f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.6f);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.8f);
                return;
            case 5:
                cutAreaEqualPart(0, 4, AppblishCollageLine.Direction.HORIZONTAL);
                addLine(3, AppblishCollageLine.Direction.VERTICAL, 0.2f);
                addLine(2, AppblishCollageLine.Direction.VERTICAL, 0.4f);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.6f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.8f);
                return;
            case 6:
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.HORIZONTAL);
                cutAreaEqualPart(2, 3, AppblishCollageLine.Direction.VERTICAL);
                cutAreaEqualPart(1, 2, AppblishCollageLine.Direction.VERTICAL);
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.VERTICAL);
                return;
            case 7:
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.VERTICAL);
                cutAreaEqualPart(2, 3, AppblishCollageLine.Direction.HORIZONTAL);
                cutAreaEqualPart(1, 2, AppblishCollageLine.Direction.HORIZONTAL);
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.HORIZONTAL);
                return;
            case 8:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.8f);
                cutAreaEqualPart(1, 5, AppblishCollageLine.Direction.VERTICAL);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                return;
            case 9:
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.HORIZONTAL);
                cutAreaEqualPart(2, 2, AppblishCollageLine.Direction.VERTICAL);
                cutAreaEqualPart(1, 3, AppblishCollageLine.Direction.VERTICAL);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.75f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.33333334f);
                return;
            case 10:
                cutAreaEqualPart(0, 2, 1);
                addLine(5, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(4, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                return;
            default:
                return;
        }
    }

    public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
        return new EightStraightLayout((StraightCollageLayout) appblishLayout, true);
    }
}
