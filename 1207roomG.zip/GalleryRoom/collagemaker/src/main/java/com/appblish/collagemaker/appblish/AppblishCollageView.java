package com.appblish.collagemaker.appblish;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.RelativeLayout;


import com.appblish.collagemaker.interfaces.AppblishSelectedListener;
import com.appblish.collagemaker.interfaces.AppblishUnSelectedListener;
import com.appblish.collagemaker.interfaces.AppblishCollageBlurCallback;
import com.appblish.collagemaker.appblish.grid.AppblishCollageGrid;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.interfaces.OnInitializeResultListener;
import com.appblish.collagemaker.utils.AppblishCollageAspectRatio;
import com.appblish.collagemaker.utils.AppblishCollageBlurUtils;
import com.appblish.collagemaker.utils.AppblishCollageUtils;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;


public class AppblishCollageView extends AppblishCollageStickerView {

    private AppblishCollageGridView gridView;

    public AppblishCollageView(Context context) {
        super(context);
        init(context, null);
    }



    public AppblishCollageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public AppblishCollageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }


    private void init(Context context, AttributeSet attrs) {
        gridView = new AppblishCollageGridView(context, attrs);

        RelativeLayout.LayoutParams lp =
                new RelativeLayout.LayoutParams(
                        LayoutParams.MATCH_PARENT,
                        LayoutParams.MATCH_PARENT
                );

        addView(gridView, lp);


    }



    public void setAppInitializeList(
            final List<String> itemList,
            final OnInitializeResultListener listener
    ) {

        if (itemList == null || itemList.isEmpty()) {
            if (listener != null) listener.onResult(false);
            return;
        }

        if (getWidth() == 0 || getHeight() == 0) {
            post(() -> setAppInitializeList(itemList, listener));
            return;
        }

        List<AppblishCollageLayout> layouts =
                AppblishCollageUtils.getCollageLayouts(itemList.size());

        if (layouts == null || layouts.isEmpty()) {
            if (listener != null) listener.onResult(false);
            return;
        }

        AppblishCollageLayout layout = layouts.get(0);
        setAppblishLayout(layout);

        List<Bitmap> bitmaps = new ArrayList<>();

        for (String path : itemList) {
            Bitmap bmp = BitmapFactory.decodeFile(path);
            if (bmp != null) {
                bitmaps.add(bmp);
            }
        }

        addPieces(bitmaps);

        // Forward Glide result here
        gridView.loadPhoto(itemList, layout, success -> {
            if (listener != null) {
                listener.onResult(success);
            }
        });
    }


//    public void setAppInitializeList(final List<String> itemList) {
//
//        if (itemList == null || itemList.isEmpty()) return;
//
//        // View size not ready yet → retry after layout pass
//        if (getWidth() == 0 || getHeight() == 0) {
//            post(new Runnable() {
//                @Override
//                public void run() {
//                    setAppInitializeList(itemList);
//                }
//            });
//            return;
//        }
//
//        List<AppblishCollageLayout> layouts =
//                CollageUtils.getCollageLayouts(itemList.size());
//
//        if (layouts == null || layouts.isEmpty()) return;
//
//        // 1️⃣ Set layout
//        AppblishCollageLayout layout = layouts.get(0);
//        setAppblishLayout(layout);
//
//        // 2️⃣ Add pieces (initial placeholders)
//        List<Bitmap> bitmaps = new ArrayList<>();
//
//        for (String path : itemList) {
//            Bitmap bmp = BitmapFactory.decodeFile(path);
//            if (bmp != null) {
//                bitmaps.add(bmp);
//            }
//        }
//
//        addPieces(bitmaps);
//
//        // 3️⃣ Load & replace with scaled images
////        gridView.loadPhoto(itemList, layout);
//
//        gridView.loadPhoto(itemList, layout, success -> {
//            if (success) {
//                Log.d("LOAD", "All images loaded successfully");
//            } else {
//                Log.d("LOAD", "Image loading failed");
//            }
//        });
//
//
//
//    }


    // =========================
    // Layout Methods
    // =========================
    public void updateLayout(AppblishCollageLayout layout) {
        gridView.updateLayout(layout);
    }

    public void updateLayout(int position,final List<String> itemList) {

        List<AppblishCollageLayout> layouts =
                AppblishCollageUtils.getCollageLayouts(itemList.size());

        updateLayout(layouts.get(position));
    }

    public void setCollageLayout(AppblishCollageLayout.Info info) {
        gridView.setCollageLayout(info);
    }

    public void setAppblishLayout(AppblishCollageLayout layout) {
        gridView.setAppblishLayout(layout);
    }

    public AppblishCollageLayout getAppblishLayout() {
        return gridView.getAppblishLayout();
    }

    public void reset() {
        gridView.reset();
    }

    public void clearAppblish() {
        gridView.clearAppblish();
    }

    public void clearHandlingPieces() {
        gridView.clearHandlingPieces();
    }

    // =========================
    // Add / Replace Pieces
    // =========================
    public void addPieces(List<Bitmap> bitmaps) {
        gridView.addPieces(bitmaps);
    }

    public void addAppblishCollage(Bitmap bitmap) {
        gridView.addAppblishCollage(bitmap);
    }

    public void addAppblishCollage(Drawable drawable) {
        gridView.addAppblishCollage(drawable);
    }

    public void addAppblishCollage(Drawable drawable, Matrix matrix) {
        gridView.addAppblishCollage(drawable, matrix);
    }


    public void setPrevHandlingappblishGrid(AppblishCollageGrid puzzlePiece) {
        gridView.setPrevHandlingappblishGrid(puzzlePiece);
    }

    public void addAppblishCollage(Drawable drawable, Matrix matrix, String path) {
        gridView.addAppblishCollage(drawable, matrix, path);
    }

    public void replace(Bitmap bitmap, String path) {
        gridView.replace(bitmap, path);
    }

    public void replaceUri(Drawable drawable, String path) {
        gridView.replace(drawable, path);
    }

    // =========================
    // Transformations
    // =========================
    public void flipVertically() {
        gridView.flipVertically();
    }

    public void flipHorizontally() {
        gridView.flipHorizontally();
    }

    public void rotate(float degrees) {
        gridView.rotate(degrees);
    }

    // =========================
    // Drag / Zoom / Swap Settings
    // =========================
    public void setTouchEnable(boolean enable) {
        gridView.setTouchEnable(enable);
    }

    // =========================
    // Grid / Piece Access
    // =========================
    public AppblishCollageGrid getAppblishGrid() {
        return gridView.getAppblishGrid();
    }

    public void setAppblishGrid(AppblishCollageGrid grid) {
        gridView.setAppblishGrid(grid);
    }


    public List<AppblishCollageGrid> getAppblishGrids() {
        return gridView.getAppblishGrids();
    }

    // =========================
    // Animation / Drawing Settings
    // =========================
    public void setAnimateDuration(int duration) {
        gridView.setAnimateDuration(duration);
    }

    public void setAspectRatio(@NotNull final String ratioText) {
        // Wait until the view is measured
        post(() -> {
            String[] parts = ratioText.split(":");
            if (parts.length != 2) return;

            float widthRatio;
            float heightRatio;
            try {
                widthRatio = Float.parseFloat(parts[0]);
                heightRatio = Float.parseFloat(parts[1]);
            } catch (NumberFormatException e) {
                return;
            }

            // Get current width of this AppblishCollageView
            int currentWidth = getWidth();
            if (currentWidth == 0) {
                // width still not ready, try again next layout pass
                post(() -> setAspectRatio(ratioText));
                return;
            }

            // Calculate height based on aspect ratio
            int newHeight = (int) (currentWidth * heightRatio / widthRatio);

            // Update LayoutParams
            ViewGroup.LayoutParams params = getLayoutParams();
            params.height = newHeight;
            setLayoutParams(params);

            // Update internal gridView aspect ratio
            if (gridView != null) {
                gridView.setAspectRatio(new AppblishCollageAspectRatio((int) widthRatio, (int) heightRatio));
            }
        });
    }

    public AppblishCollageAspectRatio getAspectRatio() {
        return gridView.getAspectRatio();
    }


    public void setNeedDrawLine(boolean needDraw) {
        gridView.setNeedDrawLine(needDraw);
    }

    public void setNeedDrawOuterLine(boolean needDrawOuter) {
        gridView.setNeedDrawOuterLine(needDrawOuter);
    }

    public void setLineColor(int color) {
        gridView.setLineColor(color);
    }

    public void setLineSize(int size) {
        gridView.setLineSize(size);
    }

    public void setSelectedLineColor(int color) {
        gridView.setSelectedLineColor(color);
    }

    public void setHandleBarColor(int color) {
        gridView.setHandleBarColor(color);
    }

    // =========================
    // Collage Padding / Radian
    // =========================
    public void setCollagePadding(float padding) {
        gridView.setCollagePadding(padding);
    }

    public float getCollagePadding() {
        return gridView.getCollagePadding();
    }

    public void setCollageRadian(float radian) {
        gridView.setCollageRadian(radian);
    }



    public float getCollageRadian() {
        return gridView.getCollageRadian();
    }

    // =========================
    // Background Settings
    // =========================
    public void setBackgroundResourceMode(int resource) {
        gridView.setBackgroundResourceMode(resource);
    }





    public int getBackgroundResourceMode() {
        return gridView.getBackgroundResourceMode();
    }

    @Override
    public void setBackgroundColor(int color) {
        gridView.setBackgroundColor(color);
    }

    public void setLayoutBackground(Drawable drawable) {
        gridView.setBackground(drawable);
    }

     public void setBackgroundResorce(int resid) {
        gridView.setBackgroundResource(resid);
    }

    public void setBackgroundBlurGrid(
            Context context,
            Drawable path,
            AppblishCollageBlurCallback listener  // <-- yahi interface use karenge
    ) {

        AppblishCollageBlurUtils blurUtils = new AppblishCollageBlurUtils();

        Log.d("CALLBACK", "Blur started");

        blurUtils.blurImageAsync(
                context,
                path,
                gridView,
                new AppblishCollageBlurCallback() {
                    @Override
                    public void onBlurSuccess(Bitmap bitmap) {
                        Log.d("CALLBACK", "Blur complete");

                        if (listener != null) {
                            listener.onBlurSuccess(bitmap); // pass back to Activity
                        }
                    }

                    @Override
                    public void onBlurFailed(Exception e) {
                        if (listener != null) {
                            listener.onBlurFailed(e);
                        }
                    }
                }
        );
    }



    // =========================
    // Selection Listeners
    // =========================
    public void setOnAppblishSelectedListener(AppblishSelectedListener listener) {
        gridView.setOnAppblishSelectedListener(listener);
    }

    public void checklistClear(){
        gridView.checklistClear();
    }

    public void setOnAppblishUnSelectedListener(AppblishUnSelectedListener listener) {
        gridView.setonAppblishUnSelectedListener(listener);
    }
    // =========================
    // Clear / Handling
    // =========================
    public void clearHandling() {
        gridView.clearHandling();
    }

    public void clearSelectedLine() {
        gridView.clearSelectedLine();
    }

}
