package com.appblish.collagemaker.appblishlayout.slant;


import android.util.Log;

import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLine;

public class TwoSlantLayout extends NumberSlantLayout {
    public TwoSlantLayout(SlantCollageLayout slantPuzzleLayout, boolean z) {
        super(slantPuzzleLayout, z);
    }


    public TwoSlantLayout(int i) {
        super(i);
    }

    public int getThemeCount() {
        return 2;
    }

    public void layout() {
        Log.i("onCreate", "layout: "+theme);
        switch (this.theme) {
            case 0:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.56f, 0.44f);
                return;
            case 1:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.56f, 0.44f);
                return;
            default:
                return;
        }
    }

    public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
        return new TwoSlantLayout((SlantCollageLayout) appblishLayout, true);
    }
}
