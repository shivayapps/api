package com.appblish.collagemaker.appblish;

public  class AppblishCollageTextShadow {
        private int colorShadow;
        private int x;
        private int y;
        private int radius;

        public AppblishCollageTextShadow(int i, int i2, int i3, int i4) {
            this.radius = i;
            this.x = i2;
            this.y = i3;
            this.colorShadow = i4;
        }

        public int getRadius() {
            return this.radius;
        }

        public void setRadius(int i) {
            this.radius = i;
        }

        public int getDx() {
            return this.x;
        }

        public int getDy() {
            return this.y;
        }

        public int getColorShadow() {
            return this.colorShadow;
        }
    }