package com.appblish.collagemaker.appblish.grid;

import android.graphics.PointF;

public interface AppblishCollageLine {

    AppblishCollageLine attachEndLine();

    AppblishCollageLine attachStartLine();

    boolean contains(float f, float f2, float f3);

    Direction direction();

    PointF endPoint();

    float getEndRatio();

    void setEndRatio(float f);

    float getStartRatio();

    void setStartRatio(float f);

    float length();

    AppblishCollageLine lowerLine();

    float maxX();

    float maxY();

    float minX();

    float minY();

    boolean move(float f, float f2);

    void offset(float f, float f2);

    void prepareMove();

    void setLowerLine(AppblishCollageLine line);

    void setUpperLine(AppblishCollageLine line);

    float slope();

    PointF startPoint();

    void update(float f, float f2);

    AppblishCollageLine upperLine();

    enum Direction {
        HORIZONTAL,
        VERTICAL
    }
    enum TwoCollage {
        Col21,
        Col22,
        Col23,
        Col211,
    }
    enum ThreeCollage {
        Col31,
        Col32,
        Col33,
        Col311,
    }
}
