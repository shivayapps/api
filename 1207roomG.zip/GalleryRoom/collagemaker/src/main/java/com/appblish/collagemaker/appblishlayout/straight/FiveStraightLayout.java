package com.appblish.collagemaker.appblishlayout.straight;


import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLine;

public class FiveStraightLayout extends NumberStraightLayout {
    public FiveStraightLayout() {
    }

    public FiveStraightLayout(StraightCollageLayout straightPuzzleLayout, boolean z) {
        super(straightPuzzleLayout, z);
    }

    public FiveStraightLayout(int i) {
        super(i);
    }

    public int getThemeCount() {
        return 17;
    }

    public void layout() {
        switch (this.theme) {
            case 0:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.25f);
                addLine(1, AppblishCollageLine.Direction.VERTICAL, 0.6666667f);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                addLine(2, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 1:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.6f);
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.VERTICAL);
                addLine(3, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                return;
            case 2:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.4f);
                cutAreaEqualPart(0, 3, AppblishCollageLine.Direction.HORIZONTAL);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 3:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.4f);
                cutAreaEqualPart(1, 3, AppblishCollageLine.Direction.HORIZONTAL);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 4:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.75f);
                cutAreaEqualPart(1, 4, AppblishCollageLine.Direction.VERTICAL);
                return;
            case 5:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.25f);
                cutAreaEqualPart(0, 4, AppblishCollageLine.Direction.VERTICAL);
                return;
            case 6:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.75f);
                cutAreaEqualPart(1, 4, AppblishCollageLine.Direction.HORIZONTAL);
                return;
            case 7:
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.25f);
                cutAreaEqualPart(0, 4, AppblishCollageLine.Direction.HORIZONTAL);
                return;
            case 8:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.25f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.6666667f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                addLine(3, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                return;
            case 9:
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.4f);
                addLine(0, AppblishCollageLine.Direction.VERTICAL, 0.5f);
                cutAreaEqualPart(2, 3, AppblishCollageLine.Direction.VERTICAL);
                return;
            case 10:
                addCross(0, 0.33333334f);
                addLine(2, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 11:
                addCross(0, 0.6666667f);
                addLine(1, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 12:
                addCross(0, 0.33333334f, 0.6666667f);
                addLine(3, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 13:
                addCross(0, 0.6666667f, 0.33333334f);
                addLine(0, AppblishCollageLine.Direction.HORIZONTAL, 0.5f);
                return;
            case 14:
                cutSpiral(0);
                return;
            case 15:
                cutAreaEqualPart(0, 5, AppblishCollageLine.Direction.HORIZONTAL);
                return;
            case 16:
                cutAreaEqualPart(0, 5, AppblishCollageLine.Direction.VERTICAL);
                return;
            default:
                cutAreaEqualPart(0, 5, AppblishCollageLine.Direction.HORIZONTAL);
                return;
        }
    }

    public AppblishCollageLayout clone(AppblishCollageLayout appblishLayout) {
        return new FiveStraightLayout((StraightCollageLayout) appblishLayout, true);
    }
}
