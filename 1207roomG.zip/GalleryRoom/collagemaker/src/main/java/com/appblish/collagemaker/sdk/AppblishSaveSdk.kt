package com.appblish.collagemaker.sdk

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.MediaScannerConnection
import android.net.Uri
import android.provider.MediaStore
import com.appblish.collagemaker.appblish.AppblishCollageView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object AppblishSaveSdk {

    interface SaveCallback {
        fun onSaved(filePath: String?)
    }

    fun saveCollage(
        context: Context,
        collageView: AppblishCollageView,
        folderPath: String,
        fileName: String,
        callback: SaveCallback
    ) {
        CoroutineScope(Dispatchers.IO).launch {
            val savedPath = try {
                // Create bitmap from view
                val bitmap = createBitmap(collageView)

                // Ensure folder exists
                val folder = File(folderPath)
                if (!folder.exists()) folder.mkdirs()

                // Create file
                val file = File(folder, fileName)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    out.flush()
                }

                // Update gallery
                MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), null, null)

                bitmap.recycle()
                file.absolutePath
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }

            // Callback on main thread
            withContext(Dispatchers.Main) {
                callback.onSaved(savedPath)
            }
        }
    }

    fun createBitmap(appblishCollageView: AppblishCollageView): Bitmap {
        appblishCollageView.clearHandling()
        appblishCollageView.invalidate()
        val createBitmap = Bitmap.createBitmap(appblishCollageView.getWidth(), appblishCollageView.getHeight(), Bitmap.Config.ARGB_8888)
        appblishCollageView.draw(Canvas(createBitmap))
        return createBitmap
    }


    suspend fun loadBitmapFromUri(context: Context, uri: Uri): Bitmap? {
        return withContext(Dispatchers.IO) {
            try {
                // Load bitmap from URI
                var bmp = MediaStore.Images.Media.getBitmap(context.contentResolver, uri)

                // Resize if too large
                val width = bmp.width.toFloat()
                val height = bmp.height.toFloat()
                val max = maxOf(width / 1280f, height / 1280f)
                if (max > 1.0f) {
                    bmp = Bitmap.createScaledBitmap(
                        bmp,
                        (width / max).toInt(),
                        (height / max).toInt(),
                        false
                    )
                }

                bmp
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }

}