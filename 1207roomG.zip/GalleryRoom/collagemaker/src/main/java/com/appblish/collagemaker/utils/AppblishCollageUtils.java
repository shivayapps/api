package com.appblish.collagemaker.utils;


import android.util.Log;

import com.appblish.collagemaker.appblishlayout.slant.SlantLayoutHelper;
import com.appblish.collagemaker.appblishlayout.straight.StraightLayoutHelper;
import com.appblish.collagemaker.appblish.grid.AppblishCollageLayout;

import java.util.ArrayList;
import java.util.List;

public class AppblishCollageUtils {

    private AppblishCollageUtils() {
    }

    public static List<AppblishCollageLayout> getCollageLayouts(int i) {

        Log.i("onCreate", "getCollageLayouts: "+i);
        ArrayList arrayList = new ArrayList();
        arrayList.addAll(SlantLayoutHelper.getAllThemeLayout(i));
        arrayList.addAll(StraightLayoutHelper.getAllThemeLayout(i));
        return arrayList;
    }



}
