plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.jetbrains.kotlin.android)
//    alias(libs.plugins.maven.publish)
 }

android {
    namespace = "com.appblish.collagemaker"
    compileSdk = 36

    defaultConfig {
        minSdk = 24
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    buildFeatures {
        viewBinding = true
    }

}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.material)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)
    implementation("com.github.bumptech.glide:glide:5.0.5")

}


//afterEvaluate {
//    publishing {
//        publications {
//            create<MavenPublication>("v1") {
//                groupId = "com.appblish.collage"
//                artifactId = "v1"
//                version = "1.0.1"
//                artifact("./build/outputs/aar/collagemaker-release.aar")
//            }
//        }
//        repositories {
//            maven {
//                name = "GitLab"
//                url = uri("https://gitlab.com/api/v4/projects/77924385/packages/maven")
//                credentials {
//                    username = "AppblishCollage"
//                    password = "gldt-43NNKTEzjvDyhktAxbhG"
//                }
//            }
//        }
//    }
//}