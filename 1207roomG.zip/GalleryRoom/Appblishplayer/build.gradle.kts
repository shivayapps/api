plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.jetbrains.kotlin.android)
//    alias(libs.plugins.maven.publish)
}

android {
    namespace = "com.app.blish.player"
    compileSdk {
        version = release(36)
    }

    defaultConfig {
        minSdk = 24
        consumerProguardFiles("consumer-rules.pro")
    }
    buildFeatures {
        buildConfig = true
        viewBinding = true
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation("androidx.media3:media3-exoplayer:1.9.2")
    implementation("androidx.media3:media3-exoplayer-dash:1.9.2")
    implementation("androidx.media3:media3-ui:1.9.2")
    implementation("androidx.media3:media3-session:1.9.2")
}

//afterEvaluate {
//
//    publishing {
//        publications {
//            create<MavenPublication>("v2") {
//                groupId = "com.appblish.videoplayer"
//                artifactId = "v2"
//                version = "1.0.2"
//                artifact("./build/outputs/aar/Appblishplayer-release.aar")
//            }
//        }
//        repositories {
//            maven {
//                name = "GitLab"
//                url = uri("https://gitlab.com/api/v4/projects/77924398/packages/maven")
//                credentials {
//                    username = "AppbishVideoPlayer"
//                    password = "gldt-zXygUC4PznJeHcj7k68L"
//                }
//            }
//        }
//    }
//}