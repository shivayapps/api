# Keep all WorkManager workers
# ===============================
# Media3 (ExoPlayer) - Core
# ===============================
-keep class androidx.media3.** { *; }
-keep class androidx.media3.ui.** { *; }
-dontwarn androidx.media3.**

# Keep PlayerView & UI components
-keep class androidx.media3.ui.** { *; }

# Keep ExoPlayer implementation
-keep class androidx.media3.exoplayer.** { *; }

# Keep Common module
-keep class androidx.media3.common.** { *; }

# ===============================
# Prevent stripping of enums
# ===============================
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}