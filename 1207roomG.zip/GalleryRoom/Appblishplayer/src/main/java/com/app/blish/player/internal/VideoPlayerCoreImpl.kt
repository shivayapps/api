package com.app.blish.player.internal

import android.net.Uri
import androidx.annotation.OptIn
import androidx.lifecycle.LiveData
import androidx.media3.common.util.UnstableApi
import com.app.blish.player.api.AppblishAudioTrackItem
import com.app.blish.player.api.VideoPlayerCore

@OptIn(UnstableApi::class)
internal class VideoPlayerCoreImpl(private val repository: VideoPlayerRepository) : VideoPlayerCore {
    override val brightnessUpdate: LiveData<Int>
        get() = repository._brightnessUpdate
    override val volumeUpdate: LiveData<Int>
        get() = repository._volumeUpdate
    override val touchUp: LiveData<Unit>
        get() = repository._touchUp
    override val controllerVisibilityChange: LiveData<Boolean>
        get() = repository._controllerVisibilityChange

    override fun isPlaying(): Boolean {
        return repository.isPlaying()
    }


    override fun pausePlayer() {
        repository.pausePlayer()
    }

    override fun resumePlayer() {
        repository.resumePlayer()
    }

    override fun releasePlayer() {
        repository.releasePlayer()
    }

    override fun playVideo(videoUri: Uri, popupSeekPos: Long) {
        repository.playVideo(videoUri, popupSeekPos)
    }

    override fun getFileName(videoUri: Uri): String {
        return repository.getFileName(videoUri)
    }

    override fun fitScreen(callback: () -> Unit) {
        repository.fitScreen(callback)

    }

    override fun enterPipMode() {
        repository.enterPipMode()
    }

    override fun lockPlayer() {
        repository.lockPlayer()
    }

    override fun unlockPlayer() {
        repository.unlockPlayer()
    }

    override fun isResizeModeFill(): Boolean {
        return repository.isResizeModeFill()
    }

    override fun getCurrentPlaybackSpeed(): Float {
        return repository.getCurrentPlaybackSpeed()
    }

    override fun setPaybackSpeed(speed: Float) {
        repository.setPaybackSpeed(speed)
    }

    override fun getAvailableAudioTracks(): List<AppblishAudioTrackItem> {
        return repository.getAvailableAudioTracks()
    }

    override fun disableAudio() {
        repository.disableAudio()
    }

    override fun setPreferredAudioLanguage(languageCode: String) {
        repository.setPreferredAudioLanguage(languageCode)
    }


}