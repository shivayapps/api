package com.app.blish.player.api

import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.util.UnstableApi
import com.app.blish.player.internal.VideoPlayerCoreImpl
import com.app.blish.player.internal.VideoPlayerPref
import com.app.blish.player.internal.VideoPlayerRepository

object VideoPlayerSDK {
    @Volatile
    private var instance: VideoPlayerCore? = null

    @OptIn(UnstableApi::class)
    @Synchronized
    fun setUpPlayer(activity: AppCompatActivity, playerView: AppblishPlayerView) {
        val pref = VideoPlayerPref(activity, activity.packageName.hashCode().toString())
        val repo = VideoPlayerRepository(activity, playerView, pref)
        instance = VideoPlayerCoreImpl(repo)
        repo.initPlayer()
    }

    fun get(): VideoPlayerCore =
        instance ?: throw IllegalStateException(
            "MemorySdk is not initialized. Call initialize() in Application."
        )

    fun getPref(activity: AppCompatActivity) = VideoPlayerPref(activity, activity.packageName.hashCode().toString())
}