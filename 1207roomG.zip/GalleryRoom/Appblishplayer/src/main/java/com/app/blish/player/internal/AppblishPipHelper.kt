package com.app.blish.player.internal

import android.annotation.SuppressLint
import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Rational
import androidx.annotation.OptIn
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.app.blish.player.api.AppblishAudioTrackItem
import java.util.Locale
import kotlin.math.abs

internal class AppblishPipHelper {

        fun enterPip(activity: Activity, player: ExoPlayer?) {

            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            if (player == null) return

            val builder = PictureInPictureParams.Builder()

            val size = player.videoSize
            if (size.width > 0 && size.height > 0) {
                builder.setAspectRatio(Rational(size.width, size.height))
            }

            activity.enterPictureInPictureMode(builder.build())
        }

        fun createRichMediaItem(videoUri: Uri): MediaItem {

            val mediaMetadata = MediaMetadata.Builder()
                .setArtworkUri(videoUri)
                .build()

            return MediaItem.Builder()
                .setUri(videoUri)
                .setMediaMetadata(mediaMetadata)
                .build()
        }


        @SuppressLint("DefaultLocale")
        fun formatMiles(time: Long): String {
            val totalSeconds = abs(time.toInt() / 1000)
            val seconds = totalSeconds % 60
            val minutes = totalSeconds % 3600 / 60
            val hours = totalSeconds / 3600
            return if (hours > 0) String.format(
                "%d:%02d:%02d", hours, minutes, seconds
            ) else String.format("%02d:%02d", minutes, seconds)
        }

        fun formatMilesSign(time: Long): String {
            return if (time > -1000 && time < 1000) formatMiles(time) else (if (time < 0) "−" else "+") + formatMiles(
                time
            )
        }



        fun hideSystemBars(activity: Activity) {
            val windowInsetsController =
                ViewCompat.getWindowInsetsController(activity.window.decorView) ?: return
            windowInsetsController.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

            windowInsetsController.hide(WindowInsetsCompat.Type.systemBars())
        }

        fun setScreenBrightness(value: Int, activity: Activity) {
            val brightness30 = value.coerceIn(0, 30)

            val percent = brightness30 / 30f  // convert to 0–1

            val lp = activity.window.attributes
            lp.screenBrightness = percent
            activity.window.attributes = lp
        }



        fun getSystemBrightness(context: Context): Int {
            return try {
                val systemValue = Settings.System.getInt(
                    context.contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS
                ) // 0–255

                // convert 255 → 30
                ((systemValue / 255f) * 30f).toInt()

            } catch (e: Exception) {
                15 // mid fallback
            }
        }


    @OptIn(UnstableApi::class)
    fun getAvailableAudioTracks(player: ExoPlayer): List<AppblishAudioTrackItem> {

        val audioItems = mutableListOf<AppblishAudioTrackItem>()

        val tracks = player.currentTracks

        for (group in tracks.groups) {

            if (group.mediaTrackGroup.type == C.TRACK_TYPE_AUDIO) {

                val groupInfo = group.mediaTrackGroup

                for (i in 0 until groupInfo.length) {

                    val format = groupInfo.getFormat(i)
                    val language = format.language ?: "und"

                    val displayLanguage =
                        if (language == "und") "Default"
                        else Locale(language).displayLanguage

                    val rawLabel = format.label
                    val safeLabel = rawLabel
                        ?.takeIf {
                            it.isNotBlank() &&
                                    !it.equals("unknown", true) &&
                                    !it.equals("und", true)
                        }

                    val channelInfo = when (format.channelCount) {
                        6 -> "5.1"
                        2 -> "Stereo"
                        else -> null
                    }

                    val finalName = buildString {
                        append(displayLanguage)
                        safeLabel?.let { append(" ($it)") }
                        channelInfo?.let { append(" - $it") }
                    }

                    audioItems.add(
                        AppblishAudioTrackItem(
                            languageCode = language,
                            displayName = finalName
                        )
                    )
                }
            }
        }

        return audioItems
    }


    }
