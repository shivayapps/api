package com.app.blish.player.api

import android.net.Uri
import androidx.annotation.Keep
import androidx.lifecycle.LiveData

@Keep
interface VideoPlayerCore {
    val brightnessUpdate: LiveData<Int>
    val volumeUpdate: LiveData<Int>
    val touchUp: LiveData<Unit>
    val controllerVisibilityChange: LiveData<Boolean>


    fun isPlaying(): Boolean
    fun resumePlayer()
    fun pausePlayer()
    fun releasePlayer()
    fun playVideo(videoUri: Uri, popupSeekPos: Long)
    fun getFileName(videoUri: Uri): String
    fun fitScreen(callback: () -> Unit)
    fun enterPipMode()
    fun lockPlayer()
    fun unlockPlayer()
    fun isResizeModeFill(): Boolean
    fun getCurrentPlaybackSpeed(): Float
    fun setPaybackSpeed(speed: Float)
    fun getAvailableAudioTracks(): List<AppblishAudioTrackItem>
    fun disableAudio()
    fun setPreferredAudioLanguage(languageCode: String)

}