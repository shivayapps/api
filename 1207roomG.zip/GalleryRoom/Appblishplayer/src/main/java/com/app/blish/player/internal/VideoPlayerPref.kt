package com.app.blish.player.internal

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import androidx.core.content.edit

class VideoPlayerPref(val context: Context, val prefName: String) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences(prefName, Context.MODE_PRIVATE)

    private var rememberPlaybackValue: Boolean
        get() = prefs.getBoolean("REMEMBER_PLAYBACK", true)
        set(value) = prefs.edit { putBoolean("REMEMBER_PLAYBACK", value) }


    private var useSwipeControlsValue: Boolean
        get() = prefs.getBoolean("USE_SWIPE_CONTROLS", true)
        set(value) = prefs.edit { putBoolean("USE_SWIPE_CONTROLS", value) }

    private var useZoomControlsValue: Boolean
        get() = prefs.getBoolean("USE_ZOOM_CONTROLS", true)
        set(value) = prefs.edit { putBoolean("USE_ZOOM_CONTROLS", value) }

    private var screenOrientationValue: Int
        get() = prefs.getInt("screenOrientation", ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
        set(value) = prefs.edit { putInt("screenOrientation", value) }


    fun setLong(key: String, result: Long) {
        prefs.edit { putLong(key, result) }
    }

    fun getLong(key: String, default: Long = 0L): Long {
        return prefs.getLong(key, default) ?: 0L
    }


    fun isRememberPlayback(): Boolean {
        return rememberPlaybackValue
    }

    fun setRememberPlayback(playback: Boolean) {
        rememberPlaybackValue = playback

    }

    fun isUseSwipeControl(): Boolean {
        return useSwipeControlsValue

    }

    fun setUseSwipeControl(useSwipeControls: Boolean) {
        this.useSwipeControlsValue = useSwipeControls

    }

    fun isUseZoomControl(): Boolean {
        return useZoomControlsValue

    }

    fun setUseZoomControl(useZoomControls: Boolean) {
        this.useZoomControlsValue = useZoomControls

    }

    fun getScreenOrientation(): Int {
        return screenOrientationValue
    }

    fun setScreenOrientation(screenOrientation: Int) {
        this.screenOrientationValue = screenOrientation
    }
}