package com.app.blish.player.internal

interface AppblishPlayerListener {
    fun onDoubleTapStarted(posX: Float, posY: Float)
    fun onDoubleTapProgressDown(posX: Float, posY: Float)

    fun onDoubleTapProgressUp(posX: Float, posY: Float)

    fun onDoubleTapFinished()
}