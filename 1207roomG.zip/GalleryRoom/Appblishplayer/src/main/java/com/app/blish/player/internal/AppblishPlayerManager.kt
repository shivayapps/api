package com.app.blish.player.internal

import android.app.Activity
import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.media3.common.C
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import com.app.blish.player.api.AppblishAudioTrackItem
import java.io.File


@UnstableApi
class AppblishPlayerManager(context: Context) {
    val player: ExoPlayer = ExoPlayer.Builder(context).build()
    private val pipHelper = AppblishPipHelper()
    fun enterPip(activity: Activity) {
        pipHelper.enterPip(activity, player)
    }

    fun playMedia(videoUri: Uri) {
        val mediaItem = pipHelper.createRichMediaItem(videoUri)
        player.setMediaItem(mediaItem)
        player.prepare()
        player.playWhenReady = true
    }


    fun pause() {
        player.pause()
    }

    fun isPlaying(): Boolean {
        return player.isPlaying
    }

    fun setPaybackSpeed(speed: Float) {
        player.playbackParameters = PlaybackParameters(speed)
    }

    fun resume() {
        player.playWhenReady = true
    }

    fun release() {
        player.release()
    }

    fun seekTo(mediaItemIndex: Int, positionMs: Long) {
        player.seekTo(mediaItemIndex, positionMs)
    }

    fun getDuration() = player.duration
    fun getCurrent() = player.currentPosition

    fun setPreferredAudioLanguage(language: String?) {

        val trackSelector = player?.trackSelector as DefaultTrackSelector
        trackSelector.setParameters(
            trackSelector.buildUponParameters().setRendererDisabled(C.TRACK_TYPE_AUDIO, false).setPreferredAudioLanguage(language)
        )
    }

    fun disableAudio() {
        val trackSelector = player?.trackSelector as DefaultTrackSelector
        trackSelector.setParameters(
            trackSelector.buildUponParameters().setRendererDisabled(C.TRACK_TYPE_AUDIO, true)
        )
    }

    fun hideSystemBars(activity: Activity) {
        pipHelper.hideSystemBars(activity)

    }

    fun getSystemBrightness(activity: Activity): Int {
        return pipHelper.getSystemBrightness(activity)
    }

    fun setScreenBrightness(value: Int, activity: Activity) {
        pipHelper.setScreenBrightness(value, activity)

    }


    fun formatMilesSign(time: Long): String {
        return pipHelper.formatMiles(time)
    }

    fun getAvailableAudioTracks(): List<AppblishAudioTrackItem> {
        return pipHelper.getAvailableAudioTracks(player)
    }


    fun getFileNameFromPath(filePath: String): String {
        return File(filePath).name
    }


    fun getFileName(context: Context, uri: Uri): String? {
        return try {
            val name = if (uri.scheme == ContentResolver.SCHEME_CONTENT) {
                context.contentResolver.query(
                    uri,
                    arrayOf(OpenableColumns.DISPLAY_NAME),
                    null,
                    null,
                    null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        cursor.getString(
                            cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)
                        )
                    } else null
                }
            } else {
                uri.path?.substringAfterLast('/')
            }

            name?.substringBeforeLast(".", name)

        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }


    fun formatMiles(time: Long): String {
        return pipHelper.formatMiles(time)
    }


}