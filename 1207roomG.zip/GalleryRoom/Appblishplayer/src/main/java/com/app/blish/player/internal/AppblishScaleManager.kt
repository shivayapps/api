package com.app.blish.player.internal

import android.view.ScaleGestureDetector
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.media3.ui.R


internal class AppblishScaleManager(
    private val playerView: PlayerView
) : ScaleGestureDetector.OnScaleGestureListener {

    private var scaleFactor = 1f
    private var isScalingEnabled = true   // 👈 control flag

    override fun onScale(detector: ScaleGestureDetector): Boolean {

        if (!isScalingEnabled) return false   // 👈 stop scaling

        scaleFactor *= detector.scaleFactor

        // Limit zoom range
        scaleFactor = scaleFactor.coerceIn(1f, 5f)

        applyScale()
        return true
    }

    override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
        return isScalingEnabled   // 👈 allow only if enabled
    }

    override fun onScaleEnd(detector: ScaleGestureDetector) {}

    @OptIn(UnstableApi::class)
    private fun applyScale() {
        val contentFrame = playerView.findViewById<AspectRatioFrameLayout>(
            R.id.exo_content_frame
        )

        contentFrame?.apply {
            scaleX = scaleFactor
            scaleY = scaleFactor
        }

        playerView.videoSurfaceView?.apply {
            scaleX = scaleFactor
            scaleY = scaleFactor
        }
    }

    // 🔹 Start Scaling
    fun startScaling() {
        isScalingEnabled = true
    }

    // 🔹 Stop Scaling
    fun stopScaling() {
        isScalingEnabled = false
    }

    // 🔹 Reset Zoom
    fun resetScale() {
        scaleFactor = 1f
        applyScale()
    }
}