package com.app.blish.player.api

import androidx.annotation.Keep

@Keep
data class AppblishAudioTrackItem(
    val languageCode: String,
    val displayName: String
)