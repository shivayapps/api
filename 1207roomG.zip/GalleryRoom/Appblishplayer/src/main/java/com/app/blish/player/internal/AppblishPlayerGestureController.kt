package com.app.blish.player.internal


import android.content.Context
import android.media.AudioManager
import android.view.GestureDetector
import android.view.MotionEvent
import androidx.media3.common.util.UnstableApi
import kotlin.math.abs

@UnstableApi
internal class AppblishPlayerGestureController(
    private val context: Context,
    private val playerManager: AppblishPlayerManager,
    private val audioManager: AudioManager,
    private val getCurrentBrightness: () -> Int,
    private val setBrightness: (Int) -> Unit,
    private val onSeekTextUpdate: (String) -> Unit,
    private val onBrightnessUpdate: (Int) -> Unit,
    private val onVolumeUpdate: (Int) -> Unit
) : GestureDetector.OnGestureListener {

    // ================= ENUM =================

    enum class ScrollMode {
        NONE, SEEK, BRIGHTNESS, VOLUME
    }

    // ================= FLAGS =================

    private var isGestureEnabled = true
    var allowSeek = true
    var allowBrightness = true
    var allowVolume = true

    // ================= VARIABLES =================

    private var scrollMode = ScrollMode.NONE
    private var gestureScrollX = 0f

    private var seekStart = 0L
    private var seekChange = 0L
    private var seekMax = 0L

    private var gestureInitialBrightness = 0f
    private var gestureInitialVolume = 0f

    // ================= CONSTANTS =================

    private val SEEK_STEP = 10000L
    private val SCROLL_STEP_SEEK = 8f
    private val IGNORE_BORDER = 80f
    private val DEAD_ZONE_PERCENT = 0.25f

    // ================= PUBLIC CONTROL =================

    fun enableGestures() {
        isGestureEnabled = true
    }

    fun disableGestures() {
        isGestureEnabled = false
        reset()
    }

    fun reset() {
        scrollMode = ScrollMode.NONE
        gestureScrollX = 0f
    }

    // ================= GESTURE METHODS =================

    override fun onDown(e: MotionEvent): Boolean {
        if (!isGestureEnabled) return false
        reset()
        return true
    }

    override fun onShowPress(e: MotionEvent) {}

    override fun onSingleTapUp(e: MotionEvent): Boolean = false

    override fun onLongPress(e: MotionEvent) {}

    override fun onFling(
        e1: MotionEvent?,
        e2: MotionEvent,
        velocityX: Float,
        velocityY: Float
    ): Boolean = false

    override fun onScroll(
        e1: MotionEvent?,
        e2: MotionEvent,
        distanceX: Float,
        distanceY: Float
    ): Boolean {

        if (!isGestureEnabled) return false
        if (e1 == null) return false
        if (e1.pointerCount >= 2 || e2.pointerCount >= 2) return false

        val sWidth = context.resources.displayMetrics.widthPixels
        val sHeight = context.resources.displayMetrics.heightPixels

        // ===== BORDER IGNORE =====
        if (e1.x < IGNORE_BORDER ||
            e1.x > sWidth - IGNORE_BORDER ||
            e1.y < IGNORE_BORDER ||
            e1.y > sHeight - IGNORE_BORDER
        ) return false

        // ===== DEAD ZONE =====
        val deadLeft = sWidth * DEAD_ZONE_PERCENT
        val deadRight = sWidth * (1 - DEAD_ZONE_PERCENT)
        val deadTop = sHeight * DEAD_ZONE_PERCENT
        val deadBottom = sHeight * (1 - DEAD_ZONE_PERCENT)

        if (e1.x in deadLeft..deadRight &&
            e1.y in deadTop..deadBottom
        ) return false

        // ===== MODE LOCK =====
        if (scrollMode == ScrollMode.NONE) {

            scrollMode =
                if (abs(distanceX) > abs(distanceY) && allowSeek) {
                    ScrollMode.SEEK
                } else {
                    if (e1.x < sWidth / 2 && allowBrightness)
                        ScrollMode.BRIGHTNESS
                    else if (allowVolume)
                        ScrollMode.VOLUME
                    else
                        ScrollMode.NONE
                }

            when (scrollMode) {

                ScrollMode.SEEK -> {
                    seekStart = playerManager.player.currentPosition
                    seekChange = 0L
                    seekMax = playerManager.player.duration
                }

                ScrollMode.BRIGHTNESS -> {
                    gestureInitialBrightness =
                        getCurrentBrightness().toFloat()
                }

                ScrollMode.VOLUME -> {
                    gestureInitialVolume =
                        audioManager.getStreamVolume(
                            AudioManager.STREAM_MUSIC
                        ).toFloat()
                }

                else -> {}
            }
        }

        // ===== HANDLE MODES =====
        when (scrollMode) {

            ScrollMode.SEEK -> handleSeek(distanceX)

            ScrollMode.BRIGHTNESS -> handleBrightness(e1, e2, sHeight)

            ScrollMode.VOLUME -> handleVolume(e1, e2, sHeight)

            else -> {}
        }

        return true
    }

    // ================= SEEK =================

    private fun handleSeek(distanceX: Float) {

        gestureScrollX += distanceX

        if (abs(gestureScrollX) > SCROLL_STEP_SEEK) {

            val change = SEEK_STEP

            if (gestureScrollX > 0) {
                seekChange -= change
            } else {
                seekChange += change
            }

            val newPosition =
                (seekStart + seekChange)
                    .coerceIn(0L, seekMax)

            playerManager.player.seekTo(newPosition)

            val text =
                "${playerManager.formatMilesSign(seekChange)}  ${
                    playerManager.formatMiles(newPosition)
                }"

            onSeekTextUpdate(text)

            gestureScrollX = 0f
        }
    }

    // ================= BRIGHTNESS =================

    private fun handleBrightness(
        e1: MotionEvent,
        e2: MotionEvent,
        sHeight: Int
    ) {

        val verticalDistance = e1.y - e2.y
        val maxBrightness = 30

        val change =
            (verticalDistance / sHeight) *
                    maxBrightness * 2.5f

        val newBrightness =
            (gestureInitialBrightness + change)
                .coerceIn(0f, maxBrightness.toFloat())
                .toInt()

        setBrightness(newBrightness)
        onBrightnessUpdate(newBrightness)
    }

    // ================= VOLUME =================

    private fun handleVolume(
        e1: MotionEvent,
        e2: MotionEvent,
        sHeight: Int
    ) {

        val verticalDistance = e1.y - e2.y

        val maxVolume =
            audioManager.getStreamMaxVolume(
                AudioManager.STREAM_MUSIC
            )

        val change =
            (verticalDistance / sHeight) *
                    maxVolume * 2.5f

        val newVolume =
            (gestureInitialVolume + change)
                .coerceIn(0f, maxVolume.toFloat())
                .toInt()

        audioManager.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            newVolume,
            0
        )

        onVolumeUpdate(newVolume)
    }
}
