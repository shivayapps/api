package com.app.blish.player.api

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.annotation.Keep
import androidx.core.view.GestureDetectorCompat
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.app.blish.player.internal.AppblishPlayerListener
import com.app.blish.player.internal.AppblishPlayerManager

@Keep
@SuppressLint("UseKtx")
@UnstableApi
class AppblishPlayerView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : PlayerView(context, attrs, defStyleAttr) {

    private var forwardIconRes: Int? = null
    private var rewindIconRes: Int? = null

    private val gestureListener: DoubleTapGestureListener = DoubleTapGestureListener(rootView)
    private val gestureDetector: GestureDetectorCompat = GestureDetectorCompat(context, gestureListener)

    private var controller: AppblishPlayerListener? = null
        get() = gestureListener.controls
        set(value) {
            gestureListener.controls = value
            field = value
        }

    private var controllerRef: Int = -1

    init {
        /* attrs?.let {
             val a = context.obtainStyledAttributes(
                 attrs,
                 R.styleable.AppblishPlayerView,
                 0,
                 0
             )
             controllerRef =
                 a.getResourceId(R.styleable.AppblishPlayerView_appblish_controller, -1) ?: -1
             a.recycle()
         }*/
    }

    fun setDoubleTapIcons(forwardRes: Int, rewindRes: Int) {
        forwardIconRes = forwardRes
        rewindIconRes = rewindRes
    }

    var isDoubleTapEnabled = true

    var doubleTapDelay: Long = 700
        get() = gestureListener.doubleTapDelay
        set(value) {
            gestureListener.doubleTapDelay = value
            field = value
        }

    fun controller(controller: AppblishPlayerListener) = apply {
        this.controller = controller
    }

    fun isInDoubleTapMode(): Boolean = gestureListener.isDoubleTapping

    fun keepInDoubleTapMode() {
        gestureListener.keepInDoubleTapMode()
    }

    fun cancelInDoubleTapMode() {
        gestureListener.cancelInDoubleTapMode()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (isDoubleTapEnabled) {
            gestureDetector.onTouchEvent(ev)
            Log.i("onDoubleTapStarted", "onTouchEvent: ")
            return true
        }
        return super.onTouchEvent(ev)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        /*
                if (controllerRef != -1) {
                    try {
                        val view: View = (this.parent as View).findViewById(controllerRef)
                        if (view is AppblishPlayerListener) {
                            controller(view)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Log.e(
                            "AppblishDoubleTapPlayerView",
                            "controllerRef is either invalid or not PlayerDoubleTapListener: ${e.message}"
                        )
                    }
                }*/
    }

    private class DoubleTapGestureListener(private val rootView: View) :
        GestureDetector.SimpleOnGestureListener() {

        private val mHandler = Handler(Looper.getMainLooper())
        private val mRunnable = Runnable {
            if (DEBUG) Log.d(TAG, "Runnable called")
            isDoubleTapping = false
            controls?.onDoubleTapFinished()
        }

        var controls: AppblishPlayerListener? = null
        var isDoubleTapping = false
        var doubleTapDelay: Long = 650

        fun keepInDoubleTapMode() {
            isDoubleTapping = true
            mHandler.removeCallbacks(mRunnable)
            mHandler.postDelayed(mRunnable, doubleTapDelay)
        }

        fun cancelInDoubleTapMode() {
            mHandler.removeCallbacks(mRunnable)
            isDoubleTapping = false
            controls?.onDoubleTapFinished()
        }

        override fun onDown(e: MotionEvent): Boolean {
            if (isDoubleTapping) {
                controls?.onDoubleTapProgressDown(e.x, e.y)
                return true
            }
            return super.onDown(e)
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            if (isDoubleTapping) {
                if (DEBUG) Log.d(TAG, "onSingleTapUp: isDoubleTapping = true")
                controls?.onDoubleTapProgressUp(e.x, e.y)
                return true
            }
            return super.onSingleTapUp(e)
        }

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            if (isDoubleTapping) return true
            if (DEBUG) Log.d(TAG, "onSingleTapConfirmed: isDoubleTap = false")
            return rootView.performClick()
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (DEBUG) Log.d(TAG, "onDoubleTap")

            if (!isDoubleTapping) {
                isDoubleTapping = true
                keepInDoubleTapMode()
                controls?.onDoubleTapStarted(e.x, e.y)

                val isLeft = e.x < (rootView.width / 2)

                if (rootView is AppblishPlayerView) {
                    rootView.handleDoubleTap(isLeft)
                }
            }
            return true
        }

        override fun onDoubleTapEvent(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_UP && isDoubleTapping) {
                if (DEBUG) Log.d(TAG, "onDoubleTapEvent, ACTION_UP")
                controls?.onDoubleTapProgressUp(e.x, e.y)
                return true
            }
            return super.onDoubleTapEvent(e)
        }

        companion object {
            private const val TAG = ".DTGListener"
            private var DEBUG = true
        }
    }

    private var playerManager: AppblishPlayerManager? = null

    fun setPlayerManager(manager: AppblishPlayerManager) {
        playerManager = manager
        this.player = manager.player
    }

    private fun showOverlayIcon(isLeft: Boolean) {

        val drawableRes = if (isLeft)
            rewindIconRes ?: 0
        else
            forwardIconRes ?: 0

        val overlay = ImageView(context).apply {
            setImageResource(drawableRes)
            setPadding(24, 24, 24, 24)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }

        val parentFrame = this.parent as FrameLayout
        val parentWidth = parentFrame.width
        val parentHeight = parentFrame.height

        val x = if (isLeft) parentWidth * 0.20f else parentWidth * 0.80f
        val y = parentHeight / 2f

        val size = 150
        val params = LayoutParams(size, size)
        params.leftMargin = (x - size / 2).toInt()
        params.topMargin = (y - size / 2).toInt()

        parentFrame.addView(overlay, params)

        overlay.animate()
            .alpha(0f)
            .setDuration(800)
            .withEndAction { parentFrame.removeView(overlay) }
            .start()
    }

    private fun handleDoubleTap(isLeft: Boolean) {
        playerManager?.let { manager ->
            val millis = if (isLeft) -10_000L else 10_000L
            val current = manager.player.currentPosition
            val duration = manager.player.duration
            val newPos = (current + millis).coerceIn(0L, duration)
            manager.player.seekTo(newPos)
            showOverlayIcon(isLeft)
        }
    }
}