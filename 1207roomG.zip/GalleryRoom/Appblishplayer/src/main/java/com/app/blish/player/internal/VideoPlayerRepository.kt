package com.app.blish.player.internal

import android.annotation.SuppressLint
import android.content.Context.AUDIO_SERVICE
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.util.Log
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GestureDetectorCompat
import androidx.lifecycle.MutableLiveData
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.app.blish.player.api.AppblishAudioTrackItem
import com.app.blish.player.api.AppblishPlayerView

@UnstableApi
internal class VideoPlayerRepository(
    private val activity: AppCompatActivity,
    private val playerView: AppblishPlayerView,
    private val videoPlayerPref: VideoPlayerPref
) {
    val _brightnessUpdate = MutableLiveData<Int>()
    val _volumeUpdate = MutableLiveData<Int>()
    val _touchUp = MutableLiveData<Unit>()
    val _controllerVisibilityChange = MutableLiveData<Boolean>()

    private var brightnessInt = 0
    private val playerManager by lazy { AppblishPlayerManager(activity) }
    private val scaleManager by lazy { AppblishScaleManager(playerView) }
    private val audioManager by lazy { activity.getSystemService(AUDIO_SERVICE) as AudioManager }
    private val gestureDetector by lazy { GestureDetectorCompat(activity, gestureController) }

    private val gestureController by lazy {
        AppblishPlayerGestureController(
            context = activity,
            playerManager = playerManager,
            audioManager = audioManager,
            getCurrentBrightness = { brightnessInt },
            setBrightness = {
                brightnessInt = it
                playerManager.setScreenBrightness(it, activity)
            }, onSeekTextUpdate = {

            }, onBrightnessUpdate = {
                _brightnessUpdate.value = it

            }, onVolumeUpdate = {
                _volumeUpdate.value = it
            })
    }

    private val scaleGestureDetector by lazy {
        ScaleGestureDetector(
            activity, scaleManager
        )
    }
    private var playbackSpeed = 1.0f
    fun getCurrentPlaybackSpeed() = playbackSpeed

    fun initPlayer() {
        playerView.player = playerManager.player
        playerView.setPlayerManager(playerManager)
        playbackSpeed = 1.0f
        if (brightnessInt == 0) {
            brightnessInt = playerManager.getSystemBrightness(activity)
        }
        playerView.setBackgroundColor(Color.BLACK)
        playerView.setShutterBackgroundColor(Color.BLACK)
        playerView.isDoubleTapEnabled = true
        playerView.setControllerVisibilityListener(
            PlayerView.ControllerVisibilityListener { visibility ->
                when (visibility) {
                    View.VISIBLE -> {
                        _controllerVisibilityChange.value = true
                    }

                    View.GONE -> {
                        _controllerVisibilityChange.value = false
                    }
                }
            }
        )
        applyControls()
    }

    fun releasePlayer() {
        (playerView.tag as? String)?.let {

            val total = playerManager.getDuration()
            val current = playerManager.getCurrent()
            val remaining = total - current
            if (remaining < 5000) {
                videoPlayerPref.setLong(it, 0)
            } else {
                videoPlayerPref.setLong(it, current)
            }
            Log.e("VideoPlayerRepository", "playVideo: $total $current $remaining")


        }
        playerManager.release()
    }

    @SuppressLint("ClickableViewAccessibility")
    fun playVideo(videoUri: Uri, popupSeekPos: Long) {
        Log.e("VideoPlayerRepository", "playVideo: $videoUri")
        playerManager.playMedia(videoUri)
        playerView.keepScreenOn = true
        playerView.tag = videoUri.toString()
        if (popupSeekPos > 0) {
            playerManager.seekTo(0, popupSeekPos)
        } else {
            if (videoPlayerPref.isRememberPlayback()) {
                val lastPosition = videoPlayerPref.getLong(videoUri.toString())
                if (lastPosition != 0L) {
                    playerManager.seekTo(0, lastPosition)
                }
            }
        }
        playerView.setOnTouchListener { _, motionEvent ->
            gestureDetector.onTouchEvent(motionEvent)
            scaleGestureDetector.onTouchEvent(motionEvent)
            if (motionEvent.action == MotionEvent.ACTION_UP) {
                _touchUp.value = Unit
            }
            return@setOnTouchListener false
        }
    }

    fun getFileName(videoUri: Uri): String {
        return playerManager.getFileName(activity, videoUri).toString()
    }

    fun disableAudio() {
        playerManager.disableAudio()
    }

    fun pausePlayer() {
        if (playerManager.isPlaying()) {
            playerManager.pause()
        }
    }

    fun resumePlayer() {
        if (!playerManager.isPlaying()) {
            playerManager.resume()
        }
    }


    fun setPaybackSpeed(speed: Float) {
        playbackSpeed = speed
        playerManager.setPaybackSpeed(speed)
    }

    fun setPreferredAudioLanguage(language: String?) {
        playerManager.setPreferredAudioLanguage(
            language
        )
    }

    fun fitScreen(callback: () -> Unit) {
        if (playerView.resizeMode == androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL) {
            playerView.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
            playerManager.player.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING

        } else {
            playerView.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL
            playerManager.player.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
        }
        callback.invoke()
    }

    fun lockPlayer() {
        playerView.isDoubleTapEnabled = false
        gestureController.disableGestures()
        scaleManager.stopScaling()
    }

    fun unlockPlayer() {
        playerView.isDoubleTapEnabled = true
    }


    fun applyControls() {
        if (videoPlayerPref.isUseZoomControl()) {
            scaleManager.startScaling()
        } else {
            scaleManager.stopScaling()
        }

        if (videoPlayerPref.isUseSwipeControl()) {
            gestureController.enableGestures()
        } else {
            gestureController.disableGestures()
        }
    }

    fun enterPipMode() {
        playerManager.enterPip(activity)
    }

    fun getAvailableAudioTracks(): List<AppblishAudioTrackItem> {
        return playerManager.getAvailableAudioTracks()
    }

    fun isResizeModeFill() = playerView.resizeMode == androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL


    fun isPlaying(): Boolean {
        return playerManager.isPlaying()

    }


}