plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.jetbrains.kotlin.android)
    alias(libs.plugins.ksp)
//    alias(libs.plugins.maven.publish)
}

android {
    namespace = "com.cleaner.v2"
    compileSdk = 36

    defaultConfig {
        minSdk = 30
        consumerProguardFiles("consumer-rules.pro")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }
//    publishing {
//        singleVariant("release") {}
//    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.work.runtime.ktx)
//    implementation("com.appblish.gallery:box:1.1.3")

    implementation("androidx.room:room-runtime:2.8.4")
    implementation("androidx.room:room-ktx:2.8.4")
    ksp("androidx.room:room-compiler:2.8.4")
    implementation(project(":box"))
}


//afterEvaluate {
//    publishing {
//        publications {
//            create<MavenPublication>("v2") {
//                from(components["release"])   // ✅ IMPORTANT
//                groupId = "com.appblish.cleaner"
//                artifactId = "v2"
//                version = "1.1.0"
//            }
//        }
//
//        repositories {
//            maven {
//                name = "GitLab"
//                url = uri("https://gitlab.com/api/v4/projects/78113991/packages/maven")
//
//                credentials {
//                    username = "appblishcleaner"
//                    password = "gldt-xsHuo_usyZyjrJxMxvKy"
//                }
//            }
//        }
//    }
//}