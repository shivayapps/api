package com.cleaner.v2.internal

import android.os.Environment
import com.appblish.box.api.model.MediaBox
import com.cleaner.v2.api.model.CleanerListItem
import com.cleaner.v2.api.model.CleanerMediaSizeCategory
import java.text.SimpleDateFormat
import java.util.Locale

internal object CleanerGrouper {

    // =====================================================
    // ⚙️ CONSTANTS
    // =====================================================

    private const val DAY_MS = 24L * 60 * 60 * 1000

    private val dateFormatter =
        ThreadLocal.withInitial {
            SimpleDateFormat("dd/MM/yyyy", Locale.US)
        }

    // =====================================================
    // 🚀 PUBLIC API (CALL THIS ON BACKGROUND THREAD)
    // =====================================================

    fun buildAll(
        medias: List<MediaBox>
    ): Result {

        if (medias.isEmpty()) {
            return Result.EMPTY
        }

        // 🔥 ALL BUCKETS
        val duplicateMap = HashMap<String, MutableList<MediaBox>>()
        val largeMediaMap = HashMap<Int, MutableList<MediaBox>>()
        val largeVideoMap = HashMap<Int, MutableList<MediaBox>>()
        val blurDayMap = HashMap<Long, MutableList<MediaBox>>()
        val screenshotDayMap = HashMap<Long, MutableList<MediaBox>>()

        // =====================================================
        // 🔥 SINGLE PASS (THIS IS THE KEY)
        // =====================================================

        for (m in medias) {

            // DUPLICATES
            val hash = m.hashKey
            if (hash.isNotEmpty() && hash != "no_hash") {
                duplicateMap
                    .getOrPut(hash) { ArrayList(2) }
                    .add(m)
            }

            // LARGE MEDIA
            largeMediaMap
                .getOrPut(m.sizeCategory) { ArrayList() }
                .add(m)

            // LARGE VIDEO
            if (m.isVideoCheck()) {
                largeVideoMap
                    .getOrPut(m.sizeCategory) { ArrayList() }
                    .add(m)
            }

            // BLUR
            if (m.isBlur == 1) {
                val day = m.mediaDate / DAY_MS
                blurDayMap
                    .getOrPut(day) { ArrayList() }
                    .add(m)
            }

            // SCREENSHOT
            if (m.isScreenshot()) {
                val day = m.mediaDate / DAY_MS
                screenshotDayMap
                    .getOrPut(day) { ArrayList() }
                    .add(m)
            }
        }

        // =====================================================
        // 🔹 BUILD UI LISTS (FAST, SMALL MAPS)
        // =====================================================

        return Result(
            duplicates = buildDuplicateUI(duplicateMap),
            largeMedia = buildSizeUI(largeMediaMap),
            largeVideo = buildSizeUI(largeVideoMap),
            blur = buildDayUI(blurDayMap),
            screenshots = buildDayUI(screenshotDayMap)
        )
    }

    // =====================================================
    // 🧱 UI BUILDERS
    // =====================================================

    private fun buildDuplicateUI(
        map: Map<String, MutableList<MediaBox>>
    ): List<CleanerListItem> {

        val result = ArrayList<CleanerListItem>()
        var index = 1

        for (list in map.values) {
            if (list.size < 2) continue

            var total = 0L
            for (m in list) total += m.mediaSize

            result.add(
                CleanerListItem.Header(
                    title = "set_${index++}",
                    sizeCategory = CleanerMediaSizeCategory.FROM_5_GB_TO_1_GB,
                    totalSize = total,
                    count = list.size
                )
            )

            for (m in list) {
                result.add(CleanerListItem.CleanerMedia(m))
            }
        }

        return result
    }

    private fun buildSizeUI(
        map: Map<Int, MutableList<MediaBox>>
    ): List<CleanerListItem> {

        val result = ArrayList<CleanerListItem>()
        val keys = map.keys.sortedDescending()

        for (key in keys) {
            val list = map[key] ?: continue

            var total = 0L
            for (m in list) total += m.mediaSize

            list.sortByDescending { it.mediaSize }

            result.add(
                CleanerListItem.Header(
                    title = "",
                    sizeCategory = CleanerMediaSizeCategory.fromId(key),
                    totalSize = total,
                    count = list.size
                )
            )

            for (m in list) {
                result.add(CleanerListItem.CleanerMedia(m))
            }
        }

        return result
    }

    private fun buildDayUI(
        map: Map<Long, MutableList<MediaBox>>
    ): List<CleanerListItem> {

        val result = ArrayList<CleanerListItem>()
        val keys = map.keys.sortedDescending()

        for (day in keys) {
            val list = map[day] ?: continue

            var total = 0L
            for (m in list) total += m.mediaSize

            list.sortByDescending { it.mediaDate }

            result.add(
                CleanerListItem.Header(
                    title = dayToString(day),
                    sizeCategory = CleanerMediaSizeCategory.FROM_5_GB_TO_1_GB,
                    totalSize = total,
                    count = list.size
                )
            )

            for (m in list) {
                result.add(CleanerListItem.CleanerMedia(m))
            }
        }

        return result
    }

    // =====================================================
    // ⚙️ HELPERS
    // =====================================================

    private fun dayToString(day: Long): String =
        dateFormatter.get()!!.format(day * DAY_MS)

    // =====================================================
    // 📦 RESULT HOLDER
    // =====================================================

    data class Result(
        val duplicates: List<CleanerListItem>,
        val largeMedia: List<CleanerListItem>,
        val largeVideo: List<CleanerListItem>,
        val blur: List<CleanerListItem>,
        val screenshots: List<CleanerListItem>
    ) {
        companion object {
            val EMPTY = Result(
                emptyList(),
                emptyList(),
                emptyList(),
                emptyList(),
                emptyList()
            )
        }
    }

    internal val screenshotDir = Environment
        .getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
        .absolutePath + "/Screenshots"

    internal val screenshotDCIMDir = Environment
        .getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
        .absolutePath + "/Screenshots"

    internal fun MediaBox.isScreenshot(): Boolean {
        return bucketPath == screenshotDir || bucketPath == screenshotDCIMDir
    }
}