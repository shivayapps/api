package com.cleaner.v2.internal

import com.appblish.box.api.model.MediaBox
import com.cleaner.v2.api.model.CleanerListItem
import com.cleaner.v2.api.model.CleanerMediaSizeCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.text.SimpleDateFormat
import java.util.Locale

internal object DuplicateGrouper {

    // =====================================================
    // ⚙️ THREAD CONFIG (UI SAFE)
    // =====================================================

    private val PARALLELISM =
        maxOf(2, Runtime.getRuntime().availableProcessors() - 1)

    private const val MIN_CHUNK_SIZE = 500
    private const val DAY_MS = 24L * 60 * 60 * 1000

    private val dateFormatter =
        ThreadLocal.withInitial {
            SimpleDateFormat("dd/MM/yyyy", Locale.US)
        }

    // =====================================================
    // 🔥 DUPLICATES BY HASH (PARALLEL)
    // =====================================================

    suspend fun buildDuplicateList(
        medias: List<MediaBox>
    ): List<CleanerListItem> = coroutineScope {

        if (medias.size < 2) return@coroutineScope emptyList()

        val chunkSize =
            (medias.size / PARALLELISM).coerceAtLeast(MIN_CHUNK_SIZE)

        val partialMaps = medias
            .chunked(chunkSize)
            .map { chunk ->
                async(Dispatchers.Default) {
                    val local = HashMap<String, MutableList<MediaBox>>()
                    for (m in chunk) {
                        val key = m.hashKey
                        if (key.isEmpty() || key == "no_hash") continue
                        local.getOrPut(key) { ArrayList(2) }.add(m)
                    }
                    local
                }
            }
            .awaitAll()

        val finalMap =
            HashMap<String, MutableList<MediaBox>>(medias.size / 2)

        for (map in partialMaps) {
            for ((k, v) in map) {
                finalMap.getOrPut(k) { ArrayList(v.size) }.addAll(v)
            }
        }

        val result = ArrayList<CleanerListItem>()
        var setIndex = 1

        for (entry in finalMap.values) {
            if (entry.size < 2) continue

            var totalSize = 0L
            for (m in entry) totalSize += m.mediaSize

            result.add(
                CleanerListItem.Header(
                    title = "set_${setIndex++}",
                    sizeCategory = CleanerMediaSizeCategory.FROM_5_GB_TO_1_GB,
                    totalSize = totalSize,
                    count = entry.size
                )
            )

            for (m in entry) {
                result.add(CleanerListItem.CleanerMedia(m))
            }
        }

        result
    }

    // =====================================================
    // 🔥 GROUP BY SIZE CATEGORY (PARALLEL)
    // =====================================================

    suspend fun buildGroupedList(
        medias: List<MediaBox>
    ): List<CleanerListItem> =
        groupBySizeCategory(medias)

    suspend fun buildGroupedListVideo(
        medias: List<MediaBox>
    ): List<CleanerListItem> =
        groupBySizeCategory(medias)

    private suspend fun groupBySizeCategory(
        medias: List<MediaBox>
    ): List<CleanerListItem> = coroutineScope {

        if (medias.isEmpty()) return@coroutineScope emptyList()

        val chunkSize =
            (medias.size / PARALLELISM).coerceAtLeast(MIN_CHUNK_SIZE)

        val partialMaps = medias
            .chunked(chunkSize)
            .map { chunk ->
                async(Dispatchers.Default) {
                    val local = HashMap<Int, MutableList<MediaBox>>()
                    for (m in chunk) {
                        local.getOrPut(m.sizeCategory) { ArrayList() }.add(m)
                    }
                    local
                }
            }
            .awaitAll()

        val finalMap = HashMap<Int, MutableList<MediaBox>>(8)

        for (map in partialMaps) {
            for ((k, v) in map) {
                finalMap.getOrPut(k) { ArrayList(v.size) }.addAll(v)
            }
        }

        val sortedKeys = finalMap.keys.sortedDescending()
        val result =
            ArrayList<CleanerListItem>(medias.size + sortedKeys.size)

        for (key in sortedKeys) {
            val list = finalMap[key] ?: continue

            var totalSize = 0L
            for (m in list) totalSize += m.mediaSize

            list.sortByDescending { it.mediaSize }

            result.add(
                CleanerListItem.Header(
                    title = "",
                    sizeCategory = CleanerMediaSizeCategory.fromId(key),
                    totalSize = totalSize,
                    count = list.size
                )
            )

            for (m in list) {
                result.add(CleanerListItem.CleanerMedia(m))
            }
        }

        result
    }

    // =====================================================
    // 🔥 GROUP BY DAY (BLUR / SCREENSHOT) – PARALLEL
    // =====================================================

    suspend fun buildBlurGroupedList(
        medias: List<MediaBox>
    ): List<CleanerListItem> =
        groupByDay(medias)

    suspend fun buildScreenshotsGroupedList(
        medias: List<MediaBox>
    ): List<CleanerListItem> =
        groupByDay(medias)

    private suspend fun groupByDay(
        medias: List<MediaBox>
    ): List<CleanerListItem> = coroutineScope {

        if (medias.isEmpty()) return@coroutineScope emptyList()

        val chunkSize =
            (medias.size / PARALLELISM).coerceAtLeast(MIN_CHUNK_SIZE)

        val partialMaps = medias
            .chunked(chunkSize)
            .map { chunk ->
                async(Dispatchers.Default) {
                    val local = HashMap<Long, MutableList<MediaBox>>()
                    for (m in chunk) {
                        val dayKey = m.mediaDate / DAY_MS
                        local.getOrPut(dayKey) { ArrayList() }.add(m)
                    }
                    local
                }
            }
            .awaitAll()

        val finalMap = HashMap<Long, MutableList<MediaBox>>()

        for (map in partialMaps) {
            for ((k, v) in map) {
                finalMap.getOrPut(k) { ArrayList(v.size) }.addAll(v)
            }
        }

        val sortedKeys = finalMap.keys.sortedDescending()
        val result =
            ArrayList<CleanerListItem>(medias.size + sortedKeys.size)

        for (day in sortedKeys) {
            val list = finalMap[day] ?: continue

            var totalSize = 0L
            for (m in list) totalSize += m.mediaSize

            list.sortByDescending { it.mediaDate }

            result.add(
                CleanerListItem.Header(
                    title = dayToString(day),
                    sizeCategory = CleanerMediaSizeCategory.FROM_5_GB_TO_1_GB,
                    totalSize = totalSize,
                    count = list.size
                )
            )

            for (m in list) {
                result.add(CleanerListItem.CleanerMedia(m))
            }
        }

        result
    }

    // =====================================================
    // ⚙️ HELPERS
    // =====================================================

    private fun dayToString(day: Long): String =
        dateFormatter.get()!!.format(day * DAY_MS)
}