package com.cleaner.v2.internal

import androidx.lifecycle.LifecycleOwner
import com.appblish.box.api.util.MediaDataState
import com.cleaner.v2.api.core.CleanerCore
import com.cleaner.v2.api.model.CleanerListItem

internal class CleanerCoreImpl(private val repository: CleanerRepository) : CleanerCore {
    override fun getDuplicateMedias(): MediaDataState<List<CleanerListItem>> {
        return repository.getDuplicateMedias()
    }

    override fun getLargeMedias(): MediaDataState<List<CleanerListItem>> {
        return repository.getLargeMedias()

    }

    override fun getLargeVideos(): MediaDataState<List<CleanerListItem>> {
        return repository.getLargeVideos()

    }

    override fun getScreenshotMedias(): MediaDataState<List<CleanerListItem>> {
        return repository.getScreenshotMedias()

    }

    override fun getBlurMedias(): MediaDataState<List<CleanerListItem>> {
        return repository.getBlurMedias()

    }

    override fun fetchMedia() {
        repository.fetchMedia()
    }


    override fun startScanning(owner: LifecycleOwner) {
        repository.startScanning(owner)
    }

    override fun stopScanning() {
        repository.stopScanning()
    }


}