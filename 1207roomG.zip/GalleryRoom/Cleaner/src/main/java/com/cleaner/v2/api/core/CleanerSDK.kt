package com.cleaner.v2.api.core

import android.content.Context
import androidx.annotation.Keep
import com.cleaner.v2.internal.CleanerCoreImpl
import com.cleaner.v2.internal.CleanerRepository

@Keep
object CleanerSDK {

    @Volatile
    private var instance: CleanerCore? = null

    @Synchronized
    fun initialize(appContext: Context) {
        if (instance != null) return
        val memoryRepository = CleanerRepository(
            appContext.applicationContext,
        )
        instance = CleanerCoreImpl(memoryRepository)
    }

    fun get(): CleanerCore =
        instance ?: throw IllegalStateException(
            "CleanerSDK is not initialized. Call initialize() in Application."
        )

}