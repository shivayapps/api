package com.cleaner.v2.api.model

import androidx.annotation.Keep
import com.appblish.box.api.model.MediaBox

@Keep
sealed class CleanerListItem {

    @Keep
    data class Header(
        val title: String,
        val sizeCategory: CleanerMediaSizeCategory,
        val totalSize: Long,
        val count: Int
    ) : CleanerListItem()

    @Keep
    data class CleanerMedia(val mediaBox: MediaBox) : CleanerListItem()
}
