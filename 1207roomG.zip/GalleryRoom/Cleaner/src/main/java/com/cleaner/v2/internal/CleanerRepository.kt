package com.cleaner.v2.internal

import android.content.Context
import android.os.Environment
import android.os.SystemClock
import android.util.Log
import androidx.lifecycle.LifecycleOwner
import com.appblish.box.api.core.BoxSDK
import com.appblish.box.api.core.BoxStoreProvider
import com.appblish.box.api.model.MediaBox
import com.appblish.box.api.util.AppblishEvent
import com.appblish.box.api.util.AppblishEvent.CLEANER_PROCESS
import com.appblish.box.api.util.AppblishEvent.sendIntentEvent
import com.appblish.box.api.util.MediaDataState
import com.cleaner.v2.api.model.CleanerListItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal class CleanerRepository(val appContext: Context) {
    @OptIn(ExperimentalCoroutinesApi::class)
    private val IO = Dispatchers.IO.limitedParallelism(5)

    private val scope = CoroutineScope(SupervisorJob() + IO)
    var allCleanerMedia = emptyList<MediaBox>()

    var _duplicateLists: MediaDataState<List<CleanerListItem>> = MediaDataState.Loading
    fun getDuplicateMedias(): MediaDataState<List<CleanerListItem>> {
        return _duplicateLists
    }

    var _largeMediaLists: MediaDataState<List<CleanerListItem>> = MediaDataState.Loading
    fun getLargeMedias(): MediaDataState<List<CleanerListItem>> {
        return _largeMediaLists
    }

    var _largeVideoLists: MediaDataState<List<CleanerListItem>> = MediaDataState.Loading
    fun getLargeVideos(): MediaDataState<List<CleanerListItem>> {
        return _largeVideoLists
    }

    var _screenshotsMediaLists: MediaDataState<List<CleanerListItem>> = MediaDataState.Loading
    fun getScreenshotMedias(): MediaDataState<List<CleanerListItem>> {
        return _screenshotsMediaLists
    }

    var _blurMediaLists: MediaDataState<List<CleanerListItem>> = MediaDataState.Loading
    fun getBlurMedias(): MediaDataState<List<CleanerListItem>> {
        return _blurMediaLists
    }

    fun fetchMedia() {
        scope.launch {
            allCleanerMedia = getAllList()
            fetchDuplicateItems()
        }
    }

    suspend fun getUnProFiles(): List<MediaBox> {
        return BoxSDK.getDatabase().mediaBoxDao().getUnProcessed()
    }
//    suspend fun getUnProFiles(): List<MediaBox> =
//        withContext(Dispatchers.IO) {
//            BoxStoreProvider.mediaBoxStore.query(
//                MediaBox_.hashKey.equal("")
//            )
//                .build()
//                .use { query ->
//                    query.find()
//                }
//        }

    fun stopScanning() {
        CleanerScanController.stopScan(appContext)
    }

    fun startScanning(owner: LifecycleOwner) {
        scope.launch {
            Log.e("CleanerRepository", "startPlaceScanning:")
            val totalCount = BoxSDK.getDatabase().mediaBoxDao().getCount()
            val cleanerMediaForScan = getUnProFiles()
            if (cleanerMediaForScan.isNotEmpty()) {
                _duplicateLists = MediaDataState.Loading
                _largeMediaLists = MediaDataState.Loading
                _largeVideoLists = MediaDataState.Loading
                _blurMediaLists = MediaDataState.Loading
                _screenshotsMediaLists = MediaDataState.Loading
                val remainingCount = cleanerMediaForScan.size
                val percentage = ((totalCount - remainingCount) * 100) / totalCount
                CleanerInputCache.files = getUnProFiles()
                CleanerInputCache.totalCount = totalCount
                sendIntentEvent(CLEANER_PROCESS, percentage.toInt())
                withContext(Dispatchers.Main) {
                    CleanerScanController.startScan(
                        context = appContext,
                        owner = owner,
                        onStarted = {
                            Log.e("CleanerRepository", "startPlaceScanning: Scanning started")
                        },
                        onProgress = { progress, total ->
                            Log.e("CleanerRepository", "startPlaceScanning: onProgress $progress")
                            sendIntentEvent(CLEANER_PROCESS, progress)
                        },
                        onCompleted = {
                            Log.e("CleanerRepository", "startPlaceScanning: Scan completed")
                            fetchMedia()
                        },
                        onStopped = {
                            Log.e("CleanerRepository", "startPlaceScanning: Scan stopped")
                        }
                    )
                }

            } else {
                stopScanning()
                sendIntentEvent(CLEANER_PROCESS, 100)
            }

        }

    }


    suspend fun getAllList(): List<MediaBox> =
        withContext(Dispatchers.IO) {
            BoxSDK.getDatabase().mediaBoxDao().getAllMediaWithOrder()
        }
//    suspend fun getAllList(): List<MediaBox> =
//        withContext(Dispatchers.IO) {
//            BoxStoreProvider.mediaBoxStore.query(
//                MediaBox_.hashKey.notEqual("no_hash")
//                    .and(MediaBox_.hashKey.notEqual(""))
//            )
//                .orderDesc(MediaBox_.hashKey)
//                .build()
//                .use { query ->
//                    query.find()
//                }
//        }

    fun fetchDuplicateItems() {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope.launch {

            try {
                val t0 = SystemClock.elapsedRealtime()

                val result = withContext(Dispatchers.Default) {
                    CleanerGrouper.buildAll(allCleanerMedia)
                }

                val t1 = SystemClock.elapsedRealtime()

                Log.d("CleanerRepository", "GROUPING = ${t1 - t0} ms")

                withContext(Dispatchers.Main) {
                    val uiStart = SystemClock.elapsedRealtime()

                    _duplicateLists = MediaDataState.Success(result.duplicates)
                    _largeMediaLists = MediaDataState.Success(result.largeMedia)
                    _largeVideoLists = MediaDataState.Success(result.largeVideo)
                    _blurMediaLists = MediaDataState.Success(result.blur)
                    _screenshotsMediaLists = MediaDataState.Success(result.screenshots)

                    val uiEnd = SystemClock.elapsedRealtime()
                    Log.d("CleanerRepository", "STATE SET = ${uiEnd - uiStart} ms")

                    sendIntentEvent(AppblishEvent.ALL_CLEANER_LOADED)
                }
                /*
                val time = measureTimeMillis {

                    Log.d("CleanerRepository", "fetchDuplicateItems: start")

                    val baseList = allCleanerMedia
                    Log.d("CleanerRepository", "fetchDuplicateItems: ${baseList.size}")

                    if (baseList.isEmpty()) {
                        withContext(Dispatchers.Main) {
                            _duplicateLists = MediaDataState.Success(emptyList())
                            _largeMediaLists = MediaDataState.Success(emptyList())
                            _largeVideoLists = MediaDataState.Success(emptyList())
                            _blurMediaLists = MediaDataState.Success(emptyList())
                            _screenshotsMediaLists = MediaDataState.Success(emptyList())
                            sendIntentEvent(AppblishEvent.ALL_CLEANER_LOADED)
                        }
                        return@launch
                    }

                    // 🔹 Pre-filter ONCE
                    val videos = ArrayList<MediaBox>(baseList.size / 3)
                    val blurs = ArrayList<MediaBox>()
                    val screenshots = ArrayList<MediaBox>()

                    for (m in baseList) {
                        if (m.isVideoCheck()) videos += m
                        if (m.isBlur == 1) blurs += m
                        if (m.isScreenshot()) screenshots += m
                    }

                    // 🔥 SEQUENTIAL but OFF MAIN (IMPORTANT)
                    val duplicates =
                        DuplicateGrouper.buildDuplicateList(baseList)

                    val largeMedia =
                        DuplicateGrouper.buildGroupedList(baseList)

                    val largeVideo =
                        DuplicateGrouper.buildGroupedListVideo(videos)

                    val blur =
                        DuplicateGrouper.buildBlurGroupedList(blurs)

                    val screenshotsResult =
                        DuplicateGrouper.buildScreenshotsGroupedList(screenshots)

                    // 🔹 POST TO UI (FAST)
                    withContext(Dispatchers.Main) {
                        _duplicateLists = MediaDataState.Success(duplicates)
                        _largeMediaLists = MediaDataState.Success(largeMedia)
                        _largeVideoLists = MediaDataState.Success(largeVideo)
                        _blurMediaLists = MediaDataState.Success(blur)
                        _screenshotsMediaLists = MediaDataState.Success(screenshotsResult)
                        sendIntentEvent(AppblishEvent.ALL_CLEANER_LOADED)
                    }
                }

                Log.d(
                    "CleanerRepository",
                    "fetchDuplicateItems: done ${time}ms ${allCleanerMedia.size}"
                )*/
            } finally {
                scope.cancel()
            }
        }
    }


    internal val screenshotDir = Environment
        .getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
        .absolutePath + "/Screenshots"

    internal val screenshotDCIMDir = Environment
        .getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
        .absolutePath + "/Screenshots"

    internal fun MediaBox.isScreenshot(): Boolean {
        return bucketPath == screenshotDir || bucketPath == screenshotDCIMDir
    }
}