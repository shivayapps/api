package com.cleaner.v2.internal

import android.content.Context
import androidx.annotation.Keep
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.appblish.box.api.model.MediaBox
import com.appblish.box.api.model.ScrollGate
import com.cleaner.v2.api.model.CleanerMediaSizeCategory
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.min

@Keep
internal object CleanerInputCache {
    lateinit var files: List<MediaBox>
    var totalCount: Long = 0
}

@Keep
internal class CleanerWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {


    // =====================================================
    // ⚙️ THREADING (UI FRIENDLY)
    // =====================================================

    private val WORKERS =
        maxOf(2, min(Runtime.getRuntime().availableProcessors() - 1, 4))

    private val SCAN_DISPATCHER =
        Executors.newFixedThreadPool(WORKERS) { r ->
            Thread(r, "Cleaner-Scan").apply {
                priority = Thread.MIN_PRIORITY
            }
        }.asCoroutineDispatcher()

    private val DB_DISPATCHER =
        Executors.newSingleThreadExecutor { r ->
            Thread(r, "Cleaner-DB").apply {
                priority = Thread.MIN_PRIORITY
            }
        }.asCoroutineDispatcher()

    // =====================================================
    // 🚀 WORK ENTRY
    // =====================================================

    override suspend fun doWork(): Result = coroutineScope {

        val files = CleanerInputCache.files
        val totalCount = CleanerInputCache.totalCount

        if (files.isEmpty() || totalCount <= 0) {
            setProgress(
                workDataOf(
                    KEY_SCANNED to 100,
                    KEY_TOTAL to totalCount
                )
            )
            return@coroutineScope Result.success()
        }

        val processed =
            AtomicInteger((totalCount - files.size).toInt())
        val lastPercent = AtomicInteger(-1)

        try {

            files
                .chunked(200)
                .map { chunk ->
                    launch(SCAN_DISPATCHER) {

                        val dbBuffer = ArrayList<MediaBox>(200)
                        var localCounter = 0

                        for (file in chunk) {

                            ensureActive()
                            if (isStopped) return@launch

                            ScrollGate.waitIfScrolling()

                            // cooperative yield
                            if (++localCounter % 16 == 0) yield()

                            // ---------- HASH ----------
                            file.hashKey = file.mediaPath.md5Fast()

                            // ---------- SIZE CATEGORY ----------
                            file.sizeCategory =
                                CleanerMediaSizeCategory
                                    .fromSize(file.mediaSize)
                                    .id

                            // ---------- BLUR (ULTRA FAST) ----------
                            file.isBlur =
                                if (
                                    file.isVideoCheck() ||
                                    file.mediaSize < 100_000
                                ) {
                                    0
                                } else if (
                                    isImageBlurUltraFast(
                                        file.mediaPath,
                                        file.mediaSize
                                    )
                                ) {
                                    1
                                } else {
                                    0
                                }

                            dbBuffer += file

                            // ---------- DB BATCH ----------
                            if (dbBuffer.size == 5) {
                                val batch = ArrayList(dbBuffer)
                                dbBuffer.clear()
                                withContext(DB_DISPATCHER) {
                                    BoxHelper.updateBatch(batch)
                                }
                            }

                            // ---------- PROGRESS ----------
                            val done = processed.incrementAndGet()
                            val percent =
                                ((done.toFloat() / totalCount) * 100)
                                    .toInt()
                                    .coerceIn(0, 100)

                            if (lastPercent.getAndSet(percent) != percent) {
                                setProgress(
                                    workDataOf(
                                        KEY_SCANNED to percent,
                                        KEY_TOTAL to totalCount
                                    )
                                )
                            }
                        }

                        // flush remaining
                        if (dbBuffer.isNotEmpty()) {
                            withContext(DB_DISPATCHER) {
                                BoxHelper.updateBatch(dbBuffer)
                            }
                        }
                    }
                }
                .joinAll()

            setProgress(
                workDataOf(
                    KEY_SCANNED to 100,
                    KEY_TOTAL to totalCount
                )
            )
            Result.success()

        } catch (e: CancellationException) {
            Result.failure()
        }
    }

    // =====================================================
    // ⚡ ULTRA FAST BLUR (NO BITMAP)
    // =====================================================

    private fun isImageBlurUltraFast(
        path: String,
        fileSize: Long
    ): Boolean {

        if (fileSize < 100_000) return false

        if (!path.endsWith(".jpg", true) &&
            !path.endsWith(".jpeg", true) &&
            !path.endsWith(".png", true)
        ) return false

        val buffer = ByteArray(24 * 1024)

        val read = try {
            FileInputStream(path).use {
                it.read(buffer)
            }
        } catch (e: Exception) {
            return true
        }

        if (read <= 0) return true

        var sum = 0
        var sumSq = 0
        var changes = 0

        var last = buffer[0].toInt() and 0xFF

        for (i in 1 until read) {
            val v = buffer[i].toInt() and 0xFF
            sum += v
            sumSq += v * v
            if (kotlin.math.abs(v - last) > 18) {
                changes++
            }
            last = v
        }

        val mean = sum.toDouble() / read
        val variance =
            (sumSq.toDouble() / read) - (mean * mean)
        val changeRatio = changes.toDouble() / read

        return variance < 420.0 && changeRatio < 0.055
    }

    // =====================================================
    // ⚡ FAST MD5
    // =====================================================

    private fun String.md5Fast(): String =
        try {
            val digest = MessageDigest.getInstance("MD5")
            val buffer = ByteArray(64 * 1024)

            FileInputStream(this).use { fis ->
                while (true) {
                    val read = fis.read(buffer)
                    if (read <= 0) break
                    digest.update(buffer, 0, read)
                }
            }

            val hash = digest.digest()
            val out = CharArray(32)
            var i = 0
            for (b in hash) {
                val v = b.toInt() and 0xFF
                out[i++] = HEX[v ushr 4]
                out[i++] = HEX[v and 0x0F]
            }
            String(out)
        } catch (e: Exception) {
            "no_hash"
        }

    private val HEX = "0123456789abcdef".toCharArray()
}