package com.cleaner.v2.api.core

import androidx.annotation.Keep

@Keep
enum class CleanerOption {
    DUPLICATE,
    LARGE_MEDIA,
    LARGE_VIDEO,
    SCREENSHOT,
    WHATSAPP,
    BLUR_MEDIA
}