package com.cleaner.v2.internal

import android.content.Context
import androidx.lifecycle.LifecycleOwner
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager

const val KEY_SCANNED = "scanned"
const val KEY_TOTAL = "total"

object CleanerScanController {

    private const val WORK_NAME = "cleaner_location_worker"


    // ---------- START ----------
    fun startScan(
        context: Context,
        owner: LifecycleOwner,
        onStarted: () -> Unit = {},
        onProgress: (scanned: Int, total: Long) -> Unit = { _, _ -> },
        onCompleted: () -> Unit = {},
        onStopped: () -> Unit = {}
    ) {

        val wm = WorkManager.getInstance(context)

        val request =
            OneTimeWorkRequestBuilder<CleanerWorker>()
                .build()

        // 🔒 idempotent enqueue
        wm.enqueueUniqueWork(
            WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            request
        )

        var startedNotified = false
        var completedNotified = false
        var stoppedNotified = false

        wm.getWorkInfosForUniqueWorkLiveData(WORK_NAME)
            .observe(owner) { infos ->

                val info = infos.firstOrNull() ?: return@observe

                when (info.state) {

                    WorkInfo.State.ENQUEUED -> {
                        // waiting
                    }

                    WorkInfo.State.RUNNING -> {
                        if (!startedNotified) {
                            startedNotified = true
                            onStarted()
                        }

                        val scanned =
                            info.progress.getInt(KEY_SCANNED, 0)

                        val total =
                            info.progress.getLong(KEY_TOTAL, 0)

                        if (total > 0) {
                            onProgress(scanned, total)
                        }
                    }

                    WorkInfo.State.SUCCEEDED -> {
                        if (!completedNotified) {
                            completedNotified = true
                            onCompleted()
                        }
                    }

                    WorkInfo.State.CANCELLED,
                    WorkInfo.State.FAILED -> {
                        if (!stoppedNotified) {
                            stoppedNotified = true
                            onStopped()
                        }
                    }

                    else -> Unit
                }
            }
    }

    // ---------- STOP ----------
    fun stopScan(context: Context) {
        WorkManager.getInstance(context)
            .cancelUniqueWork(WORK_NAME)
    }

    // ---------- STATUS (optional helper) ----------
    fun isRunning(
        context: Context,
        owner: LifecycleOwner,
        callback: (Boolean) -> Unit
    ) {
        WorkManager.getInstance(context)
            .getWorkInfosForUniqueWorkLiveData(WORK_NAME)
            .observe(owner) { infos ->
                val running =
                    infos.any { it.state == WorkInfo.State.RUNNING }
                callback(running)
            }
    }
}
