package com.cleaner.v2.api.model

import androidx.annotation.Keep

@Keep
enum class CleanerMediaSizeCategory(val id: Int) {

    ABOVE_10_GB(10),

    FROM_10_GB_TO_5_GB(9),
    FROM_5_GB_TO_1_GB(8),

    FROM_1_GB_TO_500_MB(7),
    FROM_500_MB_TO_200_MB(6),
    FROM_200_MB_TO_100_MB(5),
    FROM_100_MB_TO_50_MB(4),
    FROM_50_MB_TO_10_MB(3),
    FROM_10_MB_TO_5_MB(2),
    FROM_5_MB_TO_1_MB(1);

    companion object {

        private const val MB = 1024L * 1024L
        private const val GB = 1024L * MB

        fun fromSize(bytes: Long): CleanerMediaSizeCategory =
            when {
                bytes >= 10 * GB -> ABOVE_10_GB

                bytes >= 5 * GB -> FROM_10_GB_TO_5_GB
                bytes >= 1 * GB -> FROM_5_GB_TO_1_GB

                bytes >= 500 * MB -> FROM_1_GB_TO_500_MB
                bytes >= 200 * MB -> FROM_500_MB_TO_200_MB
                bytes >= 100 * MB -> FROM_200_MB_TO_100_MB
                bytes >= 50 * MB -> FROM_100_MB_TO_50_MB
                bytes >= 10 * MB -> FROM_50_MB_TO_10_MB
                bytes >= 5 * MB -> FROM_10_MB_TO_5_MB
                else -> FROM_5_MB_TO_1_MB
            }

        fun fromId(id: Int): CleanerMediaSizeCategory =
            entries.firstOrNull { it.id == id }
                ?: FROM_5_MB_TO_1_MB
    }
}