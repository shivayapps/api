package com.cleaner.v2.api.core

import androidx.annotation.Keep
import androidx.lifecycle.LifecycleOwner
import com.appblish.box.api.util.MediaDataState
import com.cleaner.v2.api.model.CleanerListItem

@Keep
interface CleanerCore {
    fun getDuplicateMedias(): MediaDataState<List<CleanerListItem>>
    fun getLargeMedias(): MediaDataState<List<CleanerListItem>>
    fun getLargeVideos(): MediaDataState<List<CleanerListItem>>
    fun getScreenshotMedias(): MediaDataState<List<CleanerListItem>>
    fun getBlurMedias(): MediaDataState<List<CleanerListItem>>

    fun fetchMedia()
    fun startScanning(owner: LifecycleOwner)
    fun stopScanning()

}