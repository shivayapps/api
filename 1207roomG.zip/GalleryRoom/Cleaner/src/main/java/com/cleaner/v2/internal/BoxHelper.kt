package com.cleaner.v2.internal

import com.appblish.box.api.core.BoxSDK
import com.appblish.box.api.core.BoxStoreProvider
import com.appblish.box.api.model.MediaBox

//internal object BoxHelper {
//    fun updateBatch(list: List<MediaBox>) {
//        BoxStoreProvider.mediaBoxStore.putBatched(list, 500)
//    }
//}
internal object BoxHelper {

    suspend fun updateBatch(list: List<MediaBox>) {
        val dao = BoxSDK.getDatabase().mediaBoxDao()

        list.chunked(500).forEach {
            dao.insertAll(it)
        }
    }
}