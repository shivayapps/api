package com.appblish.box.api.util

const val MEMORY_PATTERN_MONTH_YEAR = "MMyyyy" //pattern for month year
const val MEMORY_PATTERN_DAY_CODE = "ddMMyyyy" //pattern for month year

val photoExtensions: Array<String>
    get() = arrayOf(
        ".jpg",
        ".png",
        ".jpeg",
        ".bmp",
        ".webp",
        ".heic",
        ".heif",
        ".apng",
        ".avif"
    )
val videoExtensions: Array<String>
    get() = arrayOf(
        ".mp4",
        ".mkv",
        ".webm",
        ".avi",
        ".3gp",
        ".mov",
        ".m4v",
        ".3gpp"
    )

val extra: Array<String>
    get() = arrayOf(
        ".gif",
    )

fun String.isImageFast() = photoExtensions.any { endsWith(it, true) }

fun String.isVideoFast() = videoExtensions.any { endsWith(it, true) }
fun String.isGif() = endsWith("gif", true)
fun String.getFilenameExtension() = substring(lastIndexOf(".") + 1)
fun String.getFilenameFromPath() = substring(lastIndexOf("/") + 1)
fun String.getParentPath() = removeSuffix("/${getFilenameFromPath()}")
fun String.toAlbumId() = hashCode().toLong()

