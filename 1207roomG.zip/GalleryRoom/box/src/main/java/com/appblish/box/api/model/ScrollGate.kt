package com.appblish.box.api.model

import androidx.annotation.Keep
import androidx.recyclerview.widget.RecyclerView

@Keep
object ScrollGate {
    @Volatile
    var scrolling = false
    private val lock = Object()

    fun onScrollStart() {
        synchronized(lock) {
            scrolling = true
        }
    }

    fun onScrollStop() {
        synchronized(lock) {
            scrolling = false
            lock.notifyAll() // 🔥 resume labeling
        }
    }

    fun waitIfScrolling() {
        synchronized(lock) {
            while (scrolling) {
                try {
                    lock.wait()
                } catch (_: InterruptedException) {}
            }
        }
    }

    enum class Mode { SCROLL, IDLE }

    @Volatile
    var mode: Mode = Mode.IDLE

    fun onScrollStateChanged(state: Int) {
        mode = if (state == RecyclerView.SCROLL_STATE_IDLE)
            Mode.IDLE
        else
            Mode.SCROLL
    }

    fun isScrolling() = mode == Mode.SCROLL
    fun isIdle() = mode == Mode.IDLE
}