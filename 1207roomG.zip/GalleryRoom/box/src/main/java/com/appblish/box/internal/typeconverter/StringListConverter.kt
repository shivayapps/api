package com.appblish.box.internal.typeconverter

import androidx.annotation.Keep
import androidx.room.TypeConverter

@Keep
class StringListConverter {

    @TypeConverter
    fun convertToDatabaseValue(list: List<String>): String {
        return list.joinToString(",")
    }

    @TypeConverter
    fun convertToEntityProperty(data: String): List<String> {
        if (data.isEmpty()) return emptyList()
        return data.split(",")
    }
}

//class StringListConverter : PropertyConverter<List<String>, String> {
//
//    override fun convertToDatabaseValue(entityProperty: List<String>?): String {
//        return entityProperty?.joinToString("||") ?: ""
//    }
//
//    override fun convertToEntityProperty(databaseValue: String?): List<String> {
//        return if (databaseValue.isNullOrEmpty()) {
//            emptyList()
//        } else {
//            databaseValue.split("||")
//        }
//    }
//}
