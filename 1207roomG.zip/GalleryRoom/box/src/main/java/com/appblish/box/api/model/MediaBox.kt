package com.appblish.box.api.model

import androidx.annotation.Keep
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Keep
@Entity(
    tableName = "media_box",
    indices = [
        Index("mediaUri"),
        Index("mediaPath"),
        Index("mediaName"),
        Index("bucketPath"),
        Index("bucketName"),
        Index("mediaExtension"),
        Index("mediaDate"),
        Index("mediaDateTaken"),
        Index("mediaSize"),
        Index("mediaDuration"),
        Index("dayCode"),
        Index("memoryYear"),
        Index("memoryMonthYear"),
        Index("albumId"),
        Index("isVideo"),
        Index("ignoreMemory"),
        Index("isImage"),
        Index("isGif"),
        Index("isPortrait"),
        Index("isAddressFetch"),
        Index("hasLocation"),
        Index("isCategoryFetch"),
        Index("isSearchTextFetch"),
        Index("hashKey")
    ]
)
data class MediaBox(

    @PrimaryKey
    var mediaId: Long,

    var mediaUri: String,
    var mediaPath: String,
    var mediaName: String,
    var bucketPath: String,
    var bucketName: String,
    var mediaExtension: String,
    var mediaDate: Long,
    var mediaDateTaken: Long,
    var mediaSize: Long,
    var mediaDuration: Long,
    var dayCode: String,
    var memoryYear: Long,
    var memoryMonthYear: String,
    var albumId: Long,

    var isVideo: Int = 0,
    var ignoreMemory: Int = 0,
    var isImage: Int = 0,
    var isGif: Int = 0,
    var isPortrait: Int = 0,
    var isAddressFetch: Int = 0,
    var hasLocation: Int = 0,

    var latitude: Double = 0.0,
    var longitude: Double = 0.0,

    var fullAddress: String = "",
    var featureName: String = "",
    var locality: String = "",
    var subLocality: String = "",
    var adminArea: String = "",
    var subAdminArea: String = "",
    var countryName: String = "",
    var countryCode: String = "",
    var postalCode: String = "",
    var thoroughfare: String = "",

    var accuracyLevel: Double = 0.0,

    var isCategoryFetch: Int = 0,
    var categories: String = "",
    var mainCategories: String = "",

    var isSearchTextFetch: Int = 0,
    var searchText: String = "",

    var hashKey: String = "",
    var isBlur: Int = 0,
    var sizeCategory: Int = 0
) {

    fun isVideoCheck() = isVideo == 1
    fun isImageCheck() = isImage == 1
    fun isGifCheck() = isGif == 1

    fun getLocationHeader(countryCodeValue: String): String {
        if (countryCodeValue.equals(countryCode, ignoreCase = true)) {
            if (locality.isNotEmpty()) return locality
            if (adminArea.isNotEmpty()) return adminArea
            return countryName
        } else {
            return countryName
        }
    }

    fun getLocationGroupKey(countryCodeValue: String): String {
        if (countryCodeValue.equals(countryCode, ignoreCase = true)) {
            if (locality.isNotEmpty()) return locality
            if (adminArea.isNotEmpty()) return adminArea
            return countryName
        } else {
            return countryName
        }
    }

    fun getGroupKey(): String {
        if (subLocality.isNotEmpty()) return subLocality
        if (locality.isNotEmpty()) return locality
        if (adminArea.isNotEmpty()) return adminArea
        return countryName
    }
}