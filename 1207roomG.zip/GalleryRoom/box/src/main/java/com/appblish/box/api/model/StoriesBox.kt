package com.appblish.box.api.model

import androidx.annotation.Keep
import androidx.room.Entity
import androidx.room.PrimaryKey

@Keep
@Entity(tableName = "stories_box")
data class StoriesBox(

    @PrimaryKey
    var storyId: Long,

    var storyKey: String,
    var storyDate: String,
    var storyDateId: Long,
    var orderIndex: Int,
    var title: String,
    var musicRawId: Int,

    var mediaIdList: List<Long>,
    var mediaSeenIdList: List<Long> = emptyList(),
)