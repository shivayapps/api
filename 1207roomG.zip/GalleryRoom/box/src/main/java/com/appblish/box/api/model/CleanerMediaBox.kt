package com.appblish.box.api.model

import androidx.annotation.Keep
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Keep
@Entity(
    tableName = "cleaner_media_box",
    indices = [
        Index("mediaPath"),
        Index("mediaName"),
        Index("mediaSize"),
        Index("mediaDate"),
        Index("isVideo"),
        Index("isImage"),
        Index("isGif"),
        Index("isScreenShots"),
        Index("hashKey")
    ]
)
data class CleanerMediaBox(

    @PrimaryKey
    var mediaId: Long,

    var mediaPath: String,
    var mediaName: String,
    var mediaSize: Long,
    var mediaDate: Long,

    var isVideo: Boolean = false,
    var isImage: Boolean = false,
    var isGif: Boolean = false,
    var isScreenShots: Boolean = false,

    var hashKey: String = "",

    var isBlur: Int = 0,

    var sizeCategory: Int = 0
)