package com.appblish.box.api.model

import androidx.annotation.Keep

@Keep
enum class MediaType { IMAGE, VIDEO, IMAGE_GIF }


@Keep
enum class Mode { COPY, MOVE, DELETE }

@Keep
enum class AlbumSortType {
    NAME,
    PATH,
    SIZE,
    LAST_MODIFIED,
}

@Keep
enum class MainMediaFilter {
    ALL,
    PHOTOS,
    VIDEO,
    GIF,
}

@Keep
enum class MediaGroupBy {
    NO_GROUP,
    LAST_MODIFIED,
    FILE_TYPE,
    EXTENSION,
    FOLDER,
}

@Keep
enum class MediaSortType {
    NAME,
    PATH,
    SIZE,
    LAST_MODIFIED,
}

@Keep
enum class SortOrder {
    ASCENDING,
    DESCENDING
}
