package com.appblish.box.api.model

import androidx.annotation.Keep
import androidx.room.Entity
import androidx.room.PrimaryKey

@Keep
@Entity(tableName = "memory_category_remote_box")
data class MemoryCategoryRemoteBox(

    @PrimaryKey
    var categoryId: Long,

    val categoryName: String,

    val categories: List<String>,

    val category: String
)