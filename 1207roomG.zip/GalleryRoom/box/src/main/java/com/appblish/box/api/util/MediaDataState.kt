package com.appblish.box.api.util

import androidx.annotation.Keep

@Keep
sealed class MediaDataState<out T> {
    @Keep
    object Loading : MediaDataState<Nothing>()

    @Keep
    object Empty : MediaDataState<Nothing>()

    @Keep
    data class Progress(val percent: Int) : MediaDataState<Nothing>()

    @Keep
    data class Success<T>(val data: T) : MediaDataState<T>()

}