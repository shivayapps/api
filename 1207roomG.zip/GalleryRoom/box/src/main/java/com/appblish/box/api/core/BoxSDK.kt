package com.appblish.box.api.core

import android.content.Context
import androidx.room.Room
import com.appblish.box.api.db.AppDatabase

object BoxSDK {

    @Volatile
    private var database: AppDatabase? = null

    fun init(context: Context) {
        database = AppDatabase.getInstance(context)
//        if (database == null) {
//            synchronized(this) {
//                if (database == null) {
//                    database = Room.databaseBuilder(
//                        context,
//                        AppDatabase::class.java,
//                        "gallery_db"
//                    ).build()
//                }
//            }
//        }
    }

    fun getDatabase(): AppDatabase {
        return database ?: throw IllegalStateException(
            "Room is not initialized. Call BoxSDK.init(context) in Application"
        )
    }

    fun isInitialized(): Boolean = database != null
}