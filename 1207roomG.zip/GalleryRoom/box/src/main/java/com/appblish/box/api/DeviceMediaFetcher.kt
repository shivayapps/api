package com.appblish.box.api

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.system.ErrnoException
import android.system.Os
import android.util.Log
import com.appblish.box.api.core.BoxSDK
import com.appblish.box.api.core.BoxStoreProvider
import com.appblish.box.api.model.MediaBox
import com.appblish.box.api.util.MEMORY_PATTERN_DAY_CODE
import com.appblish.box.api.util.MEMORY_PATTERN_MONTH_YEAR
import com.appblish.box.api.util.getFilenameExtension
import com.appblish.box.api.util.getFilenameFromPath
import com.appblish.box.api.util.getParentPath
import com.appblish.box.api.util.isGif
import com.appblish.box.api.util.toAlbumId
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.greenrobot.eventbus.EventBus
import org.joda.time.DateTime
import kotlin.system.measureTimeMillis

object DeviceMediaFetcher {

    val FIRST_FETCH_DONE = "FIRST_FETCH_DONE"
    private val TAG = "DeviceMediaHelper"

    @Volatile
    var isFetchingData = false

    @OptIn(ExperimentalCoroutinesApi::class)
    private val MEDIA_FETCHER = Dispatchers.IO

    private val fetchMutex = Mutex()


    suspend fun fetchAllMedia(context: Context) = withContext(Dispatchers.IO) {
        fetchMutex.withLock {
            if (isFetchingData) return@withLock
            isFetchingData = true

            Log.e(TAG, "fetchAllMedia start")

            val time = measureTimeMillis {
                coroutineScope {
                    awaitAll(
                        async { loadImages(context) },
                        async { loadVideos(context) }
                    )
                }
            }
            EventBus.getDefault().post(Intent(FIRST_FETCH_DONE))
            isFetchingData = false
            Log.e(TAG, "fetchAllMedia completed in $time ms")
        }
    }


    private suspend fun loadImages(context: Context) {
        queryAndInsert(
            context,
            baseUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
        )
    }

    private suspend fun loadVideos(context: Context) {
        queryAndInsert(
            context,
            baseUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
        )
    }

    private suspend fun queryAndInsert(
        context: Context,
        baseUri: Uri,
        ids: List<Long> = emptyList<Long>()
    ) = withContext(MEDIA_FETCHER) {

        val resolver = context.contentResolver

        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATA,
            MediaStore.MediaColumns.DURATION,
        )

        val selection = if (ids.isNotEmpty()) "${MediaStore.MediaColumns._ID} IN (${ids.joinToString { "?" }})" else null
        val args = if (ids.isNotEmpty()) ids.map { it.toString() }.toTypedArray() else null

        val items = ArrayList<MediaBox>(30000)
        val isVideo = baseUri == MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        resolver.query(baseUri, projection, selection, args, null)?.use { cursor ->

            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
            val dateTakenCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION)


            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val size = cursor.getLong(sizeCol)
                val mediaDuration = cursor.getLong(durationCol)
                val mediaPath = cursor.getString(dataCol)
                val mediaName = mediaPath.getFilenameFromPath()
                val bucketPath = mediaPath.getParentPath()
                val mediaDate = cursor.getLong(dateCol) * 1000
                val mediaDateTaken = try {
                    cursor.getLong(dateTakenCol) * 1000
                } catch (e: Exception) {
                    mediaDate
                }
                val dayCode = DateTime(mediaDate).toString(MEMORY_PATTERN_DAY_CODE)
                val memoryYear = DateTime(mediaDate).year
                val memoryMonthYear = DateTime(mediaDate).toString(MEMORY_PATTERN_MONTH_YEAR)
                val ignoreMemory = shouldIgnoreForMemory(bucketPath, size, mediaDuration)
                val mediaBox = MediaBox(
                    mediaId = id,
                    mediaUri = ContentUris.withAppendedId(baseUri, id).toString(),
                    mediaPath = mediaPath,
                    mediaName = mediaName,
                    bucketPath = bucketPath,
                    bucketName = bucketPath.getFilenameFromPath(),
                    albumId = bucketPath.toAlbumId(),
                    mediaDate = mediaDate,
                    mediaDateTaken = mediaDateTaken,
                    mediaDuration = mediaDuration,
                    mediaSize = size,
                    mediaExtension = mediaPath.getFilenameExtension().lowercase(),
                    isVideo = if (isVideo) 1 else 0,
                    isImage = if (isVideo) 0 else 1,
                    isGif = if (mediaPath.isGif()) 1 else 0,
                    ignoreMemory = if (ignoreMemory) 1 else 0,
                    dayCode = dayCode,
                    memoryYear = memoryYear.toLong(),
                    memoryMonthYear = memoryMonthYear
                )
                items.add(mediaBox)
            }
        }
        Log.e(TAG, "fetchAllMediaFast $baseUri load done ${items.size}")

        BoxSDK.getDatabase().runInTransaction {
            BoxSDK.getDatabase().mediaBoxDao().insertAll(items)
            Log.e(TAG, "fetchAllMediaFast $baseUri inserted ${items.size}")
        }
//        BoxSDK.getBoxStore().runInTx {
//            BoxStoreProvider.mediaBoxStore.putBatched(items, 5000)
//            Log.e(TAG, "fetchAllMediaFast $baseUri inserted ${items.size}")
//
//        }
    }


    suspend fun checkAndInsertNewMedia(context: Context, callback: suspend (Boolean) -> Unit = {}) {
        val deviceIds = fetchAllMediaIds(context)
        val dbIds = getMediaBoxMediaIds()

        val deleted = dbIds.subtract(deviceIds)
        val added = deviceIds.subtract(dbIds)

        if (deleted.isNotEmpty()) {
            deleted.chunked(900).forEach {
                deleteByIds(it)
            }
        }

        if (added.isNotEmpty()) {
            insertNewMediaByIds(context, added.toList())
        }
        Log.e(TAG, "checkAndInsertNewMedia: ${deleted.size} ${added.size}")
        callback(deleted.isNotEmpty() || added.isNotEmpty())
    }

    suspend fun deleteByIds(ids: List<Long>) {
        BoxSDK.getDatabase()
            .mediaBoxDao()
            .deleteByIds(ids)
    }

//    fun getMediaBoxMediaIds(): HashSet<Long> {
//        return BoxStoreProvider.mediaBoxStore.query().build().findIds().toHashSet()
//    }
    suspend fun getMediaBoxMediaIds(): HashSet<Long> {
        return BoxSDK.getDatabase()
            .mediaBoxDao()
            .getAllIds()
            .toHashSet()
    }

    private suspend fun fetchAllMediaIds(context: Context): HashSet<Long> = withContext(Dispatchers.IO) {
        val set = kotlin.collections.HashSet<Long>(20000)

        fun query(uri: Uri) {
            context.contentResolver.query(
                uri,
                arrayOf(MediaStore.MediaColumns._ID),
                null, null, null
            )?.use {
                val col = it.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                while (it.moveToNext()) set.add(it.getLong(col))
            }
        }

        query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI)

        set
    }

    private suspend fun insertNewMediaByIds(context: Context, ids: List<Long>) {
        if (ids.isEmpty()) return

        ids.chunked(900).forEach { chunk ->
            coroutineScope {
                awaitAll(
                    async { loadImagesByIds(context, chunk) },
                    async { loadVideosByIds(context, chunk) }
                )
            }
        }
    }

    private suspend fun loadImagesByIds(context: Context, ids: List<Long>) {
        queryAndInsert(
            context,
            baseUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            ids = ids
        )
    }

    private suspend fun loadVideosByIds(context: Context, ids: List<Long>) {
        queryAndInsert(
            context,
            baseUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            ids = ids
        )
    }

    fun removeMediaStoreRowsByIdsFast(
        context: Context,
        ids: LongArray,
        size: Int,
        batchSize: Int = 500
    ): Int {

        if (size == 0) return 0

        val resolver = context.contentResolver
        val baseUri = MediaStore.Files.getContentUri("external")

        var deleted = 0
        var index = 0

        // Reuse buffer to avoid allocations
        val buffer = LongArray(batchSize)

        for (i in 0 until size) {
            buffer[index++] = ids[i]

            if (index == batchSize) {
                deleted += bulkDeleteIds(resolver, baseUri, buffer, index)
                index = 0
            }
        }

        // final flush
        if (index > 0) {
            deleted += bulkDeleteIds(resolver, baseUri, buffer, index)
        }

        return deleted
    }

    private fun bulkDeleteIds(
        resolver: ContentResolver,
        baseUri: Uri,
        ids: LongArray,
        size: Int
    ): Int {
        if (size == 0) return 0

        val selection = buildString(size * 6) {
            append(MediaStore.MediaColumns._ID)
            append(" IN (")

            for (i in 0 until size) {
                if (i > 0) append(',')
                append(ids[i])
            }
            append(')')
        }

        return try {
            resolver.delete(baseUri, selection, null)
        } catch (_: Exception) {
            0
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    suspend fun forEachMissingFastMedia(
        mediaList: List<MediaBox>,
        batchSize: Int = 500,
        parallelism: Int = 3,
        onBatch: (LongArray, Int) -> Unit
    ) {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope.launch {
            try {
                // Force background-only execution
                val dispatcher = Dispatchers.IO.limitedParallelism(parallelism)

                // Fixed-size shared buffer (bounded memory)
                val sharedBuffer = LongArray(batchSize)
                var sharedIndex = 0
                val lock = Any()

                // Chunked iteration (no list copy, just views)
                val chunkSize = 1_000
                val total = mediaList.size
                var start = 0

                while (start < total) {
                    val end = minOf(start + chunkSize, total)
                    val chunk = mediaList.subList(start, end) // ⚠️ view, not copy
                    start = end

                    launch(dispatcher) {
                        // Thread-local buffer (small + short-lived)
                        val localBuffer = LongArray(batchSize)
                        var localIndex = 0

                        for (media in chunk) {
                            ensureActive() // cancel-safe

                            val path = media.mediaPath
                            if (path.isEmpty() || !path.isFileExists()) {
                                localBuffer[localIndex++] = media.mediaId

                                if (localIndex == batchSize) {
                                    synchronized(lock) {
                                        System.arraycopy(localBuffer, 0, sharedBuffer, sharedIndex, localIndex)
                                        sharedIndex += localIndex

                                        if (sharedIndex >= batchSize) {
                                            onBatch(sharedBuffer, sharedIndex)
                                            sharedIndex = 0
                                        }
                                    }
                                    localIndex = 0
                                }
                            }
                        }

                        if (localIndex > 0) {
                            synchronized(lock) {
                                System.arraycopy(localBuffer, 0, sharedBuffer, sharedIndex, localIndex)
                                sharedIndex += localIndex

                                if (sharedIndex >= batchSize) {
                                    onBatch(sharedBuffer, sharedIndex)
                                    sharedIndex = 0
                                }
                            }
                        }
                    }
                    if (sharedIndex > 0) {
                        onBatch(sharedBuffer, sharedIndex)
                    }
                }
            } finally {
                scope.cancel()

            }
        }
    }

    fun shouldIgnoreForMemory(
        bucketPath: String?,
        sizeBytes: Long,
        durationMs: Long // 0 for images
    ): Boolean {

        val path = bucketPath?.lowercase() ?: ""

        // ------------------------------------------------
        // 1. Screenshots
        // ------------------------------------------------
        if (path.contains("screenshot")) return true

        // ------------------------------------------------
        // 2. Downloads
        // ------------------------------------------------
        if (path.contains("download")) return true

        // ------------------------------------------------
        // 3. Cache / temp media (hard ignore)
        // ------------------------------------------------
        if (
            path.contains("android/data") ||
            path.contains("cache/")
        ) return true

        // ------------------------------------------------
        // 4. Status / temporary media
        // ------------------------------------------------
        if (
            path.contains(".statuses") ||
            path.contains("/status")
        ) return true

        // ------------------------------------------------
        // 5. Screen recordings
        // ------------------------------------------------
        if (
            path.contains("screenrecord") ||
            path.contains("screen_record")
        ) return true

        // ------------------------------------------------
        // 6. Very small files (icons, stickers)
        // ------------------------------------------------
        if (sizeBytes in 1 until 50_000) return true // < 50 KB

        // ------------------------------------------------
        // 7. Very short videos
        // ------------------------------------------------
        if (durationMs in 1 until 5_000) return true // < 5 sec

        // ------------------------------------------------
        // 8. Allow memory-worthy folders ONLY
        // ------------------------------------------------
        val isCameraMedia =

            // WhatsApp camera
            path.contains("whatsapp images") ||
                    path.contains("whatsapp video") ||

                    // Telegram camera
                    path.contains("telegram images") ||
                    path.contains("telegram video") ||

                    // Facebook SAVED media (not cache)
                    path.contains("facebook/photos") ||
                    path.contains("facebook/videos") ||
                    path.contains("facebook/camera")

        return isCameraMedia

        // ------------------------------------------------
        // ✅ Memory worthy
        // ------------------------------------------------
    }

    fun String.isFileExists(): Boolean {
        return try {
            Os.lstat(this) // Only checks if the file exists, no extra overhead
            true
        } catch (e: ErrnoException) {
            false
        }
    }
}