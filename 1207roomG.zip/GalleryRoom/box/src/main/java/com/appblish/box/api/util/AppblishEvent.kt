package com.appblish.box.api.util

import android.content.Intent
import org.greenrobot.eventbus.EventBus

object AppblishEvent {
    val ALL_MEDIA_LOADED = "ALL_MEDIA_LOADED"
    val ALL_ALBUM_LOADED = "ALL_ALBUM_LOADED"
    val ALL_VIDEO_ALBUM_LOADED = "ALL_VIDEO_ALBUM_LOADED"
    val ALL_TIME_LINE_LOADED = "ALL_TIME_LINE_LOADED"
    val ALL_PLACES_LOADED = "ALL_PLACES_LOADED"
    val ALL_PRIVATE_LOADED = "ALL_PRIVATE_LOADED"
    val ALL_PRIVATE_RECYCLE_BIN_LOADED = "ALL_PRIVATE_RECYCLE_BIN_LOADED"
    val ALL_RECYCLE_BIN_LOADED = "ALL_RECYCLE_BIN_LOADED"
    val ALL_MEMORIES_LOADED = "ALL_MEMORIES_LOADED"
    val ALL_STORIES_LOADED = "ALL_STORIES_LOADED"
    val CLEANER_PROCESS = "CLEANER_PROCESS"
    val ALL_CLEANER_LOADED = "ALL_CLEANER_LOADED"

    fun sendIntentEvent(type: String) {
        EventBus.getDefault().post(Intent(type))
    }

    fun sendIntentEvent(type: String, process: Int) {
        EventBus.getDefault().post(
            Intent(type).putExtra(
                CLEANER_PROCESS, process
            )
        )
    }

}