package com.appblish.box.api.db

import android.content.Context
import android.os.Environment
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.appblish.box.api.model.CleanerMediaBox
import com.appblish.box.api.model.MediaBox
import com.appblish.box.api.model.MemoriesBox
import com.appblish.box.api.model.MemoryCategoryRemoteBox
import com.appblish.box.api.model.StoriesBox
import java.io.File

@Database(
    entities = [MediaBox::class, CleanerMediaBox::class, MemoryCategoryRemoteBox::class, StoriesBox::class, MemoriesBox::class],
    version = 1
)

@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun mediaBoxDao(): MediaBoxDao
    companion object {
        private var instance: AppDatabase? = null

        @Synchronized
        fun getInstance(ctx: Context): AppDatabase {
            if (instance == null) {
                instance = Room.databaseBuilder(
                    ctx.applicationContext,
                    AppDatabase::class.java,
//                    Constant.ROOT_PATH + "/.Gallery/db_category.encrypt",
                    "gallery_db"
                )
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration().build()
            }
            return instance!!
        }
    }
}