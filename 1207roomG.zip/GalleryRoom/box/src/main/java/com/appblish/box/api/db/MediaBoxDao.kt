package com.appblish.box.api.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.appblish.box.api.model.MediaBox
import com.appblish.box.api.model.MemoriesBox
import com.appblish.box.api.model.MemoryCategoryRemoteBox
import com.appblish.box.api.model.StoriesBox

@Dao
interface MediaBoxDao {

    @Query("""
        SELECT * FROM media_box
        WHERE isImage = 1
        AND hasLocation = 0
        AND isAddressFetch = 0
    """)
    suspend fun getImagesWithoutLocation(): List<MediaBox>

    @Update
    suspend fun updateMedia(media: MediaBox)

    @Query("""
        SELECT * FROM media_box
        WHERE isAddressFetch = 1
        AND hasLocation = 1
        ORDER BY mediaDate DESC
    """)
    suspend fun getAllList(): List<MediaBox>

    @Query("""
        SELECT * FROM media_box
        WHERE memoryYear = :memoryYear
        AND LOWER(mainCategories) LIKE '%' || :category || '%'
    """)
    suspend fun getCategoriesMedia(
        category: String,
        memoryYear: Int
    ): List<MediaBox>
    @Query("""
        SELECT * FROM media_box
        WHERE mediaDate >= :startTime 
        AND mediaDate <= :endTime
        ORDER BY mediaDate DESC
    """)
    suspend fun getPlacesImages(startTime: Long, endTime: Long): List<MediaBox>


    @Query("""
        SELECT * FROM media_box
        WHERE memoryYear = :memoryYear
        ORDER BY mediaDate DESC
    """)
    suspend fun getYearPhotos(memoryYear: Long): List<MediaBox>
    @Query("""
        SELECT * FROM media_box
        WHERE memoryMonthYear = :memoryMonthYear
        ORDER BY mediaDate DESC
    """)
    suspend fun getMonthYearPhotos(memoryMonthYear: String): List<MediaBox>

    @Query("""
        SELECT * FROM media_box
        WHERE dayCode = :dayCode
        ORDER BY mediaDate DESC
    """)
    suspend fun getDayCodePhotos(dayCode: String): List<MediaBox>

    @Query("""
        SELECT * FROM media_box
        WHERE memoryMonthYear = :memoryMonthYear
        AND isPortrait = 1
        ORDER BY mediaDate DESC
    """)
    suspend fun getMonthYearPortraitPhotos(memoryMonthYear: String): List<MediaBox>
    @Query("""
        SELECT * FROM media_box 
        WHERE memoryYear = :memoryYear 
        AND isPortrait = 1
        ORDER BY mediaDate DESC
    """)
    suspend fun getYearPortraitPhotos(memoryYear: Int): List<MediaBox>

    @Query("DELETE FROM stories_box WHERE storyId = :storyId")
    suspend fun deleteStory(storyId: Long)

    @Query("SELECT * FROM stories_box WHERE storyId = :storyId")
    suspend fun getStory(storyId: Long): StoriesBox?

    @Update
    suspend fun updateStory(story: StoriesBox)

    @Query("SELECT * FROM memories_box WHERE memoryId = :memoryId")
    suspend fun getMemory(memoryId: Long): MemoriesBox?

    @Update
    suspend fun updateMemory(memory: MemoriesBox)

    @Query("UPDATE memories_box SET title = :title WHERE memoryId = :memoryId")
    suspend fun updateMemoryTitle(memoryId: Long, title: String)

    @Query("UPDATE memories_box SET musicRawId = :rawId WHERE memoryId = :memoryId")
    suspend fun updateMemoryMusic(memoryId: Long, rawId: Int)

    @Query("DELETE FROM memories_box WHERE memoryId = :memoryId")
    suspend fun deleteMemory(memoryId: Long)

    @Query("UPDATE memories_box SET isFavourite = 1 WHERE memoryId = :memoryId")
    suspend fun addToFavourite(memoryId: Long)

    @Query("UPDATE memories_box SET isFavourite = 0 WHERE memoryId = :memoryId")
    suspend fun removeFromFavourite(memoryId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: StoriesBox)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStories(stories: List<StoriesBox>)

    @Query("SELECT * FROM stories_box WHERE storyDateId = :storyDateId")
    suspend fun getStoriesByDateId(storyDateId: Long): List<StoriesBox>

    @Query("SELECT * FROM stories_box WHERE storyId IN (:ids)")
    suspend fun getStoryByIds(ids: List<Long>): List<StoriesBox>

    @Update
    suspend fun update(story: StoriesBox)

    @Query("DELETE FROM stories_box WHERE storyId IN (:ids)")
    suspend fun deleteStoryByIds(ids: List<Long>)

    @Query("SELECT * FROM media_box WHERE mediaId IN (:ids)")
    suspend fun getByIds(ids: List<Long>): List<MediaBox>

    @Query("SELECT * FROM memories_box")
    suspend fun getAllMemory(): List<MemoriesBox>

    @Query("SELECT * FROM memories_box WHERE memoryId IN (:ids)")
    suspend fun getMemoryByIds(ids: List<Long>): List<MemoriesBox>

    @Update
    suspend fun update(memory: MemoriesBox)

    @Query("DELETE FROM memories_box WHERE memoryId IN (:ids)")
    suspend fun deleteMemoryByIds(ids: List<Long>)

    @Query("""
        SELECT * FROM media_box
        WHERE mediaDate < :beforeTime
        AND isImage = 1
        AND ignoreMemory = 0
    """)
    suspend fun getMediaBeforeDays(beforeTime: Long): List<MediaBox>

    @Query("UPDATE media_box SET isPortrait = :isPortrait WHERE mediaId = :mediaId")
    suspend fun updatePortrait(mediaId: Long, isPortrait: Int)

    @Query("""
SELECT * FROM media_box
WHERE isPortrait = 0
AND isImage = 1
""")
    suspend fun getAllNotPortraitCheck(): List<MediaBox>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<MemoryCategoryRemoteBox>)

    @Query("SELECT * FROM memory_category_remote_box")
    suspend fun getAllMemoryCategories(): List<MemoryCategoryRemoteBox>

    @Query("SELECT EXISTS(SELECT 1 FROM memories_box WHERE memoryId = :memoryId)")
    suspend fun isMemoryExists(memoryId: Long): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertMemory(memory: MemoriesBox)

    @Query("""
SELECT * FROM media_box
WHERE isGif = 0
AND ignoreMemory = 0
ORDER BY mediaDate DESC
""")
    suspend fun getAllMemoryMedia(): List<MediaBox>

    @Query("""
        SELECT * FROM media_box
        WHERE mediaDate < :beforeTime
        AND isImage = 1
        AND isAddressFetch = 1
        AND ignoreMemory = 0
    """)
    suspend fun getMediaBeforeDaysWithAddress(beforeTime: Long): List<MediaBox>

    @Query("SELECT * FROM media_box WHERE hashKey = ''")
    suspend fun getUnProcessed(): List<MediaBox>

    @Query("SELECT COUNT(*) FROM media_box")
    suspend fun getCount(): Long

    @Query("SELECT mediaId FROM media_box")
    suspend fun getAllIds(): List<Long>


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(media: MediaBox)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(list: List<MediaBox>)

    @Query("SELECT * FROM media_box")
    suspend fun getAll(): List<MediaBox>

    @Delete
    suspend fun delete(media: MediaBox)


    @Query("""
        SELECT * FROM media_box
        WHERE (:albumId = 0 OR albumId = :albumId)
        AND (:filter = 'ALL'
            OR (:filter = 'PHOTOS' AND isImage = 1)
            OR (:filter = 'VIDEO' AND isVideo = 1)
            OR (:filter = 'GIF' AND isGif = 1))
        ORDER BY
        CASE WHEN :sort = 'NAME' THEN mediaName END ASC,
        CASE WHEN :sort = 'PATH' THEN mediaPath END ASC,
        CASE WHEN :sort = 'SIZE' THEN mediaSize END ASC,
        CASE WHEN :sort = 'DATE' THEN mediaDate END ASC
    """)
    suspend fun getMediaSorted(
        albumId: Long,
        filter: String,
        sort: String
    ): List<MediaBox>


    @Query("SELECT mediaPath FROM media_box")
    suspend fun getAllMediaPaths(): List<String>

    @Query("SELECT * FROM media_box ORDER BY mediaDate DESC")
    suspend fun getAllMediaWithOrder(): List<MediaBox>

    @Query("SELECT * FROM media_box WHERE mediaPath = :path LIMIT 1")
    fun getMediaByPath(path: String): MediaBox?

    @Query("SELECT mediaUri FROM media_box WHERE albumId = :albumId")
    suspend fun getMediaUris(albumId: Long): List<String>

    @Query("SELECT mediaPath FROM media_box WHERE mediaUri = :uri LIMIT 1")
    fun getPathFromUri(uri: String): String?

    @Query("SELECT mediaUri FROM media_box WHERE mediaPath = :path LIMIT 1")
    fun getUriFromPath(path: String): String?

    @Query("DELETE FROM media_box WHERE mediaPath = :path")
    suspend fun deleteByPath(path: String): Int

    @Query("UPDATE media_box SET mediaDate = :date WHERE mediaPath = :path")
    fun updateDate(path: String, date: Long)

    @Query("DELETE FROM media_box WHERE mediaId IN (:ids)")
    fun deleteByIds(ids: List<Long>)
}