package com.appblish.box.api.core

import androidx.annotation.Keep
import com.appblish.box.api.db.AppDatabase
import com.appblish.box.api.db.MediaBoxDao
//import com.appblish.box.api.db.dao.MediaBoxDao
//import com.appblish.box.api.db.dao.MemoriesDao
//import com.appblish.box.api.db.dao.StoriesDao
//import com.appblish.box.api.db.dao.MemoryCategoryDao

@Keep
object BoxStoreProvider {

    private val db: AppDatabase
        get() = BoxSDK.getDatabase()

    val mediaBoxStore: MediaBoxDao
        get() = db.mediaBoxDao()

//    val memeryBox: MemoriesDao
//        get() = db.memoriesDao()
//
//    val storyBox: StoriesDao
//        get() = db.storiesDao()
//
//    val memoryCategoryRemoteBox: MemoryCategoryDao
//        get() = db.memoryCategoryDao()
}