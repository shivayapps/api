package com.appblish.box.api.model

import androidx.annotation.Keep
import androidx.room.Entity
import androidx.room.PrimaryKey

@Keep
@Entity(tableName = "memories_box")
data class MemoriesBox(

    @PrimaryKey
    var memoryId: Long,

    var memoryKey: String,
    var title: String,
    var subTitle: String,
    var categoryKey: String,
    var musicRawId: Int,
    var fontId: Int,
    var extra: String,
    var createdTime: Long,
    var isFavourite: Boolean = false,
    var isSeen: Boolean = false,

    var mediaIdList: List<Long>
)