package com.appblish.box.internal.typeconverter

import androidx.annotation.Keep
import androidx.room.TypeConverter

class LongListConverter {

    @TypeConverter
    fun convertToDatabaseValue(list: List<Long>): String {
        return list.joinToString(",")
    }

    @TypeConverter
    fun convertToEntityProperty(data: String): List<Long> {
        if (data.isEmpty()) return emptyList()
        return data.split(",").map { it.toLong() }
    }
}

