plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.jetbrains.kotlin.android)
    alias(libs.plugins.ksp)
//    alias(libs.plugins.maven.publish)
    //alias(libs.plugins.objectbox)
}

android {
    namespace = "com.appblish.box"
    compileSdk = 36

    defaultConfig {
        minSdk = 30

        consumerProguardFiles("consumer-rules.pro")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    api(libs.gson)
//    implementation(libs.objectbox.kotlin)
    implementation(libs.joda.time)
    implementation(libs.eventbus)

    implementation("androidx.room:room-runtime:2.8.4")
    implementation("androidx.room:room-ktx:2.8.4")
    ksp("androidx.room:room-compiler:2.8.4")
//    implementation("androidx.room:room-runtime:2.6.1")
//    implementation("androidx.room:room-ktx:2.6.1")
//    ksp("androidx.room:room-compiler:2.6.1")
}


//publishing {
//    publications {
//        create<MavenPublication>("box") {
//            groupId = "com.appblish.gallery"
//            artifactId = "box"
//            version = "1.1.3"
//            artifact("./build/outputs/aar/box-release.aar")
//        }
//    }
//    repositories {
//        maven {
//            name = "GitLab"
//            url = uri("https://gitlab.com/api/v4/projects/77713169/packages/maven")
//            credentials {
//                username = "GalleryCore"
//                password = "gldt-rLmrq7_pPYihg9EvzDFZ"
//            }
//        }
//    }
//}