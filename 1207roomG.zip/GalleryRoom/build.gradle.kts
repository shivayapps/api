//buildscript {
//    dependencies {
//        classpath(libs.objectbox.gradle.plugin)
//    }
//}
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.jetbrains.kotlin.android) apply false
    alias(libs.plugins.ksp).apply(false)
    alias(libs.plugins.kotlinSerialization).apply(false)
    id("com.google.gms.google-services") version "4.4.4" apply false
    id("com.google.firebase.crashlytics") version "3.0.6" apply false
    alias(libs.plugins.android.library) apply false
}