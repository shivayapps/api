-dontwarn java.lang.**

-keep class java.lang.invoke.** { *; }