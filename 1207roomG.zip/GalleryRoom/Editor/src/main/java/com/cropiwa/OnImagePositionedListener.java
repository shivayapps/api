package com.cropiwa;

import android.graphics.RectF;


interface OnImagePositionedListener {
    void onImagePositioned(RectF imageRect);
}
