package com.cropiwa.config;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;

import androidx.annotation.FloatRange;

import com.editify_editor.photo.editor.R;

import java.util.ArrayList;
import java.util.List;

public class CropIwaImageViewConfig {

    public static final int SCALE_UNSPECIFIED = -1;
    private static final float DEFAULT_MIN_SCALE = 0.7f;
    private static final float DEFAULT_MAX_SCALE = 3f;
    private float maxScale;
    private float minScale;
    private boolean isScaleEnabled;
    private boolean isTranslationEnabled;
    private float scale;
    private InitialPosition initialPosition;
    private List<ConfigChangeListener> configChangeListeners;

    public CropIwaImageViewConfig() {
        configChangeListeners = new ArrayList<>();
    }

    @SuppressWarnings("Range")
    public static CropIwaImageViewConfig createDefault() {
        return new CropIwaImageViewConfig()
                .setMaxScale(DEFAULT_MAX_SCALE)
                .setMinScale(DEFAULT_MIN_SCALE)
                .setImageTranslationEnabled(true)
                .setImageScaleEnabled(true)
                .setScale(SCALE_UNSPECIFIED);
    }

    public static CropIwaImageViewConfig createFromAttributes(Context c, AttributeSet attrs) {
        CropIwaImageViewConfig config = createDefault();
        if (attrs == null) {
            return config;
        }
        TypedArray ta = c.obtainStyledAttributes(attrs, R.styleable.CropIwaView);
        try {
            config.setMaxScale(ta.getFloat(
                    R.styleable.CropIwaView_ci_max_scale,
                    config.getMaxScale()));
            config.setImageTranslationEnabled(ta.getBoolean(
                    R.styleable.CropIwaView_ci_translation_enabled,
                    config.isImageTranslationEnabled()));
            config.setImageScaleEnabled(ta.getBoolean(
                    R.styleable.CropIwaView_ci_scale_enabled,
                    config.isImageScaleEnabled()));
            config.setImageInitialPosition(InitialPosition.values()[
                    ta.getInt(R.styleable.CropIwaView_ci_initial_position, 0)]);
        } finally {
            ta.recycle();
        }
        return config;
    }

    public float getMaxScale() {
        return maxScale;
    }

    public CropIwaImageViewConfig setMaxScale(@FloatRange(from = 0.001) float maxScale) {

        this.maxScale = maxScale;
        return this;
    }

    public float getMinScale() {
        return minScale;
    }

    public CropIwaImageViewConfig setMinScale(@FloatRange(from = 0.001) float minScale) {
        this.minScale = minScale;
        return this;
    }

    public boolean isImageScaleEnabled() {
        return isScaleEnabled;
    }

    public CropIwaImageViewConfig setImageScaleEnabled(boolean scaleEnabled) {
        this.isScaleEnabled = scaleEnabled;
        return this;
    }

    public boolean isImageTranslationEnabled() {
        return isTranslationEnabled;
    }

    public CropIwaImageViewConfig setImageTranslationEnabled(boolean imageTranslationEnabled) {
        this.isTranslationEnabled = imageTranslationEnabled;
        return this;
    }

    public InitialPosition getImageInitialPosition() {
        return initialPosition;
    }

    public CropIwaImageViewConfig setImageInitialPosition(InitialPosition initialPosition) {
        this.initialPosition = initialPosition;
        return this;
    }

    public float getScale() {
        return scale;
    }

    public CropIwaImageViewConfig setScale(@FloatRange(from = 0.01, to = 1f) float scale) {
        this.scale = scale;
        return this;
    }

    public void addConfigChangeListener(ConfigChangeListener configChangeListener) {
        if (configChangeListener != null) {
            configChangeListeners.add(configChangeListener);
        }
    }

    public void removeConfigChangeListener(ConfigChangeListener configChangeListener) {
        configChangeListeners.remove(configChangeListener);
    }

    public void apply() {
        for (ConfigChangeListener listener : configChangeListeners) {
            listener.onConfigChanged();
        }
    }

}
