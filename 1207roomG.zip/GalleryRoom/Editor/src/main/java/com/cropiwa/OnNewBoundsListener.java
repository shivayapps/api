package com.cropiwa;

import android.graphics.RectF;

interface OnNewBoundsListener {
    void onNewBounds(RectF bounds);
}
