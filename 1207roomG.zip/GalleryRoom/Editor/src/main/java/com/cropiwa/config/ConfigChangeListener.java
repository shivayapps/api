package com.cropiwa.config;


public interface ConfigChangeListener {
    void onConfigChanged();
}
