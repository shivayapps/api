package com.cropiwa.config;

public enum InitialPosition {
    CENTER_INSIDE,
    CENTER_CROP
}
