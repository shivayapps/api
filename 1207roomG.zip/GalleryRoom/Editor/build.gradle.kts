plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
//    alias(libs.plugins.maven.publish)
}

android {
    namespace = "com.editify_editor.photo.editor"
    compileSdk = 35

    defaultConfig {
        minSdk = 30
        vectorDrawables.useSupportLibrary = true
        consumerProguardFiles("consumer-rules.pro")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }



    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
}

configurations.all {
    resolutionStrategy {
        exclude(group = "com.android.support", module = "appcompat-v7")
        exclude(group = "com.android.support", module = "support-v4")
        exclude(group = "com.android.support", module = "support-compat")
        exclude(group = "com.android.support", module = "support-media-compat")
        exclude(group = "com.android.support", module = "support-core-utils")
    }
}

dependencies {
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)

    implementation("androidx.palette:palette:1.0.0")
    implementation("androidx.exifinterface:exifinterface:1.3.6")

    // AndroidX
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.cardview:cardview:1.0.0")
    implementation("androidx.vectordrawable:vectordrawable-animated:1.1.0")
    implementation("androidx.browser:browser:1.8.0")
    implementation("androidx.multidex:multidex:2.0.1")
    implementation("androidx.work:work-runtime-ktx:2.9.0")
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("androidx.preference:preference-ktx:1.2.1")
    implementation("androidx.annotation:annotation:1.8.2")

    // Material
    implementation("com.balysv:material-ripple:1.0.2") { exclude(group = "com.android.support") }


    // UI / Widgets
    implementation("com.github.siyamed:android-shape-imageview:0.9.3") {
        exclude(group = "com.android.support")
    }
    implementation("de.hdodenhof:circleimageview:3.1.0")
    implementation("me.relex:circleindicator:2.1.6")

    // Image / Graphics
    implementation("org.wysaid:gpuimage-plus:3.1.0-16k")
    implementation("com.squareup.picasso:picasso:2.8")
    implementation("com.github.bumptech.glide:glide:4.16.0")
    annotationProcessor("com.github.bumptech.glide:compiler:4.16.0")

    // Animations
    implementation("com.airbnb.android:lottie:6.5.2")
    implementation("com.facebook.shimmer:shimmer:0.5.0")

    // Utils
    implementation("org.greenrobot:eventbus:3.3.1")
    implementation("io.reactivex.rxjava2:rxjava:2.2.21")
    implementation("com.karumi:dexter:6.2.3")
    implementation("com.github.ConsultantPlus-Mobile:KeyboardHeightProvider:v1.0.0")
    implementation(libs.android.sdp)
    implementation(libs.android.ssp)
//    implementation("com.appblish.cropview:v1:1.0.1")
    implementation(project(":Appblishcropview"))
}


//afterEvaluate {
//    publishing {
//        publications {
//            create<MavenPublication>("v1") {
//                groupId = "com.appblish.editor"
//                artifactId = "v1"
//                version = "1.0.1"
//                artifact("./build/outputs/aar/Editor-release.aar")
//            }
//        }
//        repositories {
//            maven {
//                name = "GitLab"
//                url = uri("https://gitlab.com/api/v4/projects/77924394/packages/maven")
//                credentials {
//                    username = "AppblishEditor"
//                    password = "gldt-J-e_shoDhunft2nd_nCM"
//                }
//            }
//        }
//    }
//}