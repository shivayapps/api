package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogAlbumDeatilsBinding
import com.gallery.photo.image.video.databinding.DialogDeatilsBinding
import com.gallery.photo.image.video.extension.beGoneIf
import com.gallery.photo.image.video.model.AlbumData
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.utils.Utils
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Objects

class AlbumDetailsDialog(var pictureData: AlbumData, val isFromPrivate: Boolean = false) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogAlbumDeatilsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogAlbumDeatilsBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {

        intListener()
        bindingDialog.llPath.beGoneIf(isFromPrivate)

        val formatDetails = SimpleDateFormat("dd/MM/yyyy, hh:mm aa", Locale.ENGLISH)
        bindingDialog.txtName.text = pictureData.title
        bindingDialog.txtPath.text = pictureData.folderPath
        val strDate = formatDetails.format(pictureData.date)

        bindingDialog.txtTime.text = strDate
        val size=getFolderSize(File(pictureData.folderPath))
        bindingDialog.txtSize.text = Formatter.formatShortFileSize(requireActivity(), size)
        bindingDialog.txtFileCount.text = "${pictureData.pictureData.size}"

    }


    fun getFolderSize(dir: File): Long {
        var size: Long = 0
        dir.listFiles()?.let {
            for (file in it) {
                size += if (file.isFile) {
                    // System.out.println(file.getName() + " " + file.length());
                    file.length()
                } else getFolderSize(file)
            }
        }

        return size
    }

    private fun intListener() {

        bindingDialog.btnOK.setOnClickListener {
            dismiss()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}