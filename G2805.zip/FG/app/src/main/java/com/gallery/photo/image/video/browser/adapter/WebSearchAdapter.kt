package com.gallery.photo.image.video.browser.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R


class WebSearchAdapter constructor(
    var arrayList: ArrayList<String>,
    var activity: Activity,
    var view: View
) : RecyclerView.Adapter<WebSearchAdapter.MyViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view: View = LayoutInflater.from(activity).inflate(R.layout.item_search_list, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.tv_link.text = arrayList[position]
        holder.itemView.setOnClickListener {
            val ll_search: LinearLayout = view.findViewById(R.id.ll_search)
            val webs: WebView = view.findViewById(R.id.webs)
            ll_search.visibility = View.GONE
            webs.visibility = View.VISIBLE
            val url: String = holder.tv_link.text.toString().trim { it <= ' ' }
            webs.loadUrl(url)
        }
    }

    override fun getItemCount(): Int {
        return arrayList.size
    }

    inner class MyViewHolder constructor(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tv_link: TextView

        init {
            tv_link = itemView.findViewById(R.id.tv_link)
        }
    }
}