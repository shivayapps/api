package com.gallery.photo.image.video.utils

import android.content.Context
import android.provider.MediaStore
import android.util.Log

public class  FileCursorHelper {
    fun getAllFilesInDirectory(context: Context) {
        // Define the projection (which columns to retrieve) and the selection (which files to include).
        val projection = arrayOf(MediaStore.Files.FileColumns.DATA)
//        val selection = MediaStore.Files.FileColumns.DATA + " like ?"
//        val selectionArgs = arrayOf("$directoryPath%") // Add the path of your directory here.

        // Create a cursor to query the MediaStore for files in the specified directory.
        context.contentResolver.query(
            MediaStore.Files.getContentUri("external"),
            projection,
            null,
            null,
            null
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val filePath =
                    cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA))
                // Do something with the file path, e.g., print it or store it in a list.
                Log.e("getImages", "FileCursorHelper File Path: $filePath")
            }
        }
    }
}