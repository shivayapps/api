package com.adconfig.adsutil.admob

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.View
import android.widget.FrameLayout
import com.adconfig.adsutil.utils.isOnline
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdValue
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.OnPaidEventListener

@SuppressLint("All")
object BannerAds {
    private const val TAG = "ADMOB---BannerAds+++++"
    var mAdView: AdView? = null
    var isRequestSend = false
//    private var f_request = "f_request"
//    private var f_load = "f_load"
//    private var f_fail_to_load = "f_fail_to_load"
//    private var f_click = "f_click"
//    private var f_impression = "f_impression"

    /**
     * This function is used to display the banner ad into the frame layout this all variables should be passed compulsory,
     * the banner ad type get from firebase remote config or the developer have to pass it as string.
     *
     *
     * AdType Cases are like :
     * 1. adaptive_banner
     * 2. large_banner
     */
    fun loadAdmobBannerAds(
        activity: Activity,
        frameLayout_admob_banner: FrameLayout,
//        adSizeType: String,
        adId: String
    ) {
        isRequestSend = true
        loadBannerAds(activity, frameLayout_admob_banner, adId)
    }

    @SuppressLint("LongLogTag")
    private fun loadBannerAds(
        activity: Activity,
        frameLayout_admob_banner: FrameLayout,
//        adSizeType: String,
        adId: String
    ) {
        if (activity.isOnline()) {


            mAdView = AdView(activity)
            mAdView!!.setAdSize(getAdSize(activity))
//            val adId: String
//            if (ad_from == "game") {
//                adId = UtilsStaticData.getGamesBannerAdId(activity)
//                ads_banner = UtilsStaticData.ads_banner_gamezone
//            } else if (ad_from == "splash") {
//                adId = UtilsStaticData.getSplashBannerAdId(activity)
//                ads_banner = UtilsStaticData.ads_banner_splash
//            } else {
//                adId = UtilsStaticData.getBannerAdId(activity)
//                ads_banner = UtilsStaticData.ads_banner
//            }

            mAdView!!.adUnitId = adId
            val adRequest = AdRequest.Builder().build()
            mAdView!!.loadAd(adRequest)

            mAdView!!.adListener = object : AdListener() {
                override fun onAdImpression() {
                    super.onAdImpression()

                }

                override fun onAdLoaded() {

                    frameLayout_admob_banner.removeAllViews()
                    frameLayout_admob_banner.addView(mAdView)
                    frameLayout_admob_banner.visibility = View.VISIBLE
                    isRequestSend = false

                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    // Code to be executed when an ad request fails.

                    mAdView!!.visibility = View.GONE
//                    reloadBannerAds(activity, frameLayout_admob_banner, adSizeType, ad_from)

                }

                override fun onAdOpened() {
                }

                override fun onAdClicked() {
                }

                override fun onAdClosed() {
                }
            }
        }
    }

    private fun reloadBannerAds(
        activity: Activity,
        frameLayout_admob_banner: FrameLayout,
        adSizeType: String,
        adId: String
    ) {
        if (activity.isOnline()) {


            mAdView = AdView(activity)
            mAdView!!.setAdSize(getAdSize(activity))
            mAdView!!.adUnitId = adId


            val adRequest = AdRequest.Builder().build()
            mAdView!!.loadAd(adRequest)

            mAdView!!.adListener = object : AdListener() {
                override fun onAdImpression() {
                    super.onAdImpression()
                }

                override fun onAdLoaded() {
                    frameLayout_admob_banner.removeAllViews()
                    frameLayout_admob_banner.addView(mAdView)
                    frameLayout_admob_banner.visibility = View.VISIBLE
                    isRequestSend = false
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    mAdView!!.visibility = View.GONE
                    frameLayout_admob_banner.visibility = View.GONE
                    isRequestSend = false
                }

                override fun onAdOpened() {
                }

                override fun onAdClicked() {
                }

                override fun onAdClosed() {
                }
            }
        }
    }

    private fun getAdSize(activity: Activity): AdSize {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        val display = activity.windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val widthPixels = outMetrics.widthPixels.toFloat()
        val density = outMetrics.density
        val adWidth = (widthPixels / density).toInt()


        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth)
    }

    fun destroyAd() {
        if (mAdView != null) {
            mAdView!!.destroy()
        }
    }

    fun resumeAd() {
        if (mAdView != null) {
            mAdView!!.resume()
        }
    }

    fun pauseAd() {
        if (mAdView != null) {
            mAdView!!.pause()
        }
    }

}