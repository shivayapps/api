package sms.convoconnect.domain.interactor

import io.reactivex.Flowable
import sms.convoconnect.domain.repository.MessageRepository
import javax.inject.Inject

class MarkDelivered @Inject constructor(private val messageRepo: MessageRepository) :
    Interactor<Long>() {

    override fun buildObservable(params: Long): Flowable<Unit> {
        return Flowable.just(Unit)
            .doOnNext { messageRepo.markDelivered(params) }
    }

}