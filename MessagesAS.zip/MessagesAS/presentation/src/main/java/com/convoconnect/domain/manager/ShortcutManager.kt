package sms.convoconnect.domain.manager

interface ShortcutManager {

    fun updateBadge()

    fun updateShortcuts()

}