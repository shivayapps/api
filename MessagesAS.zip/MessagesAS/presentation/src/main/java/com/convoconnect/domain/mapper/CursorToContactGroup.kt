package sms.convoconnect.domain.mapper

import android.database.Cursor
import sms.convoconnect.domain.model.ContactGroup

interface CursorToContactGroup : Mapper<Cursor, ContactGroup> {

    fun getContactGroupsCursor(): Cursor?

}
