package sms.convoconnect.data.receiver

import android.app.Activity
import android.content.*
import android.net.Uri
import android.provider.Telephony
import com.google.android.mms.MmsException
import com.google.android.mms.util_alt.SqliteWrapper
import com.klinker.android.send_message.Transaction
import dagger.android.AndroidInjection
import sms.convoconnect.domain.interactor.MarkFailed
import sms.convoconnect.domain.interactor.MarkSent
import sms.convoconnect.domain.interactor.SendEvent
import sms.convoconnect.domain.interactor.SyncMessage
import java.io.File
import javax.inject.Inject

class MmsSentReceiver : BroadcastReceiver() {

    @Inject
    lateinit var syncMessage: SyncMessage

    @Inject
    lateinit var markSent: MarkSent

    @Inject
    lateinit var markFailed: MarkFailed

    @Inject
    lateinit var sendEvent: SendEvent

    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)
        val id = intent.getLongExtra("id", 0L)
        sms.convoconnect.data.extensions.LogW(
            "MmsSentReceiver+++++",
            "MMS sending result: $resultCode"
        )
        val uri = Uri.parse(intent.getStringExtra(Transaction.EXTRA_CONTENT_URI))
        sms.convoconnect.data.extensions.LogW("MmsSentReceiver+++++", uri.toString())

        when (resultCode) {
            Activity.RESULT_OK -> {
                sms.convoconnect.data.extensions.LogW(
                    "MmsSentReceiver+++++",
                    "MMS has finished sending, marking it as so in the database"
                )
                val values = ContentValues(1)
                values.put(Telephony.Mms.MESSAGE_BOX, Telephony.Mms.MESSAGE_BOX_SENT)
                SqliteWrapper.update(context, context.contentResolver, uri, values, null, null)

                val pendingResult = goAsync()
                sendEvent.execute(
                    SendEvent.Params(
                        "message_detail",
                        "send_mms",
                        "success"
                    )
                )
                markSent.execute(id) {
                    try {
                        pendingResult.finish()
                    } catch (e: IllegalStateException) {
                        sms.convoconnect.data.extensions.LogE(
                            "IllegalStateException: ",
                            e.message.toString()
                        )
                        e.printStackTrace()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }

            else -> {
                sms.convoconnect.data.extensions.LogW(
                    "MmsSentReceiver+++++",
                    "MMS has failed to send, marking it as so in the database"
                )
                try {
                    val messageId = ContentUris.parseId(uri)

                    val values = ContentValues(1)
                    values.put(Telephony.Mms.MESSAGE_BOX, Telephony.Mms.MESSAGE_BOX_FAILED)
                    SqliteWrapper.update(
                        context, context.contentResolver, Telephony.Mms.CONTENT_URI, values,
                        "${Telephony.Mms._ID} = ?", arrayOf(messageId.toString())
                    )

                    // TODO this query isn't able to find any results
                    // Need to figure out why the message isn't appearing in the PendingMessages Uri,
                    // so that we can properly assign the error type
                    val errorTypeValues = ContentValues(1)
                    errorTypeValues.put(
                        Telephony.MmsSms.PendingMessages.ERROR_TYPE,
                        Telephony.MmsSms.ERR_TYPE_GENERIC_PERMANENT
                    )
                    SqliteWrapper.update(
                        context,
                        context.contentResolver,
                        Telephony.MmsSms.PendingMessages.CONTENT_URI,
                        errorTypeValues,
                        "${Telephony.MmsSms.PendingMessages.MSG_ID} = ?",
                        arrayOf(messageId.toString())
                    )

                } catch (e: MmsException) {
                    e.printStackTrace()
                }
                sendEvent.execute(
                    SendEvent.Params(
                        "message_detail",
                        "send_mms",
                        "failed_$resultCode"
                    )
                )
                val pendingResult = goAsync()
                markFailed.execute(MarkFailed.Params(id, resultCode)) {
                    try {
                        pendingResult.finish()
                    } catch (e: IllegalStateException) {
                        sms.convoconnect.data.extensions.LogE(
                            "IllegalStateException:",
                            e.message.toString()
                        )
                        e.printStackTrace()
                    } catch (e: Exception) {
                        sms.convoconnect.data.extensions.LogE("Exception: ", e.message.toString())
                        e.printStackTrace()
                    }
                }
            }
        }

        val filePath = intent.getStringExtra(Transaction.EXTRA_FILE_PATH)
        sms.convoconnect.data.extensions.LogW("MmsSentReceiver+++++", "filePath---" + filePath)
        File(filePath).delete()

        Uri.parse(intent.getStringExtra("content_uri"))?.let { uri ->
            val pendingResult = goAsync()
            syncMessage.execute(uri) {
                try {
                    pendingResult.finish()
                } catch (e: IllegalStateException) {
                    sms.convoconnect.data.extensions.LogE(
                        "IllegalStateException: ",
                        e.message.toString()
                    )
                    e.printStackTrace()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }
}