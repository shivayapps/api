package sms.convoconnect.domain.manager

interface WidgetManager {

    companion object {
        const val ACTION_NOTIFY_DATASET_CHANGED = "sms.convoconnect.domain.intent.action.ACTION_NOTIFY_DATASET_CHANGED"
    }

    fun updateUnreadCount()

    fun updateTheme()

}