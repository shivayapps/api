package sms.convoconnect.data.receiver

import com.android.mms.transaction.PushReceiver

class MmsReceiver : PushReceiver()