package sms.convoconnect.domain.interactor

import io.reactivex.Flowable
import sms.convoconnect.domain.interactor.Interactor
import sms.convoconnect.domain.repository.ConversationRepository
import javax.inject.Inject

class MarkAllAsRead @Inject constructor(private val conversationRepository: ConversationRepository) :
    Interactor<Unit>() {

    override fun buildObservable(params: Unit): Flowable<*> {
        return Flowable.just(Unit)
            .doOnNext { conversationRepository.markAllAsRead() }

    }

}




