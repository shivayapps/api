package sms.convoconnect.domain.mapper

import android.database.Cursor
import sms.convoconnect.domain.model.MmsPart

interface CursorToPart : Mapper<Cursor, MmsPart> {

    fun getPartsCursor(messageId: Long?=null): Cursor?

}