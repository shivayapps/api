package sms.convoconnect.domain.interactor

import io.reactivex.Flowable
import sms.convoconnect.domain.repository.ConversationRepository
import javax.inject.Inject

class MarkBlocked @Inject constructor(
    private val conversationRepo: ConversationRepository, private val markRead: MarkRead
) : Interactor<MarkBlocked.Params>() {

    data class Params(val threadIds: List<Long>, val blockReason: String?)

    override fun buildObservable(params: Params): Flowable<*> {
        return Flowable.just(params).doOnNext { (threadIds, blockReason) ->
            conversationRepo.markBlocked(threadIds, blockReason)
        }.flatMap { (threadIds) -> markRead.buildObservable(threadIds) }
    }

}
