package sms.convoconnect.domain.model

import android.graphics.Bitmap

data class WidgetModel(
    var id: Long? = 0L,
    var initial: String? = "",
    var title: String? = "",
    var photoUri: String? = null,
    var unread: Boolean = false,
    var me: Boolean = false,
    var timestamp: Long = 0L,
    var snippet: String? = "",
    var draft: String = "",
)