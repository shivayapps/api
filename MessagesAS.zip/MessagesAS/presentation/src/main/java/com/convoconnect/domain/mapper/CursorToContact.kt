package sms.convoconnect.domain.mapper

import android.database.Cursor
import sms.convoconnect.domain.model.Contact

interface CursorToContact : Mapper<Cursor, Contact> {

    fun getContactsCursor(): Cursor?

}