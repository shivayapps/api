package sms.convoconnect.common.common.util.extensions

fun now(): Long {
    return System.currentTimeMillis()
}
