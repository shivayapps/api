package sms.convoconnect.domain.interactor

import io.reactivex.Flowable
import sms.convoconnect.domain.manager.NotificationManager
import sms.convoconnect.domain.repository.MessageRepository
import javax.inject.Inject

class MarkSent @Inject constructor(
    private val messageRepo: MessageRepository,
    private val notificationManager: NotificationManager
) : Interactor<Long>() {

    override fun buildObservable(params: Long): Flowable<Unit> {
        return Flowable.just(Unit)
            .doOnNext { messageRepo.markSent(params) }
            .doOnNext { notificationManager.logSent(params) }
    }

}