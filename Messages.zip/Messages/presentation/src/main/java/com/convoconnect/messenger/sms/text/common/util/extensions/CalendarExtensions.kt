package com.convoconnect.messenger.sms.text.common.util.extensions

import java.util.*

fun Calendar.isSameDay(other: Calendar): Boolean {
    return get(Calendar.YEAR) == other.get(Calendar.YEAR) && get(Calendar.DAY_OF_YEAR) == other.get(
        Calendar.DAY_OF_YEAR
    )
}

fun Calendar.isYesterday(other: Calendar): Boolean {
    add(Calendar.DATE, -1)
    return get(Calendar.YEAR) == other.get(Calendar.YEAR) && get(Calendar.MONTH) == other.get(
        Calendar.MONTH
    ) && get(Calendar.DATE) == other.get(Calendar.DATE)
}

fun Calendar.isOneMinute(other: Calendar): Boolean {
    val diff: Long = timeInMillis - other.timeInMillis
    val seconds = diff / 1000
    val minutes = seconds / 60
    return minutes < 1
}

fun Calendar.isOneHour(other: Calendar): Boolean {
    val diff: Long = timeInMillis - other.timeInMillis
    val seconds = diff / 1000
    val minutes = seconds / 60
    return minutes < 60
}

fun Calendar.getOneHourPeriod(other: Calendar): String {
    val diff: Long = timeInMillis - other.timeInMillis
    val seconds = diff / 1000
    val minutes = seconds / 60
    return "$minutes min"
}

fun Calendar.isSameWeek(other: Calendar): Boolean {
    return get(Calendar.YEAR) == other.get(Calendar.YEAR) && get(Calendar.WEEK_OF_YEAR) == other.get(
        Calendar.WEEK_OF_YEAR
    )
}

fun Calendar.isSameYear(other: Calendar): Boolean {
    return get(Calendar.YEAR) == other.get(Calendar.YEAR)
}