package com.convoconnect.messenger.sms.text.common.prefixAd;

public enum NativeAdSize {
    Exit, List, Game
}
