package com.convoconnect.messenger.sms.text.common.prefixAd;


import static com.convoconnect.messenger.sms.text.common.util.extensions.LogExtensionsKt.LogE;
import static com.convoconnect.messenger.sms.text.common.util.extensions.LogExtensionsKt.LogW;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;

import org.json.JSONArray;
import org.json.JSONException;

import com.convoconnect.messenger.sms.text.R;
import com.convoconnect.messenger.sms.text.common.MessagesApplication;
import com.convoconnect.messenger.sms.text.common.util.AppUtils;
import com.convoconnect.messenger.sms.text.common.PreferanceData.AppPreference;
import com.convoconnect.messenger.sms.text.common.PreferanceData.PreferenceKeys;
import com.convoconnect.messenger.sms.text.common.staticData.EventKeys;
import com.convoconnect.messenger.sms.text.common.staticData.UtilsStaticData;
import com.convoconnect.messenger.sms.text.utils.ConstantsKt;
import com.convoconnect.messenger.sms.text.utils.PreferenceManager;

public class NativeAds {
    private static String TAG = NativeAds.class.getSimpleName();

    private static String f_request = "f_request";
    private static String f_load = "f_load";
    private static String f_fail_to_load = "f_fail_to_load";
    private static String f_click = "f_click";
    private static String f_impression = "f_impression";

    private static String ads_native = "ads_native";


    private static NativeAd mNativeAd = null;


    /**
     * This class is used to load & show the native ads
     **/

    public static void loadNativeAds(Activity activity, final FrameLayout fLayout, final NativeAdSize adSize, boolean showDivider) {
        if (mNativeAd != null && !ConstantsKt.isOnline(activity)  && PreferenceManager.getBooleanData(activity, PreferenceKeys.is_ads_remove))
            return;

        if (ConstantsKt.isOnline(activity)) {
            String actName = AppUtils.checkActivityName(activity);
            f_request = "f_request";
            f_load = "f_load";
            f_fail_to_load = "f_fail_to_load";
            f_click = "f_click";
            f_impression = "f_impression";

            String nativeAdId;

            NativeAdView nativeAdView;
            if (adSize == NativeAdSize.Exit) {
                nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.admob_native_exit, null);
                ads_native = UtilsStaticData.ads_native;
                nativeAdId = UtilsStaticData.getNativeId(activity);
            } else if (adSize == NativeAdSize.List) {
                nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.admob_native_list, null);
                ads_native = UtilsStaticData.ads_native_inline;
                nativeAdId = UtilsStaticData.getListNativeAdId(activity);
            } else if (adSize == NativeAdSize.Game) {
                nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.admob_native_exit, null);
                ads_native = UtilsStaticData.ads_native_gamezone;
                nativeAdId = UtilsStaticData.getGameZoneNativeId(activity);
            } else {
                nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.admob_native_exit, null);
                ads_native = UtilsStaticData.ads_native;
                nativeAdId = UtilsStaticData.getNativeId(activity);
            }
            RelativeLayout relativeLayout = nativeAdView.findViewById(R.id.rl_text_loading);
            relativeLayout.setVisibility(View.VISIBLE);
            nativeAdView.findViewById(R.id.rel_main_ad).setVisibility(View.GONE);
            fLayout.addView(nativeAdView);
            if (adSize == NativeAdSize.Exit || adSize == NativeAdSize.Game) {
                nativeAdView.setMediaView(nativeAdView.findViewById(R.id.media_view));
            }
            nativeAdView.setHeadlineView(nativeAdView.findViewById(R.id.primary));
            nativeAdView.setBodyView(nativeAdView.findViewById(R.id.secondary));
            nativeAdView.setCallToActionView(nativeAdView.findViewById(R.id.cta));
            nativeAdView.setIconView(nativeAdView.findViewById(R.id.icon));
            nativeAdView.setAdvertiserView(nativeAdView.findViewById(R.id.tertiary));

            NativeAdView finalNativeAdView = nativeAdView;
            LogW(TAG, "AdId:---" + nativeAdId);
            LogW(TAG, "AdSize:---" + adSize);

            if (mNativeAd != null) {
                NativeAds.populateNativeAdView(mNativeAd, nativeAdView, adSize, showDivider);
                fLayout.removeAllViews();
                fLayout.addView(nativeAdView);
            } else {
                AppUtils.logAdapterMessages(ads_native, f_request, actName);

                AdLoader.Builder builder = new AdLoader.Builder(activity, nativeAdId).forNativeAd(nativeAd -> {
                    mNativeAd = nativeAd;
                    NativeAds.populateNativeAdView(nativeAd, finalNativeAdView, adSize, showDivider);
                    fLayout.removeAllViews();
                    fLayout.addView(finalNativeAdView);

                }).withAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();
                        mNativeAd = null;
                    }

                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                        Log.e("firebaseAnalytics", "onAdLoaded: " + adSize + " ");
                        AppUtils.logAdapterMessages(ads_native, f_load, actName);
                        if (mNativeAd != null)
                            logBannerImpressionData(mNativeAd, nativeAdId);
                    }


                    @Override
                    public void onAdFailedToLoad(LoadAdError adError) {
                        AppUtils.logAdapterMessages(ads_native, f_fail_to_load, actName + "_" + adError.getMessage());
                        if (MessagesApplication.remoteConfig.getString(UtilsStaticData.is_back_id_required).equals("true")) {
                            NativeAds.reLoadNativeAds(activity, fLayout, adSize, showDivider);
                        }
                    }

                    @Override
                    public void onAdOpened() {
                    }

                    @Override
                    public void onAdClicked() {
                        super.onAdClicked();
                        new AppPreference(activity).saveData(PreferenceKeys.SystemDialogOpened, true);
                        AppUtils.logAdapterMessages(ads_native, f_click, actName);
                    }

                    @Override
                    public void onAdImpression() {
                        super.onAdImpression();
                        AppUtils.logAdapterMessages(ads_native, f_impression, actName);
                    }
                });
                builder.build().loadAd(new AdRequest.Builder().build());
            }

        }

    }



    public static void loadListCustomAds(Activity activity, final FrameLayout frameLayout, boolean showDivider) {
        View customView = activity.getLayoutInflater().inflate(R.layout.admob_custom_native_list, null);
        frameLayout.removeAllViews();
        frameLayout.addView(customView);

        ConstraintLayout btnUnlockNow = customView.findViewById(R.id.custom_list_native_ad);
        View divider = customView.findViewById(R.id.view_divider);
        if (showDivider) {
            divider.setVisibility(View.VISIBLE);
        } else {
            divider.setVisibility(View.GONE);
        }

        btnUnlockNow.setOnClickListener(v -> {
            ConstantsKt.launchSubscription(activity, "inside", false);
        });


    }

    public static void loadCustomAds(Activity activity, final FrameLayout fLayout) throws JSONException {
        View customView = activity.getLayoutInflater().inflate(R.layout.admob_custom_native_exit, null);
        fLayout.removeAllViews();
        fLayout.addView(customView);

        JSONArray jsonArray = new JSONArray(MessagesApplication.remoteConfig.getString(UtilsStaticData.CustomNativeAdData));


        String appIcon = jsonArray.getJSONObject(0).getString("app_icon");
        String bannerImage = jsonArray.getJSONObject(1).getString("banner_link");
        String primaryText = jsonArray.getJSONObject(2).getString("primary_text");
        String bodyText = jsonArray.getJSONObject(3).getString("body_text");
        String btnLink = jsonArray.getJSONObject(4).getString("btn_link");
        String btnText = jsonArray.getJSONObject(5).getString("button_text");

        TextView linkBtn = customView.findViewById(R.id.cta);
        ImageView banner = customView.findViewById(R.id.media_view);
        ImageView icon = customView.findViewById(R.id.icon);
        TextView title = customView.findViewById(R.id.primary);
        TextView description = customView.findViewById(R.id.secondary);

        Glide.with(activity).load(bannerImage).into(banner);
        Glide.with(activity).load(appIcon).into(icon);

        title.setText(primaryText);
        description.setText(bodyText);
        linkBtn.setText(btnText);

        linkBtn.setOnClickListener(v -> {
            Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(btnLink));
            activity.startActivity(myIntent);
        });


    }


    private static void reLoadNativeAds(Activity activity, final FrameLayout fLayout, final NativeAdSize adSize, boolean showDivider) {

        if (ConstantsKt.isOnline(activity)) {

            String actName = AppUtils.checkActivityName(activity);
            f_request = "b_request";
            f_load = "b_load";
            f_fail_to_load = "b_fail_to_load";
            f_click = "b_click";
            f_impression = "b_impression";


            NativeAdView nativeAdView;
            if (adSize == NativeAdSize.Exit) {
                nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.admob_native_exit, null);
                ads_native = UtilsStaticData.ads_native;
            } else if (adSize == NativeAdSize.List) {
                nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.admob_native_list, null);
                ads_native = UtilsStaticData.ads_native_inline;
            } else if (adSize == NativeAdSize.Game) {
                nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.admob_native_exit, null);
                ads_native = UtilsStaticData.ads_native_gamezone;
            } else {
                nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.admob_native_exit, null);
                ads_native = UtilsStaticData.ads_native;
            }

            RelativeLayout relativeLayout = nativeAdView.findViewById(R.id.rl_text_loading);
            relativeLayout.setVisibility(View.VISIBLE);
            nativeAdView.findViewById(R.id.rel_main_ad).setVisibility(View.GONE);
            fLayout.addView(nativeAdView);
            if (adSize == NativeAdSize.Exit) {
                nativeAdView.setMediaView(nativeAdView.findViewById(R.id.media_view));
            }
            nativeAdView.setHeadlineView(nativeAdView.findViewById(R.id.primary));
            nativeAdView.setBodyView(nativeAdView.findViewById(R.id.secondary));
            nativeAdView.setCallToActionView(nativeAdView.findViewById(R.id.cta));
            nativeAdView.setIconView(nativeAdView.findViewById(R.id.icon));
            nativeAdView.setAdvertiserView(nativeAdView.findViewById(R.id.tertiary));


            NativeAdView finalNativeAdView = nativeAdView;
            if (mNativeAd != null) {
                NativeAds.populateNativeAdView(mNativeAd, nativeAdView, adSize, showDivider);
                fLayout.removeAllViews();
                fLayout.addView(nativeAdView);
            } else {
                AppUtils.logAdapterMessages(ads_native, f_request, actName);
                AdLoader.Builder builder = new AdLoader.Builder(activity, UtilsStaticData.getBackNativeId(activity)).forNativeAd(nativeAd -> {
                    mNativeAd = nativeAd;
                    NativeAds.populateNativeAdView(nativeAd, finalNativeAdView, adSize, showDivider);
                    fLayout.removeAllViews();
                    fLayout.addView(finalNativeAdView);
                }).withAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();
                        mNativeAd = null;
                    }

                    @Override
                    public void onAdLoaded() {
                        Log.e("firebaseAnalytics", "reload: " + adSize + " ");
                        AppUtils.logAdapterMessages(ads_native, f_load, actName);
                        fLayout.setVisibility(View.VISIBLE);
                        if (mNativeAd != null)
                            logBannerImpressionData(mNativeAd, UtilsStaticData.getBackNativeId(activity));
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError adError) {
                        AppUtils.logAdapterMessages(ads_native, f_fail_to_load, adError.getCode() + "_" + actName);
                        LogE("adError ", adError.getMessage());
                    }

                    @Override
                    public void onAdOpened() {
                    }

                    @Override
                    public void onAdClicked() {
                        super.onAdClicked();
                        AppUtils.logAdapterMessages(ads_native, f_click, actName);
                        new AppPreference(activity).saveData(PreferenceKeys.SystemDialogOpened, true);

                    }

                    @Override
                    public void onAdImpression() {
                        super.onAdImpression();
                        AppUtils.logAdapterMessages(ads_native, f_impression, actName);

                    }
                });
                builder.build().loadAd(new AdRequest.Builder().build());
            }

        }
    }

    public static void populateNativeAdView(NativeAd nativeAd, NativeAdView nativeAdView, NativeAdSize adSize, boolean showDivider) {
        ((TextView) nativeAdView.getHeadlineView()).setText(nativeAd.getHeadline());
        ((TextView) nativeAdView.getBodyView()).setText(nativeAd.getBody());
        ((TextView) nativeAdView.getCallToActionView()).setText(nativeAd.getCallToAction());
        NativeAd.Image icon = nativeAd.getIcon();
        if (icon == null) {
            nativeAdView.getIconView().setVisibility(View.INVISIBLE);
        } else {
            ((ImageView) nativeAdView.getIconView()).setImageDrawable(icon.getDrawable());
            nativeAdView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getAdvertiser() == null) {
            nativeAdView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) nativeAdView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            nativeAdView.getAdvertiserView().setVisibility(View.VISIBLE);
        }
        if (nativeAdView.getMediaView() != null) {
            nativeAdView.getMediaView().setImageScaleType(ImageView.ScaleType.FIT_CENTER);
        }
        nativeAdView.findViewById(R.id.rl_text_loading).setVisibility(View.GONE);
        nativeAdView.findViewById(R.id.rel_main_ad).setVisibility(View.VISIBLE);
        if (adSize == NativeAdSize.List && showDivider) {
            nativeAdView.findViewById(R.id.view_divider).setVisibility(View.VISIBLE);
        }
        nativeAdView.setNativeAd(nativeAd);
    }

    private static void logBannerImpressionData(NativeAd nativeAd, String admobAdId) {
        nativeAd.setOnPaidEventListener(adValue -> {
            Bundle mBundle = new Bundle();
            mBundle.putString("valueMicros", adValue.getValueMicros() + "");
            mBundle.putString("currencyCode", adValue.getCurrencyCode() + "");
            mBundle.putString("precision", adValue.getPrecisionType() + "");
            mBundle.putString("adUnitId",admobAdId);
            AppUtils.logAdapterBundleMessages(EventKeys.paid_ad_impression, mBundle);
        });
    }
}