package com.convoconnect.messenger.sms.text.common.util

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.annotation.Size
import com.grow.subscriptionmodule.activity.SubscriptionPurchaseActivity
import org.jetbrains.annotations.NotNull
import com.convoconnect.messenger.sms.text.BuildConfig
import com.convoconnect.messenger.sms.text.common.MessagesApplication
import com.convoconnect.messenger.sms.text.feature.backup.BackupActivity
import com.convoconnect.messenger.sms.text.feature.blocking.BlockingActivity
import com.convoconnect.messenger.sms.text.feature.compose.ComposeActivity
import com.convoconnect.messenger.sms.text.feature.contacts.ContactsActivity
import com.convoconnect.messenger.sms.text.feature.main.MainActivity
import com.convoconnect.messenger.sms.text.feature.scheduled.ScheduledActivity
import com.convoconnect.messenger.sms.text.feature.settings.SettingsActivity
import com.convoconnect.messenger.sms.text.common.prefixAd.OpenAdApplication
import com.convoconnect.messenger.sms.text.common.staticData.EventKeys
import com.convoconnect.messenger.sms.text.common.util.extensions.LogE
import com.convoconnect.messenger.sms.text.common.util.extensions.LogW
import com.convoconnect.messenger.sms.text.feature.main.SplashActivity
import com.convoconnect.messenger.sms.text.feature.settings.thememode.ThemeModeActivity

import java.util.*
import java.util.regex.Matcher
import java.util.regex.Pattern


object AppUtils {

    fun copy(context: Context, string: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("SMS", string)
        clipboard.setPrimaryClip(clip)
    }

    fun parseCode(msg: String): String {
        val message = msg.replace("\n", " ").trim().lowercase(Locale.getDefault())
        if (message.contains("otp") || message.contains(
                "one time password"
            ) || message.contains(
                "do not share"
            ) || message.contains(
                "don't share it"
            ) || message.contains(
                "verification code"
            ) || message.contains(
                "access code"
            )
        ) {
            val p: Pattern = Pattern.compile("\\b\\d{6}\\b")
            val m: Matcher = p.matcher(message)
            var code = ""
            while (m.find()) {
                code = m.group(0)
            }
            return if (code.length == 6) code
            else {
                val p1: Pattern = Pattern.compile("\\b\\d{4}\\b")
                val m1: Matcher = p1.matcher(message)
                var code1 = ""
                while (m1.find()) {
                    code1 = m1.group(0)
                }
                if (code1.length == 4) code1 else {
                    val p2: Pattern = Pattern.compile("\\b\\d{5}\\b")
                    val m2: Matcher = p2.matcher(message)
                    var code2 = ""
                    while (m2.find()) {
                        code2 = m2.group(0)
                    }
                    if (code2.length == 5) code2 else {
                        val p3: Pattern = Pattern.compile("\\b\\d{3}(-| )\\d{3}\\b")
                        val m3: Matcher = p3.matcher(message)
                        var code3 = ""
                        while (m3.find()) {
                            code3 = m3.group(0).replace("-", "").replace(" ", "")
                        }
                        if (code3.length == 6) {
                            return code3
                        } else ""
                    }
                }
            }
        } else return ""
    }


    fun e(msg: String) {
        if (BuildConfig.DEBUG) {
            LogE("MessageApp-->", msg)
        }
    }

    fun w(msg: String) {
        if (BuildConfig.DEBUG) {
            LogW("MessageApp-->", msg)
        }
    }

//    fun isOnline(context: Context): Boolean {
//        if (context == null) return false
//        val connectivityManager =
//            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
//            if (connectivityManager != null) {
//                val capabilities =
//                    connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
//                if (capabilities != null) {
//                    if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
//                        LogI("Internet", "NetworkCapabilities.TRANSPORT_CELLULAR")
//                        return true
//                    } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
//                        LogI("Internet", "NetworkCapabilities.TRANSPORT_WIFI")
//                        return true
//                    } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
//                        LogI("Internet", "NetworkCapabilities.TRANSPORT_ETHERNET")
//                        return true
//                    }
//                }
//            }
//        } else {
//            val activeNetworkInfo = connectivityManager.activeNetworkInfo
//            if (activeNetworkInfo != null && activeNetworkInfo.isConnected) {
//                return true
//            }
//        }
//        return false
//    }
    /**
     * Firebase event passing bundle
     */
    @JvmStatic
    fun logAdapterBundleMessages(
        @NotNull @Size(min = 1L, max = 40L) eventName0: String, mBundle: Bundle
    ) {

        try {
            val eventName = eventName0.trim().replace(" ", "_").replace(",", "_").lowercase()
            if (BuildConfig.DEBUG) {
                MessagesApplication.mFirebaseAnalytics.logEvent(eventName0, mBundle)
                LogE("firebaseAnalytics", "$eventName $mBundle")
            } else {
                MessagesApplication.mFirebaseAnalytics.logEvent(eventName, mBundle)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * eventName0 is event name you can add any event name
     * for eg. if you add log for ads you can set eventName like "ADMOB_INTERSTITIAL" or "ADMOB_OPEN_ADS"
     * paramName = actionName
     *
     * paramValue = actionValue or actName
     */
    @JvmStatic
    fun logAdapterMessages(
        @NotNull @Size(min = 1L, max = 40L) eventName0: String,
        @Size(min = 1L, max = 40L) paramName0: String,
        @Size(min = 1L, max = 40L) actName: String
    ) {
        try {
            val eventName = eventName0.trim().replace(" ", "_").replace(",", "_")
            val paramName = paramName0.trim().replace(" ", "_").replace(",", "_").lowercase()
            val paramValue =
                actName.trim().replace(" ", "_").replace(",", "_").replace("/", "_").lowercase()

            val mBundle = Bundle()
            mBundle.putString(paramName, paramValue)
            if (BuildConfig.DEBUG) {
                //when need events uncomment below code
                MessagesApplication.mFirebaseAnalytics.logEvent(eventName, mBundle)
                LogE("firebaseAnalytics", "$eventName $paramName $paramValue")
            } else {
                MessagesApplication.mFirebaseAnalytics.logEvent(eventName, mBundle)
            }
        } catch (e: Exception) {
            LogE("firebaseAnalytics: ", "excep" + e.message.toString())
        }
    }

    fun setLocale(country_code: String, activity: Activity) {
        val locale = Locale(country_code)
        Locale.setDefault(locale)
        val config = activity.resources.configuration
        config.setLocale(locale)
        activity.resources.updateConfiguration(config, activity.resources.displayMetrics)
        /* AppCompatDelegate.setApplicationLocales(
             LocaleListCompat.forLanguageTags(country_code)
         )*/
    }

    @JvmStatic
    fun checkActivityName(context: Context): String {
        return try {
            when (context.javaClass.simpleName) {
                MainActivity::class.simpleName -> EventKeys.home_screen
                ComposeActivity::class.simpleName -> EventKeys.message_detail
                ThemeModeActivity::class.simpleName -> EventKeys.theme_mode
                ScheduledActivity::class.simpleName -> EventKeys.schedule_message
                BlockingActivity::class.simpleName -> EventKeys.block_list
                BackupActivity::class.simpleName -> EventKeys.backup_restore
                SettingsActivity::class.simpleName -> EventKeys.settings
                ContactsActivity::class.simpleName -> EventKeys.contacts
                SubscriptionPurchaseActivity::class.simpleName -> EventKeys.subscription
                MessagesApplication::class.simpleName, OpenAdApplication::class.java.simpleName, SplashActivity::class.java.simpleName -> EventKeys.splash
                else -> context.javaClass.simpleName
            }
        } catch (e: Exception) {
            context.javaClass.simpleName
        }


    }
}
