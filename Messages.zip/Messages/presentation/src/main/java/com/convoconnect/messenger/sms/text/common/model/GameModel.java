package com.convoconnect.messenger.sms.text.common.model;

public class GameModel {
    String id;
    String name;
    String link;
    String preview;
    String screenOrientation;
    String isAd;
    String category;
    String tags;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    String isLock;
    String type;

    public String getIsLock() {
        return isLock;
    }

    public void setIsLock(String isLock) {
        this.isLock = isLock;
    }

    public GameModel(String id, String name, String link, String preview, String screenOrientation, String isAd, String category, String tags, String isLock, String type) {
        this.id = id;
        this.name = name;
        this.link = link;
        this.preview = preview;
        this.screenOrientation = screenOrientation;
        this.isAd = isAd;
        this.category = category;
        this.tags = tags;
        this.isLock = isLock;
        this.type = type;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getPreview() {
        return preview;
    }

    public void setPreview(String preview) {
        this.preview = preview;
    }

    public String getScreenOrientation() {
        return screenOrientation;
    }

    public void setScreenOrientation(String screenOrientation) {
        this.screenOrientation = screenOrientation;
    }

    public String getIsAd() {
        return isAd;
    }

    public void setIsAd(String isAd) {
        this.isAd = isAd;
    }
}
