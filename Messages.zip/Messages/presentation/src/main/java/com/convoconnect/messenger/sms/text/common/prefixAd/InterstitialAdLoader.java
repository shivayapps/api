package com.convoconnect.messenger.sms.text.common.prefixAd;


import static com.convoconnect.messenger.sms.text.common.PreferanceData.PreferenceKeys.isAnyAdShowing;
import static com.convoconnect.messenger.sms.text.common.util.extensions.LogExtensionsKt.LogE;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import com.convoconnect.messenger.sms.text.common.MessagesApplication;
import com.convoconnect.messenger.sms.text.common.util.AppUtils;
import com.convoconnect.messenger.sms.text.common.PreferanceData.AppPreference;
import com.convoconnect.messenger.sms.text.common.PreferanceData.PreferenceKeys;
import com.convoconnect.messenger.sms.text.common.staticData.EventKeys;
import com.convoconnect.messenger.sms.text.common.staticData.UtilsStaticData;
import com.convoconnect.messenger.sms.text.utils.ConstantsKt;

/**
 * The type Interstitial ad loader.
 */
public class InterstitialAdLoader {

    public static String ads_interstitial = "ads_interstitial";

    /**
     * The constant mAdmobInterstitialAd.
     */
    private static InterstitialAd mAdmobInterstitialAd = null;

    private static boolean isAdLoading = false;
    private static final String TAG = InterstitialAdLoader.class.getSimpleName();

    private static String f_request = "f_request";
    private static String f_load = "f_load";
    private static String f_fail_to_load = "f_fail_to_load";
    private static String f_fail_to_show = "f_fail_to_show";
    private static String f_show = "f_show";
    private static String f_click = "f_click";
    private static String f_impression = "f_impression";
    private static String f_dismiss = "f_dismiss";
    @SuppressLint("StaticFieldLeak")
    private static AppPreference appPreference;


    /**
     * This method is will be called by the user to show the Interstitial & Reward ads,
     * the interstitial ad type get from firebase remote config or the developer have to pass it as string.
     * <p>
     * AdType Cases are like :
     * 1. admob_int (For interstitial)
     * 2. admob_reward (For reward)
     * <p>
     */
    public static void showFullScreenAds(Activity activity, boolean isAdTrue, boolean isLastAd, String rewardAdType, AdFinishWithControlListener listener) {
        appPreference = new AppPreference(activity);
        if (!appPreference.getBooleanData(UtilsStaticData.is_ads_remove) && ConstantsKt.isOnline(activity)) {
            if (isAdTrue) {
                switch (rewardAdType) {
                    case UtilsStaticData.admob_int:
                        LogE(TAG, "InterstitialAdLoader--------------- showFullScreenAds   : " + appPreference.getBooleanData(PreferenceKeys.Admob_IntAd));
                        if (InterstitialAdLoader.isAdLoaded() && !appPreference.getBooleanData(PreferenceKeys.Admob_IntAd, false)) {
                            showInterstitialAd(activity, isLastAd, listener);
                        } else {
                            listener.adFinished();
                        }
                        break;
                    case UtilsStaticData.admob_reward:
                        RewardedAdLoader.loadRewardedAd(activity, UtilsStaticData.rewardedAdLoader_ID(activity), UtilsStaticData.rewardedAdLoader_ID_reload(activity), new RewardedAdLoader.RewardAdCallback() {
                            @Override
                            public void onAdLoadFailed() {
                                listener.rewardAdFailed();
                            }

                            @Override
                            public void onAdDismiss() {
                                isAnyAdShowing = false;
                                listener.rewardAdDismiss(true);
                            }
                        });
                        break;
                    default:
                        listener.adFinished();
                        break;
                }
            } else {
                listener.adFinished();
            }

        } else {
            listener.adFinished();
        }
    }

    /**
     * This method is used to load the Interstitial ads, after ad finished or on start of activity.
     */
    public static void loadFullScreenAds(Context context) {
        appPreference = new AppPreference(context);
        if (!appPreference.getBooleanData(UtilsStaticData.is_ads_remove) && ConstantsKt.isOnline(context)) {
            if (!isAdLoaded() && !isAdLoading) {
                loadAdmobInt(context);
            }
        }
    }


    /**
     * Is ad loaded boolean.
     *
     * @return the boolean
     */
    private static boolean isAdLoaded() {
        if (!appPreference.getBooleanData(UtilsStaticData.is_ads_remove)) {
            return mAdmobInterstitialAd != null;
        } else {
            return false;
        }
    }


    /**
     * Load admob int.
     *
     * @param context the context
     */
    private static void loadAdmobInt(final Context context) {

        if (ConstantsKt.isOnline(context) && mAdmobInterstitialAd == null) {

            String actName = AppUtils.checkActivityName(context);

            f_request = "f_request";
            f_load = "f_load";
            f_fail_to_load = "f_fail_to_load";
            f_show = "f_show";
            f_fail_to_show = "f_fail_to_show";
            f_dismiss = "f_dismiss";
            f_click = "f_click";
            f_impression = "f_impression";

            AppUtils.logAdapterMessages(ads_interstitial, f_request, actName);
            isAdLoading = true;
            InterstitialAd.load(context, UtilsStaticData.getInterstitialAdLoaderId(context), new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    // The mInterstitialAd reference will be null until
                    // an ad is loaded.
                    AppUtils.logAdapterMessages(ads_interstitial, f_load, actName);
                    mAdmobInterstitialAd = interstitialAd;
                    isAdLoading = false;
                    logInterstitialImpressionData(interstitialAd);
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    // Handle the error
                    AppUtils.logAdapterMessages(ads_interstitial, f_fail_to_load, loadAdError.getCode() + "_" + actName);
                    mAdmobInterstitialAd = null;
                    if (MessagesApplication.remoteConfig.getString(UtilsStaticData.is_back_id_required).equals("true")) {
                        loadAdmobIntReload(context);
                    }
                }
            });
        }
    }


    public interface AdFinishWithControlListener {

        void adFinished();

        void rewardAdDismiss(boolean isReworded);

        void rewardAdFailed();
    }

    /**
     * Show Interstitial ad.
     *
     * @param activity    the activity
     * @param isLastAd    the is last ad
     * @param adFinishWithControlListener the finished 1
     */
    private static void showInterstitialAd(Activity activity, boolean isLastAd, AdFinishWithControlListener adFinishWithControlListener) {


        if (isAdLoaded() && !appPreference.getBooleanData(PreferenceKeys.Admob_IntAd, false)) {


            String actName = AppUtils.checkActivityName(activity);

            mAdmobInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {

                @Override
                public void onAdClicked() {
                    AppUtils.logAdapterMessages(ads_interstitial, f_click, actName);
                    super.onAdClicked();
                }

                @Override
                public void onAdImpression() {
                    AppUtils.logAdapterMessages(ads_interstitial, f_impression, actName);
                    super.onAdImpression();
                }

                @Override
                public void onAdDismissedFullScreenContent() {
                    AppUtils.logAdapterMessages(ads_interstitial, f_dismiss, actName);

                    isAnyAdShowing = false;
                    mAdmobInterstitialAd = null;
                    appPreference.saveData(PreferenceKeys.IS_OPEN_AD, true);
                    if (!isLastAd) {
                        loadFullScreenAds(activity);
                    }
                    adFinishWithControlListener.adFinished();

                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    AppUtils.logAdapterMessages(ads_interstitial, f_fail_to_show, adError.getCode() + "_" + actName);

                    mAdmobInterstitialAd = null;
                    appPreference.saveData(PreferenceKeys.IS_OPEN_AD, true);
                    adFinishWithControlListener.adFinished();

                }

                @Override
                public void onAdShowedFullScreenContent() {
                    AppUtils.logAdapterMessages(ads_interstitial, f_show, actName);
                    appPreference.saveData(PreferenceKeys.IS_OPEN_AD, false);
                }
            });
            if (!isAnyAdShowing) {
                isAnyAdShowing = true;
                mAdmobInterstitialAd.show(activity);
            }
        } else {
            adFinishWithControlListener.adFinished();
        }
    }

    /**
     * This method is used to reload the interstitial ad, if gets failed on first load.
     */
    private static void loadAdmobIntReload(final Context context) {

        if (ConstantsKt.isOnline(context) && mAdmobInterstitialAd == null) {
            String actName = AppUtils.checkActivityName(context);
            f_request = "b_request";
            f_load = "b_load";
            f_fail_to_load = "b_fail_to_load";
            f_show = "b_show";
            f_fail_to_show = "b_fail_to_show";
            f_dismiss = "b_dismiss";
            f_click = "b_click";
            f_impression = "b_impression";

            AppUtils.logAdapterMessages(ads_interstitial, f_request, actName);

            InterstitialAd.load(context, UtilsStaticData.getInterstitialAdLoadReloadId(context), new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    // The mInterstitialAd reference will be null until
                    // an ad is loaded.
                    AppUtils.logAdapterMessages(ads_interstitial, f_load, actName);
                    mAdmobInterstitialAd = interstitialAd;
                    isAdLoading = false;
                    logInterstitialImpressionData(interstitialAd);
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError errorCode) {
                    // Handle the error
                    AppUtils.logAdapterMessages(ads_interstitial, f_fail_to_load, errorCode.getCode() + "_" + actName);
                    isAnyAdShowing = false;
                    mAdmobInterstitialAd = null;
                    isAdLoading = false;

                }
            });
        }
    }
    private static void logInterstitialImpressionData(InterstitialAd interstitialAd) {
        interstitialAd.setOnPaidEventListener(adValue -> {
            Bundle mBundle = new Bundle();
            mBundle.putString("valueMicros", adValue.getValueMicros() + "");
            mBundle.putString("currencyCode", adValue.getCurrencyCode() + "");
            mBundle.putString("precision", adValue.getPrecisionType() + "");
            mBundle.putString("adUnitId", interstitialAd.getAdUnitId());
            AppUtils.logAdapterBundleMessages(EventKeys.paid_ad_impression, mBundle);

        });
    }
}
