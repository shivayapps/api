package com.convoconnect.messenger.sms.text.common.PreferanceData;

public class PreferenceKeys {
    public static String start_like_pro = "start_like_pro";
    public static String in_app_subscription_setup_failed = "in_app_subscription_setup_failed";
    public static String IS_OPEN_AD = "is_open_ad";

    public static String PURCAHSE_KEY = "purcahse_key";
    public static  String IS_MODE_CHANGE = "IS_MODE_CHANGE";
    public static  String APP_COUNTER = "APP_COUNTER"; //start like pro or open adds in splash, also how many times rate us to be shown in main activity
    public static String SystemDialogOpened = "SystemDialogOpened";

    public static String fcm_token = "fcm_token";
    public static boolean Is_Reload = false;
    public static boolean isAnyAdShowing = false;
    public static String localization_country_code = "localeCountryCode";
    public static String isOpenAdsLodead = "isOpenAdsLodead";
    public static String Admob_IntAd = "INTAD";
    public static String CONTACT_CHANGE = "CONTACT_CHANGE";
    public static String is_ads_remove = "ads_free";

    public static String OPEN_FROM_REWARD_AD = "open_from_reward_ad";
    public static String localization_country_name = "localizationCountryName";

}
