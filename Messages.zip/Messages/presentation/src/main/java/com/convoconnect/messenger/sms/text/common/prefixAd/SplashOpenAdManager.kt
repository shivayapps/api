package com.convoconnect.messenger.sms.text.common.prefixAd

import android.app.Activity
import android.content.Context
import android.os.Bundle
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdValue
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.admanager.AdManagerAdRequest
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.firebase.analytics.FirebaseAnalytics
import com.convoconnect.messenger.sms.text.common.MessagesApplication
import com.convoconnect.messenger.sms.text.common.util.AppUtils
import com.convoconnect.messenger.sms.text.common.util.AppUtils.logAdapterBundleMessages
import com.convoconnect.messenger.sms.text.common.util.AppUtils.logAdapterMessages
import com.convoconnect.messenger.sms.text.common.PreferanceData.AppPreference
import com.convoconnect.messenger.sms.text.common.PreferanceData.PreferenceKeys
import com.convoconnect.messenger.sms.text.common.staticData.EventKeys
import com.convoconnect.messenger.sms.text.common.staticData.UtilsStaticData
import com.convoconnect.messenger.sms.text.utils.isOnline
import java.util.Date

open class SplashOpenAdManager {

    private var appOpenAd: AppOpenAd? = null
    private var loadTime: Long = 0
    private var TAG: String = SplashOpenAdManager::class.java.simpleName + "+++++++++++++++"
     var ads_appopen ="ads_appopen_splash"

    private fun wasLoadTimeLessThanNHoursAgo(numHours: Long): Boolean {
        val dateDifference: Long = Date().time - loadTime
        val numMilliSecondsPerHour: Long = 3600000
        return dateDifference < numMilliSecondsPerHour * numHours
    }

    /**
     * Check if ad exists and can be shown.
     */
    private fun isAdAvailable(): Boolean {
        // Ad references in the app open beta will time out after four hours, but this time limit
        // may change in future beta versions. For details, see:
        // https://support.google.com/admob/answer/9341964?hl=en
        return appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4)
    }

    open fun showAdIfAvailable(
        activity: Activity,
        onShowAdCompleteListener: OpenAdApplication.OnShowAdCompleteListener
    ) {
        // If the app open ad is already showing, do not show the ad again.
        val actName = EventKeys.splash
        // If the app open ad is not available yet, invoke the callback then load the ad.
        if (activity.isOnline && !isAdAvailable()) {
            AppUtils.e("$TAG The app open ad is not ready yet.")
            onShowAdCompleteListener.onShowAdComplete()
            return
        }
        AppUtils.e("$TAG Will show ad.")
        if (appOpenAd != null) {
            appOpenAd!!.setFullScreenContentCallback(object : FullScreenContentCallback() {
                override fun onAdClicked() {
                    logAdapterMessages(
                        ads_appopen,
                        OpenAdApplication.f_click,
                        actName
                    )
                    super.onAdClicked()
                }

                override fun onAdImpression() {
                    logAdapterMessages(
                        ads_appopen,
                        OpenAdApplication.f_impression,
                        actName
                    )
                    super.onAdImpression()
                }

                /** Called when full screen content is dismissed.  */
                override fun onAdDismissedFullScreenContent() {
                    logAdapterMessages(
                        ads_appopen,
                        OpenAdApplication.f_dismiss,
                        actName
                    )
                    onShowAdCompleteListener.onShowAdComplete()
                }

                /** Called when fullscreen content failed to show.  */
                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    logAdapterMessages(
                        ads_appopen,
                        OpenAdApplication.f_fail_to_show,
                        adError.code.toString() + "_" + actName
                    )
                    onShowAdCompleteListener.onShowAdComplete()
                }

                /** Called when fullscreen content is shown.  */
                override fun onAdShowedFullScreenContent() {
                    AppUtils.e("$TAG onAdShowedFullScreenContent.")
                    logAdapterMessages(
                        ads_appopen,
                        OpenAdApplication.f_show,
                        actName
                    )
                }
            })
            appOpenAd!!.show(activity)
        }
        /* else {
            AppUtils.logAdapterMessages(ads_appopen, "appOpenAd", "null");
        }*/
    }

    /**
     * Load an ad.
     *
     * @param context the context of the activity that loads the ad
     */
    fun loadAd(context: Context?, appPrefs: AppPreference) {
        val actName = EventKeys.splash
        // Do not load ad if there is an unused ad or one is already loading.
        if (!MessagesApplication.isFirebaseAnalyticsInit() && context != null) {
            MessagesApplication.mFirebaseAnalytics = FirebaseAnalytics.getInstance(context)
        }
//        if (!MessagesApplication.isRemoteConfigInit()) {
//            MessagesApplication.remoteConfig = FirebaseRemoteConfig.getInstance()
//        }
        if (context!!.isOnline && !appPrefs.getBooleanData(PreferenceKeys.is_ads_remove)) {
            if (isAdAvailable()) {
                return
            }
            OpenAdApplication.f_request = "f_request"
            OpenAdApplication.f_load = "f_load"
            OpenAdApplication.f_fail_to_load = "f_fail_to_load"
            OpenAdApplication.f_show = "f_show"
            OpenAdApplication.f_fail_to_show = "f_fail_to_show"
            OpenAdApplication.f_dismiss = "f_dismiss"
            OpenAdApplication.f_click = "f_click"
            OpenAdApplication.f_impression = "f_impression"
            //                AppUtils.INSTANCE.e(TAG + " load req=== " + UtilsStaticData.getOpenAdId(context));
            logAdapterMessages(
                ads_appopen,
                OpenAdApplication.f_request,
                actName
            )
            val request = AdManagerAdRequest.Builder().build()
            AppOpenAd.load(
                context,
                UtilsStaticData.getSplashOpenAdId(context),
                request,
                AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    /**
                     * Called when an app open ad has loaded.
                     *
                     * @param ad the loaded app open ad.
                     */
                    override fun onAdLoaded(ad: AppOpenAd) {
                        appOpenAd = ad
                        appPrefs.saveData(PreferenceKeys.isOpenAdsLodead, true)
                        //                                isOpenAdsLodead = true;
                        loadTime = Date().time
                        //                                AppUtils.INSTANCE.e("Admob_OpenAds--------------------" + isOpenAdsLodead);
                        logAdapterMessages(
                            ads_appopen,
                            OpenAdApplication.f_load,
                            actName
                        )
                        logOpenAdImpressionData(ad)
                    }

                    /**
                     * Called when an app open ad has failed to load.
                     *
                     * @param loadAdError the error.
                     */
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        //                                isOpenAdsLodead=false;
                        appPrefs.saveData(PreferenceKeys.isOpenAdsLodead, false)
                        logAdapterMessages(
                            ads_appopen,
                            OpenAdApplication.f_fail_to_load,
                            loadAdError.code.toString() + "_" + actName
                        )
                        AppUtils.e("onAdFailedToLoad: " + loadAdError.message)
                    }
                })
        }
    }

    fun isAdLoaded(): Boolean {
        return appOpenAd != null
    }

    private fun logOpenAdImpressionData(openAd: AppOpenAd) {
        /*openAd.onPaidEventListener = OnPaidEventListener { adValue: AdValue ->
            val valueMicros = adValue.valueMicros
            val currencyCode = adValue.currencyCode
            val precision = adValue.precisionType
            logAdapterMessages(
                EventKeys.paid_ad_impression,
                "valueMicros",
                valueMicros.toString() + ""
            )
            logAdapterMessages(
                EventKeys.paid_ad_impression,
                "currencyCode",
                currencyCode + ""
            )
            logAdapterMessages(
                EventKeys.paid_ad_impression,
                "precision",
                precision.toString() + ""
            )
            logAdapterMessages(
                EventKeys.paid_ad_impression,
                "adUnitId",
                openAd.adUnitId
            )
        }*/
        openAd.setOnPaidEventListener { adValue: AdValue ->
            val mBundle = Bundle()
            mBundle.putString("valueMicros", adValue.valueMicros.toString() + "")
            mBundle.putString("currencyCode", adValue.currencyCode + "")
            mBundle.putString("precision", adValue.precisionType.toString() + "")
            mBundle.putString("adUnitId", openAd.adUnitId)
            logAdapterBundleMessages(
                EventKeys.paid_ad_impression,
                mBundle
            )
        }

    }
}