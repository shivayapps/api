package com.convoconnect.messenger.sms.text.common

import android.annotation.SuppressLint
import android.app.Activity
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import android.provider.Telephony
import android.util.Log
import android.webkit.MimeTypeMap
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.grow.gamezonelibrary.builder.GameZoneBuilder
import com.convoconnect.messenger.sms.text.BuildConfig
import com.convoconnect.messenger.sms.text.common.util.AppUtils
import com.convoconnect.messenger.sms.text.feature.StarredActivity
import com.convoconnect.messenger.sms.text.feature.backup.BackupActivity
import com.convoconnect.messenger.sms.text.feature.blocking.BlockingActivity
import com.convoconnect.messenger.sms.text.feature.compose.ComposeActivity
import com.convoconnect.messenger.sms.text.feature.gallery.GalleryActivity
import com.convoconnect.messenger.sms.text.feature.main.MainActivity
import com.convoconnect.messenger.sms.text.feature.scheduled.ScheduledActivity
import com.convoconnect.messenger.sms.text.feature.settings.SettingsActivity
import com.convoconnect.messenger.sms.text.manager.NotificationManager
import com.convoconnect.messenger.sms.text.manager.PermissionManager
import com.convoconnect.messenger.sms.text.common.PreferanceData.AppPreference
import com.convoconnect.messenger.sms.text.common.PreferanceData.PreferenceKeys
import com.convoconnect.messenger.sms.text.common.prefixAd.SplashGameInterstitialAdLoader
import com.convoconnect.messenger.sms.text.common.staticData.EventKeys
import com.convoconnect.messenger.sms.text.common.util.extensions.LogE
import com.convoconnect.messenger.sms.text.feature.localization.LocalizationActivityNew
import com.convoconnect.messenger.sms.text.feature.main.FragBottomMain
import com.convoconnect.messenger.sms.text.feature.settings.swipe.SwipeActionControllerActivity
import com.convoconnect.messenger.sms.text.feature.settings.thememode.ThemeModeActivity
import com.convoconnect.messenger.sms.text.feature.widget.WidgetActivity
import com.convoconnect.messenger.sms.text.utils.COME_FROM
import com.convoconnect.messenger.sms.text.utils.FROM_SETTING
import java.io.File
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton
import com.convoconnect.messenger.sms.text.feature.notificationprefs.NotificationPrefsActivity as NotificationPrefsActivity1

@SuppressLint("All")
@Singleton
class Navigator @Inject constructor(
    private val context: Context,
    private val notificationManager: NotificationManager,
    private val permissions: PermissionManager,
    private val appPrefs: AppPreference
) {


    var fragBottomMain: FragBottomMain? = null

    private fun startActivity(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)

    }

    private fun startActivityExternal(intent: Intent) {
        if (intent.resolveActivity(context.packageManager) != null) {
            startActivity(intent)
        } else {
            startActivity(Intent.createChooser(intent, null))
        }
    }

    fun showDefaultSmsDialog(context: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(RoleManager::class.java) as RoleManager
            val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS)
            context.startActivityForResult(intent, 42389)
        } else {
            val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
            intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, context.packageName)
            context.startActivity(intent)
        }
        AppUtils.logAdapterMessages(
            EventKeys.home_screen,
            EventKeys.show,
            EventKeys.set_as_default_dialog
        )
    }

    fun showCompose(
        body: String? = null,
        images: List<Uri>? = null,
        isScheduleClicked: Boolean = false
    ) {
        val intent = Intent(context, ComposeActivity::class.java)
        intent.putExtra(Intent.EXTRA_TEXT, body)
        intent.putExtra("isScheduleClicked", isScheduleClicked)
        images?.takeIf { it.isNotEmpty() }?.let {
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(images))
        }
        startActivity(intent)
    }


    fun showConversation(
        threadId: Long,
        query: String? = null,
        messageId: Long? = -1
    ) {
        val intent = Intent(context, ComposeActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("threadId", threadId)
            .putExtra("query", query)
            .putExtra("messageIdForScroll", messageId)
        startActivity(intent)
    }

    fun showMedia(partId: Long) {
        val intent = Intent(context, GalleryActivity::class.java)
        intent.putExtra("partId", partId)
        startActivity(intent)
    }

    fun showBackup() {
        startActivity(Intent(context, BackupActivity::class.java))
    }

    fun showScheduled() {
        val intent = Intent(context, ScheduledActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    fun showHome() {
        val intent = Intent(context, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }


    fun showStarred() {
        val intent = Intent(context, StarredActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    fun showSettings() {
        val intent = Intent(context, SettingsActivity::class.java)
        startActivity(intent)
    }

    fun showFilterDialog(
        mainActivity: AppCompatActivity,
        mCheckedItem: Pair<Int, String>,
        appPrefs: AppPreference,
        startDate: Date?,
        endDate: Date?
    ) {
//        val addPhotoBottomDialogFragment = FragBottomMain()
        fragBottomMain = FragBottomMain()
        fragBottomMain?.apply {
            arguments = Bundle().apply {
                putSerializable("mCheckedItem", mCheckedItem)
                putSerializable("startDate", startDate)
                putSerializable("endDate", endDate)
            }
        }
        fragBottomMain?.show(
            mainActivity.supportFragmentManager,
            "FragBottomMain"
        )

    }

    fun showBlockedConversations() {
        val intent = Intent(context, BlockingActivity::class.java)
        startActivity(intent)
    }

    fun showThemeModeActivity() {
        val intent = Intent(context, ThemeModeActivity::class.java)
        startActivity(intent)
    }

    fun showSwipeActionControllerActivity() {
        val intent = Intent(context, SwipeActionControllerActivity::class.java)
        startActivity(intent)
    }

    fun makePhoneCall(address: String) {
        val action = if (permissions.hasCalling()) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val intent = Intent(action, Uri.parse("tel:$address"))
        startActivityExternal(intent)
        appPrefs.saveData(PreferenceKeys.SystemDialogOpened, true)
    }

    fun shareMessage(message: String) {
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "text/plain"
        intent.putExtra(Intent.EXTRA_TEXT, message)
        startActivityExternal(intent)
        appPrefs.saveData(PreferenceKeys.SystemDialogOpened, true)
    }

    fun showInvite() {
        Intent(Intent.ACTION_SEND)
            .setType("text/plain")
            .putExtra(
                Intent.EXTRA_TEXT,
                context.getString(R.string.hey_checkout) + BuildConfig.APPLICATION_ID
            )
            .let { Intent.createChooser(it, null) }
            .let(::startActivityExternal)
        appPrefs.saveData(PreferenceKeys.SystemDialogOpened, true)

    }

    fun addContact(address: String) {
        AppUtils.logAdapterMessages(
            EventKeys.message_detail,
            EventKeys.click,
            EventKeys.details_add_to_contacts
        )
        val intent = Intent(Intent.ACTION_INSERT)
            .setType(ContactsContract.Contacts.CONTENT_TYPE)
            .putExtra(ContactsContract.Intents.Insert.PHONE, address)

        startActivityExternal(intent)
    }


    private val deviceName = Build.MANUFACTURER.lowercase(Locale.getDefault())

    fun editContact(lookupKey: String) {
        AppUtils.logAdapterMessages(
            EventKeys.message_detail,
            EventKeys.click,
            EventKeys.details_edit
        )
        if (deviceName.contains("huawei")) {
            contactViewIntent(lookupKey)
        } else if (deviceName.contains("xiaomi")) {
            contactViewIntent(lookupKey)
        } else if (deviceName.contains("oppo")) {
            contactViewIntent(lookupKey)
        } else if (deviceName.contains("vivo")) {
            contactViewIntent(lookupKey)
        } else if (deviceName.contains("meizu")) {
            contactViewIntent(lookupKey)
        } else {
            contactEditIntent(lookupKey)
        }

    }

    private fun contactViewIntent(lookupKey: String) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(
                Uri.withAppendedPath(
                    ContactsContract.Contacts.CONTENT_LOOKUP_URI,
                    lookupKey
                ), ContactsContract.Contacts.CONTENT_ITEM_TYPE
            )
        }
        startActivityExternal(intent)
    }

    private fun contactEditIntent(lookupKey: String) {
        val intent = Intent(Intent.ACTION_EDIT).apply {
            setDataAndType(
                Uri.withAppendedPath(
                    ContactsContract.Contacts.CONTENT_LOOKUP_URI,
                    lookupKey
                ), ContactsContract.Contacts.CONTENT_ITEM_TYPE
            )
        }
        startActivityExternal(intent)
    }


    fun viewFile(file: File) {
        val data = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.name.split(".").last())
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(data, type)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

        startActivityExternal(intent)
    }

    fun shareFile(file: File) {
        val data = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.name.split(".").last())
        val intent = Intent(Intent.ACTION_SEND)
            .setType(type)
            .putExtra(Intent.EXTRA_STREAM, data)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

        startActivityExternal(intent)
    }

    fun showNotificationSettings(threadId: Long = 0, fromContactInfo: Boolean = false) {
        val intent = Intent(context, NotificationPrefsActivity1::class.java)
        intent.putExtra("threadId", threadId)
        intent.putExtra("fromContactInfo", fromContactInfo)
        startActivity(intent)

    }

    fun showWidgetScreen() {
        val intent = Intent(context, WidgetActivity::class.java)
        startActivity(intent)
    }

    fun showLanguagesSettings() {
        val intent = Intent(context, LocalizationActivityNew::class.java)
        intent.putExtra(COME_FROM, FROM_SETTING)
        startActivity(intent)
    }

    fun showNotificationChannel(threadId: Long = 0) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (threadId != 0L) {
                notificationManager.createNotificationChannel(threadId)
            }
            val channelId = notificationManager.buildNotificationChannelId(threadId)
            val intent = Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_CHANNEL_ID, channelId)
                .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            startActivity(intent)
        }
        appPrefs.saveData(PreferenceKeys.SystemDialogOpened, true)

    }

    fun showGame(activity: Activity) {
        GameZoneBuilder.with().setInterstitialAdLoadCallback { activity ->
            SplashGameInterstitialAdLoader.loadFullScreenAds(
                activity, "game"
            )
        }.startGameZoneMainActivity(activity)
    }

    fun showmessagesPlusSnackbar(s: String) {}

    fun rateApp() {
        val uri = Uri.parse("market://details?id=" + context.packageName)
        val myAppLinkToMarket = Intent(Intent.ACTION_VIEW, uri)
        try {
            startActivity(myAppLinkToMarket)
        } catch (e: ActivityNotFoundException) {
            LogE("rateApp: ", e.message.toString())
        }
    }

}
