package com.convoconnect.messenger.sms.text.common.staticData;

import static com.convoconnect.messenger.sms.text.common.util.extensions.LogExtensionsKt.LogE;
import static com.convoconnect.messenger.sms.text.common.util.extensions.LogExtensionsKt.LogW;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.util.Log;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.convoconnect.messenger.sms.text.R;
import com.convoconnect.messenger.sms.text.common.MessagesApplication;
import com.convoconnect.messenger.sms.text.common.PreferanceData.AppPreference;
import com.convoconnect.messenger.sms.text.common.PreferanceData.PreferenceKeys;

public class UtilsStaticData {
    public static String is_ads_remove = "ads_free";
    public static String is_list_native_ad_enabled = "is_list_native_ad_enabled";
    public static String native_ad_type = "native_ad_type";
    public static String external_link = "external_link";
    public static String external_click = "external_click";
    public static final String admob_reward = "reward";
    public static final String admob_int = "interstitial";
    public static final String ads_interstitial_gamezone = "ads_interstitial_gamezone";
    public static final String ads_interstitial_splash = "ads_interstitial_splash";
    public static String ads_native ="ads_native";
    public static String ads_native_inline="ads_native_inline";
    public static String ads_native_gamezone= "ads_native_gamezone";

    public static String ads_banner ="ads_banner";
    public static String ads_banner_splash="ads_banner_splash";
    public static String ads_banner_gamezone= "ads_banner_gamezone";



    /* RC varables */
    public static String pro_app_key = "start_like_pro";
    public static String privacy_policy_tc_url = "privacy_policy_tc_url";
    public static String reward_ad_show_process_dialog_close_time = "reward_ad_show_process_dialog_close_time";
    public static String is_intro_screen_enabled = "is_intro_screen_enabled";
    public static String adMobMessageBackInterstitial = "adMobMessageBackInterstitial";
    public static String back_admob_interestial = "back_admob_interestial";
    public static String admob_native = "admob_native";
    public static String admob_list_native = "admob_list_native";
    public static String back_admob_native = "back_admob_native";
    public static String back_admob_banner = "back_admob_banner";
    public static String admob_app_open_back = "admob_app_open_back";
    public static String is_back_id_required = "is_back_id_required";
    public static String Immediate_update_mode = "Immediate_update_mode";
    public static String update_dialog_show = "update_dialog_show";
    public static String is_pro_app_enabled = "is_pro_app_enabled";
    public static String is_enabled_gamezon = "is_enabled_gamezon";
    public static String show_game_or_language = "show_game_or_language";
    public static String is_app_live = "is_app_live";
    public static String is_app_redirect_immediate = "is_app_redirect_immediate";
    public static String app_redirect_package = "app_redirect_package";
    public static String isMarkAllAsReadIntAdsEnabled = "isMarkAllAsReadIntAdsEnabled";
    public static String preload_premium_ad = "preload_premium_ad";
    public static String list_native_ad_details = "list_native_ad_details";
    public static String home_game_icon_external = "home_game_icon_external";

    public static String isEnableSettingOnBackIntAds = "isEnableSettingOnBackIntAds";
    public static String isEnableContactBackIntAds = "isEnableContactBackIntAds";
    public static String isEnableScheduledBackIntAds = "isEnableScheduledBackIntAds";

    public static String isEnableStarredBackIntAds = "isEnableStarredBackIntAds";
    public static String isEnableBackUpBackIntAds = "isEnableBackUpBackIntAds";
    public static String isEnableBlockBackIntAds = "isEnableBlockBackIntAds";
    public static String isEnableGameScreenBackIntAds = "isEnableGameScreenBackIntAds";
    public static String isEnableGameExitIntAds = "isEnableGameExitIntAds";
    public static String isEnableSplashBannerAds = "isEnableSplashBannerAds";
    public static String isEnableBlockDialogIntAds = "isEnableBlockDialogIntAds";

    public static String isEnableAppResumeOpenAd = "isEnableAppResumeOpenAd";
    public static String isEnableMessageBackIntAds = "isEnableMessageBackIntAds";
    public static String isSplashAdType = "isSplashAdType";
    public static String show_collect_data_dialog = "show_collect_data_dialog";
    public static String subscription_plan = "subscription_plan";
    public static String messageLimit = "messageLimit";


    //for subscription
    public static String inAppSubsricptionKey = "inAppSubsricptionKey";
    public static final String subscription_ui = "subscription_ui";
    public static final String premium_feature_dialog_data = "premium_feature_dialog_data";
    public static final String premium_feature_with_ads = "premium_feature_with_ads";

    public static final String slider_data = "slider_data";
    public static final String subscriptionPlan = "subscriptionPlan";

    //timer for splash
    public static String AppOpenFirstTime = "AppOpenFirstTime";
    public static String AppOpenRegularTime = "AppOpenRegularTime";

    //for rating
    public static String CustomNativeAdData = "CustomNativeAdData";
    public static String isEnableCustomExitAd = "isEnableCustomExitAd";

    public static final String bottom_large_ad_type = "bottom_large_ad_type";

    public static String isEnableAllPageBannerAds = "isEnableAllPageBannerAds"; // Home, Backup, Block,  Search, Scheduled, Settings banner
    public static String isEnableAllPageBannerNativeAds = "isEnableAllPageBannerNativeAds"; // custom Notification, ThemeMode, Swipe Action
    public static String isEnableGameBannerAds = "isEnableGameBannerAds";
    public static final String bottom_game_large_ad_type = "bottom_game_large_ad_type";


    //test
    public static String StartLikeProVisibilityCounter = "StartLikeProVisibilityCounter";
    @NotNull
    public static final String premium_ad_type = "premium_ad_type";

    public static final String admob_rewarded = "admob_rewarded"; // For Reward  Ad ID

    public static String back_admob_rewarded = "back_admob_rewarded"; // For Reward Ad ID

    public static final String RateUsDialogVisibilityCounter = "RateUsDialogVisibilityCounter";

    public static final String isEnableSwipeActionBackIntAds = "isEnableSwipeActionBackIntAds";

    public static final String isEnableThemeModeBackIntAds = "isEnableThemeModeBackIntAds";
    public static final String isEnableScreenWidgetBackIntAds = "isEnableScreenWidgetBackIntAds";


    public static String getInterstitialAdLoaderId(Context context) {
        String admob_interestial = "admob_interestial";
        if (UtilsStaticData.verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(admob_interestial).equals("")) {
                admob_interestial = MessagesApplication.remoteConfig.getString(admob_interestial);
                LogW("First", "remoteConfig ID---------" + admob_interestial);
            } else {
                admob_interestial = context.getString(R.string.admob_interestial);
                LogW("First", "String Resources ID---------" + admob_interestial);
            }
        } else {
            admob_interestial = "ca-app-pub-3940256099942544/1033173712";
        }
        return admob_interestial;
    }

    public static String getGameInterstitialAdLoaderId(Context context) {
        String admob_interestial_game = "admob_interestial_game";
        if (UtilsStaticData.verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(admob_interestial_game).equals("")) {
                admob_interestial_game = MessagesApplication.remoteConfig.getString(admob_interestial_game);
                LogW("First", "remoteConfig ID---------" + admob_interestial_game);
            } else {
                admob_interestial_game = context.getString(R.string.admob_interestial);
                LogW("First", "String Resources ID---------" + admob_interestial_game);
            }
        } else {
            admob_interestial_game = "ca-app-pub-3940256099942544/1033173712";
        }
        return admob_interestial_game;
    }

    public static String getSplashInterstitialAdLoaderId(Context context) {
        String admob_interestial_splash = "admob_interestial_splash";
        if (UtilsStaticData.verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(admob_interestial_splash).equals("")) {
                admob_interestial_splash = MessagesApplication.remoteConfig.getString(admob_interestial_splash);
                LogW("First", "remoteConfig ID---------" + admob_interestial_splash);
            } else {
                admob_interestial_splash = context.getString(R.string.admob_interestial);
                LogW("First", "String Resources ID---------" + admob_interestial_splash);
            }
        } else {
            admob_interestial_splash = "ca-app-pub-3940256099942544/1033173712";
        }
        return admob_interestial_splash;
    }

    public static String rewardedAdLoader_ID(Context context) {
        String admob_rewarded_new_3;
        if (UtilsStaticData.verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(UtilsStaticData.admob_rewarded).equals("")) {
                admob_rewarded_new_3 = MessagesApplication.remoteConfig.getString(UtilsStaticData.admob_rewarded);
            } else {
                admob_rewarded_new_3 = context.getString(R.string.admob_rewarded);
            }
        } else {
            admob_rewarded_new_3 = "ca-app-pub-3940256099942544/5224354917";
        }
        Log.w("msg", "FirebaseAds admob_rewarded : " + admob_rewarded_new_3);
        return admob_rewarded_new_3;
    }

    public static String rewardedAdLoader_ID_reload(Context context) {
        String back_admob_rewarded;
        if (UtilsStaticData.verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(UtilsStaticData.back_admob_rewarded).equals("")) {
                back_admob_rewarded = MessagesApplication.remoteConfig.getString(UtilsStaticData.back_admob_rewarded);
            } else {
                back_admob_rewarded = context.getString(R.string.back_admob_rewarded);
            }
        } else {
            back_admob_rewarded = "ca-app-pub-3940256099942544/5224354917";
        }
        Log.w("msg", "FirebaseAds back_admob_rewarded : " + back_admob_rewarded);
        return back_admob_rewarded;
    }


    public static String getInterstitialAdLoadReloadId(Context context) {
        String back_admob_interestial;
        if (verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(UtilsStaticData.back_admob_interestial).equals("")) {
                LogW("msg", "admob loadAdmobInt method  else first firbase   " + MessagesApplication.remoteConfig.getString(UtilsStaticData.back_admob_interestial));
                back_admob_interestial = MessagesApplication.remoteConfig.getString(UtilsStaticData.back_admob_interestial);
            } else {
                LogW("msg", "admob loadAdmobInt method  else first project   ");
                back_admob_interestial = context.getString(R.string.back_admob_interestial);
            }
        } else {
            back_admob_interestial = "ca-app-pub-3940256099942544/1033173712";
        }
        LogW("msg", "FirebaseAds admob_interstitial : " + back_admob_interestial);
        return back_admob_interestial;

    }
    /*method used for capping main id */

    public static String getInterstitialAdOnCappingID(Context context) {
        if (UtilsStaticData.verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(UtilsStaticData.adMobMessageBackInterstitial).equals("")) {
                return MessagesApplication.remoteConfig.getString(UtilsStaticData.adMobMessageBackInterstitial);
            } else {
                return context.getString(R.string.adMobMessageBackInterstitial);
            }
        } else {
            return "ca-app-pub-3940256099942544/1033173712";
        }
    }

    public static String getBannerAdId(Context context) {
        String admob_banner = "admob_banner";
        if (UtilsStaticData.verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(admob_banner).equals("")) {
                return MessagesApplication.remoteConfig.getString(admob_banner);
            } else {
                return context.getString(R.string.admob_banner);
            }
        } else {
            return "ca-app-pub-3940256099942544/6300978111";
        }
    }
    public static String getGamesBannerAdId(Context context) {
        String admob_banner_game = "admob_banner_game";
        if (UtilsStaticData.verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(admob_banner_game).equals("")) {
                return MessagesApplication.remoteConfig.getString(admob_banner_game);
            } else {
                return context.getString(R.string.admob_banner_game);
            }
        } else {
            return "ca-app-pub-3940256099942544/6300978111";
        }
    }
    public static String getSplashBannerAdId(Context context) {
        String admob_banner_splash = "admob_banner_splash";
        if (UtilsStaticData.verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(admob_banner_splash).equals("")) {
                return MessagesApplication.remoteConfig.getString(admob_banner_splash);
            } else {
                return context.getString(R.string.admob_banner_splash);
            }
        } else {
            return "ca-app-pub-3940256099942544/6300978111";
        }
    }

    public static String getBannerAdReloadId(Context context) {
        if (UtilsStaticData.verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(UtilsStaticData.back_admob_banner).equals("")) {
                return MessagesApplication.remoteConfig.getString(UtilsStaticData.back_admob_banner);
            } else {
                return context.getString(R.string.back_admob_banner);
            }
        } else {
            return "ca-app-pub-3940256099942544/6300978111";
        }
    }

    public static String getOpenAdId(Context context) {
        if (UtilsStaticData.verifyForTest(context)) {
            String admob_app_open = "admob_app_open";
            if (new AppPreference(context).getIntData(PreferenceKeys.APP_COUNTER) - 1 == 1) {
                LogE("ADMOB", "getOpenAdId: 1 ->" + new AppPreference(context).getIntData(PreferenceKeys.APP_COUNTER));
                return context.getString(R.string.admob_app_open);
            } else {
                if (!MessagesApplication.remoteConfig.getString(admob_app_open).equals("")) {
                    return MessagesApplication.remoteConfig.getString(admob_app_open);
                } else {
                    return context.getString(R.string.admob_app_open);
                }
            }
        } else {
            return "ca-app-pub-3940256099942544/3419835294";
        }
    }

    public static String getSplashOpenAdId(Context context) {
        if (UtilsStaticData.verifyForTest(context)) {
            String admob_app_open_splash = "admob_app_open_splash";
            if (new AppPreference(context).getIntData(PreferenceKeys.APP_COUNTER) - 1 == 1) {
                LogE("ADMOB", "getOpenAdId: 1 ->" + new AppPreference(context).getIntData(PreferenceKeys.APP_COUNTER));
                return context.getString(R.string.admob_app_open_splash);
            } else {
                if (!MessagesApplication.remoteConfig.getString(admob_app_open_splash).equals("")) {
                    return MessagesApplication.remoteConfig.getString(admob_app_open_splash);
                } else {
                    return context.getString(R.string.admob_app_open_splash);
                }
            }
        } else {
            return "ca-app-pub-3940256099942544/3419835294";
        }
    }

    public static String getBackOpenAdId(Context context) {
        if (UtilsStaticData.verifyForTest(context)) {
            if (new AppPreference(context).getIntData(PreferenceKeys.APP_COUNTER) - 1 == 1) {
                LogE("ADMOB", "Reload: 1 ->" + new AppPreference(context).getIntData(PreferenceKeys.APP_COUNTER));
                return context.getString(R.string.back_admob_open_id);
            } else {
                if (!MessagesApplication.remoteConfig.getString(admob_app_open_back).equals("")) {
                    return MessagesApplication.remoteConfig.getString(admob_app_open_back);
                } else {
                    return context.getString(R.string.back_admob_open_id);
                }
            }
        } else {
            return "ca-app-pub-3940256099942544/3419835294";
        }
    }

    public static String getNativeId(Context context) {
        if (UtilsStaticData.verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(admob_native).equals("")) {
                return MessagesApplication.remoteConfig.getString(admob_native);
            } else {
                return context.getString(R.string.admob_native);
            }
        } else {
            return "ca-app-pub-3940256099942544/2247696110";
        }
    }

    public static String getGameZoneNativeId(Context context) {
        String admob_native_game = "admob_native_game";
        if (UtilsStaticData.verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(admob_native_game).equals("")) {
                return MessagesApplication.remoteConfig.getString(admob_native_game);
            } else {
                return context.getString(R.string.admob_native_game);
            }
        } else {
            return "ca-app-pub-3940256099942544/2247696110";
        }
    }

    public static String getListNativeAdId(Context context) {
        if (UtilsStaticData.verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(admob_list_native).equals("")) {
                return MessagesApplication.remoteConfig.getString(admob_list_native);
            } else {
                return context.getString(R.string.admob_list_native);
            }
        } else {
            return "ca-app-pub-3940256099942544/2247696110";
        }
    }

    public static String getBackNativeId(Context context) {
        if (UtilsStaticData.verifyForTest(context)) {
            if (!MessagesApplication.remoteConfig.getString(back_admob_native).equals("")) {
                return MessagesApplication.remoteConfig.getString(back_admob_native);
            } else {
                return context.getString(R.string.back_admob_native);
            }
        } else {
            return "ca-app-pub-3940256099942544/2247696110";
        }
    }

    public static boolean verifyForTest(Context context) {
        try {
            PackageInfo pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return pInfo.versionName.matches("[0-9][0-9.]*[0-9]");

        } catch (Exception e) {
            LogE("verifyForTest", "verifyForTest: Error" + e.getMessage());
            return false;
        }
    }
}
