package com.convoconnect.messenger.sms.text.common.prefixAd;

import static com.convoconnect.messenger.sms.text.common.util.extensions.LogExtensionsKt.LogE;
import static com.convoconnect.messenger.sms.text.common.util.extensions.LogExtensionsKt.LogW;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import com.convoconnect.messenger.sms.text.common.util.AppUtils;
import com.convoconnect.messenger.sms.text.common.PreferanceData.PreferenceKeys;
import com.convoconnect.messenger.sms.text.common.staticData.EventKeys;
import com.convoconnect.messenger.sms.text.common.staticData.UtilsStaticData;
import com.convoconnect.messenger.sms.text.utils.ConstantsKt;
import com.convoconnect.messenger.sms.text.utils.PreferenceManager;

@SuppressLint("All")
public class AdmobInterstitialLoaderCapping {

    private static adFinishBack myAdFinish;

    public static boolean isAdmobIntAdLoaded = false;
    public static boolean AdmobIntAdLoaded = false;
    private static final String TAG = "Admob_Interstitial_ConversionBack+++++";

    public static InterstitialAd mAdmobInterstitialAd = null;

    private static String ads_interstitial_capping = "ads_interstitial_capping";
    private static String f_request = "f_request";
    private static String f_load = "f_load";
    private static String f_fail_to_load = "f_fail_to_load";
    private static String f_fail_to_show = "f_fail_to_show";
    private static String f_show = "f_show";
    private static String f_click = "f_click";
    private static String f_impression = "f_impression";
    private static String f_dismiss = "f_dismiss";

    public static boolean isAdLoaded() {

        if (mAdmobInterstitialAd != null) {
            AdmobIntAdLoaded = true;
            return true;
        } else {
            AdmobIntAdLoaded = false;
            return false;
        }

    }

    /**
     * This method is used to load the Capping Interstitial ads, on back of compose activity.
     */
    public static void loadAdmobInt(final Context context) {
        LogW(TAG + "First", "------loadAdmobInt-------");
        try {
            String actName = AppUtils.checkActivityName(context);
            if (ConstantsKt.isOnline(context)) {
                AdRequest adRequest = new AdRequest.Builder().build();
                if (isAdLoaded()) {
                    return;
                }

                AppUtils.logAdapterMessages(ads_interstitial_capping, f_request, actName);
                InterstitialAd.load(context, UtilsStaticData.getInterstitialAdOnCappingID(context), adRequest,
                        new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                LogW(TAG + "First", "------onAdLoaded-------");
                                logIntersImpressionData(interstitialAd);
                                AppUtils.logAdapterMessages(ads_interstitial_capping, f_load, actName);
                                mAdmobInterstitialAd = interstitialAd;
                                isAdmobIntAdLoaded = true;
                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                LogW(TAG + "First", "------onAdFailedToLoad-------" + loadAdError.getCode());
                                isAdmobIntAdLoaded = false;
                                AppUtils.logAdapterMessages(ads_interstitial_capping, f_fail_to_load, loadAdError.getCode() + "_" + actName);
                            }
                        });
            }

        } catch (Exception e) {
            e.printStackTrace();
            LogW(TAG + "First", "------Exceptions------" + e.getMessage());
        }
    }


    private static Integer isCount = 0;

    /**
     * This method is will be called by the user to show the Capping Interstitial ads.
     */
    public static void showFullScreenAds(Activity context, adFinishBack myAdFinish1) {
        LogW(TAG, "------Show AD-------");
        myAdFinish = myAdFinish1;

        String actName = AppUtils.checkActivityName(context);
        if (!PreferenceManager.getBooleanData(context, UtilsStaticData.is_ads_remove)) {
            if (isAdLoaded() && !PreferenceManager.getBooleanData(context, PreferenceKeys.Admob_IntAd, false)) {
                mAdmobInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdClicked() {
                        AppUtils.logAdapterMessages(ads_interstitial_capping, f_click, actName);
                        super.onAdClicked();
                    }

                    @Override
                    public void onAdImpression() {
                        AppUtils.logAdapterMessages(ads_interstitial_capping, f_impression, actName);
                        super.onAdImpression();
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        AppUtils.logAdapterMessages(ads_interstitial_capping, f_dismiss, actName);

                        LogW(TAG + "showAD", "------onAdDismissedFullScreenContent-------");
                        PreferenceManager.saveData(context, PreferenceKeys.IS_OPEN_AD, true);
                        mAdmobInterstitialAd = null;

                        myAdFinish.adFinished();
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                        // Called when fullscreen content failed to show.

                        LogW(TAG + "showAd", "------onAdFailedToShowFullScreenContent-------" + adError.getCode());

                        AppUtils.logAdapterMessages(ads_interstitial_capping, f_fail_to_show, adError.getCode() + "_" + actName);
                        PreferenceManager.saveData(context, PreferenceKeys.IS_OPEN_AD, true);
                        mAdmobInterstitialAd = null;
                        myAdFinish.adFinished();
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        AppUtils.logAdapterMessages(ads_interstitial_capping, f_show, actName);
                        LogW(TAG + "showAd", "------onAdShowedFullScreenContent-------" + context.getClass().getSimpleName());
                        PreferenceManager.saveData(context, PreferenceKeys.IS_OPEN_AD, false);
                    }
                });
                if (mAdmobInterstitialAd != null) {
                    mAdmobInterstitialAd.show(context);
                } else {
                    LogE(TAG, "showAd:---else new ");
                    myAdFinish.adFinished();
                }
            } else {
                if (isCount <= 3) {
                    myAdFinish.adFinished();
                    isCount++;
                    LogE(TAG, "showAd:---else new 22");
                } else {
                    myAdFinish.adFinished();
                }
            }
            LogW(TAG, "PreferenceKeys.IS_OPEN_AD=====" + PreferenceManager.getBooleanData(context, PreferenceKeys.IS_OPEN_AD, true));

        } else {
            myAdFinish.adFinished();
        }
    }

    private static void logIntersImpressionData(InterstitialAd interstitialAd) {
        interstitialAd.setOnPaidEventListener(adValue -> {
            Bundle mBundle = new Bundle();
            mBundle.putString("valueMicros", adValue.getValueMicros() + "");
            mBundle.putString("currencyCode", adValue.getCurrencyCode() + "");
            mBundle.putString("precision", adValue.getPrecisionType() + "");
            mBundle.putString("adUnitId", interstitialAd.getAdUnitId());
            AppUtils.logAdapterBundleMessages(EventKeys.paid_ad_impression, mBundle);

        });
    }

    public interface adFinishBack {
        void adFinished();
    }
}