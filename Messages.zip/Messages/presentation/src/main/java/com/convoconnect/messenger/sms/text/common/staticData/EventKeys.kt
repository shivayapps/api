package com.convoconnect.messenger.sms.text.common.staticData

class EventKeys {
    companion object {


        /* param name */
        const val show: String = "show"
        const val exit: String = "exit"
        const val submit: String = "submit"
        const val unsubmit: String = "unsubmit"
        const val setup: String = "setup"
        const val click: String = "click"
        const val long_click: String = "long_click"
        const val from: String = "long_click"
        const val send: String = "send"
        const val add: String = "add"
        const val scheduled: String = "scheduled"
        const val enable: String = "enable"
        const val disable: String = "disable"
        const val save: String = "save"
        const val play = "play"
        const val anr = "anr"

        /* Home page Events */
        const val home_screen: String = "home_screen"

        const val exit_dialog: String = "exit_dialog"
        const val rateus_dialog: String = "rateus_dialog"
        const val set_as_default_dialog: String = "set_as_default_dialog"
        const val search: String = "search"
        const val message: String = "message"
        const val mms: String = "mms"
        const val success: String = "success"
        const val failed: String = "failed"
        const val start_chat: String = "start_chat"
        const val scroll_to_top: String = "scroll_to_top"
        const val play_games: String = "play_games"
        const val change: String = "change"

        const val menu_remove_ads_pro: String = "menu_remove_ads_pro"
        const val menu_games: String = "menu_games"
        const val menu_language: String = "menu_language"
        const val menu_archived: String = "menu_archived"
        const val menu_mark_all_as_read: String = "menu_mark_all_as_read"
        const val menu_backup_restore: String = "menu_backup_restore"
        const val menu_scheduled: String = "menu_scheduled"
        const val menu_settings: String = "menu_settings"
        const val menu_messages: String = "menu_messages"

        const val filter_by_default: String = "filter_by_default"
        const val filter_by_today: String = "filter_by_today"
        const val filter_by_month: String = "filter_by_month"
        const val filter_by_year: String = "filter_by_year"
        const val filter_by_custom: String = "filter_by_custom"

        const val drawer_remove_ads_pro: String = "drawer_remove_ads_pro"
        const val drawer_removeads: String = "drawer_removeads"
        const val drawer_messages: String = "drawer_messages"
        const val drawer_archive: String = "drawer_archive"
        const val drawer_scheduled: String = "drawer_scheduled"
        const val drawer_starred: String = "drawer_starred"
        const val drawer_mark_all_read: String = "drawer_mark_all_read"
        const val drawer_backup_restore: String = "drawer_backup_restore"
        const val drawer_block_list: String = "drawer_block_list"
        const val drawer_mode_change: String = "drawer_mode_change"
        const val drawer_language: String = "drawer_language"

        const val drawer_settings: String = "drawer_settings"
        const val drawer_rate_us: String = "drawer_rate_us"
        const val drawer_more_app: String = "drawer_more_app"

        const val menu_pin: String = "menu_pin"
        const val menu_unpin: String = "menu_unpin"
        const val menu_archive: String = "menu_archive"
        const val menu_unarchive: String = "menu_unarchive"
        const val menu_delete: String = "menu_delete"
        const val menu_add_to_contacts: String = "menu_add_to_contacts"
        const val menu_mark_as_read: String = "menu_mark_as_read"
        const val menu_mark_as_unread: String = "menu_mark_as_unread"
        const val menu_block: String = "menu_block"

        const val category_all: String = "category_all"
        const val category_personal: String = "category_personal"
        const val category_transaction: String = "category_transaction"
        const val category_offers: String = "category_offers"
        const val category_otps: String = "category_otps"


        /* Message Detail Events */
        const val message_detail: String = "message_detail"

        const val details: String = "details"
        const val details_call: String = "details_call"
        const val details_message: String = "details_message"
        const val details_edit: String = "details_edit"
        const val details_add_to_contacts: String = "details_add_to_contacts"
        const val details_phone_no_copy: String = "details_phone_no_copy"
        const val details_notifications: String = "details_notifications"
        const val details_archive: String = "details_archive"
        const val details_unarchive: String = "details_unarchive"
        const val details_block: String = "details_block"
        const val details_unblock: String = "details_unblock"
        const val details_delete_conversations: String = "details_delete_conversations"
        const val call: String = "call"
        const val emoji: String = "emoji"
        const val camera: String = "camera"
        const val gallery: String = "photo"
        const val schedule: String = "schedule"
        const val contact: String = "contact"
        const val scroll_to_down: String = "scroll_to_down"
        const val unblock: String = "unblock"
        const val add_more_people: String = "add_more_people"
        const val send_as_group_message: String = "send_as_group_message"
        const val starred: String = "starred"
        const val unstarred: String = "unstarred"
        const val copy: String = "copy"
        const val delete: String = "delete"
        const val menu_share: String = "menu_share"
        const val menu_forward: String = "menu_forward"
        const val menu_view_details: String = "menu_view_details"


        /* Theme Mode */
        const val theme_mode: String = "theme_mode"

        const val mode_change_day: String = "mode_change_day"
        const val mode_change_night: String = "mode_change_night"
        const val mode_change_system: String = "mode_change_system"

        /* Scheduled Messages */
        const val schedule_message: String = "schedule_message"

        const val scheduled_message: String = "scheduled_message"
        const val successfully: String = "successfully"
        const val send_now: String = "send_now"
        const val copy_text: String = "copy_text"

        /* Block List */
        const val block_list: String = "block_list"

        const val drop_message: String = "drop_message"
        const val blocked_message: String = "blocked_message"

        /* Subscription */
        const val subscription: String = "subscription"
        const val close: String = "close"
        const val inside: String = "inside"
        const val privacy_policy: String = "privacy_policy"
        const val plan: String = "_plan"
        const val lifetime_plan: String = "lifetime_plan"

        /* Backup & Restore */
        const val backup_restore: String = "backup_restore"

        const val restore_now: String = "restore_now"
        const val backup: String = "backup"


        /* Contact Activity */
        const val contacts: String = "contacts"

        /* Splash Activity */
        const val splash: String = "splash"


        /* Settings */
        const val settings: String = "settings"

        const val appearance_mode_change_day: String = "appearance_mode_change_day"
        const val appearance_mode_change_system: String = "appearance_mode_change_system"
        const val appearance_mode_change_night: String = "appearance_mode_change_night"
        const val appearance_font_size_small: String = "appearance_font_size_small"
        const val appearance_font_size_normal: String = "appearance_font_size_normal"
        const val appearance_font_size_large: String = "appearance_font_size_large"
        const val appearance_font_size_extra_larger: String = "appearance_font_size_extra_larger"
        const val appearance_automatic_contact_color: String = "appearance_automatic_contact_color"
        const val appearance_system_font: String = "appearance_system_font"
        const val games: String = "games"
        const val general_app_language: String = "general_app_language"
        const val general_notifications: String = "general_notifications"
        const val general_delay_sending: String = "general_delay_sending"
        const val general_widget_guide: String = "general_widget_guide"
        const val general_swipe_actions: String = "general_swipe_actions"
        const val general_delivery_confirmation: String = "general_delivery_confirmation"
        const val general_sign: String = "general_sign"
        const val auto_delete: String = "auto_delete"
        const val general_delete_msg_auto_daily: String = "general_delete_msg_auto_daily"
        const val general_delete_msg_auto_weekly: String = "general_delete_msg_auto_weekly"
        const val general_delete_msg_auto_monthly: String = "general_delete_msg_auto_monthly"
        const val general_delete_msg_auto_yearly: String = "general_delete_msg_auto_yearly"
        const val general_delete_msg_auto_custom: String = "general_delete_msg_auto_custom"
        const val general_send_long_msg_MMS: String = "general_send_long_msg_MMS"
        const val general_auto_compress_attachments_: String = "general_auto_compress_attachments_"
        const val general_sync_messages: String = "general_sync_messages"
        const val general_about_us: String = "general_about_us"

        const val notifications: String = "notifications"
        const val notification_prev_: String = "notification_prev_"
        const val wake_screen: String = "wake_screen"
        const val b1_: String = "b1_"
        const val b2_: String = "b2_"
        const val b3_: String = "b3_"
        const val quick_reply: String = "quick_reply"
        const val tap_to_dismiss: String = "tap_to_dismiss"
        const val vibration: String = "vibration"



        /*Swipe Actions*/
        const val swipe = "swipe"
        const val swipe_actions = "swipe_actions"
        /*Firebase Notification*/
        const val firebase_notification = "firebase_notification"
        const val receive = "receive"


        /* Crash */
        const val crash: String = "crash"
        const val crash_textview: String = "crash_textview"


        const val throw_plug = "throw_plug"
        const val main_view_model = "main_view_model"
        const val main_application = "main_application"
        const val exception_handler = "exception_handler"

        const val pro_dialog: String = "pro_dialog"
        const val _pro: String = "_pro"
        const val _watch_video: String = "_watch_video"

        const val paid_ad_impression: String = "paid_ad_impression"

    }
}