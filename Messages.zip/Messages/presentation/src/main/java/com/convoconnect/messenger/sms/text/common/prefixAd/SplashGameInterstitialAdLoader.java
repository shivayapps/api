package com.convoconnect.messenger.sms.text.common.prefixAd;


import static com.convoconnect.messenger.sms.text.common.PreferanceData.PreferenceKeys.isAnyAdShowing;
import static com.convoconnect.messenger.sms.text.common.util.extensions.LogExtensionsKt.LogE;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.convoconnect.messenger.sms.text.common.MessagesApplication;
import com.convoconnect.messenger.sms.text.common.util.AppUtils;
import com.convoconnect.messenger.sms.text.common.PreferanceData.AppPreference;
import com.convoconnect.messenger.sms.text.common.PreferanceData.PreferenceKeys;
import com.convoconnect.messenger.sms.text.common.staticData.EventKeys;
import com.convoconnect.messenger.sms.text.common.staticData.UtilsStaticData;
import com.convoconnect.messenger.sms.text.common.util.BaseConfig;
import com.convoconnect.messenger.sms.text.utils.ConstantsKt;

/**
 * The type Interstitial ad loader.
 */
public class SplashGameInterstitialAdLoader {

    public static String ads_interstitial_splash = "ads_interstitial_splash";

    /**
     * The constant mAdmobInterstitialAd.
     */
    private static InterstitialAd mAdmobInterstitialAd = null;

    private static boolean isAdLoading = false;
    private static final String TAG = SplashGameInterstitialAdLoader.class.getSimpleName();

    private static String f_request = "f_request";
    private static String f_load = "f_load";
    private static String f_fail_to_load = "f_fail_to_load";
    private static String f_fail_to_show = "f_fail_to_show";
    private static String f_show = "f_show";
    private static String f_click = "f_click";
    private static String f_impression = "f_impression";
    private static String f_dismiss = "f_dismiss";
    @SuppressLint("StaticFieldLeak")
    private static AppPreference appPreference;

    /**
     * This method is will be called by the user to show the Interstitial ad for splash screen & game zone.
     */
    public static void showFullScreenAds(Activity activity, boolean isAdTrue, String ad_from, AdFinishWithControlListener admonishmentControl) {
        appPreference = new AppPreference(activity);
        if (!BaseConfig.Companion.newInstance(activity).getAds_free() && !appPreference.getBooleanData(UtilsStaticData.is_ads_remove) && ConstantsKt.isOnline(activity)) {
            if (isAdTrue) {
                LogE(TAG, "InterstitialAdLoader--------------- showFullScreenAds   : " + appPreference.getBooleanData(PreferenceKeys.Admob_IntAd));
                if (SplashGameInterstitialAdLoader.isAdLoaded() && !appPreference.getBooleanData(PreferenceKeys.Admob_IntAd, false)) {
                    showInterstitialAd(activity, ad_from, admonishmentControl);
                } else {
                    admonishmentControl.adFinished();
                }
            } else {
                admonishmentControl.adFinished();
            }

        } else {
            admonishmentControl.adFinished();
        }
    }

    /**
     * This method is used to load the Interstitial ads for splash screen and game zone.
     */
    public static void loadFullScreenAds(Context context, String ad_from) {
        appPreference = new AppPreference(context);
        if (!appPreference.getBooleanData(UtilsStaticData.is_ads_remove) && ConstantsKt.isOnline(context)) {
            if (!isAdLoaded() && !isAdLoading) {
                loadAdmobInt(context, ad_from);
            }
        }
    }


    /**
     * Is ad loaded boolean.
     * @return the boolean
     */
    public static boolean isAdLoaded() {

        if (!appPreference.getBooleanData(UtilsStaticData.is_ads_remove)) {
            return mAdmobInterstitialAd != null;
        } else {
            return false;
        }
    }


    /**
     * Load admob int.
     *
     * @param context the context
     */
    public static void loadAdmobInt(final Context context, String ad_from) {

        if (ConstantsKt.isOnline(context) && mAdmobInterstitialAd == null) {

            String actName = AppUtils.checkActivityName(context);

            f_request = "f_request";
            f_load = "f_load";
            f_fail_to_load = "f_fail_to_load";
            f_show = "f_show";
            f_fail_to_show = "f_fail_to_show";
            f_dismiss = "f_dismiss";
            f_click = "f_click";
            f_impression = "f_impression";

            String adId;
            if (ad_from.equalsIgnoreCase("game")) {
                adId = UtilsStaticData.getGameInterstitialAdLoaderId(context);
                ads_interstitial_splash = UtilsStaticData.ads_interstitial_gamezone;
            } else {
                adId = UtilsStaticData.getSplashInterstitialAdLoaderId(context);
                ads_interstitial_splash = UtilsStaticData.ads_interstitial_splash;
            }

            AppUtils.logAdapterMessages(ads_interstitial_splash, f_request, actName);
            isAdLoading = true;
            InterstitialAd.load(context, adId, new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    // The mInterstitialAd reference will be null until
                    // an ad is loaded.
                    AppUtils.logAdapterMessages(ads_interstitial_splash, f_load, actName);
                    mAdmobInterstitialAd = interstitialAd;
                    isAdLoading = false;
                    logSplashGameInterImpressionData(interstitialAd);
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    // Handle the error
                    AppUtils.logAdapterMessages(ads_interstitial_splash, f_fail_to_load, loadAdError.getCode() + "_" + actName);
                    mAdmobInterstitialAd = null;
                    if (MessagesApplication.remoteConfig.getString(UtilsStaticData.is_back_id_required).equals("true")) {
                        loadAdmobIntReload(context, ad_from);
                    }
                }
            });
        }
    }



    /**
     * The interface ad finish with control.
     */
    public interface AdFinishWithControlListener {

        /**
         * ad finished.
         */
        void adFinished();
    }


    /**
     * Show Interstitial ad.
     *
     * @param activity    the activity
     * @param finishWithControlListener the ad finish 1
     */
    public static void showInterstitialAd(Activity activity, String ad_from, AdFinishWithControlListener finishWithControlListener) {

        if (isAdLoaded() && !appPreference.getBooleanData(PreferenceKeys.Admob_IntAd, false)) {


            String actName = AppUtils.checkActivityName(activity);
            if (ad_from.equalsIgnoreCase("game")) {
                ads_interstitial_splash = UtilsStaticData.ads_interstitial_gamezone;
            } else {
                ads_interstitial_splash = UtilsStaticData.ads_interstitial_splash;
            }
            mAdmobInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {

                @Override
                public void onAdClicked() {
                    AppUtils.logAdapterMessages(ads_interstitial_splash, f_click, actName);
                    super.onAdClicked();
                }

                @Override
                public void onAdImpression() {
                    AppUtils.logAdapterMessages(ads_interstitial_splash, f_impression, actName);
                    super.onAdImpression();
                }

                @Override
                public void onAdDismissedFullScreenContent() {
                    AppUtils.logAdapterMessages(ads_interstitial_splash, f_dismiss, actName);

                    isAnyAdShowing = false;
                    mAdmobInterstitialAd = null;
                    appPreference.saveData(PreferenceKeys.IS_OPEN_AD, true);
                    finishWithControlListener.adFinished();

                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    AppUtils.logAdapterMessages(ads_interstitial_splash, f_fail_to_show, adError.getCode() + "_" + actName);
                    mAdmobInterstitialAd = null;
                    appPreference.saveData(PreferenceKeys.IS_OPEN_AD, true);
                    finishWithControlListener.adFinished();

                }

                @Override
                public void onAdShowedFullScreenContent() {
                    AppUtils.logAdapterMessages(ads_interstitial_splash, f_show, actName);
                    appPreference.saveData(PreferenceKeys.IS_OPEN_AD, false);
                }
            });
            if (!isAnyAdShowing) {
                isAnyAdShowing = true;
                mAdmobInterstitialAd.show(activity);
            }
        } else {
            finishWithControlListener.adFinished();
        }
    }

    /**
     * Load admob int reload.
     *
     * @param context the context
     */
    public static void loadAdmobIntReload(final Context context, String ad_from) {

        if (ConstantsKt.isOnline(context) && mAdmobInterstitialAd == null) {

            String actName = AppUtils.checkActivityName(context);

            f_request = "b_request";
            f_load = "b_load";
            f_fail_to_load = "b_fail_to_load";
            f_show = "b_show";
            f_fail_to_show = "b_fail_to_show";
            f_dismiss = "b_dismiss";
            f_click = "b_click";
            f_impression = "b_impression";


            String adId;
            if (ad_from.equalsIgnoreCase("game")) {
                adId = UtilsStaticData.getGameInterstitialAdLoaderId(context);
                ads_interstitial_splash = UtilsStaticData.ads_interstitial_gamezone;
            } else {
                adId = UtilsStaticData.getSplashInterstitialAdLoaderId(context);
                ads_interstitial_splash = UtilsStaticData.ads_interstitial_splash;
            }


            AppUtils.logAdapterMessages(ads_interstitial_splash, f_request, actName);

            InterstitialAd.load(context, adId, new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                    // The mInterstitialAd reference will be null until
                    // an ad is loaded.
                    AppUtils.logAdapterMessages(ads_interstitial_splash, f_load, actName);
                    mAdmobInterstitialAd = interstitialAd;
                    isAdLoading = false;
                    logSplashGameInterImpressionData(interstitialAd);
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError errorCode) {
                    // Handle the error
                    AppUtils.logAdapterMessages(ads_interstitial_splash, f_fail_to_load, errorCode.getCode() + "_" + actName);
                    isAnyAdShowing = false;
                    mAdmobInterstitialAd = null;
                    isAdLoading = false;

                }
            });
        }
    }
    private static void logSplashGameInterImpressionData(InterstitialAd interstitialAd) {
        interstitialAd.setOnPaidEventListener(adValue -> {
            Bundle mBundle = new Bundle();
            mBundle.putString("valueMicros", adValue.getValueMicros() + "");
            mBundle.putString("currencyCode", adValue.getCurrencyCode() + "");
            mBundle.putString("precision", adValue.getPrecisionType() + "");
            mBundle.putString("adUnitId", interstitialAd.getAdUnitId());
            AppUtils.logAdapterBundleMessages(EventKeys.paid_ad_impression, mBundle);
        });
    }
}