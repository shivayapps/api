package com.convoconnect.messenger.sms.text.common.PreferanceData

import android.content.Context
import android.content.SharedPreferences
import com.convoconnect.messenger.sms.text.common.util.extensions.LogE
import javax.inject.Inject

class AppPreference @Inject constructor(private val context: Context) {
    /**
     * Gets boolean data.
     *
     * @param context the context
     * @param key     the key
     * @return the boolean data
     */
    fun getBooleanData(key: String?): Boolean {
        return try {
            sharedPreferences.getBoolean(key, false) ?: false
        } catch (e: Exception) {
            false
        }
    }


    fun getLongData(key: String, def: Long): Long {
        return sharedPreferences.getLong(key, def)
    }

    /**
     * Gets boolean data.
     *
     * @param context the context
     * @param key     the key
     * @return the boolean data
     */
    fun getBooleanData(key: String?, def: Boolean): Boolean {
        return try {
            sharedPreferences.getBoolean(key, def)
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Gets int data.
     *
     * @param context the context
     * @param key     the key
     * @return the int data
     */
    fun getIntData(key: String?): Int {
        return try {
            sharedPreferences.getInt(key, 1) ?: 0
        } catch (e: Exception) {
            0
        }
    }

    fun getIntData(key: String?, def: Int): Int {
        return try {
            sharedPreferences
                .getInt(key, def)
                ?: 0
        } catch (e: Exception) {
            0
        }
    }

    /**
     * Gets string data.
     *
     * @param context the context
     * @param key     the key
     * @return the string data
     */
    // Get Data
    fun getStringData(key: String): String? {
        return if (key.contains("app_version_code")) {
            try {
                sharedPreferences.getString(key, "")
            } catch (e: Exception) {
                ""
            }
        } else {
            sharedPreferences.getString(key, "")
        }
    }

    /**
     * Save data.
     *
     * @param context the context
     * @param key     the key
     * @param val     the val
     */
    // Save Data
    fun saveData(key: String?, `val`: String?) {

        sharedPreferences.edit().putString(key, `val`)
            .apply()
    }

    /**
     * Save data.
     *
     * @param context the context
     * @param key     the key
     * @param val     the val
     */
    fun saveData(key: String?, `val`: Int) {
        sharedPreferences.edit().putInt(key, `val`)
            .apply()
    }

    /**
     * Save data.
     *
     * @param key     the key
     * @param val     the val
     */
    companion object {
        lateinit var sharedPreferences: SharedPreferences

        fun isInitSharedPref() = ::sharedPreferences.isInitialized
    }

    fun initPrefs() {
        sharedPreferences = context.getSharedPreferences("Prefs", Context.MODE_PRIVATE)
    }

    fun saveData(key: String?, boolean: Boolean) {

        LogE("saveData: ", "--------if")
        sharedPreferences.edit()
            .putBoolean(key, boolean)
            .apply()
    }

    fun saveData(key: String?, `val`: Float) {
        sharedPreferences
            .edit()
            .putFloat(key, `val`)
            .apply()
    }

    fun saveData(key: String?, `val`: Long) {
        sharedPreferences
            .edit()
            .putLong(key, `val`)
            .apply()
    }
}