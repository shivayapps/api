package com.convoconnect.messenger.sms.text.common.prefixAd;

import static com.convoconnect.messenger.sms.text.common.util.extensions.LogExtensionsKt.LogW;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;

import com.convoconnect.messenger.sms.text.common.MessagesApplication;
import com.convoconnect.messenger.sms.text.common.util.AppUtils;
import com.convoconnect.messenger.sms.text.common.staticData.EventKeys;
import com.convoconnect.messenger.sms.text.common.staticData.UtilsStaticData;
import com.convoconnect.messenger.sms.text.utils.ConstantsKt;

@SuppressLint("All")
public class BannerAds {


    private static String TAG = "ADMOB---BannerAds+++++";
    public static AdView mAdView;
    public static Boolean isRequestSend = false;
    private static String ads_banner = "ads_banner";
    private static String f_request = "f_request";
    private static String f_load = "f_load";
    private static String f_fail_to_load = "f_fail_to_load";

    private static String f_click = "f_click";
    private static String f_impression = "f_impression";


    /**
     * This function is used to display the banner ad into the frame layout this all variables should be passed compulsory,
     * the banner ad type get from firebase remote config or the developer have to pass it as string.
     * <p>
     * AdType Cases are like :
     * 1. adaptive_banner
     * 2. large_banner
     */
    public static void loadAdmobBannerAds(final Activity activity, FrameLayout frameLayout_admob_banner, String adSizeType, String ad_from) {
        isRequestSend = true;
        loadBannerAds(activity, frameLayout_admob_banner, adSizeType, ad_from);
    }


    @SuppressLint("LongLogTag")
    private static void loadBannerAds(Activity activity, FrameLayout frameLayout_admob_banner, String adSizeType, String ad_from) {
        if (ConstantsKt.isOnline(activity)) {
            f_request = "f_request";
            f_load = "f_load";
            f_fail_to_load = "f_fail_to_load";
            f_click = "f_click";
            f_impression = "f_impression";
            String actName = AppUtils.checkActivityName(activity);
            LogW(TAG, "---------loadSimpleAdmobBanner()--calling----");
            mAdView = new AdView(activity);
            mAdView.setAdSize(getBannerAdsType(activity, adSizeType));
            String adId;
            if (ad_from.equals("game")) {
                adId = UtilsStaticData.getGamesBannerAdId(activity);
                ads_banner = UtilsStaticData.ads_banner_gamezone;
            } else if (ad_from.equals("splash")) {
                adId = UtilsStaticData.getSplashBannerAdId(activity);
                ads_banner = UtilsStaticData.ads_banner_splash;
            } else {
                adId = UtilsStaticData.getBannerAdId(activity);
                ads_banner = UtilsStaticData.ads_banner;
            }
            LogW("TAG", "AdId:" + adId);
            mAdView.setAdUnitId(adId);
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);
            AppUtils.logAdapterMessages(ads_banner, f_request, actName);
            mAdView.setAdListener(new AdListener() {

                @Override
                public void onAdImpression() {
                    super.onAdImpression();
                    AppUtils.logAdapterMessages(ads_banner, f_impression, actName);
                }

                @Override
                public void onAdLoaded() {
                    LogW(TAG + "First++++", "SimpleAdmobBanner--onAdLoaded----");
                    AppUtils.logAdapterMessages(ads_banner, f_load, actName);
                    frameLayout_admob_banner.removeAllViews();
                    frameLayout_admob_banner.addView(mAdView);
                    frameLayout_admob_banner.setVisibility(View.VISIBLE);
                    isRequestSend = false;
                    logBannerImpressionData(mAdView);
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError adError) {
                    // Code to be executed when an ad request fails.
                    LogW(TAG + "First++++", "SimpleAdmobBanner--onAdFailedToLoad----" + adError.getMessage());
                    AppUtils.logAdapterMessages(ads_banner, f_fail_to_load, adError.getCode() + "_" + actName);
                    mAdView.setVisibility(View.GONE);
                    if (MessagesApplication.remoteConfig.getString(UtilsStaticData.is_back_id_required).equals("true")) {
                        reloadBannerAds(activity, frameLayout_admob_banner, adSizeType, ad_from);
                    }
                }

                @Override
                public void onAdOpened() {
                    //   AppUtils.logAdapterMessages(ads_banner, f_open, actName);
                    LogW(TAG + "First++++", "SimpleAdmobBanner--onAdOpened----");
                    // Code to be executed when an ad opens an overlay that
                    // covers the screen.
                }

                @Override
                public void onAdClicked() {
                    AppUtils.logAdapterMessages(ads_banner, f_click, actName);
                    LogW(TAG + "First++++", "SimpleAdmobBanner--onAdClicked----");
                    // Code to be executed when the user clicks on an ad.
                }

                @Override
                public void onAdClosed() {
//                AppUtils.logAdapterMessages(ads_banner, f_close, actName);
                    LogW(TAG + "First++++", "---------SimpleAdmobBanner--onAdClosed----");
                    // Code to be executed when the user is about to return
                    // to the app after tapping on an ad.
                }
            });
        }

    }


    private static void reloadBannerAds(Activity activity, FrameLayout frameLayout_admob_banner, String adSizeType, String ad_from) {
        if (ConstantsKt.isOnline(activity)) {
            f_request = "b_request";
            f_load = "b_load";
            f_fail_to_load = "b_fail_to_load";
            //    f_open = "b_open";
            f_click = "b_click";
            f_impression = "b_impression";
            String actName = AppUtils.checkActivityName(activity);

            LogW(TAG + "Reload++++", "Reload_Simple_Admob_BannerAD-------calling--------");
            mAdView = new AdView(activity);
            mAdView.setAdSize(getBannerAdsType(activity, adSizeType));
            mAdView.setAdUnitId(UtilsStaticData.getBannerAdReloadId(activity));
            if (ad_from.equals("game")) {
                ads_banner = UtilsStaticData.ads_banner_gamezone;
            } else if (ad_from.equals("splash")) {
                ads_banner = UtilsStaticData.ads_banner_splash;
            } else {
                ads_banner = UtilsStaticData.ads_banner;
            }
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);
            AppUtils.logAdapterMessages(ads_banner, f_request, actName);
            mAdView.setAdListener(new AdListener() {

                @Override
                public void onAdImpression() {
                    super.onAdImpression();
                    AppUtils.logAdapterMessages(ads_banner, f_impression, actName);
                }

                @Override
                public void onAdLoaded() {
                    AppUtils.logAdapterMessages(ads_banner, f_load, actName);
                    LogW(TAG + "Reload++++", "Simple_Admob_BannerAD--------onAdLoaded-------");
                    frameLayout_admob_banner.removeAllViews();
                    frameLayout_admob_banner.addView(mAdView);
                    frameLayout_admob_banner.setVisibility(View.VISIBLE);
                    isRequestSend = false;
                    logBannerImpressionData(mAdView);
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError adError) {
                    AppUtils.logAdapterMessages(ads_banner, f_fail_to_load, adError.getCode() + "_" + actName);
                    mAdView.setVisibility(View.GONE);
                    frameLayout_admob_banner.setVisibility(View.GONE);
                    isRequestSend = false;
                    LogW(TAG + "Reload++++", "Simple_Admob_BannerAD--------onAdFailedToLoad-------" + adError.getMessage());
                }

                @Override
                public void onAdOpened() {
//                    AppUtils.logAdapterMessages(ads_banner, f_open, actName);
                    LogW(TAG + "Reload++++", "Simple_Admob_BannerAD--------onAdOpened-------");
                }

                @Override
                public void onAdClicked() {
                    AppUtils.logAdapterMessages(ads_banner, f_click, actName);
                    LogW(TAG + "Reload++++", "Simple_Admob_BannerAD--------onAdClicked-------");
                }


                @Override
                public void onAdClosed() {
                    //AppUtils.logAdapterMessages(ads_banner, f_close, actName);
                    LogW(TAG + "Reload++++", "Simple_Admob_BannerAD--------onAdClosed-------");
                }
            });
        }
    }

    private static AdSize getAdSize(Activity activity) {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        Display display = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);


        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return com.google.android.gms.ads.AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth);
    }

    private static AdSize getBannerAdsType(Activity activity, String admobBannerType) {
        AdSize adSize;
        if (ConstantsKt.LARGE_BANNER.equals(admobBannerType)) {
            adSize = AdSize.MEDIUM_RECTANGLE;
        } else {
            adSize = getAdSize(activity);
        }
        return adSize;
    }

    public static void destroyAd() {
        if (mAdView != null) {
            mAdView.destroy();
        }
    }

    public static void resumeAd() {
        if (mAdView != null) {
            mAdView.resume();
        }
    }

    public static void pauseAd() {
        if (mAdView != null) {
            mAdView.pause();
        }
    }

    private static void logBannerImpressionData(AdView bannerAd) {
        bannerAd.setOnPaidEventListener(adValue -> {
            Bundle mBundle = new Bundle();
            mBundle.putString("valueMicros", adValue.getValueMicros() + "");
            mBundle.putString("currencyCode", adValue.getCurrencyCode() + "");
            mBundle.putString("precision", adValue.getPrecisionType() + "");
            mBundle.putString("adUnitId", bannerAd.getAdUnitId());
            AppUtils.logAdapterBundleMessages(EventKeys.paid_ad_impression, mBundle);
        });
    }
}