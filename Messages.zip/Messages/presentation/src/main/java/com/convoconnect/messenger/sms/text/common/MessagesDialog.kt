package com.convoconnect.messenger.sms.text.common

import android.app.Activity
import android.content.Context
import androidx.annotation.StringRes
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.convoconnect.messenger.sms.text.R
import com.convoconnect.messenger.sms.text.common.util.extensions.dpToPx
import com.convoconnect.messenger.sms.text.common.util.extensions.setPadding
import com.convoconnect.messenger.sms.text.util.Preferences
import javax.inject.Inject

/**
 * Wrapper around AlertDialog which makes it easier to display lists that use our UI
 */
class MessagesDialog @Inject constructor(
    private val context: Context,
    val adapter: MenuItemAdapter
) {

    var title: String? = null
    var old = 0

    @Inject
    lateinit var prefs: Preferences

    var fromDelaySending: Boolean = false

    fun show(activity: Activity, title: String, index: Int = 0,fromNotificationsAction:Boolean = false) {
        val recyclerView = RecyclerView(activity)
        recyclerView.layoutManager = LinearLayoutManager(context)
        adapter.selectedItem = index
        adapter.fromDelaySending = fromDelaySending
        adapter.fromActions = fromNotificationsAction
        recyclerView.adapter = adapter
        recyclerView.setPadding(top = 8.dpToPx(context), bottom = 2.dpToPx(context))

        val dialog =
            AlertDialog.Builder(activity, R.style.FontMyOptionDialogTheme)
                .setView(recyclerView)
                .setPositiveButton(context.resources.getString(R.string.ok)) { _, _ ->
                    adapter.menuItemClicks.onNext(adapter.actionId1)
                }
                .setNegativeButton(context.resources.getString(R.string.button_cancel)) { dialog, id ->
                    dialog.cancel()
                }
                .create()
        if (title.isNotEmpty()) {
            dialog.setTitle(title)
        }
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.color_app_theme
                )
            )
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.color_app_theme
                )
            )
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.color_app_theme
                )
            )
        }
        dialog.show()

    }

    fun setTitle(@StringRes title: Int) {
        this.title = context.resources.getString(title)
    }

}