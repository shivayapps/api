package com.convoconnect.messenger.sms.text.common

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Service
import android.content.BroadcastReceiver
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.util.Log
import androidx.core.provider.FontRequest
import androidx.emoji.text.EmojiCompat
import androidx.emoji.text.FontRequestEmojiCompatConfig
import com.google.android.gms.tasks.Task
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.grow.subscriptionmodule.activity.SubscriptionPurchaseActivity
import dagger.android.*

import io.realm.Realm
import io.realm.RealmConfiguration
import com.convoconnect.messenger.sms.text.R
import com.convoconnect.messenger.sms.text.common.util.AppUtils
import com.convoconnect.messenger.sms.text.common.util.FileLoggingTree
import com.convoconnect.messenger.sms.text.injection.AppComponentManager
import com.convoconnect.messenger.sms.text.injection.appComponent
import com.convoconnect.messenger.sms.text.migration.MessagesRealmMigration
import com.convoconnect.messenger.sms.text.util.NightModeManager
import com.convoconnect.messenger.sms.text.common.PreferanceData.PreferenceKeys
import com.convoconnect.messenger.sms.text.common.prefixAd.OpenAdApplication
import com.convoconnect.messenger.sms.text.common.staticData.EventKeys
import com.convoconnect.messenger.sms.text.common.staticData.UtilsStaticData.isEnableAppResumeOpenAd
import com.convoconnect.messenger.sms.text.common.util.extensions.LogE
import com.convoconnect.messenger.sms.text.common.util.extensions.LogW
import com.convoconnect.messenger.sms.text.feature.main.SplashActivity
import com.convoconnect.messenger.sms.text.utils.*
import timber.log.Timber
import java.util.*
import javax.inject.Inject


@SuppressLint("All")
class MessagesApplication : OpenAdApplication(), HasActivityInjector, HasBroadcastReceiverInjector,
    HasServiceInjector, OpenAdApplication.AppLifecycleListener {

    @Inject
    lateinit var dispatchingActivityInjector: DispatchingAndroidInjector<Activity>

    @Inject
    lateinit var dispatchingBroadcastReceiverInjector: DispatchingAndroidInjector<BroadcastReceiver>

    @Inject
    lateinit var dispatchingServiceInjector: DispatchingAndroidInjector<Service>

    @Inject
    lateinit var fileLoggingTree: FileLoggingTree

    @Inject
    lateinit var realmMigration: MessagesRealmMigration

    @Inject
    lateinit var nightModeManager: NightModeManager


    override fun onCreate() {
        super.onCreate()
        try {
            openAdApplication = OpenAdApplication()
            setAppLifeCycleListener(this) //For Open Ad
            remoteConfig = firebaseRemoteConfig
            AppComponentManager.init(this@MessagesApplication)
            appComponent.inject(this@MessagesApplication)
            Realm.init(this@MessagesApplication)

            if (mFirebaseAnalytics.equals(null)) {
                mFirebaseAnalytics = FirebaseAnalytics.getInstance(this@MessagesApplication)
            }
            nightModeManager.updateCurrentTheme()
            fireBaseConfigGet()
            setRealmConfiguration()
            Timber.plant(Timber.DebugTree(), fileLoggingTree)
            val fontRequest = FontRequest(
                "com.google.android.gms.fonts",
                "com.google.android.gms",
                "Noto Color Emoji Compat",
                R.array.com_google_android_gms_fonts_certs
            )
            EmojiCompat.init(
                FontRequestEmojiCompatConfig(
                    this@MessagesApplication,
                    fontRequest
                )
            )
        } catch (e: Exception) {
            AppUtils.logAdapterMessages(
                EventKeys.crash,
                EventKeys.main_application,
                e.message.orEmpty()
            )
            LogE(
                "MessagesApplication++++++",
                "Exceptions----- ${e.message}"
            )
        }
    }

    private fun setRealmConfiguration() {
        try {
            Realm.removeDefaultConfiguration()
            Realm.setDefaultConfiguration(
                RealmConfiguration.Builder()
                    .compactOnLaunch()
                    .schemaVersion(MessagesRealmMigration.SchemaVersion)
                    .deleteRealmIfMigrationNeeded()
                    .migration(realmMigration)
                    .build()

            )
        } catch (e: Exception) {
            LogE("Jayesh --setReal", e.message.toString())
            Realm.getDefaultConfiguration()
        }
    }

    private fun fireBaseConfigGet() {
        try {
            remoteConfig.setConfigSettingsAsync(
                FirebaseRemoteConfigSettings.Builder()
                    .setMinimumFetchIntervalInSeconds(0)
                    .setFetchTimeoutInSeconds(3)
                    .build()
            )
            LogE("TAG" + "fireBaseConfigGet: ", "send req")
            remoteConfig.setDefaultsAsync(R.xml.firebase_rc_defaults)
            remoteConfig.fetch(0)
                .addOnCompleteListener { task: Task<Void?> ->
                    var errorString = ""
                    if (task.isSuccessful) {
                        remoteConfig.fetchAndActivate()
                        AppUtils.e("TAGmFirebaseRemoteConfigis_ +-$errorString")
                        LogE("TAG" + "fireBaseConfigGet: ", "data fetch")
                        errorString = " task is successful  "
                        AppUtils.e(
                            "---" + "Reload OpenAd Id isEnableAppResumeOpenAd " + remoteConfig.getBoolean(
                                isEnableAppResumeOpenAd
                            )
                        )

                        for (key in remoteConfig.getKeysByPrefix("")) {
                            val value = remoteConfig.getValue(key)
                            if (value.asString() != null) {
                                Log.i("RemoteConfigList: ", "Key::>>" + key + "<<::Value-String::>>" + remoteConfig.getString(key) + "<<::")
                            } else if (value.asBoolean()) {
                                Log.i("RemoteConfigList: ", "Key::>>" + key + "<<::Value-Boolean::>>" + remoteConfig.getBoolean(key) + "<<::")
                            } else if (value.asDouble() != null) {
                                Log.i("RemoteConfigList: ", "Key::>>" + key + "<<::Value-Double::>>" + remoteConfig.getDouble(key) + "<<::")
                            } else if (value.asLong() != null) {
                                Log.i("RemoteConfigList: ", "Key::>>" + key + "<<::Value-Long::>>" + remoteConfig.getLong(key) + "<<::")
                            } else {
                                Log.i("RemoteConfigList: ", "Key::>>" + key + "<<::Value-ELSE::>>" + remoteConfig.getValue(key) + "<<::")
                            }
                        }
                    } else {
                        errorString = "task is canceled"
                    }
                    AppUtils.e(" mFirebaseRemoteConfigis_ errorString ---------$errorString")
                }
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val nightModeFlags = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK

        if (nightModeFlags == Configuration.UI_MODE_NIGHT_NO) {
            LogW(
                "MessagesApplication++++++",
                "MODE CHANGE-- WHTIE"
            )
            isOrientationChanged = true
            PreferenceManager.saveData(this, PreferenceKeys.IS_MODE_CHANGE, true)
        } else {
            LogW(
                "MessagesApplication++++++",
                "MODE CHANGE-- BLACK"
            )
            isOrientationChanged = true
            PreferenceManager.saveData(this, PreferenceKeys.IS_MODE_CHANGE, true)

        }
    }

    override fun activityInjector(): AndroidInjector<Activity> {
        return dispatchingActivityInjector
    }

    override fun broadcastReceiverInjector(): AndroidInjector<BroadcastReceiver> {
        return dispatchingBroadcastReceiverInjector
    }

    override fun serviceInjector(): AndroidInjector<Service> {
        return dispatchingServiceInjector
    }

    companion object {
        var isOrientationChanged: Boolean = false
        lateinit var remoteConfig: FirebaseRemoteConfig
        lateinit var mFirebaseAnalytics: FirebaseAnalytics
        lateinit var openAdApplication: OpenAdApplication
        fun isFirebaseAnalyticsInit() = ::mFirebaseAnalytics.isInitialized
        fun isRemoteConfigInit() = ::remoteConfig.isInitialized
    }

    override fun onResumeApp(currentActivity: Activity?): Boolean {
        LogE(
            "===",
            "onResumeApp: ------------------- AdmobModuleApplication" + firebaseRemoteConfig.getBoolean(
                isEnableAppResumeOpenAd
            )
        )
        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {
            currentActivity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            currentActivity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        if (currentActivity is SplashActivity) {
            return false
        } else if (currentActivity is SubscriptionPurchaseActivity) {
            return false
        } else if (prefsData.getBooleanData(PreferenceKeys.SystemDialogOpened)) {
            prefsData.saveData(PreferenceKeys.SystemDialogOpened, false)
            return false
        } else if (!firebaseRemoteConfig.getBoolean(isEnableAppResumeOpenAd)) {
            return false
        }
        return true
    }

}