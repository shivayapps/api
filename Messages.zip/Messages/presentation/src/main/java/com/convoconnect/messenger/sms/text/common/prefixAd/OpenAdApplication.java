package com.convoconnect.messenger.sms.text.common.prefixAd;


import static com.convoconnect.messenger.sms.text.common.util.extensions.LogExtensionsKt.LogE;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleOwner;
import androidx.multidex.MultiDexApplication;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.admanager.AdManagerAdRequest;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

import java.util.Date;

import com.convoconnect.messenger.sms.text.common.MessagesApplication;
import com.convoconnect.messenger.sms.text.common.util.AppUtils;
import com.convoconnect.messenger.sms.text.common.PreferanceData.AppPreference;
import com.convoconnect.messenger.sms.text.common.PreferanceData.PreferenceKeys;
import com.convoconnect.messenger.sms.text.common.staticData.EventKeys;
import com.convoconnect.messenger.sms.text.common.staticData.UtilsStaticData;
import com.convoconnect.messenger.sms.text.common.util.BaseConfig;
import com.convoconnect.messenger.sms.text.utils.ConstantsKt;

public class OpenAdApplication extends MultiDexApplication implements Application.ActivityLifecycleCallbacks, DefaultLifecycleObserver {

    private String TAG = "ADMOB---" + OpenAdApplication.class.getSimpleName();
    public AppOpenAdManager appOpenAdManager;
    private Activity currentActivity;
    private AppLifecycleListener appLifecycleListener;
    public FirebaseRemoteConfig firebaseRemoteConfig;


    public static String ads_appopen = "ads_appopen";
    public static String f_request = "f_request";
    public static String f_load = "f_load";
    public static String f_fail_to_load = "f_fail_to_load";
    public static String f_fail_to_show = "f_fail_to_show";
    public static String f_show = "f_show";

    public static String f_click = "f_click";
    public static String f_impression = "f_impression";
    public static String f_dismiss = "f_dismiss";

    public AppPreference prefsData;

    @Override
    public void onCreate() {
        super.onCreate();
        AppUtils.INSTANCE.e("onCreate: ");
        prefsData = new AppPreference(this);
        prefsData.initPrefs();
        prefsData.saveData(PreferenceKeys.isOpenAdsLodead, false);


        if (MessagesApplication.mFirebaseAnalytics == null) {
            MessagesApplication.mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        }




        try {
            MobileAds.initialize(this, initializationStatus -> LogE(TAG, "onInitializationComplete: Done "));
        } catch (Exception ignored) {

        }

        LogE(TAG, "onInitializationComplete: Req ");
        appOpenAdManager = new AppOpenAdManager();


        firebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
//        fireBaseConfigGet();
    }


    @Override
    public void onStart(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onStart(owner);
        if (appOpenAdManager != null)
            appOpenAdManager.loadAd(OpenAdApplication.this);

        AppUtils.INSTANCE.e(TAG + "onStart: ---------------------- OpenAdApplication");
    }

    @Override
    public void onStop(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onStop(owner);
        AppUtils.INSTANCE.e(TAG + " onStop: ---------------------- OpenAdApplication");
    }

    @Override
    public void onDestroy(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onDestroy(owner);
        AppUtils.INSTANCE.e(TAG + " onDestroy: ---------------------- OpenAdApplication");
    }


    @Override
    public void onResume(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onResume(owner);
        AppUtils.INSTANCE.e(TAG + "onResume: ---------------------- OpenAdApplication1" + " " + currentActivity.getClass().getSimpleName());
        try {
            if (!new BaseConfig(OpenAdApplication.this).getAds_free()) {
                if (prefsData.getBooleanData(PreferenceKeys.IS_OPEN_AD, true)/* && UtilsStaticData.remoteConfig.getBoolean(UtilsStaticData.isEnableAppResumeOpenAd)*/) {
                    if (appLifecycleListener.onResumeApp(currentActivity)) {
                        appOpenAdManager.showAdIfAvailable(currentActivity);
                    }
                }
            }
        } catch (Exception e) {
            LogE(TAG, "onResume: " + "config issue");
        }
    }

    public void setAppLifeCycleListener(AppLifecycleListener appLifeCycleListener) {
        this.appLifecycleListener = appLifeCycleListener;
    }


    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        if (!appOpenAdManager.isShowingAd) {
            currentActivity = activity;
        }
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {
    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        currentActivity = null;
    }

    public interface AppLifecycleListener {
        Boolean onResumeApp(Activity currentActivity);
    }

    public interface OnShowAdCompleteListener {
        void onShowAdComplete();

        void onAdsDismiss();
    }
/*

    private boolean isOpenAdsLodead = false;
*/

    public boolean isLoadingAd() {
        if (prefsData == null) {
            LogE("isLoadingAd: ", "-----------------if---------------");
            prefsData = new AppPreference(this);
        }
        return prefsData.getBooleanData(PreferenceKeys.isOpenAdsLodead, false);

    }

    /**
     * Inner class that loads and shows app open ads.
     */
    public class AppOpenAdManager {


        private AppOpenAd appOpenAd = null;
        private boolean isLoadingAd = false;
        private boolean isShowingAd = false;

        /**
         * Keep track of the time an app open ad is loaded to ensure you don't show an expired ad.
         */
        private long loadTime = 0;

        /**
         * Constructor.
         */
        public AppOpenAdManager() {
        }

        /**
         * Load an ad.
         *
         * @param context the context of the activity that loads the ad
         */
        public void loadAd(Context context) {

            String actName = AppUtils.checkActivityName(context);
            // Do not load ad if there is an unused ad or one is already loading.
            if (!MessagesApplication.Companion.isFirebaseAnalyticsInit()) {
                MessagesApplication.mFirebaseAnalytics = FirebaseAnalytics.getInstance(context);
            }
            if (!MessagesApplication.Companion.isRemoteConfigInit()) {
                MessagesApplication.remoteConfig = FirebaseRemoteConfig.getInstance();
            }

            if (ConstantsKt.isOnline(context) && !prefsData.getBooleanData(PreferenceKeys.is_ads_remove)) {
                if (isLoadingAd || isAdAvailable()) {
                    return;
                }

                isLoadingAd = true;

                f_request = "f_request";
                f_load = "f_load";
                f_fail_to_load = "f_fail_to_load";
                f_show = "f_show";
                f_fail_to_show = "f_fail_to_show";
                f_dismiss = "f_dismiss";
                f_click = "f_click";
                f_impression = "f_impression";
//                AppUtils.INSTANCE.e(TAG + " load req=== " + UtilsStaticData.getOpenAdId(context));
                AppUtils.logAdapterMessages(ads_appopen, f_request, actName);

                AdManagerAdRequest request = new AdManagerAdRequest.Builder().build();
                AppOpenAd.load(
                        context,
                        UtilsStaticData.getOpenAdId(context),
                        request,
                        AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
                        new AppOpenAd.AppOpenAdLoadCallback() {
                            /**
                             * Called when an app open ad has loaded.
                             *
                             * @param ad the loaded app open ad.
                             */
                            @Override
                            public void onAdLoaded(AppOpenAd ad) {
                                appOpenAd = ad;
                                prefsData.saveData(PreferenceKeys.isOpenAdsLodead, true);
                                isLoadingAd = false;
                                loadTime = (new Date()).getTime();
                                AppUtils.logAdapterMessages(ads_appopen, f_load, actName);
                                logOpenAdImpressionData(ad);
                            }

                            /**
                             * Called when an app open ad has failed to load.
                             *
                             * @param loadAdError the error.
                             */
                            @Override
                            public void onAdFailedToLoad(LoadAdError loadAdError) {
                                isLoadingAd = false;
                                prefsData.saveData(PreferenceKeys.isOpenAdsLodead, false);

                                AppUtils.logAdapterMessages(ads_appopen, f_fail_to_load, loadAdError.getCode() + "_" + actName);
                                AppUtils.INSTANCE.e("onAdFailedToLoad: " + loadAdError.getMessage());
                                if (MessagesApplication.remoteConfig.getString(UtilsStaticData.is_back_id_required).equals("true")) {
                                    reloadOpenAd(context);
                                }
                            }
                        });
            }

        }


        private void reloadOpenAd(Context context) {


            String actName = AppUtils.checkActivityName(context);
            // Do not load ad if there is an unused ad or one is already loading.
            if (isLoadingAd || isAdAvailable()) {
                return;
            }

            isLoadingAd = true;
            f_request = "b_request";
            f_load = "b_load";
            f_fail_to_load = "b_fail_to_load";
            f_show = "b_show";
            f_fail_to_show = "b_fail_to_show";
            f_dismiss = "b_dismiss";
            f_click = "b_click";
            f_impression = "b_impression";

            AppUtils.INSTANCE.e(TAG + " load Back req=== " + UtilsStaticData.getBackOpenAdId(context));
            AppUtils.logAdapterMessages(ads_appopen, f_request, actName);
            AdManagerAdRequest request = new AdManagerAdRequest.Builder().build();
            AppOpenAd.load(
                    context,
                    UtilsStaticData.getBackOpenAdId(context),
                    request,
                    AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
                    new AppOpenAd.AppOpenAdLoadCallback() {
                        /**
                         * Called when an app open ad has loaded.
                         *
                         * @param ad the loaded app open ad.
                         */
                        @Override
                        public void onAdLoaded(AppOpenAd ad) {
                            appOpenAd = ad;
                            isLoadingAd = false;
                            prefsData.saveData(PreferenceKeys.isOpenAdsLodead, true);
                            loadTime = (new Date()).getTime();

                            AppUtils.INSTANCE.e(TAG + " reloadOpenAd onAdLoaded.");
                            AppUtils.logAdapterMessages(ads_appopen, f_load, actName);
                            logOpenAdImpressionData(ad);
                        }

                        /**
                         * Called when an app open ad has failed to load.
                         *
                         * @param loadAdError the error.
                         */
                        @Override
                        public void onAdFailedToLoad(LoadAdError loadAdError) {
                            isLoadingAd = false;
                            prefsData.saveData(PreferenceKeys.isOpenAdsLodead, false);
                            AppUtils.INSTANCE.e(TAG + " reloadOpenAd onAdFailedToLoad: " + loadAdError.getMessage());
                            AppUtils.logAdapterMessages(ads_appopen, f_fail_to_load, loadAdError.getCode() + "_" + actName);
                        }
                    });
        }

        /**
         * Check if ad was loaded more than n hours ago.
         */
        private boolean wasLoadTimeLessThanNHoursAgo(long numHours) {
            long dateDifference = (new Date()).getTime() - loadTime;
            long numMilliSecondsPerHour = 3600000;
            return (dateDifference < (numMilliSecondsPerHour * numHours));
        }

        /**
         * Check if ad exists and can be shown.
         */
        private boolean isAdAvailable() {
            // Ad references in the app open beta will time out after four hours, but this time limit
            // may change in future beta versions. For details, see:
            // https://support.google.com/admob/answer/9341964?hl=en
            return appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4);
        }

        /**
         * Show the ad if one isn't already showing.
         *
         * @param activity the activity that shows the app open ad
         */
        private void showAdIfAvailable(@NonNull final Activity activity) {
            showAdIfAvailable(activity, new OnShowAdCompleteListener() {
                @Override
                public void onShowAdComplete() {
                    AppUtils.INSTANCE.e(TAG + " ONADSHOWCOMPLETE --");
                }

                @Override
                public void onAdsDismiss() {
                    AppUtils.INSTANCE.e(TAG + " Dismiss--");

                }
            });
        }

        /**
         * Show the ad if one isn't already showing.
         *
         * @param activity                 the activity that shows the app open ad
         * @param onShowAdCompleteListener the listener to be notified when an app open ad is complete
         */
        private void showAdIfAvailable(
                @NonNull final Activity activity,
                @NonNull OnShowAdCompleteListener onShowAdCompleteListener) {
            // If the app open ad is already showing, do not show the ad again.


            String actName = AppUtils.checkActivityName(activity);

            if (isShowingAd) {
                AppUtils.INSTANCE.e(TAG + "The app open ad is already showing.");
                onShowAdCompleteListener.onShowAdComplete();
                return;
            }

            // If the app open ad is not available yet, invoke the callback then load the ad.
            if (ConstantsKt.isOnline(activity) && !isAdAvailable()) {
                AppUtils.INSTANCE.e(TAG + " The app open ad is not ready yet.");
                onShowAdCompleteListener.onShowAdComplete();
                loadAd(activity);
                return;
            }

            AppUtils.INSTANCE.e(TAG + " Will show ad.");
            if (appOpenAd != null) {
                appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdClicked() {
                        AppUtils.logAdapterMessages(ads_appopen, f_click, actName);
                        super.onAdClicked();
                    }

                    @Override
                    public void onAdImpression() {
                        AppUtils.logAdapterMessages(ads_appopen, f_impression, actName);
                        super.onAdImpression();
                    }

                    /** Called when full screen content is dismissed. */

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        AppUtils.logAdapterMessages(ads_appopen, f_dismiss, actName);
                        // Set the reference to null so isAdAvailable() returns false.
                        appOpenAd = null;
                        isShowingAd = false;


                        AppUtils.INSTANCE.e(TAG + " onAdDismissedFullScreenContent.");
                        //Toast.makeText(activity, "onAdDismissedFullScreenContent", Toast.LENGTH_SHORT).show();

                        prefsData.saveData(PreferenceKeys.Admob_IntAd, false);
                        onShowAdCompleteListener.onAdsDismiss();
                        loadAd(activity);
                    }

                    /** Called when fullscreen content failed to show. */
                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        appOpenAd = null;
                        isShowingAd = false;
                        AppUtils.INSTANCE.e(TAG + " onAdFailedToShowFullScreenContent: " + adError.getMessage());
                        AppUtils.logAdapterMessages(ads_appopen, f_fail_to_show, adError.getCode() + "_" + actName);
                        prefsData.saveData(PreferenceKeys.Admob_IntAd, false);
                        onShowAdCompleteListener.onShowAdComplete();
                        loadAd(activity);
                    }

                    /** Called when fullscreen content is shown. */
                    @Override
                    public void onAdShowedFullScreenContent() {
                        AppUtils.INSTANCE.e(TAG + " onAdShowedFullScreenContent.");
                        AppUtils.logAdapterMessages(ads_appopen, f_show, actName);
                        prefsData.saveData(PreferenceKeys.Admob_IntAd, true);
                    }
                });

                isShowingAd = true;
                appOpenAd.show(activity);
            }
        }
    }

    private static void logOpenAdImpressionData(AppOpenAd openAd) {
        openAd.setOnPaidEventListener(adValue -> {
            Bundle mBundle = new Bundle();
            mBundle.putString("valueMicros", adValue.getValueMicros() + "");
            mBundle.putString("currencyCode", adValue.getCurrencyCode() + "");
            mBundle.putString("precision", adValue.getPrecisionType() + "");
            mBundle.putString("adUnitId", openAd.getAdUnitId());
            AppUtils.logAdapterBundleMessages(EventKeys.paid_ad_impression, mBundle);
        });
    }
}
