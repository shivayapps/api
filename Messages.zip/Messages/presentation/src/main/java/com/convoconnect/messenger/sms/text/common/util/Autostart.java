package com.convoconnect.messenger.sms.text.common.util;

import static com.convoconnect.messenger.sms.text.common.util.extensions.LogExtensionsKt.LogE;
import static com.convoconnect.messenger.sms.text.common.util.extensions.LogExtensionsKt.LogI;

import android.content.Context;
import android.os.Build;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

import javax.annotation.Nullable;

public class Autostart {
    private static final String TAG = "Autostart";

    private static final String XIAOMI_NAME = "xiaomi";

    private static final String MIUI_CLAZZ = "android.miui.AppOpsUtils";
    private static final String POLICY_CLAZZ = "miui.content.pm.PreloadedAppPolicy";

    private static boolean isReflectionEnabled = false;

    private static final int STATE_ENABLED = 0;
    private static final int STATE_DISABLED = 1;

    private final Context context;

    /**
     * State for the autostart
     * ENABLED and DISABLED are the expected results for a MIUI device
     */

    public enum State {
        ENABLED, DISABLED, NO_INFO, UNEXPECTED_RESULT
    }

    public static boolean isXiaomi() {
        return Build.MANUFACTURER.equalsIgnoreCase(XIAOMI_NAME);
    }

    /**
     * Create an instance of Autostart, the phone must be Xiaomi device
     *
     * @param context Application context
     */

    public Autostart(Context context) {
        this.context = context;
        if (!isXiaomi()) {
            LogE(TAG, "Autostart: Not Xiaomi");

        }

        if (!isReflectionEnabled) {
            try {
                Reflection.unseal(context);
                isReflectionEnabled = true;

            } catch (Exception e) {
                LogE("Autostart: ", e.getLocalizedMessage());
            }
        }
    }

    /**
     * Checks if autostart is enabled.
     * May also return false (even if its enabled)
     */

    public boolean isAutoStartEnabled() throws Exception {
        return getAutoStartState() == State.ENABLED;
    }

    /**
     * Returns the state of the autostart
     *
     * <p>
     * ENABLED / DISABLED = autostart state
     * NOINFO = something went wrong when attempting to get the state
     * UNEXPECTED_RESULT = we got the state, but it is not right
     * </p>
     */

    public State getAutoStartState()   {
        final Class<?> clazz = getClazz(MIUI_CLAZZ);

        if (clazz == null) {
            return State.NO_INFO;
        }

        final Method method = findMethod(clazz);

        if (method == null) {
            // the method does not exist!
            return State.NO_INFO;
        }

        Object result = null;
        try {
            result = method.invoke(null,
                    context, context.getPackageName());
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        // it must be an integer, else things are changed

        if (!(result instanceof Integer)) {
            return State.UNEXPECTED_RESULT;
        }
        final int _int = (int) result;
        if (_int == STATE_ENABLED) {
            return State.ENABLED;
        } else if (_int == STATE_DISABLED) {
            return State.DISABLED;
        }
        return State.UNEXPECTED_RESULT;
    }

    @SuppressWarnings("SuspiciousToArrayCall")
    public String[] defaultWhiteListedPackages() throws NoSuchFieldException, IllegalAccessException {
        final Class<?> clazz = getClazz(POLICY_CLAZZ);
        if (clazz == null) {
            // just return an empty array
            return new String[0];
        }
        final Field field = clazz.getDeclaredField("sProtectedDataApps");
        field.setAccessible(true);

        // we pass null to `Field.get()` because the field
        // is statically defined
        final Object result = field.get(null);
        if (result instanceof ArrayList<?>) {
            return ((ArrayList<?>) result).toArray(new String[0]);
        }
        final String message = "defaultWhiteListedPackages() unexpected result type";
        if (result == null) {
            return new String[0];
        }
        LogE(TAG, message + " " + result.getClass());
        return new String[0];
    }

    private Class<?> getClazz(String name) {
        try {
            return Class.forName(name);
        } catch (ClassNotFoundException ignored) {
            // we couldn't find the class name
            // we are out of luck
            return null;
        }
    }

    /**
     * Finds the method of the MIUI clazz
     *
     * @return returns the method, is null
     * if method is not found
     */


    private @Nullable
    Method findMethod(final Class<?> clazz) {
        final String methodName = "getApplicationAutoStart";

        try {
            final Method method = clazz.getDeclaredMethod("getApplicationAutoStart",
                    Context.class, String.class);

            method.setAccessible(true);
            return method;
        } catch (NoSuchMethodException e) {
            for (Method method : clazz.getDeclaredMethods()) {
                if (method.getName().equals(methodName)) {
                    LogI(TAG, "Found a new method matching method name");
                }
            }
            // we could not find the method name
            // we were near to get the autostart
            return null;
        }
    }
}