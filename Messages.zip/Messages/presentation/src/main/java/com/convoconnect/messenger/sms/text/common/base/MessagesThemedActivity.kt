package com.convoconnect.messenger.sms.text.common.base

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import com.rateus.rateusexitdialog.utils.toastMsg
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import com.convoconnect.messenger.sms.text.R
import com.convoconnect.messenger.sms.text.common.util.AppUtils
import com.convoconnect.messenger.sms.text.repository.ConversationRepository
import com.convoconnect.messenger.sms.text.repository.MessageRepository
import com.convoconnect.messenger.sms.text.util.PhoneNumberUtils
import com.convoconnect.messenger.sms.text.util.Preferences
import com.convoconnect.messenger.sms.text.common.PreferanceData.AppPreference
import com.convoconnect.messenger.sms.text.common.PreferanceData.PreferenceKeys
import com.convoconnect.messenger.sms.text.common.base.MessagesActivity
import com.convoconnect.messenger.sms.text.common.util.extensions.LogD
import com.convoconnect.messenger.sms.text.common.util.extensions.LogE
import com.convoconnect.messenger.sms.text.common.util.extensions.LogV
import java.io.File
import java.util.*
import java.util.concurrent.TimeUnit
import javax.inject.Inject

abstract class MessagesThemedActivity : MessagesActivity() {


    @Inject
    lateinit var conversationRepo: ConversationRepository

    @Inject
    lateinit var messageRepo: MessageRepository

    @Inject
    lateinit var phoneNumberUtils: PhoneNumberUtils

    @Inject
    lateinit var prefs: Preferences

    @Inject
    lateinit var appPrefs: AppPreference

    /**
     * In case the activity should be themed for a specific conversation, the selected conversation
     * can be changed by pushing the threadId to this subject
     */
    val threadId: Subject<Long> = BehaviorSubject.createDefault(0)

    /**
     * Switch the theme if the threadId changes
     * Set it based on the latest message in the conversation
     *//*
    val theme: Observable<Colors.Theme> = threadId
        .distinctUntilChanged()
        .switchMap { threadId ->
            val conversation = conversationRepo.getConversation(threadId)
            when {
                conversation == null -> Observable.just(Optional(null))
                conversation.recipients.size == 1 -> Observable.just(Optional(conversation.recipients.first()))

                else -> messageRepo.getLastIncomingMessage(conversation.id)
                    .asObservable()
                    .mapNotNull { messages -> messages.firstOrNull() }
                    .distinctUntilChanged { message -> message.address }
                    .mapNotNull { message ->
                        conversation.recipients.find { recipient ->
                            phoneNumberUtils.compare(recipient.address, message.address)
                        }
                    }
                    .map { recipient -> Optional(recipient) }
                    .startWith(Optional(conversation.recipients.firstOrNull()))
                    .distinctUntilChanged()
            }
        }
        .switchMap { colors.themeObservable(it.value) }*/

    @SuppressLint("InlinedApi", "SourceLockedOrientationActivity")
    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(getActivityThemeRes(prefs.night.get()))
        requestedOrientation = if (Build.VERSION.SDK_INT == Build.VERSION_CODES.O)
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        else
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        val isNightMode =
            this@MessagesThemedActivity.resources.configuration.uiMode.and(Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

        if (isNightMode) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        } else {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        window.navigationBarColor = ContextCompat.getColor(this, R.color.app_background)
        window.statusBarColor = ContextCompat.getColor(this, R.color.app_background)
        super.onCreate(savedInstanceState)

        // When certain preferences change, we need to recreate the activity
        val triggers =
            listOf(prefs.nightMode, prefs.night, prefs.textSize, prefs.systemFont)
        Observable.merge(triggers.map { it.asObservable().skip(1) })
            .debounce(400, TimeUnit.MILLISECONDS)
            .observeOn(AndroidSchedulers.mainThread())
            .autoDisposable(scope())
            .subscribe({ recreate() }
            ) { t -> LogE("accept: ", t?.message.toString()) }

        requestedOrientation = if (Build.VERSION.SDK_INT == Build.VERSION_CODES.O)
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        else
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        // We can only set light nav bar on API 27 in attrs, but we can do it in API 26 here
        /*if (Build.VERSION.SDK_INT == Build.VERSION_CODES.O) {
            val night = !resolveThemeBoolean(R.attr.isLightTheme)
            window.decorView.systemUiVisibility = if (night) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }*/


        // Some devices don't let you modify android.R.attr.navigationBarColor
        /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.navigationBarColor = resolveThemeColor(android.R.attr.windowBackground)
        }*/

        // Set the color for the recent apps title
//        val toolbarColor = resolveThemeColor(R.attr.colorPrimary)
//        val icon = BitmapFactory.decodeResource(resources, R.drawable.appicon)
//        val taskDesc =
//            ActivityManager.TaskDescription(getString(R.string.app_name), icon, toolbarColor)
//        setTaskDescription(taskDesc)

        try {
            val strCountryCode = appPrefs.getStringData(PreferenceKeys.localization_country_code)
            if (!strCountryCode.isNullOrBlank())
                AppUtils.setLocale(strCountryCode, this)//app selected country
            else {
                val cCodeDefault = Locale.getDefault().language
                AppUtils.setLocale(cCodeDefault, this)//system default country
                LogV("MessageApp", "CC$cCodeDefault")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onResume() {
        super.onResume()
        val freeBytesInternal: Long =
            File(filesDir.absoluteFile.toString()).freeSpace
        if (freeBytesInternal < 200000000)
            toastMsg(getString(R.string.low_memory))
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        try {
            LogD("MTA:", "onpostcreate")
            /*Observables.combineLatest(menu, theme) { menu, _ ->
                menu.iterator().forEach { _ ->
                }
            }.autoDisposable(scope(*//*Lifecycle.Event.ON_DESTROY*//*)).subscribe({ }) {
                LogE("TAG", "onPostCreate: ")
            }*/

        } catch (e: Exception) {
            LogD("MTA:error", "$e")
        }
    }

    open fun getColoredMenuItems(): List<Int> {
        return listOf()
    }

    /* override fun onResume() {
         try {
             val strCountryCode = appPrefs.getStringData(PreferenceKeys.localization_country_code)
             if (!strCountryCode.isNullOrBlank())
                 AppUtils.setLocale(strCountryCode,this)
             else {
                 val cCodeDefault = Locale.getDefault().language
                 AppUtils.setLocale(cCodeDefault,this)
                 LogV("MessageApp", "CC$cCodeDefault")
             }
         } catch (e: Exception) {
             e.printStackTrace()
         }
         super.onResume()
     }*/

    /**
     * This can be overridden in case an activity does not want to use the default themes
     */
    open fun getActivityThemeRes(black: Boolean) = when {
        black -> R.style.AppTheme
        else -> R.style.AppTheme
    }

}