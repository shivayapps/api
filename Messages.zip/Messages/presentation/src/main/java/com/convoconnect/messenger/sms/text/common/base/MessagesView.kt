package com.convoconnect.messenger.sms.text.common.base

import androidx.lifecycle.LifecycleOwner

interface MessagesView<in State> : LifecycleOwner {

    fun render(state: State)

}