package com.convoconnect.messenger.sms.text.common.prefixAd;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;

import com.convoconnect.messenger.sms.text.R;
import com.convoconnect.messenger.sms.text.common.util.AppUtils;
import com.convoconnect.messenger.sms.text.common.staticData.EventKeys;
import com.convoconnect.messenger.sms.text.common.staticData.UtilsStaticData;
import com.convoconnect.messenger.sms.text.utils.ConstantsKt;

public class NativeGameZoneAds {


    public static NativeAd mNativeGameZoneAd = null;
    private static Boolean mNativeAdGameZoneProcess = false;
    private static String F_Request = "f_request";
    private static String F_Load = "f_load";
    private static String F_Fail_Load = "f_fail_load";
    private static String ads_native = "ads_native";

    private static String F_Open = "f_open";
    private static String F_Close = "f_close";
    private static String F_Click = "f_click";
    private static String F_Impression = "f_impression";



    /**
     * This class is used to load & show the game zone native ads
     **/
    public static void loadNativeAds(Activity activity, final FrameLayout fLayout, final NativeAdSize adSize) {
        if (mNativeAdGameZoneProcess) return;
        mNativeAdGameZoneProcess = true;
        if (ConstantsKt.isOnline(activity)) {
            String activityName = AppUtils.checkActivityName(activity);
            NativeAdView nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.admob_native_exit, null);
            if (adSize == NativeAdSize.Exit) {
                nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.admob_native_exit, null);
            }
            nativeAdView.setMediaView(nativeAdView.findViewById(R.id.media_view));
            nativeAdView.setHeadlineView(nativeAdView.findViewById(R.id.primary));
            nativeAdView.setBodyView(nativeAdView.findViewById(R.id.secondary));
            nativeAdView.setCallToActionView(nativeAdView.findViewById(R.id.cta));
            nativeAdView.setIconView(nativeAdView.findViewById(R.id.icon));
            nativeAdView.setAdvertiserView(nativeAdView.findViewById(R.id.tertiary));
            NativeAdView finalNativeAdView = nativeAdView;
            F_Request = "f_request";
            F_Load = "f_load";
            F_Fail_Load = "f_fail_to_load";
            F_Open = "f_open";
            F_Close = "f_close";
            F_Click = "f_click";
            F_Impression = "f_impression";

            AppUtils.logAdapterMessages(ads_native, F_Request, activityName);
            if (mNativeGameZoneAd != null){
                NativeGameZoneAds.populateNativeAdView(mNativeGameZoneAd, finalNativeAdView);
                fLayout.setVisibility(View.VISIBLE);
                fLayout.removeAllViews();
                fLayout.addView(nativeAdView);
            } else {
                AdLoader.Builder builder = new AdLoader.Builder(activity, UtilsStaticData.getGameZoneNativeId(activity)).forNativeAd(nativeAd -> {
                    mNativeGameZoneAd = nativeAd;
                    mNativeAdGameZoneProcess = false;
                    NativeGameZoneAds.populateNativeAdView(nativeAd, finalNativeAdView);
                    fLayout.removeAllViews();
                    fLayout.addView(finalNativeAdView);

                }).withAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                        AppUtils.logAdapterMessages(ads_native, F_Close, activityName);
                        super.onAdClosed();
                    }

                    @Override
                    public void onAdImpression() {
                        super.onAdImpression();
                        AppUtils.logAdapterMessages(ads_native, F_Impression, activityName);

                    }

                    @Override
                    public void onAdOpened() {
                        super.onAdOpened();
                        AppUtils.logAdapterMessages(ads_native, F_Open, activityName);
                    }

                    @Override
                    public void onAdLoaded() {
                        AppUtils.logAdapterMessages(ads_native, F_Load, activityName);
                        logNativeImpressionData(UtilsStaticData.getGameZoneNativeId(activity));
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError adError) {
                        AppUtils.logAdapterMessages(ads_native, F_Fail_Load, activityName + "_" + adError.getCode());
                        reLoadNativeAds(activity, fLayout, adSize);
                    }

                    @Override
                    public void onAdClicked() {
                        AppUtils.logAdapterMessages(ads_native, F_Click, activityName);
                    }
                });
                builder.build().loadAd(new AdRequest.Builder().build());
            }

        }

    }

    private static void reLoadNativeAds(Activity activity, final FrameLayout fLayout, final NativeAdSize adSize) {


        NativeAdView nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.admob_native_exit, null);
        if (adSize == NativeAdSize.Exit) {
            nativeAdView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.admob_native_exit, null);
        }
        String activityName = AppUtils.checkActivityName(activity);
        nativeAdView.setMediaView((MediaView) nativeAdView.findViewById(R.id.media_view));
        nativeAdView.setHeadlineView(nativeAdView.findViewById(R.id.primary));
        nativeAdView.setBodyView(nativeAdView.findViewById(R.id.secondary));
        nativeAdView.setCallToActionView(nativeAdView.findViewById(R.id.cta));
        nativeAdView.setIconView(nativeAdView.findViewById(R.id.icon));
        nativeAdView.setAdvertiserView(nativeAdView.findViewById(R.id.tertiary));

        NativeAdView finalNativeAdView = nativeAdView;

        F_Request = "b_request";
        F_Load = "b_load";
        F_Fail_Load = "b_fail_to_load";
        F_Open = "b_open";
        F_Close = "b_close";
        F_Click = "b_click";
        F_Impression = "b_impression";
        AppUtils.logAdapterMessages(ads_native, F_Request, activityName);
        AdLoader.Builder builder = new AdLoader.Builder((Context) activity, UtilsStaticData.getBackNativeId(activity)).forNativeAd(nativeAd -> {
            mNativeGameZoneAd = nativeAd;
            NativeGameZoneAds.populateNativeAdView(nativeAd, finalNativeAdView);
            fLayout.removeAllViews();
            fLayout.addView(finalNativeAdView);
            mNativeAdGameZoneProcess = false;

        }).withAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                super.onAdClosed();
                AppUtils.logAdapterMessages(ads_native, F_Close, activityName);
            }

            @Override
            public void onAdImpression() {
                super.onAdImpression();
                AppUtils.logAdapterMessages(ads_native, F_Impression, activityName);
            }

            @Override
            public void onAdClicked() {
                AppUtils.logAdapterMessages(ads_native, F_Click, activityName);
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                AppUtils.logAdapterMessages(ads_native, F_Load, activityName);
                logNativeImpressionData(UtilsStaticData.getBackNativeId(activity));
                fLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                AppUtils.logAdapterMessages(ads_native, F_Fail_Load, activityName + "_" + adError.getCode());
                mNativeAdGameZoneProcess = false;

            }
        });
        builder.build().loadAd(new AdRequest.Builder().build());

    }

    public static void populateNativeAdView(NativeAd nativeAd, NativeAdView nativeAdView) {
        ((TextView) nativeAdView.getHeadlineView()).setText(nativeAd.getHeadline());
        ((TextView) nativeAdView.getBodyView()).setText(nativeAd.getBody());
        ((TextView) nativeAdView.getCallToActionView()).setText(nativeAd.getCallToAction());
        NativeAd.Image icon = nativeAd.getIcon();
        if (icon == null) {
            nativeAdView.getIconView().setVisibility(View.INVISIBLE);
        } else {
            ((ImageView) nativeAdView.getIconView()).setImageDrawable(icon.getDrawable());
            nativeAdView.getIconView().setVisibility(View.VISIBLE);
        }
        if (nativeAd.getAdvertiser() == null) {
            nativeAdView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) nativeAdView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            nativeAdView.getAdvertiserView().setVisibility(View.VISIBLE);
        }
        if (nativeAdView.getMediaView() != null) {
            nativeAdView.getMediaView().setImageScaleType(ImageView.ScaleType.FIT_XY);
        }
        nativeAdView.setNativeAd(nativeAd);
        mNativeGameZoneAd = null;
    }

    private static void logNativeImpressionData(String admobAdId) {
        mNativeGameZoneAd.setOnPaidEventListener(adValue -> {
            Bundle mBundle = new Bundle();
            mBundle.putString("valueMicros", adValue.getValueMicros() + "");
            mBundle.putString("currencyCode", adValue.getCurrencyCode() + "");
            mBundle.putString("precision", adValue.getPrecisionType() + "");
            mBundle.putString("adUnitId", admobAdId);
            AppUtils.logAdapterBundleMessages(EventKeys.paid_ad_impression, mBundle);
        });
    }

}
