package com.convoconnect.messenger.sms.text.common.base

import androidx.lifecycle.LifecycleOwner

interface MessagesViewContract<in State>: LifecycleOwner {

    fun render(state: State)

}