package gallery.app.picasa.web.albums.photo.folder.gallery.commons.extensions

import android.content.Context
import android.os.Environment

fun Context.getSharedPrefs() = getSharedPreferences("Prefs", Context.MODE_PRIVATE)

