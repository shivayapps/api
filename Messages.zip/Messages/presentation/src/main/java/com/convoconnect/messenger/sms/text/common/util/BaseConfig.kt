package com.convoconnect.messenger.sms.text.common.util

import android.content.Context
import gallery.app.picasa.web.albums.photo.folder.gallery.commons.extensions.getSharedPrefs
import com.convoconnect.messenger.sms.text.common.PreferanceData.PreferenceKeys.is_ads_remove

open class BaseConfig(val context: Context) {
    protected val prefs = context.getSharedPrefs()

    companion object {
        fun newInstance(context: Context) = BaseConfig(context)
    }


    var ads_free: Boolean
        get() = prefs.getBoolean(is_ads_remove, false)
        set(show) = prefs.edit().putBoolean(is_ads_remove, show).apply()
//    var ads_free = true


}