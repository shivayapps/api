package com.convoconnect.messenger.sms.text.common.base;

import android.view.Menu;

import io.reactivex.subjects.BehaviorSubject;
import io.reactivex.subjects.Subject;
import kotlin.jvm.internal.Intrinsics;
import com.convoconnect.messenger.sms.text.repository.ConversationRepository;
import com.convoconnect.messenger.sms.text.repository.MessageRepository;
import com.convoconnect.messenger.sms.text.util.PhoneNumberUtils;
import com.convoconnect.messenger.sms.text.util.Preferences;

public class NewMessageThemedActivity extends MessagesActivity {

    public ConversationRepository conversationRepo;
    private final Subject<Menu> menu;
    public MessageRepository messageRepo;
    public PhoneNumberUtils phoneNumberUtils;
    public Preferences prefs;
    private final Subject<Long> threadId;

    NewMessageThemedActivity(){
        BehaviorSubject create = BehaviorSubject.create();
        Intrinsics.checkExpressionValueIsNotNull(create, "BehaviorSubject.create()");
        this.menu = create;
        BehaviorSubject createDefault = BehaviorSubject.createDefault(0L);
        Intrinsics.checkExpressionValueIsNotNull(createDefault, "BehaviorSubject.createDefault(0)");
        this.threadId = createDefault;
    }
}
