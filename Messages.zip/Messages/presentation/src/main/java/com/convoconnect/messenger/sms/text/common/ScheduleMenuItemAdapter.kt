package com.convoconnect.messenger.sms.text.common

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.ArrayRes
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import kotlinx.android.synthetic.main.schedule_menu_list_item.*
import com.convoconnect.messenger.sms.text.R
import com.convoconnect.messenger.sms.text.common.base.MessagesAdapter
import com.convoconnect.messenger.sms.text.common.base.MessagesViewHolder
import com.convoconnect.messenger.sms.text.common.util.extensions.resolveThemeColor
import javax.inject.Inject

class ScheduleMenuItemAdapter @Inject constructor(
    private val context: Context
) : MessagesAdapter<MenuItem>() {

    val menuItemClicks: Subject<Int> = PublishSubject.create()

    private val disposables = CompositeDisposable()

    var selectedItem: Int? = null
        set(value) {
            val old = data.map { it.actionId }.indexOfFirst { it == field }
            val new = data.map { it.actionId }.indexOfFirst { it == value }

            field = value

            old.let { notifyItemChanged(it) }
            new.let { notifyItemChanged(it) }
        }

    fun setData(@ArrayRes titles: Int, @ArrayRes values: Int = -1) {
        val valueInts = if (values != -1) context.resources.getIntArray(values) else null

        data = context.resources.getStringArray(titles)
            .mapIndexed { index, title ->
                MenuItem(title, valueInts?.getOrNull(index) ?: index)
            }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessagesViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)

        val view = layoutInflater.inflate(R.layout.schedule_menu_list_item, parent, false)

        val states = arrayOf(
            intArrayOf(android.R.attr.state_activated),
            intArrayOf(-android.R.attr.state_activated)
        )

        val text = parent.context.resolveThemeColor(android.R.attr.textColorTertiary)
        /* view.ivOptionView.imageTintList =
             ColorStateList(states, intArrayOf(colors.theme().theme, text))*/

        return MessagesViewHolder(view).apply {
            view.setOnClickListener {
                val menuItem = getItem(absoluteAdapterPosition)
                menuItemClicks.onNext(menuItem.actionId)
            }
        }
    }

    override fun onBindViewHolder(holder: MessagesViewHolder, position: Int) {
        val menuItem = getItem(position)
        holder.title.text = menuItem.title
        if (position == 0) {
            holder.divider.visibility = View.VISIBLE
            holder.ivOptionView.setImageDrawable(
                ContextCompat.getDrawable(
                    context,
                    R.drawable.ic_schedule_send
                )
            )
        }
        if (position == 1) {
            holder.divider.visibility = View.VISIBLE
            holder.ivOptionView.setImageDrawable(
                ContextCompat.getDrawable(
                    context,
                    R.drawable.ic_schedule_copy
                )
            )
        }
        if (position == 2) {
            holder.divider.visibility = View.INVISIBLE
            holder.ivOptionView.setImageDrawable(
                ContextCompat.getDrawable(
                    context,
                    R.drawable.ic_schedule_delete
                )
            )
        }
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        super.onDetachedFromRecyclerView(recyclerView)
        disposables.clear()
    }

}