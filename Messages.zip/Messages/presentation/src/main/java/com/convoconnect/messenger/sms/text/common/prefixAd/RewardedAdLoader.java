package com.convoconnect.messenger.sms.text.common.prefixAd;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import com.convoconnect.messenger.sms.text.R;
import com.convoconnect.messenger.sms.text.common.MessagesApplication;
import com.convoconnect.messenger.sms.text.common.util.AppUtils;
import com.convoconnect.messenger.sms.text.common.util.extensions.ContextExtensionsKt;
import com.convoconnect.messenger.sms.text.common.PreferanceData.AppPreference;
import com.convoconnect.messenger.sms.text.common.PreferanceData.PreferenceKeys;
import com.convoconnect.messenger.sms.text.common.staticData.EventKeys;
import com.convoconnect.messenger.sms.text.common.staticData.UtilsStaticData;
import com.convoconnect.messenger.sms.text.utils.ConstantsKt;


public class RewardedAdLoader {
    private static RewardedAd mRewardedAd;
    private static final String TAG = RewardedAdLoader.class.getSimpleName();
    private static final String ads_rewarded = "ads_rewarded";
    private static String F_Load = "f_load";
    private static String F_Show = "f_show";
    private static String F_FailToShow = "f_fail_to_show";
    private static String F_Fail = "f_fail";
    private static String F_Request = "f_request";
    private static String F_Click = "f_click";
    private static String F_dismiss = "f_dismiss";
    private static String F_Impression = "f_impression";

    private static boolean isRewardAdLoading = false;


    private static AlertDialog alertDialog = null;
    private static RewardAdCallback mRewardAdCallback = null;
    private static final boolean wantToGiveRewardAfterFullAdViewedTemp = true;
    private static boolean wantToGiveRewardAfterFullAdViewed = wantToGiveRewardAfterFullAdViewedTemp;

    @SuppressLint("StaticFieldLeak")
    private static AppPreference appPreference;

    private static CountDownTimer countDownTimer;

    public interface RewardAdCallback {

        void onAdLoadFailed();

        void onAdDismiss();
    }

    private static void showVideoAd(Activity activity, String reward_id, String reward_int_back_id) {
        appPreference = new AppPreference(activity);
        if (mRewardedAd != null && !appPreference.getBooleanData(PreferenceKeys.is_ads_remove) && ConstantsKt.isOnline(activity)) {

            String actName = AppUtils.checkActivityName(activity);

            mRewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdClicked() {
                    super.onAdClicked();
                    AppUtils.logAdapterMessages(ads_rewarded, F_Click, actName);
                }

                @Override
                public void onAdImpression() {
                    AppUtils.logAdapterMessages(ads_rewarded, F_Impression, actName);
                    super.onAdImpression();
                }

                @Override
                public void onAdShowedFullScreenContent() {
                    Log.w(TAG, "showVideoAd onAdShowedFullScreenContent-");
                    AppUtils.logAdapterMessages(ads_rewarded, F_Show, actName);
                    appPreference.saveData(PreferenceKeys.IS_OPEN_AD, false);

                }

                @SuppressLint("WrongConstant")
                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    Log.w(TAG, "showVideoAd onAdFailedToShowFullScreenContent- " + adError.getCode());
                    AppUtils.logAdapterMessages(ads_rewarded, F_FailToShow, adError.getCode() + "_" + actName);
                    isRewardAdLoading = false;
                    if (mRewardAdCallback != null) {
                        mRewardAdCallback.onAdLoadFailed();
                    }
                    mRewardedAd = null;
                    appPreference.saveData(PreferenceKeys.IS_OPEN_AD, true);
                    if (alertDialog != null && alertDialog.isShowing() && !activity.isFinishing()) {
                        if (countDownTimer != null) {
                            countDownTimer.cancel();
                            countDownTimer = null;
                        }
                        alertDialog.dismiss();
                    }
                }

                @Override
                public void onAdDismissedFullScreenContent() {
                    Log.w(TAG, "showVideoAd onAdDismissedFullScreenContent ");
                    AppUtils.logAdapterMessages(ads_rewarded, F_dismiss, actName);
                    isRewardAdLoading = false;
                    mRewardedAd = null;
                    if (alertDialog != null && alertDialog.isShowing() && !activity.isFinishing()) {
                        if (countDownTimer != null) {
                            countDownTimer.cancel();
                            countDownTimer = null;
                        }
                        alertDialog.dismiss();
                    }
                    if (!wantToGiveRewardAfterFullAdViewed && mRewardAdCallback != null) {
                        mRewardAdCallback.onAdDismiss();
                    }
                    wantToGiveRewardAfterFullAdViewed = wantToGiveRewardAfterFullAdViewedTemp;
                    appPreference.saveData(PreferenceKeys.IS_OPEN_AD, true);
                    appPreference.saveData(PreferenceKeys.SystemDialogOpened, true);
                    mRewardedAd = null;
                    if (MessagesApplication.remoteConfig.getBoolean(UtilsStaticData.preload_premium_ad) && MessagesApplication.remoteConfig.getString(UtilsStaticData.premium_ad_type).equalsIgnoreCase(UtilsStaticData.admob_reward)) {
                        loadPreLoadRewardAd(activity, reward_id, reward_int_back_id);
                    }
                }
            });
            mRewardedAd.show(activity, rewardItem -> wantToGiveRewardAfterFullAdViewed = false);
        }
    }

    static boolean isTimeUp = false;
    public static void loadRewardedAd(Activity activity, String admob_rewarded, String admob_back_rewarded, RewardAdCallback mCallBack) {
        appPreference = new AppPreference(activity);
        mRewardAdCallback = mCallBack;
        if (!appPreference.getBooleanData(PreferenceKeys.is_ads_remove) && ConstantsKt.isOnline(activity)) {
            F_Show = "f_show";
            F_Click = "f_click";
            F_dismiss = "f_dismiss";
            F_Impression = "f_impression";
            F_FailToShow = "f_fail_to_show";
            Log.e(TAG, "loadRewardedAd:1 -------------" + isRewardAdLoading);
            Log.e(TAG, "loadRewardedAd:2 -------------" + mRewardedAd);
            Log.e(TAG, "loadRewardedAd:3 -------------" + mRewardAdCallback);

            long countTimerCloseTime;
            try {
                countTimerCloseTime = Long.parseLong(MessagesApplication.remoteConfig.getString(UtilsStaticData.reward_ad_show_process_dialog_close_time));
            } catch (Exception e) {
                countTimerCloseTime = 20000L;
            }
            Log.e(TAG, "loadRewardedAd: -----------------------"+countTimerCloseTime);
            countDownTimer = new CountDownTimer(countTimerCloseTime, 100L) {
                @Override
                public void onTick(long millisUntilFinished) {

                }

                @Override
                public void onFinish() {
                    if (mRewardedAd == null) {
                        if (alertDialog != null && alertDialog.isShowing() && !activity.isFinishing()) {
                            alertDialog.dismiss();
                        }
                        isTimeUp = true;
                        ContextExtensionsKt.makeToast(activity, activity.getString(R.string.something_went_wrong_Please_Try_Again_Later), Toast.LENGTH_SHORT);
                    }
                }
            };
            isTimeUp=false;
            countDownTimer.start();
            if (!isRewardAdLoading && mRewardedAd == null && !activity.isFinishing()) {
                F_Request = "f_request";
                F_Load = "f_load";
                F_Fail = "f_fail_to_load";
                isRewardAdLoading = true;

                String actName = AppUtils.checkActivityName(activity);
                showProgressDialog(activity);
                AppUtils.logAdapterMessages(ads_rewarded, F_Request, actName);
                RewardedAd.load(activity, admob_rewarded,
                        new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                // Handle the error.

                                Log.w(TAG, "loadRewardedVideoAd onAdFailedToLoad==" + loadAdError.getMessage());
                                mRewardedAd = null;
                                AppUtils.logAdapterMessages(ads_rewarded, F_Fail, loadAdError.getCode() + "_" + actName);
                                if (MessagesApplication.remoteConfig.getString(UtilsStaticData.is_back_id_required).equals("true") && !isTimeUp) {
                                    countDownTimer.cancel();
                                    loadRewardedReloadAd(activity, admob_back_rewarded, admob_back_rewarded);
                                }
                            }

                            @Override
                            public void onAdLoaded(@NonNull RewardedAd rewardedAd) {

                                mRewardedAd = rewardedAd;
                                AppUtils.logAdapterMessages(ads_rewarded, F_Load, actName);
                                Log.w(TAG, "loadRewardedVideoAd onAdLoaded-");
                                if (isRewardAdLoading && mRewardAdCallback != null && !isTimeUp) {
                                    countDownTimer.cancel();
                                    showVideoAd(activity, admob_rewarded, admob_back_rewarded);
                                }
                                logRewardedImpressionData(rewardedAd);
                            }

                        });

            } else if (mRewardAdCallback != null && mRewardedAd != null && !activity.isFinishing()) {
                showProgressDialog(activity);
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    if (mRewardAdCallback != null && mRewardedAd != null) {
                        showVideoAd(activity, admob_rewarded, admob_back_rewarded);
                    }
                }, 500);

            } else if (!activity.isFinishing()) {
                showProgressDialog(activity);
            }

        }
    }

    public static void loadRewardedReloadAd(Activity activity, String reward_ad_id, String admob_back_rewarded) {

        appPreference = new AppPreference(activity);
        if (!appPreference.getBooleanData(PreferenceKeys.is_ads_remove) && ConstantsKt.isOnline(activity)) {
            F_Request = "b_request";
            F_Load = "b_load";
            F_Fail = "b_fail_to_load";
            F_Show = "b_show";
            F_Click = "b_click";
            F_dismiss = "b_dismiss";
            F_Impression = "b_impression";
            F_FailToShow = "b_fail_to_show";
            String actName = AppUtils.checkActivityName(activity);

            AppUtils.logAdapterMessages(ads_rewarded, F_Request, actName);
            RewardedAd.load(activity, admob_back_rewarded,
                    new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            // Handle the error.
                            Log.w(TAG, "loadRewardedVideoAdReLoad onAdFailedToLoad - " + loadAdError.getMessage());

                            AppUtils.logAdapterMessages(ads_rewarded, F_Fail, loadAdError.getCode() + "_" + actName);
                            isRewardAdLoading = false;
                            mRewardedAd = null;

                            if (mRewardAdCallback != null) {
                                mRewardAdCallback.onAdLoadFailed();
                            }

                            if (alertDialog != null && alertDialog.isShowing() && !activity.isFinishing()) {
                                alertDialog.dismiss();
                            }
                        }

                        @Override
                        public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                            AppUtils.logAdapterMessages(ads_rewarded, F_Load, actName);
                            mRewardedAd = rewardedAd;
                            Log.w(TAG, "loadRewardedVideoAdReLoad onAdLoaded- ");
                            if (isRewardAdLoading && mRewardAdCallback != null) {
                                showVideoAd(activity, reward_ad_id, admob_back_rewarded);
                            }
                            logRewardedImpressionData(rewardedAd);
                        }
                    });
        }
    }

    public static void loadPreLoadRewardAd(Activity activity, String reward_id,
                                           String reward_back_id) {
        appPreference = new AppPreference(activity);
        if (!appPreference.getBooleanData(PreferenceKeys.is_ads_remove)
                && ConstantsKt.isOnline(activity)) {

            String actName = AppUtils.checkActivityName(activity);
            AppUtils.logAdapterMessages(ads_rewarded, F_Request, actName);

            if (!isRewardAdLoading && mRewardedAd == null) {
                F_Request = "f_request";
                F_Load = "f_load";
                F_Fail = "f_fail_to_load";
                isRewardAdLoading = true;

                AdRequest adRequest = new AdRequest.Builder().build();
                RewardedAd.load(activity, reward_id,
                        adRequest, new RewardedAdLoadCallback() {
                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                super.onAdFailedToLoad(loadAdError);
                                AppUtils.logAdapterMessages(ads_rewarded, F_Fail, loadAdError.getCode() + "_" + actName);
                                mRewardedAd = null;
                                preReloadReward(activity, reward_back_id);
                            }

                            @Override
                            public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                                super.onAdLoaded(rewardedAd);
                                AppUtils.logAdapterMessages(ads_rewarded, F_Load, actName);
                                mRewardedAd = rewardedAd;
                                logRewardedImpressionData(rewardedAd);
                            }
                        });
            }
        }
    }

    private static void logRewardedImpressionData(RewardedAd rewardedAd) {
        rewardedAd.setOnPaidEventListener(adValue -> {
            Bundle mBundle = new Bundle();
            mBundle.putString("valueMicros", adValue.getValueMicros() + "");
            mBundle.putString("currencyCode", adValue.getCurrencyCode() + "");
            mBundle.putString("precision", adValue.getPrecisionType() + "");
            mBundle.putString("adUnitId", rewardedAd.getAdUnitId());
            AppUtils.logAdapterBundleMessages(EventKeys.paid_ad_impression, mBundle);
            Log.e("JASH---", "logRewardedImpressionData: ------------" + mBundle);
        });
    }

    private static void preReloadReward(Activity activity, String reward_back_id) {
        F_Request = "b_request";
        F_Load = "b_load";
        F_Fail = "b_fail_to_load";

        String actName = AppUtils.checkActivityName(activity);
        AppUtils.logAdapterMessages(ads_rewarded, F_Request, actName);

        AdRequest adRequest = new AdRequest.Builder().build();
        RewardedAd.load(activity, reward_back_id,
                adRequest, new RewardedAdLoadCallback() {
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
                        AppUtils.logAdapterMessages(ads_rewarded, F_Fail, loadAdError.getCode() + "_" + actName);
                        mRewardedAd = null;
                        isRewardAdLoading = false;
                    }

                    @Override
                    public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                        super.onAdLoaded(rewardedAd);
                        F_Show = "b_show";
                        F_Click = "b_click";
                        F_dismiss = "b_dismiss";
                        F_Impression = "b_impression";
                        F_FailToShow = "b_fail_to_show";
                        mRewardedAd = rewardedAd;
                        AppUtils.logAdapterMessages(ads_rewarded, F_Load, actName);
                        logRewardedImpressionData(rewardedAd);
                    }
                });
    }

    private static void showProgressDialog(Activity activity) {
        if (activity != null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            LayoutInflater inflater = activity.getLayoutInflater();
            View convertview = inflater.inflate(R.layout.dialog_reward_ad_loading, null);
            builder.setView(convertview);
            alertDialog = builder.create();
            alertDialog.setCancelable(true);
            alertDialog.setCanceledOnTouchOutside(true);
            alertDialog.setOnCancelListener(dialogInterface -> {
                if (mRewardAdCallback != null) {
                    mRewardAdCallback.onAdLoadFailed();
                }
                mRewardAdCallback = null;
            });
            alertDialog.setOnDismissListener(dialogInterface -> mRewardAdCallback = null);
            alertDialog.show();
            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        }
    }

}
