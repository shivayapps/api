package org.w3c.dom.smil;

public interface SMILParElement extends ElementParallelTimeContainer, SMILElement { }
