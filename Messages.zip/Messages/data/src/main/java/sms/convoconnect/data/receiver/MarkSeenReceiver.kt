package sms.convoconnect.data.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.android.AndroidInjection
import sms.convoconnect.domain.interactor.MarkSeen
import javax.inject.Inject

class MarkSeenReceiver : BroadcastReceiver() {

    @Inject
    lateinit var markSeen: MarkSeen

    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)

        val pendingResult = goAsync()
        val threadId = intent.getLongExtra("threadId", 0)
        markSeen.execute(threadId) {
            try {
                pendingResult.finish()
            } catch (e: IllegalStateException) {
                sms.convoconnect.data.extensions.LogE(
                    "IllegalStateException: ",
                    e.message.toString()
                )
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}