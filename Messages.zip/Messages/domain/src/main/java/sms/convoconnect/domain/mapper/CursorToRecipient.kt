package sms.convoconnect.domain.mapper

import android.database.Cursor
import sms.convoconnect.domain.model.Recipient

interface CursorToRecipient : Mapper<Cursor, Recipient> {

    fun getRecipientCursor(): Cursor?

    fun getRecipientCursor(id: Long): Cursor?

}