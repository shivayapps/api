package sms.convoconnect.domain.mapper

import android.database.Cursor
import sms.convoconnect.domain.model.Conversation

interface CursorToConversation : Mapper<Cursor, Conversation> {

    fun getConversationsCursor(): Cursor?

}