package sms.convoconnect.domain.interactor

import android.telephony.SmsMessage
import android.util.Log
import io.reactivex.Flowable
import sms.convoconnect.domain.extensions.LogE
import sms.convoconnect.domain.extensions.mapNotNull
import sms.convoconnect.domain.manager.NotificationManager
import sms.convoconnect.domain.manager.ShortcutManager
import sms.convoconnect.domain.repository.BlockingRepository
import sms.convoconnect.domain.repository.ConversationRepository
import sms.convoconnect.domain.repository.MessageRepository
import sms.convoconnect.domain.util.Preferences
import javax.inject.Inject

class ReceiveSms @Inject constructor(
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val messageRepo: MessageRepository,
    private val notificationManager: NotificationManager,
    private val updateBadge: UpdateBadge,
    private val shortcutManager: ShortcutManager,
    private val blockingRepository: BlockingRepository
) : Interactor<ReceiveSms.Params>() {

    class Params(val subId: Int, val messages: Array<SmsMessage>)

    override fun buildObservable(params: Params): Flowable<*> {
        return Flowable.just(params)
            .filter { it.messages.isNotEmpty() }
            .mapNotNull {
                Log.w("messageApp : ", " sms buildObservable")
                // Don't continue if the sender is blocked
                val messages = it.messages
                val address = messages[0].displayOriginatingAddress
                val isBlocked = blockingRepository.isBlocked(address)
                val shouldDrop = prefs.drop.get()
                Log.w("messageApp : ", "block=$isBlocked, drop=$shouldDrop")

                // If we should drop the message, don't even save it
                if (isBlocked && shouldDrop) {
                    return@mapNotNull null
                }

                val time = messages[0].timestampMillis
                val body: String = messages
                    .mapNotNull { message -> message.displayMessageBody }
                    .reduce { body, new -> body + new }

                // Add the message to the db
                val message = messageRepo.insertReceivedSms(it.subId, address, body, time)
                Log.w("messageApp : ", " sms message" + message)

                message
            }
            .doOnNext { message ->
                conversationRepo.updateConversations(message.threadId) // Update the conversation
            }
            .mapNotNull { message ->
                conversationRepo.getOrCreateConversation(message.threadId) // Map message to conversation
            }
            .filter { conversation -> !conversation.blocked } // Don't notify for blocked conversations
            .doOnNext { conversation ->
                // Unarchive conversation if necessary
                if (conversation.archived) conversationRepo.markUnarchived(conversation.id)
            }
            .map { conversation -> conversation.id } // Map to the id because [delay] will put us on the wrong thread
            .doOnNext { threadId ->
                try {
                    var conversation = conversationRepo.getConversation(threadId)
                    if (!conversation!!.blocked) {
                        notificationManager.update(threadId)
                    }
                } catch (e: Exception) {
                    LogE("notificationManager: ", e.message.toString())
                }
            } // Update the notification
            .doOnNext { shortcutManager.updateShortcuts() } // Update shortcuts
            .flatMap { updateBadge.buildObservable(Unit) } // Update the badge and widget
    }

}
