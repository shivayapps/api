package sms.convoconnect.domain.manager

interface ReferralManager {

    fun trackReferrer()

}
