package sms.convoconnect.domain.interactor

import io.reactivex.Flowable
import io.reactivex.rxkotlin.toFlowable
import io.realm.RealmList
import sms.convoconnect.domain.extensions.mapNotNull
import sms.convoconnect.domain.interactor.Interactor
import sms.convoconnect.domain.repository.ScheduledMessageRepository
import javax.inject.Inject

class ScheduleMessageDelete @Inject constructor(
    private val scheduledMessageRepo: ScheduledMessageRepository
) : Interactor<Long>() {
    override fun buildObservable(params: Long): Flowable<*> {
        return Flowable.just(params)
            .mapNotNull(scheduledMessageRepo::getScheduledMessage)
            .flatMap { message ->
                if (message.sendAsGroup) {
                    listOf(message)
                } else {
                    message.recipients.map { recipient ->
                        message.copy(
                            recipients = RealmList(
                                recipient
                            )
                        )
                    }
                }.toFlowable()
            }
            .doOnNext { scheduledMessageRepo.deleteScheduledMessage(params) }
    }

}