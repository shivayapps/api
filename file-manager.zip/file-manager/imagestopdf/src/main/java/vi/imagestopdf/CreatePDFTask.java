package vi.imagestopdf;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;


import androidx.annotation.RequiresApi;
import androidx.core.content.FileProvider;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfAction;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfDocument;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.concurrent.locks.ReadWriteLock;

public class CreatePDFTask extends AsyncTask<String, Integer, File>{

    private final Context context;
    private final ArrayList<File> files;
    private CreatePDFListener createPDFListener;
    private String filename;
    private boolean isShare;
    private int quality;
    private boolean isNeedToShow;

    public CreatePDFTask(Context context, ArrayList<File> files, CreatePDFListener createPDFListener, String name,boolean isShare,int quality,boolean isNeedToShow) {
        this.context = context;
        this.files = files;
        this.createPDFListener = createPDFListener;
        this.filename = name;
        this.isShare = isShare;
        this.quality = quality;
        this.isNeedToShow = isNeedToShow;
    }


    public void manipulatePdf(String src, String dest) throws IOException, DocumentException {

        PdfReader reader = new PdfReader(src);
        int n = reader.getNumberOfPages();
        PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(dest));
        stamper.setRotateContents(false);



        // text watermark
        Font f = new Font(Font.FontFamily.HELVETICA, 18);

//        Phrase p = new Phrase("\"https://play.google.com/store/apps/details?id=com.photo.image.video.photogallery\"", f);

        Drawable d = context.getResources ().getDrawable (R.drawable.ic_app_logo);
        int wh = 1, hh = 1;
        Bitmap.Config conf = Bitmap.Config.ARGB_8888; // see other conf types
        Bitmap bmp = Bitmap.createBitmap(wh, hh, conf); // this creates a MUTABLE bitmap

        Bitmap bitmap;
        if (isNeedToShow)
        {
             bitmap = ((BitmapDrawable)d).getBitmap();
        }
        else {
             bitmap = bmp;
             }
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] bitmapData = stream.toByteArray();

//        Paragraph ps = new Paragraph();
//        ps.add(createImage(bitmapData, "https://play.google.com/store/apps/details?id=com.photo.image.video.photogallery"));

        // image watermark
        Image img = Image.getInstance(bitmapData);

        float w = img.getScaledWidth();
        float h = img.getScaledHeight();

        PdfContentByte over;
        Rectangle pagesize;
        float x, y;

        // loop over every page
        for (int i = 1; i <= n; i++) {

            pagesize = reader.getPageSize(i);
            x = pagesize.getLeft() +15;
            y = pagesize.getBottom()+30;
            over = stamper.getOverContent(i);
            over.saveState();
          //  over.addImage(img, w, 0, 0, h, x, y - (h / 2));
           // ColumnText.showTextAligned(over, Element.ALIGN_CENTER, ps, x, y, 0);
            over.restoreState();
        }

        stamper.close();
        reader.close();

        SharedPrefs.PdfName="";

        if (outputFile.exists())
            outputFile.delete();

        if (createPDFListener != null)
            createPDFListener.onPDFGenerated(new File(dest), files.size());

        if(isShare)
        {
            sharePDF(context,new File(dest));
        }
    }
    File outputFile;

    public void sharePDF(Context context, File pdfFile) {
        Intent intentShareFile = new Intent(Intent.ACTION_SEND);

        if (pdfFile.exists()) {

            Uri contentUri = FileProvider.getUriForFile(context, "com.photo.image.video.photogallery.FileProvider", pdfFile);

            Log.e("SharePDF", "sharePDF: "+pdfFile.getPath());
            intentShareFile.setType("application/pdf");
            intentShareFile.putExtra(Intent.EXTRA_TEXT, "Make more PDF with app link \n https://play.google.com/store/apps/" +
                    "details?id=com.photo.image.video.photogallery");
            intentShareFile.putExtra(Intent.EXTRA_STREAM, contentUri);
            intentShareFile.putExtra(Intent.EXTRA_SUBJECT, "Shared via Camera Scanner");

            context.startActivity(Intent.createChooser(intentShareFile, "Share PDF"));
        }
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();


    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onPostExecute(File s) {
        super.onPostExecute(s);

        if (createPDFListener != null)
                createPDFListener.onPDFGenerated(s, files.size());

//            if(Build.VERSION.SDK_INT > Build.VERSION_CODES.Q)
//            {
            //    manipulatePdf(s.getAbsolutePath(),Utils.getOutputMediaFile(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getAbsolutePath() + "/PDF Document Scanner", this.filename + ".pdf").getAbsolutePath());
//            }
//            else{
//                manipulatePdf(s.getAbsolutePath(),Utils.getOutputMediaFile(Utils.PDFS_PATH, this.filename + ".pdf").getAbsolutePath());
//            }



    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected File doInBackground(String... params) {
     //   SharedPrefs.PdfName=this.filename;
        outputFile = Utils.getOutputMediaFile(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getAbsolutePath() + "/Gallery", this.filename + ".pdf");
        Document document = new Document(PageSize.A4, 10,10,0,10);

        try {

            PdfWriter.getInstance(document, new FileOutputStream(outputFile.getPath()));
            document.open();


            for (int i = 0; i < files.size(); i++) {

                OutputStream os = null;

                try {

                    Bitmap bitmap = BitmapFactory.decodeFile(files.get(i).getAbsolutePath());
                    os= context.getContentResolver().openOutputStream(Uri.fromFile(files.get(i)));
                    bitmap.compress(Bitmap.CompressFormat.JPEG, quality, os);


                } catch (FileNotFoundException e) {

                } finally {
                    try {
                        if (os != null) {
                            os.close();
                        }
                    } catch (IOException e) {

                    }
                }


             Image image1 = Image.getInstance(files.get(i).getPath());

                float documentWidth = document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin();
                float documentHeight = document.getPageSize().getHeight() - document.topMargin() - document.bottomMargin();
                image1.scaleToFit(documentWidth, documentHeight-70);

                float x = (PageSize.A4.getWidth() - image1.getScaledWidth()) / 2;
                float y = (PageSize.A4.getHeight() - image1.getScaledHeight()) / 2;
                image1.setAbsolutePosition(x, y);

                Drawable d = context.getResources ().getDrawable (R.drawable.ic_app_logo);
                Bitmap  bitmap = ((BitmapDrawable)d).getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] bitmapData = stream.toByteArray();
                Paragraph ps = new Paragraph();
                ps.add(createImage(bitmapData, "https://play.google.com/store/apps/details?id=com.photo.image.video.photogallery"));

               PdfPTable table = new PdfPTable(1);
                table.setWidthPercentage(100);
                table.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);

                PdfPCell cell = new PdfPCell();
                cell.addElement(ps);
                cell.setBorderWidth(0);
                cell.setVerticalAlignment(Element.ALIGN_BOTTOM);
                cell.setPaddingTop(PageSize.A4.getHeight()-35);
                cell.setPaddingRight(20);
                table.addCell(cell);

//                if (isNeedToShow)
//                {
//                    if (i == (files.size()-1))
//                    {
//                        document.add(table);
//                    }
//
//                }
                document.add(image1);
                document.newPage();
                publishProgress(i);

            }
            document.close();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        return outputFile;
    }


    public Chunk createImage(byte[] imgb, String url) throws BadElementException, IOException {
        Image img = Image.getInstance(imgb);
        Chunk chunk = new Chunk(img, 0, 0, true);
        chunk.setAction(new PdfAction(url));
        return chunk;
    }
    public String getFilename(String path) {
        File file = new File(Environment.getExternalStorageDirectory().getPath(), "MyFolder/Images");
        if (!file.exists()) {
            file.mkdirs();
        }
        String uriSting = null;
        try {
            uriSting   = (file.getAbsolutePath() + "/" + System.currentTimeMillis() + ".jpg");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return uriSting;

    }

    private String getRealPathFromURI(String contentURI) {
        Uri contentUri = Uri.parse(contentURI);
        Cursor cursor = context.getContentResolver().query(contentUri, null, null, null, null);
        if (cursor == null) {
            return contentUri.getPath();
        } else {
            cursor.moveToFirst();
            int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(index);
        }
    }

    public int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
        }
        final float totalPixels = width * height;
        final float totalReqPixelsCap = reqWidth * reqHeight * 2;
        while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
            inSampleSize++;
        }

        return inSampleSize;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);

    }
}