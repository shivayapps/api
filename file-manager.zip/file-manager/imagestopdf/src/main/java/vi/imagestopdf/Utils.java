package vi.imagestopdf;

import android.os.Build;
import android.os.Environment;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

/**
 * Created by droidNinja on 25/07/16.
 */
@RequiresApi(api = Build.VERSION_CODES.KITKAT)
public class Utils {
    private static final String IMAGE_TO_PDF_MODULE = "IMAGE_TO_PDF_MODULE";

    public static String mBusinessCardScannerPath = Environment.getExternalStorageDirectory().getPath()
            + File.separator + "CameraScanner-DocumentScanner" + File.separator +  "Screenshots" +
            File.separator + "BusinessCard";
    public static String mIDcard = Environment.getExternalStorageDirectory().getPath()
            + File.separator + "CameraScanner-DocumentScanner" + File.separator + "Screenshots" +
            File.separator + "BusinessCard";
    public static String mgreettingCardScannerPath = Environment.getExternalStorageDirectory().getPath()
            + File.separator + "CameraScanner-DocumentScanner" + File.separator +  "Screenshots" + File.separator + "GreetingCard";


    //NoActionbarStyle public static final String PDFS_PATH = Environment.getExternalStorageDirectory().getPath() + File.separator + "DocScanner" + File.separator + "PDFs";
    public static final String PDFS_PATH = Environment.getExternalStorageDirectory().getPath() + File.separator +
            "CameraScanner-DocumentScanner" + File.separator + "PDFs";
    public static final String IMAGE_PATH = Environment.getExternalStorageDirectory().getPath() + File.separator +
            "CameraScanner-DocumentScanner" + File.separator + "Images";
    public static final String IMAGE_PATH_TEMP = Environment.getExternalStorageDirectory().getPath() + File.separator +
            ".CameraScanner-DocumentScanner" + File.separator + "TempImages";
    public static final String PDFS_PATH1 = Environment.getExternalStorageDirectory().getPath() + File.separator +
            "CameraScanner-DocumentScanner";
    public static final String IDCard = Environment.getExternalStorageDirectory().getPath() + File.separator +
            "CameraScanner-DocumentScanner" + File.separator + "Screenshots" + File.separator + "IdCard";
 public static final String Download = Environment.getExternalStorageDirectory().getPath() + File.separator +
            "CameraScanner-DocumentScanner" + File.separator + "Screenshots" + File.separator + "CamaraDownload";

    public static File getOutputMediaFile(String path, String name) {
        // To be safe, we should check that the SDCard is mounted

        File dir = new File(path);
        // Create the storage directory if it doesn't exist
        if (!dir.exists()) {
            if (!dir.mkdirs()) {
                Log.e(IMAGE_TO_PDF_MODULE, "Failed to create directory");
                return null;
            }
        }

        return new File(dir.getPath() + File.separator + name);
    }
    public static File getOutputFile(String path) {
        // To be safe, we should check that the SDCard is mounted

        File dir = new File(path);
        // Create the storage directory if it doesn't exist
        if (!dir.exists()) {
            try {
                if (!dir.createNewFile()) {
                    Log.e(IMAGE_TO_PDF_MODULE, "Failed to create directory");
                    return null;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return new File(dir.getPath() );
    }

    public static String getPDFName(ArrayList<File> files) {
        String fileName = "";
        for (int i = 0; i < files.size(); i++) {
            fileName += "_" + files.get(i).getName();
        }
        Log.i("name", fileName);
        String md5 = getMd5(fileName);
        return "PDF_" + md5 + ".pdf";
    }

    public static File getPDFFileFromName(String pdfName) {
        return new File(Utils.PDFS_PATH + File.separator + pdfName);
    }

    public static String getMd5(String text) {
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }

        md.update(text.getBytes());

        byte byteData[] = md.digest();

        //convert the byte to hex format method 1
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < byteData.length; i++) {
            sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
        }

        return sb.toString();
    }
}
