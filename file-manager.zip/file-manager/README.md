# file-manager
file-manager

figma.com/design/KoeprPCRmfHYqRV5v8ZuKX/File-Manager?node-id=0-1&p=f&t=kCLD9QaE8sdQaogU-0
https://docs.google.com/document/d/1yPjtfiwPaZDOHqjOtTKv77Mjw0yNHc-mA1YFly-p-ls/edit?tab=t.0