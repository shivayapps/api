package com.explorefile.filemanager.fragments

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.util.Log
import androidx.activity.viewModels
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.MainAnalysisFragmentBinding
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.updateTextColors
import com.explorefile.filemanager.filecleaner.viewmodel.StorageAnalysisVM
import com.explorefile.filemanager.interfaces.ItemOperationsListener
import com.explorefile.filemanager.models.FileDirItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DecimalFormat
import kotlin.getValue
import kotlin.math.abs

class StorageAnalysisFragment(context: Context, attributeSet: AttributeSet) :
    MyViewPagerFragment<MyViewPagerFragment.AnalysisInnerBinding>(context, attributeSet) {


    private val vm: StorageAnalysisVM by (context as FragmentActivity).viewModels()

    private lateinit var binding: MainAnalysisFragmentBinding

    override fun onFinishInflate() {
        super.onFinishInflate()
        binding = MainAnalysisFragmentBinding.bind(this)
        innerBinding = AnalysisInnerBinding(binding)
    }

    override fun setupFragment(activity: BaseActivity) {
        if (this.activity == null) {
            this.activity = activity
        }
        binding.sabMain.setSegmentSpacing(10f)
        binding.sabMain.setRoundCap(true)
        binding.sabMain.setThick(22f)
        setupObservers()
        setupClickListeners()
    }

    override fun setupCategoriesBinding(activity: BaseActivity) {
    }

    override fun onResume(textColor: Int) {
        context.updateTextColors(binding.root)
        val properPrimaryColor = context.getProperPrimaryColor()

    }

    override fun refreshFragment() {
    }

    private fun setupObservers() {
        vm.startScanStorage()
        vm.scanResult.observe(activity!!) { result ->
            result?.stat?.let { stat ->
                val usedPercent = if (stat.totalSize != 0L)
                    (stat.usedSize * 100 / stat.totalSize).toInt()
                else 0
                binding.tvSaUsedPercentValue.text = "$usedPercent%"
                binding.tvSaStorageUsedSizeValue.text = formatSize(stat.usedSize) + " Used"
                binding.tvSaStorageTotalSizeValue.text = formatSize(stat.totalSize - stat.usedSize) + " Available"
            }

            result?.file?.let { file ->
                binding.tvSrImageSize.text = formatSize(file.image.queueSize.get())
                binding.tvSrVideoSize.text = formatSize(file.video.queueSize.get())
                binding.tvSrAudioSize.text = formatSize(file.audio.queueSize.get())
                binding.tvSrDocumentSize.text = formatSize(file.document.queueSize.get())
                binding.tvSrApkFileSize.text = formatSize(file.apkFile.queueSize.get())
                binding.tvSrCompressedFileSize.text = formatSize(file.compressedFile.queueSize.get())
                binding.tvSrEmptyDirSize.text = formatCount(file.emptyDir.fileQueue.size)
                binding.tvSrNoExtFileSize.text = formatSize(file.noExt.queueSize.get())
                binding.tvSrUnknownExtFileSize.text = formatSize(file.unknownExt.queueSize.get())
            }

            binding.tvSrOtherSize.text = formatSize(result.other)
//            binding.tvSaScanCost.text = getString(R.string.scan_cost, result.file?.scanCost ?: 0)
            binding.tvSaScanCost.text =
                activity!!.getString(R.string.scan_cost, result.file?.scanCost?.toString() ?: "0")

            val listTests = vm.sabData.value?.map { it.first } ?: emptyList()
            val colorsTest = vm.sabData.value?.map { it.second } ?: emptyList()

            binding.sabMain.setColor(colorsTest)
            binding.sabMain.setData(listTests)

//            binding.sabMain.dataAndColorArray=vm.sabData.value
//            binding.sabMain.invalidate()
        }

        vm.sabData.observe(activity!!) {
            val listTests = it?.map { it.first } ?: emptyList()
            val colorsTest = it?.map { it.second } ?: emptyList()
            binding.sabMain.setColor(colorsTest)
            binding.sabMain.setData(listTests)

//            binding.sabMain.dataAndColorArray=it
//            binding.sabMain.invalidate()
        }
    }

    private fun setupClickListeners() {
        binding.llSrImageSizeContainer.setOnClickListener {

        }
        binding.llSrVideoSizeContainer.setOnClickListener {

        }
        binding.llSrAudioSizeContainer.setOnClickListener {

        }
        binding.llSrDocumentSizeContainer.setOnClickListener {

        }
        binding.llSrApkFileSizeContainer.setOnClickListener {

        }
        binding.llSrCompressedFileSizeContainer.setOnClickListener {

        }
        binding.llSrEmptyDirSizeContainer.setOnClickListener {

        }
        binding.llSrNoExtFileSizeContainer.setOnClickListener {

        }
        binding.llSrUnknownExtFileSizeContainer.setOnClickListener {

        }
        binding.llSrOtherSizeContainer.setOnClickListener {

        }
    }


    private fun formatSize(bytes: Long?): String {
        val size = bytes ?: return "0 B"
        if (size <= 0) return "0 B"

        val units = arrayOf("B", "kB", "MB", "GB", "TB")

        val digitGroups = (Math.log10(size.toDouble()) / Math.log10(1024.0)).toInt()
            .coerceIn(0, units.size - 1)

        val value = size / Math.pow(1024.0, digitGroups.toDouble())

        return "${DecimalFormat("#,##0.#").format(value)} ${units[digitGroups]}"
    }


    private fun formatCount(count: Int?): String {
        return count?.toString() ?: "0"
    }

//    override fun searchQueryChanged(text: String) {
//
//    }

//    override fun deleteFiles(files: ArrayList<FileDirItem>) {
//        //("Not yet implemented")
//    }
//
//    override fun selectedPaths(paths: ArrayList<String>) {
//        //("Not yet implemented")
//    }
//
//    override fun setupDateTimeFormat() {
//        //("Not yet implemented")
//    }
//
//    override fun toggleFilenameVisibility() {
//        //("Not yet implemented")
//    }
//
//    override fun columnCountChanged() {
//        ("Not yet implemented")
//    }
//
//    override fun finishActMode() {
//        //("Not yet implemented")
//    }

}