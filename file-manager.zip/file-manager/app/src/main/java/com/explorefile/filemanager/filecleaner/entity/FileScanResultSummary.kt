package com.explorefile.filemanager.filecleaner.entity

import com.explorefile.filemanager.filecleaner.entity.FileScanResult
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicInteger

data class FileScanResultSummary(
    val image: FileScanResult = FileScanResult(),
    val video: FileScanResult = FileScanResult(),
    val audio: FileScanResult = FileScanResult(),
    val document: FileScanResult = FileScanResult(),
    val apkFile: FileScanResult = FileScanResult(),
    val compressedFile: FileScanResult = FileScanResult(),
    val emptyDir: FileScanResult = FileScanResult(),
    val noExt: FileScanResult = FileScanResult(),
    val unknownExt: FileScanResult = FileScanResult(),
    var scanCost: Int = 0,

    val scanTaskNum: AtomicInteger = AtomicInteger(),
    val countDownLatch: CountDownLatch = CountDownLatch(1),
)
