package messages.text.sms.feature.main

import android.app.Activity
import android.content.Intent
import messages.text.sms.feature.main.ui.ContactMultiPickerActivity
import messages.text.sms.feature.main.ui.ContactPickerActivity

object ContactPicker {

    fun open(context: Activity, code: Int, from: String) {
        val intent = Intent(context, ContactPickerActivity::class.java)
        intent.putExtra("from", from)
        context.startActivityForResult(intent, code)
    }
    fun openMultiPick(context: Activity, code: Int, from: String) {
        val intent = Intent(context, ContactMultiPickerActivity::class.java)
        intent.putExtra("from", from)
        context.startActivityForResult(intent, code)
    }

    //    public fun open(context: Activity) {
//        open(context, ContactPickerActivity.RC_CONTACT_PICKER)
//    }
    fun open(context: Activity, from: String) {
        open(context, ContactPickerActivity.RC_CONTACT_PICKER, from)
    }
    fun openMultiPick(context: Activity, from: String) {
        openMultiPick(context, ContactMultiPickerActivity.RC_CONTACT_PICKER, from)
    }

}