package messages.text.sms.model

import android.telephony.PhoneNumberUtils
import io.realm.RealmList
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey

open class Contact(
    @PrimaryKey var lookupKey: String = "",
    var numbers: RealmList<PhoneNumber> = RealmList(),
    var name: String = "",
    var photoUri: String? = null,
    var starred: Boolean = false,
    var lastUpdate: Long = 0,
) : RealmObject() {
    fun getDefaultNumber(): PhoneNumber? = numbers.find { number -> number.isDefault }
    fun getCommaAddress(): String = numbers.map { PhoneNumberUtils.stripSeparators(it.address) }.joinToString { "," }
}

open class ContactData(
    var lookupKey: String = "",
    var numbers: ArrayList<PhoneNumber> = ArrayList(),
    var name: String = "",
    var photoUri: String? = null,
    var starred: Boolean = false,
    var lastUpdate: Long = 0,
    var contact: Contact? = null,
) {
    fun getDefaultNumber(): PhoneNumber? = numbers.find { number -> number.isDefault }
    fun getContacts() = listOf(this)
}

sealed class ContactDataItem {
    abstract fun getContacts(): List<ContactData>
    data class New(val value: ContactData) : ContactDataItem() {
        override fun getContacts(): List<ContactData> {
            return listOf(value)
        }
    }

    data class Header(val value: String) : ContactDataItem() {
        override fun getContacts(): List<ContactData> {
            return emptyList()
        }
    }

    data class Person(val value: ContactData) : ContactDataItem() {
        override fun getContacts(): List<ContactData> {
            return listOf(value)
        }
    }
}


