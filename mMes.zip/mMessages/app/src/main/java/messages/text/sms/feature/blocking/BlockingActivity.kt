package messages.text.sms.feature.blocking

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.telephony.PhoneNumberUtils.normalizeNumber
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import dagger.android.AndroidInjection
import io.realm.Realm
import messages.text.sms.R
import messages.text.sms.ads.app_block_activity_open
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.common.util.extensions.setVisible
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.config
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.commons.helpers.ReConstant
import messages.text.sms.databinding.BackupContainerActivityBinding
import messages.text.sms.feature.main.BlockedMessageListActivity
import messages.text.sms.feature.main.ContactPicker
import messages.text.sms.feature.main.ConversationsPickerActivity
import messages.text.sms.feature.main.models.Contact
import messages.text.sms.feature.main.ui.ContactMultiPickerActivity
import messages.text.sms.model.BLOCKED_COUNT
import messages.text.sms.model.ContactData
import messages.text.sms.model.Conversation
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.PICKED_CONTACT
import messages.text.sms.model.PICKED_CONVERSION
import messages.text.sms.password.AddContactDialog
import messages.text.sms.password.AddPhoneNumberDialog
import messages.text.sms.password.DialogCallback
import messages.text.sms.repository.ConversationRepository
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import javax.inject.Inject

class BlockingActivity : MainBaseThemedActivity() {


    private val binding by viewBinding(BackupContainerActivityBinding::inflate)


    @Inject
    lateinit var contactsRepo: messages.text.sms.repository.ContactRepository

    val contactDataList: List<ContactData> by lazy { contactsRepo.getContactsList() }

    @Inject
    lateinit var conversationRepository: ConversationRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this)


        setTitle(R.string.spam_and_blocking)

        setActionBarSetup()

        setClickLisner()

        firebaseAnalyticsHandler.logMessages(
            app_block_activity_open, getActivityName()
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this)
        }
    }

    private fun setActionBarSetup() {
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)
    }

    private fun updateDetails() {

        try {
            val savedKeywordsListSize = config.keywordList.size

            val savedContactsListSize: List<Contact> = baseConfig.blockContactsList

            if (savedKeywordsListSize > 0) {
                binding.badgeKeywords.text = savedKeywordsListSize.toString()
                binding.badgeKeywords.setVisible(true)
            } else {
                binding.badgeKeywords.setVisible(false)
            }

            if (savedContactsListSize.size > 0) {
                binding.badgeNumbers.text = savedContactsListSize.size.toString()
                binding.badgeNumbers.setVisible(true)
            } else {
                binding.badgeNumbers.setVisible(false)
            }


            if (conversationRepository.getBlockedListCount() > 0) {
                binding.badgeMessageBlocked.text =
                    conversationRepository.getBlockedListCount().toString()

                binding.badgeMessageBlocked.setVisible(true)
            } else {
                binding.badgeMessageBlocked.setVisible(false)
            }


            var count = baseConfig.blockedMessageCount

            binding.messageCount.text = count.toString() + " " + getString(R.string.messages)
        } catch (e: Exception) {
        }


        setUpTheme()
    }

    private fun setClickLisner() {


        binding.addBlackList.setOnClickListener {

            AddContactDialog(
                this,
                getString(R.string.add_blacklist_contacts),
                object : DialogCallback {
                    override fun onItemClick(position: Int) {
                        when (position) {
                            1 -> {
                                startActivity(
                                    Intent(
                                        this@BlockingActivity,
                                        ConversationsPickerActivity::class.java
                                    ).putExtra("from", "block")
                                )

                            }

                            2 -> {

                                ContactPicker.openMultiPick(this@BlockingActivity, "block")
                            }


                            3 -> {
                                Log.d("AddNumber", "Opening AddPhoneNumberDialog")
                                val addPhoneNumberDialog = AddPhoneNumberDialog(
                                    config,
                                    this@BlockingActivity,
                                    object : AddPhoneNumberDialog.AddPhoneNumberListener {
                                        override fun addNumber(result: String) {
                                            Log.d("AddNumber", "User entered number: $result")

                                            val inputNumber =
                                                result.trim().replace("[^0-9]".toRegex(), "")
                                                    .takeLast(9)
                                            Log.d(
                                                "AddNumber",
                                                "Normalized input number: $inputNumber"
                                            )

                                            val existing = baseConfig.blockContactsList.any {
                                                val contactIdentifier = it.phone
                                                    ?.replace("[^0-9]".toRegex(), "")
                                                    ?.takeLast(9)
                                                contactIdentifier == inputNumber
                                            }

                                            val existingIndex = contactDataList.indexOfFirst {
                                                it.numbers.getOrNull(0)?.address
                                                    ?.replace("[^0-9]".toRegex(), "")
                                                    ?.takeLast(9) == inputNumber
                                            }

                                            Log.d(
                                                "AddNumber",
                                                "Is number already blocked: $existing"
                                            )

                                            if (!existing) {
                                                var newContact: Contact

                                                if (existingIndex != -1) {
                                                    val matchedContact =
                                                        contactDataList[existingIndex]
                                                    val contactName =
                                                        matchedContact.name
                                                    val contactPhone =
                                                        matchedContact.numbers.getOrNull(0)?.address
                                                            ?: result.trim()

                                                    newContact = Contact(contactName, contactPhone)

                                                    // Use contactName and contactPhone to create new contact or whatever you want
                                                } else {
                                                    newContact =
                                                        Contact(result.trim(), result.trim())
                                                }


                                                val savedData = baseConfig.blockContactsList

                                                if (!savedData.contains(newContact)) {

                                                    savedData.add(newContact)
                                                }

                                                baseConfig.blockContactsList = savedData


                                                setBlock(result.trim())
                                            } else {
                                                Log.d("AddNumber", "Contact is already blocked")
                                                Toast.makeText(
                                                    this@BlockingActivity,
                                                    "Already Blocked",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            }
                                        }
                                    }
                                )

                                addPhoneNumberDialog.show()
                                Log.d("AddNumber", "AddPhoneNumberDialog displayed")
                            }


                        }
                    }
                })
        }



        binding.keywordsRow.setOnClickListener {
            val intent = Intent(it.context, MainBlockActivity::class.java)
            intent.putExtra("selected_tab", 0) // 0 = Keywords
            startActivity(intent)
        }

        binding.numbersRow.setOnClickListener {
            val intent = Intent(it.context, MainBlockActivity::class.java)
            intent.putExtra("selected_tab", 1) // 1 = Contact
            startActivity(intent)
        }

        binding.messageBlockedRow.setOnClickListener {
            val intent = Intent(it.context, BlockedMessageListActivity::class.java)
            startActivity(intent)
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.type) {
            BLOCKED_COUNT -> {

                try {
                    val result = event.data as Int
                    binding.messageCount.text =
                        result.toString() + " " + getString(R.string.messages)
                } catch (e: Exception) {
                }
            }

            PICKED_CONTACT -> {

                val result = event.data as List<Contact>

                onResume()

            }

            PICKED_CONVERSION -> {

                val result = event.data as ArrayList<Contact>


                onResume()
            }
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == ContactMultiPickerActivity.RC_CONTACT_PICKER) {


            val result =
                data?.getParcelableExtra<Contact>(ContactMultiPickerActivity.EXTRA_CONTACT_DATA)
            Log.d("Picker", result?.name + " " + result?.phone)


//            if (result != null) {
//                baseConfig.blockContactsList.add(result)
//            }

            /*     val savedData = baseConfig.blockContactsList

                 if (!savedData.contains(result)) {

                     savedData.add(result!!)
                 }

                 baseConfig.blockContactsList = savedData

                 if (result?.name?.isEmpty() == true) {
                     result.phone?.let { setBlock(it) }
                 } else {
                     result?.name?.let { setBlock(it) }
                 }
                 onResume()*/
        }
    }


    /*  fun setBlock(phoneNumber: String) {
          Realm.getDefaultInstance().use { realm ->
              realm.executeTransaction {
                  val conversations = realm.where(Conversation::class.java)
                      .findAll()

                  conversations.filter {
                      it.getTitle().replace(" ", "").endsWith(phoneNumber.trim().replace(" ", ""))
                  }.forEach {
                          it.isPrivate = false
                          it.blocked = true
                      }
              }
          }
      }*/


    /*  fun setBlock(phoneNumber: String) {
          val inputNumber = phoneNumber.trim().replace(" ", "")
          Log.d("BlockCheck", "Input number: $inputNumber")

          Realm.getDefaultInstance().use { realm ->
              realm.executeTransaction {
                  val conversations = realm.where(Conversation::class.java)
                      .findAll()

                  conversations.filter {
  //                    val title = it.getTitle().replace(" ", "")
                      val title = it.recipients.get(0)?.contact
                      val normalizedTitle = title?.numbers?.get(0)?.address
                      val isMatch = normalizedTitle?.endsWith(inputNumber, ignoreCase = true)

                      Log.d(
                          "BlockCheck",
                          "Checking: Title='$title' | Normalized='$normalizedTitle' | Match=$isMatch"
                      )

                      isMatch == true
                  }.forEach {
                      it.isPrivate = false
                      it.archived = false
                      it.blocked = true
                      it.blockingClient = 0
                      it.blockReason = ""
                      Log.d("BlockCheck", "Blocked: ${it.getTitle()}")
                  }
              }

              realm.close()
          }
      }*/

    fun setBlock(phoneNumber: String) {
        val inputNumber = normalizeNumber(phoneNumber)
        val thredId = ReConstant.getThreadId(this, phoneNumber)

        updateConversationByThreadId(thredId, true)
        /*  Realm.getDefaultInstance().use { realm ->
              realm.executeTransaction {
                  val conversations = realm.where(Conversation::class.java)
                      .findAll()

                  conversations.filter { it.recipients.size == 1 }.filter {
                      val title = it.recipients.getOrNull(0)?.contact
                      val normalizedTitle =
                          title?.numbers?.getOrNull(0)?.address?.let { normalizePhoneNumber(it) }
                              ?: ""

                      val isMatch = normalizedTitle == inputNumber


                      isMatch
                  }.forEach {
                      it.isPrivate = false
                      it.archived = false
                      it.blocked = value
                      it.blockingClient = if (!value) null else 0
                      it.blockReason = if (!value) null else ""

                  }
              }

              realm.close()
          }*/
    }

    fun updateConversationByThreadId(threadID: Long, value: Boolean) {
        Realm.getDefaultInstance().use { realm ->
            realm.executeTransaction {
                val conversation = realm.where(Conversation::class.java)
                    .equalTo("id", threadID)
                    .findFirst()

                conversation?.apply {
                    isPrivate = false
                    archived = false
                    blocked = value
                    blockingClient = if (!value) null else 0
                    blockReason = if (!value) null else ""
                }
            }


            realm.close()
        }
    }

    private fun setUpTheme() {

        updateTextColors(binding.contentView)
        //  binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }


        val tintedDrawable = ContextCompat.getDrawable(this, R.drawable.round_button)?.apply {
            setTint(baseConfig.primaryColor)
        }
        val tintedDrawabled = ContextCompat.getDrawable(this, R.drawable.round_button)?.apply {
            setTint(baseConfig.primaryColor)
        }




        listOf(
            binding.badgeKeywords,
            binding.badgeMessageBlocked,
            binding.badgeNumbers
        ).forEach { it.background = tintedDrawable }




        binding.addBlackList.background = tintedDrawabled

        listOfNotNull(
            binding.iconKeywords,
            binding.iconNumbers,
            binding.iconMessageBlocked
        ).forEach { it.setTint(baseConfig.primaryColor) }

    }

    override fun onResume() {
        super.onResume()
        updateDetails()
    }


}