package messages.text.sms.feature.blocking

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.f2prateek.rx.preferences2.RxSharedPreferences
import io.realm.Realm
import messages.text.sms.R
import messages.text.sms.blocking.BlockingClient
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.config
import messages.text.sms.commons.helpers.ReConstant
import messages.text.sms.databinding.DialogRemoveKeywordBinding
import messages.text.sms.databinding.FragmentContactBinding
import messages.text.sms.feature.main.ContactPicker
import messages.text.sms.feature.main.ConversationsPickerActivity
import messages.text.sms.feature.main.models.Contact
import messages.text.sms.model.ContactData
import messages.text.sms.model.Conversation
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.PICKED_CONTACT
import messages.text.sms.model.PICKED_CONVERSION
import messages.text.sms.password.AddContactDialog
import messages.text.sms.password.AddPhoneNumberDialog
import messages.text.sms.password.DialogCallback
import messages.text.sms.repository.ContactRepository
import messages.text.sms.repository.ContactRepositoryImpl
import messages.text.sms.util.Preferences
import messages.text.sms.util.StringManager
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import javax.inject.Inject


class ContactFragment : Fragment() {

    private var binding: FragmentContactBinding? = null
    private lateinit var adapter: NumberAdapter
    private var isMultiSelectMode = false
    var blockedContactsList: ArrayList<Contact> = arrayListOf()
    var resumePic = false

    @Inject
    lateinit var blockingManager: BlockingClient
    lateinit var contactsRepo: ContactRepository

    val contactDataList: List<ContactData>
        get() = contactsRepo.getContactsList()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentContactBinding.inflate(inflater, container, false)

        blockedContactsList = requireActivity().baseConfig.blockContactsList

        val shPrefs = PreferenceManager.getDefaultSharedPreferences(requireActivity())
        val rxPrefs = RxSharedPreferences.create(shPrefs)
        contactsRepo = ContactRepositoryImpl(
            requireActivity(),
            Preferences(requireActivity(), rxPrefs, shPrefs)
        )

        setupRecyclerView()

        binding?.fabAddKeywords?.setOnClickListener {
            showDialogforSelect()
        }
        binding!!.btnAddNumbers.setOnClickListener {

            showDialogforSelect()
        }

        val drawable = ContextCompat.getDrawable(requireContext(), R.drawable.round_button)
        drawable?.setTint(requireActivity().baseConfig.primaryColor)
        binding?.btnUnblockAll?.background = drawable

        binding?.btnUnblockAll?.setOnClickListener {

            showCustomKeywordDialog(requireContext(), getString(R.string.unblock_selected)) {

                val selected = adapter.getSelectedContacts()
                selected.forEach { contact ->
                    setBlock(contact.phone ?: "", false)
                    blockedContactsList.remove(contact)
                }
                blockedContactsList = blockedContactsList

                requireActivity().baseConfig.blockContactsList = blockedContactsList
                enableMultiSelectMode(false)
                adapter.notifyDataSetChanged()
                updateVisibility()
            }


        }


        val colorInt = requireActivity().baseConfig.primaryColor
        binding!!.fabAddKeywords.backgroundTintList = ColorStateList.valueOf(colorInt)

        setUpTheme()
        return binding!!.root
    }


    private var isAllSelected = false
    private var selectAllMenuItem: MenuItem? = null


    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.blocked_menu, menu)
        selectAllMenuItem = menu.findItem(R.id.action_select_all)
        val iconDrawable =
            ContextCompat.getDrawable(requireContext(), R.drawable.ic_select_all)

        iconDrawable?.setTint(
            if (isAllSelected) requireContext().baseConfig.primaryColor else requireContext().resources.getColor(
                R.color.gray
            )
        )
        selectAllMenuItem?.setIcon(iconDrawable)


        selectAllMenuItem?.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS) // Show always
        selectAllMenuItem?.setVisible(false)
        updateSelectAllMenuIcon() // Set the correct icon initially
        super.onCreateOptionsMenu(menu, inflater)
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_select_all -> {
                if (!::adapter.isInitialized) return true

                isAllSelected = !isAllSelected
                adapter.selectedAllContacts(isAllSelected)
                updateSelectAllMenuIcon()

                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun updateSelectAllMenuIcon() {
        val drawableRes = if (isAllSelected) R.drawable.ic_select_all else R.drawable.ic_select_all
        val drawable = ContextCompat.getDrawable(requireContext(), drawableRes)?.mutate()
        drawable?.setTint(
            if (isAllSelected) requireContext().baseConfig.primaryColor else requireContext().resources.getColor(
                R.color.gray
            )
        )
        selectAllMenuItem?.icon = drawable

        //    selectAllMenuItem?.title = if (isAllSelected) "Unselect All" else "Select All"
    }

    override fun onDestroy() {
        super.onDestroy()
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this)
        }
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setHasOptionsMenu(true)
        super.onViewCreated(view, savedInstanceState)
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.type) {
            PICKED_CONTACT -> {

                val result = event.data as List<Contact>

                val savedData = requireActivity().baseConfig.blockContactsList
                adapter.clearAll()
                for (item in savedData) {
                    setBlock(item.phone ?: item.name + "", true)
                    adapter.addItem(item)
                }
                adapter.notifyDataSetChanged()
                updateVisibility()
            }

            PICKED_CONVERSION -> {

                val result = event.data as ArrayList<Contact>
                for (item in result) {
                    adapter.addItem(item)
                }
                adapter.notifyDataSetChanged()
                updateVisibility()
            }
        }
    }


    private fun setUpTheme() {

//        updateTextColors(binding.main)

        if (requireActivity().baseConfig.useImageResource) {
            if (requireActivity().baseConfig.storedImageResource == -1) {

                if (requireActivity().baseConfig.storedImageResource == 111) {
                    val stringManager = StringManager(requireActivity())
                    val imageBitmap = stringManager.getSavedThemeBitmaps().last()
                    val drawable = BitmapDrawable(resources, imageBitmap)
                    binding?.main?.background = drawable
//                    findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(resources.getColor(R.color.transperent))
                } else {
                    val drawable = ContextCompat.getDrawable(
                        requireActivity(),
                        requireActivity().baseConfig.storedImageResource
                    )
                    binding?.main?.background = drawable
//                    findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(resources.getColor(R.color.transperent))
                }

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(
                    requireActivity(),
                    requireActivity().baseConfig.storedImageResource
                )
                binding?.main?.background = drawable
//                findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(resources.getColor(R.color.transperent))
//                findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(requireActivity().baseConfig.backgroundColor)
            }


        } else {
            val primaryColor = requireActivity().baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            if (requireActivity().baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
                binding?.main?.background =
                    ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
            } else {
                binding?.main?.background =
                    ColorDrawable(requireActivity().baseConfig.backgroundColor)
            }
        }
    }

    fun setBlock(phoneNumber: String, value: Boolean) {
        val threadId = ReConstant.getThreadId(requireActivity(), phoneNumber)
        updateConversationByThreadId(threadId, value)
    }

    fun updateConversationByThreadId(threadID: Long, value: Boolean) {
        Realm.getDefaultInstance().use { realm ->
            realm.executeTransaction {
                val conversation = realm.where(Conversation::class.java)
                    .equalTo("id", threadID)
                    .findFirst()
                conversation?.apply {
                    isPrivate = false
                    archived = false
                    blocked = value
                    blockingClient = if (!value) null else 0
                    blockReason = if (!value) null else ""
                }
            }
        }
    }

    private fun showDialogforSelect() {
        AddContactDialog(
            requireActivity(),
            getString(R.string.add_blacklist_contacts),
            object : DialogCallback {
                override fun onItemClick(position: Int) {
                    when (position) {
                        1 -> {
                            resumePic = true
                            startActivity(
                                Intent(
                                    requireActivity(),
                                    ConversationsPickerActivity::class.java
                                ).putExtra("from", "block")
                            )

                        }

                        2 -> {
                            resumePic = true
                            ContactPicker.openMultiPick(requireActivity(), "block")
                        }

                        3 -> {
                            val addPhoneNumberDialog = AddPhoneNumberDialog(
                                requireActivity().config,
                                requireActivity(),
                                object : AddPhoneNumberDialog.AddPhoneNumberListener {
                                    override fun addNumber(result: String) {

                                        val inputNumber =
                                            result.trim().replace("[^0-9]".toRegex(), "")
                                                .takeLast(9)

                                        val existing =
                                            requireActivity().baseConfig.blockContactsList.any {
                                                val contactIdentifier = it.phone
                                                    ?.replace("[^0-9]".toRegex(), "")
                                                    ?.takeLast(9)
                                                contactIdentifier == inputNumber
                                            }

                                        val existingIndex = contactDataList.indexOfFirst {
                                            it.numbers.getOrNull(0)?.address
                                                ?.replace("[^0-9]".toRegex(), "")
                                                ?.takeLast(9) == inputNumber
                                        }

                                        if (!existing) {
                                            var newContact: Contact

                                            if (existingIndex != -1) {
                                                val matchedContact = contactDataList[existingIndex]
                                                val contactName =
                                                    matchedContact.name
                                                val contactPhone =
                                                    matchedContact.numbers.getOrNull(0)?.address
                                                        ?: result.trim()

                                                newContact = Contact(contactName, contactPhone)

                                                // Use contactName and contactPhone to create new contact or whatever you want
                                            } else {
                                                newContact = Contact(result.trim(), result.trim())
                                            }

                                            val savedData =
                                                requireActivity().baseConfig.blockContactsList

                                            if (!savedData.contains(newContact)) {

                                                savedData.add(newContact)
                                            }

                                            requireActivity().baseConfig.blockContactsList =
                                                savedData

                                            setBlock(result.trim(), true)
                                            adapter.addItem(newContact)
                                            adapter.notifyDataSetChanged()
                                            updateVisibility()


                                        } else {
                                            Toast.makeText(
                                                requireActivity(),
                                                "Already Blocked",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }
                                }
                            )

                            addPhoneNumberDialog.show()
                            Log.d("AddNumber", "AddPhoneNumberDialog displayed")
                        }


                    }
                }
            })
    }

    private fun setupRecyclerView() {
        adapter = NumberAdapter(blockedContactsList, { position ->
            if (!isMultiSelectMode) {
                blockedContactsList.getOrNull(position)?.name?.let {
                    showCustomKeywordDialog(requireContext(), it) {
                        onDeleteData(position)
                    }
                }
            }
        }, {

            enableMultiSelectMode(true)

        }, { count ->


            selectAllMenuItem?.setVisible(if (count > 0) true else false)


            val drawableRes =
                if (blockedContactsList.size == count) R.drawable.ic_select_all else R.drawable.ic_select_all
            val drawable = ContextCompat.getDrawable(requireContext(), drawableRes)?.mutate()
            drawable?.setTint(
                if (isAllSelected) requireContext().baseConfig.primaryColor else requireContext().resources.getColor(
                    R.color.gray
                )
            )
            selectAllMenuItem?.icon = drawable

            isAllSelected = if (blockedContactsList.size == count) true else false

        })

        adapter.multiSelectEmptyListener = {
            enableMultiSelectMode(false)
        }

        binding?.recyclerView?.layoutManager = LinearLayoutManager(requireContext())
        binding?.recyclerView?.adapter = adapter
        updateVisibility()
    }

    private fun enableMultiSelectMode(enable: Boolean) {
        isMultiSelectMode = enable
        adapter.setMultiSelectMode(enable)
        binding?.fabAddKeywords?.visibility = if (enable) View.GONE else View.VISIBLE
        binding?.btnUnblockAll?.visibility = if (enable) View.VISIBLE else View.GONE
        selectAllMenuItem?.setVisible(if (enable) true else false)
    }

    fun showCustomKeywordDialog(context: Context, keyword: String, onDelete: () -> Unit) {
        val dialog = Dialog(context, R.style.QuickReplyDialogStyle)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val binding = DialogRemoveKeywordBinding.inflate(LayoutInflater.from(context))
        dialog.setContentView(binding.root)
        dialog.setCancelable(true)

        binding.tvTitle.text = keyword
        binding.tvMessage.text =
            (context as Activity).getString(R.string.do_you_want_to_unblock_this_contact_from_blacklist)

        binding.btnDelete.setTextColor(context.baseConfig.primaryColor)
        binding.btnCancel.setTextColor(
            ContextCompat.getColor(
                context,
                R.color.transparent
            )
        ) // Replace with appropriate color

        binding.btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        binding.btnDelete.setOnClickListener {
            onDelete()
            dialog.dismiss()
        }
        binding.btnDelete.text = requireActivity().getString(R.string.unblock)


        // Set dialog width and margin in dp
        val params = dialog.window?.attributes
        val marginInDp = 30  // e.g., 16dp margin on left/right
        val marginInPx = (marginInDp * context.resources.displayMetrics.density).toInt()

// Adjust window layout with calculated margins
        params?.width = context.resources.displayMetrics.widthPixels - 2 * marginInPx
        dialog.window?.attributes = params

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }

    private fun onDeleteData(position: Int) {

        val removed = blockedContactsList.getOrNull(position)
        removed?.let {
            setBlock(it.phone ?: "", false)
            blockedContactsList.removeAt(position)
        }
        requireActivity().baseConfig.blockContactsList = blockedContactsList
        adapter.notifyItemRemoved(position)
        updateVisibility()
    }




    private fun updateVisibility() {
        if (adapter.itemCount > 0) {
            binding?.viewData?.visibility = View.VISIBLE
            binding?.noData?.visibility = View.GONE
        } else {
            binding?.viewData?.visibility = View.GONE
            binding?.noData?.visibility = View.VISIBLE
        }
    }

    // (Other methods remain the same like dialog, EventBus, setBlock, etc.)

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }

    override fun onResume() {
        super.onResume()
        if (resumePic) {
            resumePic = false
            setupRecyclerView()
        } else {
            adapter.notifyDataSetChanged()
            updateVisibility()
        }
    }
}


