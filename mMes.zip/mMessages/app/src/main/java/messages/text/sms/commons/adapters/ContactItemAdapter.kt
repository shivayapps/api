package messages.text.sms.commons.adapters

import android.annotation.SuppressLint
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.common.base.MainBaseAdapter
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.common.util.extensions.forwardTouches
import messages.text.sms.commons.extensions.addAlpha
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.databinding.ContactListItemNewBinding
import messages.text.sms.feature.compose.editing.PhoneNumberAdapter
import messages.text.sms.feature.main.MainActivity
import messages.text.sms.model.ContactData
import messages.text.sms.model.PhoneNumber
import messages.text.sms.model.RecipientData

class ContactItemAdapter : MainBaseAdapter<ContactData, ContactListItemNewBinding>() {
    private val numbersViewPool = RecyclerView.RecycledViewPool()

    init {
        // This is how we access the threadId for the swipe actions
//        setHasStableIds(true)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<ContactListItemNewBinding> {
        return MainBaseMsgViewHolder(parent, ContactListItemNewBinding::inflate).apply {
            val textColorPrimary = parent.context.baseConfig.textColor
            binding.title.setTextColor(textColorPrimary)
            val colorWithAlpha = textColorPrimary.addAlpha(0.45F)
            binding.subtitle.setTextColor(colorWithAlpha)

            binding.numbers.setRecycledViewPool(numbersViewPool)
            binding.numbers.adapter = PhoneNumberAdapter()
            binding.numbers.forwardTouches(binding.root)

            binding.root.setOnClickListener {
                val item = getItem(adapterPosition)
                (it.context as? MainActivity)?.onContactClick(item)
            }

            binding.root.setOnLongClickListener {
                val item = getItem(adapterPosition)
                (it.context as? MainActivity)?.onContactLongClick(item)
                true
            }


        }
    }

    @SuppressLint("SuspiciousIndentation")
    override fun onBindViewHolder(
        holder: MainBaseMsgViewHolder<ContactListItemNewBinding>,
        position: Int,
    ) {

        val contact = getItem(position) ?: return
        var numbersList = ArrayList<PhoneNumber>()
            try {
                numbersList = ArrayList(contact.numbers)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            holder.binding.avatars.recipientData = listOf(
                RecipientData(
                    address = numbersList.firstOrNull()?.address ?: "",
                    contact = contact
                )
            )
            try {
                holder.binding.title.text = contact.name
            } catch (e: Exception) {
                e.printStackTrace()
            }
            holder.binding.subtitle.isVisible = false
            holder.binding.numbers.isVisible = true
            (holder.binding.numbers.adapter as PhoneNumberAdapter).data = numbersList


    }

    override fun getItemCount(): Int {
        return super.getItemCount()
    }
    override fun areContentsTheSame(old: ContactData, new: ContactData): Boolean {
        return old.name == new.name && old.numbers == new.numbers
    }

    override fun areItemsTheSame(old: ContactData, new: ContactData): Boolean {
        return old.name == new.name && old.numbers == new.numbers
    }

}
