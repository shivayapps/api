package messages.text.sms.feature.personalize

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.ads.MainInterAdManager
import messages.text.sms.ads.app_bubble_activity_open
import messages.text.sms.ads.app_bubble_style_applied_successfully
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.common.MysmsApplication.Companion.isHomeInterShow
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.extensions.applyColorFilter
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.clientConfigPref
import messages.text.sms.commons.extensions.config
import messages.text.sms.commons.extensions.getBottomNavigationBackgroundColor
import messages.text.sms.commons.extensions.getContrastColor
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.commons.helpers.BUBBLE_STYLE_ORIGINAL
import messages.text.sms.commons.helpers.BubbleStyleType
import messages.text.sms.databinding.ActivityBubbleBinding
import messages.text.sms.util.StringManager

class BubbleActivity : MainBaseThemedActivity() {

    var title: String = ""
    var color = 0
    private val PRIMARY_COLORS_COUNT = 19
    private val DEFAULT_PRIMARY_COLOR_INDEX = 14
    private val DEFAULT_SECONDARY_COLOR_INDEX = 6

    //    private var backgroundColorOne: Int = Color.parseColor("#E7F0FB")
//    private var backgroundColorTwo: Int = Color.parseColor("#569BF5")
//    private var backgroundTextColorOne: Int = Color.parseColor("#000000")
//    private var backgroundTextColorTwo: Int = Color.parseColor("#FFFFFF")
    private var backgroundColorOne: Int = Color.parseColor("#E7F0FB")
    private var backgroundColorTwo: Int = Color.parseColor("#E6F3FF")
    private var backgroundTextColorOne: Int = Color.parseColor("#000000")
    private var backgroundTextColorTwo: Int = Color.parseColor("#FFFFFF")

    private var TempBackgroundColorOne: Int = Color.parseColor("#E7F0FB")
    private var TempBackgroundColorTwo: Int = Color.parseColor("#569BF5")
    private var TempBackgroundTextColorOne: Int = Color.parseColor("#000000")
    private var TempBackgroundTextColorTwo: Int = Color.parseColor("#FFFFFF")

    private var stokeTwo: Int = Color.parseColor("#ECEDEF")
    private var savedPosition: Int = 0

    private var backgroundstyle: Int = 0
    private var backgroundStyleType: BubbleStyleType = BubbleStyleType.AUTO


    private val binding by viewBinding(ActivityBubbleBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        showBackButton(true)
        setTitle(R.string.bubble)



        TempBackgroundColorOne = Color.parseColor("#E7F0FB")
        TempBackgroundColorTwo = Color.parseColor("#569BF5")
        TempBackgroundTextColorOne = Color.parseColor("#000000")
        TempBackgroundTextColorTwo = Color.parseColor("#FFFFFF")

        savedPosition = config.getSavedIntData("savedPosition")


        val background = ResourcesCompat.getDrawable(
            resources,
            R.drawable.message_simple_out_last,
            null
        )

        binding.tvone.background = background
        binding.tvone.background.applyColorFilter(TempBackgroundColorOne)

        binding.tvtwo.setTextColor(TempBackgroundTextColorTwo)
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        setUI()
        setUpTheme()
        setUpListener()

        binding.btnApply.setTextColor(Color.parseColor("#FFFFFF"))

        firebaseAnalyticsHandler.logMessages(
            app_bubble_activity_open, getActivityName()
        )


        setUpThemeList()

    }

    private fun setUpThemeList() {

        val colorOptions = listOf(
            Triple(
                Color.parseColor("#E6F3FF"),
                Color.parseColor("#C3E3FF"),
                Color.parseColor("#1B4F7D")
            ),
            Triple(
                Color.parseColor("#F0ECFF"),
                Color.parseColor("#D0C1FF"),
                Color.parseColor("#524873")
            ),
            Triple(
                Color.parseColor("#D9FFE3"),
                Color.parseColor("#B2ECC1"),
                Color.parseColor("#3D5B45")
            ),
            Triple(
                Color.parseColor("#FFEDE3"),
                Color.parseColor("#FFD9C3"),
                Color.parseColor("#633419")
            ),
            Triple(
                Color.parseColor("#FFF5DB"),
                Color.parseColor("#FFE2A1"),
                Color.parseColor("#59471F")
            ),
            Triple(
                Color.parseColor("#F6F7F9"),
                Color.parseColor("#ECEDEF"),
                Color.parseColor("#333333")
            )
        )

        setupColorsRight(colorOptions.get(savedPosition))



        val colorAdapter = ColorOptionAdapter(
            colorOptions, savedPosition,
            onItemSelected = { position ->
                savedPosition = position
            },
            onColorSelected = { selectedColor ->
                setupColorsRight(selectedColor)
            }
        )

        binding.recyclerView.apply {
            layoutManager = GridLayoutManager(context, 5) // 3 columns in the grid
            adapter = colorAdapter
        }
//        binding.recyclerView.addItemDecoration(GridSpacingItemDecoration(3, 16)) // 3 columns, 16px spacing


    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")

        updateTextColors(binding.contentView)
        //   binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
//            arrayListOf(binding.ivBack).forEach {
//                val colorStateList = ColorStateList.valueOf(Color.WHITE)
//                it.imageTintList = colorStateList
//            }
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
//            arrayListOf(binding.ivBack).forEach {
//                val colorStateList = ColorStateList.valueOf(Color.BLACK)
//                it.imageTintList = colorStateList
//            }
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource != -1) {
//                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
//                binding.contentView.background = drawable
//                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))

                if (baseConfig.storedImageResource == 111) {
                    val stringManager = StringManager(this)
                    val imageBitmap = stringManager.getSavedThemeBitmaps().last()
                    val drawable = BitmapDrawable(resources, imageBitmap)
                    binding.contentView.background = drawable
                    toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
                } else {
                    val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                    binding.contentView.background = drawable
                    toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
                }
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }


        arrayOf(
            binding.llbottom,
        ).forEach {
            if (baseConfig.useImageResource == true) {
                if (baseConfig.storedImageResource == -1) {

                } else {
                    try {
                        it.background.applyColorFilter(resources.getColor(R.color.transperent30))
                    } catch (_: Exception) {
                    }
                }
            } else {
                it.background.applyColorFilter(getBottomNavigationBackgroundColor())
            }
        }
    }

    private fun setUI() {


        binding.btnApply.backgroundTintList = ColorStateList.valueOf(baseConfig.primaryColor)


        val drawable = GradientDrawable()
        drawable.shape = GradientDrawable.RECTANGLE
        val colorWithOpacity = baseConfig.primaryColor
//        val colorWith90Opacity = colorWithOpacity?.let { ColorUtils.setAlphaComponent(it, (0.9 * 255).toInt()) }
        val colorWith90Opacity = baseConfig.primaryColor
        drawable.setColor(colorWith90Opacity)

        val cornerRadius = resources?.getDimension(R.dimen.small_icon_size)
        if (cornerRadius != null) {
            drawable.cornerRadius = cornerRadius
        }

        binding.rauto.visibility = View.VISIBLE
    }

    private fun setupColorsRight(primaryColors: Triple<Int, Int, Int>) {


        backgroundstyle = BUBBLE_STYLE_ORIGINAL

//            setupToggleBubbleStyle(BUBBLE_STYLE_ORIGINAL)

        val first = primaryColors.first
        val stoke = primaryColors.second
        val textColor = primaryColors.third
        /*   val drawable = GradientDrawable().apply {
               shape = GradientDrawable.RECTANGLE  // For a circular background
               color = ColorStateList.valueOf(first)  // Set background color
               setStroke(4, stoke)  // Set stroke width and color
               cornerRadius = 16f
           }
   */

        val background = ResourcesCompat.getDrawable(
            resources,
            R.drawable.message_simple_out_last,
            null
        )

        binding.tvtwo.background = background

        binding.tvtwo.background.applyColorFilter(first)
        binding.tvtwo.setTextColor(textColor)


        backgroundStyleType = BubbleStyleType.AUTO
        backgroundColorOne = Color.parseColor("#E7F0FB")
        backgroundColorTwo = first
        backgroundTextColorOne = Color.parseColor("#000000")
        backgroundTextColorTwo = textColor
        stokeTwo = stoke


        TempBackgroundColorOne = backgroundColorOne
        TempBackgroundColorTwo = backgroundColorTwo
        TempBackgroundTextColorOne = backgroundTextColorOne
        TempBackgroundTextColorTwo = backgroundTextColorTwo

        /*  binding.tvone.apply {
              background = ResourcesCompat.getDrawable(
                  resources,
                  R.drawable.item_received_background,
                  null
              )
              val backgroundReceived = backgroundColorOne
              background.applyColorFilter(backgroundReceived)
              setTextColor(backgroundTextColorOne)
          }*/

        /*  binding.tvtwo.apply {
              background = drawable
              setTextColor(textColor)
          }*/



        binding.apply {
            val backgroundReceived = primaryColors.first
            val contrastColorReceived = backgroundReceived.getContrastColor()
            tvtwo.background.applyColorFilter(backgroundReceived)
            tvtwo.setTextColor(contrastColorReceived)
            backgroundTextColorTwo = contrastColorReceived
            backgroundColorTwo = primaryColors.first
        }
    }

    override fun onBackPressed() {

        if (clientConfigPref.enableBackPressInter && !isHomeInterShow) {
            Log.e("Message_Log", "enable_back_press_inter - showMainInterAds")

            MainInterAdManager.showMainInterAds(this) {
                Log.e("Message_Log", "enable_back_press_inter - isHomeInterShow = true")
                isHomeInterShow = true
                finish()
            }

        } else {
            Log.e("Message_Log", "enable_back_press_inter - finish")
            finish()
        }
    }

    private fun setUpListener() {
//        binding.ivBack.setOnClickListener {
//            onBackPressed()
//        }


//        -----------------------------------Start Auto Items Click(1st Tab)------------------------------------

        /* binding.styleOriginalauto.setOnClickListener {
             backgroundstyle = BUBBLE_STYLE_ORIGINAL

 //            setupToggleBubbleStyle(BUBBLE_STYLE_ORIGINAL)

             backgroundStyleType = BubbleStyleType.AUTO
             backgroundColorOne = Color.parseColor("#E7F0FB")
             backgroundColorTwo = Color.parseColor("#569BF5")
             backgroundTextColorOne = Color.parseColor("#000000")
             backgroundTextColorTwo = Color.parseColor("#FFFFFF")


             hideAllFirstTabBubbles()
             binding.styleOriginalCheckauto.visibility = View.VISIBLE
             TempBackgroundColorOne = backgroundColorOne
             TempBackgroundColorTwo = backgroundColorTwo
             TempBackgroundTextColorOne = backgroundTextColorOne
             TempBackgroundTextColorTwo = backgroundTextColorTwo

             binding.tvone.apply {
                 background = ResourcesCompat.getDrawable(
                     resources,
                     R.drawable.item_received_background,
                     null
                 )
                 val backgroundReceived = backgroundColorOne
                 background.applyColorFilter(backgroundReceived)
                 setTextColor(backgroundTextColorOne)
             }

             binding.tvtwo.apply {
                 background =
                     ResourcesCompat.getDrawable(resources, R.drawable.item_sent_background, null)
                 val backgroundReceived = backgroundColorTwo
                 background.applyColorFilter(backgroundReceived)
                 setTextColor(backgroundTextColorTwo)
             }

             hideAllSecondTabBubbles()

             Log.e("ZZZZZZZ", "BubbleStyleType--->>> " + backgroundstyle)
         }
         binding.styleRoundedauto.setOnClickListener {
             backgroundstyle = BUBBLE_STYLE_ROUNDED

             hideAllFirstTabBubbles()
             binding.styleRoundedCheckauto.visibility = View.VISIBLE

             backgroundStyleType = BubbleStyleType.AUTO

             backgroundColorOne = Color.parseColor("#E8E2FF")
             backgroundColorTwo = Color.parseColor("#8A6EFF")
             backgroundTextColorOne = Color.parseColor("#000000")
             backgroundTextColorTwo = Color.parseColor("#FFFFFF")


             TempBackgroundColorOne = backgroundColorOne
             TempBackgroundColorTwo = backgroundColorTwo
             TempBackgroundTextColorOne = backgroundTextColorOne
             TempBackgroundTextColorTwo = backgroundTextColorTwo

             binding.tvone.apply {
                 background = ResourcesCompat.getDrawable(
                     resources,
                     R.drawable.item_received_rounded_background,
                     null
                 )
                 val backgroundReceived = backgroundColorOne
                 background.applyColorFilter(backgroundReceived)
                 setTextColor(backgroundTextColorOne)
             }

             binding.tvtwo.apply {
                 background = ResourcesCompat.getDrawable(
                     resources,
                     R.drawable.item_sent_rounded_background,
                     null
                 )
                 val backgroundReceived = backgroundColorTwo
                 background.applyColorFilter(backgroundReceived)
                 setTextColor(backgroundTextColorTwo)
             }

             hideAllSecondTabBubbles()

             Log.e("ZZZZZZZ", "BubbleStyleType--->>> " + backgroundstyle)
         }
         binding.styleIosNewauto.setOnClickListener {
             backgroundstyle = BUBBLE_STYLE_IOS_NEW
 //            setupToggleBubbleStyle(BUBBLE_STYLE_IOS_NEW)

             backgroundStyleType = BubbleStyleType.AUTO

             backgroundColorOne = Color.parseColor("#E0FFF1")
             backgroundColorTwo = Color.parseColor("#4BD695")
             backgroundTextColorOne = Color.parseColor("#000000")
             backgroundTextColorTwo = Color.parseColor("#FFFFFF")

             TempBackgroundColorOne = backgroundColorOne
             TempBackgroundColorTwo = backgroundColorTwo
             TempBackgroundTextColorOne = backgroundTextColorOne
             TempBackgroundTextColorTwo = backgroundTextColorTwo


             hideAllFirstTabBubbles()
             binding.styleIosNewCheckauto.visibility = View.VISIBLE

             binding.tvone.apply {
                 background = ResourcesCompat.getDrawable(
                     resources,
                     R.drawable.item_received_ios_new_background,
                     null
                 )
                 val backgroundReceived = backgroundColorOne
                 background.applyColorFilter(backgroundReceived)
                 setTextColor(backgroundTextColorOne)
             }

             binding.tvtwo.apply {
                 background = ResourcesCompat.getDrawable(
                     resources,
                     R.drawable.item_sent_ios_new_background,
                     null
                 )
                 val backgroundReceived = backgroundColorTwo
                 background.applyColorFilter(backgroundReceived)
                 setTextColor(backgroundTextColorTwo)
             }

             hideAllSecondTabBubbles()

             Log.e("ZZZZZZZ", "BubbleStyleType--->>> " + backgroundstyle)
         }
         binding.styleIosauto.setOnClickListener {


             backgroundColorOne = Color.parseColor("#FFF6DF")
             backgroundColorTwo = Color.parseColor("#FFB801")
             backgroundTextColorOne = Color.parseColor("#000000")
             backgroundTextColorTwo = Color.parseColor("#FFFFFF")


             TempBackgroundColorOne = backgroundColorOne
             TempBackgroundColorTwo = backgroundColorTwo
             TempBackgroundTextColorOne = backgroundTextColorOne
             TempBackgroundTextColorTwo = backgroundTextColorTwo

             backgroundstyle = BUBBLE_STYLE_IOS
             backgroundStyleType = BubbleStyleType.AUTO

             hideAllFirstTabBubbles()
             binding.styleIosCheckauto.visibility = View.VISIBLE
 //            setupToggleBubbleStyle(BUBBLE_STYLE_IOS)


             binding.tvone.apply {
                 background = ResourcesCompat.getDrawable(
                     resources,
                     R.drawable.item_received_ios_background,
                     null
                 )
                 val backgroundReceived = backgroundColorOne
                 background.applyColorFilter(backgroundReceived)

                 setTextColor(backgroundTextColorOne)

             }

             binding.tvtwo.apply {
                 background = ResourcesCompat.getDrawable(
                     resources,
                     R.drawable.item_sent_ios_background,
                     null
                 )
                 val backgroundReceived = backgroundColorTwo
                 background.applyColorFilter(backgroundReceived)
                 setTextColor(backgroundTextColorTwo)


             }
             hideAllSecondTabBubbles()

             Log.e("ZZZZZZZ", "BubbleStyleType--->>> " + backgroundstyle)
         }*/

//        -----------------------------------End Auto Items Click(1st Tab)------------------------------------
        binding.btnApply.setOnClickListener {
            setupToggleBubbleStyle()

            firebaseAnalyticsHandler.logMessages(
                app_bubble_style_applied_successfully, getActivityName()
            )
            finish()
        }
    }


    private fun setupToggleBubbleStyle() {

//        Log.e("ZZZZZZZ", "backgroundStyleType--->>> " + backgroundStyleType.toString())
//        Log.e("ZZZZZZZ", "backgroundstyle--->>> " + backgroundstyle.toString())

        prefs.bubbleStyleType.set(backgroundStyleType.toString())
        prefs.bubbleStyle.set(backgroundstyle)
        config.saveData("backgroundColorone", backgroundColorOne)
        config.saveData("backgroundColortwo", backgroundColorTwo)
        config.saveData("backgroundtextColorone", backgroundTextColorOne)
        config.saveData("backgroundtextColortwo", backgroundTextColorTwo)
        config.saveData("stokeTwo", stokeTwo)
        config.saveData("savedPosition", savedPosition)


        config.bubbleStyle = backgroundstyle
        /*
                binding.styleOriginalCheck.isActivated = backgroundstyle == BUBBLE_STYLE_ORIGINAL
                binding.styleRoundedCheck.isActivated = backgroundstyle == BUBBLE_STYLE_ROUNDED
                binding.styleIosNewCheck.isActivated = backgroundstyle == BUBBLE_STYLE_IOS_NEW
                binding.styleIosCheck.isActivated = backgroundstyle == BUBBLE_STYLE_IOS

                binding.styleOriginalCheckauto.isActivated = backgroundstyle == BUBBLE_STYLE_ORIGINAL
                binding.styleRoundedCheckauto.isActivated = backgroundstyle == BUBBLE_STYLE_ROUNDED
                binding.styleIosNewCheckauto.isActivated = backgroundstyle == BUBBLE_STYLE_IOS_NEW
                binding.styleIosCheckauto.isActivated = backgroundstyle == BUBBLE_STYLE_IOS*/
    }

    private fun setupColors(primaryColor: Int) {
        binding.apply {
            val backgroundReceived = primaryColor
            val contrastColorReceived = backgroundReceived.getContrastColor()
            tvone.background.applyColorFilter(backgroundReceived)
            tvone.setTextColor(contrastColorReceived)

            backgroundTextColorOne = contrastColorReceived
            backgroundColorOne = primaryColor
        }
    }

    private fun Context.getColorIndexes(color: Int, defaultColor: Int): Pair<Int, Int> {
        if (color == defaultColor) {
            return getDefaultColorPair()
        }

        for (i in 0 until PRIMARY_COLORS_COUNT) {
            getColorsForIndex(i).indexOfFirst { color == it }.apply {
                if (this != -1) {
                    return Pair(i, this)
                }
            }
        }

        return getDefaultColorPair()
    }

    fun getDefaultColorPair() = Pair(DEFAULT_PRIMARY_COLOR_INDEX, DEFAULT_SECONDARY_COLOR_INDEX)


    private fun Context.getColorsForIndex(index: Int) = when (index) {
        0 -> getColors(R.array.md_reds)
        1 -> getColors(R.array.md_pinks)
        2 -> getColors(R.array.md_purples)
        3 -> getColors(R.array.md_deep_purples)
        4 -> getColors(R.array.md_indigos)
        5 -> getColors(R.array.md_blues)
        6 -> getColors(R.array.md_light_blues)
        7 -> getColors(R.array.md_cyans)
        8 -> getColors(R.array.md_teals)
        9 -> getColors(R.array.md_greens)
        10 -> getColors(R.array.md_light_greens)
        11 -> getColors(R.array.md_limes)
        12 -> getColors(R.array.md_yellows)
        13 -> getColors(R.array.md_ambers)
        14 -> getColors(R.array.md_oranges)
        15 -> getColors(R.array.md_deep_oranges)
        16 -> getColors(R.array.md_browns)
        17 -> getColors(R.array.md_blue_greys)
        18 -> getColors(R.array.md_greys)
        else -> throw RuntimeException("Invalid color id $index")
    }

    private fun Context.getColors(id: Int) = resources.getIntArray(id).toCollection(ArrayList())

    class GridSpacingItemDecoration(private val spanCount: Int, private val spacing: Int) :
        RecyclerView.ItemDecoration() {
        override fun getItemOffsets(
            outRect: Rect,
            view: View,
            parent: RecyclerView,
            state: RecyclerView.State,
        ) {
            val position = parent.getChildAdapterPosition(view) // item position
            val column = position % spanCount // item column

            outRect.left =
                column * spacing / spanCount // spacing - column * ((1f / spanCount) * spacing)
            outRect.right =
                spacing - (column + 1) * spacing / spanCount // (column + 1) * ((1f / spanCount) * spacing)

            if (position >= spanCount) {
                outRect.top = spacing // item top
            }
        }
    }

}