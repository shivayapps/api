package messages.text.sms.feature.blocking.messages

import io.realm.RealmResults
import messages.text.sms.model.Conversation

data class BlockedMessagesState(
    val data: RealmResults<Conversation>? = null,
    val selected: Int = 0,
)
