package messages.text.sms.feature.fragments.contact

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import messages.text.sms.ads.delayExecution
import messages.text.sms.common.util.extensions.scrapViews
import messages.text.sms.commons.adapters.NewContactItemAdapter
import messages.text.sms.databinding.FragmentAllContactBinding
import messages.text.sms.feature.main.MainActivity
import messages.text.sms.model.ContactDataItem
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.THEME_CHANGED
import messages.text.sms.model.UPDATE_ALL_CONTACT
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode


class AllContactFragment : Fragment() {

    var contactsAdapter = NewContactItemAdapter()
    lateinit var binding: FragmentAllContactBinding
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentAllContactBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this)

        if (isAdded) {
            /* activity?.delayExecution(300) {
                 binding.contacts.adapter = contactsAdapter
                 binding.contacts.layoutManager = MyGridLayoutManager(requireActivity())
                 val list = (requireActivity() as? MainActivity)?.contacts ?: ArrayList()
 //            contactsAdapter.data = list
                 contactsAdapter.updateData(list)
             }*/

            activity?.let { act ->
                act.delayExecution(300) {
                    if (isAdded && view != null) {
                        binding.contacts.adapter = contactsAdapter
                        binding.contacts.layoutManager = MyGridLayoutManager(act)
                        val list = (act as? MainActivity)?.contacts ?: ArrayList()
                        contactsAdapter.updateData(list.map { ContactDataItem.Person(it) }) {}
                    }
                }
            }

        }


    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this)
        }
    }


    private val searchHandle = Handler(Looper.getMainLooper())

    /*private val searchRunnable = Runnable {
        binding.contacts.recycledViewPool.clear()
        binding.contacts.post {
            val list = (activity as MainActivity).contacts ?: ArrayList()
            contactsAdapter.updateData(list)
        }
    }*/
    private val searchRunnable = Runnable {
        binding.contacts.recycledViewPool.clear()
        binding.contacts.post {
            val mainActivity = activity as? MainActivity
            if (mainActivity != null) {
                val list = mainActivity.contacts ?: ArrayList()
                contactsAdapter.updateData(list.map { ContactDataItem.Person(it) }) {}
            } else {
                // Log or handle the case where activity is not MainActivity
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.type) {
            UPDATE_ALL_CONTACT -> {
                if (::binding.isInitialized) {
                    searchHandle.removeCallbacks(searchRunnable)
                    searchHandle.postDelayed(searchRunnable, 100)
                }
            }

            THEME_CHANGED -> {
                if (::binding.isInitialized) {
                    binding.contacts.scrapViews()
                }
            }
        }
    }
}
