package messages.text.sms.feature.main

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.databinding.ActivityQuickResponseBinding
import java.util.Collections

class QuickResponseActivity : AppCompatActivity() {

    private lateinit var adapter: QuickResponseAdapter

    private lateinit var mQuickMessagesList: MutableList<String>

    lateinit var binding: ActivityQuickResponseBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = baseConfig.statusBarColor

        binding = ActivityQuickResponseBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mQuickMessagesList = getCallerMessages().toMutableList()

        adapter = QuickResponseAdapter(
            mQuickMessagesList,
            this,
            onClick = { message, isLongPress ->
                handleMessageClick(message, isLongPress)
            },
            onSelect = { isSelected ->
                updateSelectionToolbar(isSelected)
            }
        ) { viewHolder ->
            itemTouchHelper.startDrag(viewHolder)
        }

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        binding.quickMessageAddFab.setOnClickListener {
            showAddMessageDialog()
        }

        binding.mQuickItemDeleteBtn.setOnClickListener {
            adapter.deleteSelectedItems { success ->
                if (mQuickMessagesList.isEmpty()) {
                    binding.noQuickMessagesText.visibility = View.VISIBLE
                } else {
                    adapter.clearSelections()
                    binding.noQuickMessagesText.visibility = View.GONE
                }
                binding.mQuickItemClearBtn.visibility = View.GONE
                binding.mQuickItemDeleteBtn.visibility = View.GONE
                binding.quickMessageAddFab.visibility = View.VISIBLE
                binding.mStartSelectionBtn.visibility = View.VISIBLE
                binding.selectAllButton.visibility = View.GONE
            }
        }


        binding.mQuickItemClearBtn.setOnClickListener {
            adapter.clearSelections()
            binding.mQuickItemClearBtn.visibility = View.GONE
            binding.mQuickItemDeleteBtn.visibility = View.GONE
            binding.quickMessageAddFab.visibility = View.VISIBLE
            binding.mStartSelectionBtn.visibility = View.VISIBLE
            binding.selectAllButton.visibility = View.GONE
        }


        itemTouchHelper.attachToRecyclerView(binding.recyclerView)

        setupSelectAllButton()
        setupToolbar()
    }

    private val itemTouchHelper = ItemTouchHelper(object : ItemTouchHelper.Callback() {
        override fun isLongPressDragEnabled() = false

        override fun getMovementFlags(
            recyclerView: RecyclerView,
            viewHolder: RecyclerView.ViewHolder,
        ): Int {
            return makeMovementFlags(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0)
        }

        override fun isItemViewSwipeEnabled() = false

        override fun onMove(
            recyclerView: RecyclerView,
            viewHolder: RecyclerView.ViewHolder,
            target: RecyclerView.ViewHolder,
        ): Boolean {
            val fromPosition = viewHolder.bindingAdapterPosition
            val toPosition = target.bindingAdapterPosition
            Collections.swap(adapter.mQuickMessagesList, fromPosition, toPosition)
            adapter.notifyItemMoved(fromPosition, toPosition)
            return true
        }

        override fun onSelectedChanged(viewHolder: RecyclerView.ViewHolder?, actionState: Int) {
            super.onSelectedChanged(viewHolder, actionState)
            if (actionState == ItemTouchHelper.ACTION_STATE_IDLE) {
                updateCallerCadConfig(
                    adapter.mQuickMessagesList
                )
            }
        }

        override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}
    })

    override fun onBackPressed() {
        if (adapter.selectedItems.size > 0 && selectionMode) {
            adapter.clearSelections()
            binding.mQuickItemClearBtn.visibility = View.GONE
            binding.mQuickItemDeleteBtn.visibility = View.GONE
            binding.quickMessageAddFab.visibility = View.VISIBLE
            binding.mStartSelectionBtn.visibility = View.VISIBLE
            binding.selectAllButton.visibility = View.GONE

        } else {
            super.onBackPressed()
        }

    }


    private fun handleMessageClick(message: String, isLongPress: Boolean) {
        if (isLongPress) {
            // Handle long press
        } else {
            showEditMessageDialog(message)
        }
    }

    private fun showAddMessageDialog() {
        val dialog = AddMessageDialog(this, object : AddMessageDialog.OnMessageEnteredListener {
            override fun onMessageEntered(message: String) {
                mQuickMessagesList.add(message)
                adapter.notifyItemInserted(mQuickMessagesList.size - 1)
                updateCallerCadConfig()
                if (mQuickMessagesList.isEmpty()) {
                    binding.noQuickMessagesText.visibility = View.VISIBLE
                } else {
                    binding.noQuickMessagesText.visibility = View.GONE
                }
            }
        })

        dialog.show()
    }

    private fun showEditMessageDialog(currentMessage: String) {
        val dialog =
            UpdateMessageDialog(this, object : UpdateMessageDialog.OnMessageActionListener {
                override fun onMessageUpdated(message: String) {
                    val index = mQuickMessagesList.indexOf(currentMessage)
                    if (index != -1) {
                        mQuickMessagesList[index] = message
                        adapter.notifyItemChanged(index)
                        updateCallerCadConfig()
                        Toast.makeText(
                            this@QuickResponseActivity,
                            "Message Updated",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onMessageDeleted() {
                    val index = mQuickMessagesList.indexOf(currentMessage)
                    if (index != -1) {
                        mQuickMessagesList.removeAt(index)
                        adapter.notifyItemRemoved(index)
                        updateCallerCadConfig()
                        Toast.makeText(
                            this@QuickResponseActivity,
                            "Message Deleted",
                            Toast.LENGTH_SHORT
                        ).show()

                        if (mQuickMessagesList.isEmpty()) {
                            binding.noQuickMessagesText.visibility = View.VISIBLE
                        } else {
                            binding.noQuickMessagesText.visibility = View.GONE
                        }
                    }
                }
            }, currentMessage)

        dialog.show()
    }

    private var selectionMode = false

    private fun setupToolbar() {
        binding.mStartSelectionBtn.setOnClickListener {


            if (selectionMode) {
                adapter.clearSelections()
                selectionMode = false

            } else {
                selectionMode = true
                adapter.enableSelectionMode()

            }
            binding.mStartSelectionBtn.visibility = if (!selectionMode) View.VISIBLE else View.GONE
            binding.selectAllButton.visibility = if (selectionMode) View.VISIBLE else View.GONE
            binding.quickMessageAddFab.visibility = if (!selectionMode) View.VISIBLE else View.GONE
            binding.mQuickItemDeleteBtn.visibility = if (selectionMode) View.VISIBLE else View.GONE
            binding.mQuickItemClearBtn.visibility = if (selectionMode) View.VISIBLE else View.GONE


        }
    }

    fun updateSelectionToolbar(isSelectionMode: Boolean) {
//        binding.toolbar.isVisible = !isSelectionMode
//        binding.mStartSelectionBtn.isVisible = !isSelectionMode
//        binding.selectAllButton.visibility = if (isSelectionMode) View.VISIBLE else View.GONE
//        binding.mQuickItemDeleteBtn.visibility = if (isSelectionMode) View.VISIBLE else View.GONE
//        binding.mQuickItemClearBtn.visibility = if (isSelectionMode) View.VISIBLE else View.GONE
        if (isSelectionMode) {
            binding.mQuickItemDeleteBtn.visibility = View.VISIBLE
            binding.mQuickItemClearBtn.visibility = View.VISIBLE
            binding.selectAllButton.visibility = View.VISIBLE
            binding.quickMessageAddFab.visibility = View.GONE
            binding.mStartSelectionBtn.visibility = View.GONE
        }


        selectionMode = isSelectionMode

//        binding.mStartSelectionBtn
    }

    private fun setupSelectAllButton() {
        binding.backBtnAtTheme.setOnClickListener {
            onBackPressed()
        }
        binding.selectAllButton.setOnClickListener {

            if (adapter.selectedItems.size == mQuickMessagesList.size) {
                adapter.clearSelections()
                binding.mQuickItemClearBtn.visibility = View.GONE
                binding.mQuickItemDeleteBtn.visibility = View.GONE
                binding.quickMessageAddFab.visibility = View.VISIBLE
                binding.mStartSelectionBtn.visibility = View.VISIBLE
                binding.selectAllButton.visibility = View.GONE
                binding.selectAllButton.setImageResource(R.drawable.ic_un_select_qk_msg)
            } else {
                adapter.selectAll()
                binding.selectAllButton.setImageResource(R.drawable.ic_select_qk_msg)
            }

        }
    }

    fun updateCallerCadConfig() {
        baseConfig.quickMessagesList = mQuickMessagesList
    }

    fun updateCallerCadConfig(mQuickMessagesList: MutableList<String>) {
        this.baseConfig.quickMessagesList = mQuickMessagesList
    }

    private fun getCallerMessages(): List<String> {
        return baseConfig.quickMessagesList
    }
}