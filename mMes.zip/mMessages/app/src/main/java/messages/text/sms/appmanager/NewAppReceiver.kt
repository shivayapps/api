package messages.text.sms.appmanager


import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log


class NewAppReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null || intent?.data == null) return

        Log.e("AppReceiver", "onReceive: ${intent.action}")
        val packageName = intent.data!!.encodedSchemeSpecificPart

        when (intent.action) {

            Intent.ACTION_PACKAGE_ADDED -> {
                //   val info = getAppInstallInfo(context, packageName)
                //    Log.e("AppReceiver", "App Installed: $info")
            }

            Intent.ACTION_PACKAGE_REMOVED -> {
                Log.e("AppReceiver", "App Removed: $packageName")
            }
        }
    }

    private fun getAppInstallInfo(context: Context, packageName: String): AppInstallInfo {
        val pm = context.packageManager
        val appInfo = pm.getApplicationInfo(packageName, 0)

        val appName = pm.getApplicationLabel(appInfo).toString()
        val icon = pm.getApplicationIcon(packageName)

        val pkgInfo = pm.getPackageInfo(packageName, 0)
        val firstInstallTime = pkgInfo.firstInstallTime
        val lastUpdateTime = pkgInfo.lastUpdateTime

        return AppInstallInfo(
            packageName,
            appName,
            firstInstallTime,
            lastUpdateTime
        )
    }
}

data class AppInstallInfo(
    val packageName: String,
    val appName: String,
    val installedTime: Long,
    val updateTime: Long,
)
