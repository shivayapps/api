package messages.text.sms.common.base

import androidx.lifecycle.LifecycleOwner

interface MainBaseMsgViewContract<in State> : LifecycleOwner {

    fun render(state: State)

}