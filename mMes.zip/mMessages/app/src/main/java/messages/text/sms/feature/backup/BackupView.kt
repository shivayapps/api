package messages.text.sms.feature.backup

import io.reactivex.Observable
import messages.text.sms.common.base.MainBaseMsgViewContract
import messages.text.sms.model.BackupFile

interface BackupView : MainBaseMsgViewContract<BackupState> {

//    fun activityVisible(): Observable<*>
//    fun permissionGiven(): Observable<*>
//    fun restoreClicks(): Observable<*>
//    fun restoreFileSelected(): Observable<BackupFile>
//    fun restoreConfirmed(): Observable<*>
//    fun stopRestoreClicks(): Observable<*>
//    fun stopRestoreConfirmed(): Observable<*>
//    fun stopBackup(): Observable<*>
//    fun fabClicks(): Observable<*>
//
//    fun requestStoragePermission()
//    fun selectFile()
//    fun confirmRestore()
//    fun stopRestore()

    fun activityVisible(): Observable<*>
    fun permissionGiven(): Observable<*>
    fun restoreClicks(): Observable<*>
    fun restoreFileSelected(): Observable<BackupFile>
    fun restoreConfirmed(): Observable<*>
    fun deleteRestoreFileSelected(): Observable<BackupFile>

    //    fun deleteRestoreFileSelected2(): Observable<*>
    fun stopRestoreClicks(): Observable<*>
    fun stopRestoreConfirmed(): Observable<*>
    fun stopBackup(): Observable<*>
    fun fabClicks(): Observable<*>


    fun requestDefaultSms()
    fun requestStoragePermission()
    fun selectFile()
    fun confirmRestore()
    fun stopRestore()
    fun showDialog()

}
