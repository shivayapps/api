package messages.text.sms.commons.dialog

import android.app.Activity
import android.app.AlertDialog
import messages.text.sms.R
import messages.text.sms.databinding.DialogMessageBinding

class PermissionRequiredDialog(
    val activity: Activity,
    textId: Int,
    private val positiveActionCallback: () -> Unit,
    private val negativeActionCallback: (() -> Unit)? = null,
) {
    private var dialog: AlertDialog? = null

    init {
        // Load interstitial ad if needed

        val view = DialogMessageBinding.inflate(activity.layoutInflater, null, false)
        view.message.text = activity.getString(textId)

        // Create and show the AlertDialog
        dialog = AlertDialog.Builder(activity, R.style.CustomFieldDialogTheme)
            .setTitle(activity.getString(R.string.permission_required))
            .setView(view.root)
            .setPositiveButton(R.string.grant_permission) { _, _ ->
                // Show interstitial ad before proceeding
                positiveActionCallback()
            }
            .setNegativeButton(R.string.cancel) { _, _ ->
                negativeActionCallback?.invoke()
            }
            .create()
        dialog?.show()
    }
}
