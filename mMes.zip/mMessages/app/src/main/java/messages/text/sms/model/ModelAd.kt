package messages.text.sms.model


/*
open class ModelAd : RealmObject(), ModelType{
    override fun getType(): Int {
        return AD_TYPE
    }
}*/

open class ModelAd : ModelType {
    override fun getType(): Int {
        return AD_TYPE
    }
}