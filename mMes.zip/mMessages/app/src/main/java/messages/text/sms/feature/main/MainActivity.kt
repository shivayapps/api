package messages.text.sms.feature.main

import android.Manifest
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.provider.Telephony
import android.text.Editable
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.view.ContextThemeWrapper
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import com.jakewharton.rxbinding2.view.clicks
import com.jakewharton.rxbinding2.widget.editorActions
import com.jakewharton.rxbinding2.widget.textChanges
import com.klinker.android.send_message.Utils
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import io.realm.Realm
import io.realm.RealmResults
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import messages.text.sms.R
import messages.text.sms.ads.AdmobNative
import messages.text.sms.ads.AdsPreferences
import messages.text.sms.ads.GoogleBannerAdManager
import messages.text.sms.ads.GoogleBannerAdManager.showHomeBannerViewBanner
import messages.text.sms.ads.GoogleSmallNativeAdManagerHome
import messages.text.sms.ads.GoogleSmallNativeAdManagerHome.loadSmallNative4Home
import messages.text.sms.ads.GoogleSmallNativeAdManagerHome.loadSmallNativeHome
import messages.text.sms.ads.MainInterAdManager
import messages.text.sms.ads.app_allow_notification_permission
import messages.text.sms.ads.app_click_on_contact_menu
import messages.text.sms.ads.app_click_on_personalize_menu
import messages.text.sms.ads.app_click_on_setting_menu
import messages.text.sms.ads.app_click_on_sms_menu
import messages.text.sms.ads.app_create_new_message_from_notification
import messages.text.sms.ads.app_home_created
import messages.text.sms.ads.app_inbox_open_from_notification
import messages.text.sms.ads.app_manage_apps_open_from_notification
import messages.text.sms.ads.app_notification_dialog
import messages.text.sms.ads.app_overlay_allow_permission
import messages.text.sms.ads.app_overlay_deny_permission
import messages.text.sms.ads.app_reject_default_sms_permissions
import messages.text.sms.ads.app_reject_notification_permission
import messages.text.sms.ads.cad_call_allow_permission
import messages.text.sms.ads.cad_call_deny_permission
import messages.text.sms.ads.cad_click_setup
import messages.text.sms.ads.cad_overlay_allow_permission
import messages.text.sms.ads.cad_overlay_deny_permission
import messages.text.sms.ads.data_set_in_activity
import messages.text.sms.ads.data_set_in_activity_200
import messages.text.sms.ads.delayExecution
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.ads.getAppExitNative
import messages.text.sms.ads.getAppListNative1
import messages.text.sms.ads.getAppListNative2
import messages.text.sms.ads.isFirstTimeAppOpen
import messages.text.sms.ads.isFirstTimeLog
import messages.text.sms.ads.isInternetConnected
import messages.text.sms.ads.logCount
import messages.text.sms.appmanager.FindAppActivity
import messages.text.sms.common.BubbleListener
import messages.text.sms.common.FastScroller
import messages.text.sms.common.MysmsApplication.Companion.dataLoading
import messages.text.sms.common.MysmsApplication.Companion.isAdsNotShowOnResume
import messages.text.sms.common.MysmsApplication.Companion.isAppOpenFlag
import messages.text.sms.common.MysmsApplication.Companion.isHomeInterShow
import messages.text.sms.common.MysmsApplication.Companion.mEnterScreen
import messages.text.sms.common.MysmsApplication.Companion.mOpenOverlayScreen
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.autoScrollToStart
import messages.text.sms.common.util.extensions.dismissKeyboard
import messages.text.sms.common.util.extensions.hideKeyboard
import messages.text.sms.common.util.extensions.resolveThemeColor
import messages.text.sms.common.util.extensions.scrapViews
import messages.text.sms.common.util.extensions.setBackgroundTint
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.common.util.extensions.showKeyboard
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.common.widget.QkDialog
import messages.text.sms.commons.dialogs.MoreBottomSheetDialog
import messages.text.sms.commons.dialogs.RateUsCheckBottomSheetDialog
import messages.text.sms.commons.extensions.addAlpha
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.commons.extensions.beVisibleIf
import messages.text.sms.commons.extensions.clientConfigPref
import messages.text.sms.commons.extensions.config
import messages.text.sms.commons.extensions.setItemColors
import messages.text.sms.commons.extensions.showHomeNotification
import messages.text.sms.commons.extensions.toast
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.commons.helpers.ReConstant
import messages.text.sms.commons.helpers.isQPlus
import messages.text.sms.databinding.MainActivityBinding
import messages.text.sms.extensions.Optional
import messages.text.sms.extensions.setupTermsText
import messages.text.sms.extensions.startZoomAnimation
import messages.text.sms.feature.blocking.BlockingActivity
import messages.text.sms.feature.blocking.BlockingDialog
import messages.text.sms.feature.compose.ComposeActivity
import messages.text.sms.feature.compose.editing.PhoneNumberAction
import messages.text.sms.feature.compose.editing.PhoneNumberPickerAdapter
import messages.text.sms.feature.contacts.ContactsActivity.Companion.ChipsKey
import messages.text.sms.feature.contacts.GroupsActivity
import messages.text.sms.feature.conversations.ConversationItemTouchCallback
import messages.text.sms.feature.conversations.NewConversationsAdapter
import messages.text.sms.feature.fragments.contact.AllContactFragment
import messages.text.sms.feature.scheduled.ScheduledActivity
import messages.text.sms.manager.PermissionManager
import messages.text.sms.model.CLOSE_SEARCH
import messages.text.sms.model.ContactData
import messages.text.sms.model.ContactGroup
import messages.text.sms.model.Conversation
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.NEW_MSG_UPDATE_AVAILABLE
import messages.text.sms.model.REFRESH_ARCHIVE
import messages.text.sms.model.REFRESH_CONTACT_GROUP
import messages.text.sms.model.REFRESH_MESSAGE
import messages.text.sms.model.RESUME_MAIN
import messages.text.sms.model.SETTING_OPEN
import messages.text.sms.model.SYNC_MESSAGE
import messages.text.sms.model.TEMP_REFRESH_MESSAGE
import messages.text.sms.model.THEME_CHANGED
import messages.text.sms.model.UPDATE_ALL_CONTACT
import messages.text.sms.password.PasswordActivity
import messages.text.sms.repository.SyncRepository
import messages.text.sms.searchview.SimpleSearchView
import messages.text.sms.util.AutoStartHelper
import messages.text.sms.util.ExitDialog
import messages.text.sms.util.StringManager
import messages.text.sms.util.appPreference
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.lang.ref.WeakReference
import java.util.Calendar
import javax.inject.Inject


class MainActivity : MainBaseThemedActivity(), MainView {
    private val binding by viewBinding(MainActivityBinding::inflate)

    companion object {
        var mainActivity: MainActivity? = null

        var currentPoss = 0
        var viewHomeScreen = ""

    }

    private var isAdapterSet = false
    var lastUpdateTime: Long = 0
//    var tempUpdate = false

    @Inject
    lateinit var blockingDialog: BlockingDialog

    @Inject
    lateinit var disposables: CompositeDisposable

    @Inject
    lateinit var navigator: Navigator

    @Inject
    lateinit var conversationsAdapter: NewConversationsAdapter

    @Inject
    lateinit var drawerBadgesExperiment: DrawerBadgesExperiment

    @Inject
    lateinit var searchAdapter: SearchAdapter

    @Inject
    lateinit var permissionManager: PermissionManager

    @Inject
    lateinit var itemTouchCallback: ConversationItemTouchCallback



    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory
    lateinit var appUpdateManager: AppUpdateManager
    var contacts: List<ContactData>? = null
    var recentContacts: List<ContactData>? = null
    var contactGroups: List<ContactGroup>? = null
    override val onNewIntentIntent: Subject<Intent> = PublishSubject.create()
    override val activityResumedIntent: Subject<Boolean> = PublishSubject.create()
    override val queryConversationChangedIntent by lazy { binding.messageTab.toolbarSearch.textChanges() }
    override val composeIntent by lazy { binding.messageTab.compose.clicks() }

    private var cat: String = ""

    //    private var selectPos: Int = 0
    //  private lateinit var mCategoryAdapter: AdapterHomeCategory

//    override val drawerOpenIntent: Observable<Boolean> by lazy {
//        binding.drawerLayout
//            .drawerOpen(Gravity.START)
//            .doOnNext { dismissKeyboard() }
//    }

    override val homeIntent: Subject<Unit> = PublishSubject.create()
    override val navigationIntent: Observable<NavItem> by lazy {
        Observable.merge(
            listOf(
                backPressedSubject,
            )
        )
    }

    override val optionsItemIntent: Subject<Int> = PublishSubject.create()

    //    override val dismissRatingIntent by lazy { binding.drawer.rateDismiss.clicks() }
//    override val rateIntent by lazy { binding.drawer.rateOkay.clicks() }
    override val conversationsSelectedIntent by lazy { conversationsAdapter.selectionChanges }
    override val confirmDeleteIntent: Subject<List<Long>> = PublishSubject.create()
    override val swipeConversationIntent by lazy { itemTouchCallback.swipes }
    override val undoArchiveIntent: Subject<Unit> = PublishSubject.create()
    override val refreshArchive: Subject<Unit> = PublishSubject.create()
    override val refreshMessages: Subject<Unit> = PublishSubject.create()
    override val refreshBlocked: Subject<Unit> = PublishSubject.create()

    override val queryChangedIntent: Observable<CharSequence> by lazy { binding.contactTab.searchContact.textChanges() }
    override val queryClearedIntent: Observable<*> by lazy { binding.contactTab.cancel.clicks() }
    override val queryEditorActionIntent: Observable<Int> by lazy { binding.contactTab.searchContact.editorActions() }
    override val phoneNumberSelectedIntent: Subject<Optional<Long>> by lazy { phoneNumberAdapter.selectedItemChanges }
    override val phoneNumberActionIntent: Subject<PhoneNumberAction> = PublishSubject.create()
    override val composeItemPressedIntent: Subject<ContactData> = PublishSubject.create()
    override val composeItemLongPressedIntent: Subject<ContactData> = PublishSubject.create()

    override val setAsDefaultClick by lazy { binding.messageTab.snackbar.snackbarTitle.clicks() }


    private val viewModel by lazy {
        ViewModelProviders.of(
            this,
            viewModelFactory
        )[MainViewModel::class.java]
    }
    private val itemTouchHelper by lazy { ItemTouchHelper(itemTouchCallback) }
    private val progressAnimator by lazy {
        ObjectAnimator.ofInt(
            binding.messageTab.syncing.syncingProgress,
            "progress",
            0,
            0
        )
    }
    private val backPressedSubject: Subject<NavItem> = PublishSubject.create()


    @Inject
    lateinit var phoneNumberAdapter: PhoneNumberPickerAdapter
    private val phoneNumberDialog by lazy {
        QkDialog(this).apply {
            titleRes = R.string.compose_number_picker_title
            adapter = phoneNumberAdapter
            positiveButton = R.string.compose_number_picker_always
            positiveButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.ALWAYS) }
            negativeButton = R.string.compose_number_picker_once
            negativeButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.JUST_ONCE) }
            cancelListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.CANCEL) }
        }
    }

    var alertDialog: AlertDialog? = null
    private var alertDialogNoti: AlertDialog? = null
    private val REQUEST_DRAW_OVERLAYS_PERMISSION = 1002
    private val REQUEST_DRAW_OVERLAYS_PERMISSION_OTP = 1005
    private val REQUEST_CODE_UPDATE = 2222
    private var actionType: String? = ""
    private var lastSelectedTab = R.id.messageFragment
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
//        binding=MainActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        appPreference.isRefreshMessages = false
        mainActivity = this
        runOnUiThread {
            viewModel.bindView(this)
            if (!isInternetConnected()) {
                conversationsAdapter.isLoadingAd = false
            }
        }
        runOnUiThread {
            if (isInternetConnected()) {
                binding.adsBannerParent.visibility = View.VISIBLE
                showHomeBannerViewBanner(this, binding.adsBannerParent)
            } else {
                binding.adsBannerParent.visibility = View.GONE
            }
        }
        actionType = intent.getStringExtra("ACTION_TYPE")
//        firebaseAnalytics = Firebase.analytics

        if (isFirstTimeLog()) {
            firebaseAnalyticsHandler.logMessages(
                app_home_created, getActivityName()
            )

            // Log.e("firebaseAnalyticsHandler__", "firebaseAnalyticsHandler ${main_activity_created}")
        }

        onNewIntentIntent.onNext(intent)
//        setSupportActionBar(binding.messageTab.toolbar)
        setSupportActionBar(binding.toolbar)
        isHomeBackClick = false
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this)


        config.saveData("checkfirst", true)

        /*binding.messageTab.toolbar.setNavigationOnClickListener {
            dismissKeyboard()
            homeIntent.onNext(Unit)
        }*/

        itemTouchCallback.adapter = conversationsAdapter
        conversationsAdapter.autoScrollToStart(binding.messageTab.recyclerView)

        // Don't allow clicks to pass through the drawer layout
//        binding.drawer.root.clicks().autoDisposable(scope()).subscribe()
        when (baseConfig.select_cat) {
            0 -> {
                cat = resources.getString(R.string.cat_all)
            }

            1 -> {
                cat = resources.getString(R.string.cat_personal)
            }

            2 -> {
                cat = resources.getString(R.string.cat_transaction)
            }

            3 -> {
                cat = resources.getString(R.string.cat_otps)
            }

            4 -> {
                cat = resources.getString(R.string.cat_offers)
            }

            else -> {
                cat = resources.getString(R.string.cat_all)
            }
        }

        /*theme.autoDisposable(scope())
            .subscribe { theme ->
                // Set the color for the drawer icons
                val states = arrayOf(
                    intArrayOf(android.R.attr.state_activated),
                    intArrayOf(-android.R.attr.state_activated)
                )

                resolveThemeColor(android.R.attr.textColorSecondary)
                    .let { textSecondary ->
                        ColorStateList(
                            states,
                            intArrayOf(theme.theme, textSecondary)
                        )
                    }
                    .let { tintList ->
//                        binding.drawer.inboxIcon.imageTintList = tintList
                        //   binding.messageTab.archivedIcon.imageTintList = tintList
                    }
                binding.messageTab.syncing.syncingProgress.progressTintList =
                    ColorStateList.valueOf(theme.theme)
                binding.messageTab.syncing.syncingProgress.indeterminateTintList =
                    ColorStateList.valueOf(theme.theme)
//                binding.messageTab.compose.setBackgroundTint(theme.theme)
//                binding.messageTab.compose.setTint(theme.textPrimary)
                binding.messageTab.compose.setBackgroundTint(baseConfig.primaryColor)
                val primaryColor = Color.parseColor("#FFFFFF")
                binding.messageTab.compose.setTint(primaryColor)

            }*/

        theme.autoDisposable(scope())
            .subscribe { theme ->

                // ---------- State list for activated / normal ----------
                val states = arrayOf(
                    intArrayOf(android.R.attr.state_activated),
                    intArrayOf(-android.R.attr.state_activated)
                )

                // ---------- Text secondary (safe) ----------
                val textSecondary = runCatching {
                    resolveThemeColor(android.R.attr.textColorSecondary)
                }.getOrElse {
                    Color.GRAY
                }

                val tintList = ColorStateList(
                    states,
                    intArrayOf(theme.theme, textSecondary)
                )

                // ❌ Do NOT touch drawables here unless verified
                // binding.drawer.inboxIcon.imageTintList = tintList

                // ---------- Progress tint (colors only – SAFE) ----------
                binding.messageTab.syncing.syncingProgress.apply {
                    progressTintList = ColorStateList.valueOf(theme.theme)
                    indeterminateTintList = ColorStateList.valueOf(theme.theme)
                }

                // ---------- Compose button background (color only) ----------
                val bgColor = runCatching {
                    baseConfig.primaryColor
                }.getOrElse {
                    theme.theme
                }

                binding.messageTab.compose.setBackgroundTint(bgColor)

                // ---------- Icon tint (color only) ----------
                binding.messageTab.compose.setTint(Color.WHITE)
            }

        setUpTheme()
        initContactView()
        initListener()

        if (baseConfig.ringtoneUri.isEmpty()) {
            baseConfig.ringtoneUri =
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION).toString()
        }



        if (isInternetConnected()) {
            runOnUiThread {

                requestAd()
            }
        }

//        if (!isFirstTimeAppOpen()) {

        //   fetchJSONArrayIfNeeded()
//        }

        Log.d("PermissionsXXBX", "SMS - ${clientConfigPref.smsDefaultNecessary}")


        if (clientConfigPref.smsDefaultNecessary) {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_SMS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                binding.viewFlipper.visibility = View.GONE
                binding.llBottom.beGone()
                binding.viewPermission.visibility = View.VISIBLE

                startZoomAnimation(binding.btnStart)

            } else {

                binding.viewFlipper.visibility = View.VISIBLE
                binding.llBottom.beVisible()

                binding.viewPermission.visibility = View.GONE
            }


        } else {


            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_PHONE_STATE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPhoneStatePermissionNew()
            } else {

                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.READ_SMS
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    //Log.d("PermissionsXXX", "SMS REQUESTSMSPERMISSION")
                    requestSmsPermission()
                } else {
                    checkContactsPermission()
                }
            }


        }

        binding.btnStart.setOnClickListener {
            loadMessages()
        }

        lifecycleScope.launch {
            delayExecution(500) {
                Log.d("HomeInterAd", "isHomeInterShow - $isHomeInterShow")
                if (isInternetConnected() && !isHomeInterShow) {
                    MainInterAdManager.loadHomeInter(this@MainActivity)
                }
            }
        }

        if (!isFirstTimeAppOpen()) {

            appUpdateManager = AppUpdateManagerFactory.create(this)

            appUpdateManager.appUpdateInfo.addOnSuccessListener { appUpdateInfo ->
                if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                    appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)
                ) {
                    try {
                        appUpdateManager.startUpdateFlowForResult(
                            appUpdateInfo,
                            AppUpdateType.IMMEDIATE,
                            this,
                            REQUEST_CODE_UPDATE
                        )
                    } catch (e: Exception) {
                    }
                }
            }

            appUpdateManager.registerListener { state ->
                if (state.installStatus() == InstallStatus.DOWNLOADED) {
                    // Notify the user to complete the update
                    Snackbar.make(
                        findViewById(android.R.id.content),
                        "An update has just been downloaded.",
                        Snackbar.LENGTH_INDEFINITE
                    ).setAction("Restart") {
                        appUpdateManager.completeUpdate()
                    }.show()
                }
            }
        }

        if (actionType != null && actionType?.isNotEmpty() == true) {
            when (actionType) {
                "notification_inbox" -> {
                    firebaseAnalyticsHandler.logMessages(
                        app_inbox_open_from_notification, getActivityName()
                    )
//                     Log.d("firebaseAnalyticsHandler", " - " + app_inbox_open_from_notification)
                }

                "notification_new_message" -> {
                    firebaseAnalyticsHandler.logMessages(
                        app_create_new_message_from_notification, getActivityName()
                    )
//                    Log.d("firebaseAnalyticsHandler", " - " + app_new_message_open_from_notification)
                    navigator.showCompose()
                }

//                "notification_manage_apps" -> {
//                    firebaseAnalyticsHandler.logMessages(
//                        app_manage_apps_open_from_notification, getActivityName()
//                    )
////                    Log.d("firebaseAnalyticsHandler", " - " + app_manage_apps_open_from_notification)
//                    startActivity(Intent(this@MainActivity, FindAppActivity::class.java))
//                }

                else -> {
                    // Handle default action
                }
            }
        }


        showHomeNotification()

//        binding.messageTab.snackbar.btnSetOverlay.setOnClickListener {
//            val intent = Intent(
//                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
//                Uri.parse("package:" + packageName)
//            )
//
//            isAdsNotShowOnResume = true
//            try {
//                startActivityForResult(intent, REQUEST_DRAW_OVERLAYS_PERMISSION_OTP)
//            } catch (_: Exception) {
//            }
//        }

        runOnUiThread {
            if (isInternetConnected()) {
                delayExecution(5000) {
                    loadExitAds()
                }
            }
        }
    }

    fun getInstalledApps(context: Context): List<String> {
        val packageManager: PackageManager = context.packageManager
        val installedApps: List<ApplicationInfo> =
            packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        return installedApps.map { it.packageName }
    }


    private val MAKE_DEFAULT_APP_REQUEST = 111
    private fun loadMessages() {


        if (isQPlus()) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager!!.isRoleAvailable(RoleManager.ROLE_SMS)) {
                if (roleManager.isRoleHeld(RoleManager.ROLE_SMS)) {

                    viewModel.refreshMessages()

                    binding.viewFlipper.visibility = View.VISIBLE
                    binding.viewPermission.visibility = View.GONE
                    binding.llBottom.beVisible()
                } else {
                    val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS)
                    intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
                    startActivityForResult(intent, MAKE_DEFAULT_APP_REQUEST)
                }
            } else {
                finish()
            }
        } else {
            if (Telephony.Sms.getDefaultSmsPackage(this) == packageName) {

                viewModel.refreshMessages()
                binding.viewFlipper.visibility = View.VISIBLE
                binding.viewPermission.visibility = View.GONE
                binding.llBottom.beVisible()
            } else {
                val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
                startActivityForResult(intent, MAKE_DEFAULT_APP_REQUEST)
            }
        }
    }


    private val requestSmsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGrant: Boolean ->

        if (isGrant) {
            //Log.d("PermissionsXXX", "SMS PERMISSION_GRANTED")

            viewModel.refreshMessagesNotDefaultSms()

        } else {

            //Log.d("PermissionsXXX", "SMS PERMISSION_DENIED")
        }
        checkContactsPermission()
    }

    private val requestAutoStartLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGrant: Boolean ->

        if (isGrant) {

        } else {

        }
    }

    private val requestContactsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isgrant: Boolean ->
        if (isgrant) {
            viewModel.syncContactsData()


        } else {

            //Log.d("PermissionsXXX", "CONTACTS PERMISSION_DENIED")
        }
        checkNotificationPermission()
    }
    private val requestPhoneStatePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGrant: Boolean ->

        if (isGrant) {
            firebaseAnalyticsHandler.logMessages(
                cad_call_allow_permission, getActivityName()
            )

            //   if (!AutoStartHelper.isAutoStartSettingsAvailable(this)) {
                requestSystemOverlayPermission()
            //   }

        } else {

            firebaseAnalyticsHandler.logMessages(
                cad_call_deny_permission, getActivityName()
            )

                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            }


    }
    private val requestPhoneStatePermissionLauncherNew = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGrant: Boolean ->

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            //Log.d("PermissionsXXX", "SMS REQUESTSMSPERMISSION")
            requestSmsPermission()
        } else {
            checkContactsPermission()
        }
    }

    private val requestNotificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGrant: Boolean ->

        if (!isGrant) {
            firebaseAnalyticsHandler.logMessages(
                app_reject_notification_permission, getActivityName()
            )
            customNotificationdialog()
            //Log.d("PermissionsXXX", "NOTIFICATION PERMISSION_GRANTED")
        } else {
            firebaseAnalyticsHandler.logMessages(
                app_allow_notification_permission, getActivityName()
            )
            if (alertDialogNoti?.isShowing == true) {
                alertDialogNoti?.dismiss()
            }
            //Log.d("PermissionsXXX", "NOTIFICATION PERMISSION_DENIED")
            showHomeNotification()
        }
        /*  delayExecution(1000) {
              if (AutoStartHelper.isAutoStartSettingsAvailable(this)) {
                  itemCallerDisable?.isVisible = false
              }
          }*/

    }

    private val requestNotificationPermissionLauncherDialog = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGrant: Boolean ->
        if (!isGrant) {
            firebaseAnalyticsHandler.logMessages(
                app_reject_notification_permission,
                getActivityName()
            )
            //Log.d("PermissionsXXX", "DIALOG NOTIFICATION PERMISSION_GRANTED")
            // Optionally show a dialog explaining why the permission is needed if the user denied it permanently
            if (!shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {

                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                val uri = Uri.fromParts("package", packageName, null)
                intent.data = uri
                startActivity(intent)
            }
        } else {
            firebaseAnalyticsHandler.logMessages(
                app_allow_notification_permission,
                getActivityName()
            )

            if (alertDialogNoti?.isShowing == true) {
                alertDialogNoti?.dismiss()
            }
            //Log.d("PermissionsXXX", "DIALOG NOTIFICATION PERMISSION_DENIED")

            val restartIntent = Intent("RestartService")
            sendBroadcast(restartIntent)
        }
    }

    private fun requestPhoneStatePermissionNew() {

        requestPhoneStatePermissionLauncherNew.launch(Manifest.permission.READ_PHONE_STATE)

    }

    private fun requestPhoneStatePermission() {

        requestPhoneStatePermissionLauncher.launch(Manifest.permission.READ_PHONE_STATE)

    }

    private fun requestSmsPermission() {

        requestSmsPermissionLauncher.launch(Manifest.permission.READ_SMS)


    }

    private fun checkContactsPermission() {
        // Check if Contacts permission is granted
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_CONTACTS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestContactsPermission()

            //Log.d("PermissionsXXX", "CONTACTS REQUEST_CONTACTS_PERMISSION")
        } else {
            // Contacts permission is already granted, proceed to notification permission
            checkNotificationPermission()
        }
    }

    private fun requestContactsPermission() {

        requestContactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
    }

    private fun checkNotificationPermission() {
        // Check if Notification permission is granted
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                customNotificationdialog()
            } else {
                //Log.d("PermissionsXXX", "NOTIFICATION REQUEST_NOTIFICATION_PERMISSION")
                requestNotificationPermission()
            }
        } else {
            // All permissions are granted, proceed with your app logic
            // Example: Start a service that uses SMS, Contacts, and Notifications
            //Log.d("PermissionsXXX", "CALLERPERMISSIONDIALOG")

        }

        /*  if (AutoStartHelper.isAutoStartSettingsAvailable(this)) {

              if (ContextCompat.checkSelfPermission(
                      this,
                      Manifest.permission.READ_PHONE_STATE
                  ) != PackageManager.PERMISSION_GRANTED) {

                  itemCallerDisable?.isVisible = true
              } else{
                  itemCallerDisable?.isVisible = false
              }
          }else{
              if (!Settings.canDrawOverlays(this@MainActivity)) {
                  permissiondialog()
              }else{
                  itemCallerDisable?.isVisible = false
              }
          }*/
    }


    private fun requestNotificationPermission() {


        requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }


    private fun requestAd() {

        delayExecution(200) {
            conversationsAdapter.isLoadingAd = true
            loadSmallNativeHome(this, getAppListNative1()) {
                var isFirstNativeLoaded = false
                if (it != null) {
                    isFirstNativeLoaded = true
                    notifyItem(0)
                    //conversationsAdapter.notifyItemChanged(0, "refresh_ad")
                }

                if (conversationsAdapter.itemCount > 5) {

                    if (isFirstTimeAppOpen()) {

                        if (clientConfigPref.homeSecondAdShow) {
                            loadSmallNative4Home(this, getAppListNative2()) { secondNative ->
                                var isSecondNativeLoaded = false
                                if (secondNative != null) {
                                    isSecondNativeLoaded = true
                                    notifyItem(5)
                                    if (!isFirstNativeLoaded) {
                                        isFirstNativeLoaded = true
                                        conversationsAdapter.notifyItemChanged(0)
                                        notifyItem(0)
                                    }
                                } else {
                                    if (!isSecondNativeLoaded) {
                                        conversationsAdapter.isLoadingAd = false
                                        //  notifyItem(0)
                                        notifyItem(5)
                                    }
                                }
                            }
                        } /*else{
                            conversationsAdapter.isLoadingAd = false
                            //  notifyItem(0)
                            notifyItem(5)
                        }*/

                    } else {

                        loadSmallNative4Home(this, getAppListNative2()) { secondNative ->
                            var isSecondNativeLoaded = false
                            if (secondNative != null) {
                                isSecondNativeLoaded = true
                                notifyItem(5)
                                if (!isFirstNativeLoaded) {
                                    isFirstNativeLoaded = true
                                    conversationsAdapter.notifyItemChanged(0)
                                    notifyItem(0)
                                }
                            } else {
                                if (!isSecondNativeLoaded) {
                                    conversationsAdapter.isLoadingAd = false
                                    //  notifyItem(0)
                                    notifyItem(5)
                                }
                            }
                        }


                        /*   if (conversationsAdapter.itemCount > 8) {
                               loadSmallNative8Home(this, getAppListNative3()) { thirdNative ->
                                   conversationsAdapter.isLoadingAd = false
                                   if (!isFirstNativeLoaded) {
                                       notifyItem(0)
                                   }
                                   if (!isSecondNativeLoaded) {
                                       notifyItem(4)
                                   }
                                   notifyItem(8)
                               }
                           } else {
                               if (!isSecondNativeLoaded) {
                                   conversationsAdapter.isLoadingAd = false
                                   //  notifyItem(0)
                                   notifyItem(4)
                               }
                           }*/
                    }
                } else {
                    if (!isFirstNativeLoaded) {
                        conversationsAdapter.isLoadingAd = false
                        notifyItem(0)
                    }
                }

            }
        }
    }

    private fun notifyItem(position: Int) {

//        conversationsAdapter.notifyItemChanged(position)
        if (position == 8) {
            /* binding.messageTab.recyclerView.post {
                 binding.messageTab.recyclerView.suppressLayout(true)
                 conversationsAdapter.notifyItemChanged(position)
                 binding.messageTab.recyclerView.suppressLayout(false)
             }*/

            conversationsAdapter.notifyDataSetChanged()
        } else {

            binding.messageTab.recyclerView.post {
                conversationsAdapter.notifyItemChanged(position)
            }
        }
    }


    private fun customNotificationdialog() {
        if (isFinishing || isDestroyed) {
            return
        }
        firebaseAnalyticsHandler.logMessages(app_notification_dialog, getActivityName())

        val dialogBuilder = AlertDialog.Builder(this)
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_notification_permission, null)
        dialogBuilder.setView(view)

        val btnPermission = view.findViewById<TextView>(R.id.btnPermission)
        val close = view.findViewById<ImageView>(R.id.close)

        val applyBackground = ResourcesCompat.getDrawable(
            resources,
            R.drawable.button_background_rounded,
            null
        ) as RippleDrawable
        (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
            .setColorFilter(Color.parseColor("#2569F1"), PorterDuff.Mode.SRC_IN)
        btnPermission.background = applyBackground
        btnPermission.setTextColor(Color.parseColor("#FFFFFF"))

        alertDialogNoti = dialogBuilder.create() // Initialize BEFORE setting listeners

        close.setOnClickListener {
            alertDialogNoti?.dismiss()
        }

        btnPermission.setOnClickListener {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    val uri = Uri.fromParts("package", packageName, null)
                    intent.data = uri
                    startActivity(intent)
                } else {
                    requestNotificationPermissionLauncherDialog.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            } else {
                Log.d("Permissions", "All permissions granted!")
                //callerPermissionDialog() // Uncomment if needed, but carefully consider its effects.
            }
        }

        alertDialogNoti?.setOnDismissListener {
//            if (config.getBooleanData("checkfirsttimedialog") == true) {
//                // Your code here
//            } else {
//                // Your code here
//                //callerPermissionDialog() // Uncomment if needed, but carefully consider its effects.
//            }
        }

        alertDialogNoti?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        if (alertDialogNoti?.isShowing == false) {

            alertDialogNoti?.show()
        }
    }

    /* private fun customNotificationdialog() {

         firebaseAnalyticsHandler.logMessages(
             app_notification_dialog, getActivityName()
         )
         val dialogBuilder = AlertDialog.Builder(this)
         val view = layoutInflater.inflate(R.layout.dialog_notification_permission, null)

         dialogBuilder.setView(view)

         val btnPermission = view.findViewById<TextView>(R.id.btnPermission)
         val close = view.findViewById<ImageView>(R.id.close)
         val applyBackground = ResourcesCompat.getDrawable(
             resources,
             R.drawable.button_background_rounded,
             null
         ) as RippleDrawable
         (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
             .setColorFilter(Color.parseColor("#2569F1"), PorterDuff.Mode.SRC_IN)
         btnPermission.background = applyBackground

         btnPermission.setTextColor(Color.parseColor("#FFFFFF"))

         close.setOnClickListener {
             if (alertDialogNoti?.isShowing == true) {

                 alertDialogNoti?.dismiss()
             }
         }
         btnPermission.setOnClickListener {


             if (ContextCompat.checkSelfPermission(
                     this,
                     Manifest.permission.POST_NOTIFICATIONS
                 ) != PackageManager.PERMISSION_GRANTED
             ) {

                 if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {

                     val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                     val uri = Uri.fromParts("package", packageName, null)
                     intent.data = uri
                     startActivity(intent)

                 } else {
                     // No explanation needed; request the permission
                     requestNotificationPermissionLauncherDialog.launch(Manifest.permission.POST_NOTIFICATIONS)
                 }
             } else {
                 Log.d("Permissions", "All permissions granted!")
                 callerPermissionDialog()
             }
         }

         alertDialogNoti = dialogBuilder.create()

         alertDialogNoti?.setOnDismissListener {
             if (config.getBooleanData("checkfirsttimedialog") == true) {

             } else {

             }
             callerPermissionDialog()
         }

         alertDialogNoti?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
         alertDialogNoti?.show()
     }*/

    private fun requestSystemOverlayPermission() {



        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + packageName)
        )

        isAdsNotShowOnResume = true
        try {
            startActivityForResult(intent, REQUEST_DRAW_OVERLAYS_PERMISSION)
        } catch (e: Exception) {
//            Log.e("printStackTrace", "printStackTrace:$e")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)

        if (requestCode == REQUEST_DRAW_OVERLAYS_PERMISSION_OTP) {
            if (Settings.canDrawOverlays(this)) {
                firebaseAnalyticsHandler.logMessages(
                    app_overlay_allow_permission, getActivityName()
                )

            } else {
                firebaseAnalyticsHandler.logMessages(
                    app_overlay_deny_permission, getActivityName()
                )
            }
        }


        if (requestCode == MAKE_DEFAULT_APP_REQUEST) {
            if (resultCode == Activity.RESULT_OK) {
                viewModel.refreshMessages()
                binding.viewFlipper.visibility = View.VISIBLE
                binding.viewPermission.visibility = View.GONE
                binding.llBottom.beVisible()

            } else if (resultCode == Activity.RESULT_CANCELED) {
                firebaseAnalyticsHandler.logMessages(
                    app_reject_default_sms_permissions, getActivityName()
                )
//                MainInterAdManager.showGeneralInterAds(this, true) {
//                    if (intent.hasExtra("DefaultSms")) {
//                        startActivity(
//                            Intent(
//                                this,
//                                MainActivity::class.java
//                            ).setAction(intent.action)
//                        )
//                        finish()
//                    } else {
//                        launchHomeScreen()
//                    }
//                }
//                launchHomeScreen()

            }
        }
    }


    private fun setUpTheme() {

        val primaryColorWithAlpha =
            ColorUtils.setAlphaComponent(baseConfig.primaryColor, (255 * 0.1).toInt())

        val textColorPrimaryss = baseConfig.textColor
        val colorWithAlpha = textColorPrimaryss.addAlpha(0.8F)

        binding.messageTab.toolbarSearch.setBackgroundTint(primaryColorWithAlpha)
        binding.contactTab.searchContact.setBackgroundTint(primaryColorWithAlpha)


        binding.contactTab.searchContact.setHintTextColor(colorWithAlpha)
        binding.messageTab.toolbarSearch.setHintTextColor(colorWithAlpha)

        binding.messageTab.toolbarSearch.setTextColor(R.attr.textColor)
        binding.contactTab.searchContact.setTextColor(R.attr.textColor)

        binding.messageTab.goToTopButton.setTint(baseConfig.primaryColor)

//        if (baseConfig.useImageResource){
//            if (baseConfig.storedImageResource==-1){
//
//            }else{
////                val bitmapDrawable = BitmapDrawable(resources, baseConfig.storedBitmap)
//                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
//                binding.mainLayout.background = drawable
//            }
//        }

        updateTextColors(binding.mainLayout)
        binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

//        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
        if (baseConfig.backgroundColor.equals(Color.BLACK)) {
            //  binding.llBottomAction.background = ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
            try {
                binding.llBottomAction.setBackgroundColor(
                    ContextCompat.getColor(
                        binding.root.context,
                        R.color.bottom_tabs_black_background_new
                    )
                )
            } catch (e: Exception) {

            }


            arrayListOf(
                binding.ivBack,
                binding.ivDelete,
                binding.ivMore,
                binding.ivArchive,
                binding.ivRead,
                binding.ivBlock
            ).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.white)
                val colorStateList = ColorStateList.valueOf(Color.WHITE)
                it.imageTintList = colorStateList
            }
        } else {
            try {
                binding.llBottomAction.background = ColorDrawable(baseConfig.statusBarColor)
            } catch (e: Exception) {
            }


            arrayListOf(
                binding.ivBack,
                binding.ivDelete,
                binding.ivMore,
                binding.ivArchive,
                binding.ivRead,
                binding.ivBlock
            ).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.black)
                val colorStateList = ColorStateList.valueOf(getColor(R.color.iconColor))
                it.imageTintList = colorStateList
            }
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource != -1) {

//                binding.navView.setBackgroundColor(baseConfig.backgroundColor)
//                val bitmapDrawable = BitmapDrawable(resources, baseConfig.storedBitmap)
//                constraintLayout.background = bitmapDrawable
//                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
//                binding.mainLayout.background = drawable
//                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))

                if (baseConfig.storedImageResource == 111) {
                    val stringManager = StringManager(this)
                    val imageBitmap = stringManager.getSavedThemeBitmaps().last()
                    val drawable = BitmapDrawable(resources, imageBitmap)
                    binding.mainLayout.background = drawable
                    try {
                        toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
                    } catch (e: Exception) {
                    }
                } else {
                    val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                    binding.mainLayout.background = drawable
                    try {
                        toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
                    } catch (e: Exception) {
                    }
                }

                try {
                    val colorWithAlpha = baseConfig.primaryColor.addAlpha(0.8F)
                    binding.navView.background = ColorDrawable(colorWithAlpha)
                } catch (e: Exception) {
                }

//                val unselectedColor = ContextCompat.getColor(this, android.R.color.darker_gray) // Unselected color
                val states = arrayOf(
                    intArrayOf(android.R.attr.state_checked), // Selected state
                    intArrayOf(-android.R.attr.state_checked) // Unselected state
                )

                val primaryColor = Color.parseColor("#FFFFFF")
                val colors = intArrayOf(
                    primaryColor, // Color for selected state
                    primaryColor // Color for unselected state
                )

                val colorStateList = ColorStateList(states, colors)
                binding.navView.itemIconTintList = colorStateList
                binding.navView.setItemColors(primaryColor, primaryColor)
                // Log.e("MainActivity", "setUpTheme.navView.001")
                binding.navView.itemRippleColor =
                    ColorStateList.valueOf(primaryColor.addAlpha(0.08F))
                binding.navView.itemActiveIndicatorColor =
                    ColorStateList.valueOf(primaryColor.addAlpha(0.12F))

            }
        } else {
            binding.mainLayout.background = null
            val primaryColor = baseConfig.primaryColor
            try {
                binding.navView.setBackgroundColor(baseConfig.backgroundColor)
            } catch (e: Exception) {
            }
//            lloptionmenu.setBackgroundColor(baseConfig.backgroundColor)
            try {
                toolbar.setBackgroundColor(baseConfig.backgroundColor)
            } catch (e: Exception) {

            }

            val unselectedColor =
                ContextCompat.getColor(this, android.R.color.darker_gray) // Unselected color
            val states = arrayOf(
                intArrayOf(android.R.attr.state_checked), // Selected state
                intArrayOf(-android.R.attr.state_checked) // Unselected state
            )
            val colors = intArrayOf(
                primaryColor, // Color for selected state
                unselectedColor // Color for unselected state
            )

            if (baseConfig.backgroundColor.equals(Color.BLACK)) {
                val primaryColortext = Color.parseColor("#FFFFFF")
                val colorstext = intArrayOf(
                    primaryColortext, // Color for selected state
                    unselectedColor // Color for unselected state
                )
                val colorStateListtext = ColorStateList(states, colorstext)
                binding.navView.itemTextColor = colorStateListtext

            } else {
                val primaryColortext = Color.parseColor("#000000")
                val colorstext = intArrayOf(
                    primaryColortext, // Color for selected state
                    unselectedColor // Color for unselected state
                )
                val colorStateListtext = ColorStateList(states, colorstext)
                binding.navView.itemTextColor = colorStateListtext

            }

            val colorStateList = ColorStateList(states, colors)
            binding.navView.itemIconTintList = colorStateList
//            binding.navView.setItemColors(primaryColor, unselectedColor)
            // Log.e("MainActivity", "setUpTheme.navView.002")
            binding.navView.itemRippleColor = ColorStateList.valueOf(primaryColor.addAlpha(0.08F))
            binding.navView.itemActiveIndicatorColor =
                ColorStateList.valueOf(primaryColor.addAlpha(0.12F))
        }

    }

    private fun initListener() {

        binding.navView.setOnNavigationItemSelectedListener { item ->
            lastSelectedTab = item.itemId
            when (item.itemId) {
                R.id.messageFragment -> {


                    binding.messageTab.toolbarSearch.text =
                        Editable.Factory.getInstance().newEditable(" ")

                    binding.contactTab.searchContact.text =
                        Editable.Factory.getInstance().newEditable(" ")

                    setTitle(R.string.messages)

                    itemMore?.isVisible = true
                    actionSearchMenu?.isVisible = true
                    actionContactSearch?.isVisible = false

                    binding.searchView.closeSearch(true)
                    binding.messageTab.toolbarSearch.text = null
                    binding.contactTab.searchContact.text = null
                    binding.searchContactView.closeSearch(true)

                    binding.searchContactView.visibility = View.GONE
                    binding.searchView.visibility = View.GONE


                    binding.viewFlipper.displayedChild = 0
//                    binding.navView.selectedItemId = R.id.messageFragment

                    firebaseAnalyticsHandler.logMessages(
                        app_click_on_sms_menu, getActivityName()
                    )

                    true

                }

                R.id.contactFragment -> {
                    firebaseAnalyticsHandler.logMessages(
                        app_click_on_contact_menu, getActivityName()
                    )
                    navigator.showCompose()
//                    binding.messageTab.compose.performClick()
                    /*
                                        binding.messageTab.toolbarSearch.text =
                                            Editable.Factory.getInstance().newEditable(" ")

                                        binding.contactTab.searchContact.text =
                                            Editable.Factory.getInstance().newEditable(" ")

                                        itemMore?.isVisible = false
                                        setTitle(R.string.contacts)
                                        binding.searchView.closeSearch(true)
                                        binding.messageTab.toolbarSearch.text = null
                                        binding.contactTab.searchContact.text = null
                                        binding.searchContactView.closeSearch(true)

                                        binding.searchContactView.visibility = View.GONE
                                        binding.searchView.visibility = View.GONE

                                        binding.viewFlipper.displayedChild = 1
                    //                    binding.navView.selectedItemId = R.id.contactFragment


                                        actionSearchMenu?.isVisible = false
                                        actionContactSearch?.isVisible = true


                                        firebaseAnalyticsHandler.logMessages(
                                            app_click_on_contact_menu, getActivityName()
                                        )*/



                    false
                }

                R.id.personalizeFragment -> {


                    binding.messageTab.toolbarSearch.text =
                        Editable.Factory.getInstance().newEditable(" ")

                    binding.contactTab.searchContact.text =
                        Editable.Factory.getInstance().newEditable(" ")

                    itemMore?.isVisible = false
                    binding.searchView.closeSearch(true)
                    binding.messageTab.toolbarSearch.text = null
                    binding.contactTab.searchContact.text = null
                    binding.searchContactView.closeSearch(true)
                    actionSearchMenu?.isVisible = false
                    actionContactSearch?.isVisible = false

                    binding.searchContactView.visibility = View.GONE
                    binding.searchView.visibility = View.GONE
                    setTitle(R.string.personalize)
                    binding.viewFlipper.displayedChild = 2
//                    binding.navView.selectedItemId = R.id.personalizeFragment
                    firebaseAnalyticsHandler.logMessages(
                        app_click_on_personalize_menu, getActivityName()
                    )
                    true
                }

                R.id.settingFragment -> {


                    binding.messageTab.toolbarSearch.text =
                        Editable.Factory.getInstance().newEditable(" ")

                    binding.contactTab.searchContact.text =
                        Editable.Factory.getInstance().newEditable(" ")

                    itemMore?.isVisible = false
                    EventBus.getDefault().post(MessageEvent(SETTING_OPEN))

                    binding.searchContactView.visibility = View.GONE
                    binding.searchView.visibility = View.GONE


                    binding.searchView.closeSearch(true)
                    binding.messageTab.toolbarSearch.text = null
                    binding.contactTab.searchContact.text = null
                    binding.searchContactView.closeSearch(true)
                    actionSearchMenu?.isVisible = false
                    actionContactSearch?.isVisible = false

                    setTitle(R.string.settings)
                    binding.viewFlipper.displayedChild = 3
//                    binding.navView.selectedItemId = R.id.settingFragment

                    firebaseAnalyticsHandler.logMessages(
                        app_click_on_setting_menu, getActivityName()
                    )
                    true
                }

                else -> false
            }
        }

        binding.messageTab.recyclerView.post {

            FastScroller(binding.messageTab.dragHandle, object : BubbleListener {
                override fun setBubbleText(str: String) {
//                    Log.e("FastScroller", "setBubbleText:$str")
                }

                override fun setViewY(y: Float, isMovedByHandleDrag: Boolean) {
                    //  binding.messageTab.messageBubble.y = y
//                    Log.e("FastScroller", "setViewY:$y,isMovedByHandleDrag:$isMovedByHandleDrag")

                    val firstPosition =
                        (binding.messageTab.recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                    val lastPosition =
                        (binding.messageTab.recyclerView.layoutManager as LinearLayoutManager).findLastVisibleItemPosition()

//                    Log.e("FastScroller", "lastPosition:$lastPosition,itemCount:${conversationsAdapter.itemCount}")
//                    if (lastPosition >= conversationsAdapter.itemCount - 2) {
////                        if(isMovedByHandleDrag)
//                        binding.messageTab.messageBubble.beGone()
////                        binding.messageTab.scrollToEnd.beGone()
////                        binding.scrollToEnd.beVisible()
//                    } else {
//                        val str = conversationsAdapter.getBubbleText(firstPosition)
//                        if (str.isNotEmpty()) binding.messageTab.bubbleText.text = str
//                        if (isMovedByHandleDrag) binding.messageTab.messageBubble.beVisible()
//                        else binding.messageTab.messageBubble.beGone()
//
////                        binding.messageTab.scrollToEnd.beVisible()
////                        binding.scrollToEnd.beGone()
//                    }
                }

                override fun setVisible(isVisible: Boolean) {
//                    Log.e("FastScroller", "setVisible:$isVisible")
                }
            }).bind(binding.messageTab.recyclerView)


        }

//        binding.messageTab.snackbar.llDefault.background = backgroundchange()


        /*   binding.ivCaller.setOnClickListener {
               *//*  val intent = Intent(this@MainActivity, SettingsActivity::class.java)
              startActivity(intent)*//*

            if (!Settings.canDrawOverlays(this@MainActivity)) {
                permissiondialog()
            }

        }*/


        binding.ivBack.setOnClickListener {
            backPressedSubject.onNext(NavItem.BACK)
            setTitle(R.string.messages)
            showBackButton(false)
            if (binding.ivSelect.isSelected) {
                binding.ivSelect.isSelected = !binding.ivSelect.isSelected
            }
        }
        binding.ivSelect.setOnClickListener {
            //     conversationsAdapter.toggleSelectAll(true)
            binding.ivSelect.isSelected = !binding.ivSelect.isSelected

            // Based on the checkbox's state, call the appropriate function
            if (binding.ivSelect.isSelected) {
                conversationsAdapter.toggleSelectAll(true)
                binding.ivSelect.setTint(baseConfig.primaryColor)
            } else {
                conversationsAdapter.toggleSelectAll(false)
                binding.ivSelect.setTint(getColor(R.color.iconColor))
            }
        }

        binding.messageTab.goToTopButton.setOnClickListener {
            scrollToTop()

        }
//        binding.messageTab.snackbar.ivClose.setOnClickListener {
//
//
//            config.snackBarClosedTimestamp = System.currentTimeMillis()
//            isAppOpenFlag = false
//            binding.messageTab.snackbar.root.isVisible = false
//        }
        binding.messageTab.archived.setOnClickListener {
            startActivity(Intent(this@MainActivity, ArchiveActivity::class.java))
        }
        binding.llDelete.setOnClickListener {
            optionsItemIntent.onNext(R.id.delete)
        }
        binding.llArchiveTab.setOnClickListener {
            optionsItemIntent.onNext(R.id.archive)
        }
        binding.llMarkRead.setOnClickListener {
            optionsItemIntent.onNext(R.id.read)
        }
        binding.llBlock.setOnClickListener {
            optionsItemIntent.onNext(R.id.block)
        }
        binding.llMore.setOnClickListener {
            val wrapper = if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
                ContextThemeWrapper(this@MainActivity, R.style.CustomPopUpStyleBlack)
            } else {
                ContextThemeWrapper(this@MainActivity, R.style.CustomPopUpStyle)
            }

            val popupMenu = PopupMenu(wrapper, binding.llMore)

            // Inflating popup menu from popup_menu.xml file
            popupMenu.menuInflater.inflate(R.menu.desktop_menu, popupMenu.menu)

            val menu = popupMenu.menu

//                menu.findItem(R.id.archive)?.isVisible = currentPage is Inbox && selectedConversations != 0
//                menu.findItem(R.id.read)?.isVisible = markRead && selectedConversations != 0
//                menu.findItem(R.id.block)?.isVisible = selectedConversations != 0
//                menu.findItem(R.id.delete)?.isVisible = selectedConversations != 0
            menu.findItem(R.id.unarchive)?.isVisible =
                currentPage is Archived && selectedConversations != 0
            menu.findItem(R.id.add)?.isVisible = addContact && selectedConversations != 0
            menu.findItem(R.id.pin)?.isVisible = markPinned && selectedConversations != 0
            menu.findItem(R.id.unpin)?.isVisible = !markPinned && selectedConversations != 0
            menu.findItem(R.id.unread)?.isVisible = !markRead && selectedConversations != 0
            menu.findItem(R.id.unread)?.isVisible = selectedConversations != 0
            menu.findItem(R.id.privatebox)?.isVisible = selectedConversations != 0


            popupMenu.setOnMenuItemClickListener { menuItem ->

                when (menuItem.itemId) {
                    R.id.unarchive -> {
                        optionsItemIntent.onNext(R.id.unarchive)
                    }

                    R.id.add -> {
                        optionsItemIntent.onNext(R.id.add)
                    }

                    R.id.pin -> {
                        optionsItemIntent.onNext(R.id.pin)
                    }

                    R.id.unpin -> {
                        optionsItemIntent.onNext(R.id.unpin)
                    }

                    R.id.unread -> {
                        optionsItemIntent.onNext(R.id.unread)
                    }

                    R.id.privatebox -> {
                        optionsItemIntent.onNext(R.id.privatebox)
                    }
                }
                true
            }

            // Showing the popup menu
            popupMenu.show()


        }

        binding.messageTab.compose.setOnLongClickListener { view ->
            // Handle the long-click event here

            if (baseConfig.hideEntranceSwitchStatus) {
                startActivity(Intent(this, PasswordActivity::class.java))
            }
            true
        }


        binding.messageTab.snackbar.btnSetDefault.setOnClickListener {

            navigator.showPermissionScreen(permissionManager, this)

        }



    }

    fun backgroundchange(): GradientDrawable {
        val drawable = GradientDrawable()
        drawable.shape = GradientDrawable.RECTANGLE
        //    val colorWithOpacity = baseConfig.primaryColor
        val colorWithOpacity = Color.parseColor("#FFF5E7")

//        val colorWith20Opacity =
//            colorWithOpacity?.let { ColorUtils.setAlphaComponent(it, 20) } // 51 is 20% of 255

        if (colorWithOpacity != null) {
            drawable.setColor(colorWithOpacity)
        }
        val strokeWidthInDp = 1.0f
        val strokeWidthInPixels =
            (strokeWidthInDp * resources?.displayMetrics!!.density + 0.5f).toInt()
        baseConfig.let { drawable.setStroke(strokeWidthInPixels, Color.parseColor("#F37B24")) }
        val cornerRadius = resources?.getDimension(R.dimen.small_text_size)
        if (cornerRadius != null) {
            drawable.cornerRadius = cornerRadius
        }
        return drawable
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.run(onNewIntentIntent::onNext)
    }

    var addContact = false
    var markPinned = false
    var markRead = false
    var selectedConversations = 0
    var currentPage: MainPage = Inbox()
    override fun render(state: MainState) {

        if (state.hasError) {
            // Log.e("render", "MainActivity:render.hasError:${state.hasError}")
            finish()
            return
        }

        syncingCurrentTime = System.currentTimeMillis()

        if (state.selectedContact != null && !phoneNumberDialog.isShowing) {
            phoneNumberAdapter.data = state.selectedContact.numbers
            phoneNumberDialog.subtitle = state.selectedContact.name

            phoneNumberDialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
            phoneNumberDialog.show()
        } else if (state.selectedContact == null && phoneNumberDialog.isShowing) {
            phoneNumberDialog.dismiss()
        }
        currentPage = state.page
        addContact = when (state.page) {
            is Inbox -> state.page.addContact
            is Archived -> state.page.addContact
            else -> false
        }

        markPinned = when (state.page) {
            is Inbox -> state.page.markPinned
            is Archived -> state.page.markPinned
            else -> false
        }

        markRead = when (state.page) {
            is Inbox -> state.page.markRead
            is Archived -> state.page.markRead
            else -> true
        }

        selectedConversations = when (state.page) {
            is Inbox -> state.page.selected
            is Archived -> state.page.selected
            else -> 0
        }

//        binding.toolbarSearch.setVisible(state.page is Inbox && state.page.selected == 0 || state.page is Searching)
//        binding.toolbarTitle.setVisible(binding.toolbarSearch.visibility != View.VISIBLE)
//        binding.toolbar.menu.findItem(R.id.selectAll)?.isVisible = selectedConversations != 0
        binding.ivSelect.beVisibleIf(selectedConversations != 0)

        if (binding.navView.selectedItemId == R.id.messageFragment) {
            actionSearchMenu?.isVisible = selectedConversations == 0
        }

//        if (selectedConversations != 0) {
//            val layoutManager = binding.messageTab.recyclerView.layoutManager as? LinearLayoutManager
//            val isVisible = (layoutManager?.findFirstCompletelyVisibleItemPosition()!! > 5)
//            binding.messageTab.goToTopButton.visibility =
//                if (isVisible) {
//                    View.VISIBLE
//                } else {
//                    View.GONE
//                }
//        }

//        binding.toolbar.menu.findItem(R.id.unarchive)?.isVisible = state.page is Archived && selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.archive)?.isVisible = state.page is Inbox && selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.delete)?.isVisible = selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.add)?.isVisible = addContact && selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.pin)?.isVisible = markPinned && selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.unpin)?.isVisible = !markPinned && selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.read)?.isVisible = markRead && selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.unread)?.isVisible = !markRead && selectedConversations != 0
//        binding.toolbar.menu.findItem(R.id.block)?.isVisible = selectedConversations != 0

//        listOf(binding.drawer.plusBadge1, binding.drawer.plusBadge2).forEach { badge ->
//            badge.isVisible = drawerBadgesExperiment.variant && !state.upgraded
//        }
//        plus.isVisible = state.upgraded
//        binding.drawer.plusBanner.isVisible = !state.upgraded
//        binding.drawer.rateLayout.setVisible(state.showRating)

//        binding.compose.setVisible(state.page is Inbox || state.page is Archived)
        searchAdapter.emptyView = binding.messageTab.empty.takeIf { state.page is Searching }

        when (state.page) {
            is Inbox -> {

                if (syncingCurrentTime - lastRunTimeInbox >= 300) {

                    if (state.page.archiveMessages > 0) {
                        binding.messageTab.llArchive.beVisible()
                        binding.messageTab.llArchive.layoutParams = CoordinatorLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                        binding.messageTab.archiveCount.text = state.page.archiveMessages.toString()
                    } else {
                        binding.messageTab.llArchive.layoutParams.height = 0
                        binding.messageTab.llArchive.beVisible() // Assuming beGone() hides the view
                    }
//                binding.messageTab.llArchive.isVisible = (state.page.archiveMessages ?: 0) > 0


//                binding.messageTab.llArchive.layoutParams = CoordinatorLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
                    binding.messageTab.compose.beVisible()
                    binding.navView.beVisible()
//                showBackButton(false)
//                binding.messageTab.toolbar.setNavigationIcon(null)
//                title = getString(R.string.main_title_selected, state.page.selected)
//                setTitle(getString(R.string.main_title_selected, state.page.selected))
                    if (state.page.selected > 0) {
//                    setTitle(getString(R.string.main_title_selected, state.page.selected))
                        binding.actionbarTitle.text =
                            getString(R.string.main_title_selected, state.page.selected)

                        setCommonData(
                            showBottomAction = true
                        )
                    } else {
                        setCommonData(
                            showBottomAction = false
                        )
                        // title = getString(R.string.messages)
                    }

                    if (isFirstTimeLog()) {
                        if (logCount == 0) {
                            firebaseAnalyticsHandler.logMessages(
                                data_set_in_activity_200, getActivityName()
                            )
                            logCount++
                        } else if (logCount == 1) {
                            AdsPreferences(this).firstLog++
                            firebaseAnalyticsHandler.logMessages(
                                data_set_in_activity, getActivityName()
                            )
                            logCount++
                            setEventForTotalConversations()
                        }
                    }

                    lastRunTimeInbox = syncingCurrentTime

                    if (dataLoading == true) {
                        val currentTime = System.currentTimeMillis()
                        if (currentTime - lastUpdateTime >= 3000) { // Check if at least 5 seconds have passed
                            runOnUiThread {

                                setConversationAdapter(
                                    state.page.data,
                                    state.page.selected > 0,
                                    R.string.inbox_empty_text,
                                    true
                                )
                            }
                            lastUpdateTime = currentTime // Update the last update time
                        }
                    } else {
//                        Log.e("Message_Log", "setConversationAdapter.002")

                        setConversationAdapter(
                            state.page.data,
                            state.page.selected > 0,
                            R.string.inbox_empty_text,
                            true
                        )
                    }
                }

                if (state.page.data != null && !isAdapterSet) {
                    setConversationAdapter(
                        state.page.data,
                        state.page.selected > 0,
                        R.string.inbox_empty_text,
                        true
                    )
                    isAdapterSet = true

                }

                val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                val alreadyCalled = prefs.getBoolean("called_old_blocked_list", false)
                if (!alreadyCalled) {
                    getOldBlockedList()
                    prefs.edit().putBoolean("called_old_blocked_list", true).apply()
                }

            }

            is Searching -> {
//                Log.e("Message_Log", "Searching: ")
//                showBackButton(false)
//                binding.messageTab.toolbar.setNavigationIcon(null)


                if (binding.messageTab.recyclerView.adapter !== searchAdapter) binding.messageTab.recyclerView.adapter =
                    searchAdapter
                searchAdapter.data = state.page.data ?: listOf()
                itemTouchHelper.attachToRecyclerView(null)
                binding.messageTab.emptyText.setText(R.string.inbox_search_empty_text)
            }

            is Archived -> {

                if (syncingCurrentTime - lastRunTimeArchived >= 200) {

                    try {

                        binding.messageTab.compose.beGone()
                        binding.navView.beGone()
//                title = when (state.page.selected != 0) {
//                    true -> getString(R.string.main_title_selected, state.page.selected)
//                    false -> getString(R.string.title_archived)
//                }
                        when (state.page.selected != 0) {
                            true -> {
//                        getString(R.string.main_title_selected, state.page.selected)
                                setCommonData(
                                    showBottomAction = true
                                )
//                        setTitle(getString(R.string.main_title_selected, state.page.selected))
                                binding.actionbarTitle.text =
                                    getString(R.string.main_title_selected, state.page.selected)
                            }

                            false -> {
                                setCommonData(
                                    showBottomAction = false
                                )
                                title = getString(R.string.title_archived)
                            }
                        }

                        setConversationAdapter(
                            state.page.data,
                            true,
                            R.string.archived_empty_text,
                            false
                        )

                    } catch (_: Exception) {
                    }

                    lastRunTimeArchived = syncingCurrentTime
                }

            }

            else -> {
            }
        }
        when (state.contact) {
            is ContactPage -> {

                if (syncingCurrentTime - lastRunTimeContactPage >= 100) {

                    try {
                        contacts = ArrayList(state.composeItems)
                        recentContacts = ArrayList(state.composeRecentItems)
                        contactGroups = ArrayList(state.composeGroupItems)
                        EventBus.getDefault().post(MessageEvent(UPDATE_ALL_CONTACT))
                    } catch (_: Exception) {
                    }

                    lastRunTimeContactPage = syncingCurrentTime
                }

            }

            else -> {}
        }

//        binding.drawer.inbox.isActivated = state.page is Inbox
//        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START) && !state.drawerOpen) {
//            binding.drawerLayout.closeDrawer(GravityCompat.START)
//        } else if (!binding.drawerLayout.isDrawerVisible(GravityCompat.START) && state.drawerOpen) {
//            binding.drawerLayout.openDrawer(GravityCompat.START)
//        }

        when (state.syncing) {
            is SyncRepository.SyncProgress.Idle -> {


                if (syncingCurrentTime - lastRunTimeIdle >= 200) {

                    binding.messageTab.syncing.root.isVisible = false
                    /*  binding.messageTab.snackbar.root.isVisible =
                              !state.defaultSms || !state.smsPermission || !state.contactPermission || !state.notificationPermission*/


                    if (ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.READ_SMS
                        ) == PackageManager.PERMISSION_GRANTED &&
                        ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.READ_CONTACTS
                        ) == PackageManager.PERMISSION_GRANTED
                    ) {
                        if (!config.firstTimeLoadData) {
                            config.firstTimeLoadData = true
                            delayExecution(1000) {
                                val activeTabId = binding.navView.selectedItemId
                                if (activeTabId == R.id.messageFragment) {
                                    Log.e(
                                        "fdddddddddddd",
                                        "Required permissions are not granted"
                                    )
                                    binding.navView.setSelectedItemId(R.id.messageFragment)
                                }
                            }
                        }

                        lastRunTimeIdle = syncingCurrentTime
                    }
                    dataLoading = false


                }

            }

            is SyncRepository.SyncProgress.Running -> {
                if (syncingCurrentTime - lastRunTimeSyncProgress >= 200) {
                    binding.messageTab.syncing.root.isVisible = true
                    binding.messageTab.syncing.syncingProgress.max = state.syncing.max
                    progressAnimator.apply {
                        setIntValues(
                            binding.messageTab.syncing.syncingProgress.progress,
                            state.syncing.progress
                        )
                    }.start()
                    binding.messageTab.syncing.syncingProgress.isIndeterminate =
                        state.syncing.indeterminate
//                binding.messageTab.snackbar.root.isVisible = false
                    dataLoading = true
                    lastRunTimeSyncProgress = syncingCurrentTime
                }
            }
        }
//        val applyBackground = ResourcesCompat.getDrawable(
//            resources,
//            R.drawable.ads_item_gradiant_rounded,
//            null
//        ) as LayerDrawable
//        val strokeDrawable =
//            applyBackground.findDrawableByLayerId(R.id.button_background_ads) as GradientDrawable
//        strokeDrawable.setStroke(2, Color.parseColor("#F37B24"))
        when {
            !state.defaultSms -> {
                if (syncingCurrentTime - lastRunTimeSefaultSms >= 100) {

                    binding.messageTab.snackbar.snackbarTitle.setText(R.string.main_default_sms_title)
                    binding.messageTab.snackbar.snackbarMessage.setText(R.string.main_default_sms_message_new)
                    binding.messageTab.snackbar.btnSetDefault.setText(R.string.set_now)
//                binding.messageTab.snackbar.btnSetDefault.setTextColor(config.primaryColor)

//                binding.messageTab.snackbar.btnSetDefault.background = applyBackground
                    binding.messageTab.snackbar.llDefault.isVisible = !isDefaultSmsApp(this)

                    lastRunTimeSefaultSms = syncingCurrentTime
                }
            }

            !state.smsPermission -> {
                if (syncingCurrentTime - lastRunTimeSmsPermission >= 500) {

                    binding.messageTab.snackbar.snackbarTitle.setText(R.string.main_permission_required)
                    binding.messageTab.snackbar.snackbarMessage.setText(R.string.main_permission_sms)
                    binding.messageTab.snackbar.btnSetDefault.setText(R.string.main_permission_allow)
                    //    binding.messageTab.snackbar.btnSetDefault.setTextColor(config.primaryColor)

//                binding.messageTab.snackbar.btnSetDefault.background = applyBackground

                    lastRunTimeSmsPermission = syncingCurrentTime
                }

            }

            !state.contactPermission -> {

                if (syncingCurrentTime - lastRunTimeContactPermission >= 500) {

                    binding.messageTab.snackbar.snackbarTitle.setText(R.string.main_permission_required)
                    binding.messageTab.snackbar.snackbarMessage.setText(R.string.main_permission_contacts)
                    binding.messageTab.snackbar.btnSetDefault.setText(R.string.main_permission_allow)

                    lastRunTimeContactPermission = syncingCurrentTime
                }

                //     binding.messageTab.snackbar.btnSetDefault.setTextColor(config.primaryColor)

//                binding.messageTab.snackbar.btnSetDefault.background = applyBackground
            }

            !state.notificationPermission -> {

                runOnUiThread {


                    if (syncingCurrentTime - lastRunTimenotificationPermission >= 100) {

                        binding.messageTab.snackbar.snackbarTitle.setText(R.string.main_permission_required)
                        binding.messageTab.snackbar.snackbarMessage.setText(R.string.main_permission_notifications)
                        binding.messageTab.snackbar.btnSetDefault.setText(R.string.main_permission_allow)
                        //     binding.messageTab.snackbar.btnSetDefault.setTextColor(config.primaryColor)

                        lastRunTimenotificationPermission = syncingCurrentTime
                    }
                }

            }

        }

        runOnUiThread {

            if (syncingCurrentTime - lastRunTimeDefaultSms >= 2000) {

                binding.messageTab.snackbar.snackbarTitle.setText(R.string.main_default_sms_title)
                binding.messageTab.snackbar.snackbarMessage.setText(R.string.main_default_sms_message_new)
                binding.messageTab.snackbar.btnSetDefault.setText(R.string.set_now)

//                binding.messageTab.snackbar.llOverlay.isVisible = !Settings.canDrawOverlays(this)
                binding.messageTab.snackbar.llDefault.isVisible = !isDefaultSmsApp(this)
                if (isDefaultSmsApp(this) && Settings.canDrawOverlays(this)) {
                    binding.messageTab.snackbar.root.beGone()
//                    binding.messageTab.snackbar.ivClose.beGone()
                } else if (!isDefaultSmsApp(this)) {
                    if (isAppOpenFlag) {
                        binding.messageTab.snackbar.root.beVisible()
//                        binding.messageTab.snackbar.ivClose.beVisible()
                    }
                } else {
                    if (isTimestampFromPreviousDay(config.snackBarClosedTimestamp)) {
                        if (isAppOpenFlag) {
                            binding.messageTab.snackbar.root.beVisible()
//                            binding.messageTab.snackbar.ivClose.beVisible()
                        }
                    }
                }
                lastRunTimeDefaultSms = syncingCurrentTime


                if (binding.messageTab.snackbar.snackbarTitle.text.length > 23) {
                    binding.messageTab.snackbar.snackbarTitle.apply {
                        ellipsize = TextUtils.TruncateAt.MARQUEE
                        isFocusable = true
                        isFocusableInTouchMode = true
                        marqueeRepeatLimit = -1 // Infinite repeat
                        setHorizontallyScrolling(true)
                    }
                }
            }
        }
    }

    private fun getOldBlockedList() {
        val realm = Realm.getDefaultInstance()
        val blockedAddresses = getBlockedConversationAddresses(realm)

        blockedAddresses.forEach {
            println(it)
            Log.e("blockedAddresses", "blockedAddresses:  + $it")
            updateOldBlockedList(it)

        }
        realm.close()
    }

    private fun updateOldBlockedList(address: String) {
        val existingList = baseConfig.blockContactsList
        val finalList =
            ArrayList<messages.text.sms.feature.main.models.Contact>()
        Log.d("BlockScreen", "Existing blocked contacts: ${existingList.size}")

        if (!address.isNullOrEmpty()) {
            val normalizedPhone = address.replace("[^0-9]".toRegex(), "")

            val isAlreadyBlocked = existingList.any { contact ->
                val existingPhone = contact.phone?.replace("[^0-9]".toRegex(), "")
                existingPhone == normalizedPhone
            }

            Log.d(
                "BlockScreen",
                "Normalized phone: $normalizedPhone, Already blocked: $isAlreadyBlocked"
            )

            if (!isAlreadyBlocked) {

                val newContact = if (address.isNullOrEmpty()) {
                    messages.text.sms.feature.main.models.Contact(
                        address, address
                    )
                } else {
                    messages.text.sms.feature.main.models.Contact(
                        address, normalizedPhone
                    )
                }

                finalList.add(newContact)
            } else {
                Log.d("BlockScreen", "Skipping already blocked contact: $normalizedPhone")
            }
        } else {
            Log.d("BlockScreen", "Address is empty or null, skipping contact")
        }


        for (item in finalList) {
            setBlock(item.phone ?: item.name ?: "", true)
        }

        Log.d("BlockScreen", "New contacts to add: ${finalList.size}")
        existingList.addAll(finalList)
        baseConfig.blockContactsList = existingList
    }

    /*    fun setBlock(phoneNumber: String, value: Boolean) {
            if (phoneNumber.isNullOrEmpty()) {
                val inputNumber = normalizeNumber(phoneNumber)


                Realm.getDefaultInstance().use { realm ->
                    realm.executeTransaction {
                        val conversations = realm.where(Conversation::class.java)
                            .findAll()

                        conversations.filter { it.recipients.size == 1 }.filter {
                            val title = it.recipients.getOrNull(0)?.contact
                            val normalizedTitle =
                                title?.numbers?.getOrNull(0)?.address?.let { normalizePhoneNumber(it) }
                                    ?: ""

                            val isMatch = normalizedTitle == inputNumber


                            isMatch
                        }.forEach {
                            it.isPrivate = false
                            it.archived = false
                            it.blocked = value
                            it.blockingClient = if (!value) null else 0
                            it.blockReason = if (!value) null else ""

                        }
                    }

                    realm.close()
                }
            }

        }*/

    fun setBlock(phoneNumber: String, value: Boolean) {
        val inputNumber = normalizeNumber(phoneNumber)
        val thredId = ReConstant.getThreadId(this, phoneNumber)

        updateConversationByThreadId(thredId, value)
        /*  Realm.getDefaultInstance().use { realm ->
              realm.executeTransaction {
                  val conversations = realm.where(Conversation::class.java)
                      .findAll()

                  conversations.filter { it.recipients.size == 1 }.filter {
                      val title = it.recipients.getOrNull(0)?.contact
                      val normalizedTitle =
                          title?.numbers?.getOrNull(0)?.address?.let { normalizePhoneNumber(it) }
                              ?: ""

                      val isMatch = normalizedTitle == inputNumber


                      isMatch
                  }.forEach {
                      it.isPrivate = false
                      it.archived = false
                      it.blocked = value
                      it.blockingClient = if (!value) null else 0
                      it.blockReason = if (!value) null else ""

                  }
              }

              realm.close()
          }*/
    }

    fun updateConversationByThreadId(threadID: Long, value: Boolean) {
        Realm.getDefaultInstance().use { realm ->
            realm.executeTransaction {
                val conversation = realm.where(Conversation::class.java)
                    .equalTo("id", threadID)
                    .findFirst()

                conversation?.apply {
                    isPrivate = false
                    archived = false
                    blocked = value
                    blockingClient = if (!value) null else 0
                    blockReason = if (!value) null else ""
                }
            }
            realm.close()
        }
    }

    fun normalizeNumber(phoneNumber: String): String {

        return if (phoneNumber.matches(Regex("^[\\d+()\\s-]+$")) || phoneNumber.length > 5) {
            normalizePhoneNumber(phoneNumber)
        } else {
            phoneNumber
        }
    }

    fun normalizePhoneNumber(phoneNumber: String): String {
        val trimmed = phoneNumber.trim()

        // If input contains letters or dash, return as-is
        if (trimmed.any { it.isLetter() } || trimmed.contains("-")) {
            return trimmed
        }

        // Extract only digits
        val digits = trimmed.replace("[^0-9]".toRegex(), "")

        // Handle leading 0 or country code (like +91)
        return when {
            digits.length == 10 -> digits
            digits.length > 10 -> digits.takeLast(10)
            else -> digits // return whatever is left if less than 10 digits
        }
    }


    private var syncingCurrentTime = 0L
    private var lastRunTimeDefaultSms = 0L
    private var lastRunTimenotificationPermission = 0L
    private var lastRunTimeIdle = 0L
    private var lastRunTimeSyncProgress = 0L
    private var lastRunTimeSefaultSms = 0L
    private var lastRunTimeSmsPermission = 0L
    private var lastRunTimeContactPermission = 0L
    private var lastRunTimeInbox = 0L
    private var lastRunTimeArchived = 0L
    private var lastRunTimeContactPage = 0L
    private fun setEventForTotalConversations() {
        val conversationCount = conversationsAdapter.itemCount
        val logMessage = when (conversationCount) {
            in 0..1000 -> "app_conversations_counts : 0-1000"
            in 1001..2000 -> "app_conversations_counts : 1000-2000"
            in 2001..3000 -> "app_conversations_counts : 2000-3000"
            in 3001..4000 -> "app_conversations_counts : 3000-4000"
            in 4001..5000 -> "app_conversations_counts : 4000-5000"
            in 5001..10000 -> "app_conversations_counts : 5000-10000"
            in 10001..Int.MAX_VALUE -> "app_conversations_counts : 10000+"
            else -> {
                // Handle unexpected negative values
                // Log.e( "ConversationCount","Unexpected negative conversation count: $conversationCount")
                "app_conversations_counts : error" // Send a specific error message to Analytics
            }
        }
        firebaseAnalyticsHandler.logMessages(logMessage, getActivityName())


        Log.d("ConversationCount", "Total SMS: " + conversationsAdapter.getList().size)

    }

    private fun scrollToTop() {

        binding.messageTab.recyclerView.scrollToPosition(0)
        binding.messageTab.goToTopButton.visibility = View.GONE
    }

    private fun setCommonData(
        showBottomAction: Boolean,
    ) {
        if (showBottomAction) {
            binding.mainToolbar.beGone()
            binding.actionToolbar.beVisible()
            binding.llBottomAction.beVisible()
            binding.navView.beGone()
        } else {
            binding.mainToolbar.beVisible()
            binding.actionToolbar.beGone()
            binding.llBottomAction.beGone()
            binding.navView.beVisible()
        }
    }

    private fun setConversationAdapter(
        data: RealmResults<Conversation>?,
        backVisible: Boolean,
        inboxEmptyText: Int,
        isTouchHelper: Boolean,
    ) {


        if (data != null && data.hashCode() != conversationsAdapter.asyncListDiffer.currentList.hashCode()) {


            if (binding.messageTab.recyclerView.adapter !== conversationsAdapter) {
                binding.messageTab.recyclerView.apply {
                    adapter = conversationsAdapter
                }
            }
            binding.messageTab.recyclerView.itemAnimator = null
            conversationsAdapter.activity = this

            conversationsAdapter.currentActivity = javaClass.simpleName
            conversationsAdapter.updateData(data)
            itemTouchHelper.attachToRecyclerView(if (isTouchHelper) if (backVisible) null else binding.messageTab.recyclerView else null)
            binding.messageTab.emptyText.text = resources.getString(inboxEmptyText)
//            binding.messageTab.recyclerView.post {
            if (data.isEmpty() == true) {
                binding.messageTab.empty.visibility = View.GONE

            } else {
                binding.messageTab.empty.visibility = View.VISIBLE
            }
//            }

            itemTouchCallback.callbackSwipe = {
                itemTouchHelper.attachToRecyclerView(null)
                itemTouchHelper.attachToRecyclerView(if (isTouchHelper) if (backVisible) null else binding.messageTab.recyclerView else null)

            }
            showBackButton(backVisible)


        }
        /* else{
             if(conversationsAdapter.itemCount == 0){

               //  delayExecution(2000) {

                     if(data != null ){
                         Log.e("fddfdfdfdffdfdf","delayExecution(2000)")
                         binding.navView.setSelectedItemId(R.id.messageFragment)
 //                        conversationsAdapter.notifyDataSetChanged()
                     }
             //    }
             }
         }*/
    }


    fun callGetContactsDataWithCooldown() {
        /*  val currentTime = System.currentTimeMillis()
          val lastSync = baseConfig.lastContactSyncTime
          val cooldownMillis = 5000L

          val isCooldownOver = currentTime - lastSync >= cooldownMillis

          if (isCooldownOver) {
              baseConfig.lastContactSyncTime = currentTime

              lifecycleScope.launch {
                  try {
                      viewModel.getContactsDataAsync(this)
                  } catch (e: Exception) {
                      e.printStackTrace()
                  }
              }
          } else {
              Log.d("ContactSync", "Sync skipped: cooldown in progress.")
              // Just skip execution without returning
          }*/

        lifecycleScope.launch {
            try {
                viewModel.getContactsDataAsync(this)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }


    override fun onResume() {
        super.onResume()
        try {
            currentFocus?.clearFocus()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        callGetContactsDataWithCooldown()

        initListener()
        conversationsAdapter.activity = this
        conversationsAdapter.currentActivity = javaClass.simpleName
        activityResumedIntent.onNext(true)
        if (prefs.themechanged.get()) {

            runOnUiThread {
                prefs.themechanged.set(false)
                // Set the theme color tint to the recyclerView, progressbar, and FAB
                theme
                    .autoDisposable(scope())
                    .subscribe { theme ->
                        // Set the color for the drawer icons
                        val states = arrayOf(
                            intArrayOf(android.R.attr.state_activated),
                            intArrayOf(-android.R.attr.state_activated)
                        )

                        resolveThemeColor(android.R.attr.textColorSecondary)
                            .let { textSecondary ->
                                ColorStateList(
                                    states,
                                    intArrayOf(theme.theme, textSecondary)
                                )
                            }
                            .let { tintList ->
//                        binding.drawer.inboxIcon.imageTintList = tintList
                                //  binding.messageTab.archivedIcon.imageTintList = tintList
                            }

                        // Miscellaneous views
//                listOf(binding.drawer.plusBadge1, binding.drawer.plusBadge2).forEach { badge ->
//                    badge.setBackgroundTint(theme.theme)
//                    badge.setTextColor(theme.textPrimary)
//                }
                        binding.messageTab.syncing.syncingProgress.progressTintList =
                            ColorStateList.valueOf(theme.theme)
                        binding.messageTab.syncing.syncingProgress.indeterminateTintList =
                            ColorStateList.valueOf(theme.theme)
//                        binding.messageTab.compose.setBackgroundTint(theme.theme)
//                        binding.messageTab.compose.setTint(theme.textPrimary)

                        try {
                            binding.messageTab.compose.setBackgroundTint(baseConfig.primaryColor)
                        } catch (e: Exception) {
                        }

                        try {
                            binding.messageTab.compose.setTint(Color.parseColor("#FFFFFF"))
                        } catch (e: Exception) {
                        }

                    }

                setUpTheme()
                runOnUiThread {
                    conversationsAdapter.notifyDataSetChanged()
                }

            }

            //   updateStatusBarColor(getProperBackgroundColor())
        }



        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            if (alertDialogNoti?.isShowing == true) {
                alertDialogNoti?.dismiss()
                //  callerPermissionDialog()
            }
        }


//        if (Settings.canDrawOverlays(this)) {
//            binding.messageTab.snackbar.llOverlay.visibility = View.GONE
//        } else {
//            binding.messageTab.snackbar.llOverlay.visibility = View.VISIBLE
//        }

        EventBus.getDefault().post(MessageEvent(RESUME_MAIN))
        if (appPreference.isRefreshMessages) {
            appPreference.isRefreshMessages = false
            refreshArchive.onNext(Unit)
            refreshMessages.onNext(Unit)
        }

        if (mEnterScreen && !mOpenOverlayScreen) {
            maybeShowOverlayForOtpDialog()
        }

        // TO
// 1. First, determine if there is any reason at all to show the snackbar.
        val conditionsMetToShowSnackbar = !isDefaultSmsApp(this) || !Settings.canDrawOverlays(this)

        if (conditionsMetToShowSnackbar) {
            // 2. If yes, now check if we are allowed to show it based on the day.
            if (isTimestampFromPreviousDay(config.snackBarClosedTimestamp)) {
                // It's a new day (or it was never closed before), so show it.
                if (isAppOpenFlag) { // Respecting your existing flag
                    binding.messageTab.snackbar.root.beVisible()
//                    binding.messageTab.snackbar.ivClose.beVisible()
                }
            } else {
                // The user already closed it today, so force it to be hidden.

                if (isDefaultSmsApp(this) && Settings.canDrawOverlays(this)) {
                    binding.messageTab.snackbar.root.beGone()
//                    binding.messageTab.snackbar.ivClose.beGone()
                } else if (!isDefaultSmsApp(this)) {
                    if (isAppOpenFlag) {
                        binding.messageTab.snackbar.root.beVisible()
//                        binding.messageTab.snackbar.ivClose.beVisible()
                    }
                } else {
                    if (isTimestampFromPreviousDay(config.snackBarClosedTimestamp)) {
                        if (isAppOpenFlag) {
                            binding.messageTab.snackbar.root.beVisible()
//                            binding.messageTab.snackbar.ivClose.beVisible()
                        }
                    }
                }
            }
        } else {
            if (isDefaultSmsApp(this) && Settings.canDrawOverlays(this)) {
                binding.messageTab.snackbar.root.beGone()
//                binding.messageTab.snackbar.ivClose.beGone()
            } else if (!isDefaultSmsApp(this)) {
                if (isAppOpenFlag) {
                    binding.messageTab.snackbar.root.beVisible()
//                    binding.messageTab.snackbar.ivClose.beVisible()
                }
            } else {
                if (isTimestampFromPreviousDay(config.snackBarClosedTimestamp)) {
                    if (isAppOpenFlag) {
                        binding.messageTab.snackbar.root.beVisible()
//                        binding.messageTab.snackbar.ivClose.beVisible()
                    }
                }
            }
        }

        try {
            if (currentPoss != 0) {
                if (conversationsAdapter.itemCount > 0) {
                    conversationsAdapter.notifyItemChanged(currentPoss)
                    currentPoss = 0
                }
            }
        } catch (_: Exception) {

        }


        if (viewHomeScreen.equals("Schedule")) {
            viewHomeScreen = ""
            onBackPressed()
        }

        // EventBus.getDefault().post(MessageEvent(SYNC_MESSAGE))


        /*    val otp = "251555"
            //Log.e("SmsReceiver--------------", "NotificationManagerImpl - 88888 $otp ")
            if (otp.isNotEmpty()) {
                val title = "conversation.getTitle()"

                val recipients = arrayListOf<Recipient>(Recipient(0, "fdfdf", null, 0))
                val otpCode = "251555"
                val notificationOverlay = NotificationOverlay.getInstance(this)
                notificationOverlay.showOverlay(
                    context = this,
                    threadId = 20,
                    title = title,
                    recipients = recipients,
                    otp = otpCode
                )
            }*/

    }


    /*fun isDefaultSmsApp(context: Context): Boolean {


        val isDefaultSmsApp = Telephony.Sms.getDefaultSmsPackage(context) == context.packageName

        Log.d(
            "SMSAppCheck",
            "Default SMS Package: $isDefaultSmsApp, Current App: ${context.packageName}, Is Default: $isDefaultSmsApp"
        )

        return isDefaultSmsApp
    }*/

    fun isDefaultSmsApp(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(Context.ROLE_SERVICE) as? RoleManager
            roleManager?.isRoleHeld(RoleManager.ROLE_SMS) == true
        } else {
            Telephony.Sms.getDefaultSmsPackage(context) == context.packageName
        }
    }


    /* fun isDefaultSmsApp(context: Context): Boolean {
         val defaultSmsPackage = Telephony.Sms.getDefaultSmsPackage(context)
         val currentPackage = context.packageName

         if (defaultSmsPackage == null) {
             Log.w("SMSAppCheck", "Default SMS package is null on this device.")
             return false
         }

         val isDefault = currentPackage == defaultSmsPackage
         Log.d("SMSAppCheck", "Default SMS: $defaultSmsPackage, Current: $currentPackage, Is Default: $isDefault")
         return isDefault
     }*/


    override fun onPause() {
        super.onPause()
        activityResumedIntent.onNext(false)

    }

    override fun onDestroy() {
        super.onDestroy()
        disposables.dispose()
        if (EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().unregister(this)

        GoogleSmallNativeAdManagerHome.onDestroy()
        GoogleBannerAdManager.onDestroy()
        AdmobNative.clearNative()
    }

    override fun setTitle(titleId: Int) {
        //super.setTitle(titleId)
        binding.toolbarTitle.text = getString(titleId)
    }

    override fun setTitle(title: CharSequence?) {
        ///super.setTitle(title)
        binding.toolbarTitle.text = title
    }

    override fun showBackButton(show: Boolean) {

        if (show) {
            binding.mainToolbar.beGone()
            binding.actionToolbar.beVisible()
            binding.llBottomAction.beVisible()
            binding.navView.beGone()
        } else {
            binding.mainToolbar.beVisible()
            binding.actionToolbar.beGone()
            binding.llBottomAction.beGone()
            binding.navView.beVisible()
        }
//        super.showBackButton(show)
    }

    override fun requestDefaultSms() {
        navigator.showDefaultSmsDialog(this@MainActivity)
    }

    override fun requestPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }

        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 0)
    }

    override fun clearSearch() {
        dismissKeyboard()
        binding.messageTab.toolbarSearch.text = null
        binding.searchView.closeSearch(true)
    }


    override fun clearSelection() {
        conversationsAdapter.clearSelection()
    }


    override fun themeChanged() {
        binding.messageTab.recyclerView.scrapViews()
        EventBus.getDefault().post(MessageEvent(THEME_CHANGED))
    }

    override fun showBlockingDialog(conversations: List<Long>, block: Boolean) {
        blockingDialog.show(this, conversations, block)
    }

    override fun showDeleteDialog(conversations: List<Long>) {
        val count = conversations.size
        val dialog = AlertDialog.Builder(this, R.style.CustomFieldDialogTheme)
            .setTitle(R.string.dialog_delete_title)
            .setMessage(resources.getQuantityString(R.plurals.dialog_delete_message, count, count))
            .setPositiveButton(R.string.button_delete) { _, _ ->
                confirmDeleteIntent.onNext(conversations)
            }
            .setNegativeButton(R.string.button_cancel, null)
            .create()  // Use create() instead of show()

        dialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
        dialog.setOnShowListener {
            // Change the button text colors after the dialog is shown
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(
                baseConfig.primaryColor
            )
            try {
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                    ?.setTextColor(resources.getColor(R.color.black))
            } catch (e: Exception) {
            }
        }

        dialog.show()
    }

    override fun showArchivedSnackbar() {
        Snackbar.make(binding.messageTab.root, R.string.toast_archived, Snackbar.LENGTH_LONG)
            .apply {
                setAction(R.string.button_undo) { undoArchiveIntent.onNext(Unit) }
                setActionTextColor(colors.theme().theme)
                show()
                addCallback(object : Snackbar.Callback() {
                    override fun onDismissed(transientBottomBar: Snackbar?, event: Int) {
                        super.onDismissed(transientBottomBar, event)
                        refreshArchive.onNext(Unit)
                    }
                })
            }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.main_menu, menu)
        setupSearchView(menu)
        return true
    }


    var actionSearchMenu: MenuItem? = null

    var itemMore: MenuItem? = null
    var actionContactSearch: MenuItem? = null


    private fun setupSearchView(menu: Menu?) = with(binding) {
        actionSearchMenu = menu?.findItem(R.id.action_search)
        actionContactSearch = menu?.findItem(R.id.action_contact_search)
        actionSearchMenu?.isVisible = true
        actionContactSearch?.isVisible = false
        itemMore = menu?.findItem(R.id.item_more)
        searchView.setMenuItem(actionSearchMenu!!)
        searchContactView.setMenuItem(actionContactSearch!!)
        searchView.closeSearch(true)
        searchContactView.closeSearch(true)



        searchView.setOnQueryTextListener(object : SimpleSearchView.OnQueryTextListener {
            override fun onQueryTextChange(newText: String): Boolean {
//                Log.e(TAG, getString(R.string.changed, newText))

//                binding.messageTab.toolbarSearch.text = newText
                binding.messageTab.toolbarSearch.text =
                    Editable.Factory.getInstance().newEditable(newText)
                return false
            }

            override fun onQueryTextSubmit(query: String): Boolean {
//                Log.e(TAG, getString(R.string.submitted, query))
                return false
            }

            override fun onQueryTextCleared(): Boolean {
//                Log.e(TAG, getString(R.string.cleared))
                binding.messageTab.toolbarSearch.text =
                    Editable.Factory.getInstance().newEditable("")
                return false
            }
        })
        searchView.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {

                binding.messageTab.toolbarSearch.text =
                    Editable.Factory.getInstance().newEditable("")
            }
        }
        searchContactView.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {

                binding.contactTab.searchContact.text =
                    Editable.Factory.getInstance().newEditable("")
            }
        }

        searchContactView.setOnQueryTextListener(object : SimpleSearchView.OnQueryTextListener {
            override fun onQueryTextChange(newText: String): Boolean {

                binding.contactTab.searchContact.text =
                    Editable.Factory.getInstance().newEditable(newText)
                return false
            }

            override fun onQueryTextSubmit(query: String): Boolean {
                return false
            }

            override fun onQueryTextCleared(): Boolean {
                binding.contactTab.searchContact.text =
                    Editable.Factory.getInstance().newEditable("")
                return false
            }
        })

        // Adding padding to the animation because of the hidden menu item
//        val revealCenter = searchView.revealAnimationCenter
//        revealCenter!!.x -= convertDpToPx(40, this@MainActivity)

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                backPressedSubject.onNext(NavItem.BACK)
                setTitle(R.string.messages)
                showBackButton(false)
                true
            }

//            R.id.caller_disable -> {
//
//                if (!AutoStartHelper.isAutoStartSettingsAvailable(this)) {
//                    if (!Settings.canDrawOverlays(this@MainActivity)) {
//                        permissiondialog()
//                    } else {
//                        itemCallerDisable?.isVisible = false
//                    }
//                } else {
//
//                    if (ContextCompat.checkSelfPermission(
//                            this,
//                            Manifest.permission.READ_PHONE_STATE
//                        ) != PackageManager.PERMISSION_GRANTED
//                    ) {
//                        requestPhoneStatePermission()
//                    } else {
//
//                        if (!Settings.canDrawOverlays(this@MainActivity)) {
//                            permissiondialog()
//                        } else {
//                            itemCallerDisable?.isVisible = false
//                        }
//                    }
//                }
//
//                true
//            }

            R.id.item_more -> {
                moreDialog()
                true
            }


            else -> {
                optionsItemIntent.onNext(item.itemId)
                return true
            }
        }

    }

    private var lastBackPressTime: Long = 0


    var isRateClosed = false
    var isRateOpen = false

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {

        if (binding.navView.selectedItemId != R.id.messageFragment) {
            binding.navView.selectedItemId = R.id.messageFragment
            return
        }

        if (binding.searchView.isSearchOpen || binding.searchContactView.isSearchOpen) {
            binding.searchView.closeSearch(true)
            binding.searchContactView.closeSearch(true)
            binding.messageTab.toolbarSearch.text = null
            binding.contactTab.searchContact.text = null
            return
        }

        if (conversationsAdapter.isSelection()) {
            backPressedSubject.onNext(NavItem.BACK)
            setTitle(R.string.messages)
            showBackButton(false)

            if (binding.ivSelect.isSelected) {
                binding.ivSelect.isSelected = !binding.ivSelect.isSelected
            }

        } else {

            if (listOf(1, 3, 6, 9).contains(AdsPreferences(this).splashCounter)
                && !baseConfig.getBoolean(this, "RATE_US_DIALOG")
                && !isRateClosed && !isRateOpen
            ) {
                isRateOpen = true
                rateUsDialogMain()
            } else {
//                if (mNativeAd != null) {

                showExitDialog()
//                } else {
////                    backPressedSubject.onNext(NavItem.BACK)
//
//                    val currentTime = System.currentTimeMillis()
//                    if (currentTime - lastBackPressTime < 2000) {
//                        // Exit the app
//
//                        finishAffinity()
//                        System.exit(0)
//                    } else {
//                        lastBackPressTime = currentTime
//                        // Show toast message
//                        Toast.makeText(this, "Press again to exit", Toast.LENGTH_SHORT).show()
//                    }
//                }
            }


            /* if (!config.saveReview && !tempUpdate) {
                 tempUpdate = true

                 if (listOf(1, 3, 6, 9).contains(AdsPreferences(this).splashCounter)
                     && !baseConfig.getBoolean(this, "RATE_US_DIALOG")
                     && !isRateClosed && !isRateOpen
                 ) {
                     isRateOpen = true
                     rateUsDialog()
                 }
             } else {
                 if (mNativeAd != null) {

                     showExitDialog()
                 } else {
 //                    backPressedSubject.onNext(NavItem.BACK)

                     val currentTime = System.currentTimeMillis()
                     if (currentTime - lastBackPressTime < 2000) {
                         // Exit the app
                         backPressedSubject.onNext(NavItem.BACK)
                     } else {
                         lastBackPressTime = currentTime
                         // Show toast message
                         Toast.makeText(this, "Press again to exit", Toast.LENGTH_SHORT).show()
                     }
                 }
             }*/
        }
    }


    fun rateUsDialogMain() {
        val rateUsCheckBottomSheetDialog = RateUsCheckBottomSheetDialog()
        rateUsCheckBottomSheetDialog.show(supportFragmentManager, rateUsCheckBottomSheetDialog.tag)

        rateUsCheckBottomSheetDialog.btnClickListener = { action ->
            isRateClosed = true
            if (action == 0) {
                //startActivity(Intent(this, FeedBackActivity::class.java))
            } else if (action == 1) {
//                finishAffinity()
            } else if (action == 2) {
                isAdsNotShowOnResume = true
                showInAppRateDialog(this@MainActivity)
            }

        }

    }


    private fun maybeShowOverlayForOtpDialog() {
        if (listOf(3, 13, 23).contains(AdsPreferences(this).splashCounter)
            && !Settings.canDrawOverlays(this)
        ) {
            delayExecution(200) {
                mOpenOverlayScreen = true
                showOverlayForOtpDialog()
            }
        }

    }

    private fun showOverlayForOtpDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_otp_overlay)
        dialog.setCanceledOnTouchOutside(false)

        val llAllow = dialog.findViewById<LinearLayout>(R.id.llAllow)
        llAllow.setOnClickListener {

            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + packageName)
            )

            isAdsNotShowOnResume = true
            try {
                startActivityForResult(intent, REQUEST_DRAW_OVERLAYS_PERMISSION_OTP)
            } catch (e: Exception) {
            }

            dialog.dismiss()
        }


        val llDeny = dialog.findViewById<LinearLayout>(R.id.llDeny)
        llDeny.setOnClickListener {
            dialog.dismiss()
        }

        try {
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        } catch (e: Exception) {
        }
        dialog.window?.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        dialog.show()
    }


    private fun moreDialog() {
        val moreBottomSheetDialog = MoreBottomSheetDialog()
        moreBottomSheetDialog.show(supportFragmentManager, moreBottomSheetDialog.tag)

        moreBottomSheetDialog.btnClickListener = { action ->
            isRateClosed = true
            if (action == 0) {
                startActivity(Intent(this, ScheduledActivity::class.java))
            } else if (action == 1) {
                startActivity(Intent(this, BlockingActivity::class.java))
            } else if (action == 2) {
                // startActivity(Intent(this, AutoReplyActivity::class.java))
                toast(R.string.under_development)
            }

        }

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.type) {
            REFRESH_MESSAGE -> {


                delayExecution(100) {
                    viewModel.refreshMessages()
                    Log.e(
                        "onMessageEventX - 1",
                        "REFRESH_MESSAGE - " + conversationsAdapter.itemCount
                    )

                }

                if (!Utils.isDefaultSmsApp(this)) {
                    lifecycleScope.launch {
                        delay(1000) // wait 5 sec without blocking UI
                        if (conversationsAdapter.itemCount == 0) {
                            runOnUiThread {
                                viewModel.bindView(this@MainActivity)
                            }
                        }
                    }
                }

            }

            TEMP_REFRESH_MESSAGE -> {


                delayExecution(300) {
                    viewModel.refreshMessages()
                    Log.e(
                        "onMessageEventX - 2",
                        "REFRESH_MESSAGE - " + conversationsAdapter.itemCount
                    )
                }
            }

            REFRESH_CONTACT_GROUP -> {
                binding.contactTab.cancel.performClick()
            }

            THEME_CHANGED -> {
                binding.messageTab.recyclerView.scrapViews()
            }

            SYNC_MESSAGE -> {

                delayExecution(300) {
                    viewModel.forceRefreshMessages()
                }
            }

            REFRESH_ARCHIVE -> {

                delayExecution(300) {
                    refreshArchive.onNext(Unit)
                    appPreference.isRefreshMessages = true
                }
            }

            CLOSE_SEARCH -> {
                Log.e("CLOSE_SEARCH", "CLOSE_SEARCH")
                onBackPressed()
            }

            NEW_MSG_UPDATE_AVAILABLE -> {
                //  if(conversationsAdapter.itemCount > 0 && dataLoading == false){
                delayExecution(500) {
                    refreshMessages.onNext(Unit)
                }
                //    }
            }
        }

    }

    override fun clearQuery() {
        binding.contactTab.searchContact.text = null
        binding.contactTab.searchContact.text =
            Editable.Factory.getInstance().newEditable(" ")

        binding.searchContactView.closeSearch(true)
    }

    override fun refreshArchive() {
        refreshArchive.onNext(Unit)
    }

    override fun refreshBlockedList() {
        refreshBlocked.onNext(Unit)
    }

    override fun openKeyboard() {
        binding.contactTab.searchContact.postDelayed({
            binding.contactTab.searchContact.showKeyboard()
        }, 200)
    }

    override fun finish(result: HashMap<String, String?>) {

        binding.contactTab.searchContact.hideKeyboard()

        /*   if (clientConfigPref.showRemainAds) {
               MainInterAdManager.showGeneralInterAds(this, true) {
                   val intent =
                       Intent(this@MainActivity, ComposeActivity::class.java).putExtra(
                           ChipsKey,
                           result
                       )
                   startActivity(intent)
               }
           } else {
               val intent =
                   Intent(this@MainActivity, ComposeActivity::class.java).putExtra(ChipsKey, result)
               startActivity(intent)
           }*/

        val intent =
            Intent(this@MainActivity, ComposeActivity::class.java).putExtra(ChipsKey, result)
        startActivity(intent)


//        finish()
    }

    fun onContactClick(contact: ContactData) {
        composeItemPressedIntent.onNext(contact)
    }

    fun onContactLongClick(contact: ContactData) {
        composeItemLongPressedIntent.onNext(contact)
    }

    fun onContactGroupClick(contact: ContactGroup) {
        startActivity(
            Intent(this, GroupsActivity::class.java).putExtra("groupId", contact.id)
                .putExtra("groupName", contact.title)
        )
    }

    fun onContactGroupLongClick(contact: ContactGroup) {
    }

    private fun initContactView() {
        val adapter = ViewPagerAdapter(this, supportFragmentManager)
//        adapter.addFragment(RecentContactFragment())
        adapter.addFragment(AllContactFragment())
//        adapter.addFragment(ContactGroupFragment())

        binding.contactTab.viewPager.offscreenPageLimit = 3
        binding.contactTab.viewPager.adapter = adapter
        binding.contactTab.loutTab.beGone()

        val drawable = GradientDrawable()
        drawable.shape = GradientDrawable.RECTANGLE
        val colorWithOpacity = baseConfig.primaryColor

        val colorWith20Opacity =
            colorWithOpacity.let { ColorUtils.setAlphaComponent(it, 20) } // 51 is 20% of 255
        if (colorWith20Opacity != null) {
            drawable.setColor(colorWith20Opacity)
        }
        val strokeWidthInDp = 1.5f
        val strokeWidthInPixels =
            (strokeWidthInDp * resources?.displayMetrics!!.density + 0.5f).toInt()
        baseConfig.let { drawable.setStroke(strokeWidthInPixels, it.primaryColor) }
        val cornerRadius = resources?.getDimension(R.dimen.normal_text_size)
        if (cornerRadius != null) {
            drawable.cornerRadius = cornerRadius
        }

        binding.contactTab.loutTab.tabIndicator.indicatorDrawable = drawable
        binding.contactTab.loutTab.apply {
            observeIndexChange { fromIndex, toIndex, reselect, fromUser ->
                binding.contactTab.viewPager.currentItem = toIndex
            }
            tabLayoutConfig?.tabDeselectColor = baseConfig.textColor
            tabLayoutConfig?.tabSelectColor = baseConfig.textColor
        }

        binding.contactTab.viewPager.addOnPageChangeListener(object :
            ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {

            }

            override fun onPageSelected(position: Int) {
                binding.contactTab.loutTab.onPageSelected(position)

            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })

        /*    binding.messageTab.recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
             override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                 super.onScrollStateChanged(recyclerView, newState)
                 val layoutManager = recyclerView.layoutManager as? LinearLayoutManager
                 val isVisible = (layoutManager?.findFirstCompletelyVisibleItemPosition()!! > 10)
                 binding.messageTab.goToTopButton.visibility = if (isVisible) View.VISIBLE else View.GONE
             }
         })*/

        binding.messageTab.recyclerView.addOnScrollListener(object :
            RecyclerView.OnScrollListener() {

            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)

                val layoutManager = recyclerView.layoutManager as? LinearLayoutManager
                val isVisible = (layoutManager?.findFirstCompletelyVisibleItemPosition()!! > 5)
                binding.messageTab.goToTopButton.visibility =
                    if (isVisible) {
                        View.VISIBLE
                    } else {
                        View.GONE
                    }
            }
        })
    }

    class ViewPagerAdapter(val activity: Activity, fm: FragmentManager) :
        FragmentStatePagerAdapter(fm) {

        private val fragments = mutableListOf<Fragment>()


        fun addFragment(fragment: Fragment) {
            fragments.add(fragment)
            notifyDataSetChanged()
        }

        override fun getCount(): Int {
            return fragments.size
        }

        override fun getItem(position: Int): Fragment {
            return fragments[position]
        }
    }


//    override fun onAdRevenuePaid(impressionData: MaxAd) {
//        impressionData.let {
//            Firebase.analytics.logEvent(FirebaseAnalytics.Event.AD_IMPRESSION) {
//                param(FirebaseAnalytics.Param.AD_PLATFORM, "admob")
//                param(FirebaseAnalytics.Param.AD_UNIT_NAME, impressionData.adUnitId)
//                param(FirebaseAnalytics.Param.AD_FORMAT, impressionData.format.label)
//                param(FirebaseAnalytics.Param.AD_SOURCE, impressionData.networkName)
//                param(FirebaseAnalytics.Param.VALUE, impressionData.revenue)
//                param(
//                    FirebaseAnalytics.Param.CURRENCY,
//                    "USD"
//                ) // All Applovin revenue is sent in USD
//            }
//        }
//    }


    private fun launchEmail() {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "message/rfc822"
        i.putExtra(Intent.EXTRA_EMAIL, arrayOf("babymariagame@gmail.com"))
        i.putExtra(
            Intent.EXTRA_SUBJECT,
            "${getString(R.string.app_name)} ${getString(R.string.feedback)}"
        )
        i.putExtra(Intent.EXTRA_TEXT, "")
        i.setPackage("com.google.android.gm")

        try {
            startActivity(Intent.createChooser(i, "Send_mail"))
        } catch (_: ActivityNotFoundException) {
        }
    }


    private fun showInAppRateDialog(activity: Activity) {
        Log.e("RatingDialog", "showInAppRateDialog")
        val reviewManager = ReviewManagerFactory.create(activity)
        val activityRef = WeakReference(activity)
        val requestReview = reviewManager.requestReviewFlow()
        requestReview.addOnCompleteListener { task ->
            Log.e("RatingDialog", "showInAppRateDialog.task:${task.isSuccessful}")
            if (task.isSuccessful) {

                config.saveReview = true
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    showInAppRateDialogInternal(
                        reviewManager,
                        fragmentActivity,
                        task.result
                    )
                }
            } else {
                Log.e("RatingDialog", "showInAppRateDialog.exception:${task.exception}")
//                log.error(task.exception)
            }
        }
    }

    private fun showInAppRateDialogInternal(
        reviewManager: ReviewManager,
        activity: Activity,
        reviewInfo: ReviewInfo,
    ) {
        Log.e("RatingDialog", "showInAppRateDialogInternal")
        val reviewFlow = reviewManager.launchReviewFlow(activity, reviewInfo)
        val activityRef = WeakReference(activity)
        reviewFlow.addOnCompleteListener { task ->
            Log.e("RatingDialog", "showInAppRateDialogInternal.task:${task.isSuccessful}")
            if (task.isSuccessful) {
                activity.baseConfig.storeBoolean(activity, "RATE_US_DIALOG", true)

                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    launchAppStore()
                    Log.e("RatingDialog", "showInAppRateDialogInternal.RateUsState.IGNORED")
                }
            } else {
                Log.e("RatingDialog", "showInAppRateDialogInternal.exception:${task.exception}")
            }
        }
    }

    private fun launchAppStore() {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${packageName}")
        )
        startActivity(intent)
    }


    fun getBlockedConversationAddresses(realm: Realm): List<String> {
        val blockedConversations = realm.where(Conversation::class.java)
            .equalTo("blocked", true)
            .findAll()

        val addresses = mutableListOf<String>()

        blockedConversations.forEach { conversation ->
            conversation.recipients.forEach { recipient ->
                val address = recipient.address
                if (!address.isNullOrBlank()) {
                    addresses.add(address)
                }
            }
        }

        return addresses
    }


    private fun showExitDialog() {
        val exitDialog = ExitDialog(this, mNativeAd) { isExit ->
            if (isExit) {
                finishAffinity()
                System.exit(0)
            }
        }
        if (!exitDialog.isShowing) {
            val bottomSheet =
                exitDialog.findViewById<View>(R.id.design_bottom_sheet)
            bottomSheet?.setBackgroundResource(R.drawable.shape_bg_bottom_dialog)

            if (bottomSheet != null) {
                val behavior: BottomSheetBehavior<*> = BottomSheetBehavior.from(bottomSheet)
                behavior.peekHeight = 0 // You can adjust this as needed
                behavior.state = BottomSheetBehavior.STATE_EXPANDED
                behavior.isDraggable = false
            }
            exitDialog.show()
        }


    }


    private var mNativeAd: NativeAd? = null
    private fun loadExitAds() {
        if (mNativeAd == null) {

            AdmobNative.preLoad(this, { isLoaded, nativeAd ->
                Log.e("native_exit", "preLoad:$isLoaded")
                if (isLoaded) {
                    mNativeAd = nativeAd
                }
            }, getAppExitNative())
        }

    }


    private fun isTimestampFromPreviousDay(timestamp: Long): Boolean {
        // If the snackbar was never closed, it's "from a previous day" so we can show it.
        if (timestamp <= 0L) {
            return true
        }

        val lastClosedCal = Calendar.getInstance().apply { timeInMillis = timestamp }
        val currentCal = Calendar.getInstance()

        // Compare the day of the year and the year itself. This correctly handles year changes.
        return lastClosedCal.get(Calendar.DAY_OF_YEAR) != currentCal.get(Calendar.DAY_OF_YEAR)
                || lastClosedCal.get(Calendar.YEAR) != currentCal.get(Calendar.YEAR)
    }

}
