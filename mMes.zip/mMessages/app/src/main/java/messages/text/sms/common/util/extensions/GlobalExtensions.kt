package messages.text.sms.common.util.extensions

fun now(): Long {
    return System.currentTimeMillis()
}
