package messages.text.sms.password.callback;


public interface FingerprintDialogCallback {
    void onAuthenticationSucceeded();

    void onAuthenticationCancel();
}
