package messages.text.sms.feature.themepicker

import com.f2prateek.rx.preferences2.Preference
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import io.reactivex.rxkotlin.Observables
import io.reactivex.rxkotlin.withLatestFrom
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MainBasePresenter
import messages.text.sms.common.util.Colors
import messages.text.sms.manager.WidgetManager
import messages.text.sms.util.Preferences
import javax.inject.Inject
import javax.inject.Named

class ThemePickerPresenter @Inject constructor(
    prefs: Preferences,
    @Named("recipientId") private val recipientId: Long,
    private val colors: Colors,
    private val navigator: Navigator,
    private val widgetManager: WidgetManager,
) : MainBasePresenter<ThemePickerView, ThemePickerState>(ThemePickerState(recipientId = recipientId)) {

    private val theme: Preference<Int> = prefs.theme(recipientId)

    override fun bindIntents(view: ThemePickerView) {
        super.bindIntents(view)

        theme.asObservable()
            .autoDisposable(view.scope())
            .subscribe { color -> view.setCurrentTheme(color) }

        // Update the theme when a material theme is clicked
        view.themeSelected()
            .autoDisposable(view.scope())
            .subscribe { color ->
                theme.set(color)
                if (recipientId == 0L) {
                    widgetManager.updateTheme()
                }
            }

        // Update the color of the apply button
        view.hsvThemeSelected()
            .doOnNext { color -> newState { copy(newColor = color) } }
            .map { color -> colors.textPrimaryOnThemeForColor(color) }
            .doOnNext { color -> newState { copy(newTextColor = color) } }
            .autoDisposable(view.scope())
            .subscribe()

        // Toggle the visibility of the apply group
        Observables.combineLatest(
            theme.asObservable(),
            view.hsvThemeSelected()
        ) { old, new -> old != new }
            .autoDisposable(view.scope())
            .subscribe { themeChanged -> newState { copy(applyThemeVisible = themeChanged) } }

        // Update the theme, when apply is clicked
        view.applyHsvThemeClicks()
            .withLatestFrom(view.hsvThemeSelected()) { _, color -> color }
            .autoDisposable(view.scope())
            .subscribe { color ->
                theme.set(color)
                if (recipientId == 0L) {
                    widgetManager.updateTheme()
                }
            }


        // Reset the theme
        view.clearHsvThemeClicks()
            .withLatestFrom(theme.asObservable()) { _, color -> color }
            .autoDisposable(view.scope())
            .subscribe { color -> view.setCurrentTheme(color) }
    }

}