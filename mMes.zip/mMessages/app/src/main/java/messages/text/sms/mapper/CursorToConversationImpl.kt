package messages.text.sms.mapper

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabaseCorruptException
import android.net.Uri
import android.provider.Telephony.Threads
import messages.text.sms.manager.PermissionManager
import messages.text.sms.model.Conversation
import messages.text.sms.model.Recipient
import javax.inject.Inject

class CursorToConversationImpl @Inject constructor(
    private val context: Context,
    private val permissionManager: PermissionManager,
) : CursorToConversation {

    companion object {
        val URI: Uri = Uri.parse("content://mms-sms/conversations?simple=true")
        val PROJECTION = arrayOf(
            Threads._ID,
            Threads.RECIPIENT_IDS
        )
        const val ID = 0
        const val RECIPIENT_IDS = 1
    }

    override fun map(from: Cursor): Conversation {
        return Conversation().apply {
            id = from.getLong(ID)
            recipients.addAll(from.getString(RECIPIENT_IDS)
                .split(" ")
                .filter { it.isNotBlank() }
                .map { recipientId -> recipientId.toLong() }
                .map { recipientId -> Recipient().apply { id = recipientId } })
        }
    }

//    override fun getConversationsCursor(): Cursor? {
//        return when (permissionManager.hasReadSms()) {
//            true -> context.contentResolver.query(URI, PROJECTION, null, null, "date desc")
//            false -> null
//        }
//    }

    /* override fun getConversationsCursor(): Cursor? {
         return if (permissionManager.hasReadSms()) {
             try {
                 context.contentResolver.query(URI, PROJECTION, null, null, "date desc")
             } catch (e: SQLiteDatabaseCorruptException) {
                 // Log.e("DatabaseError", "Database is corrupted: ${e.message}")
                 null
             } catch (e: android.database.sqlite.SQLiteException) {
                 null
             } catch (e: Exception) {
                 //  Log.e("DatabaseError", "Unexpected error while querying: ${e.message}")
                 null
             }
         } else {
             null

         }
     }*/

    override fun getConversationsCursor(limit: Boolean): Cursor? {
        return if (permissionManager.hasReadSms()) {
            try {
                val sortOrder = if (limit) {
                    "date desc LIMIT 100"
                } else {
                    "date desc"
                }
                context.contentResolver.query(
                    URI,
                    PROJECTION,
                    null,
                    null,
                    sortOrder
                )
            } catch (e: SQLiteDatabaseCorruptException) {
                null
            } catch (e: android.database.sqlite.SQLiteException) {
                null
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }
    }


}