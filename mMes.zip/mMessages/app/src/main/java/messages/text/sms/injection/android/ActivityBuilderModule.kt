package messages.text.sms.injection.android


import dagger.Module
import dagger.android.ContributesAndroidInjector
import messages.text.sms.appmanager.FindAppActivity
import messages.text.sms.appmanager.ManageAppActivity
import messages.text.sms.autoreply.AutoReplyActivity
import messages.text.sms.feature.backup.BackupActivity
import messages.text.sms.feature.blocking.BlockingActivity
import messages.text.sms.feature.blocking.MainBlockActivity
import messages.text.sms.feature.compose.ComposeActivity
import messages.text.sms.feature.compose.ComposeActivityModule
import messages.text.sms.feature.contacts.ContactsActivity
import messages.text.sms.feature.contacts.ContactsActivityModule
import messages.text.sms.feature.contacts.GroupsActivity
import messages.text.sms.feature.conversationinfo.ConversationInfoActivity
import messages.text.sms.feature.gallery.GalleryActivity
import messages.text.sms.feature.gallery.GalleryActivityModule
import messages.text.sms.feature.main.ArchiveActivity
import messages.text.sms.feature.main.BlockedMessageListActivity
import messages.text.sms.feature.main.ConversationsPickerActivity
import messages.text.sms.feature.main.MainActivity
import messages.text.sms.feature.main.MainActivityModule
import messages.text.sms.feature.main.PermissionActivity
import messages.text.sms.feature.main.PrivateContactActivity
import messages.text.sms.feature.main.PrivateConversationsActivity
import messages.text.sms.feature.main.SplashActivity
import messages.text.sms.feature.notificationprefs.NotificationPrefsActivity
import messages.text.sms.feature.notificationprefs.NotificationPrefsActivityModule
import messages.text.sms.feature.personalize.BubbleActivity
import messages.text.sms.feature.personalize.CropImageThemeActivity
import messages.text.sms.feature.personalize.FontActivity
import messages.text.sms.feature.personalize.RingtonesListActivity
import messages.text.sms.feature.personalize.ThemeActivity
import messages.text.sms.feature.personalize.ThemeImagePreviewActivity
import messages.text.sms.feature.personalize.ThemePreviewActivity
import messages.text.sms.feature.qkreply.MainBaseReplyActivity
import messages.text.sms.feature.qkreply.QkReplyActivityModule
import messages.text.sms.feature.scheduled.ScheduledActivity
import messages.text.sms.feature.scheduled.ScheduledActivityModule
import messages.text.sms.feature.settings.AdvanceSettingsActivity
import messages.text.sms.feature.settings.SettingsActivity
import messages.text.sms.feature.settings.SwipeActionsActivity
import messages.text.sms.feature.starred.StarredActivity
import messages.text.sms.feature.starred.StarredActivityModule
import messages.text.sms.injection.scope.ActivityScope
import messages.text.sms.password.ChangePasswordActivity
import messages.text.sms.password.ForgetPasswordActivity
import messages.text.sms.password.HideEntranceActivity
import messages.text.sms.password.PasswordActivity
import messages.text.sms.password.PrivateSettingsActivity

@Module
abstract class ActivityBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindMainActivity(): MainActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindArchiveActivity(): ArchiveActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindBlockedMessageListActivity(): BlockedMessageListActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindConversionPickerActivity(): ConversationsPickerActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindPrivateConversationsActivity(): PrivateConversationsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindPrivateContactActivity(): PrivateContactActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindPasswordActivity(): PasswordActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindChangePasswordActivity(): ChangePasswordActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindForgetPasswordActivity(): ForgetPasswordActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindPrivateSettingsActivity(): PrivateSettingsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindHideEntranceActivity(): HideEntranceActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBackupActivity(): BackupActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [StarredActivityModule::class])
    abstract fun bindStarredActivity(): StarredActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindFontActivity(): FontActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindThemeActivity(): ThemeActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindCropImageThemeActivity(): CropImageThemeActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBubbleActivity(): BubbleActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindRingtonesListActivity(): RingtonesListActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindThemePreviewActivity(): ThemePreviewActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindThemeImagePreviewActivity(): ThemeImagePreviewActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindFindAppActivity(): FindAppActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindManageAppActivity(): ManageAppActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ComposeActivityModule::class])
    abstract fun bindComposeActivity(): ComposeActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ContactsActivityModule::class])
    abstract fun bindContactsActivity(): ContactsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindConversationInfoActivity(): ConversationInfoActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [GalleryActivityModule::class])
    abstract fun bindGalleryActivity(): GalleryActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [NotificationPrefsActivityModule::class])
    abstract fun bindNotificationPrefsActivity(): NotificationPrefsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [QkReplyActivityModule::class])
    abstract fun bindQkReplyActivity(): MainBaseReplyActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ScheduledActivityModule::class])
    abstract fun bindScheduledActivity(): ScheduledActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSettingsActivity(): SettingsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindMainBlockActivity(): MainBlockActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindNewSettingsActivity(): AdvanceSettingsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSwipeActionsActivity(): SwipeActionsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSplashActivity(): SplashActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindPermissionActivity(): PermissionActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBlockingActivity(): BlockingActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindGroupsActivity(): GroupsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindAutoReplyActivity(): AutoReplyActivity

}
