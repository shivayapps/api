package messages.text.sms.feature.settings.swipe

import android.content.Context
import androidx.annotation.DrawableRes
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.rxkotlin.withLatestFrom
import messages.text.sms.R
import messages.text.sms.common.base.MainBasePresenter
import messages.text.sms.util.Preferences
import javax.inject.Inject

class SwipeActionsPresenter @Inject constructor(
    context: Context,
    private val prefs: Preferences,
) : MainBasePresenter<SwipeActionsView, SwipeActionsState>(SwipeActionsState()) {

    init {
        val actionLabels = context.resources.getStringArray(R.array.settings_swipe_actions_list)

        disposables += prefs.swipeRight.asObservable()
            .subscribe { action ->
                newState {
                    copy(
                        rightLabel = actionLabels[action],
                        rightIcon = iconForAction(action)
                    )
                }
            }

        disposables += prefs.swipeLeft.asObservable()
            .subscribe { action ->
                newState {
                    copy(
                        leftLabel = actionLabels[action],
                        leftIcon = iconForAction(action)
                    )
                }
            }
    }

    override fun bindIntents(view: SwipeActionsView) {
        super.bindIntents(view)

        view.actionClicks()
            .map { action ->
                when (action) {
                    SwipeActionsView.Action.RIGHT -> {
                        prefs.swipeRight.get()
                    }

                    SwipeActionsView.Action.LEFT -> prefs.swipeLeft.get()
                }
            }
            .autoDisposable(view.scope())
            .subscribe(view::showSwipeActions)

        view.actionSelected()
            .withLatestFrom(view.actionClicks()) { actionId, action ->
                when (action) {
                    SwipeActionsView.Action.RIGHT -> prefs.swipeRight.set(actionId)
                    SwipeActionsView.Action.LEFT -> prefs.swipeLeft.set(actionId)
                }
            }
            .autoDisposable(view.scope())
            .subscribe()
    }
    /*
        @DrawableRes
        private fun iconForAction(action: Int, isToggled: Boolean = false): Int = when (action) {
            AdsPreferences.SWIPE_ACTION_ARCHIVE -> R.drawable.ic_archive_white_24dp
            AdsPreferences.SWIPE_ACTION_DELETE -> R.drawable.ic_delete
            AdsPreferences.SWIPE_ACTION_BLOCK -> R.drawable.ic_block_white_24dp
            AdsPreferences.SWIPE_ACTION_CALL -> R.drawable.ic_call_gray_24dp
            AdsPreferences.SWIPE_ACTION_READ -> if (isToggled) R.drawable.ic_unread_white_24dp else R.drawable.ic_read_white_24dp
            AdsPreferences.SWIPE_ACTION_UNREAD -> if (isToggled) R.drawable.ic_read_white_24dp else R.drawable.ic_unread_white_24dp
            else -> 0
        }*/

    @DrawableRes
    private fun iconForAction(action: Int) = when (action) {
        Preferences.SWIPE_ACTION_ARCHIVE -> R.drawable.ic_archive_swipe
        Preferences.SWIPE_ACTION_DELETE -> R.drawable.ic_delete_swipe
        Preferences.SWIPE_ACTION_BLOCK -> R.drawable.ic_block_swipe
        Preferences.SWIPE_ACTION_CALL -> R.drawable.ic_call_swipe
        Preferences.SWIPE_ACTION_READ -> R.drawable.ic_read_white_24dp
        Preferences.SWIPE_ACTION_UNREAD -> R.drawable.ic_unread_white_24dp
        else -> 0
    }

}