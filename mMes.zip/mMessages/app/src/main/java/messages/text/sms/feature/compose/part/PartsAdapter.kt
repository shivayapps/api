package messages.text.sms.feature.compose.part

import android.view.View
import android.view.ViewGroup
import androidx.viewbinding.ViewBinding
import io.reactivex.Observable
import messages.text.sms.common.base.MainBaseAdapter
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.extensions.forwardTouches
import messages.text.sms.databinding.MessageListItemInBinding
import messages.text.sms.extensions.isSmil
import messages.text.sms.extensions.isText
import messages.text.sms.feature.compose.BubbleUtils.canGroup
import messages.text.sms.model.Message
import messages.text.sms.model.MmsPart
import javax.inject.Inject

class PartsAdapter @Inject constructor(
    colors: Colors,
    fileBinder: FileBinder,
    mediaBinder: MediaBinder,
    vCardBinder: VCardBinder,
) : MainBaseAdapter<MmsPart, ViewBinding>() {

    private val partBinders = listOf(mediaBinder, vCardBinder, fileBinder)

    var theme: Colors.Theme = colors.theme()
        set(value) {
            field = value
            partBinders.forEach { binder -> binder.theme = value }
        }

    val clicks: Observable<Long> = Observable.merge(partBinders.map { it.clicks })

    private lateinit var message: Message
    private var previous: Message? = null
    private var next: Message? = null
    private var holder: MainBaseMsgViewHolder<MessageListItemInBinding>? = null
    private var bodyVisible: Boolean = true

    fun setData(
        message: Message,
        previous: Message?,
        next: Message?,
        holder: MainBaseMsgViewHolder<MessageListItemInBinding>,
    ) {
        this.message = message
        this.previous = previous
        this.next = next
        this.holder = holder
        this.bodyVisible = holder.binding.body.visibility == View.VISIBLE
        this.data = message.parts.filter { !it.isSmil() && !it.isText() }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<ViewBinding> {
        return MainBaseMsgViewHolder(parent, partBinders[viewType].bindingInflater).apply {
            holder?.binding?.root?.let(binding.root::forwardTouches)
        }
    }

    override fun onBindViewHolder(holder: MainBaseMsgViewHolder<ViewBinding>, position: Int) {
        val part = data[position]

        val canGroupWithPrevious = canGroup(message, previous) || position > 0
        val canGroupWithNext = canGroup(message, next) || position < itemCount - 1 || bodyVisible

        partBinders.find { binder ->
            binder.bindPart(
                holder,
                part,
                message,
                canGroupWithPrevious,
                canGroupWithNext
            )
        }
    }

    override fun getItemViewType(position: Int): Int {
        val part = data[position]
        return partBinders.indexOfFirst { it.canBindPart(part) }
    }

}