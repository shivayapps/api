package messages.text.sms.feature.main.ui

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R
import messages.text.sms.feature.main.models.Contact
import java.util.Locale.getDefault


class ContactPickerAdapter(val result: ArrayList<Contact>) :
    RecyclerView.Adapter<ContactPickerAdapter.ContactViewHolder>(), Filterable {

    private var data = result
    private val copy = result


    public var clickListener: (Contact) -> Unit = { _ -> }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {

        return ContactViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.layout_contact,
                parent, false
            )
        )
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {

        val contact = data[position]
        holder.nameTextView.text = contact.name
        holder.phoneTextView.text = contact.phone

        val colors: IntArray =
            holder.nameTextView.context.resources.getIntArray(R.array.random_colors)

        val color = colors[position % colors.size]


        // Apply the selected color to the drawable
        val roundedDrawable = ContextCompat.getDrawable(
            holder.contactFirstChar.context,
            R.drawable.round_button_grey
        ) as GradientDrawable
        roundedDrawable.setColor(color)

        holder.contactFirstChar.background = roundedDrawable

        holder.contactFirstChar.text = contact.name?.substring(0, 1)

        holder.root.setOnClickListener {
            clickListener.invoke(contact)
        }
    }

    override fun getFilter() = namedFilter

    private val namedFilter: Filter = object : Filter() {

        override fun publishResults(p0: CharSequence?, p1: FilterResults?) {

            if (p1?.values == null || p1.count < 0) {

                data.clear()
                data = copy
                notifyDataSetChanged()
                return
            }

            data = p1.values as (ArrayList<Contact>)
            notifyDataSetChanged()
        }

        override fun performFiltering(p0: CharSequence?): FilterResults {

            return if (p0 == null || p0.toString().trim().isEmpty()) {

                val result = FilterResults()

                result.count = 0
                result.values = null
                result
            } else {
                val data = filterContacts(p0)
                val result = FilterResults()

                result.count = 0
                result.values = data
                result
            }
        }
    }

    private fun filterContacts(p0: CharSequence?): ArrayList<Contact> {

        val value = p0.toString().trim().lowercase(getDefault())
        val response = ArrayList<Contact>()

        copy.forEach {

            if (it.name != null && it.phone != null) {

                if (it.name!!.lowercase(getDefault()).contains(value) || it.phone!!.lowercase(
                        getDefault()
                    )
                        .contains(value)
                ) {
                    response.add(it)
                }
            }
        }

        return response
    }


    class ContactViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val contactFirstChar = view.findViewById<TextView>(R.id.iv_contact_photo)
        val nameTextView = view.findViewById<TextView>(R.id.tv_contact_name)
        val phoneTextView = view.findViewById<TextView>(R.id.tv_contact_phone_number)
        val root = view.findViewById<FrameLayout>(R.id.layout_contact_root)
    }
}