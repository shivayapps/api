package messages.text.sms.commons.dialogs

import android.app.Dialog
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import androidx.fragment.app.DialogFragment
import messages.text.sms.databinding.BottomDialogAlarmPermissionBinding

class AlarmPermissionBottomSheetDialog : DialogFragment() {
    private lateinit var binding: BottomDialogAlarmPermissionBinding
    var checkstatus: Boolean = false
    var btnClickListener: ((Int) -> Unit?)? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?,
    ): View {
        binding = BottomDialogAlarmPermissionBinding.inflate(inflater, container, false)
        initListener()
        return binding.root
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        // Inflate the layout and initialize binding here
        val inflater = LayoutInflater.from(requireContext())
        binding = BottomDialogAlarmPermissionBinding.inflate(inflater)

        dialog.setContentView(binding.root)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        dialog.setCancelable(false)


        // Set dialog width and margin in dp
        val params = dialog.window?.attributes
        val marginInDp = 15  // e.g., 16dp margin on left/right
        val marginInPx = (marginInDp * resources.displayMetrics.density).toInt()

// Adjust window layout with calculated margins
        params?.width = resources.displayMetrics.widthPixels - 2 * marginInPx
        dialog.window?.attributes = params

        initListener() // Ensure listeners are set up properly

        return dialog
    }


    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        if (!checkstatus) {
//            checkdiaogopn = false
        }
    }

    private fun initListener() {
        binding.llAllow.setOnClickListener {
            btnClickListener?.invoke(0)
            dismiss()
        }
        binding.ivClose.setOnClickListener {
//            btnClickListener?.invoke(1)
            dismiss()
        }
        binding.llDeny.setOnClickListener {
//            btnClickListener?.invoke(1)
            dismiss()
        }
    }
}