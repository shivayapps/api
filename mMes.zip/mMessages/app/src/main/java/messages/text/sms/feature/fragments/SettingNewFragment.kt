package messages.text.sms.feature.fragments

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import messages.text.sms.BuildConfig
import messages.text.sms.R
import messages.text.sms.ads.app_language_screen_open
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.databinding.FragmentSettingBinding
import messages.text.sms.databinding.FragmentSettingNewBinding
import messages.text.sms.feature.main.PermissionActivity
import messages.text.sms.feature.notificationprefs.NotificationPrefsActivity
import messages.text.sms.password.PasswordActivity


class SettingNewFragment : Fragment() {

    lateinit var binding: FragmentSettingNewBinding



    private fun onClickEvents() {
        binding.cardPrivateChat.setOnClickListener { startActivity(Intent(context, PasswordActivity::class.java)) }
        binding.cardBackup.setOnClickListener {  }
        binding.cardRemoveAds.setOnClickListener {  }
        binding.cardNotification.setOnClickListener {
            val intent = Intent(requireContext(), NotificationPrefsActivity::class.java)
            intent.putExtra("threadId", 0)
            startActivity(intent)
        }
        binding.cardLanguage.setOnClickListener {
            try {
                requireActivity().firebaseAnalyticsHandler.logMessages(
                    app_language_screen_open,
                    requireActivity().getActivityName()
                )
            } catch (e: Exception) {

            }
            startActivity(Intent(context, PermissionActivity::class.java).putExtra("reset", true))

        }
        binding.cardShare.setOnClickListener {
            shareApp()
        }
        binding.cardRate.setOnClickListener {  }
        binding.cardHelp.setOnClickListener {
            email(
                activity!!, "teamshivay@gmail.com",
                "Message Feedback",
                "Your feedback"
            )
        }
        binding.cardAbout.setOnClickListener {  }
    }



    fun email(
        context: Context,
        emailTo: String,
        subject: String,
        emailText: String,
    ) {
        val emailIntent = Intent(Intent.ACTION_SEND_MULTIPLE)
        emailIntent.type = "message/rfc822"
        emailIntent.setPackage("com.google.android.gm")
        emailIntent.putExtra(Intent.EXTRA_EMAIL, arrayOf(emailTo))
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject)
        emailIntent.putExtra(Intent.EXTRA_TEXT, emailText)
        context.startActivity(Intent.createChooser(emailIntent, "Send mail..."))
    }

    private fun shareApp() {
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.setType("text/plain")
        val shareMessage =
            "Check out this amazing app: https://play.google.com/store/apps/details?id=${BuildConfig.APPLICATION_ID}"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, "Share App via"))
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentSettingNewBinding.inflate(inflater, container, false)
        onClickEvents()
        return binding.root
    }


}