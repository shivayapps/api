package messages.text.sms.feature.starred

import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.QkViewModel
import messages.text.sms.manager.PermissionManager
import messages.text.sms.repository.StarredMessageRepository

import javax.inject.Inject

class StarredViewModel @Inject constructor(
    private val navigator: Navigator,
    scheduledMessageRepo: StarredMessageRepository,
    private val permissionManager: PermissionManager,
) : QkViewModel<StarredMessagesView, StarredMessagesState>(
    StarredMessagesState(
        data = scheduledMessageRepo.getStarredMessages()
    )
) {
    override fun bindView(view: StarredMessagesView) {
        super.bindView(view)
        view.conversationClicks
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .autoDisposable(view.scope())
            .subscribe { it -> navigator.showConversation(it.threadId, null, it.id) }
    }
}