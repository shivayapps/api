package messages.text.sms.manager

interface ShortcutManager {

    fun updateBadge()

    fun updateShortcuts()

}