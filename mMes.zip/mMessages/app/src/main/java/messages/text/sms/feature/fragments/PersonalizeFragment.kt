package messages.text.sms.feature.fragments


import android.content.Intent
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.f2prateek.rx.preferences2.RxSharedPreferences
import messages.text.sms.R
import messages.text.sms.ads.MainInterAdManager
import messages.text.sms.common.MysmsApplication.Companion.isHomeInterShow
import messages.text.sms.commons.extensions.applyColorFilter
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.clientConfigPref
import messages.text.sms.commons.extensions.getItemBackgroundColor
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.FragmentPersonalizeBinding
import messages.text.sms.feature.personalize.BubbleActivity
import messages.text.sms.feature.personalize.FontActivity
import messages.text.sms.feature.personalize.RingtonesListActivity
import messages.text.sms.feature.personalize.ThemeActivity
import messages.text.sms.util.Preferences


class PersonalizeFragment constructor() : Fragment() {

    lateinit var prefs: Preferences

    lateinit var binding: FragmentPersonalizeBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        binding = FragmentPersonalizeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val shPrefs = PreferenceManager.getDefaultSharedPreferences(context)
        val rxPrefs = RxSharedPreferences.create(shPrefs)
        prefs = Preferences(requireContext(), rxPrefs, shPrefs)

        setUI()
        setUpListener()
    }

    private fun setUI() {
        requireContext().updateTextColors(binding.personalizeCoordinator)

        binding.apply {

            /*  arrayOf(
                  themeLabel,
                  fontLabel,
                  bubbleLabel,
                  ringtoneLabel,
              ).forEach {
                  it.setTextColor(requireContext().getProperPrimaryColor())
              }*/

//            arrayOf(
//                llThemeHolder,
//                llFontHolder,
//                llBubbleHolder,
//                llRingtoneHolder,
//            ).forEach {
//                it.background.applyColorFilter(requireContext().getBottomNavigationBackgroundColor())
//            }
            arrayOf(
                llThemeHolder,
                llFontHolder,
                llBubbleHolder,
                llRingtoneHolder,
            ).forEach {
                if (requireActivity().baseConfig.useImageResource == true) {
                    if (requireActivity().baseConfig.storedImageResource == -1) {

                    } else {
                        it.background.applyColorFilter(requireContext().resources.getColor(R.color.transperent70))
                    }
                } else {
                    it.background.applyColorFilter(requireContext().getItemBackgroundColor())

                }
            }
        }
    }

    private fun setUpListener() {

        binding.llFontHolder.setOnClickListener {

            if (requireActivity().clientConfigPref.enableBackPressInter) {
                Log.e("Message_Log", "enable_back_press_inter - showMainInterAds")
                MainInterAdManager.showMainInterAds(requireActivity()) {

                    Log.e("Message_Log", "enable_back_press_inter - isHomeInterShow = true")
                    isHomeInterShow = true
                    startActivity(Intent(requireContext(), FontActivity::class.java))
                }
            } else {
                Log.e("Message_Log", "enable_back_press_inter - finish")
                startActivity(Intent(requireContext(), FontActivity::class.java))

            }
        }
        binding.llThemeHolder.setOnClickListener {

            if (requireActivity().clientConfigPref.enableBackPressInter) {
                Log.e("Message_Log", "enable_back_press_inter - showMainInterAds")
                MainInterAdManager.showMainInterAds(requireActivity()) {

                    Log.e("Message_Log", "enable_back_press_inter - isHomeInterShow = true")
                    isHomeInterShow = true
                    startActivity(Intent(requireContext(), ThemeActivity::class.java))
                }
            } else {
                Log.e("Message_Log", "enable_back_press_inter - finish")
                startActivity(Intent(requireContext(), ThemeActivity::class.java))

            }

        }
        binding.llBubbleHolder.setOnClickListener {

            if (requireActivity().clientConfigPref.enableBackPressInter) {
                Log.e("Message_Log", "enable_back_press_inter - showMainInterAds")
                MainInterAdManager.showMainInterAds(requireActivity()) {

                    Log.e("Message_Log", "enable_back_press_inter - isHomeInterShow = true")
                    isHomeInterShow = true
                    startActivity(Intent(requireContext(), BubbleActivity::class.java))
                }
            } else {
                Log.e("Message_Log", "enable_back_press_inter - finish")
                startActivity(Intent(requireContext(), BubbleActivity::class.java))

            }
        }
        binding.llRingtoneHolder.setOnClickListener {

            if (requireActivity().clientConfigPref.enableBackPressInter) {
                Log.e("Message_Log", "enable_back_press_inter - showMainInterAds")
                MainInterAdManager.showMainInterAds(requireActivity()) {

                    Log.e("Message_Log", "enable_back_press_inter - isHomeInterShow = true")
                    isHomeInterShow = true
                    startActivity(Intent(requireContext(), RingtonesListActivity::class.java))
                }
            } else {
                Log.e("Message_Log", "enable_back_press_inter - finish")
                startActivity(Intent(requireContext(), RingtonesListActivity::class.java))

            }

        }
    }


}
