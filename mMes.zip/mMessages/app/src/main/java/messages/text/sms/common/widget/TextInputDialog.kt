package messages.text.sms.common.widget

import android.app.Activity
import android.content.DialogInterface
import android.view.LayoutInflater
import androidx.appcompat.app.AlertDialog
import messages.text.sms.R
import messages.text.sms.databinding.TextInputDialogBinding

class TextInputDialog(context: Activity, hint: String, listener: (String) -> Unit) :
    AlertDialog(context) {

    private val layout = TextInputDialogBinding.inflate(LayoutInflater.from(context))

    init {
        layout.field.hint = hint

        setView(layout.root)
        setButton(
            DialogInterface.BUTTON_NEUTRAL,
            context.getString(R.string.button_cancel)
        ) { _, _ -> }
        setButton(
            DialogInterface.BUTTON_NEGATIVE,
            context.getString(R.string.button_delete)
        ) { _, _ -> listener("") }
        setButton(
            DialogInterface.BUTTON_POSITIVE,
            context.getString(R.string.button_save)
        ) { _, _ ->
            listener(layout.field.text.toString())
        }
    }

    fun setText(text: String): TextInputDialog {
        layout.field.setText(text)
        return this
    }

}
