package messages.text.sms.interactor

import android.content.Context
import android.telephony.SmsMessage
import io.reactivex.Flowable
import messages.text.sms.blocking.BlockingClient
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.config
import messages.text.sms.extensions.mapNotNull
import messages.text.sms.manager.NotificationManager
import messages.text.sms.manager.ShortcutManager
import messages.text.sms.model.BLOCKED_COUNT
import messages.text.sms.model.Message
import messages.text.sms.model.MessageEvent
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.repository.MessageRepository
import messages.text.sms.util.Preferences
import org.greenrobot.eventbus.EventBus
import timber.log.Timber
import javax.inject.Inject

class ReceiveSms @Inject constructor(
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val blockingClient: BlockingClient,
    private val prefs: Preferences,
    private val messageRepo: MessageRepository,
    private val notificationManager: NotificationManager,
    private val updateBadge: UpdateBadge,
    private val shortcutManager: ShortcutManager,
) : Interactor<ReceiveSms.Params>() {

    class Params(val subId: Int, val messages: Array<SmsMessage>)

//    override fun buildObservable(params: Params): Flowable<*> {
//        return Flowable.just(params)
//            .filter { it.messages.isNotEmpty() }
//            .mapNotNull {
//                val messages = it.messages
//                val address = messages[0].displayOriginatingAddress
//                val time = messages[0].timestampMillis
//                val body: String = messages
//                    .mapNotNull { message -> message.displayMessageBody }
//                    .reduce { body, new -> body + new }
//
//                // Load block lists
//                val blockedKeywordList = ArrayList(context.config.keywordList)
//                val blockedNumberList = context.baseConfig.blockContactsList
//                    .split(",")
//                    .map { it.trim() }
//                    .filter { it.isNotEmpty() }
//
//                // Check if number is blocked
//                val isNumberBlocked = blockedNumberList.any { blockedNumber ->
//                    address.contains(blockedNumber, ignoreCase = true)
//                }
//
//                // Check if message contains any blocked keyword
//
//                val isKeywordBlocked = blockedKeywordList.any { blockedKeyword ->
//                    body.contains(blockedKeyword.keyword, ignoreCase = true)
//                }
//
//                // Check user-defined drop setting
//                val action = blockingClient.getAction(address).blockingGet()
//                val shouldDrop = prefs.drop.get()
//
//                // Combine conditions: block if system or user config says so
//                if ((action is BlockingClient.Action.Block && shouldDrop)) {
//                    Timber.v("Blocked message from $address - Reason: ${
//                        when {
//                            isNumberBlocked -> "Blocked Number"
//                            isKeywordBlocked -> "Blocked Keyword"
//                            else -> "Blocked by Client"
//                        }
//                    }")
//                    return@mapNotNull null
//                }
//
//
//
//
//                // Save message to DB
//                val message = messageRepo.insertReceivedSms(it.subId, address, body, time)
//
//                if (isNumberBlocked || isKeywordBlocked) {
//
//                }
//
//                when (action) {
//                    is BlockingClient.Action.Block -> {
//                        messageRepo.markRead(message.threadId)
//                        conversationRepo.markBlocked(
//                            listOf(message.threadId),
//                            prefs.blockingManager.get(),
//                            action.reason
//                        )
//                    }
//
//                    is BlockingClient.Action.Unblock -> {
//                        conversationRepo.markUnblocked(message.threadId)
//                    }
//
//                    else -> Unit
//                }
//
//                message
//            }
//            .doOnNext { message ->
//                conversationRepo.updateConversations(message.threadId)
//            }
//            .mapNotNull { message ->
//                conversationRepo.getOrCreateConversation(message.threadId)
//            }
//            .filter { conversation -> !conversation.blocked }
//            .doOnNext { conversation ->
//                if (conversation.archived) conversationRepo.markUnarchived(conversation.id)
//                if (conversation.isRecycle) conversationRepo.markRecycle(conversation.id)
//            }
//            .map { conversation -> conversation.id }
//            .doOnNext { threadId -> notificationManager.update(threadId) }
//            .doOnNext { shortcutManager.updateShortcuts() }
//            .flatMap { updateBadge.buildObservable(Unit) }
//    }


    override fun buildObservable(params: Params): Flowable<*> {
        return Flowable.just(params)
            .filter { it.messages.isNotEmpty() }
            .mapNotNull {
                // Don't continue if the sender is blocked
                val messages = it.messages
                val address = messages[0].displayOriginatingAddress
                val action = blockingClient.getAction(address).blockingGet()
                val shouldDrop = prefs.drop.get()
                Timber.v("002.block=$action, drop=$shouldDrop")

                //Log.e("SmsReceiver--------------", "buildObservable")
                //Log.e("SmsReceiver--------------", "messages - $messages")
                // If we should drop the message, don't even save it
                if (action is BlockingClient.Action.Block && shouldDrop) {
                    return@mapNotNull null
                }

                val time = messages[0].timestampMillis
                val body: String = messages
                    .mapNotNull { message -> message.displayMessageBody }
                    .reduce { body, new -> body + new }


                val blockedKeywordList = ArrayList(context.config.keywordList)
                val blockedNumberList = context.baseConfig.blockContactsList


                val isBlockedKeywords = blockedKeywordList.any { keyword ->
                    val pattern =
                        "\\b${Regex.escape(keyword.keyword)}\\b".toRegex(RegexOption.IGNORE_CASE)
                    pattern.containsMatchIn(body)
                }

//                val isBlockedNumbers =
//                    blockedNumberList.any { number -> address.contains(number, ignoreCase = true) }


                val isBlockedNumbers = blockedNumberList.any { number ->
                    val normalizedAddress = address.replace("[^0-9]".toRegex(), "").takeLast(9)
                    val normalizedBlocked =
                        number.phone.toString().replace("[^0-9]".toRegex(), "").takeLast(9)
                    normalizedAddress == normalizedBlocked
                }


                var message: Message? = null

                if (!isBlockedKeywords && !isBlockedNumbers) {

                    message = messageRepo.insertReceivedSms(it.subId, address, body, time)
//                    when (action) {
//                        is BlockingClient.Action.Block -> {
//                            messageRepo.markRead(message.threadId)
//                            conversationRepo.markBlocked(
//                                listOf(message.threadId),
//                                prefs.blockingManager.get(),
//                                action.reason
//                            )
//                        }
//
//                        is BlockingClient.Action.Unblock -> conversationRepo.markUnblocked(
//                            message.threadId
//                        )
//
//                        else -> Unit
//                    }

                } else {
                    try {
                        var count = context.baseConfig.blockedMessageCount
                        count = count + 1
                        context.baseConfig.blockedMessageCount = count

                        EventBus.getDefault().post(MessageEvent(BLOCKED_COUNT, count))
                    } catch (e: Exception) {
                    }
                }
                /* else if (isBlockedNumbers) {

                     message = messageRepo.insertReceivedSms(it.subId, address, body, time)
                     when (action) {
                         is BlockingClient.Action.Block -> {
                             messageRepo.markRead(message.threadId)
                             conversationRepo.markBlocked(
                                 listOf(message.threadId),
                                 prefs.blockingManager.get(),
                                 action.reason
                             )
                         }

                         is BlockingClient.Action.Unblock -> conversationRepo.markUnblocked(message.threadId)
                         else -> Unit
                     }

                     Log.e("BNBNBN", "threadId - " + listOf(message.threadId))

                     Realm.getDefaultInstance().use { realm ->
                         val conversations = realm.where(Conversation::class.java)
                             .anyOf("id", listOf(message.threadId).toLongArray())
                             .equalTo("blocked", false)
                             .findAll()

                         realm.executeTransaction {
                             conversations.forEach { conversation ->
                                 conversation.blocked = true
                                 conversation.isPrivate = false
                                 conversation.isRecycle = false
                                 conversation.blockingClient = prefs.blockingManager.get()
                                 conversation.blockReason = null
                             }
                         }
                         realm.close()

                     }

                 }*/

                /*    val blockedKeywordList = ArrayList(context.config.keywordList)
                  val blockedNumberList = context.baseConfig.blockContactsList
                      .split(",")
                      .map { it.trim() }
                      .filter { it.isNotEmpty() }

                  val isBlocked = blockedKeywordList.any { keyword -> message.body.contains(keyword.keyword, ignoreCase = true) } ||
                          blockedNumberList.any { number -> message.address.contains(number, ignoreCase = true) }


                  Log.e("BNBNBN","isBlocked - " + isBlocked)
                  if (isBlocked) {

                      Log.e("BNBNBN","threadId - " + listOf(message.threadId))

                      Realm.getDefaultInstance().use { realm ->
                          val conversations = realm.where(Conversation::class.java)
                              .anyOf("id", listOf(message.threadId).toLongArray())
                              .equalTo("blocked", false)
                              .findAll()

                          realm.executeTransaction {
                              conversations.forEach { conversation ->
                                  conversation.blocked = true
                                  conversation.isPrivate = false
                                  conversation.isRecycle = false
                                  conversation.blockingClient = prefs.blockingManager.get()
                                  conversation.blockReason = null
                              }
                          }
                          realm.close()

                      }
                  }*/

                //Log.e("SmsReceiver--------------", "message - $message")
                //Log.e("SmsReceiver--------------", "message - ${message?.threadId}")

                message
            }
            .doOnNext { message ->
                //Log.e("SmsReceiver--------------", "updateConversations")
                conversationRepo.updateConversations(message.threadId) // Update the conversation
            }
            .mapNotNull { message ->
                //Log.e("SmsReceiver--------------", "getOrCreateConversation")
                conversationRepo.getOrCreateConversation(message.threadId) // Map message to conversation
            }
            .filter { conversation -> !conversation.blocked } // Don't notify for blocked conversations
            .doOnNext { conversation ->
                // Unarchive conversation if necessary

                //Log.e("SmsReceiver--------------", "doOnNext - " + conversation.id)

                if (conversation.archived) conversationRepo.markUnarchived(conversation.id)
                if (conversation.isRecycle) conversationRepo.markRecycle(conversation.id)
            }
            .map { conversation -> conversation.id } // Map to the id because [delay] will put us on the wrong thread
            .doOnNext { threadId -> notificationManager.update(threadId) } // Update the notification
            .doOnNext { shortcutManager.updateShortcuts() } // Update shortcuts
            .flatMap { updateBadge.buildObservable(Unit) } // Update the badge and widget
    }
}
