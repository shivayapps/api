package messages.text.sms.feature.scheduled

import io.reactivex.Observable
import messages.text.sms.common.base.MainBaseMsgView

interface ScheduledView : MainBaseMsgView<ScheduledState> {

    val messageClickIntent: Observable<Long>
    val messageMenuIntent: Observable<Int>
//    val composeIntent: Observable<*>

    fun showMessageOptions()

}
