package messages.text.sms.feature.main.ui

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.AppBarLayout
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.resolveThemeBoolean
import messages.text.sms.common.util.extensions.resolveThemeColor
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.feature.main.FetchContactTask
import messages.text.sms.feature.main.models.Contact
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.PICKED_CONTACT
import messages.text.sms.util.StringManager
import org.greenrobot.eventbus.EventBus
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class ContactPickerActivity : MainBaseThemedActivity() {

    private val executor: ExecutorService = Executors.newFixedThreadPool(1)
    private val contactsData: ArrayList<Contact> = ArrayList<Contact>()
    private val adapter: ContactPickerAdapter = ContactPickerAdapter(contactsData)

    private var mRecyclerView: RecyclerView? = null
    private var mSwipeRefreshLayout: SwipeRefreshLayout? = null
    private var mCloseButton: ImageView? = null
    private var mFilterEditText: EditText? = null

    companion object {

        const val EXTRA_CONTACT_DATA = "EXTRA_CONTACT_DATA"
        const val RC_CONTACT_PICKER = 12
        const val PERMISSION_REQUEST_CODE = 13
    }

    var mScreenfrom = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // We can only set light nav bar on API 27 in attrs, but we can do it in API 26 here
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.O) {
            val night = !resolveThemeBoolean(R.attr.isLightTheme)
            window.decorView.systemUiVisibility = if (night) 0 else
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        // Some devices don't let you modify android.R.attr.navigationBarColor
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.navigationBarColor = resolveThemeColor(android.R.attr.windowBackground)
        }

        window.statusBarColor = baseConfig.statusBarColor

        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
        }

        setContentView(R.layout.layout_picker_activity)


        mScreenfrom = intent.getStringExtra("from").toString()

        setupViews()
        requestPermission()
        setUpTheme()
    }

    private fun setUpTheme() {

//        updateTextColors(binding.main)

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

                if (baseConfig.storedImageResource == 111) {
                    val stringManager = StringManager(this)
                    val imageBitmap = stringManager.getSavedThemeBitmaps().last()
                    val drawable = BitmapDrawable(resources, imageBitmap)
                    findViewById<CoordinatorLayout>(R.id.main).background = drawable
                    findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(resources.getColor(R.color.transperent))
                } else {
                    val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                    findViewById<CoordinatorLayout>(R.id.main).background = drawable
                    findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(resources.getColor(R.color.transperent))
                }

            } else {
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                findViewById<CoordinatorLayout>(R.id.main).background = drawable
//                findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(resources.getColor(R.color.transperent))
                findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(baseConfig.backgroundColor)
            }


        } else {
            val primaryColor = baseConfig.primaryColor
            if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
                findViewById<CoordinatorLayout>(R.id.main).background =
                    ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
            } else {
                findViewById<CoordinatorLayout>(R.id.main).background =
                    ColorDrawable(baseConfig.backgroundColor)
            }
        }
    }

    /*   private fun fetchContacts() {

           mSwipeRefreshLayout?.isRefreshing = true
           executor.execute(FetchContactTask(this) { data ->

               contactsData.clear()
               data.forEach {
                   contactsData.add(it)
               }

               mSwipeRefreshLayout?.isRefreshing = false
               adapter.notifyDataSetChanged()
           })
       }*/

    private fun fetchContacts() {
        mSwipeRefreshLayout?.isRefreshing = true
        executor.execute(FetchContactTask(this) { data ->
            val blockedPhones = baseConfig.blockContactsList.mapNotNull { it.phone }.toSet()

            val filteredSortedContacts = data
                .filter { contact ->
                    val phone = contact.phone
                    !phone.isNullOrBlank() && !blockedPhones.contains(phone)
                }
                .sortedWith(
                    compareBy<Contact> { contact ->
                        contact.name?.firstOrNull()?.isDigit() ?: true // digits go later
                    }.thenBy { contact ->
                        contact.name?.lowercase() ?: ""
                    }
                )

            runOnUiThread {
                contactsData.clear()
                contactsData.addAll(filteredSortedContacts)
                adapter.notifyDataSetChanged()
                mSwipeRefreshLayout?.isRefreshing = false
            }
        })
    }


    private fun setupViews() {

        mRecyclerView = findViewById(R.id.rv_contacts)
        mSwipeRefreshLayout = findViewById(R.id.swipe_layout_contact_picker)
        mCloseButton = findViewById(R.id.btn_close_picker)
        mFilterEditText = findViewById(R.id.edt_filter_)

        mRecyclerView?.layoutManager = LinearLayoutManager(this)
        mRecyclerView?.adapter = adapter

        adapter.clickListener = {


            if (mScreenfrom == "private") {
                val intent = intent
                intent.putExtra(EXTRA_CONTACT_DATA, it)
                setResult(Activity.RESULT_OK, intent)
            } else if (mScreenfrom == "block") {

                EventBus.getDefault().post(MessageEvent(PICKED_CONTACT, it))
            }

            finish()

        }

        mSwipeRefreshLayout?.setOnRefreshListener {
            fetchContacts()
        }
        mCloseButton?.setOnClickListener {
            finish()
        }

        mFilterEditText?.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

                adapter.filter.filter(p0)
            }

            override fun afterTextChanged(p0: Editable?) {}

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        })
    }

    private fun requestPermission() {

        val state = ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
        if (state == PackageManager.PERMISSION_GRANTED) {

            fetchContacts()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_CONTACTS),
                PERMISSION_REQUEST_CODE
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == PERMISSION_REQUEST_CODE && grantResults.size > 0) {

            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchContacts()
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        executor.shutdownNow()
    }
}