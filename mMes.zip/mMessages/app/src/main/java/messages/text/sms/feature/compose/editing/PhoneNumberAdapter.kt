package messages.text.sms.feature.compose.editing

import android.view.ViewGroup
import messages.text.sms.common.base.MainBaseAdapter
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.commons.extensions.addAlpha
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.databinding.ContactNumberListItemBinding
import messages.text.sms.model.PhoneNumber

class PhoneNumberAdapter : MainBaseAdapter<PhoneNumber, ContactNumberListItemBinding>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<ContactNumberListItemBinding> {
        return MainBaseMsgViewHolder(parent, ContactNumberListItemBinding::inflate).apply {
//            val textColorPrimary = parent.context.baseConfig.textColor
            val colorWithAlpha = parent.context.baseConfig.textColor.addAlpha(0.3F)
            binding.address.setTextColor(colorWithAlpha)
            binding.type.setTextColor(colorWithAlpha)

        }
    }

    override fun onBindViewHolder(
        holder: MainBaseMsgViewHolder<ContactNumberListItemBinding>,
        position: Int,
    ) {
        val number = getItem(position)

        holder.binding.address.text = number.address
        holder.binding.type.text = number.type

        val textColorPrimary = holder.binding.address.context.baseConfig.textColor
        val colorWithAlpha = textColorPrimary.addAlpha(0.45F)
        holder.binding.address.setTextColor(colorWithAlpha)
        holder.binding.type.setTextColor(colorWithAlpha)
    }

    override fun areItemsTheSame(old: PhoneNumber, new: PhoneNumber): Boolean {
        return old.type == new.type && old.address == new.address
    }

    override fun areContentsTheSame(old: PhoneNumber, new: PhoneNumber): Boolean {
        return old.type == new.type && old.address == new.address
    }

}