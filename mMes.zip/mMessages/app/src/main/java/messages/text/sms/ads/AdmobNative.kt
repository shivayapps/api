package  messages.text.sms.ads

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.LayerDrawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import messages.text.sms.R
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.commons.extensions.config
import messages.text.sms.databinding.LayoutChatNativeBinding
import messages.text.sms.databinding.LayoutLanguageBigNativeBinding
import messages.text.sms.databinding.LayoutListItemNativeBinding
import messages.text.sms.databinding.LayoutManageAppNativeBinding

object AdmobNative {


    var nativeAdManageApps: NativeAd? = null
    fun preLoad(
        mContext: Context,
        listener: (isLoaded: Boolean, NativeAd?) -> Unit?,
        adId: String,
    ) {
        if (!mContext.isInternetConnected() || !AdsPreferences(mContext).adsEnable
        ) {
            listener.invoke(false, null)
            return
        }
        val videoOptionBuilder = VideoOptions.Builder()
            .setClickToExpandRequested(true)
            .setStartMuted(true)

        val nativeAdOptionsBuilder = NativeAdOptions.Builder()
            .setVideoOptions(videoOptionBuilder.build())

        val adLoader = AdLoader.Builder(mContext, adId)
            .forNativeAd { nativeAd: NativeAd ->
                nativeAdManageApps = nativeAd
                listener.invoke(true, nativeAd)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    nativeAdManageApps = null
                    listener.invoke(false, null)
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                }
            })
            .withNativeAdOptions(nativeAdOptionsBuilder.build())
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }
    fun LoadOTPNative(
        mContext: Context,
        listener: (isLoaded: Boolean, NativeAd?) -> Unit?,
        adId: String,
    ) {
        if (!mContext.isInternetConnected() || !AdsPreferences(mContext).adsEnable
        ) {
            listener.invoke(false, null)
            return
        }
        val videoOptionBuilder = VideoOptions.Builder()
            .setClickToExpandRequested(true)
            .setStartMuted(true)

        val nativeAdOptionsBuilder = NativeAdOptions.Builder()
            .setVideoOptions(videoOptionBuilder.build())

        val adLoader = AdLoader.Builder(mContext, adId)
            .forNativeAd { nativeAd: NativeAd ->
                listener.invoke(true, nativeAd)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    listener.invoke(false, null)
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                }
            })
            .withNativeAdOptions(nativeAdOptionsBuilder.build())
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    fun clearNative() {
        if (nativeAdManageApps != null) {
            nativeAdManageApps?.destroy()
        }
    }

    fun preLoadChat(
        mContext: Context,
        listener: (isLoaded: Boolean, NativeAd?) -> Unit?,
        adId: String,
    ) {
        if (!mContext.isInternetConnected() || !AdsPreferences(mContext).adsEnable || AdsPreferences(
                mContext
            ).isPro
        ) {
            listener.invoke(false, null)
            return
        }
        val videoOptionBuilder = VideoOptions.Builder()
            .setClickToExpandRequested(true)
            .setStartMuted(true)

        val nativeAdOptionsBuilder = NativeAdOptions.Builder()
            .setVideoOptions(videoOptionBuilder.build())

        val adLoader = AdLoader.Builder(mContext, adId)
            .forNativeAd { nativeAd: NativeAd ->
                nativeAdChat = nativeAd
                listener.invoke(true, nativeAd)

            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    nativeAdChat = null
                    listener.invoke(false, null)
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                }
            })
            .withNativeAdOptions(nativeAdOptionsBuilder.build())
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

//    private var nativeAdLoader: MaxNativeAdLoader? = null
//    private var nativeAd: MaxAd? = null
//    private var nativeAdViewLovin: MaxNativeAdView? = null

//    fun loadApplovinChatNative(
//        context: Context,
//        adId: String,
//        listener: (MaxNativeAdView?) -> Unit,
//    ) {
//        nativeAdLoader = MaxNativeAdLoader(adId, context).apply {
//            setNativeAdListener(object : MaxNativeAdListener() {
//                override fun onNativeAdLoaded(nativeAdView: MaxNativeAdView?, ad: MaxAd) {
//                    nativeAd = ad
//                    nativeAdViewLovin = nativeAdView
//                    listener.invoke(nativeAdView)
//
//                }
//
//                override fun onNativeAdLoadFailed(adUnitId: String, error: MaxError) {
//                    nativeAdViewLovin = null
//                    listener.invoke(null)
//                }
//
//                override fun onNativeAdExpired(ad: MaxAd) {
////                    loadApplovinSmallNative(context, listener)
//                }
//            })
//        }
//        nativeAdLoader?.setRevenueListener {
//            context.setApplovinLogs(it)
//        }
//        nativeAdLoader?.loadAd(createNativeAdView(context))
//    }

//    fun showAdChatAppLovin(
//        context: Context,
//        parentView: ViewGroup,
//    ) {
//        if (nativeAd == null || nativeAdViewLovin == null || nativeAd?.nativeAd?.isExpired == true) {
//
//            parentView.visibility = View.GONE
//
//        } else {
//            try {
////                (nativeAdViewLovin?.parent as? ViewGroup)?.removeView(nativeAdViewLovin)
////                parentView.removeView(nativeAdViewLovin)
//                parentView.removeAllViews()
//                parentView.addView(nativeAdViewLovin)
//            } catch (e: Exception) {
//
//            }
//        }
//    }

//    private fun createNativeAdView(context: Context): MaxNativeAdView? {
//        val binder = MaxNativeAdViewBinder.Builder(R.layout.layout_chat_applovin_native)
//            .setTitleTextViewId(R.id.title_text_view)
//            .setIconImageViewId(R.id.icon_image_view)
//            .setCallToActionButtonId(R.id.cta_button)
//            .build()
//
//        val nativeAdView = MaxNativeAdView(binder, context)
//
//        // Get the CTA button from the native ad view
//        val ctaButton = nativeAdView.findViewById<Button>(R.id.cta_button)
//        val adsBubbleView = nativeAdView.findViewById<RelativeLayout>(R.id.adsBubbleView)
//        val title_text_view = nativeAdView.findViewById<TextView>(R.id.title_text_view)
//
//
//        adsBubbleView.setBackgroundResource(
//            getBubbleAds(
//                emojiOnly = false,
//                canGroupWithPrevious = false,
//                canGroupWithNext = false,
//                style = context.config.bubbleStyle
//            )
//        )
//
//
//        val backgroundColorOne =
//            context.config.getIntData("backgroundColorone", Color.parseColor("#E7F0FB"))
//        try {
//            adsBubbleView.setBackgroundTint(backgroundColorOne)
//            title_text_view.setTextColor(
//                ContextCompat.getColor(
//                    context,
//                    R.color.black
//                )
//            )
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//
//        // Set the text color of the CTA button
//        ctaButton.setTextColor(context.baseConfig.primaryColor)
//
//        val applyBackground = ResourcesCompat.getDrawable(
//            context.resources,
//            R.drawable.ads_item_gradiant_rounded,
//            null
//        ) as LayerDrawable
//        val strokeDrawable =
//            applyBackground.findDrawableByLayerId(R.id.button_background_ads) as GradientDrawable
//        strokeDrawable.setStroke(2, context.baseConfig.primaryColor)
//
//        ctaButton.background = applyBackground
//
//
//        return nativeAdView
//    }

    public fun showNativeAd(
        mContext: Context,
        frameLayout: FrameLayout,
        mNativeAd: NativeAd? = null,
        adId: String,
    ) {
        if (mNativeAd != null) {
            populateAdmobNativeAd(mContext, frameLayout, mNativeAd)
        } else {
            preLoad(mContext, { isLoaded, nativeAd ->
                if (isLoaded) {
                    populateAdmobNativeAd(mContext, frameLayout, nativeAd!!)
                }
            }, adId)
        }
    }



    public fun showOTPNativeAd(
        mContext: Context,
        frameLayout: FrameLayout,
        placeHolder: View,
        adId: String,
    ) {

        LoadOTPNative(mContext, { isLoaded, nativeAd ->
                if (isLoaded) {
                    Log.e("fddfdfdfdd", "isLoaded")
                    populateSmallAdmobNativeAd(mContext, frameLayout, placeHolder, nativeAd!!)
                } else {
                    Log.e("fddfdfdfdd", "Not isLoaded")
                    frameLayout.visibility = View.GONE
                    placeHolder.visibility = View.GONE
                }
            }, adId)
    }



    private fun populateSmallAdmobNativeAd(
        mContext: Context,
        frameLayout: FrameLayout,
        placeHolder: View,
        nativeAd: NativeAd,
    ) {

        val mTextColor = ContextCompat.getColor(mContext, R.color.title_color)
        val mBodyColor = ContextCompat.getColor(mContext, R.color.body_color)
        val mLayout = R.layout.layout_otp_native
        val adView = LayoutInflater.from(mContext).inflate(mLayout, null) as NativeAdView

        frameLayout.visibility = View.VISIBLE
        placeHolder.visibility = View.GONE
        frameLayout.removeAllViews()
        frameLayout.addView(adView)

        val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
        if (headlineView != null) {
            headlineView.setTextColor(mTextColor)
            headlineView.text = nativeAd.headline
            adView.headlineView = headlineView
        }

        val bodyView = adView.findViewById<TextView>(R.id.ad_body)
        if (bodyView != null) {
            bodyView.setTextColor(mBodyColor)
            bodyView.text = nativeAd.body
            adView.bodyView = bodyView
        }


        val callToActionView = adView.findViewById<TextView>(R.id.ad_call_to_action)
        if (callToActionView != null) {
            callToActionView.text = nativeAd.callToAction
            adView.callToActionView = callToActionView
        }

        val adAppIcon = adView.findViewById<ImageView>(R.id.ad_app_icon)
        if (adAppIcon != null && nativeAd.icon != null) {
            adAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
            adView.iconView = adAppIcon
        }

        adView.setNativeAd(nativeAd)
    }



    private fun populateAdmobNativeAd(
        mContext: Context,
        frameLayout: FrameLayout,
        nativeAd: NativeAd,
    ) {

        val mTextColor = ContextCompat.getColor(mContext, R.color.title_color)
        val mBodyColor = ContextCompat.getColor(mContext, R.color.body_color)
        val mLayout = R.layout.layout_google_native_ad_bigg
        val adView = LayoutInflater.from(mContext).inflate(mLayout, null) as NativeAdView
        frameLayout.removeAllViews()
        frameLayout.addView(adView)
        frameLayout.visibility = View.VISIBLE

        val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
        if (headlineView != null) {
            headlineView.setTextColor(mTextColor)
            headlineView.text = nativeAd.headline
            adView.headlineView = headlineView
        }

        val bodyView = adView.findViewById<TextView>(R.id.ad_body)
        if (bodyView != null) {
            bodyView.setTextColor(mBodyColor)
            bodyView.text = nativeAd.body
            adView.bodyView = bodyView
        }

        /* val adChoiceView = adView.findViewById<AdChoicesView>(R.id.adChoiceView)
         if (adChoiceView != null) {
             adView.adChoicesView = adChoiceView
         }

         val adPrice = adView.findViewById<TextView>(R.id.ad_price)
         if (adPrice != null) {
             adPrice.setTextColor(mBodyColor)
             adPrice.text = nativeAd.price
             adView.priceView = adPrice
         }

         val adStore = adView.findViewById<TextView>(R.id.ad_store)
         if (adStore != null) {
             adStore.setTextColor(mBodyColor)
             adStore.text = nativeAd.store
             adView.storeView = adStore
         }*/

        val callToActionView = adView.findViewById<TextView>(R.id.ad_call_to_action)
        if (callToActionView != null) {
            callToActionView.text = nativeAd.callToAction
            adView.callToActionView = callToActionView
        }

        val adAppIcon = adView.findViewById<ImageView>(R.id.ad_app_icon)
        if (adAppIcon != null && nativeAd.icon != null) {
            adAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
            adView.iconView = adAppIcon
        }

        val adStars = adView.findViewById<RatingBar>(R.id.ad_stars)
        if (adStars != null && nativeAd.starRating != null) {
            adStars.rating = nativeAd.starRating!!.toFloat()
            adView.starRatingView = adStars
        }

        val advertiser = adView.findViewById<TextView>(R.id.ad_advertiser)
        if (advertiser != null) {
            advertiser.text = nativeAd.advertiser
            adView.advertiserView = advertiser
        }

        try {
            val mediaView = adView.findViewById<MediaView>(R.id.ad_media)
            if (mediaView != null) {
                mediaView.visibility = View.VISIBLE
                adView.mediaView = mediaView
                nativeAd.mediaContent?.let {
                    mediaView.setMediaContent(it)
                }
                mediaView.setImageScaleType(ImageView.ScaleType.FIT_CENTER)
            }
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }

        adView.setNativeAd(nativeAd)
    }

    fun populateManageAppNativeAd(
        context: Context,
        view: View,
        nativeAd: NativeAd,
    ) {

        val applyBackground = ResourcesCompat.getDrawable(
            context.resources,
            R.drawable.ads_big_gradiant_rounded,
            null
        ) as LayerDrawable

        LayoutManageAppNativeBinding.bind(view).apply {
            adHeadline.text = nativeAd.headline
            adBody.text = nativeAd.body
            adCallToAction.text = nativeAd.callToAction

            if (nativeAd.icon != null) {
                ivAdAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
                nativeAdView.iconView = ivAdAppIcon
            } else {
                cvAppIcon.layoutParams.width = 0
            }
            adMedia.mediaContent = nativeAd.mediaContent
            adMedia.setImageScaleType(ImageView.ScaleType.FIT_CENTER)
            nativeAdView.headlineView = adHeadline
            nativeAdView.callToActionView = adCallToAction
            nativeAdView.mediaView = adMedia
            nativeAdView.setNativeAd(nativeAd)

            cvRoot.background = applyBackground

            shimmerView.beGone()
            nativeAdView.beVisible()
        }
    }


    fun populateLanguageNativeAd(
        view: View,
        nativeAd: NativeAd,
    ) {
        LayoutLanguageBigNativeBinding.bind(view).apply {
            adHeadline.text = nativeAd.headline
            adBody.text = nativeAd.body
            adCallToAction.text = nativeAd.callToAction

            if (nativeAd.icon != null) {
                ivAdAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
                nativeAdView.iconView = ivAdAppIcon
            } else {
                cvAppIcon.layoutParams.width = 0
            }
            adMedia.mediaContent = nativeAd.mediaContent
            adMedia.setImageScaleType(ImageView.ScaleType.FIT_CENTER)
            nativeAdView.headlineView = adHeadline
            nativeAdView.bodyView = adBody
            nativeAdView.callToActionView = adCallToAction
            nativeAdView.mediaView = adMedia
            nativeAdView.setNativeAd(nativeAd)
            shimmerView.beGone()
            nativeAdView.beVisible()
        }
    }

    var nativeAdChat: NativeAd? = null

    fun populateChatNativeAd(
        mContext: Context,
        view: View,
    ) {
        if (nativeAdChat == null) return

        val nativeAd = nativeAdChat
        /* val applyBackground = ResourcesCompat.getDrawable(
             mContext.resources,
             R.drawable.ads_item_gradiant_rounded,
             null
         ) as LayerDrawable
         val strokeDrawable =
             applyBackground.findDrawableByLayerId(R.id.button_background_ads) as GradientDrawable
         strokeDrawable.setStroke(2, mContext.baseConfig.primaryColor)*/

        /* val applyBackground = ResourcesCompat.getDrawable(
             mContext.resources,
             R.drawable.ads_item_gradiant_rounded,
             null
         )

         if (applyBackground is LayerDrawable) {
             val strokeDrawable =
                 applyBackground.findDrawableByLayerId(R.id.button_background_ads) as GradientDrawable
             strokeDrawable.setStroke(2, mContext.baseConfig.primaryColor)
         } else if (applyBackground is GradientDrawable) {
             applyBackground.setStroke(2, mContext.baseConfig.primaryColor)
         }*/

        val applyBackground = ResourcesCompat.getDrawable(
            mContext.resources,
            R.drawable.ads_big_bg_rounded,
            null
        )





        LayoutChatNativeBinding.bind(view).apply {

            if (nativeAd?.body?.isNotBlank() == true) {

                adHeadline.text = nativeAd.body
            } else {

                adHeadline.text = nativeAd?.headline
            }

            /*  adsBubbleView.setBackgroundResource(
                  getBubbleAds(
                      emojiOnly = false,
                      canGroupWithPrevious = false,
                      canGroupWithNext = false,
                      style = mContext.config.bubbleStyle
                  )
              )*/


            val backgroundColorOne =
                mContext.config.getIntData("backgroundColorone", Color.parseColor("#E7F0FB"))
            try {
                // adsBubbleView.setBackgroundTint(backgroundColorOne)
                adHeadline.setTextColor(
                    ContextCompat.getColor(
                        mContext,
                        R.color.black
                    )
                )
                //                    holder.binding.body.setColors(R.string.black,backgroundColorOne)
            } catch (e: Exception) {
                e.printStackTrace()
            }

            adCallToAction.text = nativeAd?.callToAction
            //   adCallToAction.setTextColor(mContext.baseConfig.primaryColor)
            adCallToAction.background = applyBackground

            if (nativeAd?.icon != null) {
                ivAdAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
                nativeAdView.iconView = ivAdAppIcon
            } else {
                ivAdAppIcon.layoutParams.height = 0
            }
            nativeAdView.headlineView = adHeadline
            nativeAdView.callToActionView = adCallToAction
            nativeAdView.setNativeAd(nativeAd!!)
            nativeAdView.beVisible()
        }
    }

    fun populateExitNativeAd(
        mContext: Context,
        view: View,
        nativeAd: NativeAd,
    ) {

        LayoutLanguageBigNativeBinding.bind(view).apply {
//            adCallToAction.setTextColor(Color.WHITE)
            adHeadline.text = nativeAd.headline
            adBody.text = nativeAd.body
            adCallToAction.text = nativeAd.callToAction

            if (nativeAd.icon != null) {
                ivAdAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
                nativeAdView.iconView = ivAdAppIcon
            } else {
                cvAppIcon.layoutParams.width = 0
            }
            adMedia.mediaContent = nativeAd.mediaContent
            adMedia.setImageScaleType(ImageView.ScaleType.FIT_CENTER)
            nativeAdView.headlineView = adHeadline
            nativeAdView.bodyView = adBody
            nativeAdView.callToActionView = adCallToAction
            nativeAdView.mediaView = adMedia
            nativeAdView.setNativeAd(nativeAd)
            shimmerView.beGone()
            nativeAdView.beVisible()
        }
    }

    fun populateSmallNativeAd(
        mContext: Context,
        view: View,
        nativeAd: NativeAd,
    ) {

        try {
            val applyBackground = ResourcesCompat.getDrawable(
                mContext.resources,
                R.drawable.ads_big_bg_rounded,
                null
            ) as LayerDrawable
            val strokeDrawable =
                //  strokeDrawable.setStroke(2, mContext.baseConfig.primaryColor)

            LayoutListItemNativeBinding.bind(view).apply {
                //            if(adCallToAction!=null) adCallToAction.setTextColor(Color.WHITE)
                adHeadline.text = nativeAd.headline
                adBody.text = nativeAd.body

//                try {
//                    val typeface =
//                        ResourcesCompat.getFont(mContext, mContext.baseConfig.selectedFont)
//                    adBody.setTypeface(typeface)
//                } catch (_: Exception) {
//                }

                adCallToAction.text = nativeAd.callToAction
                adCallToAction.text = setMaxCharacters(adCallToAction.text.toString(), 8)
                //      adCallToAction.setTextColor(mContext.baseConfig.primaryColor)
                adCallToAction.background = applyBackground

                if (nativeAd.icon != null) {
                    ivAdAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
                    nativeAdView.iconView = ivAdAppIcon
                } else {
                    ivAdAppIcon.layoutParams.width = 0
                }
                nativeAdView.headlineView = adHeadline
                nativeAdView.bodyView = adBody
                nativeAdView.callToActionView = adCallToAction
                nativeAdView.setNativeAd(nativeAd)
                nativeAdView.setBackgroundColor(view.context.resources.getColor(R.color.smallnativebg))
                shimmerView.beGone()
                nativeAdView.beVisible()

            }
        } catch (e: Exception) {
        }
    }

    fun setMaxCharacters(text: String, maxChars: Int): String {
        if (text.length > maxChars) {
            return text.substring(0, maxChars) + "..."
        } else {
            return text
        }
    }

}