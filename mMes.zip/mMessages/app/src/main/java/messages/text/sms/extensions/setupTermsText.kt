package messages.text.sms.extensions

import android.graphics.Color
import android.text.SpannableString
import android.text.Spanned
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat
import messages.text.sms.R

fun setupTermsText(
    textView: TextView,
    onPrivacyClick: () -> Unit,
    onTermsClick: () -> Unit,
) {
    val context = textView.context

    val policy = context.getString(R.string.privacy_policy_)
    val terms = context.getString(R.string.terms)

    // this text already contains placeholders %1$s %2$s
    val text = context.getString(
        R.string.by_clicking_setup_now,
        policy,
        terms
    )

    val spannable = SpannableString(text)

    val policyStart = text.indexOf(policy).takeIf { it >= 0 } ?: return
    val policyEnd = policyStart + policy.length

    val termsStart = text.indexOf(terms).takeIf { it >= 0 } ?: return
    val termsEnd = termsStart + terms.length

    val linkColor = ContextCompat.getColor(context, R.color.primary)


    val privacyClickable = object : ClickableSpan() {
        override fun onClick(widget: View) = onPrivacyClick()
        override fun updateDrawState(ds: TextPaint) {
            ds.color = linkColor
            ds.isUnderlineText = false
        }
    }

    val termsClickable = object : ClickableSpan() {
        override fun onClick(widget: View) = onTermsClick()
        override fun updateDrawState(ds: TextPaint) {
            ds.color = linkColor
            ds.isUnderlineText = false
        }
    }

    spannable.setSpan(
        privacyClickable,
        policyStart,
        policyEnd,
        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
    )

    spannable.setSpan(
        termsClickable,
        termsStart,
        termsEnd,
        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
    )

    textView.text = spannable
    textView.movementMethod = LinkMovementMethod.getInstance()
    textView.highlightColor = Color.TRANSPARENT
}
