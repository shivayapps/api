package messages.text.sms.feature.personalize

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.SeekBar
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.GridLayoutManager
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.ads.MainInterAdManager
import messages.text.sms.ads.app_font_activity_open
import messages.text.sms.ads.app_font_setting_applied
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.common.MysmsApplication.Companion.isHomeInterShow
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.adapters.FontListAdapter
import messages.text.sms.commons.extensions.applyColorFilter
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.clientConfigPref
import messages.text.sms.commons.extensions.config
import messages.text.sms.commons.extensions.getBottomNavigationBackgroundColor
import messages.text.sms.commons.extensions.getBottomNavigationBackgroundColorFont
import messages.text.sms.commons.extensions.toast
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.ActivityFontBinding
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.THEME_CHANGED
import org.greenrobot.eventbus.EventBus

class FontActivity : MainBaseThemedActivity() {


    private lateinit var adapter: FontListAdapter
    private lateinit var fontList: MutableList<Int>

    var checkfontsize = 16;
    var checkfontname = -1

    private val binding by viewBinding(ActivityFontBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)


        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)
        showBackButton(true)
        setTitle(R.string.title_font)

        setUI()
        setUpListener()
        setUpTheme()

        /*  val background = ResourcesCompat.getDrawable(
              resources,
              R.drawable.message_simple_out_last,
              null
          )
  */
        setDynamicDrawable(
            binding.tvone,
            Color.parseColor("#F6F7F9"),
            Color.parseColor("#ECEDEF")
        )

        val stokeTwo =
            config.getIntData("stokeTwo", Color.parseColor("#C3E3FF"))
        val backgroundColorTwo =
            config.getIntData("backgroundColortwo", Color.parseColor("#E6F3FF"))

        setDynamicDrawable(
            binding.tvtwo,
            backgroundColorTwo,
            stokeTwo
        )


        val mTempBackgroundTextColorTwo = Color.parseColor("#FFFFFF")
        val mTempBackgroundColorOne = Color.parseColor("#E7F0FB")
        //    binding.tvtwo.setTextColor(mTempBackgroundTextColorTwo)
        //    binding.tvone.background = background
        //binding.tvone.background.applyColorFilter(mTempBackgroundColorOne)
        binding.btnApply.setTextColor(Color.parseColor("#FFFFFF"))

        firebaseAnalyticsHandler.logMessages(
            app_font_activity_open, getActivityName()
        )


    }

    fun setDynamicDrawable(view: View, bgColor: Int, strokeColor: Int) {
        val drawable =
            view.context.getDrawable(R.drawable.message_simple_out_last) as GradientDrawable
        drawable.setColor(bgColor)
        drawable.setStroke(4, strokeColor)
        view.background = drawable
    }

    private fun setUpTheme() {

        binding.fontSizeSeekBar.setTint(baseConfig.primaryColor)
        binding.fontSizeSeekBar.progressDrawable.setTint(baseConfig.primaryColor)
        binding.fontSizeSeekBar.thumb.setTint(baseConfig.primaryColor)

        updateTextColors(binding.contentView)
        //   binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {

            try {
                binding.contentView.background =
                    ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
            } catch (_: Exception) {

            }

//            arrayListOf(binding.ivBack).forEach {
//                val colorStateList = ColorStateList.valueOf(Color.WHITE)
//                it.imageTintList = colorStateList
//            }
        } else {
            try {
                binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
            } catch (_: Exception) {
            }
//            arrayListOf(binding.ivBack).forEach {
////                val whiteColor = ContextCompat.getColor(this, R.color.black)
//                val colorStateList = ColorStateList.valueOf(Color.BLACK)
//                it.imageTintList = colorStateList
//            }
        }

        try {
            if (baseConfig.useImageResource) {
                if (baseConfig.storedImageResource == -1) {

                } else {
                    Log.i("onCreate", "onCreateitemselse11111: ")
                    try {
                        val drawable =
                            ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                        binding.contentView.background = drawable

                        toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
                    } catch (_: Exception) {

                    }
                }
            } else {
                val primaryColor = baseConfig.primaryColor
                Log.i("onCreate", "onCreateitemselse: ")
                toolbar.setBackgroundColor(baseConfig.backgroundColor)
            }
        } catch (_: Exception) {

        }


        try {
            arrayOf(
                binding.llbottom,
            ).forEach {
                if (baseConfig.useImageResource == true) {
                    if (baseConfig.storedImageResource == -1) {

                    } else {
                        try {
                            it.background.applyColorFilter(resources.getColor(R.color.transperent30))
                        } catch (_: Exception) {
                        }
                    }
                } else {
                    it.background.applyColorFilter(getBottomNavigationBackgroundColor())
                }
            }
        } catch (_: Exception) {

        }

    }

    private fun setUI() {
        binding.btnApply.backgroundTintList = ColorStateList.valueOf(baseConfig.primaryColor)
        binding.btnApply.setTextColor(Color.parseColor("#FFFFFF"))

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.root.background = drawable
            }
        }

        try {
            binding.imDivider.background.applyColorFilter(getBottomNavigationBackgroundColorFont())
        } catch (_: Exception) {

        }


//        binding.llbottom.background.applyColorFilter(resources.getColor(R.color.transperent30))

        checkfontname = prefs.selectedFont.get()
        checkfontsize = prefs.textSize.get()

        try {
            val typeface = ResourcesCompat.getFont(this, checkfontname)
            binding.tvone.typeface = typeface
            binding.tvtwo.typeface = typeface
        } catch (_: Exception) {
        }

        binding.tvone.textSize = checkfontsize.toFloat()
        binding.tvtwo.textSize = checkfontsize.toFloat()

        binding.recyclerView.layoutManager = GridLayoutManager(this, 3)
        fontList = getFontList()
        adapter = FontListAdapter(this@FontActivity, fontList, checkfontname) { selectedFont ->
            checkfontname = selectedFont

            try {
                val checkTypeface = ResourcesCompat.getFont(this, selectedFont)
                binding.tvone.setTypeface(checkTypeface, checkTypeface?.style ?: Typeface.NORMAL)
                binding.tvtwo.setTypeface(checkTypeface, checkTypeface?.style ?: Typeface.NORMAL)
            } catch (_: Exception) {
            }
        }
        binding.recyclerView.adapter = adapter

    }


    override fun onBackPressed() {

        if (clientConfigPref.enableBackPressInter && !isHomeInterShow) {
            Log.e("Message_Log", "enable_back_press_inter - showMainInterAds")

            MainInterAdManager.showMainInterAds(this) {
                Log.e("Message_Log", "enable_back_press_inter - isHomeInterShow = true")
                isHomeInterShow = true
                finish()
            }

        } else {
            Log.e("Message_Log", "enable_back_press_inter - finish")
            finish()
        }
    }


    private fun getFontList(): MutableList<Int> {
        val fonts: MutableList<Int> = ArrayList()
        fonts.add(R.font.acme_regular)
        fonts.add(R.font.courgette_regular)
        fonts.add(R.font.josefinslab_regular)
        fonts.add(R.font.lato_regular)
        fonts.add(R.font.libre_baskerville)
        fonts.add(R.font.montserrat_regular)
        fonts.add(R.font.notoserif_regular)
        fonts.add(R.font.opensans_regular)
        fonts.add(R.font.poetsen_one)
        fonts.add(R.font.poppins_regular)
        fonts.add(R.font.roboto)
        fonts.add(R.font.rubik_regular)

        return fonts
    }

    var newFontSize = 16;
    private fun setUpListener() {

        newFontSize = prefs.textSize.get()

        binding.fontSizeSeekBar.setProgress(prefs.textSize.get())
        binding.fontSizeSeekBar.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                // Update font size of the TextView based on the progress range 10-20
                val fontSize = progress // Adjust to start from 10
                newFontSize = fontSize
                binding.tvone.textSize = fontSize.toFloat()
                binding.tvtwo.textSize = fontSize.toFloat()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // Not needed
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                // Not needed
            }
        })

        binding.btnApply.setOnClickListener {
            prefs.selectedFont.set(checkfontname)
            baseConfig.selectedFont = checkfontname
            prefs.textSize.set(newFontSize)
            EventBus.getDefault().post(MessageEvent(THEME_CHANGED))
            toast(getString(R.string.setting_applied))
            prefs.themechanged.set(true)

            firebaseAnalyticsHandler.logMessages(
                app_font_setting_applied, getActivityName()
            )
        }
    }
}