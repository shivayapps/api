package messages.text.sms.common

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R

class CustomDialogAdapter(
    private val items: List<String>,
    private val itemClickListener: (String, Int) -> Unit,
) : RecyclerView.Adapter<CustomDialogAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val quickMessage: TextView = itemView.findViewById(R.id.quickMessage)
        val icIconLoad: ImageView = itemView.findViewById(R.id.icIconLoad)
        val mainItemQuickReply: LinearLayout = itemView.findViewById(R.id.mainItemQuickReply)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.quick_reply_item_dialog, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.quickMessage.text = item
        holder.itemView.setOnClickListener {
            itemClickListener(item, position)
        }

        when (position) {
            items.size - 2 -> {
                // Second to last item
                holder.icIconLoad.setImageResource(R.drawable.icons_chat_quick_item_text) // Replace with your icon resource
            }

            items.size - 1 -> {
                // Last item
                holder.icIconLoad.setImageResource(R.drawable.setting) // Replace with your icon resource
            }

            else -> {
                // Other items
                holder.icIconLoad.setImageResource(R.drawable.icons_chat_dots) // Replace with your icon resource
            }
        }

        // Determine the tint color based on the theme
        /* val tintColor = ContextCompat.getColor(
             holder.mainItemQuickReply.context,
             if (holder.mainItemQuickReply.context.callerCadBaseConfig.callerCardDarkTheme) {
                 R.color.white // Dark theme color
             } else {
                 R.color.white // Light theme color
             }
         )*/
        val tintColor = ContextCompat.getColor(
            holder.mainItemQuickReply.context,
            R.color.white
        )

        val textColor = ContextCompat.getColor(
            holder.mainItemQuickReply.context,
            R.color.black
        )

        val tintColorStateList = ContextCompat.getColorStateList(
            holder.mainItemQuickReply.context,
            R.color.iconColor
        )

        ContextCompat.getDrawable(
            holder.mainItemQuickReply.context,
            R.drawable.custom_bordered_home_ripple
        )?.let { drawable ->
            val mutableDrawable = drawable.mutate() // Ensure the drawable is mutable
            mutableDrawable.setTint(tintColor) // Apply the tint color
            holder.mainItemQuickReply.background = mutableDrawable // Set as background
            holder.quickMessage.setTextColor(textColor)
            holder.icIconLoad.imageTintList = tintColorStateList

        }
    }

    override fun getItemCount(): Int = items.size
}