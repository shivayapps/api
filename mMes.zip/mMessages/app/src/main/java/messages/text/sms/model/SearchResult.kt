package messages.text.sms.model

data class SearchResult(val query: String, val conversation: Conversation, val messages: Int)