package messages.text.sms.feature.conversationinfo

import android.content.Context
import androidx.lifecycle.Lifecycle
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.Observables
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.rxkotlin.withLatestFrom
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MainBasePresenter
import messages.text.sms.common.util.ClipboardUtils
import messages.text.sms.common.util.extensions.makeToast
import messages.text.sms.extensions.asObservable
import messages.text.sms.extensions.mapNotNull
import messages.text.sms.feature.conversationinfo.ConversationInfoItem.ConversationInfoMedia
import messages.text.sms.feature.conversationinfo.ConversationInfoItem.ConversationInfoRecipient
import messages.text.sms.interactor.DeleteConversations
import messages.text.sms.interactor.MarkArchived
import messages.text.sms.interactor.MarkRecycle
import messages.text.sms.interactor.MarkUnRecycle
import messages.text.sms.interactor.MarkUnarchived
import messages.text.sms.manager.PermissionManager
import messages.text.sms.model.Conversation
import messages.text.sms.model.DELETE_FROM_INFO
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.NEW_MSG_UPDATE_AVAILABLE
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.repository.MessageRepository
import messages.text.sms.util.appPreference
import org.greenrobot.eventbus.EventBus
import javax.inject.Inject
import javax.inject.Named

class ConversationInfoPresenter @Inject constructor(
    @Named("threadId") threadId: Long,
    messageRepo: MessageRepository,
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val deleteConversations: DeleteConversations,
    private val markArchived: MarkArchived,
    private val markUnarchived: MarkUnarchived,
    private val markRecycle: MarkRecycle,
    private val markUnRecycle: MarkUnRecycle,
    private val navigator: Navigator,
    private val permissionManager: PermissionManager,
) : MainBasePresenter<ConversationInfoView, ConversationInfoState>(
    ConversationInfoState(threadId = threadId)
) {

    private val conversation: Subject<Conversation> = BehaviorSubject.create()

    init {
        disposables += conversationRepo.getConversationAsync(threadId)
            .asObservable()
            .filter { conversation -> conversation.isLoaded }
            .doOnNext { conversation ->
                if (!conversation.isValid) {
                    newState { copy(hasError = true) }
                }
            }
            .filter { conversation -> conversation.isValid }
            .filter { conversation -> conversation.id != 0L }
            .subscribe(conversation::onNext)

        disposables += markArchived
        disposables += markUnarchived
        disposables += markRecycle
        disposables += markUnRecycle
        disposables += deleteConversations

        disposables += Observables
            .combineLatest(
                conversation,
                messageRepo.getPartsForConversation(threadId).asObservable()
            ) { conversation, parts ->
                val data = mutableListOf<ConversationInfoItem>()

                // If some data was deleted, this isn't the place to handle it
                if (!conversation.isLoaded || !conversation.isValid || !parts.isLoaded || !parts.isValid) {
                    return@combineLatest
                }

                data += conversation.recipients.map(::ConversationInfoRecipient)
                data += ConversationInfoItem.ConversationInfoSettings(
                    name = conversation.name,
                    recipients = conversation.recipients,
                    archived = conversation.archived,
                    blocked = conversation.blocked
                )
                data += parts.map(::ConversationInfoMedia)

                newState { copy(data = data) }
            }
            .subscribe()
    }

    override fun bindIntents(view: ConversationInfoView) {
        super.bindIntents(view)

        // Add or display the contact
        view.recipientClicks()
            .mapNotNull(conversationRepo::getRecipient)
            .doOnNext { recipient ->
                recipient.contact?.lookupKey?.let(navigator::showContact)
                    ?: navigator.addContact(recipient.address)
            }
            .autoDisposable(view.scope(Lifecycle.Event.ON_DESTROY)) // ... this should be the default
            .subscribe()

        // Copy phone number
        view.recipientLongClicks()
            .mapNotNull(conversationRepo::getRecipient)
            .map { recipient -> recipient.address }
            .observeOn(AndroidSchedulers.mainThread())
            .autoDisposable(view.scope())
            .subscribe { address ->
                ClipboardUtils.copy(context, address)
                context.makeToast(R.string.info_copied_address)
            }

        // Show the theme settings for the conversation
        view.themeClicks()
            .autoDisposable(view.scope())
            .subscribe(view::showThemePicker)

        // Show the conversation title dialog
        view.nameClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .map { conversation -> conversation.name }
            .autoDisposable(view.scope())
            .subscribe(view::showNameDialog)

        // Set the conversation title
        view.nameChanges()
            .withLatestFrom(conversation) { name, conversation ->
                conversationRepo.setConversationName(conversation.id, name)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
            }
            .flatMapCompletable { it }
            .autoDisposable(view.scope())
            .subscribe {
                EventBus.getDefault().post(MessageEvent(NEW_MSG_UPDATE_AVAILABLE))
            }

        // Show the notifications settings for the conversation
        view.notificationClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDisposable(view.scope())
            .subscribe { conversation -> navigator.showNotificationSettings(conversation.id) }

        // Toggle the archived state of the conversation
        view.archiveClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDisposable(view.scope())
            .subscribe { conversation ->
                when (conversation.archived) {
                    true -> markUnarchived.execute(listOf(conversation.id)) {
                        context.appPreference.isRefreshMessages = true
                        context.appPreference.isRefreshArchiveMessages = true
                    }

                    false -> markArchived.execute(listOf(conversation.id)) {
                        context.appPreference.isRefreshMessages = true
                    }
                }

            }

        // Show the delete confirmation dialog
//        view.deleteClicks()
//            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
//            .autoDisposable(view.scope())
//            .subscribe { view.showDeleteDialog() }
        view.deleteClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDisposable(view.scope())
            .subscribe { conversation ->
                view.showDeleteDialog()
                /*when (conversation.archived) {
                    true -> markUnRecycle.execute(listOf(conversation.id)) {
                        context.appPreference.isRefreshMessages = true


                    }

                    false -> markRecycle.execute(listOf(conversation.id)) {
                        context.appPreference.isRefreshMessages = true
                        EventBus.getDefault().post(MessageEvent(DELETE_FROM_INFO, conversation.id))
                    }
                }*/


            }

        // Toggle the blocked state of the conversation
        view.blockClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDisposable(view.scope())
            .subscribe { conversation ->
                view.showBlockingDialog(
                    listOf(conversation.id),
                    !conversation.blocked
                )

            }


        // Delete the conversation
        view.confirmDelete()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDisposable(view.scope())
            .subscribe { conversation ->
                deleteConversations.execute(listOf(conversation.id)) {
                    EventBus.getDefault().post(MessageEvent(DELETE_FROM_INFO, conversation.id))
                }
            }

        // Media
        view.mediaClicks()
            .autoDisposable(view.scope())
            .subscribe(navigator::showMedia)
    }

}