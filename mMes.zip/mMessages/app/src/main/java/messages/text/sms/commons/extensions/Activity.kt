package messages.text.sms.commons.extensions

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import messages.text.sms.R
import messages.text.sms.common.widget.BabyTextView
import messages.text.sms.databinding.DialogTitleBinding

fun Activity.launchCustomizeNotificationsIntent() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
            putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            startActivity(this)
        }
    }
}

fun Activity.getAlertDialogBuilder() = AlertDialog.Builder(this)

fun Activity.setupDialogStuffnew(
    view: View,
    dialog: AlertDialog.Builder,
    titleId: Int = 0,
    titleText: String = "",
    cancelOnTouchOutside: Boolean = true,
    callback: ((alertDialog: AlertDialog) -> Unit)? = null,
) {
    if (isDestroyed || isFinishing) {
        return
    }

    val textColor = getProperTextColor()
    val backgroundColor = getProperBackgroundColor()
    val primaryColor = config.primaryColor
    if (view is ViewGroup) {
        updateTextColors(view)
    } else if (view is BabyTextView) {
        view.setColors(textColor, primaryColor, backgroundColor)
    }

    val alertDialog = dialog.create()
    if (titleId != 0) {
        alertDialog.setTitle(titleId)
    } else if (titleText.isNotEmpty()) {
        alertDialog.setTitle(titleText)
    }

    alertDialog.setView(view)
    alertDialog.setCancelable(cancelOnTouchOutside)
    if (!isFinishing) {
        alertDialog.show()
    }

    alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(primaryColor)
    alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(primaryColor)
    alertDialog.getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(getColor(R.color.black))


    val bgDrawable = resources.getColoredDrawableWithColor(
        this@setupDialogStuffnew,
        R.drawable.dialog_bg,
        baseConfig.backgroundColor
    )

    alertDialog.window?.setBackgroundDrawable(bgDrawable)

    alertDialog.findViewById<View>(android.R.id.content)?.post {
        val titleView = alertDialog.findViewById<TextView>(
            resources.getIdentifier(
                "alertTitle",
                "id",
                packageName
            )
        )
        val messageView = alertDialog.findViewById<TextView>(android.R.id.message)

        titleView?.setTextColor(textColor)
        messageView?.setTextColor(textColor)
    }

    callback?.invoke(alertDialog)
}

fun Activity.setupDialogStuff(
    view: View,
    dialog: AlertDialog.Builder,
    titleId: Int = 0,
    titleText: String = "",
    cancelOnTouchOutside: Boolean = true,
    callback: ((alertDialog: AlertDialog) -> Unit)? = null,
) {


    if (isDestroyed || isFinishing) {
        return
    }

    val textColor = getProperTextColor()
    val backgroundColor = getProperBackgroundColor()
    val primaryColor = config.primaryColor
    if (view is ViewGroup) {
        updateTextColors(view)
    } else if (view is BabyTextView) {
        view.setColors(textColor, primaryColor, backgroundColor)
    }


    if (dialog is MaterialAlertDialogBuilder) {
        dialog.create().apply {
            if (titleId != 0) {
                setTitle(titleId)
            } else if (titleText.isNotEmpty()) {
                setTitle(titleText)
            }

            window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
            setView(view)
            setCancelable(cancelOnTouchOutside)
            if (!isFinishing) {
                show()
            }
            getButton(Dialog.BUTTON_POSITIVE)?.setTextColor(primaryColor)
            getButton(Dialog.BUTTON_NEGATIVE)?.setTextColor(primaryColor)
            getButton(Dialog.BUTTON_NEUTRAL)?.setTextColor(primaryColor)

            callback?.invoke(this)
        }
    } else {
        var title: DialogTitleBinding? = null
        if (titleId != 0 || titleText.isNotEmpty()) {
            title = DialogTitleBinding.inflate(layoutInflater, null, false)
            title.dialogTitleTextview.apply {
                if (titleText.isNotEmpty()) {
                    text = titleText
                } else {
                    setText(titleId)
                }
                setTextColor(textColor)
            }
        }

        // if we use the same primary and background color, use the text color for dialog confirmation buttons
//        val dialogButtonColor = if (primaryColor == baseConfig.backgroundColor) {
//            textColor
//        } else {
        val dialogButtonColor = primaryColor
//        }

        dialog.create().apply {
            setView(view)
            requestWindowFeature(Window.FEATURE_NO_TITLE)
            setCustomTitle(title?.root)
            setCanceledOnTouchOutside(cancelOnTouchOutside)

            window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
            if (!isFinishing) {
                show()
            }
            getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(dialogButtonColor)
            getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(dialogButtonColor)
            getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(dialogButtonColor)
            val bgDrawable = resources.getColoredDrawableWithColor(
                this@setupDialogStuff,
                R.drawable.dialog_bg,
                baseConfig.backgroundColor
            )
            window?.setBackgroundDrawable(bgDrawable)
            callback?.invoke(this)
        }
    }
}