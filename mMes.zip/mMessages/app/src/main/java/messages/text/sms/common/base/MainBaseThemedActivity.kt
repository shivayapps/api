package messages.text.sms.common.base

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.preference.PreferenceManager
import android.view.View
import com.f2prateek.rx.preferences2.RxSharedPreferences
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.extensions.resolveThemeBoolean
import messages.text.sms.common.util.extensions.resolveThemeColor
import messages.text.sms.commons.extensions.addBit
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.config
import messages.text.sms.commons.extensions.getContrastColor
import messages.text.sms.commons.extensions.getProperBackgroundColor
import messages.text.sms.commons.extensions.removeBit
import messages.text.sms.commons.helpers.DARK_GREY
import messages.text.sms.extensions.Optional
import messages.text.sms.extensions.asObservable
import messages.text.sms.extensions.mapNotNull
import messages.text.sms.filter.PhoneNumberFilter
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.repository.MessageRepository
import messages.text.sms.util.PhoneNumberUtils
import messages.text.sms.util.Preferences
import java.util.Locale
import java.util.concurrent.TimeUnit
import javax.inject.Inject

/**
 * Base activity that automatically applies any necessary theme theme settings and colors
 *
 * In most cases, this should be used instead of the base MainBaseActivity, except for when
 * an activity does not depend on the theme
 */
abstract class MainBaseThemedActivity : MainBaseActivity() {

    @Inject
    lateinit var colors: Colors

    @Inject
    lateinit var conversationRepo: ConversationRepository

    @Inject
    lateinit var messageRepo: MessageRepository

    @Inject
    lateinit var phoneNumberUtils: PhoneNumberUtils

    @Inject
    lateinit var phoneNumberFilter: PhoneNumberFilter

    @Inject
    lateinit var prefs: Preferences


    /**
     * In case the activity should be themed for a specific conversation, the selected conversation
     * can be changed by pushing the threadId to this subject
     */
    val threadId: Subject<Long> = BehaviorSubject.createDefault(0)

    /**
     * Switch the theme if the threadId changes
     * Set it based on the latest message in the conversation
     */
    val theme: Observable<Colors.Theme> = threadId
        .distinctUntilChanged()
        .switchMap { threadId ->
            val conversation = conversationRepo.getConversation(threadId)
            when {
                conversation == null -> Observable.just(Optional(null))

                conversation.recipients.size == 1 -> Observable.just(Optional(conversation.recipients.first()))

                else -> messageRepo.getLastIncomingMessage(conversation.id)
                    .asObservable()
                    .mapNotNull { messages -> messages.firstOrNull() }
                    .distinctUntilChanged { message -> message.address }
                    .mapNotNull { message ->
                        conversation.recipients.find { recipient ->
                            phoneNumberUtils.compare(recipient.address, message.address)
                        }
                    }
                    .map { recipient -> Optional(recipient) }
                    .startWith(Optional(conversation.recipients.firstOrNull()))
                    .distinctUntilChanged()
            }
        }
        .switchMap { colors.themeObservable(it.value) }

    @SuppressLint("InlinedApi")
    override fun onCreate(savedInstanceState: Bundle?) {
//        setTheme(getActivityThemeRes(prefs.black.get()))
        setTheme(R.style.AppTheme)
        super.onCreate(savedInstanceState)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        // When certain preferences change, we need to recreate the activity


        if (::prefs.isInitialized) {
        } else {
            val shPrefs = PreferenceManager.getDefaultSharedPreferences(this)
            val rxPrefs = RxSharedPreferences.create(shPrefs)
            prefs = Preferences(this, rxPrefs, shPrefs)
        }


        val triggers =
            listOf(prefs.nightMode, prefs.night, prefs.black, prefs.textSize, prefs.systemFont)
        Observable.merge(triggers.map { it.asObservable().skip(1) })
            .debounce(400, TimeUnit.MILLISECONDS)
            .observeOn(AndroidSchedulers.mainThread())
            .autoDisposable(scope())
            .subscribe { recreate() }

        if (config.selectedLanguage.isNotEmpty()) {
            setLocale(config.selectedLanguage)
        }

        // We can only set light nav bar on API 27 in attrs, but we can do it in API 26 here
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.O) {
            val night = !resolveThemeBoolean(R.attr.isLightTheme)
            window.decorView.systemUiVisibility = if (night) 0 else
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        // Some devices don't let you modify android.R.attr.navigationBarColor
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.navigationBarColor = resolveThemeColor(android.R.attr.windowBackground)
        }

        window.statusBarColor = baseConfig.statusBarColor

    }

    fun updateActionbarColor(color: Int = getProperBackgroundColor()) {
        updateStatusBarColor(color)
    }

    fun updateStatusBarColor(color: Int) {
        window.statusBarColor = baseConfig.statusBarColor
//        window.statusBarColor = color
        updateStatusbarContents(color)
    }

    fun setLocale(languageCode: String) {
        val locale = Locale(languageCode)
        Locale.setDefault(locale)
        val config = Configuration()
        config.setLocale(locale)
        resources.updateConfiguration(config, resources.displayMetrics)
    }

    fun updateStatusbarContents(color: Int) {
        if (color.getContrastColor() == DARK_GREY) {
            window.decorView.systemUiVisibility =
                window.decorView.systemUiVisibility.addBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
        } else {
            window.decorView.systemUiVisibility =
                window.decorView.systemUiVisibility.removeBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
        }
    }

    var resumeTheme = false
    override fun onPause() {
        super.onPause()
        resumeTheme = true
    }

    override fun onResume() {
        super.onResume()
        if (resumeTheme) {
            resumeTheme = false
            setTheme(R.style.AppTheme)
            try {
                window.statusBarColor = baseConfig.statusBarColor
            } catch (_: Exception) {
            }
        }
        window.statusBarColor = baseConfig.statusBarColor
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)

        // Set the color for the overflow and navigation icon
        val textSecondary = resolveThemeColor(android.R.attr.textColorSecondary)
        toolbar?.overflowIcon = toolbar?.overflowIcon?.apply { setTint(textSecondary) }

    }

    open fun getColoredMenuItems(): List<Int> {
        return listOf()
    }

}