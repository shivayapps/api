package messages.text.sms.common

import android.app.Activity
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Settings
import android.provider.Telephony
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import messages.text.sms.BuildConfig
import messages.text.sms.autoreply.AutoReplyActivity
import messages.text.sms.common.MysmsApplication.Companion
import messages.text.sms.common.MysmsApplication.Companion.qkApplicationContext
import messages.text.sms.feature.backup.BackupActivity
import messages.text.sms.feature.blocking.BlockingActivity
import messages.text.sms.feature.compose.ComposeActivity
import messages.text.sms.feature.conversationinfo.ConversationInfoActivity
import messages.text.sms.feature.gallery.GalleryActivity
import messages.text.sms.feature.main.ArchiveActivity
import messages.text.sms.feature.main.BlockedMessageListActivity
import messages.text.sms.feature.main.MainView
import messages.text.sms.feature.main.PermissionActivity
import messages.text.sms.feature.main.PrivateContactActivity
import messages.text.sms.feature.main.PrivateConversationsActivity
import messages.text.sms.feature.notificationprefs.NotificationPrefsActivity
import messages.text.sms.feature.scheduled.ScheduledActivity
import messages.text.sms.feature.settings.SettingsActivity
import messages.text.sms.manager.AnalyticsManager
import messages.text.sms.manager.NotificationManager
import messages.text.sms.manager.PermissionManager
import messages.text.sms.password.ChangePasswordActivity
import messages.text.sms.password.ForgetPasswordActivity
import messages.text.sms.password.HideEntranceActivity
import messages.text.sms.password.PasswordActivity
import messages.text.sms.password.PrivateSettingsActivity
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class Navigator @Inject constructor(
    private val context: Context,
    private val analyticsManager: AnalyticsManager,
    private val notificationManager: NotificationManager,
    private val permissions: PermissionManager,
) {

    private fun startActivity(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    private fun startActivityExternal(intent: Intent) {
        if (intent.resolveActivity(context.packageManager) != null) {
            startActivity(intent)
        } else {
            startActivity(Intent.createChooser(intent, null))
        }
    }


    /**
     * This won't work unless we use startActivityForResult
     */
    fun showDefaultSmsDialog(context: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(RoleManager::class.java) as RoleManager
            val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS)
            context.startActivityForResult(intent, 42389)
        } else {
            val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
            intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, context.packageName)
            context.startActivity(intent)
        }
    }

    fun showCompose(body: String? = null, images: List<Uri>? = null) {
        val intent = Intent(context, ComposeActivity::class.java)
        intent.putExtra(Intent.EXTRA_TEXT, body)

        images?.takeIf { it.isNotEmpty() }?.let {
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(images))
        }

        startActivity(intent)
    }

    public fun showPermissionScreen(permissionManager: PermissionManager, view: MainView) {
        when {
            !permissionManager.isDefaultSms() -> {
                val context = qkApplicationContext?.applicationContext
                context?.startActivity(
                    Intent(context, PermissionActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        putExtra("DefaultSms", true)
                    }
                )
                // Or you can call: view.requestDefaultSms()
            }

            !permissionManager.hasReadSms() || !permissionManager.hasContacts() -> {
                view.requestPermissions()
            }
        }
    }


    fun showComposeForSchedule(body: String? = null, images: List<Uri>? = null) {


        val intent = Intent(context, ComposeActivity::class.java)
        intent.putExtra(Intent.EXTRA_TEXT, body)
        intent.putExtra("from", "Schedule")

        images?.takeIf { it.isNotEmpty() }?.let {
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(images))
        }

        startActivity(intent)

    }

    fun showConversation(
        threadId: Long, query: String? = null,
        messageId: Long? = -1,
    ) {


        val intent = Intent(context, ComposeActivity::class.java)
            .putExtra("threadId", threadId)
            .putExtra("query", query)
            .putExtra("messageIdForScroll", messageId)
        startActivity(intent)
    }

    fun showConversationInfo(threadId: Long, isPrivate: Boolean = false) {

        val intent = Intent(context, ConversationInfoActivity::class.java)
        intent.putExtra("threadId", threadId)
        intent.putExtra("isPrivate", isPrivate)
        startActivity(intent)
    }

    fun shareMessage(details: String) {
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.setType("text/plain")
        shareIntent.putExtra(Intent.EXTRA_TEXT, details)
        startActivity(Intent.createChooser(shareIntent, "Share via"))
    }

    fun showMedia(partId: Long) {
        val intent = Intent(context, GalleryActivity::class.java)
        intent.putExtra("partId", partId)
        startActivity(intent)
    }

    fun showBackup() {
        analyticsManager.track("Viewed Backup")
        startActivity(Intent(context, BackupActivity::class.java))
    }

    fun showArchive() {
        analyticsManager.track("Viewed Archive")
        startActivity(Intent(context, ArchiveActivity::class.java))
    }


    fun showBlockedMessageListActivity() {
        analyticsManager.track("Viewed Blocked Messages")
        startActivity(Intent(context, BlockedMessageListActivity::class.java))
    }

    fun showPrivateConversation() {
        analyticsManager.track("Viewed Private Conversations")
        startActivity(Intent(context, PrivateConversationsActivity::class.java))
    }

    fun showPrivateContactActivity() {
        analyticsManager.track("Viewed Private Contact")
        startActivity(Intent(context, PrivateContactActivity::class.java))
    }

    fun showPassword() {
        analyticsManager.track("Viewed Private Conversations")
        startActivity(Intent(context, PasswordActivity::class.java))
    }

    fun showChangePassword() {
        analyticsManager.track("Viewed Private ChangePassword")
        startActivity(Intent(context, ChangePasswordActivity::class.java))
    }

    fun showForgetPassword() {
        analyticsManager.track("Viewed Private Conversations")
        startActivity(Intent(context, ForgetPasswordActivity::class.java))
    }

    fun showPrivateSettings() {
        analyticsManager.track("Viewed Private Settings")
        startActivity(Intent(context, PrivateSettingsActivity::class.java))
    }

    fun showHideEntranceActivity() {
        analyticsManager.track("Viewed Private Settings")
        startActivity(Intent(context, HideEntranceActivity::class.java))
    }

    fun showScheduled() {
        analyticsManager.track("Viewed Scheduled")
        val intent = Intent(context, ScheduledActivity::class.java)
        startActivity(intent)
    }

    fun showSettings() {
        val intent = Intent(context, SettingsActivity::class.java)
        startActivity(intent)
    }

    fun showAutoReply() {
        val intent = Intent(context, AutoReplyActivity::class.java)
        startActivity(intent)
    }

    fun showBlockedConversations() {
        val intent = Intent(context, BlockingActivity::class.java)
        startActivity(intent)
    }

    fun makePhoneCall(address: String) {
        Companion.isAdsNotShowOnResume = true
        val action = if (permissions.hasCalling()) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val intent = Intent(action, Uri.parse("tel:$address"))
        startActivityExternal(intent)
    }


    fun showRating() {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("market://details?id=messages.text.sms")
        )
            .addFlags(
                Intent.FLAG_ACTIVITY_NO_HISTORY
                        or Intent.FLAG_ACTIVITY_NEW_DOCUMENT
                        or Intent.FLAG_ACTIVITY_MULTIPLE_TASK
            )

        try {
            startActivityExternal(intent)
        } catch (e: ActivityNotFoundException) {
            val url =
                "https://play.google.com/store/apps/details?id=messages.text.sms"
            startActivityExternal(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    fun installCallControl() {
//        val url = "https://innovate.google.com/store/apps/details?id=com.flexaspect.android.everycallcontrol"
//        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
//        startActivityExternal(intent)
    }

    fun installSia() {
//        val url = "https://innovate.google.com/store/apps/details?id=org.mistergroup.shouldianswer"
//        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
//        startActivityExternal(intent)
    }

    fun showSupport() {
        Companion.isAdsNotShowOnResume = true
        val intent = Intent(Intent.ACTION_SENDTO)
        intent.data = Uri.parse("mailto:")
        intent.putExtra(Intent.EXTRA_EMAIL, arrayOf("babymariagame@gmail.com"))
        intent.putExtra(Intent.EXTRA_SUBJECT, "Message Support")
        intent.putExtra(
            Intent.EXTRA_TEXT, StringBuilder("\n\n")
                .append("\n\n--- Please write your message above this line ---\n\n")
                .append("Package: ${context.packageName}\n")
                .append("Version: ${BuildConfig.VERSION_NAME}\n")
                .append("Device: ${Build.BRAND} ${Build.MODEL}\n")
                .append("SDK: ${Build.VERSION.SDK_INT}\n")
                .toString()
        )
        startActivityExternal(intent)
    }

    fun showInvite() {
        Companion.isAdsNotShowOnResume = true
        analyticsManager.track("Clicked Invite")
        Intent(Intent.ACTION_SEND)
            .setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, "")
            .let { Intent.createChooser(it, null) }
            .let(::startActivityExternal)
    }

    fun addContact(address: String) {


        Companion.isAdsNotShowOnResume = true
        val intent = Intent(Intent.ACTION_INSERT)
            .setType(ContactsContract.Contacts.CONTENT_TYPE)
            .putExtra(ContactsContract.Intents.Insert.PHONE, address)

        startActivityExternal(intent)
    }

    fun showContact(lookupKey: String) {
        Companion.isAdsNotShowOnResume = true
        val intent = Intent(Intent.ACTION_VIEW)
            .setData(Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_LOOKUP_URI, lookupKey))

        startActivityExternal(intent)
    }

    fun viewFile(file: File) {
        Companion.isAdsNotShowOnResume = true
        val data = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.name.split(".").last())
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(data, type)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

        startActivityExternal(intent)
    }

    fun shareFile(file: File) {
        Companion.isAdsNotShowOnResume = true
        val data = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.name.split(".").last())
        val intent = Intent(Intent.ACTION_SEND)
            .setType(type)
            .putExtra(Intent.EXTRA_STREAM, data)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

        startActivityExternal(intent)
    }

    fun showNotificationSettings(threadId: Long = 0) {
        val intent = Intent(context, NotificationPrefsActivity::class.java)
        intent.putExtra("threadId", threadId)
        startActivity(intent)
    }

    fun showNotificationChannel(threadId: Long = 0) {


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (threadId != 0L) {
                notificationManager.createNotificationChannel(threadId)
            }
            MysmsApplication.isAdsNotShowOnResume = true

            val channelId = notificationManager.buildNotificationChannelId(threadId)
            val intent = Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_CHANNEL_ID, channelId)
                .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            startActivity(intent)
        }
    }


}
