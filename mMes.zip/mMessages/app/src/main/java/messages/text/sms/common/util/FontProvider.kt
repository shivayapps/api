package messages.text.sms.common.util

import android.content.Context
import android.graphics.Typeface
import android.preference.PreferenceManager
import androidx.core.content.res.ResourcesCompat
import com.f2prateek.rx.preferences2.RxSharedPreferences
import messages.text.sms.util.Preferences
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FontProvider @Inject constructor(context: Context) {

    private var lato: Typeface? = null
    private val pendingCallbacks = ArrayList<(Typeface) -> Unit>()
    lateinit var prefs: Preferences

    init {
        val shPrefs = PreferenceManager.getDefaultSharedPreferences(context)
        val rxPrefs = RxSharedPreferences.create(shPrefs)
        prefs = Preferences(context, rxPrefs, shPrefs)

//        val font=R.font.lato
        val font = prefs.selectedFont.get()

        ResourcesCompat.getFont(context, font, object : ResourcesCompat.FontCallback() {
            override fun onFontRetrievalFailed(reason: Int) {
                Timber.w("Font retrieval failed: $reason")
            }

            override fun onFontRetrieved(typeface: Typeface) {
                lato = typeface
                pendingCallbacks.forEach { lato?.run(it) }
                pendingCallbacks.clear()
            }
        }, null)
    }

    fun getLato(callback: (Typeface) -> Unit) {
        lato?.run(callback) ?: pendingCallbacks.add(callback)
    }

}