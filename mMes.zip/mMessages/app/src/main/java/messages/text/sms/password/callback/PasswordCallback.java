package messages.text.sms.password.callback;


public interface PasswordCallback {
    void onPasswordSucceeded();

    boolean onPasswordCheck(String password);

    void onPasswordCancel();
}