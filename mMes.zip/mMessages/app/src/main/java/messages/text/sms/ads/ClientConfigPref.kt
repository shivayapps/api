package messages.text.sms.ads

import android.content.Context
import androidx.core.content.edit
import messages.text.sms.util.PRIVACY_POLICY

fun Context.getSharedPrefs() = getSharedPreferences(PREFS_KEY, Context.MODE_PRIVATE)
const val PREF_ENABLE_SALES2 = "pref_enable_sales2"
const val PREF_ENABLE_SALES1 = "pref_enable_sales1"
const val PREFS_KEY = "ClientConfigPref"

class ClientConfigPref(context: Context) {
    protected val prefs = context.getSharedPrefs()

    companion object {
        fun newInstance(context: Context) = ClientConfigPref(context)
    }


    var languageAdType: String
        get() = prefs.getString("languageAdType", "large") ?: "small"
        set(languageAdType) = prefs.edit().putString("languageAdType", languageAdType).apply()

    var enableSales2: Boolean
        get() = prefs.getBoolean(PREF_ENABLE_SALES2, true)
        set(enableSales2) = prefs.edit().putBoolean(PREF_ENABLE_SALES2, enableSales2).apply()
    var enableSales1: Boolean
        get() = prefs.getBoolean(PREF_ENABLE_SALES1, true)
        set(enableSales1) = prefs.edit().putBoolean(PREF_ENABLE_SALES1, enableSales1).apply()

    var sale2Created: Int
        get() = prefs.getInt("sales2_created", 0)
        set(sale2Created) = prefs.edit().putInt("sales2_created", sale2Created).apply()

    var maxTapTime: Int
        get() = prefs.getInt("maxTapTime", 30)
        set(maxTapTime) = prefs.edit().putInt("maxTapTime", maxTapTime).apply()

    var maxTapCount: Int
        get() = prefs.getInt("maxTapCount", 3)
        set(maxTapCount) = prefs.edit().putInt("maxTapCount", maxTapCount).apply()

    var sale1Created: Int
        get() = prefs.getInt("sales1_created", 0)
        set(sale1Created) = prefs.edit().putInt("sales1_created", sale1Created).apply()


    var adsEnable: Boolean
        get() = /*!isPurchased &&*//* !BuildConfig.DEBUG &&*/ prefs.getBoolean(
            "PREF_ADS_ENABLED",
            true
        )
        set(adsEnable) = prefs.edit().putBoolean("PREF_ADS_ENABLED", adsEnable).apply()

    var isPurchased: Boolean
        get() = prefs.getBoolean("PREF_PURCHASED", false)
        set(isPurchased) = prefs.edit().putBoolean("PREF_PURCHASED", isPurchased).apply()

    var privacyPolicy: String
        get() = prefs.getString("PREF_PRIVACY_POLICY", PRIVACY_POLICY) ?: PRIVACY_POLICY
        set(privacyPolicy) = prefs.edit().putString("PREF_PRIVACY_POLICY", privacyPolicy).apply()

    var feedbackEmail: String
        get() = prefs.getString("PREF_FEEDBACK_EMAIL", "") ?: ""
        set(feedbackEmail) = prefs.edit().putString("PREF_FEEDBACK_EMAIL", feedbackEmail).apply()

    /* var adsInChat: String
         get() = prefs.getString("adsInChat", "admob") ?: "admob"
         set(adsInChat) = prefs.edit().putString("adsInChat", adsInChat).apply()*/

    var showRemainAds: Boolean
        get() = prefs.getBoolean("showRemainAds", true)
        set(value) = prefs.edit().putBoolean("showRemainAds", value).apply()



    var homeSecondAdShow: Boolean
        get() = prefs.getBoolean("home_second_ad_show", true)
        set(value) = prefs.edit().putBoolean("home_second_ad_show", value).apply()

    var defaultNewScreen: Boolean
        get() = prefs.getBoolean("default_new_screen", false)
        set(value) = prefs.edit().putBoolean("default_new_screen", value).apply()

    var otpAdEnable: Boolean
        get() = prefs.getBoolean("otp_ad_enable", true)
        set(value) = prefs.edit().putBoolean("otp_ad_enable", value).apply()

    var enableLanguageInterstitial: Boolean
        get() = prefs.getBoolean("ENABLE_LANGUAGE_INTERSTITIAL", true)
        set(value) = prefs.edit().putBoolean("ENABLE_LANGUAGE_INTERSTITIAL", value).apply()


    var languageInterstitialMessage: String
        get() = prefs.getString("LANGUAGE_INTERSTITIAL_MESSAGE", "Setting language")
            ?: "Setting language"
        set(value) = prefs.edit().putString("LANGUAGE_INTERSTITIAL_MESSAGE", value)
            .apply()

    var languageInterstitialAdId: String
        get() = prefs.getString("LANGUAGE_INTERSTITIAL_AD_ID", "") ?: ""
        set(value) = prefs.edit().putString("LANGUAGE_INTERSTITIAL_AD_ID", value)
            .apply()


    var smsDefaultNecessary: Boolean
        get() = prefs.getBoolean("sms_default_necessary", false)
        set(value) = prefs.edit { putBoolean("sms_default_necessary", value) }

    var enableBackPressInter: Boolean
        get() = prefs.getBoolean("enable_back_press_inter", true)
        set(value) = prefs.edit { putBoolean("enable_back_press_inter", value) }

    var showAppOpenAdInSplash: Boolean
        get() = prefs.getBoolean("first_time_app_open_ad", false)
        set(value) = prefs.edit { putBoolean("first_time_app_open_ad", value) }

    var showFirstTimeInterAd: Boolean
        get() = prefs.getBoolean("showFirstTimeInterAd", true)
        set(value) = prefs.edit { putBoolean("showFirstTimeInterAd", value) }

    var enableAutoStartPermission: Boolean
        get() = prefs.getBoolean("enable_auto_start_permission", true)
        set(value) = prefs.edit { putBoolean("enable_auto_start_permission", value) }

    var isBottomBarHidden: Boolean
        get() = prefs.getBoolean("isBottomBarHidden", true)
        set(value) = prefs.edit { putBoolean("isBottomBarHidden", value) }


    var AppOpenAdInSplashID: String
        get() = prefs.getString("AppOpenAdInSplashID", "") ?: ""
        set(callerCardAdType) = prefs.edit().putString("AppOpenAdInSplashID", callerCardAdType)
            .apply()

//    var termsAndConditionUrlCdo: String
//        get() = prefs.getString("termsAndConditionUrlCdo", "") ?: ""
//        set(value) = prefs.edit().putString("termsAndConditionUrlCdo", value)
//            .apply()

//    var privacyClickUrlCdo: String
//        get() = prefs.getString("privacyClickUrlCdo", "") ?: ""
//        set(value) = prefs.edit().putString("privacyClickUrlCdo", value)
//            .apply()

//    var bottom_navigation_in_cdo_screen: String
//        get() = prefs.getString("bottom_navigation_in_cdo_screen", "") ?: ""
//        set(callerCardAdType) = prefs.edit()
//            .putString("bottom_navigation_in_cdo_screen", callerCardAdType)
//            .apply()




//    var otpAdType: String
//        get() = prefs.getString("otp_ad_type", "native") ?: "native"
//        set(value) = prefs.edit().putString("otp_ad_type", value)
//            .apply()


    var reviewEmail: String
        get() = prefs.getString("PREF_reviewEmail", "") ?: ""
        set(callerCardAdType) = prefs.edit().putString("PREF_reviewEmail", callerCardAdType).apply()

    var firstTimeInterDelay: Int
        get() = prefs.getInt("first_time_inter_delay", 2000) ?: 2000
        set(value) = prefs.edit()
            .putInt("first_time_inter_delay", value).apply()

    var splashAppOpenWaitTime: Long
        get() = prefs.getLong("PREF_splashAppOpenWaitTime", 6000) ?: 6000
        set(splashAppOpenIntervalCount) = prefs.edit()
            .putLong("PREF_splashAppOpenWaitTime", splashAppOpenIntervalCount).apply()
    var currentSplashAppOpenCount: Int
        get() = prefs.getInt("PREF_currentSplashAppOpenCount", 0)
        set(splashAppOpenIntervalCount) = prefs.edit()
            .putInt("PREF_currentSplashAppOpenCount", splashAppOpenIntervalCount).apply()

    var moreApps: String
        get() = prefs.getString("PREF_moreApps", "") ?: ""
        set(moreApps) = prefs.edit().putString("PREF_moreApps", moreApps).apply()
    var appUpdate: String
        get() = prefs.getString("PREF_appUpdate", "") ?: ""
        set(moreApps) = prefs.edit().putString("PREF_appUpdate", moreApps).apply()


    var rateAppInterval: Int
        get() = prefs.getInt("PREF_rateAppInterval", 3)
        set(value) = prefs.edit().putInt("PREF_rateAppInterval", value).apply()
    var rateAppFeedbackInterval: Int
        get() = prefs.getInt("PREF_rateAppFeedbackInterval", 5)
        set(value) = prefs.edit().putInt("PREF_rateAppFeedbackInterval", value).apply()
    var rateAppIntervalCounter: Int
        get() = prefs.getInt("PREF_rateAppIntervalCounter", 0)
        set(value) = prefs.edit().putInt("PREF_rateAppIntervalCounter", value).apply()
    var isCallerCardPermissionRequired: Boolean
        get() = prefs.getBoolean("PREF_isCallerCardPermissionRequired", false)
        set(isCallerCardPermissionRequired) = prefs.edit()
            .putBoolean("PREF_isCallerCardPermissionRequired", isCallerCardPermissionRequired)
            .apply()

}