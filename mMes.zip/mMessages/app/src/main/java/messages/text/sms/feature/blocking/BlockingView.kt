package messages.text.sms.feature.blocking

import io.reactivex.Observable
import messages.text.sms.common.base.MainBaseMsgViewContract

interface BlockingView : MainBaseMsgViewContract<BlockingState> {

    //    val blockingManagerIntent: Observable<*>
    val blockedNumbersIntent: Observable<*>
    val blockedMessagesIntent: Observable<*>
    val dropClickedIntent: Observable<*>

    //    fun openBlockingManager()
    fun openBlockedNumbers()
    fun openBlockedMessages()
}
