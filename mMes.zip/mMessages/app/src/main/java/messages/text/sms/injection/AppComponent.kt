package messages.text.sms.injection

import dagger.Component
import dagger.android.support.AndroidSupportInjectionModule
import messages.text.sms.common.MysmsApplication
import messages.text.sms.common.MysmsDialog
import messages.text.sms.common.util.QkChooserTargetService
import messages.text.sms.common.widget.AvatarView
import messages.text.sms.common.widget.BabyTextView
import messages.text.sms.common.widget.MessageTextView
import messages.text.sms.common.widget.PagerTitleView
import messages.text.sms.common.widget.PreferenceView
import messages.text.sms.common.widget.QkEditText
import messages.text.sms.common.widget.QkSwitch
import messages.text.sms.common.widget.RadioPreferenceView
import messages.text.sms.common.widget.StyledTextView
import messages.text.sms.feature.backup.BackupController
import messages.text.sms.feature.blocking.BlockingController
import messages.text.sms.feature.blocking.manager.BlockingManagerController
import messages.text.sms.feature.blocking.messages.BlockedMessagesController
import messages.text.sms.feature.blocking.numbers.BlockedNumbersController
import messages.text.sms.feature.compose.editing.DetailedChipView
import messages.text.sms.feature.conversationinfo.injection.ConversationInfoComponent
import messages.text.sms.feature.settings.AdvanceSettingsController
import messages.text.sms.feature.settings.SettingsController
import messages.text.sms.feature.settings.swipe.SwipeActionsController
import messages.text.sms.feature.themepicker.injection.ThemePickerComponent
import messages.text.sms.feature.widget.WidgetAdapter
import messages.text.sms.injection.android.ActivityBuilderModule
import messages.text.sms.injection.android.BroadcastReceiverBuilderModule
import messages.text.sms.injection.android.ServiceBuilderModule
import javax.inject.Singleton

@Singleton
@Component(
    modules = [
        AndroidSupportInjectionModule::class,
        AppModule::class,
        ActivityBuilderModule::class,
        BroadcastReceiverBuilderModule::class,
        ServiceBuilderModule::class]
)
interface AppComponent {

    fun conversationInfoBuilder(): ConversationInfoComponent.Builder
    fun themePickerBuilder(): ThemePickerComponent.Builder

    fun inject(application: MysmsApplication)

    fun inject(controller: BackupController)
    fun inject(controller: BlockedMessagesController)
    fun inject(controller: BlockedNumbersController)
    fun inject(controller: BlockingController)
    fun inject(controller: BlockingManagerController)
    fun inject(controller: SettingsController)
    fun inject(controller: AdvanceSettingsController)
    fun inject(controller: SwipeActionsController)

    fun inject(dialog: MysmsDialog)

    fun inject(service: WidgetAdapter)

    /**
     * This can't use AndroidInjection, or else it will crash on pre-marshmallow devices
     */
    fun inject(service: QkChooserTargetService)

    fun inject(view: AvatarView)
    fun inject(view: DetailedChipView)
    fun inject(view: PagerTitleView)
    fun inject(view: PreferenceView)
    fun inject(view: RadioPreferenceView)
    fun inject(view: QkEditText)
    fun inject(view: QkSwitch)
    fun inject(view: BabyTextView)
    fun inject(view: StyledTextView)
    fun inject(view: MessageTextView)

}
