package  messages.text.sms.ads

import android.app.Activity
import android.content.Context
import android.os.Bundle
import androidx.annotation.Size
import androidx.multidex.BuildConfig
import com.google.firebase.analytics.FirebaseAnalytics

fun Activity.getActivityName(): String {
    return localClassName.substring(localClassName.lastIndexOf(".") + 1)
}

fun Context.getActivityName(): String {
    if (this is Activity) {
        return getActivityName()
    }
    return ""
}

class FirebaseAnalyticsHandler(val context: Context) {
    fun logMessages(
        @Size paramName: String,
        @Size actName: String,
    ) {
        if (context.isInternetConnected()) {
            try {
                val mBundle = Bundle()
                mBundle.putString(paramName, actName)
                if (BuildConfig.DEBUG) {
//                    Log.e("firebaseAnalytics", "$paramName $mBundle")
                } else {
//                    Log.e("firebaseAnalytics LIVE", "$paramName $mBundle")
                    FirebaseAnalytics.getInstance(context).logEvent(paramName, mBundle)
                }
            } catch (e: Exception) {
            }
        }
    }

    fun logMessages2(
        @Size paramMain: String,
        @Size paramName: String,
        @Size actName: String,
    ) {
        if (context.isInternetConnected()) {
            try {
                val mBundle = Bundle()
                mBundle.putString(paramName, actName)
                if (BuildConfig.DEBUG) {
//                    Log.e("firebaseAnalytics", "$paramMain  $mBundle")
                } else {
//                    Log.e("firebaseAnalytics LIVE", "$paramMain $mBundle")
//                      FirebaseAnalytics.getInstance(context).logEvent(paramMain, mBundle)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}

const val app_appopen_created = "app_appopen_created"
const val app_ad_appopen_shown = "app_ad_appopen_shown"
const val app_ad_appopen_failed = "app_ad_appopen_shown"
const val app_first_session_bev_first_tracking = "app_first_session_bev_first_tracking"
const val app_splash_first_tracking = "app_splash_first_tracking"
const val app_language_first_tracking = "app_language_first_tracking"
const val app_home_first_tracking = "app_home_first_tracking"
const val app_notification_overlay_created = "app_notification_overlay_created"
const val app_notification_overlay_details_clicked = "app_notification_overlay_details_clicked"
const val app_notification_overlay_snooze_clicked = "app_notification_overlay_snooze_clicked"
const val app_notification_overlay_gotit_clicked = "app_notification_overlay_gotit_clicked"
const val app_notification_overlay_mark_complete_clicked =
    "app_notification_overlay_mark_complete_clicked"
const val app_notification_fullscreen_details_clicked =
    "app_notification_fullscreen_details_clicked"
const val app_notification_fullscreen_snooze_clicked = "app_notification_fullscreen_snooze_clicked"
const val app_notification_fullscreen_gotit_clicked = "app_notification_fullscreen_gotit_clicked"
const val app_holiday_clicked = "app_holiday_clicked"
const val app_theme_created = "app_theme_created"
const val app_theme_clicked = "app_theme_clicked"
const val app_widget_created = "app_widget_created"
const val app_widget_clicked = "app_widget_clicked"
const val app_notification_bar_created = "app_notification_bar_created"
const val app_notification_bar_clicked = "app_notification_bar_clicked"
const val app_event_clicked = "app_event_clicked"
const val app_task_clicked = "app_task_clicked"
const val app_ai_description_clicked = "app_ai_description_clicked"

const val app_banner_created = "app_banner_created"
const val app_ad_banner_shown = "app_ad_banner_shown"
const val app_ad_banner_failed = "app_ad_banner_failed"

const val app_native_created = "app_native_created"
const val app_ad_native_shown = "app_ad_native_shown"
const val app_ad_native_failed = "app_ad_native_failed"

const val app_inter_created = "app_inter_created"
const val app_ad_inter_shown = "app_ad_inter_shown"
const val app_ad_inter_failed = "app_ad_inter_failed"

const val app_singlead_click = "app_singlead_click"

const val cad_click_setup = "cad_click_setup"
const val cad_call_allow_permission = "cad_call_allow_permission"
const val cad_call_deny_permission = "cad_call_deny_permission"
const val cad_overlay_allow_permission = "cad_overlay_allow_permission"
const val cad_overlay_deny_permission = "cad_overlay_deny_permission"
const val app_overlay_allow_permission = "app_otp_overlay_allow_permission"
const val app_overlay_deny_permission = "app_otp_overlay_deny_permission"

const val app_allow_notification_permission = "app_allow_notification_permission"
const val app_reject_notification_permission = "app_reject_notification_permission"
const val app_notification_dialog = "app_reject_notification_permission"

const val app_ad_language_native_show = "app_ad_language_native_show"
const val app_ad_language_native_failed = "app_ad_language_native_failed"
const val app_language_open = "app_language_open"
const val app_language_screen_open = "app_language_screen_open"


const val app_splash_open_ad_show = "app_splash_open_ad_show"
const val app_splash_open_ad_click = "app_splash_open_ad_click"
const val app_splash_open_ad_failed = "app_splash_open_ad_failed"


const val main_activity_created = "app_main_activity_created"
const val data_set_in_activity = "app_data_set_in_activity"
const val data_set_in_activity_200 = "app_data_set_in_activity_200"
const val app_default_sms_permissions = "app_accept_default_sms_permissions"
const val app_reject_default_sms_permissions = "app_deny_default_sms_permissions"
const val app_default_Screen_enter_from_splash = "app_default_Screen_enter_from_splash"
const val app_default_Screen_enter_for_default = "app_default_Screen_enter_for_default"

const val app_click_on_sms_menu = "app_click_on_sms_menu"
const val app_click_on_contact_menu = "app_click_on_contact_menu"
const val app_click_on_personalize_menu = "app_click_on_personalize_menu"
const val app_click_on_setting_menu = "app_click_on_setting_menu"

const val app_open_from_notification = "app_open_from_notification"
const val app_inbox_open_from_notification = "app_inbox_open_from_notification"
const val app_create_new_message_from_notification = "app_create_new_message_from_notification"
const val app_manage_apps_open_from_notification = "app_manage_apps_open_from_notification"

const val app_private_conversations_open = "app_private_conversations_open"
const val app_archive_activity_open = "app_archive_activity_open"

const val app_manage_apps_screen1_open = "app_manage_apps_screen1_open"
const val app_manage_apps_screen2_open = "app_manage_apps_screen2_open"
const val app_manage_apps_screen3_open = "app_manage_apps_screen3_open"

const val app_font_activity_open = "app_font_activity_open"
const val app_font_setting_applied = "app_font_setting_applied_successfully"

const val app_theme_activity_open = "app_theme_activity_open"

const val app_block_activity_open = "app_block_activity_open"

const val app_color_theme_preview_activity = "app_color_theme_preview_activity"
const val app_color_theme_applied_successfully = "app_color_theme_applied_successfully"

const val app_image_theme_preview_activity = "app_image_theme_preview_activity"
const val app_image_theme_applied_successfully = "app_image_theme_applied_successfully"

const val app_bubble_activity_open = "app_bubble_activity_open"
const val app_bubble_style_applied_successfully = "app_bubble_style_applied_successfully"

const val app_ringtones_list_activity_open = "app_ringtones_list_activity_open"
const val app_ringtone_applied_successfully = "app_ringtone_applied_successfully"


const val app_splash_created = "app_splash_created"
const val app_language_created = "app_language_created"
const val app_permission_created = "app_permission_created"
const val app_home_created = "app_home_created"
const val app_change_language_created = "app_language_created"