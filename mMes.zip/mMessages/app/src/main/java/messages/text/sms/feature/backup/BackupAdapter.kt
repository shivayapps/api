package messages.text.sms.feature.backup

import android.content.Context
import android.text.format.Formatter
import android.view.ViewGroup
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.common.base.FlowableAdapter
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.databinding.BackupListItemBinding
import messages.text.sms.model.BackupFile
import javax.inject.Inject

class BackupAdapter @Inject constructor(
    private val context: Context,
    private val dateFormatter: DateFormatter,
) : FlowableAdapter<BackupFile, BackupListItemBinding>() {

    val backupSelected: Subject<BackupFile> = PublishSubject.create()
    val deleteSelected: Subject<BackupFile> = PublishSubject.create()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<BackupListItemBinding> {
        return MainBaseMsgViewHolder(parent, BackupListItemBinding::inflate).apply {
            binding.root.setOnClickListener { backupSelected.onNext(getItem(adapterPosition)) }
            binding.delete.setOnClickListener {
                deleteSelected.onNext(getItem(adapterPosition))
            }
        }
    }

    override fun onBindViewHolder(
        holder: MainBaseMsgViewHolder<BackupListItemBinding>,
        position: Int,
    ) {
        val backup = getItem(position)
        val count = backup.messages

        holder.binding.title.text = dateFormatter.getDetailedTimestamp(backup.date)
//        holder.binding.messages.text = context.resources.getQuantityString(R.plurals.backup_message_count, count, count)
        holder.binding.size.text = Formatter.formatFileSize(
            context,
            backup.size
        ) + " " + context.resources.getQuantityString(R.plurals.backup_message_count, count, count)
    }

}