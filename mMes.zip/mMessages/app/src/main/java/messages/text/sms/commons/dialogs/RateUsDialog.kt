package messages.text.sms.commons.dialogs


import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import messages.text.sms.R
import messages.text.sms.databinding.DialogRateUsBinding
import java.lang.ref.WeakReference

/*
class RateUsDialog(var activity: Activity) : Dialog(activity, R.style.AppBottomSheetDialogTheme) {

    var btnClickListener: ((Int) -> Unit?)? = null
    lateinit var binding: DialogRateUsBinding
    private var rate: Float = 0f
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setWindowAnimations(R.style.AppThemeSlide)
        binding = DialogRateUsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        //    binding.btnOk.background.applyColorFilter(activity.getProperPrimaryColor())
        //     binding.llMain.background.applyColorFilter(activity.getBackgroundColor())
        //     activity.updateOnlyTextColors(binding.llMain)
        intView()
    }


    private fun intView() {
        binding.txtTitle.text = activity.getString(R.string.rate_title_good)
        //   binding.ivTop.setImageResource(R.drawable.rate_four)
        binding.btnOk.isEnabled = false
        binding.btnOk.alpha = 0.5f


        binding.ivTop.setImageResource(R.drawable.rate_four)
        binding.btRatingBar.setOnRatingChangeListener { _, rating, _ ->
            rate = rating
            binding.btnOk.isEnabled = true
            binding.btnOk.alpha = 1f

            when (rating) {
                0f -> {
                    binding.txtTitle.text = activity.getString(R.string.rate_title_good)
//                    binding.ivTop.setImageResource(R.drawable.rate_four)
                    binding.btnOk.isEnabled = false
                    binding.btnOk.alpha = 0.5f
                }

                1f -> {
                    binding.txtTitle.text = activity.getString(R.string.rate_title_fair)
                    binding.ivTop.setImageResource(R.drawable.rate_one)
                }

                2f -> {
                    binding.txtTitle.text = activity.getString(R.string.rate_title_fair)
                    binding.ivTop.setImageResource(R.drawable.rate_two)
                }

                3f -> {
                    binding.txtTitle.text = activity.getString(R.string.rate_title_good)
                    binding.ivTop.setImageResource(R.drawable.rate_three)
                }

                4f -> {
                    binding.txtTitle.text = activity.getString(R.string.rate_title_good)
                    binding.ivTop.setImageResource(R.drawable.rate_five)
                }

                5f -> {
                    binding.txtTitle.text = activity.getString(R.string.rate_title_good)
                    binding.ivTop.setImageResource(R.drawable.rate_four)
                }
            }
        }
        intListener()
//        PrefUtils.storeBoolean(activity, Const.RATE_US_DIALOG, true)
    }


    private fun showInAppRateDialogInternal(
        reviewManager: ReviewManager,
        activity: Activity,
        reviewInfo: ReviewInfo,
    ) {
        val reviewFlow = reviewManager.launchReviewFlow(activity, reviewInfo)
        val activityRef = WeakReference(activity)
        reviewFlow.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    lauchAppStore(activity)
//                    storeRateResult(fragmentActivity, RateUsState.IGNORED)
                }
            } else {
//                log.error(task.exception)
            }
        }
    }


    private fun showInAppRateDialog(activity: Activity) {

        val reviewManager = ReviewManagerFactory.create(activity)
        val activityRef = WeakReference(activity)
        val requestReview = reviewManager.requestReviewFlow()
        requestReview.addOnCompleteListener { task ->

            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    showInAppRateDialogInternal(
                        reviewManager,
                        fragmentActivity,
                        task.result
                    )
                }
            } else {
//                log.error(task.exception)
            }
        }
    }

    private fun intListener() {
        binding.btnOk.setOnClickListener {
            if (rate >= 4) {
                // activity.baseConfig.storeBoolean(activity, "RATE_US_DIALOG", true)

                showInAppRateDialog(activity)
                btnClickListener?.invoke(0)
                dismiss()
            } else if (rate <= 3 && rate.toInt() != 0) {
                val intent = Intent(activity, FeedBackActivity::class.java)
                activity.startActivity(intent)
                btnClickListener?.invoke(1)
                dismiss()
            }
//            PrefUtils.storeBoolean(activity, Const.RATE_US_DIALOG, true)
        }


    }

    private fun lauchAppStore(activity: Activity) {
        activity.startActivity(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse("http://play.google.com/store/apps/details?id=${activity.packageName}")
            )
        )
    }


}*/

class RateUsDialog(private val activity: Activity) :
    BottomSheetDialog(activity, R.style.AppBottomSheetDialogTheme) {

    var btnClickListener: ((Int) -> Unit?)? = null
    private lateinit var binding: DialogRateUsBinding
    private var rate: Float = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DialogRateUsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.navigationBarColor = ContextCompat.getColor(context, R.color.white)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        initView()
    }

    private fun initView() {
        binding.txtTitle.text = activity.getString(R.string.rate_title_good)
        binding.ivTop.setImageResource(R.drawable.rate_four)

        binding.btnOk.isEnabled = false
        binding.btnOk.alpha = 0.5f

        binding.btRatingBar.setOnRatingChangeListener { _, rating, _ ->
            rate = rating
            binding.btnOk.isEnabled = rating > 0
            binding.btnOk.alpha = if (rating > 0) 1f else 0.5f

            when (rating.toInt()) {
                1 -> {
                    binding.txtTitle.text = activity.getString(R.string.rate_title_fair)
                    binding.ivTop.setImageResource(R.drawable.rate_one)
                }

                2 -> {
                    binding.txtTitle.text = activity.getString(R.string.rate_title_fair)
                    binding.ivTop.setImageResource(R.drawable.rate_two)
                }

                3 -> {
                    binding.txtTitle.text = activity.getString(R.string.rate_title_good)
                    binding.ivTop.setImageResource(R.drawable.rate_three)
                }

                4 -> {
                    binding.txtTitle.text = activity.getString(R.string.rate_title_good)
                    binding.ivTop.setImageResource(R.drawable.rate_five)
                }

                5 -> {
                    binding.txtTitle.text = activity.getString(R.string.rate_title_good)
                    binding.ivTop.setImageResource(R.drawable.rate_four)
                }

                else -> {
                    binding.txtTitle.text = activity.getString(R.string.rate_title_good)
                    binding.btnOk.isEnabled = false
                    binding.btnOk.alpha = 0.5f
                }
            }
        }

        binding.btnOk.setOnClickListener {
            if (rate >= 4) {
                showInAppRateDialog(activity)
                btnClickListener?.invoke(0)
            } else if (rate > 0) {
//                activity.startActivity(Intent(activity, FeedBackActivity::class.java))
                btnClickListener?.invoke(1)
            }
            dismiss()
        }
    }

    private fun showInAppRateDialog(activity: Activity) {
        val reviewManager = ReviewManagerFactory.create(activity)
        val activityRef = WeakReference(activity)
        val requestReview = reviewManager.requestReviewFlow()
        requestReview.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    showInAppRateDialogInternal(
                        reviewManager,
                        fragmentActivity,
                        task.result
                    )
                }
            }
        }
    }

    private fun showInAppRateDialogInternal(
        reviewManager: ReviewManager,
        activity: Activity,
        reviewInfo: ReviewInfo,
    ) {
        val activityRef = WeakReference(activity)
        val reviewFlow = reviewManager.launchReviewFlow(activity, reviewInfo)
        reviewFlow.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                activityRef.get()?.let {
                    launchAppStore(it)
                }
            }
        }
    }

    private fun launchAppStore(activity: Activity) {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${activity.packageName}")
        )
        activity.startActivity(intent)
    }
}