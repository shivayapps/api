package messages.text.sms.feature.settings

import io.reactivex.Observable
import messages.text.sms.common.base.MainBaseMsgViewContract
import messages.text.sms.common.widget.PreferenceView

interface SettingsView : MainBaseMsgViewContract<SettingsState> {
    fun preferenceClicks(): Observable<PreferenceView>
    fun nightModeSelected(): Observable<Int>
    fun nightStartSelected(): Observable<Pair<Int, Int>>
    fun nightEndSelected(): Observable<Pair<Int, Int>>
    fun textSizeSelected(): Observable<Int>
    fun sendDelaySelected(): Observable<Int>
    fun signatureSet(): Observable<String>
    fun mmsSizeSelected(): Observable<Int>

    fun showNightModeDialog()
    fun showStartTimePicker(hour: Int, minute: Int)
    fun showEndTimePicker(hour: Int, minute: Int)
    fun showTextSizePicker()
    fun showDelayDurationDialog()
    fun showSignatureDialog(signature: String)
    fun showMmsSizePicker()
    fun showSwipeActions()
    fun showThemePicker()
}
