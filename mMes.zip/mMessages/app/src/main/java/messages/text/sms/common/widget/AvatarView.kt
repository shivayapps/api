package messages.text.sms.common.widget

import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.core.text.isDigitsOnly
import androidx.core.view.setPadding
import com.bumptech.glide.Glide
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.extensions.setBackgroundTint
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.helpers.BaseConfig
import messages.text.sms.databinding.AvatarViewBinding
import messages.text.sms.feature.contacts.ContactsActivity
import messages.text.sms.injection.appComponent
import messages.text.sms.model.Recipient
import messages.text.sms.model.RecipientData

import messages.text.sms.util.Preferences
import javax.inject.Inject

class AvatarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null,
) : FrameLayout(context, attrs) {

    @Inject
    lateinit var colors: Colors

    @Inject
    lateinit var navigator: Navigator

    @Inject
    lateinit var prefs: Preferences

    private var lookupKey: String? = null
    private var fullName: String? = null
    private var photoUri: String? = null
    private var lastUpdated: Long? = null
    private var baseConfig: BaseConfig? = null
    private var color: Int = -1
    private var textColor: Int = -1

    //    private var theme: Colors.Theme
    private val binding = viewBinding(AvatarViewBinding::inflate)

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
        }

//        theme = colors.theme()
        baseConfig = BaseConfig.newInstance(context)

        setBackgroundResource(R.drawable.circle)
        clipToOutline = true
    }

    fun setRecipient(recipient: Recipient?) {
        lookupKey = recipient?.contact?.lookupKey
        fullName = recipient?.contact?.name
        photoUri = recipient?.contact?.photoUri
        lastUpdated = recipient?.contact?.lastUpdate
//        theme = colors.theme(recipient)
        try {
            if (prefs.autoColor.get()) {
                color = colors.generateColor(recipient!!)
                textColor = Color.WHITE
            } else {
                color = baseConfig?.primaryColor!!
                textColor = Color.WHITE
                //            textColor = baseConfig?.customTextColor!!
            }
        } catch (_: Exception) {

        }
        updateView()
    }

    fun setRecipient(recipient: RecipientData?) {
        lookupKey = recipient?.contact?.lookupKey
        fullName = recipient?.contact?.name
        photoUri = recipient?.contact?.photoUri
        lastUpdated = recipient?.contact?.lastUpdate
//        theme = colors.themeData(recipient)
        if (prefs.autoColor.get()) {
            color = colors.generateColor(recipient!!)
            textColor = Color.WHITE
        } else {
            color = baseConfig?.primaryColor!!
            textColor = Color.WHITE
//            textColor = baseConfig?.customTextColor!!
        }
        updateView()
    }

    fun setRecipient(recipient: Recipient?, title: String) {
        lookupKey = recipient?.contact?.lookupKey
        fullName = if (title.isNotEmpty()) title else recipient?.contact?.name
        photoUri = recipient?.contact?.photoUri
        lastUpdated = recipient?.contact?.lastUpdate
//        theme = colors.theme(recipient)
        if (prefs.autoColor.get()) {
            color = colors.generateColor(recipient!!)
            textColor = Color.WHITE
        } else {
            color = baseConfig?.primaryColor!!
            textColor = Color.WHITE
//            textColor = baseConfig?.customTextColor!!
        }
        updateView()
    }

    override fun onFinishInflate() {
        super.onFinishInflate()

        if (!isInEditMode) {
            updateView()
        }
    }

    fun updateIconPadding(padding: Int) {
        binding.icon.setPadding(padding)
    }

    private fun updateView() {
        // Apply theme
//        setBackgroundTint(theme.theme)
//        binding.initial.setTextColor(theme.textPrimary)
//        binding.icon.setTint(theme.textPrimary)
        setBackgroundTint(color)
        binding.initial.setTextColor(textColor)
        binding.icon.setTint(textColor)

        val initials = fullName
            ?.substringBefore(',')
            ?.split(" ").orEmpty()
            .filter { name -> name.isNotEmpty() }
            .map { name -> name[0] }
            .filter { initial -> initial.isLetterOrDigit() }
            .map { initial -> initial.toString() }

        if (initials.isNotEmpty() && context !is ContactsActivity) {
            if (initials.first().isDigitsOnly()) {
                binding.initial.text = null
                binding.icon.visibility = VISIBLE
            } else {
                binding.initial.text = if (initials.size > 1) initials.first() else initials.first()
                binding.icon.visibility = GONE
            }

        } else {
            binding.initial.text = null
            binding.icon.visibility = VISIBLE
        }

        binding.photo.setImageDrawable(null)
        photoUri?.let { photoUri ->
            Glide.with(binding.photo)
                .load(photoUri)
                .into(binding.photo)
        }
    }
}
