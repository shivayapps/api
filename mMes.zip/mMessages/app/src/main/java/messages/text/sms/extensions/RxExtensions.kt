package messages.text.sms.extensions

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.animation.doOnEnd
import io.reactivex.Flowable
import io.reactivex.Observable

data class Optional<out T>(val value: T?) {
    fun notNull() = value != null
}

fun <T, R> Flowable<T>.mapNotNull(mapper: (T) -> R?): Flowable<R> =
    map { input -> Optional(mapper(input)) }
        .filter { optional -> optional.notNull() }
        .map { optional -> optional.value }

fun <T, R> Observable<T>.mapNotNull(mapper: (T) -> R?): Observable<R> =
    map { input -> Optional(mapper(input)) }
        .filter { optional -> optional.notNull() }
        .map { optional -> optional.value }

fun <T> Observable<T>.toFlowable(): Flowable<T> =
    this.toFlowable(io.reactivex.BackpressureStrategy.BUFFER)

fun startZoomAnimation(view: View) {
    val scaleUpX = ObjectAnimator.ofFloat(view, "scaleX", 1f, 0.9f)
    val scaleUpY = ObjectAnimator.ofFloat(view, "scaleY", 1f, 0.9f)
    val scaleDownX = ObjectAnimator.ofFloat(view, "scaleX", 0.9f, 1f)
    val scaleDownY = ObjectAnimator.ofFloat(view, "scaleY", 0.9f, 1f)

    val scaleUpSet = AnimatorSet().apply {
        playTogether(scaleUpX, scaleUpY)
        duration = 700
        interpolator = LinearInterpolator()
    }

    val scaleDownSet = AnimatorSet().apply {
        playTogether(scaleDownX, scaleDownY)
        duration = 700
        interpolator = LinearInterpolator()
    }

    val animatorSet = AnimatorSet()
    animatorSet.playSequentially(scaleUpSet, scaleDownSet)

    animatorSet.doOnEnd { animatorSet.start() } // Loop the animation
    animatorSet.start()
}