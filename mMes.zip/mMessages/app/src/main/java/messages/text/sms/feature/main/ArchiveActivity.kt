package messages.text.sms.feature.main

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import androidx.appcompat.view.ContextThemeWrapper
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders

import com.jakewharton.rxbinding2.view.clicks
import com.jakewharton.rxbinding2.widget.textChanges
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import io.realm.Realm
import io.realm.RealmResults
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import messages.text.sms.R
import messages.text.sms.ads.GoogleSmallNativeAdManagerArchive
import messages.text.sms.ads.GoogleSmallNativeAdManagerArchive.loadSmallNative4Archived
import messages.text.sms.ads.GoogleSmallNativeAdManagerArchive.loadSmallNative8Archived
import messages.text.sms.ads.GoogleSmallNativeAdManagerArchive.loadSmallNativeArchived
import messages.text.sms.ads.app_archive_activity_open
import messages.text.sms.ads.delayExecution
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.ads.getAppArchivedNative1
import messages.text.sms.ads.getAppArchivedNative3
import messages.text.sms.ads.getAppListNative2
import messages.text.sms.ads.isInternetConnected
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.autoScrollToStart
import messages.text.sms.common.util.extensions.dismissKeyboard
import messages.text.sms.common.util.extensions.resolveThemeColor
import messages.text.sms.common.util.extensions.scrapViews
import messages.text.sms.common.util.extensions.setBackgroundTint
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.common.widget.QkDialog
import messages.text.sms.commons.extensions.addAlpha
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.commons.extensions.config
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.ArchiveActivityBinding
import messages.text.sms.extensions.Optional
import messages.text.sms.feature.blocking.BlockingDialog
import messages.text.sms.feature.compose.ComposeActivity
import messages.text.sms.feature.compose.editing.PhoneNumberAction
import messages.text.sms.feature.compose.editing.PhoneNumberPickerAdapter
import messages.text.sms.feature.contacts.ContactsActivity.Companion.ChipsKey
import messages.text.sms.feature.conversations.ArchiveConversationsAdapter
import messages.text.sms.model.ContactData
import messages.text.sms.model.Conversation
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.REFRESH_ARCHIVE
import messages.text.sms.model.REFRESH_CONTACT_GROUP
import messages.text.sms.model.REFRESH_MESSAGE
import messages.text.sms.model.SELECTED_CHANGES
import messages.text.sms.model.SYNC_MESSAGE
import messages.text.sms.model.THEME_CHANGED
import messages.text.sms.util.appPreference
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.util.Arrays
import javax.inject.Inject

class ArchiveActivity : MainBaseThemedActivity(), MainView {
    private val binding by viewBinding(ArchiveActivityBinding::inflate)

    @Inject
    lateinit var blockingDialog: BlockingDialog

    @Inject
    lateinit var disposables: CompositeDisposable


    @Inject
    lateinit var conversationsAdapter: ArchiveConversationsAdapter


    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory
    override val navigationIntent: Observable<NavItem> = PublishSubject.create()
    override val swipeConversationIntent: Observable<Pair<Long, Int>> = PublishSubject.create()
    override val onNewIntentIntent: Subject<Intent> = PublishSubject.create()
    override val activityResumedIntent: Subject<Boolean> = PublishSubject.create()
    override val queryConversationChangedIntent by lazy { binding.messageTab.toolbarSearch.textChanges() }
    override val composeIntent by lazy { binding.messageTab.compose.clicks() }
    override val homeIntent: Subject<Unit> = PublishSubject.create()
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()
    override val conversationsSelectedIntent by lazy { conversationsAdapter.selectionChanges }
    override val confirmDeleteIntent: Subject<List<Long>> = PublishSubject.create()
    override val undoArchiveIntent: Subject<Unit> = PublishSubject.create()
    override val refreshArchive: Subject<Unit> = PublishSubject.create()
    override val refreshBlocked: Subject<Unit> = PublishSubject.create()
    override val refreshMessages: Subject<Unit> = PublishSubject.create()
    override val queryChangedIntent: Observable<CharSequence> get() = PublishSubject.create<CharSequence>()
    override val queryClearedIntent: Observable<*> get() = PublishSubject.create<Unit>()
    override val queryEditorActionIntent: Observable<Int> get() = PublishSubject.create<Int>()

    override val phoneNumberSelectedIntent: Subject<Optional<Long>> by lazy { phoneNumberAdapter.selectedItemChanges }
    override val phoneNumberActionIntent: Subject<PhoneNumberAction> = PublishSubject.create()
    override val composeItemPressedIntent: Subject<ContactData> = PublishSubject.create()
    override val composeItemLongPressedIntent: Subject<ContactData> = PublishSubject.create()

    override val setAsDefaultClick by lazy { binding.messageTab.snackbar.btnSetDefault.clicks() }

    private val viewModel by lazy {
        ViewModelProviders.of(
            this,
            viewModelFactory
        )[ArchiveViewModel::class.java]
    }

    @Inject
    lateinit var phoneNumberAdapter: PhoneNumberPickerAdapter
    private val phoneNumberDialog by lazy {
        QkDialog(this).apply {
            titleRes = R.string.compose_number_picker_title
            adapter = phoneNumberAdapter
            positiveButton = R.string.compose_number_picker_always
            positiveButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.ALWAYS) }
            negativeButton = R.string.compose_number_picker_once
            negativeButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.JUST_ONCE) }
            cancelListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.CANCEL) }

        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        viewModel.bindView(this)
        appPreference.isRefreshArchiveMessages = false
        binding.messageTab.llArchive.beGone()
        binding.messageTab.compose.beGone()
        binding.messageTab.empty.visibility = View.GONE
        fetchMessages()
        if (!isInternetConnected()) {
            conversationsAdapter.isLoadingAd = false
        }
        onNewIntentIntent.onNext(intent)
        setSupportActionBar(binding.toolbar)


        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)


        setTitle(getString(R.string.title_archived))
        showBackButton(true)
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this)
        config.saveData("checkfirst", true)

        conversationsAdapter.autoScrollToStart(binding.messageTab.recyclerView)
        binding.messageTab.snackbar.llDefault.background = backgroundchange()
        binding.messageTab.snackbar.root.beGone()
        binding.messageTab.syncing.root.beGone()
        theme
            .autoDisposable(scope())
            .subscribe { theme ->
                // Set the color for the drawer icons
                val states = arrayOf(
                    intArrayOf(android.R.attr.state_activated),
                    intArrayOf(-android.R.attr.state_activated)
                )

                resolveThemeColor(android.R.attr.textColorSecondary)
                    .let { textSecondary ->
                        ColorStateList(
                            states,
                            intArrayOf(theme.theme, textSecondary)
                        )
                    }
                    .let { tintList ->
//                        binding.drawer.inboxIcon.imageTintList = tintList
                        binding.messageTab.archivedIcon.imageTintList = tintList
                    }
                binding.messageTab.syncing.syncingProgress?.progressTintList =
                    ColorStateList.valueOf(theme.theme)
                binding.messageTab.syncing.syncingProgress?.indeterminateTintList =
                    ColorStateList.valueOf(theme.theme)
                binding.messageTab.compose.setBackgroundTint(theme.theme)
                //  binding.messageTab.compose.setTint(theme.textPrimary)
                binding.messageTab.compose.imageTintList = ColorStateList.valueOf(theme.textPrimary)

            }
        initListener()
        setUpTheme()
        binding.messageTab.rlToolbar.visibility = View.GONE
        if (isInternetConnected()) {
            requestAd()
        }

        firebaseAnalyticsHandler.logMessages(
            app_archive_activity_open, getActivityName()
        )
    }

    private fun fetchMessages() {
        CoroutineScope(Dispatchers.Main).launch {
            val result = conversationRepo.getConversations(true, false)
            runOnUiThread {
                val arrayListOfUnmanagedObjects: List<Conversation> =
                    Realm.getDefaultInstance().copyFromRealm(result)

                if (arrayListOfUnmanagedObjects.isNotEmpty()) {
                    setConversationAdapter(result, true, R.string.archived_empty_text, false)
//                    setConversationAdapter(result, true, R.string.archived_empty_text, false)
                    binding.messageTab.empty.visibility = View.GONE
                } else {
                    binding.messageTab.recyclerView.visibility = View.GONE
                    binding.messageTab.dragHandle.visibility = View.GONE
                    //    binding.messageTab.bubbleText.visibility = View.GONE
                    binding.messageTab.empty.visibility = View.VISIBLE

//                    finish()
                }

            }
        }
    }

    private fun requestAd() {

        delayExecution(300) {
            conversationsAdapter.isLoadingAd = true
            loadSmallNativeArchived(this, getAppArchivedNative1()) {
                var isFirstNativeLoaded = false
                if (it != null) {
                    isFirstNativeLoaded = true
                    notifyItem(0)
                    //conversationsAdapter.notifyItemChanged(0, "refresh_ad")
                }

                if (conversationsAdapter.itemCount > 4) {

                    loadSmallNative4Archived(this, getAppListNative2()) { secondNative ->
                        var isSecondNativeLoaded = false
                        if (secondNative != null) {
                            isSecondNativeLoaded = true
                            notifyItem(4)
                            if (!isFirstNativeLoaded) {
                                isFirstNativeLoaded = true
                                conversationsAdapter.notifyItemChanged(0)
                                notifyItem(0)
                            }
                        }
                        if (conversationsAdapter.itemCount > 8) {
                            loadSmallNative8Archived(this, getAppArchivedNative3()) { thirdNative ->
                                conversationsAdapter.isLoadingAd = false
                                if (!isFirstNativeLoaded) {
                                    notifyItem(0)
                                }
                                if (!isSecondNativeLoaded) {
                                    notifyItem(4)
                                }
                                notifyItem(8)
                            }
                        } else {
                            if (!isSecondNativeLoaded) {
                                conversationsAdapter.isLoadingAd = false
                                //  notifyItem(0)
                                notifyItem(4)
                            }
                        }
                    }
                } else {
                    if (!isFirstNativeLoaded) {
                        conversationsAdapter.isLoadingAd = false
                        notifyItem(0)
                    }
                }

            }
        }
    }

    private fun notifyItem(position: Int) {
        binding.messageTab.recyclerView.post {
            conversationsAdapter.notifyItemChanged(position)
        }
    }

    private fun setUpTheme() {


        val primaryColorWithAlpha =
            ColorUtils.setAlphaComponent(baseConfig.primaryColor, (255 * 0.1).toInt())
        val textColorPrimaryss = baseConfig.textColor
        val colorWithAlpha = textColorPrimaryss.addAlpha(0.6F)

        binding.messageTab.toolbarSearch.setBackgroundTint(primaryColorWithAlpha)
        binding.messageTab.toolbarSearch.setHintTextColor(colorWithAlpha)


        updateTextColors(binding.contentView)
        //  binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
            binding.llBottomAction.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
            arrayListOf(
                binding.ivDelete,
                binding.ivMore,
                binding.ivArchive,
                binding.ivRead,
                binding.ivBlock
            ).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.white)
                val colorStateList = ColorStateList.valueOf(Color.WHITE)
                it.imageTintList = colorStateList
            }
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
            binding.llBottomAction.background = ColorDrawable(baseConfig.statusBarColor)
            arrayListOf(
                binding.ivDelete,
                binding.ivMore,
                binding.ivArchive,
                binding.ivRead,
                binding.ivBlock
            ).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.black)
                val colorStateList = ColorStateList.valueOf(Color.BLACK)
                it.imageTintList = colorStateList
            }
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }

    private fun initListener() {

        binding.llDelete.setOnClickListener {
            optionsItemIntent.onNext(R.id.delete)
        }
        binding.llUnArchiveTab.setOnClickListener {
            optionsItemIntent.onNext(R.id.unarchive)
        }
        binding.llMarkRead.setOnClickListener {
            optionsItemIntent.onNext(R.id.read)
        }
        binding.llBlock.setOnClickListener {
            optionsItemIntent.onNext(R.id.block)
        }


        binding.llMore.setOnClickListener {
            Log.e("initListener", "rlMore.click")
            val wrapper = if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
                ContextThemeWrapper(this@ArchiveActivity, R.style.CustomPopUpStyleBlack)
            } else {
                ContextThemeWrapper(this@ArchiveActivity, R.style.CustomPopUpStyle)
            }

            val popupMenu = PopupMenu(wrapper, binding.llMore)
            // Inflating popup menu from popup_menu.xml file
            popupMenu.menuInflater.inflate(R.menu.desktop_menu, popupMenu.menu)
            val menu = popupMenu.menu

//                menu.findItem(R.id.archive)?.isVisible = currentPage is Inbox && selectedConversations != 0
//                menu.findItem(R.id.read)?.isVisible = markRead && selectedConversations != 0
//                menu.findItem(R.id.block)?.isVisible = selectedConversations != 0
//                menu.findItem(R.id.delete)?.isVisible = selectedConversations != 0
//            menu.findItem(R.id.unarchive)?.isVisible = currentPage is Archived && selectedConversations != 0
            menu.findItem(R.id.unarchive)?.isVisible = false
            menu.findItem(R.id.add)?.isVisible = addContact && selectedConversations != 0
            menu.findItem(R.id.pin)?.isVisible = markPinned && selectedConversations != 0
            menu.findItem(R.id.unpin)?.isVisible = !markPinned && selectedConversations != 0
//            menu.findItem(R.id.unread)?.isVisible = !markRead && selectedConversations != 0
            menu.findItem(R.id.unread)?.isVisible = selectedConversations != 0
            menu.findItem(R.id.privatebox)?.isVisible = false


            popupMenu.setOnMenuItemClickListener { menuItem ->

                when (menuItem.itemId) {
                    R.id.unarchive -> {
                        optionsItemIntent.onNext(R.id.unarchive)
                    }

                    R.id.add -> {
                        optionsItemIntent.onNext(R.id.add)
                    }

                    R.id.pin -> {
                        optionsItemIntent.onNext(R.id.pin)
                    }

                    R.id.unpin -> {
                        optionsItemIntent.onNext(R.id.unpin)
                    }

                    R.id.unread -> {
                        optionsItemIntent.onNext(R.id.unread)
                    }
                }
                true
            }

            // Showing the popup menu
            Log.e("initListener", "popupMenu.show")
            popupMenu.show()
        }
    }

    fun backgroundchange(): GradientDrawable {
        val drawable = GradientDrawable()
        drawable.shape = GradientDrawable.RECTANGLE
        val colorWithOpacity = baseConfig?.primaryColor

        val colorWith20Opacity =
            colorWithOpacity?.let { ColorUtils.setAlphaComponent(it, 20) } // 51 is 20% of 255

//                val colorWith20Opacity = Color.argb(51, Color.red(colorWithOpacity), Color.green(colorWithOpacity), Color.blue(colorWithOpacity))
        if (colorWith20Opacity != null) {
            drawable.setColor(colorWith20Opacity)
        }
        val strokeWidthInDp = 1.0f
        val strokeWidthInPixels =
            (strokeWidthInDp * resources?.displayMetrics!!.density + 0.5f).toInt()
        baseConfig?.let { drawable.setStroke(strokeWidthInPixels, it.primaryColor) }
        val cornerRadius = resources?.getDimension(R.dimen.normal_text_size)
        if (cornerRadius != null) {
            drawable.cornerRadius = cornerRadius
        }
        return drawable
    }


    var addContact = false
    var markPinned = false
    var markRead = false
    var selectedConversations = 0
    var currentPage: MainPage = Inbox()
    override fun render(state: MainState) {
        if (state.hasError) {
            Log.e("render", "MainActivity:render.hasError:${state.hasError}")
            finish()
            return
        }
        if (state.selectedContact != null && !phoneNumberDialog.isShowing) {
            phoneNumberAdapter.data = state.selectedContact.numbers
            phoneNumberDialog.subtitle = state.selectedContact.name

            phoneNumberDialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
            phoneNumberDialog.show()
        } else if (state.selectedContact == null && phoneNumberDialog.isShowing) {
            phoneNumberDialog.dismiss()
        }
        currentPage = state.page
        addContact = when (state.page) {
            is Inbox -> state.page.addContact
            is Archived -> state.page.addContact
            else -> false
        }

        markPinned = when (state.page) {
            is Inbox -> state.page.markPinned
            is Archived -> state.page.markPinned
            else -> false
        }

        markRead = when (state.page) {
            is Inbox -> state.page.markRead
            is Archived -> state.page.markRead
            else -> true
        }

        selectedConversations = when (state.page) {
            is Inbox -> state.page.selected
            is Archived -> state.page.selected
            else -> 0
        }

        binding.toolbar.menu.findItem(R.id.selectAll)?.isVisible = selectedConversations != 0

        when (state.page) {
            is Archived -> {
                binding.messageTab.llArchive.beGone()
                binding.messageTab.compose.beGone()
                when (state.page.selected != 0) {
                    true -> {
                        setCommonData(
                            showBottomAction = true
                        )
                        binding.actionbarTitle.text = String.format(getString(R.string.main_title_selected), state.page.selected)
                    }

                    false -> {
                        setCommonData(
                            showBottomAction = false
                        )
                        binding.actionbarTitle.text = getString(R.string.title_archived)
                    }
                }
            }

            else -> {

            }
        }
    }


    private fun setCommonData(
        showBottomAction: Boolean,
    ) {

        if (showBottomAction) {
            binding.mainToolbar.beGone()
            binding.actionToolbar.beVisible()
            binding.llBottomAction.beVisible()
        } else {
            binding.mainToolbar.beVisible()
            binding.actionToolbar.beGone()
            binding.llBottomAction.beGone()
        }
    }


    private fun setConversationAdapter(
        data: RealmResults<Conversation>?,
        backVisible: Boolean,
        inboxEmptyText: Int,
        isTouchHelper: Boolean,
    ) {
//        if(data?.size==0) {
//            onBackPressed()
//            return
//        }
        if (binding.messageTab.recyclerView.adapter !== conversationsAdapter) {
            binding.messageTab.recyclerView.apply {
                adapter = conversationsAdapter
            }
        }

        binding.messageTab.recyclerView.itemAnimator = null
        conversationsAdapter.updateData(data)

        binding.messageTab.emptyText.text = resources.getString(inboxEmptyText)
        //   binding.messageTab.recyclerView.post {
        if (conversationsAdapter.asyncListDiffer.currentList.isNotEmpty() ?: false) {
            binding.messageTab.empty.visibility = View.GONE
        } else {
            binding.messageTab.empty.visibility = View.VISIBLE
        }
        ///     }
//        showBackButton(backVisible)
    }

    override fun onResume() {
        super.onResume()
        conversationsAdapter.activity = this
        conversationsAdapter.currentActivity = javaClass.simpleName
        activityResumedIntent.onNext(true)
        if (appPreference.isRefreshArchiveMessages) {
            appPreference.isRefreshArchiveMessages = false
            fetchMessages()
        }
    }

    override fun onPause() {
        super.onPause()
        activityResumedIntent.onNext(false)
    }

    override fun onDestroy() {
        super.onDestroy()
        disposables.dispose()
        if (EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().unregister(this)

        GoogleSmallNativeAdManagerArchive.onDestroy()
    }

    override fun showBackButton(show: Boolean) {
//        if (show) {
//            supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_close_black_24dp)
//        } else {
//            supportActionBar?.setHomeAsUpIndicator(null)
//        }
        super.showBackButton(show)
    }

    override fun requestDefaultSms() {
    }

    override fun requestPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }

        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 0)
    }

    override fun clearSearch() {
        dismissKeyboard()
        binding.messageTab.toolbarSearch.text = null
    }

    override fun clearSelection() {
        conversationsAdapter.clearSelection()
    }

//    override fun onBackPressedFromArchive() {
//        backPressedSubject.onNext(NavItem.BACK)
//    }

    override fun themeChanged() {
        binding.messageTab.recyclerView.scrapViews()
        EventBus.getDefault().post(MessageEvent(THEME_CHANGED))
    }

    override fun showBlockingDialog(conversations: List<Long>, block: Boolean) {
        blockingDialog.show(this, conversations, block)
        delayExecution(200) {
            refreshArchive()
        }
    }


    override fun showDeleteDialog(conversations: List<Long>) {
        val count = conversations.size
        val dialog = AlertDialog.Builder(this, R.style.CustomFieldDialogTheme)
            .setTitle(R.string.dialog_delete_title)
            .setMessage(resources.getQuantityString(R.plurals.dialog_delete_message, count, count))
            .setPositiveButton(R.string.button_delete) { _, _ ->
                confirmDeleteIntent.onNext(conversations)
            }
            .setNegativeButton(R.string.button_cancel, null)
            .create()  // Use create() instead of show()

        dialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
        dialog.setOnShowListener {
            // Change the button text colors after the dialog is shown
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(
                baseConfig.primaryColor
            )
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                ?.setTextColor(resources.getColor(R.color.black))
        }

        dialog.show()
    }


    override fun showArchivedSnackbar() {

    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }

            R.id.selectAll -> {
                conversationsAdapter.toggleSelectAll(true)
                true
            }

            else -> {
                optionsItemIntent.onNext(item.itemId)
                return true
            }
        }

    }

    override fun onBackPressed() {
        if (conversationsAdapter.selection.isNotEmpty()) {
            clearSelection()
        } else {
            finish()
        }

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.type) {
            REFRESH_MESSAGE -> {
                Log.e("onMessageEvent", "REFRESH_MESSAGE")
                fetchMessages()
            }

            REFRESH_CONTACT_GROUP -> {
//                binding.contactTab.cancel.performClick()
            }

            THEME_CHANGED -> {
                binding.messageTab.recyclerView.scrapViews()
            }

            SYNC_MESSAGE -> {
                Log.e("onMessageEvent", "SYNC_MESSAGE")
                fetchMessages()
            }

            REFRESH_ARCHIVE -> {
                Log.e("onMessageEvent", "SYNC_MESSAGE")
                fetchMessages()
            }

            SELECTED_CHANGES -> {
                binding.messageTab.llArchive.beGone()
                binding.messageTab.compose.beGone()
                val page = event.data as Archived
                when (page.selected != 0) {
                    true -> {
                        setCommonData(
                            showBottomAction = true
                        )
                        setTitle(getString(R.string.main_title_selected, page.selected))
                    }

                    false -> {
                        setCommonData(
                            showBottomAction = false
                        )
                        setTitle(getString(R.string.title_archived))
                    }
                }
            }
        }

    }

    override fun clearQuery() {
    }

    override fun refreshArchive() {
        EventBus.getDefault().post(MessageEvent(REFRESH_ARCHIVE))
        fetchMessages()
    }


    override fun refreshBlockedList() {
//        EventBus.getDefault().post(MessageEvent(REFRESH_ARCHIVE))
//        fetchMessages()
    }


    override fun openKeyboard() {
    }

    override fun finish(result: HashMap<String, String?>) {
        val intent =
            Intent(this@ArchiveActivity, ComposeActivity::class.java).putExtra(ChipsKey, result)
        startActivity(intent)
    }

}
