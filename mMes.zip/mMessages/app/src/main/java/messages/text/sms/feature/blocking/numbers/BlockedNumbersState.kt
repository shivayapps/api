package messages.text.sms.feature.blocking.numbers

import io.realm.RealmResults
import messages.text.sms.model.BlockedNumber

data class BlockedNumbersState(
    val numbers: RealmResults<BlockedNumber>? = null,
)
