package messages.text.sms.commons.adapters

import android.view.ViewGroup
import androidx.core.view.isVisible
import messages.text.sms.common.base.MainBaseAdapter
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.databinding.ContactListItemGroupBinding
import messages.text.sms.feature.main.MainActivity
import messages.text.sms.model.Contact
import messages.text.sms.model.ContactGroup
import messages.text.sms.model.Recipient

class ContactGroupItemAdapter : MainBaseAdapter<ContactGroup, ContactListItemGroupBinding>() {

    init {
        setHasStableIds(true)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<ContactListItemGroupBinding> {
        return MainBaseMsgViewHolder(parent, ContactListItemGroupBinding::inflate).apply {
            binding.root.setOnClickListener {
                val item = getItem(adapterPosition)
                (it.context as? MainActivity)?.onContactGroupClick(item)
            }

            binding.root.setOnLongClickListener {
                val item = getItem(adapterPosition)
                (it.context as? MainActivity)?.onContactGroupLongClick(item)
                true
            }


        }
    }

    override fun onBindViewHolder(
        holder: MainBaseMsgViewHolder<ContactListItemGroupBinding>,
        position: Int,
    ) {
        val group = getItem(position) ?: return
        holder.binding.avatars.recipientsGroup = group.contacts.map(::createRecipient)
        holder.binding.title.text = group.title
        holder.binding.subtitle.text = "${group.contacts.size} People"
//        holder.binding.subtitle.collapseEnabled = group.contacts.size > 1
        holder.binding.subtitle.isVisible = holder.binding.subtitle.text.isNotEmpty()

    }

    private fun createRecipient(contact: Contact): Recipient {
        return Recipient(
            address = contact.numbers.firstOrNull()?.address ?: "",
            contact = contact
        )
    }

    override fun areContentsTheSame(old: ContactGroup, new: ContactGroup): Boolean {
        val oldIds = old.contacts.map { contact -> contact.lookupKey }
        val newIds = new.contacts.map { contact -> contact.lookupKey }
        return oldIds == newIds
    }

    override fun areItemsTheSame(old: ContactGroup, new: ContactGroup): Boolean {
        return false
    }

}
