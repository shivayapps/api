package  messages.text.sms.ads

import android.app.Activity
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.ViewGroup
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import messages.text.sms.common.MysmsApplication
import messages.text.sms.common.isAdsNotShowOnResume


object GoogleBannerAdManager {
    private val TAG = "BannerAdManager"


    private var homeBannerAd: AdView? = null
    private var ishomeBannerLoading = false
    private var ishomeBannerLoaded = false
    fun showHomeGoogleBanner(activity: Activity, parentView: ViewGroup) {
        homeBannerAd = null
        ishomeBannerLoading = false
        ishomeBannerLoaded = false
        if (!activity.isInternetConnected() || !AdsPreferences(activity).adsEnable
        ) {
            handleBannerVisibility(activity, parentView, null)
            return
        }

        if (homeBannerAd != null) {
            handleBannerVisibility(activity, parentView, homeBannerAd!!)
        } else {
            if (ishomeBannerLoading) return
            ishomeBannerLoading = true
            homeBannerAd = AdView(activity)
            homeBannerAd!!.apply {
                setAdSize(getAdSize(activity))
                adUnitId = activity.getAppHomeBanner()
                adListener = object : AdListener() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        ishomeBannerLoading = false
                        failedToLoad(activity, adError)
                        homeBannerAd = null
                        handleBannerVisibility(activity, parentView, null)
                    }

                    override fun onAdLoaded() {
                        ishomeBannerLoading = false
                        ishomeBannerLoaded = true
                        handleBannerVisibility(activity, parentView, this@apply)
                        loadedLog(activity)

                    }

                    override fun onAdClicked() {
                        super.onAdClicked()
                        isAdsNotShowOnResume = true
                    }
                }
                loadAd(AdRequest.Builder().build())
            }
        }
    }


    fun showHomeAdmobBanner(activity: Activity, parentView: ViewGroup) {
        if (!activity.isInternetConnected() || !AdsPreferences(activity).adsEnable
        ) {
            handleBannerVisibility(activity, parentView, null)
            return
        }
        if (homeBannerAd != null) {
            parentView.removeAllViews()
            val bannerParent = homeBannerAd!!.parent as? ViewGroup
            bannerParent?.removeView(homeBannerAd)
            parentView.addView(homeBannerAd)
            homeBannerAd!!.resume()

        } else {
            showHomeGoogleBanner(activity, parentView)
        }
    }


    private var docViewBannerAd: AdView? = null
      private var isDocViewBannerLoading = false
      private var isDocViewBannerLoaded = false
    fun showHomeBannerViewBanner(activity: Activity, parentView: ViewGroup) {
        if (!activity.isInternetConnected() || !AdsPreferences(activity).adsEnable
          ) {
            handleHomeBannerVisibility(activity, parentView, null)
              return
          }

          if (docViewBannerAd != null) {
              handleHomeBannerVisibility(activity, parentView, docViewBannerAd!!)
          } else {
              if (isDocViewBannerLoading) return
              isDocViewBannerLoading = true
              docViewBannerAd = AdView(activity)
              docViewBannerAd!!.apply {
                  setAdSize(getAdSize(activity))
                  adUnitId = activity.getAppHomeBanner()
                  adListener = object : AdListener() {
                      override fun onAdFailedToLoad(adError: LoadAdError) {
                          isDocViewBannerLoading = false
                          failedToLoad(activity, adError)
                          docViewBannerAd = null
                          handleHomeBannerVisibility(activity, parentView, null)
                      }

                      override fun onAdLoaded() {
                          isDocViewBannerLoading = false
                          isDocViewBannerLoaded = true
                          handleHomeBannerVisibility(activity, parentView, this@apply)
                          loadedLog(activity)

                      }

                      override fun onAdClicked() {
                          super.onAdClicked()
                          isAdsNotShowOnResume = true
                      }
                  }
                  loadAd(AdRequest.Builder().build())
              }
          }
      }

    var otpBannerAd: AdView? = null
    var otpBannerLoading = false
    var otpBannerLoaded = false

    fun showOTPBanner(activity: Activity, parentView: ViewGroup, placeHolder: View) {
        Log.d("OTPBanner", "Attempting to show otp banner ad...")

        if (!activity.isInternetConnected()) {
            Log.d("OTPBanner", "No internet connection. Skipping ad load.")
            handleOTPBannerVisibility(activity, parentView, placeHolder, null)
            return
        }

        val adsPref = AdsPreferences(activity)
        if (!adsPref.adsEnable) {
            Log.d("OTPBanner", "Ads are disabled in preferences.")
            handleOTPBannerVisibility(activity, parentView, placeHolder, null)
            return
        }

        if (adsPref.isPro) {
            Log.d("OTPBanner", "User is Pro. No ads will be shown.")
            handleOTPBannerVisibility(activity, parentView, placeHolder, null)
            return
        }

        if (otpBannerAd != null) {
            Log.d("OTPBanner", "OTP banner already loaded. Showing existing banner.")
            handleOTPBannerVisibility(activity, parentView, placeHolder, otpBannerAd!!)
        } else {
            if (otpBannerLoading) {
                Log.d("OTPBanner", "Banner is already loading. Skipping duplicate load.")
                return
            }
            otpBannerLoading = true
            Log.d("OTPBanner", "Creating and loading new AdView...")

            val adView = AdView(activity)
            adView.setAdSize(AdSize.BANNER)
            adView.adUnitId = activity.getOTPBanner()

            adView.adListener = object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.e("OTPBanner", "Ad failed to load: ${adError.message}")
                    otpBannerLoading = false
                    failedToLoad(activity, adError)
                    otpBannerAd = null
                    handleOTPBannerVisibility(activity, parentView, placeHolder, null)
                }

                override fun onAdLoaded() {
                    Log.d("OTPBanner", "Ad successfully loaded.")
                    otpBannerLoading = false
                    otpBannerLoaded = true
                    handleOTPBannerVisibility(activity, parentView, placeHolder, adView)
                    loadedLog(activity)
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                    Log.d("OTPBanner", "Ad clicked.")
                    isAdsNotShowOnResume = true
                }
            }

            otpBannerAd = adView
            Log.d("OTPBanner", "Loading ad with AdRequest...")
            adView.loadAd(AdRequest.Builder().build())
        }
    }

    private var exitBannerAd: AdView? = null
    private var exitBannerLoading = false
    private var exitBannerLoaded = false

    fun showExitBanner(activity: Activity, parentView: ViewGroup) {
        Log.d("ExitBanner", "Attempting to show exit banner ad...")

        if (!activity.isInternetConnected()) {
            Log.d("ExitBanner", "No internet connection. Skipping ad load.")
            handleExitBannerVisibility(activity, parentView, null)
            return
        }

        val adsPref = AdsPreferences(activity)
        if (!adsPref.adsEnable) {
            Log.d("ExitBanner", "Ads are disabled in preferences.")
            handleExitBannerVisibility(activity, parentView, null)
            return
        }

        if (adsPref.isPro) {
            Log.d("ExitBanner", "User is Pro. No ads will be shown.")
            handleExitBannerVisibility(activity, parentView, null)
            return
        }

        if (exitBannerAd != null) {
            Log.d("ExitBanner", "Exit banner already loaded. Showing existing banner.")
            handleExitBannerVisibility(activity, parentView, exitBannerAd!!)
        } else {
            if (exitBannerLoading) {
                Log.d("ExitBanner", "Banner is already loading. Skipping duplicate load.")
                return
            }
            exitBannerLoading = true
            Log.d("ExitBanner", "Creating and loading new AdView...")

            val adView = AdView(activity)
            adView.setAdSize(AdSize.MEDIUM_RECTANGLE)
            adView.adUnitId = activity.getExitBanner()

            adView.adListener = object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.e("ExitBanner", "Ad failed to load: ${adError.message}")
                    exitBannerLoading = false
                    failedToLoad(activity, adError)
                    exitBannerAd = null
                    handleExitBannerVisibility(activity, parentView, null)
                }

                override fun onAdLoaded() {
                    Log.d("ExitBanner", "Ad successfully loaded.")
                    exitBannerLoading = false
                    exitBannerLoaded = true
                    handleExitBannerVisibility(activity, parentView, adView)
                    loadedLog(activity)
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                    Log.d("ExitBanner", "Ad clicked.")
                    isAdsNotShowOnResume = true
                }
            }

            exitBannerAd = adView
            Log.d("ExitBanner", "Loading ad with AdRequest...")
            adView.loadAd(AdRequest.Builder().build())
        }
    }


    /*
             private var mainHomeViewBannerAd: AdView? = null
             private var ismainHomeViewBannerLoading = false
             private var isMainHomeViewBannerLoaded = false
             fun showMainHomeViewBanner(activity: Activity, parentView: ViewGroup) {
                 if (!activity.isInternetConnected() || !AdsPreferences(activity).adsEnable || AdsPreferences(
                         activity
                     ).isPro
                 ) {
                     handleBannerVisibility(activity, parentView, null)
                     return
                 }

                 if (mainHomeViewBannerAd != null) {
                     handleBannerVisibility(activity, parentView, mainHomeViewBannerAd!!)
                 } else {
                     if (ismainHomeViewBannerLoading) return
                     ismainHomeViewBannerLoading = true
                     mainHomeViewBannerAd = AdView(activity)
                     mainHomeViewBannerAd!!.apply {
                         setAdSize(getAdSize(activity))
                         adUnitId = activity.geMainHomeBanner()
                         adListener = object : AdListener() {
                             override fun onAdFailedToLoad(adError: LoadAdError) {
                                 ismainHomeViewBannerLoading = false
                                 failedToLoad(activity, adError)
                                 mainHomeViewBannerAd = null
                                 handleBannerVisibility(activity, parentView, null)
                             }

                             override fun onAdLoaded() {
                                 ismainHomeViewBannerLoading = false
                                 isMainHomeViewBannerLoaded = true
                                 handleBannerVisibility(activity, parentView, this@apply)
                                 loadedLog(activity)
                             }

                             override fun onAdClicked() {
                                 super.onAdClicked()
                                 isAdsNotShowOnResume = true
                             }
                         }
                         loadAd(AdRequest.Builder().build())
                     }
                 }
             }

             private var singleImageViewBannerAd: AdView? = null
             private var isSingleImageViewBannerLoading = false
             private var isSingleImageViewBannerLoaded = false
             fun showSingleImageViewBanner(activity: Activity, parentView: ViewGroup) {
                 if (!activity.isInternetConnected() || !AdsPreferences(activity).adsEnable || AdsPreferences(
                         activity
                     ).isPro
                 ) {
                     handleBannerVisibility(activity, parentView, null)
                     return
                 }

                 if (singleImageViewBannerAd != null) {
                     handleBannerVisibility(activity, parentView, singleImageViewBannerAd!!)
                 } else {
                     if (isSingleImageViewBannerLoading) return
                     isSingleImageViewBannerLoading = true
                     singleImageViewBannerAd = AdView(activity)
                     singleImageViewBannerAd!!.apply {
                         setAdSize(getAdSize(activity))
                         adUnitId = activity.getFilesViewBanner()
                         adListener = object : AdListener() {
                             override fun onAdFailedToLoad(adError: LoadAdError) {
                                 isSingleImageViewBannerLoading = false
                                 failedToLoad(activity, adError)
                                 singleImageViewBannerAd = null
                                 handleBannerVisibility(activity, parentView, null)
                             }

                             override fun onAdLoaded() {
                                 isSingleImageViewBannerLoading = false
                                 isSingleImageViewBannerLoaded = true
                                 handleBannerVisibility(activity, parentView, this@apply)
                                 loadedLog(activity)
                             }

                             override fun onAdClicked() {
                                 super.onAdClicked()
                                 isAdsNotShowOnResume = true
                             }
                         }
                         loadAd(AdRequest.Builder().build())
                     }
                 }
             }*/


    fun handleHomeBannerVisibility(
        activity: Activity,
        parentView: ViewGroup,
        bannerAdView: AdView?,
    ) {
        if (activity.isDestroyed || activity.isFinishing) return

        if (bannerAdView != null) {
            activity.firebaseAnalyticsHandler.logMessages(
                app_banner_created, activity.getActivityName()
            )
            activity.firebaseAnalyticsHandler.logMessages(
                app_ad_banner_shown, activity.getActivityName()
            )
            val view = parentView.getChildAt(0)

            if (view.tag != null && view.tag.toString().equals("shrimmer")) {
                if (bannerAdView.parent != null) (bannerAdView.parent as ViewGroup).removeView(
                    bannerAdView
                )
                parentView.removeAllViews()
                parentView.addView(bannerAdView)
                bannerAdView.resume()
                (parentView.parent as View).visibility = View.VISIBLE
            } else {

                if (bannerAdView.parent != null) (bannerAdView.parent as ViewGroup).removeView(
                    bannerAdView
                )
                parentView.removeAllViews()

                parentView.addView(bannerAdView)
            }
            bannerAdView.setOnClickListener {
                MysmsApplication.isAdsNotShowOnResume = true
            }
        } else {
            activity.firebaseAnalyticsHandler.logMessages(
                app_banner_created, activity.getActivityName()
            )
            activity.firebaseAnalyticsHandler.logMessages(
                app_ad_banner_failed, activity.getActivityName()
            )
            parentView.removeAllViews()
            (parentView.parent as View).visibility = View.GONE
        }

    }

    fun handleBannerVisibility(activity: Activity, parentView: ViewGroup, bannerAdView: AdView?) {
        if (activity.isDestroyed || activity.isFinishing) return

        if (bannerAdView != null) {
            activity.firebaseAnalyticsHandler.logMessages(
                app_banner_created, activity.getActivityName()
            )
            activity.firebaseAnalyticsHandler.logMessages(
                app_ad_banner_shown, activity.getActivityName()
            )
            val view = parentView.getChildAt(0)

            if (view.tag != null && view.tag.toString().equals("shrimmer")) {
                if (bannerAdView.parent != null) (bannerAdView.parent as ViewGroup).removeView(
                    bannerAdView
                )
                parentView.removeAllViews()
                parentView.addView(bannerAdView)
                bannerAdView.resume()
                (parentView.parent as View).visibility = View.VISIBLE
            } else {

                if (bannerAdView.parent != null) (bannerAdView.parent as ViewGroup).removeView(
                    bannerAdView
                )
                parentView.removeAllViews()

                parentView.addView(bannerAdView)
            }
        } else {
            activity.firebaseAnalyticsHandler.logMessages(
                app_banner_created, activity.getActivityName()
            )
            activity.firebaseAnalyticsHandler.logMessages(
                app_ad_banner_failed, activity.getActivityName()
            )
            parentView.removeAllViews()
            (parentView.parent as View).visibility = View.GONE
        }

    }

    fun handleExitBannerVisibility(
        activity: Activity,
        parentView: ViewGroup,
        bannerAdView: AdView?,
    ) {
        if (activity.isDestroyed || activity.isFinishing) return

        if (bannerAdView != null) {
            activity.firebaseAnalyticsHandler.logMessages(
                app_banner_created, activity.getActivityName()
            )
            activity.firebaseAnalyticsHandler.logMessages(
                app_ad_banner_shown, activity.getActivityName()
            )

            if (bannerAdView.parent != null) (bannerAdView.parent as ViewGroup).removeView(
                bannerAdView
            )
            parentView.removeAllViews()

            parentView.addView(bannerAdView)

        } else {
            activity.firebaseAnalyticsHandler.logMessages(
                app_banner_created, activity.getActivityName()
            )
            activity.firebaseAnalyticsHandler.logMessages(
                app_ad_banner_failed, activity.getActivityName()
            )
            parentView.removeAllViews()
            (parentView.parent as View).visibility = View.GONE
        }

    }

    fun handleOTPBannerVisibility(
        activity: Activity,
        parentView: ViewGroup,
        placeHolder: View,
        bannerAdView: AdView?,
    ) {
        if (activity.isDestroyed || activity.isFinishing) return

        if (bannerAdView != null) {


            (parentView.parent as View).visibility = View.VISIBLE
            placeHolder.visibility = View.GONE

            activity.firebaseAnalyticsHandler.logMessages(
                app_banner_created, activity.getActivityName()
            )
            activity.firebaseAnalyticsHandler.logMessages(
                app_ad_banner_shown, activity.getActivityName()
            )

            if (bannerAdView.parent != null) (bannerAdView.parent as ViewGroup).removeView(
                bannerAdView
            )
            parentView.removeAllViews()

            parentView.addView(bannerAdView)


        } else {
            activity.firebaseAnalyticsHandler.logMessages(
                app_banner_created, activity.getActivityName()
            )
            activity.firebaseAnalyticsHandler.logMessages(
                app_ad_banner_failed, activity.getActivityName()
            )
            parentView.removeAllViews()
            (parentView.parent as View).visibility = View.GONE
        }

    }


    /*   fun onPause(activity: Activity) {
           if (activity is HomeActivity) mainHomeViewBannerAd?.pause()
           if (activity is FileListActivity) homeBannerAd?.pause()
           if (activity is DirectoriesActivity) homeBannerAd?.pause()
           if (activity is SingleImageViewActivity) singleImageViewBannerAd?.pause()
           if (activity is EditActivity) pdfPreviewBannerAd?.pause()
           if (activity is ViewFilesNew_Activity) docViewBannerAd?.pause()
           if (activity is RecyclerActivity) homeBannerAd?.pause()
       }

       fun onResume(activity: Activity) {
           if (activity is HomeActivity) mainHomeViewBannerAd?.resume()
           if (activity is DirectoriesActivity) homeBannerAd?.resume()
           if (activity is RecyclerActivity) homeBannerAd?.resume()
           if (activity is FileListActivity) homeBannerAd?.resume()
           if (activity is SingleImageViewActivity) singleImageViewBannerAd?.resume()
           if (activity is EditActivity) pdfPreviewBannerAd?.resume()
           if (activity is ViewFilesNew_Activity) docViewBannerAd?.resume()
       }*/


    fun onDestroyFileView() {

        /* docViewBannerAd?.destroy()
         docViewBannerAd = null

         pdfPreviewBannerAd?.destroy()
         pdfPreviewBannerAd = null

         singleImageViewBannerAd?.destroy()
         singleImageViewBannerAd = null*/
    }

    fun onDestroy() {
//        mainHomeViewBannerAd?.destroy()
//        mainHomeViewBannerAd = null

        homeBannerAd?.destroy()
        homeBannerAd = null

        docViewBannerAd?.destroy()
        docViewBannerAd = null

//        docViewBannerAd?.destroy()
//        docViewBannerAd = null

//        pdfPreviewBannerAd?.destroy()
//        pdfPreviewBannerAd = null

//        singleImageViewBannerAd?.destroy()
//        singleImageViewBannerAd = null
    }

    private fun getAdSize(activity: Activity): AdSize {
        val display = activity.windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val widthPixels = outMetrics.widthPixels.toFloat()
        val density = outMetrics.density
        val adWidth = (widthPixels / density).toInt()

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
            activity, adWidth
        )
    }

    private fun failedToLoad(activity: Activity, adError: LoadAdError) {
        Log.i(
            activity.localClassName.replace(activity.packageName, ""),
            "onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
        )
    }

    private fun loadedLog(activity: Activity) {
        Log.i(
            activity.localClassName.replace(activity.packageName, ""),
            "onAdFailedToLoad: loadedLog "
        )
    }
}