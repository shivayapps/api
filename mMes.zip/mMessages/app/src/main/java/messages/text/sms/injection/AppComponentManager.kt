package messages.text.sms.injection


import messages.text.sms.common.MysmsApplication


internal lateinit var appComponent: AppComponent
    private set

internal object AppComponentManager {

    fun init(application: MysmsApplication) {
        appComponent = DaggerAppComponent.builder()
            .appModule(AppModule(application))
            .build()
    }

}