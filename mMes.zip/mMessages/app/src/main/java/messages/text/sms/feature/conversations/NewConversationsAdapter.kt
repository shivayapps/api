package messages.text.sms.feature.conversations

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import io.realm.Realm
import io.realm.RealmResults
import messages.text.sms.R
import messages.text.sms.ads.GoogleSmallNativeAdManagerHome
import messages.text.sms.ads.GoogleSmallNativeAdManagerHome.showNative4Home
import messages.text.sms.ads.GoogleSmallNativeAdManagerHome.showNativeHome
import messages.text.sms.ads.delayExecution
import messages.text.sms.ads.isFirstTimeAppOpen
import messages.text.sms.common.MysmsApplication.Companion.dataLoading
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.common.base.NewBaseAdapter
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.common.util.extensions.makeToast
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.commons.extensions.addAlpha
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.commons.extensions.clientConfigPref
import messages.text.sms.commons.extensions.config
import messages.text.sms.commons.helpers.ReConstant
import messages.text.sms.databinding.ConversationListItemBinding
import messages.text.sms.feature.main.MainActivity.Companion.currentPoss
import messages.text.sms.interactor.MarkRead
import messages.text.sms.model.Conversation
import messages.text.sms.model.ConversationAD
import messages.text.sms.model.ModelType
import messages.text.sms.repository.MessageRepository
import messages.text.sms.util.PhoneNumberUtils
import messages.text.sms.util.Preferences
import java.util.regex.Pattern
import javax.inject.Inject


class NewConversationsAdapter @Inject constructor(
    private val colors: Colors,
    private val context: Context,
    private val dateFormatter: DateFormatter,
    private val navigator: Navigator,
    private val phoneNumberUtils: PhoneNumberUtils,
    private val messageRepo: MessageRepository,
    private val prefs: Preferences,
    private val markRead: MarkRead,
) : NewBaseAdapter<Conversation, ConversationListItemBinding>() {

    var activity: Activity? = null
    var currentActivity: String? = null
    var isLoadingAd = true
    private val AD_VIEW_TYPE = 2 // Unique view type for native ads

    init {
        // This is how we access the threadId for the swipe actions
        setHasStableIds(true)
    }

    /*  override fun onChange(position: Int): CharSequence {
          val conversation = getItem(getConversationPosition(position)) ?: return ""

          return if (conversation is Conversation) {
              conversation.date.takeIf { it > 0 }?.let(dateFormatter::getConversationTimestamp) ?: ""
          } else {
              ""
          }
      }*/

    override fun getItemId(position: Int): Long {
        val conversation = getItem(getConversationPosition(position)) ?: return -1
        if (conversation is Conversation) {
            return conversation.id
        }
        return -1
    }

    fun getList(): List<ModelType> {
        return getAllItems()
    }

    fun toggleSelectAll(isSelect: Boolean) {

        val cnt = itemCount
        if (selection.size == cnt) {
            clearSelection()
        } else {
            selection = listOf()
            // Create a list of all eligible item IDs (excluding AD_VIEW_TYPE)
            val eligibleIds =
                asyncListDiffer.currentList.filterIsInstance<Conversation>().map { it.id }

            // Use Kotlin's set operations for efficient selection manipulation
            if (isSelect) {
                // Add all eligible IDs to the selection
                selection = selection + eligibleIds
            } else {
                // Remove all eligible IDs from the selection
                selection = selection - eligibleIds
            }

            selectionChanges.onNext(selection)
            notifyDataSetChanged()
        }
    }

    /*fun getBubbleText(adapterPosition: Int): String {
        val conversation = getItem(adapterPosition)
        return if (conversation is Conversation) {
            conversation.date.takeIf { it > 0 }?.let(dateFormatter::getConversationTimestamp) ?: ""
        } else {
            ""
        }
    }*/
    fun getBubbleText(adapterPosition: Int): String {
        if (adapterPosition < 0 || adapterPosition >= itemCount) {
            return ""
        }
        val conversation = getItem(adapterPosition)
        return if (conversation is Conversation) {
            conversation.date.takeIf { it > 0 }?.let(dateFormatter::getConversationTimestamp) ?: ""
        } else {
            ""
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<ConversationListItemBinding> {

        return MainBaseMsgViewHolder(parent, ConversationListItemBinding::inflate).apply {
            if (viewType == AD_VIEW_TYPE) {
                binding.llAds.beVisible()
                binding.topLine.beVisible()
                binding.mainConversation.beGone()

            } else {
                binding.llAds.beGone()
                binding.topLine.beGone()
                binding.mainConversation.beVisible()
                val textColorPrimary = context.baseConfig.textColor
                val colorWithAlpha = textColorPrimary.addAlpha(0.45F)
                binding.title.setTextColor(textColorPrimary)
                binding.date.setTextColor(colorWithAlpha)
                binding.snippet.setTextColor(colorWithAlpha)

                if (viewType == 1) {
                    binding.title.setTypeface(binding.title.typeface, Typeface.BOLD)
                    binding.snippet.setTypeface(binding.snippet.typeface, Typeface.BOLD)
                    binding.snippet.setTextColor(textColorPrimary)
                    binding.unread.isVisible = true
                    binding.date.setTypeface(binding.date.typeface, Typeface.BOLD)
                } else {
                    binding.title.setTypeface(binding.title.typeface, Typeface.NORMAL)
                    binding.snippet.setTypeface(binding.snippet.typeface, Typeface.NORMAL)
                    binding.snippet.setTextColor(colorWithAlpha)
                }

                val rtlLanguages = listOf(6, 10, 20) // Positions for RTL languages
                if (context.config.selectedLanguagePos in rtlLanguages) {


                    /* Log.e("Message_LogA", "title - :${binding.title.text.toString()} ")
                     Log.e("Message_LogA", "isValidNumber :${isValidNumber(binding.title.text.toString())} ")

                     if(isValidNumber(binding.title.text.toString())){

                         binding.snippet.gravity = Gravity.START
                         binding.title.gravity = Gravity.START
                     }else{

                         binding.snippet.gravity = Gravity.END
                         binding.title.gravity = Gravity.END
                     }*/

                    binding.snippet.gravity = Gravity.END
                    //    binding.title.gravity = Gravity.END
                } else {
                    binding.snippet.gravity = Gravity.START
                    //    binding.title.gravity = Gravity.START
                }



                binding.mainConversation.setOnClickListener {
                    val conversation = getItem(getConversationPosition(adapterPosition))
                        ?: return@setOnClickListener
                    if (conversation is Conversation) {

                        when (toggleSelection(conversation.id, false)) {
                            true -> {
                                if (isSelected(conversation.id)) {
                                    binding.cbSelect.isChecked = true
                                    binding.mainConversation.setBackgroundColor(Color.parseColor("#F4DCDF"))
                                } else {
                                    binding.cbSelect.isChecked = false
                                    binding.mainConversation.setBackgroundColor(Color.parseColor("#00000000"))
                                }
                            }

                            false -> {
                                try {
                                    currentPoss = position
                                    navigator.showConversation(conversation.id)

                                } catch (_: Exception) {
                                }
                                try {
                                    val xactivity = context as? Activity


                                    if (conversation.unread) {
                                        conversation.lastMessage?.read = true
                                        conversation.lastMessage?.seen = true
                                        xactivity?.delayExecution(500) {
                                            notifyDataSetChanged()
                                        }
                                    }
                                } catch (_: Exception) {
                                }
                            }
                        }
                    }

                }

                binding.mainConversation.setOnLongClickListener {
                    if (dataLoading == true) {

                        Toast.makeText(
                            context,
                            context.getString(R.string.please_wait_while_syncing_data),
                            Toast.LENGTH_SHORT
                        ).show()

                    } else {
                        /*val conversation = getItem(getConversationPosition(adapterPosition))
                        if (conversation is Conversation) {
                            toggleSelection(conversation.id)
                            if (isSelected(conversation.id)) {
                                binding.cbSelect.isChecked = true
                                binding.mainConversation.setBackgroundColor(Color.parseColor("#F4DCDF"))
                            } else {
                                binding.cbSelect.isChecked = false
                                binding.mainConversation.setBackgroundColor(Color.parseColor("#00000000"))
                            }
                            notifyDataSetChanged()
                        }*/

                        val position = getConversationPosition(adapterPosition)
                        if (position != RecyclerView.NO_POSITION) {
                            val conversation = getItem(position)
                            if (conversation is Conversation) {
                                toggleSelection(conversation.id)
                                if (isSelected(conversation.id)) {
                                    binding.cbSelect.isChecked = true
                                    binding.mainConversation.setBackgroundColor(Color.parseColor("#F4DCDF"))
                                } else {
                                    binding.cbSelect.isChecked = false
                                    binding.mainConversation.setBackgroundColor(Color.parseColor("#00000000"))
                                }
                                notifyDataSetChanged()
                            }
                        }

                    }
                    true
                }
            }


        }
    }

    fun isValidNumber(value: String): Boolean {
        // Check if the string contains at least one digit and does not contain letters
        return value.any { it.isDigit() } && !value.any { it.isLetter() }
    }

    override fun onBindViewHolder(
        holder: MainBaseMsgViewHolder<ConversationListItemBinding>,
        position: Int,
    ) {
        val conversation = getItem(getConversationPosition(position)) ?: return


        if (conversation is Conversation) {
            if (isSelected(conversation.id)) {
                holder.binding.cbSelect.isChecked = true
                holder.binding.mainConversation.setBackgroundColor(Color.parseColor("#F4DCDF"))
            } else {
                holder.binding.cbSelect.isChecked = false
                holder.binding.mainConversation.setBackgroundColor(Color.parseColor("#00000000"))
            }
            holder.binding.avatars.title = conversation.getTitle()
            holder.binding.avatars.recipients = conversation.recipients
            holder.binding.title.collapseEnabled = conversation.recipients.size > 1
            holder.binding.title.text = conversation.getTitle()
            holder.binding.date.text =
                conversation.date.takeIf { it > 0 }?.let(dateFormatter::getConversationTimestamp)

            try {
                val typeface = ResourcesCompat.getFont(context, prefs.selectedFont.get())
                holder.binding.snippet.setTypeface(typeface)
            } catch (_: Exception) {
            }
            holder.binding.snippet.text = when {
                conversation.draft.isNotEmpty() -> context.getString(
                    R.string.main_draft, conversation.draft
                )

                conversation.me -> context.getString(R.string.main_sender_you, conversation.snippet)
                else -> conversation.snippet
            }
            holder.binding.pinned.isVisible = conversation.pinned
            if (isSelection()) {
                holder.binding.cbSelect.beVisible()
            } else {
                holder.binding.cbSelect.beGone()
            }
//            holder.binding.cbSelect.buttonTintList =
//                ColorStateList.valueOf(context.baseConfig.primaryColor)
            holder.binding.pinned.imageTintList =
                ColorStateList.valueOf(context.baseConfig.primaryColor)

            // If the last message wasn't incoming, then the colour doesn't really matter anyway
            val lastMessage = conversation.lastMessage
            val recipient = when {
                conversation.recipients.size == 1 || lastMessage == null -> conversation.recipients.firstOrNull()
                else -> conversation.recipients.find { recipient ->
                    phoneNumberUtils.compare(recipient.address, lastMessage.address)
                }
            }
            holder.binding.unread.setTint(context.baseConfig.primaryColor)

            if (conversation.lastMessage != null) {

                val resultOtp =
                    Pattern.compile(ReConstant.otp_regex.toString())
                        .matcher(conversation.lastMessage?.body!!.replace("\n", " ").trim()).find()
//                Log.d(
//                    "check_conversationsadapter",
//                    "messageCatType: $resultOtp =====> ${conversation.lastMessage!!.body}"
//                )
                if (resultOtp && conversation.unread) {
                    holder.binding.tvOTP.beVisible()
                    holder.binding.tvOTP.setOnClickListener {

                        messageRepo.markRead(conversation.id)
                        conversation.makeRead()
                        holder.binding.tvOTP.beGone()

                        val otpCode =
                            ReConstant.parseCode(lastMessage!!.body.replace("\n", " ").trim())
                        ReConstant.copy(context, otpCode)
                        context.makeToast(R.string.toast_copied)

                        notifyItemChanged(position)

                    }
                } else {
                    holder.binding.tvOTP.beGone()
                }

            } else {
                holder.binding.tvOTP.beGone()
            }

        } else if (conversation is ConversationAD) {
            holder.binding.root.isFocusable = false
            holder.binding.llAds.isEnabled = false
            holder.itemView.isEnabled = false

            holder.binding.inBannerViewTop.root.visibility = View.VISIBLE
            if (conversation.position == 0) {
                if (GoogleSmallNativeAdManagerHome.mSmallNativeAd != null) {
                    showNativeHome(context, holder.binding.inBannerViewTop.root)
                } else if (GoogleSmallNativeAdManagerHome.mSmallNativeAd4 != null) {
                    showNative4Home(context, holder.binding.inBannerViewTop.root)
                }
                /* else if (GoogleSmallNativeAdManagerHome.mSmallNativeAd8 != null) {
                     showNative8Home(context, holder.binding.inBannerViewTop.root)
                 }*/
                else {
                    if (!isLoadingAd) {
                        holder.binding.llAds.visibility = View.GONE
                    }
                }
            } else if (conversation.position == 5) {


                if (context.isFirstTimeAppOpen()) {
                    if (GoogleSmallNativeAdManagerHome.mSmallNativeAd4 != null && context.clientConfigPref.homeSecondAdShow) {
                        showNative4Home(context, holder.binding.inBannerViewTop.root)
                    } else if (GoogleSmallNativeAdManagerHome.mSmallNativeAd != null && context.clientConfigPref.homeSecondAdShow) {
                        showNativeHome(context, holder.binding.inBannerViewTop.root)
                    } else {
                        if (!isLoadingAd) {
                            holder.binding.llAds.visibility = View.GONE
                        }
                    }
                } else {
                    if (GoogleSmallNativeAdManagerHome.mSmallNativeAd4 != null) {
                        showNative4Home(context, holder.binding.inBannerViewTop.root)
                    } else if (GoogleSmallNativeAdManagerHome.mSmallNativeAd != null) {
                        showNativeHome(context, holder.binding.inBannerViewTop.root)
                    } else {
                        if (!isLoadingAd) {
                            holder.binding.llAds.visibility = View.GONE
                        }
                    }
                }

                /*   if (GoogleSmallNativeAdManagerHome.mSmallNativeAd4 != null && context.clientConfigPref.homeSecondAdShow) {
                       showNative4Home(context, holder.binding.inBannerViewTop.root)
                   } else if (GoogleSmallNativeAdManagerHome.mSmallNativeAd != null && context.clientConfigPref.homeSecondAdShow) {
                       showNativeHome(context, holder.binding.inBannerViewTop.root)
                   }
                   *//*  else if (GoogleSmallNativeAdManagerHome.mSmallNativeAd8 != null) {
                      showNative8Home(context, holder.binding.inBannerViewTop.root)
                  } *//*
                else {
                    if (!isLoadingAd) {
                        holder.binding.llAds.visibility = View.GONE
                    }
                }*/
            }
            /* else if (conversation.position == 8) {
                 if (GoogleSmallNativeAdManagerHome.mSmallNativeAd8 != null) {
                     showNative8Home(context, holder.binding.inBannerViewTop.root)
                 } else if (GoogleSmallNativeAdManagerHome.mSmallNativeAd != null) {
                     showNativeHome(context, holder.binding.inBannerViewTop.root)
                 } else if (GoogleSmallNativeAdManagerHome.mSmallNativeAd4 != null) {
                     showNative4Home(context, holder.binding.inBannerViewTop.root)
                 } else {
                     if (!isLoadingAd) {
                         holder.binding.inBannerViewTop.root.visibility = View.VISIBLE
                         holder.binding.llAds.visibility = View.GONE
                     }
                 }
             }*/
            holder.binding.llAds.isEnabled = true
            holder.itemView.isEnabled = true
        }

    }

    override fun getItemViewType(position: Int): Int {
        val conversation = getItem(getConversationPosition(position))
        return if (conversation is ConversationAD) AD_VIEW_TYPE else if (conversation is Conversation && !conversation.unread) 0 else 1
    }


    fun getConversationPosition(position: Int): Int {
        return position
    }

    fun removeItem(threadId: Long) {
        val list =
            ArrayList(asyncListDiffer.currentList).filterIsInstance<Conversation>() as ArrayList<Conversation>
        list.removeIf { (it.id == threadId) }
//        Log.e("Message_Log", "updateData removeItem:${threadId} ")
        notifyList(list)
    }

    fun handleAction(threadId: Long, action: Int) {
        try {
            val list =
                ArrayList(asyncListDiffer.currentList).filterIsInstance<Conversation>() as ArrayList<Conversation>
            val conversation = list.firstOrNull { it.id == threadId }
            when (action) {
                Preferences.SWIPE_ACTION_DELETE -> {
                    removeItem(threadId)
                }

                Preferences.SWIPE_ACTION_BLOCK -> {
                    removeItem(threadId)
                }


                /*Preferences.SWIPE_ACTION_READ -> {
                    if (conversation!!.lastMessage!!.read) {
                        try {
                            conversation.makeUnread()
                        } catch (e: Exception) {
                        }
                    } else {
                        try {
                            conversation.makeRead()
                        } catch (e: Exception) {
                        }
                    }
                    notifyList(list)
                }*/

                Preferences.SWIPE_ACTION_READ -> {
                    val lastMsg = conversation?.lastMessage
                    if (lastMsg != null) {
                        try {
                            if (lastMsg.read) {
                                conversation.makeUnread()
                            } else {
                                conversation.makeRead()
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                        notifyList(list)
                    }
                }


                Preferences.SWIPE_ACTION_UNREAD -> {
                    if (conversation!!.lastMessage!!.read) {
                        conversation.makeUnread()
                    } else {
                        conversation.makeRead()

                    }
                    notifyList(list)
                }
            }
        } catch (e: Exception) {
            Log.e("Message_Log", "Exception :${e.message} ")
        }
    }

    fun updateData(dataMessage: RealmResults<Conversation>?) {
        if (dataMessage != null) {
            val arrayListOfUnmanagedObjects: List<Conversation> =
                Realm.getDefaultInstance().copyFromRealm(dataMessage)
            notifyList(arrayListOfUnmanagedObjects)
        }
    }

    private fun notifyList(arrayListOfUnmanagedObjects: List<Conversation>) {
        if (arrayListOfUnmanagedObjects.isNotEmpty()) {
            val list = ArrayList<ModelType>()
            list.addAll(arrayListOfUnmanagedObjects)
            list.add(0, ConversationAD(0))

            if (context.isFirstTimeAppOpen()) {
                if (list.size > 5 && context.clientConfigPref.homeSecondAdShow) {
                    list.add(5, ConversationAD(5))
                }
            } else {
                if (list.size > 5) {
                    list.add(5, ConversationAD(5))
                }
            }

            /*  if (list.size > 8) {
                  list.add(8, ConversationAD(8))
              }*/
//            Log.e("arrayListOfUnmanagedObjects", "updateData: ${arrayListOfUnmanagedObjects.size}")
//            Log.e("Message_Log", "updateData 002:${list.size} ")
            asyncListDiffer.submitList(list)
        } else {
            Log.e("Message_Log", "updateData notifyList.else")
        }
    }
}
