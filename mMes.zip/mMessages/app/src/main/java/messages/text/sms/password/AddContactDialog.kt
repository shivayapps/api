package messages.text.sms.password

import android.app.Dialog
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import messages.text.sms.R

class AddContactDialog(
    context: Context,
    title: String,
    private val callback: DialogCallback,
) {

    init {
        showDialog(context, title)
    }

    private fun showDialog(context: Context, title: String) {
        // Inflate the layout
        val dialogView =
            LayoutInflater.from(context).inflate(R.layout.add_contact_dialog_layout, null)

        // View references
        val item1 = dialogView.findViewById<TextView>(R.id.item1)
        val item2 = dialogView.findViewById<TextView>(R.id.item2)
        val item3 = dialogView.findViewById<TextView>(R.id.item3)
        val mTitle = dialogView.findViewById<TextView>(R.id.mTitle)
        val mCancel = dialogView.findViewById<TextView>(R.id.cancel)

        // Configure AlertDialog
        val dialog = Dialog(context)
        dialog.setContentView(dialogView)
        // Set rounded background (ensure correct drawable)
        dialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)

        // Set dialog width and margin in dp
        val params = dialog.window?.attributes
        val marginInDp = 30  // e.g., 16dp margin on left/right
        val marginInPx = (marginInDp * context.resources.displayMetrics.density).toInt()

// Adjust window layout with calculated margins
        params?.width = context.resources.displayMetrics.widthPixels - 2 * marginInPx
        dialog.window?.attributes = params


        // Set the title text
        mTitle.text = title

        // Click Listeners
        item1.setOnClickListener { callback.onItemClick(1); dialog.dismiss() }
        item2.setOnClickListener { callback.onItemClick(2); dialog.dismiss() }
        item3.setOnClickListener { callback.onItemClick(3); dialog.dismiss() }
        mCancel.setOnClickListener { dialog.dismiss() }

        // Show dialog
        dialog.show()
    }
}

interface DialogCallback {
    fun onItemClick(position: Int)
}