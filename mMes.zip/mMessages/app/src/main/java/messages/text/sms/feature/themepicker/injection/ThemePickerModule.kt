package messages.text.sms.feature.themepicker.injection

import dagger.Module
import dagger.Provides
import messages.text.sms.feature.themepicker.ThemePickerController
import messages.text.sms.injection.scope.ControllerScope
import javax.inject.Named

@Module
class ThemePickerModule(private val controller: ThemePickerController) {

    @Provides
    @ControllerScope
    @Named("recipientId")
    fun provideThreadId(): Long = controller.recipientId

}