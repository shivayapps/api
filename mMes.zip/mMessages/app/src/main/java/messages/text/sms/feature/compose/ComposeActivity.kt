package messages.text.sms.feature.compose

import android.Manifest
import android.animation.LayoutTransition
import android.app.Activity
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PersistableBundle
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.text.format.DateFormat
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.jakewharton.rxbinding2.view.clicks
import com.jakewharton.rxbinding2.widget.textChanges
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.ads.AdmobNative
import messages.text.sms.ads.AdmobNative.nativeAdChat
import messages.text.sms.ads.MainInterAdManager
import messages.text.sms.ads.delayExecution
import messages.text.sms.ads.getAppChatScreenNative
import messages.text.sms.common.BubbleListener
import messages.text.sms.common.CommonDialog
import messages.text.sms.common.FastScroller
import messages.text.sms.common.MysmsApplication.Companion.isAdsNotShowOnResume
import messages.text.sms.common.MysmsApplication.Companion.isHomeInterShow
import messages.text.sms.common.Navigator
import messages.text.sms.common.QuickMessageCustomDialog
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.common.util.extensions.autoScrollToStart
import messages.text.sms.common.util.extensions.hideKeyboard
import messages.text.sms.common.util.extensions.resolveThemeColor
import messages.text.sms.common.util.extensions.scrapViews
import messages.text.sms.common.util.extensions.setBackgroundTint
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.common.util.extensions.setVisible
import messages.text.sms.common.util.extensions.showKeyboard
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.dialogs.AlarmPermissionBottomSheetDialog
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.commons.extensions.beVisibleIf
import messages.text.sms.commons.extensions.clientConfigPref
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.ComposeActivityBinding
import messages.text.sms.feature.blocking.BlockingDialog
import messages.text.sms.feature.compose.editing.ChipsAdapter
import messages.text.sms.feature.contacts.ContactsActivity
import messages.text.sms.interactor.DeleteMessages
import messages.text.sms.model.Attachment
import messages.text.sms.model.Conversation
import messages.text.sms.model.DATA_SET
import messages.text.sms.model.DELETE_FROM_INFO
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.Recipient
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.inject.Inject


class ComposeActivity : MainBaseThemedActivity(), ComposeView {

    companion object {
        private const val SelectContactRequestCode = 0
        private const val TakePhotoRequestCode = 1
        private const val AttachPhotoRequestCode = 2
        private const val AttachContactRequestCode = 3

        private const val CameraDestinationKey = "camera_destination"
    }

    @Inject
    lateinit var attachmentAdapter: AttachmentAdapter


    @Inject
    lateinit var blockingDialog: BlockingDialog

    @Inject
    lateinit var chipsAdapter: ChipsAdapter

    @Inject
    lateinit var dateFormatter: DateFormatter

    @Inject
    lateinit var messageAdapter: MessagesAdapter

    @Inject
    lateinit var navigator: Navigator

    var dataSetDone = false
    var dataSetDone1 = false
    var isPrivateMessage = false
    var isBlockedMessage = false
    var tempBlock = false
    var threadIdManual: Long = 0

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    override val activityVisibleIntent: Subject<Boolean> = PublishSubject.create()
    override val chipsSelectedIntent: Subject<HashMap<String, String?>> = PublishSubject.create()
    override val chipDeletedIntent: Subject<Recipient> by lazy { chipsAdapter.chipDeleted }
    override val menuReadyIntent: Observable<Unit> = menu.map { }
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()
    override val sendAsGroupIntent by lazy { binding.sendAsGroupBackground.clicks() }
    override val messageClickIntent: Subject<Long> by lazy { messageAdapter.clicks }
    override val adapterItemDelete: Subject<Long> by lazy { messageAdapter.clicksDelete }
    override val messagePartClickIntent: Subject<Long> by lazy { messageAdapter.partClicks }
    override val messagesSelectedIntent by lazy { messageAdapter.selectionChanges }
    override val cancelSendingIntent: Subject<Long> by lazy { messageAdapter.cancelSending }
    override val attachmentDeletedIntent: Subject<Attachment> by lazy { attachmentAdapter.attachmentDeleted }
    override val textChangedIntent by lazy { binding.message.textChanges() }
    override val removeStarMessageSubject: Subject<Long> by lazy { messageAdapter.removeStarMessageSubject }
    override fun addOrRemoveStarred(): Observable<Long> = removeStarMessageSubject
    override fun addStarred(): Observable<Long> = starMessageSubject
    override val starMessageSubject: Subject<Long> = PublishSubject.create()

    override val attachIntent by lazy {
        Observable.merge(
            binding.attach.clicks(),
            binding.attachingBackground.clicks()
        )
    }
    override val cameraIntent by lazy {
        binding.llCamera.clicks()
    }
    override val quickIntent by lazy {
        binding.llQuick.clicks()
    }
    override val galleryIntent by lazy {
        binding.llGallery.clicks()
    }
    override val scheduleIntent by lazy {
        binding.llSchedule.clicks()
    }
    override val attachContactIntent by lazy {
        binding.llContact.clicks()
    }
    override val attachmentSelectedIntent: Subject<Uri> = PublishSubject.create()
    override val confirmDeleteIntent: Subject<DeleteMessages.Params> = PublishSubject.create()
    override val contactSelectedIntent: Subject<Uri> = PublishSubject.create()
    override val inputContentIntent by lazy { binding.message.inputContentSelected }
    override val scheduleSelectedIntent: Subject<Long> = PublishSubject.create()
    override val changeSimIntent by lazy { binding.sim.clicks() }
    override val scheduleCancelIntent by lazy { binding.scheduledCancel.clicks() }
    override val sendIntent by lazy { binding.send.clicks() }
    override val backPressedIntent: Subject<Unit> = PublishSubject.create()

    private val binding by viewBinding(ComposeActivityBinding::inflate)
    private val viewModel by lazy {
        ViewModelProviders.of(
            this,
            viewModelFactory
        )[ComposeViewModel::class.java]
    }

    private var cameraDestination: Uri? = null

    private fun changeOverflowIconColor(colorResId: Int) {
        val overflowIcon: Drawable? = toolbar.overflowIcon
        overflowIcon?.let {
            // Get the color from resources
            val color = resources.getColor(colorResId, null)

            // Wrap the drawable to apply color
            val wrappedDrawable = DrawableCompat.wrap(it)
            DrawableCompat.setTint(wrappedDrawable, color)

            // Set the wrapped drawable as the new overflow icon
            toolbar.overflowIcon = wrappedDrawable
        }
    }
    var fromScreen = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        if (intent.hasExtra(ContactsActivity.ChipsKey)) {
            viewModel.shouldShowContacts = false
        }
        viewModel.bindView(this)
        setSupportActionBar(binding.toolbar)
//        showBackButton(true)
        binding.contentView.layoutTransition = LayoutTransition().apply {
            disableTransitionType(LayoutTransition.CHANGING)
        }
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this)



        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = onBackPressedCall()
        })


        changeOverflowIconColor(R.color.iconColor)
        chipsAdapter.view = binding.chips
//        binding.chips.itemAnimator = null
//        binding.chips.layoutManager = FlexboxLayoutManager(this)

        val layoutManager = LinearLayoutManager(this)
        layoutManager.reverseLayout = true
        binding.chips.layoutManager = layoutManager

        messageAdapter.emptyView = binding.messagesEmpty


        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        fromScreen = intent.getStringExtra("from").toString()


        messageAdapter.autoScrollToStart(binding.messageList)

        binding.messageList.setHasFixedSize(true)

        binding.messageList.adapter = messageAdapter
//        binding.messageList.visibility = View.INVISIBLE

//        if (messageAdapter.itemCount > 6) {

//        Log.e("FastScroller", "message_Count.001:${messageAdapter.itemCount}")
        binding.messageList.post {
            FastScroller(binding.dragHandle, object : BubbleListener {
                override fun setBubbleText(str: String) {
//                    Log.e("FastScroller", "setBubbleText:$str")
                }

                override fun setViewY(y: Float, isMovedByHandleDrag: Boolean) {
                    binding.messageBubble.y = y
//                    Log.e("FastScroller", "setViewY:$y,isMovedByHandleDrag:$isMovedByHandleDrag")

                    val firstPosition =
                        (binding.messageList.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                    val lastPosition =
                        (binding.messageList.layoutManager as LinearLayoutManager).findLastVisibleItemPosition()

                    if (lastPosition >= messageAdapter.itemCount - 2) {
//                        if(isMovedByHandleDrag)
                        binding.messageBubble.beGone()
                        binding.scrollToEnd.beGone()
//                        binding.scrollToEnd.beVisible()
                    } else {
                        val str = messageAdapter.getBubbleText(firstPosition)
                        if (str.isNotEmpty()) binding.bubbleText.text = str
                        if (isMovedByHandleDrag) binding.messageBubble.beVisible()
                        else binding.messageBubble.beGone()

                        binding.scrollToEnd.beVisible()
//                        binding.scrollToEnd.beGone()
                    }
                }

                override fun setVisible(isVisible: Boolean) {
//                    Log.e("FastScroller", "setVisible:$isVisible")
                }
            }).bind(binding.messageList)
        }
//        }

//        binding.root.doOnPreDraw {
//            binding.messageList.addOnScrollListener(object : RecyclerView.OnScrollListener() {
//                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
//                    val firstPosition = (binding.messageList.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
//                    val lastPosition = (binding.messageList.layoutManager as LinearLayoutManager).findLastVisibleItemPosition()
//
////                    binding.ivScrollTopAlbum.beVisibleIf(firstPosition > 3)
//                    Log.e("FastScroller", "lastPosition:$lastPosition,itemCount:${messageAdapter.itemCount}")
//                    if (lastPosition >= messageAdapter.itemCount-3) {
//                        binding.messageBubble.beGone()
//                        binding.scrollToEnd.beGone()
////                        binding.scrollToEnd.beVisible()
//                    } else {
//                        val str = messageAdapter.getBubbleText(firstPosition)
//                        if (str.isNotEmpty()) binding.bubbleText.text = str
//                        binding.messageBubble.beVisible()
//                        binding.scrollToEnd.beVisible()
////                        binding.scrollToEnd.beGone()
//                    }
//                }
//            })
//        }

        binding.attachments.adapter = attachmentAdapter

        binding.message.supportsInputContent = true

        binding.messageList.scrollToPosition(messageAdapter.itemCount - 1)
        binding.scrollToEnd.setOnClickListener {
            binding.messageList.scrollToPosition(messageAdapter.itemCount - 1)
        }

        binding.unblockText.setOnClickListener {

            optionsItemIntent.onNext(R.id.unblock)
            /*  val updatedList = baseConfig.blockContactsList
                  .split(",")
                  .map { it.trim() }
                  .filter { it.replace(" ", "") != binding.titleText.text.toString() }*/

//            val nameToRemove = binding.titleText.text.toString()
//                .replace(" ", "")
//                .trim()
//                .takeLast(9)
//
//
//            val updatedList = baseConfig.blockContactsList.filter { contact ->
//                contact.phone?.replace("\\s".toRegex(), "")?.takeLast(9) != nameToRemove
//            }
//
//
//            baseConfig.blockContactsList = updatedList as ArrayList


            binding.mBlockView.visibility = View.GONE
            tempBlock = true

        }

        binding.closeIcon.setOnClickListener {


            binding.mBlockView.visibility = View.GONE
            isBlockedMessage = false
            tempBlock = true

        }

        theme
            .autoDisposable(scope())
            .subscribe { theme ->
                messageAdapter.theme = theme
                binding.attach.setBackgroundTint(baseConfig.primaryColor)
                binding.attach.setTint(theme.textPrimary)
                binding.loading.setTint(theme.theme)
            }
        window.callback = ComposeWindowCallback(window.callback, this)

        // These theme attributes don't apply themselves on API 21
        if (Build.VERSION.SDK_INT <= 22) {
            binding.messageBackground.setBackgroundTint(resolveThemeColor(R.attr.bubbleColor))
        }
        chipsSelectedIntent.onNext(intent?.getSerializableExtra(ContactsActivity.ChipsKey)
            ?.let { serializable -> serializable as? HashMap<String, String?> }
            ?: hashMapOf())

        setUpTheme()



        if (messageAdapter.itemCount > 0) {

//            if (clientConfigPref.adsInChat.lowercase() == "applovin") {
//                loadApplovinNative()
//            } else {
//                loadNative()
//            }
            loadNative()
        }
        binding.toolbarTitle.setOnClickListener {
            val menuItem = toolbar.menu.findItem(R.id.info)
            onOptionsItemSelected(menuItem)
        }

        binding.llCopy.setOnClickListener { optionsItemIntent.onNext(binding.llCopy.id) }
        binding.llDetail.setOnClickListener { optionsItemIntent.onNext(binding.llDetail.id) }
        binding.llForward.setOnClickListener { optionsItemIntent.onNext(binding.llForward.id) }
        binding.llDelete.setOnClickListener { optionsItemIntent.onNext(binding.llDelete.id) }
        binding.llShare.setOnClickListener { optionsItemIntent.onNext(binding.llShare.id) }


    }



    override fun showBlockingDialog(conversations: List<Long>, block: Boolean) {
        blockingDialog.show(this, conversations, block)
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.type) {
            DATA_SET -> {

                delayExecution(200) {

                    binding.messageList.scrollToPosition(messageAdapter.itemCount - 1)
                }
            }

            DELETE_FROM_INFO -> {
                val threadIdEvent = event.data as Long
                if (threadIdEvent == threadIdManual) {
                    finish()
                }
            }
        }

    }

    private fun setUpTheme() {

        updateTextColors(binding.contentView)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
            binding.llBottomAction.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
//            binding.llBottomAction.background =
//                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
//            arrayListOf(binding.ivBack, binding.ivDelete, binding.ivMore, binding.ivArchive, binding.ivRead, binding.ivBlock).forEach {
////                val whiteColor = ContextCompat.getColor(this, R.color.white)
//                val colorStateList = ColorStateList.valueOf(Color.WHITE)
//                it.imageTintList = colorStateList
//            }
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
            binding.llBottomAction.background = ColorDrawable(baseConfig.backgroundColor)
//            binding.llBottomAction.background = ColorDrawable(baseConfig.backgroundColor)
//            arrayListOf(binding.ivBack,binding.ivDelete, binding.ivMore, binding.ivArchive, binding.ivRead, binding.ivBlock).forEach {
////                val whiteColor = ContextCompat.getColor(this, R.color.black)
//                val colorStateList = ColorStateList.valueOf(Color.BLACK)
//                it.imageTintList = colorStateList
//            }
        }

        if (baseConfig.useImageResource == true) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")

//                val bitmapDrawable = BitmapDrawable(resources, baseConfig.storedBitmap)
//                constraintLayout.background = bitmapDrawable
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable

                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))

//                val colorWithAlpha = baseConfig.primaryColor.addAlpha(0.8F)
//                binding.navView.background = ColorDrawable(colorWithAlpha)

                val unselectedColor =
                    ContextCompat.getColor(this, android.R.color.darker_gray) // Unselected color
                val states = arrayOf(
                    intArrayOf(android.R.attr.state_checked), // Selected state
                    intArrayOf(-android.R.attr.state_checked) // Unselected state
                )

                val primaryColor = Color.parseColor("#FFFFFF")
                val colors = intArrayOf(
                    primaryColor, // Color for selected state
                    primaryColor // Color for unselected state
                )

//                val colorStateList = ColorStateList(states, colors)
//                binding.navView.itemIconTintList = colorStateList
//                binding.navView.setItemColors(primaryColor, primaryColor)
//                binding.navView.itemRippleColor = ColorStateList.valueOf(primaryColor.addAlpha(0.08F))
//                binding.navView.itemActiveIndicatorColor = ColorStateList.valueOf(primaryColor.addAlpha(0.12F))
            }
        } else {

            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
//            binding.navView.setBackgroundColor(baseConfig.backgroundColor)
//            lloptionmenu.setBackgroundColor(baseConfig.backgroundColor)
            toolbar.setBackgroundColor(baseConfig.backgroundColor)

            val unselectedColor =
                ContextCompat.getColor(this, android.R.color.darker_gray) // Unselected color
            val states = arrayOf(
                intArrayOf(android.R.attr.state_checked), // Selected state
                intArrayOf(-android.R.attr.state_checked) // Unselected state
            )
            val colors = intArrayOf(
                primaryColor, // Color for selected state
                unselectedColor // Color for unselected state
            )

            if (baseConfig.backgroundColor.equals(Color.BLACK)) {
                val primaryColortext = Color.parseColor("#FFFFFF")
                val colorstext = intArrayOf(
                    primaryColortext, // Color for selected state
                    unselectedColor // Color for unselected state
                )
                val colorStateListtext = ColorStateList(states, colorstext)
//                binding.navView.itemTextColor = colorStateListtext
            } else {
                val primaryColortext = Color.parseColor("#000000")
                val colorstext = intArrayOf(
                    primaryColortext, // Color for selected state
                    unselectedColor // Color for unselected state
                )
                val colorStateListtext = ColorStateList(states, colorstext)
//                binding.navView.itemTextColor = colorStateListtext
            }

//            val colorStateList = ColorStateList(states, colors)
//            binding.navView.itemIconTintList = colorStateList
//            binding.navView.itemRippleColor = ColorStateList.valueOf(primaryColor.addAlpha(0.08F))
//            binding.navView.itemActiveIndicatorColor =
//                ColorStateList.valueOf(primaryColor.addAlpha(0.12F))

        }


    }

    override fun onStart() {
        super.onStart()
        activityVisibleIntent.onNext(true)
    }

    override fun onPause() {
        super.onPause()
        activityVisibleIntent.onNext(false)
    }

    override fun render(state: ComposeState) {
        if (state.hasError) {
            Log.e("render", "ComposeActivity:render.hasError:${state.messages?.second}")
//            finish()
//            return
        }
        isPrivateMessage = state.messages?.first?.isPrivate ?: false
        isBlockedMessage = state.messages?.first?.blocked ?: false
        threadIdManual = state.threadId
        threadId.onNext(state.threadId)



        if (isBlockedMessage == true && tempBlock == false) {

            binding.mBlockView.visibility = View.VISIBLE

        } else if (isBlockedMessage == false) {
            binding.mBlockView.visibility = View.GONE
        }


        val titleTextValue = when {
            state.selectedMessages > 0 -> getString(
                R.string.compose_title_selected,
                state.selectedMessages
            )

            state.query.isNotEmpty() -> state.query
            else -> state.conversationtitle
        }

        binding.titleText.text = titleTextValue
        binding.toolbarTitle.text = titleTextValue

//        binding.llBottomAction.setVisible(state.selectedMessages > 0)
        binding.toolbarSubtitle.setVisible(state.query.isNotEmpty())
//        binding.attach.setVisible(!state.query.isNotEmpty() /*&& !binding.llBottomAction.isVisible*/)
        binding.toolbarSubtitle.text = getString(
            R.string.compose_subtitle_results, state.searchSelectionPosition,
            state.searchResults
        )

        binding.toolbarTitle.setVisible(!state.editingMode)

        binding.chips.setVisible(state.editingMode)
        //binding.composeBar.setVisible(!state.loading/*&& !binding.llBottomAction.isVisible*/)

        toolbar?.overflowIcon?.setColorFilter(
            ContextCompat.getColor(this, R.color.iconColor),
            PorterDuff.Mode.SRC_ATOP
        )
        // Don't set the adapters unless needed
        if (state.editingMode && binding.chips.adapter == null) binding.chips.adapter = chipsAdapter

        val menuItem = toolbar.menu.findItem(R.id.star)

        menuItem?.isVisible =
            !messageAdapter.isStarred && !state.editingMode && state.selectedMessages == 1

        toolbar.menu.findItem(R.id.un_star)?.isVisible =
            messageAdapter.isStarred && !state.editingMode && state.selectedMessages == 1

        binding.toolbar.menu.findItem(R.id.add)?.isVisible = state.editingMode
        binding.toolbar.menu.findItem(R.id.call)?.isVisible =
            !state.editingMode && state.selectedMessages == 0
                    && state.query.isEmpty()
        binding.toolbar.menu.findItem(R.id.info)?.isVisible =
            !state.editingMode && state.selectedMessages == 0 && state.query.isEmpty()

        binding.toolbar.menu.findItem(R.id.select)?.isVisible =
            !state.editingMode && state.selectedMessages > 0
//        binding.toolbar.menu.findItem(R.id.copy)?.isVisible = !state.editingMode && state.selectedMessages > 0
//        binding.toolbar.menu.findItem(R.id.details)?.isVisible = !state.editingMode && state.selectedMessages == 1
//        binding.toolbar.menu.findItem(R.id.delete)?.isVisible = !state.editingMode && state.selectedMessages > 0
//        binding.toolbar.menu.findItem(R.id.forward)?.isVisible = !state.editingMode && state.selectedMessages == 1

        binding.toolbar.menu.findItem(R.id.previous)?.isVisible =
            state.selectedMessages == 0 && state.query.isNotEmpty()
        binding.toolbar.menu.findItem(R.id.next)?.isVisible =
            state.selectedMessages == 0 && state.query.isNotEmpty()
        binding.toolbar.menu.findItem(R.id.clear)?.isVisible =
            state.selectedMessages == 0 && state.query.isNotEmpty()

        binding.llCopy.beVisibleIf(!state.editingMode && state.selectedMessages > 0)
        binding.llDetail.beVisibleIf(!state.editingMode && state.selectedMessages == 1)
        binding.llForward.beVisibleIf(!state.editingMode && state.selectedMessages == 1)
        binding.llDelete.beVisibleIf(!state.editingMode && state.selectedMessages > 0)
        binding.llShare.beVisibleIf(!state.editingMode && state.selectedMessages == 1)

        chipsAdapter.data = state.selectedChips

        binding.loading.setVisible(state.loading)

        binding.sendAsGroup.setVisible(state.editingMode && state.selectedChips.size >= 2)
        binding.sendAsGroupSwitch.isChecked = state.sendAsGroup

        // Temp Commit for Ads
//        binding.messageList.setVisible(!state.editingMode || state.sendAsGroup || state.selectedChips.size == 1)
        messageAdapter.data = state.messages

//        Log.e("FastScroller", "message_Count.002:${messageAdapter.itemCount}")
        if (messageAdapter.itemCount < 6) {
            binding.dragHandle.beGone()
        } else {
            binding.dragHandle.beVisible()
        }

        if (!dataSetDone1 && chipsAdapter.data.size > 0) {

            binding.messageList.scrollToPosition(messageAdapter.itemCount - 1)
            delayExecution(1000) {
                dataSetDone1 = true
            }
        } else {


            if (!dataSetDone) {

                binding.messageList.scrollToPosition(messageAdapter.itemCount - 1)

                delayExecution(1000) {
                    dataSetDone = true
                }
            } else {

                binding.messageList.scrollToPosition(messageAdapter.itemCount)
            }
        }

        messageAdapter.highlight = state.searchSelectionId

        binding.scheduledGroup.isVisible = state.scheduled != 0L
        binding.scheduledTime.text = dateFormatter.getScheduledTimestamp(state.scheduled)

        binding.attachments.setVisible(state.attachments.isNotEmpty())
        attachmentAdapter.data = state.attachments

        // binding.attach.animate().rotation(if (state.attaching) 135f else 0f).start()
        binding.attaching.isVisible = state.attaching

        messageAdapter.toggleItemVisibility(state.attaching)

        binding.counter.text = state.remaining
        binding.counter.setVisible(binding.counter.text.isNotBlank())

        binding.sim.setVisible(state.subscription != null)
        binding.sim.contentDescription =
            getString(R.string.compose_sim_cd, state.subscription?.displayName)
        binding.simIndex.text = state.subscription?.simSlotIndex?.plus(1)?.toString()

        binding.send.setTint(baseConfig.primaryColor)
        binding.send.isEnabled = state.canSend
        binding.send.imageAlpha = if (state.canSend) 255 else 128

        if (state.scrollToPosition!! > 0) {
            scrollToMessage(state.scrollToPosition)
        }

        binding.llBottomAction.setVisible(state.selectedMessages > 0)
        binding.composeBar.setVisible(state.selectedMessages == 0)
//        if (state.selectedMessages == 0) {
//            binding.llBottomAction.beVisible()
//            binding.composeBar.beGone()
////            binding.layoutInvalidShortCodeInfo.beGone()
////            state.messages?.first?.recipients?.forEach { it ->
////                val s = it.address
////                val ss = s.substring(0, 2)
////                if (isLetters(ss)) {
////                    binding.composeBar.visibility = View.INVISIBLE
////                    shortCodeReplyPreventView()
////                } else {
////                    binding.composeBar.setVisible(!state.loading)
////                    binding.layoutInvalidShortCodeInfo.beGone()
////                }
////            }
//        } else {
//            binding.llBottomAction.beVisible()
//            binding.composeBar.beGone()
////            binding.layoutInvalidShortCodeInfo.beGone()
//        }
    }

//    private fun shortCodeReplyPreventView() {
//        binding.composeBar.beGone()
//        binding.layoutInvalidShortCodeInfo.beVisible()
//        val bGotoWebsite: TextView = findViewById(R.id.tv_learn_more)
//        bGotoWebsite.setOnClickListener {
//            shortCodeReplyLearnMore()
//        }
//    }

    private fun shortCodeReplyLearnMore() {
        CommonDialog(this).show(
            this,
            resources.getString(R.string.cannot_reply_short_code_title),
            resources.getString(R.string.cannot_reply_short_code_message) + "\n\n" + resources.getString(
                R.string.cannot_reply_short_code_message1
            ),
            resources.getString(R.string.ok),
            "",
            "",
            onPositive = {

            },
            cancelable = false
        )
    }

    private fun isEdgeToEdgeEnabled(): Int {
        val resourceId: Int =
            resources.getIdentifier("config_navBarInteractionMode", "integer", "android")
        return if (resourceId > 0) {
            resources.getInteger(resourceId)
        } else 0
    }

    private fun isLetters(string: String): Boolean {
        return string.filter { it in 'A'..'Z' || it in 'a'..'z' }.length == string.length
    }

    override fun clearSelection() {
        messageAdapter.clearSelection()
    }

    override fun showDetails(details: String) {
        AlertDialog.Builder(this, R.style.CustomFieldDialogTheme)
            .setTitle(R.string.compose_details_title)
            .setMessage(details)
            .setCancelable(true)
            .show()
    }


    override fun showUnStarredSnackBar() {
        Snackbar.make(binding.contentView, getString(R.string.star_removed), Snackbar.LENGTH_LONG)
            .apply {
                setAction(getString(R.string.undo)) { starMessageSubject.onNext(messageAdapter.messageIdForUndoUnStar) }
                setActionTextColor(
                    ContextCompat.getColor(
                        this@ComposeActivity,
                        R.color.color_app_theme
                    )
                )
                show()
            }
    }

    override fun requestDefaultSms() {
        navigator.showDefaultSmsDialog(this)
    }

    override fun requestStoragePermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
            0
        )
    }

    override fun requestSmsPermission() {
        ActivityCompat.requestPermissions(
            this, arrayOf(
                Manifest.permission.READ_SMS,
                Manifest.permission.SEND_SMS
            ), 0
        )
    }

    private val scheduleExactAlarmLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (hasScheduleExactAlarmPermission(this)) {
            requestDatePicker()
        }
    }

    fun hasScheduleExactAlarmPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    fun requestScheduleExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.parse("package:$packageName")
            }
            scheduleExactAlarmLauncher.launch(intent)
        }
    }


    private fun alarmPermissionDialog() {
        val alarmPermissionBottomSheetDialog = AlarmPermissionBottomSheetDialog()
        alarmPermissionBottomSheetDialog.show(
            supportFragmentManager,
            alarmPermissionBottomSheetDialog.tag
        )

        alarmPermissionBottomSheetDialog.btnClickListener = { action ->
            if (action == 0) {
                isAdsNotShowOnResume = true
                requestScheduleExactAlarmPermission()
            }

        }

    }

    override fun requestDatePicker() {

        Log.e("requestDatePicker--------------", "requestDatePicker")
        if (!hasScheduleExactAlarmPermission(this)) {
            alarmPermissionDialog()
            return
        }


        val calendar = Calendar.getInstance()
        DatePickerDialog(
            this, R.style.Theme_MaterialComponents_Light_Dialog,
            DatePickerDialog.OnDateSetListener { _, year, month, day ->
                TimePickerDialog(
                    this, R.style.Theme_MaterialComponents_Light_Dialog,
                    TimePickerDialog.OnTimeSetListener { _, hour, minute ->
                        calendar.set(Calendar.YEAR, year)
                        calendar.set(Calendar.MONTH, month)
                        calendar.set(Calendar.DAY_OF_MONTH, day)
                        calendar.set(Calendar.HOUR_OF_DAY, hour)
                        calendar.set(Calendar.MINUTE, minute)
                        scheduleSelectedIntent.onNext(calendar.timeInMillis)
                    },
                    calendar.get(Calendar.HOUR_OF_DAY),
                    calendar.get(Calendar.MINUTE),
                    DateFormat.is24HourFormat(this)
                )
                    .show()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    override fun requestContact() {
        val intent = Intent(Intent.ACTION_PICK)
            .setType(ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE)

        startActivityForResult(Intent.createChooser(intent, null), AttachContactRequestCode)
    }

    override fun showContacts(sharing: Boolean, chips: List<Recipient>) {
        binding.message.hideKeyboard()
        val serialized =
            HashMap(chips.associate { chip -> chip.address to chip.contact?.lookupKey })
        val intent = Intent(this, ContactsActivity::class.java)
            .putExtra(ContactsActivity.SharingKey, sharing)
            .putExtra(ContactsActivity.ChipsKey, serialized)
        startActivityForResult(intent, SelectContactRequestCode)
    }

    override fun themeChanged() {
        binding.messageList.scrapViews()
    }

    override fun showDeleteDialog(messageIds: List<Long>, conversation: Conversation) {
        val count = messageIds.size
        val dialog = android.app.AlertDialog.Builder(this, R.style.CustomFieldDialogTheme)
            .setTitle(R.string.dialog_delete_title)
            .setMessage(resources.getQuantityString(R.plurals.dialog_delete_chat, count, count))
            .setPositiveButton(R.string.button_delete) { _, _ ->
                confirmDeleteIntent.onNext(DeleteMessages.Params(messageIds, conversation.id))
            }
            .setNegativeButton(R.string.button_cancel, null)
            .create()  // Use create() instead of show()

        dialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
        dialog.setOnShowListener {
            // Change the button text colors after the dialog is shown
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE)?.setTextColor(
                baseConfig.primaryColor
            )
            dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE)
                ?.setTextColor(resources.getColor(R.color.black))
        }

        dialog.show()

//        deleteMessages.execute(DeleteMessages.Params(messageIds, threadId))

    }

    override fun showKeyboard() {
        binding.message.postDelayed({
            binding.message.showKeyboard()
        }, 200)
    }

    override fun requestCamera() {
        cameraDestination = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            .let { timestamp ->
                ContentValues().apply {
                    put(
                        MediaStore.Images.Media.TITLE,
                        timestamp
                    )
                }
            }
            .let { cv -> contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) }

        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            .putExtra(MediaStore.EXTRA_OUTPUT, cameraDestination)
        startActivityForResult(Intent.createChooser(intent, null), TakePhotoRequestCode)
    }


    private var quickMessageCustomDialog: QuickMessageCustomDialog? = null

    override fun openQuickMessageActivity() {

        quickMessageCustomDialog = QuickMessageCustomDialog(
            this@ComposeActivity,
            onDialogShow = {

            },
            onDialogDismiss = {

            }
        )
        quickMessageCustomDialog?.show { selectedItem, position ->

            binding.message.setText(selectedItem)
            quickMessageCustomDialog!!.dismiss()

        }
    }

    override fun requestGallery() {
        val intent = Intent(Intent.ACTION_PICK)
            .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            .addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            .putExtra(Intent.EXTRA_LOCAL_ONLY, false)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .setType("image/*")
        startActivityForResult(Intent.createChooser(intent, null), AttachPhotoRequestCode)
    }

    override fun setDraft(draft: String) = binding.message.setText(draft)

    override fun scrollToMessage(id: Long) {
        messageAdapter.data?.second
            ?.indexOfLast { message -> message.id == id }
            ?.takeIf { position -> position != -1 }
            ?.let(binding.messageList::scrollToPosition)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.compose, menu)

        val menuItem = toolbar.menu.findItem(R.id.star)
        menuItem?.icon?.setTint(baseConfig.primaryColor)

        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressedCall()
            }

            R.id.select -> {
                messageAdapter.toggleSelectAll(true)
            }

            else -> optionsItemIntent.onNext(item.itemId)
        }
//        optionsItemIntent.onNext(item.itemId)
        return true
    }

    override fun getColoredMenuItems(): List<Int> {
        return super.getColoredMenuItems() + R.id.call
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when {
            /*requestCode == SelectContactRequestCode -> {
                chipsSelectedIntent.onNext(data?.getSerializableExtra(ContactsActivity.ChipsKey)
                    ?.let { serializable -> serializable as? HashMap<String, String?> }
                    ?: hashMapOf())

            }*/

            requestCode == SelectContactRequestCode -> {
                val selectedContacts = data?.getSerializableExtra(ContactsActivity.ChipsKey)
                    ?.let { serializable -> serializable as? HashMap<String, String?> }
                    ?: hashMapOf()

                if (selectedContacts.isNotEmpty()) {
                    chipsSelectedIntent.onNext(selectedContacts)

//                    Log.e("dsdsdsdsssd", " ---------------   1 + $fromScreen")


//                     fromScreen = intent.getStringExtra("from").toString()


                    if (fromScreen == "Schedule") {
                        requestDatePicker()
                        fromScreen = ""
                    }

                } else {
                    finish()
                }


            }


            requestCode == TakePhotoRequestCode && resultCode == Activity.RESULT_OK -> {
                cameraDestination?.let(attachmentSelectedIntent::onNext)
            }

            requestCode == AttachPhotoRequestCode && resultCode == Activity.RESULT_OK -> {
                data?.clipData?.itemCount
                    ?.let { count -> 0 until count }
                    ?.mapNotNull { i -> data.clipData?.getItemAt(i)?.uri }
                    ?.forEach(attachmentSelectedIntent::onNext)
                    ?: data?.data?.let(attachmentSelectedIntent::onNext)
//                Log.e("dsdsdsdsssd", " ---------------   3")
            }

            requestCode == AttachContactRequestCode && resultCode == Activity.RESULT_OK -> {
                data?.data?.let(contactSelectedIntent::onNext)

//                Log.e("dsdsdsdsssd", " ---------------   2")
            }


            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onResume() {
        super.onResume()

        // isAdsNotShowOnResume = false
        quickMessageCustomDialog?.updateList()


    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putParcelable(CameraDestinationKey, cameraDestination)
        super.onSaveInstanceState(outState)
    }

    override fun onRestoreInstanceState(
        savedInstanceState: Bundle?,
        persistentState: PersistableBundle?,
    ) {
        cameraDestination = savedInstanceState?.getParcelable(CameraDestinationKey)
        super.onRestoreInstanceState(savedInstanceState, persistentState)
    }

//    override fun onRestoreInstanceState(savedInstanceState: Bundle?) {
//        cameraDestination = savedInstanceState?.getParcelable(CameraDestinationKey)
//        super.onRestoreInstanceState(savedInstanceState)
//    }

    //    override fun onBackPressed() = backPressedIntent.onNext(Unit)

    fun onBackPressedCall() {
        binding.message.hideKeyboard()
        if (messageAdapter.selection.isNotEmpty()) {
            clearSelection()
        } else {
            if (clientConfigPref.enableBackPressInter) {
                Log.e("Message_Log", "enable_back_press_inter - showMainInterAds")
                MainInterAdManager.showMainInterAds(this) {

                    Log.e("Message_Log", "enable_back_press_inter - isHomeInterShow = true")
                    isHomeInterShow = true
                    finish()
                }
            } else {
                Log.e("Message_Log", "enable_back_press_inter - finish")
                finish()
            }
        }
    }

    override fun onDestroy() {
        try {
            currentFocus?.clearFocus()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onDestroy()
        binding.message.hideKeyboard()
        dataSetDone = false
        dataSetDone1 = false
        try {
            nativeAdChat?.destroy()
            nativeAdChat = null
        } catch (_: Exception) {
        }
    }

    /*  private fun loadNative() {
          delayExecution(300) {
              AdmobNative.preLoadChat(this, { isLoaded, nativeAd ->
                  messageAdapter.notifyItemInserted(messageAdapter.itemCount)
  //                binding.messageList.scrollToPosition(messageAdapter.itemCount)
              }, getAppChatScreenNative())
          }
      }

      private fun loadApplovinNative() {
          delayExecution(300) {
              AdmobNative.loadApplovinChatNative(this, getAppLovinChatScreen(), {
                  messageAdapter.notifyItemInserted(messageAdapter.itemCount)
  //                binding.messageList.scrollToPosition(messageAdapter.itemCount)
              })
          }
      }*/

    private fun loadNative() {
        delayExecution(100) {
            AdmobNative.preLoadChat(this, { isLoaded, nativeAd ->
                messageAdapter.notifyItemInserted(messageAdapter.itemCount)

                // Check if the last item is visible
                val layoutManager = binding.messageList.layoutManager as? LinearLayoutManager
                val lastVisibleItemPosition = layoutManager?.findLastVisibleItemPosition()

                if (lastVisibleItemPosition == messageAdapter.itemCount) { // -2 because itemCount is updated after notify
                    binding.messageList.scrollToPosition(messageAdapter.itemCount)
                }
            }, getAppChatScreenNative())
        }
    }

    /*   private fun loadApplovinNative() {
           delayExecution(100) {
               AdmobNative.loadApplovinChatNative(this, getAppLovinChatScreen(), {
                   messageAdapter.notifyItemInserted(messageAdapter.itemCount)

                   // Check if the last item is visible
                   val layoutManager = binding.messageList.layoutManager as? LinearLayoutManager
                   val lastVisibleItemPosition = layoutManager?.findLastVisibleItemPosition()

                   if (lastVisibleItemPosition == messageAdapter.itemCount) { // -2 because itemCount is updated after notify
                       binding.messageList.scrollToPosition(messageAdapter.itemCount)
                   }
               })
           }
       }*/


}
