package messages.text.sms.feature.compose

import android.net.Uri
import androidx.core.view.inputmethod.InputContentInfoCompat
import io.reactivex.Observable
import io.reactivex.subjects.Subject
import messages.text.sms.common.base.MainBaseMsgView
import messages.text.sms.interactor.DeleteMessages
import messages.text.sms.model.Attachment
import messages.text.sms.model.Conversation
import messages.text.sms.model.Recipient

interface ComposeView : MainBaseMsgView<ComposeState> {

    val activityVisibleIntent: Observable<Boolean>
    val chipsSelectedIntent: Subject<HashMap<String, String?>>
    val chipDeletedIntent: Subject<Recipient>
    val menuReadyIntent: Observable<Unit>
    val optionsItemIntent: Observable<Int>
    val removeStarMessageSubject: Observable<Long>
    val starMessageSubject: Observable<Long>
    val sendAsGroupIntent: Observable<*>
    val messageClickIntent: Subject<Long>
    val adapterItemDelete: Subject<Long>
    val messagePartClickIntent: Subject<Long>
    val messagesSelectedIntent: Observable<List<Long>>
    val cancelSendingIntent: Subject<Long>
    val attachmentDeletedIntent: Subject<Attachment>
    val textChangedIntent: Observable<CharSequence>
    val attachIntent: Observable<Unit>
    val cameraIntent: Observable<*>
    val quickIntent: Observable<*>
    val galleryIntent: Observable<*>
    val scheduleIntent: Observable<*>
    val attachContactIntent: Observable<*>
    val attachmentSelectedIntent: Observable<Uri>
    val contactSelectedIntent: Observable<Uri>
    val inputContentIntent: Observable<InputContentInfoCompat>
    val scheduleSelectedIntent: Observable<Long>
    val scheduleCancelIntent: Observable<*>
    val changeSimIntent: Observable<*>
    val sendIntent: Observable<Unit>
    val backPressedIntent: Observable<Unit>
    val confirmDeleteIntent: Observable<DeleteMessages.Params>

    fun clearSelection()
    fun showDetails(details: String)
    fun requestDefaultSms()
    fun requestStoragePermission()
    fun requestSmsPermission()
    fun showContacts(sharing: Boolean, chips: List<Recipient>)
    fun themeChanged()
    fun showDeleteDialog(messageIds: List<Long>, conversation: Conversation)
    fun showKeyboard()
    fun requestCamera()
    fun openQuickMessageActivity()
    fun addOrRemoveStarred(): Observable<Long>
    fun addStarred(): Observable<Long>
    fun showUnStarredSnackBar()
    fun requestGallery()
    fun requestDatePicker()
    fun requestContact()
    fun setDraft(draft: String)
    fun scrollToMessage(id: Long)
    fun showBlockingDialog(conversations: List<Long>, block: Boolean)

}