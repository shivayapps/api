package messages.text.sms.commons.extensions

import android.graphics.Bitmap
import android.os.StatFs
import android.telephony.PhoneNumberUtils
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import com.bumptech.glide.signature.ObjectKey
import messages.text.sms.commons.helpers.audioExtensions
import messages.text.sms.commons.helpers.extensionsSupportingEXIF
import messages.text.sms.commons.helpers.normalizeRegex
import messages.text.sms.commons.helpers.photoExtensions
import messages.text.sms.commons.helpers.rawExtensions
import messages.text.sms.commons.helpers.videoExtensions
import java.io.File
import java.text.Normalizer
import java.util.Locale.getDefault
import java.util.regex.Pattern

fun String.getFilenameFromPath() = substring(lastIndexOf("/") + 1)

fun String.getFilenameExtension() = substring(lastIndexOf(".") + 1)


fun String.isAValidFilename(): Boolean {
    val ILLEGAL_CHARACTERS =
        charArrayOf('/', '\n', '\r', '\t', '\u0000', '`', '?', '*', '\\', '<', '>', '|', '\"', ':')
    ILLEGAL_CHARACTERS.forEach {
        if (contains(it))
            return false
    }
    return true
}

fun String.isMediaFile() =
    isImageFast() || isVideoFast() || isGif() || isRawFast() || isSvg() || isPortrait()

fun String.isApng() = endsWith(".apng", true)

fun String.isWebP() = endsWith(".webp", true)

fun String.isGif() = endsWith(".gif", true)

fun String.isPng() = endsWith(".png", true)

fun String.isJpg() = endsWith(".jpg", true) or endsWith(".jpeg", true)

fun String.isSvg() = endsWith(".svg", true)

fun String.isPortrait() = getFilenameFromPath().contains(
    "portrait",
    true
) && File(this).parentFile?.name?.startsWith("img_", true) == true

// fast extension checks, not guaranteed to be accurate
fun String.isVideoFast() = videoExtensions.any { endsWith(it, true) }

fun String.isImageFast() = photoExtensions.any { endsWith(it, true) }
fun String.isAudioFast() = audioExtensions.any { endsWith(it, true) }
fun String.isRawFast() = rawExtensions.any { endsWith(it, true) }

fun String.canModifyEXIF() = extensionsSupportingEXIF.any { endsWith(it, true) }

fun String.getCompressionFormat(): Bitmap.CompressFormat {
    getFilenameExtension()
    return when (lowercase(getDefault())) {
        "png" -> Bitmap.CompressFormat.PNG
        "webp" -> Bitmap.CompressFormat.WEBP
        else -> Bitmap.CompressFormat.JPEG
    }
}

fun String.areDigitsOnly() = matches(Regex("[0-9]+"))

fun String.areLettersOnly() = matches(Regex("[a-zA-Z]+"))

fun String.getGenericMimeType(): String {
    if (!contains("/"))
        return this

    val type = substring(0, indexOf("/"))
    return "$type/*"
}

fun String.getParentPath() = removeSuffix("/${getFilenameFromPath()}")

fun String.relativizeWith(path: String) = this.substring(path.length)


fun String.substringTo(cnt: Int): String {
    return if (isEmpty()) {
        ""
    } else {
        substring(0, Math.min(length, cnt))
    }
}

fun String.highlightTextPart(
    textToHighlight: String,
    color: Int,
    highlightAll: Boolean = false,
    ignoreCharsBetweenDigits: Boolean = false,
): SpannableString {
    val spannableString = SpannableString(this)
    if (textToHighlight.isEmpty()) {
        return spannableString
    }

    var startIndex = normalizeString().indexOf(textToHighlight, 0, true)
    val indexes = ArrayList<Int>()
    while (startIndex >= 0) {
        if (startIndex != -1) {
            indexes.add(startIndex)
        }

        startIndex =
            normalizeString().indexOf(textToHighlight, startIndex + textToHighlight.length, true)
        if (!highlightAll) {
            break
        }
    }

    // handle cases when we search for 643, but in reality the string contains it like 6-43
    if (ignoreCharsBetweenDigits && indexes.isEmpty()) {
        try {
            val regex = TextUtils.join("(\\D*)", textToHighlight.toCharArray().toTypedArray())
            val pattern = Pattern.compile(regex)
            val result = pattern.matcher(normalizeString())
            if (result.find()) {
                spannableString.setSpan(
                    ForegroundColorSpan(color),
                    result.start(),
                    result.end(),
                    Spannable.SPAN_EXCLUSIVE_INCLUSIVE
                )
            }
        } catch (ignored: Exception) {
        }

        return spannableString
    }

    indexes.forEach {
        val endIndex = Math.min(it + textToHighlight.length, length)
        try {
            spannableString.setSpan(
                ForegroundColorSpan(color),
                it,
                endIndex,
                Spannable.SPAN_EXCLUSIVE_INCLUSIVE
            )
        } catch (ignored: IndexOutOfBoundsException) {
        }
    }

    return spannableString
}

fun String.searchMatches(textToHighlight: String): ArrayList<Int> {
    val indexes = arrayListOf<Int>()
    var indexOf = indexOf(textToHighlight, 0, true)

    var offset = 0
    while (offset < length && indexOf != -1) {
        indexOf = indexOf(textToHighlight, offset, true)

        if (indexOf == -1) {
            break
        } else {
            indexes.add(indexOf)
        }

        offset = indexOf + 1
    }

    return indexes
}

fun String.getFileSignature(lastModified: Long? = null) = ObjectKey(getFileKey(lastModified))

fun String.getFileKey(lastModified: Long? = null): String {
    val file = File(this)
    val modified = if (lastModified != null && lastModified > 0) {
        lastModified
    } else {
        file.lastModified()
    }

    return "${file.absolutePath}$modified"
}

fun String.getAvailableStorageB(): Long {
    return try {
        val stat = StatFs(this)
        val bytesAvailable = stat.blockSizeLong * stat.availableBlocksLong
        bytesAvailable
    } catch (e: Exception) {
        -1L
    }
}

// remove diacritics, for example č -> c
fun String.normalizeString() =
    Normalizer.normalize(this, Normalizer.Form.NFD).replace(normalizeRegex, "")

// checks if string is a phone number
fun String.isPhoneNumber(): Boolean {
    return this.matches("^[0-9+\\-\\)\\( *#]+\$".toRegex())
}

fun String.isValidPhoneNumber(): Boolean {
    return android.util.Patterns.PHONE.matcher(this).matches()
//    return this.matches("^[0-9+\\-\\)\\( *#]+\$".toRegex())
}

// if we are comparing phone numbers, compare just the last 9 digits
fun String.trimToComparableNumber(): String {
    // don't trim if it's not a phone number
    if (!this.isPhoneNumber()) {
        return this
    }
    val normalizedNumber = this.normalizeString()
    val startIndex = Math.max(0, normalizedNumber.length - 9)
    return normalizedNumber.substring(startIndex)
}

// get the contact names first letter at showing the placeholder without image
fun String.getNameLetter() =
    normalizeString().toCharArray().getOrNull(0)?.toString()?.let { uppercase(getDefault()) }
        ?: "A"

fun String.normalizePhoneNumber() = PhoneNumberUtils.normalizeNumber(this)

fun String.highlightTextFromNumbers(textToHighlight: String, primaryColor: Int): SpannableString {
    val spannableString = SpannableString(this)
    val digits = PhoneNumberUtils.convertKeypadLettersToDigits(this)
    if (digits.contains(textToHighlight)) {
        val startIndex = digits.indexOf(textToHighlight, 0, true)
        val endIndex = Math.min(startIndex + textToHighlight.length, length)
        try {
            spannableString.setSpan(
                ForegroundColorSpan(primaryColor),
                startIndex,
                endIndex,
                Spannable.SPAN_EXCLUSIVE_INCLUSIVE
            )
        } catch (ignored: IndexOutOfBoundsException) {
        }
    }

    return spannableString
}


