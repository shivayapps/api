package messages.text.sms.common.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.Settings
import android.text.SpannableString
import android.text.Spanned
import android.text.style.TypefaceSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.RelativeLayout
import android.widget.RemoteViews
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.app.RemoteInput
import androidx.core.app.TaskStackBuilder
import androidx.core.content.getSystemService
import androidx.core.content.res.getColorOrThrow
import androidx.core.graphics.drawable.IconCompat
import com.bumptech.glide.Glide
import messages.text.sms.R
import messages.text.sms.common.util.extensions.dpToPx
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.config
import messages.text.sms.commons.helpers.ReConstant
import messages.text.sms.extensions.applyColorFilter
import messages.text.sms.extensions.isImage
import messages.text.sms.feature.compose.ComposeActivity
import messages.text.sms.feature.qkreply.MainBaseReplyActivity
import messages.text.sms.manager.PermissionManager
import messages.text.sms.mapper.CursorToPartImpl
import messages.text.sms.receiver.BlockThreadReceiver
import messages.text.sms.receiver.CopyOtpReceiver
import messages.text.sms.receiver.DeleteMessagesReceiver
import messages.text.sms.receiver.DismissReceiver
import messages.text.sms.receiver.MarkArchivedReceiver
import messages.text.sms.receiver.MarkReadReceiver
import messages.text.sms.receiver.MarkSeenReceiver
import messages.text.sms.receiver.RemoteMessagingReceiver
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.repository.MessageRepository
import messages.text.sms.util.NotificationOverlay
import messages.text.sms.util.PhoneNumberUtils
import messages.text.sms.util.Preferences
import messages.text.sms.util.tryOrNull
import timber.log.Timber
import java.util.regex.Pattern
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class NotificationManagerImpl @Inject constructor(
    private val context: Context,
    private val colors: Colors,
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val messageRepo: MessageRepository,
    private val permissions: PermissionManager,
    private val phoneNumberUtils: PhoneNumberUtils,
) : messages.text.sms.manager.NotificationManager {

    companion object {
        const val DEFAULT_CHANNEL_ID = "notifications_default"
        const val SILENT_CHANNEL_ID = "SILENT_CHANNEL_ID"
        const val BACKUP_RESTORE_CHANNEL_ID = "notifications_backup_restore"
        val VIBRATE_PATTERN = longArrayOf(0, 200, 0, 200)
    }

    var thisIsPrivate = false
    var thisIsBlocked = false
    var personBitmap: Bitmap? = null
    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val randomColors: List<Int> = context.resources.obtainTypedArray(R.array.random_colors)
        .let { typedArray -> (0 until typedArray.length()).map(typedArray::getColorOrThrow) }

    init {

        // Make sure the default channel has been initialized
        createNotificationChannel()

    }

    /**
     * Updates the notification for a particular conversation
     */
    override fun update(threadId: Long) {
        // If notifications are disabled, don't do anything


        //Log.e("SmsReceiver--------------", "NotificationManagerImpl - update")

        if (!prefs.notifications(threadId).get()) {
            return
        }

        if (!permissions.hasNotifications()) {
            Timber.w("Cannot update notification because we don't have the notification permission")
            return
        }


        //Log.e("SmsReceiver--------------", "  - update 1 ")

        val messages = messageRepo.getUnreadUnseenMessages(threadId)

        // If there are no messages to be displayed, make sure that the notification is dismissed
        if (messages.isEmpty()) {
            notificationManager.cancel(threadId.toInt())
            notificationManager.cancel(threadId.toInt() + 100000)
            return
        }
        //Log.e("SmsReceiver--------------", "NotificationManagerImpl - $messages ")

        val conversation = conversationRepo.getConversation(threadId) ?: return
        val lastRecipient = conversation.lastMessage?.let { lastMessage ->
            conversation.recipients.find { recipient ->
                phoneNumberUtils.compare(recipient.address, lastMessage.address)
            }
        } ?: conversation.recipients.firstOrNull()

        val contentIntent =
            Intent(context, ComposeActivity::class.java).putExtra("threadId", threadId)
        val taskStackBuilder = TaskStackBuilder.create(context)
            .addParentStack(ComposeActivity::class.java)
            .addNextIntent(contentIntent)
        val contentPI = taskStackBuilder.getPendingIntent(
            threadId.toInt(),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val seenIntent =
            Intent(context, MarkSeenReceiver::class.java).putExtra("threadId", threadId)
        val seenPI = PendingIntent.getBroadcast(
            context, threadId.toInt(), seenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val resultOtp =
            Pattern.compile(ReConstant.otp_regex.toString())
                .matcher(conversation.lastMessage?.body!!.replace("\n", " ").trim()).find()

        //Log.e("SmsReceiver--------------", "NotificationManagerImpl - 111111111 ")

        val notification =
            if (resultOtp && Settings.canDrawOverlays(context) && context.config.enableOtpView) {
            notificationManager.createNotificationChannel(NotificationChannel(SILENT_CHANNEL_ID, "OTP", NotificationManager.IMPORTANCE_LOW).apply {
                enableLights(false)
                enableVibration(false)
            })
            NotificationCompat.Builder(context, SILENT_CHANNEL_ID)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setSmallIcon(R.drawable.ic_message_notification)
                .setNumber(messages.size)
                .setAutoCancel(true)
                .setContentIntent(contentPI)
                .setDeleteIntent(seenPI)
                .setSound(null)
                .setWhen(conversation.lastMessage?.date ?: System.currentTimeMillis())
                .setVibrate(null)
        } else
            NotificationCompat.Builder(context, getChannelIdForNotification(threadId))
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setSmallIcon(R.drawable.ic_message_notification)
                .setNumber(messages.size)
                .setAutoCancel(true)
                .setContentIntent(contentPI)
                .setDeleteIntent(seenPI)
                .setSound(Uri.parse(context.baseConfig.ringtoneUri))
                .setLights(Color.WHITE, 500, 2000)
                .setWhen(conversation.lastMessage?.date ?: System.currentTimeMillis())
                .setVibrate(
                    if (prefs.vibration(threadId).get()) VIBRATE_PATTERN else longArrayOf(0)
                )

        // Tell the notification if it's a group message
        val messagingStyle = NotificationCompat.MessagingStyle("Me")
        if (conversation.recipients.size >= 2) {
            messagingStyle.isGroupConversation = true
            messagingStyle.conversationTitle = conversation.getTitle()
        }

        //Log.e("SmsReceiver--------------", "NotificationManagerImpl - 222222222 ")
        // Add the messages to the notification
        messages.forEach { message ->
            val person = Person.Builder()

            if (!message.isMe()) {
                val recipient = conversation.recipients.find { recipient ->
                    phoneNumberUtils.compare(recipient.address, message.address)
                }

                person.setName(recipient?.getDisplayName() ?: message.address)
                person.setIcon(
                    Glide.with(context)
                        .asBitmap()
                        .circleCrop()
                        .load(recipient?.contact?.photoUri)
                        .submit(64.dpToPx(context), 64.dpToPx(context))
                        .let { futureGet -> tryOrNull(false) { futureGet.get() } }
                        ?.let {
                            //Log.e("SmsReceiver--------------", "update: personBitmap  createWithBitmap $it")
                            IconCompat.createWithBitmap(it)
                        })

                recipient?.contact
                    ?.let { contact -> "${ContactsContract.Contacts.CONTENT_LOOKUP_URI}/${contact.lookupKey}" }
                    ?.let(person::setUri)
            }

            NotificationCompat.MessagingStyle.Message(
                message.getSummary(),
                message.date,
                person.build()
            ).apply {
                message.parts.firstOrNull { it.isImage() }?.let { part ->
                    setData(
                        part.type,
                        ContentUris.withAppendedId(CursorToPartImpl.CONTENT_URI, part.id)
                    )
                }
                messagingStyle.addMessage(this)
            }
        }

        //Log.e("SmsReceiver--------------", "NotificationManagerImpl - 333333333333 ")
        // Set the large icon
        val avatar = conversation.recipients.takeIf { it.size == 1 }
            ?.first()?.contact?.photoUri
            ?.let { photoUri ->
                Glide.with(context)
                    .asBitmap()
                    .circleCrop()
                    .load(photoUri)
                    .submit(64.dpToPx(context), 64.dpToPx(context))
            }
            ?.let { futureGet -> tryOrNull(false) { futureGet.get() } }
        personBitmap = avatar

//        Log.e("NotificationPrefs", "resultOtp:$resultOtp $avatar")
        // Convert the comma-separated list to a List
        val privateContacts = context.baseConfig.privateContactsList.split(",").toList()


        // Check if the conversation title is in the privateContacts list
        if (conversation.getTitle() in privateContacts) {

            val customMessageForPrivate = context.baseConfig.customMessageForPrivate
            val quantityString = context.resources.getQuantityString(
                R.plurals.notification_new_messages,
                messages.size,
                customMessageForPrivate,
                messages.size
            )
            notification
                .setContentTitle(context.getString(R.string.app_name))
                .setContentText(quantityString)
            thisIsPrivate = true

            //Log.e("SmsReceiver--------------", "NotificationManagerImpl - 44444444444444 ")
        } else {


            /*  val blockedKeywordList = ArrayList(context.config.keywordList)
              val blockedNumberList = context.baseConfig.blockContactsList
                  .split(",")
                  .map { it.trim() }
                  .filter { it.isNotEmpty() }

              val isBlocked = blockedKeywordList.any { keyword -> message.body.contains(keyword.keyword, ignoreCase = true) } ||
                      blockedNumberList.any { number -> message.address.contains(number, ignoreCase = true) }


              Log.e("BNBNBN","isBlocked - " + isBlocked)
              if (isBlocked) {

                  Log.e("BNBNBN","threadId - " + listOf(message.threadId))

              }*/
            if (Settings.canDrawOverlays(context) && context.config.enableOtpView) {
                try {
                    val msg = conversation.lastMessage?.body
                    if (resultOtp) {
                        val otp = ReConstant.parseCode(msg ?: "")
                        //Log.e("SmsReceiver--------------", "NotificationManagerImpl - 88888 $otp ")
                        if (otp.isNotEmpty()) {
                            val title = conversation.getTitle()
                            val recipients = conversation.recipients.map { it }.toMutableList()
                            val otpCode = ReConstant.parseCode(msg ?: "")
                            val notificationOverlay = NotificationOverlay.getInstance(context)
                            notificationOverlay.showOverlay(
                                context = context,
                                threadId = threadId,
                                title = title,
                                recipients = recipients,
                                otp = otpCode
                            )
                        }
                    }
                } catch (e: Exception) {
                }
            }
            thisIsPrivate = false
            when (prefs.notificationPreviews(threadId).get()) {
                Preferences.NOTIFICATION_PREVIEWS_ALL -> {
                    notification
                        .setLargeIcon(avatar)
                        .setStyle(messagingStyle)
                }

                Preferences.NOTIFICATION_PREVIEWS_NAME -> {
                    notification
                        .setLargeIcon(avatar)
                        .setContentTitle(conversation.getTitle())
                        .setContentText(
                            context.resources.getQuantityString(
                                R.plurals.notification_new_messages,
                                messages.size,
                                messages.size
                            )
                        )
                }

                Preferences.NOTIFICATION_PREVIEWS_NONE -> {

                    val customMessageForPrivate = context.baseConfig.customMessageForPrivate
                    val quantityString = context.resources.getQuantityString(
                        R.plurals.notification_new_messages,
                        messages.size,
                        customMessageForPrivate,
                        messages.size
                    )
                    notification
                        .setContentTitle(context.getString(R.string.app_name))
                        .setContentText(quantityString)
                }
            }
        }

        // Add all of the people from this conversation to the notification, so that the system can
        // appropriately bypass DND mode
        conversation.recipients.forEach { recipient ->
            notification.addPerson("tel:${recipient.address}")
        }

        // Add the action buttons
        val actionLabels =
            context.resources.getStringArray(R.array.notification_actions)

        //Log.e("SmsReceiver--------------", "NotificationManagerImpl - 5555555555555 ")
//        val conversation=conversationRepo.getConversation(threadId)


        val actionList = if (resultOtp) listOf(prefs.notifyActionOtp, prefs.notifyAction1) else listOf(prefs.notifyAction1, prefs.notifyAction2, prefs.notifyAction3)
//        val actionList = listOf(prefs.notifyAction1, prefs.notifyAction2, prefs.notifyAction3)

        actionList.map { preference -> preference.get() }
            .distinct()
            .mapNotNull { action ->

                Log.e(
                    "SmsReceiver--------------",
                    "NotificationManagerImpl - 5555555555555 " + action
                )
                when (action) {
                    Preferences.NOTIFICATION_ACTION_ARCHIVE -> {
                        val intent = Intent(context, MarkArchivedReceiver::class.java).putExtra(
                            "threadId",
                            threadId
                        )
                        /*    val pi = PendingIntent.getBroadcast(
                                context, threadId.toInt(), intent,
                                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                            )*/
                        val pi = PendingIntent.getBroadcast(
                            context,
                            (threadId + 9999).toInt(),       // UNIQUE REQUEST CODE
                            intent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )


                        NotificationCompat.Action.Builder(
                            R.drawable.ic_archive_white_24dp,
                            actionLabels[action],
                            pi
                        )
                            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_ARCHIVE)
                            .build()
                    }

                    Preferences.NOTIFICATION_ACTION_DELETE -> {
                        val messageIds = messages.map { it.id }.toLongArray()
                        val intent = Intent(context, DeleteMessagesReceiver::class.java)
                            .putExtra("threadId", threadId)
                            .putExtra("messageIds", messageIds)
                        val pi = PendingIntent.getBroadcast(
                            context, threadId.toInt(), intent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        NotificationCompat.Action.Builder(
                            R.drawable.ic_delete_white_24dp,
                            actionLabels[action],
                            pi
                        )
                            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_DELETE)
                            .build()
                    }

                    Preferences.NOTIFICATION_ACTION_BLOCK -> {
                        val intent = Intent(context, BlockThreadReceiver::class.java).putExtra(
                            "threadId",
                            threadId
                        )
                        val pi = PendingIntent.getBroadcast(
                            context, threadId.toInt(), intent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        NotificationCompat.Action.Builder(
                            R.drawable.ic_block_white_24dp,
                            actionLabels[action],
                            pi
                        )
                            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_MUTE)
                            .build()
                    }

                    Preferences.NOTIFICATION_ACTION_READ -> {
                        val intent = Intent(context, MarkReadReceiver::class.java).putExtra(
                            "threadId",
                            threadId
                        )
                        val pi = PendingIntent.getBroadcast(
                            context, threadId.toInt(), intent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        NotificationCompat.Action.Builder(
                            R.drawable.ic_check_white_24dp,
                            actionLabels[action],
                            pi
                        )
                            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_MARK_AS_READ)
                            .build()
                    }

                    Preferences.NOTIFICATION_ACTION_REPLY -> {
                        if (Build.VERSION.SDK_INT >= 24) {
                            getReplyAction(threadId)
                        } else {
                            val intent =
                                Intent(context, MainBaseReplyActivity::class.java).putExtra(
                                "threadId",
                                threadId
                            )
                            val pi = PendingIntent.getActivity(
                                context, threadId.toInt(), intent,
                                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                            )
                            NotificationCompat.Action
                                .Builder(
                                    R.drawable.ic_reply_white_24dp,
                                    actionLabels[action],
                                    pi
                                )
                                .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
                                .build()
                        }
                    }

                    Preferences.NOTIFICATION_ACTION_CALL -> {
                        val address = conversation.recipients[0]?.address
                        val intentAction =
                            if (permissions.hasCalling()) Intent.ACTION_CALL else Intent.ACTION_DIAL
                        val intent = Intent(intentAction, Uri.parse("tel:$address"))
                        val pi = PendingIntent.getActivity(
                            context, threadId.toInt(), intent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        NotificationCompat.Action.Builder(
                            R.drawable.ic_call_white_24dp,
                            actionLabels[action],
                            pi
                        )
                            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_CALL)
                            .build()
                    }

                    Preferences.NOTIFICATION_ACTION_OTP -> {
                        val otpCode = ReConstant.parseCode(conversation.lastMessage?.body!!.replace("\n", " ").trim())
                        Log.e(
                            "SmsReceiver--------------",
                            "NotificationManagerImpl - NOTIFICATION_ACTION_OTP  $otpCode"
                        )
                        if (otpCode.isNotEmpty()) {
                            //Log.e("SmsReceiver--------------", "update: personBitmap $personBitmap")
                            val intent = Intent(context, CopyOtpReceiver::class.java).putExtra(
                                "threadId",
                                threadId
                            ).putExtra(
                                "otpCode",
                                otpCode.toString()
                            ).putExtra(
                                "conversationid",
                                conversation.id
                            )
                            val pi = PendingIntent.getBroadcast(
                                context, threadId.toInt(), intent,
                                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                            )
                            val spannableCopy = SpannableString("Copy")
                            spannableCopy.setSpan(TypefaceSpan("sans-serif-bold"), 0, spannableCopy.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)

                            val spannable = SpannableString(otpCode)
                            spannable.setSpan(TypefaceSpan("sans-serif-bold"), 0, spannable.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)

                            val spannableName = SpannableString("OTP · " + conversation.getTitle())
                            spannableName.setSpan(TypefaceSpan("sans-serif-bold"), 0, spannableName.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)

                            val remoteViews = RemoteViews(context.packageName, R.layout.custom_otp_notification)
                            remoteViews.setTextViewText(R.id.tvOtp, spannable)
                            remoteViews.setTextViewText(R.id.tvCopy, spannableCopy)
                            remoteViews.setOnClickPendingIntent(R.id.llCopy, pi)
                            remoteViews.setTextViewText(R.id.tvOtp, otpCode)
                            remoteViews.setTextViewText(R.id.tvName, spannableName)
                            notification.setCustomContentView(remoteViews)
                            notification.setCustomHeadsUpContentView(remoteViews)
                            val remoteViewsBig = RemoteViews(context.packageName, R.layout.custom_otp_notification_big)
                            try {
                                val personBitmap = createBitmapFromLayout(context, conversation.getTitle(), colors.generateColor(conversation.recipients.first()!!))
                                remoteViews.setImageViewBitmap(R.id.viewIcon, personBitmap)
                                remoteViewsBig.setImageViewBitmap(R.id.viewIcon, personBitmap)
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }

                            remoteViewsBig.setTextViewText(R.id.tvOtp, spannable)
                            remoteViews.setTextViewText(R.id.tvCopy, spannableCopy)
                            remoteViewsBig.setOnClickPendingIntent(R.id.llCopy, pi)
                            remoteViewsBig.setTextViewText(R.id.tvOtp, otpCode)
                            remoteViewsBig.setTextViewText(R.id.tvName, spannableName)


                            val intentRead = Intent(context, MarkReadReceiver::class.java).putExtra(
                                "threadId",
                                threadId
                            )
                            val piRead = PendingIntent.getBroadcast(
                                context, threadId.toInt(), intentRead,
                                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                            )
                            remoteViewsBig.setOnClickPendingIntent(R.id.tvMarkAsRead, piRead)

                            val intentDismiss = Intent(context, DismissReceiver::class.java).putExtra(
                                "threadId",
                                threadId
                            )
                            val piDismiss = PendingIntent.getBroadcast(
                                context, threadId.toInt(), intentDismiss,
                                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                            )
                            remoteViewsBig.setOnClickPendingIntent(R.id.tvDismiss, piDismiss)

                            notification.setCustomBigContentView(remoteViewsBig)
                            notification.setContentTitle(spannable)
                            spannableName.setSpan(
                                TypefaceSpan("sans-serif-medium"),
                                0,
                                spannableName.length,
                                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                            )
                            notification.setContentText(spannableName)
                            notification.setStyle(NotificationCompat.DecoratedCustomViewStyle())
                            /* NotificationCompat.Action.Builder(
                                 R.drawable.ic_check_white_24dp,
                                 actionLabels[action],
                                 pi
                             ).setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_MARK_AS_READ)
                                 .build()*/
                            null

                        } else null

                    }

                    else -> null
                }
            }
            .forEach { notification.addAction(it) }


        //Log.e("SmsReceiver--------------", "NotificationManagerImpl - 666666666666666 ")
        if (prefs.qkReply.get()) {
            notification.priority = NotificationCompat.PRIORITY_DEFAULT

            val intent = Intent(context, MainBaseReplyActivity::class.java)
                .putExtra("threadId", threadId)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

            context.startActivity(intent)
        }


        Log.e(
            "SmsReceiver--------------",
            "NotificationManagerImpl - thisIsPrivate - $thisIsPrivate "
        )
        if (thisIsPrivate) {

            Log.e(
                "SmsReceiver--------------",
                "NotificationManagerImpl - privateNotification - ${context.baseConfig.privateNotification}"
            )
            if (context.baseConfig.privateNotification) {

                notificationManager.notify(threadId.toInt(), notification.build())
            }
        } else {

            notificationManager.notify(threadId.toInt(), notification.build())
        }

        // Wake screen
        if (prefs.wakeScreen(threadId).get()) {
            context.getSystemService<PowerManager>()?.let { powerManager ->
                if (!powerManager.isInteractive) {
                    val flags =
                        PowerManager.SCREEN_DIM_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP
                    val wakeLock = powerManager.newWakeLock(flags, context.packageName)
                    wakeLock.acquire(5000)
                }
            }
        }
    }

    override fun notifyFailed(msgId: Long, resultCode: Int) {
        val message = messageRepo.getMessage(msgId)

        Log.e(
            "SmsReceiver--------------",
            "NotificationManagerImpl - 7777777777777777777 notifyFailed"
        )
        if (message == null || !message.isFailedMessage()) {
            return
        }

        val conversation = conversationRepo.getConversation(message.threadId) ?: return
        val lastRecipient = conversation.lastMessage?.let { lastMessage ->
            conversation.recipients.find { recipient ->
                phoneNumberUtils.compare(recipient.address, lastMessage.address)
            }
        } ?: conversation.recipients.firstOrNull()

        val threadId = conversation.id

        val contentIntent =
            Intent(context, ComposeActivity::class.java).putExtra("threadId", threadId)
        val taskStackBuilder = TaskStackBuilder.create(context)
        taskStackBuilder.addParentStack(ComposeActivity::class.java)
        taskStackBuilder.addNextIntent(contentIntent)


        val contentPI = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            taskStackBuilder.getPendingIntent(threadId.toInt() + 40000, PendingIntent.FLAG_MUTABLE)
        } else {
            taskStackBuilder.getPendingIntent(
                threadId.toInt() + 40000,
                PendingIntent.FLAG_UPDATE_CURRENT
            )
        }
//        Log.e("@@@@####", "setSound 3---> " + Uri.parse(context.baseConfig.ringtoneUri))
        val notification =
            NotificationCompat.Builder(context, getChannelIdForNotification(threadId))
                .setContentTitle(context.getString(R.string.notification_message_failed_title))
                .setContentText(
                    context.getString(
                        R.string.notification_message_failed_text,
                        conversation.getTitle()
                    )
                )
                .setPriority(NotificationManagerCompat.IMPORTANCE_MAX)
                .setSmallIcon(R.drawable.ic_notification_failed)
                .setAutoCancel(true)
                .setContentIntent(contentPI)
//                .setSound(Uri.parse(prefs.ringtone(threadId).get()))
                .setSound(Uri.parse(context.baseConfig.ringtoneUri))
                .setLights(Color.WHITE, 500, 2000)
                .setVibrate(
                    if (prefs.vibration(threadId).get()) VIBRATE_PATTERN else longArrayOf(0)
                )

        notificationManager.notify(threadId.toInt() + 50000, notification.build())
    }

//    override fun notifyFailed(msgId: Long) {
//        val message = messageRepo.getMessage(msgId)
//
//        if (message == null || !message.isFailedMessage()) {
//            return
//        }
//
//        val conversation = conversationRepo.getConversation(message.threadId) ?: return
//        val lastRecipient = conversation.lastMessage?.let { lastMessage ->
//            conversation.recipients.find { recipient ->
//                phoneNumberUtils.compare(recipient.address, lastMessage.address)
//            }
//        } ?: conversation.recipients.firstOrNull()
//
//        val threadId = conversation.id
//
//        val contentIntent = Intent(context, ComposeActivity::class.java).putExtra("threadId", threadId)
//        val taskStackBuilder = TaskStackBuilder.create(context)
//            .addParentStack(ComposeActivity::class.java)
//            .addNextIntent(contentIntent)
//        val contentPI = taskStackBuilder.getPendingIntent(threadId.toInt(), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
//
//        val notification = NotificationCompat.Builder(context, getChannelIdForNotification(threadId))
//            .setContentTitle(context.getString(R.string.notification_message_failed_title))
//            .setContentText(context.getString(R.string.notification_message_failed_text, conversation.getTitle()))
//            .setPriority(NotificationManagerCompat.IMPORTANCE_MAX)
//            .setSmallIcon(R.drawable.ic_notification_failed)
//            .setAutoCancel(true)
//            .setContentIntent(contentPI)
//            .setSound(Uri.parse(prefs.ringtone(threadId).get()))
//            .setLights(Color.WHITE, 500, 2000)
//            .setVibrate(if (prefs.vibration(threadId).get()) VIBRATE_PATTERN else longArrayOf(0))
//
//        notificationManager.notify(threadId.toInt() + 100000, notification.build())
//    }

    private fun getReplyAction(threadId: Long): NotificationCompat.Action {
        val replyIntent =
            Intent(context, RemoteMessagingReceiver::class.java).putExtra("threadId", threadId)
        val replyPI = PendingIntent.getBroadcast(
            context, threadId.toInt(), replyIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )

        val title =
            context.resources.getStringArray(R.array.notification_actions)[
                Preferences.NOTIFICATION_ACTION_REPLY]
        val responseSet =
            context.resources.getStringArray(R.array.qk_responses)
        val remoteInput = RemoteInput.Builder("body")
            .setLabel(title)

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            remoteInput.setChoices(responseSet)
        }

        return NotificationCompat.Action.Builder(
            R.drawable.ic_reply_white_24dp,
            title,
            replyPI
        )
            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
            .addRemoteInput(remoteInput.build())
            .build()
    }

    /**
     * Creates a notification channel for the given conversation
     */
    override fun createNotificationChannel(threadId: Long) {

        // Only proceed if the android version supports notification channels, and the channel hasn't
        // already been created
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || getNotificationChannel(threadId) != null) {
            return
        }

        val channel = when (threadId) {
            0L -> NotificationChannel(
                DEFAULT_CHANNEL_ID,
                "Default",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                enableLights(true)
                lightColor = Color.WHITE
                enableVibration(true)
                vibrationPattern = VIBRATE_PATTERN
            }

            else -> {


//                Log.e("@@@@####", "setSound 4---> " + prefs.ringtone().get().let(Uri::parse))
                val conversation = conversationRepo.getConversation(threadId) ?: return
                val channelId = buildNotificationChannelId(threadId)
                val title = conversation.getTitle()
                NotificationChannel(channelId, title, NotificationManager.IMPORTANCE_HIGH).apply {
                    enableLights(true)
                    lightColor = Color.WHITE
                    enableVibration(true)
                    vibrationPattern = VIBRATE_PATTERN
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    setSound(
                        prefs.ringtone().get().let(Uri::parse), AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )

                }
            }
        }

        notificationManager.createNotificationChannel(channel)

    }

    /**
     * Returns the notification channel for the given conversation, or null if it doesn't exist
     */
    private fun getNotificationChannel(threadId: Long): NotificationChannel? {
        val channelId = buildNotificationChannelId(threadId)
        return notificationManager.notificationChannels
            .find { channel -> channel.id == channelId }
    }

    /**
     * Returns the channel id that should be used for a notification based on the threadId
     *
     * If a notification channel for the conversation exists, use the id for that. Otherwise return
     * the default channel id
     */
    private fun getChannelIdForNotification(threadId: Long): String {
        return getNotificationChannel(threadId)?.id ?: DEFAULT_CHANNEL_ID

    }

    /**
     * Formats a notification channel id for a given thread id, whether the channel exists or not
     */
    override fun buildNotificationChannelId(threadId: Long): String {
        return when (threadId) {
            0L -> DEFAULT_CHANNEL_ID
            else -> "notifications_$threadId"
        }
    }

    override fun getNotificationForBackup(): NotificationCompat.Builder {
        if (Build.VERSION.SDK_INT >= 26) {
            val name =
                context.getString(R.string.backup_notification_channel_name)
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(BACKUP_RESTORE_CHANNEL_ID, name, importance)
            val notificationManager = context.getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }

//        Log.e("@@@@####", "setSound 5---> " + Uri.parse(context.baseConfig.ringtoneUri))

        return NotificationCompat.Builder(context, BACKUP_RESTORE_CHANNEL_ID)
            .setContentTitle(context.getString(R.string.backup_restoring))
            .setShowWhen(false)
            .setWhen(System.currentTimeMillis()) // Set this anyway in case it's shown
            .setSmallIcon(R.drawable.ic_file_download_black_24dp)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setProgress(0, 0, true)
            .setSound(Uri.parse(context.baseConfig.ringtoneUri))
            .setOngoing(true)
    }

    fun createBitmapFromLayout(context: Context, initial: String, color: Int): Bitmap {
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.recipient_layout, null) // Inflate the layout
        val rlRecipinet = view.findViewById<RelativeLayout>(R.id.rlRecip)
        val tvInitial = view.findViewById<TextView>(R.id.tvInitial)
        rlRecipinet.background.applyColorFilter(color)
        tvInitial.text = initial.first().toString()
        // Measure and layout the view
        view.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        view.layout(0, 0, view.measuredWidth, view.measuredHeight)

        // Create a Bitmap and draw the view into it
        val bitmap = Bitmap.createBitmap(view.measuredWidth, view.measuredHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        view.draw(canvas)

        return bitmap
    }
}