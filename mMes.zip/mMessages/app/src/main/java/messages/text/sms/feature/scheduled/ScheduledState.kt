package messages.text.sms.feature.scheduled

import io.realm.RealmResults
import messages.text.sms.model.ScheduledMessage

data class ScheduledState(
    val scheduledMessages: RealmResults<ScheduledMessage>? = null,
    val upgraded: Boolean = true,
)
