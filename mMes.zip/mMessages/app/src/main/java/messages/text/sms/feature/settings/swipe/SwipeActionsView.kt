package messages.text.sms.feature.settings.swipe

import io.reactivex.Observable
import messages.text.sms.common.base.MainBaseMsgViewContract

interface SwipeActionsView : MainBaseMsgViewContract<SwipeActionsState> {

    enum class Action { LEFT, RIGHT }

    fun actionClicks(): Observable<Action>
    fun actionSelected(): Observable<Int>

    fun showSwipeActions(selected: Int)

}