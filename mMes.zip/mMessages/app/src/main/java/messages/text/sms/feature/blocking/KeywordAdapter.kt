package messages.text.sms.feature.blocking

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.databinding.ItemKeywordBinding

class KeywordAdapter(
    private val keywords: MutableList<KeywordItem>,
    private val onDeleteClick: (Int) -> Unit,
) : RecyclerView.Adapter<KeywordAdapter.KeywordViewHolder>() {

    inner class KeywordViewHolder(val binding: ItemKeywordBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: KeywordItem, position: Int) {
//            binding.name.text = " ${position + 1}. ${item.keyword}"
            binding.keywordName.text = " ${position + 1}. ${item.keyword}"
            binding.btnDelete.setOnClickListener {
                onDeleteClick(position)
            }

            binding.keywordName.visibility = View.VISIBLE
            binding.no.visibility = View.GONE
            binding.name.visibility = View.GONE
            binding.tvKeyword.visibility = View.GONE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): KeywordViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemKeywordBinding.inflate(inflater, parent, false)
        return KeywordViewHolder(binding)
    }

    override fun onBindViewHolder(holder: KeywordViewHolder, position: Int) {
        holder.bind(keywords[position], position)
    }

    override fun getItemCount(): Int = keywords.size

    fun addItem(item: KeywordItem) {
        // keywords.add(0, item)
        keywords.add(item)
        notifyDataSetChanged()
    }

    fun getItems(): MutableList<KeywordItem> {
        return keywords
    }

    fun removeItem(position: Int) {
        if (position in keywords.indices) {
            keywords.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, itemCount)
        }
    }
}

