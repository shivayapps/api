package messages.text.sms.injection.android

//import messages.text.sms.receiver.NightModeReceiver
import dagger.Module
import dagger.android.ContributesAndroidInjector
import messages.text.sms.feature.widget.WidgetProvider
import messages.text.sms.injection.scope.ActivityScope
import messages.text.sms.receiver.BlockThreadReceiver
import messages.text.sms.receiver.BootReceiver
import messages.text.sms.receiver.DefaultSmsChangedReceiver
import messages.text.sms.receiver.DeleteMessagesReceiver
import messages.text.sms.receiver.MarkArchivedReceiver
import messages.text.sms.receiver.MarkReadReceiver
import messages.text.sms.receiver.MarkSeenReceiver
import messages.text.sms.receiver.MmsReceivedReceiver
import messages.text.sms.receiver.MmsReceiver
import messages.text.sms.receiver.MmsSentReceiver
import messages.text.sms.receiver.MmsUpdatedReceiver
import messages.text.sms.receiver.RemoteMessagingReceiver
import messages.text.sms.receiver.SendScheduledMessageReceiver
import messages.text.sms.receiver.SmsDeliveredReceiver
import messages.text.sms.receiver.SmsProviderChangedReceiver
import messages.text.sms.receiver.SmsReceiver
import messages.text.sms.receiver.SmsSentReceiver

@Module
abstract class BroadcastReceiverBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindBlockThreadReceiver(): BlockThreadReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindBootReceiver(): BootReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindDefaultSmsChangedReceiver(): DefaultSmsChangedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindDeleteMessagesReceiver(): DeleteMessagesReceiver

    @ActivityScope
    @ContributesAndroidInjector
    abstract fun bindMarkArchivedReceiver(): MarkArchivedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMarkReadReceiver(): MarkReadReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMarkSeenReceiver(): MarkSeenReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMmsReceivedReceiver(): MmsReceivedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMmsReceiver(): MmsReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMmsSentReceiver(): MmsSentReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMmsUpdatedReceiver(): MmsUpdatedReceiver

//    @ActivityScope
//    @ContributesAndroidInjector()
//    abstract fun bindNightModeReceiver(): NightModeReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindRemoteMessagingReceiver(): RemoteMessagingReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSendScheduledMessageReceiver(): SendScheduledMessageReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSmsDeliveredReceiver(): SmsDeliveredReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSmsProviderChangedReceiver(): SmsProviderChangedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSmsReceiver(): SmsReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSmsSentReceiver(): SmsSentReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindWidgetProvider(): WidgetProvider

}