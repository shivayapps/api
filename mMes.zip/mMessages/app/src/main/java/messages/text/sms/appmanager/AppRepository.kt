package messages.text.sms.appmanager

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable

const val MSG_TEXT_KEY = "send_msg"
const val CHANNEL_ID_1 = "1"
const val CHANNEL_ID_2 = "2"
const val CH_ID = "CH_ID"
const val NOTIFICATION_ID = 1001
const val NOTIFICATION_ALARM_ID = 1002
const val ALARM_ON = "ALARM ON"
const val ALARM_OFF = "ALARM OFF"
const val MESSAGE_ACTION = "showmessage"
const val INSTALLED_APP = "Installed app"
const val EXAMPLE_ALARM = "Example alarm"
const val PACKAGE = "package"
const val ALARM_MESSAGE = "Alarm! Wake up! Wake up!"

const val REQUEST_CODE = 111

class AppRepository {

    fun getAppName(context: Context?, packageName: String): String {
        val packageManager: PackageManager? =
            context?.packageManager
        val applicationInfo: ApplicationInfo? = try {
            packageManager?.getApplicationInfo(packageName, 0)
        } catch (exception: PackageManager.NameNotFoundException) {
            null
        }
        return (if (applicationInfo != null) packageManager?.getApplicationLabel(applicationInfo) else packageName) as String
    }

    fun getAppIcon(context: Context?, packageName: String): Drawable? {
        val packageManager: PackageManager? =
            context?.packageManager
        val applicationIcon: Drawable? = try {
            packageManager?.getApplicationIcon(packageName)
        } catch (exception: PackageManager.NameNotFoundException) {
            null
        }
        return applicationIcon
    }
}
