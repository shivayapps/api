package messages.text.sms.feature.themepicker

import android.content.Context
import android.content.res.Resources
import android.view.LayoutInflater
import android.view.ViewGroup
import com.google.android.flexbox.FlexDirection
import com.google.android.flexbox.FlexWrap
import com.google.android.flexbox.FlexboxLayout
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.common.base.MainBaseAdapter
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.extensions.dpToPx
import messages.text.sms.common.util.extensions.setBackgroundTint
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.common.util.extensions.setVisible
import messages.text.sms.databinding.ThemeListItemBinding
import messages.text.sms.databinding.ThemePaletteListItemBinding
import javax.inject.Inject

class ThemeAdapter @Inject constructor(
    private val context: Context,
    private val colors: Colors,
) : MainBaseAdapter<List<Int>, ThemePaletteListItemBinding>() {

    val colorSelected: Subject<Int> = PublishSubject.create()

    var selectedColor: Int = -1
        set(value) {
            val oldPosition = data.indexOfFirst { it.contains(field) }
            val newPosition = data.indexOfFirst { it.contains(value) }

            field = value
            iconTint = colors.textPrimaryOnThemeForColor(value)

            oldPosition.takeIf { it != -1 }?.let { position -> notifyItemChanged(position) }
            newPosition.takeIf { it != -1 }?.let { position -> notifyItemChanged(position) }
        }

    private var iconTint = 0

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<ThemePaletteListItemBinding> {
        return MainBaseMsgViewHolder(parent, ThemePaletteListItemBinding::inflate).apply {
            binding.palette.flexWrap = FlexWrap.WRAP
            binding.palette.flexDirection = FlexDirection.ROW
        }
    }

    override fun onBindViewHolder(
        holder: MainBaseMsgViewHolder<ThemePaletteListItemBinding>,
        position: Int,
    ) {
        val palette = getItem(position)

        val screenWidth = Resources.getSystem().displayMetrics.widthPixels
        val minPadding = (16 * 6).dpToPx(context)
        val size = if (screenWidth - minPadding > (56 * 5).dpToPx(context)) {
            56.dpToPx(context)
        } else {
            (screenWidth - minPadding) / 5
        }
        val swatchPadding = (screenWidth - size * 5) / 12

        holder.binding.palette.removeAllViews()
        holder.binding.palette.setPadding(
            swatchPadding,
            swatchPadding,
            swatchPadding,
            swatchPadding
        )

        (palette.subList(0, 5) + palette.subList(5, 10).reversed())
            .mapIndexed { index, color ->
                ThemeListItemBinding.inflate(
                    LayoutInflater.from(context),
                    holder.binding.palette,
                    false
                ).apply {

                    // Send clicks to the selected subject
                    root.setOnClickListener { colorSelected.onNext(color) }

                    // Apply the color to the view
                    theme.setBackgroundTint(color)

                    // Control the check visibility and tint
                    check.setVisible(color == selectedColor)
                    check.setTint(iconTint)

                    // Update the size so that the spacing is perfectly even
                    root.layoutParams = (root.layoutParams as FlexboxLayout.LayoutParams).apply {
                        height = size
                        width = size
                        isWrapBefore = index % 5 == 0
                        setMargins(swatchPadding, swatchPadding, swatchPadding, swatchPadding)
                    }
                }.root
            }
            .forEach { theme -> holder.binding.palette.addView(theme) }
    }

}