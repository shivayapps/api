package messages.text.sms.feature.main

import android.content.Intent
import io.reactivex.Observable
import io.reactivex.subjects.Subject
import messages.text.sms.common.base.MainBaseMsgView
import messages.text.sms.extensions.Optional
import messages.text.sms.feature.compose.editing.PhoneNumberAction
import messages.text.sms.model.ContactData

interface MainView : MainBaseMsgView<MainState> {

    val onNewIntentIntent: Observable<Intent>
    val activityResumedIntent: Observable<Boolean>
    val queryConversationChangedIntent: Observable<CharSequence>
    val composeIntent: Observable<Unit>

    //    val drawerOpenIntent: Observable<Boolean>
    val homeIntent: Observable<*>
    val navigationIntent: Observable<NavItem>
    val optionsItemIntent: Observable<Int>

    //    val dismissRatingIntent: Observable<*>
//    val rateIntent: Observable<*>
    val conversationsSelectedIntent: Observable<List<Long>>
    val confirmDeleteIntent: Observable<List<Long>>
    val swipeConversationIntent: Observable<Pair<Long, Int>>
    val undoArchiveIntent: Observable<Unit>
    val refreshArchive: Observable<Unit>
    val refreshBlocked: Observable<Unit>
    val refreshMessages: Observable<Unit>
    val setAsDefaultClick: Observable<*>

    fun requestDefaultSms()
    fun requestPermissions()
    fun clearSearch()
    fun clearSelection()

    //    fun onBackPressedFromArchive()
    fun themeChanged()
    fun showBlockingDialog(conversations: List<Long>, block: Boolean)
    fun showDeleteDialog(conversations: List<Long>)
    fun showArchivedSnackbar()

    val queryChangedIntent: Observable<CharSequence>
    val queryClearedIntent: Observable<*>
    val queryEditorActionIntent: Observable<Int>
    val composeItemPressedIntent: Subject<ContactData>
    val composeItemLongPressedIntent: Subject<ContactData>
    val phoneNumberSelectedIntent: Subject<Optional<Long>>
    val phoneNumberActionIntent: Subject<PhoneNumberAction>
    fun clearQuery()
    fun refreshArchive()
    fun refreshBlockedList()
    fun openKeyboard()
    fun finish(result: HashMap<String, String?>)
}

enum class NavItem { BACK, INBOX, ARCHIVED, BACKUP, SCHEDULED, BLOCKING, SETTINGS, HELP, INVITE }
