package messages.text.sms.feature.compose.editing

import android.content.Context
import android.view.ViewGroup
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseAdapter
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.common.util.extensions.forwardTouches
import messages.text.sms.databinding.PhoneNumberListItemBinding
import messages.text.sms.extensions.Optional
import messages.text.sms.model.PhoneNumber
import javax.inject.Inject

class PhoneNumberPickerAdapter @Inject constructor(
    private val context: Context,
) : MainBaseAdapter<PhoneNumber, PhoneNumberListItemBinding>() {

    val selectedItemChanges: Subject<Optional<Long>> = BehaviorSubject.create()

    private var selectedItem: Long? = null
        set(value) {
            data.indexOfFirst { number -> number.id == field }.takeIf { it != -1 }
                ?.run(::notifyItemChanged)
            field = value
            data.indexOfFirst { number -> number.id == field }.takeIf { it != -1 }
                ?.run(::notifyItemChanged)
            selectedItemChanges.onNext(Optional(value))
        }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<PhoneNumberListItemBinding> {
        return MainBaseMsgViewHolder(parent, PhoneNumberListItemBinding::inflate).apply {
            binding.number.binding.radioButton.forwardTouches(itemView)

            binding.root.setOnClickListener {
                val phoneNumber = getItem(adapterPosition)
                selectedItem = phoneNumber.id
            }
        }
    }

    override fun onBindViewHolder(
        holder: MainBaseMsgViewHolder<PhoneNumberListItemBinding>,
        position: Int,
    ) {
        val phoneNumber = getItem(position)

        holder.binding.number.binding.radioButton.isChecked = phoneNumber.id == selectedItem
        holder.binding.number.binding.titleView.text = phoneNumber.address
        holder.binding.number.binding.summaryView.text = when (phoneNumber.isDefault) {
            true -> context.getString(R.string.compose_number_picker_default, phoneNumber.type)
            false -> phoneNumber.type
        }
    }

    override fun onDatasetChanged() {
        super.onDatasetChanged()
        selectedItem = data.find { number -> number.isDefault }?.id ?: data.firstOrNull()?.id
    }

}
