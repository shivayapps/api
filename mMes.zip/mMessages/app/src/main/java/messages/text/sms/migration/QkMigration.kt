package messages.text.sms.migration

import android.content.Context
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import messages.text.sms.blocking.QksmsBlockingClient
import messages.text.sms.common.util.extensions.versionCode
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.util.Preferences
import javax.inject.Inject

class QkMigration @Inject constructor(
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val qksmsBlockingClient: QksmsBlockingClient,
) {

    fun performMigration() {
        GlobalScope.launch {
            prefs.version.set(context.versionCode)
        }
    }


}
