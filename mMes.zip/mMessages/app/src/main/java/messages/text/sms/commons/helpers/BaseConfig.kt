package messages.text.sms.commons.helpers

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Environment
import android.text.format.DateFormat
import android.util.Base64
import androidx.core.content.ContextCompat
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import messages.text.sms.R
import messages.text.sms.commons.extensions.getSharedPrefs
import messages.text.sms.feature.main.models.Contact
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.LinkedList
import java.util.Locale
import java.util.Locale.getDefault

open class BaseConfig(val context: Context) {
    protected val prefs = context.getSharedPrefs()

    companion object {
        fun newInstance(context: Context) = BaseConfig(context)
    }

    var appRunCount: Int
        get() = prefs.getInt(APP_RUN_COUNT, 0)
        set(appRunCount) = prefs.edit().putInt(APP_RUN_COUNT, appRunCount).apply()


    var select_cat: Int
        get() = prefs.getInt("select_cat", 0)
        set(selectCat) = prefs.edit().putInt("select_cat", selectCat).apply()

    var checkpage: Int
        get() = prefs.getInt(CHECK_PAGE, 0)
        set(appRunCount) = prefs.edit().putInt(CHECK_PAGE, appRunCount).apply()


    var lastContactSyncTime: Long
        get() = prefs.getLong("last_contact_sync_time", 0L)
        set(value) = prefs.edit().putLong("last_contact_sync_time", value).apply()


    var ringtoneSelected: Int
        get() = prefs.getInt("RINGTONE_SELECTED", 1)
        set(ringtoneselected) = prefs.edit().putInt("RINGTONE_SELECTED", ringtoneselected).apply()

    var selectedFont: Int
        get() = prefs.getInt("selectedFont", R.font.lato)
        set(value) = prefs.edit().putInt("selectedFont", value).apply()


    var primaryAndroidDataTreeUri: String
        get() = prefs.getString(PRIMARY_ANDROID_DATA_TREE_URI, "")!!
        set(uri) = prefs.edit().putString(PRIMARY_ANDROID_DATA_TREE_URI, uri).apply()

    var sdAndroidDataTreeUri: String
        get() = prefs.getString(SD_ANDROID_DATA_TREE_URI, "")!!
        set(uri) = prefs.edit().putString(SD_ANDROID_DATA_TREE_URI, uri).apply()

    var otgAndroidDataTreeUri: String
        get() = prefs.getString(OTG_ANDROID_DATA_TREE_URI, "")!!
        set(uri) = prefs.edit().putString(OTG_ANDROID_DATA_TREE_URI, uri).apply()

    var primaryAndroidObbTreeUri: String
        get() = prefs.getString(PRIMARY_ANDROID_OBB_TREE_URI, "")!!
        set(uri) = prefs.edit().putString(PRIMARY_ANDROID_OBB_TREE_URI, uri).apply()

    var sdAndroidObbTreeUri: String
        get() = prefs.getString(SD_ANDROID_OBB_TREE_URI, "")!!
        set(uri) = prefs.edit().putString(SD_ANDROID_OBB_TREE_URI, uri).apply()

    // List of Drive auto-reply messages
    var driveReplies: List<String>
        get() = prefs.getString("DRIVE_REPLIES_KEY", null)
            ?.let { Gson().fromJson(it, object : TypeToken<List<String>>() {}.type) } ?: emptyList()
        set(value) = prefs.edit().putString("DRIVE_REPLIES_KEY", Gson().toJson(value)).apply()

    // Index of the selected Drive auto-reply
    var driveSelectedReplyIndex: Int
        get() = prefs.getInt("DRIVE_SELECTED_REPLY_INDEX_KEY", 0)
        set(value) = prefs.edit().putInt("DRIVE_SELECTED_REPLY_INDEX_KEY", value).apply()

    // Whether to reply only to contacts
    var onlyReplyContacts: Boolean
        get() = prefs.getBoolean("ONLY_REPLY_CONTACTS_KEY", false)
        set(value) = prefs.edit().putBoolean("ONLY_REPLY_CONTACTS_KEY", value).apply()



    var otgAndroidObbTreeUri: String
        get() = prefs.getString(OTG_ANDROID_OBB_TREE_URI, "")!!
        set(uri) = prefs.edit().putString(OTG_ANDROID_OBB_TREE_URI, uri).apply()

    var sdTreeUri: String
        get() = prefs.getString(SD_TREE_URI, "")!!
        set(uri) = prefs.edit().putString(SD_TREE_URI, uri).apply()

    var OTGTreeUri: String
        get() = prefs.getString(OTG_TREE_URI, "")!!
        set(OTGTreeUri) = prefs.edit().putString(OTG_TREE_URI, OTGTreeUri).apply()

    var OTGPartition: String
        get() = prefs.getString(OTG_PARTITION, "")!!
        set(OTGPartition) = prefs.edit().putString(OTG_PARTITION, OTGPartition).apply()

    var OTGPath: String
        get() = prefs.getString(OTG_REAL_PATH, "")!!
        set(OTGPath) = prefs.edit().putString(OTG_REAL_PATH, OTGPath).apply()

    var privatePin: String
        get() = prefs.getString(PRIVATE_PIN, "")!!
        set(privatePin) = prefs.edit().putString(PRIVATE_PIN, privatePin).apply()

    var privateBoxName: String
        get() = prefs.getString(
            "PRIVATEBOXNAME",
            context.getString(R.string.private_conversations)
        )!!
        set(privateboxname) = prefs.edit().putString("PRIVATEBOXNAME", privateboxname).apply()

    var customMessageForPrivate: String
        get() = prefs.getString(
            "CUSTOM_MESSAGE_FOR_PRIVATE",
            context.getString(R.string.new_message)
        )!!
        set(customMessagePrivate) = prefs.edit()
            .putString("CUSTOM_MESSAGE_FOR_PRIVATE", customMessagePrivate).apply()

    var securityAnswer: String
        get() = prefs.getString("SECURITY_QUESTIONS", "")!!
        set(securityquestions) = prefs.edit().putString("SECURITY_QUESTIONS", securityquestions)
            .apply()

    var privateContactsList: String
        get() = prefs.getString("PRIVATE_CONTACTS", "")!!
        set(privatecontacts) = prefs.edit().putString("PRIVATE_CONTACTS", privatecontacts)
            .apply()

//    var blockContactsList: String
//        get() = prefs.getString("BLOCK_CONTACTS", "")!!
//        set(blockContactsList) = prefs.edit().putString("BLOCK_CONTACTS", blockContactsList)
//            .apply()

    private val gson = Gson()
    var blockContactsList: ArrayList<Contact>
        get() {
            val json = prefs.getString("BLOCK_CONTACTS", "") ?: ""
            return if (json.isNotEmpty()) {
                val type = object : TypeToken<ArrayList<Contact>>() {}.type
                gson.fromJson(json, type)
            } else {
                arrayListOf()
            }
        }
        set(value) {
            val json = gson.toJson(value)
            prefs.edit().putString("BLOCK_CONTACTS", json).apply()
        }


    var signaturecheck: String
        get() = prefs.getString(SIGNATURECHECK, "")!!
        set(OTGPath) = prefs.edit().putString(SIGNATURECHECK, OTGPath).apply()


    var textColor: Int
        get() = prefs.getInt(
            TEXT_COLOR,
            context.resources.getColor(R.color.theme_black_background_color)
        )
        set(textColor) = prefs.edit().putInt(TEXT_COLOR, textColor).apply()

    var blockedMessageCount: Int
        get() = prefs.getInt(
            "BLOCKED_MESSAGE_COUNT",
            0
        )
        set(value) = prefs.edit().putInt("BLOCKED_MESSAGE_COUNT", value).apply()

    var statusBarColor: Int
        get() = prefs.getInt(STATUS_BG_COLOR, ContextCompat.getColor(context, R.color.white))
        set(textColor) = prefs.edit().putInt(STATUS_BG_COLOR, textColor).apply()

    var backgroundColor: Int
        get() = prefs.getInt(
            BACKGROUND_COLOR,
            context.resources.getColor(R.color.theme_light_background_color)
        )
        set(backgroundColor) = prefs.edit().putInt(BACKGROUND_COLOR, backgroundColor).apply()

    var primaryColor: Int
        get() = prefs.getInt(
            PRIMARY_COLOR,
            context.resources.getColor(R.color.default_primary_color)
        )
        set(primaryColor) = prefs.edit().putInt(PRIMARY_COLOR, primaryColor).apply()


    var primaryColortheme: Int
        get() = prefs.getInt(PRIMARY_COLOR_THEME, context.resources.getColor(R.color.white))
        set(primaryColor) = prefs.edit().putInt(PRIMARY_COLOR_THEME, primaryColor).apply()

    var checkprimaryColortheme: Int
        get() = prefs.getInt(CHECK_COLOR_THEME, context.resources.getColor(R.color.white))
        set(primaryColor) = prefs.edit().putInt(CHECK_COLOR_THEME, primaryColor).apply()

    var toolbarcolor: Int
        get() = prefs.getInt(ToolBar_COLOR, context.resources.getColor(R.color.white))
        set(primaryColor) = prefs.edit().putInt(ToolBar_COLOR, primaryColor).apply()

    var accentColor: Int
        get() = prefs.getInt(ACCENT_COLOR, context.resources.getColor(R.color.default_accent_color))
        set(accentColor) = prefs.edit().putInt(ACCENT_COLOR, accentColor).apply()


    var lastHandledShortcutColor: Int
        get() = prefs.getInt(LAST_HANDLED_SHORTCUT_COLOR, 1)
        set(lastHandledShortcutColor) = prefs.edit()
            .putInt(LAST_HANDLED_SHORTCUT_COLOR, lastHandledShortcutColor).apply()

    var appIconColor: Int
        get() = prefs.getInt(
            APP_ICON_COLOR,
            context.resources.getColor(R.color.default_app_icon_color)
        ) // TODO APP ICON DEFAULT CUR
        set(appIconColor) {
            isUsingModifiedAppIcon =
                appIconColor != context.resources.getColor(R.color.color_primary)
            prefs.edit().putInt(APP_ICON_COLOR, appIconColor).apply()
        }

    var useImageResource: Boolean
        get() = prefs.getBoolean("USE_IMAGE_RESOURCE", false)
        set(useImageResource) = prefs.edit().putBoolean("USE_IMAGE_RESOURCE", useImageResource)
            .apply()

    var callFirstTime: Boolean
        get() = prefs.getBoolean("CALL_FIRST_TIME", false)
        set(value) = prefs.edit().putBoolean("CALL_FIRST_TIME", value)
            .apply()

    var callUMP: Boolean
        get() = prefs.getBoolean("callUMP", false)
        set(value) = prefs.edit().putBoolean("callUMP", value)
            .apply()

    var autoReplyEnable: Boolean
        get() = prefs.getBoolean("autoReplayEnable", false)
        set(value) = prefs.edit().putBoolean("autoReplayEnable", value)
            .apply()


    var autoReplySelectedCard: Int
        get() = prefs.getInt("AUTOREPLYSELECTEDCARD", 1)
        set(accentColor) = prefs.edit().putInt("AUTOREPLYSELECTEDCARD", accentColor).apply()

    var storedImageResource: Int
        get() = prefs.getInt("storedImageResource", -1)
        set(value) = prefs.edit().putInt("storedImageResource", value).apply()

    var quickMessagesList: List<String>
        get() {
            val savedMessages = prefs.getString("CALLER_QUICK_MESSAGES", null)
            return savedMessages?.split("|")
                ?.map { it.trim() } // Remove leading/trailing whitespace
                ?.filter { it.isNotEmpty() } // Filter out empty messages
                ?: listOf(
                    "What's up?", "I'll be running a bit late, but I’ll be there soon",
                    "Where is the meeting taking place?", "Where are you?", "How are things?",
                    "Please give me a call after receiving this message.", "When are we meeting?",
                    "I’ll let you know a bit.", "No problem. I missed your call."
                )
        }
        set(value) {
            prefs.edit().putString(
                "CALLER_QUICK_MESSAGES",
                value.filter { it.isNotEmpty() }.joinToString("|")
            ).apply()
        }

    var lastIconColor: Int
        get() = prefs.getInt(LAST_ICON_COLOR, context.resources.getColor(R.color.color_primary))
        set(lastIconColor) = prefs.edit().putInt(LAST_ICON_COLOR, lastIconColor).apply()

    var customTextColor: Int
        get() = prefs.getInt(CUSTOM_TEXT_COLOR, textColor)
        set(customTextColor) = prefs.edit().putInt(CUSTOM_TEXT_COLOR, customTextColor).apply()

    var customPrimaryColor: Int
        get() = prefs.getInt(CUSTOM_PRIMARY_COLOR, primaryColor)
        set(customPrimaryColor) = prefs.edit().putInt(CUSTOM_PRIMARY_COLOR, customPrimaryColor)
            .apply()

    var customAccentColor: Int
        get() = prefs.getInt(CUSTOM_ACCENT_COLOR, accentColor)
        set(customAccentColor) = prefs.edit().putInt(CUSTOM_ACCENT_COLOR, customAccentColor).apply()

    var customAppIconColor: Int
        get() = prefs.getInt(CUSTOM_APP_ICON_COLOR, appIconColor)
        set(customAppIconColor) = prefs.edit().putInt(CUSTOM_APP_ICON_COLOR, customAppIconColor)
            .apply()

    var widgetBgColor: Int
        get() = prefs.getInt(
            WIDGET_BG_COLOR,
            context.resources.getColor(R.color.default_widget_bg_color)
        )
        set(widgetBgColor) = prefs.edit().putInt(WIDGET_BG_COLOR, widgetBgColor).apply()

    var widgetTextColor: Int
        get() = prefs.getInt(
            WIDGET_TEXT_COLOR,
            context.resources.getColor(R.color.default_widget_text_color)
        )
        set(widgetTextColor) = prefs.edit().putInt(WIDGET_TEXT_COLOR, widgetTextColor).apply()

    // hidden folder visibility protection
    var isHiddenPasswordProtectionOn: Boolean
        get() = prefs.getBoolean(PASSWORD_PROTECTION, false)
        set(isHiddenPasswordProtectionOn) = prefs.edit()
            .putBoolean(PASSWORD_PROTECTION, isHiddenPasswordProtectionOn).apply()

    var hiddenPasswordHash: String
        get() = prefs.getString(PASSWORD_HASH, "")!!
        set(hiddenPasswordHash) = prefs.edit().putString(PASSWORD_HASH, hiddenPasswordHash).apply()

    var hiddenProtectionType: Int
        get() = prefs.getInt(PROTECTION_TYPE, PROTECTION_PATTERN)
        set(hiddenProtectionType) = prefs.edit().putInt(PROTECTION_TYPE, hiddenProtectionType)
            .apply()

//    fun getIntData(key:String,default:Int):Int{
//        return prefs.getInt(key, default)
//    }
//    fun saveData(key:String,value:Int){
//        prefs.edit().putInt(key, value).apply()
//    }

    // whole app launch protection
    var isAppPasswordProtectionOn: Boolean
        get() = prefs.getBoolean(APP_PASSWORD_PROTECTION, false)
        set(isAppPasswordProtectionOn) = prefs.edit()
            .putBoolean(APP_PASSWORD_PROTECTION, isAppPasswordProtectionOn).apply()
    var isfilteron: Boolean
        get() = prefs.getBoolean(FILTER_ON, true)
        set(isAppPasswordProtectionOn) = prefs.edit()
            .putBoolean(FILTER_ON, isAppPasswordProtectionOn).apply()

    var appPasswordHash: String
        get() = prefs.getString(APP_PASSWORD_HASH, "")!!
        set(appPasswordHash) = prefs.edit().putString(APP_PASSWORD_HASH, appPasswordHash).apply()

    var appProtectionType: Int
        get() = prefs.getInt(
            APP_PROTECTION_TYPE,
            PROTECTION_PATTERN
        )
        set(appProtectionType) = prefs.edit().putInt(APP_PROTECTION_TYPE, appProtectionType).apply()

    // file delete and move protection
    var isDeletePasswordProtectionOn: Boolean
        get() = prefs.getBoolean(DELETE_PASSWORD_PROTECTION, false)
        set(isDeletePasswordProtectionOn) = prefs.edit()
            .putBoolean(DELETE_PASSWORD_PROTECTION, isDeletePasswordProtectionOn).apply()

    var deletePasswordHash: String
        get() = prefs.getString(DELETE_PASSWORD_HASH, "")!!
        set(deletePasswordHash) = prefs.edit().putString(DELETE_PASSWORD_HASH, deletePasswordHash)
            .apply()

    var deleteProtectionType: Int
        get() = prefs.getInt(
            DELETE_PROTECTION_TYPE,
            PROTECTION_PATTERN
        )
        set(deleteProtectionType) = prefs.edit()
            .putInt(DELETE_PROTECTION_TYPE, deleteProtectionType).apply()

    // folder locking
    fun addFolderProtection(path: String, hash: String, type: Int) {
        prefs.edit()
            .putString("${PROTECTED_FOLDER_HASH}$path", hash)
            .putInt("${PROTECTED_FOLDER_TYPE}$path", type)
            .apply()
    }

    fun removeFolderProtection(path: String) {
        prefs.edit()
            .remove("${PROTECTED_FOLDER_HASH}$path")
            .remove("${PROTECTED_FOLDER_TYPE}$path")
            .apply()
    }

    fun isFolderProtected(path: String) = getFolderProtectionType(path) != PROTECTION_NONE

    fun getFolderProtectionHash(path: String) =
        prefs.getString("${PROTECTED_FOLDER_HASH}$path", "") ?: ""

    fun getFolderProtectionType(path: String) = prefs.getInt(
        "${PROTECTED_FOLDER_TYPE}$path",
        PROTECTION_NONE
    )

    var storeLanguageName: String
        get() = prefs.getString("DLANGUAGE_NAME", "")!!
        set(storeLanguageName) = prefs.edit().putString("DLANGUAGE_NAME", storeLanguageName).apply()

    var selectedLanguage_default_name1: String
        get() = prefs.getString("selectedLanguage_default_name1", "Default")!!
        set(storeLanguageName) = prefs.edit()
            .putString("selectedLanguage_default_name1", storeLanguageName).apply()

    var selectedLanguage_default_name2: String
        get() = prefs.getString("selectedLanguage_default_name2", "System Default")!!
        set(storeLanguageName) = prefs.edit()
            .putString("selectedLanguage_default_name2", storeLanguageName).apply()

    var achivecheck: String
        get() = prefs.getString(ARCHIVE_CHECK, "archived")!!
        set(lastCopyPath) = prefs.edit().putString(ARCHIVE_CHECK, lastCopyPath).apply()


    var privatchatcheck: String
        get() = prefs.getString(PRIVATE_CHECK, "is_privatebox")!!
        set(lastCopyPath) = prefs.edit().putString(PRIVATE_CHECK, lastCopyPath).apply()

    var last_logged_date: String
        get() = prefs.getString("LAST_LOGGED_DATE", null)!!
        set(last_logged_date) = prefs.edit().putString("LAST_LOGGED_DATE", last_logged_date).apply()

    var keepLastModified: Boolean
        get() = prefs.getBoolean(KEEP_LAST_MODIFIED, true)
        set(keepLastModified) = prefs.edit().putBoolean(KEEP_LAST_MODIFIED, keepLastModified)
            .apply()

    var useEnglish: Boolean
        get() = prefs.getBoolean(USE_ENGLISH, false)
        set(useEnglish) {
            wasUseEnglishToggled = true
            prefs.edit().putBoolean(USE_ENGLISH, useEnglish).commit()
        }

    var wasUseEnglishToggled: Boolean
        get() = prefs.getBoolean(WAS_USE_ENGLISH_TOGGLED, false)
        set(wasUseEnglishToggled) = prefs.edit()
            .putBoolean(WAS_USE_ENGLISH_TOGGLED, wasUseEnglishToggled).apply()

    var useIconTabs: Boolean
        get() = prefs.getBoolean(USE_ICON_TABS, false)
        set(useIconTabs) = prefs.edit().putBoolean(USE_ICON_TABS, useIconTabs).apply()


    var firstoLog: Boolean
        get() = prefs.getBoolean("firstoLog", false)
        set(value) = prefs.edit().putBoolean("firstoLog", value).apply()

    var tabsChanged: Boolean
        get() = prefs.getBoolean(TABS_CHANGED, true)
        set(tabsChanged) = prefs.edit().putBoolean(TABS_CHANGED, tabsChanged).apply()

    var useDividers: Boolean
        get() = prefs.getBoolean(USE_DIVIDERS, false)
        set(useDividers) = prefs.edit().putBoolean(USE_DIVIDERS, useDividers).apply()

    var useColoredContacts: Boolean
        get() = prefs.getBoolean(USE_COLORED_CONTACTS, true)
        set(useColoredContacts) = prefs.edit().putBoolean(USE_COLORED_CONTACTS, useColoredContacts)
            .apply()

    var contactColorList: Int
        get() = prefs.getInt(CONTACT_COLOR_LIST, LBC_ARC)
        set(contactsColorList) = prefs.edit().putInt(CONTACT_COLOR_LIST, contactsColorList).apply()

    var wasSharedThemeEverActivated: Boolean
        get() = prefs.getBoolean(WAS_SHARED_THEME_EVER_ACTIVATED, false)
        set(wasSharedThemeEverActivated) = prefs.edit()
            .putBoolean(WAS_SHARED_THEME_EVER_ACTIVATED, wasSharedThemeEverActivated).apply()

    var isUsingSharedTheme: Boolean
        get() = prefs.getBoolean(IS_USING_SHARED_THEME, false)
        set(isUsingSharedTheme) = prefs.edit().putBoolean(IS_USING_SHARED_THEME, isUsingSharedTheme)
            .apply()

    var shouldUseSharedTheme: Boolean
        get() = prefs.getBoolean(SHOULD_USE_SHARED_THEME, false)
        set(shouldUseSharedTheme) = prefs.edit()
            .putBoolean(SHOULD_USE_SHARED_THEME, shouldUseSharedTheme).apply()

    var isUsingAutoTheme: Boolean
        get() = prefs.getBoolean(IS_USING_AUTO_THEME, false)
        set(isUsingAutoTheme) = prefs.edit().putBoolean(IS_USING_AUTO_THEME, isUsingAutoTheme)
            .apply()


    var wasCustomThemeSwitchDescriptionShown: Boolean
        get() = prefs.getBoolean(WAS_CUSTOM_THEME_SWITCH_DESCRIPTION_SHOWN, false)
        set(wasCustomThemeSwitchDescriptionShown) = prefs.edit()
            .putBoolean(
                WAS_CUSTOM_THEME_SWITCH_DESCRIPTION_SHOWN,
                wasCustomThemeSwitchDescriptionShown
            )
            .apply()

    var wasSharedThemeForced: Boolean
        get() = prefs.getBoolean(WAS_SHARED_THEME_FORCED, false)
        set(wasSharedThemeForced) = prefs.edit()
            .putBoolean(WAS_SHARED_THEME_FORCED, wasSharedThemeForced).apply()

    var showInfoBubble: Boolean
        get() = prefs.getBoolean(SHOW_INFO_BUBBLE, true)
        set(showInfoBubble) = prefs.edit().putBoolean(SHOW_INFO_BUBBLE, showInfoBubble).apply()

    var saveReview: Boolean
        get() = prefs.getBoolean("SAVEREVIEW", false)
        set(saveReview) = prefs.edit().putBoolean("SAVEREVIEW", saveReview).apply()


    fun storeBoolean(context: Context?, key: String, value: Boolean) {
        val editor = getSharePreference(context).edit()
        editor.putBoolean(key, value)
        editor.apply()
    }

    fun getBoolean(context: Context?, key: String): Boolean {
        return getSharePreference(context).getBoolean(key, false)
    }

    private fun getSharePreference(context: Context?): SharedPreferences {
        return context!!.getSharedPreferences(PREFERENCE_MESSAGE_NAME, Context.MODE_PRIVATE)
    }


    var lastConflictApplyToAll: Boolean
        get() = prefs.getBoolean(LAST_CONFLICT_APPLY_TO_ALL, true)
        set(lastConflictApplyToAll) = prefs.edit()
            .putBoolean(LAST_CONFLICT_APPLY_TO_ALL, lastConflictApplyToAll).apply()

    var lastConflictResolution: Int
        get() = prefs.getInt(
            LAST_CONFLICT_RESOLUTION,
            CONFLICT_SKIP
        )
        set(lastConflictResolution) = prefs.edit()
            .putInt(LAST_CONFLICT_RESOLUTION, lastConflictResolution).apply()

    var sorting: Int
        get() = prefs.getInt(SORT_ORDER, context.resources.getInteger(R.integer.default_sorting))
        set(sorting) = prefs.edit().putInt(SORT_ORDER, sorting).apply()

    fun saveCustomSorting(path: String, value: Int) {
        if (path.isEmpty()) {
            sorting = value
        } else {
            prefs.edit().putInt(SORT_FOLDER_PREFIX + path.lowercase(getDefault()), value).apply()
        }
    }

    fun getFolderSorting(path: String) =
        prefs.getInt(SORT_FOLDER_PREFIX + path.lowercase(getDefault()), sorting)

    fun removeCustomSorting(path: String) {
        prefs.edit().remove(SORT_FOLDER_PREFIX + path.lowercase(getDefault())).apply()
    }

    fun hasCustomSorting(path: String) =
        prefs.contains(SORT_FOLDER_PREFIX + path.lowercase(getDefault()))

    var hadThankYouInstalled: Boolean
        get() = prefs.getBoolean(HAD_THANK_YOU_INSTALLED, false)
        set(hadThankYouInstalled) = prefs.edit()
            .putBoolean(HAD_THANK_YOU_INSTALLED, hadThankYouInstalled).apply()

    var skipDeleteConfirmation: Boolean
        get() = prefs.getBoolean(SKIP_DELETE_CONFIRMATION, false)
        set(skipDeleteConfirmation) = prefs.edit()
            .putBoolean(SKIP_DELETE_CONFIRMATION, skipDeleteConfirmation).apply()

    var enablePullToRefresh: Boolean
        get() = prefs.getBoolean(ENABLE_PULL_TO_REFRESH, true)
        set(enablePullToRefresh) = prefs.edit()
            .putBoolean(ENABLE_PULL_TO_REFRESH, enablePullToRefresh).apply()

    var scrollHorizontally: Boolean
        get() = prefs.getBoolean(SCROLL_HORIZONTALLY, false)
        set(scrollHorizontally) = prefs.edit().putBoolean(SCROLL_HORIZONTALLY, scrollHorizontally)
            .apply()

    var preventPhoneFromSleeping: Boolean
        get() = prefs.getBoolean(PREVENT_PHONE_FROM_SLEEPING, true)
        set(preventPhoneFromSleeping) = prefs.edit()
            .putBoolean(PREVENT_PHONE_FROM_SLEEPING, preventPhoneFromSleeping).apply()

    var lastUsedViewPagerPage: Int
        get() = prefs.getInt(
            LAST_USED_VIEW_PAGER_PAGE,
            context.resources.getInteger(R.integer.default_viewpager_page)
        )
        set(lastUsedViewPagerPage) = prefs.edit()
            .putInt(LAST_USED_VIEW_PAGER_PAGE, lastUsedViewPagerPage).apply()

    var use24HourFormat: Boolean
        get() = prefs.getBoolean(USE_24_HOUR_FORMAT, DateFormat.is24HourFormat(context))
        set(use24HourFormat) = prefs.edit().putBoolean(USE_24_HOUR_FORMAT, use24HourFormat).apply()

    var isSundayFirst: Boolean
        get() {
            val isSundayFirst =
                Calendar.getInstance(Locale.getDefault()).firstDayOfWeek == Calendar.SUNDAY
            return prefs.getBoolean(SUNDAY_FIRST, isSundayFirst)
        }
        set(sundayFirst) = prefs.edit().putBoolean(SUNDAY_FIRST, sundayFirst).apply()

    var wasAlarmWarningShown: Boolean
        get() = prefs.getBoolean(WAS_ALARM_WARNING_SHOWN, false)
        set(wasAlarmWarningShown) = prefs.edit()
            .putBoolean(WAS_ALARM_WARNING_SHOWN, wasAlarmWarningShown).apply()

    var wasReminderWarningShown: Boolean
        get() = prefs.getBoolean(WAS_REMINDER_WARNING_SHOWN, false)
        set(wasReminderWarningShown) = prefs.edit()
            .putBoolean(WAS_REMINDER_WARNING_SHOWN, wasReminderWarningShown).apply()

    var useSameSnooze: Boolean
        get() = prefs.getBoolean(USE_SAME_SNOOZE, true)
        set(useSameSnooze) = prefs.edit().putBoolean(USE_SAME_SNOOZE, useSameSnooze).apply()

    var snoozeTime: Int
        get() = prefs.getInt(SNOOZE_TIME, 10)
        set(snoozeDelay) = prefs.edit().putInt(SNOOZE_TIME, snoozeDelay).apply()

    var vibrateOnButtonPress: Boolean
        get() = prefs.getBoolean(
            VIBRATE_ON_BUTTON_PRESS,
            context.resources.getBoolean(R.bool.default_vibrate_on_press)
        )
        set(vibrateOnButton) = prefs.edit().putBoolean(VIBRATE_ON_BUTTON_PRESS, vibrateOnButton)
            .apply()

    var yourAlarmSounds: String
        get() = prefs.getString(YOUR_ALARM_SOUNDS, "")!!
        set(yourAlarmSounds) = prefs.edit().putString(YOUR_ALARM_SOUNDS, yourAlarmSounds).apply()

    var isUsingModifiedAppIcon: Boolean
        get() = prefs.getBoolean(IS_USING_MODIFIED_APP_ICON, false)
        set(isUsingModifiedAppIcon) = prefs.edit()
            .putBoolean(IS_USING_MODIFIED_APP_ICON, isUsingModifiedAppIcon).apply()

    var appId: String
        get() = prefs.getString(APP_ID, "")!!
        set(appId) = prefs.edit().putString(APP_ID, appId).apply()

    var initialWidgetHeight: Int
        get() = prefs.getInt(INITIAL_WIDGET_HEIGHT, 0)
        set(initialWidgetHeight) = prefs.edit().putInt(INITIAL_WIDGET_HEIGHT, initialWidgetHeight)
            .apply()

    var widgetIdToMeasure: Int
        get() = prefs.getInt(WIDGET_ID_TO_MEASURE, 0)
        set(widgetIdToMeasure) = prefs.edit().putInt(WIDGET_ID_TO_MEASURE, widgetIdToMeasure)
            .apply()

    var wasOrangeIconChecked: Boolean
        get() = prefs.getBoolean(WAS_ORANGE_ICON_CHECKED, false)
        set(wasOrangeIconChecked) = prefs.edit()
            .putBoolean(WAS_ORANGE_ICON_CHECKED, wasOrangeIconChecked).apply()

    var wasAppOnSDShown: Boolean
        get() = prefs.getBoolean(WAS_APP_ON_SD_SHOWN, false)
        set(wasAppOnSDShown) = prefs.edit().putBoolean(WAS_APP_ON_SD_SHOWN, wasAppOnSDShown).apply()

    var wasBeforeAskingShown: Boolean
        get() = prefs.getBoolean(WAS_BEFORE_ASKING_SHOWN, false)
        set(wasBeforeAskingShown) = prefs.edit()
            .putBoolean(WAS_BEFORE_ASKING_SHOWN, wasBeforeAskingShown).apply()

    var wasBeforeRateShown: Boolean
        get() = prefs.getBoolean(WAS_BEFORE_RATE_SHOWN, false)
        set(wasBeforeRateShown) = prefs.edit().putBoolean(WAS_BEFORE_RATE_SHOWN, wasBeforeRateShown)
            .apply()

    var wasInitialUpgradeToProShown: Boolean
        get() = prefs.getBoolean(WAS_INITIAL_UPGRADE_TO_PRO_SHOWN, false)
        set(wasInitialUpgradeToProShown) = prefs.edit()
            .putBoolean(WAS_INITIAL_UPGRADE_TO_PRO_SHOWN, wasInitialUpgradeToProShown).apply()

    var wasAppIconCustomizationWarningShown: Boolean
        get() = prefs.getBoolean(WAS_APP_ICON_CUSTOMIZATION_WARNING_SHOWN, false)
        set(wasAppIconCustomizationWarningShown) = prefs.edit()
            .putBoolean(
                WAS_APP_ICON_CUSTOMIZATION_WARNING_SHOWN,
                wasAppIconCustomizationWarningShown
            )
            .apply()

    var appSideloadingStatus: Int
        get() = prefs.getInt(
            APP_SIDELOADING_STATUS,
            SIDELOADING_UNCHECKED
        )
        set(appSideloadingStatus) = prefs.edit()
            .putInt(APP_SIDELOADING_STATUS, appSideloadingStatus).apply()

    var dateFormat: String
        get() = prefs.getString(DATE_FORMAT, getDefaultDateFormat())!!
        set(dateFormat) = prefs.edit().putString(DATE_FORMAT, dateFormat).apply()

    private fun getDefaultDateFormat(): String {
        val format = DateFormat.getDateFormat(context)
        val pattern = (format as SimpleDateFormat).toLocalizedPattern()
        return when (pattern.lowercase().replace(" ", "")) {
            "d.M.y" -> DATE_FORMAT_ONE
            "dd/mm/y" -> DATE_FORMAT_TWO
            "mm/dd/y" -> DATE_FORMAT_THREE
            "y-mm-dd" -> DATE_FORMAT_FOUR
            "dmmmmy" -> DATE_FORMAT_FIVE
            "mmmmdy" -> DATE_FORMAT_SIX
            "mm-dd-y" -> DATE_FORMAT_SEVEN
            "dd-mm-y" -> DATE_FORMAT_EIGHT
            else -> DATE_FORMAT_ONE
        }
    }

    var wasOTGHandled: Boolean
        get() = prefs.getBoolean(WAS_OTG_HANDLED, false)
        set(wasOTGHandled) = prefs.edit().putBoolean(WAS_OTG_HANDLED, wasOTGHandled).apply()

    var wasUpgradedFromFreeShown: Boolean
        get() = prefs.getBoolean(WAS_UPGRADED_FROM_FREE_SHOWN, false)
        set(wasUpgradedFromFreeShown) = prefs.edit()
            .putBoolean(WAS_UPGRADED_FROM_FREE_SHOWN, wasUpgradedFromFreeShown).apply()

    var wasRateUsPromptShown: Boolean
        get() = prefs.getBoolean(WAS_RATE_US_PROMPT_SHOWN, false)
        set(wasRateUsPromptShown) = prefs.edit()
            .putBoolean(WAS_RATE_US_PROMPT_SHOWN, wasRateUsPromptShown).apply()

    var wasAppRated: Boolean
        get() = prefs.getBoolean(WAS_APP_RATED, false)
        set(wasAppRated) = prefs.edit().putBoolean(WAS_APP_RATED, wasAppRated).apply()

    var wasSortingByNumericValueAdded: Boolean
        get() = prefs.getBoolean(WAS_SORTING_BY_NUMERIC_VALUE_ADDED, false)
        set(wasSortingByNumericValueAdded) = prefs.edit().putBoolean(
            WAS_SORTING_BY_NUMERIC_VALUE_ADDED, wasSortingByNumericValueAdded
        ).apply()

    var wasFolderLockingNoticeShown: Boolean
        get() = prefs.getBoolean(WAS_FOLDER_LOCKING_NOTICE_SHOWN, false)
        set(wasFolderLockingNoticeShown) = prefs.edit()
            .putBoolean(WAS_FOLDER_LOCKING_NOTICE_SHOWN, wasFolderLockingNoticeShown).apply()

    var lastRenameUsed: Int
        get() = prefs.getInt(LAST_RENAME_USED, RENAME_SIMPLE)
        set(lastRenameUsed) = prefs.edit().putInt(LAST_RENAME_USED, lastRenameUsed).apply()

    var lastRenamePatternUsed: String
        get() = prefs.getString(LAST_RENAME_PATTERN_USED, "")!!
        set(lastRenamePatternUsed) = prefs.edit()
            .putString(LAST_RENAME_PATTERN_USED, lastRenamePatternUsed).apply()

    var lastExportedSettingsFolder: String
        get() = prefs.getString(LAST_EXPORTED_SETTINGS_FOLDER, "")!!
        set(lastExportedSettingsFolder) = prefs.edit()
            .putString(LAST_EXPORTED_SETTINGS_FOLDER, lastExportedSettingsFolder).apply()

    var lastBlockedNumbersExportPath: String
        get() = prefs.getString(LAST_BLOCKED_NUMBERS_EXPORT_PATH, "")!!
        set(lastBlockedNumbersExportPath) = prefs.edit()
            .putString(LAST_BLOCKED_NUMBERS_EXPORT_PATH, lastBlockedNumbersExportPath).apply()

    var blockUnknownNumbers: Boolean
        get() = prefs.getBoolean(BLOCK_UNKNOWN_NUMBERS, false)
        set(blockUnknownNumbers) = prefs.edit()
            .putBoolean(BLOCK_UNKNOWN_NUMBERS, blockUnknownNumbers).apply()

    var blockHiddenNumbers: Boolean
        get() = prefs.getBoolean(BLOCK_HIDDEN_NUMBERS, false)
        set(blockHiddenNumbers) = prefs.edit().putBoolean(BLOCK_HIDDEN_NUMBERS, blockHiddenNumbers)
            .apply()

    // notify the users about new SMS Messenger and Voice Recorder released
    var wasMessengerRecorderShown: Boolean
        get() = prefs.getBoolean(WAS_MESSENGER_RECORDER_SHOWN, false)
        set(wasMessengerRecorderShown) = prefs.edit()
            .putBoolean(WAS_MESSENGER_RECORDER_SHOWN, wasMessengerRecorderShown).apply()

    var defaultTab: Int
        get() = prefs.getInt(DEFAULT_TAB, TAB_LAST_USED)
        set(defaultTab) = prefs.edit().putInt(DEFAULT_TAB, defaultTab).apply()

    var startNameWithSurname: Boolean
        get() = prefs.getBoolean(START_NAME_WITH_SURNAME, false)
        set(startNameWithSurname) = prefs.edit()
            .putBoolean(START_NAME_WITH_SURNAME, startNameWithSurname).apply()

    var favorites: MutableSet<String>
        get() = prefs.getStringSet(FAVORITES, HashSet())!!
        set(favorites) = prefs.edit().remove(FAVORITES).putStringSet(FAVORITES, favorites).apply()

    var showCallConfirmation: Boolean
        get() = prefs.getBoolean(SHOW_CALL_CONFIRMATION, false)
        set(showCallConfirmation) = prefs.edit()
            .putBoolean(SHOW_CALL_CONFIRMATION, showCallConfirmation).apply()

    // color picker last used colors
    var colorPickerRecentColors: LinkedList<Int>
        get(): LinkedList<Int> {
            val defaultList = arrayListOf(
                context.resources.getColor(R.color.md_red_700),
                context.resources.getColor(R.color.md_blue_700),
                context.resources.getColor(R.color.md_green_700),
                context.resources.getColor(R.color.md_yellow_700),
                context.resources.getColor(R.color.md_orange_700)
            )
            return LinkedList(
                prefs.getString(COLOR_PICKER_RECENT_COLORS, null)?.lines()?.map { it.toInt() }
                    ?: defaultList)
        }
        set(recentColors) = prefs.edit()
            .putString(COLOR_PICKER_RECENT_COLORS, recentColors.joinToString(separator = "\n"))
            .apply()

    var ignoredContactSources: HashSet<String>
        get() = prefs.getStringSet(IGNORED_CONTACT_SOURCES, hashSetOf(".")) as HashSet
        set(ignoreContactSources) = prefs.edit().remove(IGNORED_CONTACT_SOURCES).putStringSet(
            IGNORED_CONTACT_SOURCES, ignoreContactSources
        ).apply()

    var showContactThumbnails: Boolean
        get() = prefs.getBoolean(SHOW_CONTACT_THUMBNAILS, true)
        set(showContactThumbnails) = prefs.edit()
            .putBoolean(SHOW_CONTACT_THUMBNAILS, showContactThumbnails).apply()

    var showPhoneNumbers: Boolean
        get() = prefs.getBoolean(SHOW_PHONE_NUMBERS, false)
        set(showPhoneNumbers) = prefs.edit().putBoolean(SHOW_PHONE_NUMBERS, showPhoneNumbers)
            .apply()

    var showOnlyContactsWithNumbers: Boolean
        get() = prefs.getBoolean(SHOW_ONLY_CONTACTS_WITH_NUMBERS, false)
        set(showOnlyContactsWithNumbers) = prefs.edit()
            .putBoolean(SHOW_ONLY_CONTACTS_WITH_NUMBERS, showOnlyContactsWithNumbers).apply()

    var lastUsedContactSource: String
        get() = prefs.getString(LAST_USED_CONTACT_SOURCE, "")!!
        set(lastUsedContactSource) = prefs.edit()
            .putString(LAST_USED_CONTACT_SOURCE, lastUsedContactSource).apply()

    var onContactClick: Int
        get() = prefs.getInt(
            ON_CONTACT_CLICK,
            ON_CLICK_VIEW_CONTACT
        )
        set(onContactClick) = prefs.edit().putInt(ON_CONTACT_CLICK, onContactClick).apply()

    var showContactFields: Int
        get() = prefs.getInt(
            SHOW_CONTACT_FIELDS,
            SHOW_FIRST_NAME_FIELD or SHOW_SURNAME_FIELD or SHOW_PHONE_NUMBERS_FIELD or SHOW_MESSENGERS_ACTIONS_FIELD or SHOW_EMAILS_FIELD or
                    SHOW_ADDRESSES_FIELD or SHOW_EVENTS_FIELD or SHOW_NOTES_FIELD or SHOW_GROUPS_FIELD or SHOW_CONTACT_SOURCE_FIELD or SHOW_RINGTONE_FIELD or SHOW_ORGANIZATION_FIELD
        )
        set(showContactFields) = prefs.edit().putInt(SHOW_CONTACT_FIELDS, showContactFields).apply()

    var showDialpadButton: Boolean
        get() = prefs.getBoolean(SHOW_DIALPAD_BUTTON, true)
        set(showDialpadButton) = prefs.edit().putBoolean(SHOW_DIALPAD_BUTTON, showDialpadButton)
            .apply()

    var wasLocalAccountInitialized: Boolean
        get() = prefs.getBoolean(WAS_LOCAL_ACCOUNT_INITIALIZED, false)
        set(wasLocalAccountInitialized) = prefs.edit()
            .putBoolean(WAS_LOCAL_ACCOUNT_INITIALIZED, wasLocalAccountInitialized).apply()

    var lastExportPath: String
        get() = prefs.getString(LAST_EXPORT_PATH, "")!!
        set(lastExportPath) = prefs.edit().putString(LAST_EXPORT_PATH, lastExportPath).apply()

    var speedDial: String
        get() = prefs.getString(SPEED_DIAL, "")!!
        set(speedDial) = prefs.edit().putString(SPEED_DIAL, speedDial).apply()

    var swipright: String
        get() = prefs.getString(SWIPETORIGHT, "Mark as Read")!!
        set(speedDial) = prefs.edit().putString(SWIPETORIGHT, speedDial).apply()

    var showPrivateContacts: Boolean
        get() = prefs.getBoolean(SHOW_PRIVATE_CONTACTS, true)
        set(showPrivateContacts) = prefs.edit()
            .putBoolean(SHOW_PRIVATE_CONTACTS, showPrivateContacts).apply()

    var mergeDuplicateContacts: Boolean
        get() = prefs.getBoolean(MERGE_DUPLICATE_CONTACTS, true)
        set(mergeDuplicateContacts) = prefs.edit()
            .putBoolean(MERGE_DUPLICATE_CONTACTS, mergeDuplicateContacts).apply()

    var favoritesContactsOrder: String
        get() = prefs.getString(FAVORITES_CONTACTS_ORDER, "")!!
        set(order) = prefs.edit().putString(FAVORITES_CONTACTS_ORDER, order).apply()

    var isCustomOrderSelected: Boolean
        get() = prefs.getBoolean(FAVORITES_CUSTOM_ORDER_SELECTED, false)
        set(selected) = prefs.edit().putBoolean(FAVORITES_CUSTOM_ORDER_SELECTED, selected).apply()

    var viewType: Int
        get() = prefs.getInt(VIEW_TYPE, VIEW_TYPE_LIST)
        set(viewType) = prefs.edit().putInt(VIEW_TYPE, viewType).apply()

    var contactsGridColumnCount: Int
        get() = prefs.getInt(CONTACTS_GRID_COLUMN_COUNT, getDefaultContactColumnsCount())
        set(contactsGridColumnCount) = prefs.edit()
            .putInt(CONTACTS_GRID_COLUMN_COUNT, contactsGridColumnCount).apply()

    private fun getDefaultContactColumnsCount(): Int {
        val isPortrait =
            context.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        return if (isPortrait) {
            context.resources.getInteger(R.integer.contacts_grid_columns_count_portrait)
        } else {
            context.resources.getInteger(R.integer.contacts_grid_columns_count_landscape)
        }
    }

    var autoBackup: Boolean
        get() = prefs.getBoolean(AUTO_BACKUP, false)
        set(autoBackup) = prefs.edit().putBoolean(AUTO_BACKUP, autoBackup).apply()

    var autoBackupFolder: String
        get() = prefs.getString(
            AUTO_BACKUP_FOLDER,
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath
        )!!
        set(autoBackupFolder) = prefs.edit().putString(AUTO_BACKUP_FOLDER, autoBackupFolder).apply()


    var autoBackupFilename: String
        get() = prefs.getString(AUTO_BACKUP_FILENAME, "")!!
        set(autoBackupFilename) = prefs.edit().putString(AUTO_BACKUP_FILENAME, autoBackupFilename)
            .apply()

    var ringtoneUri: String
        get() = prefs.getString(RINGTONEURI, "")!!
        set(autoBackupFilename) = prefs.edit().putString(RINGTONEURI, autoBackupFilename).apply()


    var themenameuri: String
        get() = prefs.getString(THEMENAMEURI, "")!!
        set(autoBackupFilename) = prefs.edit().putString(THEMENAMEURI, autoBackupFilename).apply()


    var lastAutoBackupTime: Long
        get() = prefs.getLong(LAST_AUTO_BACKUP_TIME, 0L)
        set(lastAutoBackupTime) = prefs.edit().putLong(LAST_AUTO_BACKUP_TIME, lastAutoBackupTime)
            .apply()

    var passwordRetryCount: Int
        get() = prefs.getInt(PASSWORD_RETRY_COUNT, 0)
        set(passwordRetryCount) = prefs.edit().putInt(PASSWORD_RETRY_COUNT, passwordRetryCount)
            .apply()

    var passwordCountdownStartMs: Long
        get() = prefs.getLong(PASSWORD_COUNTDOWN_START_MS, 0L)
        set(passwordCountdownStartMs) = prefs.edit()
            .putLong(PASSWORD_COUNTDOWN_START_MS, passwordCountdownStartMs).apply()


    //Goodwy
    var settingsIcon: Int
        get() = prefs.getInt(SETTINGS_ICON, 1)
        set(settingsIcon) = prefs.edit().putInt(SETTINGS_ICON, settingsIcon).apply()

    var overflowIcon: Int
        get() = prefs.getInt(
            OVERFLOW_ICON,
            OVERFLOW_ICON_HORIZONTAL
        )
        set(overflowIcon) = prefs.edit().putInt(OVERFLOW_ICON, overflowIcon).apply()

    var screenSlideAnimation: Int
        get() = prefs.getInt(SCREEN_SLIDE_ANIMATION, 1)
        set(screenSlideAnimation) = prefs.edit()
            .putInt(SCREEN_SLIDE_ANIMATION, screenSlideAnimation).apply()

    var materialDesign3: Boolean
        get() = prefs.getBoolean(MATERIAL_DESIGN3, false)
        set(materialDesign3) = prefs.edit().putBoolean(MATERIAL_DESIGN3, materialDesign3).apply()

    var useRelativeDate: Boolean
        get() = prefs.getBoolean(USE_RELATIVE_DATE, false)
        set(useRelativeDate) = prefs.edit().putBoolean(USE_RELATIVE_DATE, useRelativeDate).apply()

    var colorSimIcons: Boolean
        get() = prefs.getBoolean(COLOR_SIM_ICON, false)
        set(colorSimIcons) = prefs.edit().putBoolean(COLOR_SIM_ICON, colorSimIcons).apply()

    var enableOtpView: Boolean
        get() = prefs.getBoolean("SETTINGS_OTP_ICONS", true)
        set(enableOtpView) = prefs.edit().putBoolean("SETTINGS_OTP_ICONS", enableOtpView).apply()

    var settingsFingerprtOn: Boolean
        get() = prefs.getBoolean("SETTINGS_FINGERPRT_ON", false)
        set(settingsFingerprOn) = prefs.edit()
            .putBoolean("SETTINGS_FINGERPRT_ON", settingsFingerprOn).apply()

    var privateNotification: Boolean
        get() = prefs.getBoolean("PRIVATE_NOTIFICATION", true)
        set(privatenotification) = prefs.edit()
            .putBoolean("PRIVATE_NOTIFICATION", privatenotification).apply()

    var hideEntranceSwitchStatus: Boolean
        get() = prefs.getBoolean("HIDE_ENTRANCE_SWITCH_STATUS", false)
        set(entranceSwitchStatus) = prefs.edit()
            .putBoolean("HIDE_ENTRANCE_SWITCH_STATUS", entranceSwitchStatus).apply()

    // Tab bar
    var bottomNavigationBar: Boolean
        get() = prefs.getBoolean(BOTTOM_NAVIGATION_BAR, true)
        set(bottomNavigationBar) = prefs.edit()
            .putBoolean(BOTTOM_NAVIGATION_BAR, bottomNavigationBar).apply()

    var transparentNavigationBar: Boolean
        get() = prefs.getBoolean(TRANSPARENT_NAVI_BAR, true)
        set(transparentNavigationBar) = prefs.edit()
            .putBoolean(TRANSPARENT_NAVI_BAR, transparentNavigationBar).apply()

    var appRecommendationDialogCount: Int
        get() = prefs.getInt(APP_RECOMMENDATION_DIALOG_COUNT, 3)
        set(appRecommendationDialogCount) = prefs.edit()
            .putInt(APP_RECOMMENDATION_DIALOG_COUNT, appRecommendationDialogCount).apply()

    var openSearch: Boolean
        get() = prefs.getBoolean(OPEN_SEARCH, false)
        set(openSearch) = prefs.edit().putBoolean(OPEN_SEARCH, openSearch).apply()

//    var isPro: Boolean
//        get() = prefs.getBoolean(IS_PRO_VERSION, true)
//        set(isPro) = prefs.edit().putBoolean(IS_PRO_VERSION, isPro).apply()

//    var isProSubs: Boolean
//        get() = prefs.getBoolean(IS_PRO_SUBS_VERSION, false)
//        set(isProSubs) = prefs.edit().putBoolean(IS_PRO_SUBS_VERSION, isProSubs).apply()
//
//    var isProRuStore: Boolean
//        get() = prefs.getBoolean(IS_PRO_RUSTORE_VERSION, false)
//        set(isProSubs) = prefs.edit().putBoolean(IS_PRO_RUSTORE_VERSION, isProSubs).apply()

    var simIconsColors: LinkedList<Int>
        get(): LinkedList<Int> {
            val defaultList = arrayListOf(
                context.resources.getColor(R.color.md_red_500),
                context.resources.getColor(R.color.ic_dialer),
                context.resources.getColor(R.color.color_primary),
                context.resources.getColor(R.color.md_yellow_500),
                context.resources.getColor(R.color.md_orange_500)
            )
            return LinkedList(prefs.getString(SIM_ICON_COLORS, null)?.lines()?.map { it.toInt() }
                ?: defaultList)
        }
        set(simIconsColors) = prefs.edit()
            .putString(SIM_ICON_COLORS, simIconsColors.joinToString(separator = "\n")).apply()

    var textCursorColor: Int
        get() = prefs.getInt(TEXT_CURSOR_COLOR, -2)
        set(textCursorColor) = prefs.edit().putInt(TEXT_CURSOR_COLOR, textCursorColor).apply()

    var linesCount: Int
        get() = prefs.getInt(LINES_COUNT, 2)
        set(linesCount) = prefs.edit().putInt(LINES_COUNT, linesCount).apply()

    var showBlockedNumbers: Boolean
        get() = prefs.getBoolean(SHOW_BLOCK_NUMBERS, false)
        set(showBlockedNumbers) = prefs.edit().putBoolean(SHOW_BLOCK_NUMBERS, showBlockedNumbers)
            .apply()

    var showButtonBlockedNumbers: Boolean
        get() = prefs.getBoolean(SHOW_BUTTON_BLOCK_NUMBERS, false)
        set(showButtonBlockedNumbers) = prefs.edit()
            .putBoolean(SHOW_BUTTON_BLOCK_NUMBERS, showButtonBlockedNumbers).apply()

    var flashForAlerts: Boolean
        get() = prefs.getBoolean(FLASH_FOR_ALERTS, false)
        set(flashForAlerts) = prefs.edit().putBoolean(FLASH_FOR_ALERTS, flashForAlerts).apply()

    var useGooglePlay: Boolean
        get() = prefs.getBoolean(USE_GOOGLE_PLAY, false)
        set(useGooglePlay) = prefs.edit().putBoolean(USE_GOOGLE_PLAY, useGooglePlay).apply()

    var currentSIMCardIndex: Int
        get() = prefs.getInt(CURRENT_SIM_CARD_INDEX, 0) //0 - sim1, 1 - sim2
        set(currentSIMCardIndex) = prefs.edit().putInt(CURRENT_SIM_CARD_INDEX, currentSIMCardIndex)
            .apply()

    var isUsingAccentColor: Boolean
        get() = prefs.getBoolean(
            IS_USING_ACCENT_COLOR,
            context.resources.getBoolean(R.bool.using_accent_color)
        )
        set(isUsingAccentColor) = prefs.edit().putBoolean(IS_USING_ACCENT_COLOR, isUsingAccentColor)
            .apply()

    var topAppBarColored: Boolean
        get() = prefs.getBoolean(TOP_APP_BAR_COLORED, false)
        set(topAppBarColored) = prefs.edit().putBoolean(TOP_APP_BAR_COLORED, topAppBarColored)
            .apply()


    var topAppBarColorIcon: Boolean
        get() = prefs.getBoolean(TOP_APP_BAR_COLOR_ICON, false)
        set(topAppBarColorIcon) = prefs.edit()
            .putBoolean(TOP_APP_BAR_COLOR_ICON, topAppBarColorIcon).apply()


    var topAppBarColorTitle: Boolean
        get() = prefs.getBoolean(TOP_APP_BAR_COLOR_TITLE, false)
        set(topAppBarColorTitle) = prefs.edit()
            .putBoolean(TOP_APP_BAR_COLOR_TITLE, topAppBarColorTitle).apply()


    var autoBackupTime: Int
        get() = prefs.getInt(AUTO_BACKUP_TIME, 360)
        set(autoBackupTime) = prefs.edit().putInt(AUTO_BACKUP_TIME, autoBackupTime).apply()

    var autoBackupInterval: Int
        get() = prefs.getInt(AUTO_BACKUP_INTERVAL, 10)
        set(autoBackupInterval) = prefs.edit().putInt(AUTO_BACKUP_INTERVAL, autoBackupInterval)
            .apply()

    var nextAutoBackupTime: Long
        get() = prefs.getLong(NEXT_AUTO_BACKUP_TIME, 0L)
        set(nextAutoBackupTime) = prefs.edit().putLong(NEXT_AUTO_BACKUP_TIME, nextAutoBackupTime)
            .apply()

    var sortingSymbolsFirst: Boolean
        get() = prefs.getBoolean(SORT_SYMBOLS_FIRST, true)
        set(sortingSymbolsFirst) = prefs.edit().putBoolean(SORT_SYMBOLS_FIRST, sortingSymbolsFirst)
            .apply()

    var hideTopBarWhenScroll: Boolean
        get() = prefs.getBoolean(HIDE_TOP_BAR_WHEN_SCROLL, false)
        set(hideTopBarWhenScroll) = prefs.edit()
            .putBoolean(HIDE_TOP_BAR_WHEN_SCROLL, hideTopBarWhenScroll).apply()

    var skipArchiveConfirmation: Boolean
        get() = prefs.getBoolean(SKIP_ARCHIVE_CONFIRMATION, false)
        set(skipArchiveConfirmation) = prefs.edit()
            .putBoolean(SKIP_ARCHIVE_CONFIRMATION, skipArchiveConfirmation).apply()
    var skipprivateConfirmation: Boolean
        get() = prefs.getBoolean(SKIP_PRIVATE_CONFIRMATION, false)
        set(skipArchiveConfirmation) = prefs.edit()
            .putBoolean(SKIP_PRIVATE_CONFIRMATION, skipArchiveConfirmation).apply()

    var useSwipeToAction: Boolean
        get() = prefs.getBoolean(USE_SWIPE_TO_ACTION, true)
        set(swipeToAction) = prefs.edit().putBoolean(USE_SWIPE_TO_ACTION, swipeToAction).apply()


    fun bitmapToBase64(bitmap: Bitmap): String {
        val byteArrayOutputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)
        val byteArray = byteArrayOutputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.DEFAULT)
    }

    fun base64ToBitmap(base64String: String): Bitmap {
        val decodedString = Base64.decode(base64String, Base64.DEFAULT)
        return BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
    }

    fun setSelectedItems(selectedItems: List<String>) {
        val json = Gson().toJson(selectedItems)
        prefs.edit().putString("selectedItems", json).apply()
    }

    fun getSelectedItems(): List<String> {
        val json = prefs.getString("selectedItems", null)
        return Gson().fromJson(json, object : TypeToken<List<String>>() {}.type) ?: emptyList()
    }


}


