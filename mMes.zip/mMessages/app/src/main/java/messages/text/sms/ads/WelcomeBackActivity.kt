package messages.text.sms.ads

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import messages.text.sms.common.MysmsApplication
import messages.text.sms.common.MysmsApplication.Companion.adsApplication
import messages.text.sms.databinding.ActivityWelcomeBackBinding
import java.util.Timer
import kotlin.concurrent.timerTask

class WelcomeBackActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWelcomeBackBinding
    var isAdShow = false
    var isTimeOver = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWelcomeBackBinding.inflate(layoutInflater)

        if (!isInternetConnected()) {
            finish()
            return
        }
        setContentView(binding.root)
        firebaseAnalyticsHandler.logMessages(app_appopen_created, "WelcomeBackActivity")

        if (adsApplication.isLoadingAppOpen()) {
            finishAdsTimer()
            startAdsCheckingTimer()
        } else {
            if (adsApplication.isAdAvailable()) {
                finishTimer?.cancel()
                adCheckingTimer?.cancel()
                isAdShow = true
                firebaseAnalyticsHandler.logMessages(app_ad_appopen_shown, "WelcomeBackActivity")
                adsApplication.showAdIfAvailable(this@WelcomeBackActivity,
                    object : MysmsApplication.OnShowAdCompleteListener {
                        override fun onShowAdComplete() {
                            finish()
                        }

                    })

            } else {
                finishAdsTimer()
//                adsApplication.loadAd(this, getAppResumeAppOpenId())
//                startAdsCheckingTimer()
            }
        }
    }

    private var adCheckingTimer: Timer? = null
    fun startAdsCheckingTimer() {
        val timeOut = 200L
        adCheckingTimer?.cancel()
        adCheckingTimer = Timer()
        adCheckingTimer?.schedule(timerTask {
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (adsApplication.isAdAvailable()) {
                    finishTimer?.cancel()
                    adCheckingTimer?.cancel()
                    isAdShow = true
                    firebaseAnalyticsHandler.logMessages(
                        app_ad_appopen_shown,
                        "WelcomeBackActivity"
                    )
                    adsApplication.showAdIfAvailable(this@WelcomeBackActivity,
                        object : MysmsApplication.OnShowAdCompleteListener {
                            override fun onShowAdComplete() {
                                finish()
                            }

                        })
                }
            }
        }, timeOut, timeOut)

    }

    private var finishTimer: Timer? = null
    fun finishAdsTimer() {
        val timeOut = 200L
        finishTimer?.cancel()
        finishTimer = Timer()
        finishTimer?.schedule(timerTask {
            finishTimer?.cancel()
            isTimeOver = true
            if (!isAdShow) {
                firebaseAnalyticsHandler.logMessages(app_ad_appopen_failed, "WelcomeBackActivity")
                finish()
            }
        }, timeOut, timeOut)

    }

    override fun onPause() {
        super.onPause()
        if (!adsApplication.isAdShowing()) {
            firebaseAnalyticsHandler.logMessages(app_ad_appopen_failed, "WelcomeBackActivity")
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        if (isTimeOver) {
            firebaseAnalyticsHandler.logMessages(app_ad_appopen_failed, "WelcomeBackActivity")
            finish()
        }
    }
}