package messages.text.sms.feature.conversationinfo

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat
import com.bluelinelabs.conductor.Conductor
import com.bluelinelabs.conductor.Router
import com.bluelinelabs.conductor.RouterTransaction
import com.gallery.mvvm.ads.GoogleNativeAdConversionInfoHelper
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.ads.AdsPreferences
import messages.text.sms.ads.app_ad_language_native_failed
import messages.text.sms.ads.app_ad_language_native_show
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.ads.getAppConversionInfoNative
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.ContainerActivityBinding
import messages.text.sms.model.DELETE_FROM_INFO
import messages.text.sms.model.MessageEvent
import messages.text.sms.util.appPreference
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class ConversationInfoActivity : MainBaseThemedActivity() {

    private val binding by viewBinding(ContainerActivityBinding::inflate)
    private lateinit var router: Router

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this)
        binding.mainNativeView.visibility = View.VISIBLE
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)
        setTitle(R.string.info_title)
        showBackButton(true)

        router = Conductor.attachRouter(this, binding.container, savedInstanceState)
        if (!router.hasRootController()) {
            val threadId = intent.extras?.getLong("threadId") ?: 0L
            val isPrivate = intent.extras?.getBoolean("isPrivate") ?: false
            router.setRoot(RouterTransaction.with(ConversationInfoController(threadId, isPrivate)))
        }

        setUpTheme()

        if (AdsPreferences(this).adsEnable) {
            binding.frameNative.beVisible()
            loadNative()
        } else {
            binding.frameNative.beGone()
        }

    }


    private fun loadNative() {

        GoogleNativeAdConversionInfoHelper(
            this,
            binding.frameNative,
            getAppConversionInfoNative()
        ) { isLoaded ->
            if (isLoaded) {
                binding.mainNativeView.visibility = View.VISIBLE
                firebaseAnalyticsHandler.logMessages(
                    app_ad_language_native_show, getActivityName()
                )
            } else {
                binding.mainNativeView.visibility = View.GONE
                firebaseAnalyticsHandler.logMessages(
                    app_ad_language_native_failed, getActivityName()
                )
            }
        }.loadAd()
    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")

        updateTextColors(binding.contentView)
        //  binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))

        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)

        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }

    override fun onBackPressed() {
        if (!router.handleBack()) {
            super.onBackPressed()
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.type) {
            DELETE_FROM_INFO -> {
                val threadId = intent.extras?.getLong("threadId") ?: 0L
                val threadIdEvent = event.data as Long
                if (threadIdEvent == threadId) {
                    appPreference.isRefreshMessages = true
                    appPreference.isRefreshArchiveMessages = true
                    finish()
                }
            }
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        if (EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().unregister(this)
    }
}