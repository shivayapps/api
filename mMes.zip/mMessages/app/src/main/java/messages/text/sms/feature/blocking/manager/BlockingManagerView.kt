package messages.text.sms.feature.blocking.manager

import io.reactivex.Observable
import io.reactivex.Single
import messages.text.sms.common.base.MainBaseMsgViewContract

interface BlockingManagerView : MainBaseMsgViewContract<BlockingManagerState> {

    fun activityResumed(): Observable<*>
    fun qksmsClicked(): Observable<*>
//    fun callControlClicked(): Observable<*>
//    fun siaClicked(): Observable<*>

    fun showCopyDialog(manager: String): Single<Boolean>

}
