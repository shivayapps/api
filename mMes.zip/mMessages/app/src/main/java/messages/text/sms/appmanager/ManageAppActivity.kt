package messages.text.sms.appmanager

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.ads.nativead.NativeAd
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import messages.text.sms.R
import messages.text.sms.ads.AdmobNative
import messages.text.sms.ads.AdmobNative.nativeAdManageApps
import messages.text.sms.ads.app_manage_apps_screen2_open
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.databinding.ActivityManageAppBinding

class ManageAppActivity : AppCompatActivity() {

    private lateinit var appListAdapter: AppListAdapter
    private lateinit var launcherViewModel: LauncherViewModel // Instantiate ViewModel

    companion object {
        var totalStoppedCount = 0
        var stoppedAppList = ArrayList<String>()
    }

    lateinit var binding: ActivityManageAppBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityManageAppBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Assuming updateTextColors is a valid function in your project
        // If not, remove or implement it.
        // updateTextColors(binding.clManageApp)

        launcherViewModel = LauncherViewModel() // Initialize ViewModel

        setupToolbar()
        resetAppTrackingData()
        setupListeners()
        loadAndShowAds()
        updateStatusBarColor()
        loadInstalledApps()
        showRAMUsage()
        logAnalyticsEvent()
    }

    private fun setupToolbar() {
        binding.customizationToolbar.setBackgroundColor(Color.TRANSPARENT)
        binding.customizationToolbar.title = getString(R.string.manage_apps)
        setSupportActionBar(binding.customizationToolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.customizationToolbar.setNavigationOnClickListener {
            onBackPressed()
        }
    }

    private fun resetAppTrackingData() {
        stoppedAppList.clear()
        totalStoppedCount = 0
    }

    private fun setupListeners() {
        binding.btnOk.setOnClickListener {
            if (stoppedAppList.isNotEmpty()) {
                // Ensure unique package names and count them
                val uniqueStoppedApps = stoppedAppList.toSet()
                totalStoppedCount = uniqueStoppedApps.size
                stoppedAppList.clear() // Clear and add unique ones back if needed elsewhere
                stoppedAppList.addAll(uniqueStoppedApps)
            }
            startActivity(
                Intent(
                    this,
                    FinalManageAppScreenActivity::class.java
                )
            ) // Assuming FinalManageAppScreenActivity
            finish()
        }
    }

    private fun loadAndShowAds() {
        if (nativeAdManageApps != null) {
            showAds(nativeAdManageApps)
        } else {
            loadNative()
        }
    }

    private fun updateStatusBarColor() {
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary)
    }

    private fun loadInstalledApps() {
        binding.loader.visibility = View.VISIBLE

        // Use lifecycleScope for coroutines tied to the activity's lifecycle
        lifecycleScope.launch(Dispatchers.Main) {
            launcherViewModel.retrieveInstalledApps(this@ManageAppActivity) { apps ->
                if (apps.isNotEmpty()) {
                    appListAdapter = AppListAdapter(
                        this@ManageAppActivity,
                        apps,
                        object : AppListAdapter.IAppLaunchListener {
                            override fun onAppSelected(appModel: AppModel) {
                                // Add/remove based on selection state, for now just add
                                if (!stoppedAppList.contains(appModel.packageName)) {
                                    stoppedAppList.add(appModel.packageName)
                                }
                                Log.e("ManageAppActivity", "App selected: " + appModel.packageName)
                            }
                            // Assuming you might need an onAppDeselected if checkboxes are used
                            // If this is a single-select or toggle, you might adjust logic.
                        })

                    binding.rvAppList.adapter = appListAdapter

                    binding.appsCount.text = getString(R.string.total_g, apps.size.toString())

                    binding.loader.visibility = View.GONE
                } else {
                    binding.loader.visibility = View.GONE
                    // Handle case where no apps are found or error occurred
                    Log.d("ManageAppActivity", "No apps found or error during retrieval.")
                }
            }
        }
    }

    private fun showRAMUsage() {
        val totalRamValue = Utility.totalRamMemorySize(this)
        val freeRamValue = Utility.freeRamMemorySize(this)
        val usedRamValue = totalRamValue - freeRamValue

        val usedPercent = Utility.calculatePercentage(usedRamValue, totalRamValue).toFloat()
        binding.tvPercent.text = usedPercent.toInt().toString() // Display as integer percentage
        // If your string resource R.string.apps_in_total expects one argument, use it like this:
        // binding.appsCount.text = getString(R.string.apps_in_total, it.size.toString())
    }

    private fun loadNative() {
        binding.inNative.shimmerView.startShimmer()
        // Removed delayExecution, let AdmobNative handle its own timing or rely on its callback
        AdmobNative.preLoad(this, { isLoaded, nativeAd ->
            showAds(nativeAd)
        }, Utility.getAppManageAppsNative()) // Assuming getAppManageAppsNative is in Utility
    }

    private fun showAds(nativeAd: NativeAd?) {
        if (nativeAd != null) {
            AdmobNative.populateManageAppNativeAd(this, binding.inNative.cvRoot, nativeAd)
        } else {
            binding.adView.visibility = View.GONE
            binding.inNative.shimmerView.stopShimmer()
        }
    }

    private fun logAnalyticsEvent() {
        firebaseAnalyticsHandler.logMessages(
            app_manage_apps_screen2_open,
            Utility.getActivityName(this) // Assuming getActivityName is in Utility
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        nativeAdManageApps?.destroy()
        nativeAdManageApps = null
    }
}
