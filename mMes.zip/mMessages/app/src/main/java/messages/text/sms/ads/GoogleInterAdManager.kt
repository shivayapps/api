package  messages.text.sms.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import messages.text.sms.ads.MainInterAdManager.showInterTime
import messages.text.sms.common.MysmsApplication.Companion.isHomeInterShow
import messages.text.sms.common.isAdsNotShowOnResume
import java.util.Date

object GoogleInterAdManager {

    var mInterstitialAd: InterstitialAd? = null
    private var mInterstitialAdGeneral: InterstitialAd? = null

    var mInterstitialAdMain: InterstitialAd? = null


    var tapCount = 0
    private var adLoadTimestamp: Long = 0L
    private var isAdLoading = false

    fun showGeneralInterAdsCountUpdate(int: Int) {
        tapCount = int
    }


//    fun showGeneralInterAds(activity: Activity, dismissCallback: () -> Unit, forward: Boolean) {
//
//        val adTempLoadTimestamp = System.currentTimeMillis()
//        if (forward) {
//            if (mInterstitialAdGeneral != null) {
//                val differenceInSeconds = (adTempLoadTimestamp - adLoadTimestamp) / 1000
//                if (differenceInSeconds > AdsPreferences(activity).maxTapTime && tapCount >= AdsPreferences(
//                        activity
//                    ).maxTapCount
//                ) {
//                    showGeneralInter(activity, dismissCallback)
//                    tapCount = 0
//                } else {
//                    tapCount++
//                    dismissCallback.invoke()
//                }
//            } else {
//
//                if (tapCount >= 1) {
//                    val adId =
//                        if (activity.isFirstTimeAppOpen()) activity.getAppHomeInter() else activity.getAppHomeInter()
//                    loadAdGeneral(activity, adId)
//                }
//                tapCount++
//
//                dismissCallback.invoke()
//            }
//        } else {
//            if (mInterstitialAdGeneral == null) {
//                if (tapCount >= 1) {
//                    val adId =
//                        if (activity.isFirstTimeAppOpen()) activity.getAppHomeInter() else activity.getAppHomeInter()
//                    loadAdGeneral(activity, adId)
//                }
//            }
//            tapCount++
//            dismissCallback.invoke()
//        }
//    }

    fun loadAdMain(activity: Context, adId: String) {

        if (mInterstitialAdMain != null || adId.isEmpty()) return

        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(activity, adId, adRequest, object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(interstitialAd: InterstitialAd) {
//                Log.e("LLL_Splash : ", "InterstitialAd Loaded")
                mInterstitialAdMain = interstitialAd
            }

            override fun onAdFailedToLoad(loadAdError: LoadAdError) {
//                Log.e("LLL_Splash : ", "InterstitialAd Failed => " + loadAdError.message)
                mInterstitialAdMain = null

            }
        })
    }

    fun loadAdGeneral(activity: Context, adId: String) {

        if (mInterstitialAdGeneral != null || adId.isEmpty() || AdsPreferences(activity).isPro || isAdLoading) return
        isAdLoading = true
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(activity, adId, adRequest, object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(interstitialAd: InterstitialAd) {
                Log.e("LLL_Splash : ", "InterstitialAd Loaded")
                mInterstitialAdGeneral = interstitialAd
                isAdLoading = false
            }

            override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                Log.e("LLL_Splash : ", "InterstitialAd Failed => " + loadAdError.message)
                mInterstitialAdGeneral = null
                isAdLoading = false
            }
        })
    }

    fun showMainInterAds(activity: Activity, dismissCallback: () -> Unit) {
        if (mInterstitialAdMain != null && !isHomeInterShow) {
            showMainInter(activity, dismissCallback)
        } else {
            dismissCallback.invoke()
        }
    }


    fun langInterLoaded(): Boolean {
        if (mInterstitialAdGeneral != null) {
            return true
        } else {
            return false
        }
    }


    fun showGeneralInterAds(activity: Activity, dismissCallback: () -> Unit, forward: Boolean) {
        try {
            if (mInterstitialAdGeneral != null) {
                showGeneralInter(activity, dismissCallback)
            } else {
                dismissCallback.invoke()
            }
        } catch (e: Exception) {
            dismissCallback.invoke()
        }
    }


    fun loadManageAppsInter(activity: Activity) {
        if (mInterstitialAd != null || AdsPreferences(activity).isPro) return
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            activity,
            activity.getAppManageAppsInter(),
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(interstitialAd: InterstitialAd) {
//                    Log.e("LLL_Splash : ", "InterstitialAd Loaded")
                    mInterstitialAd = interstitialAd
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
//                    Log.e("LLL_Splash : ", "InterstitialAd Failed => " + loadAdError.message)
                    mInterstitialAd = null
                }
            })
    }


    fun showManageAppsInter(activity: Activity, dismissCallback: () -> Unit) {
        if (mInterstitialAd != null) {
            mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    super.onAdShowedFullScreenContent()
                    isAdsNotShowOnResume = true
                    activity.firebaseAnalyticsHandler.logMessages(
                        app_ad_inter_shown,
                        activity.getActivityName()
                    )
                }

                override fun onAdDismissedFullScreenContent() {
                    super.onAdDismissedFullScreenContent()
                    mInterstitialAd = null
                    isAdsNotShowOnResume = false
                    dismissCallback.invoke()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    isAdsNotShowOnResume = false
                    mInterstitialAd = null
                    dismissCallback.invoke()
                }

                override fun onAdImpression() {}
                override fun onAdClicked() {
                    super.onAdClicked()
                    isAdsNotShowOnResume = true
                }
            }
            mInterstitialAd!!.show(activity)
            activity.firebaseAnalyticsHandler.logMessages(
                app_inter_created,
                activity.getActivityName()
            )

        } else {
            dismissCallback.invoke()
        }
    }

    fun showGeneralInter(activity: Activity, dismissCallback: () -> Unit) {
        if (mInterstitialAdGeneral != null || !AdsPreferences(activity).isPro) {
            mInterstitialAdGeneral!!.fullScreenContentCallback =
                object : FullScreenContentCallback() {
                    override fun onAdShowedFullScreenContent() {
                        super.onAdShowedFullScreenContent()
                        isAdsNotShowOnResume = true
                        showInterTime = Date().time
                        adLoadTimestamp = System.currentTimeMillis()
//                        Log.e("LLL_Splash : ", "onAdShowedFullScreenContent")
                    }

                    override fun onAdDismissedFullScreenContent() {
                        super.onAdDismissedFullScreenContent()
                        mInterstitialAdGeneral = null
                        isAdsNotShowOnResume = false
                        dismissCallback.invoke()
                        showInterTime = Date().time
//                        Log.e("LLL_Splash : ", "onAdDismissedFullScreenContent")

                    }

                    override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                        isAdsNotShowOnResume = false
                        mInterstitialAdGeneral = null
                        dismissCallback.invoke()
                        showInterTime = Date().time
//                        Log.e("LLL_Splash : ", "onAdFailedToShowFullScreenContent")

                    }

                    override fun onAdImpression() {

//                        Log.e("LLL_Splash : ", "onAdImpression")
                    }

                    override fun onAdClicked() {
                        super.onAdClicked()
                        isAdsNotShowOnResume = true
//              /          Log.e("LLL_Splash : ", "onAdClicked")
                    }
                }
            mInterstitialAdGeneral!!.show(activity)
            activity.firebaseAnalyticsHandler.logMessages(
                app_inter_created,
                activity.getActivityName()
            )
            activity.firebaseAnalyticsHandler.logMessages(
                app_ad_inter_shown,
                activity.getActivityName()
            )
        } else {
            dismissCallback.invoke()
        }
    }

    fun showMainInter(activity: Activity, dismissCallback: () -> Unit) {
        if (mInterstitialAdMain != null) {
            mInterstitialAdMain!!.fullScreenContentCallback =
                object : FullScreenContentCallback() {
                    override fun onAdShowedFullScreenContent() {
                        super.onAdShowedFullScreenContent()
                        isAdsNotShowOnResume = true
                        showInterTime = Date().time
                        adLoadTimestamp = System.currentTimeMillis()
//                        Log.e("LLL_Splash : ", "onAdShowedFullScreenContent")
                    }

                    override fun onAdDismissedFullScreenContent() {
                        super.onAdDismissedFullScreenContent()
                        mInterstitialAdMain = null
                        isAdsNotShowOnResume = false
                        dismissCallback.invoke()
                        showInterTime = Date().time
//                        Log.e("LLL_Splash : ", "onAdDismissedFullScreenContent")

                    }

                    override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                        isAdsNotShowOnResume = false
                        mInterstitialAdMain = null
                        dismissCallback.invoke()
                        showInterTime = Date().time
//                        Log.e("LLL_Splash : ", "onAdFailedToShowFullScreenContent")

                    }

                    override fun onAdImpression() {

//                        Log.e("LLL_Splash : ", "onAdImpression")
                    }

                    override fun onAdClicked() {
                        super.onAdClicked()
                        isAdsNotShowOnResume = true
//              /          Log.e("LLL_Splash : ", "onAdClicked")
                    }
                }
            mInterstitialAdMain!!.show(activity)
            activity.firebaseAnalyticsHandler.logMessages(
                app_inter_created,
                activity.getActivityName()
            )
            activity.firebaseAnalyticsHandler.logMessages(
                app_ad_inter_shown,
                activity.getActivityName()
            )
        } else {
            dismissCallback.invoke()
        }
    }

    fun onDestroy() {
        mInterstitialAd = null
        mInterstitialAdGeneral = null
        mInterstitialAdMain = null
    }

}