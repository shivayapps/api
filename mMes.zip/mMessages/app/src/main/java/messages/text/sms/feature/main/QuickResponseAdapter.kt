package messages.text.sms.feature.main

import android.content.Context
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R


class QuickResponseAdapter(
    val mQuickMessagesList: MutableList<String>,
    private val context: Context,
    val onClick: (String, Boolean) -> Unit,
    val onSelect: (Boolean) -> Unit,
    private val onStartDrag: (RecyclerView.ViewHolder) -> Unit,
) : RecyclerView.Adapter<QuickResponseAdapter.MessageViewHolder>() {

    val selectedItems = mutableSetOf<String>()
    var isSelectionMode = false

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_quick_response, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val message = mQuickMessagesList[position]
        holder.messageTextView.text = message

        val isSelected = selectedItems.contains(message)

        holder.quickSelect.visibility = if (isSelectionMode) View.VISIBLE else View.GONE
        holder.moveButton.visibility = if (isSelectionMode) View.GONE else View.VISIBLE
        holder.quickSelect.setImageResource(if (isSelected) R.drawable.ic_select_qk_msg else R.drawable.ic_un_select_qk_msg)

        holder.itemView.setOnClickListener {
            if (isSelectionMode) {
                toggleSelection(message)
            } else {
                onClick(message, false)
            }
            onSelect(selectedItems.isNotEmpty())
        }

        holder.itemView.setOnLongClickListener {
            enableSelectionMode()
            toggleSelection(message)
            onSelect(selectedItems.isNotEmpty())
            true
        }



        holder.moveButton.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                onStartDrag(holder)
            }
            false
        }
    }

    override fun getItemCount() = mQuickMessagesList.size

    fun enableSelectionMode() {
        isSelectionMode = true
        notifyDataSetChanged()
    }

    fun toggleSelection(message: String) {
        if (selectedItems.contains(message)) {
            selectedItems.remove(message)
        } else {
            selectedItems.add(message)
        }
        notifyDataSetChanged()
        onSelect(selectedItems.isNotEmpty())
    }

    fun clearSelections() {
        selectedItems.clear()
        isSelectionMode = false
        notifyDataSetChanged()
        onSelect(false)
    }

    fun selectAll() {
        selectedItems.clear()
        selectedItems.addAll(mQuickMessagesList)
        notifyDataSetChanged()
        onSelect(true)  // Ensure UI updates correctly
    }


    fun deleteSelectedItems(allClear: (Boolean) -> Unit) {
        mQuickMessagesList.removeAll(selectedItems)
        clearSelections()
        allClear(true)
    }

    class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val messageTextView: TextView = itemView.findViewById(R.id.messageTextView)
        val moveButton: ImageView = itemView.findViewById(R.id.moveButton)
        val quickSelect: ImageView = itemView.findViewById(R.id.quickSelect)


    }


}


