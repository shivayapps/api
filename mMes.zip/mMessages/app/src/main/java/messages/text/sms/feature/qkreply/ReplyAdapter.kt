package messages.text.sms.feature.qkreply

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R

class ReplyAdapter(
    private val data: List<String>,
    private val onEdit: (Int) -> Unit,
    private val onSelect: (Int) -> Unit,
    private var manageMode: Boolean,
) : RecyclerView.Adapter<ReplyAdapter.VH>() {

    private var selectedIndex = 0
    private var isDisabled = false

    fun setManageMode(enabled: Boolean) {
        manageMode = enabled
        notifyDataSetChanged()
    }

    fun setDisabled(disabled: Boolean) {
        isDisabled = disabled
        notifyDataSetChanged()
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val text = view.findViewById<TextView>(R.id.replyText)
        val toggle = view.findViewById<RadioButton>(R.id.replyToggle)
        val edit = view.findViewById<ImageView>(R.id.editBtn)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.item_reply_message, parent, false)
        return VH(view)
    }

    override fun getItemCount(): Int = data.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.text.text = data[position]
        holder.toggle.isChecked = selectedIndex == position
        holder.toggle.isEnabled = !isDisabled
        holder.toggle.setOnClickListener {
            if (!isDisabled) {
                selectedIndex = position
                onSelect(position)
                notifyDataSetChanged()
            }
        }

        holder.edit.visibility = if (manageMode) View.VISIBLE else View.GONE
        holder.edit.setOnClickListener { onEdit(position) }
    }
}
