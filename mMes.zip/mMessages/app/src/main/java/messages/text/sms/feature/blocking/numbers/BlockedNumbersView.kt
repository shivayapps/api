package messages.text.sms.feature.blocking.numbers

import io.reactivex.Observable
import messages.text.sms.common.base.MainBaseMsgViewContract

interface BlockedNumbersView : MainBaseMsgViewContract<BlockedNumbersState> {

    fun unblockAddress(): Observable<Long>
    fun addAddress(): Observable<*>
    fun saveAddress(): Observable<String>

    fun showAddDialog()

}
