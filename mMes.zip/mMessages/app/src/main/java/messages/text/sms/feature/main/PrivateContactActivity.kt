package messages.text.sms.feature.main

import android.content.Intent
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import dagger.android.AndroidInjection
import io.realm.Realm
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.config
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.ActivityPrivateContactBinding
import messages.text.sms.feature.main.models.Contact
import messages.text.sms.feature.main.ui.ContactPickerActivity
import messages.text.sms.model.Conversation
import messages.text.sms.password.AddContactDialog
import messages.text.sms.password.AddPhoneNumberDialog
import messages.text.sms.password.DialogCallback
import messages.text.sms.util.StringManager
import javax.inject.Inject

class PrivateContactActivity : MainBaseThemedActivity() {
    private val binding by viewBinding(ActivityPrivateContactBinding::inflate)

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory
    lateinit var contactList: List<String>

    private val viewModel by lazy {
        ViewModelProviders.of(
            this,
            viewModelFactory
        )[MainViewModel::class.java]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        showBackButton(true)

        // Set the theme color tint to the recyclerView, progressbar, and FAB
        theme
            .autoDisposable(scope())
            .subscribe { theme ->
                // Set the color for the drawer icons
                val states = arrayOf(
                    intArrayOf(android.R.attr.state_activated),
                    intArrayOf(-android.R.attr.state_activated)
                )


                // Miscellaneous views
//                listOf(binding.drawer.plusBadge1, binding.drawer.plusBadge2).forEach { badge ->
//                    badge.setBackgroundTint(theme.theme)
//                    badge.setTextColor(theme.textPrimary)
//                }
            }

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        initListener()
        setUpTheme()

    }


    override fun onResume() {
        super.onResume()

        title = getString(R.string.private_contacts)


        Log.e("privateContactsList", "onResume: ${baseConfig.privateContactsList}")

        if (baseConfig.privateContactsList.replace(",", "").replace(" ", "").isNotEmpty()) {
            contactList = baseConfig.privateContactsList
                .split(",")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .distinct()

            Log.e("privateContactsList", "onResume: ${contactList.size}")

            val adapter = PrivateConversationsAdapter(contactList)
            binding.recyclerView.adapter = adapter


            val savedContactString = contactList.joinToString(",") { it }
            baseConfig.privateContactsList = savedContactString
            binding.noData.visibility = View.GONE
        } else {
            val adapter = PrivateConversationsAdapter(emptyList())
            binding.recyclerView.adapter = adapter
            binding.noData.visibility = View.VISIBLE
        }
    }

    private fun setUpTheme() {
        updateTextColors(binding.contentView)
        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource != -1) {
//                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
//                binding.contentView.background = drawable
//                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))

                if (baseConfig.storedImageResource == 111) {
                    val stringManager = StringManager(this)
                    val imageBitmap = stringManager.getSavedThemeBitmaps().last()
                    val drawable = BitmapDrawable(resources, imageBitmap)
                    binding.contentView.background = drawable
                    toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
                } else {
                    val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                    binding.contentView.background = drawable
                    toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
                }
            }
        } else {
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }
    }

    private fun initListener() {
        binding.addPrivate.setOnClickListener {
            AddContactDialog(
                this,
                getString(R.string.add_private_contacts),
                object : DialogCallback {
                override fun onItemClick(position: Int) {
                    when (position) {
                        1 -> {
                            startActivity(
                                Intent(
                                    this@PrivateContactActivity,
                                    ConversationsPickerActivity::class.java
                                ).putExtra("from", "private")
                            )
                        }

                        2 -> {
                            ContactPicker.open(this@PrivateContactActivity, "private")

                        }

                        3 -> {
                            val addPhoneNumberDialog =
                                AddPhoneNumberDialog(config, this@PrivateContactActivity, object :
                                    AddPhoneNumberDialog.AddPhoneNumberListener {
                                    override fun addNumber(result: String) {
                                        if (result?.isNotEmpty() == true) {
                                            if (baseConfig.privateContactsList.isEmpty()) {
                                                baseConfig.privateContactsList = result
                                            } else {
                                                baseConfig.privateContactsList =
                                                    baseConfig.privateContactsList + "," + result
                                            }

                                            contactList = baseConfig.privateContactsList
                                                .split(",")
                                                .map { it.trim() }
                                                .filter { it.isNotEmpty() }
                                                .distinct()

                                            Log.e(
                                                "privateContactsList",
                                                "onResume: ${contactList.size}"
                                            )

                                            for (item in contactList) {
                                                setPrivate(item)
                                            }

                                            val adapter = PrivateConversationsAdapter(contactList)
                                            binding.recyclerView.adapter = adapter



                                        }

                                    }
                                })
                            addPhoneNumberDialog.show()
                        }
                    }
                }
            })
        }
    }

    fun setPrivate(phoneNumber: String) {
        Realm.getDefaultInstance().use { realm ->
            realm.executeTransaction {
                val conversations = realm.where(Conversation::class.java)
                    .findAll()

                conversations.filter {
                    it.getTitle().replace(" ", "").endsWith(phoneNumber.trim().replace(" ", ""))
                }
                    .forEach { it.isPrivate = true }
            }

            realm.close()
        }
    }




    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == ContactPickerActivity.RC_CONTACT_PICKER) {
            val result = data?.getParcelableExtra<Contact>(ContactPickerActivity.EXTRA_CONTACT_DATA)
            Log.d("Picker", result?.name + " " + result?.phone)

            if (result?.name?.isNotEmpty() == true) {
                if (baseConfig.privateContactsList.isEmpty()) {
                    baseConfig.privateContactsList = result.name.toString()
                } else {
                    baseConfig.privateContactsList =
                        baseConfig.privateContactsList + "," + result.name
                }
            } else if (result?.phone?.isNotEmpty() == true) {
                if (baseConfig.privateContactsList.isEmpty()) {
                    baseConfig.privateContactsList = result.phone.toString()
                } else {
                    baseConfig.privateContactsList =
                        baseConfig.privateContactsList + "," + result.phone
                }
            }

            result?.name?.let { setPrivate(it) }
            onResume()
        }
    }

    class PrivateConversationsAdapter(private var contacts: List<String>) :
        RecyclerView.Adapter<PrivateConversationsAdapter.ContactViewHolder>() {

        class ContactViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val title: TextView = itemView.findViewById(R.id.title)
            val remove: TextView = itemView.findViewById(R.id.remove)
        }

        // Inflate the layout and create the ViewHolder
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_conversation, parent, false)
            return ContactViewHolder(view)
        }

        override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
            val contact = contacts[position]
            holder.title.text = contact
            holder.remove.setOnClickListener {

                val updatedList = contacts.filter { it != contact }
                contacts = updatedList
                val savedContactString = updatedList.joinToString(",") { it }
                holder.remove.context.baseConfig.privateContactsList = savedContactString
                setPublic(contact)
                notifyDataSetChanged()

                //   viewModel.markRemovePrivateBox.execute(conversations)
            }
        }

        override fun getItemCount(): Int = contacts.size

        private fun setPublic(threadIds: String) {
            Realm.getDefaultInstance().use { realm ->
                val conversations = realm.where(Conversation::class.java)
                    .equalTo("isPrivate", true)
                    .findAll()
                realm.executeTransaction {
                    conversations.forEach {
                        if (it.getTitle().equals(threadIds)) {
                            it.isPrivate = false
                        }
                    }
                }

                realm.close()
            }
        }
    }
}
