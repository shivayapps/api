package messages.text.sms.interactor

import io.reactivex.Flowable
import messages.text.sms.manager.ShortcutManager
import messages.text.sms.repository.ConversationRepository
import javax.inject.Inject

class MarkUnpinned @Inject constructor(
    private val conversationRepo: ConversationRepository,
    private val updateBadge: UpdateBadge,
    private val shortcutManager: ShortcutManager,
) : Interactor<List<Long>>() {

    override fun buildObservable(params: List<Long>): Flowable<*> {
        return Flowable.just(params.toLongArray())
            .doOnNext { threadIds -> conversationRepo.markUnpinned(*threadIds) }
            .doOnNext { shortcutManager.updateShortcuts() } // Update shortcuts
            .flatMap { updateBadge.buildObservable(Unit) } // Update the badge and widget
    }

}
