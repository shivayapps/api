package messages.text.sms.mapper

import android.database.Cursor
import messages.text.sms.model.Contact

interface CursorToContact : Mapper<Cursor, Contact> {

    fun getContactsCursor(): Cursor?

}