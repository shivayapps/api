package messages.text.sms.commons.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.model.Ringtone

class RingtoneListAdapter(
    private val context: Context,
    private val ringtoneList: ArrayList<Ringtone>,
    private val listener: (String, Int) -> Unit,
) :
    RecyclerView.Adapter<RingtoneListAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_layout_ringtone, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        context.updateTextColors(holder.llmain)
        holder.fontTextView.text = ringtoneList[position].name


        holder.ringtoneItemImage.setImageResource(ringtoneList.get(position).image)


        holder.im_check.setTint(context.baseConfig.primaryColor)

        if (position == context.baseConfig.ringtoneSelected) {
            holder.imCheckMain.visibility = View.VISIBLE
        } else {
            holder.imCheckMain.visibility = View.GONE
        }
    }

    override fun getItemCount(): Int {
        return ringtoneList.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val fontTextView: TextView = itemView.findViewById(R.id.item_text)
        val im_check: ImageView = itemView.findViewById(R.id.im_check)
        val imCheckMain: RelativeLayout = itemView.findViewById(R.id.imCheckMain)
        val llmain: ConstraintLayout = itemView.findViewById(R.id.llmain)
        val ringtoneItemImage: ImageView = itemView.findViewById(R.id.ringtoneItemImage)

        init {
            itemView.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val fontName = ringtoneList.get(position).name


                    listener.invoke(fontName, position)
                }
            }
        }

    }

}
