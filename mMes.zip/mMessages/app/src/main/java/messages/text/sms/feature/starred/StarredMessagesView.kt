package messages.text.sms.feature.starred

import io.reactivex.Observable
import messages.text.sms.common.base.MainBaseMsgView
import messages.text.sms.model.Message

interface StarredMessagesView : MainBaseMsgView<StarredMessagesState> {
    val conversationClicks: Observable<Message>
    fun requestDefaultSms()
}
