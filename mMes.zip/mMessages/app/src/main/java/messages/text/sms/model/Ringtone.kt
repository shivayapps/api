package messages.text.sms.model

data class Ringtone(
    val name: String,
    val image: Int,
    val sound: Int,
)