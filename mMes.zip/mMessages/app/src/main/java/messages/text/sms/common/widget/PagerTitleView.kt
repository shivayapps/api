package messages.text.sms.common.widget

import android.content.Context
import android.content.res.ColorStateList
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.TextView
import androidx.viewpager.widget.ViewPager
import com.uber.autodispose.android.ViewScopeProvider
import com.uber.autodispose.autoDisposable
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.extensions.forEach
import messages.text.sms.common.util.extensions.resolveThemeColor
import messages.text.sms.databinding.TabViewBinding
import messages.text.sms.extensions.Optional
import messages.text.sms.injection.appComponent
import messages.text.sms.repository.ConversationRepository
import javax.inject.Inject

class PagerTitleView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    LinearLayout(context, attrs) {

    @Inject
    lateinit var colors: Colors

    @Inject
    lateinit var conversationRepo: ConversationRepository

    private val recipientId: Subject<Long> = BehaviorSubject.create()

    var pager: ViewPager? = null
        set(value) {
            if (field !== value) {
                field = value
                recreate()
            }
        }

    init {
        if (!isInEditMode) appComponent.inject(this)
    }

    fun setRecipientId(id: Long) {
        recipientId.onNext(id)
    }

    private fun recreate() {
        removeAllViews()

        pager?.adapter?.count?.forEach { position ->
            val binding = TabViewBinding.inflate(LayoutInflater.from(context), this, false)
            binding.label.text = pager?.adapter?.getPageTitle(position)
            binding.root.setOnClickListener { pager?.currentItem = position }

            addView(binding.root)
        }

        childCount.forEach { index ->
            getChildAt(index).isActivated = index == pager?.currentItem
        }

        pager?.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() {
            override fun onPageSelected(position: Int) {
                childCount.forEach { index ->
                    getChildAt(index).isActivated = index == position
                }
            }
        })
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()

        val states = arrayOf(
            intArrayOf(android.R.attr.state_activated),
            intArrayOf(-android.R.attr.state_activated)
        )

        recipientId
            .distinctUntilChanged()
            .map { recipientId -> Optional(conversationRepo.getRecipient(recipientId)) }
            .switchMap { recipient -> colors.themeObservable(recipient.value) }
            .map { theme ->
                val textSecondary = context.resolveThemeColor(android.R.attr.textColorSecondary)
                ColorStateList(states, intArrayOf(theme.theme, textSecondary))
            }
            .autoDisposable(ViewScopeProvider.from(this))
            .subscribe { colorStateList ->
                childCount.forEach { index ->
                    (getChildAt(index) as? TextView)?.setTextColor(colorStateList)
                }
            }
    }

}
