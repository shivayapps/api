package messages.text.sms.mapper

interface Mapper<in From, out To> {

    fun map(from: From): To

}
