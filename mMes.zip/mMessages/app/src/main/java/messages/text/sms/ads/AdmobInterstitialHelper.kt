package messages.text.sms.ads

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import messages.text.sms.commons.extensions.clientConfigPref

object AdmobInterstitialHelper {

    private const val TAG = "AdmobInterstitial"
    private const val TIMEOUT_MS = 10_000L

    fun loadAndShowInterstitial(
        activity: Activity,
        adUnitId: String,
        onAdDismissed: () -> Unit,
        onAdFailed: () -> Unit,
    ) {

        var callbackHandled = false
        val handler = Handler(Looper.getMainLooper())

        fun failOnce(reason: String) {
            if (callbackHandled) return
            callbackHandled = true
            Log.e(TAG, reason)
            activity.hideLoaderDialog()
            onAdFailed()
        }

        fun successOnce() {
            if (callbackHandled) return
            callbackHandled = true
            activity.hideLoaderDialog()
        }


        // 🔄 Show loader immediately
        activity.showLoaderDialog(activity.clientConfigPref.languageInterstitialMessage)

        // ⏱ Timeout fallback (AdMob silent failure protection)
        val timeoutRunnable = Runnable {
            failOnce("Interstitial timeout after 10 seconds")
        }
        handler.postDelayed(timeoutRunnable, TIMEOUT_MS)

        val adRequest = AdRequest.Builder().build()

        InterstitialAd.load(
            activity,
            adUnitId,
            adRequest,
            object : InterstitialAdLoadCallback() {

                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    if (callbackHandled) return

                    Log.d(TAG, "Interstitial loaded")
                    handler.removeCallbacks(timeoutRunnable)
                    successOnce()

                    interstitialAd.fullScreenContentCallback =
                        object : FullScreenContentCallback() {

                            override fun onAdDismissedFullScreenContent() {
                                Log.d(TAG, "Interstitial dismissed")
                                onAdDismissed()
                            }

                            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                                Log.e(TAG, "Failed to show: ${adError.message}")
                                onAdFailed()
                            }
                        }

                    interstitialAd.show(activity)
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    handler.removeCallbacks(timeoutRunnable)
                    failOnce("Load failed: ${loadAdError.message}")
                }
            }
        )
    }
}