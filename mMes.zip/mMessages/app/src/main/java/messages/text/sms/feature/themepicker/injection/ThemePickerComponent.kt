package messages.text.sms.feature.themepicker.injection

import dagger.Subcomponent
import messages.text.sms.feature.themepicker.ThemePickerController
import messages.text.sms.injection.scope.ControllerScope

@ControllerScope
@Subcomponent(modules = [ThemePickerModule::class])
interface ThemePickerComponent {

    fun inject(controller: ThemePickerController)

    @Subcomponent.Builder
    interface Builder {
        fun themePickerModule(module: ThemePickerModule): Builder
        fun build(): ThemePickerComponent
    }

}