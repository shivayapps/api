package messages.text.sms.feature.compose.part

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.viewbinding.ViewBinding
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.common.util.Colors
import messages.text.sms.model.Message
import messages.text.sms.model.MmsPart

abstract class PartBinder<Binding : ViewBinding>(
    val bindingInflater: (LayoutInflater, ViewGroup, Boolean) -> Binding,
) {

    val clicks: Subject<Long> = PublishSubject.create()

    abstract var theme: Colors.Theme

    fun <T : ViewBinding> bindPart(
        holder: MainBaseMsgViewHolder<T>,
        part: MmsPart,
        message: Message,
        canGroupWithPrevious: Boolean,
        canGroupWithNext: Boolean,
    ): Boolean {
        val castHolder = holder as? MainBaseMsgViewHolder<Binding>

        if (!canBindPart(part) || castHolder == null) {
            return false
        }

        bindPartInternal(castHolder, part, message, canGroupWithPrevious, canGroupWithNext)

        return true
    }

    abstract fun canBindPart(part: MmsPart): Boolean

    protected abstract fun bindPartInternal(
        holder: MainBaseMsgViewHolder<Binding>,
        part: MmsPart,
        message: Message,
        canGroupWithPrevious: Boolean,
        canGroupWithNext: Boolean,
    )

}

