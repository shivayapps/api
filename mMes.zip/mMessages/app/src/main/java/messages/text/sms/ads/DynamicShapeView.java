package messages.text.sms.ads;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;

import androidx.core.content.ContextCompat;

import messages.text.sms.R;

public class DynamicShapeView extends androidx.appcompat.widget.AppCompatButton {

    private Paint paint;

    public DynamicShapeView(Context context) {
        super(context);
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setStrokeWidth(getResources().getDimension(R.dimen._2sdp));
        paint.setColor(ContextCompat.getColor(getContext(), R.color.primary));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // Calculate the shape size and position based on the view's dimensions
        float centerX = getWidth() / 2;
        float centerY = getHeight() / 2;
        float radius = Math.min(centerX, centerY) - 15; // Adjust the radius to leave some padding

        // Draw the rounded rectangle
        canvas.drawRoundRect(centerX - radius, centerY - radius,
                centerX + radius, centerY + radius, 15, 15, paint);
    }

    // Method to update the stroke color
    public void setStrokeColor(int color) {
        paint.setColor(color);
        invalidate(); // Redraw the view to apply the change
    }
}