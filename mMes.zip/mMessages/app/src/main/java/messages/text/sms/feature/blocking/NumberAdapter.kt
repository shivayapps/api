package messages.text.sms.feature.blocking

import android.graphics.Color
import android.graphics.PorterDuff
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.databinding.ItemNumberBinding
import messages.text.sms.feature.main.models.Contact

class NumberAdapter(
    private val contacts: ArrayList<Contact>,
    private val onDeleteClick: (Int) -> Unit,
    private val onItemLongPress: () -> Unit,
    private val onItemPress: (Int) -> Unit,
) : RecyclerView.Adapter<NumberAdapter.ViewHolder>() {

    private var isMultiSelectMode = false
    private val selectedItems = mutableSetOf<Int>()
    var multiSelectEmptyListener: (() -> Unit)? = null

    inner class ViewHolder(val binding: ItemNumberBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(contact: Contact, position: Int) {
            binding.name.text = contact.name
            binding.tvKeyword.text = contact.phone
            binding.tvKeyword.visibility =
                if (contact.name == contact.phone) View.GONE else View.VISIBLE

            binding.btnDelete.visibility = if (isMultiSelectMode) View.GONE else View.VISIBLE
            binding.radio.visibility = if (isMultiSelectMode) View.VISIBLE else View.GONE
            binding.btnDelete.setText(R.string.unblock)
            binding.btnDelete.setTextColor(binding.btnDelete.context.baseConfig.primaryColor)

            binding.root.setOnClickListener {
                if (isMultiSelectMode) {
                    toggleSelection(position)
                } else {
                    onDeleteClick(position)
                }
                onItemPress(selectedItems.size)
            }

            binding.root.setOnLongClickListener {
                if (!isMultiSelectMode) {
                    onItemLongPress()
                    toggleSelection(position)
                }
                true
            }

            val isSelected = selectedItems.contains(position)

            if (isSelected) {

                val iconDrawable =
                    ContextCompat.getDrawable(binding.radio.context, R.drawable.ic_select_qk_msg)
                iconDrawable?.setTint(binding.radio.context.baseConfig.primaryColor)
                binding.radio.setImageDrawable(iconDrawable)

            } else {

                binding.radio.setImageResource(R.drawable.ic_un_select_qk_msg)
            }

            val color = colorMap.getOrPut(position) {
                colors[position % colors.size]
            }
            binding.iconBg.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        }
    }

    private val colors = listOf(
        Color.parseColor("#34C759"),
        Color.parseColor("#AF52DE"),
        Color.parseColor("#FF9500"),
        Color.parseColor("#FF3B30"),
        Color.parseColor("#4285F4"),
        Color.parseColor("#FBBC05"),
        Color.parseColor("#34A853")
    )
    private val colorMap = mutableMapOf<Int, Int>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemNumberBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(contacts[position], position)
    }

    override fun getItemCount(): Int = contacts.size

    fun setMultiSelectMode(enabled: Boolean) {
        isMultiSelectMode = enabled
        if (!enabled) selectedItems.clear()
        notifyDataSetChanged()
    }

    fun toggleSelection(position: Int) {
        if (selectedItems.contains(position)) {
            selectedItems.remove(position)
        } else {
            selectedItems.add(position)
        }
        notifyItemChanged(position)

        if (isMultiSelectMode && selectedItems.isEmpty()) {
            multiSelectEmptyListener?.invoke()
        }
    }

    fun getSelectedContacts(): List<Contact> {
        return selectedItems.mapNotNull { contacts.getOrNull(it) }
    }

    fun selectedAllContacts(selectAll: Boolean) {
        selectedItems.clear()

        when {
            selectAll == true -> {
                // Select all
                contacts.forEachIndexed { index, contact ->
                    if (!selectedItems.contains(index)) {
                        selectedItems.add(index)
                    }
                }
            }

            selectAll == false -> {
                selectedItems.clear()
                multiSelectEmptyListener?.invoke()
            }
        }
        notifyDataSetChanged()
    }


    fun addItem(contact: Contact) {
        contacts.add(contact)
        notifyItemInserted(contacts.lastIndex)
    }

    fun removeItem(position: Int) {
        if (position in contacts.indices) {
            contacts.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, contacts.size)
        }
    }

    fun clearAll() {
        contacts.clear()
        notifyDataSetChanged()
    }

    fun getItems(): ArrayList<Contact> = contacts
}

