package messages.text.sms.feature.main

import android.Manifest
import android.animation.ObjectAnimator
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import androidx.appcompat.view.ContextThemeWrapper
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import com.jakewharton.rxbinding2.view.clicks
import com.jakewharton.rxbinding2.widget.textChanges
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import io.realm.Realm
import io.realm.RealmResults
import messages.text.sms.R
import messages.text.sms.ads.GoogleSmallNativeAdManagerPrivate
import messages.text.sms.ads.GoogleSmallNativeAdManagerPrivate.loadSmallNative4Private
import messages.text.sms.ads.GoogleSmallNativeAdManagerPrivate.loadSmallNative8Private
import messages.text.sms.ads.GoogleSmallNativeAdManagerPrivate.loadSmallNativePrivate
import messages.text.sms.ads.app_private_conversations_open
import messages.text.sms.ads.delayExecution
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.ads.getAppListNative2
import messages.text.sms.ads.getAppPrivateNative1
import messages.text.sms.ads.getAppPrivateNative3
import messages.text.sms.ads.isInternetConnected
import messages.text.sms.common.BubbleListener
import messages.text.sms.common.FastScroller
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.autoScrollToStart
import messages.text.sms.common.util.extensions.dismissKeyboard
import messages.text.sms.common.util.extensions.resolveThemeColor
import messages.text.sms.common.util.extensions.scrapViews
import messages.text.sms.common.util.extensions.setBackgroundTint
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.common.widget.QkDialog
import messages.text.sms.commons.extensions.addAlpha
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.commons.extensions.config
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.ActivityPrivateConversationsBinding
import messages.text.sms.extensions.Optional
import messages.text.sms.feature.blocking.BlockingDialog
import messages.text.sms.feature.compose.ComposeActivity
import messages.text.sms.feature.compose.editing.PhoneNumberAction
import messages.text.sms.feature.compose.editing.PhoneNumberPickerAdapter
import messages.text.sms.feature.contacts.ContactsActivity.Companion.ChipsKey
import messages.text.sms.feature.contacts.GroupsActivity
import messages.text.sms.feature.conversations.ConversationItemTouchCallback
import messages.text.sms.feature.conversations.PrivateConversationsAdapter
import messages.text.sms.feature.main.models.Contact
import messages.text.sms.feature.main.ui.ContactPickerActivity
import messages.text.sms.model.ContactData
import messages.text.sms.model.ContactGroup
import messages.text.sms.model.Conversation
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.REFRESH_CONTACT_GROUP
import messages.text.sms.model.REFRESH_MESSAGE
import messages.text.sms.model.SYNC_MESSAGE
import messages.text.sms.model.THEME_CHANGED
import messages.text.sms.password.AddContactDialog
import messages.text.sms.password.AddPhoneNumberDialog
import messages.text.sms.password.DialogCallback
import messages.text.sms.password.PrivateSettingsActivity
import messages.text.sms.repository.SyncRepository
import messages.text.sms.util.appPreference
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import javax.inject.Inject

class PrivateConversationsActivity : MainBaseThemedActivity(), MainView {
    private val binding by viewBinding(ActivityPrivateConversationsBinding::inflate)
//    lateinit var binding :MainActivityBinding

    @Inject
    lateinit var blockingDialog: BlockingDialog

    @Inject
    lateinit var disposables: CompositeDisposable

    @Inject
    lateinit var navigator: Navigator

    @Inject
    lateinit var conversationsAdapter: PrivateConversationsAdapter

    @Inject
    lateinit var drawerBadgesExperiment: DrawerBadgesExperiment

    @Inject
    lateinit var searchAdapter: SearchAdapter

    @Inject
    lateinit var itemTouchCallback: ConversationItemTouchCallback

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    override val onNewIntentIntent: Subject<Intent> = PublishSubject.create()
    override val activityResumedIntent: Subject<Boolean> = PublishSubject.create()
    override val queryConversationChangedIntent by lazy { binding.messageTab.toolbarSearch.textChanges() }
    override val composeIntent by lazy { binding.messageTab.compose.clicks() }

    override val homeIntent: Subject<Unit> = PublishSubject.create()
    override val navigationIntent: Observable<NavItem> by lazy {
        Observable.merge(
            listOf(
                backPressedSubject,
            )
        )
    }
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()

    //    override val dismissRatingIntent by lazy { binding.drawer.rateDismiss.clicks() }
//    override val rateIntent by lazy { binding.drawer.rateOkay.clicks() }
    override val conversationsSelectedIntent by lazy { conversationsAdapter.selectionChanges }
    override val confirmDeleteIntent: Subject<List<Long>> = PublishSubject.create()
    override val swipeConversationIntent by lazy { itemTouchCallback.swipes }
    override val undoArchiveIntent: Subject<Unit> = PublishSubject.create()
    override val refreshArchive: Subject<Unit> = PublishSubject.create()
    override val refreshMessages: Subject<Unit> = PublishSubject.create()
    override val refreshBlocked: Subject<Unit> = PublishSubject.create()

    //    override val queryChangedIntent: Observable<CharSequence> by lazy { binding.contactTab.searchContact.textChanges() }
//    override val queryClearedIntent: Observable<*> by lazy { binding.contactTab.cancel.clicks() }
//    override val queryEditorActionIntent: Observable<Int> by lazy { binding.contactTab.searchContact.editorActions() }
    override val queryChangedIntent: Observable<CharSequence> get() = PublishSubject.create<CharSequence>()
    override val queryClearedIntent: Observable<*> get() = PublishSubject.create<Unit>()
    override val queryEditorActionIntent: Observable<Int> get() = PublishSubject.create<Int>()

    override val phoneNumberSelectedIntent: Subject<Optional<Long>> by lazy { phoneNumberAdapter.selectedItemChanges }
    override val phoneNumberActionIntent: Subject<PhoneNumberAction> = PublishSubject.create()
    override val composeItemPressedIntent: Subject<ContactData> = PublishSubject.create()
    override val composeItemLongPressedIntent: Subject<ContactData> = PublishSubject.create()

    override val setAsDefaultClick by lazy { binding.messageTab.snackbar.btnSetDefault.clicks() }

    private val viewModel by lazy {
        ViewModelProviders.of(
            this,
            viewModelFactory
        )[PrivateBoxViewModel::class.java]
    }
    private val itemTouchHelper by lazy { ItemTouchHelper(itemTouchCallback) }
    private val progressAnimator by lazy {
        ObjectAnimator.ofInt(
            binding.messageTab.syncing.syncingProgress,
            "progress",
            0,
            0
        )
    }
    private val backPressedSubject: Subject<NavItem> = PublishSubject.create()
//    private var isSnackBarClosed = false

    @Inject
    lateinit var phoneNumberAdapter: PhoneNumberPickerAdapter
    private val phoneNumberDialog by lazy {
        QkDialog(this).apply {
            titleRes = R.string.compose_number_picker_title
            adapter = phoneNumberAdapter
            positiveButton = R.string.compose_number_picker_always
            positiveButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.ALWAYS) }
            negativeButton = R.string.compose_number_picker_once
            negativeButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.JUST_ONCE) }
            cancelListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.CANCEL) }

        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
//        binding=MainActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        viewModel.bindView(this)
        if (!isInternetConnected()) {
            conversationsAdapter.isLoadingAd = false
        }
        onNewIntentIntent.onNext(intent)
        setSupportActionBar(binding.toolbar)


        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)


        showBackButton(true)
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this)


        itemTouchCallback.adapter = conversationsAdapter
        conversationsAdapter.autoScrollToStart(binding.messageTab.recyclerView)

        // Don't allow clicks to pass through the drawer layout
//        binding.drawer.root.clicks().autoDisposable(scope()).subscribe()
        binding.messageTab.snackbar.llDefault.background = backgroundchange()
        binding.messageTab.snackbar.llDefault.beGone()
//        binding.messageTab.snackbar.llOverlay.beGone()
//        binding.messageTab.snackbar.root.beGone()
        binding.messageTab.syncing.root.beGone()


        Log.d("SMSAppCheck", "------ Default SMS Package:")

        // Set the theme color tint to the recyclerView, progressbar, and FAB
        theme
            .autoDisposable(scope())
            .subscribe { theme ->
                // Set the color for the drawer icons
                val states = arrayOf(
                    intArrayOf(android.R.attr.state_activated),
                    intArrayOf(-android.R.attr.state_activated)
                )

                resolveThemeColor(android.R.attr.textColorSecondary)
                    .let { textSecondary ->
                        ColorStateList(
                            states,
                            intArrayOf(theme.theme, textSecondary)
                        )
                    }
                    .let { tintList ->
//                        binding.drawer.inboxIcon.imageTintList = tintList
                        binding.messageTab.archivedIcon.imageTintList = tintList
                    }

                binding.messageTab.syncing.syncingProgress?.progressTintList =
                    ColorStateList.valueOf(theme.theme)
                binding.messageTab.syncing.syncingProgress?.indeterminateTintList =
                    ColorStateList.valueOf(theme.theme)
                binding.messageTab.compose.setBackgroundTint(theme.theme)
//                binding.messageTab.compose.setTint(theme.textPrimary)

                binding.messageTab.compose.imageTintList = ColorStateList.valueOf(theme.textPrimary)
            }

        viewModel.newState {
            val conv = conversationRepo.getPrivateConversations()
            copy(page = Archived(data = conv))
        }
        initListener()
        setUpTheme()

        binding.messageTab.rlToolbar.visibility = View.GONE
        if (isInternetConnected()) {
            requestAd()
        }

        firebaseAnalyticsHandler.logMessages(
            app_private_conversations_open, getActivityName()
        )
    }


    private fun requestAd() {

        delayExecution(300) {
            conversationsAdapter.isLoadingAd = true
            loadSmallNativePrivate(this, getAppPrivateNative1()) {
                var isFirstNativeLoaded = false
                if (it != null) {
                    isFirstNativeLoaded = true
                    notifyItem(0)
                    //conversationsAdapter.notifyItemChanged(0, "refresh_ad")
                }

                if (conversationsAdapter.itemCount > 4) {

                    loadSmallNative4Private(this, getAppListNative2()) { secondNative ->
                        var isSecondNativeLoaded = false
                        if (secondNative != null) {
                            isSecondNativeLoaded = true
                            notifyItem(4)
                            if (!isFirstNativeLoaded) {
                                isFirstNativeLoaded = true
                                conversationsAdapter.notifyItemChanged(0)
                                notifyItem(0)
                            }
                        }
                        if (conversationsAdapter.itemCount > 8) {
                            loadSmallNative8Private(this, getAppPrivateNative3()) { thirdNative ->
                                conversationsAdapter.isLoadingAd = false
                                if (!isFirstNativeLoaded) {
                                    notifyItem(0)
                                }
                                if (!isSecondNativeLoaded) {
                                    notifyItem(4)
                                }
                                notifyItem(8)
                            }
                        } else {
                            if (!isSecondNativeLoaded) {
                                conversationsAdapter.isLoadingAd = false
                                //  notifyItem(0)
                                notifyItem(4)
                            }
                        }
                    }
                } else {
                    if (!isFirstNativeLoaded) {
                        conversationsAdapter.isLoadingAd = false
                        notifyItem(0)
                    }
                }

            }
        }
    }

    private fun notifyItem(position: Int) {
        binding.messageTab.recyclerView.post {
            conversationsAdapter.notifyItemChanged(position)
        }
    }

    private fun setUpTheme() {
        val primaryColorWithAlpha =
            ColorUtils.setAlphaComponent(baseConfig.primaryColor, (255 * 0.1).toInt())
        val textColorPrimaryss = baseConfig.textColor
        val colorWithAlpha = textColorPrimaryss.addAlpha(0.6F)

        binding.messageTab.toolbarSearch.setBackgroundTint(primaryColorWithAlpha)
        binding.messageTab.toolbarSearch.setHintTextColor(colorWithAlpha)
        updateTextColors(binding.contentView)
        //  binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
            binding.llBottomAction.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
            arrayListOf(
                binding.ivDelete,
                binding.ivMore,
                binding.ivRemovePrivateBox,
//                binding.ivBlock
            ).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.white)
                val colorStateList = ColorStateList.valueOf(Color.WHITE)
                it.imageTintList = colorStateList
            }
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
            binding.llBottomAction.background = ColorDrawable(baseConfig.statusBarColor)
            arrayListOf(
                binding.ivDelete,
                binding.ivMore,
                binding.ivRemovePrivateBox,
//                binding.ivBlock
            ).forEach {
//                val whiteColor = ContextCompat.getColor(this, R.color.black)
                val colorStateList = ColorStateList.valueOf(Color.BLACK)
                it.imageTintList = colorStateList
            }
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }

    private fun initListener() {

        binding.llDelete.setOnClickListener {
            optionsItemIntent.onNext(R.id.delete)
        }

        binding.llRemovePrivateBox.setOnClickListener {
            optionsItemIntent.onNext(R.id.llRemovePrivateBox)
        }
        binding.llMore.setOnClickListener {
            Log.e("initListener", "rlMore.click")
            val wrapper = if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
                ContextThemeWrapper(
                    this@PrivateConversationsActivity,
                    R.style.CustomPopUpStyleBlack
                )
            } else {
                ContextThemeWrapper(this@PrivateConversationsActivity, R.style.CustomPopUpStyle)
            }

            val popupMenu = PopupMenu(wrapper, binding.llMore)
            // Inflating popup menu from popup_menu.xml file
            popupMenu.menuInflater.inflate(R.menu.desktop_menu, popupMenu.menu)
            val menu = popupMenu.menu

//                menu.findItem(R.id.archive)?.isVisible = currentPage is Inbox && selectedConversations != 0
//                menu.findItem(R.id.read)?.isVisible = markRead && selectedConversations != 0
//                menu.findItem(R.id.block)?.isVisible = selectedConversations != 0
//                menu.findItem(R.id.delete)?.isVisible = selectedConversations != 0
//            menu.findItem(R.id.unarchive)?.isVisible = currentPage is Archived && selectedConversations != 0
            menu.findItem(R.id.unarchive)?.isVisible = false
            menu.findItem(R.id.add)?.isVisible = addContact && selectedConversations != 0
            menu.findItem(R.id.pin)?.isVisible = markPinned && selectedConversations != 0
            menu.findItem(R.id.unpin)?.isVisible = !markPinned && selectedConversations != 0
//            menu.findItem(R.id.unread)?.isVisible = !markRead && selectedConversations != 0
            menu.findItem(R.id.unread)?.isVisible = false
            menu.findItem(R.id.privatebox)?.isVisible = false
            menu.findItem(R.id.read)?.isVisible = true


            popupMenu.setOnMenuItemClickListener { menuItem ->

                when (menuItem.itemId) {
                    R.id.unarchive -> {
                        optionsItemIntent.onNext(R.id.unarchive)
                    }

                    R.id.add -> {
                        optionsItemIntent.onNext(R.id.add)
                    }

                    R.id.pin -> {
                        optionsItemIntent.onNext(R.id.pin)
                    }

                    R.id.unpin -> {
                        optionsItemIntent.onNext(R.id.unpin)
                    }

                    R.id.unread -> {
                        optionsItemIntent.onNext(R.id.unread)
                    }

                    R.id.notification -> {
                        optionsItemIntent.onNext(R.id.notification)
                    }

                    R.id.read -> {
                        optionsItemIntent.onNext(R.id.read)
                    }
                }
                true
            }

            // Showing the popup menu
            Log.e("initListener", "popupMenu.show")
            popupMenu.show()
        }

        binding.privateSetting.setOnClickListener {
            startActivity(
                Intent(
                    this@PrivateConversationsActivity,
                    PrivateSettingsActivity::class.java
                )
            )
        }

        binding.addPrivate.setOnClickListener {

            AddContactDialog(
                this,
                getString(R.string.add_private_contacts),
                object : DialogCallback {
                override fun onItemClick(position: Int) {

                    when (position) {
                        1 -> {
                            startActivity(
                                Intent(
                                    this@PrivateConversationsActivity,
                                    ConversationsPickerActivity::class.java
                                ).putExtra("from", "private")
                            )
                        }

                        2 -> {
                            ContactPicker.open(this@PrivateConversationsActivity, "private")
//                            Toast.makeText(this@PrivateConversationsActivity, "Under development", Toast.LENGTH_SHORT).show()
                        }

                        3 -> {
                            val addPhoneNumberDialog =
                                AddPhoneNumberDialog(
                                    config,
                                    this@PrivateConversationsActivity,
                                    object :
                                        AddPhoneNumberDialog.AddPhoneNumberListener {
                                        override fun addNumber(result: String) {
                                            if (result?.isNotEmpty() == true) {
                                                if (baseConfig.privateContactsList.isEmpty()) {
                                                    baseConfig.privateContactsList = result
                                                } else {
                                                    baseConfig.privateContactsList =
                                                        baseConfig.privateContactsList + "," + result
                                                }
                                            }

                                            setPrivate(result)
                                            onResume()

                                        }
                                    })

                            addPhoneNumberDialog.show()
                        }
                    }

                }

            })
        }

        binding.messageTab.recyclerView.post {
            FastScroller(binding.messageTab.dragHandle, object : BubbleListener {
                override fun setBubbleText(str: String) {
//                    Log.e("FastScroller", "setBubbleText:$str")
                }

                override fun setViewY(y: Float, isMovedByHandleDrag: Boolean) {
                    //     binding.messageTab.messageBubble.y = y
//                    Log.e("FastScroller", "setViewY:$y,isMovedByHandleDrag:$isMovedByHandleDrag")

                    val firstPosition = (binding.messageTab.recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                    val lastPosition = (binding.messageTab.recyclerView.layoutManager as LinearLayoutManager).findLastVisibleItemPosition()

//                    Log.e("FastScroller", "lastPosition:$lastPosition,itemCount:${conversationsAdapter.itemCount}")
//                    if (lastPosition >= conversationsAdapter.itemCount - 2) {
////                        if(isMovedByHandleDrag)
//                        binding.messageTab.messageBubble.beGone()
////                        binding.messageTab.scrollToEnd.beGone()
////                        binding.scrollToEnd.beVisible()
//                    } else {
//                        val str = conversationsAdapter.getBubbleText(firstPosition)
//                        if (str.isNotEmpty()) binding.messageTab.bubbleText.text = str
//                        if (isMovedByHandleDrag) binding.messageTab.messageBubble.beVisible()
//                        else binding.messageTab.messageBubble.beGone()
//
////                        binding.messageTab.scrollToEnd.beVisible()
////                        binding.scrollToEnd.beGone()
//                    }
                }

                override fun setVisible(isVisible: Boolean) {
//                    Log.e("FastScroller", "setVisible:$isVisible")
                }
            }).bind(binding.messageTab.recyclerView)
        }
    }


    fun setPrivate(phoneNumber: String) {
        Realm.getDefaultInstance().use { realm ->
            realm.executeTransaction {
                val conversations = realm.where(Conversation::class.java)
                    .findAll()

                conversations.filter {
                    it.getTitle().replace(" ", "").endsWith(phoneNumber.trim().replace(" ", ""))
                }
                    .forEach { it.isPrivate = true }
            }

            realm.close()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == ContactPickerActivity.RC_CONTACT_PICKER) {


            val result = data?.getParcelableExtra<Contact>(ContactPickerActivity.EXTRA_CONTACT_DATA)
            Log.d("Picker", result?.name + " " + result?.phone)

            if (result?.name?.isNotEmpty() == true) {
                if (baseConfig.privateContactsList.isEmpty()) {
                    baseConfig.privateContactsList = result.name.toString().trim()
                } else {
                    baseConfig.privateContactsList =
                        baseConfig.privateContactsList + "," + result.name.toString().trim()
                }
            } else if (result?.phone?.isNotEmpty() == true) {
                if (baseConfig.privateContactsList.isEmpty()) {
                    baseConfig.privateContactsList = result.phone.toString().trim()
                } else {
                    baseConfig.privateContactsList =
                        baseConfig.privateContactsList + "," + result.phone.toString().trim()
                }
            }

            if (result?.name?.isEmpty() == true) {
                result.phone?.let { setPrivate(it) }
            } else {
                result?.name?.let { setPrivate(it) }
            }
            onResume()
        }
    }

    fun backgroundchange(): GradientDrawable {
        val drawable = GradientDrawable()
        drawable.shape = GradientDrawable.RECTANGLE
        val colorWithOpacity = baseConfig.primaryColor

        val colorWith20Opacity =
            colorWithOpacity.let { ColorUtils.setAlphaComponent(it, 20) } // 51 is 20% of 255

//                val colorWith20Opacity = Color.argb(51, Color.red(colorWithOpacity), Color.green(colorWithOpacity), Color.blue(colorWithOpacity))
        if (colorWith20Opacity != null) {
            drawable.setColor(colorWith20Opacity)
        }
        val strokeWidthInDp = 1.0f
        val strokeWidthInPixels =
            (strokeWidthInDp * resources?.displayMetrics!!.density + 0.5f).toInt()
        baseConfig?.let { drawable.setStroke(strokeWidthInPixels, it.primaryColor) }
        val cornerRadius = resources?.getDimension(R.dimen.normal_text_size)
        if (cornerRadius != null) {
            drawable.cornerRadius = cornerRadius
        }
        return drawable
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent?.run(onNewIntentIntent::onNext)
    }

    var addContact = false
    var markPinned = false
    var markRead = false
    var selectedConversations = 0
    var currentPage: MainPage = Inbox()
    override fun render(state: MainState) {
        if (state.hasError) {
            Log.e("render", "MainActivity:render.hasError:${state.hasError}")
            finish()
            return
        }
        if (state.selectedContact != null && !phoneNumberDialog.isShowing) {
            phoneNumberAdapter.data = state.selectedContact.numbers
            phoneNumberDialog.subtitle = state.selectedContact.name

            phoneNumberDialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
            phoneNumberDialog.show()
        } else if (state.selectedContact == null && phoneNumberDialog.isShowing) {
            phoneNumberDialog.dismiss()
        }
        currentPage = state.page
        addContact = when (state.page) {
            is Inbox -> state.page.addContact
            is Archived -> state.page.addContact
            else -> false
        }

        markPinned = when (state.page) {
            is Inbox -> state.page.markPinned
            is Archived -> state.page.markPinned
            else -> false
        }

        markRead = when (state.page) {
            is Inbox -> state.page.markRead
            is Archived -> state.page.markRead
            else -> true
        }

        selectedConversations = when (state.page) {
            is Inbox -> state.page.selected
            is Archived -> state.page.selected
            else -> 0
        }

//        binding.toolbarSearch.setVisible(state.page is Inbox && state.page.selected == 0 || state.page is Searching)
//        binding.toolbarTitle.setVisible(binding.toolbarSearch.visibility != View.VISIBLE)
        binding.toolbar.menu.findItem(R.id.selectAll)?.isVisible = selectedConversations != 0
//        binding.compose.setVisible(state.page is Inbox || state.page is Archived)
        //   conversationsAdapter.emptyView = binding.messageTab.empty.takeIf { state.page is Inbox || state.page is Archived }
        searchAdapter.emptyView = binding.messageTab.empty.takeIf { state.page is Searching }

        when (state.page) {
            is Searching -> {
//                showBackButton(false)
//                binding.messageTab.toolbar.setNavigationIcon(null)
                if (binding.messageTab.recyclerView.adapter !== searchAdapter) binding.messageTab.recyclerView.adapter =
                    searchAdapter
                searchAdapter.data = state.page.data ?: listOf()
                itemTouchHelper.attachToRecyclerView(null)
                binding.messageTab.emptyText.setText(R.string.inbox_search_empty_text)
            }

            is Archived -> {
                binding.messageTab.llArchive.beGone()
                binding.messageTab.compose.beGone()

//                binding.messageTab.llArchive.layoutParams = CoordinatorLayout.LayoutParams(MATCH_PARENT, 0)

                when (state.page.selected != 0) {
                    true -> {
//                        getString(R.string.main_title_selected, state.page.selected)
                        setCommonData(
                            showBottomAction = true
                        )
                        binding.actionbarTitle.text =
                            resources.getString(R.string.main_title_selected, state.page.selected)
                        binding.toolbarTitle.text =
                            resources.getString(R.string.main_title_selected, state.page.selected)
                    }

                    false -> {
                        setCommonData(
                            showBottomAction = false
                        )
                        binding.actionbarTitle.text =
                            this.resources.getString(R.string.private_conversations)
                        binding.toolbarTitle.text =
                            this.resources.getString(R.string.private_conversations)
                    }
                }
                setConversationAdapter(state.page.data, true, R.string.private_empty_text, false)
            }

            else -> {

            }
        }
//        when (state.contact) {
//            is ContactPage -> {
//                Log.e("fetchContact", "fetchContact: composeItems ${state.composeItems.size}")
//                Log.e(
//                    "fetchContact",
//                    "fetchContact: composeRecentItems ${state.composeRecentItems.size}"
//                )
//                Log.e("fetchContact", "fetchContact: contactGroups ${state.composeGroupItems.size}")
//                contacts = ArrayList(state.composeItems ?: ArrayList())
//                recentContacts = ArrayList(state.composeRecentItems ?: ArrayList())
//                contactGroups = ArrayList(state.composeGroupItems ?: ArrayList())
//                EventBus.getDefault().post(MessageEvent(UPDATE_ALL_CONTACT))
//            }
//
//            else -> {}
//        }

//        binding.drawer.inbox.isActivated = state.page is Inbox
//        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START) && !state.drawerOpen) {
//            binding.drawerLayout.closeDrawer(GravityCompat.START)
//        } else if (!binding.drawerLayout.isDrawerVisible(GravityCompat.START) && state.drawerOpen) {
//            binding.drawerLayout.openDrawer(GravityCompat.START)
//        }

        when (state.syncing) {
            is SyncRepository.SyncProgress.Idle -> {
//                binding.messageTab.syncing.root.isVisible = false
//                if (!isSnackBarClosed) {
//                    binding.messageTab.snackbar.root.isVisible = !state.defaultSms || !state.smsPermission || !state.contactPermission || !state.notificationPermission
//                }
            }

            is SyncRepository.SyncProgress.Running -> {
//                binding.messageTab.syncing.root.isVisible = true
                binding.messageTab.syncing.syncingProgress.max = state.syncing.max
                progressAnimator.apply {
                    setIntValues(
                        binding.messageTab.syncing.syncingProgress.progress,
                        state.syncing.progress
                    )
                }.start()
                binding.messageTab.syncing.syncingProgress.isIndeterminate =
                    state.syncing.indeterminate
//                binding.messageTab.snackbar.root.isVisible = false
            }
        }

//        when {
//            !state.defaultSms -> {
//                binding.messageTab.snackbar.snackbarTitle?.setText(R.string.main_default_sms_title)
//                binding.messageTab.snackbar.snackbarMessage?.setText(R.string.main_default_sms_message)
//                binding.messageTab.snackbar.snackbarButton?.setText(R.string.set_now)
//            }
//
//            !state.smsPermission -> {
//                binding.messageTab.snackbar.snackbarTitle?.setText(R.string.main_permission_required)
//                binding.messageTab.snackbar.snackbarMessage?.setText(R.string.main_permission_sms)
//                binding.messageTab.snackbar.snackbarButton?.setText(R.string.main_permission_allow)
//            }
//
//            !state.contactPermission -> {
//                binding.messageTab.snackbar.snackbarTitle?.setText(R.string.main_permission_required)
//                binding.messageTab.snackbar.snackbarMessage?.setText(R.string.main_permission_contacts)
//                binding.messageTab.snackbar.snackbarButton?.setText(R.string.main_permission_allow)
//            }
//
//            !state.notificationPermission -> {
//                binding.messageTab.snackbar.snackbarTitle?.setText(R.string.main_permission_required)
//                binding.messageTab.snackbar.snackbarMessage?.setText(R.string.main_permission_notifications)
//                binding.messageTab.snackbar.snackbarButton?.setText(R.string.main_permission_allow)
//            }
//        }
    }


    private fun setCommonData(
        showBottomAction: Boolean,
    ) {

        if (showBottomAction) {
            binding.mainToolbar.beGone()
            binding.actionToolbar.beVisible()
            binding.llBottomAction.beVisible()
        } else {
            binding.mainToolbar.beVisible()
            binding.actionToolbar.beGone()
            binding.llBottomAction.beGone()
        }
    }


    private fun setConversationAdapter(
        data: RealmResults<Conversation>?,
        backVisible: Boolean,
        inboxEmptyText: Int,
        isTouchHelper: Boolean,
    ) {
//        if(data?.size==0) {
//            onBackPressed()
//            return
//        }
        if (binding.messageTab.recyclerView.adapter !== conversationsAdapter) {
            binding.messageTab.recyclerView.apply {
                adapter = conversationsAdapter
            }
        }

        binding.messageTab.recyclerView.itemAnimator = null

        conversationsAdapter.updateData(data)
        itemTouchHelper.attachToRecyclerView(if (isTouchHelper) if (backVisible) null else binding.messageTab.recyclerView else null)
        binding.messageTab.emptyText.text = resources.getString(inboxEmptyText)
        //   binding.messageTab.recyclerView.post {
        if (data != null) {
            val arrayListOfUnmanagedObjects: List<Conversation> =
                Realm.getDefaultInstance().copyFromRealm(data)
            if (arrayListOfUnmanagedObjects.isNotEmpty()) {
                binding.messageTab.empty.visibility = View.GONE
                binding.messageTab.recyclerView.visibility = View.VISIBLE
            } else {
                binding.messageTab.empty.visibility = View.VISIBLE
                binding.messageTab.recyclerView.visibility = View.GONE
            }
        }

        val lastPosition = (binding.messageTab.recyclerView.layoutManager as LinearLayoutManager).findLastVisibleItemPosition()

        if (conversationsAdapter.itemCount < 6) {
            binding.messageTab.dragHandle.beGone()
        } else {
            binding.messageTab.dragHandle.beVisible()
        }

    }

    override fun onResume() {
        super.onResume()

        conversationsAdapter.activity = this
        conversationsAdapter.currentActivity = javaClass.simpleName
        title = config.privateBoxName
        activityResumedIntent.onNext(true)

        viewModel.newState {
            val conv = conversationRepo.getPrivateConversations()
            copy(page = Archived(data = conv))
        }


    }

    override fun onPause() {
        super.onPause()
        activityResumedIntent.onNext(false)
    }

    override fun onDestroy() {
        super.onDestroy()
        disposables.dispose()
        if (EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().unregister(this)


        GoogleSmallNativeAdManagerPrivate.onDestroy()
    }

    override fun showBackButton(show: Boolean) {
//        if (show) {
//            supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_close_black_24dp)
//        } else {
//            supportActionBar?.setHomeAsUpIndicator(null)
//        }
        super.showBackButton(show)
    }

    override fun requestDefaultSms() {
        navigator.showDefaultSmsDialog(this@PrivateConversationsActivity)
    }

    override fun requestPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }

        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 0)
    }

    override fun clearSearch() {
        dismissKeyboard()
        binding.messageTab.toolbarSearch.text = null
    }

    override fun clearSelection() {
        conversationsAdapter.clearSelection()
    }

//    override fun onBackPressedFromArchive() {
//        backPressedSubject.onNext(NavItem.BACK)
//    }

    override fun themeChanged() {
        binding.messageTab.recyclerView.scrapViews()
        EventBus.getDefault().post(MessageEvent(THEME_CHANGED))
    }

    override fun showBlockingDialog(conversations: List<Long>, block: Boolean) {
        blockingDialog.show(this, conversations, block)
        delayExecution(200) {
            refreshArchive()
        }
    }

    override fun showDeleteDialog(conversations: List<Long>) {
        val count = conversations.size
        val dialog = AlertDialog.Builder(this, R.style.CustomFieldDialogTheme)
            .setTitle(R.string.dialog_delete_title)
            .setMessage(resources.getQuantityString(R.plurals.dialog_delete_message, count, count))
            .setPositiveButton(R.string.button_delete) { _, _ ->
                confirmDeleteIntent.onNext(conversations)
            }
            .setNegativeButton(R.string.button_cancel, null)
            .create()  // Use create() instead of show()

        dialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
        dialog.setOnShowListener {
            // Change the button text colors after the dialog is shown
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(
                baseConfig.primaryColor
            )
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                ?.setTextColor(resources.getColor(R.color.black))
        }

        dialog.show()
    }


    override fun showArchivedSnackbar() {
        /* Snackbar.make(binding.messageTab.root, R.string.toast_archived, Snackbar.LENGTH_LONG)
             .apply {
                 setAction(R.string.button_undo) { undoArchiveIntent.onNext(Unit) }
                 setActionTextColor(colors.theme().theme)
                 show()
                 addCallback(object : Snackbar.Callback() {
                     override fun onDismissed(transientBottomBar: Snackbar?, event: Int) {
                         super.onDismissed(transientBottomBar, event)
                         refreshArchive.onNext(Unit)
                     }
                 })
             }*/
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }

            R.id.selectAll -> {
                conversationsAdapter.toggleSelectAll(true)
//                backPressedSubject.onNext(NavItem.BACK)
//                setTitle(R.string.messages)
//                showBackButton(false)
                true
            }

            else -> {
                optionsItemIntent.onNext(item.itemId)
                return true
            }
        }

    }

    override fun onBackPressed() {
        if (conversationsAdapter.selection.isNotEmpty()) {
            clearSelection()
        } else {
            finish()
        }

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.type) {
            REFRESH_MESSAGE -> {
                Log.e("onMessageEvent", "REFRESH_MESSAGE")
                viewModel.newState {
                    val conv = conversationRepo.getPrivateConversations()
                    copy(page = Archived(data = conv))
                }
            }

            REFRESH_CONTACT_GROUP -> {
//                binding.contactTab.cancel.performClick()
            }

            THEME_CHANGED -> {
                binding.messageTab.recyclerView.scrapViews()
            }

            SYNC_MESSAGE -> {
                Log.e("onMessageEvent", "SYNC_MESSAGE")
                viewModel.newState {
                    val conv = conversationRepo.getPrivateConversations()
                    copy(page = Archived(data = conv))
                }
            }
        }

    }

    override fun clearQuery() {
//        binding.contactTab.searchContact.text = null
    }

    override fun refreshArchive() {
        refreshArchive.onNext(Unit)
        appPreference.isRefreshMessages = true
    }

    override fun refreshBlockedList() {
        refreshBlocked.onNext(Unit)
        appPreference.isRefreshMessages = true
    }



    override fun openKeyboard() {
//        binding.contactTab.searchContact.postDelayed({
//            binding.contactTab.searchContact.showKeyboard()
//        }, 200)
    }

    override fun finish(result: HashMap<String, String?>) {
//        binding.contactTab.searchContact.hideKeyboard()
        val intent =
            Intent(
                this@PrivateConversationsActivity,
                ComposeActivity::class.java
            ).putExtra(ChipsKey, result)
        startActivity(intent)
//        finish()
    }

    fun onContactClick(contact: ContactData) {
        composeItemPressedIntent.onNext(contact)
    }

    fun onContactLongClick(contact: ContactData) {
        composeItemLongPressedIntent.onNext(contact)
    }

    fun onContactGroupClick(contact: ContactGroup) {
        startActivity(
            Intent(this, GroupsActivity::class.java).putExtra("groupId", contact.id)
                .putExtra("groupName", contact.title)
        )
    }

    fun onContactGroupLongClick(contact: ContactGroup) {
    }


}
