package messages.text.sms.injection.scope

import javax.inject.Scope

@Scope
annotation class ActivityScope
