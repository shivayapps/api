package messages.text.sms.feature.backup

import android.content.Context
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.rxkotlin.withLatestFrom
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MainBasePresenter
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.common.util.extensions.makeToast
import messages.text.sms.interactor.PerformBackup
import messages.text.sms.manager.PermissionManager
import messages.text.sms.repository.BackupRepository
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class BackupPresenter @Inject constructor(
    private val backupRepo: BackupRepository,
    private val context: Context,
    private val dateFormatter: DateFormatter,
    private val navigator: Navigator,
    private val performBackup: PerformBackup,
    private val permissionManager: PermissionManager,
) : MainBasePresenter<BackupView, BackupState>(BackupState()) {

    //    private val storagePermissionSubject: Subject<Boolean> = BehaviorSubject.createDefault(permissionManager.hasStorage())
    private val storagePermissionSubject: Subject<Boolean> = BehaviorSubject.createDefault(true)

    init {
        disposables += backupRepo.getBackupProgress()
            .sample(16, TimeUnit.MILLISECONDS)
            .distinctUntilChanged()
            .subscribe { progress -> newState { copy(backupProgress = progress) } }

        disposables += backupRepo.getRestoreProgress()
            .sample(16, TimeUnit.MILLISECONDS)
            .distinctUntilChanged()
            .subscribe { progress -> newState { copy(restoreProgress = progress) } }

        disposables += storagePermissionSubject
            .distinctUntilChanged()
            .switchMap { backupRepo.getBackups() }
            .doOnNext { backups -> newState { copy(backups = backups) } }
            .map { backups -> backups.maxOfOrNull { it.date } ?: 0L }
            .map { lastBackup ->
                when (lastBackup) {
                    0L -> context.getString(R.string.backup_never)
                    else -> dateFormatter.getDetailedTimestamp(lastBackup)
                }
            }
            .startWith(context.getString(R.string.backup_loading))
            .subscribe { lastBackup -> newState { copy(lastBackup = lastBackup) } }

    }

    override fun bindIntents(view: BackupView) {
        super.bindIntents(view)

        view.permissionGiven()
            .distinctUntilChanged()
            .switchMap { backupRepo.getBackups() }
            .subscribe { backups -> newState { copy(backups = backups) } }

        view.activityVisible()
            .map { permissionManager.hasStorage() }
            .autoDisposable(view.scope())
            .subscribe(storagePermissionSubject)

        view.restoreClicks()
            .withLatestFrom(
                backupRepo.getBackupProgress(),
                backupRepo.getRestoreProgress()
            )
            { _, backupProgress, restoreProgress ->
                when {
                    backupProgress.running -> context.makeToast(R.string.backup_restore_error_backup)
                    restoreProgress.running -> context.makeToast(R.string.backup_restore_error_restore)
//                    !permissionManager.hasStorage() -> view.requestStoragePermission()
                    else -> view.selectFile()
                }
            }
            .autoDisposable(view.scope())
            .subscribe()

        view.restoreFileSelected()
            .autoDisposable(view.scope())
            .subscribe { view.confirmRestore() }

        view.restoreConfirmed()
            .withLatestFrom(view.restoreFileSelected()) { _, backup -> backup }
            .autoDisposable(view.scope())
            .subscribe { backup -> RestoreBackupService.start(context, backup.path) }

        view.deleteRestoreFileSelected()
            .autoDisposable(view.scope())
            .subscribe { backup ->
                backupRepo.deleteBackup(backup.path)
            }

        view.stopRestoreClicks()
            .autoDisposable(view.scope())
            .subscribe { view.stopRestore() }

        view.stopRestoreConfirmed()
            .autoDisposable(view.scope())
            .subscribe { backupRepo.stopRestore() }

        view.stopBackup()
            .autoDisposable(view.scope())
            .subscribe { backupRepo.stopBackup() }

        view.fabClicks()
            .autoDisposable(view.scope())
            .subscribe { _ ->

//                if (!permissionManager.hasStorage()) {
//                    view.requestStoragePermission()
//                } else {
//                    Log.e("BackUp","execute Backup")
////                    if (conversationRepo.getAllConversationsSize() != 0) {
//                        performBackup.execute(Unit)
////                    } else
////                        view.showDialog()
//                }

//                when {
//                    !permissionManager.hasStorage() -> view.requestStoragePermission()
//                    else ->
                performBackup.execute(Unit)
//                }
            }
    }

}