package messages.text.sms.autoreply

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.Switch
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.databinding.FragmentDriveModeBinding

class DriveModeFragment : Fragment(R.layout.fragment_drive_mode) {

    private var _binding: FragmentDriveModeBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: AutoReplyMessageAdapter
    private var isEditMode = true

    private val replyMessages: MutableList<String>
        get() = requireActivity().baseConfig.driveReplies.toMutableList()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentDriveModeBinding.bind(view)

        binding.tvAutoReplyLabel.setTextColor(requireActivity().baseConfig.primaryColor)

        adapter = AutoReplyMessageAdapter(
            replyMessages,
            requireActivity().baseConfig.driveSelectedReplyIndex,
            ::onMessageSelected,
            ::onMessageEdited,
            ::onMessageDeleted
        )

        binding.rvMessages.layoutManager = LinearLayoutManager(requireActivity())
        binding.rvMessages.adapter = adapter



        binding.tvAddNewReply.setOnClickListener {
            showAddMessageDialog()
        }

        binding.btnEditMessages.setOnClickListener {
            isEditMode = !isEditMode
            adapter.setEditMode(isEditMode)
        }
    }

    private fun onMessageSelected(index: Int) {
        requireActivity().baseConfig.driveSelectedReplyIndex = index
        adapter.setSelectedIndex(index)
    }

    private fun onMessageEdited(index: Int, newText: String) {
        val updatedList = replyMessages
        updatedList[index] = newText
        requireActivity().baseConfig.driveReplies = updatedList
        adapter.updateMessages(updatedList)
    }

    private fun onMessageDeleted(index: Int) {
        val updatedList = replyMessages
        updatedList.removeAt(index)
        requireActivity().baseConfig.driveReplies = updatedList
        adapter.updateMessages(updatedList)
        if (index == requireActivity().baseConfig.driveSelectedReplyIndex) {
            requireActivity().baseConfig.driveSelectedReplyIndex = 0
        }
    }

    private fun showAddMessageDialog() {
        val editText = EditText(requireActivity()).apply {
            hint = "Enter auto reply message"
        }

        AlertDialog.Builder(requireActivity())
            .setTitle("New Auto Reply")
            .setView(editText)
            .setPositiveButton("Add") { _, _ ->
                val msg = editText.text.toString()
                if (msg.isNotBlank()) {
                    val updatedList = replyMessages
                    updatedList.add(msg)
                    requireActivity().baseConfig.driveReplies = updatedList
                    adapter.updateMessages(updatedList)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

