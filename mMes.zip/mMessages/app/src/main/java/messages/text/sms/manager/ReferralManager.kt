package messages.text.sms.manager

interface ReferralManager {

    suspend fun trackReferrer()

}
