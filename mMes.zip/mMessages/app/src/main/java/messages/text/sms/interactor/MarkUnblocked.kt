package messages.text.sms.interactor

import io.reactivex.Flowable
import messages.text.sms.repository.ConversationRepository
import javax.inject.Inject

class MarkUnblocked @Inject constructor(private val conversationRepo: ConversationRepository) :
    Interactor<List<Long>>() {

    override fun buildObservable(params: List<Long>): Flowable<*> {
        return Flowable.just(params.toLongArray())
            .doOnNext { threadIds -> conversationRepo.markUnblocked(*threadIds) }
    }

}