package messages.text.sms.password

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import messages.text.sms.R
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.helpers.Config

class AddPhoneNumberDialog(
    private val config: Config,
    private val context: Context,
    private val addphonenumberlistener: AddPhoneNumberListener,
) {

    fun show() {
        // Inflate the custom layout
        val inflater = LayoutInflater.from(context)
        val dialogView = inflater.inflate(R.layout.dialog_add_number, null)

        // Initialize views
        val dialogInput = dialogView.findViewById<EditText>(R.id.dialog_input)
        val dialogCancelButton = dialogView.findViewById<TextView>(R.id.dialog_cancel_button)
        val dialogOkButton = dialogView.findViewById<TextView>(R.id.dialog_ok_button)
        //   dialogInput.setText(config.privateBoxName)

        dialogCancelButton.setTextColor(Color.BLACK)
        dialogOkButton.setTextColor(context.baseConfig.primaryColor)

        val alertDialog = AlertDialog.Builder(context)
            .setView(dialogView)
            .create()

        alertDialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)



        alertDialog.setOnShowListener {
            val window = alertDialog.window
            val layoutParams = window?.attributes

            val displayMetrics = context.resources.displayMetrics
            val dialogWidth = (displayMetrics.widthPixels * 0.85).toInt() // 85% of screen width

            layoutParams?.width = dialogWidth
            window?.attributes = layoutParams
        }

        // Set click listeners for custom buttons
        dialogCancelButton.setOnClickListener {
            alertDialog.dismiss()
        }

        dialogOkButton.setOnClickListener {
            val inputText = dialogInput.text.toString()
            if (inputText.isNotEmpty() && inputText.length > 9) {
                addphonenumberlistener.addNumber(inputText)
                alertDialog.dismiss()
            } else {
                Toast.makeText(
                    context,
                    context.getString(R.string.enter_valid_phone_number),
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        alertDialog.show()
    }

    interface AddPhoneNumberListener {
        fun addNumber(newString: String)
    }
}

















