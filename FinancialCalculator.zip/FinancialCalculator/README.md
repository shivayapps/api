# FinancialCalculator

Design Guide: 
![alt text](https://mir-s3-cdn-cf.behance.net/project_modules/1400/c01b9757749199.59e21fb184777.png "Design Guide")
![alt text](https://image.ibb.co/fptf86/Screen_Shot_2017_10_16_at_9_35_16_PM.png "Statistics Channel")

