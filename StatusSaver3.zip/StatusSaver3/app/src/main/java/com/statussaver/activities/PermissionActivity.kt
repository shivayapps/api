package com.statussaver.activities

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.statussaver.R
import com.statussaver.WhatSaveViewModel
import com.statussaver.activities.base.BaseActivity
import com.statussaver.adapter.ClientAdapter
import com.statussaver.databinding.ActivityPermissionBinding
import com.statussaver.extensions.formattedAsHtml
import com.statussaver.extensions.getClientSAFIntent
import com.statussaver.extensions.hasPermissions
import com.statussaver.extensions.hasQ
import com.statussaver.extensions.hasStoragePermissions
import com.statussaver.extensions.isNullOrEmpty
import com.statussaver.extensions.launchSafe
import com.statussaver.extensions.requestWithoutOnboard
import com.statussaver.extensions.showToast
import com.statussaver.extensions.takePermissions
import com.statussaver.interfaces.IClientCallback
import com.statussaver.interfaces.IPermissionChangeListener
import com.statussaver.model.WaClient
import org.koin.androidx.viewmodel.ext.android.viewModel

class PermissionActivity : BaseActivity(), View.OnClickListener, IClientCallback,
    IPermissionChangeListener {

    private val viewModel: WhatSaveViewModel by viewModel()

    private lateinit var permissionRequest: ActivityResultLauncher<Intent>
    private var clientAdapter: ClientAdapter? = null
    private var selectedClient: WaClient? = null
    private var clients: List<WaClient> = ArrayList()

    lateinit var binding: ActivityPermissionBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Glide.with(this).load(R.drawable.ic_permission_img)
            .diskCacheStrategy(DiskCacheStrategy.NONE)
            .skipMemoryCache(true)
            .into(binding.ivHeader)

        binding.grantButton.setOnClickListener(this)
//        binding.continueButton.setOnClickListener(this)
        binding.btnSkip.setOnClickListener(this)
//        binding.privacyPolicyButton.setOnClickListener(this)

        permissionRequest = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult? ->
            if (result != null && selectedClient?.takePermissions(this, result) == true) {
                viewModel.reloadAll()
                clientAdapter?.notifyDataSetChanged()
            }
        }
        setupViews()
        setupClientPermissions()
        setupGrantButtonIcon()

        viewModel.getInstalledClients().observe(this) {
            if (it.isEmpty()) {
                binding.empty.isVisible = true
                binding.recyclerView.isVisible = false
            } else {
                binding.empty.isVisible = false
                binding.recyclerView.isVisible = true
            }
            clients = it
            clientAdapter?.setClients(it)
        }

        addPermissionsChangeListener(this)
//        onBackPressedDispatcher.addCallback(this, onBackPressedCallback)
    }

    private fun setupViews() {
//        if (args.isFromSettings) {
//            binding.subtitle.isVisible = false
//            binding.agreementText.isVisible = false
//            binding.storagePermissionView.isGone = hasStoragePermissions()
//        }
    }

    private fun setupGrantButtonIcon() {
//        val iconRes = if (hasStoragePermissions()) R.drawable.ic_round_check_24dp else R.drawable.ic_storage_24dp
//        binding.grantButton.setIconResource(iconRes)
        val permissionsText = if (hasStoragePermissions()) R.string.all_permissions_granted else R.string.grant_permissions
        binding.grantButton.setText(permissionsText)

        if (hasStoragePermissions()) {
            binding.storagePermissionView.isVisible = false
            binding.clientPermissionView.isVisible = true
            binding.btnSkip.isVisible = true
//            binding.continueButton.isVisible = true
        } else {
            binding.storagePermissionView.isVisible = true
            binding.clientPermissionView.isVisible = false
            binding.btnSkip.isVisible = false
//            binding.continueButton.isVisible = false
        }
    }

    private fun setupClientPermissions() {
        if (hasQ()) {
            clientAdapter = ClientAdapter(this, R.layout.item_client_onboard, this)
            binding.recyclerView.layoutManager = LinearLayoutManager(this)
            binding.recyclerView.adapter = clientAdapter
        } else {
            binding.clientPermissionView.isVisible = false
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun clientClick(client: WaClient) {
        if (client.hasPermissions(this)) {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.revoke_permissions_title)
                .setMessage(
                    getString(
                        R.string.revoke_permissions_message,
                        client.displayName
                    ).formattedAsHtml()
                )
                .setPositiveButton(R.string.revoke_action) { _: DialogInterface, _: Int ->
                    if (client.releasePermissions(this)) {
                        showToast(R.string.permissions_revoked_successfully)
                        viewModel.reloadAll()
                        clientAdapter?.notifyDataSetChanged()
                    }
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        } else if (hasQ()) { // Just to remove the Lint warning
            MaterialAlertDialogBuilder(this)
                .setMessage(getString(R.string.saf_tutorial, client.getSAFDirectoryPath()).formattedAsHtml())
                .setPositiveButton(android.R.string.ok) { _: DialogInterface, _: Int ->
                    this.selectedClient = client
                    permissionRequest.launchSafe(getClientSAFIntent(client))
                }
                .show()
        }
    }

    override fun checkModeForClient(client: WaClient): Int {
        if (client.hasPermissions(this)) {
            return IClientCallback.MODE_CHECKED
        }
        return IClientCallback.MODE_UNCHECKED
    }

    override fun permissionsStateChanged(hasPermissions: Boolean) {
        setupGrantButtonIcon()
        if (hasPermissions) {
            viewModel.reloadAll()
        }
    }

    override fun onClick(view: View) {
        when (view) {
            binding.grantButton -> {
                if (!hasStoragePermissions()) {
                    requestWithoutOnboard()
                }
            }

//            binding.privacyPolicyButton -> {
//                requireContext().openWeb(AboutFragment.PRIVACY_POLICY)
//            }

            binding.btnSkip -> {
                finish()
            }
//            binding.continueButton -> {
//                val clientsWithoutPermissions = clients.filterNot { it.hasPermissions(this) }
//                if (clientsWithoutPermissions.isEmpty()) {
//                    onBackPressedDispatcher.onBackPressed()
//                } else {
//                    val singleClient = clientsWithoutPermissions.first()
//                    clientClick(singleClient)
//                }
//            }
        }
    }

    override fun onStart() {
        super.onStart()
        viewModel.loadClients()
    }

//    override fun onDestroy() {
//        removePermissionsChangeListener(this)
//        super.onDestroy()
//    }

    private fun handleBackPress(): Boolean {
        // WORKAROUND: Sometimes the callback is executed even when the fragment has already
        // been removed, which is why some users got IllegalStateException errors.
        // For now, we only have to manually check the state of the fragment and cancel the
        // callback by returning 'true' when it is not visible.
//        if (!isVisible) return true
        if (clientAdapter?.isNullOrEmpty() == true) return false
        if (!hasPermissions()) {
            MaterialAlertDialogBuilder(this)
                .setMessage(R.string.permissions_denied_message)
                .setPositiveButton(R.string.continue_action) { _: DialogInterface, _: Int ->
                    closeOnboard()
                }
                .setNegativeButton(R.string.grant_permissions, null)
                .show()
            return true
        }
        return false
    }

    private fun closeOnboard() {
//        finish()
//        if (isVisible) findNavController().popBackStack()
    }

//    private val onBackPressedCallback = object : OnBackPressedCallback(true) {
//        override fun handleOnBackPressed() {
//            if (!handleBackPress()) {
//                remove()
//                onBackPressedDispatcher.onBackPressed()
//            }
//        }
//    }
}