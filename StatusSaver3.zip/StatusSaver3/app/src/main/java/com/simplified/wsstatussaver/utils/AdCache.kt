package com.simplified.wsstatussaver.utils

import com.google.android.gms.ads.AdView

class AdCache {
    companion object {
        var homeAdView:AdView?=null

    }
}


