package com.simplified.wsstatussaver.extensions

import android.app.Dialog
import android.content.Context
import android.view.LayoutInflater
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.simplified.wsstatussaver.databinding.DialogProgressBinding

fun Context.createProgressDialog(): Dialog {
    val builder = MaterialAlertDialogBuilder(this)
    val binding = DialogProgressBinding.inflate(LayoutInflater.from(builder.context))
    return builder.setView(binding.root).setCancelable(false).create()
}