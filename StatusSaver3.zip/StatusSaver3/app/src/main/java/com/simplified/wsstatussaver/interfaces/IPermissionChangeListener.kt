package com.simplified.wsstatussaver.interfaces


interface IPermissionChangeListener {
    fun permissionsStateChanged(hasPermissions: Boolean)
}