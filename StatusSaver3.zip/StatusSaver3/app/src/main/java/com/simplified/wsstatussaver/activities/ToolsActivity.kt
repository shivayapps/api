package com.simplified.wsstatussaver.activities

import android.os.Bundle
import androidx.fragment.app.Fragment
import com.simplified.wsstatussaver.R
import com.simplified.wsstatussaver.activities.base.BaseActivity
import com.simplified.wsstatussaver.databinding.ActivityToolsBinding
import com.simplified.wsstatussaver.fragments.AsciiFacesFragment
import com.simplified.wsstatussaver.fragments.SplitLongStatusFragment
import com.simplified.wsstatussaver.fragments.StylishTextFragment
import com.simplified.wsstatussaver.fragments.TextDecoratorFragment
import com.simplified.wsstatussaver.fragments.TextRepeatFragment
import com.simplified.wsstatussaver.fragments.WaDirectFragment

class ToolsActivity : BaseActivity() {


    lateinit var binding: ActivityToolsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityToolsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val itemId = intent.getIntExtra("id", 1)
        when (itemId) {
            0 -> showFragment(WaDirectFragment())
            1 -> showFragment(TextRepeatFragment())
            2 -> showFragment(StylishTextFragment())
            3 -> showFragment(TextDecoratorFragment())
            4 -> showFragment(AsciiFacesFragment())
            5 -> showFragment(SplitLongStatusFragment())
        }
    }

    private fun showFragment(fragment: Fragment) {
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }


}