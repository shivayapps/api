package com.simplified.wsstatussaver.activities

import android.os.Bundle
import androidx.fragment.app.Fragment
import com.simplified.wsstatussaver.R
import com.simplified.wsstatussaver.activities.base.BaseActivity
import com.simplified.wsstatussaver.databinding.ActivityToolsBinding
import com.simplified.wsstatussaver.extensions.applyPortraitInsetter
import com.simplified.wsstatussaver.fragments.AsciiFacesFragment
import com.simplified.wsstatussaver.fragments.SplitLongStatusFragment
import com.simplified.wsstatussaver.fragments.StylishTextFragment
import com.simplified.wsstatussaver.fragments.TextDecoratorFragment
import com.simplified.wsstatussaver.fragments.TextRepeatFragment
import com.simplified.wsstatussaver.fragments.WaDirectFragment

class ToolsActivity : BaseActivity() {

    lateinit var binding: ActivityToolsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityToolsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val itemId = intent.getIntExtra("id", 1)
        when (itemId) {
            0 -> {
                binding.toolbar.setTitle(getString(R.string.quick_message))
                showFragment(WaDirectFragment())
            }

            1 -> {
                binding.toolbar.setTitle(getString(R.string.text_repeater))
                showFragment(TextRepeatFragment())
            }

            2 -> {
                binding.toolbar.setTitle(getString(R.string.stylish_text))
                showFragment(StylishTextFragment())
            }

            3 -> {
                binding.toolbar.setTitle(getString(R.string.text_decorator))
                showFragment(TextDecoratorFragment())
            }

            4 -> {
                binding.toolbar.setTitle(getString(R.string.ascii_face))
                showFragment(AsciiFacesFragment())
            }

            5 -> {
                binding.toolbar.setTitle(getString(R.string.split_long_status))
                showFragment(SplitLongStatusFragment())
            }
        }
//        binding.fragmentContainer.applyPortraitInsetter {
//            type(navigationBars = true) {
//                padding(vertical = true)
//            }
//        }
    }

    private fun showFragment(fragment: Fragment) {
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

}