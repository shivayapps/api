package com.simplified.wsstatussaver

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import coil3.ImageLoader
import coil3.PlatformContext
import coil3.SingletonImageLoader
import coil3.request.crossfade
import coil3.video.VideoFrameDecoder
import com.simplified.wsstatussaver.extensions.getDefaultDayNightMode
import com.simplified.wsstatussaver.extensions.migratePreferences
import com.simplified.wsstatussaver.extensions.packageInfo
import com.simplified.wsstatussaver.extensions.preferences
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

fun getApp(): App = App.instance


class App : Application(), SingletonImageLoader.Factory {

    override fun onCreate() {
        super.onCreate()
        instance = this

        preferences().migratePreferences()

        // Disable Analytics/Crashlytics for debug builds

        startKoin {
            androidContext(this@App)
            modules(appModules)
        }

        AppCompatDelegate.setDefaultNightMode(preferences().getDefaultDayNightMode())
    }

    override fun newImageLoader(context: PlatformContext): ImageLoader {
        return ImageLoader.Builder(context)
            .crossfade(true)
            .components {
                add(VideoFrameDecoder.Factory())
            }
            .build()
    }

    val versionName: String
        get() = packageManager.packageInfo().versionName ?: "1.0"

    companion object {
        internal lateinit var instance: App
            private set

        fun getFileProviderAuthority(): String = instance.packageName + ".file_provider"
    }
}