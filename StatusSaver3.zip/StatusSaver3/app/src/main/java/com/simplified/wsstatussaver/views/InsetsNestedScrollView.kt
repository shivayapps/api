
package com.simplified.wsstatussaver.views

import android.content.Context
import android.util.AttributeSet
import androidx.core.widget.NestedScrollView
import com.simplified.wsstatussaver.extensions.applyPortraitInsetter


class InsetsNestedScrollView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = androidx.core.R.attr.nestedScrollViewStyle
) : NestedScrollView(context, attrs, defStyleAttr) {

    init {
        applyPortraitInsetter {
            type(navigationBars = true) {
                padding()
            }
        }
    }
}