package com.simplified.wsstatussaver.activities

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import androidx.core.app.ShareCompat
import androidx.core.net.toUri
import androidx.core.view.doOnPreDraw
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.transition.MaterialFadeThrough
import com.simplified.wsstatussaver.R
import com.simplified.wsstatussaver.WhatSaveViewModel
import com.simplified.wsstatussaver.activities.base.BaseActivity
import com.simplified.wsstatussaver.adapter.CountryAdapter
import com.simplified.wsstatussaver.databinding.ActivityNewMessageBinding
import com.simplified.wsstatussaver.databinding.DialogRecyclerviewBinding
import com.simplified.wsstatussaver.extensions.encodedUrl
import com.simplified.wsstatussaver.extensions.getPreferredClient
import com.simplified.wsstatussaver.extensions.showToast
import com.simplified.wsstatussaver.extensions.startActivitySafe
import com.simplified.wsstatussaver.interfaces.ICountryCallback
import com.simplified.wsstatussaver.model.Country
import com.simplified.wsstatussaver.views.PhoneNumberFormattingTextWatcher
import io.michaelrocks.libphonenumber.android.NumberParseException
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil
import org.koin.android.ext.android.inject
import org.koin.androidx.viewmodel.ext.android.viewModel

class NewMessageActivity : BaseActivity(), ICountryCallback {

    private val viewModel: WhatSaveViewModel by viewModel()
    private val phoneNumberUtil: PhoneNumberUtil by inject()

    private var adapter: CountryAdapter? = null
    private var countriesDialog: Dialog? = null
    private var numberFormatTextWatcher: PhoneNumberFormattingTextWatcher? = null
    lateinit var binding: ActivityNewMessageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewMessageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        postponeEnterTransition()
//        enterTransition = MaterialFadeThrough().addTarget(view)
//        reenterTransition = MaterialFadeThrough().addTarget(view)
//        view.doOnPreDraw { startPostponedEnterTransition() }

        createCountriesDialog()
        setSupportActionBar(binding.toolbar)
        binding.messageANumberContent.phoneNumberInputLayout.setEndIconOnClickListener {
            countriesDialog?.show()
        }
        binding.messageANumberContent.shareButton.setOnClickListener {
            shareLink()
        }
        binding.messageANumberContent.sendButton.setOnClickListener {
            sendMessage()
        }
        viewModel.getCountriesObservable().observe(this) {
            adapter?.countries = it
        }
        viewModel.getSelectedCountryObservable().observe(this) { country ->
            numberFormatTextWatcher?.let { textWatcher ->
                binding.messageANumberContent.phoneNumber.removeTextChangedListener(textWatcher)
            }
            numberFormatTextWatcher = PhoneNumberFormattingTextWatcher(country.isoCode).also { textWatcher ->
                binding.messageANumberContent.phoneNumber.addTextChangedListener(textWatcher)
            }
            binding.messageANumberContent.phoneNumberInputLayout.prefixText = country.getId()
            adapter?.selectedCode = country.isoCode
        }
        viewModel.loadCountries()
        viewModel.loadSelectedCountry()
    }


    private fun createCountriesDialog() {
        adapter = CountryAdapter(this, viewModel.getCountries(), this)
        val binding = DialogRecyclerviewBinding.inflate(layoutInflater)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
        countriesDialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.select_a_country_title)
            .setView(binding.root)
            .setNegativeButton(android.R.string.cancel, null)
            .create()
    }

//    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
//        super.onCreateMenu(menu, menuInflater)
//        menu.removeItem(R.id.action_settings)
//    }

    override fun countryClick(country: Country) {
        viewModel.setSelectedCountry(country)
        countriesDialog?.dismiss()
    }


    private fun shareLink() {
        createApiRequest { result ->
            ShareCompat.IntentBuilder(this)
                .setChooserTitle(R.string.share_link_action)
                .setText(result)
                .setType("text/plain")
                .startChooser()
        }
    }

    private fun sendMessage() {
        createApiRequest { result ->
            val intent = Intent(Intent.ACTION_VIEW, result.toUri())
            val whatsappClient = getPreferredClient()
            if (whatsappClient != null) {
                intent.setPackage(whatsappClient.packageName)
            }
            startActivitySafe(intent) { _: Throwable, activityNotFound: Boolean ->
                if (activityNotFound) showToast(R.string.wa_is_not_installed_title)
            }
            onBackPressed()
//            findNavController().popBackStack()
        }
    }

    private fun createApiRequest(onComplete: (String) -> Unit) {
        val entered = binding.messageANumberContent.phoneNumber.text?.toString()
        val country = viewModel.getSelectedCountry() ?: return
        val formattedNumber = formatInput(entered, country)
        if (formattedNumber == null) {
            showToast(R.string.phone_number_invalid)
            return
        }
        val encodedMessage = binding.messageANumberContent.message.text?.toString()?.encodedUrl()
        val apiRequest = StringBuilder("https://api.whatsapp.com/send?phone=")
        apiRequest.append(formattedNumber)
        if (!encodedMessage.isNullOrBlank()) {
            apiRequest.append("&text=").append(encodedMessage)
        }
        onComplete(apiRequest.toString())
    }

    private fun formatInput(input: String?, country: Country): String? {
        val number = try {
            phoneNumberUtil.parse(input, country.isoCode)
        } catch (e: NumberParseException) {
            null
        }
        if (number == null || !phoneNumberUtil.isValidNumberForRegion(number, country.isoCode)) {
            return null
        }
        return phoneNumberUtil.format(number, PhoneNumberUtil.PhoneNumberFormat.E164)
    }

}