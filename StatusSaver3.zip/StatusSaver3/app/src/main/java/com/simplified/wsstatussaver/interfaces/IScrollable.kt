package com.simplified.wsstatussaver.interfaces

interface IScrollable {
    fun scrollToTop()
}