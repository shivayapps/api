package com.simplified.wsstatussaver.utils;

import static android.os.Environment.DIRECTORY_DCIM;

import static com.simplified.wsstatussaver.BuildConfig.APPLICATION_ID;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Log;

import androidx.core.content.FileProvider;
import androidx.documentfile.provider.DocumentFile;

//import org.apache.commons.io.comparator.LastModifiedFileComparator;

import com.simplified.wsstatussaver.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLConnection;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

//import in.whatsaga.whatsapplongerstatus.status.uploader.App;
//import in.whatsaga.whatsapplongerstatus.status.uploader.R;
//import in.whatsaga.whatsapplongerstatus.status.uploader.models.MediaModel;
//import khangtran.preferenceshelper.PrefHelper;


public class Common {

    private static final String TAG = "TAG";

    public static final File folder = new File(
            Environment.getExternalStorageDirectory(), "Status Saver"
    );
    private static final String SPLIT_VIDEO = "Split Video";
    public static final File splitVideoFolder = new File(folder, SPLIT_VIDEO);

    private static final int DEFAULT_BUFFER_SIZE = 1024 * 1024;

    static char[] letterList = {
            'A', 'B', 'C', 'D', 'E',
            'F', 'G', 'H', 'I', 'J',
            'K', 'L', 'M', 'N', 'O',
            'P', 'Q', 'R', 'S', 'T',
            'U', 'V', 'W', 'X', 'Y', 'Z'};

    public static String PATH = "PATH";
    public static int POSITION = -1;

    public static final int FILE_COPIED = 1;
    public static final int FILE_EXISTS = 2;
//    public static final File folder = new File(
//            Environment.getExternalStorageDirectory(), "Unseen WhatsApp Status"
//    );
    private static List<String> voiceList;
    private static File[] files;

    public static void mkDirs() {
        if (folder.mkdirs())
            Log.i(TAG, "Folder created");
    }

    public static void mkDirs(File file) {
        if (file.mkdirs())
            Log.i(TAG, "Folder created");
    }

//    public static int copyImage(File file) {
//        mkDirs();
//        return copyFile(file, new File(Statusbackupfolder, file.getName()));
//    }

    public static int copyImage(File file, File dest) {
        mkDirs(dest);
        return copyFile(file, new File(dest, file.getName()));
    }


    public static char[] getLetterList() {
        return letterList;
    }


    public static void shareMultipleVideo(Context context, ArrayList<String> videoFiles, String title) {
        ArrayList<Uri> uriArrayList = new ArrayList<>();
        for (String videoPath : videoFiles) {
            Uri uri;
            // only for gingerbread and newer versions
            uri = FileProvider.getUriForFile(context,
                    context.getApplicationContext().getPackageName()+".provider", new File(videoPath));
            uriArrayList.add(uri);
        }
        // Intent videoShare = new Intent(Intent.ACTION_SEND_MULTIPLE);
        Intent videoShare = new Intent(Intent.ACTION_SEND_MULTIPLE);
//        videoShare.setPackage("com.whatsapp");
        videoShare.setType("video/*");
        videoShare.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uriArrayList);
        videoShare.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        context.startActivity(Intent.createChooser(videoShare, title));
    }

    public static void shareVideoFile(Context context, String filePath, String title) {
        File fileWithinMyDir = new File(filePath);
        if (fileWithinMyDir.exists()) {
            Uri uri = Uri.parse(filePath);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("video/*");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            context.startActivity(Intent.createChooser(share, title));
        }
    }

    private static int copyFile(File sourceFile, File destFile) {
        if (!destFile.getParentFile().exists())
            destFile.getParentFile().mkdirs();

        if (!destFile.exists()) {
            try {
                destFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else return FILE_EXISTS;

        FileChannel source = null;
        FileChannel destination = null;

        try {
            source = new FileInputStream(sourceFile).getChannel();
            destination = new FileOutputStream(destFile).getChannel();
            destination.transferFrom(source, 0, source.size());
        } catch (Exception ignored) {

        } finally {
            if (source != null) {
                try {
                    source.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (destination != null) {
                try {
                    destination.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return FILE_COPIED;
    }


    public static boolean isImageFile(String path) {
        String mimeType = URLConnection.guessContentTypeFromName(path);
        return mimeType != null && mimeType.startsWith("image");
    }

    public static String getMimType(String filePath) {
        return URLConnection.guessContentTypeFromName(filePath);
    }

    public static boolean isVideoFile(String path) {
        String mimeType = URLConnection.guessContentTypeFromName(path);
        return mimeType != null && mimeType.startsWith("video");
    }

    public static boolean isVoiceFile(String path) {
        String mimeType = URLConnection.guessContentTypeFromName(path);
        return mimeType != null && mimeType.startsWith("voice");
    }

    public static void startAnimation(Activity context) {
//        context.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    public static boolean appInstalledOrNot(String uri, Context context) {
        PackageManager pm = context.getPackageManager();
        boolean app_installed = false;
        try {
            pm.getPackageInfo(uri, 0);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }

    public static String getPackageName(String url) {
        return url.split("=")[1].toString();
    }


    public static boolean isMyServiceRunning(Class<?> serviceClass, Context context) {
        try {
            ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (serviceClass.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
        } catch (SecurityException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static String getDuration(File file) {
        MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
        mediaMetadataRetriever.setDataSource(file.getAbsolutePath());
        String durationStr = mediaMetadataRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
        return Common.formateMilliSeccond(Long.parseLong(durationStr));
    }

    public static String formateMilliSeccond(long milliseconds) {
        String finalTimerString = "";
        String secondsString = "";

        // Convert total duration into time
        int hours = (int) (milliseconds / (1000 * 60 * 60));
        int minutes = (int) (milliseconds % (1000 * 60 * 60)) / (1000 * 60);
        int seconds = (int) ((milliseconds % (1000 * 60 * 60)) % (1000 * 60) / 1000);

        // Add hours if there
        if (hours > 0) {
            finalTimerString = hours + ":";
        }

        // Prepending 0 to seconds if it is one digit
        if (seconds < 10) {
            secondsString = "0" + seconds;
        } else {
            secondsString = "" + seconds;
        }

        finalTimerString = finalTimerString + minutes + ":" + secondsString;

        return finalTimerString;
    }

    public static void shareImageFile(String filePath, Context context) {
        File fileWithinMyDir = new File(filePath);
        if (fileWithinMyDir.exists()) {
            Uri uri = Uri.parse(filePath);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("image/*");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            context.startActivity(Intent.createChooser(share, "Share Image"));
        }
    }

    public static List<String> getVoiceList() {
        voiceList = new ArrayList<>();

//        files = Voicefolder.listFiles();
//        if (files != null) {
//            Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
//            for (File file : files) {
//                if (file.getName().contains(".opus")) {
//                    voiceList.add(file.getPath());
//                } else {
//                    File subFile = new File(file.getPath());
//                    try {
//                        for (File sub : subFile.listFiles()) {
//                            if (sub.getName().contains(".opus")) {
//                                voiceList.add(sub.getPath());
//                            }
//                        }
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//        }

        return voiceList;

    }


    public static boolean isRorAbove() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.R;
    }

//    public static List<MediaModel> fetchImagesBusiness() {
//        List<MediaModel> list = new ArrayList<>();
//
//        try {
//            if (Build.VERSION.SDK_INT >= 30) {
//                String listPath = PrefHelper.getStringVal("PersistentPathBusiness");
//                Log.i("fetchImagesBusiness: ", listPath);
//                DocumentFile[] listFiles = DocumentFile.fromTreeUri(App.context, Uri.parse(PrefHelper.getStringVal("PersistentPathBusiness"))).listFiles();
//                int i2 = 0;
//                while (i2 < listFiles.length) {
//                    DocumentFile documentFile = listFiles[i2];
//                    if (documentFile.getUri().toString().endsWith(".Statuses")) {
//                        DocumentFile[] listFiles2 = documentFile.listFiles();
//                        int i3 = 0;
//                        while (i3 < listFiles2.length) {
//                            DocumentFile documentFile2 = listFiles2[i3];
//                            if (documentFile2.getName().endsWith(".jpg") ||
//                                    documentFile2.getName().endsWith(".png") ||
//                                    documentFile2.getName().endsWith(".mp4") ||
//                                    documentFile2.getName().endsWith(".3gp") ||
//                                    documentFile2.getName().endsWith(".avi") ||
//                                    documentFile2.getName().endsWith(".flv")) {
//                                MediaModel mediaModel = new MediaModel();
//                                mediaModel.setPath(documentFile2.getUri().toString());
//                                mediaModel.setSelected(false);
//                                list.add(mediaModel);
//                            }
//                            i3++;
//                        }
//                    }
//                    i2++;
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return list;
//    }

//    public static List<MediaModel> fetchImages() {
//        List<MediaModel> list = new ArrayList<>();
//
//        try {
//            if (Build.VERSION.SDK_INT >= 30) {
//                DocumentFile[] listFiles = DocumentFile.fromTreeUri(App.context, Uri.parse(PrefHelper.getStringVal("PersistentPath"))).listFiles();
//                int i2 = 0;
//                while (i2 < listFiles.length) {
//                    DocumentFile documentFile = listFiles[i2];
//                    if (documentFile.getUri().toString().endsWith(".Statuses")) {
//                        DocumentFile[] listFiles2 = documentFile.listFiles();
//                        int i3 = 0;
//                        while (i3 < listFiles2.length) {
//                            DocumentFile documentFile2 = listFiles2[i3];
//                            if (documentFile2.getName().endsWith(".jpg") ||
//                                    documentFile2.getName().endsWith(".png") ||
//                                    documentFile2.getName().endsWith(".mp4") ||
//                                    documentFile2.getName().endsWith(".3gp") ||
//                                    documentFile2.getName().endsWith(".avi") ||
//                                    documentFile2.getName().endsWith(".flv")) {
//                                MediaModel mediaModel = new MediaModel();
//                                String pathToSet = documentFile2.getUri().toString();
//                                mediaModel.setPath(pathToSet);
//                                mediaModel.setSelected(false);
//                                list.add(mediaModel);
//                            }
//                            i3++;
//                        }
//                    }
//                    i2++;
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return list;
//    }

    public static Uri getImageContentUri(Context context, File imageFile) {
        String filePath = imageFile.getAbsolutePath();
        Cursor cursor = context.getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media._ID},
                MediaStore.Images.Media.DATA + "=? ",
                new String[]{filePath}, null);
        if (cursor != null && cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID));
            cursor.close();
            return Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "" + id);
        } else {
            if (imageFile.exists()) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DATA, filePath);
                return context.getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            } else {
                return null;
            }
        }
    }

    public static Uri getVideoContentUri(Context context, File file) {
        String filePath = file.getAbsolutePath();
        Cursor cursor = context.getContentResolver().query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Video.Media._ID},
                MediaStore.Video.Media.DATA + "=? ",
                new String[]{filePath}, null);
        if (cursor != null && cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID));
            cursor.close();
            return Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "" + id);
        } else {
            if (file.exists()) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Video.Media.DATA, filePath);
                return context.getContentResolver().insert(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            } else {
                return null;
            }
        }
    }

//    public static boolean isAllPermission(){
//        return PrefHelper.getBooleanVal("storage") && PrefHelper.getBooleanVal("notification") && PrefHelper.getBooleanVal("battery_optimization");
//    }

    public static void shareFile(Context context, File file, String mediaType) {
        Intent shareIntent = new Intent();
        Uri uri = FileProvider.getUriForFile(context,
                APPLICATION_ID + ".provider", file); //issue
        shareIntent.setAction("android.intent.action.SEND");
        shareIntent.putExtra("android.intent.extra.STREAM", uri);
        shareIntent.setType(mediaType);
        shareIntent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        context.startActivity(Intent.createChooser(shareIntent, "Share File"));

    }

    /**
     * Get the value of the data column for this Uri. This is useful for
     * MediaStore Uris, and other file-based ContentProviders.
     *
     * @param context       The context.
     * @param uri           The Uri to query.
     * @param selection     (Optional) Filter used in the query.
     * @param selectionArgs (Optional) Selection arguments used in the query.
     * @return The value of the _data column, which is typically a file path.
     */
    public static String getDataColumn(Context context, Uri uri, String selection,
                                       String[] selectionArgs) {

        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {
                column
        };

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int column_index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(column_index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }
    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is ExternalStorageProvider.
     */
    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is DownloadsProvider.
     */
    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is MediaProvider.
     */
    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public static String getPath(final Context context, final Uri uri) {

        final boolean isKitKat = true;

        // DocumentProvider
        if (DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }

                // TODO handle non-primary volumes
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.parseLong(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[]{
                        split[1]
                };

                return getDataColumn(context, contentUri, selection, selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {
            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    public void genVideoUsingMuxer(String srcPath, String dstPath, int startMs, int endMs, boolean useAudio, boolean useVideo) throws IOException {
        // Set up MediaExtractor to read from the source.
        MediaExtractor extractor = new MediaExtractor();
        extractor.setDataSource(srcPath);
        int trackCount = extractor.getTrackCount();
        // Set up MediaMuxer for the destination.
        MediaMuxer muxer;
        muxer = new MediaMuxer(dstPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        // Set up the tracks and retrieve the max buffer size for selected
        // tracks.
        HashMap<Integer, Integer> indexMap = new HashMap<Integer, Integer>(trackCount);
        int bufferSize = -1;
        for (int i = 0; i < trackCount; i++) {
            MediaFormat format = extractor.getTrackFormat(i);
            String mime = format.getString(MediaFormat.KEY_MIME);
            boolean selectCurrentTrack = false;
            if (mime.startsWith("audio/") && useAudio) {
                selectCurrentTrack = true;
            } else if (mime.startsWith("video/") && useVideo) {
                selectCurrentTrack = true;
            }
            if (selectCurrentTrack) {
                extractor.selectTrack(i);
                int dstIndex = muxer.addTrack(format);
                indexMap.put(i, dstIndex);
                if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                    int newSize = format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE);
                    bufferSize = Math.max(newSize, bufferSize);
                }
            }
        }
        if (bufferSize < 0) {
            bufferSize = DEFAULT_BUFFER_SIZE;
        }
        // Set up the orientation and starting time for extractor.
        MediaMetadataRetriever retrieverSrc = new MediaMetadataRetriever();
        retrieverSrc.setDataSource(srcPath);
        String degreesString = retrieverSrc.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
        if (degreesString != null) {
            int degrees = Integer.parseInt(degreesString);
            if (degrees >= 0) {
                muxer.setOrientationHint(degrees);
            }
        }
        if (startMs > 0) {
            extractor.seekTo(startMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
        }
        // Copy the samples from MediaExtractor to MediaMuxer. We will loop
        // for copying each sample and stop when we get to the end of the source
        // file or exceed the end time of the trimming.
        int offset = 0;
        int trackIndex = -1;
        ByteBuffer dstBuf = ByteBuffer.allocate(bufferSize);
        MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
        muxer.start();
        while (true) {
            bufferInfo.offset = offset;
            bufferInfo.size = extractor.readSampleData(dstBuf, offset);
            if (bufferInfo.size < 0) {
                bufferInfo.size = 0;
                break;
            } else {
                bufferInfo.presentationTimeUs = extractor.getSampleTime();
                if (endMs > 0 && bufferInfo.presentationTimeUs > (endMs * 1000L)) {
                    break;
                } else {
                    bufferInfo.flags = extractor.getSampleFlags();
                    trackIndex = extractor.getSampleTrackIndex();
                    muxer.writeSampleData(indexMap.get(trackIndex), dstBuf, bufferInfo);
                    extractor.advance();
                }
            }
        }


        try {
            muxer.stop();
        } catch (Throwable e) {
            e.printStackTrace();
        }

        muxer.release();
    }

    public static boolean isAppInstalled(Context context, String packageName) {
        try {
            context.getPackageManager().getApplicationInfo(packageName, 0);
            return true;
        }
        catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

}