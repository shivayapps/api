package com.simplified.wsstatussaver.fragments

//import com.crazylegend.audiopicker.audios.AudioModel
//import com.crazylegend.audiopicker.pickers.MultiAudioPicker
//import com.crazylegend.audiopicker.pickers.SingleAudioPicker
//import com.crazylegend.core.dto.PickerConfig
//import com.crazylegend.core.modifiers.SizeTextModifier
import android.app.ProgressDialog
import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaPlayer.OnPreparedListener
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.view.View
import android.widget.MediaController
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.doOnPreDraw
import androidx.fragment.app.Fragment
import com.google.android.material.transition.MaterialSharedAxis
import com.simplified.wsstatussaver.R
import com.simplified.wsstatussaver.databinding.FragmentSplitLongStatusBinding
import com.simplified.wsstatussaver.utils.Common
import java.io.IOException

class SplitLongStatusFragment : Fragment(R.layout.fragment_split_long_status), View.OnClickListener, MediaPlayer.OnCompletionListener {

    private var _binding: FragmentSplitLongStatusBinding? = null
    private val binding get() = _binding!!
    private var videoPath = ""

    //    private lateinit var videoView: VideoView
//    private var path: String = ""
    private var splitFileCount: Int = 0
    private var stopPosition: Int = 0
    private var start: Int = -1
    private var end: Int = -1
    private val SEPARATOR = "/"
    private lateinit var progress: ProgressDialog
//    private lateinit var sharePref: SharePref


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentSplitLongStatusBinding.bind(view)

        setData()
        pickVideo()

        postponeEnterTransition()
        view.doOnPreDraw { startPostponedEnterTransition() }
        enterTransition = MaterialSharedAxis(MaterialSharedAxis.Y, true)
        reenterTransition = MaterialSharedAxis(MaterialSharedAxis.Y, true)
    }

    private fun pickVideo() {
        val intent = Intent().apply {
            type = "video/*"
            action = Intent.ACTION_GET_CONTENT
        }
        pickerLauncher.launch(intent)

//        SingleVideoPicker.showPicker(requireContext(), {
//        }, ::loadVideo)
//        SingleVideoPicker.showPicker(requireContext(),extensions = arrayOf(),pickerConfig = PickerConfig(showFileSize = true), {
//            setupBaseModifier(loadingIndicatorColor = R.color.minusColor, titleTextModifications = {
//                textAlignment = TextView.TEXT_ALIGNMENT_VIEW_START
//                textStyle = TitleTextModifier.TextStyle.ITALIC
//                textColor = Color.BLACK
//                marginBottom = 30 // use dp or sp this is only for demonstration purposes
//                textPadding = 5 // use dp or sp this is only for demonstration purposes
//                textSize = 30f  // use sp this is only for demonstration purposes
//                textString = "Pick a video"
//            }, placeHolderModifications = {
//                resID = R.drawable.ic_image
//            }, sizeTextModifications = {
//                textAlignment = TextView.TEXT_ALIGNMENT_VIEW_START
//                textStyle = SizeTextModifier.TextStyle.NORMAL
//                margin = 22 // use dp or sp this is only for demonstration purposes
//                textColor = Color.BLACK
//                textPadding = 5 // use dp or sp this is only for demonstration purposes
//                textSize = 12f  // use sp this is only for demonstration purposes
//                backgroundDrawable = R.drawable.rounded_bg_abstract_dialog
//            }
//            )
//        }::loadVideo)
    }

//    private fun loadVideo(videoModel: VideoModel) {
//
//    }


    override fun onPause() {
        super.onPause()
        try {
            stopPosition = binding.videoView.getCurrentPosition() //stopPosition is an int
            binding.videoView.pause()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    override fun onResume() {
        super.onResume()

        try {
            if (stopPosition == binding.videoView.getDuration()) stopPosition = 0
            binding.videoView.seekTo(stopPosition)
            binding.videoView.start() //Or use resume() if it doesn't work. I'm not sure
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    private fun setUpVideo() {

        val controller = MediaController(requireActivity())
        end = getDuration()
        binding.videoView.setOnPreparedListener(OnPreparedListener {
            val duration: Int = binding.videoView.getDuration() / 1000
            val splitTime = if (getDuration() === 29000) {
                29
            } else {
                15
            }
            splitFileCount = duration / splitTime + 1
        })
        controller.setAnchorView(binding.videoView)
        controller.setMediaPlayer(binding.videoView)
        binding.videoView.setMediaController(controller)
        binding.videoView.setVideoPath(videoPath)
        binding.videoView.setOnCompletionListener(this)
        binding.videoView.requestFocus()
        binding.videoView.start()
    }

    private fun setData() {
//        val intent = Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
//        pickerLauncher.launch(intent)
        binding.upload.setOnClickListener(this)


//        path = getIntent().getStringExtra("path")
    }


    var pickerLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            var selectedVideo: Uri? = null
            selectedVideo = result.data?.data!!

            if (selectedVideo == null) {
                Toast.makeText(requireActivity(), "video not supported", Toast.LENGTH_SHORT).show()
            } else {
                try {
                    videoPath = Common.getPath(requireActivity(), selectedVideo)
                    if (videoPath.isNotEmpty()) setUpVideo()
                    else Toast.makeText(requireActivity(), "Please retry to select video...!", Toast.LENGTH_LONG).show()

//                    intent.putExtra("path", filePath)
//                    startActivity(intent)
//                    Common.startAnimation(this)
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(requireActivity(), "Please retry to select video...!", Toast.LENGTH_LONG).show()
                }
            }
        } else {
            Toast.makeText(requireActivity(), "Please retry to select video...!", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.upload -> {
                if (videoPath.isNotEmpty()) SplitVideo().execute()
                else pickVideo()
            }
        }
    }

    override fun onCompletion(p0: MediaPlayer?) {
        binding.videoView.start();
    }

    private fun splitVideo() {
        val videoFiles = ArrayList<String>()
        for (i in 0 until splitFileCount) {
            val outputPath = "${Common.splitVideoFolder.path}$SEPARATOR${"video"}$i.mp4"
            videoFiles.add(outputPath)
            try {
                Common().genVideoUsingMuxer(videoPath, outputPath, start, end, true, true)
                start = end
                end += getDuration()
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
        Common.shareMultipleVideo(requireActivity(), videoFiles, "Share Videos")
    }

    inner class SplitVideo : AsyncTask<Void, Void, Void>() {

        override fun onPreExecute() {
            super.onPreExecute()
            progress = ProgressDialog(requireActivity()).apply {
                setTitle("Splitting the video")
                setMessage("Please wait...")
                setCancelable(false) // disable dismiss by tapping outside of the dialog
                show()
            }
        }

        override fun doInBackground(vararg params: Void?): Void? {
            splitVideo()
            return null
        }

        override fun onPostExecute(result: Void?) {
            super.onPostExecute(result)
            dismissProgressDialog()
        }
    }

    private fun getDuration(): Int {
        return 29000
    }

    private fun dismissProgressDialog() {
        if (::progress.isInitialized && progress.isShowing) {
            progress.dismiss()
        }
    }


}