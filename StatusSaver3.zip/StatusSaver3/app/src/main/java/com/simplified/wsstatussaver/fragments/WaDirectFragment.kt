package com.simplified.wsstatussaver.fragments

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.view.doOnPreDraw
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.transition.MaterialSharedAxis
import com.simplified.wsstatussaver.R
import com.simplified.wsstatussaver.adapter.StyleAdapter
import com.simplified.wsstatussaver.databinding.FragmentTextDecoratorBinding
import com.simplified.wsstatussaver.databinding.FragmentWaDirectBinding
import com.simplified.wsstatussaver.utils.Common
import com.simplified.wsstatussaver.utils.Constants
import java.net.URLEncoder
import java.util.Locale

class WaDirectFragment : Fragment(R.layout.fragment_wa_direct), View.OnClickListener {

    private var _binding: FragmentWaDirectBinding? = null
    private val binding get() = _binding!!

    var countryCode: String? = null
    var number: String? = null
    var numberWithCountryCode: String? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentWaDirectBinding.bind(view)

        setData()

        postponeEnterTransition()
        view.doOnPreDraw { startPostponedEnterTransition() }
        enterTransition = MaterialSharedAxis(MaterialSharedAxis.Y, true)
        reenterTransition = MaterialSharedAxis(MaterialSharedAxis.Y, true)
    }

    private fun setData() {

        binding.sendWa.setOnClickListener(this)
        binding.sendWb.setOnClickListener(this)
        binding.share.setOnClickListener(this)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.sendWa -> {
                if (!Common.isAppInstalled(context, "com.whatsapp")) {
                    Toast.makeText(context, "Whatsapp not installed", Toast.LENGTH_SHORT).show()
                    return
                }
                countryCode = binding.ccp.selectedCountryCode
                number = binding.edNumber.text.toString()

                if (number!!.isNotEmpty()) {
                    send("com.whatsapp")
                } else {
                    Toast.makeText(context, "Enter Number", Toast.LENGTH_SHORT).show()
                }
            }

            R.id.sendWb -> {
                if (!Common.isAppInstalled(context, "com.whatsapp.w4b")) {
                    Toast.makeText(context, "Whatsapp not installed", Toast.LENGTH_SHORT).show()
                    return
                }
                countryCode = binding.ccp.selectedCountryCode
                number = binding.edNumber.text.toString()

                if (number!!.isNotEmpty()) {
                    send("com.whatsapp.w4b")
                } else {
                    Toast.makeText(context, "Enter Number", Toast.LENGTH_SHORT).show()
                }
            }

            R.id.share -> shareMessage(binding.edMsg.text.toString())
        }
    }

    private fun shareMessage(message: String) {
        val sendIntent = Intent()
        sendIntent.action = Intent.ACTION_SEND
        sendIntent.putExtra(Intent.EXTRA_TEXT, message)
        sendIntent.type = "text/plain"
        startActivity(Intent.createChooser(sendIntent, "share via"))
    }

    private fun send(pack: String) {
        numberWithCountryCode = try {
            if (number!![0].code == 0) {
                number!!.replace("(^|[^0-9])0+".toRegex(), countryCode!!)
            } else {
                countryCode + number
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Enter Number", Toast.LENGTH_SHORT).show()
            return
        }
        val packageManager = requireContext().packageManager
        val i = Intent(Intent.ACTION_VIEW)
        try {
            val url =
                "https://api.whatsapp.com/send?phone=$numberWithCountryCode&text=" + URLEncoder.encode(
                    binding.edMsg.text.toString(), "UTF-8"
                )
            i.setPackage(pack)
            i.data = Uri.parse(url)
            if (i.resolveActivity(packageManager) != null) {
                startActivity(i)
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Invalid Number", Toast.LENGTH_SHORT).show()
        }
    }

}