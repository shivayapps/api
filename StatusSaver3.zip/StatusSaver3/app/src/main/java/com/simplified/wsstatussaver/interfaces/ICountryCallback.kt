package com.simplified.wsstatussaver.interfaces

import com.simplified.wsstatussaver.model.Country

interface ICountryCallback {
    fun countryClick(country: Country)
}