package com.simplified.wsstatussaver.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.fragment.app.FragmentActivity
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.simplified.wsstatussaver.R
import com.simplified.wsstatussaver.WhatSaveViewModel
import com.simplified.wsstatussaver.activities.base.BaseActivity
import com.simplified.wsstatussaver.databinding.ActivityMainBinding
import com.simplified.wsstatussaver.extensions.getPreferredClient
import com.simplified.wsstatussaver.extensions.hasStoragePermissions
import com.simplified.wsstatussaver.extensions.startActivitySafe

import com.simplified.wsstatussaver.utils.AdCache
import org.koin.androidx.viewmodel.ext.android.viewModel


class StatusesActivity : BaseActivity() {

    //    private val viewModel by viewModel<WhatSaveViewModel>()
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        val navHostFragment = supportFragmentManager.findFragmentById(R.id.global_container) as NavHostFragment
//        val navController = navHostFragment.navController
//        navController.addOnDestinationChangedListener(object : NavController.OnDestinationChangedListener {
//            override fun onDestinationChanged(controller: NavController, destination: NavDestination, arguments: Bundle?) {
//                Log.e("navController","destination:${destination.id}")
//                if (destination.id == R.id.onboardFragment) {
//                    binding.llAds.visibility = View.GONE
//                } else {
//                    binding.llAds.visibility = View.VISIBLE
//                }
//            }
//        })

        loadAds()
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()

    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadAds() {
        val adId = getString(R.string.b_homeActivity)
        BannerAdHelper.showBanner(this,
            binding.frameAds,
            binding.frameAds,
            adId,
            AdCache.homeAdView,
            { isLoaded, adView, message ->
//                if (!isDestroyed) {
                mAdView = adView
                AdCache.homeAdView = adView
                isAdLoaded = isLoaded
//                }
            })
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        if (!hasStoragePermissions()) {
            startActivity(Intent(this, PermissionActivity::class.java))
//            requestPermissions(preferences().isShownOnboard)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        menu.setupWhatsAppMenuItem(this)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_settings -> {
                val intent = Intent(this, SettingsActivity::class.java)
                startActivitySafe(intent)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onSupportNavigateUp(): Boolean =
        findNavController(R.id.main_container).navigateUp()
}

fun Menu.setupWhatsAppMenuItem(activity: FragmentActivity) {
    this.removeItem(R.id.action_launch_client)

    val client = activity.getPreferredClient()
    if (client != null) {
        this.add(
            Menu.NONE, R.id.action_launch_client,
            Menu.FIRST, activity.getString(R.string.launch_x_client, client.displayName)
        )
            .setIcon(R.drawable.ic_open_in_new_24dp)
            .setIntent(client.getLaunchIntent(activity.packageManager))
            .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
    }
}