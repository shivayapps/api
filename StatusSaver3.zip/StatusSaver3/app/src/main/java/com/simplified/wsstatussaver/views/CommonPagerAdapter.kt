package com.simplified.wsstatussaver.views

import android.view.View
import android.view.ViewGroup
import androidx.annotation.IdRes
import androidx.viewpager.widget.PagerAdapter


class CommonPagerAdapter : PagerAdapter() {
    private val pageIds: ArrayList<Int> = ArrayList()
    private val pageTitles: ArrayList<String> = ArrayList()
    fun insertViewId(@IdRes pageId: Int,title:String) {
        pageIds.add(pageId)
        pageTitles.add(title)
    }

    override fun getPageTitle(position: Int): CharSequence? {
        try {
            return pageTitles[position]
        } catch (e: Exception) {
            return super.getPageTitle(position)
        }
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        return container.findViewById(pageIds[position])
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(`object` as View?)
    }

    override fun getCount(): Int {
        return pageIds.size
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

}