
package com.simplified.wsstatussaver.model


enum class SavedContentState {
    HasSavedContent, HasNotSavedContent, UnknownState
}