package com.simplified.wsstatussaver.model

import android.net.Uri
import android.os.Parcelable
import kotlinx.parcelize.Parcelize


@Parcelize
open class Status(
    open val type: StatusType,
    open val name: String,
    open val fileUri: Uri,
    open val dateModified: Long,
    open val size: Long,
    open val clientPackage: String?,
    open val isSaved: Boolean
) : Parcelable