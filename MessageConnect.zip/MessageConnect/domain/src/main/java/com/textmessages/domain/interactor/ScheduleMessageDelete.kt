package com.textmessages.domain.interactor

import io.reactivex.Flowable
import io.reactivex.rxkotlin.toFlowable
import io.realm.RealmList
import com.textmessages.domain.extensions.mapNotNull
import com.textmessages.domain.interactor.Interactor
import com.textmessages.domain.repository.ScheduledMessageRepository
import javax.inject.Inject

class ScheduleMessageDelete @Inject constructor(
    private val scheduledMessageRepo: ScheduledMessageRepository
) : Interactor<Long>() {
    override fun buildObservable(params: Long): Flowable<*> {
        return Flowable.just(params)
            .mapNotNull(scheduledMessageRepo::getScheduledMessage)
            .flatMap { message ->
                if (message.sendAsGroup) {
                    listOf(message)
                } else {
                    message.recipients.map { recipient ->
                        message.copy(
                            recipients = RealmList(
                                recipient
                            )
                        )
                    }
                }.toFlowable()
            }
            .doOnNext { scheduledMessageRepo.deleteScheduledMessage(params) }
    }

}