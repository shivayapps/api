package com.textmessages.domain.experiment

data class Variant<T>(val key: String, val value: T)