package com.textmessages.domain.interactor

import io.reactivex.Flowable
import com.textmessages.domain.repository.BackupRepository
import javax.inject.Inject

class PerformRestore @Inject constructor(
    private val backupRepo: BackupRepository
) : Interactor<String>() {

    override fun buildObservable(params: String): Flowable<*> {
        return Flowable.just(params)
            .doOnNext(backupRepo::performRestore)
    }

}