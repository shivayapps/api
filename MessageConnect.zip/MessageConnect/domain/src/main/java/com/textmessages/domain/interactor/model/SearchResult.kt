package com.textmessages.domain.interactor.model

data class SearchResult(val query: String, val conversation: Conversation, val messages: Int)