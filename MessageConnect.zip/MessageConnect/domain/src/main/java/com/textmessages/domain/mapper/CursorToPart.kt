package com.textmessages.domain.mapper

import android.database.Cursor
import com.textmessages.domain.interactor.model.MmsPart

interface CursorToPart : Mapper<Cursor, MmsPart> {

    fun getPartsCursor(messageId: Long?=null): Cursor?

}