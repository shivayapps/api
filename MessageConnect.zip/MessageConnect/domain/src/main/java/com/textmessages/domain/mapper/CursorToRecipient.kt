package com.textmessages.domain.mapper

import android.database.Cursor
import com.textmessages.domain.interactor.model.Recipient

interface CursorToRecipient : Mapper<Cursor, Recipient> {

    fun getRecipientCursor(): Cursor?

    fun getRecipientCursor(id: Long): Cursor?

}