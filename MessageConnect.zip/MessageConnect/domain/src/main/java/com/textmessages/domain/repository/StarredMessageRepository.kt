package com.textmessages.domain.repository

import io.realm.RealmResults
import com.textmessages.domain.interactor.model.Conversation
import com.textmessages.domain.interactor.model.Message

interface StarredMessageRepository {

    /**
     * Returns all of the Starred messages, sorted chronologically
     */
    fun getStarredMessages(): RealmResults<Message>

    /**
     * Returns the Starred message with the given [id]
     */
    fun getStarredMessages(id: Long): Message?

    /**
     * Returns the Conversation for the given [id]
     */
    fun getConversation(id: Long): Conversation?

    /**
     * Deletes the Starred message with the given [id]
     */
    fun deleteStarredMessage(id: Long)

}