package com.textmessages.domain.interactor

import io.reactivex.Flowable
import com.textmessages.domain.manager.NotificationManager
import com.textmessages.domain.repository.MessageRepository
import javax.inject.Inject

class MarkSent @Inject constructor(
    private val messageRepo: MessageRepository,
    private val notificationManager: NotificationManager
) : Interactor<Long>() {

    override fun buildObservable(params: Long): Flowable<Unit> {
        return Flowable.just(Unit)
            .doOnNext { messageRepo.markSent(params) }
            .doOnNext { notificationManager.logSent(params) }
    }

}