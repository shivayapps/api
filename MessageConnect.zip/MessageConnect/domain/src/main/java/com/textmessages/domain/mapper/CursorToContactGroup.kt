package com.textmessages.domain.mapper

import android.database.Cursor
import com.textmessages.domain.interactor.model.ContactGroup

interface CursorToContactGroup : Mapper<Cursor, ContactGroup> {

    fun getContactGroupsCursor(): Cursor?

}
