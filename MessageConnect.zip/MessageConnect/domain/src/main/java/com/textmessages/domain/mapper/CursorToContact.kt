package com.textmessages.domain.mapper

import android.database.Cursor
import com.textmessages.domain.interactor.model.Contact

interface CursorToContact : Mapper<Cursor, Contact> {

    fun getContactsCursor(): Cursor?

}