package com.textmessages.domain.manager

interface PermissionManager {

    fun isDefaultSms(): Boolean

    fun hasReadSms(): Boolean

    fun hasSendSms(): Boolean
    fun hasSchedule(): Boolean

    fun hasContacts(): Boolean

    fun hasPhone(): Boolean

    fun hasCalling(): Boolean

    fun hasStorage(): Boolean

    fun hasLocation(): Boolean

    fun hasSystemOverlay(): Boolean

}