package com.textmessages.data.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.android.AndroidInjection
import com.textmessages.domain.interactor.MarkArchived
import com.textmessages.domain.extensions.LogE
import javax.inject.Inject

class MarkArchivedReceiver : BroadcastReceiver() {

    @Inject
    lateinit var markArchived: MarkArchived

    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)
        val pendingResult = goAsync()
        val threadId = intent.getLongExtra("threadId", 0)
        markArchived.execute(listOf(threadId)) {
            try {
                pendingResult.finish()
            } catch (e: IllegalStateException) {
                com.textmessages.domain.extensions.LogE(
                    "IllegalStateException: ",
                    e.message.toString()
                )
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}