package com.textmessages.data.compat

import android.content.Context
import android.os.Build
import android.telephony.SubscriptionManager
import com.textmessages.domain.manager.PermissionManager
import javax.inject.Inject

class SubscriptionManagerCompat @Inject constructor(context: Context, private val permissions: PermissionManager) {

    private val subscriptionManager: SubscriptionManager?
        get() = field?.takeIf { permissions.hasPhone() }

    val activeSubscriptionInfoList: List<com.textmessages.data.compat.SubscriptionInfoCompat>
        get() {
            return if (Build.VERSION.SDK_INT >= 22) {
                subscriptionManager?.activeSubscriptionInfoList?.map {
                    com.textmessages.data.compat.SubscriptionInfoCompat(
                        it
                    )
                } ?: listOf()
            } else listOf()
        }

    init {
        subscriptionManager = if (Build.VERSION.SDK_INT >= 22) SubscriptionManager.from(context) else null
    }

    fun addOnSubscriptionsChangedListener(listener: com.textmessages.data.compat.SubscriptionManagerCompat.OnSubscriptionsChangedListener) {
        if (Build.VERSION.SDK_INT >= 22) {
            subscriptionManager?.addOnSubscriptionsChangedListener(listener.listener)
        }
    }

    fun removeOnSubscriptionsChangedListener(listener: com.textmessages.data.compat.SubscriptionManagerCompat.OnSubscriptionsChangedListener) {
        if (Build.VERSION.SDK_INT >= 22) {
            subscriptionManager?.removeOnSubscriptionsChangedListener(listener.listener)
        }
    }

    abstract class OnSubscriptionsChangedListener {

        val listener: SubscriptionManager.OnSubscriptionsChangedListener? = if (Build.VERSION.SDK_INT >= 22) {
            object : SubscriptionManager.OnSubscriptionsChangedListener() {
                override fun onSubscriptionsChanged() {
                    this@OnSubscriptionsChangedListener.onSubscriptionsChanged()
                }
            }
        } else null

        abstract fun onSubscriptionsChanged()

    }

}