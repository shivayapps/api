package com.textmessages.data.repository

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.provider.Telephony
import sms.messages.app.message.box.message.me.compat.TelephonyCompat
import sms.messages.app.message.box.message.me.util.tryOrNull
import io.reactivex.Completable
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import io.realm.Case
import io.realm.Realm
import io.realm.RealmResults
import io.realm.Sort
import com.textmessages.data.extensions.anyOf
import com.textmessages.data.extensions.asObservable
import com.textmessages.data.extensions.map
import com.textmessages.data.extensions.removeAccents
import com.textmessages.data.filter.ConversationFilter
import com.textmessages.data.util.PhoneNumberUtils
import com.textmessages.data.extensions.LogD
import com.textmessages.data.extensions.LogW
import com.textmessages.domain.feature.conversationinfo.ConversationInfoItem
import com.textmessages.domain.feature.conversationinfo.ConversationInfoItem.ConversationInfoMedia
import com.textmessages.domain.interactor.model.BlockedNumber
import com.textmessages.domain.interactor.model.Contact
import com.textmessages.domain.interactor.model.Conversation
import com.textmessages.domain.interactor.model.Message
import com.textmessages.domain.interactor.model.MmsPart
import com.textmessages.domain.interactor.model.PhoneNumber
import com.textmessages.domain.interactor.model.Recipient
import com.textmessages.domain.interactor.model.SearchResult
import com.textmessages.domain.interactor.model.WidgetModel
import com.textmessages.domain.mapper.CursorToConversation
import com.textmessages.domain.mapper.CursorToRecipient
import com.textmessages.domain.repository.ConversationRepository
import timber.log.Timber
import java.util.*
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class
ConversationRepositoryImpl @Inject constructor(
    private val context: Context,
    private val conversationFilter: ConversationFilter,
    private val cursorToConversation: CursorToConversation,
    private val cursorToRecipient: CursorToRecipient,
    private val phoneNumberUtils: PhoneNumberUtils
) : ConversationRepository {


    override fun getConversations(
        archived: Boolean,
        limit: Long
    ): Pair<RealmResults<Conversation>, Boolean> {
        val data = Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("archived", archived)
            .equalTo("blocked", false)
            .isNotEmpty("recipients")
            .beginGroup()
            .isNotNull("lastMessage")
            .or()
            .isNotEmpty("draft")
            .endGroup()
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            )
//            .limit(limit)
            .findAllAsync()
        return Pair(data, false)
    }

    override fun getAllConversations(
        limit: Long
    ): RealmResults<Conversation> {
        val data = Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("blocked", false)
            .isNotEmpty("recipients")
            .beginGroup()
            .isNotNull("lastMessage")
            .or()
            .isNotEmpty("draft")
            .endGroup()
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            )
//            .limit(limit)
            .findAllAsync()
        return data
    }

    override fun getConversationsFilter(
        archived: Boolean,
        limit: Long, startDate: Date, endDate: Date
    ): Pair<RealmResults<Conversation>, Boolean> {
        val cal = Calendar.getInstance()
        cal.time = startDate
        cal[Calendar.HOUR] = 0
        cal[Calendar.MINUTE] = 0
        cal[Calendar.SECOND] = 0
        cal[Calendar.MILLISECOND] = 0

        val cal1 = Calendar.getInstance()
        cal1.time = endDate
        cal1[Calendar.HOUR] = 24
        cal1[Calendar.MINUTE] = 0
        cal1[Calendar.SECOND] = 0
        cal1[Calendar.MILLISECOND] = 0

        val data = Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("archived", archived)
            .equalTo("blocked", false)
            .isNotEmpty("recipients")
            .beginGroup()
            .isNotNull("lastMessage")
            .or()
            .isNotEmpty("draft")
            .endGroup()
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            )
            .between("lastMessage.date", cal.timeInMillis, cal1.timeInMillis)
//            .limit(limit)
            .findAllAsync()
        return Pair(data, false)
    }

    override fun getConversationsSnapshot(): ArrayList<WidgetModel> {
        val widgetData = ArrayList<WidgetModel>()
        val conversations = Realm.getDefaultInstance().where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("archived", false)
            .equalTo("blocked", false)
            .isNotEmpty("recipients")
            .beginGroup()
            .isNotNull("lastMessage")
            .or()
            .isNotEmpty("draft")
            .endGroup()
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            )
            .findAll()
        for (conversation in conversations) {
            val widgetModel = WidgetModel()
            widgetModel.id = conversation.id
            val contact = conversation.recipients.map { recipient ->
                recipient.contact ?: Contact().apply {
                    numbers.add(PhoneNumber().apply {
                        address = recipient.address
                    })
                }
            }.firstOrNull()
            if (contact?.name.orEmpty().isNotEmpty()) {
                widgetModel.initial = contact?.name?.substring(0, 1)
            } else {
                widgetModel.initial = ""
            }
            widgetModel.photoUri = contact?.photoUri
            widgetModel.title = conversation.getTitle()
            widgetModel.unread = conversation.unread

            widgetModel.timestamp = conversation.date
            widgetModel.draft = conversation.draft
            widgetModel.me = conversation.me
            widgetModel.snippet = conversation.snippet
            widgetData.add(widgetModel)
        }
        return widgetData
    }

    override fun getTransactionConversation(limit: Long): RealmResults<Conversation> {

        return Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("archived", false)
            .equalTo("blocked", false)
            .isNotEmpty("recipients").and()
            .isNotNull("lastMessage").isNotEmpty("lastMessage.body")
            /*.beginGroup()
            .like("lastMessage.body", "*A/C*", Case.INSENSITIVE)
            .or()
            .like("lastMessage.body", "* Rs. *", Case.INSENSITIVE)
            .or()
            .like("lastMessage.body", "* INR *", Case.INSENSITIVE)
            .endGroup()*/
            .equalTo("lastMessage.messageCatType", "1".toInt())
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            )
//            .limit(limit)
            .findAllAsync()
    }

    override fun getTransactionConversationFilter(
        limit: Long,
        startDate: Date,
        endDate: Date
    ): RealmResults<Conversation> {

        val cal = Calendar.getInstance()
        cal.time = startDate
        cal[Calendar.HOUR] = 0
        cal[Calendar.MINUTE] = 0
        cal[Calendar.SECOND] = 0
        cal[Calendar.MILLISECOND] = 0

        val cal1 = Calendar.getInstance()
        cal1.time = endDate
        cal1[Calendar.HOUR] = 24
        cal1[Calendar.MINUTE] = 0
        cal1[Calendar.SECOND] = 0
        cal1[Calendar.MILLISECOND] = 0

        return Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("archived", false)
            .equalTo("blocked", false)
            .isNotEmpty("recipients").and()
            .isNotNull("lastMessage").isNotEmpty("lastMessage.body")
            /* .beginGroup()
             .like("lastMessage.body", "*A/C*", Case.INSENSITIVE)
             .and()
             .like("lastMessage.body", "*credit*", Case.INSENSITIVE)
             .or()
             .like("lastMessage.body", "*debit*", Case.INSENSITIVE)
             .and()
             .like("lastMessage.body", "* Rs. *", Case.INSENSITIVE)
             .or()
             .like("lastMessage.body", "* INR *", Case.INSENSITIVE)
             .endGroup()*/
            .equalTo("lastMessage.messageCatType", "1".toInt())
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            )
            .between("lastMessage.date", cal.timeInMillis, cal1.timeInMillis)
//            .limit(limit)
            .findAllAsync()
    }

    override fun getKnownSenderConversation(limit: Long): RealmResults<Conversation> {
        return Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("archived", false)
            .equalTo("blocked", false)
            .isNotEmpty("recipients")
            .beginGroup()
            .notEqualTo("recipients.contact.name", "").and()
            .isNotNull("lastMessage")
            .or()
            .isNotEmpty("draft")
            .endGroup()
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            )
//            .limit(limit)
            .findAllAsync()
    }

    override fun getKnownSenderConversationFilter(
        limit: Long,
        startDate: Date,
        endDate: Date
    ): RealmResults<Conversation> {
        val cal = Calendar.getInstance()
        cal.time = startDate
        cal[Calendar.HOUR] = 0
        cal[Calendar.MINUTE] = 0
        cal[Calendar.SECOND] = 0
        cal[Calendar.MILLISECOND] = 0

        val cal1 = Calendar.getInstance()
        cal1.time = endDate
        cal1[Calendar.HOUR] = 24
        cal1[Calendar.MINUTE] = 0
        cal1[Calendar.SECOND] = 0
        cal1[Calendar.MILLISECOND] = 0

        return Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("archived", false)
            .equalTo("blocked", false)
            .isNotEmpty("recipients")
            .beginGroup()
            .notEqualTo("recipients.contact.name", "").and()
            .isNotNull("lastMessage")
            .or()
            .isNotEmpty("draft")
            .endGroup()
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            )
            .between("lastMessage.date", cal.timeInMillis, cal1.timeInMillis)
//            .limit(limit)
            .findAllAsync()
    }

    override fun getPromotionConversation(limit: Long): RealmResults<Conversation> {
        return Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("archived", false)
            .equalTo("blocked", false)
            .equalTo("lastMessage.messageCatType", "3".toInt())
            /*.beginGroup()
            .isNotEmpty("recipients")
            .isNotNull("lastMessage")
            .isNotEmpty("draft")
            .or()
            .like("lastMessage.body", "*personal loan*", Case.INSENSITIVE)
            .or()
            .like("lastMessage.body", "*home loan*", Case.INSENSITIVE)
            .or()
            .like("lastMessage.body", "*hurry*", Case.INSENSITIVE)
            .or()
            .like("lastMessage.body", "*recharge*", Case.INSENSITIVE)
            .or()
            .like("lastMessage.body", "*cashback*", Case.INSENSITIVE)
            .or()
            .like("lastMessage.body", "*offer*", Case.INSENSITIVE)
            .endGroup()*/
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            )
//            .limit(limit)
            .findAllAsync()
    }

    override fun getPromotionConversationFilter(
        limit: Long,
        startDate: Date,
        endDate: Date
    ): RealmResults<Conversation> {
        val cal = Calendar.getInstance()
        cal.time = startDate
        cal[Calendar.HOUR] = 0
        cal[Calendar.MINUTE] = 0
        cal[Calendar.SECOND] = 0
        cal[Calendar.MILLISECOND] = 0

        val cal1 = Calendar.getInstance()
        cal1.time = endDate
        cal1[Calendar.HOUR] = 24
        cal1[Calendar.MINUTE] = 0
        cal1[Calendar.SECOND] = 0
        cal1[Calendar.MILLISECOND] = 0

        return Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("archived", false)
            .equalTo("blocked", false)
            .equalTo("lastMessage.messageCatType", "3".toInt())
            /*.beginGroup()
            .isNotEmpty("recipients")
            .isNotNull("lastMessage")
            .isNotEmpty("draft")
            .or()
            .like("lastMessage.body", "*personal loan*", Case.INSENSITIVE)
            .or()
            .like("lastMessage.body", "*home loan*", Case.INSENSITIVE)
            .or()
            .like("lastMessage.body", "*hurry*", Case.INSENSITIVE)
            .or()
            .like("lastMessage.body", "*recharge*", Case.INSENSITIVE)
            .or()
            .like("lastMessage.body", "*cashback*", Case.INSENSITIVE)
            .or()
            .like("lastMessage.body", "*offer*", Case.INSENSITIVE)
            .endGroup()*/
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            )
            .between("lastMessage.date", cal.timeInMillis, cal1.timeInMillis)
//            .limit(limit)
            .findAllAsync()
    }

    override fun getOtpConversation(limit: Long, status: Int): RealmResults<Conversation> {
        return Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("archived", false)
            .equalTo("blocked", false)
            .equalTo("lastMessage.messageCatType", status)
            /*.beginGroup()
            .isNotEmpty("recipients")
            .isNotNull("lastMessage")
            .isNotEmpty("draft")
            .isNotEmpty("lastMessage.body")
            .endGroup()*/
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            )
//            .limit(limit)
            .findAllAsync()
    }

    override fun getOtpConversationFilter(
        limit: Long,
        startDate: Date,
        endDate: Date
    ): RealmResults<Conversation> {
        val cal = Calendar.getInstance()
        cal.time = startDate
        cal[Calendar.HOUR] = 0
        cal[Calendar.MINUTE] = 0
        cal[Calendar.SECOND] = 0
        cal[Calendar.MILLISECOND] = 0

        val cal1 = Calendar.getInstance()
        cal1.time = endDate
        cal1[Calendar.HOUR] = 24
        cal1[Calendar.MINUTE] = 0
        cal1[Calendar.SECOND] = 0
        cal1[Calendar.MILLISECOND] = 0

        return Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("archived", false)
            .equalTo("blocked", false)
            .equalTo("lastMessage.messageCatType", "2".toInt())
            /*.beginGroup()
            .isNotEmpty("recipients")
            .isNotNull("lastMessage")
            .isNotEmpty("draft")
            .isNotEmpty("lastMessage.body")
            .endGroup()*/
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            )
            .between("lastMessage.date", cal.timeInMillis, cal1.timeInMillis)
//            .limit(limit)
            .findAllAsync()
    }

    override fun getConversationsRange(
        fDate: Date,
        eDate: Date,
        limit: Long
    ): RealmResults<Conversation> {
        val cal = Calendar.getInstance()
        cal.time = fDate
        cal[Calendar.HOUR] = 0
        cal[Calendar.MINUTE] = 0
        cal[Calendar.SECOND] = 0
        cal[Calendar.MILLISECOND] = 0

        val cal1 = Calendar.getInstance()
        cal1.time = eDate
        cal1[Calendar.HOUR] = 24
        cal1[Calendar.MINUTE] = 0
        cal1[Calendar.SECOND] = 0
        cal1[Calendar.MILLISECOND] = 0

        return Realm.getDefaultInstance().where(Conversation::class.java)
            .isNotEmpty("recipients")
            .isNotNull("lastMessage").and()
            .between("lastMessage.date", cal.timeInMillis, cal1.timeInMillis)
            .findAll()
    }

    override fun getTopConversations(): List<Conversation> {
        return Realm.getDefaultInstance().use { realm ->
            realm.copyFromRealm(
                realm.where(Conversation::class.java)
                    .notEqualTo("id", 0L)
                    .isNotNull("lastMessage")
                    .beginGroup()
                    .equalTo("pinned", true)
                    .or()
                    .greaterThan(
                        "lastMessage.date",
                        System.currentTimeMillis() - TimeUnit.DAYS.toMillis(7)
                    )
                    .endGroup()
                    .equalTo("archived", false)
                    .equalTo("blocked", false)
                    .isNotEmpty("recipients")
                    .findAll()
            )
                .sortedWith(compareByDescending<Conversation> { conversation -> conversation.pinned }
                    .thenByDescending { conversation ->
                        realm.where(Message::class.java)
                            .equalTo("threadId", conversation.id)
                            .greaterThan(
                                "date",
                                System.currentTimeMillis() - TimeUnit.DAYS.toMillis(7)
                            )
                            .count()
                    })
        }
    }

    override fun setConversationName(id: Long, name: String) {
        Thread{
            try{
                Realm.getDefaultInstance().use { realm ->
                    realm.executeTransaction {
                        realm.where(Conversation::class.java)
                            .equalTo("id", id)
                            .findFirst()
                            ?.name = name
                    }
                }
            }catch (exp:Exception){
                LogD("Data","${exp.message}")
            }
        }.start()
    }

    override fun searchConversations(query: CharSequence): List<SearchResult> {
        val realm = Realm.getDefaultInstance()

        val normalizedQuery = query.removeAccents().trim()
        val conversations = realm.copyFromRealm(
            realm
                .where(Conversation::class.java)
                .notEqualTo("id", 0L)
                .isNotNull("lastMessage")
                .equalTo("blocked", false)
                .isNotEmpty("recipients")
                .sort("pinned", Sort.DESCENDING, "lastMessage.date", Sort.DESCENDING)
                .findAll()
        )

        val messagesByConversation = realm.copyFromRealm(
            realm
                .where(Message::class.java)
                .beginGroup()
                .contains("body", normalizedQuery.trim(), Case.INSENSITIVE)
                .or()
                .contains("parts.text", normalizedQuery.trim(), Case.INSENSITIVE)
                .endGroup()
                .findAll()
        )
            .asSequence()
            .groupBy { message -> message.threadId }
            .filter { (threadId, _) -> conversations.firstOrNull { it.id == threadId } != null }
            .map { (threadId, messages) ->
                Pair(
                    conversations.first { it.id == threadId },
                    messages.size
                )
            }
            .map { (conversation, messages) ->
                SearchResult(
                    normalizedQuery.trim(),
                    conversation,
                    messages
                )
            }
            .sortedByDescending { result -> result.messages }
            .toList()

        realm.close()

        return conversations
            .filter { conversation -> conversationFilter.filter(conversation, normalizedQuery.trim()) }
            .map { conversation ->
                SearchResult(
                    normalizedQuery.trim(),
                    conversation,
                    0
                )
            } + messagesByConversation
    }

    override fun getBlockedConversations(): RealmResults<Conversation> {
        return Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .equalTo("blocked", true)
            .findAll()
    }

    override fun getBlockedConversationsAsync(): RealmResults<Conversation> {
        return Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .equalTo("blocked", true)
            .findAll()
    }

    override fun getConversationAsync(threadId: Long): Conversation {
        return Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .equalTo("id", threadId)
            .findFirstAsync()
    }

    override fun getConversationAsync2(threadId: Long): MutableList<ConversationInfoItem> {
        val conversation = Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .equalTo("id", threadId)
            .findFirst()

        val data = mutableListOf<ConversationInfoItem>()

        if (conversation != null) {
            data += conversation.recipients.map(ConversationInfoItem::ConversationInfoRecipient)

            data += ConversationInfoItem.ConversationInfoSettings(
                name = conversation.name,
                recipients = conversation.recipients,
                archived = conversation.archived,
                blocked = conversation.blocked
            )
            val parts = Realm.getDefaultInstance()
                .where(MmsPart::class.java)
                .equalTo("messages.threadId", threadId)
                .beginGroup()
                .contains("type", "image/")
                .or()
                .contains("type", "video/")
                .endGroup()
                .sort("id", Sort.DESCENDING)
                .findAll()

            data += parts.map(::ConversationInfoMedia)
        }
        return data
    }

    override fun getConversation(threadId: Long): Conversation? {
        return Realm.getDefaultInstance()
            .apply {
                try {
                    refresh()
                } catch (e: Exception) {
                    com.textmessages.domain.extensions.LogE(
                        "getConversation: ",
                        e.message.toString()
                    )
                }
            }
            .where(Conversation::class.java)
            .equalTo("id", threadId)
            .findFirst()
    }

    override fun getMoreConversation(from: Long, to: Long): Conversation? {

        return Realm.getDefaultInstance()
            .apply {
                try {
                    refresh()
                } catch (e: Exception) {
                    com.textmessages.domain.extensions.LogE(
                        "getConversation: ",
                        e.message.toString()
                    )
                }
            }
            .where(Conversation::class.java)

            .findFirst()
    }

    override fun getConversations(vararg threadIds: Long): Pair<RealmResults<Conversation>, Boolean> {
        val data = Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .anyOf("id", threadIds)
            .findAllAsync()
        return Pair(data, true)
    }

    override fun getUnmanagedConversations(limit: Long): Observable<List<Conversation>> {
        val realm = Realm.getDefaultInstance()
        return realm.where(Conversation::class.java)
            .sort("lastMessage.date", Sort.DESCENDING)
            .notEqualTo("id", 0L)
            .isNotNull("lastMessage")
            .equalTo("archived", false)
            .equalTo("blocked", false)
            .isNotEmpty("recipients")
//            .limit(limit)
            .findAll()
            .asObservable()
            .filter { it.isLoaded }
            .filter { it.isValid }
            .map { realm.copyFromRealm(it) }
            .subscribeOn(AndroidSchedulers.mainThread())
            .observeOn(Schedulers.io())
    }

    override fun getRecipients(): RealmResults<Recipient> {
        val realm = Realm.getDefaultInstance()
        return realm.where(Recipient::class.java)
            .findAll()
    }

    override fun getUnmanagedRecipients(): Observable<List<Recipient>> {
        val realm = Realm.getDefaultInstance()
        return realm.where(Recipient::class.java)
            .isNotNull("contact")
            .findAll()
            .asObservable()
            .filter { it.isLoaded && it.isValid }
            .map { realm.copyFromRealm(it) }
            .subscribeOn(AndroidSchedulers.mainThread())
    }

    override fun getRecipient(recipientId: Long): Recipient? {
        return Realm.getDefaultInstance()
            .where(Recipient::class.java)
            .equalTo("id", recipientId)
            .findFirst()
    }

    override fun getThreadId(recipient: String): Long? {
        return getThreadId(listOf(recipient))
    }

    override fun getThreadId(recipients: Collection<String>): Long? {
        return Realm.getDefaultInstance().use { realm ->
            if (!realm.isInTransaction) {
                realm.refresh()
            }
            realm.where(Conversation::class.java)
                .findAll()
                .asSequence()
                .filter { conversation -> conversation.recipients.size == recipients.size }
                .find { conversation ->
                    conversation.recipients.map { it.address }.all { address ->
                        recipients.any { recipient -> phoneNumberUtils.compare(recipient, address) }
                    }
                }?.id
        }
    }

    override fun getOrCreateConversation(threadId: Long): Conversation? {
        return getConversation(threadId) ?: getConversationFromCp(threadId)
    }

    override fun getOrCreateConversation(address: String): Conversation? {
        LogW("messageApp : ", "Message onHandleIntent getOrCreateConversation-  " + address)

        return getOrCreateConversation(listOf(address))
    }

    override fun getOrCreateConversation(addresses: List<String>): Conversation? {
        if (addresses.isEmpty()) {
            return null
        }
        LogW("messageApp : ", "Message getOrCreateConversation  isnidede-  $addresses")

        return (getThreadId(addresses)
            ?: tryOrNull { TelephonyCompat.getOrCreateThreadId(context, addresses.toSet()) })
            ?.takeIf { threadId -> threadId != 0L }
            ?.let { threadId ->
                getConversation(threadId)
                    ?.let(Realm.getDefaultInstance()::copyFromRealm)
                    ?: getConversationFromCp(threadId)
            }
    }

    override fun saveDraft(threadId: Long, draft: String) {
        Realm.getDefaultInstance().use { realm ->
            realm.refresh()

            val conversation = realm.where(Conversation::class.java)
                .equalTo("id", threadId)
                .findFirst()

            realm.executeTransaction {
                conversation?.takeIf { it.isValid }?.draft = draft
            }
        }
    }

    override fun updateConversations(vararg threadIds: Long) {
        Realm.getDefaultInstance().use { realm ->
            realm.refresh()
            threadIds.forEach { threadId ->
                val conversation = realm
                    .where(Conversation::class.java)
                    .equalTo("id", threadId)
                    .findFirst() ?: return

                val message = realm
                    .where(Message::class.java)
                    .equalTo("threadId", threadId)
                    .sort("date", Sort.DESCENDING)
                    .findFirst()

                realm.executeTransaction {
                    conversation.lastMessage = message
                }
            }
        }
    }

    override fun markAllAsRead(vararg threadIds: Long) {
        val values = ContentValues()
        values.put(Telephony.Sms.SEEN, true)
        values.put(Telephony.Sms.READ, true)
        Realm.getDefaultInstance().use { realm ->
            val messages = realm.where(Message::class.java)
                .equalTo("read",false)
                .findAll()

            realm.executeTransaction {
                messages.forEach { conversation ->
                    try {
                        conversation.read = true
                        val uri = ContentUris.withAppendedId(
                            Telephony.MmsSms.CONTENT_CONVERSATIONS_URI,
                            conversation.threadId
                        )
                        context.contentResolver.update(uri, values, null, null)
                    } catch (exception: Exception) {
                        Timber.w(exception)
                    }
                }
            }
        }
    }

    override fun markArchived(vararg threadIds: Long) {
        Realm.getDefaultInstance().use { realm ->
            val conversations = realm.where(Conversation::class.java)
                .anyOf("id", threadIds)
                .findAll()

            realm.executeTransaction {
                conversations.forEach { it.archived = true }
            }
        }
    }

    override fun markUnarchived(vararg threadIds: Long) {
        Realm.getDefaultInstance().use { realm ->
            val conversations = realm.where(Conversation::class.java)
                .anyOf("id", threadIds)
                .findAll()

            realm.executeTransaction {
                conversations.forEach { it.archived = false }
            }
        }
    }

    override fun markPinned(vararg threadIds: Long) {
        Realm.getDefaultInstance().use { realm ->
            val conversations = realm.where(Conversation::class.java)
                .anyOf("id", threadIds)
                .findAll()

            realm.executeTransaction {
                conversations.forEach { it.pinned = true }
            }
        }
    }

    override fun markUnpinned(vararg threadIds: Long) {
        Realm.getDefaultInstance().use { realm ->
            val conversations = realm.where(Conversation::class.java)
                .anyOf("id", threadIds)
                .findAll()

            realm.executeTransaction {
                conversations.forEach { it.pinned = false }
            }
        }
    }

    override fun markBlocked(threadIds: List<Long>, blockReason: String?) {
        LogW("messageApp : ", "message markBlocked ")
        Realm.getDefaultInstance().use { realm ->
            val conversations = realm.where(Conversation::class.java)
                .anyOf("id", threadIds.toLongArray())
//                .equalTo("blocked", false)
                .findAll()

            realm.executeTransaction {
                conversations.forEach { conversation ->
                    conversation.blocked = true
//                    conversation.blockingClient = blockingClient
                    conversation.blockReason = blockReason
                }
            }
        }
    }

    override fun markUnblocked(vararg threadIds: Long) {
        Realm.getDefaultInstance().use { realm ->
            val conversations = realm.where(Conversation::class.java)
                .anyOf("id", threadIds)
                .findAll()

            realm.executeTransaction {
                conversations.forEach { conversation ->
                    conversation.blocked = false
//                    conversation.blockingClient = null
                    conversation.blockReason = null
                }
            }
        }
    }

    override fun block(addresses: List<String>): Completable = Completable.fromCallable {
        Realm.getDefaultInstance().use { realm ->
            realm.refresh()

            val blockedNumbers = realm.where(BlockedNumber::class.java).findAll()
            val newAddresses = addresses.filter { address ->
                blockedNumbers.none { number -> phoneNumberUtils.compare(number.address, address) }
            }

            val maxId = realm.where(BlockedNumber::class.java)
                .max("id")?.toLong() ?: -1

            realm.executeTransaction {
                realm.insert(newAddresses.mapIndexed { index, address ->
                    BlockedNumber(maxId + 1 + index, address)
                })
            }
        }
    }

    override fun unblock(addresses: List<String>): Completable = Completable.fromCallable {
        Realm.getDefaultInstance().use { realm ->
            val ids = realm.where(BlockedNumber::class.java)
                .findAll()
                .filter { number ->
                    addresses.any { address -> phoneNumberUtils.compare(number.address, address) }
                }
                .map { number -> number.id }
                .toLongArray()

            realm.executeTransaction {
                realm.where(BlockedNumber::class.java)
                    .anyOf("id", ids)
                    .findAll()
                    .deleteAllFromRealm()
            }
        }
    }

    override fun deleteConversations(vararg threadIds: Long) {
        Realm.getDefaultInstance().use { realm ->
            val conversation =
                realm.where(Conversation::class.java).anyOf("id", threadIds).findAll()
            val messages = realm.where(Message::class.java).anyOf("threadId", threadIds).findAll()

            realm.executeTransaction {
                conversation.deleteAllFromRealm()
                messages.deleteAllFromRealm()
            }
        }

        threadIds.forEach { threadId ->
            val uri = ContentUris.withAppendedId(Telephony.Threads.CONTENT_URI, threadId)
            context.contentResolver.delete(uri, null, null)
        }
    }

    /**
     * Returns a [Conversation] from the system SMS ContentProvider, based on the [threadId]
     *
     * It should be noted that even if we have a valid [threadId], that does not guarantee that
     * we can return a [Conversation]. On some devices, the ContentProvider won't return the
     * conversation unless it contains at least 1 message
     */
    private fun getConversationFromCp(threadId: Long): Conversation? {
        return cursorToConversation.getConversationsCursor()
            ?.map(cursorToConversation::map)
            ?.firstOrNull { it.id == threadId }
            ?.let { conversation ->
                val realm = Realm.getDefaultInstance()
                val contacts = realm.copyFromRealm(realm.where(Contact::class.java).findAll())
                val lastMessage = realm.where(Message::class.java).equalTo("threadId", threadId)
                    .sort("date", Sort.DESCENDING).findFirst()?.let(realm::copyFromRealm)

                val recipients = conversation.recipients
                    .map { recipient -> recipient.id }
                    .map { id -> cursorToRecipient.getRecipientCursor(id) }
                    .mapNotNull { recipientCursor ->
                        // Map the recipient cursor to a list of recipients
                        recipientCursor?.use {
                            recipientCursor.map {
                                cursorToRecipient.map(
                                    recipientCursor
                                )
                            }
                        }
                    }
                    .flatten()
                    .map { recipient ->
                        recipient.apply {
                            contact = contacts.firstOrNull {
                                it.numbers.any {
                                    phoneNumberUtils.compare(
                                        recipient.address,
                                        it.address
                                    )
                                }
                            }
                        }
                    }

                conversation.recipients.clear()
                conversation.recipients.addAll(recipients)
                conversation.lastMessage = lastMessage
                realm.executeTransaction { it.insertOrUpdate(conversation) }
                realm.close()

                conversation
            }
    }

    override fun getArchiveConversationsSize(): Int {
        return Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("archived", true)
            .equalTo("blocked", false)
            .isNotEmpty("recipients")
            .beginGroup()
            .isNotNull("lastMessage")
            .or()
            .isNotEmpty("draft")
            .endGroup()
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            ).count().toInt()
    }

    override fun getUnreadConversationsSize(): Int {
        return Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("archived", false)
            .equalTo("blocked", false)
            .equalTo("lastMessage.read", false)
            .isNotEmpty("recipients")
            .beginGroup()
            .isNotNull("lastMessage")
            .or()
            .isNotEmpty("draft")
            .endGroup()
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            ).count().toInt()
    }

    override fun getAllConversationsSize(): Int {
        return try {
            Realm.getDefaultInstance()
                .where(Conversation::class.java)
                .notEqualTo("id", 0L)
                .equalTo("blocked", false)
                .isNotEmpty("recipients")
                .beginGroup()
                .isNotNull("lastMessage")
                .or()
                .isNotEmpty("draft")
                .endGroup()
                .sort(
                    arrayOf("pinned", "draft", "lastMessage.date"),
                    arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
                ).count().toInt()
        } catch (exp : Exception){
            0
        }
    }

    override fun getArchivedConversationsSize(): Int {
        return Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .notEqualTo("id", 0L)
            .equalTo("archived", true)
            .equalTo("blocked", false)
            .isNotEmpty("recipients")
            .beginGroup()
            .isNotNull("lastMessage")
            .or()
            .isNotEmpty("draft")
            .endGroup()
//            .limit(limit)
            .sort(
                arrayOf("pinned", "draft", "lastMessage.date"),
                arrayOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)
            ).count().toInt()
    }

    override fun isConversationAvailable(threadId:Long): Boolean {
        val conversation =  Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .equalTo("id", threadId).findFirst()
        return conversation != null
    }
}