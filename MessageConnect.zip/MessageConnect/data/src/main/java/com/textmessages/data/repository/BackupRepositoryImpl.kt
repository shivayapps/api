package com.textmessages.data.repository

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.provider.Telephony
import androidx.core.content.contentValuesOf
import androidx.core.net.toUri
import androidx.documentfile.provider.DocumentFile
import com.squareup.moshi.Moshi
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import io.realm.Realm
import okio.buffer
import okio.source
import com.textmessages.domain.interactor.model.BackupFile
import com.textmessages.domain.interactor.model.Message
import com.textmessages.data.util.MessagesFileObserver
import com.textmessages.domain.util.Preferences
import sms.messages.app.message.box.message.me.util.tryOrNull
import com.textmessages.data.util.queryCursor
import com.textmessages.domain.repository.BackupRepository
import com.textmessages.domain.repository.SyncRepository
import sms.messages.app.message.box.message.me.compat.TelephonyCompat
import timber.log.Timber
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.concurrent.schedule


@Singleton
class BackupRepositoryImpl @Inject constructor(
    private val context: Context,
    private val moshi: Moshi,
    private val prefs: Preferences,
    private val syncRepo: SyncRepository
) : BackupRepository {

    companion object {

        val BACKUP_DIRECTORY =
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).path
                .toString() + "/messages/Backups"

    }

    data class Backup(
        val messageCount: Int = 0,
        val uniqDeviceId: String = "",
        val messages: List<BackupMessage> = listOf()
    )

    /**
     * Simpler version of [Backup] which allows us to read certain fields from the backup without
     * needing to parse the entire file
     */
    data class BackupMetadata(
        val messageCount: Int = 0
    )

    data class BackupMessage(
        val type: Int,
        val address: String,
        val date: Long,
        val dateSent: Long,
        val read: Boolean,
        val status: Int,
        val body: String,
        val protocol: Int,
        val serviceCenter: String?,
        val locked: Boolean,
        val subId: Int,
        val contentId: Long
    )

    // Subjects to emit our progress events to
    private val backupProgress: Subject<BackupRepository.Progress> =
        BehaviorSubject.createDefault(BackupRepository.Progress.Idle())
    private val restoreProgress: Subject<BackupRepository.Progress> =
        BehaviorSubject.createDefault(BackupRepository.Progress.Idle())
    private val TAG = "BackupRepoImpl+++"

    @Volatile
    private var stopFlag: Boolean = false

    @Volatile
    private var stopBackupFlag: Boolean = false

    override fun performBackup() {
        // If a backup or restore is already running, don't do anything
        if (isBackupOrRestoreRunning()) return

        var messageCount = 0

        // Map all the messages into our object we'll use for the Json mapping
        val backupMessages = Realm.getDefaultInstance().use { realm ->
            // Get the messages from realm
            val messages = realm.where(Message::class.java).sort("date").findAll().createSnapshot()
            messageCount = messages.size

            // Map the messages to the new format
            messages.mapIndexed { index, message ->
                // Update the progress
                backupProgress.onNext(BackupRepository.Progress.Running(messageCount, index))
                messageToBackupMessage(message)
            }
        }
        if (stopBackupFlag) {
            stopBackupFlag = false
            backupProgress.onNext(BackupRepository.Progress.Idle())
            return
        } else {
            // Update the status, and set the progress to be indeterminate since we can no longer calculate progress
            backupProgress.onNext(BackupRepository.Progress.Saving())

            // Convert the data to json
            val adapter = moshi.adapter(Backup::class.java).indent("\t")
            val androidId = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ANDROID_ID
            )
            val json =
                adapter.toJson(Backup(messageCount, androidId ?: "", backupMessages)).toByteArray()

            try {
                // Create the directory and file
                val dir = File(BACKUP_DIRECTORY).apply { mkdirs() }
                val timestamp = SimpleDateFormat(
                    "yyyyMMddHHmmss",
                    Locale.getDefault()
                ).format(System.currentTimeMillis())
                val file = File(dir, "backup-$timestamp.json")
                // Write the log to the file
                FileOutputStream(
                    file,
                    true
                ).use { fileOutputStream -> fileOutputStream.write(json) }
            } catch (e: Exception) {
                Timber.w(e)
            }
            // Mark the task finished, and set it as Idle (a second later if not cancelled)
            backupProgress.onNext(BackupRepository.Progress.Finished())
            Timer().schedule(1000) { backupProgress.onNext(BackupRepository.Progress.Idle()) }
        }
    }

    private fun messageToBackupMessage(message: Message): BackupRepositoryImpl.BackupMessage =
        BackupMessage(
            type = message.boxId,
            address = message.address,
            date = message.date,
            dateSent = message.dateSent,
            read = message.read,
            status = message.deliveryStatus,
            body = message.body,
            protocol = 0,
            serviceCenter = null,
            locked = message.locked,
            subId = message.subId,
            contentId = message.contentId,
        )

    override fun getBackupProgress(): Observable<BackupRepository.Progress> = backupProgress

    override fun getBackups(): Observable<List<BackupFile>> =
        MessagesFileObserver(BACKUP_DIRECTORY).observable
            .map { File(BACKUP_DIRECTORY).listFiles() ?: arrayOf() }
            .subscribeOn(Schedulers.io())
            .observeOn(Schedulers.computation())
            .map { files ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !prefs.downloadUri.get()
                        .isNullOrEmpty()
                ) {
                    val dfile: DocumentFile? =
                        DocumentFile.fromTreeUri(context, prefs.downloadUri.get().toUri())
                    dfile?.listFiles()?.mapNotNull { uri ->
                        val file = File("$BACKUP_DIRECTORY/${uri.name}")
                        val adapter = moshi.adapter(BackupMetadata::class.java)
                        val jsonSelectedFile = context.contentResolver.openInputStream(uri.uri)
                        val inputAsString =
                            jsonSelectedFile?.bufferedReader().use { it?.readText() }
                        val backup = adapter.fromJson(inputAsString)
                        val path = uri.uri.toString()
                        val date = file.lastModified()
                        val messages = backup?.messageCount ?: 0
                        val size = file.length()
                        BackupFile(path, date, messages, size)
                    }
                } else {
                    files.mapNotNull { file ->
                        val adapter = moshi.adapter(BackupMetadata::class.java)
                        val backup = tryOrNull(false) {
                            file.source().buffer().use(adapter::fromJson)
                        } ?: return@mapNotNull null

                        val path = file.path
                        val date = file.lastModified()
                        val messages = backup.messageCount
                        val size = file.length()
                        BackupFile(path, date, messages, size)
                    }
                }
            }
            .map { files -> files.sortedByDescending { file -> file.date } }

    override fun performRestore(filePath: String) {
        // If a backupFile or restore is already running, don't do anything
        if (isBackupOrRestoreRunning()) return

        restoreProgress.onNext(BackupRepository.Progress.Parsing())

        val backup = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !prefs.downloadUri.get()
                .isNullOrEmpty()
        ) {
            val jsonSelectedFile = context.contentResolver.openInputStream(filePath.toUri())
            val inputAsString = jsonSelectedFile?.bufferedReader().use { it?.readText() }
            moshi.adapter(Backup::class.java).fromJson(inputAsString)

        } else {
            val file = File(filePath)
            file.source().buffer().use { source ->
                moshi.adapter(Backup::class.java).fromJson(source)
            }
        }

        val messageCount = backup?.messages?.size ?: 0
        var errorCount = 0
        val resAndroidId = backup?.uniqDeviceId ?: ""
        val androidId = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ANDROID_ID
        ) ?: ""


        backup?.messages?.forEachIndexed { index, message ->
            if (stopFlag) {
                stopFlag = false
                restoreProgress.onNext(BackupRepository.Progress.Idle())
                return
            }

            // Update the progress
            restoreProgress.onNext(BackupRepository.Progress.Running(messageCount, index))

            if (!smsExist(message)) {
                try {
                    val thread = TelephonyCompat.getOrCreateThreadId(context, message.address)
                    val values = contentValuesOf(
                        Telephony.Sms.THREAD_ID to thread,
//                    Telephony.Sms._ID to message.contentId,
                        Telephony.Sms.TYPE to message.type,
                        Telephony.Sms.ADDRESS to message.address,
                        Telephony.Sms.DATE to message.date,
                        Telephony.Sms.DATE_SENT to message.dateSent,
                        Telephony.Sms.READ to message.read,
                        Telephony.Sms.SEEN to 1,
                        Telephony.Sms.STATUS to message.status,
                        Telephony.Sms.BODY to message.body,
                        Telephony.Sms.PROTOCOL to message.protocol,
                        Telephony.Sms.SERVICE_CENTER to message.serviceCenter,
                        Telephony.Sms.LOCKED to message.locked
                    )

                    if (prefs.canUseSubId.get() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                        values.put(Telephony.Sms.SUBSCRIPTION_ID, message.subId)
                    }
                    try {
                        val uri = context.contentResolver.insert(Telephony.Sms.CONTENT_URI, values)
                        if (uri == null) {
                            val uri = context.contentResolver.update(
                                ContentUris.withAppendedId(
                                    Telephony.Sms.CONTENT_URI,
                                    message.contentId
                                ), values, null, null
                            )
                        }
                    } catch (exp: Exception) {
                        if (resAndroidId == androidId) {
                            val uri = context.contentResolver.update(
                                ContentUris.withAppendedId(
                                    Telephony.Sms.CONTENT_URI,
                                    message.contentId
                                ), values, null, null
                            )
                        } else {
                            values.remove(Telephony.Sms._ID)
                            val uri =
                                context.contentResolver.insert(Telephony.Sms.CONTENT_URI, values)
                        }
                    }
                } catch (e: Exception) {
                    Timber.w(e)
                    errorCount++
                }
            }


        }

        if (errorCount > 0) {
            Timber.w(Exception("Failed to backup $errorCount/$messageCount messages"))
        }

        // Sync the messages
        syncRepo.syncProgress
            .sample(16, TimeUnit.MILLISECONDS)
            .distinctUntilChanged()
            .subscribe { syncing ->
                when (syncing) {
                    is SyncRepository.SyncProgress.Idle -> {
                        restoreProgress.onNext(BackupRepository.Progress.Finished())
                        Timer().schedule(1000) { restoreProgress.onNext(BackupRepository.Progress.Idle()) }
                    }
                    is SyncRepository.SyncProgress.Running -> {
                        restoreProgress.onNext(BackupRepository.Progress.Syncing())
                    }
                    else -> {
                        restoreProgress.onNext(BackupRepository.Progress.Finished())
                        Timer().schedule(1000) { restoreProgress.onNext(BackupRepository.Progress.Idle()) }
                    }
                }
            }
        syncRepo.syncMessages()
    }

    private fun smsExist(smsBackup: BackupMessage): Boolean {
        val uri = Telephony.Sms.CONTENT_URI
        val projection = arrayOf(Telephony.Sms._ID)
        val selection =
            "${Telephony.Sms.DATE} = ? AND ${Telephony.Sms.ADDRESS} = ? AND ${Telephony.Sms.TYPE} = ?"
        val selectionArgs =
            arrayOf(smsBackup.date.toString(), smsBackup.address, smsBackup.type.toString())
        var exists = false
        context.queryCursor(uri, projection, selection, selectionArgs) {
            exists = it.count > 0
        }
        return exists
    }

    override fun deleteBackup(filePath: String) {
        // If a backupFile or restore is already running, don't do anything
        if (isBackupOrRestoreRunning()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && prefs.downloadUri.get()
                    .isNotEmpty()
            ) {
                val docFile = DocumentFile.fromSingleUri(context, filePath.toUri())
                docFile?.delete()
            } else {
                val file = File(filePath)
                file.delete()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun stopRestore() {
        stopFlag = true
    }

    override fun stopBackup() {
        stopBackupFlag = true
    }

    override fun getRestoreProgress(): Observable<BackupRepository.Progress> = restoreProgress

    private fun isBackupOrRestoreRunning(): Boolean {
        return backupProgress.blockingFirst().running || restoreProgress.blockingFirst().running
    }

}