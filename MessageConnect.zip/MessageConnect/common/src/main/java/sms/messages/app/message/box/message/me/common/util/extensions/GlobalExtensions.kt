package sms.messages.app.message.box.message.me.common.util.extensions

fun now(): Long {
    return System.currentTimeMillis()
}
