package com.backup.restore.device.image.recovery.ads.inapp

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.SkuDetails
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.mainapps.activity.ThankYouActivity
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.getPrivacyPolicyUrl
import com.backup.restore.device.image.recovery.utilities.getTermConditionUrl
import kotlinx.android.synthetic.main.activity_in_app.*
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.jetbrains.anko.textColor
import java.util.*


class InAppActivity : MyCommonBaseActivity(), InAppPurchaseHelper.OnPurchased {

    var isYearly=true
    var skuYearly : SkuDetails?=null
    var skuMonthly : SkuDetails?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_in_app)
        addEvent(InAppActivity::class.simpleName!!)

        changePakage(isYearly)
    }

    override fun getContext(): AppCompatActivity {
        return this@InAppActivity
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
    }


    override fun initData() {

        InAppPurchaseHelper.instance!!.initBillingClient(mContext, this)

        tv_monthly.text= InAppPurchaseHelper.instance!!.getProductPrice(SUB_MONTHLY)
        tv_yearly.text= InAppPurchaseHelper.instance!!.getProductPrice(SUB_YEARLY)

        skuMonthly=InAppPurchaseHelper.instance!!.getSkuDetails(SUB_MONTHLY)
        skuYearly=InAppPurchaseHelper.instance!!.getSkuDetails(SUB_YEARLY)

        var priceMicro1=0
        var priceMicro2=0
        if(skuMonthly!=null) {
            val priceMicroMonthly=skuMonthly?.priceAmountMicros!!
            if(priceMicroMonthly!=null) {
                priceMicro1=(priceMicroMonthly/1000000).toInt()/1
                tv_inr_per_month.text="${skuMonthly?.priceCurrencyCode} ${priceMicro1} ${getString(R.string.per_month)}"
            }
        }


        if(skuMonthly!=null) {
            val priceMicroYearly=skuYearly?.priceAmountMicros!!
            if(priceMicroYearly!=null) {

                priceMicro2=((priceMicroYearly/1000000).toInt())/12

                var pricePer=0
                if(priceMicro1!=null && priceMicro2!=null) {
                    pricePer=(100-(((priceMicro2)*100)/(priceMicro1)))
                }

                Log.e("initData", "initData: priceMicro1: $priceMicro1" )

                if(pricePer<=0) tv_inr_per_year.text="${skuYearly?.priceCurrencyCode} ${priceMicro2} ${getString(R.string.per_month)}\n"
                else tv_inr_per_year.text="${skuYearly?.priceCurrencyCode} ${priceMicro2} ${getString(R.string.per_month)}\n(${pricePer} % ${getString(R.string.save)})"
            }
        }


    }

    override fun initActions() {

        iv_close.setOnClickListener(this)

//        tv_duration_1.setOnClickListener(this)
//        tv_inr_per_month.setOnClickListener(this)
//        tv_monthly.setOnClickListener(this)
//        rel_package_monthly.setOnClickListener(this)
        rel_monthly_click.setOnClickListener {
            changePakage(false)
        }

//        tv_duration_2.setOnClickListener(this)
//        tv_inr_per_year.setOnClickListener(this)
//        tv_yearly.setOnClickListener(this)
//        rel_package_yearly.setOnClickListener(this)
        rel_yearly_click.setOnClickListener {
            changePakage(true)
        }

        buttonPurchase.setOnClickListener(this)
        tv_tandc.setOnClickListener(this)
        tv_privacy.setOnClickListener(this)
    }

    var mLastClickTime: Long = 0
    var mMinDuration = 1000
    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()

        when (view.id) {
            R.id.iv_close -> onBackPressed()
            R.id.tv_privacy -> {

                val marketUri = Uri.parse(mContext.getPrivacyPolicyUrl())
//                val marketIntent = Intent(Intent.ACTION_VIEW, marketUri)
//                startActivity(marketIntent)
                val customIntent: CustomTabsIntent.Builder = CustomTabsIntent.Builder()
                customIntent.setToolbarColor(ContextCompat.getColor(this@InAppActivity, R.color.colorPrimary))
                openCustomTab(this@InAppActivity, customIntent.build(), marketUri)
            }
            R.id.tv_tandc -> {
                val marketUri = Uri.parse(mContext.getTermConditionUrl())
//                val marketIntent = Intent(Intent.ACTION_VIEW, marketUri)
//                startActivity(marketIntent)

                val customIntent: CustomTabsIntent.Builder = CustomTabsIntent.Builder()
                customIntent.setToolbarColor(ContextCompat.getColor(this@InAppActivity, R.color.colorPrimary))
                openCustomTab(this@InAppActivity, customIntent.build(), marketUri)

            }
//            R.id.tv_duration_1, R.id.tv_inr_per_month, R.id.tv_monthly, R.id.rel_package_monthly -> {
//                changePakage(false)
//            }
//            R.id.tv_duration_2, R.id.tv_inr_per_year, R.id.tv_yearly, R.id.rel_package_yearly -> {
//                changePakage(true)
//            }
            R.id.buttonPurchase -> {
                GlobalScope.launch {
                    if(isYearly) InAppPurchaseHelper.instance?.subscribeProduct(SUB_YEARLY,false)
                    else InAppPurchaseHelper.instance?.subscribeProduct(SUB_MONTHLY,false)
                }
            }
        }
    }

    private fun openCustomTab(activity: Activity, customTabsIntent: CustomTabsIntent, uri: Uri) {
        // package name is the default package
        // for our custom chrome tab
        try {
            customTabsIntent.intent.setPackage("com.android.chrome")
            customTabsIntent.launchUrl(activity, uri)
        } catch (e:Exception) {
            activity.startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    private fun changePakage(yearly:Boolean) {
        if(yearly){
            isYearly = yearly
            iv_acive_monthly.visibility=View.INVISIBLE
            tv_basic.visibility=View.INVISIBLE
            iv_acive_yearly.visibility=View.VISIBLE
            tv_popular.visibility=View.VISIBLE

            rel_package_monthly.background=resources.getDrawable(R.drawable.rounded_border)
            rel_package_yearly.background=resources.getDrawable(R.drawable.rounded_border_active)

            tv_monthly.background=resources.getDrawable(R.drawable.ic_button_disable)
            tv_monthly.textColor=resources.getColor(R.color.primary_text)

            tv_yearly.background=resources.getDrawable(R.drawable.ic_dialog_button)
            tv_yearly.textColor=resources.getColor(R.color.white)

        } else {
            isYearly = yearly
            iv_acive_monthly.visibility=View.VISIBLE
            tv_basic.visibility=View.VISIBLE
            iv_acive_yearly.visibility=View.INVISIBLE
            tv_popular.visibility=View.INVISIBLE

            rel_package_monthly.background=resources.getDrawable(R.drawable.rounded_border_active)
            rel_package_yearly.background=resources.getDrawable(R.drawable.rounded_border)

            tv_monthly.background=resources.getDrawable(R.drawable.ic_dialog_button)
            tv_monthly.textColor=resources.getColor(R.color.white)

            tv_yearly.background=resources.getDrawable(R.drawable.ic_button_disable)
            tv_yearly.textColor=resources.getColor(R.color.primary_text)
        }
    }


    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onPurchasedSuccess(purchase: Purchase) {
        Log.e("IN_APP_BILLING","onPurchasedSuccess:InAppActivity:"+purchase.skus)
//        setResult(RESULT_OK)
        startActivityForResult(Intent(mContext,ThankYouActivity::class.java),111)
//        finish()
    }

    override fun onProductAlreadyOwn() {
        Log.e("IN_APP_BILLING","onProductAlreadyOwn:InAppActivity")
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        Log.e("IN_APP_BILLING","onBillingSetupFinished:InAppActivity:"+billingResult.responseCode)
        Log.e("IN_APP_BILLING","onBillingSetupFinished:InAppActivity:"+billingResult.debugMessage)
    }

    override fun onBillingUnavailable() {
        Log.e("IN_APP_BILLING","onBillingUnavailable:InAppActivity")
    }

    override fun onBillingKeyNotFound(productId: String) {
        Log.e("IN_APP_BILLING","onBillingUnavailable:InAppActivity:$productId")
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 111) {
            setResult(RESULT_OK)
            finish()
        }
    }
}