package com.backup.restore.device.image.recovery.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class ShortcutReceiver extends BroadcastReceiver {
  public static final String kInstalledAction = "general.intent.action.SHORTCUT_ADDED";

  @Override
  public void onReceive(Context context, Intent intent) {

    Log.e("TAG", "onReceive:123 " );
    if (kInstalledAction.equals(intent.getAction())) {
      Log.e("TAG", "onReceive:123 " );
    }

  }

}