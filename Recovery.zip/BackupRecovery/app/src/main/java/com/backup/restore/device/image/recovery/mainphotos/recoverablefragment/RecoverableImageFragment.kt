package com.backup.restore.device.image.recovery.mainphotos.recoverablefragment

import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.mainphotos.activity.RecoverableImageActivity
import com.backup.restore.device.image.recovery.mainphotos.activity.ViewRecoverableImageListActivity
import com.backup.restore.device.image.recovery.mainphotos.callbacks.ItemClickListener
import com.backup.restore.device.image.recovery.mainphotos.model.RecoverableFolderModel
import com.backup.restore.device.image.recovery.mainphotos.recoverableadapter.RecoverableFolderAdapter
import com.backup.restore.device.image.recovery.utilities.SPAN_COUNT_THREE
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.getExtension
import com.backup.restore.device.image.recovery.utilities.getGridCount
import kotlinx.android.synthetic.main.activity_recover_image_new.*
import kotlinx.android.synthetic.main.fragment_recoverable_image_video.*
import java.io.File
import java.util.*
import kotlin.collections.ArrayList


class RecoverableImageFragment : Fragment(), View.OnClickListener {

    val mTAG: String = javaClass.simpleName
    lateinit var mView: View

    //    var selectedList = ArrayList<TrashModel>()
    var isVisibleHint: Boolean = false
    var isAsyncRunning: Boolean = false
    var isForSort = "date_asc"

    var mGetRecoverableAlbum: AsyncTask<*, *, *>? = null
    var mHiddenPictureFolderAdapter: RecoverableFolderAdapter? = null
    var mRecoverableFolderList = ArrayList<RecoverableFolderModel>()
    var mFolderList = ArrayList<RecoverableFolderModel>()

    companion object {
        fun newInstance(): RecoverableImageFragment {
            return RecoverableImageFragment()
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        context!!.registerReceiver(
//            refreshMediaBroadcast,
//            IntentFilter("com.progress.image.Refresh")
//        )
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
//        Log.e(mTAG, "setUserVisibleHint: isVisibleToUser: $isVisibleToUser")
//        Log.e(mTAG, "setUserVisibleHint: isAdded: $isAdded")
        if (isAdded) {
            isVisibleHint = isVisibleToUser
//            Log.e(mTAG, "setUserVisibleHint: same $isVisibleToUser")

            object : AsyncTask<Void, Long, Void>() {
                override fun doInBackground(vararg voids: Void): Void? {
//                Log.e(mTAG, "doInBackground: stopLoading")
                    if (!isAsyncRunning) stopLoading()
                    return null
                }

                override fun onPostExecute(result: Void?) {
                    super.onPostExecute(result)
                }
            }.execute()

            if (isVisibleHint) {

                if (mFolderList != null && mFolderList.size != 0) {
                    if (RecoverableImageActivity.lastSelection == 1 && RecoverableImageActivity.prevPosRecoverable == 0) {
                        if (requireActivity() is RecoverableImageActivity) {
                            (requireActivity() as RecoverableImageActivity).toggleRecoverButtonVisibility(
                                true
                            )
                            requireActivity().iv_span.alpha = 1.0F
                            requireActivity().iv_span.isEnabled = true
                            when (isForSort) {
                                "size_asc" -> {
                                    (requireActivity() as RecoverableImageActivity).selectSizeAsc()
                                    (requireActivity() as RecoverableImageActivity).isDateClick =
                                        true
                                    (requireActivity() as RecoverableImageActivity).isSizeClick =
                                        false
                                }
                                "size_desc" -> {
                                    (requireActivity() as RecoverableImageActivity).selectSizeDesc()
                                    (requireActivity() as RecoverableImageActivity).isDateClick =
                                        true
                                    (requireActivity() as RecoverableImageActivity).isSizeClick =
                                        false
                                }
                                "date_desc" -> {
                                    (requireActivity() as RecoverableImageActivity).selectDateDesc()
                                    (requireActivity() as RecoverableImageActivity).isDateClick =
                                        false
                                    (requireActivity() as RecoverableImageActivity).isSizeClick =
                                        true
                                }
                                "date_asc" -> {
                                    (requireActivity() as RecoverableImageActivity).selectTop(1)
//                                (requireActivity() as RecoverableImageActivity).selectDateAsc()
                                    (requireActivity() as RecoverableImageActivity).isDateClick =
                                        false
                                    (requireActivity() as RecoverableImageActivity).isSizeClick =
                                        true
                                }
                            }
                        }
                    }
                } else {
                    if (RecoverableImageActivity.lastSelection == 1 && RecoverableImageActivity.prevPosRecoverable == 0) {
                        if (requireActivity() is RecoverableImageActivity) {
                            (requireActivity() as RecoverableImageActivity).toggleRecoverButtonVisibility(
                                false
                            )
                            (requireActivity() as RecoverableImageActivity).unSelectAll()
                            requireActivity().iv_span.alpha = 0.5F
                            requireActivity().iv_span.isEnabled = false
                        }
                    }
                }

                if (RecoverableImageActivity.lastSelection == 1 && RecoverableImageActivity.prevPosRecoverable == 0) {
                    (requireActivity() as RecoverableImageActivity).iv_span!!.isSelected =
                        requireContext().getGridCount() == SPAN_COUNT_THREE
                }

                scan_recoverable_album!!.layoutManager = GridLayoutManager(
                    (requireActivity() as RecoverableImageActivity),
                    (requireActivity() as RecoverableImageActivity).getGridCount()
                )

            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        mView = inflater.inflate(R.layout.fragment_recoverable_image_video, container, false)
        return mView
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        getAppList()
    }

    private fun getAppList() {
//        iv_not_found.setImageResource(R.drawable.ic_backup_not_found_image)
        tv_not_found.setText(R.string.image_not_found)

        mGetRecoverableAlbum = GetRecoverableAlbum().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
//        mGetRecoverableAlbum = GetRecoverableAlbum().execute()

        scan_recoverable_album!!.layoutManager = GridLayoutManager(
            (requireActivity() as RecoverableImageActivity),
            (requireActivity() as RecoverableImageActivity).getGridCount()
        )
        scan_recoverable_album!!.setHasFixedSize(true)

        mHiddenPictureFolderAdapter = RecoverableFolderAdapter(mRecoverableFolderList,
            (requireActivity() as RecoverableImageActivity),
            object :
                ItemClickListener {
                override fun onPicClicked(pictureFolderPath: String?, folderName: String?) {
                    val move = Intent(
                        (requireActivity() as RecoverableImageActivity),
                        ViewRecoverableImageListActivity::class.java
                    )
                    move.putExtra("folderPath", pictureFolderPath)
                    move.putExtra("folderName", folderName)
                    startActivity(move)
//                    finish()
                }

            })
        scan_recoverable_album.adapter = mHiddenPictureFolderAdapter
    }

    override fun onClick(view: View) {

    }

    override fun onResume() {
        super.onResume()
        if (isAdded) {

//            resumeImageCount += 1
            Log.e(mTAG, "onResume: $isVisibleHint")

            object : AsyncTask<Void, Long, Void>() {
                override fun doInBackground(vararg voids: Void): Void? {
                    Log.e(mTAG, "doInBackground: stopLoading")
//                    stopLoading()
                    if (!isAsyncRunning) stopLoading()
                    return null
                }

                override fun onPostExecute(result: Void?) {
                    super.onPostExecute(result)
                }
            }.execute()
        }
    }


    private inner class GetRecoverableAlbum :
        AsyncTask<Void?, String?, ArrayList<RecoverableFolderModel>>() {

        override fun onPreExecute() {
            try {
                isAsyncRunning = true
                if(lottie_recoverable_image!=null) lottie_recoverable_image.visibility = View.VISIBLE
                (requireActivity() as RecoverableImageActivity).iv_span.alpha = 0.5F
                (requireActivity() as RecoverableImageActivity).iv_span.isEnabled = false
                (requireActivity() as RecoverableImageActivity).unSelectAll()

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        override fun doInBackground(vararg voids: Void?): ArrayList<RecoverableFolderModel> {
            mFolderList.clear()
            mRecoverableFolderList.clear()
//            mFolderList = gridRecoverableAlbumImage(ShareConstants.mRootPath)
            mFolderList = checkFileOfDirectory(getFileList(ShareConstants.mRootPath)!!)

//            val mlist = Utils.getListAllFiles(ShareConstants.mRootPath)
//            val mFinalList = mlist.filter { file: File? -> file?.path!!.contains("/.") && !file.path.contains("Backup And Recovery") }
//            mFolderList = checkFileOfDirectoryNew(mFinalList)


            return mFolderList
        }

        override fun onPostExecute(lRecoverableFolderList: ArrayList<RecoverableFolderModel>) {
            try {
                Log.e(mTAG, "onPostExecute ")
                Handler(Looper.getMainLooper()).post {
                    isAsyncRunning = false
                    stopLoading()
                    if (isAdded) {
                        try {
                            if (lRecoverableFolderList.size <= 0) {
                                if(lottie_recoverable_image!=null) lottie_recoverable_image.visibility = View.GONE
                                if(scan_recoverable_album!=null) scan_recoverable_album!!.visibility = View.GONE
                                if(tv_recoverable_album!=null) tv_recoverable_album!!.visibility = View.VISIBLE

                                if (RecoverableImageActivity.lastSelection == 1 && RecoverableImageActivity.prevPosRecoverable == 0) {
                                    (requireActivity() as RecoverableImageActivity).unSelectAll()
                                    (requireActivity() as RecoverableImageActivity).iv_span.alpha =
                                        0.5F
                                    (requireActivity() as RecoverableImageActivity).iv_span.isEnabled =
                                        false
                                }
                            } else {
                                if(scan_recoverable_album!=null) scan_recoverable_album!!.visibility = View.VISIBLE
                                if(tv_recoverable_album!=null) tv_recoverable_album!!.visibility = View.GONE
                                if (RecoverableImageActivity.lastSelection == 1 && RecoverableImageActivity.prevPosRecoverable == 0) {
                                    (requireActivity() as RecoverableImageActivity).selectTop(1)
                                    (requireActivity() as RecoverableImageActivity).iv_span.alpha =
                                        1F
                                    (requireActivity() as RecoverableImageActivity).iv_span.isEnabled =
                                        true
                                }
                            }
                            Collections.sort(
                                lRecoverableFolderList,
                                ShareConstants.RecoverableDateAscending()
                            )
                        } catch (e: Exception) {

                        }
                    }

                    if (isAdded) (requireActivity() as RecoverableImageActivity).mIsCancelAsync =
                        false
                }
//                mHiddenPictureFolderAdapter!!.runLayoutAnimation()
            } catch (e: Exception) {
                e.printStackTrace()
            }


        }
    }


    fun getFileList(str: String): Array<File>? {
        val file = File(str)
        return if (file.isDirectory) {
            file.listFiles()
        } else {
            null
        }
    }


    private fun checkFileOfDirectory(fileArr: Array<File>): ArrayList<RecoverableFolderModel> {

        val picPaths = ArrayList<String?>()
        val mFolderModel = RecoverableFolderModel()

        var isNewData = false
        for (i in fileArr.indices) {
            isNewData = false
            if (fileArr[i].isDirectory &&
                !fileArr[i].name.startsWith("data") &&
                !fileArr[i].name.startsWith("obb") &&
                !fileArr[i].name.startsWith("obj") &&
                !fileArr[i].name.startsWith(".trash") &&
                !fileArr[i].name.contains("Backup And Recovery")
            ) {
                checkFileOfDirectory(getFileList(fileArr[i].path)!!)
            } else {
                if (fileArr[i].length().toString() != "0" && fileArr[i].path.contains("/.")) {
//                if (fileArr[i].length().toString() != "0") {

                    val lExtension = getExtension(fileArr[i].path)
                    val isExtensionMatches = SharedPrefsConstant.ImageArray.contains(lExtension) && fileArr[i].path.endsWith(lExtension)

                    if (isExtensionMatches) {
//                        if (fileArr[i].path.contains("/.")) {
                        val folder = Objects.requireNonNull(fileArr[i].parentFile).name
                        val mRootPath = fileArr[i].parent!!

                        if (!picPaths.contains(mRootPath)) {
                            picPaths.add(mRootPath)
                            mFolderModel.path = mRootPath
                            mFolderModel.folderName = folder
                            mFolderModel.folderDate = File(mRootPath).lastModified()
//                                val lFolderSize = ShareConstants.getFolderSize(File(mRootPath))
//                                mFolderModel.folderSize = lFolderSize
                            mFolderModel.firstPic = fileArr[i].path
                            mFolderModel.addPics()
                            mRecoverableFolderList.add(mFolderModel)
                            isNewData = true
                        } else {
                            for (j in mRecoverableFolderList.indices) {
                                if (mRecoverableFolderList[j].path == mRootPath) {
                                    mRecoverableFolderList[j].firstPic = fileArr[i].path
                                    mRecoverableFolderList[j].addPics()
                                    isNewData = true
                                }
                            }
                        }
//                        }

                    }
                }
            }

            if (mGetRecoverableAlbum != null) {
                if (mGetRecoverableAlbum!!.isCancelled) {
                    (requireActivity() as RecoverableImageActivity).runOnUiThread {
                        MyApplication.isDialogOpen = false
                        mFolderList.clear()
                        if(scan_recoverable_album!=null) scan_recoverable_album!!.visibility = View.GONE
//                        if(lottie_recoverable_image!=null) lottie_recoverable_image.visibility = View.GONE
                        if (isAdded) (requireActivity() as RecoverableImageActivity).mIsCancelAsync = true
                        if (isAdded) (requireActivity() as RecoverableImageActivity).unSelectAll()
                    }
                    break
                }
            }

            if (isAdded && isNewData) {
                (requireActivity() as RecoverableImageActivity).runOnUiThread {
                    Handler(Looper.getMainLooper()).postDelayed(Runnable {
                        mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
                    }, 200)
                }
            }
        }
        return mRecoverableFolderList
    }

    fun stopLoading() {
        activity?.runOnUiThread {
            Handler(Looper.getMainLooper()).postDelayed({

                if(lottie_recoverable_image!=null) lottie_recoverable_image.visibility = View.GONE
                if (isAdded) {
                    if (mFolderList != null && mFolderList.size != 0) {

                        if (RecoverableImageActivity.lastSelection == 1 && RecoverableImageActivity.prevPosRecoverable == 0) {
                            (requireActivity() as RecoverableImageActivity).selectTop(1)
                            if (requireActivity().iv_span != null) {
                                requireActivity().iv_span.alpha = 1F
                                requireActivity().iv_span.isEnabled = true
                            }
                            if (requireActivity().btnRecover != null) {
                                requireActivity().btnRecover.alpha = 1F
                                requireActivity().btnRecover.isEnabled = true
                            }
                            if (requireActivity().llSelectAll != null) {
                                requireActivity().llSelectAll.alpha = 1F
                                requireActivity().llSelectAll.isEnabled = true
                            }
                        }
                        if(tv_recoverable_album!=null) tv_recoverable_album!!.visibility = View.GONE
                        if(lottie_recoverable_image!=null) lottie_recoverable_image.visibility = View.GONE
                        Log.e(mTAG, "stopLoading: ")
                    } else {
                        if (RecoverableImageActivity.lastSelection == 1 && RecoverableImageActivity.prevPosRecoverable == 0) {
                            (requireActivity() as RecoverableImageActivity).unSelectAll()
                        }
                        if(lottie_recoverable_image!=null) lottie_recoverable_image.visibility = View.GONE
                    }
                }
            }, 1000)
        }
    }


    override fun onDestroy() {
        super.onDestroy()

        if (mGetRecoverableAlbum != null) {
            if (mGetRecoverableAlbum?.status == AsyncTask.Status.RUNNING) {
                mGetRecoverableAlbum?.cancel(true)
            }
        }
//        context!!.unregisterReceiver(refreshMediaBroadcast)
    }
}