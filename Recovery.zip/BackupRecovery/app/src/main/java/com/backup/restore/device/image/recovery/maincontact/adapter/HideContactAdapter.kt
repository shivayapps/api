package com.backup.restore.device.image.recovery.maincontact.adapter

import android.content.Context
import android.graphics.Typeface
import android.os.SystemClock
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.amulyakhare.textdrawable.TextDrawable
import com.amulyakhare.textdrawable.util.ColorGenerator
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.database.DBAdapter
import com.backup.restore.device.image.recovery.maincontact.callbacks.OnHideItemClick
import com.backup.restore.device.image.recovery.maincontact.model.ContactModel
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_favorite.*
import java.util.*

class HideContactAdapter(var mContext: Context, var mHideContactList: ArrayList<ContactModel> , var mHideItemClick : OnHideItemClick) :
    RecyclerView.Adapter<HideContactAdapter.ContactView>() {
    var mDbHelper: DBAdapter? = null

    private val mColorGenerator = ColorGenerator.MATERIAL
    private var mDrawableBuilder: TextDrawable.IBuilder? = null


    class ContactView(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var ivPhoto: ImageView = itemView.findViewById(R.id.ivPhoto)
        var ivContact: ImageView = itemView.findViewById(R.id.ivContact)
        var tvName: TextView = itemView.findViewById(R.id.tvName)
        var tvNumber: TextView = itemView.findViewById(R.id.tvNumber)

    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactView {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.raw_hide_contact_list_item, parent, false)
        return ContactView(view)
    }

    override fun onBindViewHolder(holder: ContactView, position: Int) {
        mDbHelper = DBAdapter(mContext)
        if (mHideContactList[position].mContactImageUri != null  && mHideContactList[position].mContactImageUri != "null" && mHideContactList[position].mContactImageUri!!.length !=0) {
            Glide.with(mContext).load(mHideContactList[position].mContactImageUri).placeholder(R.drawable.no_user_contact_image).into(holder.ivPhoto)
        } else {
            if (mHideContactList[position].mContactName!!.isNotEmpty() &&
                !TextUtils.isDigitsOnly(mHideContactList[position].mContactName!!.substring(0, 1))) {
                val mTypeface: Typeface = Typeface.createFromAsset(mContext.assets, "app_font/firasans_medium.ttf")
                mDrawableBuilder = TextDrawable.builder()
                    .beginConfig()
                    .bold()
                    .useFont(mTypeface)
                    .height(50)
                    .width(50)
                    .endConfig()
                    .round()

                val drawable = mDrawableBuilder!!.build(mHideContactList[position].mContactName!![0].toString().capitalize(), mColorGenerator.getColor( mHideContactList[position].mContactName))

                holder.ivPhoto.setImageDrawable(drawable)
            } else {
                holder.ivPhoto.setImageDrawable(mContext.resources.getDrawable(R.drawable.no_user_contact_image))
            }

        }

        holder.tvName.text = mHideContactList[position].mContactName
        holder.tvNumber.text = mHideContactList[position].mNumber

        holder.itemView.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }

            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            ShareConstants.hide_position = position
            mHideItemClick.onHideContactItemClick(position)

        }
    }

    fun setList(list: ArrayList<ContactModel>) {
        mHideContactList = list
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return mHideContactList.size
    }
}