package com.backup.restore.device.image.recovery.mainapps.fragment

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainapps.adapter.ParentAdapter
import com.backup.restore.device.image.recovery.mainapps.model.FeaturesHW
import com.backup.restore.device.image.recovery.mainapps.model.ParentModel

/**
 * A placeholder fragment containing a simple view.
 */
class DeviceModelFragmentNew : Fragment() {
    var rootView: View? = null
    var mode = 0
    var ivType: ImageView? = null
    var tvTitle: TextView? = null
    var tvSubTitle: TextView? = null
    private var rvFeatureList: RecyclerView? = null

    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"

        @JvmStatic
        fun newInstance(): DeviceModelFragmentNew {
            val fragment = DeviceModelFragmentNew()
            val bundle = Bundle()
            bundle.putInt(ARG_SECTION_NUMBER, 0)
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var index = 1
//        if (arguments != null) {
//            index = arguments!!.getInt(ARG_SECTION_NUMBER)
//        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootView = inflater.inflate(R.layout.fragment_device_information, container, false)

        ivType = rootView?.findViewById(R.id.iv_type)
        tvTitle = rootView?.findViewById(R.id.tv_title)
        tvSubTitle = rootView?.findViewById(R.id.tv_sub_title)
        rvFeatureList = rootView?.findViewById(R.id.rv_feature_list)
        rvFeatureList?.layoutManager = GridLayoutManager(activity, 1)
        rvFeatureList?.hasFixedSize()
        getDeviceInfoMap()

        val scrollMain: NestedScrollView = rootView?.findViewById(R.id.scroll_main)!!
        scrollMain.scrollTo(0,0)
        return rootView
    }

    private fun getDeviceInfoMap() {
        ivType!!.setImageResource(R.drawable.ic_device)
        tvTitle!!.text = getString(R.string.device_information)
        tvSubTitle!!.text = getProperText(Build.MODEL)
        tvTitle!!.isSelected = true
        tvSubTitle!!.isSelected = true

        val parents = ArrayList<ParentModel>()
        val pIndex = 0

        parents.add(ParentModel(resources.getString(R.string.device_information), ArrayList<FeaturesHW>()))
        val lists: ArrayList<FeaturesHW> = parents.get(pIndex).lists
        lists.add(FeaturesHW(getString(R.string.brand_name), "${getProperText(Build.BRAND)}"))
        lists.add(FeaturesHW(getString(R.string.model_number), "${getProperText(Build.MODEL)}"))
        lists.add(FeaturesHW(getString(R.string.manufacturer), "${getProperText(Build.MANUFACTURER)}"))
        lists.add(FeaturesHW(getString(R.string.board), "${getProperText(Build.BOARD)}"))
        lists.add(FeaturesHW(getString(R.string.hardware), "${getProperText(Build.HARDWARE)}"))
        lists.add(FeaturesHW(getString(R.string.serial_no), "${getProperText(Build.SERIAL)}"))

        @SuppressLint("HardwareIds")
        val androidID = Settings.Secure.getString(
            requireContext().contentResolver, Settings.Secure.ANDROID_ID
        )
        lists.add(FeaturesHW(getString(R.string.android_id), "${getProperText(androidID)}"))

        val wm = requireActivity().getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val metrics = DisplayMetrics()
        display.getMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels

        lists.add(FeaturesHW(getString(R.string.screen_resolution), "$width * $height Pixels"))
        lists.add(FeaturesHW(getString(R.string.boot_loader), "${getProperText(Build.BOOTLOADER)}"))
        lists.add(FeaturesHW(getString(R.string.user), "${getProperText(Build.USER)}"))
        lists.add(FeaturesHW(getString(R.string.host), "${getProperText(Build.HOST)}"))
        lists.add(FeaturesHW(getString(R.string.model), "${getProperText(Build.MODEL)}"))

        val adapter = ParentAdapter(parents, requireContext())
        rvFeatureList?.adapter = adapter

        val scrollMain: NestedScrollView = rootView?.findViewById(R.id.scroll_main)!!
//        scrollMain.scrollTo(0,0)
//        scrollMain.fullScroll(View.FOCUS_UP)
        Handler(Looper.getMainLooper()).postDelayed({
            scrollMain.scrollTo(0,0)
        },100)

    }


//    private fun getDeviceInfo() {
//        tvManufacturer!!.text = "" + Build.MANUFACTURER
//        tvBrand!!.text = "" + Build.BRAND
//        tvModelNumber!!.text = "" + Build.MODEL
//        tvModel!!.text = "" + Build.MODEL
//        tvBoard!!.text = "" + Build.BOARD
//        tvHardware!!.text = "" + Build.HARDWARE
//        tvSerialNo!!.text = "" + Build.SERIAL
//        @SuppressLint("HardwareIds")
//        val androidID = Settings.Secure.getString(
//            requireContext().contentResolver, Settings.Secure.ANDROID_ID
//        )
//        tvAndroidId!!.text = "" + androidID
//        val wm = requireActivity().getSystemService(Context.WINDOW_SERVICE) as WindowManager
//        val display = wm.defaultDisplay
//        val metrics = DisplayMetrics()
//        display.getMetrics(metrics)
//        val width = metrics.widthPixels
//        val height = metrics.heightPixels
//        tvScreenResolution!!.text = "$width * $height Pixels"
//        tvBootLoader!!.text = Build.BOOTLOADER
//        tvHost!!.text = Build.HOST
//        tvUser!!.text = Build.USER
//
//
//        tvManufacturer?.isSelected=true
//        setEmptyText(tvManufacturer)
//        setEmptyText(tvBrand)
//        setEmptyText(tvModelNumber)
//        setEmptyText(tvSubTitle)
//        setEmptyText(tvModel)
//        setEmptyText(tvBoard)
//        setEmptyText(tvHardware)
//        setEmptyText(tvSerialNo)
//        setEmptyText(tvAndroidId)
//        setEmptyText(tvScreenResolution)
//        setEmptyText(tvBootLoader)
//        setEmptyText(tvUser)
//        setEmptyText(tvHost)
//    }

    private fun getProperText(textValue: String?): String {
        if (textValue.isNullOrEmpty()) {
            return getString(R.string.unavailable)
        } else return textValue
    }

    override fun onDestroyView() {
        super.onDestroyView()
        rootView = null
    }

}