package com.backup.restore.device.image.recovery.maincontact.activity

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.os.*
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.database.ContactFetcher
import com.backup.restore.device.image.recovery.maincontact.adapter.ContactSelectionAdapter
import com.backup.restore.device.image.recovery.maincontact.callbacks.OnBackupItemClick
import com.backup.restore.device.image.recovery.maincontact.model.ContactModel
import com.backup.restore.device.image.recovery.maincontact.model.CountNameModel
import com.backup.restore.device.image.recovery.utilities.*
import com.backup.restore.device.image.recovery.utilities.common.MyUtils
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.itextpdf.text.*
import com.itextpdf.text.pdf.*
import kotlinx.android.synthetic.main.activity_configure_contact.*
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*
import kotlin.collections.ArrayList


class ConfigureContactActivity : MyCommonBaseActivity(), View.OnClickListener {

    val mTAG: String = "ConfigureContact"
    private var mContactAdapter: ContactSelectionAdapter? = null
    private var mCountCont = 0
    private var isExportExcel = true


    val colorPrimary = BaseColor.BLACK

    val FONT_SIZE_DEFAULT = 12f
    val FONT_SIZE_SMALL = 8f
//    var basfontLight: BaseFont = BaseFont.createFont("res/font/firasans_regular.ttf", "UTF-8", BaseFont.EMBEDDED)
    var basfontLight: BaseFont = BaseFont.createFont()
//    var appFontLight = Font(basfontLight, FONT_SIZE_SMALL)
    var appFontLight = Font(Font.FontFamily.HELVETICA, FONT_SIZE_SMALL, Font.NORMAL)
//    var basfontRegular: BaseFont = BaseFont.createFont("res/font/firasans_regular.ttf", "UTF-8", BaseFont.EMBEDDED)
    var basfontRegular: BaseFont = BaseFont.createFont()
//    var appFontRegular = Font(basfontRegular, FONT_SIZE_DEFAULT)
    var appFontRegular = Font(Font.FontFamily.HELVETICA, FONT_SIZE_DEFAULT, Font.NORMAL)
//    var basfontSemiBold: BaseFont = BaseFont.createFont("res/font/firasans_medium.ttf", "UTF-8", BaseFont.EMBEDDED)
    var basfontSemiBold: BaseFont = BaseFont.createFont()
//    var appFontSemiBold = Font(basfontSemiBold, 24f)
    var appFontSemiBold = Font(Font.FontFamily.HELVETICA, 24f, Font.BOLD)
//    var basfontBold: BaseFont = BaseFont.createFont("res/font/firasans_medium.ttf", "UTF-8", BaseFont.EMBEDDED)
    var basfontBold: BaseFont = BaseFont.createFont()
    var appFontBold = Font(basfontBold, FONT_SIZE_DEFAULT)

    val PADDING_EDGE = 20f
    val TEXT_TOP_PADDING = 3f
    val TABLE_TOP_PADDING = 10f
    val TEXT_TOP_PADDING_EXTRA = 30f
    val BILL_DETAILS_TOP_PADDING = 80f
    val linkSample = "https://play.google.com/store/apps/details?id=com.backup.restore.device.image.recovery"

    companion object {
        var mainContactList = ArrayList<ContactModel>()
        var tempContactList = ArrayList<ContactModel>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_configure_contact)

        addEvent(ConfigureContactActivity::class.simpleName!!)

    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
    }

    override fun getContext(): AppCompatActivity {
        return this@ConfigureContactActivity
    }

    override fun initData() {
        contactListData()
        val gridLayoutManager1 = GridLayoutManager(mContext, 1)
        rvContact.layoutManager = gridLayoutManager1
    }

    override fun initActions() {
        ivBack.setOnClickListener(this)
        btnNext.setOnClickListener(this)
//        ivSelectAll.setOnCheckedChangeListener(mOnCheckedChangeListener)
        checkListner()

        et_search_apk.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (et_search_apk.text.toString().isEmpty()) {
                    et_search_apk.clearFocus()
                    MyUtils.hideKeyboard(applicationContext, et_search_apk)
                } else {
                    et_search_apk.requestFocus()
                }
            }

            override fun afterTextChanged(s: Editable) {
                if (s.toString() != null) searchContact(s.toString().toLowerCase(Locale.getDefault()))
                else searchContact("")
            }
        })

    }


    private fun checkListner() {

        llSelectAll.setOnClickListener {

            if (ivSelectAll!!.isChecked) {
                ivSelectAll!!.isChecked = false
                for (i in mainContactList.indices) {
                    mainContactList[i].isSelected = false
                    mContactAdapter!!.notifyDataSetChanged()
                }
            } else {
                ivSelectAll!!.isChecked = true
                for (i in mainContactList.indices) {
                    mainContactList[i].isSelected = true
                    mContactAdapter!!.notifyDataSetChanged()
                }
            }
        }
//        ivSelectAll.setOnCheckedChangeListener { _, isChecked ->
//            if (mainContactList.size >= 0) {
//                mContactAdapter?.setSelectedAll(isChecked)
//            }
//        }
    }

    private fun searchContact(str: String) {

        tempContactList = mainContactList

        if (str.isEmpty()) {

            if(tempContactList.size==0) return
            mContactAdapter!!.setList(tempContactList)
            val selectedSize = mContactAdapter!!.getSelectedItems().size
            if (selectedSize == 0) {
                ivSelectAll!!.isChecked = false
            } else {
                ivSelectAll!!.isChecked = selectedSize == mainContactList.size
            }
            if (tempContactList.size != 0) {
                rvContact.visibility = VISIBLE
                llSelectAll.visibility = VISIBLE
                ivSelectAll.visibility = VISIBLE
                btnNext.visibility = VISIBLE
                tvEmpty.visibility = GONE
                btnNext.isEnabled = true
            }
            else {
                rvContact.visibility = GONE
                llSelectAll.visibility = GONE
                ivSelectAll.visibility = GONE
                btnNext.visibility = GONE
                tvEmpty.visibility = VISIBLE
                btnNext.isEnabled = false
            }
        }
        else {
            if(tempContactList.size==0) return

            val filteredList = ArrayList<ContactModel>()
            for (contactModel in tempContactList) {
                if (contactModel.mContactName?.toLowerCase(Locale.getDefault())?.contains(str.toLowerCase(Locale.getDefault())) == true ||
                    contactModel.mNumber?.toLowerCase(Locale.getDefault())?.replace("-", "")?.contains(str.toLowerCase(Locale.getDefault())) == true
                ) {
                    filteredList.add(contactModel)
                }
            }

            tempContactList = filteredList
            mContactAdapter!!.setList(tempContactList)

            if (filteredList.size != 0) {
                rvContact.visibility = VISIBLE
                llSelectAll.visibility = VISIBLE
                ivSelectAll.visibility = GONE
                btnNext.visibility = VISIBLE
                tvEmpty.visibility = GONE
                btnNext.isEnabled = true
            } else {
                rvContact.visibility = GONE
                llSelectAll.visibility = GONE
                ivSelectAll.visibility = GONE
                btnNext.visibility = GONE
                tvEmpty.visibility = VISIBLE
                btnNext.isEnabled = false
            }
        }

//        Log.e(mTAG, "searchContact str: $str :")
//        val toLowerCase: CharSequence = str.toLowerCase(Locale.ROOT)
//        val contactList = ContactFetcher(mContext).fetchAll()
//        mainContactList.clear()
//        mainContactList.addAll(contactList.filter { s -> !s.mContactName.isNullOrEmpty() && !s.mNumber.isNullOrEmpty() })
//        val arrayList = ArrayList<ContactModel>()
//        Log.e(mTAG, "searchContact MainContactList: ${mainContactList.size} ")
//        for (contactModel in mainContactList) {
//            if (contactModel.mContactName?.toLowerCase(Locale.ROOT)
//                    ?.contains(toLowerCase) == true ||
//                contactModel.mNumber?.toLowerCase(Locale.ROOT)?.replace("-", "")
//                    ?.contains(toLowerCase) == true
//            ) {
//                arrayList.add(contactModel)
//            }
//        }
//        if (str.isEmpty()) {
//            contactListData()
//        } else {
//            mContactAdapter?.setList(arrayList)
//        }
//        rvContact.adapter = mContactAdapter
//        mContactAdapter?.notifyDataSetChanged()

    }

    override fun onClick(view: View) {
        if (view == btnNext) {
            val selectedList = mContactAdapter?.getSelectedItems()
            if (selectedList?.size != 0) {
                dialogExportTo()
            } else {
                Toast.makeText(
                    this@ConfigureContactActivity,
                    getString(R.string.no_contact_to_export),
                    Toast.LENGTH_SHORT
                ).show()
            }
        } else if (view == ivBack) {
            onBackPressed()
        }
    }

    override fun onBackPressed() {
        //et_search_apk.setText("")
        //et_search_apk.clearFocus()
//        MyUtils.hideKeyboard(applicationContext, et_search_apk)
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }


    fun contactListData() {
        mainContactList.clear()

        rvContact.visibility = GONE
//        tv_titles.text = "${mContext.getString(R.string.contact)}"
        val contactList = ContactFetcher(mContext).fetchAll()
        mainContactList.addAll(contactList.filter { s -> !s.mContactName.isNullOrEmpty() && !s.mNumber.isNullOrEmpty() })
        mCountCont = mainContactList.size

        Log.e("contactListData", "contactListData: $mCountCont")
        if (mCountCont > 0) {
            tvEmpty.visibility = GONE
            rvContact.visibility = VISIBLE
            btnNext.visibility = VISIBLE
            llSelectAll.visibility = VISIBLE
            btnNext.isEnabled = true

            Collections.sort(
                mainContactList,
                ContactSorter()
            )


            mContactAdapter =
                ContactSelectionAdapter(mContext, mainContactList, ivSelectAll, object : OnBackupItemClick {
                    override fun onItemClick(
                        contact: CountNameModel?,
                        backupFile: File?,
                        position: Int
                    ) {
//                        ivSelectAll.setOnCheckedChangeListener(null)
//                        ivSelectAll.isChecked = mContactAdapter?.getSelectedItems()?.size == mainContactList.size
//                        checkListner()
                    }

                    override fun onContactItemClick(contact: ContactModel?, position: Int) {

//                        ivSelectAll.isChecked = mContactAdapter?.getSelectedItems()?.size == mainContactList.size
                    }
                })

            rvContact.adapter = mContactAdapter
            mContactAdapter?.setSelectedAll(ivSelectAll.isChecked)

//            tv_titles.text = "${mContext.getString(R.string.contact)}"
        } else {
            btnNext.isEnabled = false
            rvContact.visibility = GONE
            tvEmpty.visibility = VISIBLE
            btnNext.visibility = GONE
            llSelectAll.visibility = GONE
        }
    }

    private fun dialogExportTo() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_contact_export)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val checkExcel = dialog.findViewById<RadioButton>(R.id.cb_select_excel)
        val checkPdf = dialog.findViewById<RadioButton>(R.id.cb_select_pdf)
        val ll_excel = dialog.findViewById<LinearLayout>(R.id.ll_rating_view)
        val ll_pdf = dialog.findViewById<LinearLayout>(R.id.ll_pdf)

        ll_excel.setOnClickListener {
            checkExcel.isChecked = true
            isExportExcel = true
            checkPdf.isChecked = false

//            checkExcel.toggle()
//            if(checkExcel.isChecked) {
//                isExportExcel=true
//                checkPdf.isChecked=false
//            } else {
//                isExportExcel=false
//                checkPdf.isChecked=true
//            }
        }
        ll_pdf.setOnClickListener {
            checkPdf.isChecked = true
            isExportExcel = false
            checkExcel.isChecked = false

//            checkPdf.toggle()
//            if(checkPdf.isChecked) {
//                isExportExcel=false
//                checkExcel.isChecked=false
//            } else {
//                isExportExcel=true
//                checkExcel.isChecked=true
//            }
        }
//        checkExcel.setOnCheckedChangeListener{ _, isChecked ->
//            if(isChecked) {
//                isExportExcel=true
//                checkPdf.isChecked=false
//            } else {
//                isExportExcel=false
//                checkPdf.isChecked=true
//            }
//        }

//        checkPdf.setOnCheckedChangeListener{ _, isChecked ->
//            if(isChecked) {
//                isExportExcel=false
//                checkExcel.isChecked=false
//            } else {
//                isExportExcel=true
//                checkExcel.isChecked=true
//            }
//        }

        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
            dialog.dismiss()
        }
        dialog.findViewById<View>(R.id.dialogButtonok).setOnClickListener {
            dialog.dismiss()
            if (checkExcel.isSelected) isExportExcel = true
            if (checkPdf.isSelected) isExportExcel = false

            dialogSelectInfo()
        }

        dialog.show()
    }

    class ContactSorter : Comparator<ContactModel> {
        override fun compare(lhs: ContactModel, rhs: ContactModel): Int {
            if (lhs.mContactName != null && rhs.mContactName != null)
                return lhs.mContactName!!.compareTo(rhs.mContactName!!)
            else return -1
        }
    }

    private fun dialogSelectInfo() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_select_detail)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val checkName = dialog.findViewById<CheckBox>(R.id.cb_name)
        val checkNumber = dialog.findViewById<CheckBox>(R.id.cb_number)
        val checkEmail = dialog.findViewById<CheckBox>(R.id.cb_email)
        val checkBirthday = dialog.findViewById<CheckBox>(R.id.cb_birthday)

        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
            dialog.dismiss()
        }
        dialog.findViewById<View>(R.id.dialogButtonok).setOnClickListener {
            val selectedList = mContactAdapter?.getSelectedItems()
            if (selectedList?.size == 0) {
                Toast.makeText(
                    getContext(),
                    getString(R.string.please_select_contact),
                    Toast.LENGTH_SHORT
                ).show()
                dialog.dismiss()
            } else if (
                !checkName.isChecked &&
                !checkNumber.isChecked &&
                !checkEmail.isChecked &&
                !checkBirthday.isChecked
            ) {
                Toast.makeText(
                    getContext(),
                    getString(R.string.please_select_information_to_export),
                    Toast.LENGTH_LONG
                ).show()
            } else {
                if (isExportExcel) {

                    val file = generateEmptyFile("contact", "xls")

                    val exemportExcel = ExcelUtils.exportDataIntoWorkbook(
                        application,
                        file,
                        selectedList,
                        checkName.isChecked,
                        checkNumber.isChecked,
                        checkEmail.isChecked,
                        checkBirthday.isChecked
                    )
                    if (exemportExcel) {
                        dialog.dismiss()

                        val intent = Intent(this@ConfigureContactActivity, ShareActivity::class.java)
                        intent.putExtra("file_path", ShareConstants.mExcelPath)
                        intent.putExtra("file_type", 0)
                        startActivity(intent)
                        (this@ConfigureContactActivity).finish()
                        if (dialog != null && dialog.isShowing) {
                            dialog.cancel()
                            MyApplication.isDialogOpen = false
                        }
                    }

                } else {
                    dialog.dismiss()
//                    RPdfGenerator.generatePdf(application,
//                        selectedList!!,
//                        checkName.isChecked,
//                        checkNumber.isChecked,
//                        checkEmail.isChecked,
//                        checkBirthday.isChecked)

                    val file = generateEmptyFile("contact", "pdf")
                    var rxportTOPdf = ExportTOPdf(
                        mContext,
                        file,
                        selectedList!!,
                        checkName.isChecked,
                        checkNumber.isChecked,
                        checkEmail.isChecked,
                        checkBirthday.isChecked
                    )

//                    exportPdf(filePath,selectedList!!, checkName.isChecked, checkNumber.isChecked, checkEmail.isChecked, checkBirthday.isChecked)

//                    val timeStamp = SimpleDateFormat("ddMMyyyy_hh_mm_ss", Locale.getDefault()).format(Date())
//                    val FILENAME = "Contact_$timeStamp.pdf"
//                    generateChallanHTML(share_pdf,FILENAME,selectedList!!,checkName.isChecked, checkNumber.isChecked, checkEmail.isChecked, checkBirthday.isChecked)

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                        rxportTOPdf.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                    } else {
                        rxportTOPdf.execute()
                    }
                }
            }

        }
        dialog.show()
    }

    private fun getHtmlFromAsset(): String? {
        var htmlString: String? = null
        try {

            val `is` = assets.open("webview/backup_pdf.html")
            val size = `is`.available()

            val buffer = ByteArray(size)
            `is`.read(buffer)
            `is`.close()

            htmlString = String(buffer)
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return htmlString
    }

    private inner class ExportTOPdf(
        val context: Context,
        val filePath: File,
        val dataList: List<ContactModel>,
        val isName: Boolean,
        val isNumber: Boolean,
        val isEmail: Boolean,
        val isDob: Boolean
    ) : AsyncTask<Void?, String?, Void?>() {
        var progressDialog: Dialog? = null

        var permission_text: TextView? = null

        //        var filePath:String=""
        val linkSample = "https://play.google.com/store/apps/details?id=com.backup.restore.device.image.recovery"

        override fun onPreExecute() {
            super.onPreExecute()
            progressDialog = Dialog(context)
            progressDialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
            progressDialog?.setCancelable(false)
            progressDialog?.setContentView(R.layout.dialog_progress)
            progressDialog?.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            progressDialog?.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            progressDialog?.findViewById<TextView>(R.id.permission)?.text =
                getString(R.string.label_please_wait)
            permission_text = progressDialog?.findViewById<TextView>(R.id.permission_text)
//            permission_text?.text = getString(R.string.loading_contacts)
            progressDialog?.findViewById<TextView>(R.id.dialogButtonCancel)?.visibility = GONE
//            holoCircleSeekBar = dialog.findViewById(R.id.holoCircleSeekbar)

            if (progressDialog != null && !progressDialog?.isShowing!!) {
                if (!isFinishing) {
                    progressDialog?.show()
                }
            }

        }

        override fun onProgressUpdate(vararg values: String?) {
            super.onProgressUpdate(*values)
            val parseInt = values[0]?.toInt()
//            permission_text?.setMax(100)
//            val value = parseInt / dataList.size
            runOnUiThread {
                permission_text?.text =
                    "${mContext.getString(R.string.export_contact)} $parseInt / ${dataList.size}"
            }
        }

        override fun doInBackground(vararg voids: Void?): Void? {

            appFontRegular.color = BaseColor.WHITE
            appFontRegular.size = 10f
            val doc = Document(PageSize.A4, 0f, 0f, 0f, 0f)
//            val outPath = generateEmptyFile("contact", "pdf")
            val writer = PdfWriter.getInstance(doc, FileOutputStream(filePath))
            doc.open()

            val numCols = getSize(isName, isNumber, isEmail, isDob)
            val sizeEach = 7 - (0.2f + 0.2f + 0.5f)
            val colSize = when (numCols) {
                1 -> sizeEach / 1
                2 -> sizeEach / 2
                3 -> sizeEach / 3
                else -> sizeEach / 4
            }
            val colWidth = when (numCols) {
                0 -> floatArrayOf(0.2f, 0.5f, 0.2f)
                1 -> floatArrayOf(0.2f, 0.5f, colSize, 0.2f)
                2 -> floatArrayOf(0.2f, 0.5f, colSize, colSize, 0.2f)
                3 -> floatArrayOf(0.2f, 0.5f, colSize, colSize, colSize, 0.2f)
                else -> floatArrayOf(0.2f, 0.5f, colSize, colSize, colSize, colSize, 0.2f)
            }

            doc.add(Paragraph("\n"))

            val colSizeH = (7 - (0.2f + 0.2f + 1f))/4
            val headerTable = PdfPTable(7)
            headerTable.setWidths(floatArrayOf(0.2f, 1f, colSizeH, colSizeH, colSizeH, colSizeH, 0.2f))
            headerTable.isLockedWidth = true
            headerTable.totalWidth = PageSize.A4.width

            val emptyCell = PdfPCell(Phrase())
            emptyCell.border = Rectangle.NO_BORDER
            emptyCell.horizontalAlignment = Rectangle.ALIGN_CENTER
            emptyCell.paddingTop = 5f
            emptyCell.paddingBottom = 5f
            emptyCell.paddingLeft = 2f
            emptyCell.paddingRight = 2f
            headerTable.addCell(emptyCell)

            val d = resources.getDrawable(R.drawable.ic_icon)
            val bitDw = d as BitmapDrawable
//            val bmp = Bitmap.createScaledBitmap(bitDw.bitmap, 45, 45, false)
            val bmp = bitDw.bitmap
            val stream = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, stream)
            val image = Image.getInstance(stream.toByteArray())
            val cell = PdfPCell(Image.getInstance(image))

            cell.border = Rectangle.TOP + Rectangle.LEFT
            cell.borderWidth = 1f
            cell.borderColor = BaseColor(244,244,244)
            cell.paddingTop = 10f
            cell.paddingBottom = 10f
            cell.paddingLeft = 10f
            cell.horizontalAlignment = Rectangle.ALIGN_LEFT
            cell.verticalAlignment = Element.ALIGN_MIDDLE
            headerTable.addCell(cell)


            appFontSemiBold.color = BaseColor.BLACK
            val itemName = PdfPCell(Phrase("Backup Recovery", appFontSemiBold))
            itemName.colspan = 2
            itemName.border = Rectangle.TOP
            itemName.borderWidth = 1f
            itemName.paddingLeft = 25f
            itemName.paddingTop = 10f
            itemName.paddingBottom = 15f
            itemName.borderColor = BaseColor(244,244,244)
            itemName.horizontalAlignment = Element.ALIGN_LEFT
            itemName.verticalAlignment = Element.ALIGN_MIDDLE
            headerTable.addCell(itemName)

            appFontRegular.color = BaseColor.BLUE

            val d2 = resources.getDrawable(R.drawable.ic_playstore)
            val bitDw2 = d2 as BitmapDrawable
//            val bmp2 = Bitmap.createScaledBitmap(bitDw2.bitmap, 135, 40, false)
            val bmp2 = bitDw2.bitmap

            val stream2 = ByteArrayOutputStream()
            bmp2.compress(Bitmap.CompressFormat.PNG, 100, stream2)
            val image2 = Image.getInstance(stream2.toByteArray())

            val link = Anchor(Chunk(Image.getInstance(image2), -10f, -20f))
            link.reference = linkSample
            val linkCell = PdfPCell(link)
            linkCell.colspan = 2
            linkCell.paddingTop = 10f
            linkCell.paddingBottom = 10f
            linkCell.paddingRight = 10f
            linkCell.paddingLeft = 10f
            linkCell.border = Rectangle.TOP + Rectangle.RIGHT
            linkCell.borderWidth = 1f
            linkCell.borderColor = BaseColor(244,244,244)
            linkCell.horizontalAlignment = Element.ALIGN_RIGHT
            linkCell.verticalAlignment = Element.ALIGN_MIDDLE
            headerTable.addCell(linkCell)
            headerTable.addCell(emptyCell)
            doc.add(headerTable)

            appFontRegular.color = BaseColor.BLACK


            val footerTable = PdfPTable(numCols + 3)
            footerTable.totalWidth = PageSize.A4.width
            footerTable.isLockedWidth = true
            footerTable.setWidths(colWidth)

//            val emptyCell = PdfPCell(Phrase())
//            emptyCell.border = Rectangle.NO_BORDER
//            emptyCell.horizontalAlignment = Rectangle.ALIGN_RIGHT
//            emptyCell.paddingTop = TABLE_TOP_PADDING

            val headerCell = PdfPCell(Phrase("Contact Exported", appFontSemiBold))
            headerCell.colspan = numCols + 1
            headerCell.border = Rectangle.BOX
            headerCell.borderWidth = 1f
            headerCell.borderColor = BaseColor(244,244,244)
            headerCell.horizontalAlignment = Rectangle.ALIGN_CENTER
            headerCell.paddingTop = 5f
            headerCell.paddingBottom = 10f
            headerCell.paddingLeft = 2f
            headerCell.paddingRight = 2f

            footerTable.addCell(emptyCell)
            footerTable.addCell(headerCell)
            footerTable.addCell(emptyCell)

            var appFontNone = Font(basfontSemiBold, 8f)

            val headerBlank = PdfPCell(Phrase("", appFontNone))
            headerBlank.colspan = numCols + 1
            headerBlank.border = Rectangle.BOX
            headerBlank.borderWidth = 1f
            headerBlank.borderColor = BaseColor.WHITE
            headerBlank.horizontalAlignment = Rectangle.ALIGN_CENTER
            headerBlank.paddingTop = 5f
            headerBlank.paddingBottom = 5f
            headerBlank.paddingLeft = 2f
            headerBlank.paddingRight = 2f
            footerTable.addCell(emptyCell)
            footerTable.addCell(headerBlank)
            footerTable.addCell(emptyCell)

            footerTable.addCell(emptyCell)
            val indexCell = PdfPCell(Phrase("No.", appFontBold))
            indexCell.border = Rectangle.BOX
            indexCell.borderWidth = 1f
            indexCell.borderColor = BaseColor(244,244,244)
            indexCell.horizontalAlignment = Rectangle.ALIGN_CENTER
            indexCell.paddingTop = 8f
            indexCell.paddingBottom = 8f
            indexCell.paddingLeft = 2f
            indexCell.paddingRight = 2f
            indexCell.backgroundColor = BaseColor(244,244,244)
            footerTable.addCell(indexCell)

            if (isName) {
                val itemCell = PdfPCell(Phrase("Name", appFontBold))
                itemCell.border = Rectangle.BOX
                itemCell.borderWidth = 1f
                itemCell.borderColor = BaseColor(244,244,244)
                itemCell.horizontalAlignment = Rectangle.ALIGN_CENTER
                itemCell.verticalAlignment = Rectangle.ALIGN_MIDDLE
                itemCell.paddingTop = 8f
                itemCell.paddingBottom = 8f
                itemCell.paddingLeft = 2f
                itemCell.paddingRight = 2f
                itemCell.backgroundColor = BaseColor(244,244,244)
                footerTable.addCell(itemCell)
            }
            if (isNumber) {
                val cellNumber = PdfPCell(Phrase("Number", appFontBold))
                cellNumber.border = Rectangle.BOX
                cellNumber.borderWidth = 1f
                cellNumber.borderColor = BaseColor(244,244,244)
                cellNumber.horizontalAlignment = Rectangle.ALIGN_CENTER
                cellNumber.verticalAlignment = Rectangle.ALIGN_MIDDLE
                cellNumber.paddingTop = 8f
                cellNumber.paddingBottom = 8f
                cellNumber.paddingLeft = 2f
                cellNumber.paddingRight = 2f
                cellNumber.backgroundColor = BaseColor(244,244,244)
                footerTable.addCell(cellNumber)
            }
            if (isEmail) {
                val cellEmail = PdfPCell(Phrase("Email", appFontBold))
                cellEmail.border = Rectangle.BOX
                cellEmail.borderWidth = 1f
                cellEmail.borderColor = BaseColor(244,244,244)
                cellEmail.horizontalAlignment = Rectangle.ALIGN_CENTER
                cellEmail.verticalAlignment = Rectangle.ALIGN_MIDDLE
                cellEmail.paddingTop = 8f
                cellEmail.paddingBottom = 8f
                cellEmail.paddingLeft = 2f
                cellEmail.paddingRight = 2f
                cellEmail.backgroundColor = BaseColor(244,244,244)
                footerTable.addCell(cellEmail)
            }
            if (isDob) {
                val cellDob = PdfPCell(Phrase("Birthday", appFontBold))
                cellDob.border = Rectangle.BOX
                cellDob.borderWidth = 1f
                cellDob.borderColor = BaseColor(244,244,244)
                cellDob.horizontalAlignment = Rectangle.ALIGN_CENTER
                cellDob.verticalAlignment = Rectangle.ALIGN_MIDDLE
                cellDob.paddingTop = 8f
                cellDob.paddingBottom = 8f
                cellDob.paddingLeft = 2f
                cellDob.paddingRight = 2f
                cellDob.backgroundColor = BaseColor(244,244,244)
                footerTable.addCell(cellDob)
            }
            footerTable.addCell(emptyCell)
            doc.add(footerTable)


//            var i=0
//            for (a in dataList) {
//                publishProgress((i++).toString())
//            }

            val itemsTable = PdfPTable(numCols + 3)
            itemsTable.isLockedWidth = true
            itemsTable.totalWidth = PageSize.A4.width
            itemsTable.setWidths(colWidth)

            appFontRegular.color = BaseColor.BLACK
            appFontRegular.size = FONT_SIZE_DEFAULT
            appFontSemiBold.color = colorPrimary

//            val emptyCell = PdfPCell(Phrase())
//            emptyCell.border = Rectangle.NO_BORDER
//            emptyCell.horizontalAlignment = Rectangle.ALIGN_RIGHT
//            emptyCell.paddingTop = 5f
//            emptyCell.paddingBottom = 5f
//            emptyCell.paddingLeft = 2f
//            emptyCell.paddingRight = 2f


            var index = 0
            for (item in dataList) {
                index++
                publishProgress((index).toString())

                val contactName = if (item.mContactName != null) item.mContactName else "--"
                val contactNumber = if (item.mNumber != null) item.mNumber else "--"
                val contactEmail = if (item.mEmail != null) item.mEmail else "--"
                val contactBirthday = if (item.mDOB != null) item.mDOB else "--"
                itemsTable.deleteBodyRows()

                itemsTable.addCell(emptyCell)

                val cellIndex = PdfPCell(Phrase(index.toString(), appFontRegular))
                cellIndex.border = Rectangle.BOX
                cellIndex.borderWidth = 1f
                cellIndex.borderColor = BaseColor(244,244,244)
                cellIndex.horizontalAlignment = Rectangle.ALIGN_CENTER
                cellIndex.verticalAlignment = Rectangle.ALIGN_MIDDLE
                cellIndex.paddingTop = 5f
                cellIndex.paddingBottom = 5f
                cellIndex.paddingLeft = 2f
                cellIndex.paddingRight = 2f
                itemsTable.addCell(cellIndex)

                if (isName) {
                    val cellName = PdfPCell(Phrase(contactName.toString(), appFontRegular))
                    cellName.border = Rectangle.BOX
                    cellName.borderWidth = 1f
                    cellName.borderColor = BaseColor(244,244,244)
                    cellName.horizontalAlignment = if (contactName.equals("--")) Rectangle.ALIGN_CENTER else Rectangle.ALIGN_LEFT
                    cellName.verticalAlignment = Rectangle.ALIGN_MIDDLE
                    cellName.paddingTop = 5f
                    cellName.paddingBottom = 5f
                    cellName.paddingLeft = 2f
                    cellName.paddingRight = 2f
//                    if(numCols!=1 && !contactName.equals("--"))
                        itemsTable.addCell(cellName)
                }

                if (isNumber) {
                    val cellNumber = PdfPCell(Phrase(contactNumber.toString(), appFontRegular))
                    cellNumber.border = Rectangle.BOX
                    cellNumber.borderWidth = 1f
                    cellNumber.borderColor = BaseColor(244,244,244)
                    cellNumber.horizontalAlignment =
                        if (contactNumber.equals("--")) Rectangle.ALIGN_CENTER else Rectangle.ALIGN_LEFT
                    cellNumber.verticalAlignment = Rectangle.ALIGN_MIDDLE
                    cellNumber.paddingTop = 5f
                    cellNumber.paddingTop = 5f
                    cellNumber.paddingLeft = 2f
                    cellNumber.paddingRight = 2f
//                    if(numCols!=1 && !contactNumber.equals("--"))
                        itemsTable.addCell(cellNumber)
                }


                if (isEmail) {
                    val cellMail = PdfPCell(Phrase(contactEmail, appFontRegular))
                    cellMail.border = Rectangle.BOX
                    cellMail.borderWidth = 1f
                    cellMail.borderColor = BaseColor(244,244,244)
                    cellMail.horizontalAlignment =
                        if (contactEmail.equals("--")) Rectangle.ALIGN_CENTER else Rectangle.ALIGN_LEFT
                    cellMail.verticalAlignment = Rectangle.ALIGN_MIDDLE
                    cellMail.paddingTop = 5f
                    cellMail.paddingBottom = 5f
                    cellMail.paddingLeft = 2f
                    cellMail.paddingRight = 2f
//                    if(numCols!=1 && !contactEmail.equals("--"))
                        itemsTable.addCell(cellMail)
                }


                if (isDob) {
                    val cellDob = PdfPCell(Phrase(contactBirthday.toString(), appFontRegular))
                    cellDob.border = Rectangle.BOX
                    cellDob.borderWidth = 1f
                    cellDob.borderColor = BaseColor(244,244,244)
                    cellDob.horizontalAlignment =
                        if (contactBirthday.equals("--")) Rectangle.ALIGN_CENTER else Rectangle.ALIGN_LEFT
                    cellDob.verticalAlignment = Rectangle.ALIGN_MIDDLE
                    cellDob.paddingTop = 5f
                    cellDob.paddingBottom = 5f
                    cellDob.paddingLeft = 2f
                    cellDob.paddingRight = 2f
//                    if(numCols!=1 && !contactBirthday.equals("--"))
                        itemsTable.addCell(cellDob)
                }

                itemsTable.addCell(emptyCell)
                doc.add(itemsTable)
            }
            doc.close()
            return null
        }

        fun getSize(vararg arr: Boolean): Int {
            var count = 0
            for (ar in arr) {
                if (ar) count++
            }
            return count
        }

        fun getValue(str: String?): String {
            if (str.isNullOrEmpty() && str.equals("null")) {
                return ""
            } else return str + ""
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)

            Handler(Looper.getMainLooper()).postDelayed(Runnable {
                try {
                    val intent = Intent(this@ConfigureContactActivity, ShareActivity::class.java)
                    intent.putExtra("file_path", filePath.path)
                    intent.putExtra("file_type", 1)
                    startActivity(intent)
                    if (progressDialog != null && progressDialog?.isShowing!!) {
                        progressDialog?.cancel()
                        MyApplication.isDialogOpen = false
                    }
                    (this@ConfigureContactActivity).finish()
                } catch (e: Exception) {
//                    addEvent(e.message!!)
                }
            }, 200)
        }
    }

    private inner class ExportTOExcel(
        val dataList: List<ContactModel>,
        val isName: Boolean,
        val isNumber: Boolean,
        val isEmail: Boolean,
        val isDob: Boolean
    ) :
        AsyncTask<Void?, String?, Void?>() {
        val dialog = Dialog(mContext)

        var permission_text: TextView? = null
        var filePath: String = ""


        override fun onPreExecute() {
            super.onPreExecute()
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            dialog.findViewById<TextView>(R.id.permission).text =
                getString(R.string.label_please_wait)
            permission_text = dialog.findViewById<TextView>(R.id.permission_text)
            dialog.findViewById<TextView>(R.id.dialogButtonCancel).visibility = GONE

            if (!dialog.isShowing) {
                dialog.show()
            }

        }

        override fun onProgressUpdate(vararg values: String?) {
            super.onProgressUpdate(*values)
            val parseInt = values[0]?.toInt()
//            permission_text?.setMax(100)
//            val value = parseInt / dataList.size
            runOnUiThread {
                permission_text?.text = "$parseInt / ${dataList.size}"
            }
        }

        override fun doInBackground(vararg voids: Void?): Void? {

//            runOnUiThread {}

            return null
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
//            Handler(Looper.getMainLooper()).post {
//
//                Toast.makeText(mContext, "Pdf saved successfully to location $filePath", Toast.LENGTH_LONG).show()
//            }

            Handler(Looper.getMainLooper()).postDelayed(Runnable {
                try {
                    if (dialog != null && dialog.isShowing) {
                        dialog.cancel()
                        MyApplication.isDialogOpen = false
                    }
                } catch (e: Exception) {
//                    addEvent(e.message!!)
                }
            }, 200)
        }
    }

}