package com.backup.restore.device.image.recovery.mainapps.activity

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.ViewPager
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.ads.rateandfeedback.*
import com.backup.restore.device.image.recovery.main.NewHomeActivity
import com.backup.restore.device.image.recovery.mainapps.fragment.*
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.MyUtils
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import kotlinx.android.synthetic.main.activity_app_manager.*
import kotlinx.coroutines.*
import java.util.*


class AppManagerActivity : MyCommonBaseActivity(), View.OnClickListener {

    var mViewPager: ViewPager? = null
    var lViewPagerAdapter: ViewPagerAdapter? = null
    var fragmentUserApps: AppsFragment? = null
    var fragmentSystemApps: AppsFragment? = null
    var isFrom = ""

    var isFromOneSignal = false
    var mIsCheckType: String? = null

    companion object {
        var actionToInterstitialAd = false
        var needInterstitialAd = false
//        lateinit var selectedPackage: MutableList<String>
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_manager)
        addEvent(AppManagerActivity::class.simpleName!!)
//        selectedPackage = ArrayList()
    }

    class ViewPagerAdapter(manager: FragmentManager?) : FragmentPagerAdapter(manager!!) {

        private val mFragmentList: MutableList<Fragment> = ArrayList()
        private val mFragmentTitleList: MutableList<String> = ArrayList()

        override fun getItem(position: Int): Fragment {
            return mFragmentList[position]
        }

        override fun getCount(): Int {
            return mFragmentList.size
        }

        fun addFrag(fragment: Fragment, title: String) {
            mFragmentList.add(fragment)
            mFragmentTitleList.add(title)
        }

        override fun getPageTitle(position: Int): CharSequence {
            return mFragmentTitleList[position]
        }
    }

    override fun getContext(): AppCompatActivity {
        return this@AppManagerActivity
    }

    override fun initData() {
        if (intent.hasExtra("IsCheckType")) {
            mIsCheckType = intent.extras!!.getString("IsCheckType")
        }
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }

        mViewPager = findViewById(R.id.viewpager)
        fragmentUserApps = AppsFragment.newInstance("user")
        fragmentSystemApps = AppsFragment.newInstance("system")

        mViewPager?.offscreenPageLimit = 2
        setupViewPager(mViewPager!!)

        if (AdsManager(mContext).isNeedToShowAds()) {
            InterstitialAdHelper.loadInterstitialAd(fContext = mContext)
        }
    }

    private fun setupViewPager(viewPager: ViewPager) {
        lViewPagerAdapter = ViewPagerAdapter(supportFragmentManager)
        lViewPagerAdapter!!.addFrag(fragmentUserApps!!, "UserApps")
        lViewPagerAdapter!!.addFrag(fragmentSystemApps!!, "SystemApps")
        viewPager.adapter = lViewPagerAdapter
        viewPager.offscreenPageLimit = 2
        initViewActions(0)

        viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
            }

            override fun onPageSelected(position: Int) {
                Log.e("mTAG", "onPageSelected: $position")
                if (position == 0) {
                    isFrom = "UserApps"
                } else {
                    isFrom = "SystemApps"
                }
                val fragment = lViewPagerAdapter?.getItem(position)
                if (fragment is AppsFragment) {
                    fragment.deSelectAll()
                    fragment.filter("")
                }
                initViewActions(position)
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })

        if(mIsCheckType=="UserApps") {
            viewPager.currentItem=0
        } else if(mIsCheckType=="SystemApps") {
            viewPager.currentItem=1
        }
    }

    private fun initViewActions(position: Int) {
        et_search.setText("")
        if (position == 0) {
            view_user_active.visibility = View.VISIBLE
            view_system_active.visibility = View.GONE
        } else if (position == 1) {
            view_user_active.visibility = View.GONE
            view_system_active.visibility = View.VISIBLE
        }

    }

    override fun initActions() {
        viewUser.setOnClickListener(this)
        viewSystem.setOnClickListener(this)
        iv_back.setOnClickListener(this)
        iv_history.setOnClickListener(this)
        var strBefore = ""
        et_search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                Log.e("AppsFragment", "beforeTextChanged: ${s.toString()}")
                strBefore = s.toString().trim()
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (et_search!!.text.toString().trim().isEmpty()) {
                    et_search!!.clearFocus()
                    MyUtils.hideKeyboard(mContext, et_search)
                } else {
                    et_search!!.requestFocus()
                }
            }

            override fun afterTextChanged(s: Editable?) {
                Log.e("AppsFragment", "afterTextChanged: ${s.toString()}")
                if (strBefore.isEmpty() && s.toString().trim().isEmpty()) return

                if (mViewPager?.currentItem == 0) {
                    fragmentUserApps?.filter(s.toString().trim().lowercase(Locale.getDefault()))
                } else {
                    fragmentSystemApps?.filter(s.toString().trim().lowercase(Locale.getDefault()))
                }
            }
        })
    }

    override fun onBackPressed() {
        Log.e("InterstitialAd", "needInterstitialAd $needInterstitialAd")
        Log.e("InterstitialAd", "actionToInterstitialAd $actionToInterstitialAd")

        if (needInterstitialAd || actionToInterstitialAd) {
            SharedPrefsConstant.save(this@AppManagerActivity, ShareConstants.RATE_UNINSTALLER, SharedPrefsConstant.getInt(this@AppManagerActivity, ShareConstants.RATE_UNINSTALLER) + 1)
            needInterstitialAd = false
            actionToInterstitialAd = false
            MyApplication.isInterstitialShown = true

            if (AdsManager(mContext).isNeedToShowAds()) {
                if (!SharedPrefsConstant.getBoolean(mContext, SharedPrefsConstant.IS_APP_IN_BACKGROUND, true)) {

                    mContext.isShowInterstitialAd { isShowFullScreenAd ->
                        Log.e(mTAG, "onClick: isShowFullScreenAd::$isShowFullScreenAd")
                        MyApplication.isInterstitialShown = false
                        if (isFromOneSignal) {
                            startActivity(NewHomeActivity.newIntent(this))
                            finish()
                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                        } else {
                            super.onBackPressed()
                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                        }
                    }
                } else {
                    Log.e("InterstitialAd", "else $002")
                    if (isFromOneSignal) {
                        startActivity(NewHomeActivity.newIntent(this))
                        finish()
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    } else {
                        super.onBackPressed()
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    }
                }
            } else {
                Log.e("InterstitialAd", "else $001")
                super.onBackPressed()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
        } else {
            SharedPrefsConstant.save(this@AppManagerActivity, ShareConstants.RATE_UNINSTALLER, SharedPrefsConstant.getInt(this@AppManagerActivity, ShareConstants.RATE_UNINSTALLER) + 1)
            Log.e("InterstitialAd", "else $000")
            if (isFromOneSignal) {
                startActivity(NewHomeActivity.newIntent(this))
                finish()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            } else {
                super.onBackPressed()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
        }
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.viewUser -> {
                initViewActions(0)
                mViewPager?.currentItem = 0
                fragmentUserApps?.filter("")
            }
            R.id.viewSystem -> {
                initViewActions(1)
                mViewPager?.currentItem = 1
                fragmentSystemApps?.filter("")
            }
            R.id.iv_back -> onBackPressed()
            R.id.iv_history -> {
                val intent = Intent(mContext, AppHistoryActivity::class.java)
                startActivity(intent)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.e("onActivityResult", "activity-requestCode: $requestCode")
        Log.e("onActivityResult", "activity-resultCode: $resultCode")
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
//            mContext.loadOfflineNativeAdvanceLarge(findViewById(R.id.ad_view_container))
//        } else {
//            findViewById<FrameLayout>(R.id.ad_view_container).visibility = View.GONE
//        }
    }

}