package com.backup.restore.device.image.recovery.mainapps.activity

import android.Manifest
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.os.storage.StorageManager
import android.os.storage.StorageVolume
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.EnvironmentCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.database.DBAdapter
import com.backup.restore.device.image.recovery.filepicker.model.DialogConfigs
import com.backup.restore.device.image.recovery.filepicker.model.DialogProperties
import com.backup.restore.device.image.recovery.filepicker.view.FilePickerDialog
import com.backup.restore.device.image.recovery.mainapps.adapter.IgnoredAdapter
import com.backup.restore.device.image.recovery.mainapps.fragment.*
import com.backup.restore.device.image.recovery.mainapps.model.Utils
import com.backup.restore.device.image.recovery.mainduplicate.model.IgnorePath
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant.*
import com.example.app.ads.helper.GiftIconHelper
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlinx.android.synthetic.main.activity_ignore_list.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.util.*


class IgnoreListActivity : MyCommonBaseActivity() {

    private lateinit var pathList: MutableList<IgnorePath>
    private var mDbHelper: DBAdapter? = null
    private var recyclerViewLayoutManager: RecyclerView.LayoutManager? = null
    private var onPathSelect: IgnoredAdapter.OnPathSelect? = null
    private var adapter: IgnoredAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ignore_list)
        addEvent(IgnoreListActivity::class.simpleName!!)

    }

    override fun getContext(): AppCompatActivity {
        return this@IgnoreListActivity
    }

    override fun initData() {
        mDbHelper = DBAdapter(mContext)
        recyclerViewLayoutManager = GridLayoutManager(mContext, 1)

        onPathSelect = object : IgnoredAdapter.OnPathSelect{
            override fun onPathClick(position: Int, appInfo: IgnorePath) {
                delete(appInfo)
            }
        }
        pathList = ArrayList()
        getList(mContext)

        if (AdsManager(mContext).isNeedToShowAds()) {
            if (NetworkManager.isInternetConnected(mContext)) {
                GiftIconHelper.loadGiftAd(
                    fContext = mContext,
                    fivGiftIcon = findViewById(R.id.main_la_gift),
                    fivBlastIcon = findViewById(R.id.main_la_gift_blast)
                )
            }
        }
    }

    override fun initActions() {
        iv_back.setOnClickListener(this)
        btn_add_folder.setOnClickListener(this)

    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.iv_back -> {
                onBackPressed()
            }
            R.id.btn_add_folder -> {
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1500) {
                    return
                }
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    checkPermissions(
                        arrayOf(
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        )
                    )
                }
            }
        }
    }

    private fun delete(appInfo: IgnorePath) {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

//        dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(resources.getDrawable(R.drawable.ic_dialog_delete))
        dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.confirm_delete)
        dialog.findViewById<TextView>(R.id.permission_text).setText(R.string.sure_to_delete_path)
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            mDbHelper?.deleteIgnorePath(appInfo.pathId.toString())

            getList(mContext)

        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }
        dialog.show()
        MyApplication.isDialogOpen = true
        MyApplication.isInternalCall = true
    }


    private fun getList(context: Context) {
        GlobalScope.launch(Dispatchers.Default) {

            try {
                pathList.clear()

                val pathListAlternate = mDbHelper?.ignoredPath!!

                adapter = IgnoredAdapter(context, pathList, onPathSelect!!)

                withContext(Dispatchers.Main) {

                    rv_paths.layoutManager = recyclerViewLayoutManager
                    rv_paths.adapter = adapter

                    updateAppList(pathListAlternate)

                }
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        }
    }
    private fun updateAppList(newAppList : MutableList<IgnorePath>) {
        if(newAppList.size>0) {
            pathList.clear()
            pathList.addAll(newAppList)
            adapter?.notifyDataSetChanged()

            ll_empty.visibility = View.GONE
//            iv_deleteAll.visibility = View.VISIBLE
            rv_paths.visibility = View.VISIBLE
        } else {
            ll_empty.visibility = View.VISIBLE
//            iv_deleteAll.visibility = View.GONE
            rv_paths.visibility = View.GONE
        }

    }

    private fun dialogDetailExtension(title:String,extensionArray: Array<String>) {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_more_extension)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val tv_title = dialog.findViewById<TextView>(R.id.tv_title)
        val tv_detail_text = dialog.findViewById<TextView>(R.id.tv_detail_text)

        tv_title.text = title
        tv_detail_text.text = extensionArray.joinToString(
            transform = { "\""+it+"\"" }
        )

        dialog.findViewById<View>(R.id.dialogButtonOk).setOnClickListener {
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun checkPermissions(permissions: Array<String>) {

        MyApplication.isInternalCall = true

        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                dialogSelectLocation()
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            Toast.makeText(
                                mContext,
                                getString(R.string.permission_required),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest>,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            }).check()


    }

    fun showSettingsDialog() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            openSettings()
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun openSettings() {
        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        startActivity(intent)
//        dialogSelectLocation()
    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                dialogSelectLocation()
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                try {
                    MyApplication.isInternalCall = true
                    startActivityForResult(intent, 2296)
                } catch (e: ActivityNotFoundException) {
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 4010) {
            val uri: Uri? = data?.data
            grantUriPermission(
                packageName,
                uri,
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            val takeFlags = data?.flags?.and(
                (Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                        Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                takeFlags?.let { contentResolver.takePersistableUriPermission(uri!!, it) }
            }
        } else if (requestCode == 2296) {
            dialogSelectLocation()
        }
    }

    private fun takeCardUriPermission(sdCardRootPath: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val sdCard = File(sdCardRootPath)
            val storageManager: StorageManager =
                getSystemService(Context.STORAGE_SERVICE) as StorageManager
            val storageVolume: StorageVolume? = storageManager.getStorageVolume(sdCard)
            val intent: Intent? = storageVolume?.createAccessIntent(null)
            try {
                startActivityForResult(intent, 4010)
            } catch (e: ActivityNotFoundException) {
            }
        }
    }

    private fun getExternalStorageDirectories(): Array<String?> {
        val results: MutableList<String> = ArrayList()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            //Method 1 for KitKat & above
            val externalDirs = getExternalFilesDirs(null)
            val internalRoot = Environment.getExternalStorageDirectory().absolutePath.toLowerCase()
            for (file in externalDirs) {
                if (file == null) //solved NPE on some Lollipop devices
                    continue
                val path = file.path.split("/Android".toRegex()).toTypedArray()[0]
                if (path.toLowerCase().startsWith(internalRoot)) continue
                var addPath = false
                addPath = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    Environment.isExternalStorageRemovable(file)
                } else {
                    Environment.MEDIA_MOUNTED == EnvironmentCompat.getStorageState(file)
                }
                if (addPath) {
                    results.add(path)
                }
            }
        }
        if (results.isEmpty()) {
            //Method 2 for all versions
            // better variation of: http://stackoverflow.com/a/40123073/5002496
            var output = ""
            try {
                val process = ProcessBuilder().command("mount | grep /dev/block/vold")
                    .redirectErrorStream(true).start()
                process.waitFor()
                val `is`: InputStream = process.inputStream
                val buffer = ByteArray(1024)
                while (`is`.read(buffer) !== -1) {
                    output = output + String(buffer)
                }
                `is`.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (output.trim { it <= ' ' }.isNotEmpty()) {
                val devicePoints = output.split("\n".toRegex()).toTypedArray()
                for (voldPoint in devicePoints) {
                    results.add(voldPoint.split(" ".toRegex()).toTypedArray()[2])
                }
            }
        }

        //Below few lines is to remove paths which may not be external memory card, like OTG (feel free to comment them out)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            var i = 0
            while (i < results.size) {
                if (!results[i].toLowerCase().matches(".*[0-9a-f]{4}[-][0-9a-f]{4}".toRegex())) {
//                    Log.d(ImageViewTouchBase.LOG_TAG, results[i] + " might not be extSDcard")
                    results.removeAt(i--)
                }
                i++
            }
        } else {
            var i = 0
            while (i < results.size) {
                if (!results[i].toLowerCase().contains("ext") && !results[i].toLowerCase()
                        .contains("sdcard")
                ) {
//                    Log.d(ImageViewTouchBase.LOG_TAG, results[i] + " might not be extSDcard")
                    results.removeAt(i--)
                }
                i++
            }
        }
        val storageDirectories = arrayOfNulls<String>(results.size)
        for (i in results.indices) storageDirectories[i] = results[i]
        return storageDirectories
    }

    private fun dialogScanLocation() {
        addEvent("ScanType")
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_scan_type)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val rbInternal = dialog.findViewById<RadioButton>(R.id.rb_internal)
        val rbExternal = dialog.findViewById<RadioButton>(R.id.rb_external)
        val rbCustom = dialog.findViewById<RadioButton>(R.id.rb_custom)
//        var selectedRb = "internal"

        if (Utils.getExternalMounts().size > 0) {
            rbExternal.visibility = View.VISIBLE
        } else {
            rbExternal.visibility = View.GONE
        }

        val scanType = SharedPrefsConstant.getInt(this, "scanTypeLabel", R.string.internal)
        var selectedRb = SharedPrefsConstant.getString(this, "scanType", "internal")
        Log.e("scanTypeRb", "dialogScan: $selectedRb")

        if (selectedRb.equals("internal", true)) {
            selectedRb = "internal"
            rbInternal.isChecked = true
            rbExternal.isChecked = false
            rbCustom.isChecked = false
        } else if (selectedRb.equals("external", true)) {
            selectedRb = "external"
            rbInternal.isChecked = false
            rbExternal.isChecked = true
            rbCustom.isChecked = false
        } else if (selectedRb.equals("custom", true)) {
            selectedRb = "custom"
            rbInternal.isChecked = false
            rbExternal.isChecked = false
            rbCustom.isChecked = true
        }

        rbInternal.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                selectedRb = "internal"
                //rb_internal.isChecked=false
                rbExternal.isChecked = false
                rbCustom.isChecked = false
            }
        }
        rbExternal.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                selectedRb = "external"
                rbInternal.isChecked = false
                //rb_external.isChecked=false
                rbCustom.isChecked = false
            }
        }
        rbCustom.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                //selectedRb="custom"
                rbInternal.isChecked = false
                rbExternal.isChecked = false
                //rb_custom.isChecked=false
            }
        }

        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
            dialog.dismiss()
        }
        dialog.findViewById<View>(R.id.dialogButtonok).setOnClickListener {

            dialog.dismiss()

        }
        dialog.show()
    }


    private fun dialogSelectLocation() {

        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
        val dialogProperties = DialogProperties()
        dialogProperties.selection_type = DialogConfigs.FILE_AND_DIR_SELECT
        dialogProperties.selection_mode = DialogConfigs.SINGLE_MODE
        dialogProperties.show_hidden_files = true
        dialogProperties.root = File(DialogConfigs.DEFAULT_DIR)
        dialogProperties.offset = File(DialogConfigs.DEFAULT_DIR)
        dialogProperties.root = File(ShareConstants.mRootPath)
//        dialogProperties.extensions = SharedPrefsConstant.OtherArray

        val pickerDialog = FilePickerDialog(this@IgnoreListActivity, dialogProperties)
        pickerDialog.setTitle(getString(R.string.select_a_file))
        pickerDialog.setPositiveBtnName(getString(R.string.filechooser_ok))

        //Method handle selected files.
        pickerDialog.setDialogSelectionListener { files ->
            //files is the array of paths selected by the App User.
            if (files.isNotEmpty()) {
                for (path in files) {
                    val file = File(path)
                    Log.e("ScanLocation", "dialogScanLocation:custom: " + file.absolutePath)
                    if(isUnique(pathList,file.absolutePath)) {
                        mDbHelper?.saveIgnorePath(file.name,file.absolutePath)
                    } else {
                        Toast.makeText(mContext,getString(R.string.path_already_exist),Toast.LENGTH_SHORT).show()
                    }
                }
            }

            Handler(Looper.getMainLooper()).postDelayed({
                getList(mContext)
            },1000)

        }
        pickerDialog.properties = dialogProperties

        pickerDialog.show()
    }


    private fun isUnique(pathList: MutableList<IgnorePath>, currentPath: String): Boolean {
        var needToAdd = true
        for (path in pathList) {
            if (currentPath==(path.path)) {
                needToAdd = false
                return needToAdd
            }
        }
        return needToAdd
    }


    override fun onResume() {
        super.onResume()
        changeLanguage()
    }
}