package com.backup.restore.device.image.recovery.mainphotos.deepfragment

import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainphotos.activity.DeepScanActivity
import com.backup.restore.device.image.recovery.mainphotos.activity.ViewVideoListActivity
import com.backup.restore.device.image.recovery.mainphotos.callbacks.AlbumClickListener
import com.backup.restore.device.image.recovery.mainphotos.model.TrashModel
import com.backup.restore.device.image.recovery.mainphotos.recoverableadapter.AlbumItemAdapter
import com.backup.restore.device.image.recovery.retriever.Album
import com.backup.restore.device.image.recovery.retriever.MediaStoreRetriever
import com.backup.restore.device.image.recovery.retriever.Retriever
import com.backup.restore.device.image.recovery.utilities.OnFolderLoaded
import com.backup.restore.device.image.recovery.utilities.SPAN_COUNT_THREE
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.getGridCount
import kotlinx.android.synthetic.main.activity_deep_scan.*
import kotlinx.android.synthetic.main.fragment_ds_image_video.*
import java.util.*
import kotlin.collections.ArrayList

class DSVideoFragment : Fragment(), View.OnClickListener {

    val mTAG: String = javaClass.simpleName
    lateinit var mView: View
    var selectedList = ArrayList<TrashModel>()
    var isVisibleHint: Boolean = false

        var isAsyncRunning: Boolean = false
    var isForSort = "date_asc"
    var isDateClick = false
    var isSizeClick = false

    var mGetRecoverableAlbum: AsyncTask<*, *, *>? = null
//    var mHiddenPictureFolderAdapter: RecoverableFolderAdapter? = null
//    var mRecoverableFolderList = ArrayList<RecoverableFolderModel>()
//    var mFolderList = ArrayList<RecoverableFolderModel>()

    var mHiddenPictureFolderAdapter: AlbumItemAdapter? = null
    var mRecoverableFolderList = ArrayList<Album>()


    companion object {
        fun newInstance(): DSVideoFragment {
            return DSVideoFragment()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (mGetRecoverableAlbum != null) {
            if (mGetRecoverableAlbum?.status == AsyncTask.Status.RUNNING) {
                mGetRecoverableAlbum?.cancel(true)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        if (isAdded) {
            isVisibleHint = isVisibleToUser
//            Log.e(mTAG, "setUserVisibleHint: same $isVisibleToUser")

            if (isVisibleToUser) {
                object : AsyncTask<Void, Long, Void>() {
                    override fun doInBackground(vararg voids: Void): Void? {
//                        Log.e(mTAG, "doInBackground: stopLoading")
                        if(!isAsyncRunning) stopLoading()
                        return null
                    }

                    override fun onPostExecute(result: Void?) {
                        super.onPostExecute(result)
                    }
                }.execute()

                Log.e(mTAG, "setUserVisibleHint:getGridCount " + requireContext().getGridCount())
                (requireActivity() as DeepScanActivity).iv_span!!.isSelected =
                    requireContext().getGridCount() == SPAN_COUNT_THREE
//                if((scan_recoverable_album!!.layoutManager as GridLayoutManager).spanCount !=(requireActivity() as DeepScanActivity).getGridCount() ) {
                scan_recoverable_album!!.layoutManager = GridLayoutManager(
                    (requireActivity() as DeepScanActivity),
                    (requireActivity() as DeepScanActivity).getGridCount()
                )
//                }
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        mView = inflater.inflate(R.layout.fragment_ds_image_video, container, false)
        return mView
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        getAppList()
    }

    private fun getAppList() {
//        iv_not_found.setImageResource(R.drawable.ic_backup_not_found_video)
        tv_not_found.setText(R.string.video_not_found)

        scan_recoverable_album!!.layoutManager = GridLayoutManager(
            (requireActivity() as DeepScanActivity),
            (requireActivity() as DeepScanActivity).getGridCount()
        )
        scan_recoverable_album!!.setHasFixedSize(true)

        mHiddenPictureFolderAdapter = AlbumItemAdapter(mRecoverableFolderList,
            (requireActivity() as DeepScanActivity),
            "video",
            object : AlbumClickListener {
                override fun onPicClicked(
                    pictureFolderPath: Album?,
                    folderName: String?
                ) {
                    val move = Intent(
                        (requireActivity() as DeepScanActivity),
                        ViewVideoListActivity::class.java
                    )
                    ViewVideoListActivity.moImageLists.clear()
                    ViewVideoListActivity.moImageLists.addAll(pictureFolderPath?.albumItems!!)
                    Collections.sort(
                        ViewVideoListActivity.moImageLists,
                        ShareConstants.dateComparatorAlbumItem()
                    )

                    move.putExtra("folderPath", pictureFolderPath.path)
                    move.putExtra("folderName", folderName)
                    startActivity(move)
                }

            })

//        val albumListener = object : AlbumListener {
//            override fun onFolderLoaded(albumList: MutableList<Album>) {
//                Handler(Looper.getMainLooper()).post {
//                    mRecoverableFolderList.addAll(albumList)
//                    if ((requireActivity() as DeepScanActivity) != null && isAdded) {
//                        lottie_recoverable_image.visibility = View.GONE
//                    }
//
//                    if (!isAsyncRunning) stopLoading()
//                }
//
//            }
//        }

        scan_recoverable_album.adapter = mHiddenPictureFolderAdapter
        scan_recoverable_album.setItemViewCacheSize(500)

        unSelectAll(1)
        isAsyncRunning=true
        val retriever: Retriever = MediaStoreRetriever()
        retriever.loadAlbums(activity, false, MediaStoreRetriever.TYPE_VIDEO, object :
            OnFolderLoaded {
            override fun onFolderLoaded(albumList: MutableList<Album>) {
                Log.e(mTAG, "OnFolderLoaded:albumList: " + albumList.size)
//                for (album:Album in albumList) {
//                    mRecoverableFolderList.add(album)
//                    Thread.sleep(100)
//                    activity?.runOnUiThread {
//                        mHiddenPictureFolderAdapter?.notifyDataSetChanged()
//                    }
//                }

                isAsyncRunning=false
                activity?.runOnUiThread {
                    mRecoverableFolderList.clear()
                    mRecoverableFolderList.addAll(albumList)
                    Collections.sort(
                        mRecoverableFolderList,
                        ShareConstants.AlbumDateAscending()
                    )
                    if (isVisibleHint) selectTop(1);
                    mHiddenPictureFolderAdapter?.notifyDataSetChanged()
                    stopLoading()
                }
//                            mRecoverableFolderList.addAll(albumList)
//                            stopLoading()
            }

            override fun onSingleFolder(album: Album) {
                Log.e(mTAG, "onSingleFolder:albumList: " + album.name)
                activity?.runOnUiThread {
                    mRecoverableFolderList.add(album)
                    mHiddenPictureFolderAdapter?.notifyDataSetChanged()
                }
            }

            override fun timeout() {
                Log.e(mTAG, "OnFolderLoaded:timeout ")
            }
        })

//        mGetRecoverableAlbum = GetRecoverableAlbum(albumListener).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
//        mGetRecoverableAlbum = GetRecoverableAlbum().execute()


        llDateWise.setOnClickListener {
            if (mHiddenPictureFolderAdapter != null) {
                if (mRecoverableFolderList != null && mRecoverableFolderList.isNotEmpty()) {
                    selectAllDate()
                    if (isDateClick) {
                        Collections.sort(
                            mRecoverableFolderList,
                            ShareConstants.AlbumDateAscending()
                        )
                        isForSort = "date_asc"
                        isDateClick = false
                        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
                    } else {
                        Collections.sort(
                            mRecoverableFolderList,
                            ShareConstants.AlbumDateDescending()
                        )
                        isForSort = "date_desc"
                        isDateClick = true
                        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
                    }
                    isSizeClick = true
                    mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
                }
            }
        }

        llSizeWise.setOnClickListener {
            if (mHiddenPictureFolderAdapter != null) {
                if (mRecoverableFolderList != null && mRecoverableFolderList.isNotEmpty()) {
                    if (isSizeClick) {
                        Collections.sort(
                            mRecoverableFolderList,
                            ShareConstants.AlbumSizeAscending()
                        )
                        isForSort = "size_asc"
                        isSizeClick = false
                        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
                    } else {
                        Collections.sort(
                            mRecoverableFolderList,
                            ShareConstants.AlbumSizeDescending()
                        )
                        isForSort = "size_desc"
                        isSizeClick = true
                        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
                    }
                    isDateClick = true
                    mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
                    selectAllSize()
                }
            }
        }


    }

    fun selectTop(frag: Int) {
//        Log.e(mTAG, "selectTop: prevPos -> $prevPos")
        Log.e(mTAG, "selectTop: frag -> $frag")
        Log.e(mTAG, "selectTop: selection -> $selection")

//        if(prevPos==frag) {
        if (selection == 0) selectAll()
        else if (selection == 1) selectAllSize()
        else if (selection == 2) selectAllDate()
//        }
    }

    fun selectSizeAsc() {
        if (llDateWise != null) llDateWise!!.background =
            resources.getDrawable(R.drawable.tab_box_un_fill)
        if (llSizeWise != null) llSizeWise!!.background =
            resources.getDrawable(R.drawable.tab_box_fill)
        if (select_up_date != null) select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
        if (select_up_size != null) select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
        if (tvSize != null) tvSize!!.setTextColor(resources.getColor(R.color.colorPrimary))
        if (tvDate != null) tvDate!!.setTextColor(resources.getColor(R.color.filter_text_color))
    }

    fun selectSizeDesc() {
        if (llDateWise != null) llDateWise!!.background =
            resources.getDrawable(R.drawable.tab_box_un_fill)
        if (llSizeWise != null) llSizeWise!!.background =
            resources.getDrawable(R.drawable.tab_box_fill)
        if (select_up_date != null) select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
        if (select_up_size != null) select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
        if (tvSize != null) tvSize!!.setTextColor(resources.getColor(R.color.colorPrimary))
        if (tvDate != null) tvDate!!.setTextColor(resources.getColor(R.color.filter_text_color))
    }

    fun selectDateDesc() {
        if (llDateWise != null) llDateWise!!.background =
            resources.getDrawable(R.drawable.tab_box_fill)
        if (llSizeWise != null) llSizeWise!!.background =
            resources.getDrawable(R.drawable.tab_box_un_fill)
        if (select_up_date != null) select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
        if (select_up_size != null) select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
        if (tvDate != null) tvDate!!.setTextColor(resources.getColor(R.color.colorPrimary))
        if (tvSize != null) tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
    }

    fun selectDateAsc() {
        if (llDateWise != null) llDateWise!!.background =
            resources.getDrawable(R.drawable.tab_box_fill)
        if (llSizeWise != null) llSizeWise!!.background =
            resources.getDrawable(R.drawable.tab_box_un_fill)
        if (select_up_date != null) select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
        if (select_up_size != null) select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
        if (tvDate != null) tvDate!!.setTextColor(resources.getColor(R.color.colorPrimary))
        if (tvSize != null) tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
    }


    var selection = 0
    fun selectAll() {
        selection = 0
        if (llDateWise != null) llDateWise!!.background =
            resources.getDrawable(R.drawable.tab_box_fill)
        if (llSizeWise != null) llSizeWise!!.background =
            resources.getDrawable(R.drawable.tab_box_un_fill)
        if (select_up_date != null) select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
        if (select_up_size != null) select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
        if (tvDate != null) tvDate!!.setTextColor(resources.getColor(R.color.colorPrimary))
        if (tvSize != null) tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
        if (llDateWise != null) llDateWise.isEnabled = true
        if (llSizeWise != null) llSizeWise.isEnabled = true
    }

    private fun selectAllSize() {
        selection = 1
        if (llDateWise != null) llDateWise!!.background =
            resources.getDrawable(R.drawable.tab_box_un_fill)
        if (llSizeWise != null) llSizeWise!!.background =
            resources.getDrawable(R.drawable.tab_box_fill)
        if (select_up_date != null) select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
        if (tvDate != null) tvDate!!.setTextColor(resources.getColor(R.color.filter_text_color))
        if (tvSize != null) tvSize!!.setTextColor(resources.getColor(R.color.colorPrimary))
        if (llDateWise != null) llDateWise.isEnabled = true
        if (llSizeWise != null) llSizeWise.isEnabled = true
    }

    private fun selectAllDate() {
        selection = 2
        if (llDateWise != null) llDateWise!!.background =
            resources.getDrawable(R.drawable.tab_box_fill)
        if (llSizeWise != null) llSizeWise!!.background =
            resources.getDrawable(R.drawable.tab_box_un_fill)
        if (select_up_size != null) select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
        if (tvDate != null) tvDate!!.setTextColor(resources.getColor(R.color.colorPrimary))
        if (tvSize != null) tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
        if (llDateWise != null) llDateWise.isEnabled = true
        if (llSizeWise != null) llSizeWise.isEnabled = true
    }

    fun unSelectAll(frag: Int) {
//        if(prevPos==frag) {
        if (llDateWise != null) llDateWise!!.background =
            resources.getDrawable(R.drawable.tab_box_un_fill)
        if (llSizeWise != null) llSizeWise!!.background =
            resources.getDrawable(R.drawable.tab_box_un_fill)
        if (select_up_date != null) select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
        if (select_up_size != null) select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
        if (tvDate != null) tvDate!!.setTextColor(resources.getColor(R.color.filter_text_color))
        if (tvSize != null) tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
        if (llDateWise != null) llDateWise.isEnabled = false
        if (llSizeWise != null) llSizeWise.isEnabled = false
//        }
    }


    override fun onClick(view: View) {

    }

    override fun onResume() {
        super.onResume()
        if (isAdded) {

//            Log.e(mTAG, "onResume: $isVisibleHint")

//            if (SharedPrefsConstant.getBoolean(requireActivity(), "AfterRecover", false)) {
//                SharedPrefsConstant.savePref(requireActivity(), "AfterRecover", false)
//                getAppList()
//            }

            object : AsyncTask<Void, Long, Void>() {
                override fun doInBackground(vararg voids: Void): Void? {
//                Log.e(mTAG, "doInBackground: stopLoading")
                    if(!isAsyncRunning) stopLoading()
                    return null
                }

                override fun onPostExecute(result: Void?) {
                    super.onPostExecute(result)
                }
            }.execute()

            if (isVisibleHint && !isAsyncRunning) {

                if (mRecoverableFolderList != null && mRecoverableFolderList.size != 0) {
                    if (requireActivity() is DeepScanActivity) {
                        requireActivity().iv_span.alpha = 1.0F
                        requireActivity().iv_span.isEnabled = true
                        when (isForSort) {
                            "size_asc" -> {
                                selectSizeAsc()
                                isDateClick = true
                                isSizeClick = false
                            }
                            "size_desc" -> {
                                selectSizeDesc()
                                isDateClick = true
                                isSizeClick = false
                            }
                            "date_desc" -> {
                                selectDateDesc()
                                isDateClick = false
                                isSizeClick = true
                            }
                            "date_asc" -> {
                                selectTop(1)
                                isDateClick = false
                                isSizeClick = true
                            }
                        }
                    }
                } else {
                    if (requireActivity() is DeepScanActivity) {
                        unSelectAll(1)
                        requireActivity().iv_span.alpha = 0.5F
                        requireActivity().iv_span.isEnabled = false
                    }
                }

            }
        }
    }


    fun stopLoading() {
//        Log.e(mTAG, "doInBackground: stopLoading")
//        if((requireActivity() as DeepScanActivity).getCurrentPosition()!=1) return
        activity?.runOnUiThread {
            Handler(Looper.getMainLooper()).postDelayed({
//                userVisibleHint = true
                Log.e(mTAG, "stopLoading: isAdded:$isAdded")
                mHiddenPictureFolderAdapter?.notifyDataSetChanged()
                if (lottie_recoverable_image != null) lottie_recoverable_image.visibility =
                    View.GONE
//                Log.e(mTAG, "doInBackground: stopLoading-before")
                if (isAdded) {
//                    Log.e(mTAG, "doInBackground: stopLoading-inside")
//                    Log.e(mTAG, "doInBackground: stopLoading-${mFolderList.size}")
                    try {
//                        mHiddenPictureFolderAdapter?.notifyDataSetChanged()

                        if (mRecoverableFolderList != null && mRecoverableFolderList.size > 1) {
//                            Log.e(mTAG, "doInBackground: stopLoading-true")
                            selectTop(1)
                            if (requireActivity().iv_span != null && DeepScanActivity.prevPos == 1) {
                                Log.e(mTAG, "stopLoading: iv_span:found true")
                                requireActivity().iv_span.alpha = 1F
                                requireActivity().iv_span.isEnabled = true
                            } else {
                                Log.e(mTAG, "stopLoading: iv_span:null true")
                            }
                            tv_recoverable_album!!.visibility = View.GONE
                            scan_recoverable_album!!.visibility = View.VISIBLE
//                            Log.e(mTAG, "stopLoading: ")
                        } else {
//                            Log.e(mTAG, "doInBackground: stopLoading-false")
                            unSelectAll(1)
                            if (requireActivity().iv_span != null && DeepScanActivity.prevPos == 1) {
                                Log.e(mTAG, "stopLoading: iv_span:found false")
                                requireActivity().iv_span.alpha = 0.5F
                                requireActivity().iv_span.isEnabled = false
                            } else {
                                Log.e(mTAG, "stopLoading: iv_span:null false")
                            }
                            tv_recoverable_album!!.visibility = View.VISIBLE
                            scan_recoverable_album!!.visibility = View.GONE
                        }
                    } catch (e: Exception) {
//                        Log.e(mTAG, "doInBackground: stopLoading-Exception $e")
                    }
                }
            }, 2500)
        }
    }

}