@file:Suppress("DEPRECATION")

package com.backup.restore.device.image.recovery.mainapps.activity

import android.Manifest
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.ViewPager
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.ads.rateandfeedback.ExitSPHelper
import com.backup.restore.device.image.recovery.main.NewHomeActivity
import com.backup.restore.device.image.recovery.mainapps.fragment.AlreadyBackupApkFragment
import com.backup.restore.device.image.recovery.mainapps.fragment.ApkBackupFragment
import com.backup.restore.device.image.recovery.utilities.checkPermissionStorage
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.RatingDialog
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.example.app.ads.helper.GiftIconHelper
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlinx.android.synthetic.main.activity_apps_backup_old.*
import kotlinx.android.synthetic.main.activity_apps_backup_old.iv_back
import kotlinx.android.synthetic.main.activity_recover_image_new.*
import org.greenrobot.eventbus.EventBus
import java.util.*

class AppsBackupActivityOld : MyCommonBaseActivity() {

    val mTAG: String = javaClass.simpleName
    var mClGift: ConstraintLayout? = null
    var mViewPager: ViewPager? = null
    val mPermissionStorage = arrayOf(
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    )
    var isFromOneSignal = false
    var lViewPagerAdapter : ViewPagerAdapter? = null

    companion object {
        @JvmField
        var isFrom = ""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apps_backup_old)
    }

    override fun getContext(): AppCompatActivity {
        return this@AppsBackupActivityOld
    }

    override fun initData() {
        mViewPager = findViewById(R.id.viewpager)
        mClGift = findViewById(R.id.cl_gift)
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }

        if(isFromOneSignal){
            isFrom = "BackUp"
        }

//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
//            NativeAdvancedModelHelper(mContext).loadNativeAdvancedAd(
//                NativeAdsSize.Medium,
//                findViewById(R.id.ad_view_container)
//            )
//            if (viewpager.currentItem == 0) {
//                mClGift!!.visibility = View.VISIBLE
//            }
//
//        } else {
//            findViewById<FrameLayout>(R.id.ad_view_container).visibility = View.GONE
//            mClGift!!.visibility = View.GONE
//
//        }
    }

    override fun initActions() {
        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            GiftIconHelper.loadGiftAd(
                fContext = mContext,
                fivGiftIcon = findViewById(R.id.main_la_gift),
                fivBlastIcon = findViewById(R.id.main_la_gift_blast)
            )
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            checkAllFilePermission()
        } else {
            if (checkPermissionStorage(mContext)) {
                setAllData()
            } else {
                givePermissions(mPermissionStorage)
            }
        }
    }

    private fun setAllData() {
        setupViewPager(mViewPager)
        Handler().postDelayed({
            et_search_apk.isFocusable = true
            et_search_apk.isFocusableInTouchMode = true
            Log.e(mTAG, "findViews: focus ")
        }, 500)

        initViewActions(0)
        mViewPager!!.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
            }

            override fun onPageSelected(position: Int) {
                Log.e(mTAG, "onPageSelected: $position")
                if (position == 0) {
                    isFrom = "BackUp"
                    mClGift!!.visibility = View.VISIBLE
                } else {
                    isFrom = "AlreadyBackup"
                    mClGift!!.visibility = View.GONE
                }
                initViewActions(position)
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })
        llTabLeft!!.setOnClickListener(this)
        llTabRight!!.setOnClickListener(this)
        iv_back.setOnClickListener(this)
    }

    private fun givePermissions(permissions: Array<String>) {

        MyApplication.isInternalCall = true

        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                setAllData()
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionStorage)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest>,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            }).check()
    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                setAllData()
            } else {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse(String.format("package:%s", packageName)))
                try {
                    MyApplication.isInternalCall = true
                    startActivityForResult(intent, 2296)
                } catch (e: ActivityNotFoundException) {
                }
            }
        }
    }

    fun showSettingsDialog() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            MyApplication.isDialogOpen = false
            dialog.cancel()
            openSettings()
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            MyApplication.isDialogOpen = false
            dialog.cancel()
            if(isFromOneSignal) {
                startActivity(NewHomeActivity.newIntent(this))
                finish()
            }else{
                finish()
            }
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }
        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun openSettings() {
        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        MyApplication.isInternalCall = true
        startActivityForResult(intent, 200)
    }

    private fun initViewActions(pos: Int) {
        val gdLeft = llTabLeft!!.background.current as GradientDrawable
        val gdRight = llTabRight!!.background.current as GradientDrawable
        if (pos == 0) {
            isFrom = "BackUp"
            ivDeleteAll!!.visibility = View.GONE
            gdLeft.setColor(Color.parseColor("#6d214f"))
            gdRight.setColor(Color.parseColor("#FFFFFF"))
            tvLeft!!.setTextColor(Color.parseColor("#FFFFFF"))
            tvRight!!.setTextColor(Color.parseColor("#6d214f"))
        } else if (pos == 1) {
            isFrom = "AlreadyBackup"
            ivDeleteAll!!.visibility = View.VISIBLE
            gdLeft.setColor(Color.parseColor("#FFFFFF"))
            gdRight.setColor(Color.parseColor("#6d214f"))
            tvLeft!!.setTextColor(Color.parseColor("#6d214f"))
            tvRight!!.setTextColor(Color.parseColor("#FFFFFF"))
        }
        setupHeader(pos)
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 100) {
            return
        }
        ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.llTabLeft -> {
                isFrom = "BackUp"
                EventBus.getDefault().post("ToggleAlreadyBackup")
                mViewPager!!.currentItem = 0
                setupHeader(0)
            }
            R.id.llTabRight -> {
                isFrom = "AlreadyBackup"
                EventBus.getDefault().post("AppBack")
                mViewPager!!.currentItem = 1
            }
            R.id.iv_back -> onBackPressed()
        }
    }

    private fun setupHeader(i: Int) {
        if (i == 0) {
            ivDeleteAll!!.visibility = View.GONE
        } else {
            ivDeleteAll!!.visibility = View.VISIBLE
        }
    }

    private fun setupViewPager(viewPager: ViewPager?) {
        lViewPagerAdapter = ViewPagerAdapter(supportFragmentManager)
        lViewPagerAdapter!!.addFrag(ApkBackupFragment.newInstance(), "Backup")
        lViewPagerAdapter!!.addFrag(AlreadyBackupApkFragment.newInstance(), "History")
        viewPager!!.adapter = lViewPagerAdapter
    }

    class ViewPagerAdapter(manager: FragmentManager?) : FragmentPagerAdapter(manager!!) {

        private val mFragmentList: MutableList<Fragment> = ArrayList()
        private val mFragmentTitleList: MutableList<String> = ArrayList()

        override fun getItem(position: Int): Fragment {
            return mFragmentList[position]
        }

        override fun getCount(): Int {
            return mFragmentList.size
        }

        fun addFrag(fragment: Fragment, title: String) {
            mFragmentList.add(fragment)
            mFragmentTitleList.add(title)
        }

        override fun getPageTitle(position: Int): CharSequence {
            return mFragmentTitleList[position]
        }
    }

//    override fun attachBaseContext(newBase: Context) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
//    }

    override fun onBackPressed() {
        if (isFromOneSignal) {
            startActivity(NewHomeActivity.newIntent(this))
            finish()
        } else {

            if (viewpager.currentItem == 0) {
//                stopAsync()
                super.onBackPressed()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            } else {
                val isRated = ExitSPHelper(mContext).isRated()
                if (!isRated) {
                    if (SharedPrefsConstant.getInt(mContext, ShareConstants.RATE_RECOVER_APK_COUNT) >= 3 && SharedPrefsConstant.getInt(mContext,ShareConstants.RATE_LATTER,1)==0) {
                        RatingDialog.smileyRatingDialog(mContext)
                    } else {
//                        stopAsync()
                        super.onBackPressed()
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    }
                } else {
//                    stopAsync()
                    super.onBackPressed()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            }
        }
    }


    override fun onResume() {
        super.onResume()

//        if(isSetting){
//            isSetting = false
//            givePermissions(mPermissionStorage)
//        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    setAllData()
                    Log.e(mTAG, "onActivityResult: Service Start ")
                } else {
                    if (isFromOneSignal) {
                        startActivity(NewHomeActivity.newIntent(this))
                        finish()
                        Toast.makeText(mContext, getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                    } else {
                        finish()
                        Toast.makeText(mContext, getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        } else if (requestCode == 200) {
            if (checkPermissionStorage(mContext)) {
                setAllData()
            } else {
                if (isFromOneSignal) {
                    startActivity(NewHomeActivity.newIntent(this))
                    finish()
                    Toast.makeText(mContext, getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(mContext, getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}