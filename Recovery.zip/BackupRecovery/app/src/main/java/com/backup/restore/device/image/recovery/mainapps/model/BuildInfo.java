package com.backup.restore.device.image.recovery.mainapps.model;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Build;
import android.util.Size;

import java.io.File;
import java.util.Arrays;
import java.util.Locale;


/**
 * Created by @mrudultora
 */

public class BuildInfo {
    private final Context context;
    CameraManager cameraManager;

    public BuildInfo(Context context) {
        this.context = context;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        }
    }

    public String getOrientation() {
        String orien = "";
        switch (context.getResources().getConfiguration().orientation) {
            case 0:
                orien = "undefined";
                break;
            case 1:
                orien = "portrait";
                break;
            case 2:
                orien = "landscape";
                break;
            case 3:
                orien = "square";
                break;
        }
        return orien;
    }



    public boolean checkRootFiles() {
        boolean root = false;
        String[] paths = {"/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su",
                "/system/bin/failsafe/su", "/data/local/su", "/su/bin/su"};
        for (String path : paths) {
            root = new File(path).exists();
            if (root)
                break;
        }
        return root;
    }

    public boolean checkTags() {
        String tag = Build.TAGS;
        return tag != null && tag.trim().contains("test-keys");
    }


    public String afCamera(int facing) {
        String[] af;
        StringBuilder afm = new StringBuilder();
        String afModes = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics = null;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (characteristics != null) {
                af = Arrays.toString(characteristics.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)).replace("[", "").replace("]", "").split(",");
                for (String mode : af) {
                    if (mode.trim().contains("0"))
                        afm.append("Off, ");
                    if (mode.trim().contains("1"))
                        afm.append("Auto, ");
                    if (mode.trim().contains("2"))
                        afm.append("Macro, ");
                    if (mode.trim().contains("3"))
                        afm.append("Continuous Video, ");
                    if (mode.trim().contains("4"))
                        afm.append("Continuous Picture, ");
                    if (mode.trim().contains("5"))
                        afm.append("EDof, ");
                }
            }
            if (afm.toString().length() > 0)
                afModes = afm.toString().substring(0, afm.toString().length() - 2);
            else
                afModes = "Not Available";
        }
        return afModes;
    }

    public String abCamera(int facing) {
        String[] ab;
        StringBuilder abm = new StringBuilder();
        String abModes = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics = null;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (characteristics != null) {
                ab = Arrays.toString(characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_ANTIBANDING_MODES)).replace("[", "").replace("]", "").split(",");
                for (String mode : ab) {
                    if (mode.trim().contains("0"))
                        abm.append("Off, ");
                    if (mode.trim().contains("1"))
                        abm.append("50Hz, ");
                    if (mode.trim().contains("2"))
                        abm.append("60Hz, ");
                    if (mode.trim().contains("3"))
                        abm.append("Auto, ");
                }
            }
            if (abm.toString().length() > 0)
                abModes = abm.toString().substring(0, abm.toString().length() - 2);
            else
                abModes = "Not Available";
        }
        return abModes;
    }

    public String effCamera(int facing) {
        String[] eff;
        StringBuilder effm = new StringBuilder();
        String effects = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics = null;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (characteristics != null) {
                eff = Arrays.toString(characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_EFFECTS)).replace("[", "").replace("]", "").split(",");
                for (String mode : eff) {
                    if (mode.trim().contains("0"))
                        effm.append("Off, ");
                    if (mode.trim().contains("1"))
                        effm.append("Mono, ");
                    if (mode.trim().contains("2"))
                        effm.append("Negative, ");
                    if (mode.trim().contains("3"))
                        effm.append("Solarize, ");
                    if (mode.trim().contains("4"))
                        effm.append("Sepia, ");
                    if (mode.trim().contains("5"))
                        effm.append("Posterize, ");
                    if (mode.trim().contains("6"))
                        effm.append("Whiteboard, ");
                    if (mode.trim().contains("7"))
                        effm.append("Blackboard, ");
                    if (mode.trim().contains("8"))
                        effm.append("Aqua, ");
                }
            }
            if (effm.toString().length() > 0)
                effects = effm.toString().substring(0, effm.toString().length() - 2);
            else
                effects = "Not Available";
        }
        return effects;
    }

    public String sceneCamera(int facing) {
        String[] scenes;
        String sceneModes = null;
        StringBuilder scenem = new StringBuilder();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics = null;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (characteristics != null) {
                scenes = Arrays.toString(characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES)).replace("[", "").replace("]", "").split(",");
                for (String mode : scenes) {
                    if (mode.trim().contains("0"))
                        scenem.append("Disabled, ");
                    if (mode.trim().contains("1"))
                        scenem.append("Face Priority, ");
                    if (mode.trim().contains("2"))
                        scenem.append("Action, ");
                    if (mode.trim().contains("3"))
                        scenem.append("Portrait, ");
                    if (mode.trim().contains("4"))
                        scenem.append("Landscape, ");
                    if (mode.trim().contains("5"))
                        scenem.append("Night, ");
                    if (mode.trim().contains("6"))
                        scenem.append("Night Portrait, ");
                    if (mode.trim().contains("7"))
                        scenem.append("Theatre, ");
                    if (mode.trim().contains("8"))
                        scenem.append("Beach, ");
                    if (mode.trim().contains("9"))
                        scenem.append("Snow, ");
                    if (mode.trim().contains("10"))
                        scenem.append("Sunset, ");
                    if (mode.trim().contains("11"))
                        scenem.append("Steady Photo, ");
                    if (mode.trim().contains("12"))
                        scenem.append("FireWorks, ");
                    if (mode.trim().contains("13"))
                        scenem.append("Sports, ");
                    if (mode.trim().contains("14"))
                        scenem.append("Party, ");
                    if (mode.trim().contains("15"))
                        scenem.append("CandleLight, ");
                    if (mode.trim().contains("16"))
                        scenem.append("Barcode, ");
                }
            }
            if (scenem.toString().length() > 0)
                sceneModes = scenem.toString().substring(0, scenem.toString().length() - 2);
            else
                sceneModes = "Not Available";
        }
        return sceneModes;
    }

    public String awbCamera(int facing) {
        String[] awb;
        StringBuilder awbm = new StringBuilder();
        String awbModes = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics = null;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (characteristics != null) {
                awb = Arrays.toString(characteristics.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)).replace("[", "").replace("]", "").split(",");
                for (String mode : awb) {
                    if (mode.trim().contains("0"))
                        awbm.append("Off, ");
                    if (mode.trim().contains("1"))
                        awbm.append("Auto, ");
                    if (mode.trim().contains("2"))
                        awbm.append("Incandescent, ");
                    if (mode.trim().contains("3"))
                        awbm.append("Fluorescent, ");
                    if (mode.trim().contains("4"))
                        awbm.append("Warm Fluorescent, ");
                    if (mode.trim().contains("5"))
                        awbm.append("Daylight, ");
                    if (mode.trim().contains("6"))
                        awbm.append("Cloudy Daylight, ");
                    if (mode.trim().contains("7"))
                        awbm.append("Twilight, ");
                    if (mode.trim().contains("8"))
                        awbm.append("Shade, ");
                }
            }
            if (awbm.toString().length() > 0)
                awbModes = awbm.toString().substring(0, awbm.toString().length() - 2);
            else
                awbModes = "Not Available";
        }
        return awbModes;
    }

    public String hotPixelCamera(int facing) {
        String[] hp;
        StringBuilder hpm = new StringBuilder();
        String hotPixelModes = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics = null;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (characteristics != null) {
                hp = Arrays.toString(characteristics.get(CameraCharacteristics.HOT_PIXEL_AVAILABLE_HOT_PIXEL_MODES)).replace("[", "").replace("]", "").split(",");
                for (String mode : hp) {
                    if (mode.trim().contains("0"))
                        hpm.append("Off, ");
                    if (mode.trim().contains("1"))
                        hpm.append("Fast, ");
                    if (mode.trim().contains("2"))
                        hpm.append("High Quality, ");
                }
            }
            if (hpm.toString().length() > 0)
                hotPixelModes = hpm.toString().substring(0, hpm.toString().length() - 2);
            else
                hotPixelModes = "Not Available";
        }
        return hotPixelModes;
    }

    public String edgeModesCamera(int facing) {
        String[] ed;
        StringBuilder edgem = new StringBuilder();
        String edgeModes = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics = null;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (characteristics != null) {
                ed = Arrays.toString(characteristics.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)).replace("[", "").replace("]", "").split(",");
                for (String mode : ed) {
                    if (mode.trim().contains("0"))
                        edgem.append("Off, ");
                    if (mode.trim().contains("1"))
                        edgem.append("Fast, ");
                    if (mode.trim().contains("2"))
                        edgem.append("High Quality, ");
                    if (mode.trim().contains("3"))
                        edgem.append("Zero Shutter Lag, ");
                }
            }
            if (edgem.toString().length() > 0)
                edgeModes = edgem.toString().substring(0, edgem.toString().length() - 2);
            else
                edgeModes = "Not Available";
        }
        return edgeModes;
    }

    public String videoModesCamera(int facing) {
        String[] vs;
        StringBuilder vsm = new StringBuilder();
        String videoModes = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics = null;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (characteristics != null) {
                vs = Arrays.toString(characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)).replace("[", "").replace("]", "").split(",");
                for (String mode : vs) {
                    if (mode.trim().contains("0"))
                        vsm.append("Off, ");
                    if (mode.trim().contains("1"))
                        vsm.append("On, ");
                }
            }
            if (vsm.toString().length() > 0)
                videoModes = vsm.toString().substring(0, vsm.toString().length() - 2);
            else
                videoModes = "Not Available";
        }
        return videoModes;
    }

    public String camCapCamera(int facing) {
        String[] camcap;
        StringBuilder camcapm = new StringBuilder();
        String capabilities = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics = null;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (characteristics != null) {
                camcap = Arrays.toString(characteristics.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)).replace("[", "").replace("]", "").split(",");
                for (String mode : camcap) {
                    if (mode.trim().contains("0"))
                        camcapm.append("Backward Compatible, ");
                    if (mode.trim().contains("1"))
                        camcapm.append("Manual Sensor, ");
                    if (mode.trim().contains("2"))
                        camcapm.append("Manual Post Processing, ");
                    if (mode.trim().contains("3"))
                        camcapm.append("RAW, ");
                    if (mode.trim().contains("4"))
                        camcapm.append("Private Reprocessing, ");
                    if (mode.trim().contains("5"))
                        camcapm.append("Read Sensor Settings, ");
                    if (mode.trim().contains("6"))
                        camcapm.append("Burst Capture, ");
                    if (mode.trim().contains("7"))
                        camcapm.append("YUV Reprocessing, ");
                    if (mode.trim().contains("8"))
                        camcapm.append("Depth Output, ");
                    if (mode.trim().contains("9"))
                        camcapm.append("High Speed Video, ");
                    if (mode.trim().contains("10"))
                        camcapm.append("Motion Tracking, ");
                    if (mode.trim().contains("11"))
                        camcapm.append("Logical Multi Camera, ");
                    if (mode.trim().contains("12"))
                        camcapm.append("Monochrome, ");
                    if (mode.trim().contains("13"))
                        camcapm.append("Secure Image Data, ");
                }
            }
            if (camcapm.toString().length() > 0)
                capabilities = camcapm.toString().substring(0, camcapm.toString().length() - 2);
            else
                capabilities = "Not Available";
        }
        return capabilities;
    }

    public String testModesCamera(int facing) {
        String[] tp;
        StringBuilder tpm = new StringBuilder();
        String testPattern = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics = null;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (characteristics != null) {
                tp = Arrays.toString(characteristics.get(CameraCharacteristics.SENSOR_AVAILABLE_TEST_PATTERN_MODES)).replace("[", "").replace("]", "").split(",");
                for (String mode : tp) {
                    if (mode.trim().contains("0"))
                        tpm.append("Off, ");
                    if (mode.trim().contains("1"))
                        tpm.append("Solid Color, ");
                    if (mode.trim().contains("2"))
                        tpm.append("Color Bars, ");
                    if (mode.trim().contains("3"))
                        tpm.append("Color Bars Fade to Gray, ");
                    if (mode.trim().contains("4"))
                        tpm.append("PN9, ");
                    if (mode.trim().contains("256"))
                        tpm.append("Custom1, ");
                }
            }
            if (tpm.toString().length() > 0)
                testPattern = tpm.toString().substring(0, tpm.toString().length() - 2);
            else
                testPattern = "Not Available";
        }
        return testPattern;
    }

    public String aeCamera(int facing) {
        String[] ae;
        StringBuilder aem = new StringBuilder();
        String aeModes = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics = null;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (characteristics != null) {
                ae = Arrays.toString(characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES)).replace("[", "").replace("]", "").split(",");
                for (String mode : ae) {
                    if (mode.trim().contains("0"))
                        aem.append("Off, ");
                    if (mode.trim().contains("1"))
                        aem.append("On, ");
                    if (mode.trim().contains("2"))
                        aem.append("Auto Flash, ");
                    if (mode.trim().contains("3"))
                        aem.append("Always Flash, ");
                    if (mode.trim().contains("4"))
                        aem.append("Auto Flash Red-Eye, ");
                    if (mode.trim().contains("5"))
                        aem.append("External Flash, ");
                }
            }
            if (aem.toString().length() > 0)
                aeModes = aem.toString().substring(0, aem.toString().length() - 2);
            else
                aeModes = "Not Available";
        }
        return aeModes;
    }

    public String fdCamera(int facing) {
        String[] fd;
        StringBuilder fdm = new StringBuilder();
        String faceDetectModes = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics = null;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (characteristics != null) {
                fd = Arrays.toString(characteristics.get(CameraCharacteristics.STATISTICS_INFO_AVAILABLE_FACE_DETECT_MODES)).replace("[", "").replace("]", "").split(",");
                for (String mode : fd) {
                    if (mode.trim().contains("0"))
                        fdm.append("Off, ");
                    if (mode.trim().contains("1"))
                        fdm.append("Simple, ");
                    if (mode.trim().contains("2"))
                        fdm.append("Full, ");
                }
            }
            if (fdm.toString().length() > 0)
                faceDetectModes = fdm.toString().substring(0, fdm.toString().length() - 2);
            else
                faceDetectModes = "Not Available";
        }
        return faceDetectModes;
    }

    public String amCamera(int facing) {
        String[] aberrationModes;
        StringBuilder am = new StringBuilder();
        String aberrationMode = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics = null;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (characteristics != null) {
                aberrationModes = Arrays.toString(characteristics.get(CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES)).replace("[", "").replace("]", "").split(",");
                for (String mode : aberrationModes) {
                    if (mode.trim().contains("0"))
                        am.append("Off, ");
                    if (mode.trim().contains("1"))
                        am.append("Fast, ");
                    if (mode.trim().contains("2"))
                        am.append("High Quality, ");
                }
            }
            if (am.toString().length() > 0)
                aberrationMode = am.toString().substring(0, am.toString().length() - 2);
            else
                aberrationMode = "Not Available";
        }
        return aberrationMode;
    }

    public String osCamera(int facing) {
        String[] os;
        StringBuilder osm = new StringBuilder();
        String opticalStable = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics = null;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (characteristics != null) {
                os = Arrays.toString(characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)).replace("[", "").replace("]", "").split(",");
                for (String mode : os) {
                    if (mode.trim().contains("0"))
                        osm.append("Off, ");
                    if (mode.trim().contains("1"))
                        osm.append("On, ");
                }
            }
            if (osm.toString().length() > 0)
                opticalStable = osm.toString().substring(0, osm.toString().length() - 2);
            else
                opticalStable = "Not Available";
        }
        return opticalStable;
    }

    @SuppressLint("DefaultLocale")
    public String resolutionsCamera(int facing) {
        StreamConfigurationMap streamConfigurationMap;
        Size[] sizes;
        StringBuilder srm = new StringBuilder();
        String resolutions = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CameraCharacteristics characteristics;
            try {
                characteristics = cameraManager.getCameraCharacteristics(String.valueOf(facing));
                streamConfigurationMap = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                sizes = streamConfigurationMap.getOutputSizes(ImageFormat.RAW_SENSOR);
                if (sizes != null)
                    for (Size size : sizes)
                        srm.append(String.format(Locale.ENGLISH,"%.2f", size.getWidth() * size.getHeight() / 1000000.0)).append(" MP - ").append(size.getWidth()).append(" x ").append(size.getHeight()).append("\n");
                sizes = streamConfigurationMap.getOutputSizes(ImageFormat.JPEG);
                if (sizes != null)
                    for (Size size : sizes)
                        srm.append(String.format(Locale.ENGLISH,"%.2f", size.getWidth() * size.getHeight() / 1000000.0)).append(" MP - ").append(size.getWidth()).append(" x ").append(size.getHeight()).append("\n");
                resolutions = srm.toString().substring(0, srm.toString().length() - 1);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return resolutions;
    }

}
