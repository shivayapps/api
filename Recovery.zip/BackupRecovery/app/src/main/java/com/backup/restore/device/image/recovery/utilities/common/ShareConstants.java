package com.backup.restore.device.image.recovery.utilities.common;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;

import androidx.core.content.ContextCompat;

import com.backup.restore.device.image.recovery.maincontact.model.ContactModel;
import com.backup.restore.device.image.recovery.mainphotos.model.RecoverableFolderModel;
import com.backup.restore.device.image.recovery.mainphotos.model.RecoverableImageModel;
import com.backup.restore.device.image.recovery.retriever.Album;
import com.backup.restore.device.image.recovery.retriever.AlbumItem;

import java.io.File;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Comparator;
import java.util.Locale;

/**
 * Created by Vasundhara on 30-Apr-18.
 */

public class ShareConstants {


    public static Boolean isBackup = false;
    public static File path = null;
    public static int count = 0;
    public static String date_time = "";
    public static int position = 0;

    public static String user_id = "";
    public static String user_name = "";
    public static String user_number = "";
    public static int user_position;
    public static int new_position;

    public static boolean globalPause = false;

//    public static Bitmap user_image = null;
    public static String contact_image_uri = null;

    public static int fav_position;
    public static int hide_position;
    public static boolean fav_activity = false;
    public static boolean hide_activity = false;
    public static boolean is_junk_initialized = false;

    public static int isApkInitialized = 0;
    public static int isTempInitialized = 0;
    public static int isTrashInitialized = 0;
    public static int isUninstallInitialized = 0;
    public static int isEmptyInitialized = 0;
    public static int fav_contact_id = -1;

    public static final String SELECTED_LANGUAGE = "selectedLocale";
    public static final String SELECTED_LANGUAGE_LABLE = "selectedLocaleLable";
//    public static final String DUPLICATE_SELECTION = "duplicateSelection";
//    public static final String RECOVER_NOTIFICATION = "recoverNotification";

    public static final String FREE_RECOVER_IMAGE_COUNT = "freeRecoverImageCount";
    public static final String FREE_RECOVER_APK_COUNT = "freeRecoverApkCount";
    public static final String FREE_RECOVER_CONTACT_COUNT = "freeRecoverContactCount";

    public static final String RATE_RECOVER_IMAGE_COUNT = "rateRecoverImageCount";
    public static final String RATE_RECOVER_APK_COUNT = "rateRecoverAPKCount";
    public static final String RATE_BACKUP_CONTACT_COUNT = "rateBackupContactCount";
    public static final String RATE_DUPLICATE_COUNT = "rateDuplicateCount";
    public static final String RATE_DEVICE_INFO = "rateDeviceInfo";
    public static final String RATE_JUNK_CLEANER = "rateJunkCleaner";
    public static final String RATE_UNINSTALLER = "rateUninstaller";
    public static final String RATE_LATTER = "rateLatter";
    public static final String APP_RUN_COUNT = "appRunCount";

    public static String mRootPath = "";
    public static String mExcelPath = "";
    public static long mLastClickTime = 0;
    public static boolean isManualClick = false;
    public static boolean isManualHiddenClick = false;
    public static final String IS_ADS_REMOVED = "is_ads_removed";


//    public static ArrayList<EmptyFolderModel> mEmptyFolderListFinal = new ArrayList<>();

    public static Boolean RestartAppStorage(Activity activity) {
        if (!ShareConstants.checkAndRequestPermissionsBoth(activity, 1)) {
            Intent i = activity.getBaseContext().getPackageManager().getLaunchIntentForPackage(activity.getBaseContext().getPackageName());
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            activity.startActivity(i);
            return false;
        } else {
            return true;
        }
    }

    public static String getReadableFileSize(long size) {
        try {
            if (size <= 0) {
                return "0 KB";
            }
            final String[] units = new String[]{"B", "KB", "MB", "GB", "TB", "PB"};
            int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
            return new DecimalFormat("#,##0.##",new DecimalFormatSymbols(Locale.ENGLISH)).format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    //------------------------------------- Recovered -------------------------------------//

    public static class ContactModelAscending implements Comparator<ContactModel> {
        public int compare(ContactModel left, ContactModel right) {
            if(left == null || right ==null){
                return -1;
            } else if(left.getMContactName() == null || right.getMContactName() ==null){
                return -1;
            } else {
                return right.getMContactName().compareTo(left.getMContactName());
            }
        }
    }
    
    public static class RecoveredDateAscending implements Comparator<File> {
        public int compare(File left, File right) {
            if(left == null || right ==null){
                return -1;
            }else {
                return Long.compare(right.lastModified(), left.lastModified());
            }
        }
    }

    public static class RecoveredDateDescending implements Comparator<File> {
        public int compare(File left, File right) {

            if (left != null && right != null) {
                return Long.compare(left.lastModified(), right.lastModified());
            } else return -1;
//            if(left == null && right ==null){
//                return 0;
//            }else {
//            }
        }
    }

//    public static class RecoverableDateAscending implements Comparator<RecoverableFolderModel> {
//        public int compare(RecoverableFolderModel left, RecoverableFolderModel right) {
//            if(left == null || right ==null){
//                return -1;
//            }else {
//                return Long.compare(right.getFolderDate(), left.getFolderDate());
//            }
//        }
//    }

//    public static class RecoverableDateDescending implements Comparator<RecoverableFolderModel> {
//        public int compare(RecoverableFolderModel left, RecoverableFolderModel right) {
//
//            if (left != null && right != null) {
//                return Long.compare(left.getFolderDate(), right.getFolderDate());
//            } else return -1;
//        }
//    }


    public static class RecoveredSizeAscending implements Comparator<File> {
        public int compare(File left, File right) {
            if (left != null && right != null) {
                return (int) (left.length() - right.length());
            } else return -1;
        }
    }

    public static class RecoveredSizeDescending implements Comparator<File> {
        public int compare(File left, File right) {
            if (left != null && right != null) {
                return (int) (right.length() - left.length());
            } else return -1;
        }
    }

//    public static class RecoverableSizeAscending implements Comparator<RecoverableFolderModel> {
//        public int compare(RecoverableFolderModel left, RecoverableFolderModel right) {
//            if (left != null && right != null) {
//                return (int) (left.getFolderSize() - right.getFolderSize());
//            } else return -1;
//        }
//    }

//    public static class RecoverableSizeDescending implements Comparator<RecoverableFolderModel> {
//        public int compare(RecoverableFolderModel left, RecoverableFolderModel right) {
//            if (left != null && right != null) {
//                return (int) (right.getFolderSize() - left.getFolderSize());
//            } else return -1;
//        }
//    }

    //------------------------------------- Recoverable Album -------------------------------------//

    public static class AlbumDateAscending implements Comparator<Album> {
        public int compare(Album left, Album right) {
            return Long.compare(right.lastModified, left.lastModified);
        }
    }
    public static class AlbumDateDescending implements Comparator<Album> {
        public int compare(Album left, Album right) {
            return Long.compare(left.lastModified, right.lastModified);
        }
    }
    public static class AlbumSizeAscending implements Comparator<Album> {
        public int compare(Album left, Album right) {
            return Long.compare(right.getAlbumItems().size(), left.getAlbumItems().size());
        }
    }
    public static class AlbumSizeDescending implements Comparator<Album> {
        public int compare(Album left, Album right) {
            return Long.compare(left.getAlbumItems().size(), right.getAlbumItems().size());
//            return Long.compare(new File(left.getPath()).lastModified(), new File(right.getPath()).lastModified());
        }
    }

    public static class RecoverableDateAscending implements Comparator<RecoverableFolderModel> {
        public int compare(RecoverableFolderModel left, RecoverableFolderModel right) {
            return Long.compare(right.getFolderDate(), left.getFolderDate());
        }
    }

    public static class RecoverableDateDescending implements Comparator<RecoverableFolderModel> {
        public int compare(RecoverableFolderModel left, RecoverableFolderModel right) {
            return Long.compare(left.getFolderDate(), right.getFolderDate());
        }
    }

    public static class RecoverableSizeAscending implements Comparator<RecoverableFolderModel> {
        public int compare(RecoverableFolderModel left, RecoverableFolderModel right) {
//            int sizeLeft=ShareConstants.getFolderSize(new File(left.getPath()));
//            int sizeRight=ShareConstants.getFolderSize(new File(right.getPath()));
//            return (int) (sizeLeft - sizeRight);
            return (int) (left.getNumberOfPics() - right.getNumberOfPics());
        }
    }

    public static class RecoverableSizeDescending implements Comparator<RecoverableFolderModel> {
        public int compare(RecoverableFolderModel left, RecoverableFolderModel right) {
//            int sizeLeft=ShareConstants.getFolderSize(new File(left.getPath()));
//            int sizeRight=ShareConstants.getFolderSize(new File(right.getPath()));
//            return (int) (sizeRight - sizeLeft);
            return (int) (right.getNumberOfPics() - left.getNumberOfPics());
        }
    }

    //------------------------------------- Recoverable Image -------------------------------------//

    public static class dateComparator implements Comparator<RecoverableImageModel> {
        public int compare(RecoverableImageModel left, RecoverableImageModel right) {
//            return Long.compare(right.getFileDate(), left.getFileDate());
            if(left.getFileDate()>=0 && right.getFileDate()>=0) return Long.compare(right.getFileDate(), left.getFileDate());
            else return -1;
        }
    }
    public static class dateComparatorFile implements Comparator<File> {
        public int compare(File left, File right) {
//            return Long.compare(right.getFileDate(), left.getFileDate());
            if(left.lastModified()>=0 && right.lastModified()>=0) return Long.compare(right.lastModified(), left.lastModified());
            else return -1;
        }
    }

    public static class dateComparatorReversFile implements Comparator<File> {
        public int compare(File left, File right) {
            if(left.lastModified()>=0 && right.lastModified()>=0) return Long.compare(left.lastModified(), right.lastModified());
            else return -1;
//            return Long.compare(left.getFileDate(), right.getFileDate());
        }
    }
    public static class dateComparatorAlbumItem implements Comparator<AlbumItem> {
        public int compare(AlbumItem left, AlbumItem right) {
//            return Long.compare(right.getFileDate(), left.getFileDate());
            //if(new File(left.getPath()).lastModified()>=0 && new File(right.getPath()).lastModified()>=0) return Long.compare(new File(right.getPath()).lastModified(), new File(left.getPath()).lastModified());
            if(left.getDate()>=0 && right.getDate()>=0) return Long.compare(left.getDate(), right.getDate());
            else return -1;
        }
    }

    public static class dateComparatorReversAlbumItem implements Comparator<AlbumItem> {
        public int compare(AlbumItem left, AlbumItem right) {
            //if(new File(left.getPath()).lastModified()>=0 && new File(right.getPath()).lastModified()>=0) return Long.compare(new File(left.getPath()).lastModified(), new File(right.getPath()).lastModified());
            if(left.getDate()>=0 && right.getDate()>=0) return Long.compare(right.getDate(), left.getDate());
            else return -1;
//            return Long.compare(left.getFileDate(), right.getFileDate());
        }
    }

    public static class dateComparatorRevers implements Comparator<RecoverableImageModel> {
        public int compare(RecoverableImageModel left, RecoverableImageModel right) {
            if(left.getFileDate()>=0 && right.getFileDate()>=0) return Long.compare(left.getFileDate(), right.getFileDate());
            else return -1;
//            return Long.compare(left.getFileDate(), right.getFileDate());
        }
    }

    public static class sizeComparator implements Comparator<RecoverableImageModel> {
        public int compare(RecoverableImageModel left, RecoverableImageModel right) {
            if(left.getFileSize()>=0 && right.getFileSize()>=0) return (int) (left.getFileSize() - right.getFileSize());
            else return -1;
        }
    }

    public static class sizeComparatorRevers implements Comparator<RecoverableImageModel> {
        public int compare(RecoverableImageModel left, RecoverableImageModel right) {
            if(right.getFileSize()>=0 && left.getFileSize()>=0) return (int) (right.getFileSize() - left.getFileSize());
            else return -1;
        }
    }

    public static class sizeComparatorFile implements Comparator<File> {
        public int compare(File left, File right) {
            if(left.length()>=0 && right.length()>=0) return (int) (left.length() - right.length());
            else return -1;
        }
    }

    public static class sizeComparatorReversFile implements Comparator<File> {
        public int compare(File left, File right) {
            if(right.length()>=0 && left.length()>=0) return (int) (right.length() - left.length());
            else return -1;
        }
    }

    public static class sizeComparatorAlbumItem implements Comparator<AlbumItem> {
        public int compare(AlbumItem left, AlbumItem right) {
//            if(new File(left.getPath()).length()>=0 && new File(right.getPath()).length()>=0) return (int) (new File(left.getPath()).length() - new File(right.getPath()).length());
            if(left.getSize()>=0 && right.getSize()>=0) return (int) (left.getSize() - right.getSize());
            else return -1;
        }
    }

    public static class sizeComparatorReversAlbumItem implements Comparator<AlbumItem> {
        public int compare(AlbumItem left, AlbumItem right) {
            //if(new File(right.getPath()).length()>=0 && new File(left.getPath()).length()>=0) return (int) (new File(right.getPath()).length() - new File(left.getPath()).length());
            if(right.getSize()>=0 && left.getSize()>=0) return (int) (right.getSize() - left.getSize());
            else return -1;
        }
    }


    public static long getFolderSize(File dir) {
        if (dir.exists()) {
            int result = 0;
            File[] fileList = dir.listFiles();
            if (fileList != null) {
                for (File file : fileList) {
                    if (file.isDirectory()) {
                        result += getFolderSize(file);
                    } else {
                        result += file.length();
                    }
                }
            }
            return result;
        }
        return 0;
    }

    public static boolean checkAndRequestPermissionsBoth(Activity act, int code) {

        if (ContextCompat.checkSelfPermission(act, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(act, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            return false;
        } else
            return ContextCompat.checkSelfPermission(act, android.Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(act, android.Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED;
    }
}
