package com.backup.restore.device.image.recovery.utilities;

/**
 * Created by ${Saquib} on 06-02-2018.
 */

public enum Status {
    LOADING,
    SUCCESS,
    ERROR,
    COMPLETED
}