package com.backup.restore.device.image.recovery.filepicker.widget;

/**
 * @author akshay sunil masram
 */
public interface OnCheckedChangeListener {
    void onCheckedChanged(MaterialCheckbox checkbox, boolean isChecked);
}