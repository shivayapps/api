package com.backup.restore.device.image.recovery.mainduplicate.model

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.TextView
import androidx.core.app.ActivityOptionsCompat
import androidx.core.view.ViewCompat
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.rateandfeedback.ExitSPHelper
import com.backup.restore.device.image.recovery.duplicatenew.utils.algorathm.DuplicateFilesAsyncTask
import com.backup.restore.device.image.recovery.duplicatenew.utils.algorathm.ObserveFilesExecutor
import com.backup.restore.device.image.recovery.mainduplicate.activity.duplicateactivities.NewDuplicateMediaActivityNEW
import com.backup.restore.device.image.recovery.mainduplicate.asynctask.DeleteDuplicateFileAsyncTask
import com.backup.restore.device.image.recovery.mainduplicate.callbacks.MarkedListener
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateFileRemoverSharedPreferences.getMandatoryRateUsPopUsFlag
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateFileRemoverSharedPreferences.getRateUsPopUpLimit
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateFileRemoverSharedPreferences.setMandatoryRateUsPopUsFlag
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateFileRemoverSharedPreferences.setRateUsPopUpLimit
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateFileRemoverSharedPreferences.setStopScan
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateFoundAndSize.totalDuplicateAudios
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateFoundAndSize.totalDuplicateDocuments
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateFoundAndSize.totalDuplicatePhotos
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateFoundAndSize.totalDuplicateVideos
import com.backup.restore.device.image.recovery.utilities.MyAnnotations
import com.backup.restore.device.image.recovery.utilities.common.GlobalVarsAndFunctions
import com.backup.restore.device.image.recovery.utilities.common.RatingDialog
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import java.util.*

@Suppress("DEPRECATION")
class PopUp(var popUpContext: Context, var popUpActivity: Activity) {

    fun showAlertStopScanning(readingAllFiles: ObserveFilesExecutor) {

        val dialog = Dialog(popUpActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        dialog.findViewById<TextView>(R.id.permission).text = popUpContext.getString(R.string.exit_scanning)
        dialog.findViewById<TextView>(R.id.permission_text).text = popUpContext.getString(R.string.scanning_stop)
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = popUpActivity.getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = popUpActivity.getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()

            readingAllFiles.stopAsyncTask()
            NewDuplicateMediaActivityNEW.isScanRunning = false
            setStopScan(popUpContext, true)

//            popUpActivity.finish()
//            popUpActivity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
        }
        dialog.show()
    }
    fun showAlertStopScanning(readingAllFiles: DuplicateFilesAsyncTask) {

        val dialog = Dialog(popUpActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        dialog.findViewById<TextView>(R.id.permission).text = popUpContext.getString(R.string.exit_scanning)
        dialog.findViewById<TextView>(R.id.permission_text).text = popUpContext.getString(R.string.scanning_stop)
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = popUpActivity.getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = popUpActivity.getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()

//            Constants.resetOneTimePopUp()
//            GlobalVarsAndFunctions.listOfDuplicates.clear()
//            GlobalVarsAndFunctions.fileToBeDeleted.clear()
//            GlobalVarsAndFunctions.uniqueMd5Value.clear()
//            GlobalVarsAndFunctions.extensionHashSet.clear()
//            GlobalVarsAndFunctions.audiosExtensionHashSet.clear()
//            GlobalVarsAndFunctions.documentsExtensionHashSet.clear()
//            GlobalVarsAndFunctions.photosExtensionHashSet.clear()
//            GlobalVarsAndFunctions.videosExtensionHashSet.clear()

            readingAllFiles.cancel(true)
            NewDuplicateMediaActivityNEW.isScanRunning = false
            setStopScan(popUpContext, true)

//            popUpActivity.finish()
//            popUpActivity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
        }
        dialog.show()
    }

    fun showSpaceRecoveredPopUp(isType: String?, str1: String?, str2: String?, imagesMarkedListener: MarkedListener, deletedFileCount: Int) {
        Log.e("TAG", "photosCleaned showSpaceRecoveredPopUp: ")

        val dialog = Dialog(popUpActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_memory_regained)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

//        val imageView = dialog.findViewById<ImageView>(R.id.imageIcon)

//        when (isType) {
//            MyAnnotations.IMAGES -> {
//                imageView.setImageDrawable(popUpActivity.resources.getDrawable(R.drawable.ic_dialog_remove_images))
//            }
//            MyAnnotations.VIDEOS -> {
//                imageView.setImageDrawable(popUpActivity.resources.getDrawable(R.drawable.ic_dialog_remove_video))
//            }
//            MyAnnotations.AUDIOS -> {
//                imageView.setImageDrawable(popUpActivity.resources.getDrawable(R.drawable.ic_dialog_remove_audio))
//            }
//            MyAnnotations.DOCUMENTS -> {
//                imageView.setImageDrawable(popUpActivity.resources.getDrawable(R.drawable.ic_dialog_remove_document))
//            }
//            MyAnnotations.OTHER -> {
//                imageView.setImageDrawable(popUpActivity.resources.getDrawable(R.drawable.ic_dialog_remove_other))
//            }
//            else -> {
//                imageView.setImageDrawable(popUpActivity.resources.getDrawable(R.drawable.ic_dialog_remove_other))
//            }
//        }

        val tv1 = dialog.findViewById<TextView>(R.id.cleaned_photo)
        tv1.setTextColor(ViewCompat.MEASURED_STATE_MASK)
        tv1.text = str1
        val tv2 = dialog.findViewById<TextView>(R.id.cleaned_memory)
        tv2.setTextColor(ViewCompat.MEASURED_STATE_MASK)
        tv2.text = str2
        dialog.findViewById<View>(R.id.dialogButtonok).setOnClickListener {
            var updateMainDuplicateFound = 0
            val numberOfFiles: Int = deletedFileCount
            when (isType) {
                MyAnnotations.IMAGES -> {
                    if (GlobalVarsAndFunctions.listOfDuplicates != null) {
                        updateMainDuplicateFound = GlobalVarsAndFunctions.listOfDuplicates!!.size - numberOfFiles
                    }
                    totalDuplicatePhotos -= numberOfFiles
                }
                MyAnnotations.VIDEOS -> {
                    if (GlobalVarsAndFunctions.listOfDuplicates != null) {
                        updateMainDuplicateFound = GlobalVarsAndFunctions.listOfDuplicates!!.size - numberOfFiles
                    }
                    totalDuplicateVideos -= numberOfFiles
                }
                MyAnnotations.AUDIOS -> {
                    if (GlobalVarsAndFunctions.listOfDuplicates != null) {
                        updateMainDuplicateFound = GlobalVarsAndFunctions.listOfDuplicates!!.size - numberOfFiles
                    }
                    totalDuplicateAudios -= numberOfFiles
                }
                MyAnnotations.DOCUMENTS -> {
                    if (GlobalVarsAndFunctions.listOfDuplicates != null) {
                        updateMainDuplicateFound = GlobalVarsAndFunctions.listOfDuplicates!!.size - numberOfFiles
                    }
                    totalDuplicateDocuments -= numberOfFiles
                }
                MyAnnotations.OTHER -> {
                    if (GlobalVarsAndFunctions.listOfDuplicates != null) {
                        updateMainDuplicateFound = GlobalVarsAndFunctions.listOfDuplicates!!.size - numberOfFiles
                    }
                    totalDuplicateDocuments -= numberOfFiles
                }
//                "Other" -> {
//                    if (DuplicateOthersActivity.groupOfDupes != null) {
//                        updateMainDuplicateFound = DuplicateOthersActivity.groupOfDupes!!.size - numberOfFiles
//                    }
//                    totalDuplicateOthers -= numberOfFiles
//                }
            }
            imagesMarkedListener.updateDuplicateFound(updateMainDuplicateFound)
            imagesMarkedListener.cleaned(numberOfFiles)
            imagesMarkedListener.updatePageDetails(null, null, 0, null)
            imagesMarkedListener.updateMarked()
            GlobalVarsAndFunctions.resetDeleteClickAction_temp = GlobalVarsAndFunctions.resetDeleteClickAction
            GlobalVarsAndFunctions.resetDeleteClickAction++
            if (GlobalVarsAndFunctions.resetDeleteClickAction_temp == 0) {
                if (getMandatoryRateUsPopUsFlag(popUpContext)) {
                    setMandatoryRateUsPopUsFlag(popUpContext, false)
                } else if (getRateUsPopUpLimit(popUpContext) <= 2) {
                    setMandatoryRateUsPopUsFlag(popUpContext, true)
                    setRateUsPopUpLimit(popUpContext, getRateUsPopUpLimit(popUpContext) + 1)
                }
            }

            val isRated = ExitSPHelper(popUpContext).isRated()
                if (!isRated) {
                    if (SharedPrefsConstant.getInt(popUpContext, ShareConstants.RATE_DUPLICATE_COUNT) >=3 ) {
                        RatingDialog.smileyRatingDialog(popUpActivity)
                    } else {
                    }
                }
            SharedPrefsConstant.savePrefNoti(popUpContext, "isDeleteFromEmpty", false)
            dialog.cancel()
        }
        dialog.findViewById<View>(R.id.dialogButtonrescan).setOnClickListener {
            val numberOfFiles = 0
//            var intent = Intent(popUpActivity, ActivityDuplicateFileScanner::class.java)
            var intent = Intent(popUpActivity, NewDuplicateMediaActivityNEW::class.java)
//            val intent = Intent(popUpActivity, ScanningActivity::class.java)
            when (isType) {
                MyAnnotations.IMAGES -> {
                    GlobalVarsAndFunctions.fileToBeDeleted.clear()
                    GlobalVarsAndFunctions.size_Of_File_images = 0
                    totalDuplicatePhotos = 0
                    intent.putExtra(MyAnnotations.DATA_TYPE, MyAnnotations.IMAGES)
                }
                MyAnnotations.VIDEOS -> {
                    GlobalVarsAndFunctions.fileToBeDeleted.clear()
                    GlobalVarsAndFunctions.size_Of_File_videos = 0
                    totalDuplicateVideos = 0
                    intent.putExtra(MyAnnotations.DATA_TYPE, MyAnnotations.VIDEOS)
                }
                MyAnnotations.AUDIOS -> {
                    GlobalVarsAndFunctions.fileToBeDeleted.clear()
                    GlobalVarsAndFunctions.size_Of_File_audios = 0
                    totalDuplicateAudios = 0
                    intent.putExtra(MyAnnotations.DATA_TYPE, MyAnnotations.AUDIOS)
                }
                MyAnnotations.DOCUMENTS -> {
                    GlobalVarsAndFunctions.fileToBeDeleted.clear()
                    GlobalVarsAndFunctions.size_Of_File_documents = 0
                    totalDuplicateDocuments = 0
                    intent.putExtra(MyAnnotations.DATA_TYPE, MyAnnotations.DOCUMENTS)
                }
                MyAnnotations.OTHER -> {
                    GlobalVarsAndFunctions.fileToBeDeleted.clear()
                    GlobalVarsAndFunctions.size_Of_File_documents = 0
                    totalDuplicateDocuments = 0
                    intent.putExtra(MyAnnotations.DATA_TYPE, MyAnnotations.OTHER)
                }
            }
            imagesMarkedListener.cleaned(numberOfFiles)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            popUpActivity.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(popUpContext,android.R.anim.fade_in, android.R.anim.fade_out).toBundle())
            popUpActivity.finish()
            SharedPrefsConstant.savePrefNoti(popUpContext, "isDeleteFromEmpty", false)
            dialog.cancel()
        }
        dialog.show()
    }

    fun deleteAlertPopUp(mType: String?, alertMessage: String?, dialogMessage: String, fileToBeDeleted: ArrayList<ItemDuplicateModel>?, deletingFileSize: Long, groupOfDuplicates: List<IndividualGroupModel>, imagesMarkedListener: MarkedListener) {

        val dialog = Dialog(popUpActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

//        dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(popUpActivity.resources.getDrawable(R.drawable.ic_dialog_delete))
        dialog.findViewById<TextView>(R.id.permission).text = popUpContext.getString(R.string.delete_alert_title)
        dialog.findViewById<TextView>(R.id.permission_text).text = alertMessage
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = popUpActivity.getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = popUpActivity.getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            SharedPrefsConstant.savePrefNoti(popUpContext, "isDeleteFromEmpty", true)
            if (fileToBeDeleted != null) {
                DeleteDuplicateFileAsyncTask(mType, popUpContext, popUpActivity, imagesMarkedListener, dialogMessage, fileToBeDeleted, deletingFileSize, groupOfDuplicates).execute()
                SharedPrefsConstant.save(popUpContext, ShareConstants.RATE_DUPLICATE_COUNT, SharedPrefsConstant.getInt(popUpContext, ShareConstants.RATE_DUPLICATE_COUNT) + 1)

            }
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
        }
        dialog.show()
    }

    companion object {
        @JvmStatic
        fun sortByPhotosDateAscending(listOfIndividualGroups: List<IndividualGroupModel>?): List<IndividualGroupModel>? {
            if (listOfIndividualGroups != null) {
                for (i in listOfIndividualGroups.indices) {
                    val imageItems = listOfIndividualGroups[i].individualGrpOfDupes
                    if (imageItems != null) {
                        @Suppress("JavaCollectionsStaticMethodOnImmutableList")
                        Collections.sort(imageItems) { lhs: ItemDuplicateModel, rhs: ItemDuplicateModel ->
                            Date(rhs.fileDateAndTime).compareTo(Date(lhs.fileDateAndTime))
                        }
                    }
                    listOfIndividualGroups[i].individualGrpOfDupes = imageItems
                }
            }
            return listOfIndividualGroups
        }
    }
}