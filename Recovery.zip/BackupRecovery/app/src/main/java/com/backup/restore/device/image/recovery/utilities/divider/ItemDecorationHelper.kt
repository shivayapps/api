package com.backup.restore.device.image.recovery.utilities.divider

import android.content.Context
import androidx.recyclerview.widget.RecyclerView

object ItemDecorationHelper {

    fun getSimpleLinerSpaceItemDecoration(
        context: Context,
        layoutOrientation: Int,
        headSpace: Int,
        footerSpace: Int,
        itemSpace: Int
    ): RecyclerView.ItemDecoration {
        return LinerItemDecoration.Builder(context, layoutOrientation)
            .setRecyclerViewTopSpacePx(headSpace)
            .setRecyclerViewBottomSpacePx(footerSpace)
            .setDividerWidthPx(itemSpace)
            .setIsOnlySpace(true)
            .setIgnoreFootItemCount(1)
            .build()
    }

    /**
     * Get the space divider of the grid
     */
    fun getSimpleGridSpaceITemDecoration(
        context: Context,
        layoutOrientation: Int,
        headSpace: Int,
        footerSpace: Int,
        itemSpace: Int
    ): RecyclerView.ItemDecoration {
        return GridItemDecoration
            .Builder(context, layoutOrientation)
            .setRecyclerViewTopSpacePx(headSpace)
            .setRecyclerViewBottomSpacePx(footerSpace)
            .setDividerWidthPx(itemSpace)
            .setIsOnlySpace(true)
            .build()
    }
}