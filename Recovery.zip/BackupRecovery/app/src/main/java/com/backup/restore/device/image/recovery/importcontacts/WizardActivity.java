package com.backup.restore.device.image.recovery.importcontacts;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.backup.restore.device.image.recovery.R;

public class WizardActivity extends AppCompatActivity
{
	private Class< ? > _next_class;

	@Override
	protected void onCreate( Bundle saved_instance_state )
	{
		super.onCreate( saved_instance_state );

		// enable back button based on intent data
		Bundle extras = getIntent().getExtras();
		if( extras != null )//&& extras.getBoolean( "back-enabled" ) )
			( (Button)findViewById( R.id.back ) ).setEnabled( true );

		// set up back button
		Button back = (Button)findViewById( R.id.back );
		back.setOnClickListener( new View.OnClickListener() {
			public void onClick( View view ) {
				onBack();
			}
		} );
	}

	@Override
	protected void onActivityResult( int request_code, int result_code, Intent data ) {
		super.onActivityResult(request_code, result_code, data);
		if (result_code == RESULT_OK) {
			setResult(RESULT_OK);
			finish();
		}
	}

	protected void onNext()
	{
		// create bundle with back enabled state
		Bundle bundle = new Bundle();
		bundle.putBoolean( "back-enabled", true );
		Intent i = new Intent( this, _next_class );
		i.putExtras( bundle );

		// start next activity
		startActivityForResult( i, 0 );
	}

	protected void onBack()
	{
		setResult( RESULT_CANCELED );
		finish();
	}


	public SharedPreferences getSharedPreferences()
	{
		return super.getSharedPreferences( "ImportContacts", 0 );
	}

	@Override
	public void onConfigurationChanged( Configuration new_config ) {
		super.onConfigurationChanged( new_config );
	}
}
