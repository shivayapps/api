@file:Suppress("DEPRECATION")

package com.backup.restore.device.image.recovery.mainduplicate.activity.scanningactivities

import android.Manifest
import android.app.AlertDialog
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.View.GONE
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.main.NewHomeActivity
import com.backup.restore.device.image.recovery.mainduplicate.activity.duplicateactivities.EmptyFolderActivity
import com.backup.restore.device.image.recovery.mainduplicate.model.EmptyFolderModel
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.checkPermissionStorage
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.google.gson.Gson
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlinx.android.synthetic.main.activity_scanning.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class EmptyFolderScanningActivity : MyCommonBaseActivity() {

    val mTAG: String = javaClass.simpleName

    var mPermissionStorage = arrayOf(
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    )
    var mEmptyFolderList = ArrayList<EmptyFolderModel>()
    var mGetEmptyFolder: AsyncTask<*, *, *>? = null
    var isFromOneSignal = false

    var mIsScanningDone = false
    var isPause = false
    var count = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scanning)
    }

    override fun getContext(): AppCompatActivity {
        return this@EmptyFolderScanningActivity
    }

    override fun initData() {
//        tvCount.visibility = GONE

        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }
        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            checkAllFilePermission()
        } else {
            if (checkPermissionStorage(mContext)) {
                mGetEmptyFolder = GetEmptyFolder().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
            } else {
                givePermissions(mPermissionStorage)
            }
        }

        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            NativeAdvancedModelHelper(mContext).loadNativeAdvancedAd(
                NativeAdsSize.Big,
                findViewById(R.id.ad_view_container)!!
            )
        } else {
            findViewById<FrameLayout>(R.id.ad_view_container).visibility = GONE
        }

        tvCount!!.visibility = View.VISIBLE
        //tvScanning_1!!.text = count[1]
        tvScanning_2!!.visibility = View.VISIBLE
        process_dots!!.visibility = View.GONE
//        randomQuotes()

    }

    private fun randomQuotes() {
        val listOptions: Array<String> = mContext.resources.getStringArray(R.array.quotes_array)
        val random = Random().nextInt(listOptions.size)
        tvScanning_1.text = listOptions[random]
        if (!isDestroyed) {
            Handler().postDelayed({
                randomQuotes()
            }, 8000)
        }
    }

    override fun initActions() {
        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            InterstitialAdHelper.loadInterstitialAd(fContext = mContext)
        } else {
            findViewById<FrameLayout>(R.id.ad_view_container).visibility = GONE
        }
    }

    inner class GetEmptyFolder : AsyncTask<Void?, String?, ArrayList<EmptyFolderModel>>() {
        var moProgressDialog: AlertDialog? = null

        override fun onPreExecute() {
            mEmptyFolderList.clear()
        }

        override fun doInBackground(vararg voids: Void?): java.util.ArrayList<EmptyFolderModel> {
            mEmptyFolderList = getAllEmpty(ShareConstants.mRootPath)  //14sec
            return mEmptyFolderList
        }

        override fun onProgressUpdate(vararg values: String?) {
            super.onProgressUpdate(*values)
            tvCount.text = values[0].toString()

        }

        fun getAllEmpty(str: String): ArrayList<EmptyFolderModel> {
            val fold = File(str)

                val mlistAll = fold.listFiles()
                if (mlistAll != null && mlistAll.isNotEmpty()) {
                    val mlist = mlistAll.filter {
                        it.isDirectory || !it.startsWith("/storage/emulated/0/Android/data") || !it.startsWith(
                            "/storage/emulated/0/Android/obb"
                        )
                    }
                    for (f in mlist) {
                        getAllEmpty(f.absolutePath)
                    }
                }
                else {
                    if (fold.isDirectory) {
                        if (!fold.toString().startsWith("/storage/emulated/0/Android/data")
                            && !fold.toString().startsWith("/storage/emulated/0/Android/obb")
                        ) {
                            val doc = EmptyFolderModel()
                            doc.path = fold.absolutePath
                            doc.isCheckBox = true
                            Log.e("Utils", "getAllEmptyNew:getPath_002:" + fold.path)
                            mEmptyFolderList.add(doc)
                            publishProgress("${mEmptyFolderList.size.toString()}")
                        }
                    }
                }
            return mEmptyFolderList
        }

        override fun onPostExecute(lEmptyFolderList: ArrayList<EmptyFolderModel>) {
            mIsScanningDone = true
            Log.e(mTAG, "onPostExecute: " + lEmptyFolderList.size)
            if (lEmptyFolderList.size <= 0) {
                redirectActivity(mEmptyFolderList)
            } else {
                var lFinalDate = Date()
                val cal = Calendar.getInstance()
                cal.time = lFinalDate
                lFinalDate = cal.time
                val zero: Long = 0

                val dateFormat = SimpleDateFormat("dd/MM/yyyy")
                when {
//                    SharedPrefsConstant.getString(mContext,"IsLastScanDate") == dateFormat.format(lFinalDate) -> {
                    SharedPrefsConstant.getLong(
                        mContext,
                        "IsLastScanMillis"
                    ) <= cal.timeInMillis -> {
                        industrialAds(lEmptyFolderList)
                    }
//                    SharedPrefsConstant.getString(mContext,"IsLastScanDate").equals("") -> {
                    SharedPrefsConstant.getLong(mContext, "IsLastScanMillis") == zero -> {
                        industrialAds(lEmptyFolderList)
                    }
                    else -> {
                        redirectActivity(mEmptyFolderList)
                    }
                }
            }
        }
    }


    private fun gridRecoverableAlbumImage(
        directoryPath: String,
        moProgressDialog: AlertDialog?
    ): ArrayList<EmptyFolderModel> {
        val files = File(directoryPath).listFiles()

//        Log.e(mTAG, "gridRecoverableAlbumImage: directoryPath -> $directoryPath")
        if (files != null) {
            for (file in files) {
                if (file.isDirectory && !file.toString()
                        .startsWith("/storage/emulated/0/Android/data")
                    && !file.toString().startsWith("/storage/emulated/0/Android/obb")
                    && !file.toString().startsWith("/storage/emulated/0/Backup And Recovery")
                ) {
//                    Log.e(mTAG, "gridRecoverableAlbumImage: file -> $file")
                    val children = file.listFiles()
//                    Log.e(mTAG, "gridRecoverableAlbumImage: children ---> ${Gson().toJson(children)}")
                    if (children != null) {
                        if (children.isEmpty()) {
                            if (file.name != "Pictures" && file.name != "Documents" && file.name != "Music" && file.name != "Movies" && file.name != "Download" && file.name != "DCIM") {
                                val mEmptyFolderModel = EmptyFolderModel()
                                mEmptyFolderModel.path = file.path
                                mEmptyFolderModel.isCheckBox = true
                                mEmptyFolderList.add(mEmptyFolderModel)
                            }
                        }
                    }
                    gridRecoverableAlbumImage(file.path, moProgressDialog)
                    count++
                    Log.e(mTAG, "gridRecoverableAlbumImage: $count")
                    runOnUiThread {
                        tvCount.text = count.toString()
                    }
                }

            }
        }

        return mEmptyFolderList
    }

    private fun givePermissions(permissions: Array<String>) {

        MyApplication.isInternalCall = true

        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                mGetEmptyFolder = GetEmptyFolder().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionStorage)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest>,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            }).check()
    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                mGetEmptyFolder = GetEmptyFolder().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                try {
                    MyApplication.isInternalCall = true
                    startActivityForResult(intent, 2296)
                } catch (e: ActivityNotFoundException) {
                }
            }
        }
    }

    fun showSettingsDialog() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            openSettings()
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            if (isFromOneSignal) {
                startActivity(NewHomeActivity.newIntent(this))
                finish()
            } else {
                finish()
            }
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//            givePermissions(mPermissionStorage)
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun openSettings() {
        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        MyApplication.isInternalCall = true
        startActivityForResult(intent, 200)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    mGetEmptyFolder =
                        GetEmptyFolder().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                } else {
                    if (isFromOneSignal) {
                        startActivity(NewHomeActivity.newIntent(this))
                    }
                    finish()
                    Toast.makeText(
                        mContext,
                        getString(R.string.permission_required),
                        Toast.LENGTH_SHORT
                    ).show()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            }
        } else if (requestCode == 200) {
            if (checkPermissionStorage(mContext)) {
                mGetEmptyFolder = GetEmptyFolder().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
            } else {
                if (isFromOneSignal) {
                    startActivity(NewHomeActivity.newIntent(this))
                }
                finish()
                Toast.makeText(
                    mContext,
                    getString(R.string.permission_required),
                    Toast.LENGTH_SHORT
                ).show()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
        }
    }


    private fun redirectActivity(mEmptyFolderList: ArrayList<EmptyFolderModel>) {
        Log.e(mTAG, "redirectActivity: ")
        mIsScanningDone = false
        startActivity(
            Intent(mContext, EmptyFolderActivity::class.java)
                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra("mEmptyFolderListFinal", Gson().toJson(mEmptyFolderList))
                .putExtra("IsCheckOneSignalNotification", isFromOneSignal)
        )
        finish()
    }

    private fun industrialAds(mEmptyFolderList: ArrayList<EmptyFolderModel>) {
        Log.e(mTAG, "industrialAds: ")
        if (AdsManager(mContext).isNeedToShowAds()) {
            if (!SharedPrefsConstant.getBoolean(
                    mContext,
                    SharedPrefsConstant.IS_APP_IN_BACKGROUND,
                    true
                )
            ) {
                MyApplication.isInterstitialShown = true
                mContext.isShowInterstitialAd { isShowFullScreenAd ->
                    Log.e(mTAG, "onClick: isShowFullScreenAd::$isShowFullScreenAd")
                    MyApplication.isInterstitialShown = false
                    redirectActivity(mEmptyFolderList)
                }
            }
            Log.e(mTAG, "industrialAds:show ")
        } else {
            Log.e(mTAG, "industrialAds: call 2")
            redirectActivity(mEmptyFolderList)
        }
    }

    override fun onBackPressed() {
        showAlertStopScanning()
    }

    private fun showAlertStopScanning() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<TextView>(R.id.permission).text =
            mContext.getString(R.string.exit_scanning)
        dialog.findViewById<TextView>(R.id.permission_text).text =
            mContext.getString(R.string.scanning_stop)
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            mGetEmptyFolder!!.cancel(true)
            MyApplication.isDialogOpen = false
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
    }

    override fun onPause() {
        super.onPause()
        isPause = true
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()

        Log.e(mTAG, "onResume: $mIsScanningDone")

//       if (mIsScanningDone) {
//            redirectActivity(mEmptyFolderList)
//        }
    }

}