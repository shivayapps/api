package com.backup.restore.device.image.recovery.database;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Log;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import com.backup.restore.device.image.recovery.mainduplicate.model.AppHistory;
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateContactModel;
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateNumberListModel;
import com.backup.restore.device.image.recovery.mainduplicate.model.IgnorePath;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class DBAdapter extends SQLiteOpenHelper {

    public static String TAG = "DBAdapter";
    private static final int DATABASE_VERSION = 12;
    // Database Name
    private static final String DATABASE_NAME = "contacts.sql";

    private static final String TABLE_FAVOURITE = "contacts";
    public static final String KEY_ID = "fav_id";
    public static final String KEY_NAME = "fav_name";
    public static final String KEY_NUMBER = "fav_number";

    private static final String TABLE_HIDE = "contacts_hide";
    public static final String KEY_HIDE_ID = "hide_Id";
    public static final String KEY_HIDE_NAME = "hide_name";
    public static final String KEY_HIDE_NUMBER = "hide_number";
    public static final String KEY_HIDE_IMAGE = "hide_image";
    public static final String APP_HISTORY = "app_history";
    public static final String IGNORE_PATH = "ignore_path";

    public static final String DUPLICATION_REMOVE = "ContactsToSave";
    public static final String NUMBER = "duplicate_number";
    public static final String NAME = "duplicate_name";
    public static final String EMAIL = "duplicate_email";
    public static final String LOOKUP_KEY = "duplicate_LookUpKey";
    public static final String CONTACT_ID = "duplicate_contact_id";
    public static final String RAW_ID = "raw_contact_id";
    Context mContext;
    private ColorGenerator mColorGenerator = ColorGenerator.MATERIAL;

    public DBAdapter(Context context) {
        super(context, "/data/data/com.backup.restore.device.image.recovery/databases/MyData/" + DATABASE_NAME, null, DATABASE_VERSION);
        this.mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.e(TAG, "onCreate: ");
        db.execSQL("CREATE TABLE " + TABLE_FAVOURITE + "(" + KEY_NUMBER + " TEXT," + KEY_NAME + " TEXT," + KEY_ID + " INTEGER" + ");");
        db.execSQL("CREATE TABLE " + DUPLICATION_REMOVE + "(" + NUMBER + " TEXT," + NAME + " TEXT," + EMAIL + " TEXT," + CONTACT_ID + " TEXT," + RAW_ID + " TEXT," + LOOKUP_KEY + " TEXT " + ");");
        db.execSQL("CREATE TABLE " + TABLE_HIDE + "(" + KEY_HIDE_NUMBER + " TEXT," + KEY_HIDE_NAME + " TEXT," + KEY_HIDE_IMAGE + " TEXT," + KEY_HIDE_ID + " INTEGER" + ");");
        db.execSQL("CREATE TABLE "
                + APP_HISTORY + "("
                + "app_id" + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "app_name" + " TEXT,"
                + "package_name" + " TEXT,"
                + "size" + " TEXT,"
                + "date" + " TEXT"
                + ");");
        db.execSQL("CREATE TABLE "
                + IGNORE_PATH + "("
                + "path_id" + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "name" + " TEXT,"
                + "path" + " TEXT"
                + ");");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.e(TAG, "newVersion: " + newVersion);
        Log.e(TAG, "oldVersion: " + oldVersion);

//        if(oldVersion == 6 || oldVersion == 7 || oldVersion == 8 || oldVersion == 9) {
//            Log.e(TAG, "onUpgrade: old ---> " + oldVersion  );
//        } else {
//            Log.e(TAG, "onUpgrade: new --> " + newVersion );
//            forUpdate(db);
//            onCreate(db);
//        }

        if (oldVersion < 6) {
            forUpdate(db);
            onCreate(db);
        }

        if (oldVersion < 11) {
            db.execSQL("CREATE TABLE "
                    + APP_HISTORY + "("
                    + "app_id" + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "app_name" + " TEXT,"
                    + "package_name" + " TEXT,"
                    + "size" + " TEXT,"
                    + "date" + " TEXT"
                    + ");");
        }
        if (oldVersion < 12) {
            db.execSQL("CREATE TABLE "
                    + IGNORE_PATH + "("
                    + "path_id" + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "name" + " TEXT,"
                    + "path" + " TEXT"
                    + ");");
        }
    }

    private static void forUpdate(SQLiteDatabase db) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FAVOURITE);
        db.execSQL("DROP TABLE IF EXISTS " + DUPLICATION_REMOVE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HIDE);
    }


    public void saveFavoriteContact(String name, String number, String id) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(KEY_ID, id);
            values.put(KEY_NAME, name);
            values.put(KEY_NUMBER, number);
            db.insert(TABLE_FAVOURITE, null, values);
            Log.e("added", "added");
            db.close();
        } catch (Exception t) {
            Log.i("Database", "Exception caught: " + t.getMessage(), t);
        }
    }

    public void deleteFavContactDetails(String number) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            db.delete(TABLE_FAVOURITE, KEY_ID + " = ?", new String[]{number});
            Log.e("deleted", "deleted");
            db.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateDetails(String name, String number, String id) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(KEY_ID, id);
            values.put(KEY_NAME, name);
            values.put(KEY_NUMBER, number);
            db.update(TABLE_FAVOURITE, values, KEY_ID + " = ?", new String[]{id});
            db.close();
            Log.e("updateDetails", "updateDetails");

        } catch (Exception t) {
            Log.e("Database", "Exception caught: " + t.getMessage(), t);
        }
    }

    public Cursor getFavData() {
        SQLiteDatabase db = getReadableDatabase();
        String selectQuery = "SELECT  * FROM " + TABLE_FAVOURITE;
        return db.rawQuery(selectQuery, null);
    }

    public void saveContacts(String id, String raw_contact_id, String number, String name, String email, String lLookUpKey) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(CONTACT_ID, id);
            values.put(RAW_ID, raw_contact_id);
            values.put(NUMBER, number);
            values.put(NAME, name);
            values.put(EMAIL, email);
            values.put(LOOKUP_KEY, lLookUpKey);
            boolean cnt = isAvailable(lLookUpKey);
            if (!cnt) {
                db.insert(DUPLICATION_REMOVE, null, values);
                db.close();
            }
        } catch (Exception t) {
            Log.e("Database", "Exception caught: " + t.getMessage(), t);
        }
    }

    public void deleteAll() {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM " + DUPLICATION_REMOVE);
        db.close();
    }

    private boolean isAvailable(String lLookUpKey) {
        SQLiteDatabase db = getReadableDatabase();
        String selectQuery = "SELECT  " + NUMBER + " FROM " + DUPLICATION_REMOVE + " WHERE " + LOOKUP_KEY + " = '" + lLookUpKey + "';";
        Cursor cursor = db.rawQuery(selectQuery, null);
        return cursor.getCount() > 0;
    }


    public ArrayList<AppHistory> getAppHistory() {
        Log.e("DBAdapter", "getAppHistory");
        ArrayList<AppHistory> mList = new ArrayList<>();
        try {
            SQLiteDatabase db = getReadableDatabase();
            String selectQuery = "SELECT * FROM " + APP_HISTORY ;
            Cursor cursor = db.rawQuery(selectQuery, null);
            while (cursor.moveToNext()) {

                long app_id = cursor.getLong(cursor.getColumnIndex("app_id"));
                String app_name = cursor.getString(cursor.getColumnIndex("app_name"));
                String packageName = cursor.getString(cursor.getColumnIndex("package_name"));
                String size = cursor.getString(cursor.getColumnIndex("size"));
                String date = cursor.getString(cursor.getColumnIndex("date"));

                Log.e("DBAdapter", "getAppHistory name:"+app_name+" :: packageName:"+packageName+" :: size:"+size+" :: date:"+date);

                AppHistory appHistory=new AppHistory();
                appHistory.setAppId(app_id);
                appHistory.setAppName(app_name);
                appHistory.setPackageName(packageName);
                appHistory.setSize(size);
                appHistory.setDate(date);

                mList.add(appHistory);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            Log.e("DBAdapter", "getAppHistory.Exception:"+e);
            e.printStackTrace();
        }
        Collections.reverse(mList);

        return mList;
    }

    public void saveAppHistory(String name, String packageName, String size, String date) {
        Log.e("DBAdapter", "name:"+name+" :: packageName:"+packageName+" :: size:"+size+" :: date:"+date);
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
//            values.put("app_id", id);
            values.put("app_name", name);
            values.put("package_name", packageName);
            values.put("size", size);
            values.put("date", date);

            db.insert(APP_HISTORY, null, values);
            Log.e("DBAdapter", "saveAppHistory");
            db.close();
        } catch (Exception t) {
            Log.e("DBAdapter", "Exception caught: " + t.getMessage(), t);
        }
    }

    public void deleteAppHistory(String packageName) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            db.delete(APP_HISTORY, "package_name" + " = ?", new String[]{packageName});
            Log.e("DBAdapter", "deleteAppHistory");
            db.close();
        } catch (SQLException e) {
            Log.e("DBAdapter", "deleteAppHistory.SQLException:"+e);
            e.printStackTrace();
        }
    }

    public ArrayList<IgnorePath> getIgnoredPath() {
        Log.e("DBAdapter", "getIgnoredPath");
        ArrayList<IgnorePath> mList = new ArrayList<>();
        try {
            SQLiteDatabase db = getReadableDatabase();
            String selectQuery = "SELECT * FROM " + IGNORE_PATH ;
            Cursor cursor = db.rawQuery(selectQuery, null);
            while (cursor.moveToNext()) {

                long path_id = cursor.getLong(cursor.getColumnIndex("path_id"));
                String name = cursor.getString(cursor.getColumnIndex("name"));
                String path = cursor.getString(cursor.getColumnIndex("path"));

                IgnorePath appHistory=new IgnorePath();
                appHistory.setPathId(path_id);
                appHistory.setPath(path);
                appHistory.setName(name);

                mList.add(appHistory);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            Log.e("DBAdapter", "getIgnoredPath.Exception:"+e);
            e.printStackTrace();
        }
        Collections.reverse(mList);

        return mList;
    }

    public void saveIgnorePath(String name, String path) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
//            values.put("app_id", id);
            values.put("path", path);
            values.put("name", name);

            db.insert(IGNORE_PATH, null, values);
            Log.e("DBAdapter", "saveIgnorePath");
            db.close();
        } catch (Exception t) {
            Log.e("DBAdapter", "Exception caught: " + t.getMessage(), t);
        }
    }

    public void deleteIgnorePath(String pathId) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            db.delete(IGNORE_PATH, "path_id" + " = ?", new String[]{pathId});
            Log.e("DBAdapter", "deleteIgnorePath");
            db.close();
        } catch (SQLException e) {
            Log.e("DBAdapter", "deleteIgnorePath.SQLException:"+e);
            e.printStackTrace();
        }
    }

    public ArrayList<DuplicateNumberListModel> getContactsByNumber(boolean duplicateSelection) {
        ArrayList<DuplicateNumberListModel> mList = new ArrayList<>();
        try {
            SQLiteDatabase db = getReadableDatabase();
            String selectQuery = "SELECT DISTINCT " + NUMBER + " FROM " + DUPLICATION_REMOVE + " GROUP BY " + NUMBER;
            Cursor cursor = db.rawQuery(selectQuery, null);
            List<String> tempList = new ArrayList<>();
            Log.e("DuplicateContact", "getContactsByNumber: cursor.size:"+cursor.getCount());
            while (cursor.moveToNext()) {
                String number = cursor.getString(cursor.getColumnIndex(NUMBER));
                List<String> list = Arrays.asList(number.split(","));
                Log.e("DuplicateContact", "getContactsByNumber: list.size:"+list.size());
                for (int i = 0; i < list.size(); i++) {
                    if (!tempList.contains(list.get(i))) {
                        tempList.add(list.get(i));
                        ArrayList<DuplicateContactModel> duplicateList = getDuplicateListFromNumber(list.get(i));
                        if (duplicateList.size() > 1) {
                            DuplicateNumberListModel obj = new DuplicateNumberListModel();
                            obj.setMMainKey(number);
                            obj.setMNumberList(duplicateList);
                            obj.setFileCheckBox(duplicateSelection);
                            mList.add(obj);
                        }
                        break;
                    }
                    Log.e("DuplicateContact", "getContactsByNumber: i:"+i);
                }
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            Log.e("DuplicateContact", "getContactsByNumber: Exception 001:"+e);
            e.printStackTrace();
        }
        return mList;
    }

    public ArrayList<DuplicateContactModel> getDuplicateListFromNumber(String number) {
        ArrayList<DuplicateContactModel> duplicateList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String selectQuery = "SELECT * FROM " + DUPLICATION_REMOVE + " WHERE " + NUMBER + " like '%" + number + "%" + "';";
        Cursor cursor = db.rawQuery(selectQuery, null);
        while (cursor.moveToNext()) {
            String id = cursor.getString(cursor.getColumnIndex(CONTACT_ID));
            String raw_id = cursor.getString(cursor.getColumnIndex(RAW_ID));
            String name = cursor.getString(cursor.getColumnIndex(NAME));
            String mobileNo = cursor.getString(cursor.getColumnIndex(NUMBER));
            String email = cursor.getString(cursor.getColumnIndex(EMAIL));
            String lLookUpKey = cursor.getString(cursor.getColumnIndex(LOOKUP_KEY));
            Drawable mIcon = null;
            Uri uri = getPhotoUri(id);
            String mIconUri = "";
            if (uri != null)
                mIconUri = uri.toString();
            if (!name.isEmpty() && !TextUtils.isDigitsOnly(name.substring(0, 1))) {
                Typeface mTypeface = Typeface.createFromAsset(mContext.getAssets(), "app_font/firasans_medium.ttf");
                TextDrawable mDrawableBuilder = TextDrawable.builder()
                        .beginConfig()
                        .bold()
                        .useFont(mTypeface)
                        .height(50)
                        .width(50)
                        .endConfig()
                        .round().build(name.substring(0, 1).toUpperCase(), mColorGenerator.getColor(name));
                mIcon = mDrawableBuilder;
            }
            duplicateList.add(new DuplicateContactModel(id, raw_id, name, mobileNo, email, lLookUpKey, mIcon, mIconUri));
        }
        cursor.close();
        db.close();
        return duplicateList;
    }

    public ArrayList<DuplicateNumberListModel> getContactsByEmail(boolean duplicateSelection) {
        ArrayList<DuplicateNumberListModel> mList = new ArrayList<>();
        try {
            SQLiteDatabase db = getReadableDatabase();
            String selectQuery = "SELECT DISTINCT " + EMAIL + " FROM " + DUPLICATION_REMOVE + " GROUP BY " + EMAIL;
            Cursor cursor = db.rawQuery(selectQuery, null);
            List<String> tempList = new ArrayList<>();
            Log.e("DuplicateContact", "getContactsByEmail: cursor.size:"+cursor.getCount());
            while (cursor.moveToNext()) {
                String email = cursor.getString(cursor.getColumnIndex(EMAIL));
                List<String> list = Arrays.asList(email.split(","));
                Log.e("DuplicateContact", "getContactsByEmail: list.size:"+list.size());
                for (int i = 0; i < list.size(); i++) {
                    Log.e("DuplicateContact", "getContactsByEmail: i:"+i);
                    if (!tempList.contains(list.get(i)) && list.get(i) != "") {
                        tempList.add(list.get(i));
                        ArrayList<DuplicateContactModel> duplicateList = getDuplicateListFromEmail(list.get(i));
                        if (duplicateList.size() > 1) {
                            DuplicateNumberListModel obj = new DuplicateNumberListModel();
                            obj.setMMainKey(email);
                            obj.setMNumberList(duplicateList);
                            obj.setFileCheckBox(duplicateSelection);
                            mList.add(obj);
                        }
                        break;
                    }
                }
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            Log.e("DuplicateContact", "getContactsByEmail: Exception 001:"+e);
            e.printStackTrace();
        }
        return mList;
    }


    public ArrayList<DuplicateContactModel> getDuplicateListFromEmail(String emails) {
        ArrayList<DuplicateContactModel> duplicateList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String selectQuery = "SELECT * FROM " + DUPLICATION_REMOVE + " WHERE " + EMAIL + " like '%" + emails + "%" + "';";
        Cursor cursor = db.rawQuery(selectQuery, null);
        while (cursor.moveToNext()) {
            String id = cursor.getString(cursor.getColumnIndex(CONTACT_ID));
            String raw_id = cursor.getString(cursor.getColumnIndex(RAW_ID));
            String name = cursor.getString(cursor.getColumnIndex(NAME));
            String mobileNo = cursor.getString(cursor.getColumnIndex(NUMBER));
            String email = cursor.getString(cursor.getColumnIndex(EMAIL));
            String lLookUpKey = cursor.getString(cursor.getColumnIndex(LOOKUP_KEY));
            Drawable mIcon = null;
            Uri uri = getPhotoUri(id);
            String mIconUri = "";
            if (uri != null)
                mIconUri = uri.toString();
            if (!name.isEmpty() && !TextUtils.isDigitsOnly(name.substring(0, 1))) {
                Typeface mTypeface = Typeface.createFromAsset(mContext.getAssets(), "app_font/firasans_medium.ttf");
                TextDrawable mDrawableBuilder = TextDrawable.builder()
                        .beginConfig()
                        .bold()
                        .useFont(mTypeface)
                        .height(50)
                        .width(50)
                        .endConfig()
                        .round().build(name.substring(0, 1).toUpperCase(), mColorGenerator.getColor(name));
                mIcon = mDrawableBuilder;
            }
            duplicateList.add(new DuplicateContactModel(id, raw_id, name, mobileNo, email, lLookUpKey, mIcon, mIconUri));
        }
        cursor.close();
        db.close();
        return duplicateList;
    }

    public ArrayList<DuplicateNumberListModel> getContactsByName(boolean duplicateSelection) {
        ArrayList<DuplicateNumberListModel> mList = new ArrayList<>();
        try {
            SQLiteDatabase db = getReadableDatabase();
            String selectQuery = "SELECT DISTINCT " + NAME + " FROM " + DUPLICATION_REMOVE + " GROUP BY " + NAME;
            Cursor cursor = db.rawQuery(selectQuery, null);

            int i=0;
            Log.e("DuplicateContact", "getContactsByName: list.size:"+cursor.getCount());
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndex(NAME));
                ArrayList<DuplicateContactModel> duplicateList = getDuplicateListFromName(name.replace("'", ""));
                if (duplicateList.size() > 1) {
                    DuplicateNumberListModel obj = new DuplicateNumberListModel();
                    obj.setMMainKey(name);
                    obj.setMNumberList(duplicateList);
                    obj.setFileCheckBox(duplicateSelection);
                    mList.add(obj);
                }
                Log.e("DuplicateContact", "getContactsByName: i:"+i++);
            }
            cursor.close();
            db.close();
        } catch (Exception e) {
            Log.e("DuplicateContact", "getContactsByName: Exception 001:"+e);
            e.printStackTrace();
        }
        return mList;
    }

    public ArrayList<DuplicateContactModel> getDuplicateListFromName(String name) {
        ArrayList<DuplicateContactModel> duplicateList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String selectQuery = "SELECT * FROM " + DUPLICATION_REMOVE + " WHERE " + NAME + " like '" + name + "';";
        Cursor cursor = db.rawQuery(selectQuery, null);
        Log.e("DuplicateContact", "getDuplicateListFromName: list.size:"+cursor.getCount());
        int i=0;
        while (cursor.moveToNext()) {
            String id = cursor.getString(cursor.getColumnIndex(CONTACT_ID));
            String raw_id = cursor.getString(cursor.getColumnIndex(RAW_ID));
            String names = cursor.getString(cursor.getColumnIndex(NAME));
            String mobileNo = cursor.getString(cursor.getColumnIndex(NUMBER));
            String email = cursor.getString(cursor.getColumnIndex(EMAIL));
            String lLookUpKey = cursor.getString(cursor.getColumnIndex(LOOKUP_KEY));
            Drawable mIcon = null;
            Uri uri = getPhotoUri(id);
            String mIconUri = "";
            if (uri != null)
                mIconUri = uri.toString();
            if (!name.isEmpty() && !TextUtils.isDigitsOnly(name.substring(0, 1))) {
                Typeface mTypeface = Typeface.createFromAsset(mContext.getAssets(), "app_font/firasans_medium.ttf");
                TextDrawable mDrawableBuilder = TextDrawable.builder()
                        .beginConfig()
                        .bold()
                        .useFont(mTypeface)
                        .height(50)
                        .width(50)
                        .endConfig()
                        .round().build(name.substring(0, 1).toUpperCase(), mColorGenerator.getColor(name));
                mIcon = mDrawableBuilder;
            }
            duplicateList.add(new DuplicateContactModel(id, raw_id, names, mobileNo, email, lLookUpKey, mIcon, mIconUri));
            Log.e("DuplicateContact", "getDuplicateListFromName: i:"+i++);
        }
        cursor.close();
        db.close();
        return duplicateList;
    }

    private Uri getPhotoUri(String photo) {
        try {
            Cursor cur = mContext.getContentResolver().query(
                    ContactsContract.Data.CONTENT_URI,
                    null,
                    ContactsContract.Data.CONTACT_ID + "=" + photo + " AND " + ContactsContract.Data.MIMETYPE + "='" + ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE + "'",
                    null,
                    null
            );
            if (cur != null) {
                if (!cur.moveToFirst()) {
                    return null; // no photo
                }
            } else {
                return null; // error in cursor process
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        Uri person =
                ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, Long.parseLong(photo));
        return Uri.withAppendedPath(person, ContactsContract.Contacts.Photo.CONTENT_DIRECTORY);
    }

    public void saveHideContact(String name, String number, String id, String userImage) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(KEY_HIDE_ID, id);
            values.put(KEY_HIDE_NAME, name);
            values.put(KEY_HIDE_NUMBER, number);
            values.put(KEY_HIDE_IMAGE, userImage);
            db.insert(TABLE_HIDE, null, values);
            Log.e("added", "added");
            db.close();
        } catch (Exception t) {
            Log.i("Database", "Exception caught: " + t.getMessage(), t);
        }
    }

    public void deleteHideContactDetails(String number) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            db.delete(TABLE_HIDE, KEY_HIDE_ID + " = ?", new String[]{number});
            db.close();
            Log.e("deleted", "deleted");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public Cursor getHideData() {
        SQLiteDatabase db = getReadableDatabase();
        String selectQuery = "SELECT  * FROM " + TABLE_HIDE;
        return db.rawQuery(selectQuery, null);
    }
}