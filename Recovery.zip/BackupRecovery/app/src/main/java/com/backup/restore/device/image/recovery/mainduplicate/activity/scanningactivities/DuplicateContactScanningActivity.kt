@file:Suppress("DEPRECATION")

package com.backup.restore.device.image.recovery.mainduplicate.activity.scanningactivities

import android.Manifest
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.provider.Settings
import android.util.Log
import android.view.View.GONE
import android.view.View.INVISIBLE
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.database.DBAdapter
import com.backup.restore.device.image.recovery.main.NewHomeActivity
import com.backup.restore.device.image.recovery.mainduplicate.activity.duplicateactivities.DuplicateContactActivity
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateNumberListModel
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.checkPermissionContact
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant.*
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.example.jdrodi.utilities.camelCaseString
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlinx.android.synthetic.main.activity_scanning.*
import java.util.*


class DuplicateContactScanningActivity : MyCommonBaseActivity() {

    val mTAG: String = javaClass.simpleName

    var mPermissionDuplicate : Array<String> ? = null
    var mDuplicateNameList = ArrayList<DuplicateNumberListModel>()
    var mDuplicateNumberList = ArrayList<DuplicateNumberListModel>()
    var mDuplicateEmailList = ArrayList<DuplicateNumberListModel>()

    var mMainContactListAsyncTask: AsyncTask<*, *, *>? = null
    var isFromOneSignal = false

    var mIsScanningDone = false
    var mDBAdapter: DBAdapter? = null
    var isPause = false
    var count = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scanning)
    }

    override fun getContext(): AppCompatActivity {
        return this@DuplicateContactScanningActivity
    }

    override fun initData() {
        mPermissionDuplicate = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            arrayOf(Manifest.permission.WRITE_CONTACTS, Manifest.permission.READ_CONTACTS)
        } else {
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_CONTACTS,
                Manifest.permission.READ_CONTACTS
            )
        }

        mDBAdapter = DBAdapter(mContext)


//        tvCount.visibility = GONE
        tvScanning_2.setText(R.string.scanning_is_depend_on_contacts)
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }
        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()


        if (checkPermissionContact(mContext)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                checkAllFilePermission()
            } else {
                mMainContactListAsyncTask = ContactListData().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
            }
        } else {
            givePermissions(mPermissionDuplicate!!)
        }

        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            NativeAdvancedModelHelper(mContext).loadNativeAdvancedAd(
                NativeAdsSize.Big,
                findViewById(R.id.ad_view_container)!!
            )
        } else {
            findViewById<FrameLayout>(R.id.ad_view_container).visibility = GONE
        }
    }

    override fun initActions() {
        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            InterstitialAdHelper.loadInterstitialAd(fContext = mContext)
        }
    }

    private inner class ContactListData : AsyncTask<Void?, Void?, Void?>() {
        override fun onPreExecute() {
            super.onPreExecute()
//            mDuplicateList.clear()
//            mDuplicateNameList.clear()
//            mDuplicateNumberList.clear()
//            mDuplicateEmailList.clear()
//            mDuplicateNameListFinal.clear()
//            mDuplicateNumberListFinal.clear()
//            mDuplicateEmailListFinal.clear()
        }

        override fun doInBackground(vararg voids: Void?): Void? {
            mDuplicateNameList.clear()
            mDuplicateNumberList.clear()
            mDuplicateEmailList.clear()
            mDuplicateNameListFinal.clear()
            mDuplicateNumberListFinal.clear()
            mDuplicateEmailListFinal.clear()

            try {

                val cursor = contentResolver.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, "display_name ASC")
                if (cursor != null) {
                    while (cursor.moveToNext()) {
                        Log.e(mTAG, "doInBackground: moveToNext 001")
                        val id = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID))
                        val raw_contact_id = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.NAME_RAW_CONTACT_ID))
                        val lContactNumber: String = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))
                        if (lContactNumber.toInt() > 0) {
                            val pCur: Cursor? = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", arrayOf(id), null)
                            try {
                                while (pCur?.moveToNext() == true) {
                                    Log.e(mTAG, "doInBackground: moveToNext 002")
                                    var lDisplayName = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
                                    val lLookUpKey = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY))
                                    var phoneNo: String
                                    val lNumberList = StringBuilder()
                                    val pCurs = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", arrayOf(id), null)
//                                val pCurs: Cursor = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", arrayOf(id), null)!!
                                    try {
                                        if(pCurs!=null) {
                                            while (pCurs.moveToNext()) {
                                                phoneNo = pCurs.getString(pCurs.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
                                                    .replace("-", "")
                                                    .replace("(", "")
                                                    .replace(")", "")
                                                    .replace(" ", "")
                                                if (!lNumberList.contains("[$phoneNo]")) {
                                                    lNumberList.append("[")
                                                    lNumberList.append(phoneNo)
                                                    lNumberList.append("]")
                                                    lNumberList.append(",")
                                                }
                                            }
                                        }
                                    } catch (e : java.lang.Exception){

                                    } finally {
                                        pCurs?.close()
                                    }
                                    var lEmail: String
                                    val lEmailList = StringBuilder()
                                    val emails: Cursor? = contentResolver.query(ContactsContract.CommonDataKinds.Email.CONTENT_URI, null, ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?", arrayOf(id), null)!!
                                    if(emails != null) {
                                        try {
                                            while (emails.moveToNext()) {
                                                lEmail = emails.getString(emails.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA))
                                                if (!lEmailList.contains("[$lEmail]")) {
                                                    lEmailList.append("[")
                                                    lEmailList.append(lEmail)
                                                    lEmailList.append("]")
                                                    lEmailList.append(",")
                                                }
                                            }
                                        }catch (e : Exception){
                                            Log.e(mTAG, "doInBackground: Exception 001:"+e)

                                        }
                                        finally {
                                            emails.close()
                                        }
                                    }
                                    if(lDisplayName!=null) lDisplayName = camelCaseString(lDisplayName)
                                    else lDisplayName=""
                                    try {
                                        mDBAdapter!!.saveContacts(id, raw_contact_id, lNumberList.toString(), lDisplayName, lEmailList.toString(), lLookUpKey)
                                    } catch (e: java.lang.Exception) {
                                        Log.e(mTAG, "doInBackground: Exception 002:"+e)
                                        e.printStackTrace()
                                    }
                                }
                            } finally {
                                pCur?.close()
                            }
                        }
                        count++
                        Log.e(mTAG, "doInBackground: $count")
                        runOnUiThread {
                            tvCount.text = count.toString()
                        }
                    }
                    cursor.close()
                }
            } catch (e:Exception) {
                Log.e(mTAG, "doInBackground: Exception 001:"+e)

            }

            runOnUiThread {
                tvScanning_2.visibility = INVISIBLE
                tvScanning_1.text = getString(R.string.please_wait)
                tvCount.visibility = GONE
                randomQuotes()
            }


            try {

//            mDuplicateList = mDBAdapter!!.allContact
                val duplicateSelection=SharedPrefsConstant.getBooleanNoti(this@DuplicateContactScanningActivity, "duplicateSelection", true)

                mDuplicateNameList = mDBAdapter!!.getContactsByName(duplicateSelection)
//            mDuplicateNameListFinal = mDuplicateNameList

                mDuplicateNumberList = mDBAdapter!!.getContactsByNumber(duplicateSelection)
//            mDuplicateNumberListFinal = mDuplicateNumberList

                mDuplicateEmailList = mDBAdapter!!.getContactsByEmail(duplicateSelection)
//            mDuplicateEmailListFinal = mDuplicateEmailList
            } catch (e:Exception) {
                Log.e(mTAG, "doInBackground: Exception 002:"+e)

            }
//            Log.e(mTAG, "doInBackground: Please Wait"   )
            return null
        }

        private fun randomQuotes() {
            val listOptions: Array<String> = mContext.resources.getStringArray(R.array.quotes_array)
            val random = Random().nextInt(listOptions.size)
            tvScanning_1.text = listOptions[random]
            if(!isDestroyed) {
                Handler().postDelayed({
                    randomQuotes()
                },8000)
            }
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
//            Log.e(mTAG, "onPostExecute: " )
            mIsScanningDone = true

            val needToShowAds=true
            if (mDuplicateNumberList.size >= mDuplicateNameList.size && mDuplicateNumberList.size >= mDuplicateEmailList.size) {
                if(mDuplicateNumberList.isEmpty()) {
                    redirectActivity()
                } else {
                    industrialAds()
                }
            } else if (mDuplicateNameList.size >= mDuplicateNumberList.size && mDuplicateNameList.size >= mDuplicateEmailList.size) {
                if(mDuplicateNameList.isEmpty()) {
                    redirectActivity()
                } else {
                    industrialAds()
                }
            } else {
                if(mDuplicateEmailList.isEmpty()) {
                    redirectActivity()
                } else {
                    industrialAds()
                }
            }

//            industrialAds()
        }
    }

    private fun givePermissions(permissions: Array<String>) {

        MyApplication.isInternalCall = true

        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                mMainContactListAsyncTask = ContactListData().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionDuplicate!!)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest>,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            }).check()
    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                mMainContactListAsyncTask = ContactListData().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
            } else {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse(String.format("package:%s", packageName)))
                try {
                    MyApplication.isInternalCall = true
                    startActivityForResult(intent, 2296)
                } catch (e: ActivityNotFoundException) {
                }
            }
        }
    }

    fun showSettingsDialog() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            openSettings()
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            if (isFromOneSignal) {
                startActivity(NewHomeActivity.newIntent(this))
                finish()
            } else {
                finish()
            }
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//            givePermissions(mPermissionDuplicate)
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun openSettings() {
        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        MyApplication.isInternalCall = true
        startActivityForResult(intent, 200)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    mMainContactListAsyncTask = ContactListData().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                } else {
                    if (isFromOneSignal) {
                        startActivity(NewHomeActivity.newIntent(this))
                    }
                    finish()
                    Toast.makeText(mContext, getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            }
        } else if (requestCode == 200) {
            if (checkPermissionContact(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    mMainContactListAsyncTask = ContactListData().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                }
            } else {
                if (isFromOneSignal) {
                    startActivity(NewHomeActivity.newIntent(this))
                }
                finish()
                Toast.makeText(mContext, getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
        }
    }


    private fun industrialAds() {
        Log.e(mTAG, "industrialAds: ")
        MyApplication.isInterstitialShown = true
        if (AdsManager(mContext).isNeedToShowAds()) {
            if (!getBoolean(mContext, IS_APP_IN_BACKGROUND, true)) {
                mContext.isShowInterstitialAd { isShowFullScreenAd ->
                    Log.e(mTAG, "onClick: isShowFullScreenAd::$isShowFullScreenAd")
                    MyApplication.isInterstitialShown = false
                    redirectActivity()
                }
            }
            Log.e(mTAG, "industrialAds:Ads Show ")
        } else {
            redirectActivity()
        }
    }

    private fun redirectActivity() {
        Log.e(mTAG, "redirectActivity: ")
        mIsScanningDone = false
        DuplicateContactActivity.lNumberList=mDuplicateNumberList
        DuplicateContactActivity.lNameList=mDuplicateNameList
        DuplicateContactActivity.lEmailList=mDuplicateEmailList

        finish()
        startActivity(
            Intent(mContext, DuplicateContactActivity::class.java)
                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//                .putExtra("mDuplicateNameList", Gson().toJson(mDuplicateNameList))
//                .putExtra("mDuplicateNumberList", Gson().toJson(mDuplicateNumberList))
//                .putExtra("mDuplicateEmailList", Gson().toJson(mDuplicateEmailList))
                .putExtra("IsCheckOneSignalNotification", isFromOneSignal)
        )
    }

    override fun onBackPressed() {
        showAlertStopScanning()
    }

    private fun showAlertStopScanning() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

//        dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(resources.getDrawable(R.drawable.ic_dialog_exit_scan))
        dialog.findViewById<TextView>(R.id.permission).text = mContext.getString(R.string.exit_scanning)
        dialog.findViewById<TextView>(R.id.permission_text).text = mContext.getString(R.string.scanning_stop)
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            mDBAdapter!!.deleteAll()
            mMainContactListAsyncTask!!.cancel(true)
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true

    }

    override fun onPause() {
        super.onPause()
        isPause = true
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
//        Log.e(mTAG, "onResume: $mIsScanningDone")
//        if (mIsScanningDone) {
//            redirectActivity()
//        }
    }

}