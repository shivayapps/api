package com.backup.restore.device.image.recovery.main

//import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator
//import com.nostra13.universalimageloader.core.ImageLoader
//import com.nostra13.universalimageloader.core.ImageLoaderConfiguration
//import com.nostra13.universalimageloader.core.assist.QueueProcessingType
import android.content.Context
import android.os.Build
import android.webkit.WebView
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.multidex.MultiDexApplication
import com.backup.restore.device.image.recovery.observer.Analytics
import com.backup.restore.device.image.recovery.observer.ApplicationObserver
import com.backup.restore.device.image.recovery.observer.LogReporter
import com.backup.restore.device.image.recovery.utilities.common.ApplicationLifecycleHandler
import com.backup.restore.device.image.recovery.utilities.isMainProcess
//import com.onesignal.OSNotificationOpenedResult
//import com.onesignal.OneSignal


open class AppController : MultiDexApplication() {

    companion object {

        @JvmField
        var isAppRunning = true

        var application: AppController? = null

        var instance: AppController? = null
            private set

        @JvmStatic
        val appContext: Context?
            get() {
                if (application == null) {
                    application = AppController()
                }
                return application
            }

        var mTAG: String = "AppController"
    }

    override fun onCreate() {
        super.onCreate()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val process = getProcessName()
            if (packageName != process) WebView.setDataDirectorySuffix(process);
        }

        if (isMainProcess()) {
            instance = this
            application = this

            val analytics = Analytics()
            analytics.addReporter(LogReporter())
            ProcessLifecycleOwner.get().lifecycle.addObserver(ApplicationObserver(analytics, applicationContext))


            val handler = ApplicationLifecycleHandler()
            registerActivityLifecycleCallbacks(handler)
            registerComponentCallbacks(handler)

            initImageLoader(this)


//            OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE)

//            try {
//                if(applicationContext!= null) {
//                    OneSignal.initWithContext(applicationContext)
//                    OneSignal.setAppId("469231a5-25e9-4687-9ad3-872ff133169c")
//                    OneSignal.setNotificationOpenedHandler(NotificationOpenedHandler(this))
//                    OneSignal.unsubscribeWhenNotificationsAreDisabled(true)
//                    OneSignal.setLocationShared(true)
//                    OneSignal.addSubscriptionObserver { stateChanges ->
//                        Log.e(mTAG, "onCreate: || => ---3-.-3  " + stateChanges.to.userId)
//                        if (!stateChanges.from.isSubscribed && stateChanges.to.isSubscribed) {
//                            Log.e(mTAG, "onCreate: || => " + stateChanges.to.userId)
//                        }
//                    }
//                } else {
//                    Log.e(mTAG, " context null" )
//                }
//            } catch (e: java.lang.RuntimeException) {
//                Log.e(mTAG, " RuntimeException")
//            } catch (e: Exception) {
//                Log.e(mTAG, " Exception" )
//            }

        }

//        ViewPump.init(
//            ViewPump.builder().addInterceptor(
//                CalligraphyInterceptor(CalligraphyConfig.Builder().setDefaultFontPath("app_font/firasans_medium.ttf").build())
//            ).build()
//        )

//        OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE)

        // OneSignal Initialization


    }

    open fun initImageLoader(context: Context?) {
//        val config = ImageLoaderConfiguration.Builder(context)
//        config.threadPriority(Thread.NORM_PRIORITY - 2)
//        config.denyCacheImageMultipleSizesInMemory()
//        config.diskCacheFileNameGenerator(Md5FileNameGenerator())
//        config.diskCacheSize(50 * 1024 * 1024) // 50 MiB
//        config.tasksProcessingOrder(QueueProcessingType.LIFO)
//        config.writeDebugLogs() // Remove for release app
//        ImageLoader.getInstance().init(config.build())
    }

//    class NotificationOpenedHandler(private var mContext: Context) :
//        OneSignal.OSNotificationOpenedHandler {
//        override fun notificationOpened(result: OSNotificationOpenedResult?) {
//            val data = result!!.notification.additionalData
//
//            Log.e(mTAG, "startHome: $data")
//
//            if (data != null) {
//                val customKey = data.optString("OpenActivity", null)
//                if (customKey != null) {
//                    when (customKey) {
//                        "AppsBackupActivity" -> {
//                            val intent = Intent(mContext, AppsBackupActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "ContactMainActivity" -> {
//                            val intent = Intent(mContext, ContactMainActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "ScanningActivity_Image" -> {
//                            val intent = Intent(mContext, ScanningActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Image")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "ScanningActivity_Video" -> {
//                            val intent = Intent(mContext, ScanningActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Video")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "ScanningActivity_Audio" -> {
//                            val intent = Intent(mContext, ScanningActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Audio")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "ScanningActivity_Document" -> {
//                            val intent = Intent(mContext, ScanningActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Document")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "ScanningActivity_Other" -> {
//                            val intent = Intent(mContext, ScanningActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Other")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "RecoverImageActivity" -> {
//                            val intent = Intent(mContext, NewRecoverImageActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsFromNotification", "Yes")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "EmptyFolderActivity" -> {
//                            val intent = Intent(mContext, EmptyFolderScanningActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "DuplicateContactScanningActivity" -> {
//                            val intent = Intent(mContext, DuplicateContactScanningActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "JunkActivity" -> {
//                            val intent = Intent(mContext, JunkActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "AppManagerActivity_UserApps" -> {
//                            val intent = Intent(mContext, AppManagerActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "UserApps")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "AppManagerActivity_SystemApps" -> {
//                            val intent = Intent(mContext, AppManagerActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "SystemApps")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "DeepScanActivity_Image" -> {
//                            val intent = Intent(mContext, DeepScanActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Image")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "DeepScanActivity_Video" -> {
//                            val intent = Intent(mContext, DeepScanActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Video")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "DeepScanActivity_Audio" -> {
//                            val intent = Intent(mContext, DeepScanActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Audio")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                        "DeepScanActivity_Document" -> {
//                            val intent = Intent(mContext, DeepScanActivity::class.java)
//                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Document")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", true)
//                        }
//                    }
//                }
//            }
//        }
//    }
}