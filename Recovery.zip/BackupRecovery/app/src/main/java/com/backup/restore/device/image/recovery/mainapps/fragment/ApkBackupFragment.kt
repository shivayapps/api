package com.backup.restore.device.image.recovery.mainapps.fragment

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.inapp.InAppActivity
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.mainapps.activity.AppsBackupActivity
import com.backup.restore.device.image.recovery.mainapps.adapter.APKBackupAdapter
import com.backup.restore.device.image.recovery.mainapps.model.SelectedApk
import com.backup.restore.device.image.recovery.utilities.common.MyUtils
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.example.jdrodi.callback.RVClickListener
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.android.synthetic.main.activity_apps_backup.*
import kotlinx.android.synthetic.main.fragment_apk_backup.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class ApkBackupFragment : Fragment(), View.OnClickListener {

    val mTAG: String = ApkBackupFragment::class.java.simpleName

    lateinit var mView: View
    private var path = ""

    private val mInstalledApps: ArrayList<SelectedApk> = ArrayList()
    var mTempList: ArrayList<SelectedApk>? = ArrayList()

    private var mApkBackupAdapter: APKBackupAdapter? = null
    var isVisibleToUser = false

    var mLoadApksFiles: AsyncTask<*, *, *>? = null
    var mCopyApks: AsyncTask<*, *, *>? = null
    var mContext : Activity? = null
    var search_apk : EditText? = null
    private var rewardedAd: RewardedAd? = null

    private var isRewardVideoAdLoaded: Boolean = false

    companion object {
        fun newInstance(): ApkBackupFragment {
            val fragment = ApkBackupFragment()
            return fragment
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if(mLoadApksFiles?.status==AsyncTask.Status.RUNNING) {
            mLoadApksFiles?.cancel(true)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mContext = (requireActivity() as AppsBackupActivity)
    }


    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        this.isVisibleToUser = isVisibleToUser
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        mView = inflater.inflate(R.layout.fragment_apk_backup, container, false)

        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
        path = ShareConstants.mRootPath + "/Backup And Recovery/Apk Backup/"
        Log.e(mTAG, "Root : $path")


        return mView
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        findViews()
        initViewsActions()
        getAppList()
    }

    private fun getAppList() {
        Log.e(mTAG, "getAppList: " )
        Log.e(mTAG, "getAppList: " + AppsBackupActivity.isFrom )
        if (AppsBackupActivity.isFrom == "BackUp") {
            mLoadApksFiles = LoadApksFiles().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
        }
    }


    private fun findViews() {

        mContext = (requireActivity() as AppsBackupActivity)
        search_apk = (requireActivity() as AppsBackupActivity).et_search_apk
        MyUtils.hideKeyboard(mContext, search_apk)

        btnBackup!!.alpha = 0.5f
        btnBackup!!.isEnabled = false
        bottomAction.visibility=View.GONE

        checkAll!!.alpha = 0.5f
        llSelectAll!!.isEnabled = false
        llSelectAll!!.isClickable = false
        llRefreshImage!!.alpha = 0.5f
        llRefresh!!.isEnabled = false
        llRefresh!!.isClickable = false
        rvBackupApk!!.layoutManager = LinearLayoutManager(requireActivity())
        rvBackupApk!!.setHasFixedSize(true)
    }

    private fun initViewsActions() {
        llSelectAll!!.setOnClickListener {
            if (checkAll!!.isChecked) {
                checkAll!!.isChecked = false
                for (i in mInstalledApps.indices) {
                    mInstalledApps[i].isChecked = false
                    mApkBackupAdapter!!.notifyDataSetChanged()
                }
            } else {
                checkAll!!.isChecked = true
                for (i in mInstalledApps.indices) {
                    mInstalledApps[i].isChecked = true
                    mApkBackupAdapter!!.notifyDataSetChanged()
                }
            }
        }
        search_apk!!.setOnClickListener {
           search_apk!!.isFocusable = true
           search_apk!!.isFocusableInTouchMode = true
           search_apk!!.requestFocus()
        }

        search_apk!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (search_apk!!.text.toString().isEmpty()) {
                    search_apk!!.clearFocus()
                    MyUtils.hideKeyboard(mContext,search_apk)
                } else {
                    search_apk!!.requestFocus()
                }
            }
            override fun afterTextChanged(s: Editable) {
                if (mApkBackupAdapter != null) {
                    filter(s.toString())
                }
            }
        })
//        rvBackupApk!!.addOnScrollListener(object : RecyclerView.OnScrollListener() {
//            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
//                super.onScrollStateChanged(recyclerView, newState)
//                llRefresh!!.isEnabled = true
//                llRefresh!!.isClickable = true
//                llRefreshImage!!.alpha = 1f
//            }
//
//            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
//                super.onScrolled(recyclerView, dx, dy)
//                llRefresh!!.isEnabled = false
//                llRefresh!!.isClickable = false
//                llRefreshImage!!.alpha = 0.5f
//                onScrollStateChanged(rvBackupApk!!, 1)
//            }
//        })

        llRefresh!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1000) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            try {
                llRefreshImage!!.alpha = 0.5f
                llRefresh!!.isEnabled = false
                llRefresh!!.isClickable = false
                Log.e(mTAG, "initViewsActions: llRefresh try ")
                Log.e(mTAG, "onResume: llRefresh getAppList")
                clearSearch()
                tv_msg!!.visibility = View.GONE
                rvBackupApk!!.visibility = View.VISIBLE
                btnBackup!!.alpha = 0.5f
                btnBackup!!.isEnabled = false
                bottomAction.visibility=View.GONE
                getAppList()

            } catch (e: Exception) {
                e.printStackTrace()
                Log.e(mTAG, "initViewsActions: llRefresh catch" + e.message)
            }
        }
        btnBackup!!.setOnClickListener {

            if (SharedPrefsConstant.getInt(mContext, ShareConstants.FREE_RECOVER_APK_COUNT) >= 3 && AdsManager((requireActivity() as AppsBackupActivity)).isNeedToShowAds()) {
                //show dialog
                if (mApkBackupAdapter!!.selectedApk().size != 0) {
                    dialogUnlockPro()
                } else {
                    Toast.makeText(activity,getString(R.string.please_select_file),Toast.LENGTH_SHORT).show()
                }
            } else {
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 500) {
                    return@setOnClickListener
                }
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                ShareConstants.isBackup = true
                search_apk?.setText("")
                goForCopy()
            }


        }
    }

    private fun createAndLoadRewardedAd() {
        RewardedAd.load(requireContext(), resources.getString(R.string.rewarded_ad_id), AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(p0: RewardedAd) {
                super.onAdLoaded(p0)
                rewardedAd = p0
            }

            override fun onAdFailedToLoad(p0: LoadAdError) {
                super.onAdFailedToLoad(p0)
                Log.e("TAG", "onAdFailedToLoad: =>"+p0.message)
                rewardedAd = null
            }
        })
    }

    private fun showRewardedAd() {

        val activityContext: Activity = mContext!!
        rewardedAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {

            override fun onAdDismissedFullScreenContent() {
                Log.i("TAG", "onAdDismissedFullScreenContent")
                rewardedAd=null
//                createAndLoadRewardedAd()
//                    Share.isInertialShow = false
                Log.d("TAG", "The rewarded close.")
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError?) {
//                    onBackPressed()
            }

            override fun onAdShowedFullScreenContent() {
                Log.i("TAG", "onAdShowedFullScreenContent")
                //isAppOpenAdShow = false
            }

        }

        rewardedAd!!.show(activityContext) {
                SharedPrefsConstant.save(mContext, ShareConstants.FREE_RECOVER_APK_COUNT, SharedPrefsConstant.getInt(mContext, ShareConstants.FREE_RECOVER_APK_COUNT) - 1)
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                ShareConstants.isBackup = true
                search_apk?.setText("")
                goForCopy()
        }

    }

    private fun dialogUnlockPro() {
        createAndLoadRewardedAd()
        val dialog = Dialog(requireContext())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_unloack_pro)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val watchVideo = dialog.findViewById<LinearLayout>(R.id.ll_watch_video)
        val purchasePro = dialog.findViewById<LinearLayout>(R.id.ll_purchase_pro)

        watchVideo.setOnClickListener {
            if (!NetworkManager.isInternetConnected(requireContext())) {
                Toast.makeText(mContext,getString(R.string.no_internet_access),Toast.LENGTH_SHORT).show()
                createAndLoadRewardedAd()
            } else if (rewardedAd != null) {
                showRewardedAd()
                dialog.dismiss()
            } else  {
                Toast.makeText(mContext,getString(R.string.please_wait_for_ads_loading),Toast.LENGTH_SHORT).show()
                createAndLoadRewardedAd()
                Log.d("TAG", "The rewarded ad wasn't loaded yet.")
            }
        }
        purchasePro.setOnClickListener {
            dialog.dismiss()
            startActivity(Intent(mContext, InAppActivity::class.java))
        }

        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
            dialog.dismiss()
        }
        dialog.show()
    }

//    private fun dialogUnlockPro() {
//        //createAndLoadRewardedAd()
//
//        val dialog = Dialog(requireContext())
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
//        dialog.setCancelable(false)
//        dialog.setContentView(R.layout.dialog_unloack_pro)
//        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        dialog.window!!.setLayout(
//            ViewGroup.LayoutParams.MATCH_PARENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//
//        val watchVideo = dialog.findViewById<LinearLayout>(R.id.ll_watch_video)
//        val purchasePro = dialog.findViewById<LinearLayout>(R.id.ll_purchase_pro)
//        watchVideo.alpha = 0.5f
//        watchVideo.isClickable=false
//
//        InterstitialRewardHelper.loadRewardedInterstitialAd(requireActivity())
//        requireActivity().isShowRewardedInterstitialAd(
//            onStartToLoadRewardedInterstitialAd = {
//
//            },
//            onUserEarnedReward = {
//                Log.e("TAG", "onFinish: sds=>")
//                SharedPrefsConstant.save(mContext, ShareConstants.FREE_RECOVER_APK_COUNT, SharedPrefsConstant.getInt(mContext, ShareConstants.FREE_RECOVER_APK_COUNT) - 1)
//
//                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
//                ShareConstants.isBackup = true
//                search_apk?.setText("")
//                goForCopy()
//
//            },
//            onAdLoaded = {
//                watchVideo.alpha = 1.0f
//                watchVideo.isClickable = true
//                isRewardVideoAdLoaded = true
//            }
//        )
//
//
//        watchVideo.setOnClickListener {
//            if (!NetworkManager.isInternetConnected(requireContext())) {
//                Toast.makeText(mContext,getString(R.string.no_internet_access),Toast.LENGTH_SHORT).show()
//                //createAndLoadRewardedAd()
//            } else if (isRewardVideoAdLoaded) {
//                requireActivity().showRewardVideoAd()
//                dialog.dismiss()
//            } else  {
//                Toast.makeText(mContext,getString(R.string.please_wait_for_ads_loading),Toast.LENGTH_SHORT).show()
//                //createAndLoadRewardedAd()
//                Log.d("TAG", "The rewarded ad wasn't loaded yet.")
//            }
//        }
//        purchasePro.setOnClickListener {
//            dialog.dismiss()
//            startActivity(Intent(mContext, InAppActivity::class.java))
//        }
//
//        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
//            dialog.dismiss()
//        }
//        dialog.show()
//    }

    fun clearSearch() {
        search_apk!!.text = null
        search_apk!!.clearFocus()
        MyUtils.hideKeyboard(requireActivity(), search_apk)
    }

    override fun onClick(view: View) {

    }

    private fun filter(text: String) {
        mTempList = mInstalledApps
        if (text.isEmpty()) {
            mApkBackupAdapter!!.filterList(mTempList!!)
            val selectedSize = mApkBackupAdapter!!.selectedApk().size
            if (selectedSize == 0) {
                checkAll!!.isChecked = false
            } else {
                checkAll!!.isChecked = selectedSize == mInstalledApps.size
            }
        } else {
            val filteredList = ArrayList<SelectedApk>()
            for (row in mInstalledApps) {
                if (row.appName!!.toLowerCase(Locale.ROOT)
                        .contains(text.toLowerCase(Locale.ROOT))
                ) {
                    filteredList.add(row)
                }
            }
            mTempList = filteredList
            mApkBackupAdapter!!.filterList(mTempList!!)
        }
    }


    private inner class CopyFiles : AsyncTask<String?, String?, String?>() {
        val dialog = Dialog(activity!! as AppsBackupActivity)
        var progress_text : TextView?=null
        var permission_text : TextView?=null

        override fun onPreExecute() {
            super.onPreExecute()

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            progress_text=dialog.findViewById<TextView>(R.id.permission)
            progress_text?.text = getString(R.string.label_please_wait)
            permission_text=dialog.findViewById<TextView>(R.id.permission_text)
            permission_text?.text = getString(R.string.copying_apk_files)
            dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.cancel)

            dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
                dialog.cancel()
                MyApplication.isDialogOpen = false
                if (mCopyApks != null) {
                    mCopyApks!!.cancel(true)
                }
            }

            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }

            if (!dialog.isShowing) {
                dialog.show()
                MyApplication.isDialogOpen = true
            }
        }

        override fun doInBackground(vararg strings: String?): String? {
            val selectedInfoList = mApkBackupAdapter!!.selectedApk()
            if (selectedInfoList.isNotEmpty()) {
                for (i in selectedInfoList.indices) {
                    if (mCopyApks != null) {
                        if (mCopyApks!!.isCancelled) {
                            updateUi(dialog)
                        } else {
                            val file = File(selectedInfoList[i].publicSourceDir!!)
                            val dir = File(path)
                            if (dir.exists() || dir.mkdirs()) {
                                try {
                                    copy(file, selectedInfoList[i].label, selectedInfoList[i].appName)
                                    activity!!.sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)))
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                    }
                    activity?.runOnUiThread {
                        permission_text?.text="${getString(R.string.copying_apk_files)} $i/${selectedInfoList.size}"
                    }
                }
            }
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)

            try {
                Handler(Looper.getMainLooper()).post {
                    if (mInstalledApps.isNotEmpty()) {
                        for (i in mInstalledApps.indices) {
                            mInstalledApps[i].isChecked = false
                        }
                        mApkBackupAdapter!!.notifyDataSetChanged()
                    }
                    if(isAdded) {
                        checkAll!!.isChecked = false
                    }
                }

                Handler(Looper.getMainLooper()).postDelayed(Runnable {
                    try {
                        if (dialog != null && dialog.isShowing) {
                            dialog.cancel()
                            MyApplication.isDialogOpen = false
                        }
                    } catch (e: Exception) {
//                        mContext!!.addEvent(e.message!!)
                    }
                }, 100)

                mContext!!.viewpager.currentItem = 1
                SharedPrefsConstant.save(mContext, ShareConstants.RATE_RECOVER_APK_COUNT, SharedPrefsConstant.getInt(mContext, ShareConstants.RATE_RECOVER_APK_COUNT) + 1)
                SharedPrefsConstant.save(mContext, ShareConstants.FREE_RECOVER_APK_COUNT, SharedPrefsConstant.getInt(mContext, ShareConstants.FREE_RECOVER_APK_COUNT) + 1)

                Toast.makeText(mContext, getString(R.string.apks_copied) + path, Toast.LENGTH_LONG).show()

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun updateUi(pd: Dialog) {
        mContext?.runOnUiThread {
            if (mInstalledApps.isNotEmpty()) {
                for (i in mInstalledApps.indices) {
                    mInstalledApps[i].isChecked = false
                    if(mApkBackupAdapter!= null) {
                        mApkBackupAdapter?.notifyDataSetChanged()
                    }
                }
                checkAll!!.isChecked = false
                pd.cancel()
            }
        }
    }

    private fun copy(fileToCopy: File, lPackageName: String?, lAppName: String?) {
        try {
            val destinationFile = File(path, "$lAppName#$lPackageName.apk")
            Log.e(mTAG, "copy: destinationFile -- > $destinationFile")
            val fis = FileInputStream(fileToCopy)
            val fos = FileOutputStream(destinationFile)
            val b = ByteArray(1024)
            var noOfBytesRead: Int
            while (fis.read(b).also { noOfBytesRead = it } != -1) {
                fos.write(b, 0, noOfBytesRead)
            }
            fis.close()
            fos.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun goForCopy() {
        if (mApkBackupAdapter!!.selectedApk().size != 0) {
            mCopyApks = CopyFiles().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
        } else {
            Toast.makeText(mContext, getString(R.string.select_item_first), Toast.LENGTH_SHORT).show()
        }
    }

    private inner class LoadApksFiles : AsyncTask<String?, String?, String?>() {
        val dialog = Dialog(mContext!!)
        var lApplications: List<ApplicationInfo>? = null

        override fun onPreExecute() {
            super.onPreExecute()
            if (mContext != null) {
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                dialog.setCancelable(false)
                dialog.setContentView(R.layout.dialog_progress)
                dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog.window!!.setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )

                dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.label_please_wait)
                dialog.findViewById<TextView>(R.id.permission_text).text = getString(R.string.fetching_apk)
                dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.cancel)

                dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
                    if (mLoadApksFiles != null) {
                        mLoadApksFiles!!.cancel(true)
                    }
                    dialog.cancel()
                    llRefreshImage!!.alpha = 1.0f
                    llRefresh!!.isEnabled = true
                    llRefresh!!.isClickable = true
                    MyApplication.isDialogOpen = false
//                    mContext!!.finish()
                    mContext!!.onBackPressed()
                }

                dialog.setOnDismissListener {
                    MyApplication.isDialogOpen = false
                }

                if (!dialog.isShowing) {
                    llRefreshImage!!.alpha = 0.5f
                    llRefresh!!.isEnabled = false
                    llRefresh!!.isClickable = false
                    dialog.show()
                    MyApplication.isDialogOpen = true
                }
            }
            mInstalledApps.clear()
        }

        override fun doInBackground(vararg strings: String?): String? {
            try {
                mInstalledApps.clear()
                Log.e(mTAG, "doInBackground: System application")
                lApplications = mContext!!.packageManager.getInstalledApplications(0)
                for (i in lApplications!!.indices) {
                    when {
                        lApplications!![i].flags and ApplicationInfo.FLAG_SYSTEM == 1 -> {
//                            Log.e(mTAG, "doInBackground: System application")
                        }
                        lApplications!![i].packageName == mContext!!.packageName -> {
//                            Log.e(mTAG, "doInBackground: Our application")
                        }
                        else -> {
                            val selectedApk = SelectedApk()
                            selectedApk.label = lApplications!![i].packageName
                            selectedApk.drawable = lApplications!![i].loadIcon(mContext!!.packageManager)
                            selectedApk.publicSourceDir = lApplications!![i].publicSourceDir
                            selectedApk.appName = lApplications!![i].loadLabel(mContext!!.packageManager).toString()
                            selectedApk.size = File(lApplications!![i].publicSourceDir).length().toDouble()
                            val info = mContext!!.packageManager.getPackageInfo(lApplications!![i].packageName,0)
                            if(info!=null) {
                                selectedApk.installedTime=getDate(info.firstInstallTime)
                            }
                            selectedApk.isChecked = false
                            mInstalledApps.add(selectedApk)
                        }
                    }
                    if (mLoadApksFiles!!.isCancelled) {
                        mContext!!.runOnUiThread {
                            dialog.cancel()
                            llRefreshImage!!.alpha = 1.0f
                            llRefresh!!.isEnabled = true
                            llRefresh!!.isClickable = true
                            MyApplication.isDialogOpen = false
                            Log.e(mTAG, "doInBackground: on back " )
//                            mContext!!.onBackPressed()

//                            startActivity(NewHomeActivity.newIntent(mContext as AppsBackupActivity))
//                            mContext!!.finish()
                        }
                        break
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)
            try {
                Handler(Looper.getMainLooper()).post {
                    if(isAdded) {
                        MyUtils.hideKeyboard(mContext, search_apk)
                        if (mInstalledApps.size > 0) {
                            tv_msg!!.visibility = View.GONE
                            bottomAction.visibility=View.VISIBLE
                            rvBackupApk!!.visibility = View.VISIBLE
                            btnBackup!!.alpha = 1f
                            checkAll!!.alpha = 1f
                            llRefreshImage!!.alpha = 1f
                            btnBackup!!.isEnabled = true
                            llSelectAll!!.isEnabled = true
                            llSelectAll!!.isClickable = true
                            try {
                                if (mInstalledApps != null) {
                                    Collections.sort(mInstalledApps) { lhs: SelectedApk, rhs: SelectedApk ->
                                        lhs.appName!!.compareTo(rhs.appName!!)
                                    }
                                }
                            } catch (e : java.lang.Exception) {

                            }
                            mApkBackupAdapter =
                                APKBackupAdapter(mContext!!, mInstalledApps, checkAll!!, llRefresh!!, object : RVClickListener {
                                        override fun onItemClick(position: Int) {}
                                        override fun onEmpty() {
                                            tv_msg!!.visibility = View.VISIBLE
                                            bottomAction.visibility=View.GONE
                                            rvBackupApk!!.visibility = View.GONE
                                            btnBackup!!.alpha = 0.5f
                                            checkAll!!.alpha = 0.5f
                                            llRefreshImage!!.alpha = 0.5f
                                            btnBackup!!.isEnabled = false
                                            llSelectAll!!.isEnabled = false
                                            llSelectAll!!.isClickable = false
                                            llRefresh!!.isEnabled = false
                                            llRefresh!!.isClickable = false
                                            checkAll!!.isChecked = false
                                        }

                                        override fun onNotEmpty() {
                                            tv_msg!!.visibility = View.GONE
                                            bottomAction.visibility=View.VISIBLE
                                            rvBackupApk!!.visibility = View.VISIBLE
                                            rvBackupApk!!.stopScroll()
                                            btnBackup!!.alpha = 1f
                                            checkAll!!.alpha = 1f
                                            llRefreshImage!!.alpha = 1f
                                            btnBackup!!.isEnabled = true
                                            llSelectAll!!.isEnabled = true
                                            llSelectAll!!.isClickable = true
                                            llRefresh!!.isEnabled = true
                                            llRefresh!!.isClickable = true
                                            val selectedSize =
                                                mApkBackupAdapter!!.selectedApk().size
                                            if (selectedSize == mInstalledApps.size) {
                                                checkAll!!.isChecked = true
                                            }
                                        }
                                    })
                            rvBackupApk!!.adapter = mApkBackupAdapter
                            val selectedSize = mApkBackupAdapter!!.selectedApk().size
                            if (selectedSize == 0) {
                                checkAll!!.isChecked = false
                            } else {
                                checkAll!!.isChecked = selectedSize == mInstalledApps.size
                            }
                        } else {
                            tv_msg!!.visibility = View.VISIBLE
                            rvBackupApk!!.visibility = View.GONE
                            bottomAction.visibility=View.GONE
                            btnBackup!!.alpha = 0.5f
                            checkAll!!.alpha = 0.5f
                            llRefreshImage!!.alpha = 0.5f
                            btnBackup!!.isEnabled = false
                            llSelectAll!!.isEnabled = false
                            llSelectAll!!.isClickable = false
                            llRefresh!!.isEnabled = false
                            llRefresh!!.isClickable = false
                        }
                    }

                }

                Handler(Looper.getMainLooper()).postDelayed(Runnable {
                    try {
                        if (dialog != null && dialog.isShowing) {
                            dialog.cancel()
                            llRefreshImage!!.alpha = 1.0f
                            llRefresh!!.isEnabled = true
                            llRefresh!!.isClickable = true
                            MyApplication.isDialogOpen = false
                        }
                    } catch (e: Exception) {
//                        mContext!!.addEvent(e.message!!)
                    }
                }, 1000)

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun getDate(milliSeconds: Long): String {
        val formatter = SimpleDateFormat("EEE-MMM dd,yyyy")
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = milliSeconds
        return formatter.format(calendar.time)
    }

    override fun onPause() {
        super.onPause()
        search_apk!!.isFocusable = false
    }

    override fun onResume() {
        super.onResume()
//        if (AppsBackupActivity.isFrom == "BackUp" && isVisibleToUser) {
//            search_apk = (requireActivity() as AppsBackupActivity).et_search_apk
//            search_apk!!.text = null
//            Handler().postDelayed({
//                search_apk!!.isFocusable = true
//                search_apk!!.isFocusableInTouchMode = true
//                Log.e(mTAG, "findViews: focus ")
//            }, 500)
//            MyUtils.hideKeyboard(mContext, search_apk)
//        }
    }

    override fun onStart() {
        EventBus.getDefault().register(this)
        super.onStart()
    }

    override fun onStop() {
        super.onStop()
        EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRefreshAuctionsAppBack(event: String) {
        if (event == "AppBack") {
            if (mLoadApksFiles != null) {
                mLoadApksFiles!!.cancel(true)
            }
            clearSearch()
        }
    }
}