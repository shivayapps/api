@file:Suppress("DEPRECATION")

package com.backup.restore.device.image.recovery.mainphotos.activity

//import kotlinx.android.synthetic.main.fragment_recovered_image_video.*
//import kotlinx.android.synthetic.main.fragment_trash_image_video.*
import android.Manifest
import android.app.*
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.*
import android.view.View.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.recyclerview.widget.GridLayoutManager
import androidx.viewpager.widget.ViewPager
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.ads.rateandfeedback.ExitSPHelper
import com.backup.restore.device.image.recovery.main.NewHomeActivity
import com.backup.restore.device.image.recovery.mainphotos.deepfragment.*
import com.backup.restore.device.image.recovery.mainphotos.recoverablefragment.*
import com.backup.restore.device.image.recovery.mainphotos.recoveredfragment.*
import com.backup.restore.device.image.recovery.mainphotos.trashfragment.*
import com.backup.restore.device.image.recovery.service.ManagerService
import com.backup.restore.device.image.recovery.utilities.*
import com.backup.restore.device.image.recovery.utilities.common.*
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants.*
import com.google.android.gms.ads.rewarded.RewardedAd
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlinx.android.synthetic.main.activity_deep_scan.*
//import kotlinx.android.synthetic.main.activity_favorite.*
import kotlinx.android.synthetic.main.fragment_ds_image_video.*
import kotlinx.android.synthetic.main.layout_ad_view.*
import java.util.*
import kotlin.collections.ArrayList

class DeepScanActivity : MyCommonBaseActivity() {

    val mTAG: String = DeepScanActivity.javaClass.simpleName
    val mPermissionStorage = arrayOf(
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    )

    private var path = ""

    var isDateClick = false
    var isSizeClick = false

    //    var mIsFromNotification: String? = null
    var mIsCancelAsync = true


    var recoverableViewPagerAdapter: ViewPagerAdapter? = null
    private var rewardedAd: RewardedAd? = null
    var isFromOneSignal = false
    var mIsCheckType: String? = null

    companion object {
        var prevPos: Int = 0
        @JvmField
        var isRefresh = false
        var isGridChange = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_deep_scan)
        addEvent(DeepScanActivity::class.simpleName!!)
    }

    override fun getContext(): AppCompatActivity {
        return this@DeepScanActivity
    }

    override fun initData() {

        if (intent.hasExtra("IsCheckType")) {
            mIsCheckType = intent.extras!!.getString("IsCheckType")
        }
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }


        mRootPath = Environment.getExternalStorageDirectory().toString()
        path = "$mRootPath/Backup And Recovery/"


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            checkAllFilePermission()
        } else {
            if (checkPermissionStorage(mContext)) {
                setAllData()
            } else {
                givePermissions(mPermissionStorage)
            }
        }
    }

    private fun givePermissions(permissions: Array<String>) {

        MyApplication.isInternalCall = true

        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                setAllData()
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionStorage)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest>,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            }).check()
    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                setAllData()
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                try {
                    MyApplication.isInternalCall = true
                    startActivityForResult(intent, 2296)
                } catch (e: ActivityNotFoundException) {
                }
            }
        }
    }

    fun showSettingsDialog() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            MyApplication.isDialogOpen = false
            dialog.cancel()
            openSettings()
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            MyApplication.isDialogOpen = false
            dialog.cancel()
            if (isFromOneSignal) {
                startActivity(NewHomeActivity.newIntent(this))
                finish()
            } else {
                finish()
            }
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//            givePermissions(mPermissionStorage)
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun openSettings() {
        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        MyApplication.isInternalCall = true
        startActivityForResult(intent, 200)
    }

    private fun startServiceMethod() {
        try {
            if (!isMyServiceRunning(mContext, ManagerService::class.java)) {
                SharedPrefsConstant.savePrefNoti(mContext, "isDeleteFromEmpty", false)
                SharedPrefsConstant.savePrefNoti(mContext, "IsFromService", false)
                ManagerService.setData(mContext)
                startService(Intent(this, ManagerService::class.java))
                Log.e(
                    mTAG,
                    "startServiceMethod: " + SharedPrefsConstant.getBooleanNoti(
                        mContext,
                        "IsFromService",
                        false
                    )
                )
            }
        } catch (e: java.lang.Exception) {
            Log.e(mTAG, "startServiceMethod: " + e.message)
            e.printStackTrace()
        }
    }

    private fun setAllData() {
        startServiceMethod()
        setupViewPagerRecoverable(viewPager_recoverable)
        setMainAdapter()

        if (mIsCheckType == "Image") {
            viewPager_recoverable.currentItem = 0
            bottom_navigation_recoverable.selectedItemId = R.id.nav_image
        } else if (mIsCheckType == "Video") {
            viewPager_recoverable.currentItem = 1
            bottom_navigation_recoverable.selectedItemId = R.id.nav_video
        } else if (mIsCheckType == "Audio") {
            viewPager_recoverable.currentItem = 2
            bottom_navigation_recoverable.selectedItemId = R.id.nav_audio
        } else if (mIsCheckType == "Document") {
            viewPager_recoverable.currentItem = 3
            bottom_navigation_recoverable.selectedItemId = R.id.nav_doc
        }
    }

    private fun setMainAdapter() {
        Log.e(mTAG, "setAllData: no")
        tv_header!!.text = getString(R.string.deep_scan)
        tv_header!!.isSelected = true
        frame_Recoverable.visibility = INVISIBLE
        val fragment = recoverableViewPagerAdapter!!.getItem(viewPager_recoverable.currentItem)
        if (fragment is DSImageFragment) {
            fragment.userVisibleHint = true
        }
        setValueFalse()
    }

    override fun initActions() {
//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
//            GiftIconHelper.loadGiftAd(
//                fContext = mContext,
//                fivGiftIcon = findViewById(R.id.main_la_gift),
//                fivBlastIcon = findViewById(R.id.main_la_gift_blast)
//            )
//        } else {
//            if (!AdsManager(mContext).isNeedToShowAds()) main_la_gift.visibility = View.VISIBLE
//        }
        iv_back!!.setOnClickListener {
            onBackPressed()
        }
        iv_span.setOnClickListener {
            if (SystemClock.elapsedRealtime() - mLastClickTime < 800) {
                return@setOnClickListener
            }
            mLastClickTime = SystemClock.elapsedRealtime()
            isGridChange = true
            setSpanCount()
        }

//        llDateWise!!.setOnClickListener {
//            val fragment = recoverableViewPagerAdapter!!.getItem(viewPager_recoverable.currentItem)
//            when (fragment) {
//                is DSImageFragment -> {
//                    Log.e(
//                        mTAG,
//                        "RecoveredImageFragment initActions: " + fragment.mRecoverableFolderList.size
//                    )
//                }
//                is DSVideoFragment -> {
//
//                    Log.e(
//                        mTAG,
//                        "RecoverableVideoFragment initActions: " + fragment.selectedList.size
//                    )
//                }
//                is DSAudioFragment -> {
//                    Log.e(
//                        mTAG,
//                        "RecoverableAudioFragment initActions: " + fragment.selectedList.size
//                    )
//                }
//                is DSDocumentFragment -> {
//
//                    Log.e(
//                        mTAG,
//                        "RecoverableDocumentFragment initActions: " + fragment.selectedList.size
//                    )
//                }
//            }
//        }

//        llSizeWise!!.setOnClickListener {
//            val fragment = recoverableViewPagerAdapter!!.getItem(viewPager_recoverable.currentItem)
//            when (fragment) {
//                is DSImageFragment -> {
//                    Log.e(
//                        mTAG,
//                        "DSImageFragment initActions: " + fragment.mRecoverableFolderList.size
//                    )
//                }
//                is DSVideoFragment -> {
//
//                    Log.e(
//                        mTAG,
//                        "DSVideoFragment initActions: " + fragment.selectedList.size
//                    )
//
//                }
//                is DSAudioFragment -> {
//
//                    Log.e(
//                        mTAG,
//                        "RecoverableAudioFragment initActions: " + fragment.selectedList.size
//                    )
//
//                }
//                is DSDocumentFragment -> {
//
//                    Log.e(
//                        mTAG,
//                        "RecoverableDocumentFragment initActions: " + fragment.selectedList.size
//                    )
//                }
//            }
//        }
    }


    private fun btnRecoverClicked() {

    }

    private fun setupViewPagerRecoverable(viewPager: ViewPager?) {
        recoverableViewPagerAdapter = ViewPagerAdapter(supportFragmentManager)
        recoverableViewPagerAdapter!!.addFrag(DSImageFragment.newInstance(), "Images")
        recoverableViewPagerAdapter!!.addFrag(DSVideoFragment.newInstance(), "Video")
        recoverableViewPagerAdapter!!.addFrag(DSAudioFragment.newInstance(), "Audio")
        recoverableViewPagerAdapter!!.addFrag(DSDocumentFragment.newInstance(), "Document")
//        recoverableViewPagerAdapter!!.addFrag(RecoverableOtherFragment.newInstance(), "Other")

        viewPager!!.adapter = recoverableViewPagerAdapter!!
        viewPager.offscreenPageLimit = 5

//        Log.e(mTAG, "setupViewPager: showStatusPopup --> setViewPager")

        bottom_navigation_recoverable.menu.removeItem(R.id.nav_other)
        bottom_navigation_recoverable.setOnNavigationItemSelectedListener {
            Log.e(mTAG, "showStatusPopup setupViewPager: " + it.itemId)
            when (it.itemId) {
                R.id.nav_image -> {
                    viewPager_recoverable.currentItem = 0
                    iv_span.visibility = VISIBLE
                }
                R.id.nav_video -> {
                    viewPager_recoverable.currentItem = 1
                    iv_span.visibility = VISIBLE
                }
                R.id.nav_audio -> {
                    viewPager_recoverable.currentItem = 2
                    iv_span.visibility = VISIBLE
                }
                R.id.nav_doc -> {
                    viewPager_recoverable.currentItem = 3
                    iv_span.visibility = VISIBLE
                }
                R.id.nav_other -> {
                    viewPager_recoverable.currentItem = 4
                    iv_span.visibility = VISIBLE
                }
                else -> {
                    null
                }
            } != null

        }

        viewPager_recoverable.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
//                Log.e(mTAG, "showStatusPopup onPageScrolled: $position")
            }

            override fun onPageSelected(position: Int) {

                when (val lFragment = recoverableViewPagerAdapter!!.getItem(prevPos)) {
                    is DSImageFragment -> {
                        setValueFalse()
//                        checkAll.isChecked = false
                        iv_span.visibility = VISIBLE
                    }
                    is DSVideoFragment -> {
                        setValueFalse()
//                        checkAll.isChecked = false
                        iv_span.visibility = VISIBLE
                    }
                    is DSAudioFragment -> {
                        setValueFalse()
//                        checkAll.isChecked = false
                        iv_span.visibility = GONE
                    }
                    is DSDocumentFragment -> {
                        setValueFalse()
//                        checkAll.isChecked = false
                        iv_span.visibility = GONE
                    }
                }

                if (prevPos != position) {
                    when (position) {
                        0 -> {
                            val fragment = recoverableViewPagerAdapter!!.getItem(0)
                            if (fragment is DSImageFragment) {
                                fragment.userVisibleHint = true
                            }
                            bottom_navigation_recoverable.selectedItemId = R.id.nav_image
                        }
                        1 -> {
                            val fragment = recoverableViewPagerAdapter!!.getItem(1)
                            if (fragment is DSVideoFragment) {
                                fragment.userVisibleHint = true
                            }
                            bottom_navigation_recoverable.selectedItemId = R.id.nav_video
                        }
                        2 -> {
                            val fragment = recoverableViewPagerAdapter!!.getItem(2)
                            if (fragment is DSAudioFragment) {
                                fragment.userVisibleHint = true
                            }
                            bottom_navigation_recoverable.selectedItemId = R.id.nav_audio
                        }
                        3 -> {
                            val fragment = recoverableViewPagerAdapter!!.getItem(3)
                            if (fragment is DSDocumentFragment) {
                                fragment.userVisibleHint = true
                            }
                            bottom_navigation_recoverable.selectedItemId = R.id.nav_doc
                        }
                    }

                    prevPos = position
                }
            }

            override fun onPageScrollStateChanged(state: Int) {
//                Log.e(mTAG, "showStatusPopup onPageScrollStateChanged: ")
            }


        })
    }


    class ViewPagerAdapter(manager: FragmentManager?) : FragmentPagerAdapter(manager!!) {

        private val mFragmentList: MutableList<Fragment> = ArrayList()
        private val mFragmentTitleList: MutableList<String> = ArrayList()

        override fun getItem(position: Int): Fragment {
            return mFragmentList[position]
        }

        override fun getCount(): Int {
            return mFragmentList.size
        }

        fun addFrag(fragment: Fragment, title: String) {
            mFragmentList.add(fragment)
            mFragmentTitleList.add(title)
        }

        override fun getPageTitle(position: Int): CharSequence {
            return mFragmentTitleList[position]
        }
    }

    private fun setSpanCount() {
        var mCurrentSpanCount = mContext.getGridCount()
        mCurrentSpanCount = if (mCurrentSpanCount == SPAN_COUNT_THREE) {
            SPAN_COUNT_TWO
        } else {
            SPAN_COUNT_THREE
        }
        mContext.saveGridCount(mCurrentSpanCount)
        Log.e(mTAG, "setSpanCount: isGridChange mCurrentSpanCount--> $mCurrentSpanCount")
        iv_span!!.isSelected = mContext.getGridCount() == SPAN_COUNT_THREE
        spanCount()
    }

    private fun setValueFalse() {
        isDateClick = false
        isSizeClick = false
    }

    fun getCurrentPosition(): Int {
        return viewPager_recoverable.currentItem
    }


//    var selection = 0
//    fun selectAll() {
//        selection = 0
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        tvDate!!.setTextColor(resources.getColor(R.color.colorPrimary))
//        tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
//        llDateWise.isEnabled = true
//        llSizeWise.isEnabled = true
//    }
//
//    private fun selectAllSize() {
//        selection = 1
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_fill)
//        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        tvDate!!.setTextColor(resources.getColor(R.color.filter_text_color))
//        tvSize!!.setTextColor(resources.getColor(R.color.colorPrimary))
//        llDateWise.isEnabled = true
//        llSizeWise.isEnabled = true
//    }
//
//    private fun selectAllDate() {
//        selection = 2
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        tvDate!!.setTextColor(resources.getColor(R.color.colorPrimary))
//        tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
//        llDateWise.isEnabled = true
//        llSizeWise.isEnabled = true
//    }
//
//    fun unSelectAll(frag:Int) {
//        if(prevPos==frag) {
//            llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//            llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//            select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//            select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//            tvDate!!.setTextColor(resources.getColor(R.color.filter_text_color))
//            tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
//            llDateWise.isEnabled = false
//            llSizeWise.isEnabled = false
//        }
//    }

    override fun onPause() {
        super.onPause()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()


        Log.e(mTAG, "onResume:isGridChange: $isGridChange")
        if (isGridChange) {
            isGridChange = false
            Handler().postDelayed({
                Log.e(mTAG, "onResume:getGridCount " + mContext.getGridCount())
                iv_span!!.isSelected = mContext.getGridCount() == SPAN_COUNT_THREE
                spanCount()
            }, 500)
            Log.e(mTAG, "onResume:isGridChange spanCount ")
        }

        tv_header!!.text = getString(R.string.deep_scan)
        frame_Recoverable.visibility = VISIBLE
        setValueFalse()
        startServiceMethod()
    }


    fun spanCount() {
        val lCurrentSpanCount = mContext.getGridCount()
        Log.e(mTAG, "spanCount: isGridChange getGridCount --> $lCurrentSpanCount")

        if (recoverableViewPagerAdapter != null) {
            val recoverablePhotoFragment: Fragment = recoverableViewPagerAdapter?.getItem(0)!!
            if (recoverablePhotoFragment != null) {
                if (recoverablePhotoFragment is DSImageFragment) {
                    Log.e(mTAG, "setUserVisibleHint: $mContext")
                    if (recoverablePhotoFragment.scan_recoverable_album != null) {
                        val layoutManager = recoverablePhotoFragment.scan_recoverable_album.layoutManager as GridLayoutManager
                        if (layoutManager.spanCount != lCurrentSpanCount) {
                            layoutManager.spanCount = lCurrentSpanCount
                            if (recoverablePhotoFragment.mHiddenPictureFolderAdapter != null) {
                                recoverablePhotoFragment.mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
                            }
                        }
                    }
                }
            }

            val recoverableVideoFragment = recoverableViewPagerAdapter?.getItem(1)!!
            if (recoverableVideoFragment != null) {
                if (recoverableVideoFragment is DSVideoFragment) {
                    Log.e(mTAG, "setUserVisibleHint: $mContext")
                    if (recoverableVideoFragment?.scan_recoverable_album != null) {
                        val layoutManager = recoverableVideoFragment.scan_recoverable_album.layoutManager as GridLayoutManager
                        if (layoutManager.spanCount != lCurrentSpanCount) {
                            layoutManager.spanCount = lCurrentSpanCount
                            if (recoverableVideoFragment.mHiddenPictureFolderAdapter != null) {
                                recoverableVideoFragment.mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
                            }
                        }
                    }
                }
            }

            val recoverableAudioFragment = recoverableViewPagerAdapter?.getItem(2)!!
            if (recoverableAudioFragment != null) {
                if (recoverableAudioFragment is DSAudioFragment) {
                    Log.e(mTAG, "setUserVisibleHint: $mContext")
                    if (recoverableAudioFragment?.scan_recoverable_album != null) {
                        val layoutManager = recoverableAudioFragment.scan_recoverable_album.layoutManager as GridLayoutManager
                        if(layoutManager.spanCount!=lCurrentSpanCount) {
                            layoutManager.spanCount = lCurrentSpanCount
                            if (recoverableAudioFragment.mHiddenPictureFolderAdapter != null) {
                                recoverableAudioFragment.mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
                            }
                        }
                    }
                }
            }

            val recoverableDocumentFragment = recoverableViewPagerAdapter?.getItem(3)!!
            if (recoverableDocumentFragment != null) {
                if (recoverableDocumentFragment is DSDocumentFragment) {
                    Log.e(mTAG, "setUserVisibleHint: $mContext")
                    if (recoverableDocumentFragment?.scan_recoverable_album != null) {
                        val layoutManager = recoverableDocumentFragment.scan_recoverable_album.layoutManager as GridLayoutManager
                        if(layoutManager.spanCount!=lCurrentSpanCount) {
                            layoutManager.spanCount = lCurrentSpanCount
                            if (recoverableDocumentFragment.mHiddenPictureFolderAdapter != null) {
                                recoverableDocumentFragment.mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
                            }
                        }
                    }
                }
            }
        }


    }

    override fun onBackPressed() {
        if (SharedPrefsConstant.getBooleanNoti(mContext, "IsFromService", false)) {
            Log.e(mTAG, "onBackPressed: IsFromService ")
//            startActivity(NewHomeActivity.newIntent(this))
//            finish()
//            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

            if (isFromOneSignal) {
                startActivity(NewHomeActivity.newIntent(this))
                finish()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            } else {
                super.onBackPressed()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }

        } else {
            val isRated = ExitSPHelper(mContext).isRated()
            Log.e(mTAG, "onBackPressed: isRated $isRated")
            if (!isRated) {
                if (SharedPrefsConstant.getInt(
                        mContext,
                        RATE_RECOVER_IMAGE_COUNT
                    ) >= 4 && SharedPrefsConstant.getInt(
                        mContext,
                        ShareConstants.RATE_LATTER,
                        1
                    ) == 0
                ) {
                    RatingDialog.smileyRatingDialog(mContext)
                } else {
                    if (isFromOneSignal) {
                        startActivity(NewHomeActivity.newIntent(this))
                        finish()
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    } else {
                        super.onBackPressed()
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    }
                }
            } else {
                if (isFromOneSignal) {
                    startActivity(NewHomeActivity.newIntent(this))
                    finish()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                } else {
                    super.onBackPressed()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    setAllData()
                    Log.e(mTAG, "onActivityResult: Service Start ")
                } else {
                    finish()
                    Toast.makeText(
                        mContext,
                        getString(R.string.permission_required),
                        Toast.LENGTH_SHORT
                    ).show()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            }
        } else if (requestCode == 200) {
            if (checkPermissionStorage(mContext)) {
                setAllData()
            } else {
                finish()
                Toast.makeText(
                    mContext,
                    getString(R.string.permission_required),
                    Toast.LENGTH_SHORT
                ).show()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
        }
    }
//
//    fun selectTop(frag:Int) {
//        Log.e(mTAG, "selectTop: prevPos -> $prevPos")
//        Log.e(mTAG, "selectTop: frag -> $frag")
//        Log.e(mTAG, "selectTop: selection -> $selection")
//
//        if(prevPos==frag) {
//            if (selection == 0) selectAll()
//            else if (selection == 1) selectAllSize()
//            else if (selection == 2) selectAllDate()
//        }
//    }
//    fun selectSizeAsc() {
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_fill)
//        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//        tvSize!!.setTextColor(resources.getColor(R.color.colorPrimary))
//        tvDate!!.setTextColor(resources.getColor(R.color.filter_text_color))
//    }
//
//    fun selectSizeDesc() {
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_fill)
//        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//        tvSize!!.setTextColor(resources.getColor(R.color.colorPrimary))
//        tvDate!!.setTextColor(resources.getColor(R.color.filter_text_color))
//    }
//
//    fun selectDateDesc() {
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        tvDate!!.setTextColor(resources.getColor(R.color.colorPrimary))
//        tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
//    }
//    fun selectDateAsc() {
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        tvDate!!.setTextColor(resources.getColor(R.color.colorPrimary))
//        tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
//    }

}