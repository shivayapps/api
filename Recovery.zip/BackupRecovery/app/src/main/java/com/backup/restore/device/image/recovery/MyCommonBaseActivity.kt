package com.backup.restore.device.image.recovery

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.multilang.LocaleManager
import com.backup.restore.device.image.recovery.multilang.Locales
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant

//import com.backup.restore.device.image.recovery.localehelper.LocaleAwareCompatActivity

abstract class MyCommonBaseActivity : AppCompatActivity(), View.OnClickListener {

    lateinit var mContext: AppCompatActivity

    var mPreviousSelectedLanguageKey = Locales.English.toString()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mContext = getContext()

        if(!LocaleManager.isLanguageReset(this@MyCommonBaseActivity)) {
            LocaleManager.setNewLocale(this@MyCommonBaseActivity,"en")
            LocaleManager.ResetLanguage(this@MyCommonBaseActivity)
        }

        LocaleManager.setLocale(this@MyCommonBaseActivity)

        mPreviousSelectedLanguageKey = LocaleManager.getLanguagePref(this@MyCommonBaseActivity)

        addEvent(MyCommonBaseActivity::class.simpleName!!)
    }

//    override fun updateLocale(locale: Locale) {
//        super.updateLocale(locale)
//    }

    override fun onResume() {
        super.onResume()
        restartIfRequires()
    }

    private fun restartIfRequires() {
        if (mPreviousSelectedLanguageKey != LocaleManager.getLanguagePref(this@MyCommonBaseActivity)) {
            SharedPrefsConstant.savePref(this, SharedPrefsConstant.IS_REFRESH_HOME, true)
            Log.e("TAG", "restartIfRequires: ")
            recreate()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        } else {
            SharedPrefsConstant.savePref(this, SharedPrefsConstant.IS_REFRESH_HOME, false)
        }
    }

    override fun setContentView(layout: Int) {
        super.setContentView(layout)
        initViews()
        initAds()
        initData()
        initActions()
    }


    /**
     * ToDo. Set the context of activity
     *
     * @return The context of activity.
     */
    abstract fun getContext(): AppCompatActivity

    /**
     * ToDo. Use this method to setup views.
     */
    open fun initViews() {}

    /**
     * ToDo. Use this method to setup ads.
     */
    open fun initAds() {}

    /**
     * ToDo. Use this method to initialize data to view components.
     */
    abstract fun initData()

    /**
     * ToDo. Use this method to initialize action on view components.
     */
    abstract fun initActions()

    override fun onClick(view: View) {
    }



}