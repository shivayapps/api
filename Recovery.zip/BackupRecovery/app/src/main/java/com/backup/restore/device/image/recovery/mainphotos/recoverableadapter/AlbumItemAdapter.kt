package com.backup.restore.device.image.recovery.mainphotos.recoverableadapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainphotos.callbacks.AlbumClickListener
import com.backup.restore.device.image.recovery.retriever.Album
import com.bumptech.glide.Glide
import java.util.*

class AlbumItemAdapter(
    private var folders: ArrayList<Album>,
    private val mFolderContext: Context,
    private val mType: String,
    private val listenToClick: AlbumClickListener
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var mLastClickTime: Long = 0

    class FolderHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var folderPic: ImageView = itemView.findViewById(R.id.folderPic)
        var folderName: TextView = itemView.findViewById(R.id.folderName)
        var folderSize: TextView = itemView.findViewById(R.id.folderSize)
    }

    fun updateList(folders: ArrayList<Album>) {
        Log.e("AlbumItemAdapter", "updateList:folders: " + folders.size)
        this.folders = folders
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val cell = inflater.inflate(R.layout.raw_picture_folder_item, parent, false)
        return FolderHolder(cell)
    }

    override fun onBindViewHolder(holders: RecyclerView.ViewHolder, position: Int) {
        val holder = holders as FolderHolder
        val folder = folders[position]

//        Log.e("RecoverableAdapter", "onBindViewHolder:$position - ${folder.path}" )
//        Log.e("RecoverableAdapter", "onBindViewHolder folderName:$position - ${folder.folderName}" )
//        Log.e("RecoverableAdapter", "onBindViewHolder firstPic:$position - ${folder.firstPic}" )
        if (mType == "audio") {
            holder.folderPic.setImageResource(R.drawable.ic_audio_cover)
//            val padding=DensityUtils.dpToPx(22)
//            holder.folderPic.setPadding(padding,padding,padding,padding)
        } else if (mType == "document") {
            holder.folderPic.setImageResource(R.drawable.ic_doc_cover)
//            val padding=DensityUtils.dpToPx(28)
//            holder.folderPic.setPadding(padding,padding,padding,padding)
        } else if (mType == "other") {
            holder.folderPic.setImageResource(R.drawable.ic_doc_cover)
//            val padding=DensityUtils.dpToPx(24)
//            holder.folderPic.setPadding(padding,padding,padding,padding)
        } else {
            Glide.with(mFolderContext)
                .load(folder.albumItems[0].path)
                .placeholder(R.drawable.img_thumb)
                .override(100, 100)
                .into(holder.folderPic)
        }

        val text = "" + folder.name
        val folderSizeString = "(" + folder.albumItems.size + ")"
        holder.folderSize.text = folderSizeString
        holder.folderName.text = text.trim('.')
        holder.folderPic.setOnClickListener {
            Log.e("RecoverableFolderAdp", "setOnClickListener")
//            val elapsedRealtime = SystemClock.elapsedRealtime()
//            Log.e("RecoverableFolderAdp", "elapsedRealtime: $elapsedRealtime ")
//            Log.e("RecoverableFolderAdp", "mLastClickTime: $mLastClickTime ")
//            Log.e("RecoverableFolderAdp", "diff: ${elapsedRealtime - mLastClickTime} ")
//            //mLastClickTime = SystemClock.elapsedRealtime()
//            if (elapsedRealtime - mLastClickTime < 1200) {
//                return@setOnClickListener
//            }
//            mLastClickTime = elapsedRealtime
            listenToClick.onPicClicked(folder, folder.name)
        }
    }

    override fun getItemCount(): Int {
        return folders.size
    }


//    fun runLayoutAnimation() {
//        val lController = AnimationUtils.loadLayoutAnimation(mFolderContext, R.anim.layout_animation_fall_down)
//        mScanAlbumRecycle.layoutAnimation = lController
//        Objects.requireNonNull(mScanAlbumRecycle.adapter).notifyDataSetChanged()
//        mScanAlbumRecycle.scheduleLayoutAnimation()
//    }
}