package com.backup.restore.device.image.recovery.mainapps.model;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Pair;

import com.backup.restore.device.image.recovery.R;
import com.backup.restore.device.image.recovery.junckcleaner.models.FileModel;
import com.backup.restore.device.image.recovery.retriever.AlbumItem;
import com.backup.restore.device.image.recovery.retriever.MediaType;
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants;
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant;

import java.io.File;
import java.io.FileFilter;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

/**
 * Created by bruce on 14-11-6.
 */
public final class Utils {

    public static final String datePattern = "dd MMM yyyy HH:mm:ss z";
    public static final String KEY_MODE = "key_mode";

    /*** Sensor */
    public static final String KEY_SENSOR_NAME = "key_sensor_name";
    public static final String KEY_SENSOR_TYPE = "key_sensor_type";
    public static final String KEY_SENSOR_ICON = "key_sensor_icon";

    public static float KEY_LAST_KNOWN_HUMIDITY = 0f;

    public static final int KEY_CAMERA_CODE = 101;
    public static final int KEY_CALL_PERMISSION = 102;
    public static final int KEY_READ_PHONE_STATE = 103;
    public static final int IS_USER_COME_FROM_SYSTEM_APPS = 1;
    public static final int IS_USER_COME_FROM_USER_APPS = 2;

    public static final String JUNK_LAST_CLEANED_TIME = "JUNK_LAST_CLEANED_TIME";

    public static final String INSTALLATION = "INSTALLATION";
    public static final String APP_ICON = "APP_ICON";
    public static final String APP_NAME = "APP_NAME";
    public static final String APP_VERSION = "APP_VERSION";
    public static final String BOOST = "BOOST";
    public static final String BOOST_LAST_CLEANED_TIME = "BOOST_LAST_CLEANED_TIME";
    public static final String COOL_LAST_CLEANED_TIME = "COOL_LAST_CLEANED_TIME";
    public static final String COOLER = "COOLER";
    public static final String POWER_SAVED_LAST_TIME = "POWER_SAVED_LAST_TIME";

    public static String getDate(long timeStamp) {

        try {
            DateFormat sdf = new SimpleDateFormat(datePattern, Locale.ENGLISH);
            Date netDate = (new Date(timeStamp));
            return sdf.format(netDate);
        } catch (Exception ex) {
            return "xx";
        }
    }

    public static int calculatePercentage(double value, double total) {
        double usage = (int) ((value * 100.0f) / total);
        return (int) usage;
    }

    public static float dp2px(Resources resources, float dp) {
        final float scale = resources.getDisplayMetrics().density;
        return dp * scale + 0.5f;
    }

    public static float sp2px(Resources resources, float sp) {
        final float scale = resources.getDisplayMetrics().scaledDensity;
        return sp * scale;
    }

    public static int pxToDp(Context context, int px) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return Math.round(px / (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT));
    }

    public static void changeLanguage(Context context) {
//    fun Context.changeLanguage() {
        Locale locale = new Locale(SharedPrefsConstant.getString(context, ShareConstants.SELECTED_LANGUAGE, "en"));
        Locale.setDefault(locale);
        Configuration config = context.getResources().getConfiguration();
        config.locale = locale;
        context.getResources().updateConfiguration(config, context.getResources().getDisplayMetrics());
    }

    public static Uri getContentUri(Context context, AlbumItem albumItem) {
        Uri uri;
        if (MediaType.isVideo(albumItem.getPath())) {
            uri = getContentUriForVideoFromMediaStore(context, albumItem.getPath());
        } else {
            uri = getContentUriForImageFromMediaStore(context, albumItem.getPath());
        }
        return uri;
    }

    private static Uri getContentUriForImageFromMediaStore(Context context, String path) {
        ContentResolver resolver = context.getContentResolver();
        //Uri photoUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        // to handle hidden images
        Uri photoUri = MediaStore.Files.getContentUri("external");
        Cursor cursor = resolver.query(photoUri,
                new String[]{BaseColumns._ID},
                MediaStore.MediaColumns.DATA + " = ?",
                new String[]{path}, null);
        if (cursor == null) {
            return Uri.parse(path);
        }
        cursor.moveToFirst();
        if (cursor.isAfterLast()) {
            cursor.close();
            // insert system media db
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DATA, path);
            values.put(MediaStore.Images.Media.MIME_TYPE, MediaType.getMimeType(path));
            return context.getContentResolver().insert(photoUri, values);
        } else {
            long id = cursor.getLong(cursor.getColumnIndex(BaseColumns._ID));
            Uri uri = ContentUris.withAppendedId(photoUri, id);
            cursor.close();
            return uri;
        }
    }

    private static Uri getContentUriForVideoFromMediaStore(Context context, String path) {
        ContentResolver resolver = context.getContentResolver();
        //Uri videoUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        // to handle hidden videos
        Uri videoUri = MediaStore.Files.getContentUri("external");
        Cursor cursor = resolver.query(videoUri,
                new String[]{BaseColumns._ID},
                MediaStore.MediaColumns.DATA + " = ?",
                new String[]{path}, null);

        if (cursor == null) {
            return Uri.parse(path);
        }
        cursor.moveToFirst();
        if (cursor.isAfterLast()) {
            cursor.close();
            // insert system media db
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DATA, path);
            values.put(MediaStore.Video.Media.MIME_TYPE, MediaType.getMimeType(path));
            return context.getContentResolver().insert(videoUri, values);
        } else {
            int imageId = cursor.getInt(cursor.getColumnIndex(BaseColumns._ID));
            Uri uri = ContentUris.withAppendedId(videoUri, imageId);
            cursor.close();
            return uri;
        }
    }

    public static String retrieveFileName(Context context, Uri uri) {
        //retrieve file name
        try {
            Cursor cursor = context.getContentResolver().query(uri,
                    new String[]{OpenableColumns.DISPLAY_NAME},
                    null, null, null);
            if (cursor != null) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                cursor.moveToFirst();
                if (!cursor.isAfterLast()) {
                    String filename = cursor.getString(nameIndex);
                    cursor.close();
                    return filename;
                }
            }
        } catch (SecurityException ignored) {
        }
        return null;
    }


    @SuppressLint("DefaultLocale")
    public static Pair<String, String> getDataSizeWithPrefix(Context context, double size) {
        String sizePrefix = context.getString(R.string.b);
        double finalSize = size;
        if (size >= 1024) {
            double sizeKb = size / 1024;
//            sizePrefix = "KB";
            sizePrefix = context.getString(R.string.kb);
            finalSize = sizeKb;
            if (sizeKb >= 1024) {
//                sizePrefix = "MB";
                double sizeMB = sizeKb / 1024;
                sizePrefix = context.getString(R.string.mb);
                finalSize = sizeMB;
                if (sizeMB >= 1024) {
                    double sizeGb = sizeMB / 1024;
//                    sizePrefix = "GB";
                    sizePrefix = context.getString(R.string.gb);
                    finalSize = sizeGb;
                }
            }
        }
        return new Pair<>(String.format(Locale.ENGLISH, "%.2f", finalSize), sizePrefix);
    }

    public static double getCalculatedDataSizeMB(double size) {
//        float sizeBytes = size;
        double finalSize = size;
//        if (sizeBytes >= 1024) {
        double sizeKb = size / 1024;
//            finalSize = sizeKb;
//            if (sizeKb >= 1024) {
        finalSize = sizeKb / 1024;
//            }
//        }
        return finalSize;
    }

    public static float getAllSize(String path) {
        float docSize = 0;
        File fold = new File(path);
        File[] mlist = fold.listFiles();
        File[] mFilelist = fold.listFiles();
        if (mlist != null)
            for (File f : mlist) {
                if (f.isDirectory()) {
                    getAllSize(f.getAbsolutePath());
                }
            }
        if (mlist != null)
            if (mFilelist != null) {
                for (File f : mFilelist) {
                    docSize = docSize + f.length();
                }
            }
        return docSize;
    }


    public static List<File> getListAllHiddenFiles(String path) {
//        Log.e("Utils", "getListAllFiles:"+path);
        File fold = new File(path);
        List<File> docList = new ArrayList<>();
        File[] mlist = fold.listFiles();
        File[] mFilelist = fold.listFiles();
        if (mlist != null) {
            for (File f : mlist) {
                if (f.isDirectory()) {
                    List<File> fList = getListAllFiles(f.getAbsolutePath());
                    docList.addAll(fList);
                }
            }
            if (mFilelist != null) {
                for (File f : mFilelist) {
                    if (!f.isDirectory() && f.getPath().contains("/.")) {
                        if (!f.getName().isEmpty()) {
                            if (f.length() > 0) {
                                docList.add(f);
                            }
                        }
                    }
                }
            }
        }
        return docList;
    }

    public static List<File> getListAllFiles(String path) {
//        Log.e("Utils", "getListAllFiles:"+path);
        File fold = new File(path);
        List<File> docList = new ArrayList<>();
        File[] mlist = fold.listFiles();
        File[] mFilelist = fold.listFiles(new AllHiddenFilter());
        if (mlist != null) {
            for (File f : mlist) {
                if (f.isDirectory()) {
                    List<File> fList = getListAllFiles(f.getAbsolutePath());
                    docList.addAll(fList);
                }
            }
            if (mFilelist != null) {
                for (File f : mFilelist) {
                    if (!f.isDirectory()) {
                        if (!f.getName().isEmpty()) {
                            if (f.length() > 0) {
                                docList.add(f);
                            }
                        }
                    }
                }
            }
        }
        return docList;
    }


    private static class AllHiddenFilter implements FileFilter {

//        ArrayList<String> filters;

        public AllHiddenFilter() {
//            this.filters = filters;
        }

        @Override
        public boolean accept(File pathname) {
            String path = pathname.getAbsolutePath();
//            for (String filter : filters)
//                if (path.toLowerCase().matches(filter.toLowerCase()) && !path.contains("Backup And Recovery"))
            if (!path.contains("Backup And Recovery"))
                return true;
            return false;
        }
    }


    private static List<FileModel> getAllEmpty(String path) {
        Log.e("Utils", "getAllEmpty:" + path);
        File fold = new File(path);
        List<FileModel> docList = new ArrayList<>();
        File[] mlist = fold.listFiles();
        File[] mFilelist = fold.listFiles(new AllEmptyFilter());

        if (mlist != null) {
            for (File f : mlist) {
                if (f.isDirectory()) {
                    if (!f.getAbsolutePath().contains("Backup And Recovery") && !f.getAbsolutePath().contains("Android")) {
                        List<FileModel> fList = getAllEmpty(f.getAbsolutePath());
                        docList.addAll(fList);
                    }
                }
            }
            Log.e("Utils", "getAllEmpty:mlist:" + mlist.length);
            if (mFilelist != null) {
                for (File f : mFilelist) {
                    if (f.isDirectory()) {
                        if (!f.getName().isEmpty() || !f.getAbsolutePath().contains("Backup And Recovery")) {
                            FileModel doc = new FileModel();
                            doc.setName(f.getName());
                            doc.setSize(f.length());
                            doc.setPath(f.getAbsolutePath());
                            if (f.length() > 0) {
                                docList.add(doc);
                            }
                        }
                    }
                }
            }
        }
        return docList;
    }

    private static ArrayList<File> isFolderEmpty(File folder, String path) {
        ArrayList<File> fileList = new ArrayList<>();
        if (folder.isDirectory()) {
            File[] childFiles = folder.listFiles();
            if (childFiles == null || childFiles.length == 0) {
                Log.e("TAG", "Empty Folder - " + folder.getAbsolutePath());
                fileList.add(folder);
            } else {
                for (File file : childFiles) {
                    if (file.isFile()) {
                        break;
                    } else if (file.isDirectory()) {
                        fileList.addAll(isFolderEmpty(file, path));
                    }
                }
            }
        }
        return fileList;
    }

    // return any time on condition..
    public static <T> T appInfo(Context context, String apkPackageName, String whatThing) {

        T thingType = null;

        ApplicationInfo applicationInfo;

        PackageManager packageManager = context.getPackageManager();

        try {
            applicationInfo = packageManager.getApplicationInfo(apkPackageName, 0);

            if (applicationInfo != null) {

                if (whatThing.matches(Utils.APP_ICON)) {
                    thingType = (T) packageManager.getApplicationIcon(applicationInfo);
                } else if (whatThing.matches(Utils.APP_NAME)) {
                    thingType = (T) packageManager.getApplicationLabel(applicationInfo);
                } else if (whatThing.matches(Utils.APP_VERSION)) {
                    PackageManager pm = context.getPackageManager();
                    PackageInfo packageInfo = pm.getPackageInfo(apkPackageName, 0);
                    thingType = (T) packageInfo.versionName;
                }
            }

        } catch (PackageManager.NameNotFoundException e) {

            e.printStackTrace();
        }
        return thingType;
    }

    public long appSize(Context context, String packageName) throws PackageManager.NameNotFoundException {
        return new File(context.getPackageManager().getApplicationInfo(packageName, 0)
                .publicSourceDir).length();
    }

    public static class AllPackagesFilter implements FileFilter {
        @Override
        public boolean accept(File pathname) {
            String path = pathname.getPath();
            return (pathname.getAbsolutePath().endsWith(".apk") ||
                    pathname.getAbsolutePath().endsWith(".xapk"));
        }
    }

    public static class AllTempLogsFilter implements FileFilter {

        ArrayList<String> filters;

        public AllTempLogsFilter(ArrayList<String> filters) {
            this.filters = filters;
        }

        @Override
        public boolean accept(File pathname) {
            String path = pathname.getAbsolutePath();
            for (String filter : filters)
                if (path.toLowerCase().matches(filter.toLowerCase()) && !path.contains("Backup And Recovery"))
                    return true;
            return false;
        }
    }

    public static class AllEmptyFilter implements FileFilter {
        @Override
        public boolean accept(File pathname) {
            if (isDirectoryEmpty(pathname)) return true;
            return false;
        }
    }

    public static class AllUninstalledFilter implements FileFilter {
        ArrayList<String> filterInstalled;

        public AllUninstalledFilter(ArrayList<String> filterInstalled) {
            this.filterInstalled = filterInstalled;
        }

        @Override
        public boolean accept(File pathname) {
            if (pathname.getParentFile() != null && pathname.getParentFile().getParentFile() != null) {
                if (pathname.getParentFile().getName().equals("data") && pathname.getParentFile().getParentFile().getName().equals("Android"))
                    if (!filterInstalled.contains(pathname.getName()) && !pathname.getName().equals(".nomedia"))
                        return true;
            }

            return false;
        }
    }

    private static boolean isDirectoryEmpty(File directory) {
        if (directory.list() != null && directory.list() != null)
            return Objects.requireNonNull(directory.list()).length == 0;
        else return false;
    }

    public static boolean isNetworkConnected(Context mActivity) {
        ConnectivityManager cm = (ConnectivityManager) mActivity.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }

    public static String isWifiConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null) { // connected to the internet
            if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                // connected to wifi
                return context.getResources().getString(R.string.wifi);
            } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                // connected to the mobile provider's data plan
                return context.getResources().getString(R.string.network);
            }
        } else {
            return context.getResources().getString(R.string.unavailable);
        }
        return "";
    }

    public static HashSet<String> getExternalMounts() {
        final HashSet<String> out = new HashSet<String>();
        String reg = "(?i).*vold.*(vfat|ntfs|exfat|fat32|ext3|ext4).*rw.*";
        String s = "";
        try {
            final Process process = new ProcessBuilder().command("mount")
                    .redirectErrorStream(true).start();
            process.waitFor();
            final InputStream is = process.getInputStream();
            final byte[] buffer = new byte[1024];
            while (is.read(buffer) != -1) {
                s = s + new String(buffer);
            }
            is.close();
        } catch (final Exception e) {
            e.printStackTrace();
        }

        // parse output
        final String[] lines = s.split("\n");
        for (String line : lines) {
            if (!line.toLowerCase(Locale.US).contains("asec")) {
                if (line.matches(reg)) {
                    String[] parts = line.split(" ");
                    for (String part : parts) {
                        if (part.startsWith("/"))
                            if (!part.toLowerCase(Locale.US).contains("vold")) {
                                out.add(part);
//                                Log.e("ScanLocation", "externalMounts:out.add: " + part);
                            }
                    }
                }
            }
        }
        return out;
    }

    /**
     * Returns MAC address of the given interface name.
     *
     * @param interfaceName eth0, wlan0 or NULL=use first interface
     * @return mac address or empty string
     */
    public static String getMACAddress(String interfaceName) {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                if (interfaceName != null) {
                    if (!intf.getName().equalsIgnoreCase(interfaceName)) continue;
                }
                byte[] mac = intf.getHardwareAddress();
                if (mac == null) return "";
                StringBuilder buf = new StringBuilder();
                for (byte aMac : mac) buf.append(String.format("%02X:", aMac));
                if (buf.length() > 0) buf.deleteCharAt(buf.length() - 1);
                return buf.toString();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

    /**
     * Get IP address from first non-localhost interface
     *
     * @param useIPv4 true=return ipv4, false=return ipv6
     * @return address or empty string
     */
    public static String getIPAddress(boolean useIPv4) {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                for (InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress()) {
                        String sAddr = addr.getHostAddress();
                        //boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr);
                        boolean isIPv4 = sAddr.indexOf(':') < 0;

                        if (useIPv4) {
                            if (isIPv4)
                                return sAddr;
                        } else {
                            if (!isIPv4) {
                                int delim = sAddr.indexOf('%'); // drop ip6 zone suffix
                                return delim < 0 ? sAddr.toUpperCase() : sAddr.substring(0, delim).toUpperCase();
                            }
                        }
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

}
