package com.backup.restore.device.image.recovery.mainduplicate.activity.duplicateactivities

import android.app.Dialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.text.format.Formatter
import android.util.Log
import android.view.*
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.duplicatenew.ActivityDuplicateFileScanner
import com.backup.restore.device.image.recovery.duplicatenew.adapters.AdapterDuplicate
import com.backup.restore.device.image.recovery.duplicatenew.models.DuplicateGroupModel
import com.backup.restore.device.image.recovery.duplicatenew.models.FileDetails
import com.backup.restore.device.image.recovery.duplicatenew.utils.Constants
import com.backup.restore.device.image.recovery.duplicatenew.utils.DuplicatePreferences
import com.backup.restore.device.image.recovery.duplicatenew.utils.algorathm.DuplicateFilesAsyncTask
import com.backup.restore.device.image.recovery.main.NewHomeActivity
import com.backup.restore.device.image.recovery.mainduplicate.asynctask.DeleteDuplicateMediaAsyncTask
import com.backup.restore.device.image.recovery.mainduplicate.callbacks.MarkedListener
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateFileRemoverSharedPreferences
import com.backup.restore.device.image.recovery.mainduplicate.model.PopUp
import com.backup.restore.device.image.recovery.utilities.DuplicateScanningListener
import com.backup.restore.device.image.recovery.utilities.MyAnnotations
import com.backup.restore.device.image.recovery.utilities.common.GlobalVarsAndFunctions
import com.backup.restore.device.image.recovery.utilities.common.MyUtils
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import kotlinx.android.synthetic.main.activity_duplicate_images.*

class NewDuplicateMediaActivityNEW : MyCommonBaseActivity(), MarkedListener,
    DuplicateScanningListener {
    var mTAG: String = javaClass.simpleName

    var mDuplicateFound = 0
    var index = -1
    var top = -1
    var isFromOneSignal = false
    var adapter: AdapterDuplicate? = null
    var scanType = ""
    var selectedFile: ArrayList<FileDetails> = ArrayList()

    var textViewScanning: TextView? = null
    var lottieProgressbar: LottieAnimationView? = null

    //var observeFilesExecutor: DuplicateFilesExecutor? = null
    var observeFilesExecutor: DuplicateFilesAsyncTask? = null

    companion object {
        var isScanRunning = false
        var mLayoutManager: LinearLayoutManager? = null

        @JvmField
        var recyclerViewForIndividualGrp: RecyclerView? = null
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_duplicate_images)
        Log.e(mTAG, "onCreate: ")
    }

    override fun getContext(): AppCompatActivity {
        return this@NewDuplicateMediaActivityNEW
    }

    override fun initData() {
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }
        if (intent.hasExtra(MyAnnotations.DATA_TYPE)) {
            scanType = intent.getStringExtra(MyAnnotations.DATA_TYPE)!!
        }

        setSupportActionBar(toolbar)

        textViewScanning = findViewById(R.id.tvCount)
        lottieProgressbar = findViewById(R.id.lottie_progressbar)

        recyclerViewForIndividualGrp = findViewById(R.id.recycler_view_images)
        mLayoutManager = LinearLayoutManager(mContext)
        recyclerViewForIndividualGrp!!.layoutManager = mLayoutManager
        recyclerViewForIndividualGrp!!.setHasFixedSize(true)
        initiateDataInPage()

        GlobalVarsAndFunctions.listOfDuplicates.clear()
        GlobalVarsAndFunctions.fileToBeDeleted.clear()

        when (scanType) {
            MyAnnotations.IMAGES -> {
                startScanning(MyAnnotations.IMAGES)
                ActivityDuplicateFileScanner.whichButtonClicked = MyAnnotations.IMAGES
                isScanRunning = true
            }
            MyAnnotations.VIDEOS -> {
                startScanning(MyAnnotations.VIDEOS)
                ActivityDuplicateFileScanner.whichButtonClicked = MyAnnotations.VIDEOS
                isScanRunning = true
            }
            MyAnnotations.AUDIOS -> {
                startScanning(MyAnnotations.AUDIOS)
                ActivityDuplicateFileScanner.whichButtonClicked = MyAnnotations.AUDIOS
                isScanRunning = true
            }
            MyAnnotations.DOCUMENTS -> {
                startScanning(MyAnnotations.DOCUMENTS)
                ActivityDuplicateFileScanner.whichButtonClicked = MyAnnotations.DOCUMENTS
                isScanRunning = true
            }
            MyAnnotations.OTHER -> {
                startScanning(MyAnnotations.OTHER)
                ActivityDuplicateFileScanner.whichButtonClicked = MyAnnotations.OTHER
                isScanRunning = true
            }
        }

    }

    private fun startScanning(type: String) {
        observeFilesExecutor = DuplicateFilesAsyncTask(this, this, type)
        observeFilesExecutor!!.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

        recyclerViewForIndividualGrp!!.visibility = View.VISIBLE
        delete_exception_frame_layout!!.visibility = View.VISIBLE
        ll_no_duplicate!!.visibility = View.GONE

    }

    override fun initActions() {
        delete.setOnClickListener(this)
        backpress_Image!!.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
            return
        }
        ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.backpress_Image -> onBackPressed()
            R.id.delete -> {
                if (isScanRunning) {
                    Toast.makeText(
                        mContext,
                        getString(R.string.process_running_please_wait),
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    selectedFile = adapter?.getSelectedFile()!!
                    deleteDuplicate()
                }
            }
        }
    }

    private fun initiateDataInPage() {
        try {

            mDuplicateFound = 0
            for (singleGroup in GlobalVarsAndFunctions.listOfDuplicates) {
                mDuplicateFound += singleGroup.individualGrpOfDupes!!.size
            }


            if(mDuplicateFound==0) {
                recyclerViewForIndividualGrp!!.visibility = View.GONE
                delete_exception_frame_layout!!.visibility = View.GONE
                ll_no_duplicate!!.visibility = View.VISIBLE
            } else {
                recyclerViewForIndividualGrp!!.visibility = View.VISIBLE
                delete_exception_frame_layout!!.visibility = View.VISIBLE
                ll_no_duplicate!!.visibility = View.GONE
            }

            when (scanType) {
                MyAnnotations.IMAGES -> {
                    tv_title.text = getString(R.string.image_duplicate)
//                    empty_image.setImageResource(R.drawable.ic_backup_not_found_image)
                    empty_lable.text = getString(R.string.no_duplicate_image_found)
                    adapter = AdapterDuplicate(mContext, this, MyAnnotations.IMAGES)
                }
                MyAnnotations.VIDEOS -> {
                    tv_title.text = getString(R.string.video_duplicate)
//                    empty_image.setImageResource(R.drawable.ic_backup_not_found_video)
                    empty_lable.text = getString(R.string.no_duplicate_video_found)
                    adapter = AdapterDuplicate(mContext, this, MyAnnotations.VIDEOS)
                }
                MyAnnotations.AUDIOS -> {
                    tv_title.text = getString(R.string.audio_duplicate)
//                    empty_image.setImageResource(R.drawable.ic_backup_not_found_audio)
                    empty_lable.text = getString(R.string.no_duplicate_audio_found)
                    adapter = AdapterDuplicate(mContext, this, MyAnnotations.AUDIOS)
                }
                MyAnnotations.DOCUMENTS -> {
                    tv_title.text = getString(R.string.documents_duplicate)
//                    empty_image.setImageResource(R.drawable.ic_backup_not_found_doc)
                    empty_lable.text = getString(R.string.no_duplicate_document_found)
                    adapter = AdapterDuplicate(mContext, this, MyAnnotations.DOCUMENTS)
                }
                MyAnnotations.OTHER -> {
                    tv_title.text = getString(R.string.other_duplicate)
//                    empty_image.setImageResource(R.drawable.ic_backup_not_found_other)
                    empty_lable.text = getString(R.string.no_duplicate_other_found)
                    adapter = AdapterDuplicate(mContext, this, MyAnnotations.OTHER)
                }
                else -> {
                    tv_title.text = getString(R.string.image_duplicate)
//                    empty_image.setImageResource(R.drawable.ic_backup_not_found_image)
                    empty_lable.text = getString(R.string.no_duplicate_image_found)
                    adapter = AdapterDuplicate(mContext, this, MyAnnotations.IMAGES)
                }
            }
            recyclerViewForIndividualGrp!!.adapter = adapter
            imagesSelectAllAndDeselectAll(
                SharedPrefsConstant.getBooleanNoti(
                    this@NewDuplicateMediaActivityNEW,
                    "duplicateSelection",
                    true
                )
            )

            updateMarked()
            updateDuplicateFound(mDuplicateFound)

            Log.e(mTAG, "initiateDataInPage: ")
        } catch (e: Exception) {
            Log.e(mTAG, "initiateDataInPage: " + e.message)
        }
    }


    public override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)
        if (requestCode == GlobalVarsAndFunctions.REQUEST_CODE_OPEN_DOCUMENT_TREE && resultCode == -1) {
            if (MyUtils.isSelectedStorageAccessFrameWorkPathIsProper(
                    mContext,
                    DocumentFile.fromTreeUri(mContext, resultData!!.data!!)!!.name
                )
            ) {
                DuplicateFileRemoverSharedPreferences.setStorageAccessFrameWorkURIPermission(
                    mContext,
                    resultData.data.toString()
                )
                showDeleteDialog()
                return
            }
            Toast.makeText(
                mContext,
                getString(R.string.select_external_storage_dir),
                Toast.LENGTH_SHORT
            ).show()
            try {
                startActivityForResult(
                    Intent("android.intent.action.OPEN_DOCUMENT_TREE"),
                    GlobalVarsAndFunctions.REQUEST_CODE_OPEN_DOCUMENT_TREE
                )
            } catch (e: Exception) {
                Log.d("Exception", "Exception Handled")
                Toast.makeText(getContext(), "No App found supporting feature.", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }

    private fun showDeleteDialog() {
        if (GlobalVarsAndFunctions.fileToBeDeleted.size == 1) {
            //PopUp(mContext, mContext).
            deleteAlertPopUp(
                scanType,
                getString(R.string.delete_alert_message_photo_single),
                getString(R.string.delete_dialog_message_photo_single),
                //GlobalVarsAndFunctions.fileToBeDeleted,
                selectedFile,
                Constants.getSize(),
                GlobalVarsAndFunctions.listOfDuplicates,
                this
            )
        } else {
            //PopUp(mContext, mContext).
            deleteAlertPopUp(
                scanType,
                getString(R.string.delete_alert_message_photos),
                getString(R.string.delete_dialog_message_photos),
                //GlobalVarsAndFunctions.fileToBeDeleted,
                selectedFile,
                Constants.getSize(),
                GlobalVarsAndFunctions.listOfDuplicates,
                this
            )
        }
    }

    fun deleteAlertPopUp(
        mType: String?,
        alertMessage: String?,
        dialogMessage: String,
        fileToBeDeleted: ArrayList<FileDetails>?,
        deletingFileSize: Long,
        groupOfDuplicates: List<DuplicateGroupModel>,
        imagesMarkedListener: MarkedListener
    ) {

        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<TextView>(R.id.permission).text =
            mContext.getString(R.string.delete_alert_title)
        dialog.findViewById<TextView>(R.id.permission_text).text = alertMessage
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = mContext.getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text =
            mContext.getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            SharedPrefsConstant.savePrefNoti(mContext, "isDeleteFromEmpty", true)
            if (fileToBeDeleted != null) {
                DeleteDuplicateMediaAsyncTask(
                    mType,
                    mContext,
                    mContext,
                    imagesMarkedListener,
                    dialogMessage,
                    fileToBeDeleted,
                    deletingFileSize,
                    groupOfDuplicates
                ).execute()
                SharedPrefsConstant.save(
                    mContext,
                    ShareConstants.RATE_DUPLICATE_COUNT,
                    SharedPrefsConstant.getInt(mContext, ShareConstants.RATE_DUPLICATE_COUNT) + 1
                )
            }
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
        }
        dialog.show()
    }

    private fun deleteDuplicate() {
        when {
            GlobalVarsAndFunctions.fileToBeDeleted.size <= 0 -> {
                MyUtils.showToastMsg(mContext, getString(R.string.select_at_least_one_image))
            }
            Build.VERSION.SDK_INT >= 20 -> {
                showDeleteDialog()
            }
            MyUtils.getSDCardPath(mContext) == null -> {
                showDeleteDialog()
            }
            DuplicateFileRemoverSharedPreferences.getStorageAccessFrameWorkURIPermission(mContext) != null -> {
                showDeleteDialog()
            }
            else -> {
                grantPermissionWithAlertDialog()
            }
        }
    }

    private fun grantPermissionWithAlertDialog() {
        val builder = AlertDialog.Builder(mContext)
        builder.setView(layoutInflater.inflate(R.layout.dialog_saf_permission, null))
        builder.setCancelable(false)
        builder.setPositiveButton("Allow Permission" as CharSequence, PermissionYes())
        builder.setNegativeButton("Cancel" as CharSequence) { dialog: DialogInterface, _: Int -> dialog.dismiss() }
        val dialog = builder.create()
        dialog.show()
        val pButton = dialog.getButton(-1)
        pButton.setTextColor(ContextCompat.getColor(mContext, R.color.colorPrimary))
        pButton.isAllCaps = false
        dialog.getButton(-2).isAllCaps = false
    }

    internal inner class PermissionYes : DialogInterface.OnClickListener {
        override fun onClick(dialog: DialogInterface, which: Int) {
            dialog.dismiss()
            try {
                startActivityForResult(
                    Intent("android.intent.action.OPEN_DOCUMENT_TREE"),
                    GlobalVarsAndFunctions.REQUEST_CODE_OPEN_DOCUMENT_TREE
                )
            } catch (e: Exception) {
                Log.d("Exception", "Exception Handled")
                Toast.makeText(getContext(), "No App found supporting feature.", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }


    public override fun onPause() {
        var i = 0
        super.onPause()
        index = mLayoutManager!!.findFirstVisibleItemPosition()
        val v = recyclerViewForIndividualGrp!!.getChildAt(0)
        if (v != null) {
            i = v.top - recyclerViewForIndividualGrp!!.paddingTop
        }
        top = i
    }

    public override fun onResume() {
        super.onResume()
        if (index != -1) {
            mLayoutManager!!.scrollToPositionWithOffset(index, top)
        }
        if (observeFilesExecutor == null) {
            observeFilesExecutor = DuplicateFilesAsyncTask(
                this, this,
                ActivityDuplicateFileScanner.whichButtonClicked
            )
        }
//        if (observeFilesExecutor!!.stopped) {
//            ActivityDuplicateFileScanner.whichButtonClicked = ""
//        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.settings_1, menu)
        if (GlobalVarsAndFunctions.listOfDuplicates.size == 0) {
            menu.findItem(R.id.action_selectall).isEnabled = false
            menu.findItem(R.id.action_deselectall).isEnabled = false
        } else {
            menu.findItem(R.id.action_selectall).isEnabled = true
            menu.findItem(R.id.action_deselectall).isEnabled = true
        }
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        if (GlobalVarsAndFunctions.listOfDuplicates.size == 0) {
            menu.findItem(R.id.action_selectall).isEnabled = false
            menu.findItem(R.id.action_deselectall).isEnabled = false
        } else {
            menu.findItem(R.id.action_selectall).isEnabled = true
            menu.findItem(R.id.action_deselectall).isEnabled = true
        }
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        val intent: Intent
        when (id) {
            R.id.action_home -> {
                if (isScanRunning) {
                    PopUp(mContext, mContext).showAlertStopScanning(observeFilesExecutor!!)
                } else {
                    finish()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
                return true
            }
            R.id.action_rescan -> {
                if (isScanRunning) {
                    Toast.makeText(
                        mContext,
                        getString(R.string.task_already_running),
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    GlobalVarsAndFunctions.resetOneTimePopUp()
                    GlobalVarsAndFunctions.fileToBeDeleted.clear()
//                    intent = Intent(mContext, ActivityDuplicateFileScanner::class.java)
                    intent = Intent(mContext, NewDuplicateMediaActivityNEW::class.java)
                    intent.putExtra(MyAnnotations.DATA_TYPE, scanType)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(
                        intent,
                        ActivityOptionsCompat.makeCustomAnimation(
                            mContext,
                            android.R.anim.fade_in,
                            android.R.anim.fade_out
                        ).toBundle()
                    )
                    finish()
                }
                return true
            }
            R.id.action_selectall -> {
                if (isScanRunning) {
                    Toast.makeText(
                        mContext,
                        getString(R.string.process_running_please_wait),
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    if (GlobalVarsAndFunctions.listOfDuplicates.size == 0) {
//                    Toast.makeText(mContext, "No Duplicate Data Found", Toast.LENGTH_SHORT).show()
                    } else {
                        imagesSelectAllAndDeselectAll(true)
                    }
                }

                return true
            }
            R.id.action_deselectall -> {
                if (isScanRunning) {
                    Toast.makeText(
                        mContext,
                        getString(R.string.process_running_please_wait),
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    if (GlobalVarsAndFunctions.listOfDuplicates.size == 0) {
//                    Toast.makeText(mContext, "No Duplicate Data Found", Toast.LENGTH_SHORT).show()
                    } else {
                        imagesSelectAllAndDeselectAll(false)
                    }
                }
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    private fun imagesSelectAllAndDeselectAll(b: Boolean) {

        Constants.resetSize()
        for (singleGroup in GlobalVarsAndFunctions.listOfDuplicates) {
            singleGroup.isCheckBox = b
            for (i in singleGroup.individualGrpOfDupes!!.indices) {
//            for (fileDetails in singleGroup) {
                if (i != 0) {
                    singleGroup.individualGrpOfDupes!![i].isChecked = b
                    if (b) Constants.addSize(singleGroup.individualGrpOfDupes!![i].fileSize)
                } else {
                    singleGroup.individualGrpOfDupes!![i].isChecked = false
                }
            }
        }

        adapter?.notifyDataSetChanged()

        updateMarked()
    }


    override fun updateDuplicateFound(duplicateFound: Int) {
        try {
            runOnUiThread {
                (findViewById<View>(R.id.dupes_found) as TextView).text =
                    getString(R.string.duplicate_found) + duplicateFound
            }
        } catch (e: Exception) {
            Log.e(mTAG, "updateDuplicateFound: " + e.message)
        }
    }


    override fun updateMarked() {
        try {

            runOnUiThread(SetBottomMark())
        } catch (e: Exception) {
            Log.e(mTAG, "updateMarked: " + e.message)
        }
    }

    internal inner class SetBottomMark : Runnable {
        override fun run() {
            val tvMarked = findViewById<TextView>(R.id.marked)
            tvMarked.visibility = View.VISIBLE
            tvMarked.text = "( ${mContext.getString(R.string.size)} " + Formatter.formatFileSize(
                mContext,
                Constants.getSize()
            ) + " )"
        }
    }

    override fun cleaned(numberOfPhotosCleaned: Int) {
        Log.e(mTAG, "photosCleanedImages: ")
        try {
            runOnUiThread {
                val filesCleaned =
                    DuplicateFileRemoverSharedPreferences.getFilesCleaned(mContext) + numberOfPhotosCleaned
                DuplicateFileRemoverSharedPreferences.setFilesCleaned(mContext, filesCleaned)
            }
        } catch (e: Exception) {
            Log.e(mTAG, "Cleaned: " + e.message)
        }
    }

    override fun updatePageDetails(str1: String?, str2: String?, int1: Int, obj: Any?) {
        adapter!!.notifyDataSetChanged()
    }

    override fun onBackPressed() {
//        if(observeFilesExecutor!!.status==AsyncTask.Status.RUNNING) {
//            observeFilesExecutor!!.cancel(true)
//        }

        if (isScanRunning) {
            PopUp(mContext, mContext).showAlertStopScanning(observeFilesExecutor!!)
        } else {
            if (isFromOneSignal) {
                startActivity(NewHomeActivity.newIntent(this))
                finish()
            } else {
                finish()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
        }
    }


    override fun checkScanning() {
        if (ActivityDuplicateFileScanner.whichButtonClicked == MyAnnotations.IMAGES) {
            return
        }
        if (ActivityDuplicateFileScanner.whichButtonClicked == MyAnnotations.VIDEOS) {
            return
        }
        if (ActivityDuplicateFileScanner.whichButtonClicked == MyAnnotations.AUDIOS) {
            return
        }
        if (ActivityDuplicateFileScanner.whichButtonClicked == MyAnnotations.DOCUMENTS) {
            return
        }
        if (ActivityDuplicateFileScanner.whichButtonClicked == MyAnnotations.OTHER) {
            return
        }

        DuplicatePreferences.setStopScanForNotification(this, true)
        DuplicatePreferences.setNavigateFromHome(this, true)
    }

    private fun tvUpdates(msg: String) {

        textViewScanning!!.text = msg

        AsyncTask.THREAD_POOL_EXECUTOR.execute {
            runOnUiThread {
                mDuplicateFound = 0

                for (singleGroup in GlobalVarsAndFunctions.listOfDuplicates) {
                    mDuplicateFound += singleGroup.individualGrpOfDupes!!.size
                }
                updateDuplicateFound(mDuplicateFound)
            }

        }

    }


    override fun publishProgress(vararg count: String) {
        try {
            if (ActivityDuplicateFileScanner.whichButtonClicked == MyAnnotations.IMAGES || ActivityDuplicateFileScanner.whichButtonClicked == MyAnnotations.VIDEOS || ActivityDuplicateFileScanner.whichButtonClicked == MyAnnotations.AUDIOS || ActivityDuplicateFileScanner.whichButtonClicked == MyAnnotations.DOCUMENTS || ActivityDuplicateFileScanner.whichButtonClicked == MyAnnotations.OTHER) {
                if (count != null) if (count.size > 1) {
                    if (count[0].equals("Sorting", ignoreCase = true)) {
                        return
                    }
                    if (count[0] == count[1]) {
//                        isScanRunning = false
                        textViewScanning!!.visibility = View.GONE
                        lottieProgressbar!!.visibility = View.GONE
                    }
                    val counter = count[0] + " / " + count[1]
                    tvUpdates(counter)
                    adapter!!.notifyDataSetChanged()
                }
            } else {
                //randomQuotes()
//                isScanRunning = false
                lottieProgressbar!!.visibility = View.GONE
                textViewScanning!!.visibility = View.GONE
                adapter!!.notifyDataSetChanged()
                if (count[0].equals("Sorting", ignoreCase = true)) {
                    return
                }
//                val msg = "Files " + count[0]
//                tvUpdates(msg)
            }
        } catch (exception: Exception) {
            exception.printStackTrace()
        }
    }


    override fun publishProgress(duplicatesList: List<DuplicateGroupModel>) {
        if (duplicatesList != null) {
            if (isScanRunning) {
                GlobalVarsAndFunctions.listOfDuplicates = duplicatesList
                if (GlobalVarsAndFunctions.listOfDuplicates.size > 0) {
                    MyApplication.isInterstitialShown = false;
                    adapter!!.notifyDataSetChanged()
                } else {
                    adapter!!.notifyDataSetChanged()
                }
            } else {
                initiateDataInPage()
            }
        }
    }


}