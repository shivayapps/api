package com.backup.restore.device.image.recovery.observer

interface AnalyticsReporter {

    fun report(event: String)

    fun sendAllEvents()
}