package com.backup.restore.device.image.recovery.mainphotos.trashadapter;

import static com.backup.restore.device.image.recovery.utilities.UtilsKt.doCopyFile;
import static com.backup.restore.device.image.recovery.utilities.common.ShareConstants.getReadableFileSize;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.aainc.recyclebin.d.c;
import com.aainc.recyclebin.database.FilesProtectionContentProvider;
import com.backup.restore.device.image.recovery.R;
import com.backup.restore.device.image.recovery.mainphotos.model.TrashModel;
import com.backup.restore.device.image.recovery.mainphotos.trashfragment.TrashAudioFragment;
import com.backup.restore.device.image.recovery.mainphotos.trashfragment.TrashDocumentFragment;
import com.backup.restore.device.image.recovery.mainphotos.trashfragment.TrashOtherFragment;

import java.io.File;
import java.io.IOException;

public class AudioOtherTrashAdapter extends CursorAdapter {

    public static final String j = AudioOtherTrashAdapter.class.getSimpleName();
    Fragment mFragment;
    String mType = "";
    CheckBox mCheckBox;
    Cursor cursor;
    String isForSort;


    public AudioOtherTrashAdapter(Context context, Fragment fragment, Cursor cursor, int i, String type, CheckBox checkAll, String isForSort) {
        super(context, cursor, i);
        mType = type;
        mFragment = fragment;
        mCheckBox = checkAll;
        this.cursor = cursor;
        this.isForSort = isForSort;
    }

    private class myCommonClass {

        CheckBox audioCheckbox;
        TextView audioFileName;
        TextView audioFilePath;
        TextView audioFileSize;
        ImageView imageView;

        private myCommonClass() {
        }
    }


    public int b(Context context, int i) {
        return context.getContentResolver().delete(FilesProtectionContentProvider.a, "_id = ? ", new String[]{String.valueOf(i)});
    }

    public Cursor a(Context context) {
        String whereClause = "type_file=?";
        String[] whereArgs = {mType};
        String sortOrder = "";
        switch (isForSort) {
            case "size_asc":
                sortOrder = "file_size ASC";
                break;
            case "size_desc":
                sortOrder = "file_size DESC";
                break;
            case "date_desc":
                sortOrder = "deleted_at ASC";
                break;
            case "date_asc":
                sortOrder = "deleted_at DESC";
                break;
        }
        return context.getContentResolver().query(FilesProtectionContentProvider.a, null, whereClause, whereArgs, sortOrder);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        Log.e("TAG", "newView method=====================================");
        View inflate = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.raw_list_of_trash_files_item, viewGroup, false);

        return inflate;
    }

    public void recover(Context mContext, String path, int ids) {
        try {
            Integer num = Integer.parseInt(String.valueOf(ids));
            Log.e("TAG", "recover: " + num);
            synchronized (this) {
                String a2 = a(mContext, num);

                Log.e("mTAGs", "recover:a2 " + a2);
                Log.e("mTAGs", "recover:path " + path);
//                c.b(a2, path);

                //FileUtils.copyFile(new File(a2), new File(path));
                doCopyFile(new File(a2), new File(path),true);

                if (!c.c(a2)) {
                    throw new IOException("Restored file can't be deleted from myfrgamant database protected files and device storage.");
                } else if (b(mContext, num.intValue()) == 0) {
                    throw new SQLiteException("Data about restored file can't be removed from myfrgamant database.");
                }
            }
//            Cursor a3 = a(mContext);
//            changeCursor(a3);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String a(Context context, int i) {
        Uri.Builder builder = new Uri.Builder();
        builder.scheme(FilesProtectionContentProvider.a.getScheme());
        builder.authority(FilesProtectionContentProvider.a.getAuthority());
        for (String appendPath : FilesProtectionContentProvider.a.getPathSegments()) {
            builder.appendPath(appendPath);
        }
        builder.appendEncodedPath(String.valueOf(i));
        Cursor query = context.getContentResolver().query(builder.build(), new String[]{"trash_path"}, null, null, null);
        if (query == null || !query.moveToFirst()) {
        }
        String string = query.getString(0);
        if (string != null) {
            return string;
        }
        return null;
    }

    public void selectAll() {
        if (cursor != null && cursor.getCount() > 0) {
            cursor.moveToFirst();
            do {
                int id = cursor.getInt(0);
                String path = cursor.getString(3);

                TrashModel lTrashModel = new TrashModel();
                lTrashModel.setPath(path);
                lTrashModel.setId(id);

                if (mFragment instanceof TrashAudioFragment) {
                    if (!((TrashAudioFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashAudioFragment) mFragment).getSelectedList().add(lTrashModel);
                    if (cursor.getCount() == ((TrashAudioFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(true);
                    }
                }
                if (mFragment instanceof TrashDocumentFragment) {
                    if (!((TrashDocumentFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashDocumentFragment) mFragment).getSelectedList().add(lTrashModel);
                    if (cursor.getCount() == ((TrashDocumentFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(true);
                    }
                }
                if (mFragment instanceof TrashOtherFragment) {
                    if (!((TrashOtherFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashOtherFragment) mFragment).getSelectedList().add(lTrashModel);
                    if (cursor.getCount() == ((TrashOtherFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(true);
                    }
                }
            }
            while (cursor.moveToNext());
            notifyDataSetChanged();
        }
        Log.d("ghjgsdasjd", "initActions: fragment --> Cursor Null");
    }

    public void deSelectAll() {
        if (cursor != null && cursor.getCount() > 0) {
            cursor.moveToFirst();
            do {
                int id = cursor.getInt(0);
                String path = cursor.getString(3);

                TrashModel lTrashModel = new TrashModel();
                lTrashModel.setPath(path);
                lTrashModel.setId(id);

                if (mFragment instanceof TrashAudioFragment) {
                    if (((TrashAudioFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashAudioFragment) mFragment).getSelectedList().remove(lTrashModel);
                    if (cursor.getCount() != ((TrashAudioFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(false);
                    }
                }
                if (mFragment instanceof TrashDocumentFragment) {
                    if (((TrashDocumentFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashDocumentFragment) mFragment).getSelectedList().remove(lTrashModel);
                    if (cursor.getCount() != ((TrashDocumentFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(false);
                    }
                }
                if (mFragment instanceof TrashOtherFragment) {
                    if (((TrashOtherFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashOtherFragment) mFragment).getSelectedList().remove(lTrashModel);
                    if (cursor.getCount() != ((TrashOtherFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(false);
                    }
                }
            }
            while (cursor.moveToNext());
            notifyDataSetChanged();
        }
    }


    @Override
    public void bindView(View view, final Context context, final Cursor cursor) {

        myCommonClass lMyCommonClass = new myCommonClass();

        lMyCommonClass.audioCheckbox = view.findViewById(R.id.audiocheckbox);
        lMyCommonClass.audioFileName = view.findViewById(R.id.fileName);
        lMyCommonClass.audioFilePath = view.findViewById(R.id.filePath);
        lMyCommonClass.audioFileSize = view.findViewById(R.id.fileSize);
        lMyCommonClass.imageView = view.findViewById(R.id.audioFile);
        lMyCommonClass.audioFilePath.setSelected(true);
        lMyCommonClass.audioFileName.setText(cursor.getString(1));
        lMyCommonClass.audioFilePath.setText(cursor.getString(2) + cursor.getString(1));
        lMyCommonClass.audioFileSize.setText(getReadableFileSize(new File(cursor.getString(3)).length()));

        int id = cursor.getInt(0);
        String path = cursor.getString(3);

        TrashModel lTrashModel = new TrashModel();
        lTrashModel.setPath(path);
        lTrashModel.setId(id);

        if (mType.equals("Audio")) {
            lMyCommonClass.imageView.setImageResource(R.drawable.music_icon);
        } else {
            lMyCommonClass.imageView.setImageResource(R.drawable.doc_fill);
        }

        if (mFragment instanceof TrashAudioFragment) {
            Log.d("Audio ghdsfhg", "bindView: " + ((TrashAudioFragment) mFragment).getSelectedList().contains(lTrashModel));
            if (((TrashAudioFragment) mFragment).getSelectedList().contains(lTrashModel)) {
                lMyCommonClass.audioCheckbox.setSelected(true);
            } else {
                lMyCommonClass.audioCheckbox.setSelected(false);
            }
        }
        if (mFragment instanceof TrashDocumentFragment) {
            Log.d("Document ghdsfhg", "bindView: " + ((TrashDocumentFragment) mFragment).getSelectedList().contains(lTrashModel));
            if (((TrashDocumentFragment) mFragment).getSelectedList().contains(lTrashModel)) {
                lMyCommonClass.audioCheckbox.setSelected(true);
            } else {
                lMyCommonClass.audioCheckbox.setSelected(false);
            }
        }
        if (mFragment instanceof TrashOtherFragment) {
            Log.d("Other ghdsfhg", "bindView: " + ((TrashOtherFragment) mFragment).getSelectedList().contains(lTrashModel));
            if (((TrashOtherFragment) mFragment).getSelectedList().contains(lTrashModel)) {
                lMyCommonClass.audioCheckbox.setSelected(true);
            } else {
                lMyCommonClass.audioCheckbox.setSelected(false);
            }
        }

       /* lMyCommonClass.audioCheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Log.d("ghjgsdasjd122", "initActions: fragment checkbox -->" + isChecked);
                if (!isChecked) {
//                    lMyCommonClass.audioCheckbox.setChecked(false);
                    if (mFragment instanceof TrashAudioFragment) {
                        ((TrashAudioFragment) mFragment).getSelectedList().remove(lTrashModel);
                        if (cursor.getCount() != ((TrashAudioFragment) mFragment).getSelectedList().size()) {
                            mCheckBox.setChecked(false);
                        }
                    } else if (mFragment instanceof TrashDocumentFragment) {
                        ((TrashDocumentFragment) mFragment).getSelectedList().remove(lTrashModel);
                        if (cursor.getCount() != ((TrashDocumentFragment) mFragment).getSelectedList().size()) {
                            mCheckBox.setChecked(false);
                        }
                    } else if (mFragment instanceof TrashOtherFragment) {
                        ((TrashOtherFragment) mFragment).getSelectedList().remove(lTrashModel);
                        if (cursor.getCount() != ((TrashOtherFragment) mFragment).getSelectedList().size()) {
                            mCheckBox.setChecked(false);
                        }
                    }
                } else {
//                    lMyCommonClass.audioCheckbox.setChecked(true);
                    if (mFragment instanceof TrashAudioFragment) {
                        if (!((TrashAudioFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashAudioFragment) mFragment).getSelectedList().add(lTrashModel);
                        if (cursor.getCount() == ((TrashAudioFragment) mFragment).getSelectedList().size()) {
                            mCheckBox.setChecked(true);
                        }
                    } else if (mFragment instanceof TrashDocumentFragment) {
                        if (!((TrashDocumentFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashDocumentFragment) mFragment).getSelectedList().add(lTrashModel);
                        if (cursor.getCount() == ((TrashDocumentFragment) mFragment).getSelectedList().size()) {
                            mCheckBox.setChecked(true);
                        }
                    } else if (mFragment instanceof TrashOtherFragment) {
                        if (!((TrashOtherFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashOtherFragment) mFragment).getSelectedList().add(lTrashModel);
                        if (cursor.getCount() == ((TrashOtherFragment) mFragment).getSelectedList().size()) {
                            mCheckBox.setChecked(true);
                        }
                    }
                }
            }
        });*/


        lMyCommonClass.audioCheckbox.setOnClickListener(v -> {
            if (lMyCommonClass.audioCheckbox.isSelected()) {
                lMyCommonClass.audioCheckbox.setSelected(false);
                if (mFragment instanceof TrashAudioFragment) {
                    ((TrashAudioFragment) mFragment).getSelectedList().remove(lTrashModel);
                    if (cursor.getCount() != ((TrashAudioFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(false);
                    }
                }
                if (mFragment instanceof TrashDocumentFragment) {
                    ((TrashDocumentFragment) mFragment).getSelectedList().remove(lTrashModel);
                    if (cursor.getCount() != ((TrashDocumentFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(false);
                    }
                }
                if (mFragment instanceof TrashOtherFragment) {
                    ((TrashOtherFragment) mFragment).getSelectedList().remove(lTrashModel);
                    if (cursor.getCount() != ((TrashOtherFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(false);
                    }
                }
            } else {
                lMyCommonClass.audioCheckbox.setSelected(true);
                if (mFragment instanceof TrashAudioFragment) {
                    if (!((TrashAudioFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashAudioFragment) mFragment).getSelectedList().add(lTrashModel);
                    if (cursor.getCount() == ((TrashAudioFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(true);
                    }
                }
                if (mFragment instanceof TrashDocumentFragment) {
                    if (!((TrashDocumentFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashDocumentFragment) mFragment).getSelectedList().add(lTrashModel);
                    if (cursor.getCount() == ((TrashDocumentFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(true);
                    }
                }
                if (mFragment instanceof TrashOtherFragment) {
                    if (!((TrashOtherFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashOtherFragment) mFragment).getSelectedList().add(lTrashModel);
                    if (cursor.getCount() == ((TrashOtherFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(true);
                    }
                }
            }

        });
    }

}
