package com.backup.restore.device.image.recovery.mainphotos.trashfragment

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.Cursor
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.aainc.recyclebin.database.FilesProtectionContentProvider
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainphotos.activity.TrashImageActivity
import com.backup.restore.device.image.recovery.mainphotos.activity.TrashImageActivity.Companion.resumeAudioCount
import com.backup.restore.device.image.recovery.mainphotos.model.TrashModel
import com.backup.restore.device.image.recovery.mainphotos.trashadapter.AudioOtherTrashAdapter
import kotlinx.android.synthetic.main.activity_recover_image_new.*
import kotlinx.android.synthetic.main.fragment_trash_audio_doc.*

class TrashAudioFragment : Fragment(), View.OnClickListener {

    val mTAG: String = javaClass.simpleName
    lateinit var mView: View
    var mainCommonAdapter: AudioOtherTrashAdapter? = null
    var selectedList = ArrayList<TrashModel>()
    var isVisibleHint: Boolean = false
    var mCursor: Cursor? = null
    var isForSort = "date_asc"
    var mPrevCursor: Cursor? = null

    fun TrashAudioFragment(){
    }

    companion object {
        fun newInstance(): TrashAudioFragment {
            return TrashAudioFragment()
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requireContext().registerReceiver(refreshMediaBroadcast, IntentFilter("com.progress.audio.Refresh"))
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        if (isAdded) {
            isVisibleHint = isVisibleToUser
            if (isVisibleHint) {
                if (mCursor != null && mCursor!!.count != 0) {
                    if (requireActivity() is TrashImageActivity) {
                        if (TrashImageActivity.lastSelection == 2 && TrashImageActivity.prevPosTrash == 2) {
                            (requireActivity() as TrashImageActivity).toggleRecoverButtonVisibility(true)
                        }
                        when (isForSort) {
                            "size_asc" -> {
                                (requireActivity() as TrashImageActivity).selectSizeAsc()
                                (requireActivity() as TrashImageActivity).isDateClick = true
                                (requireActivity() as TrashImageActivity).isSizeClick = false
                            }
                            "size_desc" -> {
                                (requireActivity() as TrashImageActivity).selectSizeDesc()
                                (requireActivity() as TrashImageActivity).isDateClick = true
                                (requireActivity() as TrashImageActivity).isSizeClick = false
                            }
                            "date_desc" -> {
                                (requireActivity() as TrashImageActivity).selectDateDesc()
                                (requireActivity() as TrashImageActivity).isDateClick = false
                                (requireActivity() as TrashImageActivity).isSizeClick = true
                            }
                            "date_asc" -> {
                                (requireActivity() as TrashImageActivity).selectTop(2)
                                (requireActivity() as TrashImageActivity).isDateClick = false
                                (requireActivity() as TrashImageActivity).isSizeClick = true
                            }
                        }
                        if (requireActivity().iv_span != null) {
                            requireActivity().iv_span.alpha = 1.0F
                            requireActivity().iv_span.isEnabled = true
                        }
                        if (requireActivity().btnRecover != null) {
                            requireActivity().btnRecover.alpha = 1.0F
                            requireActivity().btnRecover.isEnabled = true
                        }
                    }
                } else {
                    if (requireActivity() is TrashImageActivity) {
                        (requireActivity() as TrashImageActivity).toggleRecoverButtonVisibility(false)
                        (requireActivity() as TrashImageActivity).unSelectAll()
                        requireActivity().iv_span.alpha = 0.5F
                        requireActivity().iv_span.isEnabled = false
                    }
                }
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        mView = inflater.inflate(R.layout.fragment_trash_audio_doc, container, false)
        return mView
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        getAppList()
    }

    private fun getAppList() {
//        iv_not_found.setImageResource(R.drawable.ic_backup_not_found_audio)
        tv_not_found.setText(R.string.audio_not_found)
    }

    override fun onClick(view: View) {

    }

    override fun onResume() {
        super.onResume()
        resumeAudioCount +=1
        Log.e(mTAG, "onResume: $isVisibleHint")
        val whereClause = "type_file=?"
        val whereArgs = arrayOf("Audio")
        var sortOrder = ""
        Log.e("TAG", "ListImage  --> onCreate: Audio")
        mPrevCursor = mCursor
        when (isForSort) {
            "size_asc" -> {
                sortOrder = "cast(file_size as INTEGER) ASC"
            }
            "size_desc" -> {
                sortOrder = "cast(file_size as INTEGER) DESC"
            }
            "date_desc" -> {
                sortOrder = "deleted_at ASC"
            }
            "date_asc" -> {
                sortOrder = "deleted_at DESC"
            }

        }
        mCursor = requireActivity().contentResolver.query(FilesProtectionContentProvider.a, null as Array<String?>?, whereClause, whereArgs, sortOrder)!!

        Log.e(mTAG, "ListImage  --> onCreate: ${mCursor!!.count}")
        if (mCursor!!.count == 0) {
            tv_trash_album.visibility = View.VISIBLE
            deleted_files_trash_audio_doc.visibility = View.GONE
        } else {
            tv_trash_album.visibility = View.GONE
            deleted_files_trash_audio_doc.visibility = View.VISIBLE
        }
        mainCommonAdapter = AudioOtherTrashAdapter(requireActivity(), this, mCursor, 2, "Audio", requireActivity().checkAll , isForSort)
        deleted_files_trash_audio_doc.adapter = mainCommonAdapter

        if (isVisibleHint && TrashImageActivity.mIsFromForImageCheck == "Trash") {
            if(requireActivity().checkAll!=null) requireActivity().checkAll.isChecked = mCursor!!.count == selectedList.size
            if (mCursor != null && mCursor!!.count != 0) {
                if (requireActivity() is TrashImageActivity) {
                    (requireActivity() as TrashImageActivity).toggleRecoverButtonVisibility(true)
//                    requireActivity().iv_span.alpha = 1.0F
//                    requireActivity().iv_span.isEnabled = true
                    if (mPrevCursor != null && mPrevCursor!!.count == 0) {
                        (requireActivity() as TrashImageActivity).selectTop(2)
                    }
                }
            } else {
                if (requireActivity() is TrashImageActivity) {
                    (requireActivity() as TrashImageActivity).toggleRecoverButtonVisibility(false)
//                    requireActivity().iv_span.alpha = 0.5F
//                    requireActivity().iv_span.isEnabled = false
                    (requireActivity() as TrashImageActivity).unSelectAll()
                }
            }

//            Log.e("$mTAG Audio", "initActions: fragment size  --> " + selectedList.size)
//            Log.e("$mTAG Audio", "initActions: fragment count --> " + mCursor!!.count)
//            Log.e("$mTAG Audio", "initActions: fragment mCursor-> $mCursor")
            if(mCursor != null &&  selectedList.size == mCursor!!.count) {
                mainCommonAdapter!!.selectAll()
            }
        }
        object : AsyncTask<Void, Long, Void>() {
            override fun doInBackground(vararg voids: Void): Void? {
                Log.e(mTAG, "doInBackground: stopLoading" )
                stopLoading()
                return null
            }
            override fun onPostExecute(result: Void?) {
                super.onPostExecute(result)
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
    }

    fun stopLoading() {
        activity?.runOnUiThread {
            Handler(Looper.getMainLooper()).postDelayed({
                resumeAudioCount -=1
                Log.e(mTAG, "stopLoading: $resumeAudioCount")
//                if(resumeAudioCount <=0) {
                    if(isAdded) {
//                        if(isVisibleHint) {
                        if (mCursor != null && mCursor!!.count != 0) {
                            if (TrashImageActivity.lastSelection == 2 && TrashImageActivity.prevPosTrash == 2) {
                                (requireActivity() as TrashImageActivity).selectTop(2)
                                if (requireActivity().iv_span != null) {
                                    requireActivity().iv_span.alpha = 1F
                                    requireActivity().iv_span.isEnabled = true
                                }
                                if (requireActivity().btnRecover != null) {
                                    requireActivity().btnRecover.alpha = 1F
                                    requireActivity().btnRecover.isEnabled = true
                                }
                                if (requireActivity().llSelectAll != null) {
                                    requireActivity().llSelectAll.alpha = 1F
                                    requireActivity().llSelectAll.isEnabled = true
                                }
                            }

                            if (lottie_trash_audio != null) lottie_trash_audio.visibility = View.GONE
                            Log.e(mTAG, "stopLoading: ")
//                        }
                        }
                        else{
//                                if(isVisibleHint) {
                            if (TrashImageActivity.lastSelection == 2 && TrashImageActivity.prevPosTrash == 2) {
                                (requireActivity() as TrashImageActivity).unSelectAll()
                            }
                        }
                    }
//                }
            }, 1000)
        }
    }

    var refreshMediaBroadcast = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent!!.action == "com.progress.audio.Refresh") {
                Handler(Looper.getMainLooper()).post {
                    onResume()
                }
                if(isVisibleHint) {
                    (requireActivity() as TrashImageActivity).unSelectAll()
                    requireActivity().iv_span.alpha = 0.5F
                    requireActivity().iv_span.isEnabled = false
                    requireActivity().btnRecover.alpha = 0.5F
                    requireActivity().btnRecover.isEnabled = false
                    requireActivity().llSelectAll.alpha = 0.5F
                    requireActivity().llSelectAll.isEnabled = false
                    lottie_trash_audio.visibility = View.VISIBLE
                }
            }
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        requireContext().unregisterReceiver(refreshMediaBroadcast)
    }
}