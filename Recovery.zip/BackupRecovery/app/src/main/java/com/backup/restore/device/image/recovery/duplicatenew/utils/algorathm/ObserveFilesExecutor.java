package com.backup.restore.device.image.recovery.duplicatenew.utils.algorathm;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Log;
import android.webkit.MimeTypeMap;

import com.backup.restore.device.image.recovery.database.DBAdapter;
import com.backup.restore.device.image.recovery.duplicatenew.models.DuplicateGroupModel;
import com.backup.restore.device.image.recovery.duplicatenew.models.FileDetails;
import com.backup.restore.device.image.recovery.duplicatenew.utils.Constants;
import com.backup.restore.device.image.recovery.duplicatenew.utils.DuplicatePreferences;
import com.backup.restore.device.image.recovery.mainduplicate.model.IgnorePath;
import com.backup.restore.device.image.recovery.utilities.DuplicateScanningListener;
import com.backup.restore.device.image.recovery.utilities.MyAnnotations;
import com.backup.restore.device.image.recovery.utilities.common.GlobalVarsAndFunctions;
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ObserveFilesExecutor {
    int count = 1;

    Context readingAllFilesContext;
    DuplicateScanningListener duplicateScanningListener;
    String scanType;
    public boolean stopped = false;

    public ObserveFilesExecutor(Context context, DuplicateScanningListener duplicateScanningListener, String scanType) {
        this.readingAllFilesContext = context;
        this.duplicateScanningListener = duplicateScanningListener;
        this.scanType = scanType;
        stopped = false;
    }

    protected void onPreExecute() {
        resetAllBeforeStartScan();
    }

    public void execute() {
        new Handler().post(() -> {
            onPreExecute();
            Executor executor = Executors.newSingleThreadExecutor();
            Handler handler = new Handler();
            executor.execute(() -> {
                doInBackground();
                handler.post(() -> {
                    if (!stopped) {
                        onPostExecute();
                    }
                });
            });

        });
    }

    public List<DuplicateGroupModel> listOfDuplicates = new ArrayList<>();
    public HashMap<String, ArrayList<FileDetails>> fileDetailMapStr;
    public HashMap<String, ArrayList<DuplicateGroupModel>> fileDuplicateMapStr;

//    FileDetails fileDetails;


    public HashMap<String, ArrayList<FileDetails>> getAllMediaByContent(Activity activity) {

//        String sdCard = Environment.getExternalStorageDirectory().toString();
//        String pathToScan = SharedPrefsConstant.getString(readingAllFilesContext, "scanLocation", sdCard);
        ArrayList<IgnorePath> ignoredList = new DBAdapter(readingAllFilesContext).getIgnoredPath();

//        ArrayList<FileDetails> arrayList1 = new ArrayList<>();
        ArrayList<FileDetails> arrayList = new ArrayList<>();
//        List<String> list;
        FileDetails fileDetails = new FileDetails();
        int counter = 0;
        int total = 0;
        try {
            this.fileDetailMapStr = new HashMap<>();
//            this.duplicateDetailMap = new ArrayList<>();
            this.listOfDuplicates = new ArrayList<>();
            Cursor query = null;
            switch (scanType) {
                case MyAnnotations.IMAGES:
                    query = activity.getContentResolver()
                            .query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                    new String[]{MediaStore.Images.Media.DATA},
                                    null,
                                    null,
                                    null);
                    break;
                case MyAnnotations.VIDEOS:
                    query = activity.getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                            new String[]{MediaStore.Video.Media.DATA},
                            null,
                            null,
                            null);
                    break;
                case MyAnnotations.AUDIOS:
                    query = activity.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                            new String[]{MediaStore.Audio.Media.DATA},
                            null,
                            null,
                            null);
                    break;
                case MyAnnotations.DOCUMENTS:

                    String mimeTypeDOC = MimeTypeMap.getSingleton().getMimeTypeFromExtension("doc");
                    String mimeTypeDOCX = MimeTypeMap.getSingleton().getMimeTypeFromExtension("docx");
                    String mimeTypeTXT = MimeTypeMap.getSingleton().getMimeTypeFromExtension("txt");
                    String mimeTypePDF = MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf");
                    String mimeTypeXLS = MimeTypeMap.getSingleton().getMimeTypeFromExtension("xls");
                    String mimeTypeXLSX = MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlsx");
                    String mimeTypePPT = MimeTypeMap.getSingleton().getMimeTypeFromExtension("ppt");
                    String mimeTypePPTX = MimeTypeMap.getSingleton().getMimeTypeFromExtension("pptx");
                    String mimeTypeCSV = MimeTypeMap.getSingleton().getMimeTypeFromExtension("csv");
                    String mimeTypeXLT = MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlt");
                    String mimeTypeXLTX = MimeTypeMap.getSingleton().getMimeTypeFromExtension("xltx");
                    String mimeTypeRTF = MimeTypeMap.getSingleton().getMimeTypeFromExtension("rtf");
                    String mimeTypeCHM = MimeTypeMap.getSingleton().getMimeTypeFromExtension("chm");

                    String selectionArgs = "application/pdf";
                    String[] selectionArgsPdf = new String[]{mimeTypeDOC, mimeTypeDOCX, mimeTypeTXT, mimeTypePDF, mimeTypeXLS, mimeTypeXLSX, mimeTypePPT, mimeTypePPTX, mimeTypeCSV, mimeTypeXLT, mimeTypeXLTX, mimeTypeRTF, mimeTypeCHM};

                    String selectionMimeTypeDocument =
                            MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeDOC + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeDOCX + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeTXT + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypePDF + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeXLS + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeXLSX + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypePPT + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypePPTX + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeCSV + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeXLT + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeXLTX + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeRTF + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeCHM + "')";

                    query = activity.getContentResolver()
                            .query(MediaStore.Files.getContentUri("external"),
                                    new String[]{MediaStore.Files.FileColumns.DATA},
                                    selectionMimeTypeDocument,
                                    null,
                                    null);
                    break;
                case MyAnnotations.OTHER:

                    String mimeTypeZIP = MimeTypeMap.getSingleton().getMimeTypeFromExtension("zip");
                    String mimeTypeWMV = MimeTypeMap.getSingleton().getMimeTypeFromExtension("wmv");
                    String mimeTypeAPK = MimeTypeMap.getSingleton().getMimeTypeFromExtension("apk");
                    String mimeTypeVCF = MimeTypeMap.getSingleton().getMimeTypeFromExtension("vcf");
                    String mimeTypeOGGOTHER = MimeTypeMap.getSingleton().getMimeTypeFromExtension("ogg");
                    String mimeTypeDB = MimeTypeMap.getSingleton().getMimeTypeFromExtension("db");

                    String selectionMimeTypeOther =
                            MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeWMV + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeZIP + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeAPK + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeVCF + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeOGGOTHER + "')" + " OR " +
                                    MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeDB + "')";

                    query = activity.getContentResolver()
                            .query(MediaStore.Files.getContentUri("external"),
                                    new String[]{MediaStore.Files.FileColumns.DATA},
                                    selectionMimeTypeOther, null, null);

                    break;
            }

            if (query == null || !query.moveToFirst()) {
                query.close();
                new Handler(Looper.getMainLooper()).post(() -> {
                    duplicateScanningListener.publishProgress(listOfDuplicates);
                });
                return fileDetailMapStr;
            }
            total = query.getCount();
            do {
                if (!stopped) {
                    counter++;
                    int finalCounter = counter;
                    int finalTotal = total;
                    new Handler(Looper.getMainLooper()).post(() -> duplicateScanningListener.publishProgress(new String[]{String.valueOf(finalCounter), String.valueOf(finalTotal)}));

                    @SuppressLint("Range") String string = query.getString(0);
                    boolean isConditionTrue = false;
                    switch (scanType) {
                        case MyAnnotations.AUDIOS:
                            isConditionTrue = GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.AAC)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.MP3)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.WMA)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.M4A)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.OGG)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.WAV);
                            break;
                        case MyAnnotations.DOCUMENTS:
                            isConditionTrue = GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.DOC)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.DOCX)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.TXT)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.PDF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.XLS)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.XLSX)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.PPT)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.PPTX)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.CSV)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.XLT)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.XLTX)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.RTF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.CHM);
                            break;
                        case MyAnnotations.IMAGES:
                            isConditionTrue = GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.JPG)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.AJPG)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.JPEG)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.PNG)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.BMP)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.TIFF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.PSD)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.PIC)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.GIF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.WEBP)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.HEIC)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.DWG)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.RAW)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.SRF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.DNG)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.KDC)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.NRW)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.ORF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.CPT);
                            break;
                        case MyAnnotations.VIDEOS:
                            isConditionTrue = GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.MP4)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.WMV)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.XVID)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.DIVX)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.ASF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.GP3)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.GP33)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.M4V)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.MOV)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.MKV)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.AVI);
                            break;
                        case MyAnnotations.OTHER:
                            isConditionTrue = GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.ZIP)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.WMV)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.APK)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.VCF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.OGGOTHER)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.DB);
                            break;
                        default:
                            isConditionTrue = true;
                            break;
                    }

                    boolean isIgnored = checkPathContain(ignoredList, string);
//                    if (isConditionTrue && string.contains(pathToScan) && isIgnored) {
                    if (isConditionTrue && isIgnored) {

                        if (new File(string).exists()) {
                            long length = new File(string).length();

                            fileDetails = new FileDetails();
                            fileDetails.setFileSize(length);
                            fileDetails.setFileName(new File(string).getName());
                            fileDetails.setFilePath(string);

                            String md5CheckSum = Constants.getMd5Checksum(string, this.readingAllFilesContext);
                            GlobalVarsAndFunctions.uniqueMd5Value.put(md5CheckSum, "." + Constants.getExtension(string));
                            GlobalVarsAndFunctions.extensionHashSet.add("." + Constants.getExtension(string));
                            if (md5CheckSum == null)
                                continue;

                            if (this.fileDetailMapStr.containsKey(md5CheckSum)) {
                                arrayList = fileDetailMapStr.get(md5CheckSum);
                            } else {
                                ArrayList arrayList3 = new ArrayList();
                                arrayList3.add(fileDetails);
                                this.fileDetailMapStr.put(md5CheckSum, new ArrayList<>(arrayList3));
                            }
                            arrayList.add(fileDetails);
                            arrayList = new ArrayList<>();
                        }
                    }

                } else {
                    query.moveToLast();
                    break;
//                    new Handler(Looper.getMainLooper()).post(() ->
//                            duplicateScanningListener.publishProgress(new String[]{String.valueOf("0"), String.valueOf("0")})
//                    );

                }
            } while (query.moveToNext());
            query.close();

            for (Entry<String, ArrayList<FileDetails>> entry : fileDetailMapStr.entrySet()) {
                if (entry.getValue().size() != 1) {
                    DuplicateGroupModel duplicateModel = new DuplicateGroupModel();
                    duplicateModel.setCheckBox(SharedPrefsConstant.getBooleanNoti(readingAllFilesContext, "duplicateSelection", true));
                    duplicateModel.setIndividualGrpOfDupes(entry.getValue());

                    listOfDuplicates.add(duplicateModel);
                }
            }
            new Handler(Looper.getMainLooper()).post(() -> duplicateScanningListener.publishProgress(listOfDuplicates));
            fileDetailMapStr.clear();
            return this.fileDetailMapStr;
        } catch (Exception e) {
            e.printStackTrace();
            new Handler(Looper.getMainLooper()).post(() -> duplicateScanningListener.publishProgress(listOfDuplicates));
            Log.e("test", "exception" + e.getMessage() + " " + e.getCause());
            return this.fileDetailMapStr;
        }
    }

    private boolean checkPathContain(ArrayList<IgnorePath> pathList, String currentPath) {
        boolean needToAdd = true;
        for (IgnorePath path : pathList) {
            if (currentPath.contains(path.getPath() + "/")) {
                needToAdd = false;
                return needToAdd;
            }
        }
        return needToAdd;
    }

    private void resetAllBeforeStartScan() {
        DuplicatePreferences.setScanStop(this.readingAllFilesContext, false);
        DuplicatePreferences.setSortBy(this.readingAllFilesContext, Constants.DATE_DOWN);
        DuplicatePreferences.setInitiateRescanAndEnterImagePageFirstTimeAfterScan(this.readingAllFilesContext, true);
        DuplicatePreferences.setInitiateRescanAndEnterVideoPageFirstTimeAfterScan(this.readingAllFilesContext, true);
        DuplicatePreferences.setInitiateRescanAndEnterAudioPageFirstTimeAfterScan(this.readingAllFilesContext, true);
        DuplicatePreferences.setInitiateRescanAndEnterDocumentPageFirstTimeAfterScan(this.readingAllFilesContext, true);
        DuplicatePreferences.setInitiateRescanAndEnterOtherPageFirstTimeAfterScan(this.readingAllFilesContext, true);
        Constants.resetOneTimePopUp();

        GlobalVarsAndFunctions.listOfDuplicates.clear();
        GlobalVarsAndFunctions.fileToBeDeleted.clear();
        GlobalVarsAndFunctions.uniqueMd5Value.clear();
        GlobalVarsAndFunctions.extensionHashSet.clear();
        GlobalVarsAndFunctions.audiosExtensionHashSet.clear();
        GlobalVarsAndFunctions.documentsExtensionHashSet.clear();
        GlobalVarsAndFunctions.photosExtensionHashSet.clear();
        GlobalVarsAndFunctions.videosExtensionHashSet.clear();
    }


    protected void doInBackground() {
        count = 0;
        if (scanType.equals(MyAnnotations.IMAGES) ||
                scanType.equals(MyAnnotations.VIDEOS) ||
                scanType.equals(MyAnnotations.AUDIOS) ||
                scanType.equals(MyAnnotations.DOCUMENTS) ||
                scanType.equals(MyAnnotations.OTHER)) {
            getAllMediaByContent((Activity) readingAllFilesContext);
        }

    }

    protected void onPostExecute() {
        this.duplicateScanningListener.checkScanning();
    }

    public void stopAsyncTask() {
        stopped = true;
        DuplicatePreferences.setScanStop(this.readingAllFilesContext, true);
    }

}