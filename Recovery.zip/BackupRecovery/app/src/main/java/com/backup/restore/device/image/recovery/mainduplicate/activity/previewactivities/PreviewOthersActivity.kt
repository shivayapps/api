package com.backup.restore.device.image.recovery.mainduplicate.activity.previewactivities

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.duplicatenew.models.FileDetails
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.GlobalVarsAndFunctions
import com.backup.restore.device.image.recovery.utilities.common.MyUtils
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.example.app.ads.helper.GiftIconHelper
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import kotlinx.android.synthetic.main.activity_preview_other.*
import kotlinx.android.synthetic.main.activity_preview_other.fileName
import kotlinx.android.synthetic.main.activity_preview_other.fileSize
import kotlinx.android.synthetic.main.activity_preview_other.fileType
import kotlinx.android.synthetic.main.activity_preview_other.ll_gift
import kotlinx.android.synthetic.main.activity_preview_other.modifiedDate
import kotlinx.android.synthetic.main.activity_preview_other.path
import kotlinx.android.synthetic.main.activity_preview_other.zoomableImageView
import kotlinx.android.synthetic.main.activity_preview_video.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class PreviewOthersActivity : MyCommonBaseActivity() {
    var mItemDuplicateModel: FileDetails? = null
    var mFileName: String? = null
    var mFileSize: String? = null
    var mFileType: String? = null
    var mModifiedDate: String? = null
    var mPath: String? = null

//    override fun attachBaseContext(newBase: Context) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preview_other)
        MyUtils.logError("preview Others Activity!!!")
    }

    override fun getContext(): AppCompatActivity {
        return this@PreviewOthersActivity
    }

    override fun initData() {
        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            GiftIconHelper.loadGiftAd(
                fContext = mContext,
                fivGiftIcon = findViewById(R.id.main_la_gift),
                fivBlastIcon = findViewById(R.id.main_la_gift_blast)
            )
            NativeAdvancedModelHelper(mContext).loadNativeAdvancedAd(
                NativeAdsSize.Medium,
                findViewById(R.id.ad_view_container)
            )
            ll_gift.visibility = View.VISIBLE
        }else{
            findViewById<FrameLayout>(R.id.ad_view_container).visibility = View.GONE
            ll_gift.visibility = View.INVISIBLE
        }

        assignValuesToWidgets()
        fileName1!!.text = mFileName
        fileName!!.text = mFileName
        fileType!!.text = mFileType
        fileSize!!.text = mFileSize
        modifiedDate!!.text = mModifiedDate
        path!!.isSelected = true
        path!!.text = mPath
    }

    override fun initActions() {
        zoomableImageView!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1000) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            MyApplication.isInternalCall = true
            try {
                val intent = Intent()
                intent.action = Intent.ACTION_VIEW
                val lFileUri = FileProvider.getUriForFile(
                    mContext,
                    applicationContext.packageName + ".provider",
                    File(mPath!!)
                )
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                intent.setDataAndType(lFileUri, "*/*")
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } catch (exception: ActivityNotFoundException) {}
        }
        backpress_audio!!.setOnClickListener(this)
    }

    private fun assignValuesToWidgets() {
        val b = intent.extras
        if (b != null) {
            mItemDuplicateModel = b.getSerializable("otherFiles") as FileDetails?
        }
        mFileName = GlobalVarsAndFunctions.getFileName(mItemDuplicateModel!!.filePath)
        mFileType = GlobalVarsAndFunctions.getExtension(mItemDuplicateModel!!.filePath)
//        mFileSize = ShareConstants.getReadableFileSize(mItemDuplicateModel!!.sizeOfTheFile)
        mFileSize = mItemDuplicateModel!!.fileSizeStr
//        mModifiedDate = SimpleDateFormat("MMM dd,yyyy HH:mm:ss ").format(Date(mItemDuplicateModel!!.fileDateAndTime))
        mModifiedDate = SimpleDateFormat("MMM dd,yyyy HH:mm:ss ").format(Date(File(mItemDuplicateModel!!.filePath).lastModified()))
        mPath = mItemDuplicateModel!!.filePath
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1000) {
            return
        }
        ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
        if (view.id == R.id.backpress_audio) {
            onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
    }

    override fun onBackPressed() {
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}