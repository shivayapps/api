package com.backup.restore.device.image.recovery.mainduplicate.model

import android.content.Context
import com.backup.restore.device.image.recovery.database.DBHandler

class SingleTonDbHandler(var singleTonDbHandlerContext: Context) {
    val instance: DBHandler?
        get() {
            if (mInstance == null) {
                mInstance = DBHandler(singleTonDbHandlerContext)
            }
            return mInstance
        }

    companion object {
        var mInstance: DBHandler? = null
    }
}