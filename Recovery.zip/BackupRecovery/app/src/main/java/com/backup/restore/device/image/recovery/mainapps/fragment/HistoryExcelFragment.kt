package com.backup.restore.device.image.recovery.mainapps.fragment

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.*
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.mainapps.adapter.ContactHistoryAdapter
import com.backup.restore.device.image.recovery.maincontact.activity.ContactHistoryActivity
import com.backup.restore.device.image.recovery.maincontact.activity.ShareActivity
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants.mLastClickTime
import com.example.jdrodi.callback.RVClickListener
import kotlinx.android.synthetic.main.activity_contact_history.*
import kotlinx.android.synthetic.main.fragment_history_excel.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.util.*

@Suppress("DEPRECATION")
class HistoryExcelFragment : Fragment(), View.OnClickListener {

    val mTAG: String = HistoryExcelFragment::class.java.simpleName

    lateinit var mView: View
    private var path = ""
    var mExcelFiles = ArrayList<String>()
    var mContactHistoryAdapter: ContactHistoryAdapter? = null
    var mGetExcelFiles: AsyncTask<*, *, *>? = null
    var isVisibleToUser = false
    var mTempList = ArrayList<String>()
    var mContext: Activity? = null

    companion object {
        fun newInstance(): HistoryExcelFragment {
            val fragment = HistoryExcelFragment()
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mContext = (requireActivity() as ContactHistoryActivity)
    }


    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        this.isVisibleToUser = isVisibleToUser
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        mView = inflater.inflate(R.layout.fragment_history_excel, container, false)
        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
        path = ShareConstants.mRootPath + "/Backup And Recovery/Contact Backup/"
        Log.e(mTAG, "Root : $path")

        return mView
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        findViews()
        setListeners()
        initViewsActions("Create")
    }

    private fun initViewsActions(From: String) {
        Log.e(mTAG, "getAppList: getFile $From")
        mGetExcelFiles = GetFiles().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
    }

    private fun findViews() {
        mContext = (requireActivity() as ContactHistoryActivity)

        rvAlreadyBackup.layoutManager = LinearLayoutManager(mContext)
        rvAlreadyBackup.setHasFixedSize(true)
        tv_msg!!.visibility = View.GONE

    }

    private fun setListeners() {
//        mContext!!.ivDeleteAll!!.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < 1500) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {

            R.id.ivDeleteAll -> {
                deleteAll()
            }
        }
    }

    fun clearSearch() {
    }

    private fun filter(text: String) {
        mTempList = mExcelFiles
        val filteredList = ArrayList<String>()
        for (s in mTempList) {
//            val lPackageName = s.appName
//            val tempName = lPackageName.split("#").toTypedArray()
            val name = s
            if (name!!.toLowerCase(Locale.ROOT).contains(text.toLowerCase(Locale.ROOT))) {
                filteredList.add(s)
            }
        }
        mTempList = filteredList
        mContactHistoryAdapter!!.filterList(mTempList)
    }

    private inner class GetFiles : AsyncTask<String?, String?, String?>() {
        val dialog = Dialog(mContext!!)

        override fun onPreExecute() {
            super.onPreExecute()

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            dialog.findViewById<TextView>(R.id.permission).text =
                getString(R.string.label_please_wait)
            dialog.findViewById<TextView>(R.id.permission_text).text =
                getString(R.string.fetching_backup_contact)
            dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.cancel)

            dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
                dialog.cancel()
                MyApplication.isDialogOpen = false
                cancel(true)
            }
            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }

            if (isVisibleToUser) {
                if (!dialog.isShowing) {
                    dialog.show()
                    MyApplication.isDialogOpen = true
                }
            }
            mExcelFiles.clear()
        }

        override fun doInBackground(vararg strings: String?): String? {
            mExcelFiles.clear()
            val dir = File(path)
//            Log.e(mTAG, "doInBackground:path::> $path")
            val files = dir.listFiles()
            if (files != null) {
                for (file in files) {
                    Log.e(mTAG, "doInBackground_excel:name: ${file.name}")
                    Log.e(mTAG, "doInBackground_excel:path: ${file.path}")
                    Log.e(mTAG, ":::::::::::::::::::::::::::::::::::::")
                    if (file.name.toLowerCase(Locale.ENGLISH)
                            .endsWith(".xls") || file.name.endsWith(".xlsx")
                    ) {
                        mExcelFiles.add(file.path)
                        Log.e(mTAG, "doInBackground_excel:name-->: ${file.path}")
                    }
                    if (mGetExcelFiles!!.isCancelled) {
                        mContext!!.runOnUiThread {
                            dialog.cancel()
                            MyApplication.isDialogOpen = false
                            ShareConstants.isBackup = true
                        }
                        break
                    }
                }
            }
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)
            try {
                if (isAdded) {
                    Handler(Looper.getMainLooper()).post {
                        ShareActivity.isDelete = false
                        if (mExcelFiles.size == 0) {
                            mContext!!.ivDeleteAll!!.visibility = View.INVISIBLE
                            rvAlreadyBackup!!.visibility = View.GONE
                            tv_msg!!.visibility = View.VISIBLE
//                            mContext!!.ivDeleteAll!!.isEnabled = false
//                            mContext!!.ivDeleteAll!!.alpha = 0.5f
                        } else {
                            mContext!!.ivDeleteAll!!.visibility = View.VISIBLE
                            tv_msg!!.visibility = View.GONE
                            rvAlreadyBackup!!.visibility = View.VISIBLE
//                            mContext!!.ivDeleteAll!!.isEnabled = true
//                            mContext!!.ivDeleteAll!!.alpha = 1.0f
//                            for (i in mSavedFile.indices) {
//                                if (File(mSavedFile[i]).length() == 0L) {
//                                    mSavedFile.removeAt(i)
//                                }
//                            }
                            try {
                                if (mExcelFiles != null) {
                                    mExcelFiles.sortWith(Comparator { lhs: String, rhs: String ->
                                        File(rhs).lastModified().compareTo(File(lhs).lastModified())
//                                        lhs!!.compareTo(rhs!!)
                                    })
                                }

                            } catch (e: java.lang.Exception) {

                            }

                            mContactHistoryAdapter =
                                ContactHistoryAdapter(mContext!!, mExcelFiles, 0,
                                    object : RVClickListener {
                                        override fun onItemClick(position: Int) {
                                            try {
                                                val intent =
                                                    Intent(activity, ShareActivity::class.java)
                                                intent.putExtra(
                                                    "file_path",
                                                    mContactHistoryAdapter!!.getItem(position)
                                                )
                                                intent.putExtra("file_type", 0)
                                                startActivity(intent)
                                            } catch (e: Exception) {
                                            }
                                        }

                                        override fun onEmpty() {
                                            tv_msg!!.visibility = View.VISIBLE
                                            rvAlreadyBackup!!.visibility = View.GONE
                                            if (mExcelFiles.isEmpty()) {
                                                rvAlreadyBackup!!.visibility = View.GONE
                                                tv_msg!!.visibility = View.VISIBLE
                                            }
                                        }

                                        override fun onNotEmpty() {
                                            rvAlreadyBackup!!.visibility = View.VISIBLE
                                            rvAlreadyBackup!!.stopScroll()
                                            tv_msg!!.visibility = View.GONE
                                        }
                                    })
                            rvAlreadyBackup?.layoutManager = LinearLayoutManager(mContext)
                            rvAlreadyBackup?.adapter = mContactHistoryAdapter
//                            rvAlreadyBackup?.invalidate()
                        }
                    }

                    Handler(Looper.getMainLooper()).postDelayed(Runnable {
                        try {
                            if (dialog != null && dialog.isShowing) {
                                dialog.cancel()
                                MyApplication.isDialogOpen = false
                            }
                        } catch (e: Exception) {
//                            mContext!!.addEvent(e.message!!)
                        }
                    }, 1000)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }


        }
    }

    public fun deleteAll() {
        val dialog = Dialog(mContext!!)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

//        dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(resources.getDrawable(R.drawable.ic_dialog_delete))
        dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.confirm_delete)
        dialog.findViewById<TextView>(R.id.permission_text)
            .setText(R.string.sure_to_delete_all_excel_file)
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            Handler().postDelayed(
                {
                    tv_msg!!.visibility = View.GONE
                    clearSearch()
                    rvAlreadyBackup!!.stopScroll()
                    DeleteAllFiles().execute()
                }, 500
            )
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }

        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
        MyApplication.isInternalCall = true
    }


    private inner class DeleteAllFiles : AsyncTask<String?, String?, String?>() {
        val dialog = Dialog(mContext!!)
        override fun onPreExecute() {
            super.onPreExecute()

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            dialog.findViewById<TextView>(R.id.permission).text =
                getString(R.string.label_please_wait)
            dialog.findViewById<TextView>(R.id.permission_text).text =
                getString(R.string.deleting_files)
            dialog.findViewById<TextView>(R.id.dialogButtonCancel).visibility = View.GONE

            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }

            if (!dialog.isShowing) {
                dialog.show()
                MyApplication.isDialogOpen = true
            }
        }

        override fun doInBackground(vararg strings: String?): String? {
            for (i in mExcelFiles.indices) {
                if (File(mExcelFiles[i]).exists()) {
                    File(mExcelFiles[i]).delete()
                }
            }
            mExcelFiles.clear()
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)
            try {

                Handler(Looper.getMainLooper()).post {
//                tv_no_apk_msg!!.visibility = View.GONE
                    if (mExcelFiles.size == 0) {
                        rvAlreadyBackup!!.visibility = View.GONE
                        tv_msg!!.visibility = View.VISIBLE
                        mContext!!.ivDeleteAll!!.visibility = View.INVISIBLE
//                        (activity as ContactHistoryActivity).ivDeleteAll.visibility = View.INVISIBLE
//                        mContext!!.ivDeleteAll!!.isEnabled = false
//                        mContext!!.ivDeleteAll!!.alpha = 0.5f
                        Toast.makeText(
                            mContext,
                            getString(R.string.all_file_deleted_successfully),
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        tv_msg!!.visibility = View.GONE
                        rvAlreadyBackup!!.visibility = View.VISIBLE
//                        mContext!!.ivDeleteAll!!.isEnabled = true
//                        mContext!!.ivDeleteAll!!.alpha = 1.0f
                    }
                }
                Handler(Looper.getMainLooper()).postDelayed(Runnable {
                    try {
                        if (dialog != null && dialog.isShowing) {
                            dialog.cancel()
                            MyApplication.isDialogOpen = false
                        }
                    } catch (e: Exception) {
//                        mContext!!.addEvent(e.message!!)
                    }
                }, 500)

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (isVisibleToUser) {
            if (ShareActivity.isDelete) {
                mGetExcelFiles = GetFiles().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
            }
//            Handler().postDelayed({
//                search_apk!!.isFocusable = true
//                search_apk!!.isFocusableInTouchMode = true
//                Log.e(mTAG, "findViews: focus ")
//            }, 500)

        }
    }

    override fun onPause() {
        super.onPause()
//        search_apk!!.isFocusable = false
    }

    override fun onStart() {
        EventBus.getDefault().register(this)
        super.onStart()
    }

    override fun onStop() {
        super.onStop()
        EventBus.getDefault().unregister(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (mGetExcelFiles != null) {
            if (mGetExcelFiles?.status == AsyncTask.Status.RUNNING) {
                mGetExcelFiles?.cancel(true)
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRefreshAuctionsAlreadyBackup(event: String) {
        if (event == "ToggleAlreadyBackup") {
            if (mGetExcelFiles != null) {
                mGetExcelFiles!!.cancel(true)
            }
            clearSearch()
        }
    }

}