package com.aainc.recyclebin.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class a extends SQLiteOpenHelper {
    public a(Context context) {
        super(context, "protected_files.db", (SQLiteDatabase.CursorFactory) null, 1);
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS " +
                "protected_files (_id INTEGER PRIMARY KEY AUTOINCREMENT,file_name TEXT NOT NULL COLLATE " +
                "NOCASE,original_path TEXT NOT NULL COLLATE NOCASE, trash_path TEXT NOT NULL COLLATE NOCASE, " +
                "type_file TEXT NOT NULL COLLATE NOCASE, " +  "file_size TEXT NOT NULL COLLATE NOCASE, " +
                "deleted_at TEXT NOT NULL COLLATE NOCASE );");
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS protected_files");
        onCreate(sQLiteDatabase);
    }
}
