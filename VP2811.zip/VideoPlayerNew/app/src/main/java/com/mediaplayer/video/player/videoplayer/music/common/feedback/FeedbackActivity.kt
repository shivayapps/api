package com.mediaplayer.video.player.videoplayer.music.common.feedback

import android.app.Activity
import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.*
import android.content.pm.ActivityInfo
import android.content.pm.PackageInfo
import android.os.Build
import android.os.Build.VERSION_CODES
import android.os.SystemClock
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.preference.PreferenceManager
import com.example.gallery.AGallery
import com.example.gallery.MimeType
import com.example.gallery.engine.impl.GlideEngine
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityFeedbackBinding

import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil

import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import org.jetbrains.anko.toast
import retrofit2.Response
import kotlinx.android.synthetic.main.activity_feedback.*
import java.io.*
import java.lang.reflect.Field
import kotlin.coroutines.CoroutineContext

const val REQUEST_CODE_CHOOSE = 101


class FeedbackActivity : BaseBindingActivity<ActivityFeedbackBinding>() {

    override fun getActivityContext(): AppCompatActivity {
        return this@FeedbackActivity
    }
    
    override fun setBinding(): ActivityFeedbackBinding {
        return ActivityFeedbackBinding.inflate(layoutInflater)
    }
    
    private var imageArrayList: ArrayList<String> = ArrayList()
    private var mFeedbackAdapter: FeedbackAdapter? = null
    private var intentFilter: IntentFilter? = null

    var fieldName: String = ""
    var mSmileRate: Int = 1

    override val coroutineContext: CoroutineContext
        get() = mJob + Dispatchers.Main
    private var progressDialog: ProgressDialog? = null


    companion object {
        fun newIntent(mContext: Context): Intent {
            return Intent(mContext, FeedbackActivity::class.java)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mJob.cancel()
    }

    override fun initView() {
        super.initView()

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        }
        else{
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME,"")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            GENERAL_THEME,"")

        if (editors == "theme_one")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_one)
        }
        else if (editors == "theme_two")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_two)
        }
        else if (edit == "ligt" || edit == "dark")
        {
            mBinding.root.background = null
        }

        mSmileRate = intent.getIntExtra("Rating",1)


        initData()
        initActions()
    }


    fun initActions() {

        mBinding.ivAdd.setOnClickListener(this)
        mBinding.btnSubmit.setOnClickListener(this)
        mBinding.ivBack.setOnClickListener(this)
        mBinding.edtDetails.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                mBinding.tvCurrentLength.text = s.toString().length.toString()

                Log.e(TAG, "onTextChanged: " + s.toString().length.toString())
            }

            override fun afterTextChanged(s: Editable?) {
            }

        })
    }

//    override fun attachBaseContext(newBase: Context) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
//    }

    fun initData() {

        mBinding.edtDetails.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                mBinding.edtDetails.isFocusableInTouchMode = true
                mBinding.edtDetails.isCursorVisible = false
                mBinding.edtDetails.error = null
            }
            false
        }


        mBinding.edtDetails.setOnTouchListener { view, event ->
            if (view.id == R.id.edt_details) {
                view.parent.requestDisallowInterceptTouchEvent(true)
                when (event.action and MotionEvent.ACTION_MASK) {
                    MotionEvent.ACTION_UP -> view.parent.requestDisallowInterceptTouchEvent(false)
                }
            }
            false
        }



        mBinding.edtEmail.setOnTouchListener { view, event ->
            if (view.id == R.id.edt_email) {
                view.parent.requestDisallowInterceptTouchEvent(true)
                when (event.action and MotionEvent.ACTION_MASK) {
                    MotionEvent.ACTION_UP -> view.parent.requestDisallowInterceptTouchEvent(false)
                }
            }
            false
        }

        mBinding.edtEmail.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                mBinding.edtEmail.isFocusableInTouchMode = true
                mBinding.edtEmail.isCursorVisible = false
                mBinding.edtEmail.error = null
            }
            false
        }
        progressDialog = ProgressDialog(this)
        progressDialog!!.setMessage("Please wait")
        progressDialog!!.setCancelable(false)
        progressDialog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
        progressDialog!!.isIndeterminate = true
        progressDialog!!.progress = 0


        val fields: Array<Field> = VERSION_CODES::class.java.fields
        for (field in fields) {
            fieldName = field.name
        }

        intentFilter = IntentFilter("FeedbackActivity")

    }

    override fun onClick(view: View) {

        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        when (view) {
            mBinding.ivAdd -> {
                choosePicture()
            }

            mBinding.btnSubmit -> {
                performSubmit()
            }

            mBinding.ivBack -> {
                onBackPressed()
            }
        }

    }



    private fun choosePicture() {

        val maxSelection = 4 - imageArrayList.size
        AGallery.from(mActivity)
            .choose(MimeType.ofImage())
            .countable(true)
            .showSingleMediaType(true)
            .capture(false)
            .maxSelectable(maxSelection) // Maximum image selection limit
            .restrictOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
            .showPreview(false)
            .thumbnailScale(0.85f)
            .imageEngine(GlideEngine())
            .forResult(REQUEST_CODE_CHOOSE)

    }

    private fun performSubmit() {
        if (mBinding.edtDetails.text.toString().isEmpty()) {
            mBinding.edtDetails.error = "Please enter your problem"
        } else if (mBinding.edtEmail.text.isEmpty()) {
            mBinding.edtEmail.error = "Please enter your contact detail"
        } else if (!mBinding.edtEmail.text.toString().isValidContactInformation()) {
            mBinding.edtEmail.error = "Please enter valid contact detail"
        } else {
            if (isOnline) {
                mBinding.edtDetails.error = null
                mBinding.edtEmail.error = null
                callShareAPI()
            } else {
                Toast.makeText(mActivity, "Please Check Your Internet Connection", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun createPartFromString(descriptionString: String): RequestBody {
        return RequestBody.create(MultipartBody.FORM, descriptionString)
    }


    private fun callShareAPI() {
        progressDialog?.show()
        val pInfo: PackageInfo = packageManager.getPackageInfo(packageName, 0)
        val versionName: String = pInfo.versionName //Version Name
        val verCode = pInfo.versionCode //Version Code

        val reqFeedback = ModelRequestFeedback(
            package_name = packageName,
            review = mBinding.edtDetails.text.toString(),
            ratings = mSmileRate.toString(),
            files = imageArrayList,
            contact_information = mBinding.edtEmail.text.toString(),
            version_code = verCode.toString(),
            version_name = versionName
        )

        if (isOnline) {
            // Fetch App center data from the server
            if (isSDKBelow21()) {
                callShareBelow21(reqFeedback)
            } else {
                // Using retrofit with kotlin coroutine
                GlobalScope.launch(mJob + Dispatchers.Main) {
                    callShareRetrofitAPI(mJob, reqFeedback)
                }
            }
        } else {
            progressDialog?.dismiss()
            toast("Check Your Internet Connection.")
        }
    }
    fun isSDKBelow21(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP
    }
    private fun callShareBelow21(feedback: ModelRequestFeedback) {
        GetFeedbackResponseTask(mActivity, feedback, object : JsonParserCallback {
            override fun onSuccess(response: String) {
                Log.i(TAG, "onResponse: $String")
                progressDialog?.dismiss()
                toast("Thank You For Your Feedback")
                finish()
            }

            override fun onFailure(message: String) {
                Log.e(TAG, "onResponse Failed:${message[0]}")
                toast(message)
                progressDialog?.dismiss()
            }
        }).execute()
    }


    private suspend fun callShareRetrofitAPI(mJob: Job, feedback: ModelRequestFeedback) {
        return withContext(mJob + Dispatchers.IO) {
            val retroApiInterface = FeedbackAPIService().getFeedbackClient(mActivity)


            val imageArray: ArrayList<MultipartBody.Part> = ArrayList()
            for (i in imageArrayList.indices) {
                if (!imageArrayList[i].equals("null", ignoreCase = true)) {
                    val file = File(imageArrayList[i])
                    val requestFile = RequestBody.create("*/*".toMediaTypeOrNull(), file)
                    val a = MultipartBody.Part.createFormData("image[]", file.name, requestFile)
                    imageArray.add(a)
                }
            }

            try {
                val reqFeedback = retroApiInterface.getFeedbackAsync(
                    createPartFromString(feedback.package_name),
                    createPartFromString(feedback.review),
                    createPartFromString(feedback.ratings),
                    imageArray,
                    createPartFromString(feedback.contact_information),
                    createPartFromString(feedback.version_name),
                    createPartFromString(feedback.version_code)
                )

                val resFeedback = reqFeedback.await()
                runOnUiThread {
                    progressDialog?.dismiss()
                    onRetrofitResponse(resFeedback)
                }
            } catch (exception: Exception) {
                Log.e(TAG, exception.toString())
                runOnUiThread {
                    progressDialog?.dismiss()
                    retryDialog(exception)
                }
            }
        }
    }

    private fun onRetrofitResponse(resFeedback: Response<ModelResponseFeedback>) {
        if (resFeedback.isSuccessful && resFeedback.body() != null) {
            val body = resFeedback.body()
            if (body!!.ResponseCode == 1) {
                Log.i(TAG, "onResponse: ${body.ResponseMessage}")
                toast("Thank You For Your Feedback")
                finish()
            } else {
                Log.e(TAG, "onResponse: ${body.ResponseMessage}")
                toast(body.ResponseMessage.toString())
            }
        } else {
            Log.e(TAG, "onResponse Failed:" + resFeedback.errorBody())
            toast(resFeedback.errorBody().toString())
        }
    }


    private fun retryDialog(t: Throwable) {

        val dialog = AlertDialog.Builder(this)
        var alert: AlertDialog? = null

        val title = "Internet Connection"
        val msg = "Check Your Internet Connection."
        val positiveText = "Retry"
        val negativeText = "Cancel"


        dialog.setCancelable(false)

        // Initialize a new foreground color span instance
        val foregroundColorSpan = ForegroundColorSpan(ContextCompat.getColor(this, R.color.select_text_color))
        val ssBuilder = SpannableStringBuilder(title)
        ssBuilder.setSpan(foregroundColorSpan, 0, title.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        dialog.setTitle(ssBuilder)

        dialog.setMessage(msg)

        dialog.setPositiveButton(positiveText) { _, _ ->
            alert?.dismiss()
            if (progressDialog!!.isShowing) {
                progressDialog!!.dismiss()
            }
            callShareAPI()
        }


        dialog.setNegativeButton(negativeText) { _, _ ->
            alert?.dismiss()
        }

        alert = dialog.create()
        alert.show()


        val textView = alert.findViewById<TextView>(android.R.id.message)
        try {
            textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)

        } catch (e: Exception) {
            Log.e("showAlert", e.toString())
        }
    }

    private fun updateMediaList() {
        mBinding.tvCurrentImage.text = imageArrayList.size.toString()
        if (imageArrayList.size > 0) {
            mFeedbackAdapter = FeedbackAdapter(mActivity, imageArrayList)
            mBinding.rvMedia.adapter = mFeedbackAdapter
        }
        if (imageArrayList.size >= 4) {
            mBinding.relativeImg1.visibility = View.GONE
        } else {
            mBinding.relativeImg1.visibility = View.VISIBLE
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_CODE_CHOOSE -> {
                when (resultCode) {
                    Activity.RESULT_OK -> {
                        val mSelected = AGallery.obtainPathResult(data)


                        if (mSelected.isNotEmpty() && mSelected.size > 0) {
                            val paths = AGallery.obtainPathResult(data)
                            for (path in paths) {
                                imageArrayList.add(path)
                            }
                            updateMediaList()
                        } else {
                            toast("You have selected " + mSelected.size + " images")
                        }
                    }
                    Activity.RESULT_CANCELED -> {
                        // toast(getString(R.string.label_cancel_image_selection))
                    }
                    else -> {
                        //toast(getString(R.string.label_failed_image_selection))
                    }
                }
            }
        }
    }

    private val feedbackStateReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            updateMediaList()
        }
    }


    public override fun onResume() {
        super.onResume()

        registerReceiver(feedbackStateReceiver, intentFilter)
    }

    override fun onStop() {
        super.onStop()
        try {

            unregisterReceiver(feedbackStateReceiver)

        } catch (E: Exception) {
        }
    }

    


}