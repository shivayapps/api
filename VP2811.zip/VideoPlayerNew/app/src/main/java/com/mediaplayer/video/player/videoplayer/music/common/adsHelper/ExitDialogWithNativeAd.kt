package com.mediaplayer.video.player.videoplayer.music.common.adsHelper

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.hsalf.smilerating.BaseRating
import com.hsalf.smilerating.SmileRating
import com.mediaplayer.video.player.videoplayer.music.R
import kotlinx.android.synthetic.main.dialog_exit_with_native_ad.*


class ExitDialogWithNativeAd(val fContext: AppCompatActivity) : Dialog(fContext), View.OnClickListener {

    val Context.inflater: LayoutInflater get() = LayoutInflater.from(this)
    val Context.displayWidth: Int get() = resources.displayMetrics.widthPixels


    init {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        @SuppressLint("InflateParams")
        val sheetView = fContext.inflater.inflate(R.layout.dialog_exit_with_native_ad, null)
        window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        setContentView(sheetView)
        setCancelable(false)
        setCanceledOnTouchOutside(false)

        window!!.setGravity(Gravity.CENTER)
        window!!.setLayout((0.9 * fContext.displayWidth).toInt(), Toolbar.LayoutParams.WRAP_CONTENT)
        initListeners()

    }

    private fun initListeners() {
        btn_no.setOnClickListener(this)
        btn_yes.setOnClickListener(this)

    }

    override fun onClick(v: View?) {
        when (v!!.id) {

            R.id.btn_no -> {
                cancel()
                dismiss()
            }

            R.id.btn_yes -> {
                cancel()
                dismiss()

                callActivity()


            }
        }
    }

    override fun show() {
        super.show()

    }

    private fun callActivity()
    {
        fContext.finishAffinity()
    }

    var RATING = -1

    fun Context.ratingDialog(listener: OnRateListener) {
        try {

            val inflater = (this as Activity).layoutInflater
            val alertLayout = inflater.inflate(R.layout.layout_dialog_rate_us, null)
            val smileRating: SmileRating = alertLayout.findViewById(R.id.rate_smile_rating)
            val btnDismiss = alertLayout.findViewById<TextView>(R.id.rate_btn_dismiss)
            val tvTitle = alertLayout.findViewById<TextView>(R.id.rate_tv_title)

            val alert = AlertDialog.Builder(this)
            alert.setView(alertLayout)
            alert.setCancelable(false)
            val dialog = alert.create()
            btnDismiss.setOnClickListener {
                ExitSPHelper(this).saveDismissed(true)
                RATING = -1
                dialog.dismiss()
            }
            dialog.setOnDismissListener { listener.onRate(RATING) }

            smileRating.setNameForSmile(BaseRating.TERRIBLE, getString(R.string.rating_terrible))
            smileRating.setNameForSmile(BaseRating.BAD, getString(R.string.rating_bad))
            smileRating.setNameForSmile(BaseRating.OKAY, getString(R.string.rating_okay))
            smileRating.setNameForSmile(BaseRating.GOOD, getString(R.string.rating_good))
            smileRating.setNameForSmile(BaseRating.GREAT, getString(R.string.rating_great))

            smileRating.setOnSmileySelectionListener { smiley, _ ->

                dialog.dismiss()
                ExitSPHelper(this).saveRate(true)

                RATING = if (smiley == BaseRating.GOOD || smiley == BaseRating.GREAT) {
                    4
                } else if (smiley == BaseRating.TERRIBLE) {
                    1
                } else if (smiley == BaseRating.TERRIBLE) {
                    2
                } else if (smiley == BaseRating.TERRIBLE) {
                    3
                } else {
                    1
                }
            }
            dialog.show()
        } catch (ignored: Exception) {

        }
    }

    interface OnRateListener {
        fun onRate(rate: Int)
    }

}