package com.mediaplayer.video.player.videoplayer.music.musicplayer.fragment

import android.view.LayoutInflater
import android.view.ViewGroup
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingFragment
import com.mediaplayer.video.player.videoplayer.music.databinding.FragmentForYouBinding


class ForYouFragment : BaseBindingFragment<FragmentForYouBinding>() {
    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentForYouBinding {
        return FragmentForYouBinding.inflate(layoutInflater)
    }


    companion object{
        fun newInstance(): ForYouFragment {
            return ForYouFragment()
        }
    }

}