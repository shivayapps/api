package com.mediaplayer.video.player.videoplayer.music.common.feedback

import androidx.annotation.Keep

@Keep
data class ModelResponseFeedback(
    var ResponseCode: Int? = null,
    var ResponseMessage: String? = null
)
