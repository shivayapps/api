package com.mediaplayer.video.player.videoplayer.music.common.fragment

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.view.*
import android.widget.ImageView
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.activity.MainActivity
import com.mediaplayer.video.player.videoplayer.music.common.activity.SubscriptionActivity
import com.mediaplayer.video.player.videoplayer.music.common.adapter.ThemeScreenSlidePagerAdapter
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingFragment
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.AdsManager
import com.mediaplayer.video.player.videoplayer.music.databinding.FragmentThemeMainBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.appshortcuts.DynamicShortcutManager
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil
import kotlinx.android.synthetic.main.remove_playlist_dialog.*
import java.lang.Exception


class ThemeMainFragment : BaseBindingFragment<FragmentThemeMainBinding>() {

    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentThemeMainBinding {
        return FragmentThemeMainBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()

        try {
            val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext())
                .getString(IMAGE_THEME, "")
            val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
                .getString(GENERAL_THEME, "")
            mBinding.viewPagerTheme.apply {
                val adapters = ThemeScreenSlidePagerAdapter(mContext)
                adapter = adapters
                (getChildAt(0) as RecyclerView).overScrollMode = RecyclerView.OVER_SCROLL_NEVER
            }
            mBinding.rvTheme.apply {
                layoutManager = GridLayoutManager(requireActivity(), 2)
                val adapters = ThemeAdapter(
                    mContext,
                    edit, editors,
                    getThemeOptions(),
                    object : ThemeAdapter.RVClickListener {
                        override fun onThemeClick(position: Int) {

                        }
                    })
                adapter = adapters
//                (getChildAt(0) as RecyclerView).overScrollMode = RecyclerView.OVER_SCROLL_NEVER
            }

            mBinding.viewPagerTheme.registerOnPageChangeCallback(object :
                ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {

                    if (position == 0) {
                        mBinding.btnPre.alpha = 0.1F
                        mBinding.ivThemePro.visibility = View.GONE

                        if (edit!!.isEmpty() && editors == "light") {

                            mBinding.btnSet.text = "Applied"
                            mBinding.btnSet.isEnabled = false
                        } else {
                            mBinding.btnSet.text = "Apply"
                            mBinding.btnSet.isEnabled = true
                        }

                    } else if (position == 1) {
                        mBinding.btnPre.alpha = 1F
                        mBinding.ivThemePro.visibility = View.GONE

                        if (edit!!.isEmpty() && editors == "dark") {
                            mBinding.btnSet.text = "Applied"
                            mBinding.btnSet.isEnabled = false
                        } else {
                            mBinding.btnSet.text = "Apply"
                            mBinding.btnSet.isEnabled = true
                        }
                    } else if (position == 2) {
                        mBinding.btnNext.alpha = 1F
                        if (AdsManager(mContext).isNeedToShowAds()) {
                            mBinding.ivThemePro.visibility = View.VISIBLE
                        } else {
                            mBinding.ivThemePro.visibility = View.GONE
                        }

                        if (edit == "theme_one") {
                            mBinding.btnSet.text = "Applied"
                            mBinding.btnSet.isEnabled = false
                        } else {
                            mBinding.btnSet.text = "Apply"
                            mBinding.btnSet.isEnabled = true
                        }


                    } else if (position == 3) {
                        mBinding.btnNext.alpha = 0.1F
                        if (AdsManager(mContext).isNeedToShowAds()) {
                            mBinding.ivThemePro.visibility = View.VISIBLE
                        } else {
                            mBinding.ivThemePro.visibility = View.GONE
                        }

                        if (edit == "theme_two") {
                            mBinding.btnSet.text = "Applied"
                            mBinding.btnSet.isEnabled = false
                        } else {
                            mBinding.btnSet.text = "Apply"
                            mBinding.btnSet.isEnabled = true
                        }
                    }

                    super.onPageSelected(position)
                }
            })
        } catch (e: Exception) {

        }

    }
//    dialog_apply_theme

    private fun themeDialog(position: Int){

        val dialog = Dialog(requireActivity())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_apply_theme)

        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.gravity = Gravity.CENTER

        dialog.window!!.attributes = lp
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)

        dialog.iv_close_playlist.setOnClickListener {
            dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            dialog.cancel()
            dialog.dismiss()
        }

        dialog.btn_remove.setOnClickListener {
            dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            dialog.cancel()
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun saveTheme(position: Int) {
        if (position == 0) {
            val editor =
                PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()

            editor.putString(GENERAL_THEME, "light")
            requireActivity().setTheme(PreferenceUtil.themeResFromPrefValue("light"))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                DynamicShortcutManager(requireContext()).updateDynamicShortcuts()
            }
            editor.putString(IMAGE_THEME, "")
            editor.apply()
            (mContext as MainActivity).callActivity()

        }
        else if (position == 1) {
//                    if (AdsManager(mContext).isNeedToShowAds()) {
//                        val intent = Intent(mContext, SubscriptionActivity::class.java)
//                        launchActivityForResult(intent, 111)
//                    } else {
            val editor =
                PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
            editor.putString(GENERAL_THEME, "dark")
            requireActivity().setTheme(PreferenceUtil.themeResFromPrefValue("dark"))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                DynamicShortcutManager(requireContext()).updateDynamicShortcuts()
            }

            editor.putString(IMAGE_THEME, "")
            editor.apply()
            (mContext as MainActivity).callActivity()
            //   }

        }
        else if (position == 2) {
            val editor =
                PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()

            if (AdsManager(mContext).isNeedToShowAds()) {
                val intent = Intent(mContext, SubscriptionActivity::class.java)
                launchActivityForResult(intent, 222)
            } else {
                editor.putString(GENERAL_THEME, "dark")
                requireActivity().setTheme(PreferenceUtil.themeResFromPrefValue("dark"))
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                    DynamicShortcutManager(requireContext()).updateDynamicShortcuts()
                }
                editor.putString(IMAGE_THEME, "theme_one")
                editor.apply()
                (mContext as MainActivity).callActivity()
            }

        }
        else if (position == 3) {
            val editor =
                PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
            if (AdsManager(mContext).isNeedToShowAds()) {
                val intent = Intent(mContext, SubscriptionActivity::class.java)
                launchActivityForResult(intent, 333)
            } else {
                editor.putString(GENERAL_THEME, "dark")
                requireActivity().setTheme(PreferenceUtil.themeResFromPrefValue("dark"))
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                    DynamicShortcutManager(requireContext()).updateDynamicShortcuts()
                }
                editor.putString(IMAGE_THEME, "theme_two")
                editor.apply()
                (mContext as MainActivity).callActivity()

            }
        }

    }

    class ThemeAdapter(
        val mContext: Activity,
        val imageTheme: String?,
        val generalTheme: String?,
        private val themeOptions: MutableList<Int>,
        val listener: RVClickListener
    ) : RecyclerView.Adapter<ThemeAdapter.ViewHolder>() {

        interface RVClickListener {
            fun onThemeClick(position: Int)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            return ViewHolder(
                LayoutInflater.from(mContext).inflate(R.layout.raw_main_theme, parent, false)
            )
        }

        override fun getItemCount(): Int {
            return themeOptions.size
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val nearby = themeOptions[position]
            holder.ivThumb.setImageResource(nearby)
            holder.ivThumb.setOnClickListener { listener.onThemeClick(position) }
            if (position == 0) {
                if (imageTheme!!.isEmpty() && generalTheme == "light") {
                    holder.ivCheck.visibility = View.VISIBLE
                } else {
                    holder.ivCheck.visibility = View.GONE
                }
            } else if (position == 1) {
                if (imageTheme!!.isEmpty() && generalTheme == "dark") {
                    holder.ivCheck.visibility = View.VISIBLE
                } else {
                    holder.ivCheck.visibility = View.GONE
                }
            } else if (position == 2) {
                if (imageTheme == "theme_one") {
                    holder.ivCheck.visibility = View.VISIBLE
                } else {
                    holder.ivCheck.visibility = View.GONE
                }
            } else if (position == 3) {
                if (imageTheme == "theme_two") {
                    holder.ivCheck.visibility = View.VISIBLE
                } else {
                    holder.ivCheck.visibility = View.GONE
                }
            }
        }

        class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            //            val tvTitle: TextView = itemView.findViewById(R.id.tv_title)
            val ivThumb: ImageView = itemView.findViewById(R.id.iv_thumb)
            val ivCheck: ImageView = itemView.findViewById(R.id.iv_check)
        }
    }

    fun getThemeOptions(): MutableList<Int> {
        val options: MutableList<Int> = ArrayList()
        options.add(R.drawable.ic_light_theme)
        options.add(R.drawable.ic_dark_theme)
        options.add(R.drawable.img_theme_one)
        options.add(R.drawable.img_theme_two)
        return options
    }


    override fun initViewListener() {
        super.initViewListener()

        mBinding.btnPre.setOnClickListener(this)
        mBinding.btnNext.setOnClickListener(this)
        mBinding.btnSet.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        super.onClick(v)

        when (v.id) {
            R.id.btn_pre -> {
                mBinding.viewPagerTheme.currentItem = mBinding.viewPagerTheme.currentItem - 1
            }
            R.id.btn_next -> {
                mBinding.viewPagerTheme.currentItem = mBinding.viewPagerTheme.currentItem + 1
            }
            R.id.btn_set -> {

                if (mBinding.viewPagerTheme.currentItem == 0) {
                    val editor =
                        PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()

                    editor.putString(GENERAL_THEME, "light")
                    requireActivity().setTheme(PreferenceUtil.themeResFromPrefValue("light"))
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                        DynamicShortcutManager(requireContext()).updateDynamicShortcuts()
                    }
                    editor.putString(IMAGE_THEME, "")
                    editor.apply()
                    (mContext as MainActivity).callActivity()

                } else if (mBinding.viewPagerTheme.currentItem == 1) {
//                    if (AdsManager(mContext).isNeedToShowAds()) {
//                        val intent = Intent(mContext, SubscriptionActivity::class.java)
//                        launchActivityForResult(intent, 111)
//                    } else {
                    val editor =
                        PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
                    editor.putString(GENERAL_THEME, "dark")
                    requireActivity().setTheme(PreferenceUtil.themeResFromPrefValue("dark"))
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                        DynamicShortcutManager(requireContext()).updateDynamicShortcuts()
                    }

                    editor.putString(IMAGE_THEME, "")
                    editor.apply()
                    (mContext as MainActivity).callActivity()
                    //   }

                } else if (mBinding.viewPagerTheme.currentItem == 2) {
                    val editor =
                        PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()

                    if (AdsManager(mContext).isNeedToShowAds()) {
                        val intent = Intent(mContext, SubscriptionActivity::class.java)
                        launchActivityForResult(intent, 222)
                    } else {
                        editor.putString(GENERAL_THEME, "dark")
                        requireActivity().setTheme(PreferenceUtil.themeResFromPrefValue("dark"))
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                            DynamicShortcutManager(requireContext()).updateDynamicShortcuts()
                        }
                        editor.putString(IMAGE_THEME, "theme_one")
                        editor.apply()
                        (mContext as MainActivity).callActivity()
                    }

                } else if (mBinding.viewPagerTheme.currentItem == 3) {
                    val editor =
                        PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
                    if (AdsManager(mContext).isNeedToShowAds()) {
                        val intent = Intent(mContext, SubscriptionActivity::class.java)
                        launchActivityForResult(intent, 333)
                    } else {
                        editor.putString(GENERAL_THEME, "dark")
                        requireActivity().setTheme(PreferenceUtil.themeResFromPrefValue("dark"))
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                            DynamicShortcutManager(requireContext()).updateDynamicShortcuts()
                        }
                        editor.putString(IMAGE_THEME, "theme_two")
                        editor.apply()
                        (mContext as MainActivity).callActivity()

                    }
                }
            }
        }
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        if (requestCode == 222 && resultCode == Activity.RESULT_OK) {
            val editor = PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
            editor.putString(GENERAL_THEME, "dark")
            requireActivity().setTheme(PreferenceUtil.themeResFromPrefValue("dark"))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                DynamicShortcutManager(requireContext()).updateDynamicShortcuts()
            }
            editor.putString(IMAGE_THEME, "theme_one")
            editor.apply()
            (mContext as MainActivity).callActivity()
        } else if (requestCode == 333 && resultCode == Activity.RESULT_OK) {
            val editor = PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
            editor.putString(GENERAL_THEME, "dark")
            requireActivity().setTheme(PreferenceUtil.themeResFromPrefValue("dark"))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                DynamicShortcutManager(requireContext()).updateDynamicShortcuts()
            }
            editor.putString(IMAGE_THEME, "theme_two")
            editor.apply()
            (mContext as MainActivity).callActivity()
        } else if (requestCode == 111 && resultCode == Activity.RESULT_OK) {
            val editor = PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
            editor.putString(GENERAL_THEME, "dark")
            requireActivity().setTheme(PreferenceUtil.themeResFromPrefValue("dark"))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                DynamicShortcutManager(requireContext()).updateDynamicShortcuts()
            }
            editor.putString(IMAGE_THEME, "")
            editor.apply()
            (mContext as MainActivity).callActivity()
        }
    }


    companion object {
        fun newInstance(): ThemeMainFragment {
            return ThemeMainFragment()
        }
    }


}