package com.mediaplayer.video.player.videoplayer.music.common.adsHelper

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.AdsManager
import com.mediaplayer.video.player.videoplayer.music.common.utils.isOnline
import kotlinx.android.synthetic.main.dialog_exit_with_native_ad_new.*
import kotlinx.android.synthetic.main.layout_ad_view.*
import kotlinx.android.synthetic.main.ph_exit_native_a.view.*


class ExitDialogWithNativeAdNew(val fContext: AppCompatActivity) : Dialog(fContext), View.OnClickListener {

    val Context.inflater: LayoutInflater get() = LayoutInflater.from(this)
    val Context.displayWidth: Int get() = resources.displayMetrics.widthPixels


    init {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        @SuppressLint("InflateParams")
        val sheetView = fContext.inflater.inflate(R.layout.dialog_exit_with_native_ad_new, null)

        setContentView(sheetView)
        setCancelable(false)
        setCanceledOnTouchOutside(true)

        window!!.setGravity(Gravity.BOTTOM)
        window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window!!.setLayout(Toolbar.LayoutParams.MATCH_PARENT,Toolbar.LayoutParams.WRAP_CONTENT)
        initListeners()

    }

    private fun initListeners() {

        btn_yes.setOnClickListener(this)

    }

    override fun onClick(v: View?) {
        when (v!!.id) {

            R.id.btn_yes -> {
                cancel()
                dismiss()
               callActivity()

            }
        }
    }

    override fun show() {
        super.show()

        if (fContext.isOnline && AdsManager(fContext).isNeedToShowAds()) {
            NativeAdvancedModelHelper(fContext).loadNativeAdvancedAd(
                NativeAdsSize.Custom,
                ad_view_container_mob as FrameLayout,
                LayoutInflater.from(fContext).inflate(
                    R.layout.ph_exit_native_a,
                    ad_view_container_mob as FrameLayout,
                    false
                )
            )

        }
    }

    private fun callActivity()
    {
        fContext.finishAffinity()
    }

    var RATING = -1


}