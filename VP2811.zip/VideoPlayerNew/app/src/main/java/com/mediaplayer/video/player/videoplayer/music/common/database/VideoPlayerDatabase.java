package com.mediaplayer.video.player.videoplayer.music.common.database;


import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.mediaplayer.video.player.videoplayer.music.common.database.FavoriteVideo;
import com.mediaplayer.video.player.videoplayer.music.common.database.FavoriteVideoDao;
import com.mediaplayer.video.player.videoplayer.music.common.database.RecentVideo;
import com.mediaplayer.video.player.videoplayer.music.common.database.RecentVideoDao;
import com.mediaplayer.video.player.videoplayer.music.common.database.VideoDataDao;
import com.mediaplayer.video.player.videoplayer.music.common.database.VideoDatalist;
import com.mediaplayer.video.player.videoplayer.music.common.database.VideoPlaylist;
import com.mediaplayer.video.player.videoplayer.music.common.database.VideoPlaylistDao;
import com.mediaplayer.video.player.videoplayer.music.common.database.VideoSearchHistory;
import com.mediaplayer.video.player.videoplayer.music.common.database.VideoSearchHistoryDao;

@Database(entities = {RecentVideo.class, VideoDatalist.class, VideoPlaylist.class, VideoSearchHistory.class, FavoriteVideo.class},exportSchema = false,version = 1)
public abstract class VideoPlayerDatabase extends RoomDatabase {
    private static final String DB_NAME = "video_player_db";
    private static VideoPlayerDatabase Instance;

    public static synchronized VideoPlayerDatabase getInstance(Context context)
    {
        if (Instance == null)
        {
            Instance = Room.databaseBuilder(context.getApplicationContext(),VideoPlayerDatabase.class,DB_NAME)
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build();
        }
        return Instance;
    }

    public abstract RecentVideoDao recentVideoDao();
    public abstract VideoPlaylistDao videoPlaylistDao();
    public abstract VideoDataDao videoDataDao();
    public abstract VideoSearchHistoryDao videoSearchHistoryDao();
    public abstract FavoriteVideoDao favoriteVideoDao();
}
