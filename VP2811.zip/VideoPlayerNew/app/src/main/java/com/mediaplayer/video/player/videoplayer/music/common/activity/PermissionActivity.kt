package com.mediaplayer.video.player.videoplayer.music.common.activity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityPermissionBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME

import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil


class PermissionActivity : BaseBindingActivity<ActivityPermissionBinding>() {

    private var isOpenPermissionDialog = false
    override fun getActivityContext(): FragmentActivity {
        return this@PermissionActivity
    }

    override fun setBinding(): ActivityPermissionBinding {
        return ActivityPermissionBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()
        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        }
        else{
            setImmersiveFullscreen()
        }
        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME,"")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            GENERAL_THEME,"")

        if (editors == "theme_one")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_one)
        }
        else if (editors == "theme_two")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_two)
        }
        else if (edit == "ligt" || edit == "dark")
        {
            mBinding.root.background = null
        }
    }


    override fun initViewListener() {
        super.initViewListener()
        mBinding.btnPermission.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id)
        {
            R.id.btn_permission -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                {
                    if (Environment.isExternalStorageManager()) {
                        val intent = Intent(mActivity,MainActivity::class.java)
                        launchActivity(intent,true)
                    } else {

                        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                        val uri = Uri.fromParts("package", packageName, null)
                        intent.data = uri
                        launchActivityForResult(intent,222)
                    }
                }
                else{
                    if (!checkPermissionBelow30()) {
                        ActivityCompat.requestPermissions(mActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 1)
                    }
                    else
                    {
                        val intent = Intent(mActivity,MainActivity::class.java)
                        launchActivity(intent,true)
                    }
                }
            }

        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (permissions.isEmpty()) {
            return
        }
        var permissionDetail: String? = null
        var allPermissionsGranted = true
        if (grantResults.isNotEmpty()) {
            for (grantResult in grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false
                    break
                }
            }
        }

        if (!allPermissionsGranted) {

            var somePermissionsForeverDenied = false
            for (permission in permissions) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                    if (requestCode == 1) {
                        ActivityCompat.requestPermissions(mActivity, arrayOf( Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 1)
                        break
                    }
                } else {
                    if (ActivityCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
                    } else {
                        somePermissionsForeverDenied = true
                    }
                }
            }
            if (somePermissionsForeverDenied) {
                if (!isOpenPermissionDialog) {
                    val alertDialogBuilder = AlertDialog.Builder(this)
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                        && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        permissionDetail = "Please allow permission for storage"
                    }
                    alertDialogBuilder.setTitle("Permissions Required")
                        .setMessage(permissionDetail)
                        .setPositiveButton("Ok") { dialog, which ->
                            dialog.dismiss()
                            dialog.dismiss()
                            isOpenPermissionDialog = false

                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
                            launchActivityForResult(intent, 221)
                        }.setNegativeButton("Cancel") { dialog, which ->
                            isOpenPermissionDialog = false
                                finishAffinity()
                                dialog.dismiss()

                        }.setCancelable(false).create().show()
                    isOpenPermissionDialog = true
                }
            }
        } else {
            if (requestCode==1)
            {
                val intent = Intent(mActivity,MainActivity::class.java)
                launchActivity(intent,true)
            }
        }
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        if (requestCode == 221 && checkPermissionBelow30())
        {
            val intent = Intent(mActivity,MainActivity::class.java)
            launchActivity(intent,true)
        }
        else if (requestCode == 222 && Environment.isExternalStorageManager())
        {
            val intent = Intent(mActivity,MainActivity::class.java)
            launchActivity(intent,true)
        }
    }

    private fun checkPermissionBelow30(): Boolean {
        return !(ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
    }



}