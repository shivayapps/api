package com.mediaplayer.video.player.videoplayer.music.common.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface VideoSearchHistoryDao {

    @Query("Select * from video_history ORDER BY ID DESC")
    fun getSearchVideoListLive(): LiveData<List<VideoSearchHistory>>

    @Query("Select * from video_history ORDER BY ID DESC")
    fun getSearchVideoList(): List<VideoSearchHistory>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertSearchVideo(search: VideoSearchHistory?)

    @Query("DELETE FROM video_history")
    fun deleteSearchVideo()

    @Query("DELETE from video_history WHERE name = :name")
    fun deleteRecentVideo(name: String?)

    @Query("Select count(*) from video_history WHERE name = :filepath")
    fun isSearchVideo(filepath: String?): Int
}