/*
 * Copyright (c) 2019 Hemanth Savarala.
 *
 * Licensed under the GNU General Public License v3
 *
 * This is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by
 *  the Free Software Foundation either version 3 of the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */

package com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette;

import androidx.annotation.NonNull;

import com.bumptech.glide.load.engine.Resource;
import com.bumptech.glide.util.Util;
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper;

public class BitmapPaletteResource implements Resource<com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper> {

  private final com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper bitmapPaletteWrapper;

  public BitmapPaletteResource(com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper bitmapPaletteWrapper) {
    this.bitmapPaletteWrapper = bitmapPaletteWrapper;
  }

  @NonNull
  @Override
  public com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper get() {
    return bitmapPaletteWrapper;
  }

  @NonNull
  @Override
  public Class<com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.palette.BitmapPaletteWrapper> getResourceClass() {
    return BitmapPaletteWrapper.class;
  }

  @Override
  public int getSize() {
    return Util.getBitmapByteSize(bitmapPaletteWrapper.getBitmap());
  }

  @Override
  public void recycle() {
    bitmapPaletteWrapper.getBitmap().recycle();
  }
}
