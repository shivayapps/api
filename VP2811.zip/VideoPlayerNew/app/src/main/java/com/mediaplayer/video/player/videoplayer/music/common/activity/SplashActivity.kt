package com.mediaplayer.video.player.videoplayer.music.common.activity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import code.name.monkey.appthemehelper.util.VersionUtils
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.database.HideVideoDatabase
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.*
import com.mediaplayer.video.player.videoplayer.music.common.utils.DATABASE_PATH
import com.mediaplayer.video.player.videoplayer.music.common.utils.addNoMedia
import com.mediaplayer.video.player.videoplayer.music.common.utils.ensureBackgroundThread
import com.mediaplayer.video.player.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivitySplashBinding


import com.mediaplayer.video.player.videoplayer.music.musicplayer.*
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.io.*

class SplashActivity : BaseBindingActivity<ActivitySplashBinding>(), ProductPurchaseHelper.ProductPurchaseListener {

    override fun getActivityContext(): FragmentActivity {
        return this@SplashActivity
    }

    override fun setBinding(): ActivitySplashBinding {
        return ActivitySplashBinding.inflate(layoutInflater)
    }

    override fun initViewAction() {
        if (AdsManager(this).isNeedToShowAds())
        {
            val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
            val ih = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(IMAGE_THEME,"")

            if (ih!!.isNotEmpty())
            {
                edit.putString(GENERAL_THEME, "light")
                edit.putString(IMAGE_THEME,"")
                edit.apply()
            }


        }
    }

    override fun initAds() {
        super.initAds()
        InterstitialAdHelper.destroy()
        NativeAdvancedModelHelper.destroy()
        //OpenAdHelper.destroy()
        if (AdsManager(mActivity).isNeedToShowAds() && isOnline ) {

            InterstitialAdHelper.loadInterstitialAd(mActivity)
            //OpenAdHelper.loadOpenAd(mActivity)
        }

    }
    override fun initView() {
        super.initView()
        initBilling()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            {
                if (Environment.isExternalStorageManager()) {
                    copyDB()
                }
            }
            else {
                if (checkPermissionBelow30()) {
                    copyDB()
                }
            }
        }catch (e :Exception)
        {}


        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        val edir = PreferenceManager.getDefaultSharedPreferences(App.getContext())
        val a = edir.getInt(RATE_COUNT, 0) + 1
        edir.edit().putInt(RATE_COUNT, a).apply()


        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(GENERAL_THEME, "")

        if (editors.isNullOrEmpty()) {
            val editor = PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
            editor.putString(GENERAL_THEME, "light")
            editor.apply()
        }

        if (VersionUtils.hasS()) {
            val editor = PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
            editor.putBoolean(MATERIAL_YOU, false)
            editor.apply()
        }

        Handler().postDelayed({
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            {
                if (Environment.isExternalStorageManager()) {
                    if ( isOnline && AdsManager(mActivity).isNeedToShowAds() ) {

                        isShowInterstitialAd {
                            Handler().postDelayed({
                                val intent = Intent(mActivity, MainActivity::class.java)
                                launchActivity(intent, true)
                            }, 10)

                        }
                    } else {
                        Handler().postDelayed({
                            val intent = Intent(mActivity, MainActivity::class.java)
                            launchActivity(intent, true)
                        }, 10)
                    }
                } else {

                    if ( isOnline && AdsManager(mActivity).isNeedToShowAds() ) {
                        isShowInterstitialAd {
                            val intent = Intent(mActivity, PermissionActivity::class.java)
                            launchActivity(intent, true)
                        }

                    } else {
                        val intent = Intent(mActivity, PermissionActivity::class.java)
                        launchActivity(intent, true)
                    }
                }
            }
            else
            {
                if (!checkPermissionBelow30()) {
                    if ( isOnline && AdsManager(mActivity).isNeedToShowAds() ) {
                        isShowInterstitialAd {
                            val intent = Intent(mActivity, PermissionActivity::class.java)
                            launchActivity(intent, true)
                        }

                    } else {
                        val intent = Intent(mActivity, PermissionActivity::class.java)
                        launchActivity(intent, true)
                    }
                } else {
                    if ( isOnline && AdsManager(mActivity).isNeedToShowAds() ) {

                        isShowInterstitialAd {
                            Handler().postDelayed({
                                val intent = Intent(mActivity, MainActivity::class.java)
                                launchActivity(intent, true)
                            }, 10)

                        }
                    } else {
                        Handler().postDelayed({
                            val intent = Intent(mActivity, MainActivity::class.java)
                            launchActivity(intent, true)
                        }, 10)
                    }

                }
            }


        }, 3500)


    }

    private fun checkPermissionBelow30(): Boolean {
        return !(ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
    }




    private fun initBilling() {
        runOnUiThread {
            try {
                ProductPurchaseHelper.setLifeTimeProductKey(SUBSCRIPTION_LIFE_TIME)
                ProductPurchaseHelper.setSubscriptionKey(SUBSCRIPTION_ONE_MONTH, SUBSCRIPTION_SIX_MONTH, SUBSCRIPTION_ONE_YEAR)
                ProductPurchaseHelper.initBillingClient(this@SplashActivity,this)
            } catch (e: Exception) {
                Log.e(TAG, "initBillingClient: " + e.message)
            }
        }
    }

    override fun onPurchasedExpired(productType: String) {

    }

    override fun onPurchasedSuccess(purchase: Purchase) {

    }

    override fun onPurchasedFound(productType: String, purchaseList: MutableList<Purchase>?) {
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        GlobalScope.launch(Dispatchers.Main) {
            ProductPurchaseHelper.initProductsKeys(this@SplashActivity) {
                ProductPurchaseHelper.getProductInfo(SUBSCRIPTION_LIFE_TIME)
            }
            ProductPurchaseHelper.initSubscriptionKeys(this@SplashActivity) {
                ProductPurchaseHelper.getProductInfo(SUBSCRIPTION_ONE_MONTH)
                ProductPurchaseHelper.getProductInfo(SUBSCRIPTION_SIX_MONTH)
                ProductPurchaseHelper.getProductInfo(SUBSCRIPTION_ONE_YEAR)
            }

        }
    }

    override fun onBillingKeyNotFound(productId: String) {
    }

    private fun copyDB() {
        val dbfile: File = getDatabasePath("videoplayer.db")
        var sdir = File(DATABASE_PATH)
        var parentFile = File(sdir.parentFile!!.absolutePath)
        if (!parentFile.exists()) {
            parentFile.mkdir()
        }
        if (!sdir.exists()) {
            sdir.mkdir()
        }

        val saveFile = File(DATABASE_PATH + "/videoplayer.db")

        try {
            if (!saveFile.exists()) {
                ensureBackgroundThread {
                    addNoMedia(sdir.absolutePath) {
                        addNoMedia(sdir.parentFile!!.absolutePath)
                        {
                        }
                    }
                }
                val buffersize = 8 * 1024
                val buffer = ByteArray(buffersize)
                var bytes_read = buffersize
                val savedb: OutputStream = FileOutputStream(saveFile)
                val indb: InputStream = FileInputStream(dbfile)
                while (indb.read(buffer, 0, buffersize).also { bytes_read = it } > 0) {
                    savedb.write(buffer, 0, bytes_read)
                }
                savedb.flush()
                indb.close()
                savedb.close()
                Log.e(TAG, "backupDatabase: Db Backup successful...")
                HideVideoDatabase.destroyInstance()
                try {
                    HideVideoDatabase.getInstance(this)
                } catch (e: Exception) {

                }
            }

        } catch (e: Exception) {

            Log.e(TAG, "backupDatabase: ex: $e")
        }

    }

}