package com.mediaplayer.video.player.videoplayer.music.musicplayer.activities

import android.content.Intent
import android.text.Spanned
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.afollestad.materialcab.attached.AttachedCab
import com.afollestad.materialcab.attached.destroy
import com.afollestad.materialcab.attached.isActive
import com.afollestad.materialcab.createCab
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.artistdatabase.ArtistDatabase
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.AdsManager
import com.mediaplayer.video.player.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.common.widgets.OnSingleClickListener
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityArtistDetailBinding

import com.mediaplayer.video.player.videoplayer.music.musicplayer.*
import com.mediaplayer.video.player.videoplayer.music.musicplayer.adapter.album.HorizontalAlbumAdapter
import com.mediaplayer.video.player.videoplayer.music.musicplayer.adapter.song.SimpleSongAdapter
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.*
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.artists.ArtistDetailsViewModel
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.GlideApp
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.SingleColorTarget
import com.mediaplayer.video.player.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces.IAlbumClickListener
import com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces.ICabCallback
import com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces.ICabHolder
import com.mediaplayer.video.player.videoplayer.music.musicplayer.model.Artist
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.MusicUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.RetroColorUtil
import kotlinx.android.synthetic.main.activity_album_detalit.*
import kotlinx.android.synthetic.main.activity_artist_detail.*
import kotlinx.android.synthetic.main.activity_artist_detail.banner_ad
import kotlinx.android.synthetic.main.layout_google_native_banner_small_ad_grid.view.*

import org.koin.androidx.viewmodel.ext.android.viewModel
import org.koin.core.parameter.parametersOf
import java.util.*

class ArtistDetailActivity :  BaseBindingActivity<ActivityArtistDetailBinding>(), IAlbumClickListener, ICabHolder {



    private lateinit var artistName: String
    private lateinit var detailsViewModel: ArtistDetailsViewModel
    private lateinit var artist: Artist
    private lateinit var songAdapter: SimpleSongAdapter
    private lateinit var albumAdapter: HorizontalAlbumAdapter
    private var biography: Spanned? = null
    private var lang: String? = null


    override fun initView() {
        super.initView()

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        }
        else{
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME,"")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            GENERAL_THEME,"")

        if (editors == "theme_one")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_one)
        }
        else if (editors == "theme_two")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_two)
        }
        else if (edit == "ligt" || edit == "dark")
        {
            mBinding.root.background = null
        }

        showProgressDialog(mActivity,"Please wait...")
        Log.e(TAG, "initView: ", )
        val id = intent.getLongExtra(EXTRA_ARTIST_ID,0)
        val detail: ArtistDetailsViewModel by viewModel {
            parametersOf(id, null)
        }
        detailsViewModel = detail
        addMusicServiceEventListener(detailsViewModel)

        detailsViewModel.getArtist().observe(this@ArtistDetailActivity) {
            showArtist(it)
        }
        setupRecyclerView()


        mBinding.fragmentArtistContent.playAction.apply {
            setOnClickListener { MusicPlayerRemote.openQueue(artist.sortedSongs, 0, true) }
        }
        mBinding.fragmentArtistContent.shuffleAction.apply {
            setOnClickListener { MusicPlayerRemote.openAndShuffleQueue(artist.songs, true) }
        }
        mBinding.icBack.setOnClickListener(object : OnSingleClickListener(){
            override fun onSingleClick(v: View?) {

                onBackPressed()
            }

        })

    }

    override fun onResume() {
        super.onResume()
        if (AdsManager(mActivity).isNeedToShowAds() && isOnline) {

//            NativeAdvancedModelHelper(mActivity).loadNativeAdvancedAd(
//                NativeAdsSize.Custom,banner_ad as FrameLayout,
//                LayoutInflater.from(mActivity).inflate(R.layout.layout_google_native_banner_small_ad_small, banner_ad as FrameLayout, false))

            NativeAdvancedModelHelper(mActivity).loadNativeAdvancedAd(
                NativeAdsSize.Custom,
                banner_ad as FrameLayout,
                LayoutInflater.from(mActivity).inflate(
                    R.layout.layout_google_native_ad_medium_custom,
                    banner_ad as FrameLayout,
                    false
                ), isAdLoaded = {
                    val name = NativeAdvancedModelHelper.getNativeAd!!.callToAction
                    Log.e("TAG", "populateNativeAdViewTextdghdh: $name", )
                    when {
                        name.equals("Learn More") -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_learn_more))
                        }
                        name.equals("Open") -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_open))

                        }
                        name.equals("Install") -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_install))
                        }
                        name.equals("Download") -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_download))
                        }
                        name.equals("Visit", true) -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_visit))
                        }
                        name.equals("Visit Site", true) -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_visit))
                        }
                    }
                }
            )


        }
        else
        {
            banner_ad.visibility = View.GONE
        }
    }

    override fun getActivityContext(): FragmentActivity {
        return this@ArtistDetailActivity
    }

    private fun showArtist(artist: Artist) {
        if (artist.songCount == 0) {

            return
        }
        this.artist = artist
        loadArtistImage(artist)

        mBinding.artistTitle.text = artist.name
        mBinding.text.text = String.format(
            "%s • %s",
            MusicUtil.getArtistInfoString(this@ArtistDetailActivity, artist),
            MusicUtil.getReadableDurationString(MusicUtil.getTotalDuration(artist.songs))
        )
        val songText = resources.getQuantityString(
            R.plurals.albumSongs,
            artist.songCount,
            artist.songCount
        )
        val albumText = resources.getQuantityString(
            R.plurals.albums,
            artist.songCount,
            artist.songCount
        )
        mBinding.fragmentArtistContent.songTitle.text = songText
        mBinding.fragmentArtistContent.albumTitle.text = albumText
        songAdapter.swapDataSet(artist.sortedSongs)
        albumAdapter.swapDataSet(artist.albums)



        Log.e(TAG, "showArtist: ", )
    }

    private fun setupRecyclerView() {
        albumAdapter = HorizontalAlbumAdapter(this@ArtistDetailActivity, ArrayList(), this, this)
        mBinding.fragmentArtistContent.albumRecyclerView.apply {
            itemAnimator = DefaultItemAnimator()
            layoutManager = GridLayoutManager(this.context, 1, GridLayoutManager.HORIZONTAL, false)
            adapter = albumAdapter
        }
        songAdapter = SimpleSongAdapter(this@ArtistDetailActivity, ArrayList(), R.layout.item_song, this)
        mBinding.fragmentArtistContent.recyclerView.apply {
            itemAnimator = DefaultItemAnimator()
            layoutManager = LinearLayoutManager(this.context)
            adapter = songAdapter
        }
        Log.e(TAG, "setupRecyclerView: ", )
    }

    private fun loadArtistImage(artist: Artist) {
        val artists = artist.name.split(",", "&")
        val m = ArtistDatabase.getInstance(mActivity)
        val image = m.artistDao().getArtist(artists[0])
        if (image != null)
        {
            GlideApp.with(mActivity)
                .asBitmapPalette()
                .load(image.picture)
                .placeholder( R.drawable.default_artist_art)
                .transition(RetroGlideExtension.getDefaultTransition())
                .into(object : SingleColorTarget(mBinding.image) {
                    override fun onColorReady(color: Int) {
                        setColors(color)
                    }
                })
        }
        else
        {
            GlideApp.with(mActivity)
                .asBitmapPalette()
                .load(RetroGlideExtension.getArtistModel(artist))
                .artistImageOptions(artist)
                .transition(RetroGlideExtension.getDefaultTransition())
                .into(object : SingleColorTarget(mBinding.image) {
                    override fun onColorReady(color: Int) {
                        setColors(color)
                    }
                })
        }


    }

    private fun setColors(color: Int) {

        mBinding.fragmentArtistContent.shuffleAction.applyColor(color)
        mBinding.fragmentArtistContent.playAction.applyOutlineColor(color)

        hideProgressDialog()
    }

    override fun onAlbumClick(albumId: Long, view: View) {
        val intent = Intent(this@ArtistDetailActivity,AlbumDetalitActivity::class.java)
        intent.putExtra(EXTRA_ALBUM_ID,albumId)
        launchActivity(intent)
    }



    private var cab: AttachedCab? = null

    override fun openCab(menuRes: Int, callback: ICabCallback): AttachedCab {
        cab?.let {
            if (it.isActive()) {
                it.destroy()
            }
        }
        cab = createCab(R.id.toolbar_container) {
            menu(menuRes)
            closeDrawable(R.drawable.ic_close)
            backgroundColor(literal = RetroColorUtil.shiftBackgroundColor(surfaceColor()))
            slideDown()
            onCreate { cab, menu -> callback.onCabCreated(cab, menu) }
            onSelection {
                callback.onCabItemClicked(it)
            }
            onDestroy { callback.onCabFinished(it) }
        }
        return cab as AttachedCab
    }

    override fun setBinding(): ActivityArtistDetailBinding {
       return ActivityArtistDetailBinding.inflate(layoutInflater)
    }
}