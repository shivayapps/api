package com.gallery.photo.image.video.cameraview.ui.interfaces;

import android.view.View;

public interface OnRecyclerItemClickListener {
    void OnClick_(int i, View view);

    void OnLongClick_(int i, View view);
}
