package com.gallery.photo.image.video.activity

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.util.Log
import android.view.View
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.signature.ObjectKey
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activityBinding.BaseBindingActivity
import com.gallery.photo.image.video.databinding.ActivityImageCropBinding
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.extensions.saveBitmapInInternalStorage
import com.gallery.photo.image.video.utilities.ORIGINAL_PATH
import com.gallery.photo.image.video.utilities.PATH
import com.gallery.photo.image.video.extensions.showErrorToast
import com.gallery.photo.image.video.extensions.toast
import com.gallery.photo.image.video.helpers.PERMISSION_WRITE_STORAGE
import com.gallery.photo.image.video.helpers.REQUEST_EDIT_IMAGE_IN
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.isseiaoki.simplecropview.CropImageView
import com.isseiaoki.simplecropview.callback.CropCallback
import com.isseiaoki.simplecropview.callback.SaveCallback
import java.io.File

class ImageCropActivity : BaseBindingActivity<ActivityImageCropBinding>() {
    var mPath = ""
    var isDoneClicked = false

    // variable to track event time
    override var mMinDuration = 2000

    override fun setBinding(): ActivityImageCropBinding {
        return ActivityImageCropBinding.inflate(inflater)
    }

    override fun getContext(): Activity {
        return this
    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun initData() {

        try {
            mPath = intent.getStringExtra(PATH) ?: ""

        } catch (e: Exception) {
            showErrorToast(e)
            finish()
            return
        }
        val options = RequestOptions()
            .signature(ObjectKey(mPath+File(mPath).lastModified()+File(mPath).length()))
            .skipMemoryCache(false)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
        Glide.with(this)
            .load(mPath)
            .apply(options)
            .into(
                mBinding.cropImageView)
    }

    override fun initActions() {
        mBinding.imgBack.setOnClickListener {
            onBackPressed()
        }
        mBinding.btnCropFitImage.setOnClickListener(this)
        mBinding.btnCropSquare.setOnClickListener(this)
        mBinding.btnCrop34.setOnClickListener(this)
        mBinding.btnCrop43.setOnClickListener(this)
        mBinding.btnCrop916.setOnClickListener(this)
        mBinding.btnCrop169.setOnClickListener(this)
        mBinding.btnCropCustom.setOnClickListener(this)
        mBinding.btnCropFree.setOnClickListener(this)
        mBinding.btnCropCircle.setOnClickListener(this)
        mBinding.btnCropShowCircleButCropAsSquare.setOnClickListener(this)
        mBinding.buttonRotateLeft.setOnClickListener(this)
        mBinding.buttonRotateRight.setOnClickListener(this)
        mBinding.buttonDone.setOnClickListener(this)
    }

    override fun getAppLauncherName(): String {
        return getString(R.string.app_name)
    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.btnCropFitImage -> {
                mBinding.cropImageView.setCropMode(CropImageView.CropMode.FIT_IMAGE)
            }
            R.id.btnCropSquare -> {
                mBinding.cropImageView.setCropMode(CropImageView.CropMode.SQUARE)
            }
            R.id.btnCrop3_4 -> {
                mBinding.cropImageView.setCropMode(CropImageView.CropMode.RATIO_3_4)
            }
            R.id.btnCrop4_3 -> {
                mBinding.cropImageView.setCropMode(CropImageView.CropMode.RATIO_4_3)
            }
            R.id.btnCrop9_16 -> {
                mBinding.cropImageView.setCropMode(CropImageView.CropMode.RATIO_9_16)
            }
            R.id.btnCrop16_9 -> {
                mBinding.cropImageView.setCropMode(CropImageView.CropMode.RATIO_16_9)
            }
            R.id.btnCropCustom -> {
                mBinding.cropImageView.setCropMode(CropImageView.CropMode.CUSTOM)
            }
            R.id.btnCropFree -> {
                mBinding.cropImageView.setCropMode(CropImageView.CropMode.FREE)
            }
            R.id.btnCropCircle -> {
                mBinding.cropImageView.setCropMode(CropImageView.CropMode.CIRCLE)
            }
            R.id.btnCropShowCircleButCropAsSquare -> {
                mBinding.cropImageView.setCropMode(CropImageView.CropMode.CIRCLE_SQUARE)
            }
            R.id.buttonRotateLeft -> {
                mBinding.cropImageView.rotateImage(CropImageView.RotateDegrees.ROTATE_M90D)
            }
            R.id.buttonRotateRight -> {
                mBinding.cropImageView.rotateImage(CropImageView.RotateDegrees.ROTATE_90D)
            }
            R.id.buttonDone -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    if (!checkPermissionabove11()) {
                        showGetPermissionDialog11()
                    } else {
                        mBinding.cropImageView.startCrop(createSaveUri(), mCropCallback, mSaveCallback)
                    }

                } else {
                    if (!isDoneClicked) {
                        isDoneClicked = true
                        handlePermission(PERMISSION_WRITE_STORAGE) {
                            if (it) {
                                mBinding.cropImageView.startCrop(createSaveUri(), mCropCallback, mSaveCallback)
                            } else {
                                toast(R.string.no_storage_permissions)
                            }
                        }
                    }
                }
            }


        }
    }

    private fun createSaveUri(): Uri? {
        return Uri.fromFile(File(cacheDir, "cropped"))
    }

    private val mCropCallback: CropCallback = object : CropCallback {
        override fun onSuccess(cropped: Bitmap) {
            Log.e("TAG", "onSuccess: mCropCallback")
            redirectActivity(cropped)
        }

        override fun onError(e: Throwable) {
            isDoneClicked = false
            e.printStackTrace()
        }
    }

    private fun redirectActivity(cropped: Bitmap) {
        Log.e("TAG", "redirectActivity: for start result...")
        showProgress(getString(R.string.msg_saving))
        ensureBackgroundThread {
            val imagePath = saveBitmapInInternalStorage(cropped)
            runOnUiThread {
                dismissProgress()
                isDoneClicked = false
                Intent(this, ImageEditActivity::class.java).apply {
                    putExtra(PATH, imagePath)
                    putExtra(ORIGINAL_PATH, mPath)
                    launchActivityForResult(this, REQUEST_EDIT_IMAGE_IN)
                    finish()
                }
            }
        }

    }


    private val mSaveCallback: SaveCallback = object : SaveCallback {
        override fun onSuccess(outputUri: Uri) {
        }

        override fun onError(e: Throwable) {
            e.printStackTrace()
        }
    }


}