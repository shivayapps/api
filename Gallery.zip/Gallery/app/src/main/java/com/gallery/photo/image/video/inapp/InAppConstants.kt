package com.gallery.photo.image.video.inapp

import android.app.AlertDialog
import android.content.Context
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import androidx.core.content.ContextCompat
import com.android.billingclient.api.Purchase
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.utilities.fontPath
import com.gallery.photo.image.video.extensions.baseConfig
import com.gallery.photo.image.video.extensions.getColoredDrawableWithColor
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.jetbrains.annotations.NotNull


const val PLAY_STORE_SUBSCRIPTION_URL = "https://play.google.com/store/account/subscriptions"
const val PLAY_STORE_SUBSCRIPTION_DEEPLINK_URL = "https://play.google.com/store/account/subscriptions?sku=%s&package=%s"

// Products Id's TEST
const val SUB_WEEKLY = "com.gallery.photo.image.video.weekly"
//const val SUB_MONTHLY = "com.gallery.photo.image.video.monthly"
const val SUB_YEARLY = "com.gallery.photo.image.video.yearly"
//const val PRODUCT_PURCHASED = "android.test.purchased"


// Products Id's LIVE

const val PRODUCT_PURCHASED = "com.gallery.adsremoved"

// List of purchased products
val purchaseHistory: ArrayList<Purchase> = ArrayList()

// List of available products to buy
val skuPurchaseList = listOf(PRODUCT_PURCHASED)
val skuSubList = listOf(SUB_WEEKLY,SUB_YEARLY)

fun Context.showPurchaseAlert(@NotNull productId: String, fIsConsumable: Boolean) {
    val title = getString(R.string.app_name)
    val message = getString(R.string.ask_remove_ads)
    val positiveBtn = resources.getString(R.string.dialog_yes)
    val negativeBtn = resources.getString(R.string.dialog_no)
    showAlert(title, message, positiveBtn, negativeBtn, fontPath, object : OnPositive {
        override fun onYes() {

        }
    })
}


fun Context.showPurchaseSuccess() {
    val title = getString(R.string.app_name)
    val message = resources.getString(R.string.remove_ads)
    val positiveBtn = resources.getString(R.string.dialog_ok)
    showAlert(title, message, positiveBtn, null, fontPath, object : OnPositive {
        override fun onYes() {
        }
    })

}

fun Context.showAlert(title: String? = null, msg: String? = null, positiveText: String? = null, negativeText: String? = null, fontPath: String? = null, positive: OnPositive? = null) {

    val dialog = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
    var alert: AlertDialog? = null


    dialog.setCancelable(false)
    if (title != null) {
        // Initialize a new foreground color span instance
        val foregroundColorSpan = ForegroundColorSpan(ContextCompat.getColor(this, R.color.colorPrimaryDark))
        val ssBuilder = SpannableStringBuilder(title)
        ssBuilder.setSpan(foregroundColorSpan, 0, title.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        dialog.setTitle(ssBuilder)
    }
    if (msg != null) {
        dialog.setMessage(msg)
    }
    if (positiveText != null) {
        dialog.setPositiveButton(positiveText) { _, _ ->
            alert?.dismiss()
            positive?.onYes()
        }
    }
    if (negativeText != null) {
        dialog.setNegativeButton(negativeText) { _, _ ->
            alert?.dismiss()
            positive?.onNo()
        }
    }

    alert = dialog.create()
    alert.show()

    alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))
    alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))
    alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))

    val bgDrawable = resources.getColoredDrawableWithColor(com.gallery.photo.image.video.R.drawable.dialog_bg, baseConfig.backgroundColor)
    alert.window?.setBackgroundDrawable(bgDrawable)
//    if (fontPath != null) {
//        val textView = alert.findViewById<TextView>(android.R.id.message)
//        try {
//            textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
//            val face = Typeface.createFromAsset(assets, fontPath)
//            textView.typeface = face
//        } catch (e: Exception) {
//            Log.e("showAlert", e.toString())
//        }
//    }
}


interface OnPositive {
    fun onYes()
    fun onNo() {}
}
