package com.gallery.photo.image.video.activity

import android.app.Activity
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import android.view.View
import android.widget.Toast
import com.airbnb.lottie.LottieAnimationView
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.example.app.ads.helper.GiftIconHelper
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activityBinding.BaseBindingActivity
import com.gallery.photo.image.video.activityBinding.HelpFAQActivity
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.databinding.ActivityFakeVaultSettingsBinding

import com.gallery.photo.image.video.dialog.SetSecurityQuestionDialog
import com.gallery.photo.image.video.dialog.SubscriptionDialog
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.fragment.REQUEST_CODE_CHECK_PASSWORD
import com.gallery.photo.image.video.inapp.InAppPurchaseHelper
import com.gallery.photo.image.video.inapp.showPurchaseSuccess
import com.gallery.photo.image.video.lock.activity.CustomPinActivity
import com.gallery.photo.image.video.lock.managers.AppLock
import com.gallery.photo.image.video.lock.managers.LockSettings
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.utilities.INTENT_LOCK_TYPE
import com.gallery.photo.image.video.utilities.INTENT_LOCK_TYPE_FAKE
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.extensions.beGone
import com.gallery.photo.image.video.extensions.beVisible
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


class FakeVaultSettingsActivity : BaseBindingActivity<ActivityFakeVaultSettingsBinding>(), InAppPurchaseHelper.OnPurchased {
    var isEnableLock = false
    var isEnableFingerPrint = false
    var isRemoveAdClick = false

    // variable to track event time
    override var mLastClickTime: Long = 0
    override var mMinDuration = 1000
    private val REQUEST_CODE_CHECK = 11

    companion object {
        var isUnlock = false
    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        mBinding.imgBack.setOnClickListener {
            onBackPressed()
        }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = mBinding.giftLayout.giftAdIcon,
                fivBlastIcon = mBinding.giftLayout.giftBlastAdIcon
            )
            NativeAdvancedModelHelper(this).loadNativeAdvancedAd(
                NativeAdsSize.Big,
                mBinding.adViewContainer
            )
        }
        if (AdsManager(this).isNeedToShowAds())
            setLottieJson(mBinding.lottieProgressbar, "2.json")
        else
            mBinding.lottieProgressbar.beGone()
        InAppPurchaseHelper.instance!!.initBillingClient(this, this)
    }

    fun setLottieJson(view: LottieAnimationView, iconPath: String?) {
        if (iconPath.isNullOrEmpty())
            return
        try {
            view.setAnimation(iconPath)
            view.playAnimation()
        } catch (e: Exception) {
            view.playAnimation()
        }
    }

    override fun initActions() {

        mBinding.clChangePin.setOnClickListener(this)
        mBinding.clHelp.setOnClickListener(this)

    }

    override fun onResume() {
        super.onResume()
        if (AdsManager(this).isNeedToShowAds()) {
            mBinding.giftLayout.clGiftIcon.beVisible()
        } else {

            mBinding.giftLayout.clGiftIcon.beGone()
            mBinding.adViewContainer.beGone()

        }

    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.clChangePin -> {
                if (!AdsManager(this).isNeedToShowAds()) {
                    callChangePin()
                } else {
                    SubscriptionDialog(this, 0, 0, true)
                    {
                        if (it) {
                            var intent = Intent(this, SubscriptionActivity::class.java)
                            launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
                        } else {
                            callChangePin()
                        }

                    }

                }
            }
            R.id.clHelp -> {
                startActivity(Intent(this, HelpFAQActivity::class.java))
            }

        }
    }

    private fun callChangePin() {
        if (config.isFakeVaultEnable) {
            val intent = Intent(this, CustomPinActivity::class.java)
            intent.putExtra(AppLock.EXTRA_TYPE, AppLock.CHANGE_PIN)
            intent.putExtra("ChangePatternLock", false)
            intent.putExtra(INTENT_LOCK_TYPE, INTENT_LOCK_TYPE_FAKE)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            launchActivityForResult(intent, REQUEST_CODE_CHANGE_PASSWORD)
            //                    startActivityForResult(intent, REQUEST_CODE_CHANGE_PASSWORD)
        } else {
            Toast.makeText(this, getString(R.string.error_enable_lock), Toast.LENGTH_SHORT).show()
        }
    }


    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)

        when (requestCode) {
            REQUEST_CODE_CHECK_PASSWORD -> {
                if (resultCode == RESULT_OK) {
                    Toast.makeText(this, getString(R.string.msg_lock_change_sccessfully), Toast.LENGTH_SHORT).show()

                }
            }
            REQUEST_CODE_DISABLE_PASSWORD -> {
                if (!LockSettings.isPinLockAvl()) {
                    Toast.makeText(
                        this, getString(R.string.msg_lock_remove), Toast.LENGTH_SHORT
                    ).show()
                    config.isAppPasswordProtectionOn = false
                    config.isBatterySecureLock = false
                    config.isChargerSecureLock = false
                    finish()
                }
            }
            REQUEST_CODE_CHECK -> {
                if (resultCode == RESULT_OK) {
//                    Handler().postDelayed({
                    SetSecurityQuestionDialog(this as BaseSimpleActivity) {
                        Toast.makeText(this, getString(R.string.msg_security_que_ans_change_success), Toast.LENGTH_SHORT).show()
                    }
//                    }, 200)
                }

            }

        }
    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun onPurchasedSuccess(purchase: Purchase) {
        Log.i("TAG", "purchase")
        if (window.decorView.isShown)
            showPurchaseSuccess()
        removeAds()

    }

    private fun removeAds() {
        mBinding.giftLayout.clGiftIcon.beGone()
    }

    override fun onProductAlreadyOwn() {
        Log.i("TAG", "already purchase")
        showPurchaseSuccess()
        removeAds()
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        GlobalScope.launch(Dispatchers.Main) {
            InAppPurchaseHelper.instance!!.initProducts()
            Log.i("TAG", "IN_APP_BILLING | Done")
        }
    }

    override fun onBackPressed() {
        VaultFragment.isTabUnlock = true
        VaultFragment.isNeedToShowHiddenByGallery = true
        super.onBackPressed()
    }

    override fun onBillingUnavailable() {

    }

    override fun onBillingKeyNotFound(productId: String) {

    }

    override fun setBinding(): ActivityFakeVaultSettingsBinding {
        return ActivityFakeVaultSettingsBinding.inflate(inflater)
    }


}