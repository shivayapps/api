package com.gallery.photo.image.video.mainduplicate.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.mainduplicate.activity.previewactivities.PreviewPhotosActivity
import com.gallery.photo.image.video.mainduplicate.adapter.ListPhotosAdapter.ImageViewHolder
import com.gallery.photo.image.video.mainduplicate.callbacks.MarkedListener
import com.gallery.photo.image.video.mainduplicate.model.IndividualGroupModel
import com.gallery.photo.image.video.mainduplicate.model.ItemDuplicateModel
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions
import com.gallery.photo.image.video.mainduplicate.utils.MyUtils
import com.gallery.photo.image.video.mainduplicate.utils.ShareConstants
import com.gallery.photo.image.video.utilities.AsyncBackgroundWork


class ListPhotosAdapter constructor(
    val gridMediaAdapterContext: Context,
    val gridMediaAdapterActivity: Activity,
    val imagesMarkedListener: MarkedListener,
    val individualGroupPhotos: IndividualGroupModel,
    val image: List<ItemDuplicateModel>,
    val parentCheckbox: CheckBox
) : RecyclerView.Adapter<ImageViewHolder>() {

    val inflater: LayoutInflater =
        gridMediaAdapterContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    var totalNumberOfflineInSet = 0


    @SuppressLint("StaticFieldLeak")
    class GridViewLoader(
        var lImageLoaderContext: Context,
        var imageViewReference: ImageView?,
        var checkBoxReference: CheckBox,
//        var lTxtIndividualSize: TextView,
        var progressBar: ProgressBar
    ) : AsyncTask<ItemDuplicateModel?, Void?, String?>() {
        var lCheckboxStatus: Boolean? = null
        var mSize = ""

        override fun doInBackground(vararg params: ItemDuplicateModel?): String? {
            val imageItem = params[0]!!.filePath
            lCheckboxStatus = params[0]!!.isFileCheckBox
            mSize =
                String.format("%s", ShareConstants.getReadableFileSize(params[0]!!.sizeOfTheFile))
            return imageItem
        }

        @SuppressLint("UseCompatLoadingForDrawables")
        override fun onPostExecute(path: String?) {
            super.onPostExecute(path)
            if (imageViewReference != null) {
                if (path != null) {

                    Glide.with(lImageLoaderContext)
                        .load(path)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .override(300, 300).placeholder(R.drawable.image_placeholder)
                        .into(imageViewReference!!)

//                    Glide.with(lImageLoaderContext)
//                       ` .load(path)
//                        .override(300, 300)
//                        .placeholder(R.drawable.img_thumb)
//                        .into(imageViewReference!!)

                    checkBoxReference.isChecked = lCheckboxStatus!!
//                    lTxtIndividualSize.text = mSize
                    return
                }
//                imageViewReference!!.setImageDrawable(
//                    imageViewReference!!.context.resources.getDrawable(
//                        R.drawable.image_placeholder
//                    )
//                )
            }
        }
    }

    class ImageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var checkBox: CheckBox = view.findViewById(R.id.individualcheckbox)
        var imgDuplicateImage: ImageView? = view.findViewById(R.id.img_duplicate_image)

        //        var lIndividualSize: TextView = view.findViewById(R.id.individualsize)
        var progressBar: ProgressBar = view.findViewById(R.id.progressBar)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        return ImageViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.row_list_of_group_of_images_item, parent, false)
        )
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        holder.setIsRecyclable(false)
        val lImageItem = image[position]
        holder.checkBox.isChecked = lImageItem.isFileCheckBox
        holder.checkBox.tag = position

        Glide.with(gridMediaAdapterContext)
            .load(lImageItem.filePath)
            .override(300, 300)
            .placeholder(R.drawable.image_placeholder)
            .into(holder.imgDuplicateImage!!)

        holder.imgDuplicateImage!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            val intent = Intent(gridMediaAdapterActivity, PreviewPhotosActivity::class.java)
            val bundle = Bundle()
            bundle.putSerializable("imageItem", lImageItem)
            intent.putExtras(bundle)
            intent.putExtra("totalNumberOfFiles", totalNumberOfflineInSet)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            gridMediaAdapterActivity.startActivity(
                intent,
                ActivityOptionsCompat.makeCustomAnimation(
                    gridMediaAdapterContext,
                    R.anim.slide_from_right,
                    R.anim.slide_from_left
                ).toBundle()
            )
        }
        holder.checkBox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            buttonView.setOnClickListener {
                lImageItem.isFileCheckBox = isChecked
                var selectCount = 0
                val numOffline = itemCount
                if (lImageItem.isFileCheckBox) {
                    for (i in 0 until itemCount) {
                        if (image[i].isFileCheckBox) {
                            selectCount++
                        }
                    }
                    if (selectCount != numOffline) {
                        GlobalVarsAndFunctions.file_to_be_deleted_images.add(lImageItem)
                        GlobalVarsAndFunctions.addSizeImages(lImageItem.sizeOfTheFile)
                        imagesMarkedListener.updateMarked()
                        parentCheckbox.isChecked = true
                        individualGroupPhotos.isCheckBox = true
                    }
                } else {
                    GlobalVarsAndFunctions.file_to_be_deleted_images.remove(lImageItem)
                    GlobalVarsAndFunctions.subSizeImages(lImageItem.sizeOfTheFile)
                    imagesMarkedListener.updateMarked()
                }
                if (selectCount < numOffline - 1) {
                    parentCheckbox.isChecked = false
                    individualGroupPhotos.isCheckBox = false
                } else {
                    parentCheckbox.isChecked = true
                    individualGroupPhotos.isCheckBox = true
                }
                if (numOffline == selectCount) {
                    MyUtils.showToastMsg(
                        gridMediaAdapterContext,
                        gridMediaAdapterContext.getString(R.string.error_not_select_all_image_in_same)
                    )
                    lImageItem.isFileCheckBox = false
                    holder.checkBox.isChecked = false
                    return@setOnClickListener
                }
                lImageItem.isFileCheckBox = isChecked
            }
        }
        if (holder.imgDuplicateImage != null) {
            var lCheckboxStatus: Boolean? = null
            var mSize = ""

            AsyncBackgroundWork({}, {
                lCheckboxStatus = lImageItem.isFileCheckBox
                mSize =
                    String.format("%s", ShareConstants.getReadableFileSize(lImageItem.sizeOfTheFile))
            }, {
                holder.checkBox.isChecked = lCheckboxStatus!!
            })
        }
    }

    override fun getItemCount(): Int {
        totalNumberOfflineInSet = image.size
        return totalNumberOfflineInSet
    }

}