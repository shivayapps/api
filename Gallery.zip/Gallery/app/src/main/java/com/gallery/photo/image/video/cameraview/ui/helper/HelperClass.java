package com.gallery.photo.image.video.cameraview.ui.helper;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class HelperClass {

    private static ProgressDialog mProgressDialog;
    static AlertDialog alertSimpleDialog = null;



    public static String setDateTimeFormat(String str) {
        String str2;
        Calendar instance = Calendar.getInstance();
        if (str.contains("ddth")) {
            str2 = addExtention(str);
        } else {
            str2 = new SimpleDateFormat(str, Locale.getDefault()).format(instance.getTime());
        }
        return str2.replace("am", "AM").replace("pm", "PM");
    }

    private static String addExtention(String str) {
        String str2;
        Calendar instance = Calendar.getInstance();
        String[] split = str.split("th");
        String format = new SimpleDateFormat(split[0], Locale.getDefault()).format(instance.getTime());
        char charAt = format.charAt(format.length() - 1);
        if (format.substring(format.length() - 2).equalsIgnoreCase("13") || format.equalsIgnoreCase("13") || format.substring(format.length() - 2).equalsIgnoreCase("12") || format.equalsIgnoreCase("12") || format.substring(format.length() - 2).equalsIgnoreCase("11") || format.equalsIgnoreCase("11")) {
            str2 = format + "th";
        } else if (charAt == '1') {
            str2 = format + "st";
        } else if (charAt == '2') {
            str2 = format + "nd";
        } else if (charAt == '3') {
            str2 = format + "rd";
        } else {
            str2 = format + "th";
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(split[1], Locale.getDefault());
        return str2 + simpleDateFormat.format(instance.getTime());
    }

    public static void showProgressDialog(Context context, String str) {
        try {
            ProgressDialog progressDialog = new ProgressDialog(context);
            mProgressDialog = progressDialog;
            progressDialog.setMessage(str);
            mProgressDialog.setCancelable(false);
            ProgressDialog progressDialog2 = mProgressDialog;
            if (progressDialog2 != null && !progressDialog2.isShowing()) {
                mProgressDialog.show();
            }
        } catch (Exception unused) {
        }
    }

    public static void dismissProgressDialog() {
        try {
            ProgressDialog progressDialog = mProgressDialog;
            if (progressDialog != null && progressDialog.isShowing()) {
                mProgressDialog.dismiss();
                mProgressDialog = null;
            }
        } catch (Exception unused) {
        }
    }

}
