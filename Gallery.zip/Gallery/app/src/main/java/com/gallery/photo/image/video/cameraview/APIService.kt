package com.gallery.photo.image.video.cameraview

import android.content.Context
import com.gallery.photo.image.video.cameraview.stampmodel.Stampmodel
import com.gallery.photo.image.video.models.QuestionResponseModel
import com.google.gson.GsonBuilder
import com.jakewharton.retrofit2.adapter.kotlin.coroutines.CoroutineCallAdapterFactory

import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit


class APIService {

    private lateinit var apiInterface: APIInterface

    var interceptor: HttpLoggingInterceptor = HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)

    var okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .callTimeout(1000L, TimeUnit.SECONDS)
        .connectTimeout(1000L, TimeUnit.SECONDS)
        .readTimeout(1000L, TimeUnit.SECONDS)
        .writeTimeout(1000L, TimeUnit.SECONDS)
        .build()


    var okHttpClientDebug: OkHttpClient = OkHttpClient.Builder()
        .callTimeout(1000L, TimeUnit.SECONDS)
        .connectTimeout(1000L, TimeUnit.SECONDS)
        .readTimeout(1000L, TimeUnit.SECONDS)
        .writeTimeout(1000L, TimeUnit.SECONDS)
        .addInterceptor(interceptor)
        .build()

    fun getClient(mContext: Context): APIInterface {
        val retrofit: Retrofit
//        if (BuildConfig.DEBUG) {
        retrofit = Retrofit.Builder()
            .baseUrl(mContext.getTestBaseUrl())
            .client(provideOkHttpClient(provideLoggingInterceptor()))
            .client(okHttpClientDebug)
            .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))
            .addCallAdapterFactory(CoroutineCallAdapterFactory())
            .build()
//        } else {
//            retrofit = Retrofit.Builder()
//                .baseUrl(mContext.getBaseUrlApps())
//                .client(provideOkHttpClient(provideLoggingInterceptor()))
//                .client(okHttpClient)
//                .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))
//                .addCallAdapterFactory(CoroutineCallAdapterFactory())
//                .build()
//        }
        apiInterface = retrofit.create(APIInterface::class.java)

        return apiInterface
    }

    private fun provideOkHttpClient(interceptor: HttpLoggingInterceptor): OkHttpClient {
        val b = OkHttpClient.Builder()
        b.addInterceptor(interceptor)
        return b.build()
    }

    private fun provideLoggingInterceptor(): HttpLoggingInterceptor {
        val interceptor = HttpLoggingInterceptor()
        interceptor.level = HttpLoggingInterceptor.Level.BODY
        return interceptor
    }

    interface APIInterface {

        @GET("get_all_stamp.json")
        fun doGetAllImage(): Call<Stampmodel>

        @POST("get_question")
        fun getAllQuestion(@Header("Authorization") token: String): Call<QuestionResponseModel>

        @Streaming
        @GET
        fun downloadFileByUrl(@Url fileUrl: String?): Call<ResponseBody>


    }
}
