package com.gallery.photo.image.video.extensions

import com.gallery.photo.image.video.models.FileDirItem

fun FileDirItem.isDownloadsFolder() = path.isDownloadsFolder()
