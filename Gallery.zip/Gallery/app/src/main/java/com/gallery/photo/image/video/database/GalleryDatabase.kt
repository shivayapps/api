package com.gallery.photo.image.video.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.gallery.photo.image.video.interfaces.*
import com.gallery.photo.image.video.models.*
import com.gallery.photo.image.video.utilities.DATABASE_PATH
import com.gallery.photo.image.video.extensions.getParentPath
import java.io.File

@Database(entities = [Directory::class, Medium::class, Widget::class, DateTaken::class, Favorite::class, HiddenDirectory::class, PhotoDirectory::class,VideoDirectory::class, FakeVaultHiddenDirectory::class, FakeVaultMedium::class],
    version = 5)
abstract class GalleryDatabase : RoomDatabase() {

    abstract fun DirectoryDao(): DirectoryDao
    abstract fun HiddenDirectoryDao(): HiddenDirectoryDao
    abstract fun PhotoDirectoryDao(): PhotoDirectoryDao
    abstract fun VideoDirectoryDao(): VideoDirectoryDao
    abstract fun FakeVaultHiddenDirectoryDao(): FakeVaultHiddenDirectoryDao
    abstract fun MediumDao(): MediumDao
    abstract fun FakeVaultMediumDao(): FakeVaultMediumDao

    abstract fun DateTakensDao(): DateTakensDao

    companion object {
        private var db: GalleryDatabase? = null

        fun getInstance(context: Context): GalleryDatabase {
            if (db == null) {
                synchronized(GalleryDatabase::class) {
                    if (db == null) {
                        var sdir = File(DATABASE_PATH)
                        var parentFile=File(sdir.absolutePath.getParentPath())
                        if (!parentFile.exists()) {
                            parentFile.mkdir()
                        }
                        if (!sdir.exists()) {
                            sdir.mkdir()
                        }

//                        db = Room.databaseBuilder(context.applicationContext, GalleryDatabase::class.java, "galleryvasu.db")
                        db = Room.databaseBuilder(context.applicationContext, GalleryDatabase::class.java, DATABASE_PATH + "/galleryvasu.db")
                            .fallbackToDestructiveMigration()
                            .addMigrations(MIGRATION_1_2)
                            .addMigrations(MIGRATION_2_3)
                            .addMigrations(MIGRATION_3_4)
                            .addMigrations(MIGRATION_4_5)
                            .build()
                    }
                }
            }
            return db!!
        }

        fun destroyInstance() {
            db = null
        }

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("CREATE TABLE IF NOT EXISTS `hiddenDirectories` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `path` TEXT NOT NULL,`thumbnail` TEXT NOT NULL,`filename` TEXT NOT NULL, `media_count` INTEGER NOT NULL,`last_modified` INTEGER NOT NULL,`date_taken` INTEGER NOT NULL, `size` INTEGER NOT NULL, `location` INTEGER NOT NULL,  `media_types` INTEGER NOT NULL, `sort_value` TEXT NOT NULL )")
                database.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_hiddenDirectories_path` ON `hiddenDirectories` (`path`)")
            }
        }
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("CREATE TABLE IF NOT EXISTS `photoDirectories` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `path` TEXT NOT NULL,`thumbnail` TEXT NOT NULL,`filename` TEXT NOT NULL, `media_count` INTEGER NOT NULL,`last_modified` INTEGER NOT NULL,`date_taken` INTEGER NOT NULL, `size` INTEGER NOT NULL, `location` INTEGER NOT NULL,  `media_types` INTEGER NOT NULL, `sort_value` TEXT NOT NULL )")
                database.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_photoDirectories_path` ON `photoDirectories` (`path`)")
                database.execSQL("CREATE TABLE IF NOT EXISTS `videoDirectories` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `path` TEXT NOT NULL,`thumbnail` TEXT NOT NULL,`filename` TEXT NOT NULL, `media_count` INTEGER NOT NULL,`last_modified` INTEGER NOT NULL,`date_taken` INTEGER NOT NULL, `size` INTEGER NOT NULL, `location` INTEGER NOT NULL,  `media_types` INTEGER NOT NULL, `sort_value` TEXT NOT NULL )")
                database.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_videoDirectories_path` ON `videoDirectories` (`path`)")
            }
        }
        private val MIGRATION_3_4 = object : Migration(3,4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("CREATE TABLE IF NOT EXISTS `videoDirectories` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `path` TEXT NOT NULL,`thumbnail` TEXT NOT NULL,`filename` TEXT NOT NULL, `media_count` INTEGER NOT NULL,`last_modified` INTEGER NOT NULL,`date_taken` INTEGER NOT NULL, `size` INTEGER NOT NULL, `location` INTEGER NOT NULL,  `media_types` INTEGER NOT NULL, `sort_value` TEXT NOT NULL )")
                database.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_videoDirectories_path` ON `videoDirectories` (`path`)");
            }
        }
        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("CREATE TABLE IF NOT EXISTS `FakeVaultDirectories` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `path` TEXT NOT NULL,`thumbnail` TEXT NOT NULL,`filename` TEXT NOT NULL, `media_count` INTEGER NOT NULL,`last_modified` INTEGER NOT NULL,`date_taken` INTEGER NOT NULL, `size` INTEGER NOT NULL, `location` INTEGER NOT NULL,  `media_types` INTEGER NOT NULL, `sort_value` TEXT NOT NULL )")
                database.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_FakeVaultDirectories_path` ON `FakeVaultDirectories` (`path`)");
                database.execSQL("CREATE TABLE IF NOT EXISTS `fakeVaultMedia` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `filename` TEXT NOT NULL,`full_path` TEXT NOT NULL,`parent_path` TEXT NOT NULL,`last_modified` INTEGER  default 0 NOT NULL,`date_taken` INTEGER NOT NULL, `size` INTEGER NOT NULL, `type` INTEGER NOT NULL,  `video_duration` INTEGER NOT NULL, `is_favorite` INTEGER  default 0 NOT NULL, `deleted_ts` INTEGER  default 0 NOT NULL )")
                database.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_fakeVaultMedia_full_path` ON `fakeVaultMedia` (`full_path`)");

            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("CREATE TABLE IF NOT EXISTS `date_takens` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `full_path` TEXT NOT NULL, `filename` TEXT NOT NULL, `parent_path` TEXT NOT NULL, `date_taken` INTEGER NOT NULL, `last_fixed` INTEGER NOT NULL)")
                database.execSQL("CREATE TABLE IF NOT EXISTS `favorites` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `full_path` TEXT NOT NULL, `filename` TEXT NOT NULL, `parent_path` TEXT NOT NULL)")

                database.execSQL("CREATE UNIQUE INDEX `index_date_takens_full_path` ON `date_takens` (`full_path`)")
                database.execSQL("CREATE UNIQUE INDEX `index_favorites_full_path` ON `favorites` (`full_path`)")
            }
        }

        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE directories ADD COLUMN sort_value TEXT default '' NOT NULL")
            }
        }

        private val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE date_takens ADD COLUMN last_modified INTEGER default 0 NOT NULL")
            }
        }
    }
}
