package com.gallery.photo.image.video.Camera;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.media.MediaScannerConnection;
import android.os.Build;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RSInvalidStateException;
import android.renderscript.RenderScript;
import android.renderscript.Script;
import android.renderscript.Type;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import com.gallery.photo.image.video.Camera.Script.ScriptC_align_mtb;
import com.gallery.photo.image.video.Camera.Script.ScriptC_avg_brighten;
import com.gallery.photo.image.video.Camera.Script.ScriptC_calculate_sharpness;
import com.gallery.photo.image.video.Camera.Script.ScriptC_create_mtb;
import com.gallery.photo.image.video.Camera.Script.ScriptC_histogram_adjust;
import com.gallery.photo.image.video.Camera.Script.ScriptC_histogram_compute;
import com.gallery.photo.image.video.Camera.Script.ScriptC_process_avg;
import com.gallery.photo.image.video.Camera.Script.ScriptC_process_hdr;
//import com.google.firebase.remoteconfig.FirebaseRemoteConfig;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HDRProcessor {
    private static final String TAG = "HDRProcessor";
    private ScriptC_align_mtb alignMTBScript;
    private int cached_avg_sample_size = 1;
    private final Context context;
    private ScriptC_create_mtb createMTBScript;
    private final boolean is_test;
    public int[] offsets_x = null;
    public int[] offsets_y = null;
    private ScriptC_process_avg processAvgScript;
    private RenderScript rs;
    public int sharp_index = 0;

    public enum DROTonemappingAlgorithm {
        DROALGORITHM_NONE,
        DROALGORITHM_GAINGAMMA
    }

    private enum HDRAlgorithm {
        HDRALGORITHM_STANDARD,
        HDRALGORITHM_SINGLE_IMAGE
    }

    public interface SortCallback {
        void sortOrder(List<Integer> list);
    }

    public enum TonemappingAlgorithm {
        TONEMAPALGORITHM_CLAMP,
        TONEMAPALGORITHM_EXPONENTIAL,
        TONEMAPALGORITHM_REINHARD,
        TONEMAPALGORITHM_FILMIC,
        TONEMAPALGORITHM_ACES
    }

    private double averageRGB(int i) {
        return ((double) ((((16711680 & i) >> 16) + ((65280 & i) >> 8)) + (i & 255))) / 3.0d;
    }

    public HDRProcessor(Context context2, boolean z) {
        this.context = context2;
        this.is_test = z;
    }

    private void freeScripts() {
        Log.d(TAG, "freeScripts");
        this.processAvgScript = null;
        this.createMTBScript = null;
        this.alignMTBScript = null;
    }

    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        freeScripts();
        RenderScript renderScript = this.rs;
        if (renderScript != null) {
            try {
                renderScript.destroy();
            } catch (RSInvalidStateException e) {
                e.printStackTrace();
            }
            this.rs = null;
        }
    }

    private static class ResponseFunction {
        float parameter_A;
        float parameter_B;

        private ResponseFunction(float parameter_A, float parameter_B) {
            this.parameter_A = parameter_A;
            this.parameter_B = parameter_B;
        }

        static ResponseFunction createIdentity() {
            return new ResponseFunction(1.0f, 0.0f);
        }

        /** Computes the response function.
         * We pass the context, so this inner class can be made static.
         * @param x_samples List of Xi samples. Must be at least 3 samples.
         * @param y_samples List of Yi samples. Must be same length as x_samples.
         * @param weights List of weights. Must be same length as x_samples.
         */
        ResponseFunction(Context context, int id, List<Double> x_samples, List<Double> y_samples, List<Double> weights) {
            if( MyDebug.LOG )
                Log.d(TAG, "ResponseFunction");

            if( x_samples.size() != y_samples.size() ) {
                if( MyDebug.LOG )
                    Log.e(TAG, "unequal number of samples");
                // throw RuntimeException, as this is a programming error
                throw new RuntimeException();
            }
            else if( x_samples.size() != weights.size() ) {
                if( MyDebug.LOG )
                    Log.e(TAG, "unequal number of samples");
                // throw RuntimeException, as this is a programming error
                throw new RuntimeException();
            }
            else if( x_samples.size() <= 3 ) {
                if( MyDebug.LOG )
                    Log.e(TAG, "not enough samples");
                // throw RuntimeException, as this is a programming error
                throw new RuntimeException();
            }

            // linear Y = AX + B
            boolean done = false;
            double sum_wx = 0.0;
            double sum_wx2 = 0.0;
            double sum_wxy = 0.0;
            double sum_wy = 0.0;
            double sum_w = 0.0;
            for(int i=0;i<x_samples.size();i++) {
                double x = x_samples.get(i);
                double y = y_samples.get(i);
                double w = weights.get(i);
                sum_wx += w * x;
                sum_wx2 += w * x * x;
                sum_wxy += w * x * y;
                sum_wy += w * y;
                sum_w += w;
            }
            if( MyDebug.LOG ) {
                Log.d(TAG, "sum_wx = " + sum_wx);
                Log.d(TAG, "sum_wx2 = " + sum_wx2);
                Log.d(TAG, "sum_wxy = " + sum_wxy);
                Log.d(TAG, "sum_wy = " + sum_wy);
                Log.d(TAG, "sum_w = " + sum_w);
            }
            // need to solve:
            // A . sum_wx + B . sum_w - sum_wy = 0
            // A . sum_wx2 + B . sum_wx - sum_wxy = 0
            // =>
            // A . sum_wx^2 + B . sum_w . sum_wx - sum_wy . sum_wx = 0
            // A . sum_w . sum_wx2 + B . sum_w . sum_wx - sum_w . sum_wxy = 0
            // A ( sum_wx^2 - sum_w . sum_wx2 ) = sum_wy . sum_wx - sum_w . sum_wxy
            // then plug A into:
            // B . sum_w = sum_wy - A . sum_wx
            double A_numer = sum_wy * sum_wx - sum_w * sum_wxy;
            double A_denom = sum_wx * sum_wx - sum_w * sum_wx2;
            if( MyDebug.LOG ) {
                Log.d(TAG, "A_numer = " + A_numer);
                Log.d(TAG, "A_denom = " + A_denom);
            }
            if( Math.abs(A_denom) < 1.0e-5 ) {
                if( MyDebug.LOG )
                    Log.e(TAG, "denom too small");
                // will fall back to linear Y = AX
            }
            else {
                parameter_A = (float)(A_numer / A_denom);
                parameter_B = (float)((sum_wy - parameter_A * sum_wx) / sum_w);
                if( MyDebug.LOG ) {
                    Log.d(TAG, "parameter_A = " + parameter_A);
                    Log.d(TAG, "parameter_B = " + parameter_B);
                }
                // we don't want a function that is not monotonic, or can be negative!
                if( parameter_A < 1.0e-5 ) {
                    if( MyDebug.LOG )
                        Log.e(TAG, "parameter A too small or negative: " + parameter_A);
                }
                else if( parameter_B < 1.0e-5 ) {
                    if( MyDebug.LOG )
                        Log.e(TAG, "parameter B too small or negative: " + parameter_B);
                }
                else {
                    done = true;
                }
            }

            if( !done ) {
                if( MyDebug.LOG )
                    Log.e(TAG, "falling back to linear Y = AX");
                // linear Y = AX
                double numer = 0.0;
                double denom = 0.0;
                for(int i=0;i<x_samples.size();i++) {
                    double x = x_samples.get(i);
                    double y = y_samples.get(i);
                    double w = weights.get(i);
                    numer += w*x*y;
                    denom += w*x*x;
                }
                if( MyDebug.LOG ) {
                    Log.d(TAG, "numer = " + numer);
                    Log.d(TAG, "denom = " + denom);
                }

                if( denom < 1.0e-5 ) {
                    if( MyDebug.LOG )
                        Log.e(TAG, "denom too small");
                    parameter_A = 1.0f;
                }
                else {
                    parameter_A = (float)(numer / denom);
                    // we don't want a function that is not monotonic!
                    if( parameter_A < 1.0e-5 ) {
                        if( MyDebug.LOG )
                            Log.e(TAG, "parameter A too small or negative: " + parameter_A);
                        parameter_A = 1.0e-5f;
                    }
                }
                parameter_B = 0.0f;
            }

            if( MyDebug.LOG ) {
                Log.d(TAG, "parameter_A = " + parameter_A);
                Log.d(TAG, "parameter_B = " + parameter_B);
            }

            if( MyDebug.LOG ) {
                // log samples to a CSV file
                File file = new File(context.getExternalFilesDir(null).getPath() + "/net.sourceforge.opencamera.hdr_samples_" + id + ".csv");
                if( file.exists() ) {
                    if( !file.delete() ) {
                        // keep FindBugs happy by checking return argument
                        Log.e(TAG, "failed to delete csv file");
                    }
                }
                FileWriter writer = null;
                try {
                    writer = new FileWriter(file);
                    //writer.append("Parameter," + parameter + "\n");
                    writer.append("Parameters,").append(String.valueOf(parameter_A)).append(",").append(String.valueOf(parameter_B)).append("\n");
                    writer.append("X,Y,Weight\n");
                    for(int i=0;i<x_samples.size();i++) {
                        //Log.d(TAG, "log: " + i + " / " + x_samples.size());
                        double x = x_samples.get(i);
                        double y = y_samples.get(i);
                        double w = weights.get(i);
                        writer.append(String.valueOf(x)).append(",").append(String.valueOf(y)).append(",").append(String.valueOf(w)).append("\n");
                    }
                }
                catch (IOException e) {
                    Log.e(TAG, "failed to open csv file");
                    e.printStackTrace();
                }
                finally {
                    try {
                        if( writer != null )
                            writer.close();
                    }
                    catch (IOException e) {
                        Log.e(TAG, "failed to close csv file");
                        e.printStackTrace();
                    }
                }
                MediaScannerConnection.scanFile(context, new String[] { file.getAbsolutePath() }, null, null);
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void processHDR(List<Bitmap> bitmaps, boolean release_bitmaps, Bitmap output_bitmap, boolean assume_sorted, SortCallback sort_cb, float hdr_alpha, int n_tiles, boolean ce_preserve_blacks, TonemappingAlgorithm tonemapping_algorithm, DROTonemappingAlgorithm dro_tonemapping_algorithm) throws HDRProcessorException {
        if( MyDebug.LOG )
            Log.d(TAG, "processHDR");
        if( !assume_sorted && !release_bitmaps ) {
            if( MyDebug.LOG )
                Log.d(TAG, "take a copy of bitmaps array");
            // if !release_bitmaps, then we shouldn't be modifying the input bitmaps array - but if !assume_sorted, we need to sort them
            // so make sure we take a copy
            bitmaps = new ArrayList<>(bitmaps);
        }
        int n_bitmaps = bitmaps.size();
        //if( n_bitmaps != 1 && n_bitmaps != 3 && n_bitmaps != 5 && n_bitmaps != 7 ) {
        if( n_bitmaps < 1 || n_bitmaps > 7 ) {
            if( MyDebug.LOG )
                Log.e(TAG, "n_bitmaps not supported: " + n_bitmaps);
            throw new HDRProcessorException(HDRProcessorException.INVALID_N_IMAGES);
        }
        for(int i=1;i<n_bitmaps;i++) {
            if( bitmaps.get(i).getWidth() != bitmaps.get(0).getWidth() ||
                    bitmaps.get(i).getHeight() != bitmaps.get(0).getHeight() ) {
                if( MyDebug.LOG ) {
                    Log.e(TAG, "bitmaps not of same resolution");
                    for(int j=0;j<n_bitmaps;j++) {
                        Log.e(TAG, "bitmaps " + j + " : " + bitmaps.get(j).getWidth() + " x " + bitmaps.get(j).getHeight());
                    }
                }
                throw new HDRProcessorException(HDRProcessorException.UNEQUAL_SIZES);
            }
        }

        final HDRAlgorithm algorithm = n_bitmaps == 1 ? HDRAlgorithm.HDRALGORITHM_SINGLE_IMAGE : HDRAlgorithm.HDRALGORITHM_STANDARD;

        switch( algorithm ) {
            case HDRALGORITHM_SINGLE_IMAGE:
                if( !assume_sorted && sort_cb != null ) {
                    List<Integer> sort_order = new ArrayList<>();
                    sort_order.add(0);
                    sort_cb.sortOrder(sort_order);
                }
                processSingleImage(bitmaps, release_bitmaps, output_bitmap, hdr_alpha, n_tiles, ce_preserve_blacks, dro_tonemapping_algorithm);
                break;
            case HDRALGORITHM_STANDARD:
                processHDRCore(bitmaps, release_bitmaps, output_bitmap, assume_sorted, sort_cb, hdr_alpha, n_tiles, ce_preserve_blacks, tonemapping_algorithm);
                break;
            default:
                if( MyDebug.LOG )
                    Log.e(TAG, "unknown algorithm " + algorithm);
                // throw RuntimeException, as this is a programming error
                throw new RuntimeException();
        }
    }

    private ResponseFunction createFunctionFromBitmaps(int i, Bitmap bitmap, Bitmap bitmap2, int i2, int i3) {
        double d;
        double d2;
        ArrayList arrayList;
        double d3;
        ArrayList arrayList2;
        int i4;
        Log.d(TAG, "createFunctionFromBitmaps");
        ArrayList arrayList3 = new ArrayList();
        ArrayList arrayList4 = new ArrayList();
        ArrayList arrayList5 = new ArrayList();
        int sqrt = (int) Math.sqrt(100.0d);
        int i5 = 100 / sqrt;
        double d4 = 0d;
        double d5 = 0.0d;
        int i6 = 0;
        while (i6 < i5) {
            double d6 = 1.0d;
            int height = (int) (((((double) i6) + 1.0d) / (((double) i5) + 1.0d)) * ((double) bitmap.getHeight()));
            d5 = d5;
            int i7 = 0;
            while (i7 < sqrt) {
                ArrayList arrayList6 = arrayList4;
                ArrayList arrayList7 = arrayList5;
                int i8 = i6;
                int i9 = i7;
                int width = (int) (((((double) i7) + d6) / (((double) sqrt) + d6)) * ((double) bitmap.getWidth()));
                int i10 = width + i2;
                if (i10 < 0 || i10 >= bitmap.getWidth() || (i4 = height + i3) < 0 || i4 >= bitmap.getHeight()) {
                    Bitmap bitmap3 = bitmap;
                    Bitmap bitmap4 = bitmap2;
                    arrayList2 = arrayList6;
                } else {
                    int pixel = bitmap.getPixel(i10, i4);
                    int pixel2 = bitmap2.getPixel(width, height);
                    double averageRGB = averageRGB(pixel);
                    double averageRGB2 = averageRGB(pixel2);
                    d4 += averageRGB;
                    d5 += averageRGB2;
                    arrayList3.add(Double.valueOf(averageRGB));
                    arrayList2 = arrayList6;
                    arrayList2.add(Double.valueOf(averageRGB2));
                }
                i7 = i9 + 1;
                arrayList4 = arrayList2;
                arrayList5 = arrayList7;
                i6 = i8;
                d6 = 1.0d;
            }
            Bitmap bitmap5 = bitmap;
            int i11 = i6;
            Bitmap bitmap6 = bitmap2;
            i6 = i11 + 1;
            arrayList4 = arrayList4;
            arrayList5 = arrayList5;
        }
        ArrayList arrayList8 = arrayList5;
        double d7 = d5;
        ArrayList arrayList9 = arrayList4;
        if (arrayList3.size() == 0) {
            Log.e(TAG, "no samples for response function!");
            d4 += 255.0d;
            d = d7 + 255.0d;
            arrayList3.add(Double.valueOf(255.0d));
            arrayList9.add(Double.valueOf(255.0d));
        } else {
            d = d7;
        }
        double size = d4 / ((double) arrayList3.size());
        double size2 = d / ((double) arrayList3.size());
        boolean z = size < size2;
        Log.d(TAG, "avg_in: " + size);
        Log.d(TAG, "avg_out: " + size2);
        Log.d(TAG, "is_dark_exposure: " + z);
        double doubleValue = ((Double) arrayList3.get(0)).doubleValue();
        double doubleValue2 = ((Double) arrayList3.get(0)).doubleValue();
        for (int i12 = 1; i12 < arrayList3.size(); i12++) {
            double doubleValue3 = ((Double) arrayList3.get(i12)).doubleValue();
            if (doubleValue3 < doubleValue) {
                doubleValue = doubleValue3;
            }
            if (doubleValue3 > doubleValue2) {
                doubleValue2 = doubleValue3;
            }
        }
        double d8 = (doubleValue + doubleValue2) * 0.5d;
        Log.d(TAG, "min_value: " + doubleValue);
        Log.d(TAG, "max_value: " + doubleValue2);
        Log.d(TAG, "med_value: " + d8);
        double d9 = doubleValue2;
        double doubleValue4 = ((Double) arrayList9.get(0)).doubleValue();
        double doubleValue5 = ((Double) arrayList9.get(0)).doubleValue();
        for (int i13 = 1; i13 < arrayList9.size(); i13++) {
            double doubleValue6 = ((Double) arrayList9.get(i13)).doubleValue();
            if (doubleValue6 < doubleValue4) {
                doubleValue4 = doubleValue6;
            }
            if (doubleValue6 > doubleValue5) {
                doubleValue5 = doubleValue6;
            }
        }
        ArrayList arrayList10 = arrayList9;
        double d10 = (doubleValue4 + doubleValue5) * 0.5d;
        Log.d(TAG, "min_value_y: " + doubleValue4);
        Log.d(TAG, "max_value_y: " + doubleValue5);
        Log.d(TAG, "med_value_y: " + d10);
        int i14 = 0;
        while (i14 < arrayList3.size()) {
            double doubleValue7 = ((Double) arrayList3.get(i14)).doubleValue();
            double doubleValue8 = ((Double) arrayList10.get(i14)).doubleValue();
            if (z) {
                if (doubleValue7 <= d8) {
                    d3 = doubleValue7 - doubleValue;
                    d2 = d9;
                } else {
                    d2 = d9;
                    d3 = d2 - doubleValue7;
                }
                double d11 = doubleValue8 <= d10 ? doubleValue8 - doubleValue4 : doubleValue5 - doubleValue8;
                if (d11 < d3) {
                    d3 = d11;
                }
                Double valueOf = Double.valueOf(d3);
                ArrayList arrayList11 = arrayList8;
                arrayList11.add(valueOf);
                arrayList = arrayList11;
            } else {
                d2 = d9;
                arrayList = arrayList8;
                arrayList.add(Double.valueOf(doubleValue7 <= d8 ? doubleValue7 - doubleValue : d2 - doubleValue7));
            }
            i14++;
            arrayList8 = arrayList;
            d9 = d2;
        }
        return new ResponseFunction(this.context, i, arrayList3, arrayList10, arrayList8);
    }

    /** Core implementation of HDR algorithm.
     *  Requires Android 4.4 (API level 19, Kitkat), due to using Renderscript without the support libraries.
     *  And we now need Android 5.0 (API level 21, Lollipop) for forEach_Dot with LaunchOptions.
     *  Using the support libraries (set via project.properties renderscript.support.mode) would bloat the APK
     *  by around 1799KB! We don't care about pre-Android 4.4 (HDR requires CameraController2 which requires
     *  Android 5.0 anyway; even if we later added support for CameraController1, we can simply say HDR requires
     *  Android 5.0).
     */
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void processHDRCore(List<Bitmap> bitmaps, boolean release_bitmaps, Bitmap output_bitmap, boolean assume_sorted, SortCallback sort_cb, float hdr_alpha, int n_tiles, boolean ce_preserve_blacks, TonemappingAlgorithm tonemapping_algorithm) {
        if( MyDebug.LOG )
            Log.d(TAG, "processHDRCore");

        long time_s = System.currentTimeMillis();

        int n_bitmaps = bitmaps.size();
        int width = bitmaps.get(0).getWidth();
        int height = bitmaps.get(0).getHeight();
        ResponseFunction [] response_functions = new ResponseFunction[n_bitmaps]; // ResponseFunction for each image (the ResponseFunction entry can be left null to indicate the Identity)
        offsets_x = new int[n_bitmaps];
        offsets_y = new int[n_bitmaps];
		/*int [][] buffers = new int[n_bitmaps][];
		for(int i=0;i<n_bitmaps;i++) {
			buffers[i] = new int[bm.getWidth()];
		}*/
        //float [] hdr = new float[3];
        //int [] rgb = new int[3];

        initRenderscript();
        if( MyDebug.LOG )
            Log.d(TAG, "### time after creating renderscript: " + (System.currentTimeMillis() - time_s));
        // create allocations
        Allocation[] allocations = new Allocation[n_bitmaps];
        for(int i=0;i<n_bitmaps;i++) {
            allocations[i] = Allocation.createFromBitmap(rs, bitmaps.get(i));
        }
        if( MyDebug.LOG )
            Log.d(TAG, "### time after creating allocations from bitmaps: " + (System.currentTimeMillis() - time_s));
        //final int base_bitmap = (n_bitmaps - 1) / 2; // index of the bitmap with the base exposure and offsets
        final int base_bitmap = n_bitmaps % 2 == 0 ? n_bitmaps/2 : (n_bitmaps - 1) / 2; // index of the bitmap with the base exposure and offsets
        // for even number of images, round up to brighter image

        // perform auto-alignment
        // if assume_sorted if false, this function will also sort the allocations and bitmaps from darkest to brightest.
        BrightnessDetails brightnessDetails = autoAlignment(offsets_x, offsets_y, allocations, width, height, bitmaps, base_bitmap, assume_sorted, sort_cb, true, false, 1, true, 1, width, height, time_s);
        int median_brightness = brightnessDetails.median_brightness;
        if( MyDebug.LOG ) {
            Log.d(TAG, "### time after autoAlignment: " + (System.currentTimeMillis() - time_s));
            Log.d(TAG, "median_brightness: " + median_brightness);
        }

        //final boolean use_hdr_n = true; // test always using hdr_n
        final boolean use_hdr_n = n_bitmaps != 3;

        // compute response_functions
        for(int i=0;i<n_bitmaps;i++) {
            ResponseFunction function = null;
            if( i != base_bitmap ) {
                function = createFunctionFromBitmaps(i, bitmaps.get(i), bitmaps.get(base_bitmap), offsets_x[i], offsets_y[i]);
            }
            else if( use_hdr_n ) {
                // for hdr_n, need to still create the identity response function
                function = ResponseFunction.createIdentity();
            }
            response_functions[i] = function;
        }
        if( MyDebug.LOG )
            Log.d(TAG, "### time after creating response functions: " + (System.currentTimeMillis() - time_s));

        if( n_bitmaps % 2 == 0 ) {
            // need to remap so that we aim for a brightness between the middle two images
            float a = (float) Math.sqrt(response_functions[base_bitmap-1].parameter_A);
            float b = response_functions[base_bitmap-1].parameter_B / (a+1.0f);
            if( MyDebug.LOG ) {
                Log.d(TAG, "remap for even number of images");
                Log.d(TAG, "    a: " + a);
                Log.d(TAG, "    b: " + b);
            }
            if( a < 1.0e-5f ) {
                // avoid risk of division by 0
                a = 1.0e-5f;
                if( MyDebug.LOG )
                    Log.e(TAG, "    clamp a to: " + a);
            }
            for(int i=0;i<n_bitmaps;i++) {
                float this_A = response_functions[i].parameter_A;
                float this_B = response_functions[i].parameter_B;
                response_functions[i].parameter_A = this_A / a;
                response_functions[i].parameter_B = this_B - this_A * b / a;
                if( MyDebug.LOG ) {
                    Log.d(TAG, "remapped: " + i);
                    Log.d(TAG, "    A: " + this_A + " -> " + response_functions[i].parameter_A);
                    Log.d(TAG, "    B: " + this_B + " -> " + response_functions[i].parameter_B);
                }
            }
        }

		/*
		// calculate average luminance by sampling
		final int n_samples_c = 100;
		final int n_w_samples = (int)Math.sqrt(n_samples_c);
		final int n_h_samples = n_samples_c/n_w_samples;

		double sum_log_luminance = 0.0;
		int count = 0;
		for(int y=0;y<n_h_samples;y++) {
			double alpha = ((double)y+1.0) / ((double)n_h_samples+1.0);
			int y_coord = (int)(alpha * bm.getHeight());
			for(int i=0;i<n_bitmaps;i++) {
				bitmaps.get(i).getPixels(buffers[i], 0, bm.getWidth(), 0, y_coord, bm.getWidth(), 1);
			}
			for(int x=0;x<n_w_samples;x++) {
				double beta = ((double)x+1.0) / ((double)n_w_samples+1.0);
				int x_coord = (int)(beta * bm.getWidth());
				if( MyDebug.LOG )
					Log.d(TAG, "sample luminance from " + x_coord + " , " + y_coord);
				calculateHDR(hdr, n_bitmaps, buffers, x_coord, response_functions);
				double luminance = calculateLuminance(hdr[0], hdr[1], hdr[2]) + 1.0; // add 1 so we don't take log of 0..;
				sum_log_luminance += Math.log(luminance);
				count++;
			}
		}
		float avg_luminance = (float)(Math.exp( sum_log_luminance / count ));
		if( MyDebug.LOG )
			Log.d(TAG, "avg_luminance: " + avg_luminance);
		if( MyDebug.LOG )
			Log.d(TAG, "time after calculating average luminance: " + (System.currentTimeMillis() - time_s));
			*/

        // write new hdr image

        // create RenderScript
		/*if( processHDRScript == null ) {
			processHDRScript = new ScriptC_process_hdr(rs);
		}*/
        ScriptC_process_hdr processHDRScript = new ScriptC_process_hdr(rs);

        // set allocations
        processHDRScript.set_bitmap0(allocations[0]);
        if( n_bitmaps > 2 ) {
            processHDRScript.set_bitmap2(allocations[2]);
        }

        // set offsets
        processHDRScript.set_offset_x0(offsets_x[0]);
        processHDRScript.set_offset_y0(offsets_y[0]);
        // no offset for middle image
        if( n_bitmaps > 2 ) {
            processHDRScript.set_offset_x2(offsets_x[2]);
            processHDRScript.set_offset_y2(offsets_y[2]);
        }

        // set response functions
        processHDRScript.set_parameter_A0(response_functions[0].parameter_A);
        processHDRScript.set_parameter_B0(response_functions[0].parameter_B);
        // no response function for middle image
        if( n_bitmaps > 2 ) {
            processHDRScript.set_parameter_A2(response_functions[2].parameter_A);
            processHDRScript.set_parameter_B2(response_functions[2].parameter_B);
        }

        if( use_hdr_n ) {
            // now need to set values for image 1
            processHDRScript.set_bitmap1(allocations[1]);
            processHDRScript.set_offset_x1(offsets_x[1]);
            processHDRScript.set_offset_y1(offsets_y[1]);
            processHDRScript.set_parameter_A1(response_functions[1].parameter_A);
            processHDRScript.set_parameter_B1(response_functions[1].parameter_B);
        }

        if( n_bitmaps > 3 ) {
            processHDRScript.set_bitmap3(allocations[3]);
            processHDRScript.set_offset_x3(offsets_x[3]);
            processHDRScript.set_offset_y3(offsets_y[3]);
            processHDRScript.set_parameter_A3(response_functions[3].parameter_A);
            processHDRScript.set_parameter_B3(response_functions[3].parameter_B);

            if( n_bitmaps > 4 ) {
                processHDRScript.set_bitmap4(allocations[4]);
                processHDRScript.set_offset_x4(offsets_x[4]);
                processHDRScript.set_offset_y4(offsets_y[4]);
                processHDRScript.set_parameter_A4(response_functions[4].parameter_A);
                processHDRScript.set_parameter_B4(response_functions[4].parameter_B);

                if( n_bitmaps > 5 ) {
                    processHDRScript.set_bitmap5(allocations[5]);
                    processHDRScript.set_offset_x5(offsets_x[5]);
                    processHDRScript.set_offset_y5(offsets_y[5]);
                    processHDRScript.set_parameter_A5(response_functions[5].parameter_A);
                    processHDRScript.set_parameter_B5(response_functions[5].parameter_B);

                    if( n_bitmaps > 6 ) {
                        processHDRScript.set_bitmap6(allocations[6]);
                        processHDRScript.set_offset_x6(offsets_x[6]);
                        processHDRScript.set_offset_y6(offsets_y[6]);
                        processHDRScript.set_parameter_A6(response_functions[6].parameter_A);
                        processHDRScript.set_parameter_B6(response_functions[6].parameter_B);
                    }
                }
            }
        }

        // set globals

        // set tonemapping algorithm
        switch( tonemapping_algorithm ) {
            case TONEMAPALGORITHM_CLAMP:
                if( MyDebug.LOG )
                    Log.d(TAG, "tonemapping algorithm: clamp");
                processHDRScript.set_tonemap_algorithm( processHDRScript.get_tonemap_algorithm_clamp_c() );
                break;
            case TONEMAPALGORITHM_EXPONENTIAL:
                if( MyDebug.LOG )
                    Log.d(TAG, "tonemapping algorithm: exponential");
                processHDRScript.set_tonemap_algorithm( processHDRScript.get_tonemap_algorithm_exponential_c() );
                break;
            case TONEMAPALGORITHM_REINHARD:
                if( MyDebug.LOG )
                    Log.d(TAG, "tonemapping algorithm: reinhard");
                processHDRScript.set_tonemap_algorithm( processHDRScript.get_tonemap_algorithm_reinhard_c() );
                break;
            case TONEMAPALGORITHM_FILMIC:
                if( MyDebug.LOG )
                    Log.d(TAG, "tonemapping algorithm: filmic");
                processHDRScript.set_tonemap_algorithm( processHDRScript.get_tonemap_algorithm_filmic_c() );
                break;
            case TONEMAPALGORITHM_ACES:
                if( MyDebug.LOG )
                    Log.d(TAG, "tonemapping algorithm: aces");
                processHDRScript.set_tonemap_algorithm( processHDRScript.get_tonemap_algorithm_aces_c() );
                break;
        }

        float max_possible_value = response_functions[0].parameter_A * 255 + response_functions[0].parameter_B;
        //float max_possible_value = response_functions[base_bitmap - 1].parameter_A * 255 + response_functions[base_bitmap - 1].parameter_B;
        if( MyDebug.LOG )
            Log.d(TAG, "max_possible_value: " + max_possible_value);
        if( max_possible_value < 255.0f ) {
            max_possible_value = 255.0f; // don't make dark images too bright, see below about linear_scale for more details
            if( MyDebug.LOG )
                Log.d(TAG, "clamp max_possible_value to: " + max_possible_value);
        }

        //hdr_alpha = 0.0f; // test
        //final float tonemap_scale_c = avg_luminance / 0.8f; // lower values tend to result in too dark pictures; higher values risk over exposed bright areas
        //final float tonemap_scale_c = 255.0f;
        //final float tonemap_scale_c = 255.0f - median_brightness;
        float tonemap_scale_c = 255.0f;

        int median_target = getBrightnessTarget(median_brightness, 2, 119);

        if( MyDebug.LOG ) {
            Log.d(TAG, "median_target: " + median_target);
            Log.d(TAG, "compare: " + 255.0f / max_possible_value);
            Log.d(TAG, "to: " + (((float)median_target)/(float)median_brightness + median_target / 255.0f - 1.0f));
        }
        if( 255.0f / max_possible_value < ((float)median_target)/(float)median_brightness + median_target / 255.0f - 1.0f ) {
            // For Reinhard tonemapping:
            // As noted below, we have f(V) = V.S / (V+C), where V is the HDR value, C is tonemap_scale_c
            // and S = (Vmax + C)/Vmax (see below)
            // Ideally we try to choose C such that we map median value M to target T:
            // f(M) = T
            // => T = M . (Vmax + C) / (Vmax . (M + C))
            // => (T/M).(M + C) = (Vmax + C) / Vmax = 1 + C/Vmax
            // => C . ( T/M - 1/Vmax ) = 1 - T
            // => C = (1-T) / (T/M - 1/Vmax)
            // Since we want C <= 1, we must have:
            // 1-T <= T/M - 1/Vmax
            // => 1/Vmax <= T/M + T - 1
            // If this isn't the case, we set C to 1 (to preserve the median as close as possible).
            // Note that if we weren't doing the linear scaling below, this would reduce to choosing
            // C = M(1-T)/T. We also tend to that as max_possible_value tends to infinity. So even though
            // we only sometimes enter this case, it's important for cases where max_possible_value
            // might be estimated too large (also consider that if we ever support more than 3 images,
            // we'd risk having too large values).
            // If T=M, then this simplifies to C = 1-M.
            // I've tested that using "C = 1-M" always (and no linear scaling) also gives good results:
            // much better compared to Open Camera 1.39, though not quite as good as doing both this
            // and linear scaling (testHDR18, testHDR26, testHDR32 look too grey and/or bright).
            final float tonemap_denom = ((float)median_target)/(float)median_brightness - (255.0f / max_possible_value);
            if( MyDebug.LOG )
                Log.d(TAG, "tonemap_denom: " + tonemap_denom);
            if( tonemap_denom != 0.0f ) { // just in case
                tonemap_scale_c = (255.0f - median_target) / tonemap_denom;
                if( MyDebug.LOG )
                    Log.d(TAG, "tonemap_scale_c (before setting min): " + tonemap_scale_c);
                /*if( tonemap_scale_c < 0.5f*255.0f ) {
                    throw new RuntimeException("tonemap_scale_c: " + tonemap_scale_c);
                }*/
                // important to set a min value, see testHDR58, testHDR59, testHDR60 - at least 0.25, but 0.5 works better:
                //tonemap_scale_c = Math.max(tonemap_scale_c, 0.25f*255.0f);
                tonemap_scale_c = Math.max(tonemap_scale_c, 0.5f*255.0f);
            }
            //throw new RuntimeException(); // test
        }
        // Higher tonemap_scale_c values means darker results from the Reinhard tonemapping.
        // Colours brighter than 255-tonemap_scale_c will be made darker, colours darker than 255-tonemap_scale_c will be made brighter
        // (tonemap_scale_c==255 means therefore that colours will only be made darker).
        if( MyDebug.LOG )
            Log.d(TAG, "tonemap_scale_c: " + tonemap_scale_c);
        processHDRScript.set_tonemap_scale(tonemap_scale_c);

        // algorithm specific parameters
        switch( tonemapping_algorithm ) {
            case TONEMAPALGORITHM_EXPONENTIAL:
            {
                // The basic algorithm is f(V) = 1 - exp( - E * V ), where V is the HDR value, E is a
                // constant. This maps [0, infinity] to [0, 1]. However we have an estimate of the maximum
                // possible value, Vmax, so we can set a linear scaling S so that [0, Vmax] maps to [0, 1]
                // f(V) = S . (1 - exp( - E * V ))
                // so 1 = S . (1 - exp( - E * Vmax ))
                // => S = 1 / (1 - exp( - E * Vmax ))
                // Note that Vmax should be set to a minimum of 255, else we'll make darker images brighter.
                float E = processHDRScript.get_exposure();
                float linear_scale = (float)(1.0 / (1.0 - Math.exp(-E * max_possible_value / 255.0)));
                if( MyDebug.LOG )
                    Log.d(TAG, "linear_scale: " + linear_scale);
                processHDRScript.set_linear_scale(linear_scale);
                break;
            }
            case TONEMAPALGORITHM_REINHARD: {
                // The basic algorithm is f(V) = V / (V+C), where V is the HDR value, C is tonemap_scale_c
                // This was used until Open Camera 1.39, but has the problem of making images too dark: it
                // maps [0, infinity] to [0, 1], but since in practice we never have very large V values, we
                // won't use the full [0, 1] range. So we apply a linear scale S:
                // f(V) = V.S / (V+C)
                // S is chosen such that the maximum possible value, Vmax, maps to 1. So:
                // 1 = Vmax . S / (Vmax + C)
                // => S = (Vmax + C)/Vmax
                // Note that we don't actually know the maximum HDR value, but instead we estimate it with
                // max_possible_value, which gives the maximum value we'd have if even the darkest image was
                // 255.0.
                // Note that if max_possible_value was less than 255, we'd end up scaling a max value less than
                // 1, to [0, 1], i.e., making dark images brighter, which we don't want, which is why above we
                // set max_possible_value to a minimum of 255. In practice, this is unlikely to ever happen
                // since max_possible_value is calculated as a maximum possible based on the response functions
                // (as opposed to the real brightest HDR value), so even for dark photos we'd expect to have
                // max_possible_value >= 255.
                // Note that the original Reinhard tonemapping paper describes a non-linear scaling by (1 + CV/Vmax^2),
                // though this is poorer performance (in terms of calculation time).
                float linear_scale = (max_possible_value + tonemap_scale_c) / max_possible_value;
                if( MyDebug.LOG )
                    Log.d(TAG, "linear_scale: " + linear_scale);
                processHDRScript.set_linear_scale(linear_scale);
                break;
            }
            case TONEMAPALGORITHM_FILMIC:
            {
                // For filmic, we have f(V) = U(EV) / U(W), where V is the HDR value, U is a function.
                // We want f(Vmax) = 1, so EVmax = W
                float E = processHDRScript.get_filmic_exposure_bias();
                float W = E * max_possible_value;
                if( MyDebug.LOG )
                    Log.d(TAG, "filmic W: " + W);
                processHDRScript.set_W(W);
                break;
            }
        }

        if( MyDebug.LOG )
            Log.d(TAG, "call processHDRScript");
        Allocation output_allocation;
        boolean free_output_allocation = false;
        if( release_bitmaps ) {
            // must use allocations[base_bitmap] as the output, as that's the image guaranteed to have no offset (otherwise we'll have
            // problems due to the output being equal to one of the inputs)
            output_allocation = allocations[base_bitmap];
        }
        else {
            output_allocation = Allocation.createFromBitmap(rs, output_bitmap);
            free_output_allocation = true;
        }
        if( MyDebug.LOG )
            Log.d(TAG, "### time before processHDRScript: " + (System.currentTimeMillis() - time_s));
        if( use_hdr_n ) {
            processHDRScript.set_n_bitmaps_g(n_bitmaps);
            processHDRScript.forEach_hdr_n(allocations[base_bitmap], output_allocation);
        }
        else {
            processHDRScript.forEach_hdr(allocations[base_bitmap], output_allocation);
        }
		/*processHDRScript.set_n_bitmaps_g(n_bitmaps);
		processHDRScript.forEach_hdr_n(allocations[base_bitmap], output_allocation);*/
        if( MyDebug.LOG )
            Log.d(TAG, "### time after processHDRScript: " + (System.currentTimeMillis() - time_s));

        if( release_bitmaps ) {
            if( MyDebug.LOG )
                Log.d(TAG, "release bitmaps");
            // bitmaps.get(base_bitmap) will store HDR image, so free up the rest of the memory asap - we no longer need the remaining bitmaps
            for(int i=0;i<bitmaps.size();i++) {
                if (i != base_bitmap) {
                    Bitmap bitmap = bitmaps.get(i);
                    bitmap.recycle();
                }
            }
        }

        if( hdr_alpha != 0.0f ) {
            adjustHistogram(output_allocation, output_allocation, width, height, hdr_alpha, n_tiles, ce_preserve_blacks, time_s);
            if( MyDebug.LOG )
                Log.d(TAG, "### time after adjustHistogram: " + (System.currentTimeMillis() - time_s));
        }

        if( release_bitmaps ) {
            // must be the base_bitmap we copy to - see note above about using allocations[base_bitmap] as the output
            allocations[base_bitmap].copyTo(bitmaps.get(base_bitmap));
            if( MyDebug.LOG )
                Log.d(TAG, "### time after copying to bitmap: " + (System.currentTimeMillis() - time_s));

            // make it so that we store the output bitmap as first in the list
            bitmaps.set(0, bitmaps.get(base_bitmap));
            for(int i=1;i<bitmaps.size();i++) {
                bitmaps.set(i, null);
            }
        }
        else {
            output_allocation.copyTo(output_bitmap);
            if( MyDebug.LOG )
                Log.d(TAG, "### time after copying to bitmap: " + (System.currentTimeMillis() - time_s));
        }

        if( free_output_allocation )
            output_allocation.destroy();
        for(int i=0;i<n_bitmaps;i++) {
            allocations[i].destroy();
            allocations[i] = null;
        }
        freeScripts();
        if( MyDebug.LOG )
            Log.d(TAG, "### time for processHDRCore: " + (System.currentTimeMillis() - time_s));
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void processSingleImage(List<Bitmap> bitmaps, boolean release_bitmaps, Bitmap output_bitmap, float hdr_alpha, int n_tiles, boolean ce_preserve_blacks, DROTonemappingAlgorithm dro_tonemapping_algorithm) {
        if( MyDebug.LOG )
            Log.d(TAG, "processSingleImage");

        long time_s = System.currentTimeMillis();

        int width = bitmaps.get(0).getWidth();
        int height = bitmaps.get(0).getHeight();

        initRenderscript();
        if( MyDebug.LOG )
            Log.d(TAG, "### time after creating renderscript: " + (System.currentTimeMillis() - time_s));

        // create allocation
        Allocation allocation = Allocation.createFromBitmap(rs, bitmaps.get(0));

        Allocation output_allocation;
        boolean free_output_allocation = false;
        if( release_bitmaps ) {
            output_allocation = allocation;
        }
        else {
            free_output_allocation = true;
            output_allocation = Allocation.createFromBitmap(rs, output_bitmap);
        }

        if( dro_tonemapping_algorithm == DROTonemappingAlgorithm.DROALGORITHM_GAINGAMMA ) {
            // brighten?
            int [] histo = computeHistogram(allocation, false, false);
            HistogramInfo histogramInfo = getHistogramInfo(histo);
            int brightness = histogramInfo.median_brightness;
            int max_brightness = histogramInfo.max_brightness;
            if( MyDebug.LOG )
                Log.d(TAG, "### time after computeHistogram: " + (System.currentTimeMillis() - time_s));
            if( MyDebug.LOG ) {
                Log.d(TAG, "median brightness: " + brightness);
                Log.d(TAG, "max brightness: " + max_brightness);
            }
            BrightenFactors brighten_factors = computeBrightenFactors(false, 0, 0, brightness, max_brightness);
            float gain = brighten_factors.gain;
            float gamma = brighten_factors.gamma;
            float low_x = brighten_factors.low_x;
            float mid_x = brighten_factors.mid_x;
            if( MyDebug.LOG ) {
                Log.d(TAG, "gain: " + gain);
                Log.d(TAG, "gamma: " + gamma);
                Log.d(TAG, "low_x: " + low_x);
                Log.d(TAG, "mid_x: " + mid_x);
            }

            if( Math.abs(gain - 1.0) > 1.0e-5 || max_brightness != 255 || Math.abs(gamma - 1.0) > 1.0e-5 ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "apply gain/gamma");
                //if( true )
                //	throw new HDRProcessorException(HDRProcessorException.UNEQUAL_SIZES); // test

                ScriptC_avg_brighten script = new ScriptC_avg_brighten(rs);
                script.invoke_setBrightenParameters(gain, gamma, low_x, mid_x, max_brightness);

                script.forEach_dro_brighten(allocation, output_allocation);

                // output is now the input for subsequent operations
                if( free_output_allocation ) {
                    allocation.destroy();
                    free_output_allocation = false;
                }
                allocation = output_allocation;
                if( MyDebug.LOG )
                    Log.d(TAG, "### time after dro_brighten: " + (System.currentTimeMillis() - time_s));
            }
        }

        adjustHistogram(allocation, output_allocation, width, height, hdr_alpha, n_tiles, ce_preserve_blacks, time_s);

        if( release_bitmaps ) {
            allocation.copyTo(bitmaps.get(0));
            if( MyDebug.LOG )
                Log.d(TAG, "time after copying to bitmap: " + (System.currentTimeMillis() - time_s));
        }
        else {
            output_allocation.copyTo(output_bitmap);
            if( MyDebug.LOG )
                Log.d(TAG, "time after copying to bitmap: " + (System.currentTimeMillis() - time_s));
        }

        if( free_output_allocation )
            allocation.destroy();
        output_allocation.destroy();
        freeScripts();

        if( MyDebug.LOG )
            Log.d(TAG, "time for processSingleImage: " + (System.currentTimeMillis() - time_s));
    }

    /* access modifiers changed from: package-private */
    public void brightenImage(Bitmap bitmap, int i, int i2, int i3) {
        Bitmap bitmap2 = bitmap;
        int i4 = i2;
        Log.d(TAG, "brightenImage");
        StringBuilder sb = new StringBuilder();
        sb.append("brightness: ");
        int i5 = i;
        sb.append(i5);
        Log.d(TAG, sb.toString());
        Log.d(TAG, "max_brightness: " + i4);
        StringBuilder sb2 = new StringBuilder();
        sb2.append("brightness_target: ");
        int i6 = i3;
        sb2.append(i6);
        Log.d(TAG, sb2.toString());
        BrightenFactors computeBrightenFactors = computeBrightenFactors(false, 0, 0, i5, i2, i6, false);
        float f = computeBrightenFactors.gain;
        float f2 = computeBrightenFactors.gamma;
        float f3 = computeBrightenFactors.low_x;
        float f4 = computeBrightenFactors.mid_x;
        Log.d(TAG, "gain: " + f);
        Log.d(TAG, "gamma: " + f2);
        Log.d(TAG, "low_x: " + f3);
        Log.d(TAG, "mid_x: " + f4);
        if (Math.abs(((double) f) - 1.0d) > 1.0E-5d || i4 != 255 || Math.abs(((double) f2) - 1.0d) > 1.0E-5d) {
            Log.d(TAG, "apply gain/gamma");
            initRenderscript();
            Allocation createFromBitmap = Allocation.createFromBitmap(this.rs, bitmap2);
            ScriptC_avg_brighten scriptC_avg_brighten = new ScriptC_avg_brighten(this.rs);
            scriptC_avg_brighten.invoke_setBrightenParameters(f, f2, f3, f4, (float) i4);
            scriptC_avg_brighten.forEach_dro_brighten(createFromBitmap, createFromBitmap);
            createFromBitmap.copyTo(bitmap2);
            createFromBitmap.destroy();
            freeScripts();
        }
    }

    private void initRenderscript() {
        Log.d(TAG, "initRenderscript");
        if (this.rs == null) {
            this.rs = RenderScript.create(this.context);
            Log.d(TAG, "create renderscript object");
        }
    }

    public int getAvgSampleSize(int i) {
        this.cached_avg_sample_size = i >= 1100 ? 2 : 1;
        Log.d(TAG, "getAvgSampleSize: " + this.cached_avg_sample_size);
        return this.cached_avg_sample_size;
    }

    public int getAvgSampleSize() {
        return this.cached_avg_sample_size;
    }

    public static class AvgData {
        Allocation allocation_avg_align;
        public Allocation allocation_out;
        Bitmap bitmap_avg_align;

        AvgData(Allocation allocation, Bitmap bitmap, Allocation allocation2) {
            this.allocation_out = allocation;
            this.bitmap_avg_align = bitmap;
            this.allocation_avg_align = allocation2;
        }

        public void destroy() {
            Log.d(HDRProcessor.TAG, "AvgData.destroy()");
            Allocation allocation = this.allocation_out;
            if (allocation != null) {
                allocation.destroy();
                this.allocation_out = null;
            }
            Bitmap bitmap = this.bitmap_avg_align;
            if (bitmap != null) {
                bitmap.recycle();
                this.bitmap_avg_align = null;
            }
            Allocation allocation2 = this.allocation_avg_align;
            if (allocation2 != null) {
                allocation2.destroy();
                this.allocation_avg_align = null;
            }
        }
    }

    public AvgData processAvg(Bitmap bitmap, Bitmap bitmap2, float f, int i, float f2) throws HDRProcessorException {
        Log.d(TAG, "processAvg");
        Log.d(TAG, "avg_factor: " + f);
        if (bitmap.getWidth() == bitmap2.getWidth() && bitmap.getHeight() == bitmap2.getHeight()) {
            long currentTimeMillis = System.currentTimeMillis();
            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            initRenderscript();
            Log.d(TAG, "### time after creating renderscript: " + (System.currentTimeMillis() - currentTimeMillis));
            AvgData processAvgCore = processAvgCore((Allocation) null, (Allocation) null, bitmap, bitmap2, width, height, f, i, f2, (Allocation) null, (Bitmap) null, currentTimeMillis);
            Log.d(TAG, "### time for processAvg: " + (System.currentTimeMillis() - currentTimeMillis));
            return processAvgCore;
        }
        Log.e(TAG, "bitmaps not of same resolution");
        throw new HDRProcessorException(1);
    }

    public void updateAvg(AvgData avgData, int i, int i2, Bitmap bitmap, float f, int i3, float f2) throws HDRProcessorException {
        AvgData avgData2 = avgData;
        Log.d(TAG, "updateAvg");
        Log.d(TAG, "avg_factor: " + f);
        if (i == bitmap.getWidth() && i2 == bitmap.getHeight()) {
            long currentTimeMillis = System.currentTimeMillis();
            processAvgCore(avgData2.allocation_out, avgData2.allocation_out, (Bitmap) null, bitmap, i, i2, f, i3, f2, avgData2.allocation_avg_align, avgData2.bitmap_avg_align, currentTimeMillis);
            Log.d(TAG, "### time for updateAvg: " + (System.currentTimeMillis() - currentTimeMillis));
            return;
        }
        Log.e(TAG, "bitmaps not of same resolution");
        throw new HDRProcessorException(1);
    }

    /** Core algorithm for Noise Reduction algorithm.
     * @param allocation_out If non-null, this will be used for the output allocation, otherwise a
     *                       new one will be created.
     * @param allocation_avg If non-null, an allocation for the averaged image so far. If null, the
     *                       first bitmap should be supplied as bitmap_avg.
     * @param bitmap_avg     If non-null, the first bitmap (which will be recycled). If null, an
     *                       allocation_avg should be supplied.
     * @param bitmap_new     The new bitmap to combined. The bitmap will be recycled.
     * @param width          The width of the bitmaps.
     * @param height         The height of the bitmaps.
     * @param avg_factor     The averaging factor.
     * @param iso            The ISO used for the photos.
     * @param zoom_factor    The digital zoom factor used to take the photos.
     * @param allocation_avg_align If non-null, use this allocation for alignment for averaged image.
     * @param bitmap_avg_align Should be supplied if allocation_avg_align is non-null, and stores
     *                         the bitmap corresponding to the allocation_avg_align.
     * @param time_s         Time, for debugging.
     */
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private AvgData processAvgCore(Allocation allocation_out, Allocation allocation_avg, Bitmap bitmap_avg, Bitmap bitmap_new, int width, int height, float avg_factor, int iso, float zoom_factor, Allocation allocation_avg_align, Bitmap bitmap_avg_align, long time_s) {
        if( MyDebug.LOG ) {
            Log.d(TAG, "processAvgCore");
            Log.d(TAG, "iso: " + iso);
            Log.d(TAG, "zoom_factor: " + zoom_factor);
        }

        Allocation allocation_new = null;
        boolean free_allocation_avg = false;

        //Allocation allocation_diffs = null;

        offsets_x = new int[2];
        offsets_y = new int[2];
        boolean floating_point = bitmap_avg == null;
        {
            boolean floating_point_align = floating_point;
            // perform auto-alignment
            List<Bitmap> align_bitmaps = new ArrayList<>();
            Allocation[] allocations = new Allocation[2];
            Bitmap bitmap_new_align = null;
            Allocation allocation_new_align = null;
            int alignment_width = width;
            int alignment_height = height;
            int full_alignment_width = width;
            int full_alignment_height = height;

            //final boolean scale_align = false;
            final boolean scale_align = true;
            //final int scale_align_size = 2;
            //final int scale_align_size = 4;
            //final int scale_align_size = Math.max(4 / this.cached_avg_sample_size, 1);
            final int scale_align_size = (zoom_factor > 3.9f) ?
                    1 :
                    Math.max(4 / this.getAvgSampleSize(iso), 1);
            if( MyDebug.LOG )
                Log.d(TAG, "scale_align_size: " + scale_align_size);
            boolean crop_to_centre = true;
            if( scale_align ) {
                // use scaled down and/or cropped bitmaps for alignment
                if( MyDebug.LOG )
                    Log.d(TAG, "### time before creating allocations for autoalignment: " + (System.currentTimeMillis() - time_s));
                Matrix align_scale_matrix = new Matrix();
                align_scale_matrix.postScale(1.0f/scale_align_size, 1.0f/scale_align_size);
                full_alignment_width /= scale_align_size;
                full_alignment_height /= scale_align_size;

                final boolean full_align = false; // whether alignment images should be created as being cropped to the centre
                //final boolean full_align = true; // whether alignment images should be created as being cropped to the centre
                int align_width = width;
                int align_height = height;
                int align_x = 0;
                int align_y = 0;
                if( !full_align ) {
                    // need to use /2 rather than /4 to prevent misalignment in testAvg26
                    //align_width = width/4;
                    //align_height = height/4;
                    align_width = width/2;
                    align_height = height/2;
                    align_x = (width - align_width)/2;
                    align_y = (height - align_height)/2;
                    crop_to_centre = false; // no need to crop in autoAlignment, as we're cropping here
                }

                final boolean filter_align = false;
                //final boolean filter_align = true;
                if( allocation_avg_align == null ) {
                    bitmap_avg_align = Bitmap.createBitmap(bitmap_avg, align_x, align_y, align_width, align_height, align_scale_matrix, filter_align);
                    allocation_avg_align = Allocation.createFromBitmap(rs, bitmap_avg_align);
                    if( MyDebug.LOG )
                        Log.d(TAG, "### time after creating avg allocation for autoalignment: " + (System.currentTimeMillis() - time_s));
                }
                bitmap_new_align = Bitmap.createBitmap(bitmap_new, align_x, align_y, align_width, align_height, align_scale_matrix, filter_align);
                allocation_new_align = Allocation.createFromBitmap(rs, bitmap_new_align);

                alignment_width = bitmap_new_align.getWidth();
                alignment_height = bitmap_new_align.getHeight();

                align_bitmaps.add(bitmap_avg_align);
                align_bitmaps.add(bitmap_new_align);
                allocations[0] = allocation_avg_align;
                allocations[1] = allocation_new_align;
                floating_point_align = false;
                if( MyDebug.LOG )
                    Log.d(TAG, "### time after creating allocations for autoalignment: " + (System.currentTimeMillis() - time_s));
            }
            else {
                if( allocation_avg == null ) {
                    allocation_avg = Allocation.createFromBitmap(rs, bitmap_avg);
                    free_allocation_avg = true;
                }
                allocation_new = Allocation.createFromBitmap(rs, bitmap_new);
                if( MyDebug.LOG )
                    Log.d(TAG, "### time after creating allocations from bitmaps: " + (System.currentTimeMillis() - time_s));
                align_bitmaps.add(bitmap_avg);
                align_bitmaps.add(bitmap_new);
                allocations[0] = allocation_avg;
                allocations[1] = allocation_new;
            }

            // misalignment more likely in "dark" images with more images and/or longer exposures
            // using max_align_scale=2 needed to prevent misalignment in testAvg51; also helps testAvg14
            boolean wider = iso >= 1100;
            autoAlignment(offsets_x, offsets_y, allocations, alignment_width, alignment_height, align_bitmaps, 0, true, null, false, floating_point_align, 1, crop_to_centre, wider ? 2 : 1, full_alignment_width, full_alignment_height, time_s);

			/*
			// compute allocation_diffs
			// if enabling this, should also:
			// - set full_align above to true
			// - set filter_align above to true
			if( processAvgScript == null ) {
				processAvgScript = new ScriptC_process_avg(rs);
			}
			processAvgScript.set_bitmap_align_new(allocations[1]);
			processAvgScript.set_offset_x_new(offsets_x[1]);
			processAvgScript.set_offset_y_new(offsets_y[1]);
			allocation_diffs = Allocation.createTyped(rs, Type.createXY(rs, Element.F32(rs), alignment_width, alignment_height));
			processAvgScript.forEach_compute_diff(allocations[0], allocation_diffs);
			processAvgScript.set_scale_align_size(scale_align_size);
			processAvgScript.set_allocation_diffs(allocation_diffs);
			*/

            if( scale_align ) {
                for(int i=0;i<offsets_x.length;i++) {
                    offsets_x[i] *= scale_align_size;
                }
                for(int i=0;i<offsets_y.length;i++) {
                    offsets_y[i] *= scale_align_size;
                }
            }

            if( bitmap_new_align != null ) {
                bitmap_new_align.recycle();
                //noinspection UnusedAssignment
                bitmap_new_align = null;
            }
            if( allocation_new_align != null ) {
                allocation_new_align.destroy();
                //noinspection UnusedAssignment
                allocation_new_align = null;
            }

            if( MyDebug.LOG ) {
                Log.d(TAG, "### time after autoAlignment: " + (System.currentTimeMillis() - time_s));
            }
        }

        if( allocation_out == null ) {
            if( MyDebug.LOG )
                Log.d(TAG, "need to create allocation_out");
            allocation_out = Allocation.createTyped(rs, Type.createXY(rs, Element.F32_3(rs), width, height));
            if( MyDebug.LOG )
                Log.d(TAG, "### time after create allocation_out: " + (System.currentTimeMillis() - time_s));
        }
        if( allocation_avg == null ) {
            allocation_avg = Allocation.createFromBitmap(rs, bitmap_avg);
            free_allocation_avg = true;
            if( MyDebug.LOG )
                Log.d(TAG, "### time after creating allocation_avg from bitmap: " + (System.currentTimeMillis() - time_s));
        }

        // write new avg image

        // create RenderScript
        if( processAvgScript == null ) {
            processAvgScript = new ScriptC_process_avg(rs);
        }
        //ScriptC_process_avg processAvgScript = new ScriptC_process_avg(rs);

		/*final boolean separate_first_pass = false; // whether to convert the first two images in separate passes (reduces memory)
		if( first && separate_first_pass ) {
			if( MyDebug.LOG )
				Log.d(TAG, "### time before convert_to_f: " + (System.currentTimeMillis() - time_s));
			processAvgScript.forEach_convert_to_f(allocation_avg, allocation_out);
			if( MyDebug.LOG )
				Log.d(TAG, "### time after convert_to_f: " + (System.currentTimeMillis() - time_s));
			if( free_allocation_avg ) {
				allocation_avg.destroy();
				free_allocation_avg = false;
			}
			if( MyDebug.LOG )
				Log.d(TAG, "release bitmap_avg");
			bitmap_avg.recycle();
			bitmap_avg = null;
			allocation_avg = allocation_out;
			first = false;
		}*/

        if( allocation_new == null ) {
            allocation_new = Allocation.createFromBitmap(rs, bitmap_new);
            if( MyDebug.LOG )
                Log.d(TAG, "### time after creating allocation_new from bitmap: " + (System.currentTimeMillis() - time_s));
        }

        // set allocations
        //processAvgScript.set_bitmap_avg(allocation_avg);
        processAvgScript.set_bitmap_new(allocation_new);

        // set offsets
        processAvgScript.set_offset_x_new(offsets_x[1]);
        processAvgScript.set_offset_y_new(offsets_y[1]);

        // set globals

        processAvgScript.set_avg_factor(avg_factor);

        // if changing this, pay close attention to tests testAvg6, testAvg8, testAvg17, testAvg23
        float limited_iso = Math.min(iso, 400);
        float wiener_cutoff_factor = 1.0f;
        if( iso >= 700 ) {
            // helps reduce speckles in testAvg17, testAvg23, testAvg33, testAvg36, testAvg38
            // using this level for testAvg31 (ISO 609) would increase ghosting
            //limited_iso = 500;
            limited_iso = 800;
            if( iso >= 1100 ) {
                // helps further reduce speckles in testAvg17, testAvg38
                // but don't do for iso >= 700 as makes "vicks" text in testAvg23 slightly more blurred
                wiener_cutoff_factor = 8.0f;
            }
        }
        limited_iso = Math.max(limited_iso, 100);
        float wiener_C = 10.0f * limited_iso;
        //float wiener_C = 1000.0f;
        //float wiener_C = 4000.0f;

        // Tapering the wiener scale means that we do more averaging for earlier images in the stack, the
        // logic being we'll have more chance of ghosting or misalignment with later images.
        // This helps: testAvg31, testAvg33.
        // Also slightly helps testAvg17, testAvg23 (slightly less white speckle on tv), testAvg28
        // (one less white speckle on face).
        // Note that too much tapering risks increasing ghosting in testAvg26, testAvg39.
        float tapered_wiener_scale = 1.0f - (float) Math.pow(0.5, avg_factor);
        if( MyDebug.LOG ) {
            Log.d(TAG, "avg_factor: " + avg_factor);
            Log.d(TAG, "tapered_wiener_scale: " + tapered_wiener_scale);
        }
        wiener_C /= tapered_wiener_scale;

        float wiener_C_cutoff = wiener_cutoff_factor * wiener_C;
        if( MyDebug.LOG ) {
            Log.d(TAG, "wiener_C: " + wiener_C);
            Log.d(TAG, "wiener_cutoff_factor: " + wiener_cutoff_factor);
        }
        processAvgScript.set_wiener_C(wiener_C);
        processAvgScript.set_wiener_C_cutoff(wiener_C_cutoff);

		/*final float max_weight = 0.9375f;
		if( MyDebug.LOG ) {
			Log.d(TAG, "max_weight: " + max_weight);
		}
		processAvgScript.set_max_weight(max_weight);*/

        if( MyDebug.LOG )
            Log.d(TAG, "call processAvgScript");
        if( MyDebug.LOG )
            Log.d(TAG, "### time before processAvgScript: " + (System.currentTimeMillis() - time_s));
        if( floating_point )
            processAvgScript.forEach_avg_f(allocation_avg, allocation_out);
        else
            processAvgScript.forEach_avg(allocation_avg, allocation_out);
        if( MyDebug.LOG )
            Log.d(TAG, "### time after processAvgScript: " + (System.currentTimeMillis() - time_s));

		/*if( allocation_diffs != null ) {
			allocation_diffs.destroy();
			allocation_diffs = null;
		}*/
        allocation_new.destroy();
        if( free_allocation_avg ) {
            allocation_avg.destroy();
        }
        if( bitmap_avg != null ) {
            if( MyDebug.LOG )
                Log.d(TAG, "release bitmap_avg");
            bitmap_avg.recycle();
            //noinspection UnusedAssignment
            bitmap_avg = null;
        }
        if( bitmap_new != null ) {
            if( MyDebug.LOG )
                Log.d(TAG, "release bitmap_new");
            bitmap_new.recycle();
            //noinspection UnusedAssignment
            bitmap_new = null;
        }

        if( MyDebug.LOG )
            Log.d(TAG, "### time for processAvgCore: " + (System.currentTimeMillis() - time_s));
        return new AvgData(allocation_out, bitmap_avg_align, allocation_avg_align);
    }

    public void processAvgMulti(List<Bitmap> list, float f, int i, boolean z) throws HDRProcessorException {
        Allocation allocation;
        List<Bitmap> list2 = list;
        float f2 = f;
        Log.d(TAG, "processAvgMulti");
        Log.d(TAG, "hdr_alpha: " + f2);
        int size = list.size();
        if (size == 8) {
            int i2 = 1;
            while (i2 < size) {
                if (list2.get(i2).getWidth() == list2.get(0).getWidth() && list2.get(i2).getHeight() == list2.get(0).getHeight()) {
                    i2++;
                } else {
                    Log.e(TAG, "bitmaps not of same resolution");
                    for (int i3 = 0; i3 < size; i3++) {
                        Log.e(TAG, "bitmaps " + i3 + " : " + list2.get(i3).getWidth() + " x " + list2.get(i3).getHeight());
                    }
                    throw new HDRProcessorException(1);
                }
            }
            long currentTimeMillis = System.currentTimeMillis();
            int width = list2.get(0).getWidth();
            int height = list2.get(0).getHeight();
            initRenderscript();
            Log.d(TAG, "### time after creating renderscript: " + (System.currentTimeMillis() - currentTimeMillis));
            Allocation createFromBitmap = Allocation.createFromBitmap(this.rs, list2.get(0));
            Allocation createFromBitmap2 = Allocation.createFromBitmap(this.rs, list2.get(1));
            Allocation createFromBitmap3 = Allocation.createFromBitmap(this.rs, list2.get(2));
            Allocation createFromBitmap4 = Allocation.createFromBitmap(this.rs, list2.get(3));
            Allocation createFromBitmap5 = Allocation.createFromBitmap(this.rs, list2.get(4));
            Allocation createFromBitmap6 = Allocation.createFromBitmap(this.rs, list2.get(5));
            Allocation createFromBitmap7 = Allocation.createFromBitmap(this.rs, list2.get(6));
            int i4 = height;
            Allocation createFromBitmap8 = Allocation.createFromBitmap(this.rs, list2.get(7));
            StringBuilder sb = new StringBuilder();
            int i5 = width;
            sb.append("### time after creating allocations from bitmaps: ");
            sb.append(System.currentTimeMillis() - currentTimeMillis);
            Log.d(TAG, sb.toString());
            ScriptC_process_avg scriptC_process_avg = new ScriptC_process_avg(this.rs);
            scriptC_process_avg.set_bitmap1(createFromBitmap2);
            scriptC_process_avg.set_bitmap2(createFromBitmap3);
            scriptC_process_avg.set_bitmap3(createFromBitmap4);
            scriptC_process_avg.set_bitmap4(createFromBitmap5);
            scriptC_process_avg.set_bitmap5(createFromBitmap6);
            scriptC_process_avg.set_bitmap6(createFromBitmap7);
            scriptC_process_avg.set_bitmap7(createFromBitmap8);
            Log.d(TAG, "call processAvgScript");
            Log.d(TAG, "### time before processAvgScript: " + (System.currentTimeMillis() - currentTimeMillis));
            scriptC_process_avg.forEach_avg_multi(createFromBitmap, createFromBitmap);
            Log.d(TAG, "### time after processAvgScript: " + (System.currentTimeMillis() - currentTimeMillis));
            Log.d(TAG, "release bitmaps");
            for (int i6 = 1; i6 < list.size(); i6++) {
                list2.get(i6).recycle();
            }
            if (f2 != 0.0f) {
                allocation = createFromBitmap;
                adjustHistogram(createFromBitmap, createFromBitmap, i5, i4, f, i, z, currentTimeMillis);
                Log.d(TAG, "### time after adjustHistogram: " + (System.currentTimeMillis() - currentTimeMillis));
            } else {
                allocation = createFromBitmap;
            }
            allocation.copyTo(list2.get(0));
            Log.d(TAG, "### time for processAvgMulti: " + (System.currentTimeMillis() - currentTimeMillis));
            return;
        }
        Log.e(TAG, "n_bitmaps should be 8, not " + size);
        throw new HDRProcessorException(0);
    }

    /* access modifiers changed from: package-private */
    public void autoAlignment(int[] iArr, int[] iArr2, int i, int i2, List<Bitmap> list, int i3, boolean z, int i4) {
        Log.d(TAG, "autoAlignment");
        initRenderscript();
        int size = list.size();
        Allocation[] allocationArr = new Allocation[size];
        for (int i5 = 0; i5 < list.size(); i5++) {
            allocationArr[i5] = Allocation.createFromBitmap(this.rs, list.get(i5));
        }
        Allocation[] allocationArr2 = allocationArr;
        autoAlignment(iArr, iArr2, allocationArr, i, i2, list, i3, true, (SortCallback) null, z, false, 1, false, i4, i, i2, 0);
        for (int i6 = 0; i6 < size; i6++) {
            if (allocationArr2[i6] != null) {
                allocationArr2[i6].destroy();
                allocationArr2[i6] = null;
            }
        }
        freeScripts();
    }

    static class BrightnessDetails {
        final int median_brightness;

        BrightnessDetails(int i) {
            this.median_brightness = i;
        }
    }

    /**
     *
     * @param bitmaps       Only required if use_mtb is true, otherwise may be null.
     * @param base_bitmap   Index of bitmap in bitmaps that should be kept fixed; the other bitmaps
     *                      will be aligned relative to this.
     * @param assume_sorted If assume_sorted if false, and use_mtb is true, this function will also
     *                      sort the allocations and bitmaps from darkest to brightest.
     * @param use_mtb       Whether to align based on the median threshold bitmaps or not.
     * @param floating_point If true, the first allocation is in floating point (F32_3) format.
     * @param max_align_scale If larger than 1, start from a larger start area.
     */
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private BrightnessDetails autoAlignment(int [] offsets_x, int [] offsets_y, Allocation[] allocations, int width, int height, List<Bitmap> bitmaps, int base_bitmap, boolean assume_sorted, SortCallback sort_cb, boolean use_mtb, boolean floating_point, int min_step_size, boolean crop_to_centre, int max_align_scale, int full_width, int full_height, long time_s) {
        if( MyDebug.LOG ) {
            Log.d(TAG, "autoAlignment");
            Log.d(TAG, "width: " + width);
            Log.d(TAG, "height: " + height);
            Log.d(TAG, "use_mtb: " + use_mtb);
            Log.d(TAG, "max_align_scale: " + max_align_scale);
            Log.d(TAG, "allocations: " + allocations.length);
            for(Allocation allocation : allocations) {
                Log.d(TAG, "    allocation:");
                Log.d(TAG, "    element: " + allocation.getElement());
                Log.d(TAG, "    type X: " + allocation.getType().getX());
                Log.d(TAG, "    type Y: " + allocation.getType().getY());
            }
        }

        // initialise
        for(int i=0;i<offsets_x.length;i++) {
            offsets_x[i] = 0;
            offsets_y[i] = 0;
        }

        Allocation[] mtb_allocations = new Allocation[allocations.length];
        if( MyDebug.LOG )
            Log.d(TAG, "### time after creating mtb_allocations: " + (System.currentTimeMillis() - time_s));

        // Testing shows that in practice we get good results by only aligning the centre quarter of the images. This gives better
        // performance, and uses less memory.
        // If copy_to_centre is false, this has already been done by the caller.
        int mtb_width = width;
        int mtb_height = height;
        int mtb_x = 0;
        int mtb_y = 0;
        if( crop_to_centre ) {
            mtb_width = width/2;
            mtb_height = height/2;
            mtb_x = mtb_width/2;
            mtb_y = mtb_height/2;
        }
        if( MyDebug.LOG ) {
            Log.d(TAG, "mtb_x: " + mtb_x);
            Log.d(TAG, "mtb_y: " + mtb_y);
            Log.d(TAG, "mtb_width: " + mtb_width);
            Log.d(TAG, "mtb_height: " + mtb_height);
        }

        // create RenderScript
        if( createMTBScript == null ) {
            createMTBScript = new ScriptC_create_mtb(rs);
            if( MyDebug.LOG )
                Log.d(TAG, "### time after creating createMTBScript: " + (System.currentTimeMillis() - time_s));
        }
        //ScriptC_create_mtb createMTBScript = new ScriptC_create_mtb(rs);
        if( MyDebug.LOG )
            Log.d(TAG, "### time after creating createMTBScript: " + (System.currentTimeMillis() - time_s));

        LuminanceInfo [] luminanceInfos = null;
        if( use_mtb ) {
            luminanceInfos = new LuminanceInfo[allocations.length];
            for(int i = 0; i < allocations.length; i++) {
                luminanceInfos[i] = computeMedianLuminance(bitmaps.get(i), mtb_x, mtb_y, mtb_width, mtb_height);
                if( MyDebug.LOG )
                    Log.d(TAG, i + ": median_value: " + luminanceInfos[i].median_value);
            }
            if( MyDebug.LOG )
                Log.d(TAG, "time after computeMedianLuminance: " + (System.currentTimeMillis() - time_s));
        }

        if( !assume_sorted && use_mtb ) {
            if( MyDebug.LOG )
                Log.d(TAG, "sort bitmaps");
            class BitmapInfo {
                final LuminanceInfo luminanceInfo;
                final Bitmap bitmap;
                final Allocation allocation;
                final int index;

                BitmapInfo(LuminanceInfo luminanceInfo, Bitmap bitmap, Allocation allocation, int index) {
                    this.luminanceInfo = luminanceInfo;
                    this.bitmap = bitmap;
                    this.allocation = allocation;
                    this.index = index;
                }

            }

            List<BitmapInfo> bitmapInfos = new ArrayList<>(bitmaps.size());
            for(int i=0;i<bitmaps.size();i++) {
                BitmapInfo bitmapInfo = new BitmapInfo(luminanceInfos[i], bitmaps.get(i), allocations[i], i);
                bitmapInfos.add(bitmapInfo);
            }
            if( MyDebug.LOG ) {
                Log.d(TAG, "before sorting:");
                for(int i=0;i<allocations.length;i++) {
                    Log.d(TAG, "    " + i + ": " + luminanceInfos[i]);
                }
            }
            Collections.sort(bitmapInfos, (o1, o2) -> {
                // important to use the code in LuminanceInfo.compareTo(), as that's also tested via the unit test
                // sortLuminanceInfo()
                return o1.luminanceInfo.compareTo(o2.luminanceInfo);
            });
            bitmaps.clear();
            for(int i=0;i<bitmapInfos.size();i++) {
                bitmaps.add(bitmapInfos.get(i).bitmap);
                luminanceInfos[i] = bitmapInfos.get(i).luminanceInfo;
                allocations[i] = bitmapInfos.get(i).allocation;
            }
            if( MyDebug.LOG ) {
                Log.d(TAG, "after sorting:");
                for(int i=0;i<allocations.length;i++) {
                    Log.d(TAG, "    " + i + ": " + luminanceInfos[i]);
                }
            }
            if( sort_cb != null ) {
                List<Integer> sort_order = new ArrayList<>();
                for(int i=0;i<bitmapInfos.size();i++) {
                    sort_order.add( bitmapInfos.get(i).index);
                }
                if( MyDebug.LOG )
                    Log.d(TAG, "sort_order: " + sort_order);
                sort_cb.sortOrder(sort_order);
            }
        }
        /*{
            // test
            for(int i = 0; i < luminanceInfos.length-1; i++) {
                if( luminanceInfos[i].compareTo(luminanceInfos[i+1]) == 0 ) {
                    throw new RuntimeException("this: " + luminanceInfos[i] + " , that: " + luminanceInfos[i+1]);
                }
            }
        }*/

        int median_brightness = -1;
        if( use_mtb ) {
            median_brightness = luminanceInfos[base_bitmap].median_value;
            if( MyDebug.LOG )
                Log.d(TAG, "median_brightness: " + median_brightness);
        }

        for(int i=0;i<allocations.length;i++) {
            int median_value = -1;
            if( use_mtb ) {
                median_value = luminanceInfos[i].median_value;
                if( MyDebug.LOG )
                    Log.d(TAG, i + ": median_value: " + median_value);

				/*if( median_value < 16 ) {
					// needed for testHDR2, testHDR28
					if( MyDebug.LOG )
						Log.d(TAG, "image too dark to do alignment");
					mtb_allocations[i] = null;

					continue;
				}*/
            }

            if( use_mtb && luminanceInfos[i].noisy ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "unable to compute median luminance safely");
                mtb_allocations[i] = null;
                continue;
            }

            mtb_allocations[i] = Allocation.createTyped(rs, Type.createXY(rs, Element.U8(rs), mtb_width, mtb_height));

            // avoid too low/high median_values, otherwise we'll detect dark or light pixels as "noisy" - needed for testHDR61
            final int min_diff_c = 4; // should be same value as in create_mtb.rs/create_mtb()
            /*if( median_value < min_diff_c+1 || median_value > 255-(min_diff_c+1) ) {
                throw new RuntimeException("image " + i + " has median_value: " + median_value); // test
            }*/
            median_value = Math.max(median_value, min_diff_c+1);
            median_value = Math.min(median_value, 255-(min_diff_c+1));
            if( MyDebug.LOG )
                Log.d(TAG, i + ": median_value is now: " + median_value);

            // set parameters
            if( use_mtb )
                createMTBScript.set_median_value(median_value);
            createMTBScript.set_start_x(mtb_x);
            createMTBScript.set_start_y(mtb_y);
            createMTBScript.set_out_bitmap(mtb_allocations[i]);

            if( MyDebug.LOG )
                Log.d(TAG, "call createMTBScript");
            Script.LaunchOptions launch_options = new Script.LaunchOptions();
            //launch_options.setX((int)(width*0.25), (int)(width*0.75));
            //launch_options.setY((int)(height*0.25), (int)(height*0.75));
            //createMTBScript.forEach_create_mtb(allocations[i], mtb_allocations[i], launch_options);
            launch_options.setX(mtb_x, mtb_x+mtb_width);
            launch_options.setY(mtb_y, mtb_y+mtb_height);
            if( use_mtb )
                createMTBScript.forEach_create_mtb(allocations[i], launch_options);
            else {
                if( floating_point && i == 0 )
                    createMTBScript.forEach_create_greyscale_f(allocations[i], launch_options);
                else
                    createMTBScript.forEach_create_greyscale(allocations[i], launch_options);
            }
            if( MyDebug.LOG )
                Log.d(TAG, "time after createMTBScript: " + (System.currentTimeMillis() - time_s));

			/*if( MyDebug.LOG ) {
				// debugging
				byte [] mtb_bytes = new byte[mtb_width*mtb_height];
				mtb_allocations[i].copyTo(mtb_bytes);
				int [] pixels = new int[mtb_width*mtb_height];
				for(int j=0;j<mtb_width*mtb_height;j++) {
					int b = mtb_bytes[j];
					if( b < 0 )
						b += 255;
					pixels[j] = Color.argb(255, b, b, b);
				}
				Bitmap mtb_bitmap = Bitmap.createBitmap(pixels, mtb_width, mtb_height, Bitmap.Config.ARGB_8888);
				File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/mtb_bitmap" + i + ".jpg");
				try {
					OutputStream outputStream = new FileOutputStream(file);
					mtb_bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream);
					outputStream.close();
					MainActivity mActivity = (MainActivity) context;
					mActivity.getStorageUtils().broadcastFile(file, true, false, true);
				}
				catch(IOException e) {
					e.printStackTrace();
				}
				mtb_bitmap.recycle();
			}*/
        }
        if( MyDebug.LOG )
            Log.d(TAG, "### time after all createMTBScript: " + (System.currentTimeMillis() - time_s));

        // The initial step_size N should be a power of 2; the maximum offset we can achieve by the algorithm is N-1.
        // For pictures resolution 4160x3120, this gives max_ideal_size 27, and initial_step_size 32.
        // On tests testHDR1 to testHDR35, the max required offset was 24 pixels (for testHDR33) even when using
        // inital_step_size of 64.
        // Note, there isn't really a performance cost in allowing higher initial step sizes (as larger sizes have less
        // sampling - since we sample every step_size pixels - though there might be some overhead for every extra call
        // to renderscript that we do). But high step sizes have a risk of producing really bad results if we were
        // to misidentify cases as needing a large offset.
        int max_dim = Math.max(full_width, full_height); // n.b., use the full width and height here, not the mtb_width, height
        //int max_ideal_size = max_dim / (wider ? 75 : 150);
        int max_ideal_size = (max_align_scale * max_dim) / 150;
        int initial_step_size = 1;
        while( initial_step_size < max_ideal_size ) {
            initial_step_size *= 2;
        }
        //initial_step_size = 64;
        if( MyDebug.LOG ) {
            Log.d(TAG, "max_dim: " + max_dim);
            Log.d(TAG, "max_ideal_size: " + max_ideal_size);
            Log.d(TAG, "initial_step_size: " + initial_step_size);
        }

        if( mtb_allocations[base_bitmap] == null ) {
            if( MyDebug.LOG )
                Log.d(TAG, "base image not suitable for image alignment");
            for(int i=0;i<mtb_allocations.length;i++) {
                if( mtb_allocations[i] != null ) {
                    mtb_allocations[i].destroy();
                    mtb_allocations[i] = null;
                }
            }
            return new BrightnessDetails(median_brightness);
        }

        // create RenderScript
        if( alignMTBScript == null ) {
            alignMTBScript = new ScriptC_align_mtb(rs);
        }
        //ScriptC_align_mtb alignMTBScript = new ScriptC_align_mtb(rs);

        // set parameters
        alignMTBScript.set_bitmap0(mtb_allocations[base_bitmap]);
        // bitmap1 set below

        for(int i=0;i<allocations.length;i++)  {
            if( i == base_bitmap ) {
                // don't need to align the "base" reference image
                continue;
            }
            if( mtb_allocations[i] == null ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "image " + i + " not suitable for image alignment");
                continue;
            }

            alignMTBScript.set_bitmap1(mtb_allocations[i]);

            //final int pixel_step = use_mtb ? 1 : 4;
            final int pixel_step = 1;
            int step_size = initial_step_size;
            while( step_size > min_step_size ) {
                step_size /= 2;
                int pixel_step_size = step_size * pixel_step;
                if( pixel_step_size > mtb_width || pixel_step_size > mtb_height )
                    pixel_step_size = step_size;

                if( MyDebug.LOG ) {
                    Log.d(TAG, "call alignMTBScript for image: " + i);
                    Log.d(TAG, "    versus base image: " + base_bitmap);
                    Log.d(TAG, "step_size: " + step_size);
                    Log.d(TAG, "pixel_step_size: " + pixel_step_size);
                }

                final boolean use_pyramid = false;
                //final boolean use_pyramid = true;
				/*if( use_pyramid ) {
					// downscale by step_size
					Allocation [] scaled_allocations = new Allocation[2];
					for(int j=0;j<2;j++) {
						int scaled_width = mtb_width/step_size;
						int scaled_height = mtb_height/step_size;
						if( MyDebug.LOG ) {
							Log.d(TAG, "create scaled image: " + j);
							Log.d(TAG, "    scaled_width: " + scaled_width);
							Log.d(TAG, "    scaled_height: " + scaled_height);
						}
						Allocation allocation_to_scale = mtb_allocations[(j==0) ? base_bitmap : i];
						Type type = Type.createXY(rs, allocation_to_scale.getElement(), scaled_width, scaled_height);
						scaled_allocations[j] = Allocation.createTyped(rs, type);
						ScriptIntrinsicResize theIntrinsic = ScriptIntrinsicResize.create(rs);
						theIntrinsic.setInput(allocation_to_scale);
						theIntrinsic.forEach_bicubic(scaled_allocations[j]);
					}
					alignMTBScript.set_bitmap0(scaled_allocations[0]);
					alignMTBScript.set_bitmap1(scaled_allocations[1]);
					int off_x = offsets_x[i]/step_size;
					int off_y = offsets_y[i]/step_size;
					if( MyDebug.LOG ) {
						Log.d(TAG, "off_x: " + off_x);
						Log.d(TAG, "off_y: " + off_y);
					}
					alignMTBScript.set_off_x( off_x );
					alignMTBScript.set_off_y( off_y );
					alignMTBScript.set_step_size( 1 );
				}
				else*/ {
                    alignMTBScript.set_off_x( offsets_x[i] );
                    alignMTBScript.set_off_y( offsets_y[i] );
                    alignMTBScript.set_step_size( pixel_step_size );
                }

                Allocation errorsAllocation = Allocation.createSized(rs, Element.I32(rs), 9);
                alignMTBScript.bind_errors(errorsAllocation);
                alignMTBScript.invoke_init_errors();

                Script.LaunchOptions launch_options = new Script.LaunchOptions();
                if( !use_pyramid ) {
                    // see note inside align_mtb.rs/align_mtb() for why we sample over a subset of the image
                    int stop_x = mtb_width/pixel_step_size;
                    int stop_y = mtb_height/pixel_step_size;
                    if( MyDebug.LOG ) {
                        Log.d(TAG, "stop_x: " + stop_x);
                        Log.d(TAG, "stop_y: " + stop_y);
                    }
                    //launch_options.setX((int)(stop_x*0.25), (int)(stop_x*0.75));
                    //launch_options.setY((int)(stop_y*0.25), (int)(stop_y*0.75));
                    launch_options.setX(0, stop_x);
                    launch_options.setY(0, stop_y);
                }
                long this_time_s = System.currentTimeMillis();
                if( use_mtb )
                    alignMTBScript.forEach_align_mtb(mtb_allocations[base_bitmap], launch_options);
                else
                    alignMTBScript.forEach_align(mtb_allocations[base_bitmap], launch_options);
                if( MyDebug.LOG ) {
                    Log.d(TAG, "time for alignMTBScript: " + (System.currentTimeMillis() - this_time_s));
                    Log.d(TAG, "time after alignMTBScript: " + (System.currentTimeMillis() - time_s));
                }

                int best_error = -1;
                int best_id = -1;
                int [] errors = new int[9];
                errorsAllocation.copyTo(errors);
                errorsAllocation.destroy();
                for(int j=0;j<9;j++) {
                    int this_error = errors[j];
                    if( MyDebug.LOG )
                        Log.d(TAG, "    errors[" + j + "]: " + this_error);
                    if( best_id==-1 || this_error < best_error ) {
                        best_error = this_error;
                        best_id = j;
                    }
                }
                if( MyDebug.LOG )
                    Log.d(TAG, "    best_id " + best_id + " error: " + best_error);
                if( best_error >= 2000000000 ) {
                    Log.e(TAG, "    auto-alignment failed due to overflow");
                    // hitting overflow means behaviour will be unstable under SMP, and auto-alignment won't be reliable anyway
                    best_id = 4; // default to centre
                    if( is_test ) {
                        throw new RuntimeException();
                    }
                }
				/*if( best_id != 4 ) {
					int this_off_x = best_id % 3;
					int this_off_y = best_id/3;
					this_off_x--;
					this_off_y--;
					for(int j=0;j<9;j++) {
						int that_off_x = j % 3;
						int that_off_y = j/3;
						that_off_x--;
						that_off_y--;
						if( this_off_x * that_off_x == -1 || this_off_y * that_off_y == -1 ) {
							float diff = ((float)(best_error - errors[j]))/(float)errors[j];
							if( MyDebug.LOG )
								Log.d(TAG, "    opposite errors[" + j + "] diff: " + diff);
							if( Math.abs(diff) <= 0.02f ) {
								if( MyDebug.LOG )
									Log.d(TAG, "    reject auto-alignment");
								best_id = 4;
								break;
							}
						}
					}
				}*/
                if( best_id != -1 ) {
                    int this_off_x = best_id % 3;
                    int this_off_y = best_id/3;
                    this_off_x--;
                    this_off_y--;
                    if( MyDebug.LOG ) {
                        Log.d(TAG, "this_off_x: " + this_off_x);
                        Log.d(TAG, "this_off_y: " + this_off_y);
                    }
                    offsets_x[i] += this_off_x * step_size;
                    offsets_y[i] += this_off_y * step_size;
                    if( MyDebug.LOG ) {
                        Log.d(TAG, "offsets_x is now: " + offsets_x[i]);
                        Log.d(TAG, "offsets_y is now: " + offsets_y[i]);
                    }
					/*if( wider && step_size == initial_step_size/2 && (this_off_x != 0 || this_off_y != 0 ) ) {
						throw new RuntimeException(); // test
					}*/
                }
            }
            if( MyDebug.LOG ) {
                Log.d(TAG, "resultant offsets for image: " + i);
                Log.d(TAG, "resultant offsets_x: " + offsets_x[i]);
                Log.d(TAG, "resultant offsets_y: " + offsets_y[i]);
            }
        }

		/*for(int i=0;i<allocations.length;i++) {
			offsets_x[i] = 0;
			offsets_y[i] = 0;
		}*/
        for(int i=0;i<mtb_allocations.length;i++) {
            if( mtb_allocations[i] != null ) {
                mtb_allocations[i].destroy();
                mtb_allocations[i] = null;
            }
        }
        return new BrightnessDetails(median_brightness);
    }

    public static class LuminanceInfo implements Comparable<LuminanceInfo> {
        final int min_value;
        final int median_value;
        final int hi_value;
        final boolean noisy;

        public LuminanceInfo(int min_value, int median_value, int hi_value, boolean noisy) {
            this.min_value = min_value;
            this.median_value = median_value;
            this.hi_value = hi_value;
            this.noisy = noisy;
        }

        @Override
        @NonNull
        public String toString() {
            return "min: " + min_value + " , median: " + median_value + " , hi: " + hi_value + " , noisy: " + noisy;
        }

        @Override
        public int compareTo(LuminanceInfo o) {
            int value = this.median_value - o.median_value;
            if( value == 0 ) {
                // fall back to using min_value
                value = this.min_value - o.min_value;
            }
            if( value == 0 ) {
                // fall back to using hi_value
                value = this.hi_value - o.hi_value;
            }
            return value;
        }
    }

    private LuminanceInfo computeMedianLuminance(Bitmap bitmap, int mtb_x, int mtb_y, int mtb_width, int mtb_height) {
        if( MyDebug.LOG ) {
            Log.d(TAG, "computeMedianLuminance");
            Log.d(TAG, "mtb_x: " + mtb_x);
            Log.d(TAG, "mtb_y: " + mtb_y);
            Log.d(TAG, "mtb_width: " + mtb_width);
            Log.d(TAG, "mtb_height: " + mtb_height);
        }
        final int n_samples_c = 100;
        final int n_w_samples = (int) Math.sqrt(n_samples_c);
        final int n_h_samples = n_samples_c/n_w_samples;

        int [] histo = new int[256];
        for(int i=0;i<256;i++)
            histo[i] = 0;
        int total = 0;
        //double sum_log_luminance = 0.0;
        for(int y=0;y<n_h_samples;y++) {
            double alpha = ((double) y + 1.0) / ((double) n_h_samples + 1.0);
            //int y_coord = (int) (alpha * bitmap.getHeight());
            int y_coord = mtb_y + (int) (alpha * mtb_height);
            for(int x=0;x<n_w_samples;x++) {
                double beta = ((double) x + 1.0) / ((double) n_w_samples + 1.0);
                //int x_coord = (int) (beta * bitmap.getWidth());
                int x_coord = mtb_x + (int) (beta * mtb_width);
				/*if( MyDebug.LOG )
					Log.d(TAG, "sample value from " + x_coord + " , " + y_coord);*/
                int color = bitmap.getPixel(x_coord, y_coord);
                int r = (color & 0xFF0000) >> 16;
                int g = (color & 0xFF00) >> 8;
                int b = (color & 0xFF);
                int luminance = Math.max(r, g);
                luminance = Math.max(luminance, b);
                histo[luminance]++;
                //sum_log_luminance += Math.log(luminance+1.0); // add 1 so we don't take log of 0...;
                total++;
            }
        }
		/*float avg_luminance = (float)(Math.exp( sum_log_luminance / total ));
		if( MyDebug.LOG )
			Log.d(TAG, "avg_luminance: " + avg_luminance);*/
        int middle = total/2;
        int count = 0;
        boolean noisy = false;
        int min_value = -1, hi_value = -1;
        // first count backwards to get hi_value
        for(int i=255;i>=0;i--) {
            /*if( histo[i] > 0 ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "max luminance " + i);
                max_value = i;
                break;
            }*/
            count += histo[i];
            if( count >= total/10 ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "hi luminance " + i);
                hi_value = i;
                break;
            }
        }

        // then count forwards to get min and median values
        count = 0;
        for(int i=0;i<256;i++) {
            count += histo[i];
            if( min_value == -1 && histo[i] > 0 ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "min luminance " + i);
                min_value = i;
            }
            if( count >= middle ) {
                if( MyDebug.LOG )
                    Log.d(TAG, "median luminance " + i);
                final int noise_threshold = 4;
                int n_below = 0, n_above = 0;
                for(int j=0;j<=i-noise_threshold;j++) {
                    n_below += histo[j];
                }
                for(int j=0;j<=i+noise_threshold && j<256;j++) {
                    n_above += histo[j];
                }
                double frac_below = n_below / (double)total;
                if( MyDebug.LOG ) {
                    double frac_above = 1.0 - n_above / (double)total;
                    Log.d(TAG, "count: " + count);
                    Log.d(TAG, "n_below: " + n_below);
                    Log.d(TAG, "n_above: " + n_above);
                    Log.d(TAG, "frac_below: " + frac_below);
                    Log.d(TAG, "frac_above: " + frac_above);
                }
                if( frac_below < 0.2 ) {
                    // needed for testHDR2, testHDR28
                    // note that we don't exclude cases where frac_above is too small, as this could be an overexposed image - see testHDR31
                    if( MyDebug.LOG )
                        Log.d(TAG, "too dark/noisy");
                    noisy = true;
                }
                return new LuminanceInfo(min_value, i, hi_value, noisy);
            }
        }
        Log.e(TAG, "computeMedianLuminance failed");
        return new LuminanceInfo(min_value, 127, hi_value, true);
    }

    /* access modifiers changed from: package-private */
    public void adjustHistogram(Allocation allocation, Allocation allocation2, int i, int i2, float f, int i3, boolean z, long j) {
        int i4;
        ScriptC_histogram_compute scriptC_histogram_compute;
        Allocation allocation3 = allocation;
        int i5 = i;
        int i6 = i2;
        int i7 = i3;
        Log.d(TAG, "adjustHistogram");
        RenderScript renderScript = this.rs;
        Allocation createSized = Allocation.createSized(renderScript, Element.I32(renderScript), 256);
        Log.d(TAG, "create histogramScript");
        ScriptC_histogram_compute scriptC_histogram_compute2 = new ScriptC_histogram_compute(this.rs);
        Log.d(TAG, "bind histogram allocation");
        scriptC_histogram_compute2.bind_histogram(createSized);
        int i8 = i7 * i7 * 256;
        int[] iArr = new int[i8];
        int[] iArr2 = new int[256];
        int i9 = 0;
        while (i9 < i7) {
            double d = (double) i9;
            int i10 = i9;
            double d2 = (double) i7;
            int i11 = i8;
            double d3 = (double) i5;
            int[] iArr3 = iArr;
            int[] iArr4 = iArr2;
            int i12 = (int) ((d / d2) * d3);
            int i13 = (int) (((d + 1.0d) / d2) * d3);
            if (i13 != i12) {
                int i14 = 0;
                while (i14 < i7) {
                    double d4 = (double) i14;
                    double d5 = d2;
                    double d6 = (double) i6;
                    int i15 = (int) ((d4 / d2) * d6);
                    int i16 = (int) (((d4 + 1.0d) / d2) * d6);
                    if (i16 == i15) {
                        scriptC_histogram_compute = scriptC_histogram_compute2;
                        i4 = i13;
                    } else {
                        Script.LaunchOptions launchOptions = new Script.LaunchOptions();
                        launchOptions.setX(i12, i13);
                        launchOptions.setY(i15, i16);
                        scriptC_histogram_compute2.invoke_init_histogram();
                        scriptC_histogram_compute2.forEach_histogram_compute_by_value(allocation3, launchOptions);
                        int[] iArr5 = new int[256];
                        createSized.copyTo(iArr5);
                        int i17 = (i13 - i12) * (i16 - i15);
                        int i18 = (i17 * 5) / 256;
                        int i19 = i18;
                        int i20 = 0;
                        while (i19 - i20 > 1) {
                            int i21 = (i19 + i20) / 2;
                            ScriptC_histogram_compute scriptC_histogram_compute3 = scriptC_histogram_compute2;
                            int i22 = i13;
                            int i23 = 0;
                            int i24 = 0;
                            for (int i25 = 256; i24 < i25; i25 = 256) {
                                if (iArr5[i24] > i21) {
                                    i23 += iArr5[i24] - i18;
                                }
                                i24++;
                            }
                            if (i23 > (i18 - i21) * 256) {
                                i19 = i21;
                            } else {
                                i20 = i21;
                            }
                            scriptC_histogram_compute2 = scriptC_histogram_compute3;
                            i13 = i22;
                        }
                        scriptC_histogram_compute = scriptC_histogram_compute2;
                        i4 = i13;
                        int i26 = (i19 + i20) / 2;
                        int i27 = 0;
                        int i28 = 0;
                        for (int i29 = 256; i27 < i29; i29 = 256) {
                            if (iArr5[i27] > i26) {
                                i28 += iArr5[i27] - i26;
                                iArr5[i27] = i26;
                            }
                            i27++;
                        }
                        int i30 = i28 / 256;
                        for (int i31 = 0; i31 < 256; i31++) {
                            iArr5[i31] = iArr5[i31] + i30;
                        }
                        if (z) {
                            int i32 = 0;
                            for (int i33 = 256; i32 < i33; i33 = 256) {
                                Log.d(TAG, "pre-brighten histogram[" + i32 + "] = " + iArr5[i32]);
                                i32++;
                            }
                            iArr4[0] = iArr5[0];
                            for (int i34 = 1; i34 < 256; i34++) {
                                iArr4[i34] = iArr4[i34 - 1] + iArr5[i34];
                            }
                            int i35 = i17 / 256;
                            Log.d(TAG, "equal_limit: " + i35);
                            int i36 = 0;
                            while (i36 < 128) {
                                int i37 = i36 + 1;
                                if (iArr4[i36] < i35 * i37) {
                                    int i38 = (int) ((1.0f - (((float) i36) / 128.0f)) * ((float) i35));
                                    Log.d(TAG, "x: " + i36 + " ; limit: " + i38);
                                    if (iArr5[i36] < i38) {
                                        for (int i39 = i37; i39 < 256 && iArr5[i36] < i38; i39++) {
                                            if (iArr5[i39] > i35) {
                                                int min = Math.min(iArr5[i39] - i35, i38 - iArr5[i36]);
                                                iArr5[i36] = iArr5[i36] + min;
                                                iArr5[i39] = iArr5[i39] - min;
                                            }
                                        }
                                        Log.d(TAG, "    histogram pulled up to: " + iArr5[i36]);
                                    }
                                }
                                i36 = i37;
                            }
                        }
                        int i40 = ((i10 * i7) + i14) * 256;
                        iArr3[i40] = iArr5[0];
                        int i41 = 1;
                        for (int i42 = 256; i41 < i42; i42 = 256) {
                            int i43 = i40 + i41;
                            iArr3[i43] = iArr3[i43 - 1] + iArr5[i41];
                            i41++;
                        }
                        for (int i44 = 0; i44 < 256; i44++) {
                            Log.d(TAG, "histogram[" + i44 + "] = " + iArr5[i44] + " cumulative: " + iArr3[i40 + i44]);
                        }
                    }
                    i14++;
                    int i45 = i;
                    i6 = i2;
                    scriptC_histogram_compute2 = scriptC_histogram_compute;
                    i13 = i4;
                    d2 = d5;
                }
            }
            i9 = i10 + 1;
            i5 = i;
            i6 = i2;
            scriptC_histogram_compute2 = scriptC_histogram_compute2;
            i8 = i11;
            iArr = iArr3;
            iArr2 = iArr4;
        }
        int i46 = i8;
        Log.d(TAG, "time after creating histograms: " + (System.currentTimeMillis() - j));
        RenderScript renderScript2 = this.rs;
        Allocation createSized2 = Allocation.createSized(renderScript2, Element.I32(renderScript2), i8);
        createSized2.copyFrom(iArr);
        ScriptC_histogram_adjust scriptC_histogram_adjust = new ScriptC_histogram_adjust(this.rs);
        scriptC_histogram_adjust.set_c_histogram(createSized2);
        scriptC_histogram_adjust.set_hdr_alpha(f);
        scriptC_histogram_adjust.set_n_tiles(i7);
        scriptC_histogram_adjust.set_width(i);
        scriptC_histogram_adjust.set_height(i2);
        Log.d(TAG, "time before histogramAdjustScript: " + (System.currentTimeMillis() - j));
        scriptC_histogram_adjust.forEach_histogram_adjust(allocation3, allocation2);
        Log.d(TAG, "time after histogramAdjustScript: " + (System.currentTimeMillis() - j));
        createSized.destroy();
        createSized2.destroy();
    }

    private Allocation computeHistogramAllocation(Allocation allocation, boolean z, boolean z2, long j) {
        Log.d(TAG, "computeHistogramAllocation");
        RenderScript renderScript = this.rs;
        Allocation createSized = Allocation.createSized(renderScript, Element.I32(renderScript), 256);
        Log.d(TAG, "create histogramScript");
        ScriptC_histogram_compute scriptC_histogram_compute = new ScriptC_histogram_compute(this.rs);
        Log.d(TAG, "bind histogram allocation");
        scriptC_histogram_compute.bind_histogram(createSized);
        scriptC_histogram_compute.invoke_init_histogram();
        Log.d(TAG, "call histogramScript");
        Log.d(TAG, "time before histogramScript: " + (System.currentTimeMillis() - j));
        if (z) {
            if (z2) {
                scriptC_histogram_compute.forEach_histogram_compute_by_intensity_f(allocation);
            } else {
                scriptC_histogram_compute.forEach_histogram_compute_by_intensity(allocation);
            }
        } else if (z2) {
            scriptC_histogram_compute.forEach_histogram_compute_by_value_f(allocation);
        } else {
            scriptC_histogram_compute.forEach_histogram_compute_by_value(allocation);
        }
        Log.d(TAG, "time after histogramScript: " + (System.currentTimeMillis() - j));
        return createSized;
    }

    public int[] computeHistogram(Bitmap bitmap, boolean z) {
        Log.d(TAG, "computeHistogram");
        long currentTimeMillis = System.currentTimeMillis();
        initRenderscript();
        Allocation createFromBitmap = Allocation.createFromBitmap(this.rs, bitmap);
        Log.d(TAG, "time after createFromBitmap: " + (System.currentTimeMillis() - currentTimeMillis));
        int[] computeHistogram = computeHistogram(createFromBitmap, z, false);
        createFromBitmap.destroy();
        freeScripts();
        return computeHistogram;
    }

    private int[] computeHistogram(Allocation allocation, boolean z, boolean z2) {
        Log.d(TAG, "computeHistogram");
        int[] iArr = new int[256];
        Allocation computeHistogramAllocation = computeHistogramAllocation(allocation, z, z2, System.currentTimeMillis());
        computeHistogramAllocation.copyTo(iArr);
        computeHistogramAllocation.destroy();
        return iArr;
    }

    static class HistogramInfo {
        final int max_brightness;
        final int mean_brightness;
        final int median_brightness;
        final int total;

        HistogramInfo(int i, int i2, int i3, int i4) {
            this.total = i;
            this.mean_brightness = i2;
            this.median_brightness = i3;
            this.max_brightness = i4;
        }
    }

    /* access modifiers changed from: package-private */
    public HistogramInfo getHistogramInfo(int[] iArr) {
        int i = 0;
        for (int i2 : iArr) {
            i += i2;
        }
        int i3 = i / 2;
        double d = 0.0d;
        int i4 = 0;
        int i5 = 0;
        int i6 = -1;
        for (int i7 = 0; i7 < iArr.length; i7++) {
            i4 += iArr[i7];
            d += (double) (iArr[i7] * i7);
            if (i4 >= i3 && i6 == -1) {
                i6 = i7;
            }
            if (iArr[i7] > 0) {
                i5 = i7;
            }
        }
        return new HistogramInfo(i, (int) ((d / ((double) i4)) + 0.1d), i6, i5);
    }

    private static int getBrightnessTarget(int i, float f, int i2) {
        if (i <= 0) {
            i = 1;
        }
        Log.d(TAG, "brightness: " + i);
        Log.d(TAG, "max_gain_factor: " + f);
        Log.d(TAG, "ideal_brightness: " + i2);
        return Math.max(i, Math.min(i2, (int) (f * ((float) i))));
    }

    public static class BrightenFactors {
        public final float gain;
        public final float gamma;
        public final float low_x;
        public final float mid_x;

        BrightenFactors(float f, float f2, float f3, float f4) {
            this.gain = f;
            this.low_x = f2;
            this.mid_x = f3;
            this.gamma = f4;
        }
    }

    public static BrightenFactors computeBrightenFactors(boolean z, int i, long j, int i2, int i3) {
        int brightnessTarget = getBrightnessTarget(i2, 1.5f, (!z || i >= 1100 || j >= 16949152) ? 119 : 199);
        Log.d(TAG, "brightness target: " + brightnessTarget);
        return computeBrightenFactors(z, i, j, i2, i3, brightnessTarget, true);
    }

    private static BrightenFactors computeBrightenFactors(boolean z, int i, long j, int i2, int i3, int i4, boolean z2) {
        if (i2 <= 0) {
            i2 = 1;
        }
        float f = ((float) i4) / ((float) i2);
        Log.d(TAG, "gain " + f);
        float f2 = 1.0f;
        if (f < 1.0f && z2) {
            Log.d(TAG, "clamped gain to: " + 1.0f);
            f = 1.0f;
        }
        float f3 = (float) i3;
        float f4 = f * f3;
        Log.d(TAG, "max_possible_value: " + f4);
        float f5 = 255.5f;
        if (f4 > 255.0f) {
            Log.d(TAG, "use piecewise gain/gamma");
            float f6 = (!z || i >= 1100 || j >= 16949152) ? 204.0f : 153.0f;
            f5 = f6 / f;
            f2 = (float) (Math.log((double) (f6 / 255.0f)) / Math.log((double) (f5 / f3)));
        } else if (z2 && f4 < 255.0f && i3 > 0) {
            float min = Math.min(255.0f / f3, 4.0f);
            Log.d(TAG, "alt_gain: " + min);
            if (min > f) {
                Log.d(TAG, "increased gain to: " + min);
                f = min;
            }
        }
        float f7 = 0.0f;
        if (z && i >= 400) {
            f7 = Math.min(8.0f, (127.5f / f) * 0.125f);
        }
        Log.d(TAG, "low_x " + f7);
        Log.d(TAG, "mid_x " + f5);
        Log.d(TAG, "gamma " + f2);
        return new BrightenFactors(f, f7, f5, f2);
    }

    public Bitmap avgBrighten(Allocation allocation, int i, int i2, int i3, long j) {
        Allocation allocation2 = allocation;
        int i4 = i3;
        Log.d(TAG, "avgBrighten");
        Log.d(TAG, "iso: " + i4);
        Log.d(TAG, "exposure_time: " + j);
        initRenderscript();
        long currentTimeMillis = System.currentTimeMillis();
        int[] computeHistogram = computeHistogram(allocation2, false, true);
        HistogramInfo histogramInfo = getHistogramInfo(computeHistogram);
        int i5 = histogramInfo.median_brightness;
        int i6 = histogramInfo.max_brightness;
        StringBuilder sb = new StringBuilder();
        sb.append("### time after computeHistogram: ");
        int[] iArr = computeHistogram;
        sb.append(System.currentTimeMillis() - currentTimeMillis);
        Log.d(TAG, sb.toString());
        Log.d(TAG, "median brightness: " + histogramInfo.median_brightness);
        Log.d(TAG, "mean brightness: " + histogramInfo.mean_brightness);
        Log.d(TAG, "max brightness: " + i6);
        int i7 = i6;
        HistogramInfo histogramInfo2 = histogramInfo;
        BrightenFactors computeBrightenFactors = computeBrightenFactors(true, i3, j, i5, i7);
        float f = computeBrightenFactors.gain;
        float f2 = computeBrightenFactors.low_x;
        float f3 = computeBrightenFactors.mid_x;
        float f4 = computeBrightenFactors.gamma;
        ScriptC_avg_brighten scriptC_avg_brighten = new ScriptC_avg_brighten(this.rs);
        scriptC_avg_brighten.set_bitmap(allocation2);
        int i8 = (int) (((float) histogramInfo2.total) * 0.001f);
        HistogramInfo histogramInfo3 = histogramInfo2;
        int[] iArr2 = iArr;
        int i9 = -1;
        int i10 = 0;
        for (int i11 = 0; i11 < iArr2.length; i11++) {
            int i12 = i10 + iArr2[i11];
            i10 = i12;
            if (i12 >= i8) {
                if (i9 == -1) {
                    i9 = i11;
                }
            }
        }
        float min = Math.min(Math.max(0.0f, (float) i9), i4 <= 700 ? 18.0f : 4.0f);
        Log.d(TAG, "percentile: " + i8);
        Log.d(TAG, "darkest_brightness: " + i9);
        Log.d(TAG, "black_level is now: " + min);
        scriptC_avg_brighten.invoke_setBlackLevel(min);
        float f5 = this.cached_avg_sample_size >= 2 ? 0.5f : 1.0f;
        Log.d(TAG, "median_filter_strength: " + f5);
        scriptC_avg_brighten.set_median_filter_strength(f5);
        scriptC_avg_brighten.invoke_setBrightenParameters(f, f4, f2, f3, (float) i7);
        Bitmap createBitmap = Bitmap.createBitmap(i, i2, Bitmap.Config.ARGB_8888);
        Allocation createFromBitmap = Allocation.createFromBitmap(this.rs, createBitmap);
        Log.d(TAG, "### time after creating allocation_out: " + (System.currentTimeMillis() - currentTimeMillis));
        scriptC_avg_brighten.forEach_avg_brighten_f(allocation, createFromBitmap);
        Log.d(TAG, "### time after avg_brighten: " + (System.currentTimeMillis() - currentTimeMillis));
        if (i4 < 1100 && j < 16949152) {
            float min2 = Math.min(Math.max(((float) (histogramInfo3.median_brightness - 60)) / -25.0f, 0.0f), 1.0f);
            float f6 = ((1.0f - min2) * 0.25f) + (0.5f * min2);
            Log.d(TAG, "dro alpha: " + min2);
            Log.d(TAG, "dro amount: " + f6);
            adjustHistogram(createFromBitmap, createFromBitmap, i, i2, f6, 1, true, currentTimeMillis);
            Log.d(TAG, "### time after adjustHistogram: " + (System.currentTimeMillis() - currentTimeMillis));
        }
        createFromBitmap.copyTo(createBitmap);
        createFromBitmap.destroy();
        Log.d(TAG, "### time after copying to bitmap: " + (System.currentTimeMillis() - currentTimeMillis));
        freeScripts();
        Log.d(TAG, "### total time for avgBrighten: " + (System.currentTimeMillis() - currentTimeMillis));
        return createBitmap;
    }

    private float computeSharpness(Allocation allocation, int i, long j) {
        Log.d(TAG, "computeSharpness");
        Log.d(TAG, "### time: " + (System.currentTimeMillis() - j));
        RenderScript renderScript = this.rs;
        Allocation createSized = Allocation.createSized(renderScript, Element.I32(renderScript), i);
        Log.d(TAG, "### time after createSized: " + (System.currentTimeMillis() - j));
        ScriptC_calculate_sharpness scriptC_calculate_sharpness = new ScriptC_calculate_sharpness(this.rs);
        Log.d(TAG, "### time after create sharpnessScript: " + (System.currentTimeMillis() - j));
        Log.d(TAG, "bind sums allocation");
        scriptC_calculate_sharpness.bind_sums(createSized);
        scriptC_calculate_sharpness.set_bitmap(allocation);
        scriptC_calculate_sharpness.set_width(i);
        scriptC_calculate_sharpness.invoke_init_sums();
        Log.d(TAG, "call sharpnessScript");
        Log.d(TAG, "### time before sharpnessScript: " + (System.currentTimeMillis() - j));
        scriptC_calculate_sharpness.forEach_calculate_sharpness(allocation);
        Log.d(TAG, "### time after sharpnessScript: " + (System.currentTimeMillis() - j));
        int[] iArr = new int[i];
        createSized.copyTo(iArr);
        createSized.destroy();
        float f = 0.0f;
        for (int i2 = 0; i2 < i; i2++) {
            f += (float) iArr[i2];
        }
        Log.d(TAG, "total_sum: " + f);
        return f;
    }
}
