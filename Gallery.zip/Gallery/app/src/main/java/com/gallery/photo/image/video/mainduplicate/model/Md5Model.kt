package com.gallery.photo.image.video.mainduplicate.model

class Md5Model {
    var extension: String? = null
    var filePath: String? = null
    var md5Value: String? = null
}