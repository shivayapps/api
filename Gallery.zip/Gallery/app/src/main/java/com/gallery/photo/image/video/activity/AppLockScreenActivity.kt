package com.gallery.photo.image.video.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.Window
import android.view.WindowManager
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.lock.activity.CustomPinActivity
import com.gallery.photo.image.video.lock.managers.AppLock
import com.gallery.photo.image.video.utilities.LOCK_PATTERN
import java.util.ArrayList

class AppLockScreenActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)

        Log.e("LOCK", "onCreate: AppLockScreenActivity")

        if (config.oldLockTypeWhenFingerPrintEnable.isNotEmpty()) {
            config.isFingerprintEnable = true
        }
        if (config.oldLockTypePattern == LOCK_PATTERN || config.oldLockTypeWhenFingerPrintEnable == LOCK_PATTERN) {

//            val intent = Intent(this, PatternLockActivity::class.java)
//            intent.putExtra(PatternLockUtils.INTENT_TYPE, PatternLockUtils.UNLOCK_PATTERN)
//            intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
//            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
//            startActivityForResult(intent, REQUEST_CODE_CHECK)
        } else {
            val intent = Intent(this@AppLockScreenActivity, CustomPinActivity::class.java)
            intent.putExtra(AppLock.EXTRA_TYPE, AppLock.UNLOCK_PIN)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            launchActivityForResult(intent, REQUEST_CODE_CHECK)

        }

    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {

    }

    override fun initActions() {

    }

    override fun getAppIconIDs(): ArrayList<Int> {
        return ArrayList<Int>()
    }

    override fun getAppLauncherName(): String {
        return "Gallery"
    }

    override fun onResume() {
        super.onResume()
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_CODE_CHECK -> {
                Log.e("LOCK", "onActivityResult: successfully unlock")
                setResult(RESULT_OK)
                finish()

            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        return if (isPlaySound) {
            if (keyCode == KeyEvent.KEYCODE_HOME) {
                Log.e("TAG", "onKeyDown: KEYCODE_HOME >> ")
            }
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                Log.e("TAG", "onKeyDown: KEYCODE_BACK >> ")
            }
            if (keyCode == KeyEvent.KEYCODE_POWER) {
                Log.e("TAG", "onKeyDown: KEYCODE_POWER >> ")
            }
            false
        } else true
    }

    companion object {
        private const val REQUEST_CODE_CHECK = 11
        var isPlaySound = false
    }
}
