package com.gallery.photo.image.video.Camera.utils

import android.app.Activity
import android.media.MediaScannerConnection
import android.provider.BaseColumns
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.utilities.Itemimage
import com.gallery.photo.image.video.utilities.cameraPicPathNew
import java.io.File



fun isViewContains(view: View, rx: Int, ry: Int): Boolean {
    val l = IntArray(2)
    view.getLocationOnScreen(l)
    val x = l[0]
    val y = l[1]
    val w = view.width
    val h = view.height
    return !(rx < x || rx > x + w || ry < y || ry > y + h)
}


fun Activity.openPhotoPreviewActivity() {
//
//    val file = File(Share.cameraPicPathNew)
//    MediaScannerConnection.scanFile(
//        this, arrayOf(file.toString()),
//        null, null
//    )
//
//    val projection = arrayOf(
//        BaseColumns._ID,
//        MediaStore.MediaColumns.MIME_TYPE,
//        MediaStore.MediaColumns.SIZE,
//        MediaStore.MediaColumns.DISPLAY_NAME,
//        MediaStore.MediaColumns.DATA
//    )
//    val where =
//        MediaStore.Images.Media.DATA + " LIKE ? AND " + MediaStore.Images.Media.DATA + " NOT LIKE ? "
//    val whereArgs = arrayOf("%${Share.cameraPicPathNew}%", "%${Share.cameraPicPathNew}%/%")
//
//    val cursor = contentResolver.query(
//        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
//        projection, where, whereArgs, MediaStore.MediaColumns.DATE_ADDED + " DESC"
//    )
//
//    Log.e("TAG", "onCreate: " + cursor!!.count)
//
//    if (cursor!!.moveToNext()) {
//
//        val item = Itemimage.valueOf(cursor)
//        val file = FileUtils.getFile(this, item.uri)!!
//
//        if (file.exists()) {
//            startActivity(intentFor<PhotoPreviewActivity>(AppConstant.EXTRA_IMAGE_PREVIEW to true))
//            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//            cursor.close()
//        } else {
//            toast("No image found")
//            cursor.close()
//        }
//
//    } else {
//        toast("No image found")
//        cursor.close()
//    }

}

fun Activity.scanMedia() {
    val file = File(cameraPicPathNew)
    MediaScannerConnection.scanFile(
        this, arrayOf(file.toString()),
        null, null
    )
}

fun Activity.lastImage(ivGalleryCamera: ImageView) {


    val file = File(cameraPicPathNew)
    MediaScannerConnection.scanFile(
        this, arrayOf(file.toString()),
        null, null
    )


    val projection = arrayOf(
        BaseColumns._ID, MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.SIZE,
        MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.DATA
    )
    val where =
        MediaStore.Images.Media.DATA + " LIKE ? AND " + MediaStore.Images.Media.DATA + " NOT LIKE ? "
    val whereArgs = arrayOf("%${cameraPicPathNew}%", "%${cameraPicPathNew}%/%")

    val cursor = contentResolver.query(
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
        projection, where, whereArgs, MediaStore.MediaColumns.DATE_ADDED + " DESC"
    )

    Log.e("TAG", "onCreate: " + cursor!!.count)

    if (cursor != null && cursor!!.moveToFirst()) {
        Log.e("TAG", "onResume: " + cursor!!.moveToFirst())
        val item = Itemimage.valueOf(cursor)
        Log.e("TAG", "onResume: " + item.Data)
        Log.e("TAG", "onResume: " + item.uri)
        val file = FileUtils.getFile(this, item.uri)!!
        if (file.exists()) {
            Log.e("TAG", "onResume: File exist")
            Glide.with(this)
                .load(file)
                .centerCrop()
                .into(ivGalleryCamera)
        } else {
            Log.e("TAG", "onResume: File not exist")
            Glide.with(this)
                .load(R.mipmap.ic_launcher)
                .centerCrop()
                .into(ivGalleryCamera)
        }
        cursor!!.close()
    } else {
        Glide.with(this)
            .load(R.mipmap.ic_launcher)
            .centerCrop()
            .into(ivGalleryCamera)
        cursor.close()
    }
}