package com.gallery.photo.image.video.interfaces;

public interface OnHomePressedListener {
    public void onHomePressed();

    public void onHomeLongPressed();
}