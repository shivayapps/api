package com.gallery.photo.image.video.event

import java.util.ArrayList

data class CopyMoveEvent(
    var copyMoveList: ArrayList<String>,
    var albumName: String,
    var albumPath: String,
    var deleteList: ArrayList<String>,
    var  isOpenFromFavorite: Boolean = false
)
