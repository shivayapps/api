package com.gallery.photo.image.video.activity

import android.app.Activity
import com.gallery.photo.image.video.activityBinding.BaseBindingActivity
import com.gallery.photo.image.video.databinding.ActivitySubscriptionThankYouBinding
import com.gallery.photo.image.video.extensions.inflater

class SubscriptionThankYouActivity : BaseBindingActivity<ActivitySubscriptionThankYouBinding>() {

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        mBinding.btnSubTnx.setOnClickListener {
            setResult(RESULT_OK)
            finish()
        }
    }

    override fun initActions() {

    }

    override fun setBinding(): ActivitySubscriptionThankYouBinding {
        return ActivitySubscriptionThankYouBinding.inflate(inflater)
    }
}