package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.app.ads.helper.RewardVideoHelper
import com.example.app.ads.helper.RewardVideoHelper.isShowRewardVideoAd
import com.example.app.ads.helper.RewardVideoHelper.showRewardVideoAd
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.utilities.HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION_VAL
import com.gallery.photo.image.video.utilities.HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION_VAL
import com.gallery.photo.image.video.utilities.isLoadRewardAds
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.extensions.beGone
import com.gallery.photo.image.video.extensions.beGoneIf
import com.gallery.photo.image.video.extensions.beVisible


class SubscriptionDialog(
    val activity: BaseSimpleActivity, val totalImagesCount: Int = 0, val totalVideoCount: Int = 0, val isFromFakeVaultChangePin: Boolean = false, val callback: (isSubscriptionClicked: Boolean) -> Unit
) {

    private var config = activity.config
    private var view: View
    private var onUserEarnedReward: (isUserEarnedReward: Boolean) -> Unit = {}
    private var onSubscriptionClick: () -> Unit = {}
    val dialog = Dialog(activity)

    init {
        view = activity.layoutInflater.inflate(R.layout.dialog_subscription, null)


        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        var folderDescription = dialog.findViewById<TextView>(R.id.folder_description)
        folderDescription.beGoneIf(isFromFakeVaultChangePin)

        if (totalImagesCount >= HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION_VAL &&
            totalVideoCount >= HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION_VAL
        ) {
            folderDescription.text = activity.getString(R.string.msg_subscription_image_video)
        } else if (totalImagesCount >= HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION_VAL) {
            folderDescription.text = activity.getString(R.string.msg_subscription_image)
        } else if (totalVideoCount >= HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION_VAL) {
            folderDescription.text = activity.getString(R.string.msg_subscription_video)
        }
        val llDone = dialog.findViewById(R.id.clSubscription) as ConstraintLayout
        val progressBar = dialog.findViewById(R.id.progressBar) as ProgressBar
        val llWatchVideo = dialog.findViewById(R.id.clWatchVideo) as ConstraintLayout
        if (!activity.isOnline()) {
            llWatchVideo.alpha = 0.5f
            llWatchVideo.isEnabled = false
        } else if (activity.isOnline() && !isLoadRewardAds) {
            llWatchVideo.alpha = 0.5f
            llWatchVideo.isEnabled = false
        }

        RewardVideoHelper.loadRewardVideoAd(fContext = activity)
        activity.isShowRewardVideoAd(
            onStartToLoadRewardVideoAd = {
                llWatchVideo.alpha = 0.5f
                llWatchVideo.isEnabled = false
                progressBar.beVisible()
            },
            onUserEarnedReward = { isUserEarnedReward ->
                if (isUserEarnedReward) {
                    dialog.dismiss()
                    callback(false)
                } else {
                    llWatchVideo.alpha = 0.5f
                    llWatchVideo.isEnabled = false
                }
            },
            onAdLoaded = {
                Log.d("Admob_", " on Ad Loaded: ")
                isLoadRewardAds = true
//               Handler(Looper.getMainLooper()).postDelayed({
                llWatchVideo.alpha = 1f
                llWatchVideo.isEnabled = true
                progressBar.beGone()
//               },100)

            }
        )
        val ivClose = dialog.findViewById(R.id.ivClose) as ImageView
        ivClose.setOnClickListener {
            dialog.dismiss()
        }


        llDone.setOnClickListener {
            dialog.dismiss()
//            onSubscriptionClick.invoke()
            callback(true)
        }
        llWatchVideo.setOnClickListener {
            activity.showRewardVideoAd()
        }
        dialog.show()
    }

    fun showRewardVideoDialog(afterEarnedReward: () -> Unit, onSubscriptionClick: () -> Unit) {
        if (!activity.isFinishing && !dialog.isShowing) {
            this.onUserEarnedReward = { isUserEarnedReward ->
//                Log.e(TAG, "showRewardVideoDialog: isUserEarnedReward::$isUserEarnedReward")
                if (isUserEarnedReward) {
                    afterEarnedReward.invoke()
                    dialog.dismiss()
                }
            }

            this.onSubscriptionClick = onSubscriptionClick

            dialog.show()
        }
    }

}
