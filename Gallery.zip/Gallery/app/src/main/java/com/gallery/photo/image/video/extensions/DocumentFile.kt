package com.gallery.photo.image.video.extensions

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import java.io.File


/**
 * For files under [Environment.getExternalStorageDirectory]
 */
const val PRIMARY = "primary"

/**
 * For files under [Context.getFilesDir] or [Context.getDataDir].
 * It is not really a storage ID, and can't be used in file tree URI.
 */
const val DATA = "data"

const val DOWNLOADS_FOLDER_AUTHORITY = "com.android.providers.downloads.documents"

const val MEDIA_FOLDER_AUTHORITY = "com.android.providers.media.documents"

const val EXTERNAL_STORAGE_AUTHORITY = "com.android.externalstorage.documents"

const val DOWNLOADS_TREE_URI = "content://$DOWNLOADS_FOLDER_AUTHORITY/tree/downloads"

val externalStoragePath = Environment.getExternalStorageDirectory().absolutePath

fun DocumentFile.getStorageId(context: Context) = uri.getStorageId(context)
val DocumentFile.isRawFile: Boolean
    get() = uri.isRawFile

val DocumentFile.isExternalStorageDocument: Boolean
    get() = uri.isExternalStorageDocument

val DocumentFile.isDownloadsDocument: Boolean
    get() = uri.isDownloadsDocument

val DocumentFile.isMediaDocument: Boolean
    get() = uri.isMediaDocument


fun DocumentFile.getAbsolutePath(context: Context): String {
    val path = uri.path.orEmpty()
    val storageID = getStorageId(context)
    return when {
        isRawFile -> path

        isExternalStorageDocument && path.contains("/document/$storageID:") -> {
            val basePath = path.substringAfterLast("/document/$storageID:", "").trimFileSeparator()
            if (storageID == PRIMARY) {
                "${Environment.getExternalStorageDirectory().absolutePath}/$basePath".trimEnd('/')
            } else {
                "/storage/$storageID/$basePath".trimEnd('/')
            }
        }

        uri.toString()
            .let { it == DOWNLOADS_TREE_URI || it == "${DOWNLOADS_TREE_URI}/document/downloads" } ->
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath

        isDownloadsDocument -> {
            when {
                // API 26 - 27 => content://com.android.providers.downloads.documents/document/22
                Build.VERSION.SDK_INT < Build.VERSION_CODES.P && path.matches(Regex("/document/\\d+")) -> {
                    val fileName =  context.getColumnInfoString(uri, MediaStore.MediaColumns.DISPLAY_NAME)
                        ?: return ""
                    File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                        fileName
                    ).absolutePath
                }

                Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && path.matches(Regex("(.*?)/ms[f,d]:\\d+(.*?)")) -> {
                    if (isTreeDocumentFile) {
                        val parentTree = mutableListOf(name.orEmpty())
                        var parent = this
                        while (parent.parentFile?.also { parent = it } != null) {
                            parentTree.add(parent.name.orEmpty())
                        }
                        "${externalStoragePath}/${parentTree.reversed().joinToString("/")}".trimEnd(
                            '/'
                        )
                    } else {
                        // we can't use msf/msd ID as MediaFile ID to fetch relative path, so just return empty String
                        ""
                    }
                }

                else -> path.substringAfterLast("/document/raw:", "").trimEnd('/')
            }
        }

        !isTreeDocumentFile -> ""
        inPrimaryStorage(context) -> "${externalStoragePath}/${getBasePath(context)}".trimEnd('/')
        else -> "/storage/$storageID/${getBasePath(context)}".trimEnd('/')
    }
}

@Suppress("DEPRECATION")
fun DocumentFile.getBasePath(context: Context): String {
    val path = uri.path.orEmpty()
    val storageID = getStorageId(context)
    return when {
        isRawFile -> File(path).getBasePath(context)

        isExternalStorageDocument && path.contains("/document/$storageID:") -> {
            path.substringAfterLast("/document/$storageID:", "").trimFileSeparator()
        }

        isDownloadsDocument -> {
            // content://com.android.providers.downloads.documents/tree/raw:/storage/emulated/0/Download/Denai/document/raw:/storage/emulated/0/Download/Denai
            // content://com.android.providers.downloads.documents/tree/downloads/document/raw:/storage/emulated/0/Download/Denai
            when {
                // API 26 - 27 => content://com.android.providers.downloads.documents/document/22
                Build.VERSION.SDK_INT < Build.VERSION_CODES.P && path.matches(Regex("/document/\\d+")) -> {
                    val fileName =
                        context.getColumnInfoString(uri, MediaStore.MediaColumns.DISPLAY_NAME)
                            ?: return ""
                    "${Environment.DIRECTORY_DOWNLOADS}/$fileName"
                }

                Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && path.matches(Regex("(.*?)/ms[f,d]:\\d+(.*?)")) -> {
                    if (isTreeDocumentFile) {
                        val parentTree = mutableListOf(name.orEmpty())
                        var parent = this
                        while (parent.parentFile?.also { parent = it } != null) {
                            parentTree.add(parent.name.orEmpty())
                        }
                        parentTree.reversed().joinToString("/")
                    } else {
                        // we can't use msf/msd ID as MediaFile ID to fetch relative path, so just return empty String
                        ""
                    }
                }

                else -> path.substringAfterLast(externalStoragePath, "").trimFileSeparator()
            }
        }
        else -> ""
    }
}


val DocumentFile.isTreeDocumentFile: Boolean
    get() = uri.isTreeDocumentFile

fun DocumentFile.inPrimaryStorage(context: Context) =
    isTreeDocumentFile && getStorageId(context) == PRIMARY
            || isRawFile && uri.path.orEmpty().startsWith(externalStoragePath)


fun File.getBasePath(context: Context): String {
    val externalStoragePath = externalStoragePath
    if (path.startsWith(externalStoragePath)) {
        return path.substringAfter(externalStoragePath, "").trimFileSeparator()
    }
    val dataDir = context.dataDirectory.path
    if (path.startsWith(dataDir)) {
        return path.substringAfter(dataDir, "").trimFileSeparator()
    }
    val storageId = getStorageId(context)
    return path.substringAfter("/storage/$storageId", "").trimFileSeparator()
}

fun String.trimFileSeparator() = trim('/')


fun File.getStorageId(context: Context) = when {
    path.startsWith(Environment.getExternalStorageDirectory().absolutePath) -> "primary"
    path.startsWith(context.dataDirectory.path) -> "data"
    else -> path.substringAfter("/storage/", "").substringBefore('/')
}

val Context.dataDirectory: File
    get() = if (Build.VERSION.SDK_INT > 23) dataDir else filesDir.parentFile!!

fun Context.getColumnInfoString(uri: Uri, column: String): String? {
    contentResolver.query(uri, arrayOf(column), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) {
            val columnIndex = cursor.getColumnIndex(column)
            if (columnIndex != -1) {
                return cursor.getString(columnIndex)
            }
        }
    }
    return null
}


val Uri.isTreeDocumentFile: Boolean
    get() = path?.startsWith("/tree/") == true

val Uri.isRawFile: Boolean
    get() = scheme == ContentResolver.SCHEME_FILE

val Uri.isMediaFile: Boolean
    get() = authority == MediaStore.AUTHORITY
val Uri.isExternalStorageDocument: Boolean
    get() = authority =="com.android.externalstorage.documents"

val Uri.isDownloadsDocument: Boolean
    get() = authority =="com.android.providers.downloads.documents"

val Uri.isMediaDocument: Boolean
    get() = authority == "com.android.providers.media.documents"

fun Uri.getStorageId(context: Context): String {
    val path = path.orEmpty()
    return if (isRawFile) {
        File(path).getStorageId(context)
    } else when {
        isExternalStorageDocument -> path.substringBefore(':', "").substringAfterLast('/')
        isDownloadsDocument -> "primary"
        else -> ""
    }
}


fun DocumentFile.getItemSize(countHiddenItems: Boolean): Long {
    return if (isDirectory) {
        getDirectorySize(this, countHiddenItems)
    } else {
        length()
    }
}

private fun getDirectorySize(dir: DocumentFile, countHiddenItems: Boolean): Long {
    var size = 0L
    if (dir.exists()) {
        val files = dir.listFiles()
        for (i in files.indices) {
            val file = files[i]
            if (file.isDirectory) {
                size += getDirectorySize(file, countHiddenItems)
            } else if (!file.name!!.startsWith(".") || countHiddenItems) {
                size += file.length()
            }
        }
    }
    return size
}

fun DocumentFile.getFileCount(countHiddenItems: Boolean): Int {
    return if (isDirectory) {
        getDirectoryFileCount(this, countHiddenItems)
    } else {
        1
    }
}

private fun getDirectoryFileCount(dir: DocumentFile, countHiddenItems: Boolean): Int {
    var count = 0
    if (dir.exists()) {
        val files = dir.listFiles()
        for (i in files.indices) {
            val file = files[i]
            if (file.isDirectory) {
                count++
                count += getDirectoryFileCount(file, countHiddenItems)
            } else if (!file.name!!.startsWith(".") || countHiddenItems) {
                count++
            }
        }
    }
    return count
}

