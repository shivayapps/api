package com.gallery.photo.image.video.cameraview.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.gallery.photo.image.video.cameraview.database.model.CameraStamp

@Dao
interface CameraStampDao {

    @Query("SELECT * FROM CameraStamp ORDER BY stampId DESC")
    fun loadAllStamp(): LiveData<List<CameraStamp>>

    @Query("SELECT * FROM CameraStamp ORDER BY stampId DESC")
    fun loadListAllStamp(): List<CameraStamp>

    @Insert
    fun insertStamp(cameraStamp: CameraStamp): Long

    @Update
    fun updateStamp(cameraStamp: CameraStamp)

    @Delete
    fun delete(cameraStamp: CameraStamp)

    @Query("DELETE FROM CameraStamp")
    fun deleteAll()

//    @Query("SELECT * FROM CameraStamp WHERE stampId = :id")
//    fun loadStampById(id: Int): LiveData<CameraStamp>

//    @Query("SELECT * FROM CameraStamp WHERE stampId = :id")
//    fun loadStampByIdWithoutLiveData(id: Int): CameraStamp

//    @Query("SELECT * FROM CameraStamp WHERE stampId = :id")
//    fun loadStampListById(id: Int): List<CameraStamp>
}