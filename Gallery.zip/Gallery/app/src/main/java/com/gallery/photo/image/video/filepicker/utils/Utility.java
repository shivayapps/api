package com.gallery.photo.image.video.filepicker.utils;

import android.content.Context;
import android.content.pm.PackageManager;

import com.gallery.photo.image.video.filepicker.model.FileListItem;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Utility {

    /**
     * Constructs a new Utility.
     */
    private Utility() {
        super();
    }

    /**
     * Prepares the list of Files and Folders inside 'inter' Directory.
     * The list can be filtered through extensions. 'filter' reference
     * is the FileFilter. A reference of ArrayList is passed, in case it
     * may contain the ListItem for parent directory. Returns the List of
     * Directories/files in the form of ArrayList.
     * @param internalList ArrayList containing parent directory.
     *
     * @param inter The present directory to look into.
     *
     * @param filter Extension filter class reference, for filtering files.
     *
     * @return ArrayList of FileListItem containing file info of current directory.
     */
    public static ArrayList<FileListItem> prepareFileListEntries(ArrayList<FileListItem> internalList, File inter,
                                                                 ExtensionFilter filter, boolean showHiddenFiles) {
        try {
            //Check for each and every directory/file in 'inter' directory.
            //Filter by extension using 'filter' reference.

            for(File name: inter.listFiles(filter)) {
                //If file/directory can be read by the Application
                if(name.canRead()) {
                    if(name.getName().startsWith(".") && !showHiddenFiles) continue;
                    //Create a row item for the directory list and define properties.
                    FileListItem item = new FileListItem();
                    item.setFilename(name.getName());
                    item.setDirectory(name.isDirectory());
                    item.setLocation(name.getAbsolutePath());
                    item.setTime(name.lastModified());
                    //Add row to the List of directories/files
                    internalList.add(item);
                }
            }
            //Sort the files and directories in alphabetical order.
            //See compareTo method in FileListItem class.
            Collections.sort(internalList);
        } catch(NullPointerException e) {
            //Just dont worry, it rarely occurs.
            Logger logger = Logger.getLogger(Utility.class.getName());
            logger.log(Level.WARNING, e.getLocalizedMessage());
            internalList = new ArrayList<>();
        }
        return internalList;
    }
}
