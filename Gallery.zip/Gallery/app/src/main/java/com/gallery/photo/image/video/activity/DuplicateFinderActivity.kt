package com.gallery.photo.image.video.activity

import android.app.Activity
import android.content.Intent
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.View
import com.example.app.ads.helper.GiftIconHelper
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activityBinding.BaseBindingActivity
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.databinding.ActivityDuplicateFinderNewBinding
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.mainduplicate.activity.scanningactivities.ScanningActivity


class DuplicateFinderActivity : BaseBindingActivity<ActivityDuplicateFinderNewBinding>() {

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(dm)
        val x = Math.pow((dm.widthPixels / dm.xdpi).toDouble(), 2.0)
        val y = Math.pow((dm.heightPixels / dm.ydpi).toDouble(), 2.0)
        val screenInches = Math.sqrt(x + y)
        if (AdsManager(mContext).isNeedToShowAds() && isOnline()) {
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = mBinding.giftLayout.giftAdIcon,
                fivBlastIcon = mBinding.giftLayout.giftBlastAdIcon
            )
            if (screenInches <= 5) {
                NativeAdvancedModelHelper(this).loadNativeAdvancedAd(
                    NativeAdsSize.Medium,
                    findViewById(R.id.adViewContainer)
                )
            } else {
                NativeAdvancedModelHelper(this).loadNativeAdvancedAd(
                    NativeAdsSize.Big,
                    findViewById(R.id.adViewContainer)
                )
            }
        } else {
            mBinding.adViewContainer.visibility = View.GONE
        }

        mBinding.imgBack.setOnClickListener {
            onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()

    }


    override fun initActions() {
        mBinding.llScanImages.setOnClickListener(this)
        mBinding.llScanAudio.setOnClickListener(this)
        mBinding.llScanVideo.setOnClickListener(this)
        mBinding.llScanDocument.setOnClickListener(this)
        mBinding.llScanOther.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.llScanImages -> {
                var intent = Intent(this, ScanningActivity::class.java)
                intent.putExtra("IsCheckType", "Image")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            R.id.llScanAudio -> {
                var intent = Intent(this, ScanningActivity::class.java)
                intent.putExtra("IsCheckType", "Audio")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            R.id.llScanVideo -> {
                var intent = Intent(this, ScanningActivity::class.java)
                intent.putExtra("IsCheckType", "Video")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            R.id.llScanDocument -> {
                var intent = Intent(this, ScanningActivity::class.java)
                intent.putExtra("IsCheckType", "Document")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            R.id.llScanOther -> {
                var intent = Intent(this, ScanningActivity::class.java)
                intent.putExtra("IsCheckType", "Other")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
        }
    }

    override fun getAppIconIDs() = arrayListOf(

        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)
    override fun setBinding(): ActivityDuplicateFinderNewBinding {
        return ActivityDuplicateFinderNewBinding.inflate(inflater)
    }
}