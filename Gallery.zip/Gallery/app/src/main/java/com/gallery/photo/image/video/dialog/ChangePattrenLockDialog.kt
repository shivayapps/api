package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.extensions.config

class ChangePattrenLockDialog(
    val activity: AppCompatActivity,
    val callback: (Boolean) -> Unit
) :
    DialogInterface.OnClickListener {
    private var currGrid = 0
    private var config = activity.config
    private var view: View

    init {

        view = activity.layoutInflater.inflate(R.layout.dialog_pattern_lock, null)

        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val ivClose = dialog.findViewById(R.id.ivClose) as ImageView

        ivClose.setOnClickListener {
            dialog.dismiss()
            callback(false)
        }
        val tvCancel = dialog.findViewById(R.id.tvCancel) as TextView
        val tvOK = dialog.findViewById(R.id.tvOK) as TextView
        val tvDone = dialog.findViewById(R.id.tvDone) as TextView
//
//        val tvTitle = dialog.findViewById(R.id.tvTitle) as TextView
//        val font = Typeface.createFromAsset(activity.assets, "fonts/avenirltpromedium.otf")
//        tvTitle.typeface = font

        tvDone.setOnClickListener {
            dialog.dismiss()
            callback(true)
        }
        tvCancel.setOnClickListener {
            dialog.dismiss()
            callback(false)
        }
        tvOK.setOnClickListener {
            dialog.dismiss()
            callback(true)
        }
        dialog.show()

    }

    override fun onClick(dialog: DialogInterface?, which: Int) {

    }

}
