package com.gallery.photo.image.video.helper

data class RadioItem(val id: Int, val title: String, val value: Any = id)
