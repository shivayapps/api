package com.gallery.photo.image.video.Camera;

import android.location.Location;

public interface onLocationUpdateListener {
    void setOnLocationUpdate(Location location);
}
