package com.gallery.photo.image.video.interfaces

interface SlideShowSelectListner {
    fun onSlideSHowItemSelect(time:Int)
}