package com.gallery.photo.image.video.interfaces

interface RecyclerScrollCallback {
    fun onScrolled(scrollY: Int)
}
