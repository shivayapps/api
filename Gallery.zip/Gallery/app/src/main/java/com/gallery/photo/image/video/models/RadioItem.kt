package com.gallery.photo.image.video.models

data class RadioItem(val id: Int, val title: String, val value: Any = id)
