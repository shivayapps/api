package com.gallery.photo.image.video.adapter

import android.app.ProgressDialog
import android.os.SystemClock
import android.util.Log
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.*
import com.gallery.photo.image.video.bindActivity.HiddenAudioActivity
import com.gallery.photo.image.video.bindActivity.TrashActivity
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.database.FavouriteDBHelper
import com.gallery.photo.image.video.dialog.DeleteWithRememberDialog
import com.gallery.photo.image.video.dialog.MoveToAlertDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.*
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.views.FastScroller
import com.gallery.photo.image.video.views.MyRecyclerView
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.dialog.RenameDialog
import com.gallery.photo.image.video.dialog.RenameItemDialog
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.models.FileDirItem
import kotlinx.android.synthetic.main.item_audio_document_list.view.*
import kotlinx.android.synthetic.main.thumbnail_section.view.*
import org.jetbrains.anko.toast
import java.util.LinkedHashSet

class AudioDocFileAdapter(
    activity: BaseSimpleActivity, var media: ArrayList<HideFilesDetail>, val listener: MediaOperationsListener?, val isAGetIntent: Boolean,
    val allowMultiplePicks: Boolean, recyclerView: MyRecyclerView, fastScroller: FastScroller? = null, val isFromFakeVault: Boolean = false, itemClick: (Any) -> Unit
) :
    MyRecyclerViewAdapter(activity, recyclerView, fastScroller, itemClick) {

    private val ITEM_SECTION = 0
    private val ITEM_MEDIUM_PHOTO = 2
    private val config = activity.config
    private val viewType = VIEW_TYPE_LIST
    private val isListViewType = viewType == VIEW_TYPE_LIST
    private var visibleItemPaths = java.util.ArrayList<String>()
    private var loadImageInstantly = true
    private var currentMediaHash = media.hashCode()
    private val hasOTGConnected = activity.hasOTGConnected()

    private var displayFilenames = activity.config.displayFileNames
    var mProgressDailog: ProgressDialog? = null

    // variable to track event time
    var mLastClickTime: Long = 0
    var mMinDuration = 2000
    protected var selectedMainKeys = LinkedHashSet<Int>()
    var deleteDialog: DeleteWithRememberDialog? = null

    init {
        setupDragListener(false)
        media.forEach {
            (it as? Medium)?.path?.hashCode()?.let { it1 -> selectedMainKeys.add(it1) }
        }
    }

    override fun getActionMenuId() = R.menu.cab_directories

    override fun prepareActionMode(menu: Menu) {
        val selectedItems = getSelectedItems()
        if (selectedItems.isEmpty()) {
            return
        }
        if (activity is HiddenAudioActivity) {
            (activity as HiddenAudioActivity).updateCount(selectedItems.size)
        }
        if (activity is TrashActivity) {
            (activity as TrashActivity).updateCount(selectedItems.size)
        }

        menu.apply {
            findItem(R.id.cab_delete).isVisible = activity !is TrashActivity
            val selectableItemCount = getSelectableItemCount()
            val selectedCount = Math.min(selectedKeys.size, selectableItemCount)
            if (selectedCount == selectableItemCount) {
                findItem(R.id.cab_select_all).title = "Deselect All"
                findItem(R.id.cab_select_all).icon = activity.resources.getDrawable(R.drawable.ic_deselect_all_vector)
            } else {
                findItem(R.id.cab_select_all).title = "Select All"
                findItem(R.id.cab_select_all).icon = activity.resources.getDrawable(R.drawable.ic_select_all_vector)
            }
        }
    }


    override fun actionItemPressed(id: Int) {
        if (selectedKeys.isEmpty()) {
            return
        }

        when (id) {
            R.id.cab_rename -> renameFile()
            R.id.cab_hide -> toggleFileVisibility(true)
            R.id.cab_unhide -> toggleFileVisibility(false)
            R.id.cab_share -> shareMedia()
            R.id.cab_copy_to -> copyMoveTo(true)
            R.id.cab_move_to -> moveFilesTo()
            R.id.cab_select_all -> selectAll()
            R.id.cab_delete -> checkDeleteConfirmation()
        }
    }

    override fun getSelectableItemCount() = media.size

    override fun getIsItemSelectable(position: Int) = !isASectionTitle(position)

    override fun getItemSelectionKey(position: Int) = (media.getOrNull(position) as? HideFilesDetail)?.path?.hashCode()

    override fun getItemKeyPosition(key: Int) = media.indexOfFirst { (it as? HideFilesDetail)?.path?.hashCode() == key }

    override fun onActionModeCreated() {
        if (activity is HiddenAudioActivity) {
            (activity as HiddenAudioActivity).toggleToolbar(true)
        }
        if (activity is TrashActivity) {
            (activity as TrashActivity).toggleToolbar(true)
        }

    }

    override fun onActionModeDestroyed() {
        if (activity is HiddenAudioActivity) {
            (activity as HiddenAudioActivity).toggleToolbar(false)
        }
        if (activity is TrashActivity) {
            (activity as TrashActivity).toggleToolbar(false)
        }

    }

    override fun getSelectedList(): LinkedHashSet<Int> {
        return selectedMainKeys
    }

    override fun onViewRecycled(holder: ViewHolder) {
        super.onViewRecycled(holder)
        if (!activity.isDestroyed) {
            val itemView = holder.itemView
            visibleItemPaths.remove(itemView.medium_name?.tag)
            /*val tmb = itemView.medium_thumbnail
            if (tmb != null) {
                Glide.with(activity).clear(tmb)
            }*/
        }
    }

    override fun getItemViewType(position: Int): Int {

        return ITEM_MEDIUM_PHOTO
    }

    fun getSelectedItems() = selectedKeys.mapNotNull { getItemWithKey(it) } as java.util.ArrayList<HideFilesDetail>

    private fun getSelectedPaths() = getSelectedItems().map { it.path } as java.util.ArrayList<String>

    private fun getFirstSelectedItemPath() = getItemWithKey(selectedKeys.first())?.path

    private fun getItemWithKey(key: Int): HideFilesDetail? = media.firstOrNull { (it as? HideFilesDetail)?.path?.hashCode() == key } as? HideFilesDetail

    fun updateMedia(newMedia: java.util.ArrayList<HideFilesDetail>) {
        val thumbnailItems = newMedia.clone() as java.util.ArrayList<HideFilesDetail>
        if (thumbnailItems.hashCode() != currentMediaHash) {
            currentMediaHash = thumbnailItems.hashCode()
            media = thumbnailItems
            enableInstantLoad()
            notifyDataSetChanged()
            finishActMode()
        }
    }

    private fun enableInstantLoad() {
        loadImageInstantly = true
        /*   delayHandler.postDelayed({
               loadImageInstantly = false
           }, INSTANT_LOAD_DURATION)*/
    }

    fun isASectionTitle(position: Int) = false

    fun getItemBubbleText(position: Int, sorting: Int, dateFormat: String, timeFormat: String): String {
        return (media[position] as? Medium)?.getBubbleText(sorting, activity, dateFormat, timeFormat) ?: ""
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutType = R.layout.item_audio_document_list
        return createViewHolder(layoutType, parent)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val tmbItem = media.getOrNull(position) ?: return
        if (tmbItem is HideFilesDetail) {
            visibleItemPaths.add(tmbItem.path)
        }

//        val allowLongPress = (!isAGetIntent || allowMultiplePicks) && tmbItem is Medium
        val allowLongPress = true
        holder.bindView(tmbItem, true, allowLongPress) { itemView, adapterPosition ->
            if (tmbItem is HideFilesDetail) {
                setupThumbnail(itemView, tmbItem)
            }
        }
        bindViewHolder(holder)
    }

    private fun setupThumbnail(view: View, medium: HideFilesDetail) {
        Log.d("TAG1122", "setupThumbnail: onBind ")
        val isSelected = selectedKeys.contains(medium.path.hashCode())
        view.apply {
            val padding = if (activity.config.thumbnailSpacing <= 1) {
                activity.config.thumbnailSpacing
            } else {
                0
            }

            media_item_holder.setPadding(padding, padding, padding, padding)
            if (medium.type == TYPE_AUDIO) {
                medium_thumbnail.setImageDrawable(activity.resources.getDrawable(R.drawable.ic_duplicate_audio))
            } else {
                medium_thumbnail.setImageDrawable(activity.resources.getDrawable(R.drawable.ic_duplicate_document))
            }

            medium_name.beVisibleIf(displayFilenames || isListViewType)
            medium_name.text = medium.name
            medium_name.tag = medium.path
            medium_check.beVisibleIf(isSelected)
            if (activity is TrashActivity) {
                img_arrow.beGone()
            } else {
                img_arrow.beGoneIf(isSelected)
            }


            if (isSelected) {
                medium_check.background.applyColorFilter(adjustedPrimaryColor)
                medium_check.applyColorFilter(contrastColor)

            }

            if (isListViewType) {
                media_item_holder.isSelected = isSelected
            }

        }
    }

    private fun setupSection(view: View, section: ThumbnailSection) {
        view.apply {
            thumbnail_section.text = section.title
//            thumbnail_section.setTextColor(textColor)
        }
    }

    override fun getItemCount(): Int {
        return media.size
    }


    private fun renameFile() {
        if (selectedKeys.size == 1) {
            val oldPath = getFirstSelectedItemPath() ?: return
            RenameItemDialog(activity, oldPath) {
                ensureBackgroundThread {
                    activity.updateDBMediaPath(oldPath, it)

                    activity.runOnUiThread {
                        enableInstantLoad()
                        listener?.refreshItems()
                        finishActMode()
                    }
                }
            }
        } else {
            RenameDialog(activity, getSelectedPaths(), true) {
                enableInstantLoad()
                listener?.refreshItems()
                finishActMode()
            }
        }
    }


    fun toggleFileVisibility(hide: Boolean) {
        VaultFragment.isHideUnHideMedia = true
        if (getSelectedItems().size == 0)
            return
        var selectedList = getSelectedItems()
//        var totalImagesCount = activity.config.hidePhotoCountForSubscription
//        var totalVideosCount = activity.config.hideVideoCountForSubscription
//        if (selectedList[0].type == TYPE_IMAGES)
//            totalImagesCount += selectedList.size
//        else if (selectedList[0].type == TYPE_VIDEOS)
//            totalVideosCount += selectedList.size

        var msg = activity.getString(R.string.msg_hiding)
        if (!hide) {
            msg = activity.getString(R.string.label_Unhiding)
        }
        showProgress(msg)

        ensureBackgroundThread {
//            if (hide) {
//                activity.config.hidePhotoCountForSubscription = totalImagesCount
//                activity.config.hideVideoCountForSubscription = totalVideosCount
//            }
            ensureBackgroundThread {
                selectedList.forEach {
                    if (!hide) {
                        if (VaultFragment.isFakeVaultOpen) {
                            activity.fakeHideFileDao.deleteHideFilesDetailPath(it.path)
                        } else {
                            activity.hideFileDao.deleteHideFilesDetailPath(it.path)
                        }
                    }
                }
            }
            getSelectedItems().forEach {
                activity.toggleFileVisibility(it.path, hide)
            }
            activity.runOnUiThread {
                dismissProgress()
                if (activity is MediaActivity)
                    if (activity.findViewById<EditText>(R.id.etSearch).text.isNotEmpty())
                        if (activity.findViewById<ImageView>(R.id.imgClose) != null)
                            activity.findViewById<ImageView>(R.id.imgClose).performClick()
                listener?.refreshItems()
                finishActMode()
                MainActivity.isNeedToRefresh = true
                VaultFragment.isNeedToRefresh = true
                var filterType = TYPE_AUDIO
                if (selectedList[0].type == TYPE_DOCUMENT)
                    filterType = TYPE_DOCUMENT
                when (filterType) {
                    TYPE_AUDIO -> activity.toast(activity.getString(R.string.msg_audio_unhide))
                    TYPE_DOCUMENT -> activity.toast(activity.getString(R.string.msg_document_unhide))
                    else -> activity.toast(activity.getString(R.string.msg_unhide_media_successfully))
                }
            }
        }

    }

    fun shareMedia() {

        isUnLockApp = true
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()

        isUnLockApp = true
        if (selectedKeys.size == 1 && selectedKeys.first() != -1) {
            activity.shareMediumPath(getSelectedItems().first().path)
        } else if (selectedKeys.size > 1) {
            activity.shareMediaPaths(getSelectedPaths())
        }
    }

    private fun moveFilesTo() {
        MoveToAlertDialog(activity, activity.getString(R.string.alert_confirm_move)) {
            if (it) {
                activity.handleDeletePasswordProtection {
                    copyMoveTo(false)
                }
            }

        }

    }

    private fun copyMoveTo(isCopyOperation: Boolean) {
        VaultFragment.isHideUnHideMedia = true
        if (activity is MediaActivity)
            if (activity.findViewById<EditText>(R.id.etSearch).text.isNotEmpty())
                if (activity.findViewById<ImageView>(R.id.imgClose) != null)
                    activity.findViewById<ImageView>(R.id.imgClose).performClick()
        val paths = getSelectedPaths()

        val recycleBinPath = activity.recycleBinPath
        val fileDirItems = paths.asSequence().filter { isCopyOperation || !it.startsWith(recycleBinPath) }.map {
            FileDirItem(it, it.getFilenameFromPath())
        }.toMutableList() as java.util.ArrayList

        if (!isCopyOperation && paths.any { it.startsWith(recycleBinPath) }) {
            activity.toast(R.string.moving_recycle_bin_items_disabled, Toast.LENGTH_LONG)
        }

        if (fileDirItems.isEmpty()) {

            return
        }
        var selectedList = getSelectedItems()
        if (paths.size > 5) {
            finishActMode()
        }
        activity.baseConfig.isAnyOperationRunning = true
        Log.d("TAG787878", "itemClicked: " + activity.config.isAnyOperationRunning)
        Log.d("TAG787878", "itemClicked: " + activity.config.lastDestinationPath)
        activity.tryCopyMoveFilesTo(fileDirItems, isCopyOperation) {
            finishActMode()
            if (it == "None") {
                activity.baseConfig.isAnyOperationRunning = false
                baseConfig.lastDestinationPath = ""
                Log.d("TAG787878", "itemClicked: " + activity.config.isAnyOperationRunning)
                Log.d("TAG787878", "itemClicked: " + activity.config.lastDestinationPath)
                if (activity is MainActivity)
                    if (activity.findViewById<EditText>(R.id.etSearch).text.isNotEmpty())
                        if (activity.findViewById<ImageView>(R.id.imgClose) != null)
                            activity.findViewById<ImageView>(R.id.imgClose).performClick()
            } else {

                val destinationPath = it
                baseConfig.lastDestinationPath = destinationPath
                config.tempFolderPath = ""
                baseConfig.isAnyOperationRunning = false
                baseConfig.lastDestinationPath = ""
                if (isCopyOperation) {
                    activity.toast(R.string.copying_success)
                } else {
                    activity.toast(R.string.moving_success)
                }
                activity.applicationContext.rescanFolderMedia(destinationPath)
                activity.applicationContext.rescanFolderMedia(fileDirItems.first().getParentPath())

                val newPaths = fileDirItems.map { "$destinationPath/${it.name}" }.toMutableList() as java.util.ArrayList<String>
                activity.rescanPaths(newPaths) {
                    activity.fixDateTaken(newPaths, false)
                }
                Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: CalledUpdated  Destiamtion ---> $it")
                if (selectedList[0].type == TYPE_VIDEOS) {
                    Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Video  ---> ")
                    ensureBackgroundThread {
                        activity.updatePhotoVideoDirectoryPath(it, false, true)
                        if (!isCopyOperation)
                            activity.updatePhotoVideoDirectoryPath(selectedList[0].parentPath, false, true)
                    }
                } else if (selectedList[0].type == TYPE_IMAGES) {
                    Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Image  ---> ")
                    ensureBackgroundThread {
                        activity.updatePhotoVideoDirectoryPath(it, true, false)
                        if (!isCopyOperation)
                            activity.updatePhotoVideoDirectoryPath(selectedList[0].parentPath, true, false)
                    }
                }
                if (activity is MainActivity)
                    if (activity.findViewById<EditText>(R.id.etSearch).text.isNotEmpty())
                        if (activity.findViewById<ImageView>(R.id.imgClose) != null)
                            activity.findViewById<ImageView>(R.id.imgClose).performClick()

                if (!isCopyOperation) {
                    VaultFragment.isNeedToRefresh = true
                    listener?.refreshItems()
                    var favoritesDB = FavouriteDBHelper(activity)
                    fileDirItems.forEach {
                        favoritesDB.deleteFavDetails(it.path)
                    }

                }

                Log.d("TAG787878", "itemClicked: " + activity.config.isAnyOperationRunning)
                Log.d("TAG787878", "itemClicked: " + activity.config.lastDestinationPath)

            }
        }
    }

    fun showProgress(msg: String) {
        mProgressDailog = ProgressDialog(activity, R.style.MyAlertDialogNew)
        mProgressDailog!!.setMessage(msg)

        mProgressDailog!!.setCancelable(false)
        mProgressDailog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
        mProgressDailog!!.show()
    }

    fun dismissProgress() {
        activity.runOnUiThread {
            if (mProgressDailog != null && mProgressDailog!!.isShowing) {
                mProgressDailog!!.dismiss()
            }
        }
    }

    fun checkDeleteConfirmation() {
        if (config.isDeletePasswordProtectionOn) {
            activity.handleDeletePasswordProtection {
                deleteFiles()
            }
        } else {
            askConfirmDelete()
        }
    }

    private fun askConfirmDelete() {
        val itemsCnt = selectedKeys.size
        val firstPath = getSelectedPaths().first()
        val items = if (itemsCnt == 1) {
            "\"${firstPath.getFilenameFromPath()}\""
        } else {
            resources.getQuantityString(R.plurals.delete_items, itemsCnt, itemsCnt)
        }

        val isRecycleBin = firstPath.startsWith(activity.recycleBinPath)
        val baseString = if (!isRecycleBin) R.string.msg_move_vault_trash else R.string.deletion_confirmation
//        val baseString =  R.string.deletion_confirmation
        val question = String.format(resources.getString(baseString), items)
        deleteDialog = DeleteWithRememberDialog(activity, question) {
            if (it) {
                TrashActivity.isDeleteOrRestore=true
                showProgress(activity.getString(R.string.msg_deleting))
                config.tempSkipDeleteConfirmation = it
                deleteFiles()
            } else {
                finishActMode()
            }

        }

    }

    public fun dismissDeleteDialog() {
        if (deleteDialog != null) {
            deleteDialog!!.dialog.dismiss()
        }
    }

    private fun deleteFiles() {
        VaultFragment.isHideUnHideMedia = true
        if (selectedKeys.isEmpty()) {
            return
        }

        val SAFPath = getSelectedPaths().firstOrNull { activity.needsStupidWritePermissions(it) } ?: getFirstSelectedItemPath() ?: return
        activity.handleSAFDialog(SAFPath) {
            if (!it) {
                return@handleSAFDialog
            }

            val fileDirItems = ArrayList<FileDirItem>(selectedKeys.size)
            val removeMedia = ArrayList<HideFilesDetail>(selectedKeys.size)
            val positions = getSelectedItemPositions()

            getSelectedItems().forEach {
                fileDirItems.add(FileDirItem(it.path, it.name))
                removeMedia.add(it)
            }
            Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: CalledUpdated  Destiamtion ---> " + it)
            removeSelectedItems(positions)
            currentMediaHash = media.hashCode()
            media.removeAll(removeMedia)
            listener?.tryDeleteFiles(fileDirItems)

        }
    }

    fun restoreFiles(isAudio: Boolean) {
        showProgress(activity.getString(R.string.please_wait))
        activity.restoreRecycleBinAudioDocPaths(getSelectedPaths(), VaultFragment.isFakeVaultOpen) {
            dismissProgress()
            listener?.refreshItems()
            if (isAudio) {
                activity.addEvent(restoreAudio)
                activity.toast(activity.getString(R.string.msg_audio_restore_successfully))
            } else {
                activity.addEvent(restoreDocument)
                activity.toast(activity.getString(R.string.msg_document_restore_successfully))
            }
            finishActMode()
        }
    }

}