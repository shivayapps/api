package com.gallery.photo.image.video.Camera;

public class MyDebug {
    public static final boolean LOG = true;
}
