package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.utilities.isGridSizeChange
import com.gallery.photo.image.video.activity.BaseSimpleActivity


class ChangeGridSizeDialog(
    val activity: BaseSimpleActivity, val isDirectorySorting: Boolean, val showFolderCheckbox: Boolean,
    val path: String = "", val callback: () -> Unit
) {
    private var currGrid = 0
    private var config = activity.config
    private var view: View

    init {
        currGrid = if (isDirectorySorting) config.dirColumnCnt else config.mediaColumnCnt
        view = activity.layoutInflater.inflate(R.layout.dialog_grid_size, null)

        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val ivClose = dialog.findViewById(R.id.ivClose) as ImageView
        val dividerGrid1 = dialog.findViewById(R.id.dividerGrid1) as View
        val rgGridSize = dialog.findViewById(R.id.rgGridSize) as RadioGroup
        val rbGridSize1 = dialog.findViewById(R.id.rbGridSize1) as RadioButton
        val rbGridSize2 = dialog.findViewById(R.id.rbGridSize2) as RadioButton
        val rbGridSize3 = dialog.findViewById(R.id.rbGridSize3) as RadioButton
        val rbGridSize4 = dialog.findViewById(R.id.rbGridSize4) as RadioButton
//
//        val tvTitle = dialog.findViewById(R.id.tvTitle) as TextView
//        val font = Typeface.createFromAsset(activity.assets, "fonts/avenirltpromedium.otf")
//        tvTitle.typeface = font

        if (isDirectorySorting) {
            rbGridSize1.visibility = GONE
            dividerGrid1.visibility = GONE
        } else {
            rbGridSize1.visibility = VISIBLE
            dividerGrid1.visibility = VISIBLE
        }
        var gridSize = 3
        when (currGrid) {
            1 -> {
                rbGridSize1.isChecked = true
                gridSize = 1
            }
            2 -> {
                rbGridSize2.isChecked = true
                gridSize = 2
            }
            3 -> {
                rbGridSize3.isChecked = true
                gridSize = 3
            }
            4 -> {
                rbGridSize4.isChecked = true
                gridSize = 4
            }
            else -> {
                rbGridSize3.isChecked = true
                gridSize = 3
            }
        }
        rgGridSize.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.rbGridSize1 -> {
                    gridSize = 1
                }
                R.id.rbGridSize2 -> {
                    gridSize = 2
                }
                R.id.rbGridSize3 -> {
                    gridSize = 3
                }
                R.id.rbGridSize4 -> {
                    gridSize = 4
                }
            }
        }
        ivClose.setOnClickListener {
            dialog.dismiss()
        }

        val tvDone = dialog.findViewById(R.id.tvDone) as TextView
        tvDone.setOnClickListener {
            if (isDirectorySorting)
                config.dirColumnCnt = gridSize
            else
                config.mediaColumnCnt = gridSize
            isGridSizeChange = true

            dialog.dismiss()
            callback()
        }
        dialog.show()
    }
}
