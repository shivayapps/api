package com.gallery.photo.image.video.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.databinding.MoreStickerRowBinding
import com.gallery.photo.image.video.stickerView.StickerModel
import java.util.*

/**
 * Created by Vishal2.vasundhara on 27-Jan-18.
 */
class StickerAdapterAssets constructor(
    val context: Context,
    private val list: ArrayList<StickerModel>, val callback: (position: Int) -> Unit
) : BaseAdapter<StickerModel>(list) {
    

    inner class MyView(fBinding: MoreStickerRowBinding) : BaseViewHolder<MoreStickerRowBinding>(fBinding)

    override fun onCreateHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<*> {

        return MyView(MoreStickerRowBinding.inflate(LayoutInflater.from(context), parent, false))
    }

    override fun onBindHolder(holder: BaseViewHolder<*>, position: Int) {
        with(holder as MyView) {
            with(fBinding) {
                with(list[position]) {
                    Glide.with(ivStickerRow)
                        .load(list[position].path + "/thumb.png")
                        .into(ivStickerRow)

                    holder.itemView.setOnClickListener {
                        callback(position)
                    }
                }
            }
        }
    }


    override fun getItemCount(): Int {
        return list.size
    }

}