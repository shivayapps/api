package com.gallery.photo.image.video.dialog

import android.app.Activity
import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioGroup
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogResetStyleBinding
import com.gallery.photo.image.video.extension.beVisibleIf
import com.gallery.photo.image.video.utils.Preferences

class ResetStyleDialog(
    var mContext: Activity,
    val methodListener: (methodSelected: Int) -> Unit
) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogResetStyleBinding
    var preferences: Preferences = Preferences(mContext)
//    var securityMail = ""


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogResetStyleBinding.inflate(layoutInflater, container, false)

        intView()
        intListener()
        return bindingDialog.root
    }


    private fun intView() {

//        securityMail = preferences.securityEmail
//        if (securityMail.isNotEmpty()) {
//            bindingDialog.rbEmail.isChecked = true
//        }

        bindingDialog.rbSecurityQue.isEnabled=(preferences.getSetQuestion())
    }

    private fun intListener() {
//        bindingDialog.btnCancel.setOnClickListener {
        bindingDialog.root.findViewById<TextView>(R.id.btnCancel).setOnClickListener {
            dismiss()
        }
//        bindingDialog.btnOK.setOnClickListener {
        bindingDialog.root.findViewById<TextView>(R.id.btnOK).setOnClickListener {
//            val selectedRadioButtonId: Int = bindingDialog.grpOption.checkedRadioButtonId
//            val selectedRadioButtonId: Int =
//                bindingDialog.root.findViewById<RadioGroup>(R.id.grpOption).checkedRadioButtonId
//            var typeSelected = when (selectedRadioButtonId) {
//                bindingDialog.rbEmail.id -> 1
//                bindingDialog.rbSecurityQue.id -> 2
//                else -> 1
//            }
            methodListener.invoke(0)
            dismiss()
        }

    }


    //    override fun getTheme(): Int = if(useDarkMode!!) R.style.BottomSheetDialogThemeDark else R.style.BottomSheetDialogTheme
    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}

