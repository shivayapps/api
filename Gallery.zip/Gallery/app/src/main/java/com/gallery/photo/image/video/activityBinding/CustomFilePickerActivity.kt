package com.gallery.photo.image.video.activityBinding

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Environment
import android.os.Parcelable
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.REQUEST_CODE_FOR_SUBSCRIPTION
import com.gallery.photo.image.video.activity.SubscriptionActivity
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.databinding.ActivityCustomFilePickerBinding
import com.gallery.photo.image.video.dialog.SubscriptionDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.PhotoDirectoryFragment
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.fragment.VideoDirectoryFragment
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.adapters.CustomFilepickerItemsSelectionAdapter
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.Breadcrumbs
import kotlinx.android.synthetic.main.activity_add_hidden_media.ll_progress
import org.jetbrains.anko.toast
import java.io.File
import java.util.*
import kotlin.collections.ArrayList

const val ARG_FILE_PICKER_TYPE = "arg_file_picker_type"

class CustomFilePickerActivity : BaseBindingActivity<ActivityCustomFilePickerBinding>(), Breadcrumbs.BreadcrumbsListener {

    private var mFirstUpdate = true
    private var isFabClicked = false
    private var mPrevPath = ""
    private var mScrollStates = HashMap<String, Parcelable>()

    var currPath: String = Environment.getExternalStorageDirectory().toString()
    val pickFile: Boolean = true
    var showHidden: Boolean = false
    val showFAB: Boolean = false
    var mDateFormat: String = ""
    var mTimeFormat: String = ""
    var mFilterType = CHOOSE_ALL_TYPE
    var mMedia = ArrayList<FileDirItem>()

    companion object {
        fun newIntent(mContext: Context, filterMediaType: Int = CHOOSE_ALL_TYPE): Intent {
            return Intent(mContext, CustomFilePickerActivity::class.java)
                .putExtra(ARG_FILE_PICKER_TYPE, filterMediaType)
        }
    }

    override fun setBinding(): ActivityCustomFilePickerBinding {
        return ActivityCustomFilePickerBinding.inflate(layoutInflater)
    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {

        mDateFormat = config.dateFormat
        mTimeFormat = getTimeFormat()
        currPath = internalStoragePath
        mFilterType = intent.getIntExtra(ARG_FILE_PICKER_TYPE, CHOOSE_ALL_TYPE)
        addEvent(javaClass.simpleName + "_" + mFilterType)
        mBinding.filepickerBreadcrumbs.apply {
            listener = this@CustomFilePickerActivity
            updateFontSize(getTextSize())
            updateColor(R.color.black)
        }
        tryUpdateItems()
        mBinding.imgBack.setOnClickListener(this)
        mBinding.llHideOpt.setOnClickListener(this)
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            InterstitialAdHelper.loadInterstitialAd(fContext = this)
        }
    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.llHideOpt -> {
                if (getMediaAdapter() != null) {
                    var selectedList = getMediaAdapter()!!.getSelectedItems()
                    if (selectedList.size > 0) {
                        if (mFilterType == CHOOSE_IMAGE_TYPE) {
                            var totalImagesCount = config.hidePhotoCountForSubscription
                            var totalVideosCount = config.hideVideoCountForSubscription
                            totalImagesCount += selectedList.size
                            if (AdsManager(this).isNeedToShowAds() && totalImagesCount > HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION_VAL) {
                                runOnUiThread {
                                    dismissProgress()
                                    SubscriptionDialog(this, totalImagesCount, totalVideosCount)
                                    {
                                        if (it) {
                                            var intent = Intent(this, SubscriptionActivity::class.java)
                                            launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
                                        } else {
                                            mContext.config.hidePhotoCountForSubscription = totalImagesCount
                                            ensureBackgroundThread {
                                                uDataDao.updateCount(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, config.hidePhotoCountForSubscription)
                                            }
                                            hideFiles(selectedList,false)
                                        }
                                    }
                                }
                            } else {
                                mContext.config.hidePhotoCountForSubscription = totalImagesCount
                                ensureBackgroundThread {
                                    uDataDao.updateCount(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, config.hidePhotoCountForSubscription)
                                }
                                hideFiles(selectedList,true)
                            }
                        } else if (mFilterType == CHOOSE_VIDEO_TYPE) {
                            var totalImagesCount = config.hidePhotoCountForSubscription
                            var totalVideosCount = config.hideVideoCountForSubscription
                            totalVideosCount += selectedList.size
                            if (AdsManager(this).isNeedToShowAds() && totalVideosCount > HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION_VAL) {
                                runOnUiThread {
                                    dismissProgress()
                                    SubscriptionDialog(this, totalImagesCount, totalVideosCount)
                                    {
                                        if (it) {
                                            var intent = Intent(this, SubscriptionActivity::class.java)
                                            launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
                                        } else {
                                            mContext.config.hideVideoCountForSubscription = totalVideosCount
                                            ensureBackgroundThread {
                                                uDataDao.updateCount(HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION, config.hideVideoCountForSubscription)
                                            }
                                            hideFiles(selectedList,false)
                                        }
                                    }
                                }
                            } else {
                                mContext.config.hideVideoCountForSubscription = totalVideosCount
                                ensureBackgroundThread {
                                    uDataDao.updateCount(HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION, config.hideVideoCountForSubscription)
                                }
                                hideFiles(selectedList,true)
                            }
                        } else if (mFilterType == CHOOSE_AUDIO_TYPE) {
                            var totalAudioCount = config.hideAudioCountForSubscription
                            totalAudioCount += selectedList.size
                            mContext.config.hideAudioCountForSubscription = totalAudioCount
                            hideFiles(selectedList,true)
                        } else if (mFilterType == CHOOSE_DOCUMENT_TYPE) {
                            var totalDocumentCount = config.hideDocumentCountForSubscription
                            totalDocumentCount += selectedList.size
                            mContext.config.hideDocumentCountForSubscription = totalDocumentCount
                            hideFiles(selectedList,true)
                        }
                    } else {
                        toast(getString(R.string.error_please_select_one_item))
                    }
                }
            }
            R.id.imgBack -> {
                finish()
            }
        }
    }

    private fun hideFiles(selectedList: java.util.ArrayList<FileDirItem>,isNeedToShowAd:Boolean) {
        VaultFragment.isHideUnHideMedia = true
        isInterstitialShown = true
        showProgress(getString(R.string.please_wait))
        ensureBackgroundThread {
            selectedList.forEachIndexed { index, it ->
                toggleFileVisibility(it.path, true)
                {
                    if (mFilterType == CHOOSE_AUDIO_TYPE || mFilterType == CHOOSE_DOCUMENT_TYPE) {
                        addFileToDB(it, VaultFragment.isFakeVaultOpen)
                        if (index == selectedList.size - 1) {
                            runOnUiThread {
                                config.hiddenCountForRate++
                                HiddenAudioActivity.isNeedToRefersh = true
                                when (mFilterType) {
                                    CHOOSE_IMAGE_TYPE -> toast(getString(R.string.msg_image_hide))
                                    CHOOSE_VIDEO_TYPE -> toast(getString(R.string.msg_video_hide))
                                    CHOOSE_AUDIO_TYPE -> toast(getString(R.string.msg_audio_hide))
                                    CHOOSE_DOCUMENT_TYPE -> toast(getString(R.string.msg_document_hide))
                                    else -> toast(getString(R.string.msg_hide_media_successfully))
                                }
                                ll_progress.visibility = View.GONE
                                dismissProgress()
                                isInterstitialShown = false
                                showAds(isNeedToShowAd)

                            }
                        }
                    }
                    if (VaultFragment.isFakeVaultOpen && (mFilterType == CHOOSE_IMAGE_TYPE || mFilterType == CHOOSE_VIDEO_TYPE)) {
                        addFakeMedia(it)
                    }

                }
            }
            ensureBackgroundThread {
                if (mFilterType == CHOOSE_IMAGE_TYPE || mFilterType == CHOOSE_VIDEO_TYPE) {
                    if (VaultFragment.isFakeVaultOpen) {
                        if (directoryDao.getDirectoryDetailFromDirPath(selectedList[0].path.getParentPath()) != null)
                            fakeVaultHiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(selectedList[0].path.getParentPath()).getConvertedFakeVaultDirectory())
                        else if (photoDirectoryDao.getDirectoryDetailFromDirPath(selectedList[0].path.getParentPath()) != null)
                            fakeVaultHiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(selectedList[0].path.getParentPath()).getConvertedFakeVaultDirectory())
                        else if (videoDirectoryDao.getDirectoryDetailFromDirPath(selectedList[0].path.getParentPath()) != null)
                            fakeVaultHiddenDirectoryDao.insert(videoDirectoryDao.getDirectoryDetailFromDirPath(selectedList[0].path.getParentPath()).getConvertedFakeVaultDirectory())
                        else {
                            if (mFilterType == CHOOSE_IMAGE_TYPE)
                                updatePhotoVideoDirectoryPath(selectedList[0].path.getParentPath(), true, false, true)
                            else if (mFilterType == CHOOSE_VIDEO_TYPE)
                                updatePhotoVideoDirectoryPath(selectedList[0].path.getParentPath(), false, true, true)
                        }
                    } else if (!VaultFragment.isFakeVaultOpen) {
                        if (directoryDao.getDirectoryDetailFromDirPath(selectedList[0].path.getParentPath()) != null)
                            hiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(selectedList[0].path.getParentPath()).getConvertedHiddenDirectory())
                        else if (photoDirectoryDao.getDirectoryDetailFromDirPath(selectedList[0].path.getParentPath()) != null)
                            hiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(selectedList[0].path.getParentPath()).getConvertedHiddenDirectory())
                        else if (videoDirectoryDao.getDirectoryDetailFromDirPath(selectedList[0].path.getParentPath()) != null)
                            hiddenDirectoryDao.insert(videoDirectoryDao.getDirectoryDetailFromDirPath(selectedList[0].path.getParentPath()).getConvertedHiddenDirectory())
                        else {
                            if (mFilterType == CHOOSE_IMAGE_TYPE)
                                updatePhotoVideoDirectoryPath(selectedList[0].path.getParentPath(), true, false, true)
                            else if (mFilterType == CHOOSE_VIDEO_TYPE)
                                updatePhotoVideoDirectoryPath(selectedList[0].path.getParentPath(), false, true, true)
                        }
                    }
                    runOnUiThread {
                        config.hiddenCountForRate++
                        PhotoDirectoryFragment.isNeedToRefresh = true
                        VideoDirectoryFragment.isNeedToRefresh = true
                        VaultFragment.isNeedToRefresh = true
                        HiddenImagesActivity.isNeedToRefresh = true
                        when (mFilterType) {
                            CHOOSE_IMAGE_TYPE -> toast(getString(R.string.msg_image_hide))
                            CHOOSE_VIDEO_TYPE -> toast(getString(R.string.msg_video_hide))
                            CHOOSE_AUDIO_TYPE -> toast(getString(R.string.msg_audio_hide))
                            CHOOSE_DOCUMENT_TYPE -> toast(getString(R.string.msg_document_hide))
                            else -> toast(getString(R.string.msg_hide_media_successfully))
                        }
                        ll_progress.visibility = View.GONE
                        dismissProgress()
                        isInterstitialShown = false
                        showAds(isNeedToShowAd)

                    }
                }

            }


        }
    }

    private fun showAds(isNeedToShowAd:Boolean) {

        if (AdsManager(this).isNeedToShowAds() && isOnline() && isNeedToShowAd) {
            isShowInterstitialAd {
                isInterstitialShown = false
                finish()
            }

        } else {
            isInterstitialShown = false
            finish()
        }
    }

    override fun initActions() {
        mBinding.imgSelectAll.setOnClickListener {
            if (getMediaAdapter() != null) {
                if (getMediaAdapter()!!.getSelectedItems().size == getMediaAdapter()!!.getSelectableItemCount()) {
                    getMediaAdapter()!!.toggleItemSelect()
                    mBinding.imgDeSelectAll.visibility = View.INVISIBLE
                    mBinding.imgSelectAll.visibility = View.VISIBLE
                } else {
                    getMediaAdapter()!!.toggleItemSelect()
                    mBinding.imgDeSelectAll.visibility = View.VISIBLE
                    mBinding.imgSelectAll.visibility = View.INVISIBLE
                }
                mBinding.tvDone.text = getString(R.string.hide_photo, getMediaAdapter()!!.getSelectedItems().size)
            }
        }
        mBinding.imgDeSelectAll.setOnClickListener {
            if (getMediaAdapter() != null) {
                if (getMediaAdapter()!!.getSelectedItems().size == getMediaAdapter()!!.getSelectableItemCount()) {
                    getMediaAdapter()!!.toggleItemSelect()
                    mBinding.imgDeSelectAll.visibility = View.INVISIBLE
                    mBinding.imgSelectAll.visibility = View.VISIBLE
                } else {
                    getMediaAdapter()!!.toggleItemSelect()
                    mBinding.imgDeSelectAll.visibility = View.VISIBLE
                    mBinding.imgSelectAll.visibility = View.INVISIBLE

                }
                mBinding.tvDone.text = getString(R.string.hide_photo, getMediaAdapter()!!.getSelectedItems().size)
            }
        }
    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun breadcrumbClicked(id: Int) {
        if (id == 0) {

            if (currPath != internalStoragePath) {
                currPath = internalStoragePath
                tryUpdateItems()
            }
        } else {
            val item = mBinding.filepickerBreadcrumbs.getChildAt(id).tag as FileDirItem
            if (currPath != item.path.trimEnd('/')) {
                currPath = item.path
                tryUpdateItems()
            }
        }

    }

    private fun tryUpdateItems() {
        mBinding.llProgress.beVisible()
        mBinding.llNoDataFaound.beGone()
        mBinding.imgDeSelectAll.visibility = View.INVISIBLE
        mBinding.imgSelectAll.visibility = View.INVISIBLE
        ensureBackgroundThread {
            getItems(currPath) {
                runOnUiThread {
                    updateItems(it as ArrayList<FileDirItem>)
                }
            }
        }
    }

    private fun getItems(path: String, callback: (List<FileDirItem>) -> Unit) {
        if (isPathOnOTG(path)) {
            getOTGItems(path, showHidden, false, callback)
        } else {
            val lastModifieds = getFolderLastModifieds(path)
            getRegularItems(path, lastModifieds, callback)
        }
    }

    private fun getRegularItems(path: String, lastModifieds: HashMap<String, Long>, callback: (List<FileDirItem>) -> Unit) {
        val items = ArrayList<FileDirItem>()
        val base = File(path)
        val files = base.listFiles()
        if (files == null) {
            callback(items)
            return
        }

        for (file in files) {
            if (!showHidden && file.name.startsWith('.')) {
                continue
            }


            val curPath = file.absolutePath

            if (file.isDirectory && curPath.containsNoMedia()) {
                continue
            }
            if (file.isFile && mFilterType == CHOOSE_IMAGE_TYPE && !curPath.isImageFast() && !curPath.isGif()) {
                continue
            }


            if (file.isFile && mFilterType == CHOOSE_VIDEO_TYPE && !curPath.isVideoFast()) {
                continue
            }

            if (file.isFile && mFilterType == CHOOSE_DOCUMENT_TYPE && !curPath.isDocumentFast()) {
                continue
            }

            if (file.isFile && mFilterType == CHOOSE_AUDIO_TYPE && !curPath.isAudioFast()) {
                continue
            }
            if (file.isFile && mFilterType == CHOOSE_ALL_TYPE && !curPath.isAudioFast() && !curPath.isImageFast() && !curPath.isVideoFast() && !curPath.isDocumentFast()) {
                continue
            }

            val curName = curPath.getFilenameFromPath()
            val size = file.length()
            var lastModified = lastModifieds.remove(curPath)
            val isDirectory = if (lastModified != null) false else file.isDirectory
            if (lastModified == null) {
                lastModified = 0    // we don't actually need the real lastModified that badly, do not check file.lastModified()
            }

            val children = if (isDirectory) file.getTypeWiseDirectChildrenCount(showHidden, mFilterType) else 0
            items.add(FileDirItem(curPath, curName, isDirectory, children, size, lastModified))
        }
        items.filter { File(it.path).isDirectory && !it.path.containsNoMedia() }
        callback(items)
    }

    private fun containsDirectory(items: List<FileDirItem>) = items.any { it.isDirectory }

    private fun updateItems(items: ArrayList<FileDirItem>) {
        if (!containsDirectory(items) && !mFirstUpdate && !pickFile && !showFAB) {
            verifyPath()
            return
        }

        var sortedItems = items.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase(Locale.getDefault()) }))
        mMedia = items
        val adapter = CustomFilepickerItemsSelectionAdapter(this, sortedItems, mBinding.filepickerList) {
            if ((it as FileDirItem).isDirectory) {
                handleLockedFolderOpening(it.path) { success ->
                    if (success) {
                        currPath = it.path
                        tryUpdateItems()
                    }
                }
            } else if (pickFile) {
                currPath = it.path
                verifyPath()
                if (getMediaAdapter() != null) {
                    if (getMediaAdapter()!!.getSelectedItems().size == getMediaAdapter()!!.getSelectableItemCount()) {
                        mBinding.imgDeSelectAll.visibility = View.VISIBLE
                        mBinding.imgSelectAll.visibility = View.INVISIBLE
                    } else {
                        mBinding.imgDeSelectAll.visibility = View.INVISIBLE
                        mBinding.imgSelectAll.visibility = View.VISIBLE
                    }
                    mBinding.tvDone.text = getString(R.string.hide_photo, getMediaAdapter()!!.getSelectedItems().size)
                }
            }
        }

        val layoutManager = mBinding.filepickerList.layoutManager as LinearLayoutManager
        mScrollStates[mPrevPath.trimEnd('/')] = layoutManager.onSaveInstanceState()!!


        mBinding.filepickerList.adapter = adapter

        mBinding.tvDone.text = getString(R.string.hide_photo, getMediaAdapter()!!.getSelectedItems().size)
        mBinding.filepickerBreadcrumbs.setBreadcrumb(currPath)
        mBinding.filepickerFastscroller.setViews(mBinding.filepickerList) {
            mBinding.filepickerFastscroller.updateBubbleText(sortedItems.getOrNull(it)?.getBubbleText(this, mDateFormat, mTimeFormat) ?: "")
        }

        mBinding.filepickerList.scheduleLayoutAnimation()
        layoutManager.onRestoreInstanceState(mScrollStates[currPath.trimEnd('/')])
        mBinding.filepickerList.onGlobalLayout {
            mBinding.filepickerFastscroller.setScrollToY(mBinding.filepickerList.computeVerticalScrollOffset())
        }


        mFirstUpdate = false
        mPrevPath = currPath
        mBinding.llProgress.visibility = View.GONE
        if (sortedItems.isEmpty()) {
            mBinding.llNoDataFaound.beVisible()
            mBinding.imgSelectAll.beGone()
        } else {
            mBinding.llNoDataFaound.beGone()
            mBinding.imgSelectAll.beVisibleIf(sortedItems.any { !it.isDirectory })
        }
    }

    private fun verifyPath() {
        if (isPathOnOTG(currPath)) {
            val fileDocument = getSomeDocumentFile(currPath) ?: return
            if ((pickFile && fileDocument.isFile) || (!pickFile && fileDocument.isDirectory)) {
                sendSuccess()
            }
        } else {
            val file = File(currPath)
            if ((pickFile && file.isFile) || (!pickFile && file.isDirectory)) {
                sendSuccess()
            }
        }
    }

    private fun getMediaAdapter() = mBinding.filepickerList.adapter as? CustomFilepickerItemsSelectionAdapter
    private fun sendSuccess() {
        currPath = if (currPath.length == 1) {
            currPath
        } else {
            currPath.trimEnd('/')
        }

    }

    override fun getLayoutRes(): Int? {
        return null
    }

    override fun onBackPressed() {
        val breadcrumbs = mBinding.filepickerBreadcrumbs
        if (breadcrumbs.childCount > 1) {
            breadcrumbs.removeBreadcrumb()
            currPath = breadcrumbs.getLastItem().path.trimEnd('/')
            tryUpdateItems()
        } else {
            super.onBackPressed()
        }

    }

}