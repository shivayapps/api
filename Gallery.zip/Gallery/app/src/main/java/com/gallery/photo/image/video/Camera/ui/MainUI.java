package com.gallery.photo.image.video.Camera.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Rect;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;


import com.gallery.photo.image.video.Camera.CameraActivity;
import com.gallery.photo.image.video.Camera.MyDebug;
import com.gallery.photo.image.video.Camera.PreferenceKeys;
import com.gallery.photo.image.video.Camera.cameracontroller.CameraController;
import com.gallery.photo.image.video.R;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class MainUI {
    private static final String TAG = "MainUI";
    private static final boolean cache_popup = true;
    private static final String manual_iso_value = "m";
    private static final int view_rotate_animation_duration = 100;
    private int current_orientation;
    private boolean force_destroy_popup = false;
    private final int highlightColor = Color.rgb(183, 28, 28);
    private final int highlightColorExposureUIElement = Color.rgb(244, 67, 54);
    private boolean immersive_mode;
    private int iso_button_manual_index = -1;
    private List<View> iso_buttons;
    private boolean keydown_volume_down;
    private boolean keydown_volume_up;
    private int mExposureLine = 0;
    private View mHighlightedIcon;
    private LinearLayout mHighlightedLine;
    private int mPopupIcon = 0;
    private int mPopupLine = 0;
    private boolean mSelectingExposureUIElement = false;
    private boolean mSelectingIcons = false;
    private boolean mSelectingLines = false;
    /* access modifiers changed from: private */
    public final CameraActivity main_activity;
    private volatile boolean popup_view_is_open;
    private boolean remote_control_mode;
    /* access modifiers changed from: private */
    public boolean show_gui_photo = true;
    /* access modifiers changed from: private */
    public boolean show_gui_video = true;
    public volatile int test_navigation_gap;
    public int test_saved_popup_height;
    public int test_saved_popup_width;
    private final Map<String, View> test_ui_buttons = new Hashtable();
    private View top_icon = null;
    private UIPlacement ui_placement = UIPlacement.UIPLACEMENT_RIGHT;
    private boolean view_rotate_animation;

    enum UIPlacement {
        UIPLACEMENT_RIGHT,
        UIPLACEMENT_LEFT,
        UIPLACEMENT_TOP
    }

    private void highlightExposureUILine(boolean z) {
    }

    private void highlightPopupLine(boolean z, boolean z2) {
    }

    private void resetExposureUIHighlights() {
    }

    public void audioControlStarted() {
    }

    public void audioControlStopped() {
    }

    public void destroyPopup() {
    }

    public String getEntryForAntiBanding(String str) {
        return str;
    }

    public String getEntryForNoiseReductionMode(String str) {
        return str;
    }

    public boolean isExposureUIOpen() {
        return false;
    }

    public void setPauseVideoContentDescription() {
    }

    public void setSwitchCameraContentDescription() {
    }

    public void setTakePhotoIcon() {
    }

    public void setupExposureUI() {
    }

    public void updateAutoLevelIcon() {
    }

    public void updateCycleRawIcon() {
    }

    public void updateExposureLockIcon() {
    }

    public void updateFaceDetectionIcon() {
    }

    public void updateRemoteConnectionIcon() {
    }

    public void updateStampIcon() {
    }

    public void updateStoreLocationIcon() {
    }

    public void updateTextStampIcon() {
    }

    public void updateWhiteBalanceLockIcon() {
    }

    public MainUI(CameraActivity cameraActivity) {
        Log.d(TAG, TAG);
        this.main_activity = cameraActivity;
        setSeekbarColors();
    }

    private void setSeekbarColors() {
        Log.d(TAG, "setSeekbarColors");
    }

    private void setViewRotation(View view, float f) {
        if (!this.view_rotate_animation) {
            view.setRotation(f);
        }
        float rotation = f - view.getRotation();
        if (rotation > 181.0f) {
            rotation -= 360.0f;
        } else if (rotation < -181.0f) {
            rotation += 360.0f;
        }
        view.animate().rotationBy(rotation).setDuration(100).setInterpolator(new AccelerateDecelerateInterpolator()).start();
    }

    public void layoutUI() {
        layoutUI(false);
    }

    private UIPlacement computeUIPlacement() {
        String string = PreferenceManager.getDefaultSharedPreferences(this.main_activity).getString(PreferenceKeys.UIPlacementPreferenceKey, "ui_top");
        string.hashCode();
        if (string.equals("ui_top")) {
            return UIPlacement.UIPLACEMENT_TOP;
        }
        if (!string.equals("ui_left")) {
            return UIPlacement.UIPLACEMENT_RIGHT;
        }
        return UIPlacement.UIPLACEMENT_LEFT;
    }

    private void layoutUI(boolean z) {
        Log.d(TAG, "layoutUI");
        System.currentTimeMillis();
        PreferenceManager.getDefaultSharedPreferences(this.main_activity);
        this.ui_placement = computeUIPlacement();
        Log.d(TAG, "ui_placement: " + this.ui_placement);
        int rotation = this.main_activity.getWindowManager().getDefaultDisplay().getRotation();
        int i = 0;
        if (rotation != 0) {
            if (rotation == 1) {
                i = 90;
            } else if (rotation == 2) {
                i = 180;
            } else if (rotation == 3) {
                i = 270;
            }
        }
        int i2 = (this.current_orientation + i) % 360;
        Log.d(TAG, "    current_orientation = " + this.current_orientation);
        Log.d(TAG, "    degrees = " + i);
        Log.d(TAG, "    relative_orientation = " + i2);
        int i3 = (360 - i2) % 360;
        this.main_activity.getPreview().setUIRotation(i3);
        if (this.ui_placement != UIPlacement.UIPLACEMENT_LEFT) {
            UIPlacement uIPlacement = this.ui_placement;
            UIPlacement uIPlacement2 = UIPlacement.UIPLACEMENT_TOP;
        }
        Point point = new Point();
        this.main_activity.getWindowManager().getDefaultDisplay().getSize(point);
        Math.min(point.x, point.y);
//        if (!z) {
//            this.top_icon = null;
//            View findViewById = this.main_activity.findViewById(R.id.img_camera_settings);
//            findViewById.setLayoutParams((LinearLayout.LayoutParams) findViewById.getLayoutParams());
//            float f = (float) i3;
//            setViewRotation(findViewById, f);
//            View findViewById2 = this.main_activity.findViewById(R.id.img_fileName);
//            findViewById2.setLayoutParams((LinearLayout.LayoutParams) findViewById2.getLayoutParams());
//            setViewRotation(findViewById2, f);
//            View findViewById3 = this.main_activity.findViewById(R.id.img_app_settings);
//            findViewById3.setLayoutParams((LinearLayout.LayoutParams) findViewById3.getLayoutParams());
//            setViewRotation(findViewById3, f);
//            View findViewById4 = this.main_activity.findViewById(R.id.li_ratio);
//            findViewById4.setLayoutParams((LinearLayout.LayoutParams) findViewById4.getLayoutParams());
//            setViewRotation(findViewById4, f);
//            View findViewById5 = this.main_activity.findViewById(R.id.li_grid);
//            findViewById5.setLayoutParams((LinearLayout.LayoutParams) findViewById5.getLayoutParams());
//            setViewRotation(findViewById5, f);
//            View findViewById6 = this.main_activity.findViewById(R.id.img_flash);
//            findViewById6.setLayoutParams((LinearLayout.LayoutParams) findViewById6.getLayoutParams());
//            setViewRotation(findViewById6, f);
//            View findViewById7 = this.main_activity.findViewById(R.id.li_focus);
//            findViewById7.setLayoutParams((LinearLayout.LayoutParams) findViewById7.getLayoutParams());
//            setViewRotation(findViewById7, f);
//            View findViewById8 = this.main_activity.findViewById(R.id.switch_camera);
//            findViewById8.setLayoutParams((LinearLayout.LayoutParams) findViewById8.getLayoutParams());
//            setViewRotation(findViewById8, f);
//            View findViewById9 = this.main_activity.findViewById(R.id.rel_gallery);
//            findViewById9.setLayoutParams((LinearLayout.LayoutParams) findViewById9.getLayoutParams());
//            setViewRotation(findViewById9, f);
//            View findViewById10 = this.main_activity.findViewById(R.id.rel_template);
//            findViewById10.setLayoutParams((LinearLayout.LayoutParams) findViewById10.getLayoutParams());
//            setViewRotation(findViewById10, f);
//            View findViewById11 = this.main_activity.findViewById(R.id.rel_folder);
//            findViewById11.setLayoutParams((LinearLayout.LayoutParams) findViewById11.getLayoutParams());
//            setViewRotation(findViewById11, f);
//            View findViewById12 = this.main_activity.findViewById(R.id.rel_gps);
//            findViewById12.setLayoutParams((LinearLayout.LayoutParams) findViewById12.getLayoutParams());
//            setViewRotation(findViewById12, f);
//            View findViewById13 = this.main_activity.findViewById(R.id.take_photo);
//            findViewById13.setLayoutParams((ConstraintLayout.LayoutParams) findViewById13.getLayoutParams());
//            setViewRotation(findViewById13, f);
//            setViewRotation(this.main_activity.findViewById(R.id.li_mirror), f);
//        }
    }

    public UIPlacement getUIPlacement() {
        return this.ui_placement;
    }

    public void onOrientationChanged(int i) {
        int i2;
        if (i != -1) {
            int abs = Math.abs(i - this.current_orientation);
            if (abs > 180) {
                abs = 360 - abs;
            }
            if (abs > 60 && (i2 = (((i + 45) / 90) * 90) % 360) != this.current_orientation) {
                this.current_orientation = i2;
                Log.d(TAG, "current_orientation is now: " + this.current_orientation);
                this.view_rotate_animation = true;
                layoutUI();
                this.view_rotate_animation = false;
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    public void run() {
                        Log.d(MainUI.TAG, "onOrientationChanged->postDelayed()");
                        MainUI.this.main_activity.getApplicationInterface().getDrawPreview().updateSettings();
                    }
                }, 120);
            }
        }
    }

    public boolean showExposureLockIcon() {
        if (!this.main_activity.getPreview().supportsExposureLock()) {
            return false;
        }
        return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowExposureLockPreferenceKey, false);
    }

    public boolean showWhiteBalanceLockIcon() {
        if (!this.main_activity.getPreview().supportsWhiteBalanceLock()) {
            return false;
        }
        return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowWhiteBalanceLockPreferenceKey, false);
    }

    public boolean showCycleRawIcon() {
        if (this.main_activity.getPreview().supportsRaw() && this.main_activity.getApplicationInterface().isRawAllowed(this.main_activity.getApplicationInterface().getPhotoMode())) {
            return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowCycleRawPreferenceKey, false);
        }
        return false;
    }

    public boolean showStoreLocationIcon() {
        return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowStoreLocationPreferenceKey, false);
    }

    public boolean showTextStampIcon() {
        return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowTextStampPreferenceKey, false);
    }

    public boolean showStampIcon() {
        return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowStampPreferenceKey, false);
    }

    public boolean showAutoLevelIcon() {
        if (!this.main_activity.supportsAutoStabilise()) {
            return false;
        }
        return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowAutoLevelPreferenceKey, false);
    }

    public boolean showCycleFlashIcon() {
        if (this.main_activity.getPreview().supportsFlash() && !this.main_activity.getPreview().isVideo()) {
            return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowCycleFlashPreferenceKey, false);
        }
        return false;
    }

    public boolean showFaceDetectionIcon() {
        if (!this.main_activity.getPreview().supportsFaceDetection()) {
            return false;
        }
        return PreferenceManager.getDefaultSharedPreferences(this.main_activity).getBoolean(PreferenceKeys.ShowFaceDetectionPreferenceKey, false);
    }

    public void setImmersiveMode(final boolean z) {
        Log.d(TAG, "setImmersiveMode: " + z);
        this.immersive_mode = z;
        this.main_activity.runOnUiThread(new Runnable() {
            public void run() {
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(MainUI.this.main_activity);
                int i = z ? 8 : 0;
                Log.d(MainUI.TAG, "setImmersiveMode: set visibility: " + i);
                View findViewById = MainUI.this.main_activity.findViewById(R.id.rel_gallery);
                View findViewById2 = MainUI.this.main_activity.findViewById(R.id.liMultiCamera);
                View findViewById3 = MainUI.this.main_activity.findViewById(R.id.img_gallery);
                if (MainUI.this.main_activity.getPreview().getCameraControllerManager().getNumberOfCameras() > 1) {
                    findViewById.setVisibility(z ? View.GONE : View.VISIBLE);
                }
                if (MainUI.this.main_activity.showSwitchMultiCamIcon()) {
                    findViewById2.setVisibility(z ? View.GONE : View.VISIBLE);
                }
                findViewById3.setVisibility(z ? View.GONE : View.VISIBLE);
                Log.d(MainUI.TAG, "has_zoom: " + MainUI.this.main_activity.getPreview().supportsZoom());
                if (defaultSharedPreferences.getString(PreferenceKeys.ImmersiveModePreferenceKey, "immersive_mode_low_profile").equals("immersive_mode_everything") && defaultSharedPreferences.getBoolean(PreferenceKeys.ShowTakePhotoPreferenceKey, true)) {
                    MainUI.this.main_activity.findViewById(R.id.take_photo).setVisibility(z ? View.GONE : View.VISIBLE);
                }
                if (!z) {
                    MainUI.this.showGUI();
                }
            }
        });
    }

    public boolean inImmersiveMode() {
        return this.immersive_mode;
    }

    public void showGUI(boolean z, boolean z2) {
        Log.d(TAG, "showGUI: " + z);
        Log.d(TAG, "is_video: " + z2);
        if (z2) {
            this.show_gui_video = z;
        } else {
            this.show_gui_photo = z;
        }
    }

    public void showGUI() {
        Log.d(TAG, "showGUI");
        Log.d(TAG, "show_gui_photo: " + this.show_gui_photo);
        Log.d(TAG, "show_gui_video: " + this.show_gui_video);
        if (!inImmersiveMode()) {
            if ((this.show_gui_photo || this.show_gui_video) && this.main_activity.usingKitKatImmersiveMode()) {
                this.main_activity.initImmersiveMode();
            }
            this.main_activity.runOnUiThread(new Runnable() {
                public void run() {
                    boolean isRecording = MainUI.this.main_activity.getApplicationInterface().getGyroSensor().isRecording();
                    int i = 8;
                    if (!isRecording && MainUI.this.show_gui_photo && MainUI.this.show_gui_video) {
                        i = 0;
                    }
                    if (!isRecording) {
                        boolean access$100 = MainUI.this.show_gui_photo;
                    }
                    View findViewById = MainUI.this.main_activity.findViewById(R.id.rel_gallery);
                    View findViewById2 = MainUI.this.main_activity.findViewById(R.id.imgMultiCamera);
                    if (MainUI.this.main_activity.getPreview().getCameraControllerManager().getNumberOfCameras() > 1) {
                        findViewById.setVisibility(i);
                    }
                    if (MainUI.this.main_activity.showSwitchMultiCamIcon()) {
                        findViewById2.setVisibility(i);
                    }
                    if (!MainUI.this.show_gui_photo || !MainUI.this.show_gui_video) {
                        MainUI.this.closePopup();
                    }
                    if (MainUI.this.show_gui_photo && MainUI.this.show_gui_video) {
                        MainUI.this.layoutUI();
                    }
                }
            });
        }
    }

    public void updateCycleFlashIcon() {
        // n.b., read from preview rather than saved application preference - so the icon updates correctly when in flash
        // auto mode, but user switches to manual ISO where flash auto isn't supported
        String flash_value = main_activity.getPreview().getCurrentFlashValue();
        if (flash_value != null) {
            ImageView view = main_activity.findViewById(R.id.img_flash);
            switch (flash_value) {
                case "flash_off":
                    view.setImageResource(R.drawable.ic_new_camera_flash_off);
                    break;
                case "flash_auto":
                case "flash_frontscreen_auto":
                    view.setImageResource(R.drawable.ic_new_camera_flash_auto);
                    break;
                case "flash_on":
                case "flash_frontscreen_on":
                    view.setImageResource(R.drawable.ic_new_camera_flash_on);
                    break;
                case "flash_torch":
                case "flash_frontscreen_torch":
                    view.setImageResource(R.drawable.ic_new_camera_tourch);
                    break;
                case "flash_red_eye":
                    view.setImageResource(R.drawable.ic_new_camera_red_eyes);
                    break;
                default:
                    // just in case??
                    Log.e(TAG, "unknown flash value " + flash_value);
                    view.setImageResource(R.drawable.ic_new_camera_flash_off);
                    break;
            }
        } else {
            ImageView view = main_activity.findViewById(R.id.img_flash);
            view.setImageResource(R.drawable.ic_new_camera_flash_off);
        }
    }

    public void updateCycleFlashIcon_() {
        String flashPref = this.main_activity.getApplicationInterface().getFlashPref();
        if (flashPref != null) {
            ImageView imageView = (ImageView) this.main_activity.findViewById(R.id.img_flash);
            flashPref.hashCode();
            char c = 65535;
            switch (flashPref.hashCode()) {
                case -1524012984:
                    if (flashPref.equals("flash_frontscreen_auto")) {
                        c = 0;
                        break;
                    }
                    break;
                case -1195303778:
                    if (flashPref.equals("flash_auto")) {
                        c = 1;
                        break;
                    }
                    break;
                case -1146923872:
                    if (flashPref.equals("flash_off")) {
                        c = 2;
                        break;
                    }
                    break;
                case -10523976:
                    if (flashPref.equals("flash_frontscreen_on")) {
                        c = 3;
                        break;
                    }
                    break;
                case 17603715:
                    if (flashPref.equals("flash_frontscreen_torch")) {
                        c = 4;
                        break;
                    }
                    break;
                case 1617654509:
                    if (flashPref.equals("flash_torch")) {
                        c = 5;
                        break;
                    }
                    break;
                case 1625570446:
                    if (flashPref.equals("flash_on")) {
                        c = 6;
                        break;
                    }
                    break;
            }
            switch (c) {
                case 0:
                case 1:
//                    imageView.setImageResource(R.drawable.ic_auto);
                    return;
                case 2:
//                    imageView.setImageResource(R.drawable.ic_flash_off);
                    return;
                case 3:
                case 6:
//                    imageView.setImageResource(R.drawable.ic_flash);
                    return;
                case 4:
                case 5:
//                    imageView.setImageResource(R.drawable.ic_flash);
                    return;
                default:
                    return;
            }
        }
    }

    public void updateOnScreenIcons() {
        Log.d(TAG, "updateOnScreenIcons");
        updateExposureLockIcon();
        updateWhiteBalanceLockIcon();
        updateCycleRawIcon();
        updateStoreLocationIcon();
        updateTextStampIcon();
        updateStampIcon();
        updateAutoLevelIcon();
        updateCycleFlashIcon();
        updateFaceDetectionIcon();
    }

    public void toggleExposureUI() {
        Log.d(TAG, "toggleExposureUI");
        closePopup();
        this.mSelectingExposureUIElement = false;
        if (!isExposureUIOpen() && this.main_activity.getPreview().getCameraController() != null) {
            setupExposureUI();
            if (this.main_activity.getBluetoothRemoteControl().remoteEnabled()) {
                initRemoteControlForExposureUI();
            }
        }
    }

    private void initRemoteControlForExposureUI() {
        Log.d(TAG, "initRemoteControlForExposureUI");
        if (isExposureUIOpen()) {
            this.remote_control_mode = true;
            this.mExposureLine = 0;
            highlightExposureUILine(true);
        }
    }

    private void clearRemoteControlForExposureUI() {
        Log.d(TAG, "clearRemoteControlForExposureUI");
        if (isExposureUIOpen() && this.remote_control_mode) {
            this.remote_control_mode = false;
            resetExposureUIHighlights();
        }
    }

    private void nextExposureUILine() {
        this.mExposureLine++;
        highlightExposureUILine(true);
    }

    private void previousExposureUILine() {
        this.mExposureLine--;
        highlightExposureUILine(false);
    }

    private void nextExposureUIItem() {
        Log.d(TAG, "nextExposureUIItem");
        if (this.mExposureLine == 0) {
            nextIsoItem(false);
        }
    }

    private void previousExposureUIItem() {
        Log.d(TAG, "previousExposureUIItem");
        if (this.mExposureLine == 0) {
            nextIsoItem(true);
        }
    }

    private void nextIsoItem(boolean previous) {
        if (MyDebug.LOG)
            Log.d(TAG, "nextIsoItem: " + previous);
        // Find current ISO
        final SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(main_activity);
        String current_iso = sharedPreferences.getString(PreferenceKeys.ISOPreferenceKey, CameraController.ISO_DEFAULT);
        int count = iso_buttons.size();
        int step = previous ? -1 : 1;
        boolean found = false;
        for (int i = 0; i < count; i++) {
            Button button = (Button) iso_buttons.get(i);
            String button_text = "" + button.getText();
            if (button_text.contains(current_iso)) {
                found = true;
                // Select next one, unless it's "Manual", which we skip since
                // it's not practical in remote mode.
                Button nextButton = (Button) iso_buttons.get((i + count + step) % count);
                String nextButton_text = "" + nextButton.getText();
                if (nextButton_text.contains("m")) {
                    nextButton = (Button) iso_buttons.get((i + count + 2 * step) % count);
                }
                nextButton.callOnClick();
                break;
            }
        }
        if (!found) {
            // For instance, we are in ISO manual mode and "M" is selected. default
            // back to "Auto" to avoid being stuck since we're with a remote control
            iso_buttons.get(0).callOnClick();
        }
    }

    private void selectExposureUILine() {
        Log.d(TAG, "selectExposureUILine");
        if (isExposureUIOpen()) {
            int i = this.mExposureLine;
            if (i == 0) {
                String string = PreferenceManager.getDefaultSharedPreferences(this.main_activity).getString(PreferenceKeys.ISOPreferenceKey, "auto");
                Button button = null;
                Iterator<View> it = this.iso_buttons.iterator();
                boolean z = false;
                while (it.hasNext()) {
                    Button button2 = (Button) it.next();
                    String str = "" + button2.getText();
                    if (str.contains(string)) {
                        z = true;
                    } else {
                        if (str.contains(manual_iso_value)) {
                            button = button2;
                        }
                        button2.setBackgroundColor(0);
                    }
                }
                if (!z && button != null) {
                    button.setBackgroundColor(this.highlightColorExposureUIElement);
                }
                this.mSelectingExposureUIElement = true;
            } else if (i == 1) {
                this.mSelectingExposureUIElement = true;
            } else if (i == 2) {
                this.mSelectingExposureUIElement = true;
            } else if (i == 3) {
                this.mSelectingExposureUIElement = true;
            } else if (i == 4) {
                this.mSelectingExposureUIElement = true;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public int getMaxHeightDp(boolean z) {
        Display defaultDisplay = this.main_activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        defaultDisplay.getMetrics(displayMetrics);
        int min = (int) (((float) Math.min(displayMetrics.widthPixels, displayMetrics.heightPixels)) / this.main_activity.getResources().getDisplayMetrics().density);
        Log.d(TAG, "display size: " + displayMetrics.widthPixels + " x " + displayMetrics.heightPixels);
        StringBuilder sb = new StringBuilder();
        sb.append("dpHeight: ");
        sb.append(min);
        Log.d(TAG, sb.toString());
        return min - (z ? 120 : 50);
    }

    public boolean isSelectingExposureUIElement() {
        Log.d(TAG, "isSelectingExposureUIElement returns:" + this.mSelectingExposureUIElement);
        return this.mSelectingExposureUIElement;
    }

    public boolean processRemoteUpButton() {
        Log.d(TAG, "processRemoteUpButton");
        if (popupIsOpen()) {
            if (selectingIcons()) {
                previousPopupIcon();
                return true;
            } else if (!selectingLines()) {
                return true;
            } else {
                previousPopupLine();
                return true;
            }
        } else if (!isExposureUIOpen()) {
            return false;
        } else {
            if (isSelectingExposureUIElement()) {
                nextExposureUIItem();
                return true;
            }
            previousExposureUILine();
            return true;
        }
    }

    public boolean processRemoteDownButton() {
        Log.d(TAG, "processRemoteDownButton");
        if (popupIsOpen()) {
            if (selectingIcons()) {
                nextPopupIcon();
                return true;
            } else if (!selectingLines()) {
                return true;
            } else {
                nextPopupLine();
                return true;
            }
        } else if (!isExposureUIOpen()) {
            return false;
        } else {
            if (isSelectingExposureUIElement()) {
                previousExposureUIItem();
                return true;
            }
            nextExposureUILine();
            return true;
        }
    }

    public void updateSelectedISOButton() {
        Log.d(TAG, "updateSelectedISOButton");
        if (this.main_activity.getPreview().supportsISORange() && isExposureUIOpen()) {
            String string = PreferenceManager.getDefaultSharedPreferences(this.main_activity).getString(PreferenceKeys.ISOPreferenceKey, "auto");
            Log.d(TAG, "current_iso: " + string);
            boolean z = false;
            Iterator<View> it = this.iso_buttons.iterator();
            while (it.hasNext()) {
                Button button = (Button) it.next();
                Log.d(TAG, "button: " + button.getText());
                if (("" + button.getText()).contains(string)) {
                    z = true;
                }
            }
            if (!z && !string.equals("auto")) {
                Log.d(TAG, "must be manual");
                int i = this.iso_button_manual_index;
                if (i >= 0 && i < this.iso_buttons.size()) {
                    Button button2 = (Button) this.iso_buttons.get(this.iso_button_manual_index);
                }
            }
        }
    }

    public void setSeekbarZoom(int i) {
        Log.d(TAG, "setSeekbarZoom: " + i);
        SeekBar seekBar = (SeekBar) this.main_activity.findViewById(R.id.zoom_seekbar);
        Log.d(TAG, "progress was: " + seekBar.getProgress());
        seekBar.setProgress(this.main_activity.getPreview().getMaxZoom() - i);
        Log.d(TAG, "progress is now: " + seekBar.getProgress());
    }

    public void changeSeekbar(int i, int i2) {
        Log.d(TAG, "changeSeekbar: " + i2);
        SeekBar seekBar = (SeekBar) this.main_activity.findViewById(i);
        int progress = seekBar.getProgress();
        int i3 = i2 + progress;
        if (i3 < 0) {
            i3 = 0;
        } else if (i3 > seekBar.getMax()) {
            i3 = seekBar.getMax();
        }
        Log.d(TAG, "value: " + progress);
        Log.d(TAG, "new_value: " + i3);
        Log.d(TAG, "max: " + seekBar.getMax());
        if (i3 != progress) {
            seekBar.setProgress(i3);
        }
    }

    public void closePopup() {
        Log.d(TAG, "close popup");
        if (popupIsOpen()) {
            clearRemoteControlForPopup();
            clearSelectionState();
            this.popup_view_is_open = false;
            if (this.force_destroy_popup) {
                destroyPopup();
            }
            this.main_activity.initImmersiveMode();
        }
    }

    public boolean popupIsOpen() {
        return this.popup_view_is_open;
    }

    public boolean selectingIcons() {
        return this.mSelectingIcons;
    }

    public boolean selectingLines() {
        return this.mSelectingLines;
    }

    private void highlightPopupIcon(boolean z, boolean z2) {
        Log.d(TAG, "highlightPopupIcon");
        Log.d(TAG, "highlight: " + z);
        Log.d(TAG, "goLeft: " + z2);
        if (!popupIsOpen()) {
            clearSelectionState();
            return;
        }
        highlightPopupLine(false, false);
        int childCount = this.mHighlightedLine.getChildCount();
        boolean z3 = false;
        while (!z3) {
            int i = (this.mPopupIcon + childCount) % childCount;
            this.mPopupIcon = i;
            View childAt = this.mHighlightedLine.getChildAt(i);
            Log.d(TAG, "row: " + this.mPopupIcon + " view: " + childAt);
            int i2 = 1;
            if ((childAt instanceof ImageButton) || (childAt instanceof Button)) {
                if (z) {
                    childAt.setBackgroundColor(this.highlightColor);
                    this.mHighlightedIcon = childAt;
                    this.mSelectingIcons = true;
                } else {
                    childAt.setBackgroundColor(0);
                }
                Log.d(TAG, "found icon at row: " + this.mPopupIcon);
                z3 = true;
            } else {
                int i3 = this.mPopupIcon;
                if (z2) {
                    i2 = -1;
                }
                this.mPopupIcon = i3 + i2;
            }
        }
    }

    private void nextPopupLine() {
        highlightPopupLine(false, false);
        this.mPopupLine++;
        highlightPopupLine(true, false);
    }

    private void previousPopupLine() {
        highlightPopupLine(false, true);
        this.mPopupLine--;
        highlightPopupLine(true, true);
    }

    private void nextPopupIcon() {
        highlightPopupIcon(false, false);
        this.mPopupIcon++;
        highlightPopupIcon(true, false);
    }

    private void previousPopupIcon() {
        highlightPopupIcon(false, true);
        this.mPopupIcon--;
        highlightPopupIcon(true, true);
    }

    private void clickSelectedIcon() {
        Log.d(TAG, "clickSelectedIcon: " + this.mHighlightedIcon);
        View view = this.mHighlightedIcon;
        if (view != null) {
            view.callOnClick();
        }
    }

    private void clearSelectionState() {
        Log.d(TAG, "clearSelectionState");
        this.mPopupLine = 0;
        this.mPopupIcon = 0;
        this.mSelectingIcons = false;
        this.mSelectingLines = false;
        this.mHighlightedIcon = null;
        this.mHighlightedLine = null;
    }

    public void togglePopupSettings() {
        this.main_activity.getPreview().cancelTimer();
        this.main_activity.stopAudioListeners();
        long currentTimeMillis = System.currentTimeMillis();
        this.popup_view_is_open = true;
        if (this.main_activity.getBluetoothRemoteControl().remoteEnabled()) {
            initRemoteControlForPopup();
        }
        Log.d(TAG, "time to create popup: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    private void initRemoteControlForPopup() {
        Log.d(TAG, "initRemoteControlForPopup");
        if (popupIsOpen()) {
            clearSelectionState();
            this.remote_control_mode = true;
            this.mSelectingLines = true;
            highlightPopupLine(true, false);
        }
    }

    private void clearRemoteControlForPopup() {
        Log.d(TAG, "clearRemoteControlForPopup");
        if (popupIsOpen() && this.remote_control_mode) {
            this.remote_control_mode = false;
            new Rect();
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (MyDebug.LOG)
            Log.d(TAG, "onKeyDown: " + keyCode);
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_UP:
            case KeyEvent.KEYCODE_VOLUME_DOWN:
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS: // media codes are for "selfie sticks" buttons
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_STOP: {
                if (keyCode == KeyEvent.KEYCODE_VOLUME_UP)
                    keydown_volume_up = true;
                else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
                    keydown_volume_down = true;

                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(main_activity);
                String volume_keys = sharedPreferences.getString(PreferenceKeys.VolumeKeysPreferenceKey, "volume_take_photo");

                if ((keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS
                        || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                        || keyCode == KeyEvent.KEYCODE_MEDIA_STOP)
                        && !(volume_keys.equals("volume_take_photo"))) {
                    AudioManager audioManager = (AudioManager) main_activity.getSystemService(Context.AUDIO_SERVICE);
                    if (audioManager == null) break;
                    if (!audioManager.isWiredHeadsetOn())
                        break; // isWiredHeadsetOn() is deprecated, but comment says "Use only to check is a headset is connected or not."
                }

                switch (volume_keys) {
                    case "volume_take_photo":
                        main_activity.takePicture(false);
                        return true;
                    case "volume_focus":
                        if (keydown_volume_up && keydown_volume_down) {
                            if (MyDebug.LOG)
                                Log.d(TAG, "take photo rather than focus, as both volume keys are down");
                            main_activity.takePicture(false);
                        } else if (main_activity.getPreview().getCurrentFocusValue() != null && main_activity.getPreview().getCurrentFocusValue().equals("focus_mode_manual2")) {
                            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP)
                                main_activity.changeFocusDistance(-1, false);
                            else
                                main_activity.changeFocusDistance(1, false);
                        } else {
                            // important not to repeatedly request focus, even though main_activity.getPreview().requestAutoFocus() will cancel, as causes problem if key is held down (e.g., flash gets stuck on)
                            // also check DownTime vs EventTime to prevent repeated focusing whilst the key is held down
                            if (event.getDownTime() == event.getEventTime() && !main_activity.getPreview().isFocusWaiting()) {
                                if (MyDebug.LOG)
                                    Log.d(TAG, "request focus due to volume key");
                                main_activity.getPreview().requestAutoFocus();
                            }
                        }
                        return true;
                    case "volume_zoom":
                        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP)
                            main_activity.zoomIn();
                        else
                            main_activity.zoomOut();
                        return true;
                    case "volume_exposure":
                        if (main_activity.getPreview().getCameraController() != null) {
                            String value = sharedPreferences.getString(PreferenceKeys.ISOPreferenceKey, CameraController.ISO_DEFAULT);
                            boolean manual_iso = !value.equals(CameraController.ISO_DEFAULT);
                            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                                if (manual_iso) {
                                    if (main_activity.getPreview().supportsISORange())
                                        main_activity.changeISO(1);
                                } else
                                    main_activity.changeExposure(1);
                            } else {
                                if (manual_iso) {
                                    if (main_activity.getPreview().supportsISORange())
                                        main_activity.changeISO(-1);
                                } else
                                    main_activity.changeExposure(-1);
                            }
                        }
                        return true;
                    case "volume_auto_stabilise":
                        if (main_activity.supportsAutoStabilise()) {
                            boolean auto_stabilise = sharedPreferences.getBoolean(PreferenceKeys.AutoStabilisePreferenceKey, false);
                            auto_stabilise = !auto_stabilise;
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putBoolean(PreferenceKeys.AutoStabilisePreferenceKey, auto_stabilise);
                            editor.apply();
                            String message = main_activity.getResources().getString(R.string.preference_auto_stabilise) + ": " + main_activity.getResources().getString(auto_stabilise ? R.string.on : R.string.off);
                            main_activity.getPreview().showToast(main_activity.getChangedAutoStabiliseToastBoxer(), message);
                            main_activity.getApplicationInterface().getDrawPreview().updateSettings(); // because we cache the auto-stabilise setting
                            this.destroyPopup(); // need to recreate popup in order to update the auto-level checkbox
                        } else {
                            main_activity.getPreview().showToast(main_activity.getChangedAutoStabiliseToastBoxer(), R.string.auto_stabilise_not_supported);
                        }
                        return true;
                    case "volume_really_nothing":
                        // do nothing, but still return true so we don't change volume either
                        return true;
                }
                // else do nothing here, but still allow changing of volume (i.e., the default behaviour)
                break;
            }
            case KeyEvent.KEYCODE_MENU: {
                // needed to support hardware menu button
                // tested successfully on Samsung S3 (via RTL)
                // see http://stackoverflow.com/questions/8264611/how-to-detect-when-user-presses-menu-key-on-their-android-device
//                main_activity.openSettings();
                return true;
            }
            case KeyEvent.KEYCODE_CAMERA: {
                if (event.getRepeatCount() == 0) {
                    main_activity.takePicture(false);
                    return true;
                }
            }
            case KeyEvent.KEYCODE_FOCUS: {
                // important not to repeatedly request focus, even though main_activity.getPreview().requestAutoFocus() will cancel - causes problem with hardware camera key where a half-press means to focus
                // also check DownTime vs EventTime to prevent repeated focusing whilst the key is held down - see https://sourceforge.net/p/opencamera/tickets/174/ ,
                // or same issue above for volume key focus
                if (event.getDownTime() == event.getEventTime() && !main_activity.getPreview().isFocusWaiting()) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "request focus due to focus key");
                    main_activity.getPreview().requestAutoFocus();
                }
                return true;
            }
            case KeyEvent.KEYCODE_ZOOM_IN:
            case KeyEvent.KEYCODE_PLUS:
            case KeyEvent.KEYCODE_NUMPAD_ADD: {
                main_activity.zoomIn();
                return true;
            }
            case KeyEvent.KEYCODE_ZOOM_OUT:
            case KeyEvent.KEYCODE_MINUS:
            case KeyEvent.KEYCODE_NUMPAD_SUBTRACT: {
                main_activity.zoomOut();
                return true;
            }
            case KeyEvent.KEYCODE_SPACE:
            case KeyEvent.KEYCODE_NUMPAD_5: {
                if (isExposureUIOpen() && remote_control_mode) {
                    commandMenuExposure();
                    return true;
                } else if (popupIsOpen() && remote_control_mode) {
                    commandMenuPopup();
                    return true;
                } else if (event.getRepeatCount() == 0) {
                    main_activity.takePicture(false);
                    return true;
                }
                break;
            }
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_NUMPAD_8:
                //case KeyEvent.KEYCODE_VOLUME_UP: // test
                if (!remote_control_mode) {
                    if (popupIsOpen()) {
                        initRemoteControlForPopup();
                        return true;
                    } else if (isExposureUIOpen()) {
                        initRemoteControlForExposureUI();
                        return true;
                    }
                } else if (processRemoteUpButton())
                    return true;
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_NUMPAD_2:
                //case KeyEvent.KEYCODE_VOLUME_DOWN: // test
                if (!remote_control_mode) {
                    if (popupIsOpen()) {
                        initRemoteControlForPopup();
                        return true;
                    } else if (isExposureUIOpen()) {
                        initRemoteControlForExposureUI();
                        return true;
                    }
                } else if (processRemoteDownButton())
                    return true;
                break;
            case KeyEvent.KEYCODE_FUNCTION:
            case KeyEvent.KEYCODE_NUMPAD_MULTIPLY:
                togglePopupSettings();
                break;
            case KeyEvent.KEYCODE_SLASH:
            case KeyEvent.KEYCODE_NUMPAD_DIVIDE:
                toggleExposureUI();
                break;
        }
        return false;
    }

    public void onKeyUp(int i, KeyEvent keyEvent) {
        Log.d(TAG, "onKeyUp: " + i);
        if (i == 24) {
            this.keydown_volume_up = false;
        } else if (i == 25) {
            this.keydown_volume_down = false;
        }
    }

    public void commandMenuExposure() {
        Log.d(TAG, "commandMenuExposure");
        if (!isExposureUIOpen()) {
            return;
        }
        if (isSelectingExposureUIElement()) {
            toggleExposureUI();
        } else {
            selectExposureUILine();
        }
    }

    public void commandMenuPopup() {
        Log.d(TAG, "commandMenuPopup");
        if (!popupIsOpen()) {
            return;
        }
        if (selectingIcons()) {
            clickSelectedIcon();
        } else {
            highlightPopupIcon(true, false);
        }
    }

    public AlertDialog showInfoDialog(int i, int i2, final String str) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this.main_activity);
        builder.setTitle(i);
        if (i2 != 0) {
            builder.setMessage(i2);
        }
        builder.setPositiveButton("OK", (DialogInterface.OnClickListener) null);
        builder.setNegativeButton(R.string.dont_show_again, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                Log.d(MainUI.TAG, "user clicked dont_show_again for info dialog");
                SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(MainUI.this.main_activity).edit();
                edit.putBoolean(str, true);
                edit.apply();
            }
        });
        this.main_activity.showPreview(false);
        this.main_activity.setWindowFlagsForSettings(false);
        AlertDialog create = builder.create();
        create.setOnDismissListener(new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface dialogInterface) {
                Log.d(MainUI.TAG, "info dialog dismissed");
                MainUI.this.main_activity.setWindowFlagsForCamera();
                MainUI.this.main_activity.showPreview(true);
            }
        });
        this.main_activity.showAlert(create);
        return create;
    }

    /**
     * Returns a (possibly translated) user readable string for a white balance preference value.
     * If the value is not recognised (this can happen for the old Camera API, some devices can
     * have device-specific options), then the received value is returned.
     */
    public String getEntryForWhiteBalance(String value) {
        int id = -1;
        switch (value) {
            case CameraController.WHITE_BALANCE_DEFAULT:
                id = R.string.white_balance_auto;
                break;
            case "cloudy-daylight":
                id = R.string.white_balance_cloudy;
                break;
            case "daylight":
                id = R.string.white_balance_daylight;
                break;
            case "fluorescent":
                id = R.string.white_balance_fluorescent;
                break;
            case "incandescent":
                id = R.string.white_balance_incandescent;
                break;
            case "shade":
                id = R.string.white_balance_shade;
                break;
            case "twilight":
                id = R.string.white_balance_twilight;
                break;
            case "warm-fluorescent":
                id = R.string.white_balance_warm;
                break;
            case "manual":
                id = R.string.white_balance_manual;
                break;
            default:
                break;
        }
        String entry;
        if (id != -1) {
            entry = main_activity.getResources().getString(id);
        } else {
            entry = value;
        }
        return entry;
    }

    /**
     * Returns a (possibly translated) user readable string for a scene mode preference value.
     * If the value is not recognised (this can happen for the old Camera API, some devices can
     * have device-specific options), then the received value is returned.
     */
    public String getEntryForSceneMode(String value) {
        int id = -1;
        switch (value) {
            case "action":
                id = R.string.scene_mode_action;
                break;
            case "barcode":
                id = R.string.scene_mode_barcode;
                break;
            case "beach":
                id = R.string.scene_mode_beach;
                break;
            case "candlelight":
                id = R.string.scene_mode_candlelight;
                break;
            case CameraController.SCENE_MODE_DEFAULT:
                id = R.string.scene_mode_auto;
                break;
            case "fireworks":
                id = R.string.scene_mode_fireworks;
                break;
            case "landscape":
                id = R.string.scene_mode_landscape;
                break;
            case "night":
                id = R.string.scene_mode_night;
                break;
            case "night-portrait":
                id = R.string.scene_mode_night_portrait;
                break;
            case "party":
                id = R.string.scene_mode_party;
                break;
            case "portrait":
                id = R.string.scene_mode_portrait;
                break;
            case "snow":
                id = R.string.scene_mode_snow;
                break;
            case "sports":
                id = R.string.scene_mode_sports;
                break;
            case "steadyphoto":
                id = R.string.scene_mode_steady_photo;
                break;
            case "sunset":
                id = R.string.scene_mode_sunset;
                break;
            case "theatre":
                id = R.string.scene_mode_theatre;
                break;
            default:
                break;
        }
        String entry;
        if (id != -1) {
            entry = main_activity.getResources().getString(id);
        } else {
            entry = value;
        }
        return entry;
    }

    /**
     * Returns a (possibly translated) user readable string for a color effect preference value.
     * If the value is not recognised (this can happen for the old Camera API, some devices can
     * have device-specific options), then the received value is returned.
     */
    public String getEntryForColorEffect(String value) {
        int id = -1;
        switch (value) {
            case "aqua":
                id = R.string.color_effect_aqua;
                break;
            case "blackboard":
                id = R.string.color_effect_blackboard;
                break;
            case "mono":
                id = R.string.color_effect_mono;
                break;
            case "negative":
                id = R.string.color_effect_negative;
                break;
            case CameraController.COLOR_EFFECT_DEFAULT:
                id = R.string.color_effect_none;
                break;
            case "posterize":
                id = R.string.color_effect_posterize;
                break;
            case "sepia":
                id = R.string.color_effect_sepia;
                break;
            case "solarize":
                id = R.string.color_effect_solarize;
                break;
            case "whiteboard":
                id = R.string.color_effect_whiteboard;
                break;
            default:
                break;
        }
        String entry;
        if (id != -1) {
            entry = main_activity.getResources().getString(id);
        } else {
            entry = value;
        }
        return entry;
    }

    /* access modifiers changed from: package-private */
    public View getTopIcon() {
        return this.top_icon;
    }

    public View getUIButton(String str) {
        Log.d(TAG, "getPopupButton(" + str + "): " + this.test_ui_buttons.get(str));
        StringBuilder sb = new StringBuilder();
        sb.append("this: ");
        sb.append(this);
        Log.d(TAG, sb.toString());
        Log.d(TAG, "popup_buttons: " + this.test_ui_buttons);
        return this.test_ui_buttons.get(str);
    }

    /* access modifiers changed from: package-private */
    public Map<String, View> getTestUIButtonsMap() {
        return this.test_ui_buttons;
    }

    public boolean testGetRemoteControlMode() {
        return this.remote_control_mode;
    }

    public int testGetPopupLine() {
        return this.mPopupLine;
    }

    public int testGetPopupIcon() {
        return this.mPopupIcon;
    }

    public int testGetExposureLine() {
        return this.mExposureLine;
    }
}
