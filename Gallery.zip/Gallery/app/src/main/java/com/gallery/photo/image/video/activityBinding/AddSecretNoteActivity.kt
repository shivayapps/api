package com.gallery.photo.image.video.activityBinding

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.view.View
import com.example.app.ads.helper.GiftIconHelper
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.utilities.addEvent


import com.gallery.photo.image.video.databinding.ActivityAddSecretNoteBinding
import com.gallery.photo.image.video.dialog.DeleteWithRememberDialog
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.extensions.noteDao
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.models.Note
import com.gallery.photo.image.video.utilities.isInterstitialShown
import com.gallery.photo.image.video.utilities.newNoteSave
import com.gallery.photo.image.video.extensions.hideKeyboard
import com.gallery.photo.image.video.extensions.toast
import com.gallery.photo.image.video.helpers.ensureBackgroundThread

const val ARG_NOTE_DATA = "NoteData"

class AddSecretNoteActivity : BaseBindingActivity<ActivityAddSecretNoteBinding>() {
    var note: Note? = null
    var isNoteSaveClicked = false
    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        intent.apply {
            note = getSerializableExtra(ARG_NOTE_DATA) as Note?
        }
        if (note != null) {
            mBinding.etNoteTitle.setText(note!!.title)
            mBinding.etNoteDetail.setText(note!!.description)
            mBinding.tvDone.text = getString(R.string.label_update_notes)
        } else {
            mBinding.tvDone.text = getString(R.string.label_save_notes)
        }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            InterstitialAdHelper.loadInterstitialAd(fContext = this)
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = mBinding.giftLayout.giftAdIcon,
                fivBlastIcon = mBinding.giftLayout.giftBlastAdIcon
            )
        }
    }

    override fun initActions() {
        mBinding.llSaveNote.setOnClickListener(this)
        mBinding.imgBack.setOnClickListener(this)
    }

    override fun setBinding(): ActivityAddSecretNoteBinding {
        return ActivityAddSecretNoteBinding.inflate(inflater)
    }

    companion object {
        fun newIntent(mContext: Context): Intent {
            return Intent(mContext, AddSecretNoteActivity::class.java)
        }

        fun newIntent(mContext: Context, note: Note): Intent {
            var intent = Intent(mContext, AddSecretNoteActivity::class.java)
            intent.putExtra(ARG_NOTE_DATA, note)
            return intent
        }

        var isNeedToRefresh = false

    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.imgBack -> {
                onBackPressed()
            }
            R.id.llSaveNote -> {
                hideKeyboard()
                when {
                    mBinding.etNoteTitle.text!!.trim().isNullOrEmpty() -> {
                        toast(getString(R.string.error_enter_note_title))
                    }
                    mBinding.etNoteDetail.text!!.trim().isNullOrEmpty() -> {
                        toast(getString(R.string.error_enter_note_description))
                    }
                    else -> {
                        if (!isNoteSaveClicked) {
                            isNoteSaveClicked = true
                            ensureBackgroundThread {
                                if (note != null) {
                                    noteDao.update(
                                        Note(
                                            note!!.id,
                                            mBinding.etNoteTitle.text.toString(),
                                            mBinding.etNoteDetail.text.toString(),
                                            System.currentTimeMillis(),
                                            VaultFragment.isFakeVaultOpen,
                                            0L
                                        )
                                    )
                                    runOnUiThread {
                                        toast(getString(R.string.msg_note_update_successfully))
                                        SecretNotesActivity.isNeedToRefersh = true
                                        finish()
                                    }
                                } else {
                                    noteDao.add(Note(null, mBinding.etNoteTitle.text.toString(), mBinding.etNoteDetail.text.toString(), System.currentTimeMillis(), VaultFragment.isFakeVaultOpen, 0L))
                                    runOnUiThread {
                                        toast(getString(R.string.msg_note_add_successfully))
                                        addEvent(newNoteSave)
                                        SecretNotesActivity.isNeedToRefersh = true
                                        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
                                            isShowInterstitialAd {
                                                isInterstitialShown = false
                                                finish()
                                            }
                                        } else {
                                            isInterstitialShown = false
                                            finish()
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onBackPressed() {
        if (note != null) {
            if (mBinding.etNoteTitle.text.toString() != note!!.title || mBinding.etNoteDetail.text.toString() != note!!.description) {
                DeleteWithRememberDialog(this, getString(R.string.msg_do_you_want_to_save_changes)) {
                    if (it) {
                        when {
                            mBinding.etNoteTitle.text!!.trim().isNullOrEmpty() -> {
                                toast(getString(R.string.error_enter_note_title))
                            }
                            mBinding.etNoteDetail.text!!.trim().isNullOrEmpty() -> {
                                toast(getString(R.string.error_enter_note_description))
                            }
                            else -> {
                                ensureBackgroundThread {
                                    if (note != null) {
                                        noteDao.update(
                                            Note(
                                                note!!.id,
                                                mBinding.etNoteTitle.text.toString(),
                                                mBinding.etNoteDetail.text.toString(),
                                                System.currentTimeMillis(),
                                                VaultFragment.isFakeVaultOpen,
                                                0L
                                            )
                                        )
                                        runOnUiThread {
                                            toast(getString(R.string.msg_note_update_successfully))
                                            SecretNotesActivity.isNeedToRefersh = true
                                            finish()
                                        }
                                    }
                                }
                            }
                        }

                    } else {
                        super.onBackPressed()
                    }
                }
            } else {
                super.onBackPressed()
            }
        } else {
            super.onBackPressed()
        }

    }

}