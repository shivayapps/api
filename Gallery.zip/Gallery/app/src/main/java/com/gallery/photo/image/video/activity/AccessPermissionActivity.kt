package com.gallery.photo.image.video.activity

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.util.Log
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activityBinding.BaseBindingActivity
import com.gallery.photo.image.video.databinding.ActivityAccessPermissionBinding
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.extensions.baseConfig

class AccessPermissionActivity : BaseBindingActivity<ActivityAccessPermissionBinding>() {

    private fun callNextActivity() {
        if (baseConfig.appLanguage.isEmpty()) {
            startActivity(Intent(this, ChooseAppLanguageActivity::class.java))
        } else {
            startActivity(MainActivity.newIntent(this))
        }
    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        mBinding.llGrantPermission.setOnClickListener {
            if (!checkPermissionabove11()) {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                try {
                    launchActivityForResult(intent, REQ_CODE_FOR_MANAGE_STORAGE)
                } catch (e: Exception) {
                }
            } else {
                callNextActivity()
            }
        }
    }

    override fun initActions() {

    }

    override fun getAppIconIDs() = arrayListOf(

        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)
    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_CODE_FOR_MANAGE_STORAGE -> {
                Log.d(TAG, "fromActivityResult: ")
                if (requestCode == REQ_CODE_FOR_MANAGE_STORAGE &&  checkPermissionabove11()) {
                    callNextActivity()
                }
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finishAffinity()
    }

    override fun setBinding(): ActivityAccessPermissionBinding {
        return ActivityAccessPermissionBinding.inflate(inflater)
    }

}