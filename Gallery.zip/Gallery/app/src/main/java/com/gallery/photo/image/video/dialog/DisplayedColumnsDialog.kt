package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogDisplayColumnsBinding
import com.gallery.photo.image.video.extension.beGone
import com.gallery.photo.image.video.utils.Preferences

class DisplayedColumnsDialog(val updateListener: () -> Unit) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogDisplayColumnsBinding
    lateinit var preferences: Preferences
    var gridCount = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogDisplayColumnsBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {

        preferences = Preferences(requireActivity())
        gridCount = preferences.getGridCount()

        intListener()

        when (gridCount) {
            2 -> bindingDialog.rb2Columns.isChecked = true
            3 -> bindingDialog.rb3Columns.isChecked = true
            4 -> bindingDialog.rb4Columns.isChecked = true
            5 -> bindingDialog.rb5Columns.isChecked = true
            6 -> bindingDialog.rb6Columns.isChecked = true
//            7 -> bindingDialog.rb7Columns.isChecked = true
//            8 -> bindingDialog.rb8Columns.isChecked = true
            else -> bindingDialog.rb3Columns.isChecked = true
        }


    }

    private fun intListener() {
//        bindingDialog.btnCancel.setOnClickListener {
//            dismiss()
//        }
        bindingDialog.btnOK.setOnClickListener {
            val selectedRadioButtonId: Int = bindingDialog.grpOption.checkedRadioButtonId
            var selectedGrid = -1
            selectedGrid = when (selectedRadioButtonId) {
                bindingDialog.rb2Columns.id -> 2
                bindingDialog.rb3Columns.id -> 3
                bindingDialog.rb4Columns.id -> 4
                bindingDialog.rb5Columns.id -> 5
                bindingDialog.rb6Columns.id -> 6
                else -> 3
            }


            if (gridCount != selectedGrid) {
                preferences.setGridCount(selectedGrid)
                preferences.setGridCount(selectedGrid)
                updateListener()
            }
            dismiss()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}