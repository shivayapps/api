package com.gallery.photo.image.video.interfaces

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy.REPLACE
import androidx.room.Query
import com.gallery.photo.image.video.models.FakeHideFilesDetail
import com.gallery.photo.image.video.models.HideFilesDetail

@Dao
interface FakeHideFilesDetailDao {

    @Query("SELECT filename FROM fakeHideFilesDetail  WHERE type = :type ")
    fun getTotalMedia(type: Int): List<String>


    @Query("SELECT filename, full_path, parent_path, last_modified, date_taken, size, type,  is_favorite, deleted_ts FROM fakeHideFilesDetail WHERE deleted_ts = 0 AND parent_path = :path COLLATE NOCASE")
    fun getMediaFromPath(path: String): List<FakeHideFilesDetail>

    @Query("SELECT filename, full_path, parent_path, last_modified, date_taken, size, type,  is_favorite, deleted_ts FROM fakeHideFilesDetail WHERE deleted_ts = 0 AND  type = :type COLLATE NOCASE ORDER BY last_modified DESC")
    fun getMediaFromType(type: Int): List<HideFilesDetail>

    @Query("SELECT filename, full_path, parent_path, last_modified, date_taken, size, type,  is_favorite, deleted_ts FROM fakeHideFilesDetail WHERE deleted_ts = 0 AND parent_path LIKE :path || '%' AND type = :type COLLATE NOCASE")
    fun getMediaOfTypeFromPath(path: String, type: Int): List<FakeHideFilesDetail>

    @Query("SELECT filename, full_path, parent_path, last_modified, date_taken, size, type,  is_favorite, deleted_ts FROM fakeHideFilesDetail WHERE full_path = :path COLLATE NOCASE")
    fun getMediaDetailFromPath(path: String): HideFilesDetail

    @Query("SELECT filename, full_path, parent_path, last_modified, date_taken, size, type,  is_favorite, deleted_ts FROM fakeHideFilesDetail WHERE deleted_ts = 0 AND is_favorite = 1")
    fun getFavorites(): List<FakeHideFilesDetail>

    @Query("SELECT filename, full_path, parent_path, last_modified, date_taken, size, type,  is_favorite, deleted_ts FROM fakeHideFilesDetail WHERE deleted_ts != 0")
    fun getDeletedMedia(): List<FakeHideFilesDetail>

    @Query("SELECT full_path FROM fakeHideFilesDetail WHERE  deleted_ts != 0 AND deleted_ts <= :endDeletedTS")
    fun getTrashMediaForDelete( endDeletedTS: Long): List<String>

    @Query("DELETE  FROM fakeHideFilesDetail WHERE deleted_ts != 0 AND deleted_ts <= :endDeletedTS")
    fun deleteTrashMedia(endDeletedTS: Long)

    @Query("SELECT filename, full_path, parent_path, last_modified, date_taken, size, type,  is_favorite, deleted_ts FROM fakeHideFilesDetail WHERE deleted_ts != 0 AND type = :type ORDER BY deleted_ts DESC")
    fun getTypeWiseDeletedMedia(type: Int): List<HideFilesDetail>

    @Insert(onConflict = REPLACE)
    fun insert(fakeHideFilesDetail: FakeHideFilesDetail)

    @Insert(onConflict = REPLACE)
    fun insertAll(media: List<FakeHideFilesDetail>)

    @Delete
    fun deleteMedia(vararg fakeHideFilesDetail: FakeHideFilesDetail)

    @Query("DELETE FROM fakeHideFilesDetail WHERE full_path = :path COLLATE NOCASE")
    fun deleteHideFilesDetailPath(path: String)

    @Query("DELETE FROM fakeHideFilesDetail WHERE deleted_ts < :timestmap AND deleted_ts != 0")
    fun deleteOldRecycleBinItems(timestmap: Long)

    @Query("UPDATE OR REPLACE fakeHideFilesDetail SET filename = :newFilename, full_path = :newFullPath, parent_path = :newParentPath WHERE full_path = :oldPath COLLATE NOCASE")
    fun updateHideFilesDetail(newFilename: String, newFullPath: String, newParentPath: String, oldPath: String)

    @Query("UPDATE OR REPLACE fakeHideFilesDetail SET full_path = :newPath, deleted_ts = :deletedTS WHERE full_path = :oldPath COLLATE NOCASE")
    fun updateDeleted(newPath: String, deletedTS: Long, oldPath: String)

    @Query("UPDATE fakeHideFilesDetail SET date_taken = :dateTaken WHERE full_path = :path COLLATE NOCASE")
    fun updateFavoriteDateTaken(path: String, dateTaken: Long)

    @Query("UPDATE fakeHideFilesDetail SET is_favorite = 0")
    fun clearFavorites()

    @Query("DELETE FROM fakeHideFilesDetail WHERE deleted_ts != 0")
    fun clearRecycleBin()
}
