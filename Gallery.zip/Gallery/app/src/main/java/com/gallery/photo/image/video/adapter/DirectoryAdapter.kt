package com.gallery.photo.image.video.adapter

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Intent
import android.content.pm.ShortcutManager
import android.media.MediaScannerConnection
import android.os.Build
import android.text.TextUtils
import android.util.Log
import android.view.Menu
import android.view.MotionEvent
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.MainActivity
import com.gallery.photo.image.video.activity.REQUEST_CODE_FOR_SUBSCRIPTION
import com.gallery.photo.image.video.activity.SubscriptionActivity
import com.gallery.photo.image.video.activityBinding.AllHiddenFileActivity
import com.gallery.photo.image.video.activityBinding.HiddenImagesActivity
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.database.FavouriteDBHelper
import com.gallery.photo.image.video.dialog.ConfirmDeleteFolderDialog
import com.gallery.photo.image.video.dialog.ExcludeFolderDialog
import com.gallery.photo.image.video.dialog.PrimaryDirectoryHideAlertDialog
import com.gallery.photo.image.video.dialog.SubscriptionDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.PhotoDirectoryFragment
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.fragment.VideoDirectoryFragment
import com.gallery.photo.image.video.interfaces.DirectoryOperationsListener
import com.gallery.photo.image.video.models.*
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.dialog.*
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.interfaces.ItemMoveCallback
import com.gallery.photo.image.video.interfaces.ItemTouchHelperContract
import com.gallery.photo.image.video.interfaces.StartReorderDragListener
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.FastScroller
import com.gallery.photo.image.video.views.MyRecyclerView
import com.google.gson.Gson
import kotlinx.android.synthetic.main.directory_item_grid_rounded_corners.view.rlTemp
import kotlinx.android.synthetic.main.directory_item_grid_square.view.dir_bottom_holder
import kotlinx.android.synthetic.main.directory_item_grid_square.view.dir_check
import kotlinx.android.synthetic.main.directory_item_grid_square.view.dir_create_folder
import kotlinx.android.synthetic.main.directory_item_grid_square.view.dir_drag_handle_wrapper
import kotlinx.android.synthetic.main.directory_item_grid_square.view.dir_location
import kotlinx.android.synthetic.main.directory_item_grid_square.view.dir_lock
import kotlinx.android.synthetic.main.directory_item_grid_square.view.dir_name
import kotlinx.android.synthetic.main.directory_item_grid_square.view.dir_pin
import kotlinx.android.synthetic.main.directory_item_grid_square.view.dir_thumbnail
import kotlinx.android.synthetic.main.directory_item_list.view.*
import kotlinx.android.synthetic.main.directory_item_list.view.dir_drag_handle
import kotlinx.android.synthetic.main.directory_item_list.view.dir_holder
import kotlinx.android.synthetic.main.directory_item_list.view.photo_cnt
import org.jetbrains.anko.toast
import java.io.File
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

class DirectoryAdapter(
    activity: BaseSimpleActivity, var dirs: ArrayList<Directory>, val listener: DirectoryOperationsListener?, recyclerView: MyRecyclerView,
    val isPickIntent: Boolean, val shouldVaultFragment: Boolean, val swipeRefreshLayout: SwipeRefreshLayout? = null, fastScroller: FastScroller? = null, itemClick: (Any) -> Unit
) :
    MyRecyclerViewAdapter(activity, recyclerView, fastScroller, itemClick), ItemTouchHelperContract {

    private val config = activity.config
    private val isListViewType = config.viewTypeFolders == VIEW_TYPE_LIST
    private var pinnedFolders = config.pinnedFolders
    private var scrollHorizontally = config.scrollHorizontally
    private var animateGifs = config.animateGifs
    private var cropThumbnails = config.cropThumbnails
    private var groupDirectSubfolders = config.groupDirectSubfolders
    private var currentDirectoriesHash = dirs.hashCode()
    private var lockedFolderPaths = ArrayList<String>()
    private var isDragAndDropping = false
    private var startReorderDragListener: StartReorderDragListener? = null

    private var showMediaCount = config.showFolderMediaCount
    private var folderStyle = config.folderStyle
    private var limitFolderTitle = config.limitFolderTitle
    var mProgressDailog: ProgressDialog? = null
    protected var selectedMainKeys = LinkedHashSet<Int>()
    var deleteDialog: ConfirmDeleteFolderDialog? = null

    init {
        setupDragListener(false)
        fillLockedFolders()
        dirs.forEach {
            (it as? Medium)?.path?.hashCode()?.let { it1 -> selectedMainKeys.add(it1) }
        }
    }


    override fun getSelectedList(): LinkedHashSet<Int> {
        return selectedMainKeys
    }

    override fun getActionMenuId() = R.menu.cab_directories

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutType = when {
            isListViewType -> R.layout.directory_item_list
            folderStyle == FOLDER_STYLE_SQUARE -> R.layout.directory_item_grid_square
            else -> R.layout.directory_item_grid_rounded_corners
        }
        return createViewHolder(layoutType, parent)
    }

    override fun onBindViewHolder(holder: MyRecyclerViewAdapter.ViewHolder, position: Int) {
//        holder.setIsRecyclable(false)
        if (dirs[position].path == activity.getString(R.string.label_add_album)) {
            Glide.with(activity).load(R.drawable.ic_add_album).into(holder.itemView.dir_thumbnail)
            holder.itemView.dir_name.visibility = GONE
            holder.itemView.dir_create_folder.visibility = GONE
            if (isListViewType) {
                holder.itemView.dir_create_folder.visibility = VISIBLE
                holder.itemView.dir_create_folder.text = activity.getString(R.string.label_create_folder)
            }
            if (holder.itemView.dir_path != null) {
                holder.itemView.dir_path.visibility = GONE

            }
            holder.itemView.photo_cnt.visibility = GONE
            holder.itemView.dir_bottom_holder.visibility = GONE
            holder.itemView.dir_check.visibility = GONE
            holder.itemView.rlTemp.visibility = GONE
            holder.bindView(dirs[0], true, false) { itemView, adapterPosition ->
            }
            bindViewHolder(holder)
        } else {
            holder.itemView.dir_name.visibility = VISIBLE
            if (holder.itemView.dir_path != null)
                holder.itemView.dir_path.visibility = VISIBLE
//            holder.itemView.photo_cnt.visibility = VISIBLE
            if (holder.itemView.dir_create_folder != null)
                holder.itemView.dir_create_folder.visibility = GONE
            holder.itemView.dir_bottom_holder.visibility = VISIBLE
            holder.itemView.dir_check.visibility = VISIBLE
            val dir = dirs.getOrNull(position) ?: return
            holder.itemView.rlTemp.visibility = GONE
            holder.itemView.rlTemp.visibility = GONE

            holder.bindView(dir, true, !isPickIntent) { itemView, adapterPosition ->
                setupView(itemView, dir, holder)
            }

            bindViewHolder(holder)
        }
    }

    public fun dismissDeleteDialog() {
        if (deleteDialog != null) {
            deleteDialog!!.dialog.dismiss()
        }
        dismissProgress()
    }

    override fun getItemCount() = dirs.size

    override fun prepareActionMode(menu: Menu) {
        val selectedPaths = getSelectedPaths()
        if (selectedPaths.isEmpty()) {
            return
        }
        Log.d("ItemPress", "actionItemPressed: -->" + selectedKeys.size)
        if (activity is MainActivity) {
            (activity as MainActivity).updateCount(selectedKeys.size)
        }
        if (activity is HiddenImagesActivity) {
            (activity as HiddenImagesActivity).updateCount(selectedKeys.size)
        }
        if (activity is AllHiddenFileActivity) {
            (activity as AllHiddenFileActivity).updateCount(selectedKeys.size)
        }
        menu.apply {
            val selectableItemCount = getSelectableItemCount()
            val selectedCount = Math.min(selectedKeys.size, selectableItemCount)
            if (selectedCount == selectableItemCount) {
                findItem(R.id.cab_select_all).title = "Deselect All"
                findItem(R.id.cab_select_all).icon = activity.resources.getDrawable(R.drawable.ic_deselect_all_vector)
            } else {
                findItem(R.id.cab_select_all).title = "Select All"
                findItem(R.id.cab_select_all).icon = activity.resources.getDrawable(R.drawable.ic_select_all_vector)
            }
//            checkHideBtnVisibility(this, selectedPaths)
        }
    }

    override fun actionItemPressed(id: Int) {

        if (selectedKeys.isEmpty()) {
            return
        }

        when (id) {
            R.id.cab_hide -> toggleFoldersVisibility(true)
            R.id.cab_unhide -> toggleFoldersVisibility(false)
            R.id.cab_select_all -> selectAll()
            R.id.cab_delete -> askConfirmDelete()
        }
    }

    override fun getSelectableItemCount() = dirs.filter { directory -> directory.path != activity.getString(R.string.label_add_album) }.size

    override fun getIsItemSelectable(position: Int): Boolean {
        return dirs[position].path != activity.getString(R.string.label_add_album)
    }

    override fun getItemSelectionKey(position: Int) = dirs.getOrNull(position)?.path?.hashCode()

    override fun getItemKeyPosition(key: Int) = dirs.indexOfFirst { it.path.hashCode() == key }

    override fun onActionModeCreated() {
        if (activity is MainActivity) {
            (activity as MainActivity).toggleToolbar(true)
        }
        if (activity is HiddenImagesActivity) {
            (activity as HiddenImagesActivity).toggleToolbar(true)
        }
        if (activity is AllHiddenFileActivity) {
            (activity as AllHiddenFileActivity).toggleToolbar(true)
        }
        swipeRefreshLayout!!.isEnabled = false
    }

    override fun onActionModeDestroyed() {

        if (activity is MainActivity) {
            (activity as MainActivity).toggleToolbar(false)
        }
        if (activity is HiddenImagesActivity) {
            (activity as HiddenImagesActivity).toggleToolbar(false)
        }
        if (activity is AllHiddenFileActivity) {
            (activity as AllHiddenFileActivity).toggleToolbar(false)
        }
        if (isDragAndDropping) {
            notifyDataSetChanged()
            val reorderedFoldersList = dirs.map { it.path }
            config.customFoldersOrder = TextUtils.join("|||", reorderedFoldersList)
            config.directorySorting = SORT_BY_CUSTOM
        }

        isDragAndDropping = false
        swipeRefreshLayout!!.isEnabled = true
    }

    override fun onViewRecycled(holder: ViewHolder) {
        super.onViewRecycled(holder)
        if (!activity.isDestroyed) {
            Glide.with(activity).clear(holder.itemView.dir_thumbnail!!)
        }
    }

    private fun checkHideBtnVisibility(menu: Menu, selectedPaths: ArrayList<String>) {
//        menu.findItem(R.id.cab_hide).isVisible = selectedPaths.any { !it.doesThisOrParentHaveNoMedia(HashMap(), null) }
//        menu.findItem(R.id.cab_unhide).isVisible = selectedPaths.any { it.doesThisOrParentHaveNoMedia(HashMap(), null) }
        menu.findItem(R.id.cab_hide).isVisible = !shouldVaultFragment
        menu.findItem(R.id.cab_unhide).isVisible = shouldVaultFragment
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
            if (selectedPaths.size == 1) {
                menu.findItem(R.id.cab_hide).isVisible = !shouldVaultFragment && selectedPaths.any {
                    !it.substringAfterLast("/").equals("pictures", true) && !it.substringAfterLast("/").equals("Camera", false)
                            && !it.substringAfterLast("/").equals("download", true) && !it.substringAfterLast("/").equals("internal", true)
                }
            } else {
                menu.findItem(R.id.cab_hide).isVisible = !shouldVaultFragment && !selectedPaths.filter {
                    it.substringAfterLast("/").equals("pictures", true) || it.substringAfterLast("/").equals("Camera", false)
                            || it.substringAfterLast("/").equals("download", true) || it.substringAfterLast("/").equals("internal", true)
                }.isNotEmpty()
            }

        }
    }

    private fun checkPinBtnVisibility(menu: Menu, selectedPaths: ArrayList<String>) {
        val pinnedFolders = config.pinnedFolders
        menu.findItem(R.id.cab_pin).isVisible = selectedPaths.any { !pinnedFolders.contains(it) }
        menu.findItem(R.id.cab_unpin).isVisible = selectedPaths.any { pinnedFolders.contains(it) }
    }

    private fun moveSelectedItemsToTop() {
        selectedKeys.reversed().forEach { key ->
            val position = dirs.indexOfFirst { it.path.hashCode() == key }
            val tempItem = dirs[position]
            dirs.removeAt(position)
            dirs.add(0, tempItem)
        }

        notifyDataSetChanged()
    }

    private fun moveSelectedItemsToBottom() {
        selectedKeys.forEach { key ->
            val position = dirs.indexOfFirst { it.path.hashCode() == key }
            val tempItem = dirs[position]
            dirs.removeAt(position)
            dirs.add(dirs.size, tempItem)
        }

        notifyDataSetChanged()
    }

    private fun showProperties() {
        if (selectedKeys.size <= 1) {
            val path = getFirstSelectedItemPath() ?: return
            if (path != FAVORITES && path != RECYCLE_BIN) {
                activity.handleLockedFolderOpening(path) { success ->
                    if (success) {
                        PropertiesDialog(activity, path, config.shouldShowHidden) {}
                    }
                }
            }
        } else {
            PropertiesDialog(activity, getSelectedPaths().filter {
                it != FAVORITES && it != RECYCLE_BIN && !config.isFolderProtected(it)
            }.toMutableList(), config.shouldShowHidden) {}
        }
    }

    private fun renameDir() {
        if (selectedKeys.size == 1) {
            val firstDir = getFirstSelectedItem() ?: return
            val sourcePath = firstDir.path
            val dir = File(sourcePath)
            if (activity.isAStorageRootFolder(dir.absolutePath)) {
                activity.toast(R.string.rename_folder_root)
                return
            }

            activity.handleLockedFolderOpening(sourcePath) { success ->
                if (success) {
                    RenameItemDialog(activity as BaseSimpleActivity, dir.absolutePath) {
                        activity.runOnUiThread {
                            firstDir.apply {
                                path = it
                                name = it.getFilenameFromPath()
                                tmb = File(it, tmb.getFilenameFromPath()).absolutePath
                            }
                            updateDirs(dirs)
                            ensureBackgroundThread {
                                try {
                                    activity.directoryDao.updateDirectoryAfterRename(firstDir.tmb, firstDir.name, firstDir.path, sourcePath)
                                    listener?.refreshItems()
                                } catch (e: Exception) {
                                    activity.showErrorToast(e)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            val paths = getSelectedPaths().filter { !activity.isAStorageRootFolder(it) && !config.isFolderProtected(it) } as ArrayList<String>
            RenameItemsDialog(activity as BaseSimpleActivity, paths) {
                listener?.refreshItems()
            }
        }
    }

    fun toggleFoldersVisibility(hide: Boolean) {
        VaultFragment.isHideUnHideMedia = true

        if (!hide)
            showProgress(activity.getString(R.string.label_unhiding_progress))

        val selectedPaths = getSelectedPaths()
        if (hide && selectedPaths.contains(RECYCLE_BIN)) {
            config.showRecycleBinAtFolders = false
            if (selectedPaths.size == 1) {
                listener?.refreshItems()
                finishActMode()
            }
        }

        if (hide) {
            var totalImagesCount = activity.config.hidePhotoCountForSubscription
            var totalVideosCount = activity.config.hideVideoCountForSubscription
            if (hide && selectedPaths.any { it == RECOVER_DIR_PATH || it == RESTORE_DIR_PATH || it == DCIM_DIR_PATH || it == PICTURE_DIR_PATH || it.lowercase() == DOWNLOAD_DIR_PATH.lowercase() || it == CAMERA_DIR_PATH || it == HD_CAMERA_DIR_PATH || it == MOVIE_DIR_PATH || it == RESTORE_TRASH_DIR_PATH || it == STORAGE_DIR_PATH || it.lowercase() == SCREENSHOT_DIR_PATH.lowercase() }) {
                PrimaryDirectoryHideAlertDialog(activity, selectedPaths, 0)
                { isOK ->
                    if (isOK) {
                        if (selectedPaths.size == 1) {
                            activity.baseConfig.isAnyOperationRunning = false
                            activity.baseConfig.lastDestinationPath = ""
                            MainActivity.isHideButtonClicked = false
                            finishActMode()
                            if (activity is MainActivity) {
                                (activity as MainActivity).performFolderClick(selectedPaths[0])
                            }
                        } else {
                            var filteredPath =
                                selectedPaths.filter { it != RECOVER_DIR_PATH && it != RESTORE_DIR_PATH && it != DCIM_DIR_PATH && it != PICTURE_DIR_PATH && it.lowercase() != DOWNLOAD_DIR_PATH.lowercase() && it != CAMERA_DIR_PATH && it != HD_CAMERA_DIR_PATH && it != MOVIE_DIR_PATH && it != RESTORE_TRASH_DIR_PATH && it != STORAGE_DIR_PATH && it.lowercase() != SCREENSHOT_DIR_PATH.lowercase() } as ArrayList<String>
                            finishActMode()
                            if (filteredPath.size == 0) {
                                activity.baseConfig.isAnyOperationRunning = false
                                activity.baseConfig.lastDestinationPath = ""
                                MainActivity.isHideButtonClicked = false
                            } else {

                                ensureBackgroundThread {
                                    filteredPath.forEach {
                                        val mediaCountPhoto = activity.mediaDB.getMediaOfTypeFromPath(it, TYPE_IMAGES)
                                        val mediaCountPhotoGIF = activity.mediaDB.getMediaOfTypeFromPath(it, TYPE_GIFS)
                                        val mediaCountVideo = activity.mediaDB.getMediaOfTypeFromPath(it, TYPE_VIDEOS)
                                        totalImagesCount += mediaCountPhoto.size + mediaCountPhotoGIF.size
                                        totalVideosCount += mediaCountVideo.size
                                    }
                                    if (AdsManager(activity).isNeedToShowAds() && totalImagesCount > HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION_VAL
                                        || totalVideosCount > HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION_VAL
                                    ) {
                                        Log.d("TAGHiddenCount", "Need Subscription")
                                        activity.runOnUiThread {
                                            SubscriptionDialog(activity, totalImagesCount, totalVideosCount)
                                            {
                                                if (it) {
                                                    finishActMode()
                                                    var intent = Intent(activity, SubscriptionActivity::class.java)
                                                    activity.launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
                                                } else {
                                                    activity.config.hidePhotoCountForSubscription = totalImagesCount
                                                    activity.config.hideVideoCountForSubscription = totalVideosCount
                                                    Log.d("HideCount", "Directory Adapter: hidePhotoCountForSubscription " + activity.config.hidePhotoCountForSubscription)
                                                    Log.d("HideCount", "Directory Adapter: hideVideoCountForSubscription " + activity.config.hideVideoCountForSubscription)
                                                    ensureBackgroundThread {
                                                        activity.uDataDao.updateCount(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, config.hidePhotoCountForSubscription)
                                                        activity.uDataDao.updateCount(HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION, config.hideVideoCountForSubscription)
                                                    }
                                                    try {
                                                        showProgress(activity.getString(R.string.msg_hiding))
                                                    } catch (e: Exception) {
                                                    }
                                                    ensureBackgroundThread {
                                                        hideFolders(filteredPath)
                                                    }
                                                }
                                            }
                                        }

                                    } else {
                                        activity.config.hidePhotoCountForSubscription = totalImagesCount
                                        activity.config.hideVideoCountForSubscription = totalVideosCount
                                        Log.d("HideCount", "Directory Adapter: hidePhotoCountForSubscription " + activity.config.hidePhotoCountForSubscription)
                                        Log.d("HideCount", "Directory Adapter: hideVideoCountForSubscription " + activity.config.hideVideoCountForSubscription)
                                        ensureBackgroundThread {
                                            activity.uDataDao.updateCount(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, config.hidePhotoCountForSubscription)
                                            activity.uDataDao.updateCount(HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION, config.hideVideoCountForSubscription)
                                        }
                                        try {
                                            showProgress(activity.getString(R.string.msg_hiding))
                                        } catch (e: Exception) {
                                        }
                                        ensureBackgroundThread {
                                            hideFolders(filteredPath)
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        MainActivity.isHideButtonClicked = false
                        finishActMode()
                    }

                }
                return
            }
            try {
                showProgress(activity.getString(R.string.msg_hiding))
            } catch (e: Exception) {
            }
            ensureBackgroundThread {
                selectedPaths.forEach {
                    val mediaCountPhoto = activity.mediaDB.getMediaOfTypeFromPath(it, TYPE_IMAGES)
                    val mediaCountPhotoGIF = activity.mediaDB.getMediaOfTypeFromPath(it, TYPE_GIFS)
                    val mediaCountVideo = activity.mediaDB.getMediaOfTypeFromPath(it, TYPE_VIDEOS)
                    totalImagesCount += mediaCountPhoto.size + mediaCountPhotoGIF.size
                    totalVideosCount += mediaCountVideo.size
                }
                Log.d("HideCount", "Directory Adapter: hidePhotoCountForSubscription " + totalImagesCount)
                Log.d("HideCount", "Directory Adapter: hideVideoCountForSubscription " + totalVideosCount)

                if (AdsManager(activity).isNeedToShowAds() && (totalImagesCount > HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION_VAL
                            && totalVideosCount > HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION_VAL)
                ) {

                    Log.d("TAGHiddenCount", "Need Subscription")
                    activity.runOnUiThread {
                        dismissProgress()
                        SubscriptionDialog(activity, totalImagesCount, totalVideosCount)
                        {

                            if (it) {
                                finishActMode()
                                var intent = Intent(activity, SubscriptionActivity::class.java)
                                activity.launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
                            } else {
                                callHideFolder(totalImagesCount, totalVideosCount, selectedPaths)
                            }
                        }
                    }

                } else if (AdsManager(activity).isNeedToShowAds() && totalImagesCount > HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION_VAL) {
                    Log.d("TAGHiddenCount", "Need Subscription")
                    activity.runOnUiThread {
                        dismissProgress()
                        SubscriptionDialog(activity, totalImagesCount, totalVideosCount)
                        {

                            if (it) {
                                finishActMode()
                                var intent = Intent(activity, SubscriptionActivity::class.java)
                                activity.launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
                            } else {
                                callHideFolder(totalImagesCount, totalVideosCount, selectedPaths)
                            }
                        }
                    }
                } else if (AdsManager(activity).isNeedToShowAds() && totalVideosCount > HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION_VAL) {
                    Log.d("TAGHiddenCount", "Need Subscription")
                    activity.runOnUiThread {
                        dismissProgress()
                        SubscriptionDialog(activity, totalImagesCount, totalVideosCount)
                        {

                            if (it) {
                                finishActMode()
                                var intent = Intent(activity, SubscriptionActivity::class.java)
                                activity.launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
                            } else {
                                callHideFolder(totalImagesCount, totalVideosCount, selectedPaths)
                            }
                        }
                    }
                } else {
                    callHideFolder(totalImagesCount, totalVideosCount, selectedPaths)
                }
            }

        } else {
            isInterstitialShown = true
            AsyncBackgroundWork({}, {
                ensureBackgroundThread {
                    selectedPaths.filter { (selectedPaths.size == 1 || !config.isFolderProtected(it)) }.forEach {
                        val path = it
                        activity.handleLockedFolderOpening(path) { success ->
                            if (success) {
                                var fakeMedia = ArrayList<Medium>()
                                var newMedia = ArrayList<Medium>()
                                ensureBackgroundThread {
                                    fakeMedia = activity.fakeVaultMediumDao.getMediaFromPath(path) as ArrayList<Medium>

                                    if (VaultFragment.isFakeVaultOpen) {
                                        var allFakeMedia = activity.fakeVaultMediumDao.getAllMediaFromPath(path) as ArrayList<Medium>
                                        if (!allFakeMedia.any { it.deletedTS > 0 }) {
                                            activity.fakeVaultHiddenDirectoryDao.deleteDirPath(path)
                                        }
                                    } else
                                        activity.hiddenDirectoryDao.deleteDirPath(path)



                                    if (VaultFragment.isFakeVaultOpen) {
                                        newMedia = fakeMedia
                                    } else {
                                        val mediaFetcher = MediaFetcher(activity)
                                        val folderGrouping = activity.config.getFolderGrouping(path)
                                        val fileSorting = activity.config.getFolderSorting(path)
                                        var getProperDateTaken = fileSorting and SORT_BY_DATE_TAKEN != 0 ||
                                                folderGrouping and GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                                                folderGrouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0

                                        val getProperLastModified = fileSorting and SORT_BY_DATE_MODIFIED != 0 ||
                                                folderGrouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                                                folderGrouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0
                                        val getProperFileSize = fileSorting and SORT_BY_SIZE != 0
//        val favoritePaths = context.getFavoritePaths()
                                        val getVideoDurations = activity.config.showThumbnailVideoDuration
                                        val lastModifieds = if (getProperLastModified) mediaFetcher.getLastModifieds() else java.util.HashMap()
                                        val dateTakens = if (getProperDateTaken) mediaFetcher.getDateTakens() else java.util.HashMap()
                                        newMedia = mediaFetcher.getFilesFrom(
                                            it, false, false, getProperDateTaken, getProperLastModified, getProperFileSize,
                                            ArrayList<String>(), getVideoDurations, true, lastModifieds, dateTakens
                                        )
                                        val firstListObjectIds = fakeMedia.map { it.path }.toSet()
                                        newMedia = newMedia.filter { !firstListObjectIds.contains((it as Medium).path) } as ArrayList<Medium>

                                        Log.e("TAG", "toggleFoldersVisibility: hidden file size" + newMedia.size.toString())

                                    }

                                    if (path.containsNoMedia()) {
                                        activity.removeNoMedia(path) {
                                            MediaScannerConnection.scanFile(
                                                activity, arrayOf(path),
                                                null, null
                                            )
                                            newMedia.filter { it.name.startsWith(".") }.forEach { it1 ->
                                                ensureBackgroundThread {
                                                    activity.fakeVaultMediumDao.deleteMediumPath(it1.path)
                                                }
                                                activity.toggleFileVisibility(it1.path, false) {
                                                    MediaScannerConnection.scanFile(
                                                        activity, arrayOf(it),
                                                        null, null
                                                    )
                                                }
                                            }

                                            if (config.shouldShowHidden) {
                                                updateFolderNames()
                                            }
                                        }
                                    } else {
                                        MediaScannerConnection.scanFile(
                                            activity, arrayOf(path),
                                            null, null
                                        )
                                        newMedia.forEach { medium ->
                                            ensureBackgroundThread {
                                                activity.fakeVaultMediumDao.deleteMediumPath(medium.path)
                                            }
                                            activity.toggleFileVisibility(medium.path, false) {
                                                MediaScannerConnection.scanFile(
                                                    activity, arrayOf(it),
                                                    null, null
                                                )
                                            }
                                        }
                                        if (config.shouldShowHidden) {
                                            updateFolderNames()
                                        }
                                    }
                                }

                            }
                        }
                    }

                    selectedPaths.forEach {
                        activity.updatePhotoVideoDirectoryPath(it, false, true)
                        activity.updatePhotoVideoDirectoryPath(it, true, false)
                    }
                }
            }, {


                activity.runOnUiThread {
                    activity.toast(activity.getString(R.string.msg_unhide_media_successfully))
                    listener?.refreshItems()
                    isInterstitialShown = false
                    finishActMode()
                    PhotoDirectoryFragment.isNeedToRefresh = true
                    VideoDirectoryFragment.isNeedToRefresh = true

                }
            })

        }

    }

    private fun callHideFolder(totalImagesCount: Int, totalVideosCount: Int, selectedPaths: ArrayList<String>) {
        activity.runOnUiThread {
            dismissProgress()
            ConfirmationDialog(activity, activity.getString(R.string.hide_folder_description)) {
                if (it) {
                    try {
                        showProgress(activity.getString(R.string.msg_hiding))
                    } catch (e: Exception) {
                    }
                    ensureBackgroundThread {
                        activity.config.hidePhotoCountForSubscription = totalImagesCount
                        activity.config.hideVideoCountForSubscription = totalVideosCount
                        Log.d("HideCount", "Directory Adapter: hidePhotoCountForSubscription " + activity.config.hidePhotoCountForSubscription)
                        Log.d("HideCount", "Directory Adapter: hideVideoCountForSubscription " + activity.config.hideVideoCountForSubscription)
                        ensureBackgroundThread {
                            activity.uDataDao.updateCount(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, config.hidePhotoCountForSubscription)
                            activity.uDataDao.updateCount(HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION, config.hideVideoCountForSubscription)
                        }
                        hideFolders(selectedPaths)
                    }
                }
            }
        }
    }

    fun showProgress(msg: String) {
        activity.runOnUiThread {
            mProgressDailog = ProgressDialog(activity, R.style.MyAlertDialogNew)
            mProgressDailog!!.setMessage(msg)

            mProgressDailog!!.setCancelable(false)
            mProgressDailog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
            mProgressDailog!!.show()
        }
    }

    fun dismissProgress() {
        activity.runOnUiThread {
            if (mProgressDailog != null) {
                if (mProgressDailog!!.isShowing)
                    mProgressDailog!!.dismiss()
            }
        }
    }

    private fun hideFolders(paths: ArrayList<String>) {

        for (path in paths) {
            activity.handleLockedFolderOpening(path) { success ->
                if (success) {
                    hideFolder(path)
                }
            }
        }
        activity.config.hiddenCountForRate++
        VaultFragment.isNeedToRefresh = true
//        SavePhotoDirectoryAsynctask(activity).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
//        SaveVideoDirectoryAsynctask(activity).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
        activity.runOnUiThread {
            if (activity is MainActivity)
                if (activity.findViewById<ImageView>(R.id.imgClose) != null)
                    activity.findViewById<ImageView>(R.id.imgClose).performClick()
            dismissProgress()
            listener?.refreshItems()
        }
    }

    private fun tryEmptyRecycleBin(askConfirmation: Boolean) {
        if (askConfirmation) {
            activity.showRecycleBinEmptyingDialog {
                emptyRecycleBin()
            }
        } else {
            emptyRecycleBin()
        }
    }

    private fun emptyRecycleBin() {
        activity.handleLockedFolderOpening(RECYCLE_BIN) { success ->
            if (success) {
                activity.emptyTheRecycleBin {
                    listener?.refreshItems()
                }
            }
        }
    }

    private fun emptyAndDisableRecycleBin() {
        activity.handleLockedFolderOpening(RECYCLE_BIN) { success ->
            if (success) {
                activity.showRecycleBinEmptyingDialog {
                    activity.emptyAndDisableTheRecycleBin {
                        listener?.refreshItems()
                    }
                }
            }
        }
    }

    private fun updateFolderNames() {
        val includedFolders = config.includedFolders
        val hidden = activity.getString(R.string.hidden)
        dirs.forEach {
            it.name = activity.checkAppendingHidden(it.path, hidden, includedFolders, ArrayList())
        }
        listener?.updateDirectories(dirs.toMutableList() as ArrayList)
        activity.runOnUiThread {
            finishActMode()
            MainActivity.isNeedToRefresh = true
            VaultFragment.isNeedToRefresh = true
            updateDirs(dirs)
        }
    }

    private fun hideFolder(path: String) {
        activity.addNoMedia(path) {
            if (config.shouldShowHidden) {
                updateFolderNames()
            } else {
                ensureBackgroundThread {
                    activity.updatePhotoVideoDirectoryPath(path, true, false, true)
                    activity.updatePhotoVideoDirectoryPath(path, false, true, true)
                }

                val includedFolders = config.includedFolders
                val hidden = activity.getString(R.string.hidden)
                ensureBackgroundThread {
                    dirs.forEach {
                        it.name = activity.checkAppendingHidden(it.path, hidden, includedFolders, ArrayList())
                        activity.hiddenDirectoryDao.insert(
                            HiddenDirectory(
                                null, it.path, it.tmb, it.name, it.mediaCnt, it.modified, it.taken, it.size, it.location, it.types, it.sortValue, it.mediaCnt
                            )
                        )


                    }

                }

                val affectedPositions = ArrayList<Int>()
                val newDirs = dirs.filterIndexed { index, directory ->
                    val removeDir = directory.path.doesThisOrParentHaveNoMedia(HashMap(), null) && !includedFolders.contains(directory.path)
                    if (removeDir) {
                        affectedPositions.add(index)
                    }
                    !removeDir
                } as ArrayList<Directory>
//                SaveDirectoryAsynctask(activity).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                activity.runOnUiThread {
                    affectedPositions.sortedDescending().forEach {
                        notifyItemRemoved(it)
                    }

                    currentDirectoriesHash = newDirs.hashCode()
                    dirs = newDirs
                    ensureBackgroundThread {
                        activity.updatePhotoVideoDirectoryPath(path, false, true)
                        activity.updatePhotoVideoDirectoryPath(path, true, false)
                    }
//                    MainActivity.isNeedToRefresh = true
//
//                    if (activity is MainActivity)
//                        activity.findViewById<ImageView>(R.id.imgClose).performClick()
//                    listener?.refreshItems()
                }
            }
        }

    }

    private fun tryExcludeFolder() {
        val selectedPaths = getSelectedPaths()
        val paths = selectedPaths.filter { it != PATH && it != RECYCLE_BIN && it != FAVORITES }.toSet()
        if (selectedPaths.contains(RECYCLE_BIN)) {
            config.showRecycleBinAtFolders = false
            if (selectedPaths.size == 1) {
                listener?.refreshItems()
                finishActMode()
            }
        }

        if (paths.size == 1) {
            ExcludeFolderDialog(activity, paths.toMutableList()) {
                listener?.refreshItems()
                finishActMode()
            }
        } else if (paths.size > 1) {
            config.addExcludedFolders(paths)
            listener?.refreshItems()
            finishActMode()
        }
    }

    private fun tryLockFolder() {
        if (config.wasFolderLockingNoticeShown) {
            lockFolder()
        } else {
            FolderLockingNoticeDialog(activity) {
                lockFolder()
            }
        }
    }

    private fun lockFolder() {
        SecurityDialog(activity, "", SHOW_ALL_TABS) { hash, type, success ->
            if (success) {
                getSelectedPaths().filter { !config.isFolderProtected(it) }.forEach {
                    config.addFolderProtection(it, hash, type)
                    lockedFolderPaths.add(it)
                }

                listener?.refreshItems()
                finishActMode()
            }
        }
    }

    private fun unlockFolder() {
        val paths = getSelectedPaths()
        val firstPath = paths.first()
        val tabToShow = config.getFolderProtectionType(firstPath)
        val hashToCheck = config.getFolderProtectionHash(firstPath)
        SecurityDialog(activity, hashToCheck, tabToShow) { hash, type, success ->
            if (success) {
                paths.filter { config.isFolderProtected(it) && config.getFolderProtectionType(it) == tabToShow && config.getFolderProtectionHash(it) == hashToCheck }.forEach {
                    config.removeFolderProtection(it)
                    lockedFolderPaths.remove(it)
                }

                listener?.refreshItems()
                finishActMode()
            }
        }
    }

    private fun pinFolders(pin: Boolean) {
        if (pin) {
            config.addPinnedFolders(getSelectedPaths().toHashSet())
        } else {
            config.removePinnedFolders(getSelectedPaths().toHashSet())
        }

        currentDirectoriesHash = 0
        pinnedFolders = config.pinnedFolders
        listener?.recheckPinnedFolders()
    }

    private fun changeOrder() {
        isDragAndDropping = true
        notifyDataSetChanged()
        actMode?.invalidate()

        if (startReorderDragListener == null) {
            val touchHelper = ItemTouchHelper(ItemMoveCallback(this, true))
            touchHelper.attachToRecyclerView(recyclerView)

            startReorderDragListener = object : StartReorderDragListener {
                override fun requestDrag(viewHolder: RecyclerView.ViewHolder) {
                    touchHelper.startDrag(viewHolder)
                }
            }
        }
    }

    private fun moveFilesTo() {
        activity.handleDeletePasswordProtection {
            copyMoveTo(false)
        }
    }

    private fun copyMoveTo(isCopyOperation: Boolean) {
        finishActMode()
        val paths = ArrayList<String>()
        val showHidden = config.shouldShowHidden
        getSelectedPaths().forEach {
            val filter = config.filterMedia
            File(it).listFiles()?.filter {
                !File(it.absolutePath).isDirectory &&
                        it.absolutePath.isMediaFile() && (showHidden || !it.name.startsWith('.')) &&
                        ((it.isImageFast() && filter and TYPE_IMAGES != 0) ||
                                (it.isVideoFast() && filter and TYPE_VIDEOS != 0) ||
                                (it.isGif() && filter and TYPE_GIFS != 0) ||
                                (it.isRawFast() && filter and TYPE_RAWS != 0) ||
                                (it.isSvg() && filter and TYPE_SVGS != 0))
            }?.mapTo(paths) { it.absolutePath }
        }

        val fileDirItems = paths.map { FileDirItem(it, it.getFilenameFromPath()) } as ArrayList<FileDirItem>
        activity.tryCopyMoveFilesTo(fileDirItems, isCopyOperation) {
            if (it != "None") {
                val destinationPath = it
                val newPaths = fileDirItems.map { "$destinationPath/${it.name}" }.toMutableList() as java.util.ArrayList<String>
                activity.rescanPaths(newPaths) {
                    activity.fixDateTaken(newPaths, false)
                }
                VaultFragment.isHideUnHideMedia = true
                config.tempFolderPath = ""
                listener?.refreshItems()

            }
        }
    }

    private fun tryCreateShortcut() {
        activity.handleLockedFolderOpening(getFirstSelectedItemPath() ?: "") { success ->
            if (success) {
                createShortcut()
            }
        }
    }

    @SuppressLint("NewApi")
    private fun createShortcut() {
        val manager = activity.getSystemService(ShortcutManager::class.java)
        if (manager.isRequestPinShortcutSupported) {
            val dir = getFirstSelectedItem() ?: return
            val path = dir.path
            val drawable = resources.getDrawable(R.drawable.shortcut_image).mutate()
            val coverThumbnail = config.parseAlbumCovers().firstOrNull { it.tmb == dir.path }?.tmb ?: dir.tmb
            activity.getShortcutImage(coverThumbnail, drawable) {
                /* val intent = Intent(activity, MediaActivity::class.java)
                 intent.action = Intent.ACTION_VIEW
                 intent.flags = intent.flags or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                 intent.putExtra(DIRECTORY, path)

                 val shortcut = ShortcutInfo.Builder(activity, path)
                     .setShortLabel(dir.name)
                     .setIcon(Icon.createWithBitmap(drawable.convertToBitmap()))
                     .setIntent(intent)
                     .build()

                 manager.requestPinShortcut(shortcut, null)*/
            }
        }
    }

    private fun askConfirmDelete() {

        when {

            config.isDeletePasswordProtectionOn -> activity.handleDeletePasswordProtection {
                deleteFolders()
            }
            config.skipDeleteConfirmation -> deleteFolders()
            else -> {
                val itemsCnt = selectedKeys.size
                if (itemsCnt == 1 && getSelectedItems().first().isRecycleBin()) {
                    ConfirmationDialog(activity, "", R.string.empty_recycle_bin_confirmation, R.string.yes, R.string.no) {
                        deleteFolders()
                    }
                    return
                }

                val items = if (itemsCnt == 1) {
                    val folder = getSelectedPaths().first().getFilenameFromPath()
                    "\"$folder\""
                } else {
                    resources.getQuantityString(R.plurals.delete_items, itemsCnt, itemsCnt)
                }

                val fileDirItem = getFirstSelectedItem() ?: return
                val baseString = if (activity is HiddenImagesActivity) {
                    R.string.msg_move_vault_trash
                } else if (activity is AllHiddenFileActivity) {
                    R.string.deletion_confirmation
                } else {
                    R.string.msg_move_recover_trash
                }


                val question = String.format(resources.getString(baseString), items)
                val warning = resources.getQuantityString(R.plurals.delete_warning, itemsCnt, itemsCnt)

                deleteDialog = ConfirmDeleteFolderDialog(activity, question, warning) {
                    deleteFolders()
                }
            }
        }
    }

    private fun deleteFolders() {
        VaultFragment.isHideUnHideMedia = true
        showProgress(activity.getString(R.string.msg_deleting))
        if (selectedKeys.isEmpty()) {
            return
        }
        activity.baseConfig.isAnyOperationRunning = true
        var SAFPath = ""
        val selectedDirs = getSelectedItems()
        selectedDirs.forEach {
            val path = it.path
            if (activity.needsStupidWritePermissions(path) && config.treeUri.isEmpty()) {
                SAFPath = path
            }
        }
        if (activity is MainActivity)
            activity.findViewById<ImageView>(R.id.imgClose).performClick()
        activity.handleSAFDialog(SAFPath) {
            if (!it) {
                return@handleSAFDialog
            }

            var foldersToDelete = ArrayList<File>(selectedKeys.size)
            selectedDirs.forEach {
                if (it.areFavorites() || it.isRecycleBin()) {
                    if (it.isRecycleBin()) {
                        tryEmptyRecycleBin(false)
                    } else {
                        ensureBackgroundThread {
                            var dbHelper = FavouriteDBHelper(activity)
                            dbHelper.deleteFavDetails(it.path)
                            listener?.refreshItems()
                        }
                    }

                    if (selectedKeys.size == 1) {
                        finishActMode()
                    }
                } else {
                    foldersToDelete.add(File(it.path))
                }
            }

            if (foldersToDelete.size == 1) {
                activity.handleLockedFolderOpening(foldersToDelete.first().absolutePath) { success ->
                    if (success) {
                        listener?.deleteFolders(foldersToDelete)
                    }
                }
            } else {
                foldersToDelete = foldersToDelete.filter { !config.isFolderProtected(it.absolutePath) }.toMutableList() as ArrayList<File>
                listener?.deleteFolders(foldersToDelete)
            }
        }
    }

    private fun tryChangeAlbumCover(useDefault: Boolean) {
        activity.handleLockedFolderOpening(getFirstSelectedItemPath() ?: "") { success ->
            if (success) {
                changeAlbumCover(useDefault)
            }
        }
    }

    private fun changeAlbumCover(useDefault: Boolean) {
        if (selectedKeys.size != 1)
            return

        val path = getFirstSelectedItemPath() ?: return

        if (useDefault) {
            val albumCovers = getAlbumCoversWithout(path)
            storeCovers(albumCovers)
        } else {
            pickMediumFrom(path, path)
        }
    }

    private fun pickMediumFrom(targetFolder: String, path: String) {
        /*PickMediumDialog(activity, path) {
            if (File(it).isDirectory) {
                pickMediumFrom(targetFolder, it)
            } else {
                val albumCovers = getAlbumCoversWithout(path)
                val cover = AlbumCover(targetFolder, it)
                albumCovers.add(cover)
                storeCovers(albumCovers)
            }
        }*/
    }

    private fun getAlbumCoversWithout(path: String) = config.parseAlbumCovers().filterNot { it.path == path } as ArrayList

    private fun storeCovers(albumCovers: ArrayList<AlbumCover>) {
        config.albumCovers = Gson().toJson(albumCovers)
        finishActMode()
        listener?.refreshItems()
    }

    private fun getSelectedItems() = selectedKeys.mapNotNull { getItemWithKey(it) } as ArrayList<Directory>

    public fun getSelectedPaths() = getSelectedItems().map { it.path } as ArrayList<String>

    private fun getFirstSelectedItem() = getItemWithKey(selectedKeys.first())

    private fun getFirstSelectedItemPath() = getFirstSelectedItem()?.path

    private fun getItemWithKey(key: Int): Directory? = dirs.firstOrNull { it.path.hashCode() == key }

    private fun fillLockedFolders() {
        lockedFolderPaths.clear()
        dirs.map { it.path }.filter { config.isFolderProtected(it) }.forEach {
            lockedFolderPaths.add(it)
        }
    }

    fun updateDirs(newDirs: ArrayList<Directory>) {
        val directories = newDirs.clone() as ArrayList<Directory>
        if (directories.hashCode() != currentDirectoriesHash) {
            currentDirectoriesHash = directories.hashCode()
            dirs = directories
            fillLockedFolders()
            notifyDataSetChanged()
            finishActMode()
        }
    }

    fun updateAnimateGifs(animateGifs: Boolean) {
        this.animateGifs = animateGifs
        notifyDataSetChanged()
    }

    fun updateCropThumbnails(cropThumbnails: Boolean) {
        this.cropThumbnails = cropThumbnails
        notifyDataSetChanged()
    }

    private fun setupView(view: View, directory: Directory, holder: ViewHolder) {
        val isSelected = selectedKeys.contains(directory.path.hashCode())
        view.apply {
            dir_path?.text = "${directory.path.substringBeforeLast("/")}/"
            dir_path?.visibility = VISIBLE
            if (activity.baseConfig.appLanguage == "ur") {
                dir_name.textDirection = View.TEXT_DIRECTION_RTL
                if (dir_path != null)
                    dir_path.textDirection = View.TEXT_DIRECTION_RTL
            } else {
                dir_name.textDirection = View.TEXT_DIRECTION_LTR
                if (dir_path != null)
                    dir_path.textDirection = View.TEXT_DIRECTION_LTR
            }
            val thumbnailType = when {
                directory.tmb.isVideoFast() -> TYPE_VIDEOS
                directory.tmb.isGif() -> TYPE_GIFS
                directory.tmb.isRawFast() -> TYPE_RAWS
                directory.tmb.isSvg() -> TYPE_SVGS
                else -> TYPE_IMAGES
            }

            dir_check?.beVisibleIf(isSelected)
            if (isSelected) {
                dir_check.background?.applyColorFilter(adjustedPrimaryColor)
                dir_check.applyColorFilter(contrastColor)
            }

            if (isListViewType) {
                dir_holder.isSelected = isSelected
            }

            if (scrollHorizontally && !isListViewType && folderStyle == FOLDER_STYLE_ROUNDED_CORNERS) {
                (dir_thumbnail.layoutParams as RelativeLayout.LayoutParams).addRule(RelativeLayout.ABOVE, dir_name.id)

                val photoCntParams = (photo_cnt.layoutParams as RelativeLayout.LayoutParams)
                val nameParams = (dir_name.layoutParams as RelativeLayout.LayoutParams)
                nameParams.removeRule(RelativeLayout.BELOW)

                if (config.showFolderMediaCount == FOLDER_MEDIA_CNT_LINE) {
                    nameParams.addRule(RelativeLayout.ABOVE, photo_cnt.id)
                    nameParams.removeRule(RelativeLayout.ALIGN_PARENT_BOTTOM)

                    photoCntParams.removeRule(RelativeLayout.BELOW)
                    photoCntParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM)
                } else {
                    nameParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM)
                }
            }


            dir_lock.beGone()
            val roundedCorners = when {
                isListViewType -> ROUNDED_CORNERS_SMALL
                folderStyle == FOLDER_STYLE_SQUARE -> ROUNDED_CORNERS_NONE
                else -> ROUNDED_CORNERS_BIG
            }

            activity.loadImage(thumbnailType, directory.tmb, dir_thumbnail, scrollHorizontally, animateGifs, cropThumbnails, roundedCorners, directory.getKey())

            if (limitFolderTitle) {
                dir_name.setSingleLine()
                dir_name.ellipsize = TextUtils.TruncateAt.MIDDLE
            }

            var nameCount = directory.name
            if (showMediaCount == FOLDER_MEDIA_CNT_BRACKETS) {
                nameCount += " (${directory.subfoldersMediaCount})"
            }

            if (groupDirectSubfolders) {
                if (directory.subfoldersCount > 1) {
                    nameCount += " [${directory.subfoldersCount}]"
                }
            }
            holder.itemView.dir_name.visibility = VISIBLE

            dir_name.text = nameCount.replace(context.resources.getString(R.string.hidden), "") + "(" + directory.subfoldersMediaCount.toString() + ")"


            if (isListViewType) {
//                dir_path.setTextColor(textColor)
                dir_pin.applyColorFilter(textColor)
                dir_location.applyColorFilter(textColor)
                dir_drag_handle.beVisibleIf(isDragAndDropping)
            } else {
                dir_drag_handle_wrapper.beVisibleIf(isDragAndDropping)
            }

            if (isDragAndDropping) {
                dir_drag_handle.applyColorFilter(textColor)
                dir_drag_handle.setOnTouchListener { v, event ->
                    if (event.action == MotionEvent.ACTION_DOWN) {
                        startReorderDragListener?.requestDrag(holder)
                    }
                    false
                }
            }
        }
    }

    override fun onRowMoved(fromPosition: Int, toPosition: Int) {
        if (fromPosition < toPosition) {
            for (i in fromPosition until toPosition) {
                Collections.swap(dirs, i, i + 1)
            }
        } else {
            for (i in fromPosition downTo toPosition + 1) {
                Collections.swap(dirs, i, i - 1)
            }
        }

        notifyItemMoved(fromPosition, toPosition)
    }

    override fun onRowSelected(myViewHolder: ViewHolder?) {
        swipeRefreshLayout?.isEnabled = false
    }

    override fun onRowClear(myViewHolder: ViewHolder?) {
        swipeRefreshLayout?.isEnabled = true
    }
}
