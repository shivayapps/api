package com.gallery.photo.image.video.activity

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activityBinding.BaseBindingActivity
import com.gallery.photo.image.video.adapter.AddHiddenMediaAdapter
import com.gallery.photo.image.video.databinding.ActivityAddHiddenMediaBinding
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.PhotoDirectoryFragment
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.fragment.VideoDirectoryFragment
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.models.ThumbnailSection
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.helpers.VIEW_TYPE_GRID
import com.gallery.photo.image.video.helpers.VIEW_TYPE_LIST
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager
import com.gallery.photo.image.video.views.MyRecyclerView
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import org.jetbrains.anko.toast

class AddHiddenMediaActivity : BaseBindingActivity<ActivityAddHiddenMediaBinding>(), MediaOperationsListener {

    var title: String? = null
    private var mPath = ""
    private var mIsGetImageIntent = false
    private var mIsGetVideoIntent = false
    private var mIsGetAnyIntent = false
    private var mIsGettingMedia = false
    private var mAllowPickingMultiple = false
    private var mShowAll = true
    private var mDateFormat = ""
    private var mTimeFormat = ""
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mLastSearchedText = ""
    var isFromOneSignal = false
    var isFromSettings = false
    var isScanFinished = false
    val mPermissionStorage = arrayOf(
        android.Manifest.permission.READ_EXTERNAL_STORAGE,
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
    )
    var selectedItemList = ArrayList<Medium>()
    override fun setParamBeforeLayoutInit() {
        super.setParamBeforeLayoutInit()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }


    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        mBinding.mediaEmptyTextPlaceholder.layoutParams.height = usableScreenSize.y - (statusBarHeight + navigationBarHeight)
        mBinding.imgBack.setOnClickListener {
            onBackPressed()
        }
    }

    override fun initActions() {
        mBinding.imgDone.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.imgDone -> {
                if (selectedItemList.size == 0) {
                    toast(getString(R.string.error_please_select_one_item))
                } else {
                    hideFiles()
                }
            }
        }
    }

    private fun hideFiles() {
        mBinding.llProgress.visibility = View.VISIBLE
        VaultFragment.isHideUnHideMedia = true
        ensureBackgroundThread {
            var prevPath = ""
            var hiddenDirectory = ArrayList<String>()
            selectedItemList.forEach {
                if (prevPath != it.parentPath) {
                    hiddenDirectory.add(it.parentPath)
                    prevPath = it.parentPath
                }
                toggleFileVisibility(it.path, true)

            }
            ensureBackgroundThread {
                hiddenDirectory.forEach {
                    if (directoryDao.getDirectoryDetailFromDirPath(it) != null)
                        hiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(it).getConvertedHiddenDirectory())
                }
            }

            runOnUiThread {
                Log.d("5646678979", "hideFiles: " + hiddenDirectory.size)
                config.hiddenCountForRate++
                PhotoDirectoryFragment.isNeedToRefresh = true
                VideoDirectoryFragment.isNeedToRefresh = true
                VaultFragment.isNeedToRefresh = true
                toast(getString(R.string.msg_hide_media_successfully))
                mBinding.llProgress.visibility = View.GONE
                finish()
            }

        }

    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun initViews() {
        intent.apply {
            mIsGetImageIntent = getBooleanExtra(GET_IMAGE_INTENT, false)
            mIsGetVideoIntent = getBooleanExtra(GET_VIDEO_INTENT, false)
            mIsGetAnyIntent = getBooleanExtra(GET_ANY_INTENT, false)
            mAllowPickingMultiple = getBooleanExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
        }

        try {
            mPath = intent.getStringExtra(DIRECTORY) ?: ""
            Log.d("tag ", "Path :: $mPath")
        } catch (e: Exception) {
            showErrorToast(e)
            finish()
            return
        }
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }
        mBinding.mediaRefreshLayout.setOnRefreshListener { getMedia() }
        if (checkPermissionStorage(mContext)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                checkAllFilePermission()
            } else {
                getMedia()
            }
        } else {
            givePermissions(mPermissionStorage)
        }

    }

    private fun checkPermissionStorage(mContext: Activity): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (checkPermissionabove11()) {
                return true
            }
            return false
        } else {
            return if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            ) {
                isUnLockApp = true
                isAppOpenAdShow = false
                ActivityCompat.requestPermissions(
                    this, arrayOf(android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE),
                    101
                )
                false
            } else {
                true
            }
        }


    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                getMedia()
            } else {
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                try {
                    launchActivityForResult(intent, 2296)
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun givePermissions(permissions: Array<String>) {

        isUnLockApp = true
        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                getMedia()
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionStorage)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(p0: MutableList<com.karumi.dexter.listener.PermissionRequest>?, token: PermissionToken?) {
                    token!!.continuePermissionRequest()
                }
            }).check()
    }

    private fun showSettingsDialog() {
        isUnLockApp = true
        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
        alertDialogBuilder.setTitle("Permissions Required")
            .setMessage("Please allow permission for storage")
            .setPositiveButton("OK")
            { dialog, which ->
                dialog.dismiss()
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)

            }
            .setNegativeButton("CANCEL") { dialog, which ->
                dialog.dismiss()
                finish()
            }
            .setCancelable(false)
        alertDialogBuilder.show()
    }


    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    getMedia()
                    Log.e("mTAG", "onActivityResult: Service Start ")
                } else {
                    if (isFromOneSignal) {
                        startActivity(MainActivity.newIntent(this))
                        finish()
                        Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        } else if (requestCode == 200) {
            if (checkPermissionStorage(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    getMedia()
                }
            } else {
                if (isFromOneSignal) {
                    startActivity(MainActivity.newIntent(this))
                    finish()
                    Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()

        if (isFromSettings) {
            isFromSettings = false
            if (checkPermissionStorage(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    getMedia()
                }
            }
        }
    }

    private fun getMedia() {
        startAsyncTask()
    }

    private fun startAsyncTask() {
        mBinding.llProgress.visibility = View.VISIBLE
        mBinding.mediaRefreshLayout.isEnabled = false
        getAllMedia( mPath, mIsGetImageIntent, mIsGetVideoIntent, mShowAll, TYPE_IMAGES or TYPE_VIDEOS, GROUP_BY_NONE, false) {
            ensureBackgroundThread {
                val oldMedia = mMedia.clone() as ArrayList<ThumbnailItem>
                val newMedia = it
                try {
                    newMedia.sortWith { o1, o2 ->
                        o1 as Medium
                        o2 as Medium
                        o2.modified.compareTo(o1.modified)
                    }
                    gotMedia(newMedia, false)

                } catch (e: Exception) {
                }
            }
        }
    }

    private fun gotMedia(media: ArrayList<ThumbnailItem>, isFromCache: Boolean) {
        mIsGettingMedia = false
        mMedia = media

        runOnUiThread {
            mBinding.mediaRefreshLayout.isRefreshing = false
            mBinding.mediaEmptyTextPlaceholder.beVisibleIf(media.isEmpty() && !isFromCache)
            mBinding.mediaEmptyTextPlaceholder2.beVisibleIf(media.isEmpty() && !isFromCache)

            if (mBinding.mediaEmptyTextPlaceholder.isVisible()) {
                mBinding.mediaEmptyTextPlaceholder.text = getString(R.string.no_media_with_filters)
            }
            mBinding.mediaGrid.beVisibleIf(mBinding.mediaEmptyTextPlaceholder.isGone())

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            val allowHorizontalScroll = config.scrollHorizontally && viewType == VIEW_TYPE_GRID
            mBinding.mediaVerticalFastscroller.beVisibleIf(mBinding.mediaGrid.isVisible() && !allowHorizontalScroll)
            mBinding.mediaHorizontalFastscroller.beVisibleIf(mBinding.mediaGrid.isVisible() && allowHorizontalScroll)
            setupAdapter()
        }

    }

    private fun getMediaAdapter() = mBinding.mediaGrid.adapter as? AddHiddenMediaAdapter

    private fun setupAdapter() {
        Handler(Looper.getMainLooper()).postDelayed({
            mBinding.llProgress.visibility = View.GONE
        }, 100)
        isScanFinished = true
        mBinding.mediaRefreshLayout.isEnabled = true
        if (!mShowAll && isDirEmpty()) {
            return
        }

        val currAdapter = mBinding.mediaGrid.adapter
        if (currAdapter == null) {
//            initZoomListener()
            val fastscroller = if (config.scrollHorizontally) mBinding.mediaHorizontalFastscroller else mBinding.mediaVerticalFastscroller
            AddHiddenMediaAdapter(
                this, mMedia.clone() as ArrayList<ThumbnailItem>, this, mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent,
                mAllowPickingMultiple, mPath, mBinding.mediaGrid, fastscroller
            ) {
                if (it is Medium && !isFinishing) {
                    itemClicked(it.path)
                }
            }.apply {
//                setupZoomListener(mZoomListener)
                mBinding.mediaGrid.adapter = this
            }

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            if (viewType == VIEW_TYPE_LIST) {
                mBinding.mediaGrid.scheduleLayoutAnimation()
            }

            setupLayoutManager()
            handleGridSpacing()
            measureRecyclerViewContent(mMedia)
        } else if (mLastSearchedText.isEmpty()) {
            (currAdapter as AddHiddenMediaAdapter).updateMedia(mMedia)
            handleGridSpacing()
            measureRecyclerViewContent(mMedia)
        }

        setupScrollDirection()
    }

    private fun itemClicked(path: String) {
        selectedItemList.clear()
        selectedItemList.addAll(getMediaAdapter()!!.getSelectedItemCount())
//        tvTitle.text = "${selectedItemList.size} Item selected"
        mBinding.tvTitle.text = getString(R.string.label_item_selected, selectedItemList.size)
    }


    private fun setupLayoutManager() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            setupGridLayoutManager()
        } else {
            setupListLayoutManager()
        }
    }

    private fun setupGridLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = 0
            bottomMargin = 0
        }

        if (config.scrollHorizontally) {
            layoutManager.orientation = RecyclerView.HORIZONTAL
        } else {
            layoutManager.orientation = RecyclerView.VERTICAL
        }

        layoutManager.spanCount = config.mediaColumnCnt
        val adapter = getMediaAdapter()
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter?.isASectionTitle(position) == true) {
                    layoutManager.spanCount
                } else {
                    1
                }
            }
        }
    }

    private fun setupScrollDirection() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        val allowHorizontalScroll = config.scrollHorizontally && viewType == VIEW_TYPE_GRID
        mBinding.mediaVerticalFastscroller.isHorizontal = false
        mBinding.mediaVerticalFastscroller.beGoneIf(allowHorizontalScroll)

        mBinding.mediaHorizontalFastscroller.isHorizontal = true
        mBinding.mediaHorizontalFastscroller.beVisibleIf(allowHorizontalScroll)

        val sorting = config.getFolderSorting(if (mShowAll) SHOW_ALL else mPath)
        if (allowHorizontalScroll) {
            mBinding.mediaHorizontalFastscroller.setViews(mBinding.mediaGrid, mBinding.mediaRefreshLayout) {
                mBinding.mediaHorizontalFastscroller.updateBubbleText(getBubbleTextItem(it, sorting!!))
            }
        } else {
            mBinding.mediaVerticalFastscroller.setViews(mBinding.mediaGrid, mBinding.mediaRefreshLayout) {
                mBinding.mediaVerticalFastscroller.updateBubbleText(getBubbleTextItem(it, sorting!!))
            }
        }
    }

    private fun getBubbleTextItem(index: Int, sorting: Int): String {
        var realIndex = index
        val mediaAdapter = getMediaAdapter()
        if (mediaAdapter!!.isASectionTitle(index)) {
            realIndex++
        }
        return mediaAdapter.getItemBubbleText(realIndex, sorting, mDateFormat, mTimeFormat) ?: ""
    }

    private fun isDirEmpty(): Boolean {
        return mMedia.size <= 0 && config.filterMedia > 0
    }

    private fun initZoomListener() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
            mZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 1) {
                        reduceColumnCount()
                        getMediaAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT) {
                        increaseColumnCount()
                        getMediaAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            mZoomListener = null
        }
    }

    private fun setupListLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL

        val smallMargin = resources.getDimension(R.dimen.small_margin).toInt()
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = smallMargin
            bottomMargin = smallMargin
        }

        mZoomListener = null
    }

    private fun increaseColumnCount() {
        config.mediaColumnCnt = ++(mBinding.mediaGrid.layoutManager as MyGridLayoutManager).spanCount
        columnCountChanged()
    }

    private fun reduceColumnCount() {
        config.mediaColumnCnt = --(mBinding.mediaGrid.layoutManager as MyGridLayoutManager).spanCount
        columnCountChanged()
    }

    private fun columnCountChanged() {
        handleGridSpacing()
        ActivityCompat.invalidateOptionsMenu(this)
        getMediaAdapter()?.apply {
            notifyItemRangeChanged(0, media.size)
            measureRecyclerViewContent(media)
        }
    }

    private fun measureRecyclerViewContent(media: ArrayList<ThumbnailItem>) {
        mBinding.mediaGrid.onGlobalLayout {
            if (config.scrollHorizontally) {
                calculateContentWidth(media)
            } else {
                calculateContentHeight(media)
            }
        }
    }

    private fun calculateContentWidth(media: ArrayList<ThumbnailItem>) {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        val thumbnailWidth = layoutManager.getChildAt(0)?.width ?: 0
        val spacing = config.thumbnailSpacing
        val fullWidth = ((media.size - 1) / layoutManager.spanCount + 1) * (thumbnailWidth + spacing) - spacing
        mBinding.mediaHorizontalFastscroller.setContentWidth(fullWidth)
        mBinding.mediaHorizontalFastscroller.setScrollToX(mBinding.mediaGrid.computeHorizontalScrollOffset())
    }

    private fun calculateContentHeight(media: ArrayList<ThumbnailItem>) {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        val pathToCheck = if (mPath.isEmpty()) SHOW_ALL else mPath
        val hasSections = config.getFolderGrouping(pathToCheck) and GROUP_BY_NONE == 0 && !config.scrollHorizontally
        val sectionTitleHeight = if (hasSections) layoutManager.getChildAt(0)?.height ?: 0 else 0
        val thumbnailHeight = if (hasSections) layoutManager.getChildAt(1)?.height ?: 0 else layoutManager.getChildAt(0)?.height ?: 0

        var fullHeight = 0
        var curSectionItems = 0
        media.forEach {
            if (it is ThumbnailSection) {
                fullHeight += sectionTitleHeight
                if (curSectionItems != 0) {
                    val rows = ((curSectionItems - 1) / layoutManager.spanCount + 1)
                    fullHeight += rows * thumbnailHeight
                }
                curSectionItems = 0
            } else {
                curSectionItems++
            }
        }
        val spacing = config.thumbnailSpacing
        fullHeight += ((curSectionItems - 1) / layoutManager.spanCount + 1) * (thumbnailHeight + spacing) - spacing
        mBinding.mediaVerticalFastscroller.setContentHeight(fullHeight)
        mBinding.mediaVerticalFastscroller.setScrollToY(mBinding.mediaGrid.computeVerticalScrollOffset())
    }


    private fun handleGridSpacing(media: ArrayList<ThumbnailItem> = mMedia) {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            val spanCount = config.mediaColumnCnt
            val spacing = config.thumbnailSpacing
            val useGridPosition = media.firstOrNull() is ThumbnailSection

            var currentGridDecoration: GridSpacingItemDecoration? = null
            if (mBinding.mediaGrid.itemDecorationCount > 0) {
                currentGridDecoration = mBinding.mediaGrid.getItemDecorationAt(0) as GridSpacingItemDecoration
                currentGridDecoration.items = media
            }

            val newGridDecoration = GridSpacingItemDecoration(spanCount, spacing, config.scrollHorizontally, config.fileRoundedCorners, media, useGridPosition)
            if (currentGridDecoration.toString() != newGridDecoration.toString()) {
                if (currentGridDecoration != null) {
                    mBinding.mediaGrid.removeItemDecoration(currentGridDecoration)
                }
                mBinding.mediaGrid.addItemDecoration(newGridDecoration)
            }
        }
    }

    companion object {
        var mMedia = ArrayList<ThumbnailItem>()

    }

    override fun refreshItems() {
        getMedia()
    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {
        val filtered = fileDirItems.filter { !getIsPathDirectory(it.path) && it.path.isMediaFile() } as ArrayList
        if (filtered.isEmpty()) {
            return
        }
        val deletingItems = resources.getQuantityString(R.plurals.deleting_items, filtered.size, filtered.size)
        toast(deletingItems)
        deleteFilteredFiles(filtered)
    }

    private fun deleteFilteredFiles(filtered: ArrayList<FileDirItem>) {
        deleteFiles(filtered) {
            if (!it) {
                toast(R.string.unknown_error_occurred)
                return@deleteFiles
            }

            mMedia.removeAll { filtered.map { it.path }.contains((it as? Medium)?.path) }

            ensureBackgroundThread {
                val useRecycleBin = config.useRecycleBin
                filtered.forEach {
                    deleteDBPath(it.path)
                }
            }

            if (MediaActivity.mMedia.isEmpty()) {
                deleteDirectoryIfEmpty()
                deleteDBDirectory()
                finish()
            }
        }
    }

    private fun deleteDirectoryIfEmpty() {
        if (config.deleteEmptyFolders) {
            val fileDirItem = FileDirItem(mPath, mPath.getFilenameFromPath(), true)
            if (!fileDirItem.isDownloadsFolder() && fileDirItem.isDirectory) {
                ensureBackgroundThread {
                    if (fileDirItem.getProperFileCount(this, true) == 0) {
                        tryDeleteFileDirItem(fileDirItem, true, true)
                    }
                }
            }
        }
    }

    private fun deleteDBDirectory() {
        ensureBackgroundThread {
            try {
                directoryDao.deleteDirPath(mPath)
            } catch (ignored: Exception) {
            }
        }
    }

    override fun selectedPaths(paths: ArrayList<String>) {
        Intent().apply {
            putExtra(PICKED_PATHS, paths)
            setResult(Activity.RESULT_OK, this)
        }
        finish()
    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {
        var currentGridPosition = 0
        media.forEach {
            if (it is Medium) {
                it.gridPosition = currentGridPosition++
            } else if (it is ThumbnailSection) {
                currentGridPosition = 0
            }
        }

        if (mBinding.mediaGrid.itemDecorationCount > 0) {
            val currentGridDecoration = mBinding.mediaGrid.getItemDecorationAt(0) as GridSpacingItemDecoration
            currentGridDecoration.items = media
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        if (mBinding.llProgress.visibility == View.VISIBLE)
            mBinding.llProgress.visibility = View.GONE
        if (isFromOneSignal) {
            startActivity(Intent(this, MainActivity::class.java))
        }
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun setBinding(): ActivityAddHiddenMediaBinding {
        return ActivityAddHiddenMediaBinding.inflate(inflater)
    }
}