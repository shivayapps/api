package com.gallery.photo.image.video.interfaces

import androidx.room.*
import com.gallery.photo.image.video.models.UData

@Dao
interface UDataDao {

    @Insert
    fun add(data: UData): Long

    @Query("select * from UData where title=:title")
    fun get(title: String): UData?

    @Update
    fun update(data: UData)

    @Query("UPDATE UData SET val = :value where title=:title")
    fun updateCount(title: String, value: Int)

    @Delete
    fun delete(data: UData)
}