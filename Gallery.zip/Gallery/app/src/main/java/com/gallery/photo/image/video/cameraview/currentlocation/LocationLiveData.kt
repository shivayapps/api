package com.gallery.photo.image.video.cameraview.currentlocation

import android.annotation.SuppressLint
import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.util.Log
import androidx.lifecycle.LiveData
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.utilities.AUTOMATIC
import com.gallery.photo.image.video.utilities.AsyncBackgroundWork
import com.gallery.photo.image.video.utilities.SharedPrefs
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import java.io.IOException
import java.util.*

class LocationLiveData(val context: Context) : LiveData<LocationModel>() {

    private var fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)

    override fun onInactive() {
        super.onInactive()
        fusedLocationClient.removeLocationUpdates(locationCallback)
    }


    @SuppressLint("MissingPermission")
    override fun onActive() {
        super.onActive()
        fusedLocationClient.lastLocation
                .addOnSuccessListener { location: Location? ->
                    location?.also {
                        var address = ""
                        val geocoder = Geocoder(context, Locale.getDefault())
                        var addresses: List<Address?> = ArrayList()
                        try {
                            addresses = geocoder.getFromLocation(it.latitude, it.longitude, 1)
                        } catch (e: IOException) {
                            Log.e("TAG", "doInBackground: Could not find address" + e.message)
                        }
                        if (addresses.isNotEmpty()) {
                            address = addresses[0]!!.getAddressLine(0)
                            Log.e("Location Address", "--->$address")
                        }
                        getAddressToLatLong(it)
                    }
                }
        startLocationUpdates()
    }

    private fun getAddressToLatLong(location: Location) {
        var address = ""
        val geocoder = Geocoder(context, Locale.getDefault())
        var addresses: List<Address?> = ArrayList()

        val string: String = SharedPrefs.getString(context, SharedPrefs.LOCATION_TYPE, AUTOMATIC)
        if (string != null && string.isNotEmpty() && string == AUTOMATIC && context.isOnline()) {
            AsyncBackgroundWork({

            }, {
                try {
                    addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
                } catch (e: IOException) {
                    Log.e("TAG", "doInBackground: Could not find address" + e.message)
                }
            }, {
                if (addresses.isNotEmpty()) {
                    address = addresses[0]!!.getAddressLine(0)
                }
                try {
                    val fromLocation = geocoder.getFromLocation(location.latitude, location.longitude, 1)
                    if (fromLocation != null && fromLocation.size > 0) {
//                        SharedPrefs.save(context, SharedPrefs.LATITUDE, "")
//                        SharedPrefs.save(context, SharedPrefs.LONGITUDE, "")
//                        SharedPrefs.save(context, SharedPrefs.LOC_LINE_1_ADDRESS, fromLocation[0].getAddressLine(0))
//                        SharedPrefs.save(context, SharedPrefs.LOC_LINE_2_CITY, fromLocation[0].locality)
//                        SharedPrefs.save(context, SharedPrefs.LOC_LINE_3_STATE, fromLocation[0].adminArea)
//                        SharedPrefs.save(context, SharedPrefs.LOC_LINE_4_COUNTRY, fromLocation[0].countryName)
                    }
                } catch (e: IOException) {

                }
                setLocationData(location, address)
            })
        }
    }

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                null
        )
    }

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult?) {
            locationResult ?: return
            for (location in locationResult.locations) {
                getAddressToLatLong(location)
            }
        }
    }

    private fun setLocationData(location: Location, address: String) {
        value = LocationModel(
                longitude = location.longitude,
                latitude = location.latitude,
                address = address
        )
    }

    companion object {
        val locationRequest: LocationRequest = LocationRequest.create().apply {
            interval = 1000
            fastestInterval = 1000
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }
    }
}

data class LocationModel(
        val longitude: Double = 0.0,
        val latitude: Double = 0.0,
        val address: String = ""

)
