package com.gallery.photo.image.video.cameraview.database.model

import android.graphics.Color
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.gallery.photo.image.video.utilities.AUTOMATIC
import com.gallery.photo.image.video.utilities.DEFAULT_DATE_FORMAT
import java.io.Serializable

@Entity(tableName = "CameraStamp")
data class CameraStamp(
    @PrimaryKey(autoGenerate = true)
    var id: Int?,
    var stampId: Int = 0,
    var stampPath: String = "",
//    var locationType: String = AUTOMATIC,
    var message: String = "",
//    var latitude: Double = 0.0,
//    var longitude: Double = 0.0,
    var dateTime: String = DEFAULT_DATE_FORMAT,
    var transparency: Float = 90F,
    var fontColor: Int = Integer.valueOf(Color.parseColor("#ffffff"))
) : Serializable