package com.gallery.photo.image.video.activity

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adapter.AddHiddenMediaAdapter
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.models.ThumbnailSection
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.helpers.VIEW_TYPE_GRID
import com.gallery.photo.image.video.helpers.VIEW_TYPE_LIST
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager
import com.gallery.photo.image.video.views.MyRecyclerView
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlinx.android.synthetic.main.activity_add_image_in_new_folder_new.*
import org.jetbrains.anko.toast
import java.io.File

class AddImageInNewFolderNewActivity : BaseActivity(), MediaOperationsListener {

    var title: String? = null
    private var mPath = ""
    private var mIsGetImageIntent = false
    private var mIsGetVideoIntent = false
    private var mIsGetAnyIntent = false
    private var mIsGettingMedia = false
    private var mAllowPickingMultiple = false
    private var mShowAll = true
    private var mLoadedInitialPhotos = false
    private var mDateFormat = ""
    private var mTimeFormat = ""

    private var mLatestMediaId = 0L
    private var mLatestMediaDateId = 0L
    private var mLastMediaHandler = Handler()
    private var mTempShowHiddenHandler = Handler()
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mSearchMenuItem: MenuItem? = null
    private var mLastSearchedText = ""
    var isFromOneSignal = false
    var isFromSettings = false
    var isScanFinished = false
    val mPermissionStorage = arrayOf(
        android.Manifest.permission.READ_EXTERNAL_STORAGE,
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
    )
    var selectedItemList = ArrayList<Medium>()

    private var AlbumName = ""
    private var FileDir = ""
    public var viewPager_Position: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_image_in_new_folder_new)

    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        FileDir = intent.getStringExtra("FileDir")!!
        AlbumName = intent.getStringExtra("Album Name")!!
        viewPager_Position = intent.getIntExtra("ViewPager_Position", 0)

        media_empty_text_placeholder.layoutParams.height = usableScreenSize.y - (statusBarHeight + navigationBarHeight)
        imgBack.setOnClickListener {
            onBackPressed()
        }
        tvTitle.text = getString(R.string.label_item_selected, selectedItemList.size)
    }

    override fun initActions() {
        imgDone.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.imgDone -> {
                if (selectedItemList.size == 0) {
                    toast(getString(R.string.error_please_select_one_item))
                } else {
                    copyFiles(true)
                }
            }
        }
    }

    private fun copyFiles(isCopyOperation: Boolean) {
        ll_progress.visibility = View.VISIBLE
        val paths = ArrayList<String>()
        var list = selectedItemList
        list.forEach { it ->
            paths.add(it.path)
        }
        val fileDirItems = paths.asSequence().filter { isCopyOperation || !it.startsWith(recycleBinPath) }.map {
            FileDirItem(it, it.getFilenameFromPath())
        }.toMutableList() as java.util.ArrayList

        if (!isCopyOperation && paths.any { it.startsWith(recycleBinPath) }) {
            toast(R.string.moving_recycle_bin_items_disabled, Toast.LENGTH_LONG)
        }

        if (fileDirItems.isEmpty()) {
            return
        }

        newFileAdd(fileDirItems, fileDirItems[0].getParentPath().trimEnd('/'), FileDir, isCopyOperation, true, config.shouldShowHidden)
        {

            runOnUiThread {
                ll_progress.visibility = View.GONE
                config.tempFolderPath = ""

                if (viewPager_Position == 0) {
                    ensureBackgroundThread {
                        updatePhotoVideoDirectoryPath(it, true, false)
                    }
                } else {
                    ensureBackgroundThread {
                        updatePhotoVideoDirectoryPath(it, false, true)
                    }
                }
                val newPaths = fileDirItems.map { "$FileDir/${it.name}" }.toMutableList() as java.util.ArrayList<String>
                newPaths.forEach {
                    MediaScannerConnection.scanFile(
                        this, arrayOf(File(it).toString()),
                        null, null
                    )
                }
                applicationContext.rescanFolderMedia(fileDirItems.first().getParentPath())

                MainActivity.isNeedToRefresh = true
                toast(getString(R.string.msg_new_album_created_success_fully))

                finish()
                Log.e("TAG", "copyMoveTo: $it")
            }

        }

    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun initViews() {
        intent.apply {
            mIsGetImageIntent = getBooleanExtra(GET_IMAGE_INTENT, false)
            mIsGetVideoIntent = getBooleanExtra(GET_VIDEO_INTENT, false)
            mIsGetAnyIntent = getBooleanExtra(GET_ANY_INTENT, false)
            mAllowPickingMultiple = getBooleanExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
        }

        try {
            mPath = intent.getStringExtra(DIRECTORY) ?: ""
            Log.d("tag ", "Path :: $mPath")
        } catch (e: Exception) {
            showErrorToast(e)
            finish()
            return
        }
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }
        media_refresh_layout.setOnRefreshListener { getMedia() }
        if (checkPermissionStorage(mContext)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                checkAllFilePermission()
            } else {
                getMedia()
            }
        } else {
            givePermissions(mPermissionStorage)
        }

    }

    private fun checkPermissionStorage(mContext: Activity): Boolean {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//            if (checkPermissionabove11()) {
//                return true
//            }
//            return false
//        } else {
            return if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            ) {
                isUnLockApp = true
                isAppOpenAdShow = false
                ActivityCompat.requestPermissions(
                    this, arrayOf(android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE),
                    101
                )
                false
            } else {
                true
            }
//        }
    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                getMedia()
            } else {
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                try {
                    launchActivityForResult(intent, 2296)
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun givePermissions(permissions: Array<String>) {

        isUnLockApp = true
        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                getMedia()
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionStorage)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(p0: MutableList<com.karumi.dexter.listener.PermissionRequest>?, token: PermissionToken?) {
                    token!!.continuePermissionRequest()
                }
            }).check()
    }

    private fun showSettingsDialog() {
        isUnLockApp = true
        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
        alertDialogBuilder.setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>" + getString(R.string.error_permission_required) + "</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))
            .setMessage(getString(R.string.msg_allow_permission_storage))
            .setPositiveButton(getString(R.string.ok))
            { dialog, which ->
                dialog.dismiss()
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
            .setNegativeButton(getString(R.string.cancel)) { dialog, which ->
                dialog.dismiss()
                finish()
            }
            .setCancelable(false)
        alertDialogBuilder.show()
    }


    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    getMedia()
                    Log.e("mTAG", "onActivityResult: Service Start ")
                } else {
                    if (isFromOneSignal) {
                        startActivity(MainActivity.newIntent(this))
                        finish()
                        Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        } else if (requestCode == 200) {
            if (checkPermissionStorage(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    getMedia()
                }
            } else {
                if (isFromOneSignal) {
                    startActivity(MainActivity.newIntent(this))
                    finish()
                    Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()

        if (isFromSettings) {
            isFromSettings = false
            if (checkPermissionStorage(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    getMedia()
                }
            }
        }

    }

    private fun getMedia() {
        startAsyncTask()
    }

    private fun startAsyncTask() {
        ll_progress.visibility = View.VISIBLE
        media_refresh_layout.isEnabled = false

        getAllMedia(mPath, mIsGetImageIntent, mIsGetVideoIntent, mShowAll, TYPE_IMAGES or TYPE_VIDEOS, GROUP_BY_NONE, false) {
            ensureBackgroundThread {
                val oldMedia = mMedia.clone() as ArrayList<ThumbnailItem>
                val newMedia = it
                try {
                    gotMedia(newMedia, false)
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun gotMedia(media: ArrayList<ThumbnailItem>, isFromCache: Boolean) {
        mIsGettingMedia = false

        if (viewPager_Position == 0)
            mMedia = media.filter { (it as Medium).type == TYPE_IMAGES } as ArrayList<ThumbnailItem>
        else
            mMedia = media.filter { (it as Medium).type == TYPE_VIDEOS } as ArrayList<ThumbnailItem>

        runOnUiThread {
            media_refresh_layout.isRefreshing = false
            media_empty_text_placeholder.beVisibleIf(media.isEmpty() && !isFromCache)
            media_empty_text_placeholder_2.beVisibleIf(media.isEmpty() && !isFromCache)

            if (media_empty_text_placeholder.isVisible()) {
                media_empty_text_placeholder.text = getString(R.string.no_media_with_filters)
            }
            media_grid.beVisibleIf(media_empty_text_placeholder.isGone())

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            val allowHorizontalScroll = config.scrollHorizontally && viewType == VIEW_TYPE_GRID
            media_vertical_fastscroller.beVisibleIf(media_grid.isVisible() && !allowHorizontalScroll)
            media_horizontal_fastscroller.beVisibleIf(media_grid.isVisible() && allowHorizontalScroll)
            setupAdapter()
        }
    }

    private fun getMediaAdapter() = media_grid.adapter as? AddHiddenMediaAdapter

    private fun setupAdapter() {
        Handler().postDelayed({
            ll_progress.visibility = View.GONE
        }, 100)
        isScanFinished = true
        media_refresh_layout.isEnabled = true
        if (!mShowAll && isDirEmpty()) {
            return
        }

        val currAdapter = media_grid.adapter
        if (currAdapter == null) {
            val fastscroller = if (config.scrollHorizontally) media_horizontal_fastscroller else media_vertical_fastscroller
            AddHiddenMediaAdapter(
                this, mMedia.clone() as ArrayList<ThumbnailItem>, this, mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent,
                mAllowPickingMultiple, mPath, media_grid, fastscroller
            ) {
                if (it is Medium && !isFinishing) {
                    itemClicked(it.path)
                }
            }.apply {
                media_grid.adapter = this
            }

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            if (viewType == VIEW_TYPE_LIST) {
                media_grid.scheduleLayoutAnimation()
            }

            setupLayoutManager()
            handleGridSpacing()
            measureRecyclerViewContent(mMedia)
        } else if (mLastSearchedText.isEmpty()) {
            (currAdapter as AddHiddenMediaAdapter).updateMedia(mMedia)
            handleGridSpacing()
            measureRecyclerViewContent(mMedia)
        }

        setupScrollDirection()
    }

    private fun itemClicked(path: String) {
        selectedItemList.clear()
        selectedItemList.addAll(getMediaAdapter()!!.getSelectedItemCount())
        tvTitle.text = getString(R.string.label_item_selected, selectedItemList.size)
    }

    private fun setupLayoutManager() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            setupGridLayoutManager()
        } else {
            setupListLayoutManager()
        }
    }

    private fun setupGridLayoutManager() {
        val layoutManager = media_grid.layoutManager as MyGridLayoutManager
        (media_grid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = 0
            bottomMargin = 0
        }

        if (config.scrollHorizontally) {
            layoutManager.orientation = RecyclerView.HORIZONTAL
        } else {
            layoutManager.orientation = RecyclerView.VERTICAL
        }

        layoutManager.spanCount = config.mediaColumnCnt
        val adapter = getMediaAdapter()
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter?.isASectionTitle(position) == true) {
                    layoutManager.spanCount
                } else {
                    1
                }
            }
        }
    }

    private fun setupScrollDirection() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        val allowHorizontalScroll = config.scrollHorizontally && viewType == VIEW_TYPE_GRID
        media_vertical_fastscroller.isHorizontal = false
        media_vertical_fastscroller.beGoneIf(allowHorizontalScroll)

        media_horizontal_fastscroller.isHorizontal = true
        media_horizontal_fastscroller.beVisibleIf(allowHorizontalScroll)

        val sorting = config.getFolderSorting(if (mShowAll) SHOW_ALL else mPath)
        if (allowHorizontalScroll) {
            media_horizontal_fastscroller.setViews(media_grid, media_refresh_layout) {
                media_horizontal_fastscroller.updateBubbleText(getBubbleTextItem(it, sorting!!))
            }
        } else {
            media_vertical_fastscroller.setViews(media_grid, media_refresh_layout) {
                media_vertical_fastscroller.updateBubbleText(getBubbleTextItem(it, sorting!!))
            }
        }
    }

    private fun getBubbleTextItem(index: Int, sorting: Int): String {
        var realIndex = index
        val mediaAdapter = getMediaAdapter()
        if (mediaAdapter!!.isASectionTitle(index)) {
            realIndex++
        }
        return mediaAdapter.getItemBubbleText(realIndex, sorting, mDateFormat, mTimeFormat) ?: ""
    }

    private fun isDirEmpty(): Boolean {
        return mMedia.size <= 0 && config.filterMedia > 0
    }

    private fun setupListLayoutManager() {
        val layoutManager = media_grid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL

        val smallMargin = resources.getDimension(R.dimen.small_margin).toInt()
        (media_grid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = smallMargin
            bottomMargin = smallMargin
        }

        mZoomListener = null
    }

    private fun increaseColumnCount() {
        config.mediaColumnCnt = ++(media_grid.layoutManager as MyGridLayoutManager).spanCount
        columnCountChanged()
    }

    private fun reduceColumnCount() {
        config.mediaColumnCnt = --(media_grid.layoutManager as MyGridLayoutManager).spanCount
        columnCountChanged()
    }

    private fun columnCountChanged() {
        handleGridSpacing()
        ActivityCompat.invalidateOptionsMenu(this)
        getMediaAdapter()?.apply {
            notifyItemRangeChanged(0, media.size)
            measureRecyclerViewContent(media)
        }
    }

    private fun measureRecyclerViewContent(media: ArrayList<ThumbnailItem>) {
        media_grid.onGlobalLayout {
            if (config.scrollHorizontally) {
                calculateContentWidth(media)
            } else {
                calculateContentHeight(media)
            }
        }
    }

    private fun calculateContentWidth(media: ArrayList<ThumbnailItem>) {
        val layoutManager = media_grid.layoutManager as MyGridLayoutManager
        val thumbnailWidth = layoutManager.getChildAt(0)?.width ?: 0
        val spacing = config.thumbnailSpacing
        val fullWidth = ((media.size - 1) / layoutManager.spanCount + 1) * (thumbnailWidth + spacing) - spacing
        media_horizontal_fastscroller.setContentWidth(fullWidth)
        media_horizontal_fastscroller.setScrollToX(media_grid.computeHorizontalScrollOffset())
    }

    private fun calculateContentHeight(media: ArrayList<ThumbnailItem>) {
        val layoutManager = media_grid.layoutManager as MyGridLayoutManager
        val pathToCheck = if (mPath.isEmpty()) SHOW_ALL else mPath
        val hasSections = config.getFolderGrouping(pathToCheck) and GROUP_BY_NONE == 0 && !config.scrollHorizontally
        val sectionTitleHeight = if (hasSections) layoutManager.getChildAt(0)?.height ?: 0 else 0
        val thumbnailHeight = if (hasSections) layoutManager.getChildAt(1)?.height ?: 0 else layoutManager.getChildAt(0)?.height ?: 0

        var fullHeight = 0
        var curSectionItems = 0
        media.forEach {
            if (it is ThumbnailSection) {
                fullHeight += sectionTitleHeight
                if (curSectionItems != 0) {
                    val rows = ((curSectionItems - 1) / layoutManager.spanCount + 1)
                    fullHeight += rows * thumbnailHeight
                }
                curSectionItems = 0
            } else {
                curSectionItems++
            }
        }
        val spacing = config.thumbnailSpacing
        fullHeight += ((curSectionItems - 1) / layoutManager.spanCount + 1) * (thumbnailHeight + spacing) - spacing
        media_vertical_fastscroller.setContentHeight(fullHeight)
        media_vertical_fastscroller.setScrollToY(media_grid.computeVerticalScrollOffset())
    }


    private fun handleGridSpacing(media: ArrayList<ThumbnailItem> = mMedia) {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            val spanCount = config.mediaColumnCnt
            val spacing = config.thumbnailSpacing
            val useGridPosition = media.firstOrNull() is ThumbnailSection

            var currentGridDecoration: GridSpacingItemDecoration? = null
            if (media_grid.itemDecorationCount > 0) {
                currentGridDecoration = media_grid.getItemDecorationAt(0) as GridSpacingItemDecoration
                currentGridDecoration.items = media
            }

            val newGridDecoration = GridSpacingItemDecoration(spanCount, spacing, config.scrollHorizontally, config.fileRoundedCorners, media, useGridPosition)
            if (currentGridDecoration.toString() != newGridDecoration.toString()) {
                if (currentGridDecoration != null) {
                    media_grid.removeItemDecoration(currentGridDecoration)
                }
                media_grid.addItemDecoration(newGridDecoration)
            }
        }
    }

    companion object {
        var mMedia = ArrayList<ThumbnailItem>()

    }

    override fun refreshItems() {
        getMedia()
    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {
        val filtered = fileDirItems.filter { !getIsPathDirectory(it.path) && it.path.isMediaFile() } as ArrayList
        if (filtered.isEmpty()) {
            return
        }
        val deletingItems = resources.getQuantityString(R.plurals.deleting_items, filtered.size, filtered.size)
        toast(deletingItems)
        deleteFilteredFiles(filtered)
    }

    private fun deleteFilteredFiles(filtered: ArrayList<FileDirItem>) {
        deleteFiles(filtered) {
            if (!it) {
                toast(R.string.unknown_error_occurred)
                return@deleteFiles
            }

            mMedia.removeAll { filtered.map { it.path }.contains((it as? Medium)?.path) }

            ensureBackgroundThread {
                filtered.forEach {
                    deleteDBPath(it.path)
                }
            }

            if (MediaActivity.mMedia.isEmpty()) {
                deleteDirectoryIfEmpty()
                deleteDBDirectory()
                finish()
            }
        }
    }

    private fun deleteDirectoryIfEmpty() {
        if (config.deleteEmptyFolders) {
            val fileDirItem = FileDirItem(mPath, mPath.getFilenameFromPath(), true)
            if (!fileDirItem.isDownloadsFolder() && fileDirItem.isDirectory) {
                ensureBackgroundThread {
                    if (fileDirItem.getProperFileCount(this, true) == 0) {
                        tryDeleteFileDirItem(fileDirItem, true, true)
                    }
                }
            }
        }
    }

    private fun deleteDBDirectory() {
        ensureBackgroundThread {
            try {
                directoryDao.deleteDirPath(mPath)
            } catch (ignored: Exception) {
            }
        }
    }

    override fun selectedPaths(paths: ArrayList<String>) {
        Intent().apply {
            putExtra(PICKED_PATHS, paths)
            setResult(Activity.RESULT_OK, this)
        }
        finish()
    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {
        var currentGridPosition = 0
        media.forEach {
            if (it is Medium) {
                it.gridPosition = currentGridPosition++
            } else if (it is ThumbnailSection) {
                currentGridPosition = 0
            }
        }

        if (media_grid.itemDecorationCount > 0) {
            val currentGridDecoration = media_grid.getItemDecorationAt(0) as GridSpacingItemDecoration
            currentGridDecoration.items = media
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        config.tempFolderPath=""
        if (ll_progress.visibility == View.VISIBLE)
            ll_progress.visibility = View.GONE
        if (isFromOneSignal) {
            startActivity(Intent(this, MainActivity::class.java))
        }
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}