package com.gallery.photo.image.video.Camera;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.util.Log;

import java.util.ArrayList;
import java.util.Locale;

public class SpeechControl {
    private static final String TAG = "SpeechControl";
    /* access modifiers changed from: private */
    public final CameraActivity main_activity;
    private SpeechRecognizer speechRecognizer;
    /* access modifiers changed from: private */
    public boolean speechRecognizerIsStarted;

    private void speechRecognizerStopped() {
    }

    /* access modifiers changed from: package-private */
    public void speechRecognizerStarted() {
    }

    public SpeechControl(CameraActivity cameraActivity) {
        this.main_activity = cameraActivity;
    }

    /* access modifiers changed from: package-private */
    public void startSpeechRecognizerIntent() {
        Log.d(TAG, "startSpeechRecognizerIntent");
        if (this.speechRecognizer != null) {
            Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
            intent.putExtra("android.speech.extra.LANGUAGE", "en_US");
            this.speechRecognizer.startListening(intent);
        }
    }

    public void initSpeechRecognizer() {
        Log.d(TAG, "initSpeechRecognizer");
        boolean equals = PreferenceManager.getDefaultSharedPreferences(this.main_activity).getString(PreferenceKeys.AudioControlPreferenceKey, "none").equals("voice");
        SpeechRecognizer speechRecognizer2 = this.speechRecognizer;
        if (speechRecognizer2 == null && equals) {
            Log.d(TAG, "create new speechRecognizer");
            SpeechRecognizer createSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(this.main_activity);
            this.speechRecognizer = createSpeechRecognizer;
            if (createSpeechRecognizer != null) {
                this.speechRecognizerIsStarted = false;
                createSpeechRecognizer.setRecognitionListener(new RecognitionListener() {
                    public void onRmsChanged(float f) {
                    }

                    private void restart() {
                        Log.d(SpeechControl.TAG, "RecognitionListener: restart");
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            public void run() {
                                SpeechControl.this.startSpeechRecognizerIntent();
                            }
                        }, 250);
                    }

                    public void onBeginningOfSpeech() {
                        Log.d(SpeechControl.TAG, "RecognitionListener: onBeginningOfSpeech");
                        if (!SpeechControl.this.speechRecognizerIsStarted) {
                            Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                        }
                    }

                    public void onBufferReceived(byte[] bArr) {
                        Log.d(SpeechControl.TAG, "RecognitionListener: onBufferReceived");
                        if (!SpeechControl.this.speechRecognizerIsStarted) {
                            Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                        }
                    }

                    public void onEndOfSpeech() {
                        Log.d(SpeechControl.TAG, "RecognitionListener: onEndOfSpeech");
                        if (!SpeechControl.this.speechRecognizerIsStarted) {
                            Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                        } else {
                            restart();
                        }
                    }

                    public void onError(int i) {
                        Log.d(SpeechControl.TAG, "RecognitionListener: onError: " + i);
                        if (!SpeechControl.this.speechRecognizerIsStarted) {
                            Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                        } else if (i != 7) {
                            restart();
                        }
                    }

                    public void onEvent(int i, Bundle bundle) {
                        Log.d(SpeechControl.TAG, "RecognitionListener: onEvent");
                        if (!SpeechControl.this.speechRecognizerIsStarted) {
                            Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                        }
                    }

                    public void onPartialResults(Bundle bundle) {
                        Log.d(SpeechControl.TAG, "RecognitionListener: onPartialResults");
                        if (!SpeechControl.this.speechRecognizerIsStarted) {
                            Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                        }
                    }

                    public void onReadyForSpeech(Bundle bundle) {
                        Log.d(SpeechControl.TAG, "RecognitionListener: onReadyForSpeech");
                        if (!SpeechControl.this.speechRecognizerIsStarted) {
                            Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                        }
                    }

                    public void onResults(Bundle bundle) {
                        Log.d(SpeechControl.TAG, "RecognitionListener: onResults");
                        if (!SpeechControl.this.speechRecognizerIsStarted) {
                            Log.d(SpeechControl.TAG, "...but speech recognition already stopped");
                            return;
                        }
                        ArrayList<String> stringArrayList = bundle.getStringArrayList("results_recognition");
                        int i = 0;
                        boolean z = false;
                        while (stringArrayList != null && i < stringArrayList.size()) {
                            String str = stringArrayList.get(i);
                            float[] floatArray = bundle.getFloatArray("confidence_scores");
                            if (floatArray != null) {
                                Log.d(SpeechControl.TAG, "text: " + str + " score: " + floatArray[i]);
                            }
                            if (str.toLowerCase(Locale.US).contains("cheese")) {
                                z = true;
                            }
                            i++;
                        }
                        if (z) {
                            Log.d(SpeechControl.TAG, "audio trigger from speech recognition");
                            SpeechControl.this.main_activity.audioTrigger();
                        } else if (stringArrayList != null && stringArrayList.size() > 0) {
                            String str2 = stringArrayList.get(0) + "?";
                            Log.d(SpeechControl.TAG, "unrecognised: " + str2);
                            SpeechControl.this.main_activity.getPreview().showToast(SpeechControl.this.main_activity.getAudioControlToast(), str2);
                        }
                    }
                });
                boolean inImmersiveMode = this.main_activity.getMainUI().inImmersiveMode();
            }
        } else if (speechRecognizer2 != null && !equals) {
            Log.d(TAG, "stop existing SpeechRecognizer");
            stopSpeechRecognizer();
        }
    }

    private void freeSpeechRecognizer() {
        Log.d(TAG, "freeSpeechRecognizer");
        this.speechRecognizer.cancel();
        try {
            this.speechRecognizer.destroy();
        } catch (IllegalArgumentException e) {
            Log.e(TAG, "exception destroying speechRecognizer");
            e.printStackTrace();
        }
        this.speechRecognizer = null;
    }

    public void stopSpeechRecognizer() {
        Log.d(TAG, "stopSpeechRecognizer");
        if (this.speechRecognizer != null) {
            speechRecognizerStopped();
            freeSpeechRecognizer();
        }
    }

    /* access modifiers changed from: package-private */
    public boolean isStarted() {
        return this.speechRecognizerIsStarted;
    }

    public void stopListening() {
        this.speechRecognizer.stopListening();
        speechRecognizerStopped();
    }

    public boolean hasSpeechRecognition() {
        return this.speechRecognizer != null;
    }
}
