package com.gallery.photo.image.video.activityBinding

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.ExifInterface
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.text.HtmlCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.app.ads.helper.GiftIconHelper
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.gallery.MimeType
import com.example.gallery.internal.entity.Album
import com.example.gallery.internal.entity.Item
import com.example.gallery.internal.entity.SelectionSpec
import com.example.gallery.internal.model.AlbumMediaCollection
import com.example.jdrodi.utilities.isOnline
import com.example.jdrodi.utilities.toast
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.ImagePreviewActivity
import com.gallery.photo.image.video.activity.MainActivity
import com.gallery.photo.image.video.adapter.RecoverPhotoAdapter
import com.gallery.photo.image.video.adapter.TimelineAdapter
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.databinding.ActivityTimelineBinding
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.models.ThumbnailSection
import com.gallery.photo.image.video.stories.StoryContent
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.videoplayer.VideoPlayerActivity
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager
import com.gallery.photo.image.video.views.MyRecyclerView
import com.google.android.material.appbar.AppBarLayout
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import org.jetbrains.anko.toast
import java.io.File
import java.io.IOException
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class TimeLineActivity : BaseBindingActivity<ActivityTimelineBinding>(), MediaOperationsListener {

    var title: String? = null
    var isFromOneSignal = false
    var isFromSettings = false
    var isScanFinished = false
    val mPermissionStorage = arrayOf(
        android.Manifest.permission.READ_EXTERNAL_STORAGE,
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
    )

    //Add New
    private var mTitle = ""
    private var mPath = ""
    private var mIsGetImageIntent = false
    private var mIsGetVideoIntent = false
    private var mIsGetAnyIntent = false
    private var mIsGettingMedia = false
    private var mAllowPickingMultiple = false
    private var mShowAll = true
    private var mShowAllGroup = true
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mLastSearchedText = ""
    var mMedia = ArrayList<ThumbnailItem>()
    var storyList = ArrayList<ArrayList<StoryContent>>()
    var isVideoClicked = false
    var isDataLoaded = false
    var isStoryDataLoaded = false
    override fun getContext(): Activity {
        return this
    }

    companion object {
        var isDeleteOrRestore = false
        fun newIntent(mContext: Context): Intent {
            return Intent(mContext, TimeLineActivity::class.java)
        }

        var isNeedToRefresh = false

    }

    override fun initData() {

        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            InterstitialAdHelper.loadInterstitialAd(fContext = this)
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = mBinding.giftLayout.giftAdIcon,
                fivBlastIcon = mBinding.giftLayout.giftBlastAdIcon
            )
        }
        mBinding.mediaRefreshLayout.isEnabled = false

        try {
            mTitle = intent.getStringExtra(PATH) ?: ""
            Log.d("tag ", "Path :: $mTitle")
        } catch (e: Exception) {
            e.printStackTrace()
        }

        mBinding.mediaEmptyTextPlaceholder.layoutParams.height = usableScreenSize.y - (statusBarHeight + navigationBarHeight)
        mBinding.imgBack.setOnClickListener {
            onBackPressed()
        }

        mBinding.appBarLayout.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { appBarLayout, verticalOffset ->
            Log.d(TAG, "initData: Vertical Offset -->" + verticalOffset)
            if (isDataLoaded && isStoryDataLoaded) {
                mBinding.mediaRefreshLayout.isEnabled = verticalOffset == 0
            } else {
                mBinding.mediaRefreshLayout.isEnabled = false
            }
        })

        mBinding.rvTimeLine.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                mBinding.mediaRefreshLayout.isEnabled = newState != RecyclerView.SCROLL_STATE_DRAGGING
            }
        })
    }

    override fun initActions() {
        mBinding.imgBack.setOnClickListener(this)
        mBinding.llHideOpt.setOnClickListener(this)
        mBinding.llShareOpt.setOnClickListener(this)

    }

    override fun setBinding(): ActivityTimelineBinding {
        return ActivityTimelineBinding.inflate(inflater)
    }

    fun toggleToolbar(isShowActionBar: Boolean) {
        mBinding.llBottomOption.beVisibleIf(isShowActionBar)
        mBinding.llBottomOption.beGoneIf(!isShowActionBar)
    }

    fun updateCount(selectedItems: ArrayList<Medium>) {
        if (selectedItems.any { !it.isHidden() && !it.path.doesThisOrParentHaveNoMedia(HashMap(), null) }) {
            mBinding.llHideOpt.visibility = View.VISIBLE
            mBinding.tvHideUnHideText.text = resources.getString(R.string.hide_photo, selectedItems.size)
            mBinding.imgOptHideUnHide.setImageDrawable(resources.getDrawable(R.drawable.ic_option_hide))

        } else if (selectedItems.any { it.isHidden() && !it.path.doesThisOrParentHaveNoMedia(HashMap(), null) }) {
            mBinding.llHideOpt.visibility = View.VISIBLE
            mBinding.tvHideUnHideText.text = resources.getString(R.string.unhide_photo, selectedItems.size)
            mBinding.imgOptHideUnHide.setImageDrawable(resources.getDrawable(R.drawable.ic_option_unhide))

        } else {
            mBinding.llHideOpt.visibility = View.GONE
        }
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.imgBack -> {
                onBackPressed()
            }
            R.id.llShareOpt -> {
                if (getMediaAdapter() != null)
                    getMediaAdapter()!!.shareMedia()
            }
            R.id.llHideOpt -> {
                if (getMediaAdapter() != null)
                    getMediaAdapter()!!.toggleFileVisibility(true)
            }
        }
    }

    override fun initViews() {


        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }
        mBinding.mediaRefreshLayout.setOnRefreshListener {
            mBinding.mediaRefreshLayout.isRefreshing = false
            isDataLoaded = false
            isStoryDataLoaded = false

            getTimeLineMedia()
            getMedia()
        }
        if (checkPermissionStorage(mContext)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                checkAllFilePermission()
            } else {
                getTimeLineMedia()
                getMedia()
            }
        } else {
            givePermissions(mPermissionStorage)
        }


    }


    private fun checkPermissionStorage(mContext: Activity): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (checkPermissionabove11()) {
                return true
            }
            return false
        } else {
            return if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            ) {
                isUnLockApp = true
                isAppOpenAdShow = false
                ActivityCompat.requestPermissions(
                    this, arrayOf(android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE),
                    101
                )
                false
            } else {
                true
            }
        }
    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                getTimeLineMedia()
                getMedia()
            } else {
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                launchActivityForResult(intent, 2296)
            }
        }
    }

    private fun givePermissions(permissions: Array<String>) {
        isUnLockApp = true
        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                getTimeLineMedia()
                                getMedia()
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionStorage)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(p0: MutableList<com.karumi.dexter.listener.PermissionRequest>?, token: PermissionToken?) {
                    token!!.continuePermissionRequest()
                }
            }).check()
    }

    private fun showSettingsDialog() {
        isUnLockApp = true
        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
        alertDialogBuilder.setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>" + getString(R.string.error_permission_required) + "</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))
            .setMessage(getString(R.string.msg_allow_permission_storage))
            .setPositiveButton(getString(R.string.ok))
            { dialog, which ->
                dialog.dismiss()
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
//                            Share.isAppOpenAdShow = false
            }
            .setNegativeButton(getString(R.string.cancel)) { dialog, which ->
                dialog.dismiss()
                finish()
            }
            .setCancelable(false)
        alertDialogBuilder.show()
    }


    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    getTimeLineMedia()
                    getMedia()
                    Log.e("mTAG", "onActivityResult: Service Start ")
                } else {
                    if (isFromOneSignal) {
                        startActivity(MainActivity.newIntent(this))
                        finish()
                        Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        } else if (requestCode == 200) {
            if (checkPermissionStorage(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    getTimeLineMedia()
                    getMedia()
                }
            } else {
                if (isFromOneSignal) {
                    startActivity(MainActivity.newIntent(this))
                    finish()
                    Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()

        if (isFromSettings) {
            isFromSettings = false
            if (checkPermissionStorage(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    getTimeLineMedia()
                    getMedia()
                }
            }
        }
        if (isNeedToRefresh) {
            isNeedToRefresh = false
            isDataLoaded = false
            isStoryDataLoaded = false

            getTimeLineMedia()
            getMedia()
        }
    }

    private fun getMedia() {
        if (mIsGettingMedia)
            return

        mIsGettingMedia = true
        startAsyncTask()
    }

    private fun startAsyncTask() {
        mBinding.lottieProgressbar.visibility = View.VISIBLE
        if(getMediaAdapter()!=null) {
            getMediaAdapter()!!.finishActMode()
            getMediaAdapter()!!.dismissProgress()
        }

        getRecoverMedia(mPath, mIsGetImageIntent, mIsGetVideoIntent, mShowAll, TYPE_IMAGES, GROUP_BY_LAST_MODIFIED_DAILY, false, mShowAllGroup, true) {
            ensureBackgroundThread {
                val newMedia = it
                try {
                    Log.d("recoverphoto1232", "setupAdapter: " + newMedia.size)
                    isDataLoaded = true
                    gotMedia(newMedia, false)
                    runOnUiThread {
                        if (isDataLoaded && isStoryDataLoaded)
                            Handler(Looper.getMainLooper()).postDelayed({
                                mBinding.lottieProgressbar.visibility = View.GONE
                                val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
                                val firstVisiblePosition = layoutManager.findFirstVisibleItemPosition()
                                Log.d(TAG, "getTimeLineMedia: firstVisiblePosition --> $firstVisiblePosition")
                                mBinding.mediaRefreshLayout.isEnabled = firstVisiblePosition <= 0
                                config.isAnyOperationRunning=false
//                                mBinding.mediaRefreshLayout.isEnabled = true
                            }, 500)
                    }

                } catch (e: Exception) {
                }
            }

        }


    }

    override fun onBackPressed() {
        super.onBackPressed()
        if (isFromOneSignal && MainActivity.activity == null) {
            startActivity(Intent(this, MainActivity::class.java))
        }
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    fun gotMedia(media: ArrayList<ThumbnailItem>, isFromCache: Boolean) {
        mIsGettingMedia = false

        mMedia = media

        runOnUiThread {
            mBinding.tvPleaseWait.beGone()
            mBinding.mediaRefreshLayout.isRefreshing = false
            mBinding.mediaEmptyTextPlaceholder.beVisibleIf(media.isEmpty() && storyList.isEmpty())
            mBinding.mediaEmptyTextPlaceholder2.beGone()
            if (mBinding.mediaEmptyTextPlaceholder.isVisible()) {
                mBinding.mediaEmptyTextPlaceholder.text = getString(R.string.no_media_with_filters)
            }
            mBinding.mediaGrid.beVisibleIf(media.isNotEmpty())

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            val allowHorizontalScroll = config.scrollHorizontally && viewType == VIEW_TYPE_GRID
            mBinding.mediaVerticalFastscroller.beVisibleIf(mBinding.mediaGrid.isVisible() && !allowHorizontalScroll)
            mBinding.mediaHorizontalFastscroller.beVisibleIf(mBinding.mediaGrid.isVisible() && allowHorizontalScroll)
            setupAdapter()
        }

    }

    private fun getMediaAdapter() = mBinding.mediaGrid.adapter as? RecoverPhotoAdapter

    private fun setupAdapter() {

        isScanFinished = true
        if (!mShowAll && isDirEmpty()) {
            return
        }
        Log.d("recoverphoto1232", "setupAdapter: " + mMedia.size)

        val currAdapter = mBinding.mediaGrid.adapter
        if (currAdapter == null) {
            Log.d("recoverphoto1232", "setupAdapter: Current adapter null")
//            initZoomListener()
            val fastscroller = if (config.scrollHorizontally) mBinding.mediaHorizontalFastscroller else mBinding.mediaVerticalFastscroller
            RecoverPhotoAdapter(
                this, mMedia.clone() as ArrayList<ThumbnailItem>, this, mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent,
                mAllowPickingMultiple, mPath, mBinding.mediaGrid, fastscroller, false
            ) {
                Log.d("ItemClick", "setupAdapter: item Position " + it)
                Log.d("ItemClick", "setupAdapter: item object " + mMedia[it as Int])
                if (mMedia[it as Int] is Medium)
                    itemClicked(mMedia[it as Int] as Medium)
            }.apply {
                mBinding.mediaGrid.adapter = this
            }

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            if (viewType == VIEW_TYPE_LIST) {
                mBinding.mediaGrid.scheduleLayoutAnimation()
            }

            setupLayoutManager()
            handleGridSpacing()
        } else if (mLastSearchedText.isEmpty()) {
            Log.d("recoverphoto1232", "setupAdapter: Current adapter not null")
            (currAdapter as RecoverPhotoAdapter).updateMedia(mMedia)
            handleGridSpacing()
        } else {
            Log.d("recoverphoto1232", "setupAdapter: Current adapter else")
        }

        setupScrollDirection()


    }

    private fun itemClicked(item: Medium) {
        if (isDataLoaded && isStoryDataLoaded) {
            if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
                return
            }
            mLastClickTime = SystemClock.elapsedRealtime()
            var path = item.path

            val isVideo = path.isVideoFast()
            if (isVideo) {
                if (isVideoClicked)
                    return
                isVideoClicked = true
                ensureBackgroundThread {
                    var media = mMedia as ArrayList<ThumbnailItem>
                    media = media.filter { medium ->
                        medium is Medium && medium.isVideo() && medium.path.getFilenameExtension() != ".avi" && medium.path.getFilenameExtension() != ".flv"
                    } as ArrayList<ThumbnailItem>
                    uriList = media.map {
                        FileProvider.getUriForFile(
                            this,
                            "$packageName.fileprovider", File((it as Medium).path)
                        )
                    } as ArrayList<Uri>
                }
                loadVideo(path)
            } else {
                ImagePreviewActivity.mPlaceItemList = mMedia.filter { it is Medium && (it as Medium).type != TYPE_VIDEOS } as java.util.ArrayList<ThumbnailItem>
                Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(SKIP_AUTHENTICATION, true)
                    putExtra(PATH, path)
                    putExtra(SHOW_ALL, true)
                    putExtra(SHOW_ONLY_HIDDEN, false)
                    putExtra(SHOW_FAVORITES, mPath == FAVORITES)
                    putExtra(SHOW_RECYCLE_BIN, mPath == RECYCLE_BIN)
                    putExtra(IS_FROM_FAKE_VAULT, false)
                    putExtra(IS_FROM_VAULT, false)
                    putExtra(IS_FROM_ALL_HIDE_FILE, false)
                    putExtra(SHOW_PLACE, true)
                    startActivity(this)
                }
            }
        } else {
            toast(getString(R.string.please_wait))
        }

    }

    private var uriList = ArrayList<Uri>()
    private fun loadVideo(path: String) {
        isVideoClicked = false
        val extras = HashMap<String, Boolean>()
        extras[SHOW_FAVORITES] = mPath == FAVORITES


        val uri = FileProvider.getUriForFile(
            this,
            "$packageName.fileprovider", File(path)
        )


        val mimeType = getUriMimeType(path, uri)
        if (VideoPlayerActivity.mActivity != null) {
            VideoPlayerActivity.mActivity.finish()
        }

        val extension: String = uri.path!!.substring(uri.path!!.lastIndexOf("."))

        if (extension == ".avi" || extension == ".flv") {
            val file: File = File(uri.path)
            Log.e("TAG", "loadVideo:absolutePath --> " + file.absolutePath)

            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(Uri.parse(file.absolutePath.replace("/external_files", "")), "video/*")
            try {
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(getContext(), R.string.error_no_video_activity, Toast.LENGTH_SHORT).show()
            }
        } else {
            VideoPlayerActivity.UriList = uriList
            VideoPlayerActivity.index = uriList.indexOf(uri)
            Intent(applicationContext, VideoPlayerActivity::class.java).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT)

                if (intent.extras != null) {
                    putExtras(intent.extras!!)
                }

                startActivity(this)
                overridePendingTransition(0, 0);
            }
        }
    }

    private fun isDirEmpty(): Boolean {
        return mMedia.size <= 0 && config.filterMedia > 0
    }


    private fun getTimeLineMedia() {

        val timeStampOneYearAgo = getMilliSecRangeOfYear(1)
        val timeStampTwoYearAgo = getMilliSecRangeOfYear(2)
        val timeStampThreeYearAgo = getMilliSecRangeOfYear(3)
        val timeStampFourYearAgo = getMilliSecRangeOfYear(4)
        val timeStampFiveYearAgo = getMilliSecRangeOfYear(5)
        val timeStampSixYearAgo = getMilliSecRangeOfYear(6)
        val timeStampSevenYearAgo = getMilliSecRangeOfYear(7)
        val timeStampEightYearAgo = getMilliSecRangeOfYear(8)
        val timeStampNineYearAgo = getMilliSecRangeOfYear(9)
        val timeStampTenYearAgo = getMilliSecRangeOfYear(10)


        var mSelectionSpec = SelectionSpec.getCleanInstance()
        mSelectionSpec.mimeTypeSet = MimeType.ofImage()
        mSelectionSpec.mediaTypeExclusive = true
        mSelectionSpec.maxSelectable = 5
        mSelectionSpec.noLimit = true
        mSelectionSpec.showPreview = false
        mSelectionSpec.showSingleMediaType = true
        mSelectionSpec.orientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        storyList.clear()
        if (mBinding.rvTimeLine.adapter != null)
            (mBinding.rvTimeLine.adapter as TimelineAdapter).notifyDataSetChanged()
        val mAlbumMediaCollection = AlbumMediaCollection()
        mAlbumMediaCollection.onCreate(this, object : AlbumMediaCollection.AlbumMediaCallbacks {
            override fun onAlbumMediaLoad(cursor1: Cursor?) {

                if (storyList.isEmpty()) {
                    Log.d(TAG, "onAlbumMediaLoad:  storyList Size -->" + storyList.size)
                    Log.d(TAG, "onAlbumMediaLoad:  Cursor Size -->" + cursor1!!.count)
                    val cursor = cursor1
                    val oneYearPic = ArrayList<StoryContent>()
                    val twoYearPic = ArrayList<StoryContent>()
                    val threeYearPic = ArrayList<StoryContent>()
                    val fourYearPic = ArrayList<StoryContent>()
                    val fiveYearPic = ArrayList<StoryContent>()
                    val sixYearPic = ArrayList<StoryContent>()
                    val sevenYearPic = ArrayList<StoryContent>()
                    val eightYearPic = ArrayList<StoryContent>()
                    val nineYearPic = ArrayList<StoryContent>()
                    val tenYearPic = ArrayList<StoryContent>()
                    AsyncBackgroundWork({
                    }, {

                        try {
                            cursor.moveToFirst()
                            do {
                                val item = Item.valueOf(cursor)
                                //                            Log.d(TAG, "onAlbumMediaLoad: Item -->" + item.path)
                                val path = item.path

                                if (path.getParentPath() == CAMERA_DIR_PATH || path.getParentPath() == HD_CAMERA_DIR_PATH) {

                                    var f = File(path)
                                    if (f.exists()) //Extra check, Just to validate the given path
                                    {
                                        var intf: ExifInterface? = null
                                        try {
                                            intf = ExifInterface(path)
                                            if (intf != null) {
                                                val dateString = intf.getAttribute(ExifInterface.TAG_DATETIME)
                                                if (dateString != null) {
                                                    Log.i(
                                                        TAG,
                                                        "Dated : $dateString"
                                                    ) //Display dateString. You can do/use it your own way.
                                                    val formatter: DateFormat =
                                                        SimpleDateFormat("yyyy:MM:dd hh:mm:ss")
                                                    //                                    val formatter: DateFormat = SimpleDateFormat("yyyy-MM-ddThh:mm:ss-ss:ss")
                                                    try {
                                                        val date = formatter.parse(dateString) as Date

                                                        var imageTimestamp = date.time
                                                        Log.d(TAG, "getMedia: date millis -->" + date.time)

                                                        if (imageTimestamp > timeStampTenYearAgo[0] && imageTimestamp < timeStampTenYearAgo[1]) {
                                                            val storyContent = StoryContent(10, path, imageTimestamp)
                                                            if (tenYearPic.size < TimeLinePhotoLimit && !tenYearPic.contains(storyContent))
                                                                tenYearPic.add(storyContent)
                                                        } else if (imageTimestamp > timeStampNineYearAgo[0] && imageTimestamp < timeStampNineYearAgo[1]) {
                                                            val storyContent = StoryContent(9, path, imageTimestamp)
                                                            if (nineYearPic.size < TimeLinePhotoLimit && !nineYearPic.contains(storyContent))
                                                                nineYearPic.add(storyContent)
                                                        } else if (imageTimestamp > timeStampEightYearAgo[0] && imageTimestamp < timeStampEightYearAgo[1]) {
                                                            val storyContent = StoryContent(8, path, imageTimestamp)
                                                            if (eightYearPic.size < TimeLinePhotoLimit && !eightYearPic.contains(storyContent))
                                                                eightYearPic.add(storyContent)
                                                        } else if (imageTimestamp > timeStampSevenYearAgo[0] && imageTimestamp < timeStampSevenYearAgo[1]) {
                                                            val storyContent = StoryContent(7, path, imageTimestamp)
                                                            if (sevenYearPic.size < TimeLinePhotoLimit && !sevenYearPic.contains(storyContent))
                                                                sevenYearPic.add(storyContent)
                                                        } else if (imageTimestamp > timeStampSixYearAgo[0] && imageTimestamp < timeStampSixYearAgo[1]) {
                                                            val storyContent = StoryContent(6, path, imageTimestamp)
                                                            if (sixYearPic.size < TimeLinePhotoLimit && !sixYearPic.contains(storyContent))
                                                                sixYearPic.add(storyContent)
                                                        } else if (imageTimestamp > timeStampFiveYearAgo[0] && imageTimestamp < timeStampFiveYearAgo[1]) {
                                                            val storyContent = StoryContent(5, path, imageTimestamp)
                                                            if (fiveYearPic.size < TimeLinePhotoLimit && !fiveYearPic.contains(storyContent))
                                                                fiveYearPic.add(storyContent)
                                                        } else if (imageTimestamp > timeStampFourYearAgo[0] && imageTimestamp < timeStampFourYearAgo[1]) {
                                                            val storyContent = StoryContent(4, path, imageTimestamp)
                                                            if (fourYearPic.size < TimeLinePhotoLimit && !fourYearPic.contains(storyContent))
                                                                fourYearPic.add(storyContent)
                                                        } else if (imageTimestamp > timeStampThreeYearAgo[0] && imageTimestamp < timeStampThreeYearAgo[1]) {
                                                            val storyContent = StoryContent(3, path, imageTimestamp)
                                                            if (threeYearPic.size < TimeLinePhotoLimit && !threeYearPic.contains(storyContent))
                                                                threeYearPic.add(StoryContent(3, path, imageTimestamp))
                                                        } else if (imageTimestamp > timeStampTwoYearAgo[0] && imageTimestamp < timeStampTwoYearAgo[1]) {
                                                            val storyContent = StoryContent(2, path, imageTimestamp)
                                                            if (twoYearPic.size < TimeLinePhotoLimit && !twoYearPic.contains(storyContent))
                                                                twoYearPic.add(storyContent)
                                                        } else if (imageTimestamp > timeStampOneYearAgo[0] && imageTimestamp < timeStampOneYearAgo[1]) {
                                                            val storyContent = StoryContent(1, path, imageTimestamp)
                                                            if (oneYearPic.size < TimeLinePhotoLimit && !oneYearPic.contains(storyContent))
                                                                oneYearPic.add(storyContent)
                                                        }
                                                    } catch (e: Exception) {
                                                    }
                                                }
                                            }
                                        } catch (e: IOException) {
                                            Log.d(TAG, "getMedia: date millis -->" + e.message)
                                        }
                                    }
                                }
                            } while (cursor.moveToNext())
                        } catch (e: Exception) {
                        }
                    }, {
                        if (oneYearPic.isNotEmpty() && !storyList.contains(oneYearPic))
                            storyList.add(oneYearPic)
                        if (twoYearPic.isNotEmpty() && !storyList.contains(twoYearPic))
                            storyList.add(twoYearPic)
                        if (threeYearPic.isNotEmpty() && !storyList.contains(threeYearPic))
                            storyList.add(threeYearPic)
                        if (fourYearPic.isNotEmpty() && !storyList.contains(fourYearPic))
                            storyList.add(fourYearPic)
                        if (fiveYearPic.isNotEmpty() && !storyList.contains(fiveYearPic))
                            storyList.add(fiveYearPic)
                        if (sixYearPic.isNotEmpty() && !storyList.contains(sixYearPic))
                            storyList.add(sixYearPic)
                        if (sevenYearPic.isNotEmpty() && !storyList.contains(sevenYearPic))
                            storyList.add(sevenYearPic)
                        if (eightYearPic.isNotEmpty() && !storyList.contains(eightYearPic))
                            storyList.add(eightYearPic)
                        if (nineYearPic.isNotEmpty() && !storyList.contains(nineYearPic))
                            storyList.add(nineYearPic)
                        if (tenYearPic.isNotEmpty() && !storyList.contains(tenYearPic))
                            storyList.add(tenYearPic)
                        isStoryDataLoaded = true
                        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
                        val firstVisiblePosition = layoutManager.findFirstVisibleItemPosition()
                        Log.d(TAG, "getTimeLineMedia: firstVisiblePosition --> $firstVisiblePosition")
                        if (firstVisiblePosition > 0)
                            mBinding.appBarLayout.setExpanded(false, false)
                        if (storyList.isNotEmpty()) {
                            val timelineAdapter = TimelineAdapter(this@TimeLineActivity, storyList) {
                                if (isDataLoaded && isStoryDataLoaded) {
                                    if(getMediaAdapter()!=null)
                                        getMediaAdapter()!!.finishActMode()
                                    var intent = Intent(this@TimeLineActivity, TimelineStoryActivity::class.java)
                                    intent.putExtra("List", storyList)
                                    intent.putExtra("index", it)
                                    startActivity(intent)
                                } else {
                                    toast(getString(R.string.please_wait))
                                }
                            }
                            mBinding.rvTimeLine.adapter = timelineAdapter
                        }
                        mAlbumMediaCollection.onDestroy()
                        if (isDataLoaded && isStoryDataLoaded) {
                            mBinding.mediaEmptyTextPlaceholder.beVisibleIf(mMedia.isEmpty() && storyList.isEmpty())
                            mBinding.mediaEmptyTextPlaceholder2.beGone()
                            if (mBinding.mediaEmptyTextPlaceholder.isVisible()) {
                                mBinding.mediaEmptyTextPlaceholder.text = getString(R.string.no_media_with_filters)
                            }
                            Handler(Looper.getMainLooper()).postDelayed({
                                mBinding.lottieProgressbar.visibility = View.GONE
                                val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
                                val firstVisiblePosition = layoutManager.findFirstVisibleItemPosition()
                                Log.d(TAG, "getTimeLineMedia: firstVisiblePosition --> $firstVisiblePosition")
                                mBinding.mediaRefreshLayout.isEnabled = firstVisiblePosition <= 0
                                config.isAnyOperationRunning=false
                            }, 500)
                        }
                    })
                }
            }

            override fun onAlbumMediaReset() {

            }

        })
        val selectionSpec = SelectionSpec.getInstance()
        mAlbumMediaCollection.load(Album(Album.ALBUM_ID_ALL, null, Album.ALBUM_ID_ALL, 0), selectionSpec.capture)

    }

    fun getMilliSecRangeOfYear(offset: Int): java.util.ArrayList<Long> {

        val milliSecArr = java.util.ArrayList<Long>()
        val c = Calendar.getInstance()
//        val day = 1
//        c.set(year, 0, day)
        val year = c[Calendar.YEAR]
        c.set(Calendar.HOUR_OF_DAY, 23)
        c.set(Calendar.MINUTE, 59)
        c.set(Calendar.SECOND, 59)
        c.set(Calendar.YEAR, year - offset)
        milliSecArr.add(c.timeInMillis)

        c.set(Calendar.HOUR_OF_DAY, 23)
        c.set(Calendar.MINUTE, 59)
        c.set(Calendar.SECOND, 59)
        c.add(Calendar.DAY_OF_YEAR, -7)
        milliSecArr.add(0, c.timeInMillis)

        return milliSecArr
    }

    private fun setupLayoutManager() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            setupGridLayoutManager()
        } else {
            setupListLayoutManager()
        }
    }

    private fun setupGridLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = 0
            bottomMargin = 0
        }

        if (config.scrollHorizontally) {
            layoutManager.orientation = RecyclerView.HORIZONTAL
        } else {
            layoutManager.orientation = RecyclerView.VERTICAL
        }

//        layoutManager.spanCount = config.mediaColumnCnt
        layoutManager.spanCount = 3
        val adapter = getMediaAdapter()
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter?.isASectionTitle(position) == true) {
                    layoutManager.spanCount
                } else {
                    1
                }
            }
        }
    }

    private fun setupScrollDirection() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        val allowHorizontalScroll = config.scrollHorizontally && viewType == VIEW_TYPE_GRID
        mBinding.mediaVerticalFastscroller.isHorizontal = false
        mBinding.mediaVerticalFastscroller.beGoneIf(allowHorizontalScroll)

        mBinding.mediaHorizontalFastscroller.isHorizontal = true
        mBinding.mediaHorizontalFastscroller.beVisibleIf(allowHorizontalScroll)

//        val sorting = config.getFolderSorting(if (mShowAll) SHOW_ALL else mPath)
//        if (allowHorizontalScroll) {
//            mBinding.mediaHorizontalFastscroller.setViews(mBinding.mediaGrid, mBinding.mediaRefreshLayout) {
//                mBinding.mediaHorizontalFastscroller.updateBubbleText(getBubbleTextItem(it, sorting!!))
//            }
//        } else {
//            mBinding.mediaVerticalFastscroller.setViews(mBinding.mediaGrid, mBinding.mediaRefreshLayout) {
//                mBinding.mediaVerticalFastscroller.updateBubbleText(getBubbleTextItem(it, sorting!!))
//            }
//        }
    }

    private fun handleGridSpacing(media: ArrayList<ThumbnailItem> = mMedia) {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            val spanCount = config.mediaColumnCnt
            val spacing = config.thumbnailSpacing
            val useGridPosition = media.firstOrNull() is ThumbnailSection

            var currentGridDecoration: GridSpacingItemDecoration? = null
            if (mBinding.mediaGrid.itemDecorationCount > 0) {
                currentGridDecoration = mBinding.mediaGrid.getItemDecorationAt(0) as GridSpacingItemDecoration
                currentGridDecoration.items = media
            }

            val newGridDecoration = GridSpacingItemDecoration(spanCount, spacing, config.scrollHorizontally, config.fileRoundedCorners, media, useGridPosition)
            if (currentGridDecoration.toString() != newGridDecoration.toString()) {
                if (currentGridDecoration != null) {
                    mBinding.mediaGrid.removeItemDecoration(currentGridDecoration)
                }
                mBinding.mediaGrid.addItemDecoration(newGridDecoration)
            }
        }
    }

//    private fun getBubbleTextItem(index: Int, sorting: Int): String {
//        var realIndex = index
//        val mediaAdapter = getMediaAdapter()
//        if (mediaAdapter!!.isASectionTitle(index)) {
//            realIndex++
//        }
//        return mediaAdapter.getItemBubbleText(realIndex, sorting, mDateFormat, mTimeFormat) ?: ""
//    }

    private fun calculateContentWidth(media: ArrayList<ThumbnailItem>) {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        val thumbnailWidth = layoutManager.getChildAt(0)?.width ?: 0
        val spacing = config.thumbnailSpacing
        val fullWidth = ((media.size - 1) / layoutManager.spanCount + 1) * (thumbnailWidth + spacing) - spacing
        mBinding.mediaHorizontalFastscroller.setContentWidth(fullWidth)
        mBinding.mediaHorizontalFastscroller.setScrollToX(mBinding.mediaGrid.computeHorizontalScrollOffset())
    }

    private fun calculateContentHeight(media: ArrayList<ThumbnailItem>) {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        val pathToCheck = if (mPath.isEmpty()) SHOW_ALL else mPath
        val hasSections = config.getFolderGrouping(pathToCheck) and GROUP_BY_NONE == 0 && !config.scrollHorizontally
        val sectionTitleHeight = if (hasSections) layoutManager.getChildAt(0)?.height ?: 0 else 0
        val thumbnailHeight = if (hasSections) layoutManager.getChildAt(1)?.height ?: 0 else layoutManager.getChildAt(0)?.height ?: 0

        var fullHeight = 0
        var curSectionItems = 0
        media.forEach {
            if (it is ThumbnailSection) {
                fullHeight += sectionTitleHeight
                if (curSectionItems != 0) {
                    val rows = ((curSectionItems - 1) / layoutManager.spanCount + 1)
                    fullHeight += rows * thumbnailHeight
                }
                curSectionItems = 0
            } else {
                curSectionItems++
            }
        }
        val spacing = config.thumbnailSpacing
        fullHeight += ((curSectionItems - 1) / layoutManager.spanCount + 1) * (thumbnailHeight + spacing) - spacing
        mBinding.mediaVerticalFastscroller.setContentHeight(fullHeight)
        mBinding.mediaVerticalFastscroller.setScrollToY(mBinding.mediaGrid.computeVerticalScrollOffset())
    }


    private fun setupListLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL

        val smallMargin = resources.getDimension(R.dimen.small_margin).toInt()
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = smallMargin
            bottomMargin = smallMargin
        }

        mZoomListener = null
    }

    override fun refreshItems() {
        mBinding.lottieProgressbar.visibility = View.VISIBLE
        isNeedToRefresh = false
        isDataLoaded = false
        isStoryDataLoaded = false

        getTimeLineMedia()
        getMedia()
    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {
        val filtered = fileDirItems.filter { it.path.isMediaFile() } as ArrayList
        if (filtered.isEmpty()) {
            return
        }

        movePathsInRecoverTrash(filtered.map { it.path } as ArrayList<String>) {
            if (it) {
//                deleteFilteredFiles(filtered)
                mMedia.removeAll { filtered.map { it.path }.contains((it as? Medium)?.path) }

                ensureBackgroundThread {

                    filtered.forEach {
                        deleteDBPath(it.path)

                    }

                    if (mPath.containsNoMedia() || filtered[0].path.getFilenameFromPath().startsWith(".")) {
                        if (hiddenDirectoryDao.getDirectoryThumbnail(mPath) != null) {
                            updatePhotoVideoDirectoryPath(mPath, false, true, true)
                            updatePhotoVideoDirectoryPath(mPath, true, false, true)
                        }
                    }
                    Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Video  ---> ")

                    updatePhotoVideoDirectoryPath(mPath, false, true)
                    Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Image  ---> ")
                    updatePhotoVideoDirectoryPath(mPath, true, false)


                    runOnUiThread {
                        MainActivity.isNeedToRefresh = true
                        VaultFragment.isNeedToRefresh = true
                        HiddenImagesActivity.isNeedToRefresh = true
                        AllHiddenFileActivity.isNeedToRefresh = true
                        if (getMediaAdapter() != null)
                            getMediaAdapter()!!.dismissProgress()
                        refreshItems()
                        if (mMedia.isEmpty()) {
                            deleteDirectoryIfEmpty()
                            deleteDBDirectory()
                            finish()
                        }
                    }
                }

            } else {
                toast(R.string.unknown_error_occurred)
            }
        }

    }
    private fun deleteFilteredFiles(filtered: ArrayList<FileDirItem>) {
        deleteFiles(filtered) {
            if (!it) {
                toast(R.string.unknown_error_occurred)
                if (getMediaAdapter() != null)
                    getMediaAdapter()!!.dismissProgress()
                return@deleteFiles
            }

            mMedia.removeAll { filtered.map { it.path }.contains((it as? Medium)?.path) }

            ensureBackgroundThread {

                    filtered.forEach {
                        deleteDBPath(it.path)

                    }

                if (mPath.containsNoMedia() || filtered[0].path.getFilenameFromPath().startsWith(".")) {
                    if (hiddenDirectoryDao.getDirectoryThumbnail(mPath) != null) {
                        updatePhotoVideoDirectoryPath(mPath, false, true, true)
                        updatePhotoVideoDirectoryPath(mPath, true, false, true)
                    }
                }
                Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Video  ---> ")

                updatePhotoVideoDirectoryPath(mPath, false, true)
                Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Image  ---> ")
                updatePhotoVideoDirectoryPath(mPath, true, false)


                runOnUiThread {
                    MainActivity.isNeedToRefresh = true
                    VaultFragment.isNeedToRefresh = true
                    HiddenImagesActivity.isNeedToRefresh = true
                    AllHiddenFileActivity.isNeedToRefresh = true
                    if (getMediaAdapter() != null)
                        getMediaAdapter()!!.dismissProgress()
                    refreshItems()
                    if (mMedia.isEmpty()) {
                        deleteDirectoryIfEmpty()
                        deleteDBDirectory()
                        finish()
                    }
                }
            }


        }
    }

    private fun deleteDirectoryIfEmpty() {
        if (config.deleteEmptyFolders) {
            val fileDirItem = FileDirItem(mPath, mPath.getFilenameFromPath(), true)
            if (!fileDirItem.isDownloadsFolder() && fileDirItem.isDirectory) {
                ensureBackgroundThread {
                    if (fileDirItem.getProperFileCount(this, true) == 0) {
                        tryDeleteFileDirItem(fileDirItem, true, true)
                    }
                }
            }
        }
    }

    private fun deleteDBDirectory() {
        ensureBackgroundThread {
            try {
                directoryDao.deleteDirPath(mPath)
            } catch (ignored: Exception) {
            }
        }
    }
    override fun selectedPaths(paths: ArrayList<String>) {

    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {

    }


}