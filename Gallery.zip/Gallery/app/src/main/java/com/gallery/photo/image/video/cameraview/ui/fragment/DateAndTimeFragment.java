package com.gallery.photo.image.video.cameraview.ui.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gallery.photo.image.video.R;
import com.gallery.photo.image.video.cameraview.ui.adapter.DateTimeAdapter;
import com.gallery.photo.image.video.cameraview.ui.interfaces.OnRecyclerItemClickListener;
import com.gallery.photo.image.video.fragment.BaseFragment;


public class DateAndTimeFragment extends BaseFragment {

    private View rootView;
    private static final String TAG = "DateAndTimeFragment";

    String[] mDateArray;
    private RecyclerView mRecyclerview;
    public DateTimeAdapter dateTimeAdapter;


    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_date_time, container, false);
        mRecyclerview = rootView.findViewById(R.id.fragment_recyclerview);
        mDateArray = getResources().getStringArray(R.array.datetime_format_arry);
        setAdapter();
        return rootView;
    }


    private void setAdapter() {
        mRecyclerview.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        mRecyclerview.setHasFixedSize(true);
        dateTimeAdapter = new DateTimeAdapter(getContext(), mDateArray, new OnRecyclerItemClickListener() {
            public void OnLongClick_(int i, View view) {
            }

            public void OnClick_(int i, View view) {

                requireActivity().setResult(Activity.RESULT_OK);
                final String str = mDateArray[i];
//                SharedPrefs.save(mActivity, SharedPrefs.DATE_FORMAT, str);
                new Handler(Looper.getMainLooper()).postDelayed(() -> {

                    if (dateTimeAdapter != null) {
                        dateTimeAdapter.refAdapter(str);
                    }

                }, 50);

            }

        });
        mRecyclerview.setAdapter(dateTimeAdapter);
    }



    @Nullable
    @Override
    public Integer getLayoutRes() {
        return R.layout.fragment_date_time;
    }
}
