package com.gallery.photo.image.video.interfaces

interface RefreshRecyclerViewListener {
    fun refreshItems()
}
