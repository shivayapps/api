package com.gallery.photo.image.video.cameraview.ui

import android.animation.Animator
import android.app.Activity
import android.os.Bundle
import android.view.View
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.BaseActivity
import kotlinx.android.synthetic.main.activity_camera_stamp_lottie.*

class StampWidgetActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera_stamp_lottie)

        imgCloseLottie.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.imgCloseLottie -> {
                onBackPressed()
            }
        }
    }

    override fun getContext(): Activity {
        return this@StampWidgetActivity
    }

    override fun initData() {
        widgetLottie.imageAssetsFolder = "images/"
        widgetLottie.setAnimation("Stamp.json")
        widgetLottie.addAnimatorListener(object : Animator.AnimatorListener {
            override fun onAnimationStart(animation: Animator) {}
            override fun onAnimationEnd(animation: Animator) {
            }

            override fun onAnimationCancel(animation: Animator) {}
            override fun onAnimationRepeat(animation: Animator) {

            }
        })
        widgetLottie.playAnimation()
    }

    override fun initActions() {

    }
}