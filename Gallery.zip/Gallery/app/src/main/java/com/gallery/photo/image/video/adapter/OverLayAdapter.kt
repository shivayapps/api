package com.gallery.photo.image.video.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ImageEditOverlayRowBinding

import java.util.*


class OverLayAdapter(
    val context: Context,
    private val list: ArrayList<String>,
    var selectedOverlay: Int
) : BaseAdapter<String>(list) {


    private var mOverlayListener: OverlayListener? = null

    interface OverlayListener {
        fun onOverlayClicked(position: Int)
    }

    fun setOverlayListener(eventListener: OverlayListener) {
        mOverlayListener = eventListener
    }

    inner class MyView(fBinding: ImageEditOverlayRowBinding) : BaseViewHolder<ImageEditOverlayRowBinding>(fBinding)

    override fun onCreateHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<*> {
        return MyView(ImageEditOverlayRowBinding.inflate(LayoutInflater.from(context), parent, false))
    }

    override fun onBindHolder(holder: BaseViewHolder<*>, position: Int) {
        with(holder as MyView) {
            with(fBinding) {
                with(list[position]) {
                    if (position == 0) {
                        ivBg.setImageResource(R.drawable.ic_no_effect)
                    } else {
                        Glide.with(ivBg)
                            .load(list[position])
                            .into(ivBg)
                    }

                    if (position == selectedOverlay) {
                        ivBg.setBackgroundResource(R.drawable.image_edit_select_effect_background)
                    } else {
                        ivBg.setBackgroundResource(R.drawable.image_edit_unselect_effect_background)
                    }

                    itemView.setOnClickListener {
                        selectedOverlay = position
                        mOverlayListener?.onOverlayClicked(position)
                        notifyDataSetChanged()
                    }
                }
            }
        }
    }


    override fun getItemCount(): Int {
        return list.size
    }

}