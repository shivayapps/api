package com.gallery.photo.image.video.database

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.SQLException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteFullException
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import android.widget.Toast

class FavouriteDBHelper(ctx: Context?) {
    public var context: Context? = null

    class DatabaseHelper(context: Context?) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
        override fun onCreate(db: SQLiteDatabase) {
            //here create table
            /*final String Create_Reg =
                    "CREATE TABLE IF NOT EXISTS detail ("
                            + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                            + "name TEXT,"
                            + "address TEXT,"
                            + "phone TEXT);";
            db.execSQL(Create_Reg);*/
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            onCreate(db)
        }
    }

    // ---opens the database---
    @Throws(SQLException::class)
    fun open(): FavouriteDBHelper {
        db = DBHelper!!.writableDatabase
        return this
    }

    // ---closes the database---
    fun close() {
        try {
            DBHelper!!.close()
        } catch (e: SQLiteFullException) {
            showStorageFullToast()
        } catch (sl: SQLiteException) {
            sl.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun saveFavouriteData(type: String?, image_path: String?): Long {
        var roiwid: Long = -1
        try {
            db = DBHelper!!.readableDatabase
            val values = ContentValues()
            values.put(KEY_TYPE, type)
            values.put(KEY_IMAGE_PATH, image_path)
            // values.put(KEY_IMAGE, image);
            roiwid = db.insert(TABLE_FAVOURITE, null, values)
            db.close()
        } catch (s: SQLiteFullException) {
            showStorageFullToast()
        } catch (sl: SQLiteException) {
            sl.printStackTrace()
        } catch (t: Exception) {
            t.printStackTrace()
        }
        return roiwid
    }

    public fun showStorageFullToast() {
        if (context != null) Toast.makeText(context, "Sorry your device memory have not enough space for perform this task", Toast.LENGTH_LONG).show()
    }

    fun getRowCountOfTable(type: String): Long {
        return try {
            db = DBHelper!!.readableDatabase
            val sql = "SELECT COUNT(*) FROM " + TABLE_FAVOURITE + " WHERE " + KEY_TYPE + "='" + type + "'"
            val statement = db.compileStatement(sql)
            statement.simpleQueryForLong()
        } catch (s: SQLiteFullException) {
            showStorageFullToast()
            0
        } catch (sl: SQLiteException) {
            sl.printStackTrace()
            0
        } catch (e: Exception) {
            e.printStackTrace()
            0
        }
    }

    fun getSingleFavData(path: String): Boolean {
        return try {

            db = DBHelper.readableDatabase
            val cursor = db.query(TABLE_FAVOURITE, arrayOf(KEY_ID, KEY_TYPE, KEY_IMAGE_PATH), "$KEY_IMAGE_PATH=? ", arrayOf(path), null, null, null, null)
            if (cursor.moveToFirst()) {
                cursor.getString(cursor.getColumnIndex(KEY_IMAGE_PATH))
            } else {
                ""
            }
            val cnt = cursor.count
            cursor.close()
            cnt > 0
        } catch (e: SQLiteFullException) {
            showStorageFullToast()
            false
        } catch (sl: SQLiteException) {
            sl.printStackTrace()
            false
        } catch (e: Exception) {
            false
        }

    }

    fun getSingleFavDataID(path: String): Int {
        return try {
            var data = 0
            db = DBHelper!!.readableDatabase
            val cursor = db.query(TABLE_FAVOURITE, arrayOf(KEY_ID, KEY_TYPE, KEY_IMAGE_PATH), KEY_IMAGE_PATH + "=? ", arrayOf(path), null, null, null, null)
            if (cursor.moveToFirst()) {
                data = cursor.getInt(cursor.getColumnIndex(KEY_ID))
            }
            data
        } catch (e: SQLiteFullException) {
            showStorageFullToast()
            0
        } catch (sl: SQLiteException) {
            sl.printStackTrace()
            0
        } catch (e: Exception) {
            0
        }
    }

    fun deleteFavDetails(image_path: String): Int {
        var deleted = 0
        db = DBHelper!!.readableDatabase
        try {
            deleted = db.delete(TABLE_FAVOURITE, KEY_IMAGE_PATH + " = ?", arrayOf(image_path))
            Log.e("deleted", "deleted")
        } catch (e: SQLiteFullException) {
            showStorageFullToast()
        } catch (sl: SQLiteException) {
            sl.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return deleted
    }

    fun getFavData(type: String): Cursor? {
        return try {
            db = DBHelper!!.readableDatabase
            val selectQuery = "SELECT  * FROM " + TABLE_FAVOURITE + " WHERE " + KEY_TYPE + "='" + type + "'"
            db.rawQuery(selectQuery, null)
        } catch (e: SQLiteFullException) {
            showStorageFullToast()
            null
        } catch (sl: SQLiteException) {
            sl.printStackTrace()
            null
        } catch (e: Exception) {
            null
        }
    }

    fun getAllFavouriteList(): ArrayList<String> {

        var favouritePathList = ArrayList<String>()
        var cursor: Cursor? = null
        try {
            db = DBHelper!!.readableDatabase
            val selectQuery = "SELECT  * FROM $TABLE_FAVOURITE"
            cursor = db.query(TABLE_FAVOURITE, arrayOf(KEY_ID, KEY_TYPE, KEY_IMAGE_PATH), null, null, null, null, null)
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    favouritePathList.add(cursor.getString(cursor.getColumnIndex(KEY_IMAGE_PATH)))
                }
            }
        } catch (e: SQLiteFullException) {
            showStorageFullToast()

        } catch (sl: SQLiteException) {
            sl.printStackTrace()

        } catch (e: Exception) {

        } finally {
            if (cursor != null)
                cursor!!.close()
        }
        return favouritePathList
    }

    fun deleteFavData() {
        db = DBHelper!!.readableDatabase
        try {
            db.delete(TABLE_FAVOURITE, null, null)
        } catch (e: SQLException) {
            e.printStackTrace()
        }
    }

    fun updateFavData(newPath: String?, OldPath: String): Int {
        return try {
            db = DBHelper!!.readableDatabase
            var ret = 0
            val id = getSingleFavDataID(OldPath)
            val strFilter = KEY_ID + "=" + id
            val args = ContentValues()
            args.put(KEY_IMAGE_PATH, newPath)
            ret = db.update(TABLE_FAVOURITE, args, strFilter, null)
            // db.delete(TABLE_FAVOURITE, null, null);
            ret
        } catch (e: SQLiteFullException) {
            showStorageFullToast()
            0
        } catch (sl: SQLiteException) {
            sl.printStackTrace()
            0
        } catch (e: Exception) {
            e.printStackTrace()
            0
        }
    }

    companion object {
        public const val DATABASE_VERSION = 1
        public const val DATABASE_NAME = "gallery.sql"
        public const val TABLE_FAVOURITE = "favourite_table"
        public const val KEY_ID = "id"
        public const val KEY_TYPE = "type"
        public const val KEY_IMAGE_PATH = "path"
        public const val KEY_IMAGE = "image"
        lateinit var DBHelper: DatabaseHelper
        public lateinit var db: SQLiteDatabase
    }

    init {
        try {
            context = ctx
            DBHelper = DatabaseHelper(context)
        } catch (s: SQLiteFullException) {
            showStorageFullToast()
        } catch (sl: SQLiteException) {
            sl.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


}