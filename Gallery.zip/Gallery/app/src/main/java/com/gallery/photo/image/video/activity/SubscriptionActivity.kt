package com.gallery.photo.image.video.activity

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.SkuDetails
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adapter.ImgAdapter
import com.gallery.photo.image.video.databinding.ActivitySubscriptionBinding
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.extensions.makeLinks
import com.gallery.photo.image.video.extensions.openExternalBrowser
import com.gallery.photo.image.video.extensions.strike
import com.gallery.photo.image.video.inapp.*
import com.gallery.photo.image.video.utilities.getPrivacyPolicyUrl
import com.gallery.photo.image.video.utilities.isUnLockApp
import com.gallery.photo.image.video.utilities.subscriptionWeekly
import com.gallery.photo.image.video.utilities.subscriptionYearly
import com.gallery.photo.image.video.views.ItemOffsetDecoration
import kotlinx.coroutines.Dispatchers
//import kotlinx.android.synthetic.main.activity_subscription_new.*
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class SubscriptionActivity : BaseActivity(), ProductPurchaseHelper.ProductPurchaseListener {
    var skuYearly: ProductPurchaseHelper.ProductInfo? = null
    var skuWeekly: ProductPurchaseHelper.ProductInfo? = null
    lateinit var mBinding: ActivitySubscriptionBinding
    private lateinit var mImgAdapter: ImgAdapter
    var TAG = javaClass.simpleName
    var mSelectedSku = ""
    var REQUEST_CODE_CHECK = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        mBinding = ActivitySubscriptionBinding.inflate(LayoutInflater.from(getContext()))
        setContentView(mBinding.root)
        initData()
    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {

        val img = intArrayOf(
            R.drawable.img_one,
            R.drawable.img_three,
            R.drawable.img_eight,
            R.drawable.img_five,
            R.drawable.img_two,
            R.drawable.img_six,
            R.drawable.img_four,
            R.drawable.img_seven
        )

        mImgAdapter = ImgAdapter(this@SubscriptionActivity, img)

        mBinding.rvSubImg.run {
            adapter = mImgAdapter
            addItemDecoration(ItemOffsetDecoration(this@SubscriptionActivity, R.dimen._4sdp))
        }

        val duration = 10
        val pixelsToMove = 25
        val mHandler: Handler = Handler(Looper.getMainLooper())
        val SCROLLING_RUNNABLE: Runnable = object : Runnable {
            override fun run() {
                mBinding.rvSubImg.smoothScrollBy(pixelsToMove, 0)
                mHandler.postDelayed(this, duration.toLong())
            }
        }

        mBinding.rvSubImg.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                val lastItem: Int =
                    (mBinding.rvSubImg.layoutManager as LinearLayoutManager).findLastCompletelyVisibleItemPosition()
                if (lastItem == mBinding.rvSubImg.layoutManager!!.itemCount - 1) {
                    (mBinding.rvSubImg.layoutManager as LinearLayoutManager).smoothScrollToPosition(
                        mBinding.rvSubImg,
                        RecyclerView.State(),
                        0
                    )
                }
            }
        })
        mHandler.postDelayed(SCROLLING_RUNNABLE, 500)


//        InAppPurchaseHelper.instance!!.initBillingClient(this, this)
        ProductPurchaseHelper.setSubscriptionKey(SUB_WEEKLY, SUB_YEARLY)
        ProductPurchaseHelper.initBillingClient(this@SubscriptionActivity, this)
        mBinding.tvPrivacy.makeLinks(
            Pair("Privacy Policy", this),
            Pair("Política de privacidad", this),
            Pair("गोपनीयता नीति ", this),
            Pair("Política de Privacidade", this),
            Pair("رازداری کی پالیسی", this),
        )

        mBinding.cardOne.setOnClickListener(this)
        mBinding.cardTwo.setOnClickListener(this)
        mBinding.btnSubscription.setOnClickListener(this)
        mBinding.ivClose.setOnClickListener(this)
    }

    override fun initActions() {

    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun onClick(view: View) {

        when (view.id) {
            R.id.card_one -> {
                setupUI(SUB_WEEKLY)
            }
            R.id.card_two -> {
                setupUI(SUB_YEARLY)
            }
            R.id.iv_close -> {
                onBackPressed()
            }
            R.id.btn_subscription -> {
//                if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
//                    return
//                }
//                mLastClickTime = SystemClock.elapsedRealtime()
                isUnLockApp = true
                ProductPurchaseHelper.subscribeProduct(
                    this@SubscriptionActivity,
                    mSelectedSku,
                    false
                )
            }
            R.id.tvPrivacyPolicy -> {
                if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
                    return
                }
                mLastClickTime = SystemClock.elapsedRealtime()
                isUnLockApp = true
                openExternalBrowser(getPrivacyPolicyUrl())
            }
        }
    }


    private fun setupUI(fType: String) {
        mSelectedSku = fType

        when (fType) {

            SUB_WEEKLY -> {
                mBinding.planOne.background = ContextCompat.getDrawable(
                    this@SubscriptionActivity,
                    R.drawable.rounded_selected_special
                )
                mBinding.planTwo.background = null
                mBinding.btnSubscription.text = "Subscribe Now"
                mBinding.lblPeriodOne.text = skuWeekly?.billingPeriod
                if (!skuWeekly?.freeTrialPeriod.equals("Not Found")) {
                    mBinding.btnSubscription.text =
                        "Start your ${skuWeekly?.freeTrialPeriod?.replace(" ", "-")} Trial"
                } else {
                    mBinding.btnSubscription.text = "Subscribe Now"
                }
            }

            SUB_YEARLY -> {
                mBinding.planOne.background = null
                mBinding.planTwo.background = ContextCompat.getDrawable(
                    this@SubscriptionActivity,
                    R.drawable.rounded_selected_special
                )
                mBinding.btnSubscription.text = "Subscribe Now"
                val product = ProductPurchaseHelper.getProductInfo(SUB_YEARLY)
                mBinding.lblPeriodTwo.text = product?.billingPeriod
                if (!product?.freeTrialPeriod.equals("Not Found")) {
                    mBinding.btnSubscription.text =
                        "Start your ${product?.freeTrialPeriod?.replace(" ", "-")} Trial"
                } else {
                    mBinding.btnSubscription.text = "Subscribe Now"
                }
            }
        }

    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onPurchasedExpired(productType: String) {
    }

    override fun onPurchasedSuccess(purchase: Purchase) {
        Log.e(TAG, "onPurchasedSuccess:InAppActivity:" + purchase.skus)
        launchActivityForResult(
            Intent(this, SubscriptionThankYouActivity::class.java),
            REQUEST_CODE_CHECK
        )
    }

    override fun onPurchasedFound(productType: String, purchaseList: MutableList<Purchase>?) {

    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_CODE_CHECK -> {
                Log.e("LOCK", "onActivityResult: successfully unlock")
                setResult(RESULT_OK)
                finish()
            }
        }
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        Log.e(TAG, "onBillingSetupFinished:InAppActivity:" + billingResult.responseCode)
        Log.e(TAG, "onBillingSetupFinished:InAppActivity:" + billingResult.debugMessage)
        ProductPurchaseHelper.initSubscriptionKeys(this@SubscriptionActivity) {
            skuWeekly = ProductPurchaseHelper.getProductInfo(SUB_WEEKLY)
            mBinding.tvPriceOne.text = skuWeekly?.formattedPrice
            mBinding.lblPeriodOne.text = skuWeekly?.billingPeriod

            skuYearly = ProductPurchaseHelper.getProductInfo(SUB_YEARLY)
            mBinding.tvPriceTwo.text = skuYearly?.formattedPrice
            mBinding.lblPeriodTwo.text = skuYearly?.billingPeriod

            Log.e(TAG, "onBillingSetupFinished:skuWeekly:" + skuWeekly?.priceAmountMicros)
            Log.e(TAG, "onBillingSetupFinished:skuYearly:" + skuYearly?.priceAmountMicros)

            setupUI(SUB_YEARLY)

        }
    }

    override fun onBillingKeyNotFound(productId: String) {
        Log.e(TAG, "onBillingUnavailable:InAppActivity:$productId")
    }

}