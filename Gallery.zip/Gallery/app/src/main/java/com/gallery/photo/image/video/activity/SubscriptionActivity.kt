package com.gallery.photo.image.video.activity

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.SkuDetails
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.extensions.makeLinks
import com.gallery.photo.image.video.extensions.openExternalBrowser
import com.gallery.photo.image.video.extensions.strike
import com.gallery.photo.image.video.inapp.InAppPurchaseHelper
import com.gallery.photo.image.video.inapp.*
import com.gallery.photo.image.video.utilities.getPrivacyPolicyUrl
import com.gallery.photo.image.video.utilities.isUnLockApp
import com.gallery.photo.image.video.utilities.subscriptionWeekly
import com.gallery.photo.image.video.utilities.subscriptionYearly
import kotlinx.android.synthetic.main.activity_subscription_new.*
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class SubscriptionActivity : BaseActivity(), InAppPurchaseHelper.OnPurchased {
    var skuYearly: SkuDetails? = null
    var skuWeekly: SkuDetails? = null
    var TAG = javaClass.simpleName
    var isYearlySelected = true
    var REQUEST_CODE_CHECK = 101
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        setContentView(R.layout.activity_subscription_new)
    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        InAppPurchaseHelper.instance!!.initBillingClient(this, this)
        tvPrivacyPolicy.makeLinks(
            Pair("Privacy Policy", this),
            Pair("Política de privacidad", this),
            Pair("गोपनीयता नीति ", this),
            Pair("Política de Privacidade", this),
            Pair("رازداری کی پالیسی", this),)

        Glide.with(this).load(getDrawable(R.drawable.ic_subscription_banner)).into(imageView2)

        llWeekly.setOnClickListener(this)
        llYearly.setOnClickListener(this)
        imgClose.setOnClickListener(this)
        tvSubscribeBtn.setOnClickListener(this)
        var weeklyPrice = InAppPurchaseHelper.instance!!.getProductPrice(SUB_WEEKLY)
        var yearlyprice = InAppPurchaseHelper.instance!!.getProductPrice(SUB_YEARLY)
        Log.d(TAG, "initData:  Weekly Price :$weeklyPrice")
        Log.d(TAG, "initData:  Yearly Price :$yearlyprice")
        skuWeekly = InAppPurchaseHelper.instance!!.getSkuDetails(SUB_WEEKLY)
        skuYearly = InAppPurchaseHelper.instance!!.getSkuDetails(SUB_YEARLY)
//        if (weeklyPrice != "Not Found" && yearlyprice != "Not Found") {

            try {

                val lYearNumber: String = yearlyprice.replace("""[^0-9.]""".toRegex(), "")
                val lWeekNumber: String = weeklyPrice.replace("""[^0-9.]""".toRegex(), "")

                if (lYearNumber.isNotEmpty()) {

                    val lWeekPrize: Double = (lWeekNumber.toDouble() * 52) - lYearNumber.toDouble() //4730

                    val lYearPrizeBaseOfWeek = (lWeekNumber.toDouble() * 52)//7280

                    val lDiscount = (lWeekPrize / lYearPrizeBaseOfWeek) * 100//64.97
                    val perWeekPrice = lYearNumber.toDouble() / 52
                    tvSaveUpTo.text = getString(R.string.label_save_subscribe, lDiscount.roundToInt()) + "%"
                    tvPriceYearly.text = getString(R.string.label_per_week_year_price, perWeekPrice.toInt().toString())
                }

            } catch (e: Exception) {
            }
            tvPriceWeekly.text = weeklyPrice
            tvPayYearly.text = getString(R.string.label_pay_yearly, yearlyprice)
            tvWeeklyPriceStrike.text = weeklyPrice
            tvWeeklyPriceStrike.strike = true
            if (isYearlySelected) {
                if (skuYearly != null && skuYearly!!.freeTrialPeriod != null && skuYearly!!.freeTrialPeriod.isNotBlank()) {
                    var numberOfDay = skuYearly!!.freeTrialPeriod.replace("P", "").replace("D", "")
                    tvSubscribeBtn.text = getString(R.string.label_free_trial, numberOfDay)
                } else {
                    tvSubscribeBtn.text = getString(R.string.btn_subscribe_now)
                }
            }
//        } else {
//            Toast.makeText(this, getString(R.string.error_billing_client_is_not_ready), Toast.LENGTH_SHORT).show()
//            onBackPressed()
//        }

    }

    override fun initActions() {

    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun onClick(view: View) {

        when (view.id) {
            R.id.llWeekly -> {
                isYearlySelected = false
                iv_active_yearly.visibility=View.INVISIBLE
                tvSaveUpTo.visibility=View.INVISIBLE
                iv_active_weekly.visibility=View.VISIBLE
                tv_basic.visibility=View.VISIBLE
                setSelectedLayout(rel_package_weekly, rel_package_yearly, tv_weekly, tv_yearly)
                if (skuWeekly != null && skuWeekly!!.freeTrialPeriod != null && skuWeekly!!.freeTrialPeriod.isNotBlank()) {
                    var numberOfDay = skuWeekly!!.freeTrialPeriod.replace("P", "").replace("D", "")
                    tvSubscribeBtn.text = getString(R.string.label_free_trial, numberOfDay)
                } else {
                    tvSubscribeBtn.text = getString(R.string.btn_subscribe_now)
                }
            }
            R.id.llYearly -> {
                isYearlySelected = true
                iv_active_yearly.visibility=View.VISIBLE
                tvSaveUpTo.visibility=View.VISIBLE
                iv_active_weekly.visibility=View.INVISIBLE
                tv_basic.visibility=View.INVISIBLE
                setSelectedLayout(rel_package_yearly, rel_package_weekly, tv_yearly, tv_weekly)
                if (skuYearly != null && skuYearly!!.freeTrialPeriod != null && skuYearly!!.freeTrialPeriod.isNotBlank()) {
                    var numberOfDay = skuYearly!!.freeTrialPeriod.replace("P", "").replace("D", "")
                    tvSubscribeBtn.text = getString(R.string.label_free_trial, numberOfDay)
                } else {
                    tvSubscribeBtn.text = getString(R.string.btn_subscribe_now)
                }
            }
            R.id.imgClose -> {
                onBackPressed()
            }
            R.id.tvSubscribeBtn -> {
                if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
                    return
                }
                mLastClickTime = SystemClock.elapsedRealtime()
                isUnLockApp = true
                if (isYearlySelected)
                    addEvent(subscriptionYearly)
                else
                    addEvent(subscriptionWeekly)
                GlobalScope.launch {
                    if (isYearlySelected) InAppPurchaseHelper.instance!!.subscribeProduct(SUB_YEARLY, false)
                    else InAppPurchaseHelper.instance!!.subscribeProduct(SUB_WEEKLY, false)
                }
            }
            R.id.tvPrivacyPolicy -> {
                if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
                    return
                }
                mLastClickTime = SystemClock.elapsedRealtime()
                isUnLockApp = true
                openExternalBrowser(getPrivacyPolicyUrl())
            }
        }
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private fun setSelectedLayout(selectedView: LinearLayout, unSelectedView: LinearLayout, selectedTextView: TextView, unSelectedTextView: TextView) {
        selectedView.background = getDrawable(R.drawable.subscription_selected_border_background)
        unSelectedView.background = getDrawable(R.drawable.subscription_unselected_border_background)

        selectedTextView.background=resources.getDrawable(R.drawable.ic_dialog_button)
        selectedTextView.setTextColor(resources.getColor(R.color.white))

        unSelectedTextView.background=resources.getDrawable(R.drawable.ic_button_disable)
        unSelectedTextView.setTextColor(resources.getColor(R.color.black))

    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onPurchasedSuccess(purchase: Purchase) {
        Log.e(TAG, "onPurchasedSuccess:InAppActivity:" + purchase.skus)
        launchActivityForResult(Intent(this, SubscriptionThankYouActivity::class.java), REQUEST_CODE_CHECK)
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_CODE_CHECK -> {
                Log.e("LOCK", "onActivityResult: successfully unlock")
                setResult(RESULT_OK)
                finish()

            }
        }
    }

    override fun onProductAlreadyOwn() {
        Log.e(TAG, "onProductAlreadyOwn:InAppActivity")
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        Log.e(TAG, "onBillingSetupFinished:InAppActivity:" + billingResult.responseCode)
        Log.e(TAG, "onBillingSetupFinished:InAppActivity:" + billingResult.debugMessage)

    }

    override fun onBillingUnavailable() {
        Log.e(TAG, "onBillingUnavailable:InAppActivity")
        Toast.makeText(this, "The billing client is not ready", Toast.LENGTH_SHORT).show()
        onBackPressed()
    }

    override fun onBillingKeyNotFound(productId: String) {
        Log.e(TAG, "onBillingUnavailable:InAppActivity:$productId")
    }

}