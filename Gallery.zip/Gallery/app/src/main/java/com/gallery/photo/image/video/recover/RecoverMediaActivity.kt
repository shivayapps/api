package com.gallery.photo.image.video.recover

import android.graphics.PorterDuff
import android.os.AsyncTask
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.bumptech.glide.Glide
import com.google.android.gms.ads.AdView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adapter.PictureAdapter
import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.customview.MyGridLayoutManager
import com.gallery.photo.image.video.customview.MyRecyclerView
import com.gallery.photo.image.video.database.AppDatabase
import com.gallery.photo.image.video.database.RecoverData
import com.gallery.photo.image.video.databinding.ActivityRecoverMediaBinding
import com.gallery.photo.image.video.dialog.ConfirmationDialog
import com.gallery.photo.image.video.dialog.ProgressDialog
import com.gallery.photo.image.video.event.DeleteEvent
import com.gallery.photo.image.video.extension.beGone
import com.gallery.photo.image.video.extension.getFilenameFromPath
import com.gallery.photo.image.video.extension.getParentFolder
import com.gallery.photo.image.video.extension.isImageFast
import com.gallery.photo.image.video.extension.isVideoFast
import com.gallery.photo.image.video.extension.toast
import com.gallery.photo.image.video.model.AlbumData
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.utils.AdCache
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.MAX_COLUMN_COUNT_PICTURE
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.greenrobot.eventbus.EventBus
import java.io.File
import kotlin.math.max
import kotlin.math.min

class RecoverMediaActivity : BaseActivity() {

    var imageListAdapter: PictureAdapter? = null

    private val alImageData: ArrayList<Any> = ArrayList()

    lateinit var preferences: Preferences

    var selectedItem = 0
    var isSearch: Boolean = false
    var isStopSearch: Boolean = false
    var isCheckSearchOn = false
    var isSelectAll = false
    lateinit var dataBase: AppDatabase

    var gridCount = 3
    private var lastLongPressedItem = -1
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mDragListener: MyRecyclerView.MyDragListener? = null

    lateinit var binding: ActivityRecoverMediaBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if(preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this,getString(R.string.inter_all))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivityRecoverMediaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadBanner()

        initView()

    }


    var handler: Handler = Handler(Looper.myLooper()!!)
    var notifyDataSet: Runnable = object : Runnable {
        override fun run() {
            runOnUiThread {
                notifyAdapter()
            }
            handler.postDelayed(this, 1500)
        }
    }

    var isRunning = true
    override fun onBackPressed() {
        isRunning = false
        if (preferences.isNeedInterAd) {
            AdsConfig.showInterstitialAd(this) {
                if (it) preferences.isNeedInterAd = false
                finish()
            }
        } else {
            super.onBackPressed()
        }
    }

    var isAdLoaded=false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    private fun loadBanner() {
        if (!isAdLoaded) {
            val isFirstSession = preferences.splashCounter == 1
            val adId = getString(R.string.b_recoverMediaActivity)

            BannerAdHelper.showBanner(this, binding.layoutBanner.mFLAd, binding.llAdParent, adId,
                AdCache.recoverMediaAdView,{ isLoaded, adView, message ->
                    mAdView=adView
                    AdCache.recoverMediaAdView=adView
                    isAdLoaded=isLoaded
                })
        }
    }


//    var isAsyncRunning: Boolean = false
//    private inner class GetRecoverableAlbum :
//        AsyncTask<Void?, String?, ArrayList<RecoverData>>() {
//        override fun onPreExecute() {
//            try {
//                isAsyncRunning = true
//
//            } catch (e: Exception) {
//                e.printStackTrace()
//            }
//        }
//        override fun doInBackground(vararg params: Void?): ArrayList<RecoverData> {
//
//        }
//
//    }
    private fun getRecoverableImage() {

        dataBase.dataDao().getRecoverLiveEntityList()
            .observe(this) { recoverList: List<RecoverData> ->
                recoverList.forEach { recoverData ->
                    val file = File(recoverData.path)
//                    if (file.exists()) {
                        val pictureData = PictureData(
                            recoverData.path,
                            recoverData.path.getFilenameFromPath(),
                            recoverData.path.getParentFolder(),
                            file.lastModified(),
                            file.lastModified(),
                            file.length(),
                            isVideo = recoverData.isVideo == 1
                        )
                        if (!alImageData.contains(pictureData)) alImageData.add(pictureData)
//                    }
                }

            }

        handler.postDelayed(notifyDataSet, 1500)

        Observable.fromCallable {
            Glide.get(this).clearDiskCache()
            val dirPath: String = Environment.getExternalStorageDirectory().absolutePath
            Log.d("TAG", "doInBackground: path: $dirPath")
            checkFileOfDirectory(getFileList(dirPath))

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                Log.e("gettingListPhoto", "getData:" + throwable)
                runOnUiThread {
                    handler.removeCallbacks(notifyDataSet)
                    binding.tvScanPath.beGone()
                    binding.progressBar.beGone()
                    setEmptyData()
                }
            }
            .subscribe { result: Boolean? ->
                runOnUiThread {
                    handler.removeCallbacks(notifyDataSet)
                    binding.tvScanPath.beGone()
                    binding.progressBar.beGone()
                    setEmptyData()
                }
            }
    }

    private fun setEmptyData() {
        if (alImageData != null && alImageData.size != 0) {
//            isEmpty=false
            binding.loutNoData.visibility = View.GONE
            binding.llAdPlace.visibility = View.VISIBLE
            binding.llMain.visibility = View.VISIBLE
        } else {
//            isEmpty=true
            binding.loutNoData.visibility = View.VISIBLE
            binding.llAdPlace.visibility = View.GONE
            binding.llMain.visibility = View.GONE
        }
    }

    private fun initView() {

        dataBase = AppDatabase.getInstance(this)

        binding.txtTitle.setText(getString(R.string.recover_lost_media))
        binding.icMenu.beGone()

        imageListAdapter = PictureAdapter(this, alImageData,
            clickListener = {
                if (alImageData[it] is PictureData) {
                    val pictureData = alImageData[it] as PictureData
                    if (pictureData.isCheckboxVisible && !isCheckSearchOn) {
                        pictureData.isSelected = !pictureData.isSelected
                        imageListAdapter?.notifyItemChanged(it)
                        setSelectedFile()
                    }
                }
            },
            longClickListener = {

                lastLongPressedItem = it
                binding.rvImage.setDragSelectActive(it)
                lastLongPressedItem = if (lastLongPressedItem == -1) {
                    it
                } else {
                    val min = min(lastLongPressedItem, it)
                    val max = max(lastLongPressedItem, it)
                    for (i in min..max) {
                        toggleItemSelection(true, i, false)
                    }
//                    updateTitle()
                    it
                }

                if (!isCheckSearchOn) {
                    if (alImageData[it] is PictureData) {
                        val pictureData = alImageData[it] as PictureData
                        for (i in alImageData.indices) {
                            if (alImageData[i] != null)
                                if (alImageData[i] is AlbumData) {
                                    val model = alImageData[i] as AlbumData
                                    model.isCheckboxVisible = true
                                } else if (alImageData[i] is PictureData) {
                                    val model = alImageData[i] as PictureData
                                    model.isCheckboxVisible = true
                                }
                        }
                        pictureData.isCheckboxVisible = true
                        pictureData.isSelected = true
                        notifyAdapter()
                        setSelectedFile()
                    }
                }
            },
            headerSelectListener = {
                if (alImageData[it] is AlbumData) {
                    val albumData = alImageData[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < alImageData.size) {
                        if (alImageData[pos] is PictureData) {
                            val model = alImageData[pos] as PictureData
                            model.isSelected = isSelectAll
                            pos++
                        } else if (alImageData[pos] is AlbumData) {
                            break
                        }
                    }
                    notifyAdapter()
                    setSelectedFile()
                }
            })

        setRvLayoutManager()
        binding.rvImage.adapter = imageListAdapter

        initZoomListener()
        setupZoomListener(mZoomListener)
        initDragListener()
        setupDragListener(mDragListener)

        intListener()
        getRecoverableImage()
    }

    private fun initZoomListener() {
        val isGridShow = preferences.getShowGrid()
        if (isGridShow) {
            val layoutManager = binding.rvImage.layoutManager as MyGridLayoutManager
            mZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 2) {
                        reduceColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT_PICTURE) {
                        increaseColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            mZoomListener = null
        }
    }

    private fun reduceColumnCount() {
        if (gridCount > 2) {
            gridCount -= 1
        }
        setColumnView()
    }

    private fun increaseColumnCount() {
        if (gridCount < MAX_COLUMN_COUNT_PICTURE) {
            gridCount += 1
        }
        setColumnView()
    }

    private fun setRvLayoutManager() {

//        val gridLayoutManager = GridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
        val layoutManager = binding.rvImage.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = gridCount
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < alImageData.size) {
                    return if (imageListAdapter!!.getItemViewType(position) == imageListAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }
    }


    private fun setColumnView() {
        (binding.rvImage.layoutManager as MyGridLayoutManager).spanCount = gridCount

        imageListAdapter?.apply {
            notifyItemRangeChanged(0, pictures.size)
        }
        setRvLayoutManager()
    }

    fun setupZoomListener(zoomListener: MyRecyclerView.MyZoomListener?) {
        binding.rvImage.setupZoomListener(zoomListener)
    }

    private fun initDragListener() {

        mDragListener = object : MyRecyclerView.MyDragListener {
            override fun selectItem(position: Int) {
                toggleItemSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int
            ) {
                selectItemRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedItem = -1
                }
            }

        }
    }

    fun setupDragListener(dragListener: MyRecyclerView.MyDragListener?) {
        binding.rvImage.setupDragListener(dragListener)
    }

    protected fun selectItemRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleItemSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleItemSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleItemSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleItemSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleItemSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {
//        pictureAdapter.getItemViewType(pos)
//        if (select && !getIsItemSelectable(pos)) {
        if (select && alImageData[pos] is AlbumData) {
            return
        }

        if (alImageData[pos] is PictureData) {

            if (select) {
                (alImageData[pos] as PictureData).isSelected = true
//                (pictures[pos] as PictureData).isCheckboxVisible = true
//                selectedKeys.add(itemKey)
            } else {
                (alImageData[pos] as PictureData).isSelected = false
//                (pictures[pos] as PictureData).isCheckboxVisible = false
//                selectedKeys.remove(itemKey)
            }
        }
        imageListAdapter?.notifyItemChanged(pos)
        setSelectedFile()
    }

    private fun notifyAdapter() {
        if (imageListAdapter != null)
            imageListAdapter?.notifyDataSetChanged()

        setEmptyData()
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in alImageData.indices) {
            if (alImageData[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = alImageData[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        imageListAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (alImageData[i] is PictureData) {
                val model = alImageData[i] as PictureData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == alImageData.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = alImageData[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    imageListAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
//        binding.swipeRefreshLayout.isEnabled = false

        selectedItem = selected
    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            setSelectAllColor()
        }
        binding.btnRestore.setOnClickListener {
            confirmRecoverData()
        }
        binding.btnDelete.setOnClickListener {
            confirmDeleteData()
        }
    }

    fun confirmDeleteData() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            val confirmationDialog = ConfirmationDialog(
                this,
                getString(R.string.Delete),
                getString(R.string.permanently_delete_msg_single),
                getString(R.string.ok),
                positiveBtnClickListener = {
                    deletePhoto(true)
                })
            confirmationDialog.show()
        }
    }

    private fun deletePhoto(isPermanent: Boolean) {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            this,
            R.drawable.ic_drawer_delete,
            selectedItem,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.show()
        preferences.refreshMedia = true
        preferences.scanMedia = true

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            for (i in alImageData.indices) {
                if (alImageData[i] != null) if (alImageData[i] is PictureData) {
                    val model = alImageData[i] as PictureData
                    if (model.isSelected) {
//                        runOnUiThread {
//                            bindingDialog.txtTitle.text = model.fileName
//                        }

                        val isDelete =
                            Utils.deleteFile(this, model.filePath, dataBase, isPermanent)
                        if (isDelete) {
                            deleteList.add(model.filePath)
                            runOnUiThread {
                                progressDialog.setProgress(deleteList.size, selectedItem)
//                                bindingDialog.txtProgressCount.text =
//                                    deleteList.size.toString() + "/" + selectedItem
//                                bindingDialog.progressBar.progress = deleteList.size
                            }
                        }
                    } else {
                        model.isCheckboxVisible = false
                    }
                }
//                else if (alImageData[i] is AlbumData) {
//                    val model = alImageData[i] as AlbumData
//                    model.isSelected = false
//                    model.isCheckboxVisible = false
//                }
            }

            var i = 0
            while (i < alImageData.size) {
                if (alImageData[i] != null)
                    if (alImageData[i] is AlbumData) {
                        val model = alImageData[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (alImageData[i] is PictureData) {
                        val model = alImageData[i] as PictureData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = alImageData[i - 1] is AlbumData
                            }
                            if (i < alImageData.size - 2) {
                                isNext = alImageData[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                alImageData.removeAt(i)
                                alImageData.removeAt(i - 1)
                            } else if (i == alImageData.size - 1) {
                                alImageData.removeAt(i)
                                if (isPre) {
                                    alImageData.removeAt(i - 1)
                                }
                            } else {
                                alImageData.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
//        EventBus.getDefault().post(DeleteEvent(0, deleteList))
        selectedItem = 0
        notifyAdapter()
//        enableScroll()
//        binding.swipeRefreshLayout.isEnabled = true
        longClickListener(false, 0, false)
        toast(getString(R.string.Delete_successfully))

        //deleteMainList(deleteList)
        setCloseToolbar()
    }

    fun confirmRecoverData() {
        if (selectedItem == 0) {

            toast(getString(R.string.please_select_media_to_recover))
        } else {
            val confirmationDialog = ConfirmationDialog(
                this,
                getString(R.string.restore),
                getString(R.string.restore_msg),
                getString(R.string.ok),
                positiveBtnClickListener = {
                    recoverData()
                })
            confirmationDialog.show()
        }
    }

    private fun recoverData() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in alImageData.indices) {
            if (alImageData[i] != null)
                if (alImageData[i] is PictureData) {
                    val model: PictureData = alImageData[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

//        Utils.recoverFiles(this, selectImage, selectedItem, hideListener = {
//            toast(getString(R.string.restore_successfully))
//            selectedItem = 0
//            longClickListener(false, 0, false)
//            setClose()
//        })

        var selectPath = File(Constant.RECOVER_PATH).absolutePath
        recoverFiles(selectPath, selectImage)
    }

    private fun recoverFiles(
        selectPath: String, selectImage: java.util.ArrayList<PictureData>
    ) {
        Log.e("newAlbum", "setCopyMove:$selectPath")
        Utils.moveFiles(this, selectPath, selectImage, selectedItem, copyListener = {

            toast(getString(R.string.restore_successfully))
            selectedItem = 0
            preferences.refreshMedia = true
            preferences.scanMedia = true
            Handler(Looper.getMainLooper()).postDelayed({
                setCloseToolbar()
            }, 500)
        })

    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in alImageData.indices) {
            if (alImageData[i] != null)
                if (alImageData[i] is AlbumData) {
                    val model = alImageData[i] as AlbumData
                    if(!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                    }
                } else if (alImageData[i] is PictureData) {
                    val model = alImageData[i] as PictureData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    private fun setClose() {
        for (i in alImageData.indices) {
            if (alImageData[i] != null)
                if (alImageData[i] is AlbumData) {
                    val model = alImageData[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                } else if (alImageData[i] is PictureData) {
                    val model = alImageData[i] as PictureData
                    model.isCheckboxVisible = false
                    model.isSelected = false
                }
        }

        notifyAdapter()
        selectedItem = 0
    }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
        binding.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE
        isSelectAll = isAllSelect
        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE
        binding.groupToolbarHeader.visibility = if (isShowSelection) View.GONE else View.VISIBLE
        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
        setSelectAllColor()
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    var i = 0
    fun checkFileOfDirectory(fileArr: Array<File>?) {
        if (fileArr == null || !isRunning) return

        for (i in fileArr.indices) {
            val numArr = arrayOfNulls<Int>(1)
            val i2 = this.i
            this.i = i2 + 1
            numArr[0] = i2

            if (fileArr[i].isDirectory
//                && !fileArr[i].name.contains("/.")
                && !fileArr[i].name.startsWith("data")
                && !fileArr[i].name.startsWith("obb")
                && !fileArr[i].name.startsWith("obj")
            ) {
                checkFileOfDirectory(getFileList(fileArr[i].path))
            } else {
                val file1 = File(fileArr[i].path)
                runOnUiThread {
                    Handler(Looper.getMainLooper()).post {
                        binding.tvScanPath.text = file1.path
                    }
                }
                if (fileArr[i].path.contains("/.")
                    && !fileArr[i].path.contains(".Gallery/${Constant.HIDE_FOLDER_NAME}")
                    && !fileArr[i].path.contains(".Gallery/${Constant.RECENT_DELETE_FOLDER_NAME}")
                ) {
                    if (fileArr[i].isImageFast()) {
                        Log.d("TAG", "checkFileOfDirectory_isImageFast:" + fileArr[i].path)

                        dataBase.dataDao().insertRecoverEntity(
                            RecoverData(
                                0,
                                file1.path,
                                0,
                            )
                        )
                    } else if (fileArr[i].isVideoFast()) {
                        Log.d("TAG", "checkFileOfDirectory_isVideoFast:" + fileArr[i].path)
                        dataBase.dataDao().insertRecoverEntity(
                            RecoverData(
                                0,
                                file1.path,
                                1,
                            )
                        )
//                        this.alImageData.add(pictureData);
                    }
                }

            }
        }
    }

    fun getFileList(str: String): Array<File>? {
        val file = File(str)
        return if (file.isDirectory) {
            file.listFiles()
        } else {
            null
        }
    }

//    private fun checkFileOfDirectory(fileArr: Array<File>): ArrayList<PictureData> {
//
////        val picPaths = ArrayList<String?>()
//
//
//        var isNewData = false
//        for (i in fileArr.indices) {
//            isNewData = false
//            if (fileArr[i].isDirectory &&
//                !fileArr[i].name.startsWith("data") &&
//                !fileArr[i].name.startsWith("obb") &&
//                !fileArr[i].name.startsWith("obj") &&
//                !fileArr[i].name.startsWith(".trash") &&
//                !fileArr[i].name.contains("Backup And Recovery")
//            ) {
//                checkFileOfDirectory(getFileList(fileArr[i].path)!!)
//            } else {
//                if (fileArr[i].length().toString() != "0" && fileArr[i].path.contains("/.")) {
//
//                    val lExtension = getExtension(fileArr[i].path)
//
//                    val isExtensionMatches =
//                        (ImageArray.contains(lExtension) || VideoArray.contains(lExtension)) && fileArr[i].path.endsWith(
//                            lExtension
//                        )
//
//                    if (isExtensionMatches) {
//                        val folder = Objects.requireNonNull(fileArr[i].parentFile).name
//                        val mRootPath = fileArr[i].parent!!
//                        val files = File(mRootPath).listFiles()
//
//                        val filePath = file.absolutePath
//                        if (filePath.contains("/.")) {
//                            val pi
//                            val loImageList = RecoverableImageModel(
//                                filePath,
//                                false,
//                                file.lastModified(),
//                                file.length()
//                            )
//                            moImageLists.add(loImageList)
//                            runOnUiThread {
//                                Handler(Looper.getMainLooper()).post {
//                                    Log.e(mTAG, "gridRecoverableAlbumImage: " + moImageLists.size)
//                                    mRecoverableImageAdapter!!.notifyDataSetChanged()
//                                }
//                            }
//                        }
//
//                    }
//                }
//            }
//
////            if (mGetRecoverableAlbum != null) {
////                if (mGetRecoverableAlbum!!.isCancelled) {
////                    runOnUiThread {
////                        MyApplication.isDialogOpen = false
////                        mFolderList.clear()
////                        if (binding.scanRecoverableAlbum != null) binding.scanRecoverableAlbum!!.visibility =
////                            View.GONE
//////                        if(binding.lottieRecoverableImage!=null) binding.lottieRecoverableImage.visibility = View.GONE
////                        mIsCancelAsync = true
////                        unSelectAll()
////                    }
////                    break
////                }
////            }
//
//            if (isNewData) {
//                runOnUiThread {
//                    Handler(Looper.getMainLooper()).postDelayed(Runnable {
//                        mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
//                    }, 200)
//                }
//            }
//        }
//        return allList
//    }

}