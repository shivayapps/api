package com.gallery.photo.image.video.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.gallery.photo.image.video.databinding.ListItemLanguageBinding
import com.gallery.photo.image.video.utilities.AppLanguage
import com.gallery.photo.image.video.utilities.Locales
import com.gallery.photo.image.video.extensions.baseConfig


class LanguageAdapter(val mContext: Activity, private val mLanguages: MutableList<AppLanguage>,  val itemClick: (Any) -> Unit) : BaseAdapter<AppLanguage>(mLanguages)  {

    // variable to track event time
    var mLastClickTime: Long = 0
    var mMinDuration = 1000
    var selectedLanguageKey: String = Locales.English.language

    init {
        selectedLanguageKey = mContext.baseConfig.appLanguage
        if(selectedLanguageKey.isEmpty())
        {
            selectedLanguageKey="en"
        }
    }

    override fun onCreateHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<*> {
        return ViewHolder(ListItemLanguageBinding.inflate(LayoutInflater.from(mContext),parent,false))
    }

    override fun onBindHolder(holder: BaseViewHolder<*>, position: Int) {

        with(holder as ViewHolder) {
            with(fBinding) {
                with(mLanguages[position]) {
                    val title = name
                    tvTitle.text =title
                    if(mContext.baseConfig.appLanguage == "ur")
                    {
                        tvTitle.textDirection= View.TEXT_DIRECTION_RTL
                    }else{
                        tvTitle.textDirection=View.TEXT_DIRECTION_LTR
                    }
//        mContext.loadImage(selectLanguage.thumb, selectLanguage.thumb, holder.ivThumb, null)
                    itemView.setOnClickListener {
                        selectedLanguageKey = local.language.toString()
                        itemClick.invoke(position)
                        notifyDataSetChanged()
                    }

                    ivRadio.isSelected = local.language.toString() == selectedLanguageKey
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return mLanguages.size
    }

    inner class ViewHolder(fBinding: ListItemLanguageBinding) : BaseViewHolder<ListItemLanguageBinding>(fBinding)

}