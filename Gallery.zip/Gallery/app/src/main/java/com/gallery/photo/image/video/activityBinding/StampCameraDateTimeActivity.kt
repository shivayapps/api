package com.gallery.photo.image.video.activityBinding

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.cameraview.database.model.CameraStamp
import com.gallery.photo.image.video.cameraview.ui.adapter.DateTimeAdapter
import com.gallery.photo.image.video.cameraview.ui.interfaces.OnRecyclerItemClickListener
import com.gallery.photo.image.video.databinding.ActivityStampCameraDateTimeBinding
import com.gallery.photo.image.video.extensions.inflater

class StampCameraDateTimeActivity : BaseBindingActivity<ActivityStampCameraDateTimeBinding>() {
    private var cameraStamp: CameraStamp? = null
    var selectedDateFormat = ""
    override fun getContext(): Activity {
        return this
    }

    override fun initData() {

        cameraStamp= intent.getSerializableExtra("StampData") as CameraStamp?
        var dateTimeAdapter: DateTimeAdapter? = null
        val mDateArray: Array<String> = resources.getStringArray(R.array.datetime_format_arry)

        mBinding.rvDateTime.layoutManager = LinearLayoutManager(
            getContext(),
            LinearLayoutManager.VERTICAL,
            false
        )
        mBinding.rvDateTime.setHasFixedSize(true)
        selectedDateFormat = cameraStamp!!.dateTime
        mDateArray.sortBy {
            it == cameraStamp!!.dateTime
        }
        mDateArray.reverse()

        dateTimeAdapter =
            DateTimeAdapter(getContext(), mDateArray, object : OnRecyclerItemClickListener {
                override fun OnLongClick_(i: Int, view: View) {}
                override fun OnClick_(i: Int, view: View) {
                    selectedDateFormat = mDateArray[i]
                    val str = mDateArray[i]
                    Handler(Looper.getMainLooper()).postDelayed({
                        if (dateTimeAdapter != null) {
                            dateTimeAdapter!!.refAdapter(str)
                        }
                    }, 50)
                }
            }, cameraStamp!!.dateTime)
        mBinding.rvDateTime.adapter = dateTimeAdapter
        mBinding.ivClose.setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }
        mBinding.ivDone.setOnClickListener {
            var intent = Intent()
            intent.putExtra("DateTime",selectedDateFormat)
            setResult(RESULT_OK,intent)
            finish()
        }
    }

    override fun initActions() {

    }

    override fun setBinding(): ActivityStampCameraDateTimeBinding {
        return ActivityStampCameraDateTimeBinding.inflate(inflater)
    }

}