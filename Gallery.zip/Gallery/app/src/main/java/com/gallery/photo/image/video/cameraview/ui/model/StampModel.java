package com.gallery.photo.image.video.cameraview.ui.model;

public class StampModel {
    int stampId;
    boolean isPremium;

    public StampModel() {
        stampId = -1;
        isPremium = false;
    }


    public boolean isPremium() {
        return isPremium;
    }

    public void setPremium(boolean premium) {
        isPremium = premium;
    }

    public int getStampId() {
        return stampId;
    }

    public void setStampId(int stampId) {
        this.stampId = stampId;
    }

}
