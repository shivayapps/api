package com.gallery.photo.image.video.dialog

import android.app.Activity
import androidx.appcompat.app.AlertDialog
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.extensions.beGone
import com.gallery.photo.image.video.extensions.setupDialogStuff
import kotlinx.android.synthetic.main.dialog_confirm_delete_folder.view.*

class TrashInfoDialog(activity: Activity, message: String, val callback: () -> Unit) {
    var dialog: AlertDialog

    init {
        val view = activity.layoutInflater.inflate(R.layout.dialog_confirm_delete_folder, null)
        view.message.text = message
        view.message_warning.beGone()

        val builder = AlertDialog.Builder(activity,R.style.MyAlertDialogNew)
                .setPositiveButton(R.string.ok) { dialog, which -> dialogConfirmed() }


        dialog = builder.create().apply {
            activity.setupDialogStuff(view, this)
        }
    }

    private fun dialogConfirmed() {
        dialog.dismiss()
        callback()
    }
}
