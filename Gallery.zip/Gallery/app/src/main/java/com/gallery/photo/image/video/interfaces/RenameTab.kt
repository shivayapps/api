package com.gallery.photo.image.video.interfaces

import com.gallery.photo.image.video.activity.BaseSimpleActivity

interface RenameTab {
    fun initTab(activity: com.gallery.photo.image.video.activity.BaseSimpleActivity, paths: ArrayList<String>)

    fun dialogConfirmed(useMediaFileExtension: Boolean, callback: (success: Boolean) -> Unit)
}
