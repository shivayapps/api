package com.gallery.photo.image.video.cameraview.ui.adapter

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.Drawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.net.toUri
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.SubscriptionActivity
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.cameraview.stampmodel.Data
import com.gallery.photo.image.video.utilities.STAMP_ID
import com.gallery.photo.image.video.utilities.SharedPrefs

import java.util.ArrayList

class StampAdapter(
    var mContext: Activity,
    var mList: List<Data>,
    var itemclick: (data: Data, pos: Int) -> Unit, var itemclick1: () -> Unit
) : RecyclerView.Adapter<StampAdapter.Holder>() {

//    var selectedStampId: Int =
//        SharedPrefs.getInt(mContext, SharedPrefs.STAMP_POS, AppConstant.STAMP_FORMAT_1)

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): Holder {
        return Holder(
            LayoutInflater.from(viewGroup.context).inflate(R.layout.cell_stamps, viewGroup, false)
        )
    }

    override fun onBindViewHolder(holder: Holder, i: Int) {
        //  holder.ivStamp.setImageURI(mList[i].front_image.toUri())
        Log.e("TAG", "onBindHolder: " + mList[i].front_image.toUri())
        if (i > 2) {
            itemclick1.invoke()
        }

        holder.itemView.setOnClickListener {
            if (mList[i].is_premium) {
                if (AdsManager(mContext).isNeedToShowAds()) {
                    val intent = Intent(mContext, SubscriptionActivity::class.java)
                    mContext.startActivity(intent)
                    mContext.overridePendingTransition(
                        android.R.anim.fade_in,
                        android.R.anim.fade_out
                    )
                } else {
                    itemclick.invoke(mList[i], mList[i].id)
                }
            } else {
                if (i >= 0) {
                    itemclick.invoke(mList[i], mList[i].id)
                }
            }
        }

        with(holder) {
            Glide.with(mContext)
                .load(mList[i].front_image.toUri())
                .placeholder(R.drawable.stampicon)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .skipMemoryCache(false).listener(object :
                    RequestListener<Drawable?> {
                    override fun onLoadFailed(
                        e: GlideException?,
                        model: Any,
                        target: Target<Drawable?>,
                        isFirstResource: Boolean
                    ): Boolean {
                        Log.e("TAG_1", e.toString())
                        return false
                    }

                    override fun onResourceReady(
                        resource: Drawable?,
                        model: Any,
                        target: Target<Drawable?>,
                        dataSource: DataSource,
                        isFirstResource: Boolean
                    ): Boolean {
                        Log.e("TAG_1", "onResourceReady")
                        return false
                    }
                }).into(ivStamp)


            if (AdsManager(mContext).isNeedToShowAds()) {
                if (mList[i].is_premium) {
                    ivStampPremium.visibility = View.VISIBLE
                } else {
                    ivStampPremium.visibility = View.GONE
                }
            } else {
                ivStampPremium.visibility = View.GONE
            }


            if (mList[i].id == SharedPrefs.getInt(mContext, STAMP_ID, 8)
            ) {
                ivStampSelector.visibility = View.VISIBLE
                Log.e("TAG", "onBindViewHolder: 1 -->" + mList[i].id)
            } else {
                ivStampSelector.visibility = View.GONE
                Log.e("TAG", "onBindViewHolder: 2 -->" + mList[i].id)
            }
        }

    }

    override fun getItemViewType(position: Int): Int {
        return position
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getItemCount(): Int {
        return mList.size
    }

    fun refAdapter(storyList: ArrayList<Data>) {
        mList = storyList
        notifyDataSetChanged()
    }

    inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
        var ivStamp: ImageView = view.findViewById<View>(R.id.ivStamp) as ImageView
        var ivStampPremium: ImageView = view.findViewById<View>(R.id.ivStampPremium) as ImageView
        var ivStampSelector: ImageView = view.findViewById<View>(R.id.ivStampSelector) as ImageView

    }

}