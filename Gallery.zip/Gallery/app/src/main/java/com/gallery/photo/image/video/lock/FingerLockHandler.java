package com.gallery.photo.image.video.lock;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;


@RequiresApi(api = Build.VERSION_CODES.M)
public class FingerLockHandler extends FingerprintManager.AuthenticationCallback {

    public CancellationSignal getCancellationSignal() {
        return cancellationSignal;
    }

    public void setCancellationSignal(CancellationSignal cancellationSignal) {
        this.cancellationSignal = cancellationSignal;
    }

    private CancellationSignal cancellationSignal;
    private Context context;
    private int failCounter = 1;

    public FingerLockHandler(Context mContext) {
        context = mContext;
    }

    public void startAuth(FingerprintManager manager, FingerprintManager.CryptoObject cryptoObject) {
        cancellationSignal = new CancellationSignal();
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.USE_FINGERPRINT) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        manager.authenticate(cryptoObject, cancellationSignal, 0, this, null);
    }

    @Override
    public void onAuthenticationError(int errMsgId,
                                      CharSequence errString) {
        Log.e("TAG", "onAuthenticationError:3  ID==>" + errMsgId + "\n error msg==>" + errString);

        if (errMsgId == 7) {
            Toast.makeText(context,
                    "Too many attempts please try again later after 1 minute",
                    Toast.LENGTH_LONG).show();
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Log.e("TAG", "run: callResume");
                    failCounter = 0;
                   // ((FingerLockActivity) context).callResume();
                }
            }, 60000);
        } else {
            /*Toast.makeText(context,
                    "Authentication error\n" + errString,
                    Toast.LENGTH_SHORT).show();*/
        }
    }

    @Override
    public void onAuthenticationFailed() {
        Log.e("TAG", "onAuthenticationFailed: ");
  /*      Toast.makeText(context,
                "Authentication failed",
                Toast.LENGTH_SHORT).show();*/
/*
        if (failCounter > 3) {

        } else
            failCounter++;*/
    }

    @Override
    public void onAuthenticationHelp(int helpMsgId,
                                     CharSequence helpString) {
        Log.e("TAG", "onAuthenticationHelp: ");
      /*  Toast.makeText(context,
                "Authentication help\n" + helpString,
                Toast.LENGTH_SHORT).show();*/
    }


    @Override
    public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
        Log.e("TAG", "onAuthenticationSucceeded: ");

        // Toast.makeText(context,"Success!", Toast.LENGTH_LONG).show();
        //for Service Battery

        ((Activity) context).setResult(Activity.RESULT_OK);
        ((Activity) context).finish();
    }


}
