package com.gallery.photo.image.video.adapter

import android.app.ProgressDialog
import android.text.format.DateFormat
import android.util.Log
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activityBinding.SecretNotesActivity
import com.gallery.photo.image.video.activityBinding.TrashActivity
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.dialog.DeleteWithRememberDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.*
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.helpers.VIEW_TYPE_LIST
import com.gallery.photo.image.video.views.FastScroller
import com.gallery.photo.image.video.views.MyRecyclerView
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.helpers.DAY_SECONDS
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import kotlinx.android.synthetic.main.item_notes_list.view.*
import kotlinx.android.synthetic.main.item_notes_list.view.medium_check
import java.util.*
import kotlin.collections.ArrayList

class NotesAdapter(
    activity: BaseSimpleActivity, var media: ArrayList<Note>, val listener: MediaOperationsListener?, val isAGetIntent: Boolean,
    val allowMultiplePicks: Boolean, recyclerView: MyRecyclerView, fastScroller: FastScroller? = null, val isFromFakeVault: Boolean = false, itemClick: (Any) -> Unit
) :
    MyRecyclerViewAdapter(activity, recyclerView, fastScroller, itemClick) {

    private val ITEM_MEDIUM_PHOTO = 2
    private val config = activity.config
    private val viewType = VIEW_TYPE_LIST
    private val isListViewType = viewType == VIEW_TYPE_LIST
    private var loadImageInstantly = true
    private var currentMediaHash = media.hashCode()
    var mProgressDailog: ProgressDialog? = null

    // variable to track event time
    var mLastClickTime: Long = 0
    var mMinDuration = 2000
    protected var selectedMainKeys = LinkedHashSet<Int>()
    var deleteDialog: DeleteWithRememberDialog? = null

    init {
        setupDragListener(false)
        media.forEach {
            (it as? Medium)?.path?.hashCode()?.let { it1 -> selectedMainKeys.add(it1) }
        }
    }

    override fun getActionMenuId() = R.menu.cab_directories

    override fun prepareActionMode(menu: Menu) {
        val selectedItems = getSelectedItems()
        if (selectedItems.isEmpty()) {
            return
        }
        if (activity is SecretNotesActivity) {
            (activity as SecretNotesActivity).updateCount(selectedItems.size)
        }
        if (activity is TrashActivity) {
            (activity as TrashActivity).updateCount(selectedItems.size)
        }
        menu.apply {
            findItem(R.id.cab_delete).isVisible = false
            val selectableItemCount = getSelectableItemCount()
            val selectedCount = Math.min(selectedKeys.size, selectableItemCount)
            if (selectedCount == selectableItemCount) {
                findItem(R.id.cab_select_all).title = "Deselect All"
                findItem(R.id.cab_select_all).icon = activity.resources.getDrawable(R.drawable.ic_deselect_all_vector)
            } else {
                findItem(R.id.cab_select_all).title = "Select All"
                findItem(R.id.cab_select_all).icon = activity.resources.getDrawable(R.drawable.ic_select_all_vector)
            }
        }
    }

    override fun actionItemPressed(id: Int) {
        if (selectedKeys.isEmpty()) {
            return
        }

        when (id) {
            R.id.cab_select_all -> selectAll()
            R.id.cab_delete -> checkDeleteConfirmation()
        }
    }

    override fun getSelectableItemCount() = media.size

    override fun getIsItemSelectable(position: Int) = !isASectionTitle(position)

    override fun getItemSelectionKey(position: Int) = (media.getOrNull(position) as? Note)?.id?.hashCode()

    override fun getItemKeyPosition(key: Int) = media.indexOfFirst { (it as? Note)?.id?.hashCode() == key }

    override fun onActionModeCreated() {
        if (activity is SecretNotesActivity) {
            (activity as SecretNotesActivity).toggleToolbar(true)
        }
        if (activity is TrashActivity) {
            (activity as TrashActivity).toggleToolbar(true)
        }
    }

    override fun onActionModeDestroyed() {
        if (activity is SecretNotesActivity) {
            (activity as SecretNotesActivity).toggleToolbar(false)
        }
        if (activity is TrashActivity) {
            (activity as TrashActivity).toggleToolbar(false)
        }

    }

    override fun getSelectedList(): LinkedHashSet<Int> {
        return selectedMainKeys
    }


    override fun getItemViewType(position: Int): Int {

        return ITEM_MEDIUM_PHOTO
    }

    fun getSelectedItems() = selectedKeys.mapNotNull { getItemWithKey(it) } as java.util.ArrayList<Note>

    private fun getSelectedNotes() = getSelectedItems().map { it } as java.util.ArrayList<Note>

    private fun getFirstSelectedItemPath() = getItemWithKey(selectedKeys.first())?.id

    private fun getItemWithKey(key: Int): Note? = media.firstOrNull { (it as? Note)?.id?.hashCode() == key } as? Note

    fun updateMedia(newMedia: java.util.ArrayList<Note>) {
        val thumbnailItems = newMedia.clone() as java.util.ArrayList<Note>
        if (thumbnailItems.hashCode() != currentMediaHash) {
            currentMediaHash = thumbnailItems.hashCode()
            media = thumbnailItems
            enableInstantLoad()
            notifyDataSetChanged()
            finishActMode()
        }
    }

    private fun enableInstantLoad() {
        loadImageInstantly = true
        /*   delayHandler.postDelayed({
               loadImageInstantly = false
           }, INSTANT_LOAD_DURATION)*/
    }

    fun isASectionTitle(position: Int) = false

    fun getItemBubbleText(position: Int, sorting: Int, dateFormat: String, timeFormat: String): String {
        return (media[position] as? Medium)?.getBubbleText(sorting, activity, dateFormat, timeFormat) ?: ""
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutType = R.layout.item_notes_list
        return createViewHolder(layoutType, parent)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tmbItem = media.getOrNull(position) ?: return
        val allowLongPress = true
        holder.bindView(tmbItem, true, allowLongPress) { itemView, adapterPosition ->
            setupThumbnail(itemView, tmbItem, position)
        }
        bindViewHolder(holder)
    }

    private fun setupThumbnail(view: View, note: Note, position: Int) {
        Log.d("TAG1122", "setupThumbnail: onBind ")
        val isSelected = selectedKeys.contains(note.id.hashCode())
        view.apply {
            val padding = if (activity.config.thumbnailSpacing <= 1) {
                activity.config.thumbnailSpacing
            } else {
                0
            }
            if (activity.baseConfig.appLanguage == "ur") {
                note_title.textDirection = View.TEXT_DIRECTION_RTL
                if (note_time != null)
                    note_time.textDirection = View.TEXT_DIRECTION_RTL
            } else {
                note_title.textDirection = View.TEXT_DIRECTION_LTR
                if (note_time != null)
                    note_time.textDirection = View.TEXT_DIRECTION_LTR
            }

            note_title.text = note.title
            val today = formatDate(System.currentTimeMillis().toString(), true)
            val yesterday = formatDate((System.currentTimeMillis() - DAY_SECONDS * 1000).toString(), true)
            val sectionKey = getFormattedKey(note.timestamp.toString(), GROUP_BY_LAST_MODIFIED_DAILY, today, yesterday)
            note_time.text = sectionKey.replace("am", "AM").replace("pm", "PM")
            media_item_holder.setPadding(padding, padding, padding, padding)
            medium_check.beVisibleIf(isSelected)
            if (activity is TrashActivity) {
                img_arrow.beGone()
            } else {
                img_arrow.beGoneIf(isSelected)
            }

            if (isSelected) {
                medium_check.background.applyColorFilter(adjustedPrimaryColor)
                medium_check.applyColorFilter(contrastColor)
            }
            if (isListViewType) {
                media_item_holder.isSelected = isSelected
            }
        }
    }

    private fun getFormattedKey(key: String, grouping: Int, today: String, yesterday: String): String {
        var result = when {
            grouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 || grouping and GROUP_BY_DATE_TAKEN_DAILY != 0 -> getFinalDate(formatDate(key, true), today, yesterday)
            grouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0 || grouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0 -> formatDate(key, false)

            else -> key
        }

        if (result.isEmpty()) {
            result = activity.getString(R.string.unknown)
        }

        return result
    }

    private fun getFinalDate(date: String, today: String, yesterday: String): String {
//        return when (date) {
//            today -> activity.getString(R.string.today)
//            yesterday -> activity.getString(R.string.yesterday)
//            else -> date
//        }
        return date
    }

    private fun formatDate(timestamp: String, showDay: Boolean): String {
        return if (timestamp.areDigitsOnly()) {
            val cal = Calendar.getInstance(Locale.ENGLISH)
            cal.timeInMillis = timestamp.toLong()
            val format = "MMM dd, yyyy hh:mm a"
            DateFormat.format(format, cal).toString()

        } else {
            ""
        }
    }

    private fun setupSection(view: View, section: ThumbnailSection) {
        view.apply {
//            thumbnail_section.text = section.title
        }
    }

    override fun getItemCount(): Int {
        return media.size
    }


    fun showProgress(msg: String) {
        mProgressDailog = ProgressDialog(activity, R.style.MyAlertDialogNew)
        mProgressDailog!!.setMessage(msg)

        mProgressDailog!!.setCancelable(false)
        mProgressDailog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
        mProgressDailog!!.show()
    }

    fun dismissProgress() {
        activity.runOnUiThread {
            if (mProgressDailog != null && mProgressDailog!!.isShowing) {
                if (activity.window.decorView.isShown)
                    mProgressDailog!!.dismiss()
            }
        }
    }

    fun checkDeleteConfirmation() {
        if (config.isDeletePasswordProtectionOn) {
            activity.handleDeletePasswordProtection {
                deleteFiles()
            }
        } else {
            askConfirmDelete()
        }
    }

    private fun askConfirmDelete() {
        val itemsCnt = selectedKeys.size
        val firstPath = getSelectedNotes().first()
        val items = if (itemsCnt == 1) {
            "\"${firstPath.title}\""
        } else {
            resources.getQuantityString(R.plurals.delete_items, itemsCnt, itemsCnt)
        }

        val isRecycleBin = firstPath.deletedTS > 0

        val baseString = if (!isRecycleBin) R.string.msg_move_vault_trash else R.string.deletion_confirmation
//        val baseString = R.string.deletion_confirmation
        val question = String.format(resources.getString(baseString), items)
        deleteDialog = DeleteWithRememberDialog(activity, question) {
            if (it) {
                TrashActivity.isDeleteOrRestore = true
                showProgress(activity.getString(R.string.msg_deleting))
                config.tempSkipDeleteConfirmation = it
                deleteFiles()
            } else {
                finishActMode()
            }
        }

    }

    public fun dismissDeleteDialog() {
        if (deleteDialog != null) {
            deleteDialog!!.dialog.dismiss()
        }
    }

    private fun deleteFiles() {
        if (selectedKeys.isEmpty()) {
            return
        }
        ensureBackgroundThread {
            getSelectedNotes().forEach {
                if (it.deletedTS > 0) {
                    activity.noteDao.delete(it)
                } else {
                    it.deletedTS = System.currentTimeMillis()
                    activity.noteDao.update(it)
                }
            }

            activity.runOnUiThread {
                val removeMedia = ArrayList<Note>(selectedKeys.size)
                val positions = getSelectedItemPositions()
                dismissProgress()
                finishActMode()
                if (activity is SecretNotesActivity)
                    activity.toast(activity.getString(R.string.msg_note_delete_successfully))
                removeSelectedItems(positions)
                SecretNotesActivity.isNeedToRefersh = true
                currentMediaHash = media.hashCode()
                media.removeAll(removeMedia)
                listener?.refreshItems()
            }
        }
//

    }

    fun restoreFiles() {
        showProgress(activity.getString(R.string.please_wait))
        ensureBackgroundThread {
            getSelectedNotes().forEachIndexed { index, note ->
                note.deletedTS = 0
                activity.noteDao.update(note)
                if (index == getSelectedNotes().size - 1) {
                    activity.runOnUiThread {
                        dismissProgress()
                        val removeMedia = ArrayList<Note>(selectedKeys.size)
                        val positions = getSelectedItemPositions()
                        activity.addEvent(restoreNotes)
                        activity.toast(activity.getString(R.string.msg_notes_restored))
                        dismissProgress()
                        finishActMode()
                        removeSelectedItems(positions)
                        SecretNotesActivity.isNeedToRefersh = true
                        currentMediaHash = media.hashCode()
                        media.removeAll(removeMedia)
                        listener?.refreshItems()
                    }
                }
            }


        }

    }

}