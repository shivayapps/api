package com.gallery.photo.image.video.cameraview.stampmodel

import androidx.annotation.Keep

@Keep
data class Stampmodel(
    val ResponseCode: Int,
    val ResponseMessage: String,
    val `data`: List<Data>
)