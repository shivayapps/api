package com.gallery.photo.image.video.Camera.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.gallery.photo.image.video.Camera.PreferenceKeys;
import com.gallery.photo.image.video.Camera.cameracontroller.CameraController;
import com.gallery.photo.image.video.Camera.onRecyclerClickListener;
import com.gallery.photo.image.video.Camera.preview.Preview;
import com.gallery.photo.image.video.R;
import com.gallery.photo.image.video.utilities.SharedPrefs;

import java.util.List;

public class RatioAdapter extends RecyclerView.Adapter<RatioAdapter.MyViewHolder> {
    Context mContext;
    onRecyclerClickListener mOnRecyclerClickListener;
    List<CameraController.Size> mRatio_entries;
    int selctedPos;

    public RatioAdapter(Context context, Preview preview, List<CameraController.Size> list, onRecyclerClickListener onrecyclerclicklistener) {
        this.mContext = context;
        this.mRatio_entries = list;
        this.mOnRecyclerClickListener = onrecyclerclicklistener;
        this.selctedPos = SharedPrefs.getInt(context, PreferenceKeys.getRatioPos_PrefrenceKey(preview.getCameraId()), 0);
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_grid_dialog, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, final int i) {
        if (myViewHolder instanceof MyViewHolder) {
            myViewHolder.tv_ratio.setText(Preview.getAspectRatioMPString(this.mContext.getResources(), this.mRatio_entries.get(i).width, this.mRatio_entries.get(i).height, true) + " ");
            if (this.selctedPos == i) {
                myViewHolder.imgTick.setSelected(true);
            } else {
                myViewHolder.imgTick.setSelected(false);
            }
            myViewHolder.main_layout.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    if (RatioAdapter.this.mOnRecyclerClickListener != null) {
                        RatioAdapter.this.mOnRecyclerClickListener.setOnItemClickListener(i, view);
                    }
                    RatioAdapter.this.selctedPos = i;
                    RatioAdapter.this.notifyDataSetChanged();
                }
            });
        }
    }

    public int getItemCount() {
        List<CameraController.Size> list = this.mRatio_entries;
        if (list == null) {
            return 0;
        }
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imgTick;
        LinearLayout main_layout;
        TextView tv_ratio;

        public MyViewHolder(View view) {
            super(view);
            this.tv_ratio = (TextView) view.findViewById(R.id.tv_grid);
            this.imgTick = (ImageView) view.findViewById(R.id.img_tick);
            this.main_layout = (LinearLayout) view.findViewById(R.id.grid_layout);
        }
    }
}
