package com.gallery.photo.image.video.interfaces

import androidx.room.*
import com.gallery.photo.image.video.models.Note

@Dao
interface NoteDao {

    @Insert
    fun add(note: Note): Long

    @Query("select * from Note where id=:id")
    fun get(id: Int): Note?

    @Query("select * from Note where isFromFakeVault = 0 AND deleted_ts = 0 ORDER BY timestamp DESC")
    fun getMainVaultNotes(): List<Note>

    @Query("select * from Note where isFromFakeVault = 1 AND deleted_ts = 0  ORDER BY timestamp DESC")
    fun getFakeVaultNotes(): List<Note>

    @Query("select * from Note where isFromFakeVault = 0 AND deleted_ts > 0 ORDER BY timestamp DESC")
    fun getDeletedMainVaultNotes(): List<Note>

    @Query("select * from Note where isFromFakeVault = 1 AND deleted_ts > 0  ORDER BY timestamp DESC")
    fun getDeletedFakeVaultNotes(): List<Note>

    @Query("delete from Note where deleted_ts > 0  AND deleted_ts <= :endDeletedTS")
    fun deleteTrashNotes( endDeletedTS: Long)

    @Query("SELECT COUNT(*) FROM Note WHERE id=:id")
    fun isExist(id: Int): Int

    @Update
    fun update(note: Note)

    @Delete
    fun delete(note: Note)
}