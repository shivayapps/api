package com.gallery.photo.image.video.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.RowSlidetimeBinding
import com.gallery.photo.image.video.interfaces.SlideShowSelectListner
import java.util.*

class SlidingTimeAdapter(var repeat_list: ArrayList<String>, private val listner: SlideShowSelectListner) : BaseAdapter<String>(repeat_list) {

    override fun onCreateHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<*> {
        return MyViewHolder(RowSlidetimeBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun onBindHolder(holder: BaseViewHolder<*>, position: Int) {
        with(holder as MyViewHolder) {
            with(fBinding) {
                with(repeat_list[position]) {
                    try {
                        holder.setIsRecyclable(false)
                        tvRepeat.text =  this + " " + tvRepeat.context.getString(R.string.label_slide_show)
                        loutRepeat.setOnClickListener {
                            val time = this.toInt()
                            listner.onSlideSHowItemSelect(time);

                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return repeat_list.size
    }

    inner class MyViewHolder(fBinding: RowSlidetimeBinding) : BaseViewHolder<RowSlidetimeBinding>(fBinding)


//    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
//        var tv_repeat: TextView
//        var img_repeat: ImageView
//        var lout_repeat: LinearLayout
//
//        init {
//            tv_repeat = itemView.findViewById<View>(R.id.tv_repeat) as TextView
//            img_repeat = itemView.findViewById(R.id.img_repeat)
//            lout_repeat = itemView.findViewById<View>(R.id.lout_repeat) as LinearLayout
//
//        }
//    }


}