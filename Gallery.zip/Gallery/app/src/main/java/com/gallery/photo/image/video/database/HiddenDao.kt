package com.gallery.photo.image.video.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

//@Dao
//interface HiddenDao {
//    @Insert(onConflict = OnConflictStrategy.REPLACE)
//    fun hide(data: HiddenData)
//
//    @Query("SELECT * FROM hiddenData")
//    fun getHiddenList(): List<HiddenData>
//
//    @Update
//    fun update(data: HiddenData)
//
//    @Delete
//    fun unHide(data: HiddenData)
//
//    @Delete
//    fun deleteHide(data: HiddenData)
//
//    @Query("SELECT * FROM recentDeleteData")
//    fun getRecentDeleteList(): List<RecentDeleteData>
//
//    @Insert(onConflict = OnConflictStrategy.REPLACE)
//    fun insertRecentDelete(data: RecentDeleteData)
//
//    @Delete
//    fun removeRecentDelete(data: RecentDeleteData)
//}