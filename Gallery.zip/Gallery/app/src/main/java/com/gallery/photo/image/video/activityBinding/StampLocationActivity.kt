package com.gallery.photo.image.video.activityBinding

import android.app.Activity
import android.content.Intent
import android.location.Address
import android.location.Geocoder
import android.util.Log
import android.view.View
import android.widget.EditText
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.FragmentContainerView
import androidx.lifecycle.ViewModelProvider
import com.example.app.ads.helper.GiftIconHelper
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.cameraview.currentlocation.LocationViewModel
import com.gallery.photo.image.video.cameraview.database.model.CameraStamp
import com.gallery.photo.image.video.databinding.ActivityStampLocationBinding
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.utilities.AUTOMATIC
import com.gallery.photo.image.video.utilities.AsyncBackgroundWork
import com.gallery.photo.image.video.utilities.MANUAL
import com.gallery.photo.image.video.extensions.toast
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import java.io.IOException
import java.util.*
import kotlin.collections.ArrayList

class StampLocationActivity : BaseBindingActivity<ActivityStampLocationBinding>() {
    private var cameraStamp: CameraStamp? = null
    var mapLatitude: Double = 0.0
    var mapLongitude: Double = 0.0
    var camMove = 0
    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        if (AdsManager(this).isNeedToShowAds()) {
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = mBinding.giftLayout.giftAdIcon,
                fivBlastIcon = mBinding.giftLayout.giftBlastAdIcon
            )
        }
        cameraStamp = intent.getSerializableExtra("StampData") as CameraStamp?
//        mapLatitude = cameraStamp!!.latitude
//        mapLongitude = cameraStamp!!.longitude
        camMove = 0
        var locationType = "cameraStamp!!.locationType"

        var mMap: GoogleMap? = null
        val supportMapFragment: SupportMapFragment? =
            (supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?)
        val locationViewModelDialog = ViewModelProvider(this)[LocationViewModel::class.java]


        if (locationType == AUTOMATIC) {
            mBinding.map.isEnabled = false
            mBinding.map.alpha = 0.70F
            if (mMap != null) {
                mMap.uiSettings.isScrollGesturesEnabled = false
                mMap.uiSettings.isZoomGesturesEnabled = false
            }
            mBinding.tvAutomaticLbl.setTextColor(resources.getColor(R.color.colorPrimary))
            mBinding.tvManualLbl.setTextColor(resources.getColor(R.color.grey_500))
            mBinding.viewAutomaticBottomLineSelectedHeader.visibility = View.VISIBLE
            mBinding.viewManualBottomLineSelectedHeader.visibility = View.GONE
            mBinding.etAddress.background = null
            mBinding.etAddress.isEnabled = false
            mBinding.etAddress.setTextColor(resources.getColor(R.color.black))
            mBinding.etAddress.setPadding(0, 0, 0, 0)
            (mBinding.etAddress.layoutParams as ConstraintLayout.LayoutParams).apply {
                topMargin = 0
            }
        } else {
            if (mMap != null) {
                mMap.uiSettings.isScrollGesturesEnabled = true
                mMap.uiSettings.isZoomGesturesEnabled = true
            }
            mBinding.map.isEnabled = true
            mBinding.map.alpha = 1F
            mBinding.tvAutomaticLbl.setTextColor(resources.getColor(R.color.grey_500))
            mBinding.tvManualLbl.setTextColor(resources.getColor(R.color.colorPrimary))
            mBinding.viewAutomaticBottomLineSelectedHeader.visibility = View.GONE
            mBinding.viewManualBottomLineSelectedHeader.visibility = View.VISIBLE
            mBinding.etAddress.background = resources.getDrawable(R.drawable.grey_button_background)
            mBinding.etAddress.isEnabled = true
            mBinding.etAddress.setPadding(15, 0, 15, 0)
            (mBinding.etAddress.layoutParams as ConstraintLayout.LayoutParams).apply {
                topMargin = 15
            }
            if (cameraStamp!!.message.isEmpty()) {
                mBinding.etAddress.setText(resources.getString(R.string.unable_to_find_location))
            } else {
                mBinding.etAddress.setText(cameraStamp!!.message)
            }
        }
        mBinding.tvAutomaticLbl.setOnClickListener {
//            isDataChange = true
            if (mMap != null) {
                mMap!!.uiSettings.isScrollGesturesEnabled = false
                mMap!!.uiSettings.isZoomGesturesEnabled = false
            }
            mBinding.map.isEnabled = false
            mBinding.map.alpha = 0.70F
            locationType = AUTOMATIC
            mBinding.tvAutomaticLbl.setTextColor(resources.getColor(R.color.colorPrimary))
            mBinding.tvManualLbl.setTextColor(resources.getColor(R.color.grey_500))
            mBinding.viewAutomaticBottomLineSelectedHeader.visibility = View.VISIBLE
            mBinding.viewManualBottomLineSelectedHeader.visibility = View.GONE
            mBinding.etAddress.background = null
            mBinding.etAddress.isEnabled = false
            mBinding.etAddress.setTextColor(resources.getColor(R.color.black))
            mBinding.etAddress.setPadding(0, 0, 0, 0)
            (mBinding.etAddress.layoutParams as ConstraintLayout.LayoutParams).apply {
                topMargin = 0
            }
            updateAutomaticLocationForDialog(
                locationViewModelDialog,
                locationType,
                mMap!!,
                mBinding.map,
                mBinding.etAddress
            )

        }
        mBinding.ivBack.setOnClickListener {
            onBackPressed()
        }

        mBinding.tvManualLbl.setOnClickListener {
//            isDataChange = true
            if (mMap != null) {
                mMap!!.uiSettings.isScrollGesturesEnabled = true
                mMap!!.uiSettings.isZoomGesturesEnabled = true
            }
            mBinding.map.isEnabled = true
            mBinding.map.alpha = 1F
            locationType = MANUAL
            mBinding.tvAutomaticLbl.setTextColor(resources.getColor(R.color.grey_500))
            mBinding.tvManualLbl.setTextColor(resources.getColor(R.color.colorPrimary))
            mBinding.viewAutomaticBottomLineSelectedHeader.visibility = View.GONE
            mBinding.viewManualBottomLineSelectedHeader.visibility = View.VISIBLE
            mBinding.etAddress.background = resources.getDrawable(R.drawable.grey_button_background)
            mBinding.etAddress.setPadding(15, 0, 15, 0)
            mBinding.etAddress.isEnabled = true
            (mBinding.etAddress.layoutParams as ConstraintLayout.LayoutParams).apply {
                topMargin = 15
            }
            removeAutomaticLocationForDialog(locationViewModelDialog)
        }

        supportMapFragment?.onCreate(null)
//        supportMapFragment?.onResume()

        supportMapFragment?.getMapAsync { it ->
            mMap = it
            mMap!!.uiSettings.isScrollGesturesEnabled = true
            mMap!!.uiSettings.isZoomGesturesEnabled = true

            if (locationType == MANUAL) {
                mMap!!.moveCamera(CameraUpdateFactory.newLatLng(LatLng(mapLatitude, mapLongitude)))
                mMap!!.animateCamera(
                    CameraUpdateFactory.newLatLngZoom(
                        LatLng(
                            mapLatitude,
                            mapLongitude
                        ), 15.0f
                    )
                )
            }

            mMap!!.setOnCameraIdleListener {
                onCameraIdle_(
                    locationViewModelDialog,
                    locationType,
                    mMap!!,
                    mBinding.map,
                    mBinding.etAddress
                )
            }

            updateAutomaticLocationForDialog(
                locationViewModelDialog,
                locationType,
                mMap!!,
                mBinding.map,
                mBinding.etAddress
            )

        }
        mBinding.tvSave.setOnClickListener {
            if (locationType == MANUAL) {
                if (mBinding.etAddress.text.toString().trim().isEmpty()) {
                    toast(resources.getString(R.string.please_enter_the_location))
                    return@setOnClickListener
                }
            }
            var intent = Intent()
            intent.putExtra("LocationType", locationType)
            intent.putExtra("latitude", mapLatitude)
            intent.putExtra("longitude", mapLongitude)
            intent.putExtra("address", mBinding.etAddress.text.toString())
            setResult(RESULT_OK, intent)
            finish()


        }

    }

    private fun onCameraIdle_(
        locationViewModelDialog: LocationViewModel,
        locationType: String,
        mMap: GoogleMap,
        lMap: FragmentContainerView,
        etAddress: EditText
    ) {
        var lat_lon: LatLng? = null
        val i: Int = camMove + 1
        camMove = i
        if (i >= 2 && mMap.cameraPosition.target.also { lat_lon = it } != null) {
            if (locationType == MANUAL) {
                Log.e(TAG, "showLocationDialog: ")
                removeAutomaticLocationForDialog(locationViewModelDialog)
                mMap.uiSettings.isScrollGesturesEnabled = true
                mMap.uiSettings.isZoomGesturesEnabled = true
                lMap.isEnabled = true
                lMap.alpha = 1F

                val geocoder = Geocoder(this, Locale.getDefault())
                val addresses: ArrayList<Address> = ArrayList()
                AsyncBackgroundWork({

                }, {
                    try {
                        addresses.addAll(
                            geocoder.getFromLocation(
                                lat_lon!!.latitude,
                                lat_lon!!.longitude,
                                1
                            )
                        )
                    } catch (e: IOException) {

                    }
                }) {
                    if (addresses.isNotEmpty()) {
                        val address = addresses[0].getAddressLine(0)
                        etAddress.setText(address)
                    } else {
                        etAddress.setText(resources.getString(R.string.unable_to_find_location))
                    }
                    etAddress.setSelection(etAddress.text.toString().trim().length)
                    mapLatitude = lat_lon!!.latitude
                    mapLongitude = lat_lon!!.longitude
                }
            }
        }
    }


    private fun updateAutomaticLocationForDialog(
        locationViewModelDialog: LocationViewModel,
        locationType: String,
        mMap: GoogleMap,
        lMap: FragmentContainerView,
        etAddress: EditText
    ) {
        if (mMap != null && lMap != null && locationViewModelDialog != null && locationType == AUTOMATIC) {
            locationViewModelDialog.getLocationDialogData().observe(this, { (longitude, latitude) ->
                if (locationType == AUTOMATIC) {
                    Log.e(TAG, "updateAutomaticLocationForDialog: ")
                    mMap.uiSettings.isScrollGesturesEnabled = false
                    mMap.uiSettings.isZoomGesturesEnabled = false
                    lMap.isEnabled = false
                    lMap.alpha = 0.70F

                    mMap.moveCamera(CameraUpdateFactory.newLatLng(LatLng(latitude, longitude)))
                    mMap.animateCamera(
                        CameraUpdateFactory.newLatLngZoom(
                            LatLng(
                                latitude,
                                longitude
                            ), 15.0f
                        )
                    )

                    val geocoder = Geocoder(this, Locale.getDefault())
                    val addresses: ArrayList<Address> = ArrayList()
                    AsyncBackgroundWork({

                    }, {
                        try {
                            addresses.addAll(geocoder.getFromLocation(latitude, longitude, 1))
                        } catch (e: IOException) {
                        }
                    }) {
                        if (addresses.isNotEmpty()) {
                            val address = addresses[0].getAddressLine(0)
                            etAddress.setText(address)
                        } else {
                            etAddress.setText(resources.getString(R.string.unable_to_find_location))
                        }

                        mapLatitude = latitude
                        mapLongitude = longitude
                    }
                }
            })
        }
    }

    private fun removeAutomaticLocationForDialog(locationViewModelDialog: LocationViewModel) {
        locationViewModelDialog.getLocationDialogData().removeObservers(this)
    }

    override fun initActions() {

    }

    override fun setBinding(): ActivityStampLocationBinding {
        return ActivityStampLocationBinding.inflate(inflater)
    }

}