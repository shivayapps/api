package com.gallery.photo.image.video.models

import java.io.Serializable

data class TimeLineModel(var yearAgo: Int, val mMedia: ArrayList<String>) :Serializable