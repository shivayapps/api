package com.gallery.photo.image.video.fragment

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.MainActivity
import com.gallery.photo.image.video.activityBinding.TrashActivity
import com.gallery.photo.image.video.activityBinding.TrashImagePreviewActivity
import com.gallery.photo.image.video.adapter.TrashImageVideoAdapter
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.databinding.FragmentTrashImageBinding
import com.gallery.photo.image.video.dialog.DeleteWithRememberDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.videoplayer.VideoPlayerActivity
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.helpers.FAVORITES
import com.gallery.photo.image.video.helpers.VIEW_TYPE_GRID
import com.gallery.photo.image.video.helpers.VIEW_TYPE_LIST
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager
import com.gallery.photo.image.video.views.MyRecyclerView
import java.io.File
import java.util.HashMap


class TrashVideoFragment : BaseBindingFragment<FragmentTrashImageBinding>(), MediaOperationsListener {

    var title: String? = null
    private var mPath = ""
    private var mIsGetImageIntent = true
    private var mIsGetVideoIntent = false
    private var mIsGetAnyIntent = false
    private var mAllowPickingMultiple = false
    private var mShowAll = false

    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mLastSearchedText = ""
    var itemClickPath: String = ""
    var isShowInfo = false
    var isHide = true
    var isFromVault = false
    var isFromFakeVault = false

    var mMedia = ArrayList<Medium>()
    private var uriList = ArrayList<Uri>()
    var isVideoClicked = false

    companion object {
        var isNeedToRefresh = false

        @JvmStatic
        fun newInstance() =
            TrashVideoFragment().apply {

            }
    }

    override fun setBinding(layoutInflater: LayoutInflater, container: ViewGroup?): FragmentTrashImageBinding {
        return FragmentTrashImageBinding.inflate(layoutInflater, container, false)
    }


    override fun initView() {
        super.initView()
        mBinding.mediaRefreshLayout.setOnRefreshListener { getMedia() }
        getMedia()
        if (AdsManager(mContext).isNeedToShowAds() && mContext.isOnline()) {
            InterstitialAdHelper.loadInterstitialAd(fContext = requireContext())
        }
    }


    override fun onResume() {
        super.onResume()
        if (isNeedToRefresh) {
            isNeedToRefresh = false
            getMedia()
        }
    }


    private fun getMedia() {
        if (getTrashAdapter() != null)
            getTrashAdapter()!!.finishActMode()
        ensureBackgroundThread {

            if (isAdded) {
                var newMedia = mContext.mediaDB.getTypeWiseDeletedMedia(RECYCLE_BIN,TYPE_VIDEOS)
                if (VaultFragment.isFakeVaultOpen) {
                    if (isAdded) {
                        newMedia = mContext.fakeVaultMediumDao.getTypeWiseDeletedMedia(RECYCLE_BIN,TYPE_VIDEOS)
                    }
                }
                Log.d(TAG, "getMedia: New Media Video ->" + newMedia.size)
                if (isAdded) {
                    newMedia.filter {
                        var path = File(mContext.recycleBinPath, it.path.removePrefix(RECYCLE_BIN)).toString()
                        !mContext.getDoesFilePathExist(path)
                    }.forEach {
                        if (isAdded) {
                            if (VaultFragment.isFakeVaultOpen)
                                mContext.fakeVaultMediumDao.deleteMediumPath(it.path)
                            else
                                mContext.mediaDB.deleteMediumPath(it.path)
                        }
                    }
                }
                if (isAdded) {
                    mMedia = mContext.getUpdatedTrashMediaPath(newMedia as ArrayList<Medium>)
                }
                if (isAdded) {
                    requireActivity().runOnUiThread {
                        Log.d(TAG, "getMedia: Media size -->" + mMedia.size)
                        mBinding.rlNoFileFound.beVisibleIf(mMedia.isEmpty())
                        mBinding.rlNoFileFound.beGoneIf(mMedia.isNotEmpty())
                        mBinding.mediaGrid.beVisibleIf(mBinding.rlNoFileFound.isGone())
                        mBinding.mediaRefreshLayout.isRefreshing = false
                        if (mContext is TrashActivity) {
                            if ((mContext as TrashActivity).mBinding.viewPagerTrash.currentItem == 1) {
                                (mContext as TrashActivity).mBinding.imgDelete.beGoneIf(mMedia.size <= 0)
                                (mContext as TrashActivity).mBinding.imgDelete.beVisibleIf(mMedia.size > 0)
                            }
                        }
                        setupAdapter()
                    }
                }
            }

        }
    }

    private fun setupAdapter() {
        Log.d("TAG", "setupAdapter: " + mMedia.size.toString())
        if (isAdded) {
            val currAdapter = mBinding.mediaGrid.adapter
            if (currAdapter == null) {
                val fastscroller = if (mContext.config.scrollHorizontally) mBinding.mediaHorizontalFastscroller else mBinding.mediaVerticalFastscroller
                TrashImageVideoAdapter(
                    mContext as BaseSimpleActivity, mMedia, mMedia.clone() as ArrayList<Medium>, this, mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent,
                    mAllowPickingMultiple, mPath, mBinding.mediaGrid, fastscroller, isFromFakeVault
                ) {
                    if (it is Medium) {
                        itemClicked(it.path)
                    }
                }.apply {
                    mBinding.mediaGrid.adapter = this
                }

                val viewType = mContext.config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
                if (viewType == VIEW_TYPE_LIST) {
                    mBinding.mediaGrid.scheduleLayoutAnimation()
                }

                setupLayoutManager()
                measureRecyclerViewContent(mMedia)
            } else if (mLastSearchedText.isEmpty()) {
                (currAdapter as TrashImageVideoAdapter).updateMedia(mMedia)
                measureRecyclerViewContent(mMedia)
            }

            setupScrollDirection()
        }
    }

    private fun itemClicked(path: String) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        itemClickPath = path

        val isVideo = path.isVideoFast()
        if (isVideo) {
            if (isVideoClicked)
                return
            isVideoClicked = true
            ensureBackgroundThread {
                var media = mMedia as ArrayList<Medium>
                media = media.filter { medium ->
                    medium.isVideo() && medium.path.getFilenameExtension() != ".avi" && medium.path.getFilenameExtension() != ".flv"
                } as ArrayList<Medium>
                uriList = media.map {
                    FileProvider.getUriForFile(
                        mContext,
                        "${mContext.packageName}.fileprovider", File(it.path)
                    )
                } as ArrayList<Uri>
            }
            if (MainActivity.isAdShown) {
                loadVideo(path)
            } else {
                if (AdsManager(mContext).isNeedToShowAds() && mContext.isOnline()) {
                    requireActivity().isShowInterstitialAd {
                        isInterstitialShown = false
                        loadVideo(path)
                    }

                } else {
                    isInterstitialShown = false
                    loadVideo(path)
                }
            }
        } else {
            Intent(mContext, TrashImagePreviewActivity::class.java).apply {
                putExtra(SKIP_AUTHENTICATION, false)
                putExtra(PATH, path)
                putExtra(SHOW_ALL, mShowAll)
                putExtra(SHOW_ONLY_HIDDEN, true)
                putExtra(SHOW_FAVORITES, mPath == FAVORITES)
                putExtra(SHOW_RECYCLE_BIN, mPath == RECYCLE_BIN)
                putExtra(IS_FROM_FAKE_VAULT, isFromFakeVault)
                putExtra(IS_FROM_VAULT, isFromVault)

                startActivity(this)
            }
        }

    }

    private fun loadVideo(path: String) {
        isVideoClicked = false
        val extras = HashMap<String, Boolean>()
        extras[SHOW_FAVORITES] = mPath == FAVORITES


        //                openPath(path, false, extras)
        val uri = FileProvider.getUriForFile(
            mContext,
            "${mContext.packageName}.fileprovider", File(path)
        )


        val mimeType = mContext.getUriMimeType(path, uri)
        if (VideoPlayerActivity.mActivity != null) {
            VideoPlayerActivity.mActivity.finish()
        }

        val extension: String = uri.path!!.substring(uri.path!!.lastIndexOf("."))

        if (extension == ".avi" || extension == ".flv") {
            val file: File = File(uri.path)
            Log.e("TAG", "loadVideo:absolutePath --> " + file.absolutePath)

            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(Uri.parse(file.absolutePath.replace("/external_files", "")), "video/*")
            try {
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(mContext, R.string.error_no_video_activity, Toast.LENGTH_SHORT).show()
            }

        } else {
            VideoPlayerActivity.UriList = uriList
            VideoPlayerActivity.index = uriList.indexOf(uri)
            Intent(mContext, VideoPlayerActivity::class.java).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT)
                startActivity(this)
            }
        }

    }

    private fun setupLayoutManager() {
        val viewType = mContext.config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            setupGridLayoutManager()
        } else {
            setupListLayoutManager()
        }
    }

    private fun setupGridLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = 0
            bottomMargin = 0
        }

        try {
            if (mContext.config.scrollHorizontally) {
                layoutManager.orientation = RecyclerView.HORIZONTAL
            } else {
                layoutManager.orientation = RecyclerView.VERTICAL
            }
        } catch (e: Exception) {
        }

        layoutManager.spanCount = mContext.config.mediaColumnCnt
        val adapter = getTrashAdapter()
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter?.isASectionTitle(position) == true) {
                    layoutManager.spanCount
                } else {
                    1
                }
            }
        }
    }

    private fun getTrashAdapter() = mBinding.mediaGrid.adapter as? TrashImageVideoAdapter
    private fun setupListLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL

        val smallMargin = resources.getDimension(R.dimen.small_margin).toInt()
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = smallMargin
            bottomMargin = smallMargin
        }
    }

    private fun setupScrollDirection() {
        val viewType = mContext.config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        val allowHorizontalScroll = mContext.config.scrollHorizontally && viewType == VIEW_TYPE_GRID
        mBinding.mediaVerticalFastscroller.isHorizontal = false
        mBinding.mediaVerticalFastscroller.beGoneIf(allowHorizontalScroll)
        mBinding.mediaHorizontalFastscroller.isHorizontal = true
        mBinding.mediaHorizontalFastscroller.beVisibleIf(allowHorizontalScroll)

    }


    private fun measureRecyclerViewContent(media: ArrayList<Medium>) {
        mBinding.mediaGrid.onGlobalLayout {
            if (mContext.config.scrollHorizontally) {
                calculateContentWidth(media)
            } else {
                calculateContentHeight(media)
            }
        }
    }

    private fun calculateContentWidth(media: ArrayList<Medium>) {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        val thumbnailWidth = layoutManager.getChildAt(0)?.width ?: 0
        val spacing = mContext.config.thumbnailSpacing
        val fullWidth = ((media.size - 1) / layoutManager.spanCount + 1) * (thumbnailWidth + spacing) - spacing
        mBinding.mediaHorizontalFastscroller.setContentWidth(fullWidth)
        mBinding.mediaHorizontalFastscroller.setScrollToX(mBinding.mediaGrid.computeHorizontalScrollOffset())
    }

    private fun calculateContentHeight(media: ArrayList<Medium>) {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        val pathToCheck = if (mPath.isEmpty()) SHOW_ALL else mPath
        val hasSections = mContext.config.getFolderGrouping(pathToCheck) and GROUP_BY_NONE == 0 && !mContext.config.scrollHorizontally
        val sectionTitleHeight = if (hasSections) layoutManager.getChildAt(0)?.height ?: 0 else 0
        val thumbnailHeight = if (hasSections) layoutManager.getChildAt(1)?.height ?: 0 else layoutManager.getChildAt(0)?.height ?: 0

        var fullHeight = 0
        var curSectionItems = 0
        media.forEach {
            if (it is Medium) {
                fullHeight += sectionTitleHeight
                if (curSectionItems != 0) {
                    val rows = ((curSectionItems - 1) / layoutManager.spanCount + 1)
                    fullHeight += rows * thumbnailHeight
                }
                curSectionItems = 0
            } else {
                curSectionItems++
            }
        }
        val spacing = mContext.config.thumbnailSpacing
        fullHeight += ((curSectionItems - 1) / layoutManager.spanCount + 1) * (thumbnailHeight + spacing) - spacing
        mBinding.mediaVerticalFastscroller.setContentHeight(fullHeight)
        mBinding.mediaVerticalFastscroller.setScrollToY(mBinding.mediaGrid.computeVerticalScrollOffset())
    }

    override fun refreshItems() {
        getMedia()

    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {
        val filtered = fileDirItems.filter { !mContext.getIsPathDirectory(it.path) && it.path.isMediaFile() } as ArrayList
        if (filtered.isEmpty()) {
            return
        }
        deleteFilteredFiles(filtered)
    }

    private fun deleteFilteredFiles(filtered: ArrayList<FileDirItem>) {
        (mContext as BaseSimpleActivity).deleteFiles(filtered) {
            if (!it) {
                mContext.toast(R.string.unknown_error_occurred)
                if (getTrashAdapter() != null)
                    getTrashAdapter()!!.dismissProgress()
                if (mContext is TrashActivity)
                    (mContext as TrashActivity).dismissProgress()
                return@deleteFiles
            }

            mMedia.removeAll { filtered.map { it.path }.contains((it as? Medium)?.path) }

            ensureBackgroundThread {

                filtered.forEach {
                    if (VaultFragment.isFakeVaultOpen)
                        mContext.fakeVaultMediumDao.deleteMediumPath(it.path.replace("${mContext.recycleBinPath}", RECYCLE_BIN))
                    else
                        mContext.mediaDB.deleteMediumPath(it.path.replace("${mContext.recycleBinPath}", RECYCLE_BIN))
                }
                if (mPath.containsNoMedia() || filtered[0].path.getFilenameFromPath().startsWith(".")) {
                    if (mContext.hiddenDirectoryDao.getDirectoryThumbnail(mPath) != null) {
                        mContext.updatePhotoVideoDirectoryPath(mPath, false, true, true)
                    }
                }

                mContext.updatePhotoVideoDirectoryPath(mPath, false, true)

                mContext.runOnUiThread {

                    mContext.addEvent(deleteTrashVideo)
                    if (getTrashAdapter() != null)
                        getTrashAdapter()!!.dismissProgress()
                    if (mContext is TrashActivity)
                        (mContext as TrashActivity).dismissProgress()
                    refreshItems()
                }
            }
        }
    }

    override fun selectedPaths(paths: ArrayList<String>) {

    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {

    }

    fun restoreVideo() {
        if (getTrashAdapter() != null) {
            getTrashAdapter()!!.restoreFiles(false)
        }
    }

    fun deleteVideos() {
        if (getTrashAdapter() != null) {
            getTrashAdapter()!!.checkDeleteConfirmation()
        }
    }

    fun deleteAllVideos() {
        if (mMedia.isEmpty())
            return
        val itemsCnt = mMedia.size
        val firstPath = mMedia.first().path
        val items = if (itemsCnt == 1) {
            "\"${firstPath.getFilenameFromPath()}\""
        } else {
            resources.getQuantityString(R.plurals.delete_items, itemsCnt, itemsCnt)
        }

        val baseString = R.string.deletion_confirmation
        val question = String.format(resources.getString(baseString), items)
        DeleteWithRememberDialog(mContext, question) {
            if (it) {
                TrashActivity.isDeleteOrRestore = true
                if (mContext is TrashActivity)
                    (mContext as TrashActivity).showProgress(mContext.getString(R.string.msg_deleting))
                mContext.config.tempSkipDeleteConfirmation = it
                val fileDirItems = ArrayList<FileDirItem>(mMedia.size)
                mMedia.forEach {
                    fileDirItems.add(FileDirItem(it.path, it.name))
                }
                tryDeleteFiles(fileDirItems)
            }

        }
    }

//    override fun onAdLoaded(interstitialAd: InterstitialAd) {
//        interstitialAdShow = interstitialAd
//    }
//
//    override fun onAdFailedToLoad() {
//        interstitialAdShow = null
//        InterstitialAdHelper.instance!!.load(requireActivity(), this)
//    }
//
//    override fun onAdClosed() {
//        interstitialAdShow = null
//        InterstitialAdHelper.instance!!.load(requireActivity(), this)
//        loadVideo(itemClickPath)
//    }

}