package com.gallery.photo.image.video.Camera.preview;

import android.util.Log;


import com.gallery.photo.image.video.Camera.cameracontroller.CameraController;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class VideoQualityHandler {
    private static final String TAG = "VideoQualityHandler";
    private int current_video_quality = -1;
    private List<String> video_quality;
    private List<CameraController.Size> video_sizes;
    private List<CameraController.Size> video_sizes_high_speed;

    public static class Dimension2D {
        final int height;
        final int width;

        public Dimension2D(int i, int i2) {
            this.width = i;
            this.height = i2;
        }
    }

    /* access modifiers changed from: package-private */
    public void resetCurrentQuality() {
        this.video_quality = null;
        this.current_video_quality = -1;
    }

    public void initialiseVideoQualityFromProfiles(List<Integer> list, List<Dimension2D> list2) {
        boolean[] zArr;
        Log.d(TAG, "initialiseVideoQualityFromProfiles()");
        this.video_quality = new ArrayList();
        List<CameraController.Size> list3 = this.video_sizes;
        if (list3 != null) {
            zArr = new boolean[list3.size()];
            for (int i = 0; i < this.video_sizes.size(); i++) {
                zArr[i] = false;
            }
        } else {
            zArr = null;
        }
        if (list.size() == list2.size()) {
            for (int i2 = 0; i2 < list.size(); i2++) {
                Dimension2D dimension2D = list2.get(i2);
                addVideoResolutions(zArr, list.get(i2).intValue(), dimension2D.width, dimension2D.height);
            }
            for (int i3 = 0; i3 < this.video_quality.size(); i3++) {
                Log.d(TAG, "supported video quality: " + this.video_quality.get(i3));
            }
            return;
        }
        Log.e(TAG, "profiles and dimensions have unequal sizes");
        throw new RuntimeException();
    }

    private static class SortVideoSizesComparator implements Comparator<CameraController.Size>, Serializable {
        private static final long serialVersionUID = 5802214721033718212L;

        private SortVideoSizesComparator() {
        }

        public int compare(CameraController.Size size, CameraController.Size size2) {
            return (size2.width * size2.height) - (size.width * size.height);
        }
    }

    public void sortVideoSizes() {
        Log.d(TAG, "sortVideoSizes()");
        Collections.sort(this.video_sizes, new SortVideoSizesComparator());
        for (CameraController.Size next : this.video_sizes) {
            Log.d(TAG, "    supported video size: " + next.width + ", " + next.height);
        }
    }

    private void addVideoResolutions(boolean[] zArr, int i, int i2, int i3) {
        if (this.video_sizes != null) {
            Log.d(TAG, "profile " + i + " is resolution " + i2 + " x " + i3);
            for (int i4 = 0; i4 < this.video_sizes.size(); i4++) {
                if (!zArr[i4]) {
                    CameraController.Size size = this.video_sizes.get(i4);
                    if (size.width == i2 && size.height == i3) {
                        String str = "" + i;
                        this.video_quality.add(str);
                        zArr[i4] = true;
                        Log.d(TAG, "added: " + i4 + ":" + str + " " + size.width + "x" + size.height);
                    } else if (i == 0 || size.width * size.height >= i2 * i3) {
                        String str2 = "" + i + "_r" + size.width + "x" + size.height;
                        this.video_quality.add(str2);
                        zArr[i4] = true;
                        Log.d(TAG, "added: " + i4 + ":" + str2);
                    }
                }
            }
        }
    }

    public List<String> getSupportedVideoQuality() {
        Log.d(TAG, "getSupportedVideoQuality");
        return this.video_quality;
    }

    /* access modifiers changed from: package-private */
    public int getCurrentVideoQualityIndex() {
        Log.d(TAG, "getCurrentVideoQualityIndex");
        return this.current_video_quality;
    }

    /* access modifiers changed from: package-private */
    public void setCurrentVideoQualityIndex(int i) {
        Log.d(TAG, "setCurrentVideoQualityIndex: " + i);
        this.current_video_quality = i;
    }

    public String getCurrentVideoQuality() {
        int i = this.current_video_quality;
        if (i == -1) {
            return null;
        }
        return this.video_quality.get(i);
    }

    public List<CameraController.Size> getSupportedVideoSizes() {
        Log.d(TAG, "getSupportedVideoSizes");
        return this.video_sizes;
    }

    public List<CameraController.Size> getSupportedVideoSizesHighSpeed() {
        Log.d(TAG, "getSupportedVideoSizesHighSpeed");
        return this.video_sizes_high_speed;
    }

    public boolean videoSupportsFrameRate(int i) {
        return CameraController.CameraFeatures.supportsFrameRate(this.video_sizes, i);
    }

    public boolean videoSupportsFrameRateHighSpeed(int i) {
        return CameraController.CameraFeatures.supportsFrameRate(this.video_sizes_high_speed, i);
    }

    /* access modifiers changed from: package-private */
    public CameraController.Size findVideoSizeForFrameRate(int i, int i2, double d) {
        Log.d(TAG, "findVideoSizeForFrameRate");
        Log.d(TAG, "width: " + i);
        Log.d(TAG, "height: " + i2);
        Log.d(TAG, "fps: " + d);
        CameraController.Size size = new CameraController.Size(i, i2);
        CameraController.Size findSize = CameraController.CameraFeatures.findSize(getSupportedVideoSizes(), size, d, false);
        if (findSize != null || getSupportedVideoSizesHighSpeed() == null) {
            return findSize;
        }
        Log.d(TAG, "need to check high speed sizes");
        return CameraController.CameraFeatures.findSize(getSupportedVideoSizesHighSpeed(), size, d, false);
    }

    private static CameraController.Size getMaxVideoSize(List<CameraController.Size> list) {
        int i = -1;
        int i2 = -1;
        for (CameraController.Size next : list) {
            if (i == -1 || next.width * next.height > i * i2) {
                i = next.width;
                i2 = next.height;
            }
        }
        return new CameraController.Size(i, i2);
    }

    /* access modifiers changed from: package-private */
    public CameraController.Size getMaxSupportedVideoSize() {
        return getMaxVideoSize(this.video_sizes);
    }

    /* access modifiers changed from: package-private */
    public CameraController.Size getMaxSupportedVideoSizeHighSpeed() {
        return getMaxVideoSize(this.video_sizes_high_speed);
    }

    public void setVideoSizes(List<CameraController.Size> list) {
        this.video_sizes = list;
        sortVideoSizes();
    }

    public void setVideoSizesHighSpeed(List<CameraController.Size> list) {
        this.video_sizes_high_speed = list;
    }
}
