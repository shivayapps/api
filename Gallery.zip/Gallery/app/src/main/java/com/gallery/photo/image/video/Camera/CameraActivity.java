package com.gallery.photo.image.video.Camera;


//import static com.gallery.photo.image.video.utilities.UtilsKt.addEvent;
//import static com.gallery.photo.image.video.utilities.UtilsKt.cameraPicPathNew;

import android.Manifest;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.renderscript.RenderScript;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.OrientationEventListener;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ZoomControls;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.text.HtmlCompat;
import androidx.exifinterface.media.ExifInterface;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.ItemTouchHelper;

import com.bumptech.glide.Glide;
import com.gallery.photo.image.video.views.MySquareImageView;
import com.example.jdrodi.utilities.GeneralUtilsKt;
import com.gallery.photo.image.video.AppController;
import com.gallery.photo.image.video.Camera.cameracontroller.CameraControllerManager;
import com.gallery.photo.image.video.Camera.ui.ManualSeekbars;
import com.gallery.photo.image.video.activity.BaseActivity;
import com.gallery.photo.image.video.activity.ImagePreviewActivity;
import com.gallery.photo.image.video.activity.MainActivity;
//import com.gallery.photo.image.video.cameraview.ui.CameraShortcutActivity;
import com.gallery.photo.image.video.cameraview.ui.NetworkChangeReceiver;
import com.gallery.photo.image.video.cameraview.ui.helper.HelperClass;
import com.gallery.photo.image.video.dialog.CameraGridDialog;
import com.gallery.photo.image.video.extensions.ContextKt;
import com.gallery.photo.image.video.utilities.ConstantsKt;
import com.gallery.photo.image.video.utilities.NetworkManager;
import com.gallery.photo.image.video.utilities.SharedPrefs;
import com.gallery.photo.image.video.utilities.UtilsKt;
import com.gallery.photo.image.video.extensions.StringKt;
//import com.google.android.gms.location.LocationCallback;
//import com.google.android.gms.location.LocationRequest;
//import com.google.android.gms.location.LocationSettingsRequest;
//import com.google.android.gms.maps.model.Marker;
//import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.gallery.photo.image.video.Camera.cameracontroller.CameraController;
import com.gallery.photo.image.video.Camera.cameracontroller.CameraControllerManager2;
import com.gallery.photo.image.video.Camera.fragments.RatioFragment;
import com.gallery.photo.image.video.Camera.preview.Preview;
import com.gallery.photo.image.video.Camera.remotecontrol.BluetoothRemoteControl;
import com.gallery.photo.image.video.Camera.ui.MainUI;

import com.gallery.photo.image.video.Camera.utils.HelperKt;
import com.gallery.photo.image.video.R;
import com.tbruyelle.rxpermissions2.RxPermissions;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;

public class CameraActivity extends BaseActivity implements NetworkChangeReceiver.ConnectivityReceiverListener1{

    long mLastClickTime = 0;
    int mMinDuration = 1200;

    static private final String ACTION_SHORTCUT_CAMERA = "net.sourceforge.opencamera.SHORTCUT_CAMERA";
    static private final String ACTION_SHORTCUT_SELFIE = "net.sourceforge.opencamera.SHORTCUT_SELFIE";
    static private final String ACTION_SHORTCUT_VIDEO = "net.sourceforge.opencamera.SHORTCUT_VIDEO";
    static private final String ACTION_SHORTCUT_GALLERY = "net.sourceforge.opencamera.SHORTCUT_GALLERY";
    static private final String ACTION_SHORTCUT_SETTINGS = "net.sourceforge.opencamera.SHORTCUT_SETTINGS";
    private static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = 5000;
    private static final int REQUEST_CODE_OPEN_GALLERY = 1111;
    private static final long MAX_WAIT_TIME = 2000;
    private static final String TAG = "CameraActivity";
    private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 1000;
    private static int activity_count;
    public static boolean test_force_supports_camera2;
    public boolean IS_ADS;
    RxPermissions rxPermissions;
    boolean isFirstTime = true;
    private final SensorEventListener accelerometerListener = new SensorEventListener() {

        public void onAccuracyChanged(Sensor sensor, int i) {

        }

        public void onSensorChanged(SensorEvent sensorEvent) {
            CameraActivity.this.preview.onAccelerometerSensorChanged(sensorEvent);
        }
    };

    String address_line_1;
    String quoteMessage;

    private boolean app_is_paused = false;
    public MyApplicationInterface applicationInterface;
    private final ToastBoxer audio_control_toast = new ToastBoxer();
    private AudioListener audio_listener;
    private List<Integer> back_camera_ids;
    RelativeLayout banner_native_layout;
    private BluetoothRemoteControl bluetoothRemoteControl;
    private final BroadcastReceiver cameraReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            Log.d(CameraActivity.TAG, "cameraReceiver.onReceive");
            CameraActivity.this.takePicture(false);
        }
    };
    public boolean camera_in_background;
    private final ToastBoxer changed_auto_stabilise_toast = new ToastBoxer();
//    String city;
//    String country;
    DecimalFormat dFormat;

    private List<Integer> front_camera_ids;
//    FusedLocationProviderClient fusedLocationClient;
    public volatile Bitmap gallery_bitmap;
    public ValueAnimator gallery_save_anim;

    ImageView img_tamplate;
    ImageView img_timer;
    LinearLayout liTimer;
    private Handler immersive_timer_handler = null;
    private Runnable immersive_timer_runnable = null;
    public int isInternetDialog = 0;
    int isPermission = 0;
    private boolean isSDCardPermission;
    private boolean isSDCardStorageEnabled;

    private boolean is_multi_cam;
    public boolean is_test;
    private int large_heap_memory;
    private boolean last_continuous_fast_burst;
    private LinearLayout li_Multi_Camera;

    private ImageView ivSwitchCamera;
    private LinearLayout li_timer;
    private RelativeLayout mBottomScreenPannel;

//    private GoogleMap mGMap;

    ImageView mImgTakePhoto;
    private ImageView mImg_camera_settings;
    ImageView mImg_flash;
    private ImageView mImg_focus;

    private LinearLayout mLi_app_setting;
    private LinearLayout mLi_camera_setting;
    private LinearLayout mLi_filename;
    private LinearLayout mLi_focus;
    private LinearLayout mLi_grid;
    private LinearLayout mLi_mirror;
    private LinearLayout mLi_ratio;
    FrameLayout cameraPreviewLayout;
    Location mLocation;
//    public LocationCallback mLocationCallback;
//    public LocationRequest mLocationRequest;
//    private LocationSettingsRequest mLocationSettingsRequest;
//    private SupportMapFragment mMapView;
    private RelativeLayout mRel_folder;
    private MySquareImageView mivGalleryCamera;
    //    private ImageView mRel_gps;
    private ImageView ivGrid;
    private ImageView ivCloseCamera;
    private ImageView ivSetting;

    public int mScreenH;
    private int mScreenW;
    private Sensor mSensorAccelerometer;
    private SensorManager mSensorManager;
    private LinearLayout mTopScreenPannel;
    private TextView mTvMirror;
    private ImageView img_mirror;
    private float mWaterDensity = 1.0f;
    private MagneticSensor magneticSensor;
    public MainUI mainUI;
    private ManualSeekbars manualSeekbars;
    Bitmap mapBitmap;
//    private Marker marker = null;

//    private LinearLayout moLi_Settings;
//    private ImageView imgSettingBG;
    public RelativeLayout moMainLayout;
    OnBackPressedListener onBackPressedListener;
    private OrientationEventListener orientationEventListener;
    private List<Integer> other_camera_ids;
    private PermissionHandler permissionHandler;
    public Preview preview;
    String[] ratio;
    LinearLayout ratio_linear;
    //    RelativeLayout relAdsLay;
    private boolean saf_dialog_from_preferences;
    private SaveLocationHistory save_location_history;
    private SaveLocationHistory save_location_history_saf;
    private boolean screen_is_locked;
    private SettingsManager settingsManager;
    private SoundPoolManager soundPoolManager;
    private SpeechControl speechControl;
    String str_compass;
    String str_magnaticField;
    private boolean supports_auto_stabilise;
    private boolean supports_camera2;
    private boolean supports_force_video_4k;
    ImageView switchCameraButton;
    public volatile float test_angle;
    public volatile boolean test_have_angle;
    public volatile String test_last_saved_image;
    public volatile Uri test_last_saved_imageuri;
    public volatile boolean test_low_memory;
    public volatile String test_save_settings_file;
    private TextFormatter textFormatter;
    public TextToSpeech textToSpeech;
    public boolean textToSpeechSuccess;
//    private LocationViewModel locationViewModel;
    private int current_orientation = 0;

//    ConstraintLayout clCustomStamp;
    ConstraintLayout clCameraPreview;
    FrameLayout mFramePreview;
//    OnDragTouchListener customStampOnDragTouchListener = null;

//    RotateLayout rotateLayoutCameraStamp1;

//    TextView tvStamp1Date = null;
//    TextView tvStamp1Address = null;

//    ImageView ivCameraStampInfo = null;

//    private CameraStampDatabase mDb;
//    private CameraStamp cameraStamp;
//    String state;

    @NotNull
    @Override
    public Activity getContext() {
        return CameraActivity.this;
    }

    @Override
    public void initData() {

    }

    @Override
    public void initActions() {

    }

    @Override
    public void onNetworkConnectionChanged(boolean isConnected) {
        if (!isConnected) {
            UtilsKt.dismissProgress();
        }
    }


    public interface OnBackPressedListener {
        void onBackPressed();
    }

    private void cancelImageSavingNotification() {
    }

    public void changeExposure(int i) {
    }

    public void changeFocusDistance(int i, boolean z) {
    }

    public void changeISO(int i) {
    }

    public void clickedFaceDetection(View view) {
    }

    public void clickedSwitchVideo(View view) {
    }

    public int getNavigationGap() {
        return 0;
    }

    boolean isFromOneSignal = false;

    public void onCreate(Bundle bundle) {
        int i;
        super.onCreate(bundle);

        setContentView((int) R.layout.activity_main_camera_temp);
        WindowManager.LayoutParams attributes = getWindow().getAttributes();
        attributes.rotationAnimation = 1;
        getWindow().setAttributes(attributes);
        rxPermissions = new RxPermissions(this);
        if (!(getIntent() == null || getIntent().getExtras() == null)) {
            this.is_test = getIntent().getExtras().getBoolean("test_project");
            Log.d(TAG, "is_test: " + this.is_test);
        }
        if (getIntent() != null) {
            getIntent().getExtras();
        }
        if (getIntent().hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = getIntent().getBooleanExtra("IsCheckOneSignalNotification", false);
        }
        if (!(getIntent() == null || getIntent().getAction() == null)) {
            Log.d(TAG, "shortcut: " + getIntent().getAction());
        }
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        Log.d(TAG, "standard max memory = " + activityManager.getMemoryClass() + "MB");
        Log.d(TAG, "large max memory = " + activityManager.getLargeMemoryClass() + "MB");
        int largeMemoryClass = activityManager.getLargeMemoryClass();
        this.large_heap_memory = largeMemoryClass;
        if (largeMemoryClass >= 128) {
            this.supports_auto_stabilise = true;
        }
        Log.d(TAG, "supports_auto_stabilise? " + this.supports_auto_stabilise);
        if (activityManager.getMemoryClass() >= 128 || activityManager.getLargeMemoryClass() >= 512) {
            this.supports_force_video_4k = true;
        }
        Log.d(TAG, "supports_force_video_4k? " + this.supports_force_video_4k);
        this.applicationInterface = new MyApplicationInterface(this, bundle);
        init();
        initCamera2Support();
        setWindowFlagsForCamera();
        this.save_location_history = new SaveLocationHistory(this, "save_location_history", getStorageUtils().getSaveLocation());
        checkSaveLocations();
        if (this.applicationInterface.getStorageUtils().isUsingSAF()) {
            Log.d(TAG, "create new SaveLocationHistory for SAF");
            this.save_location_history_saf = new SaveLocationHistory(this, "save_location_history_saf", getStorageUtils().getSaveLocationSAF());
        }
        SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        this.mSensorManager = sensorManager;
        if (sensorManager.getDefaultSensor(1) != null) {
            Log.d(TAG, "found accelerometer");
            this.mSensorAccelerometer = this.mSensorManager.getDefaultSensor(1);
        } else {
            Log.d(TAG, "no support for accelerometer");
        }
        this.magneticSensor.initSensor(mSensorManager);
        preview = new Preview(applicationInterface, findViewById(R.id.preview));
        int numberOfCameras = preview.getCameraControllerManager().getNumberOfCameras();
        if (numberOfCameras > 2) {
            this.back_camera_ids = new ArrayList();
            this.front_camera_ids = new ArrayList();
            this.other_camera_ids = new ArrayList();

            for (int i2 = 0; i2 < numberOfCameras; i2++) {
                switch (preview.getCameraControllerManager().getFacing(i2)) {
                    case FACING_BACK:
                        back_camera_ids.add(i2);
                        break;
                    case FACING_FRONT:
                        front_camera_ids.add(i2);
                        break;
                    default:
                        other_camera_ids.add(i2);
                        break;
                }
            }

            boolean z = this.back_camera_ids.size() >= 2 || this.front_camera_ids.size() >= 2 || this.other_camera_ids.size() >= 2;
            int i4 = this.back_camera_ids.size() > 0 ? 1 : 0;
            if (this.front_camera_ids.size() > 0) {
                i4++;
            }
            if (this.other_camera_ids.size() > 0) {
                i4++;
            }
            this.is_multi_cam = z && i4 >= 2;

            Log.d(TAG, "multi_same_facing: " + z);
            Log.d(TAG, "n_facing: " + i4);
            Log.d(TAG, "is_multi_cam: " + this.is_multi_cam);

            if (!this.is_multi_cam) {
                this.back_camera_ids = null;
                this.front_camera_ids = null;
                this.other_camera_ids = null;
            }

        }


        this.ivSwitchCamera.setVisibility(this.preview.getCameraControllerManager().getNumberOfCameras() > 1 ? View.VISIBLE : View.INVISIBLE);
        findViewById(R.id.zoom).setVisibility(View.GONE);
        this.mainUI.updateOnScreenIcons();

        getWindow().getDecorView().setOnSystemUiVisibilityChangeListener(i12 -> {
            if (CameraActivity.this.usingKitKatImmersiveMode()) {
                Log.d(CameraActivity.TAG, "onSystemUiVisibilityChange: " + i12);
                if ((i12 & 4) == 0) {
                    Log.d(CameraActivity.TAG, "system bars now visible");
                    CameraActivity.this.setImmersiveTimer();
                    return;
                }
                Log.d(CameraActivity.TAG, "system bars now NOT visible");
            }
        });
        boolean contains = defaultSharedPreferences.contains(PreferenceKeys.FirstTimePreferenceKey);
        Log.d(TAG, "has_done_first_time: " + contains);
        if (!contains) {
            setDeviceDefaults();
        }
        try {
            i = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            Log.d(TAG, "NameNotFoundException exception trying to get version number");
            e.printStackTrace();
            i = -1;
        }
        if (i != -1) {
            int i5 = defaultSharedPreferences.getInt(PreferenceKeys.LatestVersionPreferenceKey, 0);
            Log.d(TAG, "version_code: " + i);
            Log.d(TAG, "latest_version: " + i5);
            int min = Math.min(74, i);
            Log.d(TAG, "whats_new_version: " + min);
            boolean z2 = defaultSharedPreferences.getBoolean(PreferenceKeys.ShowWhatsNewPreferenceKey, true);
            Log.d(TAG, "allow_show_whats_new: " + z2);
            SharedPreferences.Editor edit = defaultSharedPreferences.edit();
            edit.putInt(PreferenceKeys.LatestVersionPreferenceKey, i);
            edit.apply();
        }
        setModeFromIntents(bundle);
        this.textToSpeechSuccess = false;
        new Thread(() -> {
            CameraActivity.this.textToSpeech = new TextToSpeech(CameraActivity.this, i1 -> {
                Log.d(CameraActivity.TAG, "TextToSpeech initialised");
                if (i1 == 0) {
                    boolean unused1 = CameraActivity.this.textToSpeechSuccess = true;
                    Log.d(CameraActivity.TAG, "TextToSpeech succeeded");
                    return;
                }
                Log.d(CameraActivity.TAG, "TextToSpeech failed");
            });
        }).start();

//        locationViewModel = new ViewModelProvider(this).get(LocationViewModel.class);
//        mDb = CameraStampDatabase.getInstance(CameraActivity.this);
        setUpStampDB();

        createSaveFolder();
        setTimer();
        setMirror();
        loadAds();
        Display defaultDisplay = getWindowManager().getDefaultDisplay();
        Point point = new Point();
        defaultDisplay.getSize(point);
        this.mScreenH = point.y;
        this.mScreenW = point.x;


        setLayout();
//        if (SharedPrefs.getBoolean(CameraActivity.this, SharedPrefs.IS_ENABLE_STAMP, true)) {
//            clCustomStamp.setVisibility(View.VISIBLE);
//        } else {
//            clCustomStamp.setVisibility(View.GONE);
//        }

        mFramePreview = findViewById(R.id.preview);

//        if (getIntent().hasExtra("openShortcutCamera")) {
//            ivSetting.setAlpha(0.5F);
//            ivSetting.setEnabled(false);
//        } else {
//            ivSetting.setEnabled(true);
//        }


//        setMapType();
        dFormat = new DecimalFormat("#.######");
//        initLocation();

//        initmap();
        setDragTouchListener();
    }

    private void setUpStampDB() {
//        List<CameraStamp> stampList = mDb.cameraStampDao().loadListAllStamp();
//        if (stampList.size() <= 0) {
//            cameraStamp = new CameraStamp(
//                    null,
//                    57,
//                    "",
//                    "",
//                    ConstantsKt.DEFAULT_DATE_FORMAT,
//                    90F,
//                    0);
//            mDb.cameraStampDao().insertStamp(cameraStamp);
//            SharedPrefs.save(mContext, ConstantsKt.STAMP_ID, 57);
//        } else {
//            int id = SharedPrefs.getInt(mContext, ConstantsKt.STAMP_ID, 57);
//            cameraStamp = mDb.cameraStampDao().loadStampByIdWithoutLiveData(id);
//        }
    }

    private void setDragTouchListener() {
//        customStampOnDragTouchListener = new OnDragTouchListener(clCustomStamp, preview.getView(), new OnDragTouchListener.OnDragActionListener() {
//            @Override
//            public void onDragStart(View view) {
//
//            }
//
//            @Override
//            public void onDragEnd(View view) {
//
//            }
//
//            @Override
//            public void onViewClick(View view, int x, int y) {
//                launchActivityForResult(new Intent(CameraActivity.this, EditStampActivity.class), ConstantsKt.REQUEST_CODE_EDIT_UPDATE_STAMP, android.R.anim.fade_in, android.R.anim.fade_out);
//            }
//        });
//        clCustomStamp.setOnTouchListener(customStampOnDragTouchListener);
    }

    private void setLayout() {
        int id = SharedPrefs.getInt(mContext, ConstantsKt.STAMP_ID, 57);
//        cameraStamp = mDb.cameraStampDao().loadStampByIdWithoutLiveData(id);

//        clCustomStamp = findViewById(R.id.clCustomStamp);
        clCameraPreview = findViewById(R.id.clCameraPreview);
//        rotateLayoutCameraStamp1 = findViewById(R.id.rotateLayoutCameraStamp1);
//        ivCameraStampInfo = findViewById(R.id.ivCameraStampInfo);
//        ivCameraStampInfo.setOnClickListener(this);

//        if (SharedPrefs.getBoolean(this, SharedPrefs.IS_STAMP_INFO_SHOW, false)) {
//            ivCameraStampInfo.setVisibility(View.GONE);
//        } else {
//            ivCameraStampInfo.setVisibility(View.VISIBLE);
//        }

        View viewa = null;

//        if (cameraStamp != null && !cameraStamp.getStampPath().equals("")) {
//            try {
//                rotateLayoutCameraStamp1.removeAllViews();
//                InputStream inputStream;
//                inputStream = getContentResolver().openInputStream(Uri.fromFile(new File(cameraStamp.getStampPath() + "/testlayout.xml")));
//                DynamicLayoutInflator.pathhh = cameraStamp.getStampPath();
//                viewa = DynamicLayoutInflator.inflate(this, inputStream, rotateLayoutCameraStamp1);
//                DynamicLayoutInflator.setDelegate(viewa, this);
//
//            } catch (FileNotFoundException e) {
//            }
//
//        } else {
//
//            rotateLayoutCameraStamp1.removeAllViews();
//            try {
//                viewa = DynamicLayoutInflator.inflate(this, getAssets().open("testlayout.xml"), rotateLayoutCameraStamp1);
//                DynamicLayoutInflator.setDelegate(viewa, this);
//            } catch (IOException e) {
//            }
//
//        }

//        tvStamp1Date = viewa.findViewById(DynamicLayoutInflator.idNumFromIdString(viewa, "tvStamp1Date"));
//        tvStamp1Address = viewa.findViewById(DynamicLayoutInflator.idNumFromIdString(viewa, "tvStamp1Address"));

//        if (cameraStamp.getFontColor() == 0) {
//            cameraStamp.setFontColor(Integer.valueOf(Color.parseColor("#ffffff")));
//        }

//        ViewGroup lViewGroup = ((ViewGroup) rotateLayoutCameraStamp1.getChildAt(0));
//        if (lViewGroup.getChildCount() != 0) {
//            for (int i = 0; i < lViewGroup.getChildCount(); i++) {
//                if (lViewGroup.getChildAt(i) instanceof TextView) {
//                    ((TextView) lViewGroup.getChildAt(i)).setTextColor(cameraStamp.getFontColor());
//                }
//            }
//        }
//        clCustomStamp.setAlpha((cameraStamp.getTransparency() / 100));
    }

    private void setMirror() {
        if (SharedPrefs.getString(this, PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no").equals("preference_front_camera_mirror_photo")) {
//            this.mTvMirror.setText(getString(R.string.yes));
            img_mirror.setColorFilter(getResources().getColor(R.color.colorPrimary));
        } else {
//            this.mTvMirror.setText(getString(R.string.no));
            img_mirror.setColorFilter(getResources().getColor(R.color.white));
        }
    }

//    private void initmap() {
//        SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapView);
//        mMapView = supportMapFragment;
//        if (supportMapFragment != null) {
//            supportMapFragment.getMapAsync(this);
//        }
//        address_line_1 = SharedPrefs.getString(this, SharedPrefs.LOC_LINE_1_ADDRESS, "").trim();
//        city = SharedPrefs.getString(this, SharedPrefs.LOC_LINE_2_CITY, "").trim();
//        state = SharedPrefs.getString(this, SharedPrefs.LOC_LINE_3_STATE, "").trim();
//        country = SharedPrefs.getString(this, SharedPrefs.LOC_LINE_4_COUNTRY, "").trim();
//    }

//    public void doWorkWithNewLocation(Location location) {
//
//        if (cameraStamp.getLocationType() != null && !cameraStamp.getLocationType().isEmpty() && cameraStamp.getLocationType().equals(ConstantsKt.AUTOMATIC)) {
//
//            double latitude = location.getLatitude();
//
//            double longitude = location.getLongitude();
//
//            try {
//
//                List<Address> fromLocation = new Geocoder(this, Locale.getDefault()).getFromLocation(latitude, longitude, 1);
//
//                if (fromLocation != null && !fromLocation.isEmpty()) {
//
//                    String addressLine = fromLocation.get(0).getAddressLine(0);
//                    String locality = fromLocation.get(0).getLocality();
//                    String adminArea = fromLocation.get(0).getAdminArea();
//                    String countryName = fromLocation.get(0).getCountryName();
//                    if (latitude != 0d) {
//
//                        String format = this.dFormat.format(latitude);
//                        if (format.contains(",")) {
//                            format = format.replace(",", ".");
//                        }
//                        SharedPrefs.save(this, SharedPrefs.LATITUDE, format);
//
//                    }
//
//                    if (longitude != 0d) {
//
//                        String format2 = this.dFormat.format(longitude);
//                        if (format2.contains(",")) {
//                            format2 = format2.replace(",", ".");
//                        }
//                        SharedPrefs.save(this, SharedPrefs.LONGITUDE, format2);
//
//                    }
//
//                    if (addressLine != null) {
//                        this.address_line_1 = addressLine;
//                        SharedPrefs.save(this, SharedPrefs.LOC_LINE_1_ADDRESS, addressLine);
//                    }
//
//                    if (locality != null) {
//                        this.city = locality;
//                        SharedPrefs.save(this, SharedPrefs.LOC_LINE_2_CITY, locality);
//                    }
//
//                    if (adminArea != null) {
//
//                        this.state = adminArea;
//                        SharedPrefs.save(this, SharedPrefs.LOC_LINE_3_STATE, adminArea);
//
//                    }
//
//                    if (countryName != null) {
//                        this.country = countryName;
//                        SharedPrefs.save(this, SharedPrefs.LOC_LINE_4_COUNTRY, countryName);
//                    }
//
//                    loadMap();
//
//                }
//
//            } catch (Exception e) {
//
//                e.printStackTrace();
//
//            }
//
//        }
//    }

    private void loadAds() {
        RelativeLayout relativeLayout = findViewById(R.id.rel_adaptive_banner);
        this.banner_native_layout = relativeLayout;
    }

    public Bitmap getMapBitmap() {
        return this.mapBitmap;
    }

    public String getCompassStr() {
        return SharedPrefs.getString(this, SharedPrefs.COMPASS_VALUE, this.str_compass);
    }

    public String getMagnaticFieldStr() {
        return SharedPrefs.getString(this, SharedPrefs.MAGNETIC_FIELD_VALUE, this.str_magnaticField);
    }

    public void onClick(View view) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return;
        }
        mLastClickTime = SystemClock.elapsedRealtime();
        switch (view.getId()) {
            case R.id.ivCloseCamera:
                onBackPressed();
                return;
            case R.id.ivGrid:
                setUpFlash();
                showGridBottomSheet();
                closePopup();
//                launchActivityForResult(new Intent(this, StampCameraTemplateActivity.class), ConstantsKt.REQUEST_CODE_OPEN_UPDATE_STAMP, android.R.anim.fade_in, android.R.anim.fade_out);
                return;
            case R.id.ivSetting:

//                startActivity(new Intent(this, CameraShortcutActivity.class));
//                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

                return;
            case R.id.liMultiCamera:
                clickedSwitchMultiCamera(view);
                return;
            case R.id.li_app_setting:
                setUpFlash();
                closePopup();
                return;
//            case R.id.ivCameraSetting:
//                if (moLi_Settings.getVisibility() == View.VISIBLE) {
//                    closePopup();
//                    return;
//                } else if (moLi_Settings.getVisibility() == View.GONE) {
//                    moLi_Settings.setVisibility(View.VISIBLE);
//                    imgSettingBG.setVisibility(View.VISIBLE);
//                    mImg_camera_settings.setColorFilter(getResources().getColor(R.color.colorPrimary));
//                    return;
//                } else {
//                    return;
//                }
            case R.id.img_flash:
                preview.cycleFlash(true, true);
                mainUI.updateCycleFlashIcon();
                return;
            case R.id.li_focus:
                MyApplicationInterface myApplicationInterface = this.applicationInterface;
                String focusPref = myApplicationInterface != null ? myApplicationInterface.getFocusPref(false) : "";
                if (this.preview == null) {
                    return;
                }
                if (focusPref.equals("focus_mode_auto")) {
                    mImg_focus.setImageResource(R.drawable.ic_camera_focus);
                    preview.updateFocus("focus_mode_continuous_picture", false, true);
                    return;
                }
                mImg_focus.setImageResource(R.drawable.ic_camera_focus_auto);
                preview.updateFocus("focus_mode_auto", false, true);
                return;
            case R.id.li_grid:
                setUpFlash();
                showGridBottomSheet();
                closePopup();
                return;
            case R.id.li_mirror:
                if (SharedPrefs.getString(this, PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no").equals("preference_front_camera_mirror_photo")) {
                    SharedPrefs.save(this, PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no");
//                    mTvMirror.setText(getString(R.string.no));
                    img_mirror.setColorFilter(getResources().getColor(R.color.white));
                    return;
                }
                SharedPrefs.save(this, PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_photo");
//                mTvMirror.setText(getString(R.string.yes));
                img_mirror.setColorFilter(getResources().getColor(R.color.colorPrimary));
                return;
            case R.id.li_ratio:
                setUpFlash();
                closePopup();
                callFragment(new RatioFragment(this), "RatioFragment");
                return;
            case R.id.ivSwitchCamera:
                setUpFlash();
                Log.d(TAG, "clickedSwitchCamera");
                if (this.preview.isOpeningCamera()) {
                    Log.d(TAG, "already opening camera in background thread");
                    return;
                } else if (this.preview.canSwitchCamera()) {


                    userSwitchToCamera(getNextCameraId());
                    if (preview.getCameraControllerManager().getFacing(getActualCameraId()) == CameraController.Facing.FACING_BACK) {
                        mLi_focus.setVisibility(View.GONE);
                    } else {
                        mLi_focus.setVisibility(View.VISIBLE);
                    }
                    return;
                } else {
                    return;
                }
            case R.id.liTimer:
                String string = SharedPrefs.getString(this, PreferenceKeys.TimerPreferenceKey, "0");
                if (string.equals("0")) {
                    SharedPrefs.save(this, PreferenceKeys.TimerPreferenceKey, ExifInterface.GPS_MEASUREMENT_3D);
                    img_timer.setImageResource(R.drawable.ic_camera_timer3);
                    return;
                } else if (string.equals(ExifInterface.GPS_MEASUREMENT_3D)) {
                    img_timer.setImageResource(R.drawable.ic_camera_timer5);
                    SharedPrefs.save(this, PreferenceKeys.TimerPreferenceKey, "5");
                    return;
                } else if (string.equals("5")) {
                    img_timer.setImageResource(R.drawable.ic_camera_timer_off);
                    SharedPrefs.save(this, PreferenceKeys.TimerPreferenceKey, "0");
                    return;
                } else {
                    return;
                }
            case R.id.ivGalleryCamera:
                openGallery_();
                closePopup();
                return;
//            case R.id.ivMapMode:
//                closePopup();
//                return;
            case R.id.take_photo:
//                addEvent(this, ConstantsKt.getTakePhoto());
                takePicture(false);
                closePopup();
                return;
//            case R.id.ivCameraStampInfo:
//                ivCameraStampInfo.setVisibility(View.GONE);
//                SharedPrefs.savePref(this, SharedPrefs.IS_STAMP_INFO_SHOW, true);
//                Intent intent = new Intent(this, StampWidgetActivity.class);
//                startActivity(intent);
//                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
//                return;
            default:
                return;
        }
    }

    private void showGridBottomSheet() {
        new CameraGridDialog(this, new Function0<Unit>() {
            @Override
            public Unit invoke() {
                onResume();
                return null;
            }
        });
    }

    public class SingleMediaScanner implements MediaScannerConnection.MediaScannerConnectionClient {

        private MediaScannerConnection mMs;
        private File mFile;

        public SingleMediaScanner(Context context, File f) {
            mFile = f;
            mMs = new MediaScannerConnection(context, this);
            mMs.connect();
        }

        public void onMediaScannerConnected() {
            mMs.scanFile(mFile.getAbsolutePath(), null);
        }

        public void onScanCompleted(String path, Uri uri) {
            if (mFile != null) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(uri);
                launchActivityForResult(intent, REQUEST_CODE_OPEN_GALLERY, android.R.anim.fade_in, android.R.anim.fade_out);
                mMs.disconnect();
            }
        }

    }

    public void callFragment(Fragment fragment, String str) {
        FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
        beginTransaction.replace(R.id.camera_layout, fragment, str);
        beginTransaction.addToBackStack(str);
        beginTransaction.commit();
    }


    private void setTimer() {
        String string = SharedPrefs.getString(this, PreferenceKeys.TimerPreferenceKey, "0");

        if (string.equals("0")) {
            this.img_timer.setImageResource(R.drawable.ic_camera_timer_off);
        } else if (string.equals(ExifInterface.GPS_MEASUREMENT_3D)) {
            this.img_timer.setImageResource(R.drawable.ic_camera_timer3);
        } else if (string.equals("5")) {
            this.img_timer.setImageResource(R.drawable.ic_camera_timer5);
        }

    }

    public void createSaveFolder() {
        File file = new File(UtilsKt.cameraPicPathNew);

        if (!file.exists()) {
            file.mkdir();
        }

    }

    public void setUpFlash() {
        if (preview == null) {
            return;
        }
        if (applicationInterface.getFlashPref().equals("flash_torch") || applicationInterface.getFlashPref().equals("flash_frontscreen_torch")) {
            preview.updateFlash("flash_off");
            mainUI.updateCycleFlashIcon();
        }
    }

    public void closePopup() {
//        if (this.moLi_Settings.getVisibility() == View.VISIBLE) {
//            this.moLi_Settings.setVisibility(View.GONE);
//            this.imgSettingBG.setVisibility(View.GONE);
//            this.mImg_camera_settings.setColorFilter(-1);
//        }
    }

    public void hideUi() {
        if (this.mTopScreenPannel.getVisibility() == View.VISIBLE) {
            this.mTopScreenPannel.setVisibility(View.INVISIBLE);
        }
        if (this.mBottomScreenPannel.getVisibility() == View.VISIBLE) {
            this.mBottomScreenPannel.setVisibility(View.INVISIBLE);
        }
    }

    public void showUI() {
        if (this.mTopScreenPannel.getVisibility() == View.INVISIBLE) {
            this.mTopScreenPannel.setVisibility(View.VISIBLE);
        }
        if (this.mBottomScreenPannel.getVisibility() == View.INVISIBLE) {
            this.mBottomScreenPannel.setVisibility(View.VISIBLE);
        }
    }

    public void updateGrid() {
        this.applicationInterface.getDrawPreview().updateSettings();
    }

    private void init() {
        bluetoothRemoteControl = new BluetoothRemoteControl(this);
        permissionHandler = new PermissionHandler(this);
        settingsManager = new SettingsManager(this);
        mainUI = new MainUI(this);
        manualSeekbars = new ManualSeekbars();
        textFormatter = new TextFormatter(this);
        soundPoolManager = new SoundPoolManager(this);
        magneticSensor = new MagneticSensor(this);
        speechControl = new SpeechControl(this);
        switchCameraButton = (ImageView) findViewById(R.id.switch_camera);
        ivSwitchCamera = (ImageView) findViewById(R.id.ivSwitchCamera);
        li_Multi_Camera = (LinearLayout) findViewById(R.id.liMultiCamera);
        img_timer = (ImageView) findViewById(R.id.ivTimer);
        liTimer = (LinearLayout) findViewById(R.id.liTimer);
        li_timer = (LinearLayout) findViewById(R.id.li_timer);
        img_tamplate = (ImageView) findViewById(R.id.img_tamplate);

//        moLi_Settings = (LinearLayout) findViewById(R.id.li_settings);
//        imgSettingBG = findViewById(R.id.imgSettingBG);
        mImg_flash = (ImageView) findViewById(R.id.img_flash);
        moMainLayout = (RelativeLayout) findViewById(R.id.camera_layout);
        ratio_linear = (LinearLayout) findViewById(R.id.li_ratio);
        mImg_camera_settings = (ImageView) findViewById(R.id.ivCameraSetting);
        mTopScreenPannel = (LinearLayout) findViewById(R.id.topscreenpannel);
        mBottomScreenPannel = (RelativeLayout) findViewById(R.id.bottomscreenpannel);
        mImg_focus = (ImageView) findViewById(R.id.img_focus);

        mLi_app_setting = (LinearLayout) findViewById(R.id.li_app_setting);
        mLi_grid = (LinearLayout) findViewById(R.id.li_grid);

        mLi_ratio = (LinearLayout) findViewById(R.id.li_ratio);
        mLi_focus = (LinearLayout) findViewById(R.id.li_focus);
        mLi_camera_setting = (LinearLayout) findViewById(R.id.li_camera_setting);
//        mRel_gps = (ImageView) findViewById(R.id.ivMapMode);
        mLi_filename = (LinearLayout) findViewById(R.id.li_filename);
        mRel_folder = (RelativeLayout) findViewById(R.id.rel_folder);
        mImgTakePhoto = (ImageView) findViewById(R.id.take_photo);
        mLi_mirror = (LinearLayout) findViewById(R.id.li_mirror);
//        relAdsLay = (RelativeLayout) findViewById(R.id.rel_adaptive_banner);
        ivGrid = (ImageView) findViewById(R.id.ivGrid);
        ivCloseCamera = (ImageView) findViewById(R.id.ivCloseCamera);
        ivSetting = (ImageView) findViewById(R.id.ivSetting);
        mivGalleryCamera = (MySquareImageView) findViewById(R.id.ivGalleryCamera);
        mTvMirror = (TextView) findViewById(R.id.tvMirror);
        img_mirror = (ImageView) findViewById(R.id.img_mirror);
        cameraPreviewLayout = (FrameLayout) findViewById(R.id.preview);

        onCliks();
    }

    private void onCliks() {
        mLi_app_setting.setOnClickListener(this);
        mLi_ratio.setOnClickListener(this);
        mLi_grid.setOnClickListener(this);
        mImg_flash.setOnClickListener(this);
        mLi_focus.setOnClickListener(this);
        ivGrid.setOnClickListener(this);
        ivCloseCamera.setOnClickListener(this);
        ivSetting.setOnClickListener(this);
        mImgTakePhoto.setOnClickListener(this);
        mLi_camera_setting.setOnClickListener(this);
        mImg_camera_settings.setOnClickListener(this);
//        mRel_gps.setOnClickListener(this);
        mLi_filename.setOnClickListener(this);
        mRel_folder.setOnClickListener(this);
        li_timer.setOnClickListener(this);
        liTimer.setOnClickListener(this);
        ivSwitchCamera.setOnClickListener(this);
        li_Multi_Camera.setOnClickListener(this);
        mivGalleryCamera.setOnClickListener(this);
        mLi_mirror.setOnClickListener(this);
    }

    private void updateStampAngle(int angle) {
//        rotateLayoutCameraStamp1.setAngle(angle);
        updateStampLayoutXY();
    }

    private void updateStampLayoutXY() {
//        if (clCustomStamp != null) {
//            clCustomStamp.post(() -> {
//                clCustomStamp.setX(0);
//                clCustomStamp.setY(200);
//                setDragTouchListener();
//            });
//        }
    }

    private void updateStampLayoutsAddressValue(String setAddress) {
//        if (setAddress.isEmpty()) {
//            tvStamp1Address.setText(getResources().getString(R.string.unable_to_find_location));
//        } else {
//            tvStamp1Address.setText(setAddress);
//        }
    }


    private void updateStampLayoutsDateTimeValue(String setDateTime) {
//        tvStamp1Date.setText(setDateTime);
    }

    private void updateStampLayoutsQuoteValue(String setDateTime) {
//        tvStamp1Address.setText(setDateTime);
    }

//    private void setMapType() {
//        if (this.mGMap != null) {
//            String string = SharedPrefs.getString(this, SharedPrefs.MAP_TYPE_TEMPLATE, ConstantsKt.NORMAL_1);
//            string.hashCode();
//            char c = 65535;
//            switch (string.hashCode()) {
//                case -1579103941:
//                    if (string.equals(ConstantsKt.SETELLITE_2)) {
//                        c = 0;
//                        break;
//                    }
//                    break;
//                case -1423437003:
//                    if (string.equals(ConstantsKt.TERRAIN_3)) {
//                        c = 1;
//                        break;
//                    }
//                    break;
//                case -1202757124:
//                    if (string.equals(ConstantsKt.HYBRID_4)) {
//                        c = 2;
//                        break;
//                    }
//                    break;
//                case 1366708796:
//                    if (string.equals(ConstantsKt.NORMAL_1)) {
//                        c = 3;
//                        break;
//                    }
//                    break;
//            }
//            switch (c) {
//                case 0:
//                    this.mGMap.setMapType(2);
//                    return;
//                case 1:
//                    this.mGMap.setMapType(3);
//                    return;
//                case 2:
//                    this.mGMap.setMapType(4);
//                    return;
//                case 3:
//                    this.mGMap.setMapType(1);
//                    return;
//                default:
//                    return;
//            }
//        }
//    }


    public int getRatioW(int i, int i2) {
        return (i2 * this.mScreenH) / i;
    }

    public int getRatioH(int i, int i2) {
        return (i * this.mScreenW) / i2;
    }

    public String getColoredSpanned(String str, int i) {
        return "<font color=" + i + ">" + str + "</font>";
    }

//    public void loadMap() {
//        double d;
//        double d2;
//        String string = SharedPrefs.getString(this, SharedPrefs.LATITUDE, "");
//        String string2 = SharedPrefs.getString(this, SharedPrefs.LONGITUDE, "");
//        if (string == null || string2 == null || string.isEmpty() || string2.isEmpty() || !ConstantsKt.isNumberFormat(string) || !ConstantsKt.isNumberFormat(string2)) {
//            d2 = 0.0d;
//            d = 0.0d;
//        } else {
//            if (string.contains(",")) {
//                string = string.replace(",", ".");
//            }
//            if (string2.contains(",")) {
//                string2 = string2.replace(",", ".");
//            }
//            d = Double.valueOf(string).doubleValue();
//            d2 = Double.valueOf(string2).doubleValue();
//        }
//        if (this.mGMap != null && d != 0d && d2 != 0d) {
//            LatLng latLng = new LatLng(d, d2);
//            this.mGMap.clear();
//            Marker marker2 = null;
//            this.marker = marker2;
//            if (marker2 == null) {
//                this.marker = this.mGMap.addMarker(new MarkerOptions().position(latLng).title(""));
//            } else {
//                marker2.setPosition(latLng);
//            }
//            this.mGMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
//            this.mGMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15.0f));
//        }
//    }

//    private void mapSnapshot() {
//        try {
//            System.gc();
//            if (this.mGMap != null && GeneralUtilsKt.isOnline(this)) {
//                this.mGMap.snapshot(new GoogleMap.SnapshotReadyCallback() {
//                    public void onSnapshotReady(Bitmap bitmap) {
//                        if (bitmap != null) {
//                            CameraActivity.this.mapBitmap = bitmap;
//                        }
//                    }
//                });
//            }
//        } catch (OutOfMemoryError e) {
//            e.printStackTrace();
//        }
//    }

    public int getIconCode(String str) {
        str.equalsIgnoreCase("01d");
        int equalsIgnoreCase = 1;

        if (str.equalsIgnoreCase("03d")) {
            equalsIgnoreCase = 2;
        }
        if (str.equalsIgnoreCase("04d")) {
            equalsIgnoreCase = 3;
        }
        if (str.equalsIgnoreCase("09d")) {
            equalsIgnoreCase = 4;
        }
        if (str.equalsIgnoreCase("10d")) {
            equalsIgnoreCase = 5;
        }
        if (str.equalsIgnoreCase("11d")) {
            equalsIgnoreCase = 6;
        }
        if (str.equalsIgnoreCase("13d")) {
            equalsIgnoreCase = 7;
        }
        if (str.equalsIgnoreCase("50d")) {
            equalsIgnoreCase = 8;
        }
        if (str.equalsIgnoreCase("01n")) {
            equalsIgnoreCase = 9;
        }
        if (str.equalsIgnoreCase("02n")) {
            equalsIgnoreCase = 10;
        }
        if (str.equalsIgnoreCase("03n")) {
            equalsIgnoreCase = 11;
        }
        if (str.equalsIgnoreCase("04n")) {
            equalsIgnoreCase = 12;
        }
        if (str.equalsIgnoreCase("09n")) {
            equalsIgnoreCase = 13;
        }
        if (str.equalsIgnoreCase("10n")) {
            equalsIgnoreCase = 14;
        }
        if (str.equalsIgnoreCase("11n")) {
            equalsIgnoreCase = 15;
        }
        if (str.equalsIgnoreCase("13n")) {
            equalsIgnoreCase = 16;
        }
        if (str.equalsIgnoreCase("50n")) {
            equalsIgnoreCase = 17;
        }
        return equalsIgnoreCase;
    }


    public void setSdCardPermissionFlag(boolean z) {
        this.isSDCardPermission = z;
        this.isSDCardStorageEnabled = z;
        SharedPrefs.savePref(this, PreferenceKeys.UsingSAFPreferenceKey, Boolean.valueOf(this.isSDCardStorageEnabled));
        SharedPrefs.savePref(this, PreferenceKeys.IS_SDCARD_PERMISSION, Boolean.valueOf(this.isSDCardPermission));
    }

    public void setOnBackPressedListener(OnBackPressedListener onBackPressedListener2) {
        this.onBackPressedListener = onBackPressedListener2;
    }

    public boolean isMultiCamEnabled() {
        return this.is_multi_cam && PreferenceManager.getDefaultSharedPreferences(this).getBoolean(PreferenceKeys.MultiCamButtonPreferenceKey, true);
    }

    public int getNextCameraId() {
        if (MyDebug.LOG)
            Log.d(TAG, "getNextCameraId");
        int cameraId = getActualCameraId();
        if (MyDebug.LOG)
            Log.d(TAG, "current cameraId: " + cameraId);
        if (this.preview.canSwitchCamera()) {
            if (isMultiCamEnabled()) {
                switch (preview.getCameraControllerManager().getFacing(cameraId)) {
                    case FACING_BACK:
                        if (front_camera_ids.size() > 0) {
                            cameraId = front_camera_ids.get(0);
                        } else if (other_camera_ids.size() > 0) {
                            cameraId = other_camera_ids.get(0);
                        }
                        break;
                    case FACING_FRONT:
                        if (other_camera_ids.size() > 0)
                            cameraId = other_camera_ids.get(0);
                        else if (back_camera_ids.size() > 0)
                            cameraId = back_camera_ids.get(0);
                        break;
                    default:
                        if (back_camera_ids.size() > 0)
                            cameraId = back_camera_ids.get(0);
                        else if (front_camera_ids.size() > 0)
                            cameraId = front_camera_ids.get(0);
                        break;
                }
            } else {
                int n_cameras = preview.getCameraControllerManager().getNumberOfCameras();
                cameraId = (cameraId + 1) % n_cameras;
            }
        }
        if (MyDebug.LOG)
            Log.d(TAG, "next cameraId: " + cameraId);
        return cameraId;
    }

    private int getActualCameraId() {
        if (this.preview.getCameraController() == null) {
            return this.applicationInterface.getCameraIdPref();
        }
        return this.preview.getCameraId();
    }

    private void userSwitchToCamera(int i) {
        Log.d(TAG, "userSwitchToCamera: " + i);
        this.ivSwitchCamera = (ImageView) findViewById(R.id.ivSwitchCamera);
        this.li_Multi_Camera = (LinearLayout) findViewById(R.id.liMultiCamera);
        this.ivSwitchCamera.setEnabled(false);
        this.li_Multi_Camera.setEnabled(false);
        this.applicationInterface.reset(true);
        this.preview.setCamera(i);
        this.ivSwitchCamera.setEnabled(true);
        this.li_Multi_Camera.setEnabled(true);
    }

//    public void initLocation() {
//        Log.d(TAG, "initLocation");
//        SharedPrefs.savePref(this, SharedPrefs.IS_CALL_WEATHER_API, true);
//        this.fusedLocationClient = LocationServices.getFusedLocationProviderClient((Activity) this);
//        LocationRequest locationRequest = new LocationRequest();
//        this.mLocationRequest = locationRequest;
//        locationRequest.setInterval(UPDATE_INTERVAL_IN_MILLISECONDS);
//        this.mLocationRequest.setFastestInterval(FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS);
//        this.mLocationRequest.setMaxWaitTime(MAX_WAIT_TIME);
//        this.mLocationRequest.setPriority(100);
//        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
//        builder.addLocationRequest(this.mLocationRequest);
//        this.mLocationSettingsRequest = builder.build();
//        this.mLocationCallback = new LocationCallback() {
//            public void onLocationResult(LocationResult locationResult) {
//                super.onLocationResult(locationResult);
//                if (locationResult != null) {
//                    for (Location next : locationResult.getLocations()) {
//                        if (next != null) {
//                            CameraActivity.this.mLocation = next;
//                            CameraActivity.this.getLocationSupplier().setLocation(next);
//                            CameraActivity.this.doWorkWithNewLocation(next);
//                        }
//                    }
//                }
//            }
//        };
//        if (ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0 || ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
//            this.fusedLocationClient.getLastLocation().addOnSuccessListener((Activity) this, new OnSuccessListener<Location>() {
//                public void onSuccess(Location location) {
//                    if (location != null) {
//                        CameraActivity.this.mLocation = location;
//                        CameraActivity.this.getLocationSupplier().setLocation(location);
//                        CameraActivity.this.doWorkWithNewLocation(location);
//                    }
//                }
//            });
//        }
//    }

//    public void createLocationRequest() {
//        try {
//            if (this.isPermission == 0) {
//                SettingsClient settingsClient = LocationServices.getSettingsClient((Activity) this);
//                settingsClient.checkLocationSettings(this.mLocationSettingsRequest).addOnSuccessListener((Activity) this, new OnSuccessListener<LocationSettingsResponse>() {
//                    public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
//                        if (CameraActivity.this.fusedLocationClient != null) {
//                            if (ActivityCompat.checkSelfPermission(CameraActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(CameraActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//                                // TODO: Consider calling
//                                //    ActivityCompat#requestPermissions
//                                // here to request the missing permissions, and then overriding
//                                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//                                //                                          int[] grantResults)
//                                // to handle the case where the user grants the permission. See the documentation
//                                // for ActivityCompat#requestPermissions for more details.
//                                return;
//                            }
//                            CameraActivity.this.fusedLocationClient.requestLocationUpdates(CameraActivity.this.mLocationRequest, CameraActivity.this.mLocationCallback, Looper.myLooper());
//                        }
//                    }
//                }).addOnFailureListener((Activity) this, (OnFailureListener) new OnFailureListener() {
//                    public void onFailure(Exception exc) {
//                        int statusCode = ((ApiException) exc).getStatusCode();
//                        if (statusCode == 6) {
//
//                            if (isFirstTime) {
//                                isFirstTime = false;
//                                try {
//                                    ((ResolvableApiException) exc).startResolutionForResult(CameraActivity.this, 1);
//                                } catch (IntentSender.SendIntentException unused) {
//                                } catch (Exception unused) {
//                                }
//                            }
//                        } else if (statusCode == 8502) {
//                            Toast.makeText(CameraActivity.this, "Location settings are inadequate, and cannot be fixed here. Fix in Settings.", Toast.LENGTH_LONG).show();
//                        }
//                    }
//                });
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    public void setDeviceDefaults() {
        Log.d(TAG, "setDeviceDefaults");
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        boolean contains = Build.MANUFACTURER.toLowerCase(Locale.US).contains("samsung");
        boolean contains2 = Build.MANUFACTURER.toLowerCase(Locale.US).contains("oneplus");
        Log.d(TAG, "is_samsung? " + contains);
        Log.d(TAG, "is_oneplus? " + contains2);
        if (contains || contains2) {
            Log.d(TAG, "set fake flash for camera2");
            SharedPreferences.Editor edit = defaultSharedPreferences.edit();
            edit.putBoolean(PreferenceKeys.Camera2FakeFlashPreferenceKey, true);
            edit.apply();
        }
    }

    private void setModeFromIntents(Bundle savedInstanceState) {
        if (MyDebug.LOG)
            Log.d(TAG, "setModeFromIntents");
        if (savedInstanceState != null) {
            if (MyDebug.LOG)
                Log.d(TAG, "restoring from saved state");
            return;
        }
        boolean done_facing = false;
        String action = this.getIntent().getAction();
        if (MediaStore.INTENT_ACTION_VIDEO_CAMERA.equals(action) || MediaStore.ACTION_VIDEO_CAPTURE.equals(action)) {
            if (MyDebug.LOG)
                Log.d(TAG, "launching from video intent");
            applicationInterface.setVideoPref(true);
        } else if (MediaStore.ACTION_IMAGE_CAPTURE.equals(action) || MediaStore.ACTION_IMAGE_CAPTURE_SECURE.equals(action) || MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA.equals(action) || MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE.equals(action)) {
            if (MyDebug.LOG)
                Log.d(TAG, "launching from photo intent");
            applicationInterface.setVideoPref(false);
        } else if ((Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && MyTileService.TILE_ID.equals(action)) || ACTION_SHORTCUT_CAMERA.equals(action)) {
            if (MyDebug.LOG)
                Log.d(TAG, "launching from quick settings tile or application shortcut for Open Camera: photo mode");
            applicationInterface.setVideoPref(false);
        } else if ((Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && MyTileServiceVideo.TILE_ID.equals(action)) || ACTION_SHORTCUT_VIDEO.equals(action)) {
            if (MyDebug.LOG)
                Log.d(TAG, "launching from quick settings tile or application shortcut for Open Camera: video mode");
            applicationInterface.setVideoPref(true);
        } else if ((Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && MyTileServiceFrontCamera.TILE_ID.equals(action)) || ACTION_SHORTCUT_SELFIE.equals(action)) {
            if (MyDebug.LOG)
                Log.d(TAG, "launching from quick settings tile or application shortcut for Open Camera: selfie mode");
            done_facing = true;
            applicationInterface.switchToCamera(true);
        } else if (ACTION_SHORTCUT_GALLERY.equals(action)) {
            if (MyDebug.LOG)
                Log.d(TAG, "launching from application shortcut for Open Camera: gallery");
            openGallery_();
        } else if (ACTION_SHORTCUT_SETTINGS.equals(action)) {
            if (MyDebug.LOG)
                Log.d(TAG, "launching from application shortcut for Open Camera: settings");
        }

        Bundle extras = this.getIntent().getExtras();
        if (extras != null) {
            if (MyDebug.LOG)
                Log.d(TAG, "handle intent extra information");
            if (!done_facing) {
                int camera_facing = extras.getInt("android.intent.extras.CAMERA_FACING", -1);
                if (camera_facing == 0 || camera_facing == 1) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "found android.intent.extras.CAMERA_FACING: " + camera_facing);
                    applicationInterface.switchToCamera(camera_facing == 1);
                    done_facing = true;
                }
            }
            if (!done_facing) {
                if (extras.getInt("android.intent.extras.LENS_FACING_FRONT", -1) == 1) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "found android.intent.extras.LENS_FACING_FRONT");
                    applicationInterface.switchToCamera(true);
                    done_facing = true;
                }
            }
            if (!done_facing) {
                if (extras.getInt("android.intent.extras.LENS_FACING_BACK", -1) == 1) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "found android.intent.extras.LENS_FACING_BACK");
                    applicationInterface.switchToCamera(false);
                    done_facing = true;
                }
            }
            if (!done_facing) {
                if (extras.getBoolean("android.intent.extra.USE_FRONT_CAMERA", false)) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "found android.intent.extra.USE_FRONT_CAMERA");
                    applicationInterface.switchToCamera(true);
                    done_facing = true;
                }
            }
        }

        // N.B., in practice the hasSetCameraId() check is pointless as we don't save the camera ID in shared preferences, so it will always
        // be false when application is started from onCreate(), unless resuming from saved instance (in which case we shouldn't be here anyway)
        if (!done_facing && !applicationInterface.hasSetCameraId()) {
            if (MyDebug.LOG)
                Log.d(TAG, "initialise to back camera");
            // most devices have first camera as back camera anyway so this wouldn't be needed, but some (e.g., LG G6) have first camera
            // as front camera, so we should explicitly switch to back camera
            applicationInterface.switchToCamera(false);
        }
    }


    private void initCamera2Support() {
        Log.d(TAG, "initCamera2Support");
        this.supports_camera2 = false;
        if (Build.VERSION.SDK_INT >= 21) {
            CameraControllerManager2 cameraControllerManager2 = new CameraControllerManager2(this);
            this.supports_camera2 = false;
            int numberOfCameras = cameraControllerManager2.getNumberOfCameras();
            if (numberOfCameras == 0) {
                Log.d(TAG, "Camera2 reports 0 cameras");
                this.supports_camera2 = false;
            }
            for (int i = 0; i < numberOfCameras && !this.supports_camera2; i++) {
                if (cameraControllerManager2.allowCamera2Support(i)) {
                    Log.d(TAG, "camera " + i + " has at least limited support for Camera2 API");
                    this.supports_camera2 = true;
                }
            }
        }
        if (test_force_supports_camera2 && Build.VERSION.SDK_INT >= 21) {
            Log.d(TAG, "forcing supports_camera2");
            this.supports_camera2 = true;
        }
        Log.d(TAG, "supports_camera2? " + this.supports_camera2);
        if (this.supports_camera2) {
            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            if (!defaultSharedPreferences.contains(PreferenceKeys.CameraAPIPreferenceKey) && defaultSharedPreferences.contains("preference_use_camera2") && defaultSharedPreferences.getBoolean("preference_use_camera2", false)) {
                Log.d(TAG, "transfer legacy camera2 boolean preference to new api option");
                SharedPreferences.Editor edit = defaultSharedPreferences.edit();
                edit.putString(PreferenceKeys.CameraAPIPreferenceKey, "preference_camera_api_camera2");
                edit.remove("preference_use_camera2");
                edit.apply();
            }
        }
    }

    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        activity_count--;
        Log.d(TAG, "activity_count: " + activity_count);
        cancelImageSavingNotification();
        waitUntilImageQueueEmpty();
        this.preview.onDestroy();
        MyApplicationInterface myApplicationInterface = this.applicationInterface;
        if (myApplicationInterface != null) {
            myApplicationInterface.onDestroy();
        }
        if (Build.VERSION.SDK_INT >= 23 && activity_count == 0) {
            Log.d(TAG, "release renderscript contexts");
            RenderScript.releaseAllContexts();
        }
        if (this.textToSpeech != null) {
            Log.d(TAG, "free textToSpeech");
            this.textToSpeech.stop();
            this.textToSpeech.shutdown();
            this.textToSpeech = null;
        }
//        stopLocationUpdates();
        cancelTimer();
        super.onDestroy();
        Log.d(TAG, "onDestroy done");
//        SupportMapFragment supportMapFragment = this.mMapView;
//        if (supportMapFragment != null) {
//            supportMapFragment.onDestroy();
//        }
    }

    public void audioTrigger() {
        Log.d(TAG, "ignore audio trigger due to popup open");
        if (this.camera_in_background) {
            Log.d(TAG, "ignore audio trigger due to camera in background");
        } else if (this.preview.isTakingPhotoOrOnTimer()) {
            Log.d(TAG, "ignore audio trigger due to already taking photo or on timer");
        } else if (this.preview.isVideoRecording()) {
            Log.d(TAG, "ignore audio trigger due to already recording video");
        } else {
            Log.d(TAG, "schedule take picture due to loud noise");
            runOnUiThread(() -> {
                Log.d(CameraActivity.TAG, "taking picture due to audio trigger");
                CameraActivity.this.takePicture(false);
            });
        }
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        Log.d(TAG, "onKeyDown: " + i);
        if (this.mainUI.onKeyDown(i, keyEvent)) {
            return true;
        }
        return super.onKeyDown(i, keyEvent);
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {

        Log.d(TAG, "onKeyUp: " + i);
        this.mainUI.onKeyUp(i, keyEvent);

        return super.onKeyUp(i, keyEvent);
    }

    public void zoomIn() {
        this.mainUI.changeSeekbar(R.id.zoom_seekbar, -1);
    }

    public void zoomOut() {
        this.mainUI.changeSeekbar(R.id.zoom_seekbar, 1);
    }

    public float getWaterDensity() {
        return this.mWaterDensity;
    }

    AlertDialog.Builder builder;

    public void onResume() {
        Log.d(TAG, "onResume");
        long currentTimeMillis = System.currentTimeMillis();
        super.onResume();
        AppController.mInstance.setConnectivityListener(this);

//        AdsUtilsKt.checkForStorageLocationCameraPermission(CameraActivity.this, () -> {
        String[] permission = {
                android.Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA
        };
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            permission = new String[]{
                    Manifest.permission.CAMERA,
            };
        }

        rxPermissions.request(permission).subscribe(aBoolean -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                app_is_paused = false;
                cancelImageSavingNotification();
                getWindow().getDecorView().getRootView().setBackgroundColor(-16777216);
                try {
                    mSensorManager.registerListener(accelerometerListener, mSensorAccelerometer, 3);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {
                    magneticSensor.registerMagneticListener(mSensorManager);
                } catch (Exception e) {
                    e.printStackTrace();

                }
                //      orientationEventListener.enable();
                registerReceiver(cameraReceiver, new IntentFilter("com.miband2.action.CAMERA"));
                bluetoothRemoteControl.startRemoteControl();
                speechControl.initSpeechRecognizer();
                initGyroSensors();
                applicationInterface.getImageSaver().onResume();
                soundPoolManager.initSound();
                soundPoolManager.loadSound(R.raw.mybeep);
                soundPoolManager.loadSound(R.raw.mybeep_hi);
                mainUI.layoutUI();
                applicationInterface.reset(false);
                if (!camera_in_background) {
                    preview.onResume();
                }
                int cameraIdPref = applicationInterface.getCameraIdPref();
                if (cameraIdPref > 0) {
                    CameraControllerManager cameraControllerManager = preview.getCameraControllerManager();
                    CameraController.Facing facing = cameraControllerManager.getFacing(cameraIdPref);
                    Log.d(TAG, "front_facing: " + facing);
                    if (cameraControllerManager.getNumberOfCameras() > 2) {
                        boolean z = true;
                        for (int i = 0; i < cameraIdPref; i++) {
                            CameraController.Facing facing2 = cameraControllerManager.getFacing(i);
                            Log.d(TAG, "camera " + i + " that_front_facing: " + facing2);
                            if (facing2 == facing) {
                                z = false;
                            }
                        }
                        Log.d(TAG, "camera_is_default: " + z);
                        if (!z) {
                            pushCameraIdToast(cameraIdPref);
                        }
                    }
                }
                Log.d(TAG, "onResume: total time to resume: " + (System.currentTimeMillis() - currentTimeMillis));

//            AdsUtilsKt.checkForStorageLocationPermission(CameraActivity.this, () -> {

                updateGalleryIcon();
                lastImage();

        updateSaveFolder();
                if (GeneralUtilsKt.isOnline(CameraActivity.this)) {
//                    createLocationRequest();
//                    if (cameraStamp.getLocationType().equals(ConstantsKt.MANUAL)) {
//                        if (SharedPrefs.getBoolean(CameraActivity.this, SharedPrefs.IS_LOCATION_CHANGED, false)) {
//                            SharedPrefs.savePref(CameraActivity.this, SharedPrefs.IS_LOCATION_CHANGED, false);
//                            SharedPrefs.savePref(CameraActivity.this, SharedPrefs.IS_CALL_WEATHER_API, true);
//                            initmap();
//                        }
//                        loadMap();
//                    }
                } else {
                    NetworkManager.internetErrorDialog(CameraActivity.this);
                }
//                return null;
//            });
//                SupportMapFragment supportMapFragment = mMapView;
//                if (supportMapFragment != null) {
//                    supportMapFragment.onResume();
//                }

                Runnable runnable = () -> {

//                    getHandler().post(updateDateTimeTextTask);
//                    getHandler().post(updateQuoteTextTask);
//
//                    if (cameraStamp.getLocationType().equals(ConstantsKt.MANUAL)) {
//                        updateAddress(0.0, 0.0);
//                    } else {
//                        if (!GeneralUtilsKt.isOnline(CameraActivity.this) && NetworkManager.isGPSConnected(mContext)) {
//                            updateStampLayoutsAddressValue("");
//                        } else {
//                            initLocation();
//                            String lat = SharedPrefs.getString(CameraActivity.this, SharedPrefs.LATITUDE, "");
//                            String strLong = SharedPrefs.getString(CameraActivity.this, SharedPrefs.LONGITUDE, "");
//
//                            if (!lat.isEmpty() && !strLong.isEmpty() && ConstantsKt.isNumberFormat(lat) && ConstantsKt.isNumberFormat(lat) && ConstantsKt.isNumberFormat(strLong)) {
//                                updateAddress(Double.parseDouble(SharedPrefs.getString(CameraActivity.this, SharedPrefs.LATITUDE, "")), Double.parseDouble(SharedPrefs.getString(CameraActivity.this, SharedPrefs.LONGITUDE, "")));
//                            }
//
//                        }
//                    }
//
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        orientationEventListener = new OrientationEventListener(CameraActivity.this) {
                            @SuppressLint("LongLogTag")
                            @RequiresApi(Build.VERSION_CODES.M)
                            @Override
                            public void onOrientationChanged(int i) {
                                int rotation = 0;
                                if (i >= 0 && i <= 10) {
                                    if (current_orientation != 0) {
                                        current_orientation = 0;

                                        rotation = 0;
                                        updateStampAngle(rotation);
                                    }
                                } else if (i >= 80 && i <= 100) {
                                    if (current_orientation != 90) {
                                        current_orientation = 90;
                                        rotation = 90;
                                        updateStampAngle(rotation);


                                    }
                                } else if (i >= 170 && i <= 190) {
                                    if (current_orientation != 180) {
                                        current_orientation = 180;

                                        rotation = 180;
                                        updateStampAngle(rotation);
                                    }
                                } else if (i >= 260 && i <= 280) {
                                    if (current_orientation != 270) {
                                        current_orientation = 270;
                                        rotation = 270;

                                        updateStampAngle(rotation);
                                    }
                                }
                            }
                        };
                        orientationEventListener.enable();
//                        if (SharedPrefs.getBoolean(CameraActivity.this, SharedPrefs.IS_ENABLE_STAMP, true)) {
//                            clCustomStamp.setVisibility(View.VISIBLE);
//                        } else {
//                            clCustomStamp.setVisibility(View.GONE);
//                        }
                    }
                };
                getHandler().postDelayed(runnable, 800);
            } else {
                if (ActivityCompat.shouldShowRequestPermissionRationale(CameraActivity.this, Manifest.permission.CAMERA)) {
                    onResume();
                } else {
                    if (builder == null) {
                        String msg = getString(R.string.msg_allow_permission_camera);
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                                this,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                        ) != PackageManager.PERMISSION_GRANTED) {
                            msg = getString(R.string.msg_allow_permission_camera);
                        } else {
                            msg = getString(R.string.msg_allow_permission_camera_only);
                        }
                        builder = new AlertDialog.Builder(CameraActivity.this);
                        builder.setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>" + getString(R.string.error_permission_required) + "</font>", HtmlCompat.FROM_HTML_MODE_LEGACY));

                        builder.setMessage(msg);

                        builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();

                                Intent intent = new Intent(
                                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                        Uri.fromParts("package", getPackageName(), null)
                                );
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        });
                        builder.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();

                                finish();
                            }
                        });
                        AlertDialog create = builder.create();
                        create.show();
                    }

                }
            }
        });


    }

    public Point getCenterScreenPosition(Context context) {
        Point p = getScreenSize(context);
        p.x = p.x / 2;
        p.y = p.y / 2;
        return p;
    }

    public Point getScreenSize(Context context) {
        Display display = ((WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE))
                .getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        return size;
    }

    private void openPhotoPreviewActivity() {
        File[] files = new File(UtilsKt.cameraPicPathNew).listFiles(new ImageFileFilter());
        if (files != null && files.length > 0) {
            Intent intent = new Intent(this, ImagePreviewActivity.class);
            intent.putExtra(ConstantsKt.SKIP_AUTHENTICATION, true);
            intent.putExtra(ConstantsKt.PATH, files[0].getAbsolutePath());
            intent.putExtra(ConstantsKt.SHOW_ALL, true);
            intent.putExtra(ConstantsKt.IS_FROM_CAMERA, true);
            intent.putExtra(ConstantsKt.SHOW_ONLY_HIDDEN, false);
            intent.putExtra(ConstantsKt.SHOW_FAVORITES, false);
            intent.putExtra(ConstantsKt.SHOW_RECYCLE_BIN, false);
            startActivity(intent);

            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        } else {
            Toast.makeText(this, getString(R.string.msg_no_image_captured_by_hd_camera), Toast.LENGTH_SHORT).show();
        }
    }

    public Uri lastImageUri() {
        File[] files = new File(UtilsKt.cameraPicPathNew).listFiles(new ImageFileFilter());
        if (files != null && files.length > 0) {
            File files1 = files[(files.length - 1)];
            return FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", files1);
        } else {
            return Uri.EMPTY;
        }
    }

    public void lastImage() {

        File[] files = new File(UtilsKt.cameraPicPathNew).listFiles(new ImageFileFilter());
        if (files != null && files.length > 0) {
            Arrays.sort(files, new Comparator<File>() {
                public int compare(File f1, File f2) {
                    return Long.compare(f2.lastModified(), f1.lastModified());
                }
            });
            File files1 = files[0];

            Glide.with(getApplicationContext())
                    .load(files1)
                    .centerCrop()
                    .into(mivGalleryCamera);
            ContextKt.updatePhotoVideoDirectoryPath(this,UtilsKt.cameraPicPathNew,true,false,false);

        } else {

            Glide.with(getApplicationContext())
                    .load(R.mipmap.ic_launcher)
                    .centerCrop()
                    .into(mivGalleryCamera);

        }

    }


    private boolean isImageFile(String filePath) {

        if (filePath.endsWith(".jpg") || filePath.endsWith(".png")) {


            try {
                ExifInterface exif = new ExifInterface(filePath);

                if (exif.hasAttribute("DateTime")) {
                    return true;
                } else {
                    return false;
                }

            } catch (IOException e) {
                return false;
            }


        }

        return false;
    }

    private class ImageFileFilter implements FileFilter {

        @Override
        public boolean accept(File file) {
            if (file.isDirectory()) {
                return true;
            } else if (StringKt.isImageFast(file.getAbsolutePath()) && !file.getName().startsWith(".")) {
                return true;
            }
            return false;
        }
    }

    public void updateSaveFolder() {
        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "HD Camera" + File.separator + "HD Camera");
        String name = file.getName();

        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        if (!this.applicationInterface.getStorageUtils().getSaveLocation().equals(name)) {

            Log.d(TAG, "changed save_folder to: " + this.applicationInterface.getStorageUtils().getSaveLocation());
            SharedPreferences.Editor edit = defaultSharedPreferences.edit();
            edit.putString(PreferenceKeys.SaveLocationPreferenceKey, name);
            edit.apply();
            this.save_location_history.updateFolderHistory(getStorageUtils().getSaveLocation(), true);

        }

    }


    public void onWindowFocusChanged(boolean z) {
        Log.d(TAG, "onWindowFocusChanged: " + z);
        super.onWindowFocusChanged(z);
        if (!this.camera_in_background && z) {
            initImmersiveMode();
        }
    }

    public void onPause() {
        Log.d(TAG, "onPause");
        System.currentTimeMillis();
        super.onPause();

//        getHandler().removeCallbacks(updateDateTimeTextTask);

        this.app_is_paused = true;
        this.mainUI.destroyPopup();
        this.mSensorManager.unregisterListener(this.accelerometerListener);
        this.magneticSensor.unregisterMagneticListener(this.mSensorManager);
//        if (isMarshmallowPlus() && orientationEventListener != null) {
//            orientationEventListener.disable();
//        }

        try {
            unregisterReceiver(this.cameraReceiver);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        this.bluetoothRemoteControl.stopRemoteControl();
        freeAudioListener(false);
        this.speechControl.stopSpeechRecognizer();
        this.applicationInterface.stopPanorama(true);
        this.applicationInterface.getGyroSensor().disableSensors();
        this.applicationInterface.getImageSaver().onPause();
        this.soundPoolManager.releaseSound();
        this.applicationInterface.clearLastImages();
        this.applicationInterface.getDrawPreview().clearGhostImage();
        this.preview.onPause();
//        stopLocationUpdates();
//        SupportMapFragment supportMapFragment = this.mMapView;
//        if (supportMapFragment != null) {
//            supportMapFragment.onPause();
//        }
        cancelTimer();
    }

//    private void stopLocationUpdates() {
//        if (this.mGMap != null) {
//            if (ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0) {
//                this.mGMap.setMyLocationEnabled(false);
//            } else {
//                return;
//            }
//        }
//        FusedLocationProviderClient fusedLocationProviderClient = this.fusedLocationClient;
//        if (fusedLocationProviderClient != null) {
//            fusedLocationProviderClient.removeLocationUpdates(this.mLocationCallback);
//        }
//    }

    public void onStart() {
        super.onStart();
//        SupportMapFragment supportMapFragment = this.mMapView;
//        if (supportMapFragment != null) {
//            supportMapFragment.onStart();
//        }

//        if (GeneralUtilsKt.isOnline(CameraActivity.this) && NetworkManager.isGPSConnected(mContext)) {
//            startLocationUpdate();
//        }
    }

//    private void startLocationUpdate() {
//
//        locationViewModel.getLocationData().observe(this, locationModel -> {
//            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM dd, yyyy HH:mm:ss", Locale.getDefault());
//            if (cameraStamp.getLocationType() != null && !cameraStamp.getLocationType().isEmpty() && cameraStamp.getLocationType().equals(ConstantsKt.AUTOMATIC)) {
//                updateAddress(locationModel.getLatitude(), locationModel.getLongitude());
//            } else {
//                updateAddress(0.0, 0.0);
//            }
//        });
//    }

//    private void updateAddress(Double latitude, Double longitude) {
//
//        if (cameraStamp.getLocationType() != null && !cameraStamp.getLocationType().isEmpty() && cameraStamp.getLocationType().equals(ConstantsKt.AUTOMATIC) && GeneralUtilsKt.isOnline(this) && NetworkManager.isGPSConnected(mContext)) {
//
//            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
//            ArrayList<Address> addresses = new ArrayList();
//
//            CoroutinesClassKt.AsyncBackgroundWork(() -> null, () -> {
//                try {
//                    addresses.addAll(geocoder.getFromLocation(latitude, longitude, 1));
//                } catch (IOException e) {
//                }
//                return null;
//            }, () -> {
//                if (!addresses.isEmpty()) {
//                    String address = addresses.get(0).getAddressLine(0);
//                    Log.d(TAG, "updateAddress: Address -->" + address);
//                    updateStampLayoutsAddressValue(address);
//                } else {
//                    updateStampLayoutsAddressValue("");
//                }
//                return null;
//            });
//
//        } else if (cameraStamp.getLocationType().equals(ConstantsKt.AUTOMATIC) && !GeneralUtilsKt.isOnline(this) && !NetworkManager.isGPSConnected(mContext)) {
//            updateStampLayoutsAddressValue("");
//        } else {
//            updateStampLayoutsAddressValue(cameraStamp.getMessage());
//        }
//    }


//    private Runnable updateDateTimeTextTask = new Runnable() {
//        @Override
//        public void run() {
//            String setDateTimeFormat = HelperClass.setDateTimeFormat(cameraStamp.getDateTime());
//            updateStampLayoutsDateTimeValue(setDateTimeFormat);
//            getHandler().postDelayed(this, 1000);
//        }
//    };
//    private Runnable updateQuoteTextTask = new Runnable() {
//        @Override
//        public void run() {
//
//            quoteMessage = SharedPrefs.getString(CameraActivity.this, SharedPrefs.QUOTE, "").trim();
//            updateStampLayoutsQuoteValue(quoteMessage);
//            getHandler().postDelayed(this, 1000);
//        }
//    };

    public void onStop() {
        super.onStop();
//        SupportMapFragment supportMapFragment = this.mMapView;
//        if (supportMapFragment != null) {
//            supportMapFragment.onStop();
//        }
//        stopLocationUpdates();
    }

    public void onLowMemory() {
        super.onLowMemory();
//        SupportMapFragment supportMapFragment = this.mMapView;
//        if (supportMapFragment != null) {
//            supportMapFragment.onLowMemory();
//        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        Log.d(TAG, "onConfigurationChanged()");
        this.preview.setCameraDisplayOrientation();
        super.onConfigurationChanged(configuration);
    }

    public void waitUntilImageQueueEmpty() {
        Log.d(TAG, "waitUntilImageQueueEmpty");
        this.applicationInterface.getImageSaver().waitUntilDone();
    }

    private boolean longClickedTakePhoto() {
        Log.d(TAG, "longClickedTakePhoto");
        if (supportsFastBurst()) {
            CameraController.Size currentPictureSize = this.preview.getCurrentPictureSize();
            if (currentPictureSize == null || !currentPictureSize.supports_burst) {
                Log.d(TAG, "fast burst not supported for this resolution");
            } else {
                MyApplicationInterface.PhotoMode photoMode = this.applicationInterface.getPhotoMode();
                if (photoMode == MyApplicationInterface.PhotoMode.Standard && this.applicationInterface.isRawOnly(photoMode)) {
                    Log.d(TAG, "fast burst not supported in RAW-only mode");
                } else if (photoMode == MyApplicationInterface.PhotoMode.Standard || photoMode == MyApplicationInterface.PhotoMode.FastBurst) {
                    takePicturePressed(false, true);
                    return true;
                }
            }
        } else {
            Log.d(TAG, "fast burst not supported");
        }
        return false;
    }

    public void clickedTakePhotoVideoSnapshot(View view) {
        Log.d(TAG, "clickedTakePhotoVideoSnapshot");
        takePicture(true);
    }

    public void clickedCancelPanorama(View view) {
        Log.d(TAG, "clickedCancelPanorama");
        this.applicationInterface.stopPanorama(true);
    }

    public void clickedCycleRaw(View view) {
        Log.d(TAG, "clickedCycleRaw");
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String str = "preference_raw_no";
        String string = defaultSharedPreferences.getString(PreferenceKeys.RawPreferenceKey, str);
        string.hashCode();
        char c = 65535;
        switch (string.hashCode()) {
            case -1076775865:
                if (string.equals("preference_raw_only")) {
                    c = 0;
                    break;
                }
                break;
            case -866009364:
                if (string.equals("preference_raw_yes")) {
                    c = 1;
                    break;
                }
                break;
            case 664800540:
                if (string.equals(str)) {
                    c = 2;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                break;
            case 1:
                str = "preference_raw_only";
                break;
            case 2:
                str = "preference_raw_yes";
                break;
            default:
                str = null;
                break;
        }
        if (str != null) {
            SharedPreferences.Editor edit = defaultSharedPreferences.edit();
            edit.putString(PreferenceKeys.RawPreferenceKey, str);
            edit.apply();
            this.applicationInterface.getDrawPreview().updateSettings();
            this.preview.reopenCamera();
        }
    }

    public void updateForSettings() {
        updateForSettings((String) null, false);
    }

    public void updateForSettings(String str) {
        updateForSettings(str, false);
    }

    public void updateForSettings(String str, boolean z) {
        boolean z2;
        CameraController.TonemapProfile tonemapProfile;
        CameraController.TonemapProfile videoTonemapProfile;
        Log.d(TAG, "updateForSettings()");
        if (str != null) {
            Log.d(TAG, "toast_message: " + str);
        }
        long currentTimeMillis = System.currentTimeMillis();
        Log.d(TAG, "update folder history");
        this.save_location_history.updateFolderHistory(getStorageUtils().getSaveLocation(), true);
        Log.d(TAG, "updateForSettings: time after update folder history: " + (System.currentTimeMillis() - currentTimeMillis));
        imageQueueChanged();
        if (!z) {
            this.mainUI.destroyPopup();
            Log.d(TAG, "updateForSettings: time after destroy popup: " + (System.currentTimeMillis() - currentTimeMillis));
        }
        if (this.preview.getCameraController() != null) {
            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            String sceneMode = this.preview.getCameraController().getSceneMode();
            Log.d(TAG, "scene mode was: " + sceneMode);
            String string = defaultSharedPreferences.getString(PreferenceKeys.SceneModePreferenceKey, "auto");
            if (!string.equals(sceneMode)) {
                Log.d(TAG, "scene mode changed to: " + string);
            } else {
                if (this.applicationInterface.useCamera2()) {
                    boolean useCamera2FakeFlash = this.preview.getCameraController().getUseCamera2FakeFlash();
                    Log.d(TAG, "camera2_fake_flash was: " + useCamera2FakeFlash);
                    if (this.applicationInterface.useCamera2FakeFlash() != useCamera2FakeFlash) {
                        Log.d(TAG, "camera2_fake_flash changed");
                    }
                }
                z2 = false;
                if (!(z2 || (tonemapProfile = this.preview.getCameraController().getTonemapProfile()) == CameraController.TonemapProfile.TONEMAPPROFILE_OFF || (videoTonemapProfile = this.applicationInterface.getVideoTonemapProfile()) == CameraController.TonemapProfile.TONEMAPPROFILE_OFF || videoTonemapProfile == tonemapProfile)) {
                    Log.d(TAG, "switching between tonemap profiles");
                    z2 = true;
                }
            }
            z2 = true;
            Log.d(TAG, "switching between tonemap profiles");
            z2 = true;
        } else {
            z2 = false;
        }
        Log.d(TAG, "updateForSettings: time after check need_reopen: " + (System.currentTimeMillis() - currentTimeMillis));
        this.mainUI.layoutUI();
        Log.d(TAG, "updateForSettings: time after layoutUI: " + (System.currentTimeMillis() - currentTimeMillis));
        checkDisableGUIIcons();
        this.speechControl.initSpeechRecognizer();
        initGyroSensors();
        Log.d(TAG, "updateForSettings: time after init speech and location: " + (System.currentTimeMillis() - currentTimeMillis));
        if (str != null) {
            if (z2 || this.preview.getCameraController() == null) {
                this.preview.reopenCamera();
                Log.d(TAG, "updateForSettings: time after reopen: " + (System.currentTimeMillis() - currentTimeMillis));
            } else {
                preview.setCameraDisplayOrientation();
                Log.d(TAG, "updateForSettings: time after set display orientation: " + (System.currentTimeMillis() - currentTimeMillis));
                preview.pausePreview(true);
                Log.d(TAG, "updateForSettings: time after pause: " + (System.currentTimeMillis() - currentTimeMillis));
                preview.setupCamera(false);
                Log.d(TAG, "updateForSettings: time after setup: " + (System.currentTimeMillis() - currentTimeMillis));
            }
        }
        if (str != null && str.length() > 0) {
            this.preview.showToast((ToastBoxer) null, str);
        }
        this.magneticSensor.registerMagneticListener(this.mSensorManager);
        this.magneticSensor.checkMagneticAccuracy();
        Log.d(TAG, "updateForSettings: done: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    public void onBackPressed() {
        Preview preview2 = this.preview;
        if (preview2 != null && preview2.isPreviewPaused()) {
            Log.d(TAG, "preview was paused, so unpause it");
            this.preview.startCameraPreview();
        } else if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            OnBackPressedListener onBackPressedListener2 = this.onBackPressedListener;
            if (onBackPressedListener2 != null) {
                onBackPressedListener2.onBackPressed();
            }
        } else {
            continueExit();
        }

    }

    public void continueExit() {
        dissmissDialog();
        if (MainActivity.Companion.getActivity() == null) {
            startActivity(MainActivity.Companion.newIntent(this));
        } else {
            super.onBackPressed();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }
    }

    public void dissmissDialog() {
        HelperClass.dismissProgressDialog();
    }

    private void cancelTimer() {
        HelperClass.dismissProgressDialog();
    }

    public boolean usingKitKatImmersiveMode() {
        if (Build.VERSION.SDK_INT < 19) {
            return false;
        }
        String string = PreferenceManager.getDefaultSharedPreferences(this).getString(PreferenceKeys.ImmersiveModePreferenceKey, "immersive_mode_low_profile");
        return string.equals("immersive_mode_gui") || string.equals("immersive_mode_everything");
    }

    public boolean usingKitKatImmersiveModeEverything() {
        return Build.VERSION.SDK_INT >= 19 && PreferenceManager.getDefaultSharedPreferences(this).getString(PreferenceKeys.ImmersiveModePreferenceKey, "immersive_mode_low_profile").equals("immersive_mode_everything");
    }

    /* access modifiers changed from: private */
    public void setImmersiveTimer() {
        Runnable runnable;
        Handler handler = this.immersive_timer_handler;
        if (!(handler == null || (runnable = this.immersive_timer_runnable) == null)) {
            handler.removeCallbacks(runnable);
        }
        Handler handler2 = new Handler(getMainLooper());
        this.immersive_timer_handler = handler2;
        Runnable r1 = new Runnable() {
            public void run() {
                Log.d(CameraActivity.TAG, "setImmersiveTimer: run");
                if (!CameraActivity.this.camera_in_background && CameraActivity.this.usingKitKatImmersiveMode()) {
                    CameraActivity.this.setImmersiveMode(true);
                }
            }
        };
        this.immersive_timer_runnable = r1;
        handler2.postDelayed(r1, FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS);
    }

    public void initImmersiveMode() {
        if (!usingKitKatImmersiveMode()) {
            setImmersiveMode(true);
        } else {
            setImmersiveTimer();
        }
    }

    public void setImmersiveMode(boolean z) {
        Log.d(TAG, "setImmersiveMode: " + z);
        if (!z) {
            getWindow().getDecorView().setSystemUiVisibility(0);
        } else if (Build.VERSION.SDK_INT < 19 || !usingKitKatImmersiveMode()) {
            if (PreferenceManager.getDefaultSharedPreferences(this).getString(PreferenceKeys.ImmersiveModePreferenceKey, "immersive_mode_low_profile").equals("immersive_mode_low_profile")) {
                getWindow().getDecorView().setSystemUiVisibility(1);
            } else {
                getWindow().getDecorView().setSystemUiVisibility(0);
            }
        } else if (this.applicationInterface.getPhotoMode() == MyApplicationInterface.PhotoMode.Panorama) {
            getWindow().getDecorView().setSystemUiVisibility(0);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(2310);
        }
    }

    public void setBrightnessForCamera(boolean z) {
        Log.d(TAG, "setBrightnessForCamera");
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        final WindowManager.LayoutParams attributes = getWindow().getAttributes();
        if (z || defaultSharedPreferences.getBoolean(PreferenceKeys.MaxBrightnessPreferenceKey, false)) {
            attributes.screenBrightness = 1.0f;
        } else {
            attributes.screenBrightness = -1.0f;
        }
        runOnUiThread(new Runnable() {
            public void run() {
                CameraActivity.this.getWindow().setAttributes(attributes);
            }
        });
    }

    public void setBrightnessToMinimumIfWanted() {
        Log.d(TAG, "setBrightnessToMinimum");
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        final WindowManager.LayoutParams attributes = getWindow().getAttributes();
        if (defaultSharedPreferences.getBoolean(PreferenceKeys.DimWhenDisconnectedPreferenceKey, false)) {
            attributes.screenBrightness = 0.0f;
        } else {
            attributes.screenBrightness = -1.0f;
        }
        runOnUiThread(new Runnable() {
            public void run() {
                CameraActivity.this.getWindow().setAttributes(attributes);
            }
        });
    }

    public void setWindowFlagsForCamera() {
        MainUI mainUI2;
        Log.d(TAG, "setWindowFlagsForCamera");
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        Preview preview2 = this.preview;
        if (preview2 != null) {
            preview2.setCameraDisplayOrientation();
        }
        if (!(this.preview == null || (mainUI2 = this.mainUI) == null)) {
            mainUI2.layoutUI();
        }
        if (defaultSharedPreferences.getBoolean(PreferenceKeys.KeepDisplayOnPreferenceKey, true)) {
            Log.d(TAG, "do keep screen on");
            getWindow().addFlags(128);
        } else {
            Log.d(TAG, "don't keep screen on");
            getWindow().clearFlags(128);
        }
        if (defaultSharedPreferences.getBoolean(PreferenceKeys.ShowWhenLockedPreferenceKey, false)) {
            showWhenLocked(false);
        } else {
            showWhenLocked(false);
        }
        setBrightnessForCamera(false);
        initImmersiveMode();
        this.camera_in_background = false;
        this.magneticSensor.clearDialog();
    }

    private void setWindowFlagsForSettings() {
        setWindowFlagsForSettings(true);
    }

    public void setWindowFlagsForSettings(boolean z) {
        Log.d(TAG, "setWindowFlagsForSettings: " + z);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        getWindow().clearFlags(128);
        if (z) {
            showWhenLocked(false);
        }
        WindowManager.LayoutParams attributes = getWindow().getAttributes();
        attributes.screenBrightness = -1.0f;
        getWindow().setAttributes(attributes);
        setImmersiveMode(false);
        this.camera_in_background = true;
    }

    private void showWhenLocked(boolean z) {
        Log.d(TAG, "showWhenLocked: " + z);
        if (z) {
            getWindow().addFlags(524288);
        } else {
            getWindow().clearFlags(524288);
        }
    }

    public void showAlert(final AlertDialog alertDialog) {
        Log.d(TAG, "showAlert");
        new Handler(getMainLooper()).postDelayed(new Runnable() {
            public void run() {
                alertDialog.show();
            }
        }, 20);
    }

    public void showPreview(boolean show) {
        if (MyDebug.LOG)
            Log.d(TAG, "showPreview: " + show);
        final ViewGroup container = findViewById(R.id.hide_container);
        container.setVisibility(show ? View.GONE : View.VISIBLE);
    }


    public Bitmap loadThumbnailFromUri(Uri uri, int i, boolean z) {
        Uri uri2 = uri;
        Bitmap bitmap2 = null;
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            InputStream openInputStream = getContentResolver().openInputStream(uri2);
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(openInputStream, (Rect) null, options);
            int i2 = options.outWidth;
            int i3 = options.outHeight;
            Point point = new Point();
            getWindowManager().getDefaultDisplay().getSize(point);
            Log.d(TAG, "bitmap_width: " + i2);
            Log.d(TAG, "bitmap_height: " + i3);
            Log.d(TAG, "display width: " + point.x);
            Log.d(TAG, "display height: " + point.y);
            if (point.x < point.y) {
                point.set(point.y, point.x);
            }
            if (i2 < i3) {
                int i4 = i3;
                i3 = i2;
                i2 = i4;
            }
            Log.d(TAG, "bitmap_width: " + i2);
            Log.d(TAG, "bitmap_height: " + i3);
            Log.d(TAG, "display width: " + point.x);
            Log.d(TAG, "display height: " + point.y);
            options.inSampleSize = 1;
            while (i3 / (options.inSampleSize * 2) >= point.y) {
                options.inSampleSize *= 2;
            }

            options.inSampleSize *= i;
            Log.d(TAG, "inSampleSize: " + options.inSampleSize);
            options.inJustDecodeBounds = false;
            openInputStream.close();
            InputStream openInputStream2 = getContentResolver().openInputStream(uri2);
            bitmap2 = BitmapFactory.decodeStream(openInputStream2, (Rect) null, options);

            openInputStream2.close();
            if (!z) {
                try {
                    return rotateForExif(bitmap2, uri2);
                } catch (IOException e) {
                    return bitmap2;
                }
            } else {
                return bitmap2;
            }


        } catch (IOException e2) {
            return bitmap2;
        }
    }

    public Bitmap rotateForExif(Bitmap bitmap, Uri uri) throws IOException {
        ExifInterface exif;
        InputStream inputStream = null;
        try {
            inputStream = this.getContentResolver().openInputStream(uri);
            exif = new ExifInterface(inputStream);
        } finally {
            if (inputStream != null)
                inputStream.close();
        }

        if (exif != null) {
            int exif_orientation_s = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);
            boolean needs_tf = false;
            int exif_orientation = 0;
            // see http://jpegclub.org/exif_orientation.html
            // and http://stackoverflow.com/questions/20478765/how-to-get-the-correct-orientation-of-the-image-selected-from-the-default-image
            if (exif_orientation_s == ExifInterface.ORIENTATION_UNDEFINED || exif_orientation_s == ExifInterface.ORIENTATION_NORMAL) {
                // leave unchanged
            } else if (exif_orientation_s == ExifInterface.ORIENTATION_ROTATE_180) {
                needs_tf = true;
                exif_orientation = 180;
            } else if (exif_orientation_s == ExifInterface.ORIENTATION_ROTATE_90) {
                needs_tf = true;
                exif_orientation = 90;
            } else if (exif_orientation_s == ExifInterface.ORIENTATION_ROTATE_270) {
                needs_tf = true;
                exif_orientation = 270;
            }

            if (needs_tf) {
                if (MyDebug.LOG)
                    Log.d(TAG, "    need to rotate bitmap due to exif orientation tag");
                Matrix m = new Matrix();
                m.setRotate(exif_orientation, bitmap.getWidth() * 0.5f, bitmap.getHeight() * 0.5f);
                Bitmap rotated_bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), m, true);
                if (rotated_bitmap != bitmap) {
                    bitmap.recycle();
                    bitmap = rotated_bitmap;
                }
            }
        }
        return bitmap;
    }

    public void updateGalleryIcon(Bitmap bitmap2) {
        Log.d(TAG, "updateGalleryIcon: " + bitmap2);
        lastImage();
        gallery_bitmap = bitmap2;
    }

    public void updateGalleryIcon_(Bitmap bitmap2, File file, Uri finalSaveUri) {
        Log.d(TAG, "updateGalleryIcon: " + bitmap2);

        lastImage();
        gallery_bitmap = bitmap2;
    }

    /**
     * Updates the gallery icon by searching for the most recent photo.
     * Launches the task in a separate thread.
     */
    public void updateGalleryIcon() {
        long debug_time = 0;
        if (MyDebug.LOG) {
            Log.d(TAG, "updateGalleryIcon");
            debug_time = System.currentTimeMillis();
        }

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String ghost_image_pref = sharedPreferences.getString(PreferenceKeys.GhostImagePreferenceKey, "preference_ghost_image_off");
        final boolean ghost_image_last = ghost_image_pref.equals("preference_ghost_image_last");
        new AsyncTask<Void, Void, Bitmap>() {
            private static final String TAG = "MainActivity/AsyncTask";
            private boolean is_video;

            /** The system calls this to perform work in a worker thread and
             * delivers it the parameters given to AsyncTask.execute() */
            protected Bitmap doInBackground(Void... params) {
                if (MyDebug.LOG)
                    Log.d(TAG, "doInBackground");
                StorageUtils.Media media = applicationInterface.getStorageUtils().getLatestMedia();
                Bitmap thumbnail = null;
                KeyguardManager keyguard_manager = (KeyguardManager) CameraActivity.this.getSystemService(Context.KEYGUARD_SERVICE);
                boolean is_locked = keyguard_manager != null && keyguard_manager.inKeyguardRestrictedInputMode();
                if (MyDebug.LOG)
                    Log.d(TAG, "is_locked?: " + is_locked);
                if (media != null && getContentResolver() != null && !is_locked) {
                    // check for getContentResolver() != null, as have had reported Google Play crashes

                    is_video = media.video;

                    if (ghost_image_last && !media.video) {
                        if (MyDebug.LOG)
                            Log.d(TAG, "load full size bitmap for ghost image last photo");
                        thumbnail = loadThumbnailFromUri(media.uri, 1, media.mediastore);
                    }
                    if (thumbnail == null) {
                        try {
                            if (!media.mediastore) {
                                if (media.video) {
                                    if (MyDebug.LOG)
                                        Log.d(TAG, "load thumbnail for video from SAF uri");
                                    ParcelFileDescriptor pfd_saf = null; // keep a reference to this as long as retriever, to avoid risk of pfd_saf being garbage collected
                                    MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                                    try {
                                        pfd_saf = getContentResolver().openFileDescriptor(media.uri, "r");
                                        retriever.setDataSource(pfd_saf.getFileDescriptor());
                                        thumbnail = retriever.getFrameAtTime(-1);
                                    } catch (Exception e) {
                                        Log.d(TAG, "failed to load video thumbnail");
                                        e.printStackTrace();
                                    } finally {
                                        try {
                                            retriever.release();
                                        } catch (RuntimeException ex) {
                                            // ignore
                                        }
                                        try {
                                            if (pfd_saf != null) {
                                                pfd_saf.close();
                                            }
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                } else {
                                    if (MyDebug.LOG)
                                        Log.d(TAG, "load thumbnail for photo from SAF uri");
                                    thumbnail = loadThumbnailFromUri(media.uri, 4, media.mediastore);
                                }
                            } else if (media.video) {
//                                thumbnail = MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), media.id, MediaStore.Video.Thumbnails.MINI_KIND, null);
                            } else {
                                if (MyDebug.LOG)
                                    thumbnail = MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), media.id, MediaStore.Images.Thumbnails.MINI_KIND, null);
                            }
                        } catch (Throwable exception) {
                            // have had Google Play NoClassDefFoundError crashes from getThumbnail() for Galaxy Ace4 (vivalto3g), Galaxy S Duos3 (vivalto3gvn)
                            // also NegativeArraySizeException - best to catch everything
                            if (MyDebug.LOG)
                                exception.printStackTrace();
                        }
                    }
                    if (thumbnail != null) {
                        if (MyDebug.LOG)
                            if (media.orientation != 0) {
                                Matrix matrix = new Matrix();
                                matrix.setRotate(media.orientation, thumbnail.getWidth() * 0.5f, thumbnail.getHeight() * 0.5f);
                                try {
                                    Bitmap rotated_thumbnail = Bitmap.createBitmap(thumbnail, 0, 0, thumbnail.getWidth(), thumbnail.getHeight(), matrix, true);
                                    // careful, as rotated_thumbnail is sometimes not a copy!
                                    if (rotated_thumbnail != thumbnail) {
                                        thumbnail.recycle();
                                        thumbnail = rotated_thumbnail;
                                    }
                                } catch (Throwable t) {
                                }
                            }
                    }
                }
                return thumbnail;
            }

            /** The system calls this to perform work in the UI thread and delivers
             * the result from doInBackground() */
            protected void onPostExecute(Bitmap thumbnail) {
                if (MyDebug.LOG)
                    Log.d(TAG, "onPostExecute");
                // since we're now setting the thumbnail to the latest media on disk, we need to make sure clicking the Gallery goes to this
                applicationInterface.getStorageUtils().clearLastMediaScanned();
                if (thumbnail != null) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "set gallery button to thumbnail");
                    updateGalleryIcon(thumbnail);
                    applicationInterface.getDrawPreview().updateThumbnail(thumbnail, is_video, false); // needed in case last ghost image is enabled
                } else {
                    if (MyDebug.LOG)
                        Log.d(TAG, "set gallery button to blank");
//                    updateGalleryIconToBlank();
                }
            }
        }.execute();

        if (MyDebug.LOG)
            Log.d(TAG, "updateGalleryIcon: total time to update gallery icon: " + (System.currentTimeMillis() - debug_time));
    }

    public void savingImage(final boolean z) {
        Log.d(TAG, "savingImage: " + z);
        runOnUiThread((Runnable) () -> {
            final MySquareImageView imageView = (MySquareImageView) CameraActivity.this.findViewById(R.id.ivGalleryCamera);
            if (z) {
                imageView.setColorFilter(-2130706433, PorterDuff.Mode.MULTIPLY);
                if (CameraActivity.this.gallery_save_anim == null) {
                    ValueAnimator unused = CameraActivity.this.gallery_save_anim = ValueAnimator.ofInt(new int[]{Color.argb(ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION, 255, 255, 255), Color.argb(63, 255, 255, 255)});
                    CameraActivity.this.gallery_save_anim.setEvaluator(new ArgbEvaluator());
                    gallery_save_anim.setRepeatCount(ValueAnimator.INFINITE);
                    gallery_save_anim.setRepeatMode(ValueAnimator.REVERSE);
                    CameraActivity.this.gallery_save_anim.setDuration(500);
                }
                CameraActivity.this.gallery_save_anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    public void onAnimationUpdate(ValueAnimator valueAnimator) {
                        imageView.setColorFilter(((Integer) valueAnimator.getAnimatedValue()).intValue(), PorterDuff.Mode.MULTIPLY);
                    }
                });
                CameraActivity.this.gallery_save_anim.start();
            } else if (CameraActivity.this.gallery_save_anim != null) {
                CameraActivity.this.gallery_save_anim.cancel();
                imageView.setColorFilter((ColorFilter) null);
            }
        });
    }

    public void imageQueueChanged() {
        Log.d(TAG, "imageQueueChanged");
        this.applicationInterface.getDrawPreview().setImageQueueFull(!this.applicationInterface.canTakeNewPhoto());
        if (this.applicationInterface.getImageSaver().getNImagesToSave() == 0) {
            cancelImageSavingNotification();
        }
    }

    public void clickedGallery(View view) {
        Log.d(TAG, "clickedGallery");
        openGallery_();
    }


    private void openGallery_() {
        if (MyDebug.LOG)
            Log.d(TAG, "openGallery");
        openPhotoPreviewActivity();
    }

    public void openFolderChooserDialogSAF(boolean z) {
        Log.d(TAG, "openFolderChooserDialogSAF: " + z);
        this.saf_dialog_from_preferences = z;
        startActivityForResult(new Intent("android.intent.action.OPEN_DOCUMENT_TREE"), 42);
    }

    public void openGhostImageChooserDialogSAF(boolean z) {
        Log.d(TAG, "openGhostImageChooserDialogSAF: " + z);
        this.saf_dialog_from_preferences = z;
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType("image/*");
        try {
            startActivityForResult(intent, 43);

        } catch (ActivityNotFoundException e) {
            Log.e(TAG, "ActivityNotFoundException from startActivityForResult");
            e.printStackTrace();
        }
    }

    public void updateFolderHistorySAF(String str) {
        Log.d(TAG, "updateSaveHistorySAF");
        if (this.save_location_history_saf == null) {
            this.save_location_history_saf = new SaveLocationHistory(this, "save_location_history_saf", str);
        }
        this.save_location_history_saf.updateFolderHistory(str, true);
    }

    @Override
    public void fromActivityResult(int i, int i2, @Nullable Intent intent) {
        super.fromActivityResult(i, i2, intent);

        Log.d(TAG, "onActivityResult: " + i);
        Log.d(TAG, "onActivityResult: " + i2);

        if (i == REQUEST_CODE_OPEN_GALLERY) {
            overridePendingTransition(ConstantsKt.ANIM_FADE_IN, ConstantsKt.ANIM_FADE_OUT);
            HelperKt.scanMedia(CameraActivity.this);
            lastImage();
        }

        if (i == ConstantsKt.REQUEST_CODE_EDIT_UPDATE_STAMP && i2 == RESULT_OK) {
            setLayout();
            updateStampLayoutXY();
        }

        if (i == ConstantsKt.REQUEST_CODE_OPEN_UPDATE_STAMP && i2 == RESULT_OK) {
            setLayout();
            updateStampLayoutXY();
        }

        if (i != 1) {
            switch (i) {
                case 42:

                    Log.d(":::sd_card:::", "returned_treeUri: " + intent);
                    if (i2 != -1 || intent == null) {
                        Log.d(TAG, "SAF dialog cancelled");
                        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
                        if (defaultSharedPreferences.getString(PreferenceKeys.SaveLocationSAFPreferenceKey, "").length() == 0) {
                            Log.d(TAG, "no SAF save location was set");
                            SharedPreferences.Editor edit = defaultSharedPreferences.edit();
                            edit.putBoolean(PreferenceKeys.UsingSAFPreferenceKey, false);
                            edit.apply();
                            setSdCardPermissionFlag(false);
                            return;
                        }
                        return;
                    }
                    Uri data = intent.getData();
                    try {
                        getContentResolver().takePersistableUriPermission(data, intent.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        SharedPreferences.Editor edit2 = PreferenceManager.getDefaultSharedPreferences(this).edit();
                        edit2.putString(PreferenceKeys.SaveLocationSAFPreferenceKey, data.toString());
                        edit2.apply();
                        setSdCardPermissionFlag(true);
                        updateFolderHistorySAF(data.toString());
                        return;
                    } catch (SecurityException e) {
                        SharedPreferences defaultSharedPreferences2 = PreferenceManager.getDefaultSharedPreferences(this);
                        if (defaultSharedPreferences2.getString(PreferenceKeys.SaveLocationSAFPreferenceKey, "").length() == 0) {
                            Log.d(TAG, "no SAF save location was set");
                            SharedPreferences.Editor edit3 = defaultSharedPreferences2.edit();
                            edit3.putBoolean(PreferenceKeys.UsingSAFPreferenceKey, false);
                            edit3.apply();
                            return;
                        }
                        return;
                    }

                case 43:
                    if (i2 != -1 || intent == null) {
                        Log.d(TAG, "SAF dialog cancelled");
                        SharedPreferences defaultSharedPreferences3 = PreferenceManager.getDefaultSharedPreferences(this);
                        if (defaultSharedPreferences3.getString(PreferenceKeys.GhostSelectedImageSAFPreferenceKey, "").length() == 0) {
                            Log.d(TAG, "no SAF ghost image was set");
                            SharedPreferences.Editor edit4 = defaultSharedPreferences3.edit();
                            edit4.putString(PreferenceKeys.GhostImagePreferenceKey, "preference_ghost_image_off");
                            edit4.apply();
                        }
                    } else {
                        Uri data2 = intent.getData();
                        Log.d(TAG, "returned single fileUri: " + data2);

                        try {
                            getContentResolver().takePersistableUriPermission(data2, intent.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                            SharedPreferences.Editor edit5 = PreferenceManager.getDefaultSharedPreferences(this).edit();
                            edit5.putString(PreferenceKeys.GhostSelectedImageSAFPreferenceKey, data2.toString());
                            edit5.apply();
                        } catch (SecurityException e2) {
                            SharedPreferences defaultSharedPreferences4 = PreferenceManager.getDefaultSharedPreferences(this);
                            if (defaultSharedPreferences4.getString(PreferenceKeys.GhostSelectedImageSAFPreferenceKey, "").length() == 0) {
                                Log.d(TAG, "no SAF ghost image was set");
                                SharedPreferences.Editor edit6 = defaultSharedPreferences4.edit();
                                edit6.putString(PreferenceKeys.GhostImagePreferenceKey, "preference_ghost_image_off");
                                edit6.apply();
                            }
                        }

                    }
                    if (!this.saf_dialog_from_preferences) {
                        setWindowFlagsForCamera();
                        showPreview(true);
                        return;
                    }
                    return;
                case 44:
                    if (i2 != -1 || intent == null) {
                        Log.d(TAG, "SAF dialog cancelled");
                    } else {
                        Uri data3 = intent.getData();
                        Log.d(TAG, "returned single fileUri: " + data3);
                        try {
                            getContentResolver().takePersistableUriPermission(data3, intent.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                            this.settingsManager.loadSettings(data3);
                        } catch (SecurityException e3) {
                            e3.printStackTrace();
                        }
                    }
                    if (!this.saf_dialog_from_preferences) {
                        setWindowFlagsForCamera();
                        showPreview(true);
                        return;
                    }
                    return;
                default:
                    return;
            }
        } else if (i2 == 0) {
            this.isPermission++;
        } else if (i2 == -1) {
            this.isPermission = 0;
        }
    }

    public boolean isMultiCam() {
        return this.is_multi_cam;
    }

    public void clickedSwitchMultiCamera(View view) {
        Log.d(TAG, "clickedSwitchMultiCamera");
        if (!isMultiCamEnabled()) {
            Log.e(TAG, "switch multi camera icon shouldn't have been visible");
        } else if (this.preview.isOpeningCamera()) {
            Log.d(TAG, "already opening camera in background thread");
        } else if (this.preview.canSwitchCamera()) {
            int nextMultiCameraId = getNextMultiCameraId();
            pushCameraIdToast(nextMultiCameraId);
            userSwitchToCamera(nextMultiCameraId);
        }
    }

    public int getNextMultiCameraId() {
        if (MyDebug.LOG)
            Log.d(TAG, "getNextMultiCameraId");
        if (!isMultiCamEnabled()) {
            Log.e(TAG, "getNextMultiCameraId() called but not in multi-cam mode");
            throw new RuntimeException("getNextMultiCameraId() called but not in multi-cam mode");
        }
        List<Integer> camera_set;
        // don't use preview.getCameraController(), as it may be null if user quickly switches between cameras
        int currCameraId = getActualCameraId();
        switch (preview.getCameraControllerManager().getFacing(currCameraId)) {
            case FACING_BACK:
                camera_set = back_camera_ids;
                break;
            case FACING_FRONT:
                camera_set = front_camera_ids;
                break;
            default:
                camera_set = other_camera_ids;
                break;
        }
        int cameraId;
        int indx = camera_set.indexOf(currCameraId);
        if (indx == -1) {
            Log.e(TAG, "camera id not in current camera set");
            // this shouldn't happen, but if it does, revert to the first camera id in the set
            cameraId = camera_set.get(0);
        } else {
            indx = (indx + 1) % camera_set.size();
            cameraId = camera_set.get(indx);
        }
        if (MyDebug.LOG)
            Log.d(TAG, "next multi cameraId: " + cameraId);
        return cameraId;
    }

    private void pushCameraIdToast(int i) {

    }

    public void clickedPauseVideo(View view) {
        Log.d(TAG, "clickedPauseVideo");
        if (this.preview.isVideoRecording()) {
            this.preview.pauseVideo();
            this.mainUI.setPauseVideoContentDescription();
        }
    }

    private boolean checkDisableGUIIcons() {
        Log.d(TAG, "checkDisableGUIIcons");
        boolean z = false;
        if (!showSwitchMultiCamIcon()) {
            View findViewById = findViewById(R.id.liMultiCamera);
            if (findViewById.getVisibility() != View.GONE) {
                z = true;
            }
            findViewById.setVisibility(View.GONE);
        }
        return z;
    }

    public void clearFolderHistory() {
        Log.d(TAG, "clearFolderHistory");
        this.save_location_history.clearFolderHistory(getStorageUtils().getSaveLocation());
    }

    public void clearFolderHistorySAF() {
        Log.d(TAG, "clearFolderHistorySAF");
        this.save_location_history_saf.clearFolderHistory(getStorageUtils().getSaveLocationSAF());
    }

    private static void putBundleExtra(Bundle bundle, String str, List<String> list) {
        if (list != null) {
            String[] strArr = new String[list.size()];
            int i = 0;
            for (String str2 : list) {
                strArr[i] = str2;
                i++;
            }
            bundle.putStringArray(str, strArr);
        }
    }

    public void clickedShare(View view) {
        Log.d(TAG, "clickedShare");
        //TODO Method not decompile
//        this.applicationInterface.shareLastImage();
    }

    public void clickedTrash(View view) {
        Log.d(TAG, "clickedTrash");
        this.applicationInterface.trashLastImage();
    }

    public void takePicture(boolean photo_snapshot) {
        Log.d(TAG, "takePicture");
        if (this.applicationInterface.getPhotoMode() == MyApplicationInterface.PhotoMode.Panorama) {
            if (this.preview.isTakingPhoto()) {
                Log.e(TAG, "-*-*-*-*-*-**-*ignore whilst taking panorama photo");
            } else if (this.applicationInterface.getGyroSensor().isRecording()) {
                Log.e(TAG, "-*-*-*-*-*-**-*panorama complete");
                this.applicationInterface.finishPanorama();
                return;
            } else if (!this.applicationInterface.canTakeNewPhoto()) {
                Log.e(TAG, "-*-*-*-*-*-**-*can't start new panoroma, still saving in background");
            } else {
                Log.e(TAG, "-*-*-*-*-*-**-*start panorama");
                this.applicationInterface.startPanorama();
            }
        }
        takePicturePressed(photo_snapshot, false);
    }

    public boolean lastContinuousFastBurst() {
        return this.last_continuous_fast_burst;
    }

    public void takePicturePressed(boolean photo_snapshot, boolean z2) {
        Log.d(TAG, "takePicturePressed");
        closePopup();
        this.last_continuous_fast_burst = z2;
        this.preview.takePicturePressed(photo_snapshot, z2);
    }

    public void lockScreen() {
        this.screen_is_locked = true;
    }

    public void unlockScreen() {
        this.screen_is_locked = false;
    }

    public boolean isScreenLocked() {
        return this.screen_is_locked;
    }


    public void onSaveInstanceState(Bundle bundle) {
        Log.d(TAG, "onSaveInstanceState");
        super.onSaveInstanceState(bundle);
        Preview preview2 = this.preview;
        if (preview2 != null) {
            preview2.onSaveInstanceState(bundle);
        }
        MyApplicationInterface myApplicationInterface = this.applicationInterface;
        if (myApplicationInterface != null) {
            myApplicationInterface.onSaveInstanceState(bundle);
        }
    }

    public boolean supportsExposureButton() {
        if (this.preview.getCameraController() == null || this.preview.isVideoHighSpeed()) {
            return false;
        }
        boolean z = !PreferenceManager.getDefaultSharedPreferences(this).getString(PreferenceKeys.ISOPreferenceKey, "auto").equals("auto");
        if (this.preview.supportsExposures() || (z && this.preview.supportsISORange())) {
            return true;
        }
        return false;
    }

    public void cameraSetup() {
        Log.d(TAG, "cameraSetup");
        long currentTimeMillis = System.currentTimeMillis();
        if (supportsForceVideo4K() && this.preview.usingCamera2API()) {
            Log.d(TAG, "using Camera2 API, so can disable the force 4K option");
            disableForceVideo4K();
        }
        if (supportsForceVideo4K() && this.preview.getVideoQualityHander().getSupportedVideoSizes() != null) {
            for (CameraController.Size next : this.preview.getVideoQualityHander().getSupportedVideoSizes()) {
                if (next.width >= 3840 && next.height >= 2160) {
                    Log.d(TAG, "camera natively supports 4K, so can disable the force option");
                    disableForceVideo4K();
                }
            }
        }
        Log.d(TAG, "cameraSetup: time after handling Force 4K option: " + (System.currentTimeMillis() - currentTimeMillis));
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        Log.d(TAG, "set up zoom");
        Log.d(TAG, "has_zoom? " + this.preview.supportsZoom());
        ZoomControls zoomControls = (ZoomControls) findViewById(R.id.zoom);
        SeekBar seekBar = (SeekBar) findViewById(R.id.zoom_seekbar);
        if (this.preview.supportsZoom()) {
            if (defaultSharedPreferences.getBoolean(PreferenceKeys.ShowZoomControlsPreferenceKey, false)) {
                zoomControls.setIsZoomInEnabled(true);
                zoomControls.setIsZoomOutEnabled(true);
                zoomControls.setZoomSpeed(20);
                zoomControls.setOnZoomInClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        CameraActivity.this.zoomIn();
                    }
                });
                zoomControls.setOnZoomOutClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        CameraActivity.this.zoomOut();
                    }
                });

                if (!this.mainUI.inImmersiveMode()) {
                    zoomControls.setVisibility(View.VISIBLE);
                }

            } else {
                zoomControls.setVisibility(View.GONE);
            }
            seekBar.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener) null);
            seekBar.setMax(this.preview.getMaxZoom());
            seekBar.setProgress(this.preview.getMaxZoom() - this.preview.getCameraController().getZoom());
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                }

                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    Log.d(CameraActivity.TAG, "zoom onProgressChanged: " + i);
                    CameraActivity.this.preview.zoomTo(CameraActivity.this.preview.getMaxZoom() - i);
                }
            });
            if (!defaultSharedPreferences.getBoolean(PreferenceKeys.ShowZoomSliderControlsPreferenceKey, false)) {
                seekBar.setVisibility(View.INVISIBLE);
            } else if (!this.mainUI.inImmersiveMode()) {
                seekBar.setVisibility(View.VISIBLE);
            }
        } else {
            zoomControls.setVisibility(View.GONE);
            seekBar.setVisibility(View.INVISIBLE);
        }
        Log.d(TAG, "cameraSetup: time after setting up zoom: " + (System.currentTimeMillis() - currentTimeMillis));
        View findViewById = findViewById(R.id.take_photo);

        if (!defaultSharedPreferences.getBoolean(PreferenceKeys.ShowTakePhotoPreferenceKey, true)) {
            findViewById.setVisibility(View.INVISIBLE);
        } else if (!this.mainUI.inImmersiveMode()) {
            findViewById.setVisibility(View.VISIBLE);
        }

        Log.d(TAG, "set up manual focus");
        setManualFocusSeekbar(false);
        setManualFocusSeekbar(true);
        Log.d(TAG, "cameraSetup: time after setting up manual focus: " + (System.currentTimeMillis() - currentTimeMillis));

        setManualWBSeekbar();
        Log.d(TAG, "cameraSetup: time after setting up iso: " + (System.currentTimeMillis() - currentTimeMillis));
        Log.d(TAG, "cameraSetup: time after setting up exposure: " + (System.currentTimeMillis() - currentTimeMillis));
        if (checkDisableGUIIcons()) {
            Log.d(TAG, "cameraSetup: need to layoutUI as we hid some icons");
            this.mainUI.layoutUI();
        }
        this.mainUI.updateOnScreenIcons();
        Log.d(TAG, "cameraSetup: time after setting popup icon: " + (System.currentTimeMillis() - currentTimeMillis));

        this.mainUI.setTakePhotoIcon();
        this.mainUI.setSwitchCameraContentDescription();

        Log.d(TAG, "cameraSetup: time after setting take photo icon: " + (System.currentTimeMillis() - currentTimeMillis));
        Log.d(TAG, "cameraSetup: total time for cameraSetup: " + (System.currentTimeMillis() - currentTimeMillis));

    }

    private void setManualFocusSeekbar(boolean z) {
        Log.d(TAG, "setManualFocusSeekbar");
        setManualFocusSeekBarVisibility(z);
    }

    public void setManualFocusSeekBarVisibility(boolean z) {
        boolean z2 = true;
        boolean z3 = this.preview.getCurrentFocusValue() != null && getPreview().getCurrentFocusValue().equals("focus_mode_manual2");
        if (z) {
            if (!z3 || this.applicationInterface.getPhotoMode() != MyApplicationInterface.PhotoMode.FocusBracketing || this.preview.isVideo()) {
                z2 = false;
            }
            boolean z4 = z2;
        }
    }

    public void setManualWBSeekbar() {
        Log.d(TAG, "setManualWBSeekbar");
        if (this.preview.getSupportedWhiteBalances() != null && this.preview.supportsWhiteBalanceTemperature()) {
            Log.d(TAG, "set up manual white balance");
            this.preview.getMinimumWhiteBalanceTemperature();
            this.preview.getMaximumWhiteBalanceTemperature();
        }
    }

    public boolean supportsAutoStabilise() {
        if (!this.applicationInterface.isRawOnly() && this.applicationInterface.getPhotoMode() != MyApplicationInterface.PhotoMode.Panorama) {
            return this.supports_auto_stabilise;
        }
        return false;
    }

    public boolean supportsDRO() {
        if (!this.applicationInterface.isRawOnly(MyApplicationInterface.PhotoMode.DRO) && Build.VERSION.SDK_INT >= 21) {
            return true;
        }
        return false;
    }

    public boolean supportsHDR() {
        return Build.VERSION.SDK_INT >= 21 && this.large_heap_memory >= 128 && this.preview.supportsExpoBracketing();
    }

    public boolean supportsExpoBracketing() {
        if (this.applicationInterface.isImageCaptureIntent()) {
            return false;
        }
        return this.preview.supportsExpoBracketing();
    }

    public boolean supportsFocusBracketing() {
        if (this.applicationInterface.isImageCaptureIntent()) {
            return false;
        }
        return this.preview.supportsFocusBracketing();
    }

    public boolean supportsPanorama() {
        if (!this.applicationInterface.isImageCaptureIntent() && Build.VERSION.SDK_INT >= 21 && this.large_heap_memory >= 256 && this.applicationInterface.getGyroSensor().hasSensors()) {
            return true;
        }
        return false;
    }

    public boolean hasAudioControl() {
        String string = PreferenceManager.getDefaultSharedPreferences(this).getString(PreferenceKeys.AudioControlPreferenceKey, "none");
        if (string.equals("voice")) {
            return this.speechControl.hasSpeechRecognition();
        }
        return string.equals("noise");
    }

    public boolean showSwitchMultiCamIcon() {
        if (isMultiCamEnabled()) {
            int cameraId = getActualCameraId();
            switch (preview.getCameraControllerManager().getFacing(cameraId)) {
                case FACING_BACK:
                    if (back_camera_ids.size() > 0)
                        return true;
                    break;
                case FACING_FRONT:
                    if (front_camera_ids.size() > 0)
                        return true;
                    break;
                default:
                    if (other_camera_ids.size() > 0)
                        return true;
                    break;
            }
        }
        return false;
    }

    public boolean supportsFastBurst() {
        if (!this.applicationInterface.isImageCaptureIntent() && this.preview.usingCamera2API() && this.large_heap_memory >= 512 && this.preview.supportsBurst()) {
            return true;
        }
        return false;
    }

    public boolean supportsNoiseReduction() {
        return Build.VERSION.SDK_INT >= 24 && this.preview.usingCamera2API() && this.large_heap_memory >= 512 && this.preview.supportsBurst() && this.preview.supportsExposureTime();
    }

    public boolean supportsBurstRaw() {
        return this.large_heap_memory >= 512;
    }

    public boolean supportsPreviewBitmaps() {
        return Build.VERSION.SDK_INT >= 21 && (this.preview.getView() instanceof TextureView) && this.large_heap_memory >= 128;
    }

    private int maxExpoBracketingNImages() {
        return this.preview.maxExpoBracketingNImages();
    }

    public boolean supportsForceVideo4K() {
        return this.supports_force_video_4k;
    }

    public boolean supportsCamera2() {
        return this.supports_camera2;
    }

    private void disableForceVideo4K() {
        this.supports_force_video_4k = false;
    }

    public Preview getPreview() {
        return this.preview;
    }

    public boolean showManualFocusSeekbar(boolean z) {
        boolean z2 = true;
        boolean z3 = this.preview.getCurrentFocusValue() != null && getPreview().getCurrentFocusValue().equals("focus_mode_manual2");
        if (!z) {
            return z3;
        }
        if (!z3 || this.applicationInterface.getPhotoMode() != MyApplicationInterface.PhotoMode.FocusBracketing || this.preview.isVideo()) {
            z2 = false;
        }
        return z2;
    }

    public boolean isCameraInBackground() {
        return this.camera_in_background;
    }

    public boolean isAppPaused() {
        return this.app_is_paused;
    }

    public BluetoothRemoteControl getBluetoothRemoteControl() {
        return this.bluetoothRemoteControl;
    }

    public PermissionHandler getPermissionHandler() {
        return this.permissionHandler;
    }

    public SettingsManager getSettingsManager() {
        return this.settingsManager;
    }

    public MainUI getMainUI() {
        return this.mainUI;
    }

    public ManualSeekbars getManualSeekbars() {
        return this.manualSeekbars;
    }

    public MyApplicationInterface getApplicationInterface() {
        return this.applicationInterface;
    }

    public TextFormatter getTextFormatter() {
        return this.textFormatter;
    }

    public SoundPoolManager getSoundPoolManager() {
        return this.soundPoolManager;
    }

    public LocationSupplier getLocationSupplier() {
        return this.applicationInterface.getLocationSupplier();
    }

    public StorageUtils getStorageUtils() {
        return this.applicationInterface.getStorageUtils();
    }

    public File getImageFolder() {
        return this.applicationInterface.getStorageUtils().getImageFolder();
    }

    public ToastBoxer getChangedAutoStabiliseToastBoxer() {
        return this.changed_auto_stabilise_toast;
    }

    private void freeAudioListener(boolean z) {
        Log.d(TAG, "freeAudioListener");
        AudioListener audioListener = this.audio_listener;
        if (audioListener != null) {
            audioListener.release(z);
            this.audio_listener = null;
        }
    }

    public void stopAudioListeners() {
        freeAudioListener(true);
        if (this.speechControl.hasSpeechRecognition()) {
            this.speechControl.stopListening();
        }
    }

    private void initGyroSensors() {
        Log.d(TAG, "initGyroSensors");
        if (this.applicationInterface.getPhotoMode() == MyApplicationInterface.PhotoMode.Panorama) {
            this.applicationInterface.getGyroSensor().enableSensors();
        } else {
            this.applicationInterface.getGyroSensor().disableSensors();
        }
    }

    public void speak(String str) {
        TextToSpeech textToSpeech2 = this.textToSpeech;
        if (textToSpeech2 != null && this.textToSpeechSuccess) {
            textToSpeech2.speak(str, 0, (HashMap) null);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.d(TAG, "onRequestPermissionsResult: requestCode " + requestCode);
        this.permissionHandler.onRequestPermissionsResult(requestCode, grantResults);
    }

    public void restartOpenCamera() {
        Log.d(TAG, "restartOpenCamera");
        waitUntilImageQueueEmpty();
        Intent launchIntentForPackage = getBaseContext().getPackageManager().getLaunchIntentForPackage(getBaseContext().getPackageName());
        launchIntentForPackage.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(launchIntentForPackage);
    }

    public void takePhotoButtonLongClickCancelled() {
        Log.d(TAG, "takePhotoButtonLongClickCancelled");
        if (this.preview.getCameraController() != null && this.preview.getCameraController().isContinuousBurstInProgress()) {
            this.preview.getCameraController().stopContinuousBurst();
        }
    }

    public ToastBoxer getAudioControlToast() {
        return this.audio_control_toast;
    }

    public SaveLocationHistory getSaveLocationHistory() {
        return this.save_location_history;
    }

    public SaveLocationHistory getSaveLocationHistorySAF() {
        return this.save_location_history_saf;
    }

    public void usedFolderPicker() {
        if (this.applicationInterface.getStorageUtils().isUsingSAF()) {
            this.save_location_history_saf.updateFolderHistory(getStorageUtils().getSaveLocationSAF(), true);
        } else {
            this.save_location_history.updateFolderHistory(getStorageUtils().getSaveLocation(), true);
        }
    }

    public boolean hasThumbnailAnimation() {
        return this.applicationInterface.hasThumbnailAnimation();
    }


    public boolean checkStoragePermission() {
        boolean z = ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0;
        if (ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            z = false;
        }
        if (ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") != 0) {
            return false;
        }
        return z;
    }

    public boolean checkLocationPermission() {
        boolean z = ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0;
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") != 0) {
            return false;
        }
        return z;
    }

    public static boolean useScopedStorage() {
        return Build.VERSION.SDK_INT >= 30;
    }

    private void checkSaveLocations() {
        boolean z;
        String str;
        Log.d(TAG, "checkSaveLocations");
        if (useScopedStorage()) {
            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            String saveLocation = getStorageUtils().getSaveLocation();
            CheckSaveLocationResult checkSaveLocation = checkSaveLocation(saveLocation);
            if (!checkSaveLocation.res) {
                Log.d(TAG, "save_location not valid with scoped storage: " + saveLocation);
                if (checkSaveLocation.alt == null) {
//                    str = "VoiceGps";
                    str = "StampCamera";
                } else {
                    Log.d(TAG, "alternative: " + checkSaveLocation.alt);
                    str = checkSaveLocation.alt;
                }
                SharedPreferences.Editor edit = defaultSharedPreferences.edit();
                edit.putString(PreferenceKeys.SaveLocationPreferenceKey, str);
                edit.apply();
                z = true;
            } else {
                z = false;
            }
            for (int size = this.save_location_history.size() - 1; size >= 0; size--) {
                String str2 = this.save_location_history.get(size);
                CheckSaveLocationResult checkSaveLocation2 = checkSaveLocation(str2);
                if (!checkSaveLocation2.res) {
                    Log.d(TAG, "save_location in history " + size + " not valid with scoped storage: " + str2);
                    if (checkSaveLocation2.alt == null) {
                        this.save_location_history.remove(size);
                    } else {
                        Log.d(TAG, "alternative: " + checkSaveLocation2.alt);
                        this.save_location_history.set(size, checkSaveLocation2.alt);
                    }
                    z = true;
                }
            }
            if (z) {
                this.save_location_history.updateFolderHistory(getStorageUtils().getSaveLocation(), false);
            }
        }
    }

    public static class CheckSaveLocationResult {
        final String alt;
        final boolean res;

        public CheckSaveLocationResult(boolean z, String str) {
            this.res = z;
            this.alt = str;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof CheckSaveLocationResult)) {
                return false;
            }
            CheckSaveLocationResult checkSaveLocationResult = (CheckSaveLocationResult) obj;
            if (checkSaveLocationResult.res != this.res) {
                return false;
            }
            String str = checkSaveLocationResult.alt;
            String str2 = this.alt;
            if (str == str2 || (str != null && str.equals(str2))) {
                return true;
            }
            return false;
        }

        public int hashCode() {
            int i = this.res ? 1249 : 1259;
            String str = this.alt;
            return i ^ (str == null ? 0 : str.hashCode());
        }

        public String toString() {
            return "CheckSaveLocationResult{" + this.res + " , " + this.alt + "}";
        }
    }

    public static CheckSaveLocationResult checkSaveLocation(String str) {
        return checkSaveLocation(str, (String) null);
    }

    public static CheckSaveLocationResult checkSaveLocation(String str, String str2) {
        String str3 = null;
        if (!StorageUtils.saveFolderIsFull(str)) {
            return new CheckSaveLocationResult(true, (String) null);
        }
        Log.d(TAG, "checkSaveLocation for full path: " +
                "" + str);
        if (str2 == null) {
            str2 = StorageUtils.getBaseFolder().getAbsolutePath();
        }
        if (str2.length() >= 1 && str2.charAt(str2.length() - 1) == '/') {
            str2 = str2.substring(0, str2.length() - 1);
        }
        Log.d(TAG, "    compare to base_folder: " + str2);
        if (str.startsWith(str2)) {
            str3 = str.substring(str2.length());
            if (str3.length() >= 1 && str3.charAt(0) == '/') {
                str3 = str3.substring(1);
            }
        }
        return new CheckSaveLocationResult(false, str3);
    }

    public Bitmap getCameraSnapShot() {
//        clCustomStamp.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
//        clCustomStamp.layout(0, 0, clCustomStamp.getMeasuredWidth(), clCustomStamp.getMeasuredHeight());
//        Bitmap bitmap = Bitmap.createBitmap(clCustomStamp.getWidth(), clCustomStamp.getHeight(), Bitmap.Config.ARGB_8888);
        Bitmap bitmap = Bitmap.createBitmap(clCameraPreview.getWidth(), clCameraPreview.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

//        clCustomStamp.draw(canvas);
        clCameraPreview.draw(canvas);
        System.gc();

        return bitmap;
    }

    public View getCameraSnapShotView() {
//        return clCustomStamp;
        return clCameraPreview;
    }

    public Float getCameraSnapShotX() {
//        return clCustomStamp.getX();
        return clCameraPreview.getX();
    }

    public Float getCameraSnapShotY() {
//        return clCustomStamp.getY();
        return clCameraPreview.getY();
    }

    public int getCameraCurrentOrientation() {
        return current_orientation;
    }
}