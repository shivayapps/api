package com.gallery.photo.image.video.Camera;

import android.content.Intent;
import android.os.Build;
import android.service.quicksettings.TileService;
import android.util.Log;

import androidx.annotation.RequiresApi;

@RequiresApi(api = Build.VERSION_CODES.N)
public class MyTileServiceFrontCamera extends TileService {
    private static final String TAG = "MyTileServiceFrontCam";
    public static final String TILE_ID = "net.sourceforge.opencamera.TILE_FRONT_CAMERA";

    public void onDestroy() {
        super.onDestroy();
    }

    public void onTileAdded() {
        super.onTileAdded();
    }

    public void onTileRemoved() {
        super.onTileRemoved();
    }

    public void onStartListening() {
        super.onStartListening();
    }

    public void onStopListening() {
        super.onStopListening();
    }

    public void onClick() {
        Log.d(TAG, "onClick");
        super.onClick();
        Intent intent = new Intent(this, CameraActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setAction(TILE_ID);
        startActivity(intent);
    }
}
