package com.gallery.photo.image.video.activities

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.PorterDuff
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.core.view.allViews
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.viewpager.widget.ViewPager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobNative
import com.adconfig.adsutil.admob.BannerAdHelper
//import com.example.mycallstate.PhoneStateForegroundService
//import com.example.mycallstate.preferences.PrefCalls
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.install.model.InstallStatus
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activities.exploremap.MapAlbumActivity
import com.gallery.photo.image.video.activities.setup.LanguageActivity
import com.gallery.photo.image.video.inapp_helper.AppUpdateInstallerListener
import com.gallery.photo.image.video.inapp_helper.AppUpdateInstallerManager
import com.gallery.photo.image.video.inapp_helper.InAppUpdateInstallerManager
import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.browser.WebBrowserActivity
import com.gallery.photo.image.video.databinding.ActivityHomeBinding
import com.gallery.photo.image.video.databinding.DialogExitBinding
import com.gallery.photo.image.video.databinding.HomeMenuFilterBinding
import com.gallery.photo.image.video.databinding.PopBottomMenuBinding
import com.gallery.photo.image.video.dialog.ConfirmationDialog

import com.gallery.photo.image.video.dialog.CreateAlbumDialog
import com.gallery.photo.image.video.dialog.DisplayedColumnsDialog
import com.gallery.photo.image.video.dialog.FilterMediaDialog
import com.gallery.photo.image.video.dialog.GroupDialog
import com.gallery.photo.image.video.dialog.HomeMenuDialog
import com.gallery.photo.image.video.dialog.SortDialog
import com.gallery.photo.image.video.extension.beGone
import com.gallery.photo.image.video.extension.beVisible
import com.gallery.photo.image.video.extension.beVisibleIf
import com.gallery.photo.image.video.extension.scanPathRecursively
import com.gallery.photo.image.video.extension.toast
import com.gallery.photo.image.video.fragment.AlbumFragment
import com.gallery.photo.image.video.fragment.PhotosFragment
import com.gallery.photo.image.video.jobs.NewPhotoFetcher
import com.gallery.photo.image.video.mainduplicate.DuplicateFinderActivity
import com.gallery.photo.image.video.model.AlbumData
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.notes.NotesActivity
import com.gallery.photo.image.video.secret.activity.LockActivity
import com.gallery.photo.image.video.secret.activity.PrivateActivity
import com.gallery.photo.image.video.secret.activity.SelectImageActivity
import com.gallery.photo.image.video.utils.AdCache
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.PopupWindowHelper
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.TYPE_GIFS
import com.gallery.photo.image.video.utils.TYPE_IMAGES
//import com.gallery.photo.image.video.utils.TYPE_PORTRAITS
//import com.gallery.photo.image.video.utils.TYPE_RAWS
//import com.gallery.photo.image.video.utils.TYPE_SVGS
import com.gallery.photo.image.video.utils.TYPE_VIDEOS
import com.gallery.photo.image.video.utils.ensureBackgroundThread
import com.gallery.photo.image.video.utils.isNougatPlus
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.single.PermissionListener

class HomeActivity : BaseActivity() {

    lateinit var preferences: Preferences

    //    lateinit var adsPref: PrefCalls
    lateinit var photosFragment: PhotosFragment
    lateinit var albumFragment: AlbumFragment
//    lateinit var expoloreFragment: ExploreFragment

    val pinList: ArrayList<String> = ArrayList()

    var isSelectAll = false
    var imageFilePath = ""
    var tabPos = 0

    lateinit var binding: ActivityHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        preferences = Preferences(this)
        loadBannerAds()
        initView()
        startNewPhotoFetcher()
        startCleanRecycleBin()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestNotification()
        }
    }


    private fun requestNotification() {
        Dexter.withContext(this@HomeActivity)
            .withPermission(
                Manifest.permission.POST_NOTIFICATIONS
            )
            .withListener(object : PermissionListener {
                override fun onPermissionGranted(p0: PermissionGrantedResponse?) {
                }

                override fun onPermissionDenied(p0: PermissionDeniedResponse?) {
                }

                override fun onPermissionRationaleShouldBeShown(p0: PermissionRequest?, p1: PermissionToken?) {
                }

            }).check()
    }

    private fun initView() {
//        adsPref = PrefCalls(this)

        Log.e("RateTag", "intView isReCreateHomeSS ${Constant.isReCreateHomeSS}")
        if (Constant.isReCreateHomeSS) {
            Constant.isReCreateHomeSS = false
        } else {
            var appOpenCounter = preferences.appOpenCounter
            appOpenCounter++
            preferences.appOpenCounter = appOpenCounter
        }

        if (preferences.isFirstTimeInstall) {
            preferences.isFirstTimeInstall = false
        }

//        needDialog = adsPref.firstTimeDialog
//        CoroutineScope(Dispatchers.IO).launch {
        setTab()
        setToolbarSelectionMaintain(false, 0, false)
//        }

        intListener()
        checkAppUpdate()

//        val serviceIntent = Intent(
//            this,
//            PhoneStateForegroundService::class.java
//        )
//        startService(serviceIntent)
//        checkCaller()

    }


//    var needDialog = true
//    private fun checkCaller() {
//        Log.e("checkCaller", "001")
//        val readPhoneState =
//            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
//        val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            Settings.canDrawOverlays(this)
//        } else {
//            true
//        }
//        binding.icCall.beVisibleIf(!adsPref.isShowCallInfo)
//
//        Log.e("checkCaller", "readPhoneState:$readPhoneState")
//        Log.e("checkCaller", "canDrawOverlays:$canDrawOverlays")
//
//        if (readPhoneState && canDrawOverlays) {
////            binding.icCall.beGone()
//            Log.e("checkCaller", "readPhoneState && canDrawOverlays")
//        } else {
////            binding.icCall.beVisible()
//            Log.e(
//                "checkCaller",
//                "preferences.needToShowCallerCad:${adsPref.needToShowCallerCad}"
//            )
//            Log.e(
//                "checkCaller",
//                "preferences.isCallDialogClosable:${adsPref.isCallDialogClosable}"
//            )
//            Log.e(
//                "checkCaller",
//                "preferences.closeCounter:${adsPref.closeCounter}"
//            )
//            if (adsPref.needToShowCallerCad && adsPref.closeCounter < 2) {
//                if (!adsPref.isCallDialogClosable) {
//                    showCallPermissionDialog()
//                } else if (needDialog) {
//                    adsPref.firstTimeDialog = false
//                    showCallPermissionDialog()
//                }
//            }
//        }
//    }

//    private fun requestSystemOverlayPermission() {
//        AdsConfig.isSystemDialogOpen = true
//
//        val intent = Intent(
//            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
//            Uri.parse("package:" + applicationContext.packageName)
//        )
//
////        val countDownTimerOverlay = object : CountDownTimer(50000L, 1) {
////            override fun onTick(l: Long) {
////                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
////                    if (Settings.canDrawOverlays(this@HomeActivity)) {
////
////                        val readPhoneState =
////                            ContextCompat.checkSelfPermission(
////                                this@HomeActivity,
////                                Manifest.permission.READ_PHONE_STATE
////                            ) == 0
////                        val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
////                            Settings.canDrawOverlays(this@HomeActivity)
////                        } else {
////                            true
////                        }
////                        if (readPhoneState && canDrawOverlays) {
////                            adsPref.isShowCallInfo = true
////                            //binding.cbCall.isChecked = true
////                        }
////                        binding.icCall.beVisibleIf(!adsPref.isShowCallInfo)
////
////                        AdsConfig.isSystemDialogOpen = true
////                        val intentHome = Intent(this@HomeActivity, HomeActivity::class.java)
////                        intentHome.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
////                        startActivity(intentHome)
////                        cancel()
////                    } else {
//////                    customPermissionEvent("home_draw_over_denied")
////                    }
////                }
////            }
////
////            override fun onFinish() {
////
////            }
////        }
////        countDownTimerOverlay.start()
//
//        try {
//            startActivityForResult(intent, 101)
//        } catch (e: Exception) {
//            Log.e("printStackTrace", "printStackTrace:$e")
//        }
//
//        Handler(Looper.getMainLooper()).postDelayed({
//            val intent1 = Intent(this@HomeActivity, SettingPermissionActivity::class.java)
//            intent1.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
//            startActivity(intent1)
//        }, 500)
//
//    }

//    private fun showCallPermissionDialog() {
//        Log.e("checkCaller", "preferences.showCallPermissionDialog")
//        val dialogBuilder = androidx.appcompat.app.AlertDialog.Builder(this@HomeActivity)
//        val view = layoutInflater.inflate(
//            R.layout.dialog_call_permission,
//            null
//        )
//        dialogBuilder.setView(view)
//        val dialog = dialogBuilder.create()
//
//        dialog.setCanceledOnTouchOutside(false)
//        val btnPermission =
//            view.findViewById<AppCompatButton>(R.id.btnPermission)
//        val imgClose =
//            view.findViewById<ShapeableImageView>(R.id.imgClose)
//
//        if (adsPref.isCallDialogClosable) {
//            imgClose.visibility = View.VISIBLE
//        } else {
//            imgClose.visibility = View.GONE
//        }
//
//        imgClose.setOnClickListener { view1: View? ->
//            if (!adsPref.isCallDialogClosable) {
//                val calendar = Calendar.getInstance()
//                val format = SimpleDateFormat("dd/mm/yy", Locale.ENGLISH)
//                val today = format.format(calendar.timeInMillis)
//                LogEvent.logEvent("CallerDialog", "main_back_pressed_exit:$today")
////                ApplicationClass.isNeedToShowAppOpen = false
//                AdsConfig.isSystemDialogOpen = true
//                finishAffinity()
//            }
//
//            dialog.dismiss()
//        }
//        btnPermission.setOnClickListener { view1: View? ->
//            AdsConfig.isSystemDialogOpen = true
//            Dexter.withContext(this@HomeActivity).withPermission(
//                Manifest.permission.READ_PHONE_STATE
//            ).withListener(object : PermissionListener {
//                override fun onPermissionGranted(permissionGrantedResponse: PermissionGrantedResponse) {
//                    if (Settings.canDrawOverlays(this@HomeActivity)) {
//                        val readPhoneState =
//                            ContextCompat.checkSelfPermission(
//                                this@HomeActivity,
//                                Manifest.permission.READ_PHONE_STATE
//                            ) == 0
//                        val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                            Settings.canDrawOverlays(this@HomeActivity)
//                        } else {
//                            true
//                        }
//                        if (readPhoneState && canDrawOverlays) {
//                            adsPref.isShowCallInfo = true
//                        }
//                        binding.icCall.beVisibleIf(!adsPref.isShowCallInfo)
//                        dialog.dismiss()
//                    } else {
//                        dialog.dismiss()
//                        requestSystemOverlayPermission()
//                    }
////                    requestSystemOverlayPermission()
//                }
//
//                override fun onPermissionDenied(permissionDeniedResponse: PermissionDeniedResponse) {
//
//                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
//                    val uri = Uri.fromParts("package", packageName, null)
//                    intent.data = uri
//                    callerLauncher.launch(intent)
//                    AdsConfig.isSystemDialogOpen = true
//                    Toast.makeText(
//                        view.getContext(),
//                        "Please allow phone permission to enable feature",
//                        Toast.LENGTH_SHORT
//                    ).show();
//                    dialog.dismiss()
//                }
//
//                override fun onPermissionRationaleShouldBeShown(
//                    permissionRequest: PermissionRequest,
//                    permissionToken: PermissionToken,
//                ) {
//                    permissionToken.continuePermissionRequest()
//                }
//            }).check()
//        }
//        dialog.setOnDismissListener { dialogInterface: DialogInterface? ->
//            val readPhoneState =
//                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
//            val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                Settings.canDrawOverlays(this)
//            } else {
//                true
//            }
//            if (readPhoneState && canDrawOverlays) {
//                adsPref.isShowCallInfo = true
//                if (adsPref.isShowCallInfo) {
//                    binding.icCall.visibility = View.GONE
//                } else {
//                    binding.icCall.visibility = View.VISIBLE
//                }
//                Log.e("checkCaller", "readPhoneState && canDrawOverlays")
//            } else {
//                adsPref.isShowCallInfo = false
//            }
//
////            if (!adsPref.isCallDialogClosable) {
////                val calendar = Calendar.getInstance()
////                val format = SimpleDateFormat("dd/mm/yy", Locale.ENGLISH)
////                val today = format.format(calendar.timeInMillis)
////                logEvent("CallerDialog", "main_back_pressed_exit:$today")
////                ApplicationClass.isNeedToShowAppOpen = false
//////                AdsConfig.isSystemDialogOpen = true
//////                finishAffinity()
////            } else {
////                dialog.dismiss()
////            }
//        }
////        dialog.window?.attributes?.windowAnimations = R.style.FullScreenDialog_Slide
//        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        if (!isFinishing && !isDestroyed) {
//            AdsConfig.isSystemDialogOpen = true
//            dialog.show()
//        }
//    }

    private fun startCleanRecycleBin() {
        if (preferences.deleteAfter30Days) {
            val autoCleanTrash =
                com.gallery.photo.image.video.asynctasks.AutoCleanTrashAsyncTask(
                    this,
                    Constant.DELETE_PATH,
                    30
                )
            autoCleanTrash.execute()
        }
    }

    private fun startNewPhotoFetcher() {
        if (isNougatPlus()) {
            val photoFetcher = NewPhotoFetcher()
            if (!photoFetcher.isScheduled(applicationContext)) {
                photoFetcher.scheduleJob(applicationContext)
            }
        }
    }

    private fun setTab() {
        binding.groupToolbarHeader.visibility = View.VISIBLE
        val adapter = ViewPagerAdapter(this, supportFragmentManager)
        albumFragment = AlbumFragment()
        photosFragment = PhotosFragment()
//        expoloreFragment = ExploreFragment()

//        binding.viewPager.isUserInputEnabled =false
        adapter.addFragment(albumFragment)
        adapter.addFragment(photosFragment)
//        adapter.addFragment(expoloreFragment)
        albumFragment.mActivity = this@HomeActivity
        photosFragment.mActivity = this@HomeActivity
//        expoloreFragment.mActivity = this@HomeActivity

        binding.viewPager.offscreenPageLimit = 3
        binding.viewPager.adapter = adapter

        binding.bottomNavigation.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.tab1 -> {
                    binding.viewPager.currentItem = 0
                }

                R.id.tab2 -> {
                    binding.viewPager.currentItem = 1
                }

//                R.id.tab3 -> {
//                    binding.viewPager.currentItem = 2
//                }

                else -> {
                    binding.viewPager.currentItem = 0
                }
            }
            true
        }

        binding.viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {

            }

            override fun onPageSelected(position: Int) {
                when (position) {
                    0 -> {
                        setEmptyData(albumFragment.isEmpty)
                        binding.bottomNavigation.selectedItemId = R.id.tab1
                    }

                    1 -> {
                        setEmptyData(photosFragment.isEmpty)
                        binding.bottomNavigation.selectedItemId = R.id.tab2
                    }

//                    2 -> {
//                        var isEmpty = false
//                        if (albumFragment != null && photosFragment != null) {
//                            isEmpty = albumFragment.isEmpty && photosFragment.isEmpty
//                        }
//                        setEmptyData(isEmpty)
//
//                        binding.bottomNavigation.selectedItemId = R.id.tab3
//                    }
                }
//                binding.loutTab.onPageSelected(position)
                tabPos = position

                if (position == 2 && binding.titleSwitcher.displayedChild != 1) {
                    binding.titleSwitcher.displayedChild = 1
                } else if (binding.titleSwitcher.displayedChild == 1) {
                    binding.titleSwitcher.displayedChild = 0
                }

                if (preferences.refreshMedia) {
                    if (albumFragment != null) {
                        albumFragment.getData()
                        preferences.refreshMedia = false
                    }
                }

//                if (position == 2) {
//                    expoloreFragment.getImageOnMap()
//                }

            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })

        var isEmpty = false
        if (albumFragment != null && photosFragment != null) {
            isEmpty = albumFragment.isEmpty && photosFragment.isEmpty
        }
        setEmptyData(isEmpty)
    }

    fun setEmptyData(isEmpty: Boolean) {
//        if (isEmpty) {
//            binding.llAdPlace.beGone()
//        } else {
//            binding.llAdPlace.beVisible()
//        }
    }

    fun updateData() {
        if (albumFragment != null) albumFragment.getData()
    }

    fun longClickListener(isShowSelection: Boolean, selected: Int, isAllSelect: Boolean) {

        if (preferences.refreshMedia) {
            preferences.refreshMedia = false
            if (albumFragment != null) albumFragment.getData()
            if (photosFragment != null) photosFragment.getData()
        }

        setToolbarSelectionMaintain(
            isShowSelection,
            selected,
            isAllSelect
        )
    }


    var needToAddPin = false
    var needToRemovePin = false
    var mSelectedItem = 0
    private fun setToolbarSelectionMaintain(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
        mSelectedItem = selectedItem
        binding.loutToolbar.visibility = View.VISIBLE
        pinList.clear()
        pinList.addAll(preferences.getPinAlbumList())

        needToAddPin = false
        needToRemovePin = false

        if (isShowSelection) {

            binding.btnHide.visibility =
                if (binding.viewPager.currentItem == 2) View.GONE else View.VISIBLE
            binding.btnMore.visibility =
                if (binding.viewPager.currentItem == 2) View.GONE else View.VISIBLE
            binding.btnPin.visibility =
                if (binding.viewPager.currentItem == 0) View.VISIBLE else View.GONE
            binding.btnShare.visibility =
                if (binding.viewPager.currentItem == 0) View.GONE else View.VISIBLE

        }

        if (binding.viewPager.currentItem == 0) {
            val selectedAlbum = albumFragment.getSelected()
//            val selectImage: ArrayList<PictureData> = ArrayList()
            for (i in selectedAlbum.indices) {
                val model: AlbumData = selectedAlbum[i] as AlbumData
                if (pinList.contains(model.folderPath))
                    needToRemovePin = true
                else
                    needToAddPin = true
            }
        }

        if (needToAddPin && needToRemovePin) {
            binding.btnPin.alpha = 0.5F
        } else if (needToAddPin) {
            binding.btnPin.alpha = 1.0F
            binding.txtPin.text = getString(R.string.pin)
        } else if (needToRemovePin) {
            binding.btnPin.alpha = 1.0F
            binding.txtPin.text = getString(R.string.unpin)
        }

        if (isShowSelection) setDrawerLock() else setDrawerUnlock()
        binding.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE

//        binding.viewPager.isUserInputEnabled = !isShowSelection
//        binding.viewPager.isEnabled = !isShowSelection
        binding.viewPager.setPagingEnabled(!isShowSelection)
        isSelectAll = isAllSelect


        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE


        if (binding.viewPager.currentItem == 2) {
            binding.groupToolbarSettingHeader.visibility = View.GONE
//            binding.groupToolbarHeaderPrivate.visibility =
//                if (isShowSelection) View.GONE else View.VISIBLE
        } else
            binding.groupToolbarHeader.visibility =
                if (isShowSelection) View.GONE else View.VISIBLE

//        binding.loutTab.visibility = if (isShowSelection) View.GONE else View.VISIBLE
//        binding.cardLoutTab.visibility = if (isShowSelection) View.GONE else View.VISIBLE
        binding.bottomNavigation.visibility = if (isShowSelection) View.GONE else View.VISIBLE
        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
        setSelectAllColor()

    }

    private fun setDrawerLock() {
        binding.drawerLay.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
    }

    private fun setDrawerUnlock() {
        binding.drawerLay.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    fun getAlbumListForSelect() {
        if (albumFragment != null)
            albumFragment.setBackAlbumData()
    }

    override fun onResume() {
        super.onResume()
        setAppTheme()
//        binding.icCall.beVisibleIf(!adsPref.isShowCallInfo)
        if (preferences.refreshMedia) {
            preferences.refreshMedia = false
            if (albumFragment != null) albumFragment.getData()
            if (photosFragment != null) photosFragment.getData()
        }

        if (preferences.scanMedia) {
            preferences.scanMedia = false
            try {
                ensureBackgroundThread {
                    scanPathRecursively(Constant.ROOT_PATH)
                }
            } catch (e: Exception) {
            }
        }
        mAdView?.resume()
    }

    var isOpenCameraPermission: Boolean = false
    private fun requestPermission() {

        val list: ArrayList<String> = ArrayList()
        if (isOpenCameraPermission) {
            list.add(Manifest.permission.CAMERA)
        } else
            list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            list.add(Manifest.permission.ACCESS_MEDIA_LOCATION)
        }

        Dexter.withContext(this@HomeActivity)
            .withPermissions(
                list
            )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    report?.let {
                        if (report.areAllPermissionsGranted()) {
                            openCamera()
                        } else if (report.isAnyPermissionPermanentlyDenied) {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            val uri = Uri.fromParts("package", packageName, null)
                            intent.data = uri
                            AdsConfig.isSystemDialogOpen = true
//            AdconfigApplication.disabledOpenAds()
                            permissionLauncher.launch(intent)
                        } else {
                            toast(
                                if (isOpenCameraPermission) getString(R.string.permission_camera_toast_msg)
                                else getString(R.string.permission_toast_msg)
                            )
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<PermissionRequest>?,
                    token: PermissionToken?
                ) {
                    token?.continuePermissionRequest()
                }
            }).check()

    }

    private fun intListener() {

        binding.icDrawer.setOnClickListener {
            if (binding.drawerLay.isDrawerOpen(GravityCompat.START))
                binding.drawerLay.closeDrawer(GravityCompat.START)
            else binding.drawerLay.openDrawer(GravityCompat.START)
        }

        binding.drawerContent.loutDrawerMain.setOnClickListener {

        }
        intDrawerListener()

        binding.icCamera.setOnClickListener {
//            if (checkCameraPermission())
            openCamera()
//            else {
//                isOpenCameraPermission=true
//                requestPermission()
//            }

        }
        binding.icSearch.setOnClickListener {
            val intent = Intent(this, SearchActivity::class.java)
            startActivity(intent)

        }

//        binding.icSearchClear.setOnClickListener {
//            binding.edtSearch.setText("")
//        }
//
//        binding.icSearchBack.setOnClickListener {
//            onBackPressed()
//        }

//        binding.edtSearch.addTextChangedListener {
//            if (it.isNullOrEmpty()) {
//                setSearch("")
//                binding.icSearchClear.visibility = View.GONE
//            } else {
//                setSearch(it.toString())
//                binding.icSearchClear.visibility = View.VISIBLE
//            }
//        }

        var resultAll = 0
        resultAll += TYPE_IMAGES
        resultAll += TYPE_VIDEOS
        resultAll += TYPE_GIFS
//        resultAll += TYPE_RAWS
//        resultAll += TYPE_SVGS
//        resultAll += TYPE_PORTRAITS

        var resultPhoto = 0
        resultPhoto += TYPE_IMAGES
//        resultPhoto += TYPE_RAWS
//        resultPhoto += TYPE_SVGS
//        resultPhoto += TYPE_PORTRAITS

        var resultVideo = 0
        resultVideo += TYPE_VIDEOS

        var resultGif = 0
        resultGif += TYPE_GIFS

        when (preferences.getFilterMedia()) {
            resultAll -> {
                binding.txtTitle.text = getString(R.string.all)
            }

            resultPhoto -> {
                binding.txtTitle.text = getString(R.string.photos)
            }

            resultVideo -> {
                binding.txtTitle.text = getString(R.string.videos)
            }

            resultGif -> {
                binding.txtTitle.text = getString(R.string.gifs)
            }
        }

        binding.txtTitle.setOnClickListener {
            showHomeMenuFilter(binding.txtTitle)
        }
        binding.icMenu.setOnClickListener {
            showMenu()
        }

        binding.icClose.setOnClickListener {
            if (binding.viewPager.currentItem == 1) {
                photosFragment.setCloseToolbar()
            } else if (binding.viewPager.currentItem == 0) {
                albumFragment.setCloseToolbar()
            }
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            if (binding.viewPager.currentItem == 1) photosFragment.setSelectClick(isSelectAll)
            else if (binding.viewPager.currentItem == 0) albumFragment.setSelectClick(isSelectAll)
            setSelectAllColor()
        }

        binding.btnShare.setOnClickListener {
            if (binding.viewPager.currentItem == 1)
                photosFragment.shareImages()
        }
        binding.btnPin.setOnClickListener {
            if (binding.viewPager.currentItem == 0) {
                if (needToAddPin && needToRemovePin) {
//                    binding.btnPin.alpha=0.5F
                } else if (needToAddPin) {
                    albumFragment.pinAlbum()
//                    binding.btnPin.alpha=1.0F
//                    binding.txtPin.text=getString(R.string.pin)
                } else if (needToRemovePin) {
                    albumFragment.unPinAlbum()
//                    binding.btnPin.alpha=1.0F
//                    binding.txtPin.text=getString(R.string.unpin)
                }
            }
        }

        binding.btnDelete.setOnClickListener {
            if (binding.viewPager.currentItem == 0) {
                albumFragment.showDeleteDialog()
            } else if (binding.viewPager.currentItem == 1)
                photosFragment.showDeleteDialog()

        }
        binding.btnHide.setOnClickListener {
            if (binding.viewPager.currentItem == 0)
                albumFragment.setHideData()
            else if (binding.viewPager.currentItem == 1)
                photosFragment.setHideData()
        }

        binding.btnMore.setOnClickListener {
            showDropDown(binding.btnMore)
        }

    }


    private fun closeDrawer() {
        if (binding.drawerLay.isDrawerOpen(GravityCompat.START)) {
            binding.drawerLay.closeDrawer(GravityCompat.START)
        }
    }

    private fun intDrawerListener() {
        binding.drawerContent.llDwHome.setOnClickListener {
            closeDrawer()
            binding.viewPager.currentItem = 0
        }
        binding.drawerContent.llDwFavourite.setOnClickListener {
            closeDrawer()
            startActivity(Intent(this, FavouriteListActivity::class.java))
            getAlbumListForSelect()

        }

        binding.drawerContent.llDwPrivate.setOnClickListener {
            closeDrawer()
            val intent = Intent(this, LockActivity::class.java)
            lockActivityResultLauncher.launch(intent)
        }
        binding.drawerContent.llDwRecentlyDelete.setOnClickListener {
            startActivity(Intent(this, RecentlyDeleteActivity::class.java))
            closeDrawer()
            getAlbumListForSelect()
        }
        binding.drawerContent.llMaps.setOnClickListener {
            startActivity(Intent(this, MapAlbumActivity::class.java))
        }
        binding.drawerContent.llNote.setOnClickListener {
            startActivity(Intent(this, NotesActivity::class.java))
        }
        binding.drawerContent.llBrowser.setOnClickListener {
            startActivity(Intent(this, WebBrowserActivity::class.java))
        }
//        binding.drawerContent.llHidden.setOnClickListener {
//            val intent = Intent(this, LockActivity::class.java)
//            lockActivityResultLauncher.launch(intent)
//        }
        binding.drawerContent.llTimeLine.setOnClickListener {
            startActivity(Intent(this, TimeLineActivity::class.java))
        }
        binding.drawerContent.llPdf.setOnClickListener {
            val intent = Intent(this, SelectImageActivity::class.java)
            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_PDF)
            intent.putExtra(Constant.EXTRA_INCLUDE_VIDEO, false)
            startActivity(intent)
        }
        binding.drawerContent.llDwDuplicate.setOnClickListener {
            startActivity(Intent(this, DuplicateFinderActivity::class.java))
            closeDrawer()
        }
        binding.drawerContent.llDwTheme.setOnClickListener {
//            val themeDialog = ThemeDialog(updateListener = {
//                val intent = Intent(this, HomeActivity::class.java)
//                finish()
//                overridePendingTransition(0, 0)
//                startActivity(intent)
//                overridePendingTransition(0, 0)
//            })
//            themeDialog.show(supportFragmentManager, themeDialog.tag)
//            closeDrawer()
        }
        binding.drawerContent.llDwSetting.setOnClickListener {
            settingLauncher.launch(Intent(this, SettingActivity::class.java))
            closeDrawer()
        }
        binding.drawerContent.llDwLanguage.setOnClickListener {
            languageLauncher.launch(Intent(this, LanguageActivity::class.java))
            closeDrawer()
        }
        binding.drawerContent.llDwPrivacyPolicy.setOnClickListener {
            openPrivacyPolicy()
            closeDrawer()
        }
    }


    fun openPrivacyPolicy() {
        val url = getPrivacyPolicy()
        if (url != null && url.isNotEmpty()) {
            try {
                val builder: CustomTabsIntent.Builder = CustomTabsIntent.Builder()
                builder.setToolbarColor(ContextCompat.getColor(this, R.color.white))
                AdsConfig.isSystemDialogOpen = true
                val customTabsIntent: CustomTabsIntent = builder.build()
                customTabsIntent.intent.setPackage("com.android.chrome")
                customTabsIntent.launchUrl(this, Uri.parse(url))

            } catch (e: Exception) {
                val i = Intent(Intent.ACTION_VIEW)
                i.data = Uri.parse(url)
                AdsConfig.isSystemDialogOpen = true
                startActivity(i)
            }
        }
    }

    var mAdView: AdView? = null


    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadBannerAds() {
        val isFirstSession = preferences.splashCounter == 1

        val adId = getString(R.string.b_homeActivity)
//            if(AdCache.homeAdView!=null)

        BannerAdHelper.showBanner(this, binding.layoutBanner.mFLAd, binding.llAdPlace, adId,
            AdCache.homeAdView,
            { isLoaded, adView, message ->
                mAdView = adView
                AdCache.homeAdView = adView
            })
    }

    private fun showDropDown(view: View) {

        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)

        val popupWindow =
            com.gallery.photo.image.video.utils.PopupWindowHelper(popUpBinding.root)

        popUpBinding.menuRename.beVisibleIf(mSelectedItem == 1)
        popUpBinding.menuCover.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 0)

//        popUpBinding.menuLock.beVisibleIf(binding.viewPager.currentItem == 0)
        popUpBinding.llMain.beVisible()
        popUpBinding.llCover.beGone()

        var needToAddFav = false
        var needToRemoveFav = false
        var videoSelected = false

        if (binding.viewPager.currentItem == 1) {
            val selectedItem = photosFragment.getSelected()
//            val selectImage: ArrayList<PictureData> = ArrayList()
            for (i in selectedItem.indices) {
                val model: PictureData = selectedItem[i] as PictureData
                if (model.isVideo)
                    videoSelected = true
                if (model.isFavorite)
                    needToRemoveFav = true
                else
                    needToAddFav = true
            }
        }

        popUpBinding.menuEdit.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 1 && !videoSelected)
        popUpBinding.menuPdf.beVisibleIf(binding.viewPager.currentItem == 1 && !videoSelected)
        popUpBinding.menuSetAs.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 1 && !videoSelected)
        popUpBinding.menuResize.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 1 && !videoSelected)
//        popUpBinding.menuAddFavourite.beVisibleIf(binding.viewPager.currentItem == 1 )
//        popUpBinding.menuRemoveFavourite.beVisibleIf(binding.viewPager.currentItem == 1 )
        popUpBinding.menuAddFavourite.beVisibleIf(needToAddFav)
        popUpBinding.menuRemoveFavourite.beVisibleIf(needToRemoveFav)

//        popUpBinding.menuInfo.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 1)
        popUpBinding.menuInfo.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem != 2)

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) {
                if (mSelectedItem == 1) albumFragment.showRenameDialog()
//                else albumFragment.showBatchRenameDialog()
            } else if (binding.viewPager.currentItem == 1) {
                if (mSelectedItem == 1) photosFragment.showRenameDialog()
//                else photosFragment.showBatchRenameDialog()
            }
        }

        popUpBinding.menuCover.setOnClickListener {
//            popupWindow.dismiss()
            popUpBinding.llMain.beGone()
            popUpBinding.llCover.beVisible()
            popupWindow.dismiss()
            popupWindow.showAsPopUp(view)
        }

        popUpBinding.selectPhoto.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0)
                if (mSelectedItem == 1) albumFragment.setCoverImage()

        }
        popUpBinding.useDefault.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0)
                if (mSelectedItem == 1) albumFragment.setDefaultCoverImage()
        }

        popUpBinding.menuEdit.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) photosFragment.openEditor()
        }
        popUpBinding.menuPdf.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) photosFragment.pdfImages()
        }

//        var needToLock = false
//        var needToUnLock = false

//        if (binding.viewPager.currentItem == 0) {
//            val selectedItem = albumFragment.getSelected()
//            for (i in selectedItem.indices) {
//                val model: AlbumData = selectedItem[i] as AlbumData
//                if (preferences.isFolderProtected(model.folderPath))
//                    needToUnLock = true
//                else
//                    needToLock = true
//            }
//        }
//
//        popUpBinding.menuLock.beVisibleIf(needToLock)
//        popUpBinding.menuUnlock.beVisibleIf(needToUnLock)

//        popUpBinding.menuLock.setOnClickListener {
//            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0) albumFragment.tryLockFolder()
//        }
//        popUpBinding.menuUnlock.setOnClickListener {
//            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0) albumFragment.tryUnLockFolder()
//        }

        popUpBinding.menuSetAs.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) photosFragment.setAs()
        }

        popUpBinding.menuResize.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) photosFragment.showResizeDialog()
        }

//        popUpBinding.menuExclude.setOnClickListener {
//            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0) {
//                albumFragment.addToExclude()
//            }
//        }

        popUpBinding.menuAddFavourite.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) photosFragment.setFavorite(true)

        }

        popUpBinding.menuRemoveFavourite.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) photosFragment.setFavorite(false)
        }

        popUpBinding.menuInfo.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) albumFragment.showDetailsDialog()
            if (binding.viewPager.currentItem == 1) photosFragment.showDetailsDialog()
        }

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) albumFragment.showAddAlbumDialog(
                Constant.deviceAlbumList,
                true
            )
            else if (binding.viewPager.currentItem == 1) photosFragment.showAddAlbumDialog(
                Constant.deviceAlbumList,
                true
            )
        }

        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) albumFragment.showAddAlbumDialog(
                albumFragment.albumList.filter { it.isCustomAlbum == false } as ArrayList<AlbumData>,
                false
            )
            else if (binding.viewPager.currentItem == 1) photosFragment.showAddAlbumDialog(
                albumFragment.albumList.filter { it.isCustomAlbum == false } as ArrayList<AlbumData>,
                false
            )
        }

        popupWindow.showAsPopUp(view)

    }


    private fun openCamera() {
        try {

            val cameraIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)

            startActivity(cameraIntent)
            AdsConfig.isSystemDialogOpen = true
            preferences.refreshMedia = true
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
            toast(getString(R.string.not_found))
        }
    }


    var languageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val intent = intent
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
            }
        }


    var permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            if (checkStoragePermission())
                openCamera()
            else
                requestPermission()
        }
//    var callerLauncher =
//        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
//            if (Settings.canDrawOverlays(this@HomeActivity)) {
////                dialog.dismiss()
//            } else {
//                requestSystemOverlayPermission()
//            }
//        }

//    var cameraActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
//        ActivityResultContracts.StartActivityForResult()
//    ) { result: ActivityResult ->
//        if (result.resultCode == RESULT_OK) {
//            openCamera()
//        }
//    }

    var captureImageActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
//            MediaScannerConnection.scanFile(
//                this@HomeActivity, arrayOf(imageFilePath), null
//            ) { path: String?, uri: Uri? -> }
//            val list = ArrayList<String>()
//            list.add(imageFilePath)
//            val file = File(imageFilePath)
//            EventBus.getDefault().post(CopyMoveEvent(list, "Camera", file.parentFile.path, ArrayList()))
        }
    }


//    private fun closeSearch() {
////        binding.icSearchClear.visibility = View.GONE
//        binding.groupToolbarHeader.visibility = View.VISIBLE
////        binding.groupSearch.visibility = View.GONE
////        binding.edtSearch.setText("")
////        hideKeyboard(binding.edtSearch)
//        if (tabPos == 0) {
//            if (albumFragment != null)
//                albumFragment.setSwipeRefreshEnabled(true)
//        } else if (tabPos == 1) {
//            if (photosFragment != null) {
//                photosFragment.setSwipeRefreshEnabled(true)
//                photosFragment.isCheckSearchOn = false
//            }
//        }
//    }

//    private fun isSearchShow(): Boolean {
//        if (binding.icSearchBack.visibility == View.VISIBLE && binding.edtSearch.visibility == View.VISIBLE)
//            return true
//        return false
//    }

    fun hideKeyboard(view: EditText) {
        view.clearFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun showKeyboard(view: EditText) {
        view.requestFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }


    private fun showHomeMenuFilter(view: View) {

        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = HomeMenuFilterBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)
        popupWindow.showAsDropDown(view, 0, 0)

//        val popupView = popUpBinding.root
//        val params = LinearLayout.LayoutParams(
//            ViewGroup.LayoutParams.WRAP_CONTENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//        params.setMargins(0, 0, 50, 60)
//        popupView.layoutParams = params
//        val popupWindow = PopupWindow(
//            popupView,
//            ViewGroup.LayoutParams.WRAP_CONTENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT, true
//        )
//
//        popupWindow.animationStyle = R.style.PopupAnimations

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        var resultAll = 0
//        resultAll += FILTER_IMAGES
//        resultAll += FILTER_VIDEOS
//        resultAll += FILTER_GIFS
        resultAll += TYPE_IMAGES
        resultAll += TYPE_VIDEOS
        resultAll += TYPE_GIFS
//        resultAll += TYPE_RAWS
//        resultAll += TYPE_SVGS
//        resultAll += TYPE_PORTRAITS

        var resultPhoto = 0
        resultPhoto += TYPE_IMAGES
//        resultPhoto += TYPE_VIDEOS
//        resultPhoto += TYPE_GIFS
//        resultPhoto += TYPE_RAWS
//        resultPhoto += TYPE_SVGS
//        resultPhoto += TYPE_PORTRAITS

        var resultVideo = 0
//        resultVideo += TYPE_IMAGES
        resultVideo += TYPE_VIDEOS
//        resultVideo += TYPE_GIFS
//        resultVideo += TYPE_RAWS
//        resultVideo += TYPE_SVGS
//        resultVideo += TYPE_PORTRAITS

        var resultGif = 0
//        resultGif += TYPE_IMAGES
//        resultGif += TYPE_VIDEOS
        resultGif += TYPE_GIFS
//        resultGif += TYPE_RAWS
//        resultGif += TYPE_SVGS
//        resultGif += TYPE_PORTRAITS

        popUpBinding.tvAll.setTextColor(resources.getColor(R.color.black_text))
        popUpBinding.tvPhoto.setTextColor(resources.getColor(R.color.black_text))
        popUpBinding.tvVideo.setTextColor(resources.getColor(R.color.black_text))
        popUpBinding.tvGif.setTextColor(resources.getColor(R.color.black_text))

        when (preferences.getFilterMedia()) {
            resultAll -> {
                popUpBinding.tvAll.setTextColor(resources.getColor(R.color.color_primary))
            }

            resultPhoto -> {
                popUpBinding.tvPhoto.setTextColor(resources.getColor(R.color.color_primary))
            }

            resultVideo -> {
                popUpBinding.tvVideo.setTextColor(resources.getColor(R.color.color_primary))
            }

            resultGif -> {
                popUpBinding.tvGif.setTextColor(resources.getColor(R.color.color_primary))
            }
        }

        popUpBinding.ivAll.setOnClickListener {
            popupWindow.dismiss()

            var result = 0
            result += TYPE_IMAGES
            result += TYPE_VIDEOS
            result += TYPE_GIFS
//            result += TYPE_RAWS
//            result += TYPE_SVGS
//            result += TYPE_PORTRAITS

            preferences.setFilterMedia(result)
            binding.txtTitle.text = getString(R.string.all)

            photosFragment.getData()
            albumFragment.getData()

        }
        popUpBinding.ivPhoto.setOnClickListener {
            popupWindow.dismiss()
            var result = 0
            result += TYPE_IMAGES
//            result += TYPE_RAWS
//            result += TYPE_SVGS
//            result += TYPE_PORTRAITS
            preferences.setFilterMedia(result)
            binding.txtTitle.text = getString(R.string.photos)

            photosFragment.getData()
            albumFragment.getData()

        }
        popUpBinding.ivVideo.setOnClickListener {
            popupWindow.dismiss()
            var result = 0
//            result += TYPE_IMAGES
            result += TYPE_VIDEOS
//            result += TYPE_GIFS
//            result += TYPE_RAWS
//            result += TYPE_SVGS
//            result += TYPE_PORTRAITS
            preferences.setFilterMedia(result)
            binding.txtTitle.text = getString(R.string.videos)

            photosFragment.getData()
            albumFragment.getData()

        }
        popUpBinding.ivGif.setOnClickListener {
            popupWindow.dismiss()
            var result = 0
//            result += TYPE_IMAGES
//            result += TYPE_VIDEOS
            result += TYPE_GIFS
//            result += TYPE_RAWS
//            result += TYPE_SVGS
//            result += TYPE_PORTRAITS
            preferences.setFilterMedia(result)
            binding.txtTitle.text = getString(R.string.gifs)

            photosFragment.getData()
            albumFragment.getData()

        }

//        popupWindow.setBackgroundDrawable(BitmapDrawable())
//        popupWindow.isOutsideTouchable = true
//        val a = IntArray(2)
//        view.getLocationInWindow(a)
//        Log.e("showDropDown", "a0==>> ${a[0]} a1==>> ${a[1]} height==>> ${view.height}")
//        popupWindow.showAtLocation(view, Gravity.NO_GRAVITY, a[0], a[1] - view.height)
//        popupWindow.update()

    }

    private fun setFilterMenu() {

    }

    private fun showMenu() {
        val dialog = HomeMenuDialog(binding.viewPager.currentItem, clickListener = {
            when (it) {
                1 -> {
                    showSortDialog()
                }

                2 -> {
                    val filterMediaDialog = FilterMediaDialog(updateListener = {
                        albumFragment.getData()
                        photosFragment.getData()
                    })
                    filterMediaDialog.show(supportFragmentManager, filterMediaDialog.tag)
                }

                21 -> {
                    photosFragment.setRvLayoutManager()
                    albumFragment.setRvLayoutManager()
                }

                22 -> {
                    photosFragment.setRvLayoutManager()
                    albumFragment.setListGridData()
                }

                3 -> {
                    // albumCreate
                    showCreateAlbum()
                }

                4 -> {
                    // displayed Columns
                    val displayColumnsDialog = DisplayedColumnsDialog(
                        updateListener = {
                            photosFragment.setRvLayoutManager()
                            albumFragment.setRvLayoutManager()
                        })
                    displayColumnsDialog.show(supportFragmentManager, displayColumnsDialog.tag)

                }

                5 -> {
                    //btnRecycleBin
                    startActivity(Intent(this, RecentlyDeleteActivity::class.java))
                }

                6 -> {
                    //btnFamilyApps
                }

//                7 -> {
//                    //btnFeedback
//                    val intent = Intent(this, FeedbackActivity::class.java)
//                    startActivity(intent)
//                }

                8 -> {
                    //btnSetting
                    settingLauncher.launch(Intent(this, SettingActivity::class.java))
                }

                9 -> {
                    //showGroupByDialog
                    showGroupByDialog()
                }

                10 -> {
                    //showPrivate
                    val intent = Intent(this, LockActivity::class.java)
                    lockActivityResultLauncher.launch(intent)
                }

            }
        })
        dialog.show(supportFragmentManager, dialog.tag)
    }

    var lockActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            val intent = Intent(this, PrivateActivity::class.java)
            privateActivityResultLauncher.launch(intent)
        }
    }

    var privateActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->

        Constant.isReCreateHomeSS = true
        val intent = intent
        finish()
        overridePendingTransition(0, 0)
        startActivity(intent)
        overridePendingTransition(0, 0)
        Constant.isChangeLanguage = false

//        }
    }

    var dirsActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {

            photosFragment.getData()
            albumFragment.getData()
        }
    }

    private fun showCreateAlbum() {

        val createDialog = CreateAlbumDialog(this, createPathListener = { newAlbum ->
            if (albumFragment != null) albumFragment.setCloseToolbar()
            val intent = Intent(this, SelectImageActivity::class.java)
            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_ALBUM)
            intent.putExtra(Constant.EXTRA_ALBUM_PATH, newAlbum)
            startActivity(intent)
        }, true)
        createDialog.show(supportFragmentManager, createDialog.tag)
    }

    private fun showSortDialog() {
        val sortDialog = SortDialog(updateListener = {
            photosFragment.setFilterData()
            albumFragment.setFilterData()
        })
        sortDialog.show(supportFragmentManager, sortDialog.tag)
    }

    private fun showGroupByDialog() {
        val groupDialog = GroupDialog(updateListener = {
            photosFragment.setList()
            photosFragment.setData()
//            albumFragment.setFilterData()
        })
        groupDialog.show(supportFragmentManager, groupDialog.tag)
    }

    private val appUpdateInstallerManager: AppUpdateInstallerManager by lazy {
        InAppUpdateInstallerManager(this)
    }

    private val appUpdateInstallerListener by lazy {
        object : AppUpdateInstallerListener() {
            override fun onDownloadedButNotInstalled() {
                Log.e("UpdateListener", "onDownloadedButNotInstalled")
                popupSnackBarForCompleteUpdate()
            }

            override fun onFailure(e: Exception) {
                Log.e("UpdateListener", "onFailure:$e")
            }

            override fun onNotUpdate() {
                Log.e("UpdateListener", "onNotUpdate")
            }

            override fun onCancelled() {
                Log.e("UpdateListener", "onCancelled")
            }

            override fun onStatus(@InstallStatus status: Int) {
                Log.e("UpdateListener", "onStatus:$status")
            }
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode == 101) {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
////                if (Settings.canDrawOverlays(this@MainActivity)) {
////                    customPermissionEvent("home_draw_over_granted")
//                AdsConfig.isSystemDialogOpen = true
////                        AdsConfig.isSystemDialogOpen = true
//                val readPhoneState =
//                    ContextCompat.checkSelfPermission(
//                        this@HomeActivity,
//                        Manifest.permission.READ_PHONE_STATE
//                    ) == 0
//                val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                    Settings.canDrawOverlays(this@HomeActivity)
//                } else {
//                    true
//                }
//                if (readPhoneState && canDrawOverlays) {
//                    adsPref.isShowCallInfo = true
//
//                    binding.icCall.beVisibleIf(!adsPref.isShowCallInfo)
//
//                } else {
//                    var closeCounter = adsPref.closeCounter
//                    closeCounter++
//                    adsPref.closeCounter = closeCounter
//                    if (!adsPref.isCallDialogClosable) {
//                        checkCaller()
//                    }
//                }
////                } else {
//////                    customPermissionEvent("home_draw_over_denied")
////                }
//            }
//        }

        appUpdateInstallerManager.onActivityResult(requestCode, resultCode, data)
    }

    private fun checkAppUpdate() {
        try {
            appUpdateInstallerManager.addAppUpdateListener(appUpdateInstallerListener)
            appUpdateInstallerManager.startCheckUpdate()
        } catch (e: Exception) {

        }
    }

    private fun popupSnackBarForCompleteUpdate() {
        val snackBar = Snackbar.make(
            findViewById(android.R.id.content),
            "An update has just been downloaded.",
            Snackbar.LENGTH_INDEFINITE
        )
        snackBar.setAction("RESTART") { appUpdateInstallerManager.completeUpdate() }
        snackBar.setActionTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
        snackBar.show()
    }

    //    var exitDialog: ExitDialog? = null
//    var exitDialog: AlertDialog? = null
    private fun showExitDialog() {
        val exitDialog = ConfirmationDialog(
            this,
            getString(R.string.exit),
            getString(R.string.are_you_sure_want_to_exit),
            getString(R.string.yes),
            positiveBtnClickListener = {
                finish()
            }, false, getString(R.string.no)
        )
        exitDialog.show()

//        val dialogDeleteBinding = DialogExitBinding.inflate(layoutInflater)
////        val builder = AlertDialog.Builder(this, R.style.RoundedCornersDialogTransp)
//        val builder = AlertDialog.Builder(this)
//            .setCancelable(false)
//            .setView(dialogDeleteBinding.root)
//        exitDialog = builder.create()
//        exitDialog?.show()
//
//        binding.root.allViews.forEach {
//            it.isEnabled = false
//        }
//
//        var exited = false
//        exitDialog?.setOnDismissListener {
//            if (exited)
//                finish()
//            else binding.root.allViews.forEach {
//                it.isEnabled = true
//            }
//        }
//
//        dialogDeleteBinding.run {
//            txtTitle.text = getString(R.string.exit_app)
//            txtSubTitle.text = getString(R.string.are_you_sure_want_to_exit)
//
//            btnOk.text = getString(R.string.exit)
//
//            btnOk.setOnClickListener {
//                exited = true
//                exitDialog?.dismiss()
//            }
//
//            btnCancel.setOnClickListener {
//                exitDialog?.dismiss()
//            }
//        }
    }

    //    var isExitDialogOpen: Boolean = false
    override fun onBackPressed() {
//        if (exitDialog != null && exitDialog!!.isExitDialogOpen) {
////            finishAffinity()
////            exitDialog!!.isExitDialogOpen = false
//            exitDialog!!.dismiss()
//        } else {
        if (binding.drawerLay.isDrawerOpen(GravityCompat.START))
            closeDrawer()
        else if (binding.viewPager.currentItem == 1 && binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            photosFragment.setCloseToolbar()
        } else if (binding.viewPager.currentItem == 0 && binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            albumFragment.setCloseToolbar()
        } else if (binding.viewPager.currentItem != 0) {
            binding.viewPager.currentItem = 0
        } else {
            showExitDialog()
//                if (exitDialog != null && exitDialog!!.isExitDialogOpen) {
//                if (exitDialog != null) {
//                    exitDialog!!.show(supportFragmentManager, exitDialog!!.tag)
//                } else {
//                    exitDialog = ExitDialog(mNativeAd) { isExit ->
//                        if (isExit) {
//                            finishAffinity()
//                        }
//                    }
//                    AdsConfig.isSystemDialogOpen = true
//                    exitDialog!!.show(supportFragmentManager, exitDialog!!.tag)
//                }
        }
//        }
    }

    class ViewPagerAdapter(val activity: Activity, fm: FragmentManager) :
        FragmentStatePagerAdapter(fm) {
//    class ViewPagerAdapter(fragmentActivity: FragmentActivity) : FragmentStateAdapter(fragmentActivity) {

        private val fragments = mutableListOf<Fragment>()


        fun addFragment(fragment: Fragment) {
            fragments.add(fragment)
            notifyDataSetChanged()
        }

        override fun getCount(): Int {
            return fragments.size
        }

        override fun getItem(position: Int): Fragment {
            return fragments[position]
        }
    }
}