package com.gallery.photo.image.video.activity

import android.animation.Animator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Resources
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.util.DisplayMetrics
import android.util.Log
import android.view.*
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.animation.DecelerateInterpolator
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.view.ContextThemeWrapper
import androidx.exifinterface.media.ExifInterface
import androidx.print.PrintHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activityBinding.AllHiddenFileActivity
import com.gallery.photo.image.video.activityBinding.BaseBindingActivity
import com.gallery.photo.image.video.activityBinding.HiddenImagesActivity
import com.gallery.photo.image.video.activityBinding.TimeLineActivity
import com.gallery.photo.image.video.adapter.MyPagerAdapter
import com.gallery.photo.image.video.adapter.SlidingTimeAdapter
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.database.FavouriteDBHelper
import com.gallery.photo.image.video.databinding.ActivityImagePreviewBinding
import com.gallery.photo.image.video.dialog.ConfirmUnFavouritePhotoDialog
import com.gallery.photo.image.video.dialog.DeleteWithRememberDialog
import com.gallery.photo.image.video.dialog.SubscriptionDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.PhotoFragment
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.fragment.ViewPagerFragment
import com.gallery.photo.image.video.interfaces.SlideShowSelectListner
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.viewpagertransformers.*
import com.gallery.photo.image.video.dialog.PropertiesDialog
import com.gallery.photo.image.video.dialog.RenameItemDialog
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.models.FileDirItem
import org.jetbrains.anko.toast
import java.io.*
import java.util.*


class ImagePreviewActivity : BaseBindingActivity<ActivityImagePreviewBinding>(), ViewPager.OnPageChangeListener, ViewPagerFragment.FragmentListener, PopupMenu.OnMenuItemClickListener,
    SlideShowSelectListner {
    private val REQUEST_VIEW_VIDEO = 1

    private var mPath = ""
    private var mDirectory = ""
    private var mIsFullScreen = false
    private var mPos = -1
    private var mShowAll = false
    private var mIsSlideshowActive = false
    private var mPrevHashcode = 0

    private var mSlideshowHandler = Handler()
    private var mSlideshowInterval = SLIDESHOW_DEFAULT_INTERVAL

    private var mSlideshowMoveBackwards = false
    private var mSlideshowMedia = mutableListOf<Medium>()
    private var mAreSlideShowMediaVisible = false

    private var mIsOrientationLocked = false

    private var mMediaFiles = ArrayList<Medium>()

    private var mFavoritePaths = ArrayList<String>()
    private var mIgnoredPaths = ArrayList<String>()
    public lateinit var slidinDialog: Dialog
    lateinit var dbHelper: FavouriteDBHelper
    var isFavourite = false
    var isShowingFavorites = false
    var isShowingPlace = false
    var isFromCamera = false
    private var mShowOnlyHidden = false
    private var isFromVault = false
    private var isFromFakeVault = false
    var isSlideshowClicked = false
    var isFromOtherApp = false
    var isFirstTime = true
    var isFirstInitialLoad = true
    var isFromAllFileHide = false

    //    private var mCurrAsyncTask: GetMediaAsynctask? = null
    val REQUEST_INLINE_EDIT_IMAGE = 1003

    companion object {
        var mPlaceItemList = ArrayList<ThumbnailItem>()
        var isCorruptImage = false
    }


    override fun setBinding(): ActivityImagePreviewBinding {
        return ActivityImagePreviewBinding.inflate(inflater)
    }

    override fun initData() {
        dbHelper = FavouriteDBHelper(this)
        (MediaActivity.mMedia.clone() as ArrayList<ThumbnailItem>).filter { it is Medium }.mapTo(mMediaFiles) { it as Medium }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!checkPermissionabove11()) {
                showGetPermissionDialog11()
            } else {
                initViewPager()
            }
        } else {
            handlePermission(PERMISSION_WRITE_STORAGE) {
                if (it) {
                    initViewPager()
                } else {
                    toast(R.string.no_storage_permissions)
                    finish()
                }
            }
        }
    }


    override fun onResume() {
        super.onResume()
        window.navigationBarColor = Color.BLACK
        if (getCurrentMedium() != null) {
            if (getCurrentMedium()!!.isHidden() || getCurrentMedium()!!.path.doesThisOrParentHaveNoMedia(HashMap(), null)) {
                mBinding.llHide.visibility = GONE
            } else {
                mBinding.llHide.visibility = VISIBLE
            }
        }
        if (mShowOnlyHidden) {
            mBinding.ivFavourite.visibility = GONE
        } else {
            mBinding.ivFavourite.visibility = VISIBLE
            var favPath = dbHelper.getSingleFavData(mPath);
            if (favPath) {
                isFavourite = true
                mBinding.ivFavourite.setImageDrawable(resources.getDrawable(R.drawable.ic_image_edit_favorite))
            } else {
                isFavourite = false
                mBinding.ivFavourite.setImageDrawable(resources.getDrawable(R.drawable.ic_image_edit_unfavorite))
            }
        }
    }


    override fun getContext(): Activity {
        return this
    }

    override fun getAppIconIDs() = arrayListOf(

        R.mipmap.ic_launcher
    )


    override fun initActions() {
        mBinding.llBackPressed.setOnClickListener(this)
        mBinding.llShare.setOnClickListener(this)
        mBinding.llHide.setOnClickListener(this)
        mBinding.llDelete.setOnClickListener(this)
        mBinding.llEdit.setOnClickListener(this)
        mBinding.llMore.setOnClickListener(this)
        mBinding.ivEffects.setOnClickListener(this)
        mBinding.ivFavourite.setOnClickListener(this)
        mBinding.ivPhotoInfo.setOnClickListener(this)
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            InterstitialAdHelper.loadInterstitialAd(fContext = this)
        }
    }

    override fun onClick(view: View) {

        when (view.id) {
            R.id.llBackPressed -> {
                onBackPressed()
            }
            R.id.llShare -> {
                if (config.isAnyOperationRunning) {
                    toast(getString(R.string.msg_operation_already_running))
                    return
                }
                if (SystemClock.elapsedRealtime() - mLastClickTime < 1500) {
                    return
                }
                mLastClickTime = SystemClock.elapsedRealtime()
                isUnLockApp = true
                shareMediumPath(getCurrentPath())
            }
            R.id.llHide -> {
                if (config.isAnyOperationRunning) {
                    toast(getString(R.string.msg_operation_already_running))
                    return
                }
                if (SystemClock.elapsedRealtime() - mLastClickTime < 1500) {
                    return
                }
                mLastClickTime = SystemClock.elapsedRealtime()
                var totalImagesCount = config.hidePhotoCountForSubscription
                var totalVideosCount = config.hideVideoCountForSubscription
//                if (getCurrentMedium()!!.type == TYPE_IMAGES) {
                totalImagesCount++
//                } else if (getCurrentMedium()!!.type == TYPE_VIDEOS) {
//                    totalVideosCount++
//                }
                if (AdsManager(this).isNeedToShowAds() && totalImagesCount > HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION_VAL
                ) {
                    SubscriptionDialog(this, totalImagesCount, totalVideosCount)
                    {
                        if(it)
                        {
                            var intent = Intent(this, SubscriptionActivity::class.java)
                            launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
                        }else{
                            config.hidePhotoCountForSubscription = totalImagesCount
                            config.hideVideoCountForSubscription = totalVideosCount
                            ensureBackgroundThread {
                                uDataDao.updateCount(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, config.hidePhotoCountForSubscription)
                            }
                            hideFile(true)
                        }

                    }
                } else {
                    config.hidePhotoCountForSubscription = totalImagesCount
                    config.hideVideoCountForSubscription = totalVideosCount
                    ensureBackgroundThread {
                        uDataDao.updateCount(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, config.hidePhotoCountForSubscription)
                    }
                    hideFile(true)
                }
            }
            R.id.llDelete -> {
                if (config.isAnyOperationRunning) {
                    toast(getString(R.string.msg_operation_already_running))
                    return
                }
                if (SystemClock.elapsedRealtime() - mLastClickTime < 1500) {
                    return
                }
                mLastClickTime = SystemClock.elapsedRealtime()
                checkDeleteConfirmation()
            }
            R.id.llEdit -> {
                if (config.isAnyOperationRunning) {
                    toast(getString(R.string.msg_operation_already_running))
                    return
                }
                if (SystemClock.elapsedRealtime() - mLastClickTime < 1500) {
                    return
                }
                mLastClickTime = SystemClock.elapsedRealtime()

                isSlideshowClicked = false
                if ((getCurrentFragment() as PhotoFragment).isCorruptImage)
                    Toast.makeText(this, getString(R.string.error_image_corrupted), Toast.LENGTH_SHORT).show()
                else
                    Intent(this, ImageCropActivity::class.java).apply {
                        putExtra(PATH, getCurrentPath())
                        launchActivityForResult(this, REQUEST_INLINE_EDIT_IMAGE)
                    }

            }
            R.id.llMore -> {
                if (config.isAnyOperationRunning) {
                    toast(getString(R.string.msg_operation_already_running))
                    return
                }
                if (SystemClock.elapsedRealtime() - mLastClickTime < 1500) {
                    return
                }
                mLastClickTime = SystemClock.elapsedRealtime()

                showMoreMenu()
            }
            R.id.ivEffects -> {
                if (SystemClock.elapsedRealtime() - mLastClickTime < 1500) {
                    return
                }
                mLastClickTime = SystemClock.elapsedRealtime()
                showEffectMenu()
            }
            R.id.ivFavourite -> {
                if (isFavourite) {
                    ConfirmUnFavouritePhotoDialog(this)
                    {
                        if (it) {
                            dbHelper.deleteFavDetails(getCurrentPath())
                            mBinding.ivFavourite.setImageDrawable(resources.getDrawable(R.drawable.ic_image_edit_unfavorite))
                            isFavourite = false
                        }
                    }

                } else {
                    dbHelper.saveFavouriteData("image", getCurrentPath())
                    mBinding.ivFavourite.setImageDrawable(resources.getDrawable(R.drawable.ic_image_edit_favorite))
                    isFavourite = true
                }
            }
            R.id.ivPhotoInfo -> {
                if (SystemClock.elapsedRealtime() - mLastClickTime < 1500) {
                    return
                }
                mLastClickTime = SystemClock.elapsedRealtime()
                showProperties()
            }
        }
    }


    override fun getAppLauncherName() = getString(R.string.app_name)

    private fun initViewPager() {
        isFromOtherApp = false
        val mUri = intent.data
        if (mUri != null) {
            isFromOtherApp = true
            Log.d("viewImage", "initViewPager: Uri -->" + mUri.toString())
            val uri = mUri.toString()
            var realPath = ""
            if (uri.startsWith("content:/") && uri.contains("/storage/")) {
                val guessedPath = uri.substring(uri.indexOf("/storage/"))
                if (getDoesFilePathExist(guessedPath)) {
                    realPath = guessedPath;
                }
            }

            var filename = getFilenameFromUri(mUri!!)


            if (getDoesFilePathExist(realPath)) {
                if (realPath.getFilenameFromPath().contains('.') || filename.contains('.')) {
                    if (isFileTypeVisible(realPath)) {
                        mPath = realPath
                    }
                } else {
                    filename = realPath.getFilenameFromPath()
                }
            }
            if (mUri!!.scheme == "file") {
                if (filename.contains('.')) {

                    rescanPaths(arrayListOf(mUri!!.path!!))
                    mPath = mUri!!.path!!
                }
                return
            } else {
                val path = applicationContext.getRealPathFromURI(mUri!!) ?: ""
                if (path != mUri.toString() && path.isNotEmpty() && mUri!!.authority != "mms" && filename.contains('.') && getDoesFilePathExist(path)) {
                    if (isFileTypeVisible(path)) {
                        Log.d("viewImage", "initViewPager: isFile typevisible true path -->" + path)
                        rescanPaths(arrayListOf(mUri!!.path!!))
                        mPath = path
                    }
                }
            }
            if (mPath.isEmpty()) {
                mPath = getFilePathFromURIWhenEmpty(mUri)!!
            }
        } else {
            try {
                mPath = intent.getStringExtra(PATH) ?: ""
                mShowAll = config.showAll
            } catch (e: Exception) {
                showErrorToast(e)
                finish()
                return
            }
        }
        mShowOnlyHidden = intent.getBooleanExtra(SHOW_ONLY_HIDDEN, false)
        isFromCamera = intent.getBooleanExtra(IS_FROM_CAMERA, false)
        isFromFakeVault = intent.getBooleanExtra(IS_FROM_FAKE_VAULT, false)
        isFromVault = intent.getBooleanExtra(IS_FROM_VAULT, false)
        isFromAllFileHide = intent.getBooleanExtra(IS_FROM_ALL_HIDE_FILE, false)
        if (mPath.isEmpty()) {
            toast(R.string.unknown_error_occurred)
            finish()
            return
        }

        if (mPath.isPortrait() && getPortraitPath() == "") {
            val newIntent = Intent(this, ImagePreviewActivity::class.java)
            newIntent.putExtras(intent!!.extras!!)
            newIntent.putExtra(PORTRAIT_PATH, mPath)
            newIntent.putExtra(PATH, "${mPath.getParentPath().getParentPath()}/${mPath.getFilenameFromPath()}")

            startActivity(newIntent)
            finish()
            return
        }

        if (!getDoesFilePathExist(mPath) && getPortraitPath() == "") {
            finish()
            return
        }

//        showSystemUI(true)

        if (intent.getBooleanExtra(SKIP_AUTHENTICATION, false)) {
            initContinue()
        } else {
            handleLockedFolderOpening(mPath.getParentPath()) { success ->
                if (success) {
                    initContinue()
                } else {
                    finish()
                }
            }
        }

    }

    private fun isFileTypeVisible(path: String): Boolean {
        val filter = config.filterMedia
        return !(path.isImageFast() && filter and TYPE_IMAGES == 0 ||
                path.isVideoFast() && filter and TYPE_VIDEOS == 0 ||
                path.isGif() && filter and TYPE_GIFS == 0 ||
                path.isRawFast() && filter and TYPE_RAWS == 0 ||
                path.isSvg() && filter and TYPE_SVGS == 0 ||
                path.isPortrait() && filter and TYPE_PORTRAITS == 0)
    }

    private fun getPortraitPath() = intent.getStringExtra(PORTRAIT_PATH) ?: ""


    private fun initContinue() {
        if (intent.extras?.containsKey(IS_VIEW_INTENT) == true) {
            if (isShowHiddenFlagNeeded()) {
                if (!config.isHiddenPasswordProtectionOn) {
                    config.temporarilyShowHidden = true
                }
            }

            config.isThirdPartyIntent = true
        }

        isShowingFavorites = intent.getBooleanExtra(SHOW_FAVORITES, false)
        isShowingPlace = intent.getBooleanExtra(SHOW_PLACE, false)
        val isShowingRecycleBin = intent.getBooleanExtra(SHOW_RECYCLE_BIN, false)
        mDirectory = when {
            else -> mPath.getParentPath()
        }
        supportActionBar?.title = mPath.getFilenameFromPath()


        refreshViewPager()
        mBinding.viewPager.offscreenPageLimit = 2

        if (config.blackBackground) {
            mBinding.viewPager.background = ColorDrawable(Color.BLACK)
        }
        setPagerTransformation();

        if (intent.action == "com.android.camera.action.REVIEW") {
            ensureBackgroundThread {
                if (mediaDB.getMediaFromPath(mPath).isEmpty()) {
                    val type = when {
                        mPath.isVideoFast() -> TYPE_VIDEOS
                        mPath.isGif() -> TYPE_GIFS
                        mPath.isSvg() -> TYPE_SVGS
                        mPath.isRawFast() -> TYPE_RAWS
                        mPath.isPortrait() -> TYPE_PORTRAITS
                        else -> TYPE_IMAGES
                    }


                    var favPath = dbHelper.getSingleFavData(mPath)
                    if (favPath) {
                        isFavourite = true
                        mBinding.ivFavourite.setImageDrawable(resources.getDrawable(R.drawable.ic_image_edit_favorite))
                    } else {
                        isFavourite = false
                        mBinding.ivFavourite.setImageDrawable(resources.getDrawable(R.drawable.ic_image_edit_unfavorite))
                    }
                    val duration = if (type == TYPE_VIDEOS) getDuration(mPath) ?: 0 else 0
                    val ts = System.currentTimeMillis()
                    val medium = Medium(null, mPath.getFilenameFromPath(), mPath, mPath.getParentPath(), ts, ts, File(mPath).length(), type, duration, favPath, 0)
                    mediaDB.insert(medium)
                }
            }
        }
    }

    private fun setPagerTransformation() {
        when (config.pagerTransformation) {
            STANDARD -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, DefaultTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            ACCORDION -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, AccordionTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            BACKGROUND_TO_FOREGROUND -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, BackgroundToForegroundTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            FOREGROUND_TO_BACKGROUND -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, ForegroundToBackgroundTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            DEPTH_PAGE -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, DepthPageTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            CUBE_IN -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, CubeInTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            CUBE_OUT -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, CubeOutTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            FLIP_HORIZONTAL -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, FlipHorizontalTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            FLIP_VERTICAL -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, FlipVerticalTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            ROTATE_DOWN -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, RotateDownTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            ROTATE_UP -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, RotateUpTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            STACK -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, StackTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            TABLET -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, TabletTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            ZOOM_IN -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, ZoomInTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            ZOOM_OUT -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, ZoomOutTranformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            ZOOM_OUT_SLIDE -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, ZoomOutSlideTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            DRAW_FROM_BACK -> {
                try {
                    mBinding.viewPager.setPageTransformer(true, DrawFromBackTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
        }
    }

    override fun fragmentClicked() {
//        mIsFullScreen = !mIsFullScreen
//        checkSystemUI()
//        fullscreenToggled()
    }

    override fun videoEnded(): Boolean {
        if (mIsSlideshowActive) {
//            swipeToNextMedium()
        }
        return mIsSlideshowActive
    }

    override fun goToPrevItem() {
        mBinding.viewPager.setCurrentItem(mBinding.viewPager.currentItem - 1, false)
        checkOrientation()
    }

    override fun goToNextItem() {
        mBinding.viewPager.setCurrentItem(mBinding.viewPager.currentItem + 1, false)
        checkOrientation()
    }

    override fun launchViewVideoIntent(path: String) {

    }

    override fun isSlideShowActive() = mIsSlideshowActive

    private fun checkSystemUI() {
        if (mIsFullScreen) {
//            hideSystemUI(true)
            hideToolBarAndBottomBar()
        } else {


            stopSlideshow()
//            showSystemUI(true)
            showToolBarAndBottomBar()
        }
    }

    private fun stopSlideshow() {
        if (mIsSlideshowActive) {
//            view_pager.setPageTransformer(false, DefaultPageTransformer())
            setPagerTransformation()
            window.statusBarColor = resources.getColor(R.color.colorPrimary)
            mIsSlideshowActive = false
            mAreSlideShowMediaVisible = false
            showSystemUI(true)
            showToolBarAndBottomBar()
            refreshViewPager()
            mSlideshowHandler.removeCallbacksAndMessages(null)
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }


    private fun checkSlideshowOnEnter() {
        if (intent.getBooleanExtra(SLIDESHOW_START_ON_ENTER, false)) {
            initSlideshow()
        }
    }

    private fun isShowHiddenFlagNeeded(): Boolean {
        val file = File(mPath)
        if (file.isHidden) {
            return true
        }

        var parent = file.parentFile ?: return false
        while (true) {
            if (parent.isHidden || parent.list()?.any { it.startsWith(NOMEDIA) } == true) {
                return true
            }

            if (parent.absolutePath == "/") {
                break
            }
            parent = parent.parentFile ?: return false
        }

        return false
    }


    private fun refreshViewPager() {
        if (isShowingFavorites) {
            if (isFirstInitialLoad) {
                isFirstInitialLoad = false
                gotMedia(mPlaceItemList)
            } else {
                getFavouriteMedia("favorites", false, false, mShowAll, TYPE_IMAGES or TYPE_VIDEOS, GROUP_BY_NONE) {
                    gotMedia(it)
                }
            }
        } else if (isShowingPlace) {
            gotMedia(mPlaceItemList)
        } else if (mPath.startsWith(recycleBinPath)) {
            ensureBackgroundThread {
                var newMedia = mediaDB.getTypeWiseDeletedMedia(RECYCLE_BIN,TYPE_IMAGES)
                if (VaultFragment.isFakeVaultOpen) {
                    newMedia = fakeVaultMediumDao.getTypeWiseDeletedMedia(RECYCLE_BIN,TYPE_IMAGES)
                }
                runOnUiThread {
                    gotMedia(mContext.getUpdatedTrashMediaPath(newMedia as ArrayList<Medium>) as ArrayList<ThumbnailItem>, true)
                }
            }
        } else {

                if (isFromCamera) {
                    getHDCameraMedia(mDirectory, true, false, mShowAll, TYPE_IMAGES or TYPE_GIFS, GROUP_BY_NONE, mShowOnlyHidden) {
                        it.sortWith { o1, o2 ->
                            o1 as Medium
                            o2 as Medium
                            var result = o2.modified.compareTo(o1.modified)
                            result
                        }
                        gotMedia(it)
                    }
                } else {
                    if (isFirstInitialLoad) {
                        isFirstInitialLoad = false

                        if (isFromOtherApp) {
//                            mCurrAsyncTask?.stopFetching()
                            getAllMedia(mDirectory, true, false, mShowAll, TYPE_IMAGES or TYPE_GIFS, GROUP_BY_NONE, mShowOnlyHidden) {
                                gotMedia(it)
                            }
//                            mCurrAsyncTask!!.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                        } else {
                            gotMedia(mPlaceItemList)
                        }
                    } else {
//                        mCurrAsyncTask?.stopFetching()
                        getAllMedia(mDirectory, true, false, mShowAll, TYPE_IMAGES or TYPE_GIFS, GROUP_BY_NONE, mShowOnlyHidden) {
                            gotMedia(it)
                        }
//                        mCurrAsyncTask!!.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                    }
                }

        }

    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.fromActivityResult(requestCode, resultCode, resultData)
        if (requestCode == REQUEST_EDIT_IMAGE ) {

//            mPos += 1
//            mPrevHashcode = 0
            refreshViewPager()
        }else if (requestCode == REQUEST_EDIT_IMAGE_IN)
        {
            refreshViewPager()
        }
        else if (requestCode == REQUEST_INLINE_EDIT_IMAGE && resultData != null) {
            mPos += 1
            refreshViewPager()
        } else if (requestCode == REQUEST_SET_AS && resultCode == Activity.RESULT_OK) {
            toast(R.string.wallpaper_set_successfully)
        } else if (requestCode == REQUEST_VIEW_VIDEO && resultCode == Activity.RESULT_OK && resultData != null) {
            if (resultData.getBooleanExtra(GO_TO_NEXT_ITEM, false)) {
                goToNextItem()
            } else if (resultData.getBooleanExtra(GO_TO_PREV_ITEM, false)) {
                goToPrevItem()
            }
        }
    }

    private fun gotMedia(thumbnailItems: ArrayList<ThumbnailItem>, ignorePlayingVideos: Boolean = false) {
        val media = thumbnailItems.asSequence().filter { it is Medium && !mIgnoredPaths.contains(it.path) }.map { it as Medium }.toMutableList() as ArrayList<Medium>
        if (isDirEmpty(media)) {
            MainActivity.isNeedToRefresh = true
            return
        }

        /*if (!ignorePlayingVideos && (getCurrentFragment() as? VideoFragment)?.mIsPlaying == true) {
            return
        }*/

        mPrevHashcode = media.hashCode()
        mMediaFiles = media
        mPos = if (mPos == -1) {
            getPositionInList(media)
        } else {
            Math.min(mPos, mMediaFiles.size - 1)
        }
        if (isFromCamera && isFirstTime) {
            isFirstTime = false
            mPos = 0
        }
        updateActionbarTitle()
        updatePagerItems(mMediaFiles.toMutableList())
        invalidateOptionsMenu()
        checkOrientation()
        initBottomActions()
    }

    private fun checkOrientation() {
        if (!mIsOrientationLocked && config.screenRotation == ROTATE_BY_ASPECT_RATIO) {
            var flipSides = false
            try {
                val pathToLoad = getCurrentPath()
                val exif = ExifInterface(pathToLoad)
                val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, -1)
                flipSides = orientation == ExifInterface.ORIENTATION_ROTATE_90 || orientation == ExifInterface.ORIENTATION_ROTATE_270
            } catch (e: Exception) {
            }
            val resolution = applicationContext.getResolution(getCurrentPath()) ?: return
            val width = if (flipSides) resolution.y else resolution.x
            val height = if (flipSides) resolution.x else resolution.y
            if (width > height) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } else if (width < height) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
        }
    }

    private fun initBottomActions() {
        initBottomActionsLayout()
    }

    private fun initBottomActionsLayout() {
        if (config.bottomActions) {
            mBinding.llBottomActions.beVisible()
        } else {
            mBinding.llBottomActions.beGone()
        }

    }


    fun NavBarheight(context: Context): Int {
        val resources = context.resources
        val resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        if (resourceId > 0) {
            Log.e("TAG123123", "onCreate getDimensionPixelSize:  " + resources.getDimensionPixelSize(resourceId))
            return resources.getDimensionPixelSize(resourceId)
        }
        return 0
    }

    fun hasNavBar(resources: Resources): Boolean {
        val id: Int = resources.getIdentifier("config_showNavigationBar", "bool", "android")
        return id > 0 && resources.getBoolean(id)
    }

    fun hasNavigationBar(activity: Activity): Boolean {
        val rectangle = Rect()
        val displayMetrics = DisplayMetrics()
        activity.window.decorView.getWindowVisibleDisplayFrame(rectangle)
        activity.windowManager.defaultDisplay.getRealMetrics(displayMetrics)
        return displayMetrics.heightPixels != rectangle.top + rectangle.height()
    }

    fun isEdgeToEdgeEnabled(context: Context): Int {
        val resources: Resources = context.getResources()
        val resourceId = resources.getIdentifier("config_navBarInteractionMode", "integer", "android")
        return if (resourceId > 0) {
            resources.getInteger(resourceId)
        } else 0
    }

    private fun showProperties() {
        if (getCurrentMedium() != null) {
            PropertiesDialog(this, getCurrentPath(), false) {}
        }
    }

    private fun moveFileTo() {
        handleDeletePasswordProtection {
            copyMoveTo(false)
        }
    }

    private fun copyMoveTo(isCopyOperation: Boolean) {
        val currPath = getCurrentPath()
        if (!isCopyOperation && currPath.startsWith(recycleBinPath)) {
            toast(R.string.moving_recycle_bin_items_disabled, Toast.LENGTH_LONG)
            return
        }

        val fileDirItems = arrayListOf(FileDirItem(currPath, currPath.getFilenameFromPath()))
        tryCopyMoveFilesTo(fileDirItems,isCopyOperation) {
            if (it != "None") {
                val newPath = "$it/${currPath.getFilenameFromPath()}"
                rescanPaths(arrayListOf(newPath)) {
                    fixDateTaken(arrayListOf(newPath), false)
                }
                if (getCurrentMedium()!!.type == TYPE_VIDEOS) {
                    Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Video  ---> ")
                    ensureBackgroundThread {
                        updatePhotoVideoDirectoryPath(it, false, true)
                        if (!isCopyOperation)
                            updatePhotoVideoDirectoryPath(getCurrentPath().getParentPath(), false, true)
                    }
                } else if (getCurrentMedium()!!.type == TYPE_IMAGES) {
                    Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Image  ---> ")
                    ensureBackgroundThread {
                        updatePhotoVideoDirectoryPath(it, true, false)
                        if (!isCopyOperation)
                            updatePhotoVideoDirectoryPath(getCurrentPath().getParentPath(), true, false)
                    }
                }
                config.tempFolderPath = ""
                TimeLineActivity.isNeedToRefresh = true
                if (isCopyOperation) {
                    toast(R.string.copying_success)
                } else {
                    toast(R.string.moving_success)
                }
                if (!isCopyOperation) {
                    getCurrentMedia()[mPos].apply {
                        path = newPath
                        name = newPath.getFilenameFromPath()
                    }

                    ensureBackgroundThread {
                        updateDBMediaPath(currPath, newPath, isFromFakeVault)
                    }
                    updateActionbarTitle()
//                    if (isShowingPlace) {
//                        mPlaceItemList[mPos].apply {
//                            if (this is Medium) {
//                                (this as Medium).path = newPath
//                                (this as Medium).name = newPath.getFilenameFromPath()
//                            }
//                        }
//                    }
                    refreshViewPager()
//                updateFavoritePaths(fileDirItems, it)
                }
            }
        }

    }

    private fun getCurrentMedia() = if (mAreSlideShowMediaVisible) mSlideshowMedia else mMediaFiles

    private fun getCurrentPath() = getCurrentMedium()?.path ?: ""

    private fun getCurrentMedium(): Medium? {
        return if (getCurrentMedia().isEmpty() || mPos == -1) {
            null
        } else {
            getCurrentMedia()[Math.min(mPos, getCurrentMedia().size - 1)]
        }
    }

    private fun setupOrientation() {
        if (!mIsOrientationLocked) {
            if (config.screenRotation == ROTATE_BY_DEVICE_ROTATION) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
            } else if (config.screenRotation == ROTATE_BY_SYSTEM_SETTING) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
    }

    private fun updatePagerItems(media: MutableList<Medium>) {
        val pagerAdapter = MyPagerAdapter(this, supportFragmentManager, media)
        if (!isDestroyed) {
            pagerAdapter.shouldInitFragment = mPos < 5
            mBinding.viewPager.apply {
                adapter = pagerAdapter
                pagerAdapter.shouldInitFragment = true
                currentItem = mPos
                removeOnPageChangeListener(this@ImagePreviewActivity)
                addOnPageChangeListener(this@ImagePreviewActivity)
                if (getCurrentMedium()!!.isHidden() || getCurrentMedium()!!.path.doesThisOrParentHaveNoMedia(HashMap(), null)) {
                    mBinding.llHide.visibility = GONE
                } else {
                    mBinding.llHide.visibility = VISIBLE
                }
                if (mShowOnlyHidden) {
                    mBinding.ivFavourite.visibility = GONE
                } else {
                    mBinding.ivFavourite.visibility = VISIBLE
                    var favPath = dbHelper.getSingleFavData(getCurrentPath());
                    if (favPath) {
                        isFavourite = true
                        mBinding.ivFavourite.setImageDrawable(resources.getDrawable(R.drawable.ic_image_edit_favorite))
                    } else {
                        isFavourite = false
                        mBinding.ivFavourite.setImageDrawable(resources.getDrawable(R.drawable.ic_image_edit_unfavorite))
                    }
                }
            }
        }
    }

    private fun updateActionbarTitle() {
        runOnUiThread {
            if (mPos < getCurrentMedia().size) {
                supportActionBar?.title = getCurrentMedia()[mPos].path.getFilenameFromPath()
                mBinding.tvTotalImg.text = getCurrentMedia().size.toString()
                mBinding.tvCurrentImg.text = (mPos + 1).toString();
            }
        }
    }

    private fun getCurrentFragment() = (mBinding.viewPager.adapter as? MyPagerAdapter)?.getCurrentFragment(mBinding.viewPager.currentItem)

    private fun isDirEmpty(media: ArrayList<Medium>): Boolean {
        return if (media.isEmpty()) {
            deleteDirectoryIfEmpty()
            finish()
            true
        } else {
            false
        }
    }

    private fun deleteDirectoryIfEmpty() {
        if (config.deleteEmptyFolders) {
            val fileDirItem = FileDirItem(mDirectory, mDirectory.getFilenameFromPath(), File(mDirectory).isDirectory)
            if (!fileDirItem.isDownloadsFolder() && fileDirItem.isDirectory) {
                ensureBackgroundThread {
                    if (fileDirItem.getProperFileCount(this, true) == 0) {
                        tryDeleteFileDirItem(fileDirItem, true, true)
                        scanPathRecursively(mDirectory)
                    }
                }
            }
        }
    }

    private fun getPositionInList(items: MutableList<Medium>): Int {
        mPos = 0
        for ((i, medium) in items.withIndex()) {
            val portraitPath = getPortraitPath()
            if (portraitPath != "") {
                val portraitPaths = File(portraitPath).parentFile?.list()
                if (portraitPaths != null) {
                    for (path in portraitPaths) {
                        if (medium.name == path) {
                            return i
                        }
                    }
                }
            } else if (medium.path == mPath) {
                return i
            }
        }
        return mPos
    }

    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}

    override fun onPageSelected(position: Int) {
        if (mPos != position) {
            mPos = position
            updateActionbarTitle()
            invalidateOptionsMenu()
            scheduleSwipe()
            if (getCurrentMedium()!!.isHidden() || getCurrentMedium()!!.path.doesThisOrParentHaveNoMedia(HashMap(), null)) {
                mBinding.llHide.visibility = GONE
            } else {
                mBinding.llHide.visibility = VISIBLE
            }
            if (mShowOnlyHidden) {
                mBinding.ivFavourite.visibility = GONE
            } else {
                mBinding.ivFavourite.visibility = VISIBLE
                var favPath = dbHelper.getSingleFavData(getCurrentPath());
                if (favPath) {
                    isFavourite = true
                    mBinding.ivFavourite.setImageDrawable(resources.getDrawable(R.drawable.ic_image_edit_favorite))
                } else {
                    isFavourite = false
                    mBinding.ivFavourite.setImageDrawable(resources.getDrawable(R.drawable.ic_image_edit_unfavorite))
                }
            }
        }
    }

    override fun onPageScrollStateChanged(state: Int) {

    }

    private fun scheduleSwipe() {
        mSlideshowHandler.removeCallbacksAndMessages(null)
        if (mIsSlideshowActive) {
            if (getCurrentMedium()!!.isImage() || getCurrentMedium()!!.isGIF() || getCurrentMedium()!!.isPortrait()) {
                mSlideshowHandler.postDelayed({
                    if (mIsSlideshowActive && !isDestroyed) {
                        swipeToNextMedium()
                    }
                }, mSlideshowInterval * 1000L)
            } else {
//                (getCurrentFragment() as? VideoFragment)!!.playVideo()
            }
        }
    }

    private fun swipeToNextMedium() {
        if (config.slideshowAnimation == SLIDESHOW_ANIMATION_NONE) {
            goToNextMedium(!mSlideshowMoveBackwards)
        } else {
            animatePagerTransition(!mSlideshowMoveBackwards)
        }
    }

    private fun goToNextMedium(forward: Boolean) {
        val oldPosition = mBinding.viewPager.currentItem
        val newPosition = if (forward) oldPosition + 1 else oldPosition - 1
        if (newPosition == -1 || newPosition > mBinding.viewPager.adapter!!.count - 1) {
            slideshowEnded(forward)
        } else {
            mBinding.viewPager.setCurrentItem(newPosition, false)
        }
    }

    private fun animatePagerTransition(forward: Boolean) {
        val oldPosition = mBinding.viewPager.currentItem
        val animator = ValueAnimator.ofInt(0, mBinding.viewPager.width)
        animator.addListener(object : Animator.AnimatorListener {
            override fun onAnimationRepeat(animation: Animator?) {
            }

            override fun onAnimationEnd(animation: Animator?) {
                if (mBinding.viewPager.isFakeDragging) {
                    try {
                        mBinding.viewPager.endFakeDrag()
                    } catch (ignored: Exception) {
                        stopSlideshow()
                    }

                    if (mBinding.viewPager.currentItem == oldPosition) {
                        slideshowEnded(forward)
                    }
                }
            }

            override fun onAnimationCancel(animation: Animator?) {
                mBinding.viewPager.endFakeDrag()
            }

            override fun onAnimationStart(animation: Animator?) {
            }
        })

        if (config.slideshowAnimation == SLIDESHOW_ANIMATION_SLIDE) {
            animator.interpolator = DecelerateInterpolator()
            animator.duration = SLIDESHOW_SLIDE_DURATION
        } else {
            animator.duration = SLIDESHOW_FADE_DURATION
        }

        animator.addUpdateListener(object : ValueAnimator.AnimatorUpdateListener {
            var oldDragPosition = 0
            override fun onAnimationUpdate(animation: ValueAnimator) {
                if (mBinding.viewPager?.isFakeDragging == true) {
                    val dragPosition = animation.animatedValue as Int
                    val dragOffset = dragPosition - oldDragPosition
                    oldDragPosition = dragPosition
                    try {
                        mBinding.viewPager.fakeDragBy(dragOffset * (if (forward) -1f else 1f))
                    } catch (e: Exception) {
                        stopSlideshow()
                    }
                }
            }
        })

        mBinding.viewPager.beginFakeDrag()
        animator.start()
    }

    private fun slideshowEnded(forward: Boolean) {
        if (config.loopSlideshow) {
            if (forward) {
                mBinding.viewPager.setCurrentItem(0, false)
            } else {
                mBinding.viewPager.setCurrentItem(mBinding.viewPager.adapter!!.count - 1, false)
            }
        } else {
            stopSlideshow()
            toast(R.string.slideshow_ended)
        }
    }


    private fun showMoreMenu() {
        val popupMenu: PopupMenu = PopupMenu(this, mBinding.llMore)
        popupMenu.menuInflater.inflate(R.menu.image_more_option_menu, popupMenu.menu)
        popupMenu.setOnMenuItemClickListener(this)
        popupMenu.show()
        if (getCurrentMedium() != null && (getCurrentMedium()!!.isHidden() || getCurrentMedium()!!.path.doesThisOrParentHaveNoMedia(HashMap(), null))) {
//            popupMenu.menu.findItem(R.id.menuHideImg).isVisible = false
            popupMenu.menu.findItem(R.id.menuMoveTo).isVisible = false
            popupMenu.menu.findItem(R.id.menuCopyTo).isVisible = false

        } else {
//            popupMenu.menu.findItem(R.id.menuHideImg).isVisible = true
            popupMenu.menu.findItem(R.id.menuMoveTo).isVisible = true
            popupMenu.menu.findItem(R.id.menuCopyTo).isVisible = true
            popupMenu.menu.findItem(R.id.menuMoveTo).isVisible = !isFavourite
            popupMenu.menu.findItem(R.id.menuRename).isVisible = !isFavourite
            popupMenu.menu.findItem(R.id.menuSlideshow).isVisible = !isFavourite

        }
    }

    private fun showEffectMenu() {
        var popupMenu: PopupMenu
        val contextWrapper = ContextThemeWrapper(this, R.style.MyPopupTheme)
        popupMenu = PopupMenu(contextWrapper, mBinding.ivEffects)
//        if (Build.VERSION.SDK_INT >= 29) {
//        } else {
//            popupMenu = PopupMenu(this, ivEffects)
//        }
        try {
            popupMenu.menuInflater.inflate(R.menu.image_pager_transformation, popupMenu.menu)
        } catch (e: Exception) {
            e.printStackTrace()
            popupMenu = PopupMenu(this, mBinding.ivEffects)
        }
        Log.e("TAG", "onClick: iv_effects: Sliding_Effect: " + config.pagerTransformation)
        when (config.pagerTransformation) {
            STANDARD -> {
                popupMenu.menu.findItem(R.id.standardTransform).isChecked = true
            }
            ACCORDION -> {
                popupMenu.menu.findItem(R.id.accordionTransform).isChecked = true
            }
            BACKGROUND_TO_FOREGROUND -> {
                popupMenu.menu.findItem(R.id.bToFTransform).isChecked = true
            }
            FOREGROUND_TO_BACKGROUND -> {
                popupMenu.menu.findItem(R.id.fToBTransform).isChecked = true
            }
            DEPTH_PAGE -> {
                popupMenu.menu.findItem(R.id.depthTransform).isChecked = true
            }
            CUBE_IN -> {
                popupMenu.menu.findItem(R.id.cubeInTransform).isChecked = true
            }
            CUBE_OUT -> {
                popupMenu.menu.findItem(R.id.cubeOutTransform).isChecked = true
            }
            FLIP_HORIZONTAL -> {
                popupMenu.menu.findItem(R.id.flipHTransform).isChecked = true
            }
            FLIP_VERTICAL -> {
                popupMenu.menu.findItem(R.id.flipVTransform).isChecked = true
            }
            ROTATE_DOWN -> {
                popupMenu.menu.findItem(R.id.RotateDTransform).isChecked = true
            }
            ROTATE_UP -> {
                popupMenu.menu.findItem(R.id.RotateUTransform).isChecked = true
            }
            STACK -> {
                popupMenu.menu.findItem(R.id.stackTransform).isChecked = true
            }
            TABLET -> {
                popupMenu.menu.findItem(R.id.tabletTransform).isChecked = true
            }
            ZOOM_IN -> {
                popupMenu.menu.findItem(R.id.zoomInTransform).isChecked = true
            }
            ZOOM_OUT -> {
                popupMenu.menu.findItem(R.id.zoomOutTransform).isChecked = true
            }
            ZOOM_OUT_SLIDE -> {
                popupMenu.menu.findItem(R.id.zoomOurSlideTransform).isChecked = true
            }
            DRAW_FROM_BACK -> {
                popupMenu.menu.findItem(R.id.drawFromBackTransform).isChecked = true
            }
        }
//        popupMenu.setOnMenuItemClickListener(this)
        popupMenu.show()
    }

    override fun onMenuItemClick(item: MenuItem?): Boolean {
        when (item!!.itemId) {
            R.id.menuRename -> {
                renameFile()
            }
            R.id.menuSetAs -> {
                isUnLockApp = true
                setAs(getCurrentPath())
            }
            R.id.menuEditWith -> {
                isUnLockApp = true
                openEditor(getCurrentPath())
            }
            R.id.menuOpenWith -> {
                isUnLockApp = true
                openPath(getCurrentPath(), true)
            }
            R.id.menuCopyTo -> {
                copyMoveTo(true)
            }
            R.id.menuMoveTo -> {
                moveFileTo()
            }
//            R.id.menuDetails -> {
//
//            }
//            R.id.menuHideImg -> {
//
////                HideFile(true)
//            }
            R.id.menuSlideshow -> {
                initSlideshow()
            }
            R.id.menuPrint -> {
                printImage()
            }


        }
        return true
    }

    private fun hideFile(hide: Boolean, callback: (() -> Unit)? = null) {

        toggleFileVisibility(getCurrentPath(), hide) {
            val newFileName = it.getFilenameFromPath()
            supportActionBar?.title = newFileName
            ensureBackgroundThread {
                if (hide) {
                    if (photoDirectoryDao.getDirectoryDetailFromDirPath(it.getParentPath()) != null) {
                        hiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(it.getParentPath()).getConvertedHiddenDirectory())
                    }
                }
            }
            var favPath = dbHelper.getSingleFavData(getCurrentPath());
            if (favPath)
                dbHelper.deleteFavDetails(getCurrentPath())
            if (getCurrentMedium() != null) {
                getCurrentMedium()!!.apply {
                    name = newFileName
                    path = it
                    getCurrentMedia()[mPos] = this
                }
            }

            invalidateOptionsMenu()
            callback?.invoke()
            toast(getString(R.string.msg_image_hide))
            config.hiddenCountForRate++
            if (isShowingPlace) {
                mPlaceItemList.remove(getCurrentMedium() as Medium)
                PlaceActivity.isNeedToRefresh = true
            }
            VaultFragment.isHideUnHideMedia = true
            TimeLineActivity.isNeedToRefresh = true
            refreshViewPager()
        }
    }

    private fun printImage() {
        val uri = Uri.parse("file://${getCurrentPath()}")
        if (uri != null) {
            try {
                var path = Uri.parse(getCurrentPath()).lastPathSegment.toString().removePrefix(".")
                PrintHelper(this).printBitmap(path.split(".")[0], uri)
            } catch (f: FileNotFoundException) {
                f.printStackTrace()
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        }
    }

    fun clickPagerEffectItem(menuItem: MenuItem) {
        when (menuItem.itemId) {
            R.id.standardTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = STANDARD
                try {
                    mBinding.viewPager.setPageTransformer(true, DefaultTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.accordionTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = ACCORDION
                try {
                    mBinding.viewPager.setPageTransformer(true, AccordionTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.bToFTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = BACKGROUND_TO_FOREGROUND
                try {
                    mBinding.viewPager.setPageTransformer(true, BackgroundToForegroundTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.fToBTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = FOREGROUND_TO_BACKGROUND
                try {
                    mBinding.viewPager.setPageTransformer(true, ForegroundToBackgroundTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.depthTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = DEPTH_PAGE
                try {
                    mBinding.viewPager.setPageTransformer(true, DepthPageTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.cubeInTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = CUBE_IN
                try {
                    mBinding.viewPager.setPageTransformer(true, CubeInTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.cubeOutTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = CUBE_OUT
                try {
                    mBinding.viewPager.setPageTransformer(true, CubeOutTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.flipHTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = FLIP_HORIZONTAL
                try {
                    mBinding.viewPager.setPageTransformer(true, FlipHorizontalTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.flipVTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = FLIP_VERTICAL
                try {
                    mBinding.viewPager.setPageTransformer(true, FlipVerticalTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.RotateDTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = ROTATE_DOWN
                try {
                    mBinding.viewPager.setPageTransformer(true, RotateDownTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.RotateUTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = ROTATE_UP
                try {
                    mBinding.viewPager.setPageTransformer(true, RotateUpTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.stackTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = STACK
                try {
                    mBinding.viewPager.setPageTransformer(true, StackTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.tabletTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = TABLET
                try {
                    mBinding.viewPager.setPageTransformer(true, TabletTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.zoomInTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = ZOOM_IN
                try {
                    mBinding.viewPager.setPageTransformer(true, ZoomInTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.zoomOutTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = ZOOM_OUT
                try {
                    mBinding.viewPager.setPageTransformer(true, ZoomOutTranformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.zoomOurSlideTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = ZOOM_OUT_SLIDE
                try {
                    mBinding.viewPager.setPageTransformer(true, ZoomOutSlideTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }
            R.id.drawFromBackTransform -> {
                menuItem.isChecked = true
                config.pagerTransformation = DRAW_FROM_BACK
                try {
                    mBinding.viewPager.setPageTransformer(true, DrawFromBackTransformer())
                } catch (e: java.lang.Exception) {
                    throw RuntimeException(e)
                }
            }

        }
    }

    private fun initSlideshow() {
        val repeat_list = ArrayList<String>()


        // custom dialog
        slidinDialog = Dialog(this)
        slidinDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        slidinDialog.setContentView(R.layout.dialog_slide_show_time)
        slidinDialog.setCancelable(false)
        slidinDialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        slidinDialog.setContentView(R.layout.dialog_slide_show_time)
        val btn_cancel = slidinDialog.findViewById<TextView>(R.id.btn_cancel)
        val rcy_repeat = slidinDialog.findViewById<RecyclerView>(R.id.rcy_repeat)
        rcy_repeat.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        repeat_list.add("1")
        repeat_list.add("2")
        repeat_list.add("3")
        repeat_list.add("4")
        repeat_list.add("5")
        repeat_list.add("10")
        val slidingTimeAdapter = SlidingTimeAdapter(repeat_list, this)
        rcy_repeat.adapter = slidingTimeAdapter
        btn_cancel.setOnClickListener { slidinDialog.dismiss() }
        slidinDialog.show()
    }

    private fun renameFile() {
        val oldPath = getCurrentPath()
        RenameItemDialog(this, oldPath) {
            getCurrentMedia()[mPos].apply {
                path = it
                name = it.getFilenameFromPath()
            }

            ensureBackgroundThread {
                updateDBMediaPath(oldPath, it, isFromFakeVault)
            }
            updateActionbarTitle()
            VaultFragment.isNeedToRefresh = true
            MainActivity.isNeedToRefresh = true
            HiddenImagesActivity.isNeedToRefresh = true
            AllHiddenFileActivity.isNeedToRefresh = true
            TimeLineActivity.isNeedToRefresh = true
        }
    }

    override fun onSlideSHowItemSelect(time: Int) {
        isSlideshowClicked = true
        config.slideshowInterval = time

        if (MainActivity.isAdShown) {
            isInterstitialShown = false
            slidinDialog.dismiss()
            startSlideshow()
        } else {
            if (AdsManager(this).isNeedToShowAds() && isOnline()) {
                isShowInterstitialAd {
                    isInterstitialShown = false
                    slidinDialog.dismiss()
                    startSlideshow()
                }
            } else {
                isInterstitialShown = false
                slidinDialog.dismiss()
                startSlideshow()
            }
        }
    }

    private fun startSlideshow() {
        if (getMediaForSlideshow()) {
            mBinding.viewPager.onGlobalLayout {
                if (!isDestroyed) {
                    if (config.slideshowAnimation == SLIDESHOW_ANIMATION_FADE) {
                        mBinding.viewPager.setPageTransformer(false, FadePageTransformer())
                    }

                    hideSystemUI(true)
                    hideToolBarAndBottomBar()
                    mSlideshowInterval = config.slideshowInterval
                    mSlideshowMoveBackwards = config.slideshowMoveBackwards
                    mIsSlideshowActive = true
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    scheduleSwipe()
                }
            }
        }
    }

    private fun hideToolBarAndBottomBar() {
        mBinding.rlStatusBar.beGone()
        mBinding.rlToolBar.beGone()
        mBinding.llBottomActions.beGone()

    }

    private fun showToolBarAndBottomBar() {
        mBinding.rlStatusBar.beVisible()
        mBinding.rlToolBar.beVisible()
        mBinding.llBottomActions.beVisible()

    }

    private fun getMediaForSlideshow(): Boolean {
        mSlideshowMedia = mMediaFiles.filter {
            it.isImage() || it.isPortrait() || (config.slideshowIncludeVideos && it.isVideo() || (config.slideshowIncludeGIFs && it.isGIF()))
        }.toMutableList()

        if (config.slideshowRandomOrder) {
            mSlideshowMedia.shuffle()
            mPos = 0
        } else {
            mPath = getCurrentPath()
            mPos = getPositionInList(mSlideshowMedia)
        }

        return if (mSlideshowMedia.isEmpty()) {
            toast(R.string.no_media_for_slideshow)
            false
        } else {
            updatePagerItems(mSlideshowMedia)
            mAreSlideShowMediaVisible = true
            true
        }
    }

    private fun checkDeleteConfirmation() {
        if (getCurrentMedium() == null) {
            return
        }

        if (config.isDeletePasswordProtectionOn) {
            handleDeletePasswordProtection {
                deleteConfirmed()
            }
        } else {
            askConfirmDelete()
        }
    }

    private fun askConfirmDelete() {
        isUnLockApp = true
        val filename = "\"${getCurrentPath().getFilenameFromPath()}\""
        val baseString =
            if (isFromAllFileHide) {
                R.string.deletion_confirmation
            } else if ((getCurrentMedium()!!.isHidden() || getCurrentMedium()!!.path.doesThisOrParentHaveNoMedia(HashMap(), null)) && !getCurrentMedium()!!.getIsInRecycleBin()) {
                R.string.msg_move_vault_trash
            } else {
                R.string.msg_move_recover_trash
            }

        val message = String.format(resources.getString(baseString), filename)
        DeleteWithRememberDialog(this, message) {
            if (it) {
                config.tempSkipDeleteConfirmation = it
                dbHelper.deleteFavDetails(getCurrentPath())
                MainActivity.isNeedToRefresh = true
                AllHiddenFileActivity.isNeedToRefresh = true
                deleteConfirmed()
            }
        }
    }

    private fun deleteConfirmed() {
        val path = getCurrentMedia().getOrNull(mPos)?.path ?: return
        if (getIsPathDirectory(path) || !path.isMediaFile()) {
            return
        }

        val fileDirItem = FileDirItem(path, path.getFilenameFromPath())
        if (isFromAllFileHide) {
            handleDeletion(fileDirItem)
        } else if ((getCurrentMedium()!!.isHidden() || getCurrentMedium()!!.path.doesThisOrParentHaveNoMedia(HashMap(), null)) && !getCurrentMedium()!!.getIsInRecycleBin()) {
            mIgnoredPaths.add(fileDirItem.path)
            val media = mMediaFiles.filter { !mIgnoredPaths.contains(it.path) } as ArrayList<ThumbnailItem>
            VaultFragment.isHideUnHideMedia = true
            VaultFragment.isNeedToRefresh = true
            HiddenImagesActivity.isNeedToRefresh = true
            AllHiddenFileActivity.isNeedToRefresh = true
            TimeLineActivity.isNeedToRefresh = true
            runOnUiThread {
                gotMedia(media, true)
            }
            movePathsInRecycleBin(arrayListOf(fileDirItem.path), isFakeVaultOpen = isFromFakeVault) {
                if (it) {
                    mIgnoredPaths.add(fileDirItem.path)
                    val media = mMediaFiles.filter { !mIgnoredPaths.contains(it.path) } as ArrayList<ThumbnailItem>
                    runOnUiThread {
                        gotMedia(media, true)
                    }
                    tryDeleteFileDirItem(fileDirItem, false, false) {
                        mIgnoredPaths.remove(fileDirItem.path)

                        deleteDirectoryIfEmpty()
                    }
                } else {
                    toast(R.string.unknown_error_occurred)
                }
            }

        } else {
            movePathsInRecoverTrash(arrayListOf(fileDirItem.path), isFakeVaultOpen = isFromFakeVault){
                if(it)
                {
                    PlaceActivity.isNeedToRefresh = true
                    TimeLineActivity.isNeedToRefresh = true
                    handleDeletion(fileDirItem)
                }
            }

        }
    }

    private fun handleDeletion(fileDirItem: FileDirItem) {
        mIgnoredPaths.add(fileDirItem.path)
        val media = mMediaFiles.filter { !mIgnoredPaths.contains(it.path) } as ArrayList<ThumbnailItem>
        runOnUiThread {
            gotMedia(media, true)
        }

        tryDeleteFileDirItem(fileDirItem, false, true) {
            mIgnoredPaths.remove(fileDirItem.path)
            deleteDirectoryIfEmpty()
        }
    }

    override fun onBackPressed() {
        if (mIsSlideshowActive) {
            stopSlideshow()
        } else
            super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
    }


}