package com.gallery.photo.image.video.adapter

import android.annotation.SuppressLint
import android.os.Build
import android.text.Html
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.databinding.SingleItemBinding
import com.gallery.photo.image.video.models.QuestionDataList

class RvAdapter(
    private var languageList: List<QuestionDataList>
) : RecyclerView.Adapter<RvAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: SingleItemBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = SingleItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        with(holder) {
            with(languageList[position]) {

                binding.tvLangName.text = this.question

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    binding.tvDescription.text = Html.fromHtml(this.answer,Html.FROM_HTML_MODE_LEGACY)
                }else{
                    binding.tvDescription.text = Html.fromHtml(this.answer)
                }

                binding.expandedView.visibility = if (this.expand) View.VISIBLE else View.GONE
                if (this.expand)
                    binding.arrow.rotation += 180
                else
                    binding.arrow.rotation = 0f

                binding.cardLayout.setOnClickListener {
                    if (!this.expand) {
                        languageList.forEach {
                            it.expand = false
                        }
                    }
                    this.expand = !this.expand
                    notifyDataSetChanged()
                }
            }
        }
    }

    // return the size of languageList
    override fun getItemCount(): Int {
        return languageList.size
    }
}