package com.gallery.photo.image.video.activity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.example.jdrodi.utilities.RvGridSpacingItemDecoration
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.utilities.getSupportedLanguage
import com.gallery.photo.image.video.adapter.LanguageAdapter
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.utilities.AppLanguage
import com.gallery.photo.image.video.extensions.baseConfig
import kotlinx.android.synthetic.main.activity_choose_app_language.*
import kotlinx.android.synthetic.main.activity_choose_app_language.imgBack


const val ARG_CHANGE_LANG = "arg_change_lang"

class ChooseAppLanguageActivity : BaseActivity(), View.OnClickListener {
    var TAG = javaClass.simpleName
    private var selectedLanguage: AppLanguage? = null
    private var isChangeLang = false

    companion object {
        fun newIntent(mContext: Context, isChangeLang: Boolean = false): Intent {
            return Intent(mContext, ChooseAppLanguageActivity::class.java)
                .putExtra(ARG_CHANGE_LANG, isChangeLang)
        }
    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName(): String {
        return getString(R.string.app_name)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(null)
        setContentView(R.layout.activity_choose_app_language)
    }


    override fun getContext(): Activity {
        return this
    }


    override fun initViews() {
        tv_title.isSelected = true
        rv_languages.addItemDecoration(RvGridSpacingItemDecoration(1, 30, true))
    }

    override fun initActions() {
        imgBack.setOnClickListener { onBackPressed() }
        iv_done.setOnClickListener(this)
    }

    override fun initAds() {

    }


    override fun initData() {
        isChangeLang = intent.getBooleanExtra(ARG_CHANGE_LANG, false)
        if (isChangeLang) {
            imgBack.visibility = View.VISIBLE
            tv_title.text = getString(R.string.change_language)
        } else {
            tv_title.text = getString(R.string.select_lang)
            imgBack.visibility = View.GONE
        }

        val mLanguages = getSupportedLanguage()
        val adapter = LanguageAdapter(
            this, mLanguages
        ) {
            selectedLanguage = mLanguages[it as Int]
        }
        rv_languages.adapter = adapter
        if (baseConfig.appLanguage.isNotEmpty()) {
            mLanguages.forEach {
                if (it.local.language == baseConfig.appLanguage)
                    selectedLanguage = it
            }
        } else {
            selectedLanguage = mLanguages[0]
        }
    }


    private fun redirectToHome() {
        startActivity(MainActivity.newIntent(mContext))
        finish()
    }

    override fun onClick(view: View) {
        when (view) {
            iv_done -> {

                if (selectedLanguage != null) {
                    if (selectedLanguage!!.local.language == baseConfig.appLanguage) {
                        finish()
                    } else {
                        Log.i(TAG, "selectedLanguage: " + selectedLanguage!!.local.language)
                        baseConfig.appLanguage = selectedLanguage!!.local.language
                        VaultFragment.isLoadedOtherApp = false
                        VaultFragment.isLoadedGallery = false
                        VaultFragment.isLoadedFakeVaultDir = false
                        VaultFragment.isLanguageChanges = true
                        redirectToHome()
                    }
                }
            }
        }
    }


    override fun onResume() {
        super.onResume()
        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(dm)
        val x = Math.pow((dm.widthPixels / dm.xdpi).toDouble(), 2.0)
        val y = Math.pow((dm.heightPixels / dm.ydpi).toDouble(), 2.0)
        val screenInches = Math.sqrt(x + y)
        if (AdsManager(mContext).isNeedToShowAds() && isOnline()) {
            if (screenInches <= 5) {
                NativeAdvancedModelHelper(this).loadNativeAdvancedAd(
                    NativeAdsSize.Medium,
                    ad_view_container
                )
            } else {
                NativeAdvancedModelHelper(this).loadNativeAdvancedAd(
                    NativeAdsSize.Big,
                    ad_view_container
                )
            }
        } else {
            ad_view_container.visibility = View.GONE
        }

    }

    override fun onBackPressed() {
        super.onBackPressed()
        if (!isChangeLang) {
            finishAffinity()
        }
    }

}