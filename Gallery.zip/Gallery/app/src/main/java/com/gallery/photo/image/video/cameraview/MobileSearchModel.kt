package com.gallery.photo.image.video.cameraview

import java.io.Serializable

data class MobileSearchModel(
        var ResponseCode: Int,
        var ResponseMessage: String,
        var data: DataModel
) : Serializable

data class DataModel(
        var id: Int = 0,
        var number: String = "",
        var operator_company: String = "",
        var name: String = "",
        var address: String = "",
        var operator_code: String = "",
        var circle_code: String = "",
        var circle: String = "",
        var provider: String = "",
        var lat: String = "",
        var lon: String = ""
) : Serializable
