package com.gallery.photo.image.video.Camera.preview.camerasurface;

import android.graphics.Matrix;
import android.media.MediaRecorder;
import android.view.View;

import com.gallery.photo.image.video.Camera.cameracontroller.CameraController;


public interface CameraSurface {
    View getView();

    void onPause();

    void onResume();

    void setPreviewDisplay(CameraController cameraController);

    void setTransform(Matrix matrix);

    void setVideoRecorder(MediaRecorder mediaRecorder);
}
