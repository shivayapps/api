package com.gallery.photo.image.video.activity

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.AnimRes
import androidx.annotation.AnimatorRes
import androidx.annotation.RequiresApi
import androidx.annotation.UiThread
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.ActivityOptionsCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.util.Pair
import androidx.documentfile.provider.DocumentFile
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.asynctasks.AddNewFolderCopyTask
import com.gallery.photo.image.video.dialog.ConfirmationDialog
import com.gallery.photo.image.video.dialog.FileConflictDialog
import com.gallery.photo.image.video.dialog.WritePermissionDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.interfaces.CopyMoveListener
import com.gallery.photo.image.video.models.FileDirItem
import java.io.File
import java.io.OutputStream
import java.util.*
import java.util.regex.Pattern
import  com.gallery.photo.image.video.multilang.*
import com.gallery.photo.image.video.utilities.AsyncBackgroundWork
import com.gallery.photo.image.video.utilities.mainscope
import kotlinx.coroutines.launch
import java.io.InputStream
import kotlin.collections.ArrayList

abstract class BaseSimpleActivity : AppCompatActivity() {
    var copyMoveCallback: ((destinationPath: String) -> Unit)? = null
    var actionOnPermission: ((granted: Boolean) -> Unit)? = null
    var isAskingPermissions = false
    var isAskingPermissionsActionNull = false
    var useDynamicTheme = true
    var showTransparentTop = false
    var checkedDocumentPath = ""
    var configItemsToExport = LinkedHashMap<String, Any>()
    var mRequestCode: Int = 0

    val launcher: ActivityResultLauncher<Intent> =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result: ActivityResult ->
            fromActivityResult(
                requestCode = mRequestCode,
                resultCode = result.resultCode,
                resultData = result.data
            )
        }

    val GENERIC_PERM_HANDLER = 100

    companion object {
        var funAfterSAFPermission: ((success: Boolean) -> Unit)? = null
    }


    open fun getAppIconIDs() = arrayListOf(
        R.drawable.dialog_bg
    )

    open fun getAppLauncherName() = "Gallery"

    override fun onCreate(savedInstanceState: Bundle?) {
        val selectedLanguage = baseConfig.appLanguage
        LocaleManager.setNewLocale(this, selectedLanguage)
        super.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onStop() {
        super.onStop()
        actionOnPermission = null
    }

    override fun onDestroy() {
        notificationManager.cancelAll()
        super.onDestroy()
        funAfterSAFPermission = null
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    override fun attachBaseContext(newBase: Context) {
        if (newBase.baseConfig.useEnglish) {
            super.attachBaseContext(MyContextWrapper(newBase).wrap(newBase, "en"))
        } else {
            super.attachBaseContext(newBase)
        }
    }

    fun updateBackgroundColor(color: Int = baseConfig.backgroundColor) {
        window.decorView.setBackgroundColor(color)
    }

    fun updateActionbarColor(color: Int = baseConfig.primaryColor) {
        supportActionBar?.setBackgroundDrawable(ColorDrawable(color))
        updateActionBarTitle(supportActionBar?.title.toString(), color)
        updateStatusbarColor(color)
        setTaskDescription(ActivityManager.TaskDescription(null, null, color))
    }

    fun updateStatusbarColor(color: Int) {
        window.statusBarColor = color.darkenColor()

        if (isMarshmallowPlus()) {
            if (color.getContrastColor() == 0xFF333333.toInt()) {
                window.decorView.systemUiVisibility = window.decorView.systemUiVisibility.addBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
            } else {
                window.decorView.systemUiVisibility = window.decorView.systemUiVisibility.removeBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
            }
        }
    }

    fun updateNavigationBarColor(color: Int = baseConfig.navigationBarColor) {
        if (baseConfig.navigationBarColor != INVALID_NAVIGATION_BAR_COLOR) {
            try {
                val colorToUse = if (color == -2) -1 else color
                window.navigationBarColor = colorToUse

                if (isOreoPlus()) {
                    if (color.getContrastColor() == 0xFF333333.toInt()) {
                        window.decorView.systemUiVisibility = window.decorView.systemUiVisibility.addBit(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
                    } else {
                        window.decorView.systemUiVisibility = window.decorView.systemUiVisibility.removeBit(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
                    }
                }
            } catch (ignored: Exception) {
            }
        }
    }

    fun updateMenuItemColors(menu: Menu?, useCrossAsBack: Boolean = false, baseColor: Int = baseConfig.primaryColor) {
        if (menu == null) {
            return
        }

        val color = baseColor.getContrastColor()
        for (i in 0 until menu.size()) {
            try {
                menu.getItem(i)?.icon?.setTint(color)
            } catch (ignored: Exception) {
            }
        }

        val drawableId = if (useCrossAsBack) R.drawable.ic_cross_vector else R.drawable.ic_arrow_left_vector
        val icon = resources.getColoredDrawableWithColor(drawableId, color)
        supportActionBar?.setHomeAsUpIndicator(icon)
    }

    fun setTranslucentNavigation() {
        window.setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION, WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
    }


    private fun saveTreeUri(resultData: Intent) {
        val treeUri = resultData.data
        baseConfig.treeUri = treeUri.toString()

        val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        applicationContext.contentResolver.takePersistableUriPermission(treeUri!!, takeFlags)
    }

    private fun isProperSDFolder(uri: Uri) = isExternalStorageDocument(uri) && isRootUri(uri) && !isInternalStorage(uri)

    private fun isProperOTGFolder(uri: Uri) = isExternalStorageDocument(uri) && isRootUri(uri) && !isInternalStorage(uri)

    private fun isRootUri(uri: Uri) = DocumentsContract.getTreeDocumentId(uri).endsWith(":")

    private fun isInternalStorage(uri: Uri) = isExternalStorageDocument(uri) && DocumentsContract.getTreeDocumentId(uri).contains("primary")

    private fun isExternalStorageDocument(uri: Uri) = "com.android.externalstorage.documents" == uri.authority

    @RequiresApi(Build.VERSION_CODES.O)
    fun launchCustomizeNotificationsIntent() {
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
            putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            startActivity(this)
        }
    }

    // synchronous return value determines only if we are showing the SAF dialog, callback result tells if the SD or OTG permission has been granted
    fun handleSAFDialog(path: String, callback: (success: Boolean) -> Unit): Boolean {
        return if (isShowingSAFDialog(path) || isShowingOTGDialog(path)) {
            funAfterSAFPermission = callback
            true
        } else {
            callback(true)
            false
        }
    }

    fun handleOTGPermission(callback: (success: Boolean) -> Unit) {
        if (baseConfig.OTGTreeUri.isNotEmpty()) {
            callback(true)
            return
        }

        funAfterSAFPermission = callback
        WritePermissionDialog(this, true) {
            Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                try {
//                    startActivityForResult(this, OPEN_DOCUMENT_TREE_OTG)
                    launchActivityForResult(this, OPEN_DOCUMENT_TREE_OTG)
                    return@apply
                } catch (e: Exception) {
                    type = "*/*"
                }

                try {
//                    startActivityForResult(this, OPEN_DOCUMENT_TREE_OTG)
                    launchActivityForResult(intent, OPEN_DOCUMENT_TREE_OTG)
                } catch (e: Exception) {
                    toast(R.string.unknown_error_occurred)
                }
            }
        }
    }

    fun copyMoveFilesTo(
        fileDirItems: ArrayList<FileDirItem>, source: String, destination: String, isCopyOperation: Boolean, copyPhotoVideoOnly: Boolean,
        copyHidden: Boolean, callback: (destinationPath: String) -> Unit
    ) {
        if (source == destination) {
            toast(R.string.source_and_destination_same)
            baseConfig.isAnyOperationRunning = false
            baseConfig.lastDestinationPath = ""
            return
        }

        if (!getDoesFilePathExist(destination)) {
            toast(R.string.invalid_destination)
            baseConfig.isAnyOperationRunning = false
            baseConfig.lastDestinationPath = ""
            return
        }

        handleSAFDialog(destination) {
            if (!it) {
                copyMoveListener.copyFailed()
                baseConfig.isAnyOperationRunning = false
                baseConfig.lastDestinationPath = ""
                return@handleSAFDialog
            }

//            copyMoveCallback = callback
            var fileCountToCopy = fileDirItems.size
            if (isCopyOperation) {
                startCopyMove(fileDirItems, destination, isCopyOperation, copyPhotoVideoOnly, copyHidden, callback)
            } else {
                startCopyMove(fileDirItems, destination, isCopyOperation, copyPhotoVideoOnly, copyHidden, callback)
            }
        }
    }

    fun newFileAdd(
        fileDirItems: ArrayList<FileDirItem>, source: String, destination: String, isCopyOperation: Boolean, copyPhotoVideoOnly: Boolean,
        copyHidden: Boolean, callback: (destinationPath: String) -> Unit
    ) {
        if (source == destination) {
            toast(R.string.source_and_destination_same)
            return
        }

        if (!getDoesFilePathExist(destination)) {
            toast(R.string.invalid_destination)
            return
        }

        handleSAFDialog(destination) {
            if (!it) {
                copyMoveListener.copyFailed()
                return@handleSAFDialog
            }

            copyMoveCallback = callback
            var fileCountToCopy = fileDirItems.size
            if (isCopyOperation) {
                startAddNewFolderCopyMove(fileDirItems, destination, isCopyOperation, copyPhotoVideoOnly, copyHidden)
            } else {
                startAddNewFolderCopyMove(fileDirItems, destination, isCopyOperation, copyPhotoVideoOnly, copyHidden)

            }
        }
    }

    fun getAlternativeFile(file: File): File {
        var fileIndex = 1
        var newFile: File?
        do {
            val newName = String.format("%s(%d).%s", file.nameWithoutExtension, fileIndex, file.extension)
            newFile = File(file.parent, newName)
            fileIndex++
        } while (getDoesFilePathExist(newFile!!.absolutePath))
        return newFile
    }

    private fun startCopyMove(
        files: ArrayList<FileDirItem>,
        destinationPath: String,
        isCopyOperation: Boolean,
        copyPhotoVideoOnly: Boolean,
        copyHidden: Boolean,
        callback: (destinationPath: String) -> Unit
    ) {
        val availableSpace = destinationPath.getAvailableStorageB()
        val sumToCopy = files.sumByLong { it.getProperSize(applicationContext, copyHidden) }
        if (availableSpace == -1L || sumToCopy < availableSpace) {
            checkConflicts(files, destinationPath, 0, LinkedHashMap()) {
                val pair = Pair(files, destinationPath)
//                CopyMoveTask(this, isCopyOperation, copyPhotoVideoOnly, it, copyMoveListener, copyHidden).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, pair)
                copyMoveToAsync(files, destinationPath, isCopyOperation, copyPhotoVideoOnly, it, copyMoveListener, copyHidden, callback)
            }
        } else {
            baseConfig.isAnyOperationRunning = false
            baseConfig.lastDestinationPath = ""
            val text = String.format(getString(R.string.no_space), sumToCopy.formatSize(), availableSpace.formatSize())
            toast(text, Toast.LENGTH_LONG)
        }
    }

    private fun startAddNewFolderCopyMove(files: ArrayList<FileDirItem>, destinationPath: String, isCopyOperation: Boolean, copyPhotoVideoOnly: Boolean, copyHidden: Boolean) {
        val availableSpace = destinationPath.getAvailableStorageB()
        val sumToCopy = files.sumByLong { it.getProperSize(applicationContext, copyHidden) }
        if (availableSpace == -1L || sumToCopy < availableSpace) {
            checkConflicts(files, destinationPath, 0, LinkedHashMap()) {
                val pair = Pair(files, destinationPath)
                AddNewFolderCopyTask(this, isCopyOperation, copyPhotoVideoOnly, it, copyMoveListener, copyHidden).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, pair)
            }
        } else {
            baseConfig.isAnyOperationRunning = false
            baseConfig.lastDestinationPath = ""
            val text = String.format(getString(R.string.no_space), sumToCopy.formatSize(), availableSpace.formatSize())
            toast(text, Toast.LENGTH_LONG)
        }
    }

    fun checkConflicts(
        files: ArrayList<FileDirItem>, destinationPath: String, index: Int, conflictResolutions: LinkedHashMap<String, Int>,
        callback: (resolutions: LinkedHashMap<String, Int>) -> Unit
    ) {
        if (index == files.size) {
            callback(conflictResolutions)
            return
        }

        val file = files[index]
        val newFileDirItem = FileDirItem("$destinationPath/${file.name}", file.name, file.isDirectory)
        if (getDoesFilePathExist(newFileDirItem.path)) {
            FileConflictDialog(this, newFileDirItem, files.size > 1) { resolution, applyForAll ->
                if (applyForAll) {
                    conflictResolutions.clear()
                    conflictResolutions[""] = resolution
                    checkConflicts(files, destinationPath, files.size, conflictResolutions, callback)
                } else {
                    conflictResolutions[newFileDirItem.path] = resolution
                    checkConflicts(files, destinationPath, index + 1, conflictResolutions, callback)
                }
            }
        } else {
            checkConflicts(files, destinationPath, index + 1, conflictResolutions, callback)
        }
    }

    fun handlePermission(permissionId: Int, callback: (granted: Boolean) -> Unit) {
        actionOnPermission = null
        if (hasPermission(permissionId)) {
            callback(true)
        } else {
            isAskingPermissions = true
            actionOnPermission = callback
            ActivityCompat.requestPermissions(this, arrayOf(getPermissionString(permissionId)), GENERIC_PERM_HANDLER)
        }
    }

    fun checkPermissions(permissionId: Array<Int>, callback: (granted: Boolean) -> Unit) {
        actionOnPermission = null
        var hasPermission = false
        permissionId.forEach {
            hasPermission = hasPermission(it)
        }
        if (hasPermission) {
            callback(true)
        } else {
            isAskingPermissions = true
            actionOnPermission = callback
            ActivityCompat.requestPermissions(this, permissionId.map { getPermissionString(it) }.toTypedArray(), GENERIC_PERM_HANDLER)
        }
    }

    fun checkPermissionabove11(): Boolean {
        return true
//        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//            Log.e("TAG", "onCreate:SDK_INT    " + Build.VERSION.SDK_INT)
//            Environment.isExternalStorageManager()
//        } else {
//            val result = ContextCompat.checkSelfPermission(
//                this,
//                "android.permission.MANAGE_EXTERNAL_STORAGE"
//            )
//            val result1 =
//                ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE")
//            result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED
//        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        isAskingPermissions = false
        if (requestCode == GENERIC_PERM_HANDLER && grantResults.isNotEmpty()) {
            actionOnPermission?.invoke(grantResults[0] == 0)
            if (actionOnPermission == null)
                isAskingPermissionsActionNull = true
        }
    }

    val copyMoveListener = object : CopyMoveListener {
        override fun copySucceeded(copyOnly: Boolean, copiedAll: Boolean, destinationPath: String) {
            Log.d("TAGCOPY", "copySucceeded: ")
            copyMoveCallback?.invoke(destinationPath)
            copyMoveCallback = null
        }

        override fun copyFailed() {
            Log.d("TAGCOPY", "copyFailed: ")
            toast(R.string.copy_move_failed)
            copyMoveCallback = null
        }
    }

    fun checkAppOnSDCard() {
        if (!baseConfig.wasAppOnSDShown && isAppInstalledOnSDCard()) {
            baseConfig.wasAppOnSDShown = true
            ConfirmationDialog(this, "", R.string.app_on_sd_card, R.string.ok, 0) {}
        }
    }

    private fun exportSettingsTo(outputStream: OutputStream?, configItems: LinkedHashMap<String, Any>) {
        if (outputStream == null) {
            toast(R.string.unknown_error_occurred)
            return
        }

        ensureBackgroundThread {
            outputStream.bufferedWriter().use { out ->
                for ((key, value) in configItems) {
                    out.writeLn("$key=$value")
                }
            }

            toast(R.string.settings_exported_successfully)
        }
    }

    private fun getExportSettingsFilename(): String {
        var defaultFilename = baseConfig.lastExportedSettingsFile
        if (defaultFilename.isEmpty()) {
            val appName = baseConfig.appId.removeSuffix(".debug").removeSuffix(".pro").removePrefix("com.simplemobiletools.")
            defaultFilename = "$appName-settings.txt"
        }

        return defaultFilename
    }

    @SuppressLint("InlinedApi")
    protected fun launchSetDefaultDialerIntent() {
        if (isQPlus()) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager!!.isRoleAvailable(RoleManager.ROLE_DIALER) && !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)) {
                val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER)
                launchActivityForResult(intent, REQUEST_CODE_SET_DEFAULT_DIALER)
            }
        } else {
            Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName).apply {
                try {
                    launchActivityForResult(intent, REQUEST_CODE_SET_DEFAULT_DIALER)
                } catch (e: ActivityNotFoundException) {
                    toast(R.string.no_app_found)
                } catch (e: Exception) {
                    showErrorToast(e)
                }
            }
        }
    }


    open fun launchActivityForResult(
        fIntent: Intent,
        fRequestCode: Int,
        @AnimatorRes @AnimRes fEnterAnimId: Int = android.R.anim.fade_in,
        @AnimatorRes @AnimRes fExitAnimId: Int = android.R.anim.fade_out
    ) {
        mRequestCode = fRequestCode
        launcher.launch(
            fIntent,
            ActivityOptionsCompat.makeCustomAnimation(this, fEnterAnimId, fExitAnimId)
        )
    }

    /**
     * This Method will replace your default method of [onActivityResult]
     *
     * @param requestCode The integer request code originally supplied to launchActivityForResult(), allowing you to identify who this result came from.
     * @param resultCode The integer result code returned by the child activity through its setResult().
     * @param data An Intent, which can return result data to the caller (various data can be attached to Intent "extras").
     */
    @UiThread
    open fun fromActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        val partition = try {
            checkedDocumentPath.substring(9, 18)
        } catch (e: Exception) {
            ""
        }
        val sdOtgPattern = Pattern.compile(SD_OTG_SHORT)

        if (requestCode == OPEN_DOCUMENT_TREE) {
            if (resultCode == Activity.RESULT_OK && resultData != null && resultData.data != null) {
                val isProperPartition = partition.isEmpty() || !sdOtgPattern.matcher(partition).matches() || (sdOtgPattern.matcher(partition).matches() && resultData.dataString!!.contains(partition))
                if (isProperSDFolder(resultData.data!!) && isProperPartition) {
                    if (resultData.dataString == baseConfig.OTGTreeUri) {
                        toast(R.string.sd_card_usb_same)
                        return
                    }

                    saveTreeUri(resultData)
                    funAfterSAFPermission?.invoke(true)
                    funAfterSAFPermission = null
                } else {
                    toast(R.string.wrong_root_selected)
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                    launchActivityForResult(intent, requestCode)
                }
            } else {
                funAfterSAFPermission?.invoke(false)
            }
        } else if (requestCode == OPEN_DOCUMENT_TREE_OTG) {
            if (resultCode == Activity.RESULT_OK && resultData != null && resultData.data != null) {
                val isProperPartition = partition.isEmpty() || !sdOtgPattern.matcher(partition).matches() || (sdOtgPattern.matcher(partition).matches() && resultData.dataString!!.contains(partition))
                if (isProperOTGFolder(resultData.data!!) && isProperPartition) {
                    if (resultData.dataString == baseConfig.treeUri) {
                        funAfterSAFPermission?.invoke(false)
                        toast(R.string.sd_card_usb_same)
                        return
                    }
                    baseConfig.OTGTreeUri = resultData.dataString!!
                    baseConfig.OTGPartition = baseConfig.OTGTreeUri.removeSuffix("%3A").substringAfterLast('/').trimEnd('/')
                    updateOTGPathFromPartition()

                    val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    applicationContext.contentResolver.takePersistableUriPermission(resultData.data!!, takeFlags)

                    funAfterSAFPermission?.invoke(true)
                    funAfterSAFPermission = null
                } else {
                    toast(R.string.wrong_root_selected_usb)
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                    launchActivityForResult(intent, requestCode)
                }
            } else {
                funAfterSAFPermission?.invoke(false)
            }
        } else if (requestCode == SELECT_EXPORT_SETTINGS_FILE_INTENT && resultCode == Activity.RESULT_OK && resultData != null && resultData.data != null) {
            val outputStream = contentResolver.openOutputStream(resultData.data!!)
            exportSettingsTo(outputStream, configItemsToExport)
        }
    }

    fun copyMoveToAsync(
        paths: java.util.ArrayList<FileDirItem>, destination: String, copyOnly: Boolean, copyMediaOnly: Boolean, conflictResolutions: LinkedHashMap<String, Int>,
        listener: CopyMoveListener, copyHidden: Boolean, callback: (destinationPath: String) -> Unit
    ) {
        var mTransferredFiles = java.util.ArrayList<FileDirItem>()
        var mDocuments = LinkedHashMap<String, DocumentFile?>()
        var mFileCountToCopy = 0

        // progress indication
        val mNotificationBuilder: NotificationCompat.Builder = NotificationCompat.Builder(this)
        var mNotifId = (System.currentTimeMillis() / 1000).toInt()
        var mCurrFilename = ""
        var mCurrentProgress = 0
        var mMaxSize = paths.size
        var isProccessSuccess = true
        AsyncBackgroundWork({
            val channelId = "Copy/Move"
            val title = getString(if (copyOnly) R.string.copying else R.string.moving)
            if (isOreoPlus()) {
                val importance = NotificationManager.IMPORTANCE_LOW
                NotificationChannel(channelId, title, importance).apply {
                    enableLights(false)
                    enableVibration(false)
                    notificationManager.createNotificationChannel(this)
                }
            }
            mNotificationBuilder.setContentTitle(title)
                .setSmallIcon(R.drawable.ic_notification)
                .setChannelId(channelId)


            mNotificationBuilder.apply {
                setContentText(mCurrFilename)
                setProgress(mMaxSize, (mCurrentProgress).toInt(), false)
                notificationManager.notify(mNotifId, build())
            }
        }, {
            for (file in paths) {
                try {
                    mCurrentProgress++
                    mCurrFilename = file.path.getFilenameFromPath()

                    val newPath = "$destination/${file.name}"
                    var newFileDirItem = FileDirItem(newPath, newPath.getFilenameFromPath(), file.isDirectory)
                    if (getDoesFilePathExist(newPath)) {
                        Log.d("TAG_COPY", "do in background:Path Exists")
                        val resolution = getConflictResolution(conflictResolutions, newPath)
                        if (resolution == CONFLICT_SKIP) {
                            Log.d("TAG_COPY", "do in background:Conflict skip")
                            mFileCountToCopy--
                            continue
                        } else if (resolution == CONFLICT_OVERWRITE) {
                            Log.d("TAG_COPY", "do in background:Conflict overrite")
                            newFileDirItem.isDirectory = if (getDoesFilePathExist(newPath)) File(newPath).isDirectory else getSomeDocumentFile(newPath)!!.isDirectory
                            deleteFileBg(newFileDirItem, true)
                            if (!newFileDirItem.isDirectory) {
                                deleteFromMediaStore(newFileDirItem.path)
                            }
                        } else if (resolution == CONFLICT_KEEP_BOTH) {
                            Log.d("TAG_COPY", "do in background:Conflict keep both")
                            val newFile = getAlternativeFile(File(newFileDirItem.path))
                            newFileDirItem = FileDirItem(newFile.path, newFile.name, newFile.isDirectory)
                        }
                    }
                    mainscope.launch {
                        baseConfig.lastDestinationPath = file.path.getParentPath()
                        mNotificationBuilder.apply {
                            setContentText(mCurrFilename)
                            setProgress(mMaxSize, (mCurrentProgress).toInt(), false)
                            notificationManager.notify(mNotifId, build())
                        }
                    }

                    Log.d("TAG_COPY", "do in background:  source path -->" + file.path)
                    Log.d("TAG_COPY", "do in background:  Destination Path" + newPath)
                    if (!file.path.isMediaFile()) {
                        continue
                    }

                    val directory = destination.getParentPath()
                    if (!createDirectorySync(directory)) {
                        val error = String.format(getString(com.gallery.photo.image.video.R.string.could_not_create_folder), directory)
                        showErrorToast(error)
                        return@AsyncBackgroundWork
                    }

//                    mCurrFilename = file.name
                    var inputStream: InputStream? = null
                    var out: OutputStream? = null
                    try {
                        if (!mDocuments.containsKey(directory) && needsStupidWritePermissions(newFileDirItem.path)) {
                            mDocuments[directory] = getDocumentFile(directory)
                        }
                        out = getFileOutputStreamSync(newFileDirItem.path, file.path.getMimeType(), mDocuments[directory])
                        inputStream = getFileInputStreamSync(file.path)!!

                        var copiedSize = 0L
                        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                        var bytes = inputStream.read(buffer)
                        while (bytes >= 0) {
                            out!!.write(buffer, 0, bytes)
                            copiedSize += bytes
//                            mCurrentProgress += bytes
                            bytes = inputStream.read(buffer)
                        }

                        out?.flush()
//            Log.d("TAG_COPY", "do in background: Copy File " + source.path)
                        if (getDoesFilePathExist(newFileDirItem.path)) {
                            mTransferredFiles.add(file)
                            if (copyOnly) {
                                rescanPath(newFileDirItem.path) {
                                    if (baseConfig.keepLastModified) {
                                        copyOldLastModified(file.path, newFileDirItem.path)
                                        File(newFileDirItem.path).setLastModified(File(file.path).lastModified())
                                    }
                                }
                            }
                            else if (baseConfig.keepLastModified) {
                                copyOldLastModified(file.path, newFileDirItem.path)
                                File(newFileDirItem.path).setLastModified(File(file.path).lastModified())
                            }

                            if (!copyOnly) {
                                inputStream.close()
                                out?.close()
                                deleteFileBg(file)
                                deleteFromMediaStore(file.path)
                            }

                        }
                    } catch (e: Exception) {
                        showErrorToast(e)
                    } finally {
                        inputStream?.close()
                        out?.close()
                    }
                } catch (e: Exception) {
                    showErrorToast(e)
                    isProccessSuccess = false
                }
            }
        }, {
            baseConfig.isAnyOperationRunning = false
            baseConfig.lastDestinationPath = ""
            Log.d("TAG787878", "itemClicked: " + baseConfig.isAnyOperationRunning)
            Log.d("TAG787878", "itemClicked: " + baseConfig.lastDestinationPath)
            notificationManager.cancel(mNotifId)
            if (isProccessSuccess)
                callback(destination)
            else {
                Log.d("TAGCOPY", "copyFailed: ")
                toast(R.string.copy_move_failed)
                copyMoveCallback = null
            }

//            val listener = mListener?.get() ?: return@AsyncBackgroundWorkCommon
//
//            if (isProccessSuccess) {
//                listener.copySucceeded(copyOnly, mTransferredFiles.size >= mFileCountToCopy, mDestinationPath)
//            } else {
//                listener.copyFailed()
//            }
        })
    }


    private fun copyOldLastModified(sourcePath: String, destinationPath: String) {
        val projection = arrayOf(
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.DATE_MODIFIED
        )
        val uri = MediaStore.Files.getContentUri("external")
        val selection = "${MediaStore.MediaColumns.DATA} = ?"
        var selectionArgs = arrayOf(sourcePath)
        val cursor = applicationContext.contentResolver.query(uri, projection, selection, selectionArgs, null)

        cursor?.use {
            if (cursor.moveToFirst()) {
                val dateTaken = cursor.getLongValue(MediaStore.Images.Media.DATE_TAKEN)
                val dateModified = cursor.getIntValue(MediaStore.Images.Media.DATE_MODIFIED)

                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DATE_TAKEN, dateTaken)
                    put(MediaStore.Images.Media.DATE_MODIFIED, dateModified)
                }

                selectionArgs = arrayOf(destinationPath)
                applicationContext.contentResolver.update(uri, values, selection, selectionArgs)
            }
        }
    }
}
