package com.gallery.photo.image.video.activity

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.hardware.fingerprint.FingerprintManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.Window
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import com.example.app.ads.helper.GiftIconHelper
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.bindActivity.*
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.databinding.ActivityVaultBinding
import com.gallery.photo.image.video.dialog.EnableFakeVaultDialog
import com.gallery.photo.image.video.dialog.NewRateDialog
import com.gallery.photo.image.video.dialog.SetSecurityQuestionDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.lock.activity.CustomPinActivity
import com.gallery.photo.image.video.lock.enums.KeyboardButtonEnum
import com.gallery.photo.image.video.lock.interfaces.KeyboardButtonClickedListener
import com.gallery.photo.image.video.lock.managers.AppLock
import com.gallery.photo.image.video.lock.managers.FingerprintUiHelper
import com.gallery.photo.image.video.lock.managers.LockManager
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.rateandfeedback.ExitSPHelper
import com.gallery.photo.image.video.rateandfeedback.library_feedback.sendEmail
import com.gallery.photo.image.video.rateandfeedback.rateApp
import com.gallery.photo.image.video.utilities.*
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlinx.android.synthetic.main.activity_vault.clConfirmLock
import kotlinx.android.synthetic.main.activity_vault.clSetUpLock
import kotlinx.android.synthetic.main.activity_vault.clVault
import kotlinx.android.synthetic.main.activity_vault.cvAllHiddenFile
import kotlinx.android.synthetic.main.activity_vault.cvPrivateBrowser
import kotlinx.android.synthetic.main.activity_vault.cvScanAudio
import kotlinx.android.synthetic.main.activity_vault.cvScanDocument
import kotlinx.android.synthetic.main.activity_vault.cvScanImages
import kotlinx.android.synthetic.main.activity_vault.cvScanVideo
import kotlinx.android.synthetic.main.activity_vault.cvSecretNote
import kotlinx.android.synthetic.main.activity_vault.cvTrash
import kotlinx.android.synthetic.main.activity_vault.flVaultOptions
import kotlinx.android.synthetic.main.activity_vault.llAllHiddenFile
import kotlinx.android.synthetic.main.activity_vault.llLastOption
import kotlinx.android.synthetic.main.activity_vault.llSetSecurity
import kotlinx.android.synthetic.main.activity_vault.ll_main_linearlayout
import kotlinx.android.synthetic.main.activity_vault.nsvSetUpLock
import kotlinx.android.synthetic.main.activity_vault.pin_code_fingerprint_imageview
import kotlinx.android.synthetic.main.activity_vault.pin_code_fingerprint_textview
import kotlinx.android.synthetic.main.activity_vault.pin_code_forgot_textview
import kotlinx.android.synthetic.main.activity_vault.pin_code_keyboard_view
import kotlinx.android.synthetic.main.activity_vault.pin_code_round_view
import kotlinx.android.synthetic.main.activity_vault.pin_code_step_textview
import kotlinx.android.synthetic.main.activity_vault.tvSetSecurity
import kotlin.math.roundToInt

const val REQUEST_CODE_CHECK_PASSWORD = 501
const val REQUEST_CODE_FAKE_LOCK_SET = 1452

class VaultActivity : BaseBindingActivity<ActivityVaultBinding>(), FingerprintUiHelper.Callback {

    companion object {
        var isHiddenByGallerySelected = true
        var isFakeVaultOpen = false
        var isColumnCountChange = false
        var isLanguageChanges = false
        var isSortingChange = false
        var isTabUnlock = false
        var isNeedToRefresh = false
        var isHideUnHideMedia = true
        var isLoadedGallery = false
        var isLoadedOtherApp = false
        var isFirstTime = true
        var isNeedToShowHiddenByGallery = false
        var isLoadedFakeVaultDir = false
        var fabButtonHeight = 0
        var mMedia = ArrayList<ThumbnailItem>()
//        fun getInstance(position: Int): Fragment {
//            val f: VaultFragment = VaultFragment()
//            val args: Bundle = Bundle()
//            args.putInt("position", position)
//            f.setArguments(args)
//            return f
//        }
    }

    private var isFromOneSignal = false
    private var isFromSettings = false
    val mPermissionStorage = arrayOf(
        android.Manifest.permission.READ_EXTERNAL_STORAGE,
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
    )

    var isEnableFakeVaultDialogDisplay = false
    var fakeVaultDialog: EnableFakeVaultDialog? = null
    var isLoaded = false

    var mPinCode: String? = null
    var mLockManager: LockManager<*>? = null
    var mFingerprintManager: FingerprintManager? = null
    var mFingerprintUiHelper: FingerprintUiHelper? = null
    var mTypePin = AppLock.UNLOCK_PIN
    var mOldPinCode: String? = ""
    var mProgressDailog: ProgressDialog? = null

    private var isAuthError = false

    //    var menuTarget: TapTargetView? = null
    private var isRateDialogDisplay = false

    override fun getContext(): Activity {
        return this@VaultActivity
    }

    override fun initData() {
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = findViewById(R.id.gift_ad_icon),
                fivBlastIcon = findViewById(R.id.gift_blast_ad_icon)
            )
        }
        if (checkPermissionStorage(mContext)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                checkAllFilePermission()
            } else {
                setData()
            }
        } else {
            givePermissions(mPermissionStorage)
        }


        mBinding.imgBack.setOnClickListener {
            onBackPressed()
        }
    }

    override fun initActions() {

    }

    override fun setBinding(): ActivityVaultBinding {
        return ActivityVaultBinding.inflate(inflater)
    }

    override fun onPause() {
        super.onPause()

        if (mFingerprintUiHelper != null)
            mFingerprintUiHelper!!.stopListening()
        runOnUiThread {
            if (fakeVaultDialog != null) {
                fakeVaultDialog!!.dialog.dismiss()
                isEnableFakeVaultDialogDisplay = false
            }
//            if (menuTarget != null)
//                menuTarget!!.dismiss(true)
        }
    }

    private fun checkPermissionStorage(mContext: Activity): Boolean {

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//            if (checkPermissionabove11()) {
//                return true
//            }
//            return false
//        } else {
            return if (ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.READ_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                isUnLockApp = true
                isAppOpenAdShow = false
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(
                        android.Manifest.permission.CAMERA,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        android.Manifest.permission.READ_EXTERNAL_STORAGE
                    ),
                    101
                )
                false
            } else {
                true
            }
//        }


    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                setData()
            } else {
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                try {
                    launchActivityForResult(intent, 2296)
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun givePermissions(permissions: Array<String>) {


        isUnLockApp = true
        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                setData()
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionStorage)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    p0: MutableList<com.karumi.dexter.listener.PermissionRequest>?,
                    token: PermissionToken?
                ) {
                    token!!.continuePermissionRequest()
                }
            }).check()
    }

    private fun showSettingsDialog() {

        isUnLockApp = true
        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
        alertDialogBuilder.setTitle(
            HtmlCompat.fromHtml(
                "<font color='#0a82f3'>" + getString(R.string.error_permission_required) + "</font>",
                HtmlCompat.FROM_HTML_MODE_LEGACY
            )
        )
            .setMessage(getString(R.string.msg_allow_permission_storage))
            .setPositiveButton(getString(R.string.ok))
            { dialog, which ->
                dialog.dismiss()
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)

//                            Share.isAppOpenAdShow = false
            }
            .setNegativeButton(R.string.cancel) { dialog, which ->
                dialog.dismiss()
                finish()
            }
            .setCancelable(false)
        alertDialogBuilder.show()
    }

    private fun setData() {
        initView()
    }

    private fun showLockAlert() {
        findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto).visibility =
            View.GONE
        mTypePin = AppLock.UNLOCK_PIN
        mPinCode = ""
        isLoaded = false
        isLoadedFakeVaultDir = false
        isLoadedGallery = false
        isFakeVaultOpen = false
        llAllHiddenFile.beVisible()
        try {
            mLockManager = LockManager.getInstance()
            Log.e("TAG", "initPinLockView: ==>$mLockManager")
            if (mLockManager!!.getAppLock() == null) {
                mLockManager!!.useForService(mContext)
            }
            mLockManager!!.getAppLock().setPinChallengeCancelled(false)
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
            //FirebaseCrash.report(e);
        }
        pin_code_step_textview.text = getText(R.string.pin_code_step_unlock)
        pin_code_round_view.setPinLength(4)
        pin_code_forgot_textview.visibility = View.VISIBLE
        pin_code_forgot_textview.text = getText(R.string.pin_code_forgot_text)
        pin_code_keyboard_view.setKeyboardButtonClickedListener(object :
            KeyboardButtonClickedListener {
            override fun onKeyboardClick(keyboardButtonEnum: KeyboardButtonEnum) {
                if (mPinCode!!.length < 4) {
                    val value = keyboardButtonEnum.buttonValue
                    if (value == KeyboardButtonEnum.BUTTON_CLEAR.buttonValue) {
                        if (!mPinCode!!.isEmpty()) {
                            setPinCode(mPinCode!!.substring(0, mPinCode!!.length - 1))
                        } else {
                            setPinCode("")
                        }
                    } else {
                        setPinCode(mPinCode + value)
                    }
                }
            }

            override fun onRippleAnimationEnd() {
                if (mPinCode!!.length == 4) {
                    onPinCodeInputed()
                }
            }
        })
        pin_code_forgot_textview.setOnClickListener(View.OnClickListener { openForgotPasswordDialog() })

        pin_code_fingerprint_imageview.setOnClickListener(this)
        initializeFingerprintManager()
    }


    @SuppressLint("CutPasteId")
    override fun onResume() {
        super.onResume()
//        findViewById<TextView>(R.id.tvHeaderTitle).visibility = View.VISIBLE
        if (AdsManager(this@VaultActivity).isNeedToShowAds() && isOnline())
            findViewById<View>(R.id.clGiftIcon).visibility = View.VISIBLE
        else
            findViewById<View>(R.id.clGiftIcon).visibility = View.GONE
//        findViewById<TextView>(R.id.tvHeaderTitle).text = getString(R.string.label_private_gallery)
//        if (requireActivity() is MainActivity) {
//            requireActivity().findViewById<ImageView>(R.id.layOpt).visibility = View.GONE
//            (requireActivity() as MainActivity).hideimgOption()
//        }
        if (config.isAppPasswordProtectionOn && config.isEnableLock) {
//            findViewById<ImageView>(R.id.imgSearch).visibility = View.VISIBLE
//            findViewById<ImageView>(R.id.imgSearch).setImageDrawable(ContextCompat.getDrawable(this@VaultActivity, R.drawable.ic_tab_setting))
        } else {
//            findViewById<ImageView>(R.id.imgSearch).visibility = View.GONE
            if (!isOnline()) {
                findViewById<View>(R.id.clGiftIcon).visibility = View.VISIBLE
            }
        }
        Log.d("TagHidden", "onResume: Vault Fragment")
        if (config.isAppPasswordProtectionOn && config.isEnableLock && !VaultFragment.isTabUnlock && VaultFragment.isFirstTime) {
            clConfirmLock.visibility = View.VISIBLE
//            findViewById<ImageView>(R.id.imgSearch).visibility = View.GONE
            showLockAlert()
        } else {
            clConfirmLock.visibility = View.GONE
            findViewById<View>(R.id.clGiftIcon).visibility = View.GONE

//            if (config.isAppPasswordProtectionOn && config.isEnableLock) {
//                findViewById<ImageView>(R.id.imgSearch).visibility = View.VISIBLE
//            } else {
//                findViewById<ImageView>(R.id.imgSearch).visibility = View.GONE
//            }

            if (!isRateDialogDisplay) {
                val sp = ExitSPHelper(this@VaultActivity)
                if (!sp.isRated() && !sp.isDismissed() && config.hiddenCountForRate >= HIDDEN_COUNT_FOR_RATE_VAL) {
                    isRateDialogDisplay = true
                    NewRateDialog(mContext){
                        if (it > 3) {
                            rateApp()
                        } else if (it >= 0) {
                            sendEmail()
                        }
                    }
                    /*requireActivity().ratingDialog(object : OnRateListener {
                        override fun onRate(rate: Int) {
                            if (rate >= 3) {
                                requireActivity().rateApp()
                            } else if (rate >= 0) {
                                // feedbackDialog()
                                startActivity(FeedbackActivity.newIntent(requireContext(), rate))
                            }
                            isRateDialogDisplay = false
                        }
                    })*/
                }
            }
        }

        if (config.isAppPasswordProtectionOn && config.isEnableLock) {
            clVault.visibility = View.VISIBLE
            clSetUpLock.visibility = View.GONE
//            if (clConfirmLock.visibility == GONE)
//                requireActivity().findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto).visibility = VISIBLE
            flVaultOptions.beVisible()
            if (VaultFragment.isFakeVaultOpen) {
//                findViewById<TextView>(R.id.tvHeaderTitle).text = getString(R.string.label_app_vault)
                llLastOption.setPadding(
                    0, 0,
                    0, 0
                )
                llAllHiddenFile.beGone()
            } else {
                llAllHiddenFile.beVisible()
                val dm = DisplayMetrics()
                mContext.windowManager.defaultDisplay.getMetrics(dm)
                val x = Math.pow((dm.widthPixels / dm.xdpi).toDouble(), 2.0)
                val y = Math.pow((dm.heightPixels / dm.ydpi).toDouble(), 2.0)
                val screenInches = Math.sqrt(x + y)

                if (screenInches <= 5 || mContext.isTablet()) {
                    val r: Resources = mContext.resources
                    var dimen = r.getDimension(R.dimen._5sdp)
                    val px = TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
                    ).roundToInt()
                    var fab = findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto)
                    fab.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
                        override fun onGlobalLayout() {
                            fab.viewTreeObserver.removeOnGlobalLayoutListener(this)
                            llLastOption.setPadding(
                                0, 0,
                                0, fab.height + px
                            )
                        }
                    })
                }
            }
        } else {
            clVault.visibility = View.GONE
            clConfirmLock.visibility = View.GONE
            clSetUpLock.visibility = View.VISIBLE
            if (AdsManager(this@VaultActivity).isNeedToShowAds() && isOnline())
                findViewById<View>(R.id.clGiftIcon).visibility = View.VISIBLE
            else findViewById<View>(R.id.clGiftIcon).visibility = View.GONE
            if (config.isAppPasswordProtectionOn && !config.isEnableLock) {
                VaultFragment.isFirstTime = true
                tvSetSecurity.text = mContext.getString(R.string.label_enable_lock)
            } else {
                tvSetSecurity.text = getString(R.string.label_set_security)
            }

            ll_main_linearlayout.visibility = View.VISIBLE
            nsvSetUpLock.visibility = View.VISIBLE
            findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto).visibility = View.GONE
//            if (requireActivity() is MainActivity) {
//                (requireActivity() as MainActivity).disableToolbarScrolling()
//            }
        }
    }

    private fun initializeFingerprintManager() {
        Log.d("TAG11", "onResume: Vault Fragment initialize finger")
        if (mContext.config.isFingerprintEnable && !mContext.config.isFakeVaultEnable) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                mFingerprintManager =
                    mContext.getSystemService(Service.FINGERPRINT_SERVICE) as FingerprintManager
                mFingerprintUiHelper =
                    FingerprintUiHelper.FingerprintUiHelperBuilder(mFingerprintManager)
                        .build(pin_code_fingerprint_imageview, pin_code_fingerprint_textview, this)
                FingerprintUiHelper.isFromVault = false
                try {
                    if (mFingerprintManager != null && mFingerprintManager!!.isHardwareDetected() && mFingerprintUiHelper!!.isFingerprintAuthAvailable()
                        && mLockManager!!.appLock.isFingerprintAuthEnabled
                    ) {
                        pin_code_fingerprint_imageview.visibility = View.VISIBLE
                        pin_code_fingerprint_textview.visibility = View.VISIBLE
                        pin_code_fingerprint_textview.text =
                            mContext.getString(R.string.pin_code_fingerprint_text)
                        pin_code_fingerprint_textview.setTextColor(
                            mContext.resources.getColor(R.color.textGray, null)
                        )
                        mFingerprintUiHelper!!.startListening()
                        isAuthError = false
                    } else {
                        pin_code_fingerprint_imageview.visibility = View.GONE
                        pin_code_fingerprint_textview.visibility = View.GONE
                    }
                } catch (e: SecurityException) {
                    Log.e("TAG", e.toString())
                    pin_code_fingerprint_imageview.visibility = View.GONE
                    pin_code_fingerprint_textview.visibility = View.GONE
                }

            } else {
                pin_code_fingerprint_imageview.visibility = View.GONE
                pin_code_fingerprint_textview.visibility = View.GONE
            }
        } else {
            pin_code_fingerprint_imageview.visibility = View.GONE
            pin_code_fingerprint_textview.visibility = View.GONE
        }
    }

    private fun openForgotPasswordDialog() {

        val view = layoutInflater.inflate(R.layout.dialog_set_security_question, null)
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val ivClose = dialog.findViewById<ImageView>(R.id.ivClose)
        val etSeqAns = dialog.findViewById<EditText>(R.id.etSeqAns)
        val spSecQue = dialog.findViewById<Spinner>(R.id.spSecQue)
        val selectedSecQue = arrayOf("")
        val selectedPos = intArrayOf(0)
        spSecQue.setSelection(0)
        etSeqAns.text = null
        spSecQue.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View,
                position: Int,
                id: Long
            ) {
                selectedSecQue[0] = spSecQue.selectedItem as String
                selectedPos[0] = spSecQue.selectedItemPosition
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        ivClose.setOnClickListener { dialog.dismiss() }

        val tvDone = dialog.findViewById<TextView>(R.id.tvDone)
        tvDone.setOnClickListener {
            if (selectedPos[0] == 0) {
                Toast.makeText(
                    mContext,
                    getString(R.string.error_msg_please_select_que),
                    Toast.LENGTH_SHORT
                ).show()
            } else if (etSeqAns.text.toString().isEmpty()) {
                Toast.makeText(
                    mContext,
                    getString(R.string.error_please_enter_answer),
                    Toast.LENGTH_SHORT
                ).show()
            } else if (etSeqAns.text.toString().length < 5) {
                Toast.makeText(
                    mContext,
                    getString(R.string.error_msg_please_enter_valid_answer),
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                if (selectedPos[0] != mContext.config.securityQuestionIndex
                    || etSeqAns.text.toString() != mContext.config.securityAnswer
                ) {
                    Toast.makeText(
                        mContext,
                        getString(R.string.msg_security_invalid),
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(
                        mContext,
                        getString(R.string.msg_match_successfully),
                        Toast.LENGTH_SHORT
                    ).show()
//                    mContext.config.isFingerprintEnable = false
                    pin_code_fingerprint_imageview.visibility = View.GONE
                    pin_code_fingerprint_textview.visibility = View.GONE
                    mTypePin = AppLock.ENABLE_PINLOCK
                    setStepText()
                    pin_code_forgot_textview!!.visibility = View.INVISIBLE
                    setPinCode("")
                }
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    fun setPinCode(pinCode: String?) {
        mPinCode = pinCode
        pin_code_round_view!!.refresh(mPinCode!!.length)
    }

    fun onPinCodeInputed() {
        when (mTypePin) {
            AppLock.ENABLE_PINLOCK -> {
                when {
                    mContext.config.fakeVaultAppLock == mPinCode -> {
                        Toast.makeText(
                            mContext,
                            getString(R.string.error_app_lock_and_fake_lock_not_same),
                            Toast.LENGTH_SHORT
                        ).show();
                        setPinCode("")
                    }
                    else -> {
                        mOldPinCode = mPinCode
                        setPinCode("")
                        mTypePin = AppLock.CONFIRM_PIN
                        setStepText()
                        pin_code_forgot_textview.visibility = View.INVISIBLE
                    }
                }
            }
            AppLock.CONFIRM_PIN -> if (mPinCode == mOldPinCode) {
                mLockManager!!.appLock!!.setPasscode(mPinCode)
                config.appVaultAppLock = mPinCode.toString()
                stopAlert()
            } else {
                mOldPinCode = ""
                setPinCode("")
                mTypePin = AppLock.ENABLE_PINLOCK
                setStepText()
                pin_code_forgot_textview.visibility = View.INVISIBLE
                onPinCodeError()
            }
            AppLock.UNLOCK_PIN -> {
                pin_code_forgot_textview.visibility = View.VISIBLE
                try {
                    if (mContext.config.appVaultAppLock == "") {
                        if (mLockManager!!.appLock!!.checkPasscode(mPinCode)) {
                            mContext.config.appVaultAppLock = mPinCode.toString()
                            stopAlert()
                        } else {
                            onPinCodeError()
                        }
                    } else {
                        if (mContext.config.appVaultAppLock == mPinCode) {
                            stopAlert()
                        } else if (mContext.config.isFakeVaultEnable && mContext.config.fakeVaultAppLock == mPinCode) {
                            stopAlertForFakeVault()
                        } else {
                            onPinCodeError()
                        }
                    }
                } catch (e: Exception) {
                }
            }
            else -> {
            }
        }
    }

    private fun stopAlertForFakeVault() {
//        if (isAdded) {
        mContext.addEvent(fakeVaultOpen)
//        }
        isFakeVaultOpen = true
        clConfirmLock.visibility = View.GONE
        isFirstTime = false
        isTabUnlock = true
        flVaultOptions.beVisible()
        cvAllHiddenFile.beGone()

        llLastOption.setPadding(
            0, 0,
            0, 0
        )
//        findViewById<TextView>(R.id.tvHeaderTitle).text = getString(R.string.label_app_vault)
//        if (requireActivity() is MainActivity) {
        enableToolbarScrolling()
//            if (viewPagerHome.currentItem == 2) {
        findViewById<View>(R.id.clGiftIcon).visibility = View.GONE
//        findViewById<ImageView>(R.id.imgSearch).visibility = View.VISIBLE
//                findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto).visibility = VISIBLE
//        findViewById<ImageView>(R.id.imgSearch).setImageDrawable(
//            ContextCompat.getDrawable(
//                mContext,
//                R.drawable.ic_tab_setting
//            )
//        )
//    }
//        }


    }

    fun disableToolbarScrolling() {
//    val params: AppBarLayout.LayoutParams = toolbar.layoutParams as AppBarLayout.LayoutParams
//    params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_NO_SCROLL
//    appBarLayout.requestLayout()
    }

    fun enableToolbarScrolling() {
//    val params: AppBarLayout.LayoutParams = toolbar.layoutParams as AppBarLayout.LayoutParams
//    params.scrollFlags =
//        AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL or AppBarLayout.LayoutParams.SCROLL_FLAG_ENTER_ALWAYS
//    appBarLayout.requestLayout()
    }

    private fun stopAlert() {
//    if (isAdded) {
        addEvent(appVaultOpen)
//    }
        clConfirmLock.visibility = View.GONE
        isFirstTime = false
        isTabUnlock = true
        isNeedToRefresh = true
        isLoadedGallery = false
        isLoadedOtherApp = false
        flVaultOptions.beVisible()
        val dm = DisplayMetrics()
        mContext.windowManager.defaultDisplay.getMetrics(dm)
        val x = Math.pow((dm.widthPixels / dm.xdpi).toDouble(), 2.0)
        val y = Math.pow((dm.heightPixels / dm.ydpi).toDouble(), 2.0)
        val screenInches = Math.sqrt(x + y)

        if (screenInches <= 5 || mContext.isTablet()) {
            val r: Resources = mContext.resources
            var dimen = r.getDimension(R.dimen._5sdp)
            val px = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
            ).roundToInt()
            llLastOption.setPadding(
                0, 0,
                0, findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto).height + px
            )
        }
//        findViewById<TextView>(R.id.tvHeaderTitle).text = getString(R.string.label_private_gallery)
//        if (requireActivity() is MainActivity) {

        enableToolbarScrolling()

//            if (viewPagerHome.currentItem == 2) {
        findViewById<View>(R.id.clGiftIcon).visibility = View.GONE
        findViewById<ImageView>(R.id.imgSearch).visibility = View.VISIBLE
//                findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto).visibility = VISIBLE
        findViewById<ImageView>(R.id.imgSearch).setImageDrawable(
            ContextCompat.getDrawable(
                mContext,
                R.drawable.ic_tab_setting
            )
        )

        Log.d("111TAG", "stopAlert: --> Required activity is MainActivity ")
        if (!isRateDialogDisplay) {

            val sp = ExitSPHelper(mContext)
            if (!sp.isRated() && !sp.isDismissed() && mContext.config.hiddenCountForRate >= HIDDEN_COUNT_FOR_RATE_VAL) {
                isRateDialogDisplay = true
                NewRateDialog(mContext) {
                    if (it > 3) {
                        mContext.rateApp()
                    } else if (it >= 0) {
                        mContext.sendEmail()
                    }
                }
                /*  ratingDialog(object : OnRateListener {
                      override fun onRate(rate: Int) {
                          if (rate >= 3) {
                              rateApp()
                          } else if (rate >= 0) {
                              // feedbackDialog()
                              startActivity(FeedbackActivity.newIntent(mContext, rate))
                          }
                          isRateDialogDisplay = false
                      }
                  })*/
            }
        }
//            }
//        }

        //Fake Vault
//        if (!isEnableFakeVaultDialogDisplay) {
        if (!mContext.config.isFakeVaultDialogShown && !mContext.config.isFakeVaultEnable && mContext.config.fakeVaultAppLock == "") {
            mContext.config.isFakeVaultDialogShown = true
            isEnableFakeVaultDialogDisplay = true
            fakeVaultDialog = EnableFakeVaultDialog(this@VaultActivity) {
                if (it) {
                    if (mContext.config.fakeVaultAppLock == "") {
                        val intent = Intent(this@VaultActivity, CustomPinActivity::class.java)
                        intent.putExtra(AppLock.EXTRA_TYPE, AppLock.ENABLE_PINLOCK)
                        intent.putExtra(INTENT_LOCK_TYPE, INTENT_LOCK_TYPE_FAKE)
                        launchActivityForResult(
                            intent,REQUEST_CODE_FAKE_LOCK_SET
                        )
//                        startActivityForResult(intent, REQUEST_CODE_CHECK_PASSWORD)
                    } else {
                        mContext.config.isFakeVaultEnable = true
                    }
                }
            }
        }


    }


    fun onPinCodeError() {
        // onPinFailure(mAttempts++);
        //Thread thread = new Thread() {
        //  void run() {
        mPinCode = ""
        pin_code_round_view!!.refresh(mPinCode!!.length)
        val animation = AnimationUtils.loadAnimation(
            mContext, R.anim.shake_lock
        )
        pin_code_keyboard_view.startAnimation(animation)
        /*    }
        };
        mAlertView.runOnUiThread(thread);*/
    }

    fun setStepText() {
        pin_code_step_textview.text = getStepText(mTypePin)
    }

    fun getStepText(reason: Int): String? {
        var msg: String? = null
        when (reason) {
            AppLock.DISABLE_PINLOCK -> msg = getString(R.string.pin_code_step_disable, 4)
            AppLock.ENABLE_PINLOCK -> msg = getString(R.string.pin_code_step_create, 4)
            AppLock.CHANGE_PIN -> msg = getString(R.string.pin_code_step_change, 4)
            AppLock.UNLOCK_PIN -> msg =
                getString(R.string.pin_code_step_unlock) //, this.getPinLength());
            AppLock.CONFIRM_PIN -> msg = getString(R.string.pin_code_step_enable_confirm, 4)
        }
        return msg
    }

    override fun onAuthenticated() {
        stopAlert()
    }

    override fun onError() {
        isAuthError = true
    }

    private fun initView() {
        if (mContext.config.isAppPasswordProtectionOn && mContext.config.isEnableLock) {
            clVault.visibility = View.VISIBLE
            clSetUpLock.visibility = View.GONE
        } else {
            clVault.visibility = View.GONE
            clSetUpLock.visibility = View.VISIBLE
            ll_main_linearlayout.visibility = View.VISIBLE
            nsvSetUpLock.visibility = View.VISIBLE
        }

        llSetSecurity.setOnClickListener {
            if (mContext.config.isAppPasswordProtectionOn && !mContext.config.isEnableLock) {
                mContext.config.isEnableLock = true
                isTabUnlock = true
                clConfirmLock.visibility = View.VISIBLE
//                findViewById<ImageView>(R.id.imgSearch).visibility = View.GONE
                showLockAlert()
                clVault.visibility = View.VISIBLE
                clSetUpLock.visibility = View.GONE
            } else {
                SetSecurityQuestionDialog(this@VaultActivity) {
                    val intent = Intent(this@VaultActivity, CustomPinActivity::class.java)
                    intent.putExtra(AppLock.EXTRA_TYPE, AppLock.ENABLE_PINLOCK)
                    launchActivityForResult(
                        intent,REQUEST_CODE_CHECK_PASSWORD
                    )
                }
            }
        }
        cvScanImages.setOnClickListener(this)
        cvScanVideo.setOnClickListener(this)
        cvScanAudio.setOnClickListener(this)
        cvScanDocument.setOnClickListener(this)
        cvSecretNote.setOnClickListener(this)
        cvPrivateBrowser.setOnClickListener(this)
        cvTrash.setOnClickListener(this)
        cvAllHiddenFile.setOnClickListener(this)

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_CODE_CHECK_PASSWORD -> {
                if (resultCode == RESULT_OK) {
                    Toast.makeText(
                        mContext,
                        getString(R.string.msg_lock_set_sccessfully),
                        Toast.LENGTH_SHORT
                    ).show()
                    clVault.visibility = View.VISIBLE
                    clSetUpLock.visibility = View.GONE
                    mContext.config.isAppPasswordProtectionOn = true
                    mContext.config.isEnableLock = true
                    isUnLockApp = false
                }
            }
            REQUEST_CODE_FAKE_LOCK_SET -> {
                if (resultCode == RESULT_OK) {
                    Toast.makeText(
                        mContext,
                        getString(R.string.msg_fake_vault_set_successfully),
                        Toast.LENGTH_SHORT
                    ).show()
                    addEvent(fakeVaultSet)
                    clVault.visibility = View.VISIBLE
                    clSetUpLock.visibility = View.GONE
                    isUnLockApp = false
//                    menuTarget = TapTargetView.showFor(mContext,
//                        TapTarget.forView(findViewById<ImageView>(R.id.imgSearch), "", getString(R.string.msg_switch_fake_vault))
//                            .cancelable(true)
//                            .textColor(R.color.white)
//                            .descriptionTextColor(R.color.white)
//                            .descriptionTextAlpha(1f)
//                            .tintTarget(true),
//                        object : TapTargetView.Listener() {
//                            override fun onTargetClick(view: TapTargetView) {
//                                super.onTargetClick(view)
//                                view.dismiss(true)
//
//                            }
//
//                            override fun onTargetCancel(view: TapTargetView?) {
//                                super.onTargetCancel(view)
//
//                            }
//
//                        })
                }
            }

        }
    }

    override fun onClick(v: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        when (v!!.id) {
            R.id.pin_code_fingerprint_imageview -> {
                if (mFingerprintUiHelper != null && isAuthError) {
                    isAuthError = false
                    mFingerprintUiHelper!!.stopListening()
                    initializeFingerprintManager()
                }
            }
            R.id.cvScanImages -> {
//                if (isAdded) {
                mContext.addEvent(vaultImageClick)
//                }
                startActivity(HiddenImagesActivity.newIntent(mContext, true, false))
            }
            R.id.cvScanVideo -> {
//                if (isAdded) {
                mContext.addEvent(vaultVideoClick)
//                }
                startActivity(HiddenImagesActivity.newIntent(mContext, false, true))
            }
            R.id.cvScanAudio -> {
//                if (isAdded) {
                mContext.addEvent(vaultAudioClick)
//                }
//                toast("Coming soon...")
                startActivity(HiddenAudioActivity.newIntent(mContext, true))
            }
            R.id.cvScanDocument -> {
//                if (isAdded) {
                mContext.addEvent(vaultDocumentClick)
//                }
//                toast("Coming soon...")
                startActivity(HiddenAudioActivity.newIntent(mContext, false))
            }
            R.id.cvSecretNote -> {
//                if (isAdded) {
                mContext.addEvent(vaultNotesClick)
//                }
//                toast("Coming soon...")
                startActivity(SecretNotesActivity.newIntent(mContext))
            }
            R.id.cvPrivateBrowser -> {
//                if (isAdded) {
                mContext.addEvent(vaultPrivateBrowserClick)
//                }
//                toast("Coming soon...")
                startActivity(PrivateBrowserActivity.newIntent(mContext))
            }
            R.id.cvTrash -> {
//                if (isAdded) {
                mContext.addEvent(vaultTrashClick)
//                }
//                toast("Coming soon...")
                startActivity(TrashActivity.newIntent(mContext))
//                Intent(mContext, TempTrashActivity::class.java).apply {
//                    putExtra(SKIP_AUTHENTICATION, true)
//                    flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
//                    putExtra(DIRECTORY, "")
//                    putExtra(SHOW_ONLY_HIDDEN, false)
//                    putExtra(GET_IMAGE_INTENT, true)
//                    putExtra(GET_VIDEO_INTENT, false)
//                    putExtra(GET_ANY_INTENT, false)
//                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
////                startActivityForResult(this, PICK_MEDIA)
//                    launchActivityForResult(this, 455)
//                }
            }
            R.id.cvAllHiddenFile -> {
//                if (isAdded) {
                mContext.addEvent(vaultHiddenAllFileClick)
//                }
//                                toast("Coming soon...")
                startActivity(AllHiddenFileActivity.newIntent(mContext))
            }

        }
    }


}