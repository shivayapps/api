package com.gallery.photo.image.video.dialog

import android.app.Activity
import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogOtherAspectRatioBinding

class OtherAspectRatioDialog(
    var mContext: Activity,
    val lastOtherAspectRatio: Pair<Float, Float>?=null,
    val callback: (aspectRatio: Pair<Float, Float>) -> Unit
) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogOtherAspectRatioBinding

//    var selectedAspectRatio : Pair<Float, Float>=Pair(0f, 0f)
    var selectedAspectRatio=Pair(1f, 1f)


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogOtherAspectRatioBinding.inflate(layoutInflater, container, false)
        intView()
        intListener()
        return bindingDialog.root
    }


    private fun ratioPicked(pair: Pair<Float, Float>) {
        selectedAspectRatio=pair
        callback(pair)
        dialog?.dismiss()
    }

    private fun customRatioPicked() {

        val customAspectRatioDialog =CustomAspectRatioDialog(mContext, lastOtherAspectRatio) {
            callback(it)
            dialog?.dismiss()
        }
        customAspectRatioDialog.show(childFragmentManager,customAspectRatioDialog.tag)
    }
    private fun intView() {
        if(lastOtherAspectRatio!=null) {
            selectedAspectRatio=lastOtherAspectRatio
        }
        bindingDialog.apply {
            otherAspectRatio21.setOnClickListener { ratioPicked(Pair(2f, 1f)) }
            otherAspectRatio32.setOnClickListener { ratioPicked(Pair(3f, 2f)) }
            otherAspectRatio43.setOnClickListener { ratioPicked(Pair(4f, 3f)) }
            otherAspectRatio53.setOnClickListener { ratioPicked(Pair(5f, 3f)) }
            otherAspectRatio169.setOnClickListener { ratioPicked(Pair(16f, 9f)) }
            otherAspectRatio199.setOnClickListener { ratioPicked(Pair(19f, 9f)) }
            otherAspectRatioCustom.setOnClickListener {
                customRatioPicked()
            }

            otherAspectRatio12.setOnClickListener { ratioPicked(Pair(1f, 2f)) }
            otherAspectRatio23.setOnClickListener { ratioPicked(Pair(2f, 3f)) }
            otherAspectRatio34.setOnClickListener { ratioPicked(Pair(3f, 4f)) }
            otherAspectRatio35.setOnClickListener { ratioPicked(Pair(3f, 5f)) }
            otherAspectRatio916.setOnClickListener { ratioPicked(Pair(9f, 16f)) }
            otherAspectRatio919.setOnClickListener { ratioPicked(Pair(9f, 19f)) }

            val radio1SelectedItemId = when (lastOtherAspectRatio) {
                Pair(2f, 1f) -> otherAspectRatio21.id
                Pair(3f, 2f) -> otherAspectRatio32.id
                Pair(4f, 3f) -> otherAspectRatio43.id
                Pair(5f, 3f) -> otherAspectRatio53.id
                Pair(16f, 9f) -> otherAspectRatio169.id
                Pair(19f, 9f) -> otherAspectRatio199.id
                else -> 0
            }
            otherAspectRatioDialogRadio1.check(radio1SelectedItemId)

            val radio2SelectedItemId = when (lastOtherAspectRatio) {
                Pair(1f, 2f) -> otherAspectRatio12.id
                Pair(2f, 3f) -> otherAspectRatio23.id
                Pair(3f, 4f) -> otherAspectRatio34.id
                Pair(3f, 5f) -> otherAspectRatio35.id
                Pair(9f, 16f) -> otherAspectRatio916.id
                Pair(9f, 19f) -> otherAspectRatio919.id
                else -> 0
            }
            otherAspectRatioDialogRadio2.check(radio2SelectedItemId)

            if (radio1SelectedItemId == 0 && radio2SelectedItemId == 0) {
                otherAspectRatioDialogRadio1.check(otherAspectRatioCustom.id)
            }
        }


    }

    private fun intListener() {

//        bindingDialog.btnCancel.setOnClickListener { dismiss() }
//
//        bindingDialog.btnResize.setOnClickListener {
//
//            callback.invoke(selectedAspectRatio)
//
//        }
    }



    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}

