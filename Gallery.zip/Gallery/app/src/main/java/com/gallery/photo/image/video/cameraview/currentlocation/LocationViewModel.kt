package com.gallery.photo.image.video.cameraview.currentlocation

import android.app.Application
import androidx.lifecycle.AndroidViewModel

class LocationViewModel(application: Application) : AndroidViewModel(application) {

    private val locationData = LocationLiveData(application)
    private val locationDialogData = LocationLiveData(application)

    fun getLocationData() = locationData
    fun getLocationDialogData() = locationDialogData
}
