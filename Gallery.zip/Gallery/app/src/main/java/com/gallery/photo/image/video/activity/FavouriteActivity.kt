package com.gallery.photo.image.video.activity

import android.app.Activity
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.example.app.ads.helper.GiftIconHelper
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activityBinding.BaseBindingActivity
import com.gallery.photo.image.video.adapter.MediaAdapter
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.databinding.ActivityFavouriteBinding

import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.models.ThumbnailSection
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.helpers.FAVORITES
import com.gallery.photo.image.video.helpers.VIEW_TYPE_GRID
import com.gallery.photo.image.video.helpers.VIEW_TYPE_LIST
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager
import com.gallery.photo.image.video.views.MyRecyclerView
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.videoplayer.VideoPlayerActivity
import org.jetbrains.anko.toast
import vi.imagestopdf.CreatePDFListener

import java.io.File
import java.io.IOException
import java.util.ArrayList
import java.util.HashMap

class FavouriteActivity : BaseBindingActivity<ActivityFavouriteBinding>(), MediaOperationsListener, CreatePDFListener {
    var title: String? = null
    private var mPath = "favorites"
    private var mIsGetImageIntent = false
    private var mIsGetVideoIntent = false
    private var mIsGetAnyIntent = false
    private var mIsGettingMedia = false
    private var mAllowPickingMultiple = false
    private var mShowAll = false
    private var mLoadedInitialPhotos = false
    private var mDateFormat = ""
    private var mTimeFormat = ""
    private var mLatestMediaId = 0L
    private var mLatestMediaDateId = 0L
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mSearchMenuItem: MenuItem? = null
    private var mLastSearchedText = ""
    var isHide = true
    override fun setBinding(): ActivityFavouriteBinding {
        return ActivityFavouriteBinding.inflate(inflater)
    }

    override fun getContext(): Activity {
        return this
    }

    override fun getAppIconIDs() = arrayListOf(

        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun initData() {
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = findViewById(R.id.gift_ad_icon),
                fivBlastIcon = findViewById(R.id.gift_blast_ad_icon)
            )
        }
        mBinding.imgBack.setOnClickListener {
            onBackPressed()
        }
        mBinding.llHideOpt.setOnClickListener(this)
        mBinding.llShareOpt.setOnClickListener(this)
    }

    override fun initViews() {
        mPath = "favorites"
        mBinding.mediaRefreshLayout.setOnRefreshListener { getMedia() }


    }

    override fun onResume() {
        super.onResume()
        Log.d("TAG", "onResume: FavouritActivity")
        getMedia()
        if(getMediaAdapter()!=null)
        {
            getMediaAdapter()!!.dismissProgress()
        }
    }

    override fun initActions() {
    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.imgBack -> {
                onBackPressed()
            }
            R.id.imgSearch -> {
//                etSearch.visibility = VISIBLE
            }
            R.id.llShareOpt -> {
                if (getMediaAdapter() != null)
                    getMediaAdapter()!!.shareMedia()
            }
            R.id.llHideOpt -> {
                if (getMediaAdapter() != null)
                    getMediaAdapter()!!.toggleFileVisibility(isHide)
            }
        }
    }

    private fun getMedia() {
        Log.d("TAG", "onResume: getMedia")
        startAsyncTask()
    }

    private fun startAsyncTask() {
        getFavouriteMedia(mPath, mIsGetImageIntent, mIsGetVideoIntent, mShowAll, TYPE_IMAGES or TYPE_VIDEOS, GROUP_BY_NONE) {
            ensureBackgroundThread {
                val newMedia = it
                try {
                    gotMedia(newMedia, false)
                } catch (e: Exception) {
                }
            }

        }
    }

    private fun gotMedia(media: ArrayList<ThumbnailItem>, isFromCache: Boolean) {
        mIsGettingMedia = false
        mMedia = media

        runOnUiThread {
            mBinding.mediaRefreshLayout.isRefreshing = false
            mBinding.mediaEmptyTextPlaceholder.beVisibleIf(media.isEmpty() && !isFromCache)
            if (media.isEmpty())
                if (AdsManager(this).isNeedToShowAds()) {
                    NativeAdvancedModelHelper(this).loadNativeAdvancedAd(
                        NativeAdsSize.Big,
                        findViewById(R.id.adViewContainer)
                    )
                }
            if (mBinding.mediaEmptyTextPlaceholder.isVisible()) {
                mBinding.mediaEmptyTextPlaceholder.text = getString(R.string.no_media_with_filters)
            }
            mBinding.mediaGrid.beVisibleIf(mBinding.mediaEmptyTextPlaceholder.isGone())

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            val allowHorizontalScroll = config.scrollHorizontally && viewType == VIEW_TYPE_GRID
            mBinding.mediaVerticalFastscroller.beVisibleIf(mBinding.mediaGrid.isVisible() && !allowHorizontalScroll)
            mBinding.mediaHorizontalFastscroller.beVisibleIf(mBinding.mediaGrid.isVisible() && allowHorizontalScroll)
            setupAdapter()
        }
    }

    private fun getMediaAdapter() = mBinding.mediaGrid.adapter as? MediaAdapter

    private fun setupAdapter() {
        if (!mShowAll && isDirEmpty()) {
            return
        }

        val currAdapter = mBinding.mediaGrid.adapter
        if (currAdapter == null) {
            val fastscroller = if (config.scrollHorizontally) mBinding.mediaHorizontalFastscroller else mBinding.mediaVerticalFastscroller
            MediaAdapter(
                this, mMedia.clone() as ArrayList<ThumbnailItem>, this, this, mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent,
                mAllowPickingMultiple, mPath, mBinding.mediaGrid, fastscroller
            ) {
                if (it is Medium && !isFinishing) {
                    itemClicked(it.path)
                }
            }.apply {
                mBinding.mediaGrid.adapter = this
            }

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            if (viewType == VIEW_TYPE_LIST) {
                mBinding.mediaGrid.scheduleLayoutAnimation()
            }

            setupLayoutManager()
            handleGridSpacing()
            measureRecyclerViewContent(mMedia)
        } else if (mLastSearchedText.isEmpty()) {
            (currAdapter as MediaAdapter).updateMedia(mMedia)
            handleGridSpacing()
            measureRecyclerViewContent(mMedia)
        }

        setupScrollDirection()
    }

    private fun itemClicked(path: String) {
        if (isSetWallpaperIntent()) {
            toast(R.string.setting_wallpaper)

            val wantedWidth = wallpaperDesiredMinimumWidth
            val wantedHeight = wallpaperDesiredMinimumHeight
            val ratio = wantedWidth.toFloat() / wantedHeight

            val options = RequestOptions()
                .override((wantedWidth * ratio).toInt(), wantedHeight)
                .fitCenter()

            Glide.with(this)
                .asBitmap()
                .load(File(path))
                .apply(options)
                .into(object : SimpleTarget<Bitmap>() {
                    override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                        try {
                            WallpaperManager.getInstance(applicationContext).setBitmap(resource)
                            setResult(Activity.RESULT_OK)
                        } catch (ignored: IOException) {
                        }

                        finish()
                    }
                })
        } else {
            val isVideo = path.isVideoFast()
            if (isVideo) {

                val extras = HashMap<String, Boolean>()
                extras[SHOW_FAVORITES] = mPath == FAVORITES

                if (shouldSkipAuthentication()) {
                    extras[SKIP_AUTHENTICATION] = true
                }
//                openPath(path, false, extras)
                val uri = FileProvider.getUriForFile(
                    this,
                    "$packageName.fileprovider", File(path)
                )
                var media = MediaActivity.mMedia as ArrayList<Medium>
                media = media.filter { medium ->
                    medium.isVideo() && medium.path.getFilenameExtension() != ".avi" && medium.path.getFilenameExtension() != ".flv"
                } as ArrayList<Medium>
                var uriList = media.map {
                    FileProvider.getUriForFile(
                        this,
                        "$packageName.fileprovider", File(it.path)
                    )
                }

                val mimeType = getUriMimeType(path, uri)
                if (VideoPlayerActivity.mActivity != null) {
                    VideoPlayerActivity.mActivity.finish()
                }

                val extension: String = uri.path!!.substring(uri.path!!.lastIndexOf("."))

                if (extension == ".avi" || extension == ".flv") {
                    val file: File = File(uri.path)
                    Log.e("TAG", "loadVideo:absolutePath --> " + file.absolutePath)

                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.setDataAndType(Uri.parse(file.absolutePath.replace("/external_files", "")), "video/*")
                    try {
                        startActivity(intent)
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(getContext(), R.string.error_no_video_activity, Toast.LENGTH_SHORT).show()
                    }

                } else {
                    VideoPlayerActivity.UriList = uriList
                    VideoPlayerActivity.index = uriList.indexOf(uri)
                    Intent(applicationContext, VideoPlayerActivity::class.java).apply {
                        setDataAndType(uri, mimeType)
                        addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT)

                        if (intent.extras != null) {
                            putExtras(intent.extras!!)
                        }

                        startActivity(this)
                        overridePendingTransition(0, 0);
                    }
                }
            } else {
                ImagePreviewActivity.mPlaceItemList = mMedia
                Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(SKIP_AUTHENTICATION, shouldSkipAuthentication())
                    putExtra(PATH, path)
                    putExtra(SHOW_ALL, mShowAll)
                    putExtra(SHOW_FAVORITES, true)
                    putExtra(SHOW_RECYCLE_BIN, mPath == RECYCLE_BIN)
                    startActivity(this)
                }
            }
        }
    }

    private fun shouldSkipAuthentication() = intent.getBooleanExtra(SKIP_AUTHENTICATION, false)

    private fun isSetWallpaperIntent() = intent.getBooleanExtra(SET_WALLPAPER_INTENT, false)

    private fun setupLayoutManager() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            setupGridLayoutManager()
        } else {
            setupListLayoutManager()
        }
    }

    private fun setupGridLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = 0
            bottomMargin = 0
        }

        if (config.scrollHorizontally) {
            layoutManager.orientation = RecyclerView.HORIZONTAL
        } else {
            layoutManager.orientation = RecyclerView.VERTICAL
        }

//        layoutManager.spanCount = config.mediaColumnCnt
        layoutManager.spanCount = 3
        val adapter = getMediaAdapter()
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter?.isASectionTitle(position) == true) {
                    layoutManager.spanCount
                } else {
                    1
                }
            }
        }
    }

    private fun setupScrollDirection() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        val allowHorizontalScroll = config.scrollHorizontally && viewType == VIEW_TYPE_GRID
        mBinding.mediaVerticalFastscroller.isHorizontal = false
        mBinding.mediaVerticalFastscroller.beGoneIf(allowHorizontalScroll)

        mBinding.mediaHorizontalFastscroller.isHorizontal = true
        mBinding.mediaHorizontalFastscroller.beVisibleIf(allowHorizontalScroll)

        val sorting = config.getFolderSorting(if (mShowAll) SHOW_ALL else mPath)
        if (allowHorizontalScroll) {
            mBinding.mediaHorizontalFastscroller.setViews(mBinding.mediaGrid, mBinding.mediaRefreshLayout) {
                mBinding.mediaHorizontalFastscroller.updateBubbleText(getBubbleTextItem(it, sorting!!))
            }
        } else {
            mBinding.mediaVerticalFastscroller.setViews(mBinding.mediaGrid, mBinding.mediaRefreshLayout) {
                mBinding.mediaVerticalFastscroller.updateBubbleText(getBubbleTextItem(it, sorting!!))
            }
        }
    }

    private fun getBubbleTextItem(index: Int, sorting: Int): String {
        var realIndex = index
        val mediaAdapter = getMediaAdapter()
        if (mediaAdapter!!.isASectionTitle(index)) {
            realIndex++
        }
        return mediaAdapter.getItemBubbleText(realIndex, sorting, mDateFormat, mTimeFormat) ?: ""
    }

    private fun isDirEmpty(): Boolean {
        return mMedia.size <= 0 && config.filterMedia > 0
    }

    private fun initZoomListener() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
            mZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 1) {
                        reduceColumnCount()
                        getMediaAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT) {
                        increaseColumnCount()
                        getMediaAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            mZoomListener = null
        }
    }

    private fun setupListLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL

        val smallMargin = resources.getDimension(R.dimen.small_margin).toInt()
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = smallMargin
            bottomMargin = smallMargin
        }

        mZoomListener = null
    }

    private fun increaseColumnCount() {
        config.mediaColumnCnt = ++(mBinding.mediaGrid.layoutManager as MyGridLayoutManager).spanCount
        columnCountChanged()
    }

    private fun reduceColumnCount() {
        config.mediaColumnCnt = --(mBinding.mediaGrid.layoutManager as MyGridLayoutManager).spanCount
        columnCountChanged()
    }

    private fun columnCountChanged() {
        handleGridSpacing()
        ActivityCompat.invalidateOptionsMenu(this)
        getMediaAdapter()?.apply {
            notifyItemRangeChanged(0, media.size)
            measureRecyclerViewContent(media)
        }
    }

    private fun measureRecyclerViewContent(media: ArrayList<ThumbnailItem>) {
        mBinding.mediaGrid.onGlobalLayout {
            if (config.scrollHorizontally) {
                calculateContentWidth(media)
            } else {
                calculateContentHeight(media)
            }
        }
    }

    private fun calculateContentWidth(media: ArrayList<ThumbnailItem>) {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        val thumbnailWidth = layoutManager.getChildAt(0)?.width ?: 0
        val spacing = config.thumbnailSpacing
        val fullWidth = ((media.size - 1) / layoutManager.spanCount + 1) * (thumbnailWidth + spacing) - spacing
        mBinding.mediaHorizontalFastscroller.setContentWidth(fullWidth)
        mBinding.mediaHorizontalFastscroller.setScrollToX(mBinding.mediaGrid.computeHorizontalScrollOffset())
    }

    private fun calculateContentHeight(media: ArrayList<ThumbnailItem>) {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        val pathToCheck = if (mPath.isEmpty()) SHOW_ALL else mPath
        val hasSections = config.getFolderGrouping(pathToCheck) and GROUP_BY_NONE == 0 && !config.scrollHorizontally
        val sectionTitleHeight = if (hasSections) layoutManager.getChildAt(0)?.height ?: 0 else 0
        val thumbnailHeight = if (hasSections) layoutManager.getChildAt(1)?.height ?: 0 else layoutManager.getChildAt(0)?.height ?: 0

        var fullHeight = 0
        var curSectionItems = 0
        media.forEach {
            if (it is ThumbnailSection) {
                fullHeight += sectionTitleHeight
                if (curSectionItems != 0) {
                    val rows = ((curSectionItems - 1) / layoutManager.spanCount + 1)
                    fullHeight += rows * thumbnailHeight
                }
                curSectionItems = 0
            } else {
                curSectionItems++
            }
        }
        val spacing = config.thumbnailSpacing
        fullHeight += ((curSectionItems - 1) / layoutManager.spanCount + 1) * (thumbnailHeight + spacing) - spacing
        mBinding.mediaVerticalFastscroller.setContentHeight(fullHeight)
        mBinding.mediaVerticalFastscroller.setScrollToY(mBinding.mediaGrid.computeVerticalScrollOffset())
    }


    private fun handleGridSpacing(media: ArrayList<ThumbnailItem> = mMedia) {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            val spanCount = config.mediaColumnCnt
            val spacing = config.thumbnailSpacing
            val useGridPosition = media.firstOrNull() is ThumbnailSection

            var currentGridDecoration: GridSpacingItemDecoration? = null
            if (mBinding.mediaGrid.itemDecorationCount > 0) {
                currentGridDecoration = mBinding.mediaGrid.getItemDecorationAt(0) as GridSpacingItemDecoration
                currentGridDecoration.items = media
            }

            val newGridDecoration = GridSpacingItemDecoration(spanCount, spacing, config.scrollHorizontally, config.fileRoundedCorners, media, useGridPosition)
            if (currentGridDecoration.toString() != newGridDecoration.toString()) {
                if (currentGridDecoration != null) {
                    mBinding.mediaGrid.removeItemDecoration(currentGridDecoration)
                }
                mBinding.mediaGrid.addItemDecoration(newGridDecoration)
            }
        }
    }

    companion object {
        var mMedia = ArrayList<ThumbnailItem>()
        var isNeedToRefresh: Boolean = false

    }

    override fun refreshItems() {
        getMedia()
    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {
        val filtered = fileDirItems.filter { !getIsPathDirectory(it.path) && it.path.isMediaFile() } as ArrayList
        if (filtered.isEmpty()) {
            return
        }
        movePathsInRecoverTrash(filtered.map { it.path } as ArrayList<String>) {
            if (it) {
//                deleteFilteredFiles(filtered)
                mMedia.removeAll { filtered.map { it.path }.contains((it as? Medium)?.path) }

                ensureBackgroundThread {
                    filtered.forEach {
                        deleteDBPath(it.path)
                    }
                }
                if (getMediaAdapter() != null)
                    getMediaAdapter()!!.dismissProgress()
                if (mMedia.isEmpty()) {
                    deleteDirectoryIfEmpty()
                    deleteDBDirectory()
                    mBinding.mediaEmptyTextPlaceholder.beVisibleIf(mMedia.isEmpty())
                    if (mMedia.isEmpty())
                        if (AdsManager(this).isNeedToShowAds()) {
                            NativeAdvancedModelHelper(this).loadNativeAdvancedAd(
                                NativeAdsSize.Big,
                                findViewById(R.id.adViewContainer)
                            )
                        }
                    if (mBinding.mediaEmptyTextPlaceholder.isVisible()) {
                        mBinding.mediaEmptyTextPlaceholder.text = getString(R.string.no_media_with_filters)
                    }
                    mBinding.mediaGrid.beVisibleIf(mBinding.mediaEmptyTextPlaceholder.isGone())
                }
            } else {
                toast(R.string.unknown_error_occurred)
            }
        }
//        deleteFilteredFiles(filtered)
    }

    private fun deleteFilteredFiles(filtered: ArrayList<FileDirItem>) {
        deleteFiles(filtered) {
            if (!it) {
                toast(R.string.unknown_error_occurred)
                return@deleteFiles
            }

            mMedia.removeAll { filtered.map { it.path }.contains((it as? Medium)?.path) }

            ensureBackgroundThread {
                filtered.forEach {
                    deleteDBPath(it.path)
                }
            }
            if (getMediaAdapter() != null)
                getMediaAdapter()!!.dismissProgress()
            if (mMedia.isEmpty()) {
                deleteDirectoryIfEmpty()
                deleteDBDirectory()
                mBinding.mediaEmptyTextPlaceholder.beVisibleIf(mMedia.isEmpty())
                if (mMedia.isEmpty())
                    if (AdsManager(this).isNeedToShowAds()) {
                        NativeAdvancedModelHelper(this).loadNativeAdvancedAd(
                            NativeAdsSize.Big,
                            findViewById(R.id.adViewContainer)
                        )
                    }
                if (mBinding.mediaEmptyTextPlaceholder.isVisible()) {
                    mBinding.mediaEmptyTextPlaceholder.text = getString(R.string.no_media_with_filters)
                }
                mBinding.mediaGrid.beVisibleIf(mBinding.mediaEmptyTextPlaceholder.isGone())
            }
        }
    }

    private fun deleteDirectoryIfEmpty() {
        if (config.deleteEmptyFolders) {
            val fileDirItem = FileDirItem(mPath, mPath.getFilenameFromPath(), true)
            if (!fileDirItem.isDownloadsFolder() && fileDirItem.isDirectory) {
                ensureBackgroundThread {
                    if (fileDirItem.getProperFileCount(this, true) == 0) {
                        tryDeleteFileDirItem(fileDirItem, true, true)
                    }
                }
            }
        }
    }

    private fun deleteDBDirectory() {
        ensureBackgroundThread {
            try {
                directoryDao.deleteDirPath(mPath)
            } catch (ignored: Exception) {
            }
        }
    }

    override fun selectedPaths(paths: ArrayList<String>) {
        Intent().apply {
            putExtra(PICKED_PATHS, paths)
            setResult(Activity.RESULT_OK, this)
        }
        finish()
    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {
        var currentGridPosition = 0
        media.forEach {
            if (it is Medium) {
                it.gridPosition = currentGridPosition++
            } else if (it is ThumbnailSection) {
                currentGridPosition = 0
            }
        }

        if (mBinding.mediaGrid.itemDecorationCount > 0) {
            val currentGridDecoration = mBinding.mediaGrid.getItemDecorationAt(0) as GridSpacingItemDecoration
            currentGridDecoration.items = media
        }
    }

    fun toggleToolbar(isShowActionBar: Boolean) {
        if (isShowActionBar) {
            mBinding.llBottomOption.visibility = View.VISIBLE
        } else {
            mBinding.llBottomOption.visibility = View.GONE
        }

    }

    fun setOptions(selectedItems: ArrayList<Medium>) {
        if (selectedItems.any { !it.isHidden() && !it.path.doesThisOrParentHaveNoMedia(HashMap(), null) }) {
            mBinding.llHideOpt.visibility = View.VISIBLE
            mBinding.tvHideUnHideText.text = resources.getString(R.string.hide_photo, selectedItems.size)
            mBinding.imgOptHideUnHide.setImageDrawable(resources.getDrawable(R.drawable.ic_option_hide))
            isHide = true
        } else if (selectedItems.any { it.isHidden() && !it.path.doesThisOrParentHaveNoMedia(HashMap(), null) }) {
            mBinding.llHideOpt.visibility = View.VISIBLE
            mBinding.tvHideUnHideText.text = resources.getString(R.string.unhide_photo, selectedItems.size)
            mBinding.imgOptHideUnHide.setImageDrawable(resources.getDrawable(R.drawable.ic_option_unhide))
            isHide = false
        } else {
            mBinding.llHideOpt.visibility = View.GONE
        }
    }

    override fun onPDFGenerated(pdfFile: File?, numOfImages: Int) {


    }


}