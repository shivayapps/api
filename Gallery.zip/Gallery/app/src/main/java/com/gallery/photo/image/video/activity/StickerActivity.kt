package com.gallery.photo.image.video.activity

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.util.Log
import android.view.View
import android.widget.*
import com.example.app.ads.helper.GiftIconHelper
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activityBinding.BaseBindingActivity
import com.gallery.photo.image.video.adshelper.AdsManager

import com.gallery.photo.image.video.databinding.ActivityStickerBinding
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.stickerView.DrawableSticker
import com.gallery.photo.image.video.stickerView.GridViewStickerAdapter
import com.gallery.photo.image.video.utilities.FinalDrawableSticker
import java.io.File
import java.util.*

class StickerActivity : BaseBindingActivity<ActivityStickerBinding>() {
    var gridViewAdapter: GridViewStickerAdapter? = null

    var activity: StickerActivity? = null

    private val stickerArray: ArrayList<String> = ArrayList<String>()


    override fun initData() {
        activity = this@StickerActivity
        initView()
//        if (Build.VERSION.SDK_INT >= 28) {
//            applayColor()
//        }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = findViewById(R.id.gift_ad_icon),
                fivBlastIcon =findViewById(R.id.gift_blast_ad_icon)
            )
        }
    }

    override fun initActions() {

    }

    private fun applayColor() {
//        val ColorId = Share.getAPPThemWisePrimoryColor(applicationContext)
//        tol_bar!!.setBackgroundColor(ColorId)
//        val HederColor = Share.getAppHeaderColorColor(applicationContext)
//        iv_back!!.setColorFilter(HederColor, PorterDuff.Mode.SRC_IN)
//        tv_title!!.setTextColor(HederColor)
    }

    private fun initView() {

        mBinding.ivBack.setOnClickListener(this)

        val path = intent.getStringExtra("path")
        Log.d("Files", "Path: $path")

        val stickerName = path?.substring(path.lastIndexOf("/") + 1)
        mBinding.tvTitle.text = stickerName

        val directory = File(path)
        val files = directory.listFiles()
        Log.d("Files", "Size: " + files.size)
        for (i in files.indices) {
            Log.d("Files", "FileName:" + files[i].name)
            //list_sticker_category.add(files[i].name)
            if (!files[i].name.contains("thumb"))
                stickerArray.add(files[i].path)
        }
        setStickerData(stickerArray)

    }

    private fun setStickerData(stickerArray: ArrayList<String>) {

        gridViewAdapter = GridViewStickerAdapter(this@StickerActivity, stickerArray)
        mBinding.gvStickerList.adapter = gridViewAdapter
        mBinding.gvStickerList.onItemClickListener =
            AdapterView.OnItemClickListener { parent, view, position, id ->
                val b2: Bitmap = BitmapFactory.decodeFile(stickerArray[position])
                val d: Drawable = BitmapDrawable(resources, b2)
                FinalDrawableSticker = DrawableSticker(d)

                ImageEditActivity.isAddSticker = true
                finish()
            }
    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.ivBack -> {
                onBackPressed()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
        }
    }

    override fun getContext(): Activity {
        return this
    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName(): String {
        return getString(R.string.app_name)
    }


    public override fun onResume() {
        super.onResume()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onBackPressed() {
        ImageEditActivity.isStickerClicked = false
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun setBinding(): ActivityStickerBinding {
        return ActivityStickerBinding.inflate(inflater)
    }

}