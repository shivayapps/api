package com.gallery.photo.image.video.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.gallery.photo.image.video.interfaces.*
import com.gallery.photo.image.video.models.*
import com.gallery.photo.image.video.utilities.DATABASE_PATH
import com.gallery.photo.image.video.extensions.getParentPath
import java.io.File

@Database(
    entities = [UData::class],
    version = 2
)
abstract class DataDatabase : RoomDatabase() {


    abstract fun uDataDao(): UDataDao

    companion object {
        private var db: DataDatabase? = null

        fun getInstance(context: Context): DataDatabase {
            if (db == null) {
                synchronized(DataDatabase::class) {
                    if (db == null) {
                        var sdir = File(DATABASE_PATH)
                        var parentFile = File(sdir.absolutePath.getParentPath())
                        if (!parentFile.exists()) {
                            parentFile.mkdir()
                        }
                        if (!sdir.exists()) {
                            sdir.mkdir()
                        }

                        db = Room.databaseBuilder(context.applicationContext, DataDatabase::class.java, DATABASE_PATH + "/data.db")
                            .fallbackToDestructiveMigration()
//                            .addMigrations(MIGRATION_1_2)
//                            .addMigrations(MIGRATION_2_3)
                            .build()
                    }
                }
            }
            return db!!
        }

        fun destroyInstance() {
            db = null
        }
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
            }
        }
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {

            }
        }




    }
}
