package com.gallery.photo.image.video.activity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Point
import android.graphics.PointF
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.*
import android.util.Log
import android.view.View
import android.view.ViewTreeObserver
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.SeekBar
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adapter.OverLayAdapter
import com.gallery.photo.image.video.adapter.StickerAdapterAssets
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.dialog.DownloadDialog
import com.gallery.photo.image.video.extensions.getImageEffectThumb
import com.gallery.photo.image.video.extensions.updatePhotoVideoDirectoryPath
import com.gallery.photo.image.video.fragment.PhotoDirectoryFragment
import com.gallery.photo.image.video.interfaces.ImageEffectSelectListener
import com.gallery.photo.image.video.retrofit.APIService
import com.gallery.photo.image.video.retrofit.DowloadUnzip
import com.gallery.photo.image.video.retrofit.model.StickerFont
import com.gallery.photo.image.video.stickerView.DrawableSticker
import com.gallery.photo.image.video.stickerView.StickerModel
import com.gallery.photo.image.video.stickerView.StickerView
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.extensions.baseConfig
import com.gallery.photo.image.video.extensions.getParentPath
import com.gallery.photo.image.video.extensions.showErrorToast
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import jp.co.cyberagent.android.gpuimage.*
import kotlinx.android.synthetic.main.activity_image_edit.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.jetbrains.anko.forEachChildWithIndex
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.*
import java.util.*

class ImageEditActivity : BaseActivity(), ImageEffectSelectListener {

    companion object {
        var isAddSticker = false
        var isStickerClicked = false
    }

    override var mMinDuration = 2000
    var mLastStickerClickTime: Long = 0
    var mStickerMinDuration = 1000
    var mPath = ""
    var mOriPath = ""
    var viewList = ArrayList<View>()
    private val filters: List<FilterType> = arrayListOf(
        FilterType.CONTRAST,
        FilterType.INVERT,
        FilterType.PIXELATION,
        FilterType.HUE,
        FilterType.GAMMA,
        FilterType.GRAYSCALE,
        FilterType.SOBEL_EDGE_DETECTION,
        FilterType.POSTERIZE,
        FilterType.FILTER_GROUP,
        FilterType.SATURATION,
        FilterType.VIGNETTE,
        FilterType.SKETCH,
        FilterType.HAZE,
        FilterType.LEVELS_FILTER_MIN
    )
    var gpu_image_filter: GPUImage? = null
    var contrest = 0
    var ivchangecontrast: Int = 0
    var initialcontrast: Int = 50
    var maxOpacity = 70
    var maxEnhance: Int = 7
    var imageContrast = 0f
    lateinit var bitmap: Bitmap
    lateinit var oriBitmap: Bitmap

    private var temp_progress = 0

    var isSaveClicked = false
    var vto: ViewTreeObserver? = null
    var imgFinalHeight = 0
    var imgFinalWidth: Int = 0
    var selectedOverlay: Int = 0
    var drawables_sticker = ArrayList<DrawableSticker>()
    var list_sticker_category = ArrayList<String>()

    private val stickerModels: java.util.ArrayList<StickerModel> = java.util.ArrayList<StickerModel>()
    var list_overlay = ArrayList<String>()

    var isEffectClicked = false
    var isStickerSelected = false
    var selectedStickerPosition = 0
    var selectedPath = 0
    var contentUri: Uri? = null

    interface OnEventListener {
        fun onEvent(event: Int, message: String)
    }

    var stickerListener: OnEventListener? = null
    var zip_sticker = ""
    var overlayListener: OnEventListener? = null
    var zip_overlay = ""
    var zip_font = ""
    var stickerDialog: DownloadDialog? = null
    var stickerDowload: DowloadUnzip? = null

    var overlayDialog: DownloadDialog? = null
    var overlayDowload: DowloadUnzip? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_edit)
    }


    override fun getContext(): Activity {
        return this
    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName(): String {
        return getString(R.string.app_name)
    }

    override fun initData() {
        //base_path = "/data/data/$packageName/stickefont"
        llBackPressed.setOnClickListener {
            onBackPressed()
        }

        try {
            mPath = intent.getStringExtra(PATH) ?: ""
            mOriPath = intent.getStringExtra(ORIGINAL_PATH) ?: ""

        } catch (e: Exception) {
            showErrorToast(e)
            finish()
            return
        }

        Glide.with(this)
            .asBitmap()
            .load(mPath)
            .skipMemoryCache(true)
            .diskCacheStrategy(DiskCacheStrategy.NONE)
            .listener(object : RequestListener<Bitmap> {
                override fun onLoadFailed(e: GlideException?, model: Any?, target: Target<Bitmap>?, isFirstResource: Boolean): Boolean {
                    return false
                }

                override fun onResourceReady(resource: Bitmap?, model: Any?, target: Target<Bitmap>?, dataSource: DataSource?, isFirstResource: Boolean): Boolean {
                    bitmap = resource!!
                    oriBitmap = resource!!
                    gpu_image_filter = GPUImage(this@ImageEditActivity)
                    gpu_image_filter!!.setImage(bitmap)
                    setUpImage()
                    return false
                }

            })
            .into(img_main)

        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
//            InterstitialAdHelper.instance!!.load(this, this)
            InterstitialAdHelper.loadInterstitialAd(fContext = this)
        }

        stickerListener = object : OnEventListener {
            override fun onEvent(event: Int, message: String) {
                loadStickers()
                showStickerRow()
            }
        }
        overlayListener = object : OnEventListener {
            override fun onEvent(event: Int, message: String) {
                setOverlayView()
            }
        }

    }

    override fun onResume() {
        super.onResume()
        if (FONT_FLAG) {
            FONT_FLAG = false
            Log.e("TAG", "onResume: add text Effect ")
            val drawableSticker: DrawableSticker = TEXT_DRAWABLE!!
            drawableSticker.setTag("text")
            stickerView.addSticker(drawableSticker)
            drawables_sticker.add(drawableSticker)
            isStickerAvail = true
            isStickerTouch = true
            stickerView.isLocked = false
        }
        if (isAddSticker) {
            isAddSticker = false
            if (FinalDrawableSticker == null) {
                Log.e("TAG", "Sticker to be added is null!")
                return
            }
            stickerView.addSticker(FinalDrawableSticker)
            drawables_sticker.add(FinalDrawableSticker!!)
            isStickerAvail = true
            isStickerTouch = true
            stickerView.isLocked = false
        }
        if (drawables_sticker.size == 0) {
            setStickerViewLocked(false)
        }
    }

    private fun getOverlay() {
        overlayDialog = DownloadDialog(this@ImageEditActivity)
        if (overlayDowload?.status == AsyncTask.Status.RUNNING) {
            overlayDialog?.dialog?.show()
        } else {
            val apiInterface = APIService().getEditorClient(this@ImageEditActivity)
            val call: Call<StickerFont> = apiInterface.doGetStickerFontList()
            call.enqueue(object : Callback<StickerFont> {
                override fun onResponse(call: Call<StickerFont>, response: Response<StickerFont>) {
                    if (response.isSuccessful) {
                        Log.e("reqStickerFont", "response:" + response.body())
                        val zipurl = response.body()!!.data.responseData.overlay.path
                        zip_overlay = zipurl.substring(zipurl.lastIndexOf('/') + 1, zipurl.lastIndexOf('.'))
                        baseConfig.overlayZip = zip_overlay

                        overlayDowload = DowloadUnzip(this@ImageEditActivity)
                        overlayDowload?.setDownloadListener { event, position, message ->

                            if (event == 3) {
                                overlayListener?.onEvent(1, "done")
//                                if (window.decorView.isShown)
                                overlayDialog?.dialog?.dismiss()

                            } else if (event == 1) {
                                overlayDialog?.setProgress(position.toFloat())
                            } else {
                                if (event != 2) Toast.makeText(this@ImageEditActivity, getString(R.string.error_check_internet), Toast.LENGTH_SHORT).show()
//                                if (window.decorView.isShown)
                                overlayDialog?.dialog?.dismiss()
//                            relProgress.visibility = View.GONE
                            }
                            Log.e("reqStickerFont", "dowload progress event:" + event)
                            Log.e("reqStickerFont", "dowload progress position:" + position)
                        }
                        overlayDowload?.download(response.body()!!.data.responseData.overlay.path)

                    } else {
                        Log.e("reqStickerFont", "Connection failed 001:" + response.errorBody())
                        Log.e("reqStickerFont", "Connection failed 002:" + response.message())
                    }
                }

                override fun onFailure(call: Call<StickerFont>, t: Throwable) {
                    Toast.makeText(this@ImageEditActivity, getString(R.string.error_check_internet), Toast.LENGTH_SHORT).show()
                    overlayDialog?.dialog?.dismiss()
                    t.printStackTrace()
                    Log.e("reqStickerFont", "onFailure02:${t.message!!}")
                }
            })
        }

    }

    private fun getStickerFont() {
        stickerDialog = DownloadDialog(this@ImageEditActivity)

        if (stickerDowload?.status == AsyncTask.Status.RUNNING) {
            stickerDialog?.dialog?.show()

        } else {
            //var apiInterface = APIClient.client.create(APIService.APIInterface::class.java)
            val apiInterface = APIService().getEditorClient(this@ImageEditActivity)
            val call: Call<StickerFont> = apiInterface.doGetStickerFontList()
            call.enqueue(object : Callback<StickerFont> {
                override fun onResponse(call: Call<StickerFont>, response: Response<StickerFont>) {
                    if (response.isSuccessful) {
                        Log.e("reqStickerFont", "response:" + response.body())

                        val zipurl = response.body()!!.data.responseData.sticker.path
                        zip_sticker = zipurl.substring(zipurl.lastIndexOf('/') + 1, zipurl.lastIndexOf('.'))

                        baseConfig.stickerZip = zip_sticker
                        stickerDowload = DowloadUnzip(this@ImageEditActivity)
                        stickerDowload?.setDownloadListener { event, position, message ->

                            if (event == 3) {
                                stickerListener?.onEvent(1, "done")
//                                if (window.decorView.isShown)
                                stickerDialog?.dialog?.dismiss()
                            } else if (event == 1) {
                                stickerDialog?.setProgress(position.toFloat())
                            } else {
                                if (event != 2) Toast.makeText(this@ImageEditActivity, getString(R.string.error_check_internet), Toast.LENGTH_SHORT).show()
//                                if (window.decorView.isShown)
                                stickerDialog?.dialog?.dismiss()
                            }
                            Log.e("reqStickerFont", "dowload progress event:" + event)
                            Log.e("reqStickerFont", "dowload progress position:" + position)
                        }
                        stickerDowload?.download(response.body()!!.data.responseData.sticker.path)

                    } else {
                        Log.e("reqStickerFont", "Connection failed 001:" + response.errorBody())
                        Log.e("reqStickerFont", "Connection failed 002:" + response.message())
                    }
                }

                override fun onFailure(call: Call<StickerFont>, t: Throwable) {
                    Toast.makeText(this@ImageEditActivity, getString(R.string.error_check_internet), Toast.LENGTH_SHORT).show()
                    stickerDialog?.dialog?.dismiss()
                    t.printStackTrace()
                    Log.e("reqStickerFont", "onFailure02:${t.message!!}")
                }
            })
        }


    }

    private fun setUpImage() {
        val display = window.windowManager.defaultDisplay
        val size = Point()
        display.getSize(size)
        val screenWidth = size.x
        val screenHeight = size.y
        val height = Math.ceil((screenWidth * bitmap.height / bitmap.width).toDouble()).toInt()
        img_main.layoutParams.height = height

        vto = img_main.viewTreeObserver
        vto!!.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                img_main.viewTreeObserver.removeOnPreDrawListener(this)
                imgFinalHeight = img_main.measuredHeight
                imgFinalWidth = img_main.measuredWidth

                // Manage image width based on height
                if (height > imgFinalWidth) {
                    imgFinalWidth = Math.ceil((imgFinalHeight * img_main.drawable.intrinsicWidth.toFloat() / img_main.drawable.intrinsicHeight).toDouble()).toInt()
                }
                img_main.layoutParams.width = imgFinalWidth
                val rLParams: RelativeLayout.LayoutParams = RelativeLayout.LayoutParams(imgFinalWidth, imgFinalHeight)
                rLParams.addRule(RelativeLayout.CENTER_IN_PARENT)
                rl_main.layoutParams = rLParams

                val layoutParams: RelativeLayout.LayoutParams = RelativeLayout.LayoutParams(imgFinalWidth, imgFinalHeight)
                layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT)
                img_effect.layoutParams = layoutParams

                val stickerParams: RelativeLayout.LayoutParams = RelativeLayout.LayoutParams(imgFinalWidth, imgFinalHeight)
                stickerParams.addRule(RelativeLayout.CENTER_IN_PARENT)
                stickerView.layoutParams = layoutParams
                return true
            }
        })
        //loadStickers()
        isStickerAvail = false
        img_effect.context = this
        if (!isStickerAvail) {
            isStickerTouch = false
            stickerView.isLocked = true
        }
    }

    private fun loadStickers() {
        val path = "/data/data/" + mContext.packageName + "/stickerfont"
        Log.d("Files", "Path: $path")
        Log.d("Files", "zip_sticker: $zip_sticker")
        val directory = File("$path/$zip_sticker")
        val files = directory.listFiles()
        if (files != null) {
            Log.d("Files", "Size: " + files.size)
            for (i in files.indices) {
                Log.d("Files", "FileName:" + files[i].name)
                //list_sticker_category.add(files[i].name)

                if (!files[i].name.contains("thumb"))
                    stickerModels.add(StickerModel(i, files[i].name, files[i].path))
            }
        }

        rv_sticker.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        val stickerAdapterAssets = StickerAdapterAssets(this, stickerModels)
        {
            if (SystemClock.elapsedRealtime() - mLastStickerClickTime < mStickerMinDuration) {
                return@StickerAdapterAssets
            }
            mLastStickerClickTime = SystemClock.elapsedRealtime()
            selectedStickerPosition = it
            isStickerClicked = true
            isStickerSelected = true
            Log.e("onCLick", "onClick: $selectedStickerPosition")

            if (AdsManager(this).isNeedToShowAds() && isOnline()) {
                isShowInterstitialAd {
                    isInterstitialShown = false
                    isStickerClicked = false
                    val intent: Intent =
                        Intent(this@ImageEditActivity, StickerActivity::class.java)
                    intent.putExtra("position", selectedStickerPosition)
                    intent.putExtra("path", stickerModels[selectedStickerPosition].path)
                    startActivity(intent)
                }
//                if (interstitialAdShow != null) {
//                    isInterstitialShown = true
//                    interstitialAdShow!!.show(this)
//                } else {
//                    if (OfflineNativeAdvancedHelper.unNativeAd != null) {
//                        FullScreenNativeAdDialog(activity = this) {
//                            isInterstitialShown = false
//                            isStickerClicked = false
//                            val intent: Intent =
//                                Intent(this@ImageEditActivity, StickerActivity::class.java)
//                            intent.putExtra("position", selectedStickerPosition)
//                            intent.putExtra("path", stickerModels[selectedStickerPosition].path)
//                            startActivity(intent)
//                        }.showFullScreenNativeAdDialog()
//                    } else {
//                        isStickerClicked = false
//                        isInterstitialShown = false
//                        isInterstitialShown = false
//                        val intent: Intent =
//                            Intent(this@ImageEditActivity, StickerActivity::class.java)
//                        intent.putExtra("position", selectedStickerPosition)
//                        intent.putExtra("path", stickerModels[selectedStickerPosition].path)
//                        startActivity(intent)
//                    }
//                }
            } else {
                isStickerClicked = false
                isInterstitialShown = false
                isInterstitialShown = false
                val intent: Intent =
                    Intent(this@ImageEditActivity, StickerActivity::class.java)
                intent.putExtra("position", selectedStickerPosition)
                intent.putExtra("path", stickerModels[selectedStickerPosition].path)
                startActivity(intent)
            }

        }

        rv_sticker.adapter = stickerAdapterAssets
    }

    override fun initActions() {
        ivEffect.setOnClickListener(this)
        ivEnhance.setOnClickListener(this)
        ivOverlay.setOnClickListener(this)
        ivAddText.setOnClickListener(this)
        ivSticker.setOnClickListener(this)
        rlCancel.setOnClickListener(this)
        ivNoColorEffect.setOnClickListener(this)
        ivNoEffect.setOnClickListener(this)
        ivSave.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.ivEffect -> {
                if (!isEffectClicked) {
                    isEffectClicked = true
                    hv_scroll_color_effect.visibility = View.GONE
                    hsvScrollEffect.visibility = View.GONE
                    hv_scroll_vintage.visibility = View.GONE
                    ll_row_sticker.visibility = View.GONE
                    setUpFilterView()
                }
            }
            R.id.rlCancel -> {
                isStickerClicked = false
                if (llMenu.visibility == View.GONE) {
                    llMenu.visibility = View.VISIBLE
                    val bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_up)
                    llMenu.startAnimation(bottomDown)
                }

                var bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_down)
                rlBackground.startAnimation(bottomDown)
                rlBackground.visibility = View.GONE

                bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_down)
                llCancel.startAnimation(bottomDown)
                llCancel.visibility = View.INVISIBLE
            }
            R.id.ivEnhance -> {
                setEnhanceView()
            }
            R.id.ivOverlay -> {

                zip_overlay = baseConfig.overlayZip
                if (zip_overlay.isNotEmpty()) {

                    Log.e("reqStickerFont", "zip_overlay:" + zip_overlay)
                    val checkFile = "/data/data/" + mContext.packageName + "/stickerfont/${zip_overlay}"
                    if (File(checkFile).exists()) {
                        Log.e("reqStickerFont", "zip_overlay exists:")
                        overlayListener?.onEvent(1, "done")
                    } else {
                        if (isOnline()) {
                            getOverlay()
                        } else {
                            Toast.makeText(this@ImageEditActivity, getString(R.string.error_check_internet), Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    if (isOnline()) {
                        getOverlay()
                    } else {
                        Toast.makeText(this@ImageEditActivity, getString(R.string.error_check_internet), Toast.LENGTH_SHORT).show()
                    }
                }

                //getOverlay()
            }
            R.id.ivAddText -> {
                rlEnhance.setVisibility(View.GONE)

                if (llCancel.getVisibility() == View.VISIBLE) {
                    val bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_down)
                    llCancel.startAnimation(bottomDown)
                    llCancel.setVisibility(View.INVISIBLE)
                }

                zip_font = baseConfig.fontZip

                if (zip_font.isNotEmpty()) {
                    val checkFile = "/data/data/" + mContext.packageName + "/stickerfont/${zip_font}"
                    if (File(checkFile).exists()) {
                        val i: Intent = Intent(this, FontActivity::class.java)
                        startActivity(i)
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    } else {
                        if (isOnline()) {
                            val i: Intent = Intent(this, FontActivity::class.java)
                            startActivity(i)
                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                        } else {
                            Toast.makeText(this@ImageEditActivity, getString(R.string.error_check_internet), Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    Log.d("reqStickerFont", "init zip_name:$zip_font")
                    if (isOnline()) {
                        val i: Intent = Intent(this, FontActivity::class.java)
                        startActivity(i)
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    } else {
                        Toast.makeText(this@ImageEditActivity, getString(R.string.error_check_internet), Toast.LENGTH_SHORT).show()
                    }
                }


            }
            R.id.ivSticker -> {
                hv_scroll_color_effect.visibility = View.GONE
                hsvScrollEffect.setVisibility(View.GONE)
                hv_scroll_vintage.visibility = View.GONE
                ll_row_sticker.visibility = View.GONE

                zip_sticker = baseConfig.stickerZip
                if (zip_sticker.isNotEmpty()) {

                    Log.e("reqStickerFont", "zip_sticker:" + zip_sticker)
                    val checkFile = "/data/data/" + mContext.packageName + "/stickerfont/${zip_sticker}"
                    if (File(checkFile).exists()) {
                        Log.e("reqStickerFont", "zip_sticker exists:")
                        stickerListener?.onEvent(1, "done")
                    } else {
                        if (isOnline()) {
                            getStickerFont()
                        } else {
                            Toast.makeText(this@ImageEditActivity, getString(R.string.error_check_internet), Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {

                    if (isOnline()) {
                        getStickerFont()
                    } else {
                        Toast.makeText(this@ImageEditActivity, getString(R.string.error_check_internet), Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.ivNoColorEffect -> {
                img_effect.visibility = View.GONE
            }
            R.id.ivNoEffect -> {
                bitmap = oriBitmap
                updateEffectRowFrame()

                img_main.setImageBitmap(bitmap)
            }
            R.id.ivSave -> {
                if (!isSaveClicked) {
                    isSaveClicked = true
                    stickerView.setControlItemsHidden()

                    if (rlBackground.childCount > 0) {
                        saveImage()
                        llMenu.visibility = View.VISIBLE
                        rlBackground.visibility = View.GONE
                        llCancel.visibility = View.INVISIBLE
                    } else {
                        Toast.makeText(this, getString(R.string.error_blank_image_save), Toast.LENGTH_SHORT).show()
                    }
                }

            }
        }

    }

    private fun saveImage() {

        showProgress(getString(R.string.msg_saving))

        rl_main.isDrawingCacheEnabled = true
        val bitmap = Bitmap.createBitmap(rl_main.drawingCache)
        rl_main.isDrawingCacheEnabled = false
        GlobalScope.launch(Dispatchers.IO) {
            val fileImagePath = saving(bitmap)
            GlobalScope.launch(Dispatchers.Main) {
                dismissProgress()
                Toast.makeText(this@ImageEditActivity, getString(R.string.save_image), Toast.LENGTH_LONG).show()
                contentUri = Uri.fromFile(File(fileImagePath))
                MediaScannerConnection.scanFile(
                    this@ImageEditActivity, arrayOf(File(fileImagePath).toString()),
                    null, null
                )
                ensureBackgroundThread {
                    updatePhotoVideoDirectoryPath(fileImagePath!!.getParentPath(), true, false)
                }
                MainActivity.isNeedToRefresh = true
                PhotoDirectoryFragment.isNeedToRefresh = true
                redirectNextActivity()

            }
        }
    }

    private fun redirectNextActivity() {

        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            isShowInterstitialAd {
                Intent().apply {
                    data = contentUri
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    setResult(RESULT_OK, this)
                }
                finish()
            }
//            if (interstitialAdShow != null) {
//                isInterstitialShown = true
//                interstitialAdShow!!.show(this)
//            } else {
//                if (OfflineNativeAdvancedHelper.unNativeAd != null) {
//                    FullScreenNativeAdDialog(activity = this) {
//                        isInterstitialShown = false
//                        Intent().apply {
//                            data = contentUri
//                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
//                            setResult(RESULT_OK, this)
//                        }
//                        finish()
//                    }.showFullScreenNativeAdDialog()
//                } else {
//                    isInterstitialShown = false
//                    Intent().apply {
//                        data = contentUri
//                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
//                        setResult(RESULT_OK, this)
//                    }
//                    finish()
//                }
//            }
        } else {
            isInterstitialShown = false
            Intent().apply {
                data = contentUri
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                setResult(RESULT_OK, this)
            }
            finish()
        }
    }

    fun saving(bitmap: Bitmap): String? {
        try {
            var canWrite = true
            val temp_path =
                Environment.getExternalStorageDirectory().path + "/Gallery Photo Editor"

            //todo
            var file: File? = File(temp_path)

//            if (!file!!.canWrite()) {
//                canWrite = false
//                file = null
//                file = File(temp_path)
//            }
            if (!file!!.exists())
                file!!.mkdirs()
            val fileImage = File(file, "Photo_" + System.currentTimeMillis() + ".png")

            if (canWrite == false) runOnUiThread {
                Toast.makeText(
                    applicationContext,
                    getString(R.string.msg_image_save_location) + fileImage.path,
                    Toast.LENGTH_LONG
                ).show()
            }
            fileImage.setWritable(true)
            val fileOutputStream: OutputStream = FileOutputStream(fileImage)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream)
            fileOutputStream.flush()
            fileOutputStream.close()
            MediaScannerConnection.scanFile(
                this, arrayOf(file.toString()),
                null, null
            )

            return fileImage.path
        } catch (e: Throwable) {
            e.printStackTrace()
        }
        return ""
    }


    private fun showStickerRow() {
        ll_row_sticker.visibility = View.VISIBLE
        rlBackground.visibility = View.VISIBLE
        var bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_up)
        rlBackground.startAnimation(bottomDown)
        bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_down)
        llMenu.startAnimation(bottomDown)
        llMenu.visibility = View.GONE
        rlEnhance.visibility = View.INVISIBLE
        rlOpacity.visibility = View.INVISIBLE
        llCancel.visibility = View.VISIBLE
        bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_up)
        llCancel.startAnimation(bottomDown)
    }


    private fun updateEffectRowFrame() {
        ivNoEffect.setBackgroundResource(R.drawable.image_edit_select_effect_background)
        llRowEffect.forEachChildWithIndex { _, view ->
            val img = view.findViewById<ImageView>(R.id.ivEffect)
            img.setBackgroundResource(R.drawable.image_edit_unselect_effect_background)

        }
    }

    private fun setOverlayView() {

        hv_scroll_color_effect.visibility = View.VISIBLE
        hsvScrollEffect.visibility = View.GONE
        hv_scroll_vintage.visibility = View.GONE
        ll_row_sticker.visibility = View.GONE

        setColorEffectThumbRow()

        rlEnhance.visibility = View.GONE

        rlBackground.visibility = View.VISIBLE
        var bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_up)
        rlBackground.startAnimation(bottomDown)

        bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_down)
        llMenu.startAnimation(bottomDown)
        llMenu.visibility = View.GONE

        llCancel.visibility = View.VISIBLE
        rlOpacity.visibility = View.VISIBLE
        bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_up)
        llCancel.startAnimation(bottomDown)

        sb_opacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (selectedOverlay != 0) {
                    img_effect.alpha = progress.toFloat() / 100
                    tv_opacity.text = (100 * progress / maxOpacity).toString()
                } else {
                    sb_opacity.progress = temp_progress
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                temp_progress = sb_opacity.progress
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                if (selectedOverlay == 0) {
                    Toast.makeText(this@ImageEditActivity, getString(R.string.error_please_select_overlay), Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun setColorEffectThumbRow() {
        try {
            val path = "/data/data/" + mContext.packageName + "/stickerfont"
            Log.d("Files", "Path: $path")

            val directory = File("$path/$zip_overlay/overlay_image")
            val files = directory.listFiles()
            Log.d("Files", "Size: " + files.size)
            list_overlay.add("NO")
            for (i in files.indices) {
                Log.d("Files", "FileName:" + files[i].name)
                //list_sticker_category.add(files[i].name)
                list_overlay.add(files[i].path)
            }

            ll_row_color_effect.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
            val overLayAdapter = OverLayAdapter(this, list_overlay, 0)
            ll_row_color_effect.layoutDirection = View.LAYOUT_DIRECTION_LTR
            ll_row_color_effect.adapter = overLayAdapter
            overLayAdapter.setOverlayListener(object : OverLayAdapter.OverlayListener {
                override fun onOverlayClicked(position: Int) {
                    if (position == 0) {
                        img_effect.visibility = View.GONE
                    } else {
                        selectedOverlay = position
                        if (list_overlay[position] != null) {
                            try {
                                val b2: Bitmap = BitmapFactory.decodeFile(list_overlay[position])
                                img_effect.visibility = View.VISIBLE
                                img_effect.invalidate()
                                if (b2 != null)
                                    img_effect.imageBitmap = b2
                            } catch (e: java.lang.Exception) {
                                e.printStackTrace()
                            }
                        }
                    }

                }
            })

        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }


    private fun setEnhanceView() {
        hv_scroll_color_effect.visibility = View.GONE
        hsvScrollEffect.visibility = View.GONE
        hv_scroll_vintage.visibility = View.GONE
        ll_row_sticker.visibility = View.GONE

        rlOpacity.visibility = View.GONE



        if (llCancel.visibility != View.VISIBLE) {
            var bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_up)
            llCancel.startAnimation(bottomDown)
            llCancel.visibility = View.VISIBLE
            if (rlEnhance.getVisibility() != View.VISIBLE) {
                llCancel.visibility = View.VISIBLE
                rlEnhance.visibility = View.VISIBLE
                bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_up)
                llCancel.startAnimation(bottomDown)
                sb_enhance.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                        // tv_enhance.setText((100 * progress) / maxEnhance + "");
                        contrest = progress + 1
                        ivchangecontrast = maxEnhance * contrest / 100
                        tv_enhance.text = "" + progress
                        imageContrast = ivchangecontrast.toFloat() * StickerView.MIN_SCALE_SIZE + 1.0f
                    }

                    override fun onStartTrackingTouch(seekBar: SeekBar) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar) {
//                        enhanceEdit().execute()
                        showProgress(getString(R.string.please_wait))
                        val filterGroup = GPUImageFilterGroup()
                        val gpuImage = GPUImage(this@ImageEditActivity)
                        gpuImage.setImage(oriBitmap)
                        GlobalScope.launch(Dispatchers.IO) {
                            if (contrest != 0) {
                                val contrastfilter = GPUImageContrastFilter()
                                contrastfilter.setContrast(imageContrast)
                                filterGroup.addFilter(contrastfilter)

                            }
                            gpuImage.setFilter(filterGroup)
                            GlobalScope.launch(Dispatchers.Main) {
                                dismissProgress()
                                bitmap = gpuImage.bitmapWithFilterApplied
                                img_main.invalidate()
                                img_main.setImageBitmap(null)
                                img_main.setImageBitmap(bitmap)
                            }
                        }
                    }
                })
            }
        }
    }

    private fun setUpFilterView() {
        if (viewList.size != 0) {
            Log.d("ViewList", viewList.size.toString())
            setImageEffectView()
        } else {
            getImageEffectThumb(mPath, this) {
                viewList = it
                Log.d("ViewList", viewList.size.toString())
                setImageEffectView()
            }

        }

    }

    private fun setImageEffectView() {
        llRowEffect.removeAllViews()
        viewList.forEach {
            llRowEffect.addView(it)
        }

        hsvScrollEffect.visibility = View.VISIBLE

        rlBackground.visibility = View.VISIBLE
        var bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_up)
        rlBackground.startAnimation(bottomDown)

        bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_down)
        llMenu.startAnimation(bottomDown)
        llMenu.visibility = View.GONE

        rlEnhance.visibility = View.INVISIBLE
        rlOpacity.visibility = View.INVISIBLE

        llCancel.visibility = View.VISIBLE
        bottomDown = AnimationUtils.loadAnimation(applicationContext, R.anim.bottom_up)
        llCancel.startAnimation(bottomDown)
        isEffectClicked = false
    }

    override fun onEffectItemSelect(position: Int, imageView: ImageView) {
        showProgress(getString(R.string.please_wait))
        llRowEffect.forEachChildWithIndex { index, view ->
            var img = view.findViewById<ImageView>(R.id.ivEffect)
            if (img.tag == position) {
                img.setBackgroundResource(R.drawable.image_edit_select_effect_background)
            } else {
                img.setBackgroundResource(R.drawable.image_edit_unselect_effect_background)
            }
        }

        GlobalScope.launch(Dispatchers.IO) {
            gpu_image_filter!!.setFilter(createFilterForType(this@ImageEditActivity, filters[position]))
            GlobalScope.launch(Dispatchers.Main) {
                dismissProgress()
                bitmap = gpu_image_filter!!.bitmapWithFilterApplied
                img_main.invalidate()
                img_main.setImageBitmap(null)
                img_main.setImageBitmap(bitmap)
            }
        }

    }

    private fun createFilterForType(context: Context, type: FilterType): GPUImageFilter? {
        return when (type) {
            FilterType.CONTRAST -> GPUImageContrastFilter(2.0f)
            FilterType.INVERT -> GPUImageColorInvertFilter()
            FilterType.PIXELATION -> GPUImagePixelationFilter()
            FilterType.HUE -> GPUImageHueFilter(90.0f)
            FilterType.GAMMA -> GPUImageGammaFilter(2.0f)
            FilterType.SEPIA -> GPUImageSepiaFilter()
            FilterType.GRAYSCALE -> GPUImageGrayscaleFilter()
            FilterType.SHARPEN -> {
                val sharpness = GPUImageSharpenFilter()
                sharpness.setSharpness(2.0f)
                sharpness
            }
            FilterType.EMBOSS -> GPUImageEmbossFilter()
            FilterType.SOBEL_EDGE_DETECTION -> GPUImageSobelEdgeDetection()
            FilterType.POSTERIZE -> GPUImagePosterizeFilter()
            FilterType.FILTER_GROUP -> {
                val filters: MutableList<GPUImageFilter> = LinkedList()
                filters.add(GPUImageContrastFilter())
                filters.add(GPUImageDirectionalSobelEdgeDetectionFilter())
                filters.add(GPUImageGrayscaleFilter())
                GPUImageFilterGroup(filters)
            }
            FilterType.SATURATION -> GPUImageSaturationFilter(1.0f)
            FilterType.VIGNETTE -> {
                val centerPoint = PointF()
                centerPoint.x = 0.5f
                centerPoint.y = 0.5f
                GPUImageVignetteFilter(centerPoint, floatArrayOf(0.0f, 0.0f, 0.0f), 0.3f, 0.75f)
            }
            FilterType.KUWAHARA -> GPUImageKuwaharaFilter()
            FilterType.SKETCH -> GPUImageSketchFilter()
            FilterType.TOON -> GPUImageToonFilter()
            FilterType.HAZE -> GPUImageHazeFilter()
            FilterType.LEVELS_FILTER_MIN -> {
                val levelsFilter = GPUImageLevelsFilter()
                levelsFilter.setMin(0.0f, 3.0f, 1.0f)
                levelsFilter
            }
            else -> throw IllegalStateException("No filter of that type!")
        }
    }

    fun setStickerViewLocked(isLock: Boolean) {
        stickerView.isLocked = isLock
        isStickerTouch = isLock
        isStickerAvail = isLock

    }

//    override fun onAdLoaded(interstitialAd: InterstitialAd) {
//        interstitialAdShow = interstitialAd
//    }
//
//    override fun onAdFailedToLoad() {
//        interstitialAdShow = null
//        InterstitialAdHelper.instance!!.load(this, this)
//    }
//
//    override fun onAdClosed() {
//        Log.d("AdClose", "onAdClosed: ")
//        if (isStickerClicked) {
//            isInterstitialShown = false
//            isStickerClicked = false
//            val intent: Intent = Intent(this, StickerActivity::class.java)
//            intent.putExtra("position", selectedStickerPosition)
//            intent.putExtra("path", stickerModels[selectedStickerPosition].path)
//            startActivity(intent)
//        } else {
//
//            Intent().apply {
//                data = contentUri
//                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
//                setResult(RESULT_OK, this)
//            }
//            finish()
//        }
//
//        InterstitialAdHelper.instance!!.load(this, this)
//    }


}