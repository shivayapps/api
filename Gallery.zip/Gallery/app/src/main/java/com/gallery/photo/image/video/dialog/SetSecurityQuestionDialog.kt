package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.InputFilter
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.extensions.toast


class SetSecurityQuestionDialog(
    val activity: BaseSimpleActivity,
    val callback: () -> Unit
){
    private var currSorting = 0
    private var config = activity.config
    private var view: View

    init {
        view = activity.layoutInflater.inflate(R.layout.dialog_set_security_question, null)
        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val ivClose = dialog.findViewById(R.id.ivClose) as ImageView
        val etSeqAns = dialog.findViewById(R.id.etSeqAns) as EditText
        val spSecQue = dialog.findViewById(R.id.spSecQue) as Spinner
        var selectedSecQue: String = ""
        var selectedPos: Int = 0
//        etSeqAns.filters = arrayOf(EMOJI_FILTER)

        spSecQue.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View, position: Int, id: Long
            ) {
                selectedSecQue = spSecQue.selectedItem as String
                selectedPos = spSecQue.selectedItemPosition
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // write code to perform some action
            }
        }

        ivClose.setOnClickListener {
            dialog.dismiss()
        }

        val tvDone = dialog.findViewById(R.id.tvDone) as TextView
        tvDone.setOnClickListener {
            when {
                selectedPos == 0 -> {
                    activity.toast( activity.getString(R.string.error_msg_please_select_que))
                }
                etSeqAns.text.trim().isEmpty() -> {
                    activity.toast( activity.getString(R.string.error_please_enter_answer))

                }
                etSeqAns.text.length < 5 -> {
                    activity.toast( activity.getString(R.string.error_msg_please_enter_valid_answer))
                }
                else -> {
                    config.securityQuestion = selectedSecQue
                    config.securityAnswer = etSeqAns.text.toString()
                    config.securityQuestionIndex=selectedPos
                    dialog.dismiss()
                    callback()
                }
            }


        }

        dialog.show()

    }

    var EMOJI_FILTER = InputFilter { source, start, end, dest, dstart, dend ->
        for (index in start until end) {
            val type = Character.getType(source[index])
            if (type == Character.SURROGATE.toInt()) {
                return@InputFilter ""
            }
        }
        null
    }

}
