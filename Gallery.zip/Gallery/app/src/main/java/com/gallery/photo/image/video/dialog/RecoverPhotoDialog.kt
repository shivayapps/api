package com.gallery.photo.image.video.dialog

import androidx.appcompat.app.AlertDialog
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.extensions.setupDialogStuff

class RecoverPhotoDialog(val activity: BaseSimpleActivity, val callback: () -> Unit) {

    init {
        val view = activity.layoutInflater.inflate(R.layout.dialog_recover_photo, null)
        AlertDialog.Builder(activity, R.style.MyAlertDialogNew)
            .setPositiveButton(R.string.ok) { dialog, which -> dialogConfirmed() }
            .setNegativeButton(R.string.cancel, null)
            .create().apply {
                activity.setupDialogStuff(view, this, R.string.lbl_Recover_Photos)
            }
    }

    private fun dialogConfirmed() {
        callback()
    }


}
