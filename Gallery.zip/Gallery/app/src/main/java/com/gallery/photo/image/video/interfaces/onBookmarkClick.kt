package com.gallery.photo.image.video.interfaces

public interface onBookmarkClick {
    fun onLinkClick(link: String)
}