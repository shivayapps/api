package com.gallery.photo.image.video.adapter

import android.app.ProgressDialog
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Menu
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activityBinding.RecoverPhotoTabActivity
import com.gallery.photo.image.video.activityBinding.TimeLineActivity
import com.gallery.photo.image.video.activityBinding.TrashActivity
import com.gallery.photo.image.video.database.FavouriteDBHelper
import com.gallery.photo.image.video.dialog.DeleteWithRememberDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.PhotoDirectoryFragment
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.helpers.VIEW_TYPE_LIST
import com.gallery.photo.image.video.views.FastScroller
import com.gallery.photo.image.video.views.MyRecyclerView
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.fragment.VideoDirectoryFragment
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.models.ThumbnailSection
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import kotlinx.android.synthetic.main.photo_item_grid.view.*
import kotlinx.android.synthetic.main.video_item_grid.view.*
import kotlinx.android.synthetic.main.photo_item_grid.view.media_item_holder
import kotlinx.android.synthetic.main.photo_item_grid.view.medium_check
import kotlinx.android.synthetic.main.photo_item_grid.view.medium_name
import kotlinx.android.synthetic.main.photo_item_grid.view.medium_thumbnail
import kotlinx.android.synthetic.main.thumbnail_section_for_recover.view.*
import java.util.LinkedHashSet

class RecoverTrashAdapter(
    activity: BaseSimpleActivity, var media: ArrayList<ThumbnailItem>, val listener: MediaOperationsListener?, val isAGetIntent: Boolean,
    val allowMultiplePicks: Boolean, val path: String, recyclerView: MyRecyclerView, fastScroller: FastScroller? = null, val isDetailPage: Boolean, itemClick: (Any) -> Unit
) :
    MyRecyclerViewAdapter(activity, recyclerView, fastScroller, itemClick, false) {

    private val INSTANT_LOAD_DURATION = 2000L
    private val IMAGE_LOAD_DELAY = 0L
    private val ITEM_SECTION = 0
    private val ITEM_MEDIUM_VIDEO_PORTRAIT = 1
    private val ITEM_MEDIUM_PHOTO = 2
    private val viewType = activity.config.getFolderViewType(if (activity.config.showAll) SHOW_ALL else path)
    private val isListViewType = viewType == VIEW_TYPE_LIST
    private var visibleItemPaths = java.util.ArrayList<String>()
    private var rotatedImagePaths = java.util.ArrayList<String>()
    private var loadImageInstantly = false
    private var delayHandler = Handler(Looper.getMainLooper())
    private var currentMediaHash = media.hashCode()
    private val hasOTGConnected = activity.hasOTGConnected()
    private val config = activity.config

    private var scrollHorizontally = activity.config.scrollHorizontally
    private var animateGifs = activity.config.animateGifs
    private var cropThumbnails = activity.config.cropThumbnails
    private var displayFilenames = activity.config.displayFileNames
    private var showFileTypes = activity.config.showThumbnailFileTypes
    protected var selectedMainKeys = LinkedHashSet<Int>()

    init {
        media.forEach {
            (it as? Medium)?.path?.hashCode()?.let { it1 -> selectedMainKeys.add(it1) }
        }
    }

    override fun getSelectedList(): LinkedHashSet<Int> {
        return selectedMainKeys
    }

    override fun getActionMenuId(): Int {
        return R.menu.menu_trash
    }


    override fun prepareActionMode(menu: Menu) {
        val selectedItems = getSelectedItems()
        if (selectedItems.isEmpty()) {
            return
        }
        if (activity is TrashActivity) {
            (activity as TrashActivity).updateCount(selectedItems.size)
        }
        if (activity is RecoverPhotoTabActivity) {
            (activity as RecoverPhotoTabActivity).updateCount(selectedItems.size)
        }
        menu.apply {
            val selectableItemCount = getSelectableItemCount()
            val selectedCount = Math.min(selectedKeys.size, selectableItemCount)
            if (selectedCount == selectableItemCount) {
                findItem(R.id.cab_select_all).title = "Deselect All"
                findItem(R.id.cab_select_all).icon = activity.resources.getDrawable(R.drawable.ic_deselect_all_vector)
            } else {
                findItem(R.id.cab_select_all).title = "Select All"
                findItem(R.id.cab_select_all).icon = activity.resources.getDrawable(R.drawable.ic_select_all_vector)
            }
        }
    }

    override fun onViewRecycled(holder: ViewHolder) {
        super.onViewRecycled(holder)
        /* if (!activity.isDestroyed) {
             val itemView = holder.itemView
             visibleItemPaths.remove(itemView.medium_name?.tag)
             val tmb = itemView.medium_thumbnail
             if (tmb != null) {
                 Glide.with(activity).clear(tmb)
             }
         }*/
    }

    override fun actionItemPressed(id: Int) {
        if (selectedKeys.isEmpty()) {
            return
        }

        when (id) {
            R.id.cab_select_all -> selectAll()
        }
    }

    private fun recoverPhoto() {

//        RecoverPhotoDialog(activity) {
//            RestorePhotosAsynctask(activity, getSelectedPaths())
//            {
//                Log.d("TAG", "recoverPhoto: Successs")
//                Toast.short(activity, "Photo restored successfully")
//                listener!!.refreshItems()
//                MainActivity.isNeedToRefresh = true
//                finishActMode()
//            }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
//        }
    }

    fun toggleItemSelect() {
        selectAll()
    }


    override fun getSelectableItemCount() = media.filter { it is Medium }.size

    override fun getIsItemSelectable(position: Int) = !isASectionTitle(position)
    override fun getItemSelectionKey(position: Int) = (media.getOrNull(position) as? Medium)?.path?.hashCode()

    override fun getItemKeyPosition(key: Int) = media.indexOfFirst { (it as? Medium)?.path?.hashCode() == key }

    override fun onActionModeCreated() {
        if (activity is RecoverPhotoTabActivity) {
            (activity as RecoverPhotoTabActivity).toggleToolbar(true)
        }
    }

    override fun onActionModeDestroyed() {
        if (activity is RecoverPhotoTabActivity) {
            (activity as RecoverPhotoTabActivity).toggleToolbar(false)
        }
    }

    override fun getItemViewType(position: Int): Int {
        val tmbItem = media[position]
        return when {
            tmbItem is ThumbnailSection -> ITEM_SECTION
            (tmbItem as Medium).isVideo() || tmbItem.isPortrait() -> ITEM_MEDIUM_VIDEO_PORTRAIT
            else -> ITEM_MEDIUM_PHOTO
        }
    }

    fun getSelectedItems() = selectedKeys.mapNotNull { getItemWithKey(it) } as java.util.ArrayList<Medium>

    fun getSelectedPaths() = getSelectedItems().map { it.path } as java.util.ArrayList<String>

    private fun getFirstSelectedItemPath() = getItemWithKey(selectedKeys.first())?.path

    private fun getItemWithKey(key: Int): Medium? = media.firstOrNull { (it as? Medium)?.path?.hashCode() == key } as? Medium

    fun updateMedia(newMedia: java.util.ArrayList<ThumbnailItem>) {
        val thumbnailItems = newMedia.clone() as java.util.ArrayList<ThumbnailItem>
        if (thumbnailItems.hashCode() != currentMediaHash) {
            currentMediaHash = thumbnailItems.hashCode()
//            var cnt = media.size
            media = thumbnailItems
            enableInstantLoad()
//            notifyItemRangeChanged(cnt, media.size)
            notifyDataSetChanged()
            finishActMode()
        }
    }

    private fun enableInstantLoad() {
//        loadImageInstantly = true
//        delayHandler.postDelayed({
//            loadImageInstantly = false
//        }, INSTANT_LOAD_DURATION)
    }

    fun isASectionTitle(position: Int) = media.getOrNull(position) is ThumbnailSection

    fun getItemBubbleText(position: Int, sorting: Int, dateFormat: String, timeFormat: String): String {
        return (media[position] as? Medium)?.getBubbleText(sorting, activity, dateFormat, timeFormat) ?: ""
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutType = if (viewType == ITEM_SECTION) {
            R.layout.thumbnail_section_for_recover
        } else {
            if (isListViewType) {
                if (viewType == ITEM_MEDIUM_PHOTO) {
                    R.layout.photo_item_list
                } else {
                    R.layout.video_item_list
                }
            } else {
                if (viewType == ITEM_MEDIUM_PHOTO) {
                    R.layout.photo_item_grid
                } else {
                    R.layout.video_item_grid
                }
            }
        }
        return createViewHolder(layoutType, parent)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tmbItem = media.getOrNull(position) ?: return
        if (tmbItem is Medium) {
            visibleItemPaths.add(tmbItem.path)
        }

        val allowLongPress = (!isAGetIntent || allowMultiplePicks) && tmbItem is Medium
        holder.bindView(tmbItem, true, true) { itemView, adapterPosition ->
            if (tmbItem is Medium) {
                setupThumbnail(itemView, tmbItem)
            } else {
                setupSection(itemView, tmbItem as ThumbnailSection)
            }
        }
        bindViewHolder(holder)
    }


    private fun setupThumbnail(view: View, medium: Medium) {
        val isSelected = selectedKeys.contains(medium.path.hashCode())
        view.apply {
            val padding = if (activity.config.thumbnailSpacing <= 1) {
                activity.config.thumbnailSpacing
            } else {
                0
            }

            media_item_holder.setPadding(padding, padding, padding, padding)

            play_portrait_outline?.beVisibleIf(medium.isVideo() || medium.isPortrait())
            if (medium.isVideo()) {
                play_portrait_outline?.setImageResource(R.drawable.ic_play_outline_vector)
                play_portrait_outline?.beVisible()
            } else if (medium.isPortrait()) {
                play_portrait_outline?.setImageResource(R.drawable.ic_portrait_photo_vector)
                play_portrait_outline?.beVisibleIf(showFileTypes)
            }
            if (showFileTypes && (medium.isGIF() || medium.isRaw() || medium.isSVG())) {
                file_type.setText(
                    when (medium.type) {
                        TYPE_GIFS -> R.string.gif
                        TYPE_RAWS -> R.string.raw
                        else -> R.string.svg
                    }
                )
                file_type.beGone()
            } else {
                file_type?.beGone()
            }

            medium_name.beVisibleIf(displayFilenames || isListViewType)
            medium_name.text = medium.name
            medium_name.tag = medium.path

            val showVideoDuration = medium.isVideo() && activity.config.showThumbnailVideoDuration
            if (showVideoDuration) {
                video_duration?.text = medium.videoDuration.getFormattedDuration()
            }
            video_duration?.beVisibleIf(showVideoDuration)
            medium_check.beVisibleIf(isSelected)
            if (isSelected) {
                medium_check.background.applyColorFilter(adjustedPrimaryColor)
                medium_check.applyColorFilter(contrastColor)
            }

            if (isListViewType) {
                media_item_holder.isSelected = isSelected
            }

            var path = medium.path
            if (hasOTGConnected && context.isPathOnOTG(path)) {
                path = path.getOTGPublicPath(context)
            }

            val roundedCorners = when {
                isListViewType -> ROUNDED_CORNERS_SMALL
                activity.config.fileRoundedCorners -> ROUNDED_CORNERS_BIG
                else -> ROUNDED_CORNERS_BIG
            }



            if (loadImageInstantly) {
                activity.loadImage(
                    medium.type, path, medium_thumbnail, scrollHorizontally, animateGifs, cropThumbnails, roundedCorners, medium.getKey(),
                    rotatedImagePaths
                )
            } else {
                medium_thumbnail.setImageDrawable(null)
                medium_thumbnail.isHorizontalScrolling = scrollHorizontally
                delayHandler.postDelayed({
                    val isVisible = visibleItemPaths.contains(medium.path)
                    if (isVisible) {
                        activity.loadImage(
                            medium.type, path, medium_thumbnail, scrollHorizontally, animateGifs, cropThumbnails, roundedCorners,
                            medium.getKey(), rotatedImagePaths
                        )
                    }
                }, IMAGE_LOAD_DELAY)
            }

            if (isListViewType) {
                medium_name.setTextColor(textColor)
//                play_portrait_outline?.applyColorFilter(textColor)
            }
        }
    }

    private fun setupSection(view: View, section: ThumbnailSection) {
        if (isDetailPage || activity is TimeLineActivity) {
            view.tvSeeAll.visibility = GONE
            view.img_one.visibility = GONE
        } else {
            view.tvSeeAll.visibility = VISIBLE
            view.img_one.visibility = VISIBLE
        }
        view.apply {
            if (section.title == "Today") {
                thumbnail_section.text = activity.getString(R.string.today)
            } else if (section.title == "Yesterday") {
                thumbnail_section.text = activity.getString(R.string.yesterday)
            } else {
                thumbnail_section.text = section.title
            }
            if (section.isBigText) {
                thumbnail_section.textSize = 25f
            }else
                thumbnail_section.textSize = 15f
//            thumbnail_section.setTextColor(textColor)
        }
    }

    override fun getItemCount(): Int {
        return media.size
    }
    var mProgressDailog: ProgressDialog? = null
    fun showProgress(msg: String) {
        mProgressDailog = ProgressDialog(activity, R.style.MyAlertDialogNew)
        mProgressDailog!!.setMessage(msg)

        mProgressDailog!!.setCancelable(false)
        mProgressDailog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
        mProgressDailog!!.show()
    }

    fun dismissProgress() {
        activity.runOnUiThread {
            if (mProgressDailog != null && mProgressDailog!!.isShowing) {
                mProgressDailog!!.dismiss()
            }
        }
    }

    fun restoreFiles(isImage:Boolean) {
//        showProgress(activity.getString(R.string.please_wait))
var selectedList=getSelectedPaths()
        finishActMode()
        activity.restoreRecoverTrashPaths(selectedList, false) {
//            dismissProgress()
            listener?.refreshItems()
            if (isImage) {
                activity.addEvent(restoreRecoverTrashImage)
                activity.toast(activity.getString(R.string.msg_image_restored_success))
                PhotoDirectoryFragment.isNeedToRefresh=true
            } else {
                activity.addEvent(restoreRecoverTrashVideo)
                activity.toast(activity.getString(R.string.msg_video_restore_success))
                VideoDirectoryFragment.isNeedToRefresh=true
            }

            finishActMode()
        }
    }
    fun checkDeleteConfirmation() {
        if (config.isDeletePasswordProtectionOn) {
            activity.handleDeletePasswordProtection {
                deleteFiles()
            }
        } else {
            askConfirmDelete()
        }
    }
    var deleteDialog: DeleteWithRememberDialog? = null

    private fun askConfirmDelete() {
        val itemsCnt = selectedKeys.size
        val firstPath = getSelectedPaths().first()
        val items = if (itemsCnt == 1) {
            "\"${firstPath.getFilenameFromPath()}\""
        } else {
            resources.getQuantityString(R.plurals.delete_items, itemsCnt, itemsCnt)
        }

        val isRecycleBin = firstPath.startsWith(activity.recycleBinPath)
        val baseString = if (config.useRecycleBin && !isRecycleBin) R.string.msg_move_vault_trash else R.string.deletion_confirmation
        val question = String.format(resources.getString(baseString), items)
        deleteDialog = DeleteWithRememberDialog(activity, question) {
            if (it) {
                showProgress(activity.getString(R.string.msg_deleting))
                RecoverPhotoTabActivity.isDeleteOrRestore=true
                config.tempSkipDeleteConfirmation = it
                deleteFiles()
            } else {
                finishActMode()
            }

        }

    }
    private fun deleteFiles() {
        VaultFragment.isHideUnHideMedia = true
        if (selectedKeys.isEmpty()) {
            return
        }

        val SAFPath = getSelectedPaths().firstOrNull { activity.needsStupidWritePermissions(it) } ?: getFirstSelectedItemPath() ?: return
        activity.handleSAFDialog(SAFPath) {
            if (!it) {
                return@handleSAFDialog
            }

            val fileDirItems = ArrayList<FileDirItem>(selectedKeys.size)
            val removeMedia = ArrayList<Medium>(selectedKeys.size)
            val positions = getSelectedItemPositions()
            var dbHelper = FavouriteDBHelper(activity)

            getSelectedItems().forEach {
                fileDirItems.add(FileDirItem(it.path, it.name))
                removeMedia.add(it)
                dbHelper.deleteFavDetails(it.path)
                if (VaultFragment.isFakeVaultOpen) {
                    ensureBackgroundThread {
                        activity.fakeVaultMediumDao.deleteMediumPath(it.path)
                    }
                }
            }
            Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: CalledUpdated  Destiamtion ---> $it")
//            removeSelectedItems(positions)
            currentMediaHash = media.hashCode()
//            media.removeAll(removeMedia)
            listener?.tryDeleteFiles(fileDirItems)

        }
    }




}