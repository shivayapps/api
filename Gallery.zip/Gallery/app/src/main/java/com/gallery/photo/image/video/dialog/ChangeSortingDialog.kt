package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.TextView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.utilities.SHOW_ALL
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.helpers.*
import kotlinx.android.synthetic.main.dialog_sort_by_option.view.*

class ChangeSortingDialog(
    val activity: BaseSimpleActivity, val isDirectorySorting: Boolean, val showFolderCheckbox: Boolean,
    val path: String = "", val callback: () -> Unit
) {
    private var currSorting = 0
    private var config = activity.config
    private var pathToUse = if (!isDirectorySorting && path.isEmpty()) SHOW_ALL else path
    private var view: View

    init {
        currSorting = if (isDirectorySorting) config.directorySorting else config.getFolderSorting(pathToUse)
        view = activity.layoutInflater.inflate(R.layout.dialog_sort_by_option, null).apply {

        }

        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

//        val tvTitle = dialog.findViewById(R.id.tvTitle) as TextView
//        val font = Typeface.createFromAsset(activity.assets, "fonts/avenirltpromedium.otf")
//        tvTitle.typeface = font

        val ivClose = dialog.findViewById(R.id.ivClose) as ImageView
        ivClose.setOnClickListener {
            dialog.dismiss()
        }

        val tvDone = dialog.findViewById(R.id.tvDone) as TextView
        tvDone.setOnClickListener {
            updateData()
            dialog.dismiss()
        }

        dialog.show()

        setupSortRadio()
        setupOrderRadio()
    }

    private fun updateData() {
        val sortingRadio = view.sortingDialogRadioSorting
        var sorting = when (sortingRadio.checkedRadioButtonId) {
            R.id.sorting_dialog_radio_name -> SORT_BY_NAME
            R.id.sorting_dialog_radio_size -> SORT_BY_SIZE
            R.id.sorting_dialog_radio_last_modified -> SORT_BY_DATE_MODIFIED
            else -> SORT_BY_DATE_MODIFIED
        }

        if (view.sortingDialogRadioSortingOrder.checkedRadioButtonId == R.id.sorting_dialog_radio_descending) {
            sorting = sorting or SORT_DESCENDING
        }


        if (isDirectorySorting) {
            config.directorySorting = sorting
        } else {
            config.sorting = sorting

        }
        callback()
    }

    private fun setupSortRadio() {
        val sortingRadio = view.sortingDialogRadioSorting
        sortingRadio.setOnCheckedChangeListener { group, checkedId ->
//            val isSortingByNameOrPath = checkedId == sortingRadio.sorting_dialog_radio_name.id || checkedId == sortingRadio.sorting_dialog_radio_path.id
//            view.sorting_dialog_numeric_sorting.beVisibleIf(isSortingByNameOrPath)
//            view.use_for_this_folder_divider.beVisibleIf(view.sorting_dialog_numeric_sorting.isVisible() || view.sorting_dialog_use_for_this_folder.isVisible())

//            val isCustomSorting = checkedId == sortingRadio.sorting_dialog_radio_custom.id
//            view.sorting_dialog_radio_order.beVisibleIf(!isCustomSorting)
//            view.sorting_dialog_order_divider.beVisibleIf(!isCustomSorting)
        }

        val sortBtn = when {
            currSorting and SORT_BY_SIZE != 0 -> sortingRadio.sorting_dialog_radio_size
            currSorting and SORT_BY_DATE_MODIFIED != 0 -> sortingRadio.sorting_dialog_radio_last_modified
            else -> sortingRadio.sorting_dialog_radio_name
        }
        sortBtn.isChecked = true
    }

    private fun setupOrderRadio() {
        val orderRadio = view.sortingDialogRadioSortingOrder
        var orderBtn = orderRadio.sorting_dialog_radio_ascending

        if (currSorting and SORT_DESCENDING != 0) {
            orderBtn = orderRadio.sorting_dialog_radio_descending
        }
        orderBtn.isChecked = true
    }

}
