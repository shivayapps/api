package com.gallery.photo.image.video.lock.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.gallery.photo.image.video.R;


public class LockSettingsActivity extends AppCompatActivity implements View.OnClickListener {
private ImageView iv_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lock_settings);
        initViews();
        initListener();
    }

    private void initListener() {
        iv_back.setOnClickListener(this);
    }

    private void initViews() {
        iv_back=findViewById(R.id.iv_back);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.iv_back:
                onBackPressed();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
