package com.gallery.photo.image.video.fragment

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.RelativeLayout
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activityBinding.TrashActivity
import com.gallery.photo.image.video.adapter.NotesAdapter
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.databinding.FragmentTrashImageBinding
import com.gallery.photo.image.video.dialog.DeleteWithRememberDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.Note
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager


class TrashNotesFragment : BaseBindingFragment<FragmentTrashImageBinding>(), MediaOperationsListener {

    var noteList = ArrayList<Note>()

    companion object {

        @JvmStatic
        fun newInstance() =
            TrashNotesFragment().apply {
            }
    }

    override fun setBinding(layoutInflater: LayoutInflater, container: ViewGroup?): FragmentTrashImageBinding {
        return FragmentTrashImageBinding.inflate(layoutInflater, container, false)
    }

    override fun initView() {
        super.initView()
        mBinding.mediaRefreshLayout.setOnRefreshListener { getMedia() }
        getMedia()
    }

    private fun getMedia() {
        ensureBackgroundThread {
            noteList = if (VaultFragment.isFakeVaultOpen) {
                mContext.noteDao.getDeletedFakeVaultNotes() as ArrayList<Note>
            } else {
                mContext.noteDao.getDeletedMainVaultNotes() as ArrayList<Note>
            }
            gotNotes()
        }
    }

    private fun gotNotes() {
        requireActivity().runOnUiThread {
            Log.d(TAG, "getMedia: Media size -->" + noteList.size)
            mBinding.rlNoFileFound.beVisibleIf(noteList.isEmpty())
            mBinding.rlNoFileFound.beGoneIf(noteList.isNotEmpty())
            mBinding.mediaGrid.beVisibleIf(mBinding.rlNoFileFound.isGone())
            mBinding.mediaRefreshLayout.isRefreshing = false
            if (mContext is TrashActivity) {
                if ((mContext as TrashActivity).mBinding.viewPagerTrash.currentItem == 4) {
                    (mContext as TrashActivity).mBinding.imgDelete.beGoneIf(noteList.size <= 0)
                    (mContext as TrashActivity).mBinding.imgDelete.beVisibleIf(noteList.size > 0)
                }
            }
            setupLayoutManager()
            setupAdapter()
        }
    }

    private fun setupAdapter() {
        requireActivity().runOnUiThread {

            if (mBinding.mediaGrid != null) {
                val currAdapter = mBinding.mediaGrid.adapter
                if (currAdapter == null) {
                    val fastscroller = mBinding.mediaHorizontalFastscroller
                    NotesAdapter(
                        mContext as BaseSimpleActivity, noteList, this, false,
                        false, mBinding.mediaGrid, fastscroller
                    ) {
//                        if (it is Note && !isFinishing) {
//                            itemClicked(it)
//                        }
                    }.apply {
                        mBinding.mediaGrid.adapter = this
                    }
                    setupLayoutManager()
                } else {
                    (currAdapter as NotesAdapter).updateMedia(noteList)
                }
            }
        }
    }


    private fun setupLayoutManager() {
        setupListLayoutManager()

    }


    private fun getTrashAdapter() = mBinding.mediaGrid.adapter as? NotesAdapter
    private fun setupListLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL

        val smallMargin = resources.getDimension(R.dimen.small_margin).toInt()
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = smallMargin
            bottomMargin = smallMargin
        }
    }

    override fun refreshItems() {
        getMedia()

    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {
        val filtered = fileDirItems.filter { !mContext.getIsPathDirectory(it.path) && it.path.isMediaFile() } as ArrayList
        if (filtered.isEmpty()) {
            return
        }
        deleteFilteredFiles(filtered)
    }

    private fun deleteFilteredFiles(filtered: ArrayList<FileDirItem>) {

    }

    override fun selectedPaths(paths: ArrayList<String>) {

    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {

    }

    fun restoreNotes() {
        if (getTrashAdapter() != null) {
            getTrashAdapter()!!.restoreFiles()
        }
    }

    fun deleteNotes() {
        if (getTrashAdapter() != null) {
            getTrashAdapter()!!.checkDeleteConfirmation()
        }
    }

    fun deleteAllNotes() {
        if (noteList.isEmpty())
            return
        val itemsCnt = noteList.size
        val firstPath = noteList.first()
        val items = if (itemsCnt == 1) {
            "\"${firstPath.title}\""
        } else {
            resources.getQuantityString(R.plurals.delete_items, itemsCnt, itemsCnt)
        }

        val baseString = R.string.deletion_confirmation
        val question = String.format(resources.getString(baseString), items)
        DeleteWithRememberDialog(mContext, question) {
            if (it) {
                TrashActivity.isDeleteOrRestore = true
                if (mContext is TrashActivity)
                    (mContext as TrashActivity).showProgress(mContext.getString(R.string.msg_deleting))
                mContext.config.tempSkipDeleteConfirmation = it

                ensureBackgroundThread {
                    noteList.forEach {
                        mContext.noteDao.delete(it)
                    }
                    requireActivity().runOnUiThread {
                        mContext.addEvent(deleteTrashNotes)
                        if (mContext is TrashActivity)
                            (mContext as TrashActivity).dismissProgress()
                        refreshItems()
                    }
                }
            }

        }
    }
}