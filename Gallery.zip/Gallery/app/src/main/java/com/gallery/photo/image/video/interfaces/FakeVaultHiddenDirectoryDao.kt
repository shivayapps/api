package com.gallery.photo.image.video.interfaces

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy.REPLACE
import androidx.room.Query
import com.gallery.photo.image.video.utilities.RECYCLE_BIN
import com.gallery.photo.image.video.models.FakeVaultHiddenDirectory

@Dao
interface FakeVaultHiddenDirectoryDao {
    @Query("SELECT path, thumbnail, filename, media_count, last_modified, date_taken, size, location, media_types, sort_value FROM FakeVaultDirectories")
    fun getAll(): List<FakeVaultHiddenDirectory>
    @Query("SELECT distinct path FROM FakeVaultDirectories")
    fun getTotalDirectory(): List<String>

    @Insert(onConflict = REPLACE)
    fun insert(directory: FakeVaultHiddenDirectory)

    @Insert(onConflict = REPLACE)
    fun insertAll(directories: List<FakeVaultHiddenDirectory>)

    @Query("DELETE FROM FakeVaultDirectories WHERE path = :path COLLATE NOCASE")
    fun deleteDirPath(path: String)


    @Query("SELECT path, thumbnail, filename, media_count, last_modified, date_taken, size, location, media_types, sort_value FROM  FakeVaultDirectories WHERE path = :path")
    fun getDirectoryDetailFromDirPath(path: String): FakeVaultHiddenDirectory

    @Query("UPDATE OR REPLACE FakeVaultDirectories SET thumbnail = :thumbnail, media_count = :mediaCnt, last_modified = :lastModified, date_taken = :dateTaken, size = :size, media_types = :mediaTypes, sort_value = :sortValue WHERE path = :path COLLATE NOCASE")
    fun updateDirectory(path: String, thumbnail: String, mediaCnt: Int, lastModified: Long, dateTaken: Long, size: Long, mediaTypes: Int, sortValue: String)

    @Query("UPDATE FakeVaultDirectories SET thumbnail = :thumbnail, filename = :name, path = :newPath WHERE path = :oldPath COLLATE NOCASE")
    fun updateDirectoryAfterRename(thumbnail: String, name: String, newPath: String, oldPath: String)

    @Query("DELETE FROM FakeVaultDirectories WHERE path = \'$RECYCLE_BIN\' COLLATE NOCASE")
    fun deleteRecycleBin()

    @Query("SELECT thumbnail FROM FakeVaultDirectories WHERE path = :path")
    fun getDirectoryThumbnail(path: String): String?
}
