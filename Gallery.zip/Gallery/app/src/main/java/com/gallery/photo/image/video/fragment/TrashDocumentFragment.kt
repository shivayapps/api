package com.gallery.photo.image.video.fragment

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.RelativeLayout
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.bindActivity.TrashActivity
import com.gallery.photo.image.video.adapter.AudioDocFileAdapter
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.databinding.FragmentTrashImageBinding
import com.gallery.photo.image.video.dialog.DeleteWithRememberDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.HideFilesDetail
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.helpers.VIEW_TYPE_GRID
import com.gallery.photo.image.video.helpers.VIEW_TYPE_LIST
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager
import com.gallery.photo.image.video.views.MyRecyclerView
import java.io.File


class TrashDocumentFragment : BaseBindingFragment<FragmentTrashImageBinding>(), MediaOperationsListener {


    var title: String? = null
    private var mPath = ""
    private var mIsGetImageIntent = true
    private var mIsGetVideoIntent = false
    private var mIsGetAnyIntent = false
    private var mAllowPickingMultiple = false
    private var mShowAll = false

    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mLastSearchedText = ""
    var itemClickPath: String = ""
    var isShowInfo = false
    var isHide = true
    var isFromVault = false
    var isFromFakeVault = false
    var mMedia = ArrayList<HideFilesDetail>()

    companion object {
        @JvmStatic
        fun newInstance() =
            TrashDocumentFragment().apply {
            }
    }

    override fun setBinding(layoutInflater: LayoutInflater, container: ViewGroup?): FragmentTrashImageBinding {
        return FragmentTrashImageBinding.inflate(layoutInflater, container, false)
    }

    override fun initView() {
        super.initView()
        mBinding.mediaRefreshLayout.setOnRefreshListener { getMedia() }
        getMedia()
    }

    private fun getMedia() {
        if (getTrashAdapter() != null)
            getTrashAdapter()!!.finishActMode()
        ensureBackgroundThread {
            var newMedia = requireContext().hideFileDao.getTypeWiseDeletedMedia(TYPE_DOCUMENT)
            if (VaultFragment.isFakeVaultOpen) {
                newMedia = requireContext().fakeHideFileDao.getTypeWiseDeletedMedia(TYPE_DOCUMENT)
            }

            newMedia.filter {
                var path = File(mContext.recycleBinPath, it.path.removePrefix(RECYCLE_BIN)).toString()
                !mContext.getDoesFilePathExist(path)
            }.forEach {
                if (VaultFragment.isFakeVaultOpen)
                    mContext.fakeHideFileDao.deleteHideFilesDetailPath(it.path)
                else
                    mContext.hideFileDao.deleteHideFilesDetailPath(it.path)
            }
            mMedia = mContext.getUpdatedTrashFilePath(newMedia as ArrayList<HideFilesDetail>)
            if (isAdded) {
                requireActivity().runOnUiThread {
                    Log.d(TAG, "getMedia: Media size -->" + mMedia.size)
                    mBinding.rlNoFileFound.beVisibleIf(mMedia.isEmpty())
                    mBinding.rlNoFileFound.beGoneIf(mMedia.isNotEmpty())
                    mBinding.mediaGrid.beVisibleIf(mBinding.rlNoFileFound.isGone())
                    mBinding.mediaRefreshLayout.isRefreshing = false

                    if (mContext is TrashActivity) {
                        if ((mContext as TrashActivity).mBinding.viewPagerTrash.currentItem == 3) {
                            (mContext as TrashActivity).mBinding.imgDelete.beGoneIf(mMedia.size <= 0)
                            (mContext as TrashActivity).mBinding.imgDelete.beVisibleIf(mMedia.size > 0)
                        }
                    }

                    setupAdapter()
                }
            }

        }
    }

    private fun setupAdapter() {
        Log.d("TAG", "setupAdapter: " + mMedia.size.toString())
        val currAdapter = mBinding.mediaGrid.adapter
        if (currAdapter == null) {
            val fastscroller = if (mContext.config.scrollHorizontally) mBinding.mediaHorizontalFastscroller else mBinding.mediaVerticalFastscroller
            AudioDocFileAdapter(
                mContext as BaseSimpleActivity, mMedia.clone() as ArrayList<HideFilesDetail>, this, mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent,
                mAllowPickingMultiple, mBinding.mediaGrid, fastscroller, isFromFakeVault
            ) {
//                if (it is Medium && !isFinishing) {
//                    itemClicked(it.path)
//                }
            }.apply {
                mBinding.mediaGrid.adapter = this
            }

            val viewType = mContext.config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            if (viewType == VIEW_TYPE_LIST) {
                mBinding.mediaGrid.scheduleLayoutAnimation()
            }

            setupLayoutManager()
            measureRecyclerViewContent(mMedia)
        } else if (mLastSearchedText.isEmpty()) {
            (currAdapter as AudioDocFileAdapter).updateMedia(mMedia)
            measureRecyclerViewContent(mMedia)
        }

    }


    private fun setupLayoutManager() {
        setupListLayoutManager()
    }


    private fun getTrashAdapter() = mBinding.mediaGrid.adapter as? AudioDocFileAdapter
    private fun setupListLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        try {
            layoutManager.orientation = RecyclerView.VERTICAL
        } catch (e: Exception) {
        }

        val smallMargin = resources.getDimension(R.dimen.small_margin).toInt()
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = smallMargin
            bottomMargin = smallMargin
        }
    }

    private fun setupScrollDirection() {
        val viewType = mContext.config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        val allowHorizontalScroll = mContext.config.scrollHorizontally && viewType == VIEW_TYPE_GRID
        mBinding.mediaVerticalFastscroller.isHorizontal = false
        mBinding.mediaVerticalFastscroller.beGoneIf(allowHorizontalScroll)

        mBinding.mediaHorizontalFastscroller.isHorizontal = true
        mBinding.mediaHorizontalFastscroller.beVisibleIf(allowHorizontalScroll)


    }


    private fun measureRecyclerViewContent(media: ArrayList<HideFilesDetail>) {
        mBinding.mediaGrid.onGlobalLayout {
            if (mContext.config.scrollHorizontally) {
                calculateContentWidth(media)
            } else {
                calculateContentHeight(media)
            }
        }
    }

    private fun calculateContentWidth(media: ArrayList<HideFilesDetail>) {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        val thumbnailWidth = layoutManager.getChildAt(0)?.width ?: 0
        val spacing = mContext.config.thumbnailSpacing
        val fullWidth = ((media.size - 1) / layoutManager.spanCount + 1) * (thumbnailWidth + spacing) - spacing
        mBinding.mediaHorizontalFastscroller.setContentWidth(fullWidth)
        mBinding.mediaHorizontalFastscroller.setScrollToX(mBinding.mediaGrid.computeHorizontalScrollOffset())
    }

    private fun calculateContentHeight(media: ArrayList<HideFilesDetail>) {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        val pathToCheck = if (mPath.isEmpty()) SHOW_ALL else mPath
        val hasSections = mContext.config.getFolderGrouping(pathToCheck) and GROUP_BY_NONE == 0 && !mContext.config.scrollHorizontally
        val sectionTitleHeight = if (hasSections) layoutManager.getChildAt(0)?.height ?: 0 else 0
        val thumbnailHeight = if (hasSections) layoutManager.getChildAt(1)?.height ?: 0 else layoutManager.getChildAt(0)?.height ?: 0

        var fullHeight = 0
        var curSectionItems = 0
        media.forEach {
            curSectionItems++
        }
        val spacing = mContext.config.thumbnailSpacing
        fullHeight += ((curSectionItems - 1) / layoutManager.spanCount + 1) * (thumbnailHeight + spacing) - spacing
        mBinding.mediaVerticalFastscroller.setContentHeight(fullHeight)
        mBinding.mediaVerticalFastscroller.setScrollToY(mBinding.mediaGrid.computeVerticalScrollOffset())
    }

    override fun refreshItems() {
        getMedia()
    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {
        val filtered = fileDirItems.filter { !mContext.getIsPathDirectory(it.path) } as ArrayList
        if (filtered.isEmpty()) {
            return
        }
        deleteFilteredFiles(filtered)
    }

    private fun deleteFilteredFiles(filtered: ArrayList<FileDirItem>) {
        (mContext as BaseSimpleActivity).deleteFiles(filtered) {
            if (!it) {
                mContext.toast(R.string.unknown_error_occurred)
                if (getTrashAdapter() != null)
                    getTrashAdapter()!!.dismissProgress()
                if (mContext is TrashActivity)
                    (mContext as TrashActivity).dismissProgress()
                return@deleteFiles
            }

            mMedia.removeAll { filtered.map { it.path }.contains((it as? HideFilesDetail)?.path) }

            ensureBackgroundThread {
                filtered.forEach {
                    if (VaultFragment.isFakeVaultOpen)
                        mContext.fakeHideFileDao.deleteHideFilesDetailPath(it.path.replace("${mContext.recycleBinPath}", RECYCLE_BIN))
                    else
                        mContext.hideFileDao.deleteHideFilesDetailPath(it.path.replace("${mContext.recycleBinPath}", RECYCLE_BIN))
                }

                mContext.runOnUiThread {
                    mContext.addEvent(deleteTrashDocument)
                    if (getTrashAdapter() != null)
                        getTrashAdapter()!!.dismissProgress()
                    if (mContext is TrashActivity)
                        (mContext as TrashActivity).dismissProgress()
                    refreshItems()
                }
            }


        }
    }

    override fun selectedPaths(paths: ArrayList<String>) {

    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {

    }

    fun restoreDocuments() {
        if (getTrashAdapter() != null) {
            getTrashAdapter()!!.restoreFiles(false)
        }
    }

    fun deleteDocuments() {
        if (getTrashAdapter() != null) {
            getTrashAdapter()!!.checkDeleteConfirmation()
        }
    }

    fun deleteAllDocuments() {
        if (mMedia.isEmpty())
            return
        val itemsCnt = mMedia.size
        val firstPath = mMedia.first().path
        val items = if (itemsCnt == 1) {
            "\"${firstPath.getFilenameFromPath()}\""
        } else {
            resources.getQuantityString(R.plurals.delete_items, itemsCnt, itemsCnt)
        }

        val baseString = R.string.deletion_confirmation
        val question = String.format(resources.getString(baseString), items)
        DeleteWithRememberDialog(mContext, question) {
            if (it) {
                TrashActivity.isDeleteOrRestore = true
                if (mContext is TrashActivity)
                    (mContext as TrashActivity).showProgress(mContext.getString(R.string.msg_deleting))
                mContext.config.tempSkipDeleteConfirmation = it
                val fileDirItems = ArrayList<FileDirItem>(mMedia.size)
                mMedia.forEach {
                    fileDirItems.add(FileDirItem(it.path, it.name))
                }
                tryDeleteFiles(fileDirItems)
            }

        }
    }
}