package com.gallery.photo.image.video.activity

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.View.*
import android.widget.EditText
import android.text.Html
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.text.HtmlCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.example.app.ads.helper.*
import com.example.jdrodi.utilities.isOnline
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd

import com.example.gallery.MimeType
import com.example.gallery.internal.entity.SelectionSpec
import com.gallery.photo.image.video.Camera.CameraActivity
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activityBinding.CustomFilePickerActivity
import com.gallery.photo.image.video.activityBinding.RecoverPhotoTabActivity
import com.gallery.photo.image.video.activityBinding.TimeLineActivity
import com.gallery.photo.image.video.activityBinding.VaultGalleryActivity
import com.gallery.photo.image.video.adapter.DirectoryAdapter
import com.gallery.photo.image.video.adapter.ViewPagerFragmentAdapter
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.database.FavouriteDBHelper
import com.gallery.photo.image.video.dialog.ChangeGridSizeDialog
import com.gallery.photo.image.video.dialog.ChangeSortingDialog
import com.gallery.photo.image.video.dialog.SubscriptionDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.fragment.*
import com.gallery.photo.image.video.inapp.*
import com.gallery.photo.image.video.jobs.NewPhotoFetcher
import com.gallery.photo.image.video.models.FakeVaultMedium
import com.gallery.photo.image.video.models.HideFilesDetail
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.rateandfeedback.displayExitDialog
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.vaultgallery.model.KEY_MEDIA_LIST
import com.gallery.photo.image.video.vaultgallery.model.KEY_MEDIA_TYPE
import com.gallery.photo.image.video.vaultgallery.ui.GalleryEngine
import com.gallery.photo.image.video.vaultgallery.ui.REQUEST_SELECT_MEDIA
import com.gallery.photo.image.video.helpers.*
import com.google.android.material.appbar.AppBarLayout
import com.tbruyelle.rxpermissions2.RxPermissions
import io.github.inflationx.viewpump.ViewPumpContextWrapper
import kotlinx.android.synthetic.main.activity_main_new.*
import kotlinx.android.synthetic.main.activity_main_new.adViewContainer
import kotlinx.android.synthetic.main.activity_main_new.etSearch
import kotlinx.android.synthetic.main.activity_main_new.imgClose
import kotlinx.android.synthetic.main.activity_main_new.imgOptHideUnHide
import kotlinx.android.synthetic.main.activity_main_new.imgOptionMenu
import kotlinx.android.synthetic.main.activity_main_new.imgOptions
import kotlinx.android.synthetic.main.activity_main_new.imgSearch
import kotlinx.android.synthetic.main.activity_main_new.llBottomOption
import kotlinx.android.synthetic.main.activity_main_new.llHideOpt
import kotlinx.android.synthetic.main.activity_main_new.tvHideUnHideText
import kotlinx.android.synthetic.main.drawer_content.*
import kotlinx.android.synthetic.main.fragment_photo_directory.directories_grid
import kotlinx.android.synthetic.main.fragment_photo_directory.directories_refresh_layout
import kotlinx.android.synthetic.main.fragment_vault.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.jetbrains.anko.toast
import java.io.*


private val TAG = MainActivity::class.java.simpleName
const val REQUEST_CODE_CHOOSE = 101
const val REQUEST_CODE_CROP = 102
const val REQUEST_CODE_CAMERA = 1012
const val REQUEST_CODE_FROM_FILE = 1013
const val REQUEST_CODE_FOR_SUBSCRIPTION = 1013
val permission_gallery = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA)


class MainActivity : BaseActivity(), InAppPurchaseHelper.OnPurchased, AdMobAdsListener {

    var prevPos: Int = 0;
    private var mDrawerToggle: ActionBarDrawerToggle? = null
    private val is_closed = true
    private var isOpenPermissionDial: Boolean = false
    var isScroll = false
    var isFromSetting = false;
    var isFromSettingForCamera = false;
    var isVaultCameraClicked = false;
    lateinit var viewPagerFragmentAdapter: ViewPagerFragmentAdapter
    lateinit var databaseInputStream1: InputStream
    lateinit var dbHelper: FavouriteDBHelper
    private var mWasProtectionHandled = false
    private var mIsPasswordProtectionPending = false
    var isInActionMode = false
    var isAlertDisplay = false


    var isFirstTime = true
    var isFABOpen = false
    var isFirstTimeAdShow = false
//    var menuTarget: TapTargetView? = null
    var isSettingClicked = false
    var isHideClicked = false
    var isFromOneSignal = false
    var mPos: Int = 0
    var isBillingInit = false

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)


    companion object {
        var isNeedToRefresh: Boolean = false
        var isInternalCall: Boolean = false
        var isRemoveAdClicked = false
        var isHideButtonClicked = false
        var activity: Activity? = null
        var isAdLoaded: Boolean = false
        var isAdShown: Boolean = false
        var isPaused: Boolean = false

        fun newIntent(mContext: Context): Intent {
            return Intent(mContext, MainActivity::class.java)
        }

    }


    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        if (savedInstanceState == null) {
//            config.temporarilyShowHidden = false
//            config.tempSkipDeleteConfirmation = false
//            startNewPhotoFetcher()
//        }
        setContentView(R.layout.activity_main_new)
        isUnLockApp = false

        activity = this
        Log.d("TAGCheckTIME", "Main Activity On Create: ")

        if (OpenAdSplashActivity.activity != null)
            OpenAdSplashActivity.activity!!.finish()

    }

    override fun getContext(): Activity {
        return this@MainActivity
    }

    override fun initActions() {

    }


    override fun onResume() {
        super.onResume()
        Log.d("TagHidden", "onResume: MainActivity")
        Log.d("TagHidden", "onResume: MainActivity -->" + viewPagerHome.currentItem)

        if (AdsManager(this).isNeedToShowAds()) {

            adViewContainer.visibility = GONE

        } else {
            adViewContainer.visibility = GONE
        }
        mIsPasswordProtectionPending = config.isAppPasswordProtectionOn
        if (isFromSetting) {
            isFromSetting = false
            checkStoragePermission()
        }
        if (isFromSettingForCamera) {
            isFromSettingForCamera = false
            if (isVaultCameraClicked) {
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                ) {
                    fabAddHiddenPhotoFromCamera.performClick()
                }
            } else {
                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                ) {
                    llCamera.performClick()
                }

            }
        }
        if (isAskingPermissionsActionNull) {
            isAskingPermissionsActionNull = false
            checkStoragePermission()
        }


        try {
            InAppPurchaseHelper.instance!!.initBillingClient(this, this)
        } catch (e: Exception) {
            Log.e(TAG, "initBillingClient: " + e.message)
        }
        if (isSettingClicked)
            isSettingClicked = false
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
            mPos = intent.getIntExtra("mType", 0)
        }
        if (isFromOneSignal) {
            Handler(Looper.getMainLooper()).postDelayed({
                viewPagerHome.currentItem = mPos
            }, 1000)
        }

    }


    fun convertDpToPx(dp: Int): Int {
        return Math.round(dp * (resources.displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT))
    }

    override fun initData() {
        checkStoragePermission()

    }

    private fun removeTempFolder() {
        if (config.tempFolderPath.isNotEmpty()) {
            val newFolder = File(config.tempFolderPath)
            if (getDoesFilePathExist(newFolder.absolutePath) && newFolder.isDirectory) {
                if (newFolder.list()?.isEmpty() == true && newFolder.getProperSize(true) == 0L && newFolder.getFileCount(true) == 0) {
//                    toast(String.format(getString(R.string.deleting_folder), config.tempFolderPath), Toast.LENGTH_LONG)
                    tryDeleteFileDirItem(newFolder.toFileDirItem(applicationContext), true, true)
                }
            }
            config.tempFolderPath = ""
        }
    }

    private fun startNewPhotoFetcher() {
        if (isNougatPlus()) {
            val photoFetcher = NewPhotoFetcher()
            if (!photoFetcher.isScheduled(applicationContext)) {
                photoFetcher.scheduleJob(applicationContext)
            }
        }
    }

    private fun setData() {
        registerFileUpdateListener()
        Log.d("TAGCheckTIME", "setData MainAvtivity: ")
        Log.d("TAGSetData", "setData: OpenAdSplashActivity.isAsyncTaskStarted" + OpenAdSplashActivity.isAsyncTaskStarted)
        if (!OpenAdSplashActivity.isAsyncTaskStarted) {
            getPhotoDirectories()
            getVideoDirectories()
            updateTrash()
        }
        viewPagerFragmentAdapter = ViewPagerFragmentAdapter(this)
        viewPagerFragmentAdapter.addFragment(PhotoDirectoryFragment.getInstance(1))
        viewPagerFragmentAdapter.addFragment(VideoDirectoryFragment.getInstance(2))
        viewPagerFragmentAdapter.addFragment(VaultFragment.getInstance(3))
        viewPagerFragmentAdapter.addFragment(SettingsFragment.getInstance(4))

        viewPagerHome.apply {
            adapter = viewPagerFragmentAdapter
            (getChildAt(0) as RecyclerView).overScrollMode = RecyclerView.OVER_SCROLL_NEVER
            offscreenPageLimit = 4

        }
        /*navigationImagesMargin(bottomNav)*/
        bottomNav.setOnItemSelectedListener { position ->
            when (position) {

                0, R.id.nav_photo -> {
                    viewPagerHome.currentItem = 0
                }
                1, R.id.nav_video -> {
                    viewPagerHome.currentItem = 1
                }
                2, R.id.nav_vault -> {
                    viewPagerHome.currentItem = 2
                }
//                3, R.id.nav_settings -> {
//                    viewPagerHome.currentItem = 3
//                }
                else -> null
            } != null
        }

        viewPagerHome.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {

                if (prevPos != position) {
//                    bottomNav.menu.getItem(prevPos).isChecked = false;
//                    bottomNav.menu.getItem(position).isChecked = true;
                    if (etSearch.visibility != GONE) {
                        etSearch.visibility = GONE
                        imgClose.visibility = GONE
                        imgOptions.visibility = VISIBLE
                        imgSearch.visibility = VISIBLE
                        tvHeaderTitle.visibility = VISIBLE
                        etSearch.text = null
                        etSearch.clearFocus()
                        hideKeyboard(etSearch)
                        val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(prevPos)
                        if (photoDirectoryFragment is PhotoDirectoryFragment) {
                            photoDirectoryFragment.setupAdapter(photoDirectoryFragment.mDirs, "")
                        }
                        if (photoDirectoryFragment is VideoDirectoryFragment) {
                            photoDirectoryFragment.setupAdapter(photoDirectoryFragment.mDirs, "")
                        }
                    }
                    var fragment = viewPagerFragmentAdapter.createFragment(prevPos)
                    when (fragment) {
                        is PhotoDirectoryFragment -> {
                            try {

                                if (fragment.getRecyclerAdapter() != null) {
                                    if (!fragment.getRecyclerAdapter()?.getSelectedPaths().isNullOrEmpty()) {
                                        fragment.getRecyclerAdapter()?.finishActMode()
                                        fragment.setupAdapter(fragment.mDirs, "")
                                    }
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                        is VideoDirectoryFragment -> {
                            try {
                                if (!fragment.getRecyclerAdapter()?.getSelectedPaths().isNullOrEmpty()) {
                                    fragment.getRecyclerAdapter()?.finishActMode()
                                    fragment.setupAdapter(fragment.mDirs, "")
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }

                    }

                    when (position) {
                        0 -> {
                            enableToolbarScrolling()
                            VaultFragment.isTabUnlock = false
                            adViewContainer.visibility = GONE
                            imgAddHiddenPhoto.visibility = GONE
                            tvHeaderTitle.visibility = View.VISIBLE
                            imgSearch.visibility = View.VISIBLE
                            tvHeaderTitle.text = getString(R.string.title_my_photo)
//                            bottomNav.selectedItemId = R.id.nav_photo
                            bottomNav.itemActiveIndex=0
                        }
                        1 -> {
                            enableToolbarScrolling()
                            VaultFragment.isTabUnlock = false
                            adViewContainer.visibility = GONE
                            imgAddHiddenPhoto.visibility = GONE
                            tvHeaderTitle.visibility = View.VISIBLE
                            imgSearch.visibility = View.VISIBLE
                            tvHeaderTitle.text = getString(R.string.title_my_video)
//                            bottomNav.selectedItemId = R.id.nav_video
                            bottomNav.itemActiveIndex=1
                        }
                        2 -> {
                            VaultFragment.isNeedToShowHiddenByGallery = true
                            enableToolbarScrolling()
                            adViewContainer.visibility = GONE
                            tvHeaderTitle.visibility = View.VISIBLE
                            tvHeaderTitle.text = getString(R.string.title_my_vault)
//                            bottomNav.selectedItemId = R.id.nav_vault
                            bottomNav.itemActiveIndex=2
                        }
//                        3 -> {
//                            disableToolbarScrolling()
//                            VaultFragment.isTabUnlock = false
//                            if (AdsManager(this@MainActivity).isNeedToShowAds() && isOnline())
//                                adViewContainer.visibility = GONE
//                            else
//                                adViewContainer.visibility = GONE
//                            tvHeaderTitle.visibility = View.VISIBLE
//                            imgSearch.visibility = View.GONE
//                            imgAddHiddenPhoto.visibility = View.GONE
//                            tvHeaderTitle.text = getString(R.string.title_settings)
//                            bottomNav.selectedItemId = R.id.nav_settings
//                        }
                    }
                }
                prevPos = position
            }
        })
        ensureBackgroundThread { copyDatabase() }
        if (AdsManager(this@MainActivity).isNeedToShowAds()) {

            llRemoveAds.visibility = VISIBLE
//            dividerRemoveAd.visibility = VISIBLE
        } else {

            llRemoveAds.visibility = GONE
//            dividerRemoveAd.visibility = GONE
        }
        mDrawerToggle = object : ActionBarDrawerToggle(this, drawerLayout, R.string.drawer_open, R.string.drawer_close) {
            override fun onDrawerOpened(drawerView: View) {
                hideKeyboard(etSearch)
                super.onDrawerOpened(drawerView)
                setDrawerData()
                if (AdsManager(this@MainActivity).isNeedToShowAds()) {

                    llRemoveAds.visibility = VISIBLE
//                    dividerRemoveAd.visibility = VISIBLE
                } else {

                    llRemoveAds.visibility = GONE
//                    dividerRemoveAd.visibility = GONE
                }
            }
        }
        if (config.viewTypeFolders == VIEW_TYPE_GRID) {
            imgOptions.setImageDrawable(getDrawable(R.drawable.ic_gallery_list))
        } else {

            imgOptions.setImageDrawable(getDrawable(R.drawable.ic_gallery_grid))
        }
        drawerLayout.addDrawerListener(mDrawerToggle as ActionBarDrawerToggle)
        imgSideMenu.setOnClickListener(this)
        imgOptions.setOnClickListener(this)

        llRemoveAds.setOnClickListener(this)
        llShareApp.setOnClickListener(this)
        val sortBtn = when {
            this.config.directorySorting and SORT_BY_SIZE != 0 -> "Size"
            this.config.directorySorting and SORT_BY_DATE_MODIFIED != 0 -> "Date"
            this.config.directorySorting and SORT_BY_NAME != 0 -> "Name"
            else -> "Date"
        }
        val sortOrder = when {
            this.config.directorySorting and SORT_DESCENDING != 0 -> "Descending"
            else -> "Ascending"
        }
        txtSort.text = Html.fromHtml("<font color='#000000'>Sort By </font><font color='#90939c'>($sortBtn, $sortOrder)</font>")
        txtGridCount.text = Html.fromHtml("<font color='#000000'>Grid Size </font><font color='#90939c'>(${this.config.dirColumnCnt} x N)</font>")

        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = findViewById(R.id.gift_ad_icon),
                fivBlastIcon = findViewById(R.id.gift_blast_ad_icon)
            )
        }
        llFavourite.setOnClickListener(this)
        llPlaceItem.setOnClickListener(this)
        llTimeLine.setOnClickListener(this)
        llDuplicateFinder.setOnClickListener(this)
        llGridCount.setOnClickListener(this)
        llRecoverPhoto.setOnClickListener(this)
        llSortBy.setOnClickListener(this)
        llRecoverTrash.setOnClickListener(this)
        llBatteryAlert.setOnClickListener(this)
        llCamera.setOnClickListener(this)
        imgAddHiddenPhoto.setOnClickListener(this)
        flBackground.setOnClickListener(this)
        fabAddHiddenPhotoFromCamera.setOnClickListener(this)
        fabAddHiddenPhotoFromGallery.setOnClickListener(this)
        fabAddHiddenAudio.setOnClickListener(this)
        fabAddHiddenDocument.setOnClickListener(this)
        fabAddHiddenVideo.setOnClickListener(this)
        fabAddHiddenPhotoFromFolder.setOnClickListener(this)


        setupSearch()

        dbHelper = FavouriteDBHelper(this)

        imgClose.setOnClickListener(this)
        imgSearch.setOnClickListener(this)
        imgSearch.setOnClickListener(this)
        llHideOpt.setOnClickListener(this)


    }

    fun disableToolbarScrolling() {
        val params: AppBarLayout.LayoutParams = toolbar.layoutParams as AppBarLayout.LayoutParams
        params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_NO_SCROLL
        appBarLayout.requestLayout()
    }

    fun enableToolbarScrolling() {
        val params: AppBarLayout.LayoutParams = toolbar.layoutParams as AppBarLayout.LayoutParams
        params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL or AppBarLayout.LayoutParams.SCROLL_FLAG_ENTER_ALWAYS
        appBarLayout.requestLayout()
    }

    fun visibleADs() {
        enableToolbarScrolling()
        if (AdsManager(this@MainActivity).isNeedToShowAds() && isOnline())
            adViewContainer.visibility = VISIBLE
        else
            adViewContainer.visibility = GONE
    }

    private fun setDrawerData() {
        ensureBackgroundThread {
            val dirs = directoryDao.getTotalDirectory()
            val photos = mediaDB.getTotalMedia(TYPE_IMAGES)
            val gif = mediaDB.getTotalMedia(TYPE_GIFS)
            val videos = mediaDB.getTotalMedia(TYPE_VIDEOS)
            var totalImage = photos + gif
            runOnUiThread {
                tvTotalAlbum.text = dirs.size.toString()
                tvTotalImage.text = totalImage.size.toString()
                tvTotalVideo.text = videos.size.toString()
            }
        }
    }

    private fun copyDatabase() {

        try {
            val f = File("/data/data/$packageName/databases/gallery.sql")
            if (f.exists()) {
                Log.e("TAG", "DataBase Already exists")

            } else {
                try {

                    Log.e("TAG", "DataBase is copying.....")
                    databaseInputStream1 = assets.open("gallery.sql")
                    try {
                        val databaseOutputStream: OutputStream = FileOutputStream(f.absolutePath)
                        val buffer = ByteArray(1024)
                        val databaseInputStream: InputStream = databaseInputStream1
                        while (databaseInputStream.read(buffer) > 0) {
                            databaseOutputStream.write(buffer)
                        }
                        databaseInputStream.close()
                        databaseOutputStream.flush()
                        databaseOutputStream.close()
                        Log.e("TAG", "DataBase is copied.....")
                    } catch (e: java.lang.Exception) {
                        e.printStackTrace()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupSearch() {

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(viewPagerHome.currentItem)
                if (photoDirectoryFragment is PhotoDirectoryFragment) {
                    photoDirectoryFragment.setupAdapter(photoDirectoryFragment.mDirs, s.toString())
                }
                if (photoDirectoryFragment is VideoDirectoryFragment) {
                    photoDirectoryFragment.setupAdapter(photoDirectoryFragment.mDirs, s.toString())
                }
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })
    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        isAppOpenAdShow = false
        if (requestCode == 101) {
            if (permissions.isEmpty()) {
                return
            }
            var allPermissionsGranted = true
            if (grantResults.isNotEmpty()) {
                for (grantResult in grantResults) {
                    if (grantResult != PackageManager.PERMISSION_GRANTED) {
                        allPermissionsGranted = false
                        break
                    }
                }
            }

            if (!allPermissionsGranted) {
                var somePermissionsForeverDenied = false
                for (permission in permissions) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                        //denied
                        Log.e("denied", permission)

                        ActivityCompat.requestPermissions(
                            this@MainActivity, arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE),
                            101
                        )
                    } else {
                        if (ActivityCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
                            //allowed
                            Log.e("allowed", permission)
                        } else {
                            //set to never ask again
                            Log.e("set to never ask again", permission)
                            somePermissionsForeverDenied = true
                        }
                    }
                }
                if (somePermissionsForeverDenied) {
                    showCameraPermissionAlert()
                } else {
                    startActivity(Intent(this, CameraActivity::class.java))
                }

            }


        }

    }

    private fun showCameraPermissionAlert() {
        isUnLockApp = true
        var msg = getString(R.string.msg_allow_permission_camera)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
            && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            msg = getString(R.string.msg_allow_permission_camera)
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
            && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            msg = getString(R.string.msg_allow_permission_camera_location)
        } else {
            msg = getString(R.string.msg_allow_permission_camera_only)
        }
        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
        alertDialogBuilder.setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>" + getString(R.string.error_permission_required) + "</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))
            .setMessage(msg)
            .setPositiveButton(getString(R.string.ok))
            { dialog, which ->
                dialog.dismiss()
                dirsDialog1 = null
                isFromSettingForCamera = true
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
            .setNegativeButton(getString(R.string.cancel)) { dialog, which ->
                dialog.dismiss()
                dirsDialog1 = null
            }
            .setCancelable(false)
        //alert dialog with theme

        if (dirsDialog1 == null) {
            dirsDialog1 = alertDialogBuilder.create()
            if (!dirsDialog1!!.isShowing()) {
                if (!this@MainActivity.isFinishing) {
                    dirsDialog1!!.show()
                    val bgDrawable = resources.getColoredDrawableWithColor(com.gallery.photo.image.video.R.drawable.dialog_bg, baseConfig.backgroundColor)
                    dirsDialog1!!.window?.setBackgroundDrawable(bgDrawable)
                    dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))
                    dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))
                    dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))
                }
            }
        }
    }

    var dirsDialog1: AlertDialog? = null

    override fun onClick(view: View) {
        super.onClick(view)
        try {
            when (view.id) {
                R.id.imgClose -> {
                    etSearch.visibility = GONE
                    imgClose.visibility = GONE
                    imgOptions.visibility = VISIBLE
                    imgSearch.visibility = VISIBLE
                    tvHeaderTitle.visibility = VISIBLE
                    etSearch.text = null
                    etSearch.clearFocus()
                    hideKeyboard(etSearch)
                    val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(viewPagerHome.currentItem)
                    if (photoDirectoryFragment is PhotoDirectoryFragment) {
                        photoDirectoryFragment.setupAdapter(photoDirectoryFragment.mDirs, "")
                    }
                    if (photoDirectoryFragment is VideoDirectoryFragment) {
                        photoDirectoryFragment.setupAdapter(photoDirectoryFragment.mDirs, "")
                    }
                }
                R.id.imgSearch -> {
                    val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(viewPagerHome.currentItem)
                    if (photoDirectoryFragment is VaultFragment) {
                        if (!isSettingClicked) {
                            isSettingClicked = true
                            if (VaultFragment.isFakeVaultOpen) {
                                startActivity(Intent(this, FakeVaultSettingsActivity::class.java))
                            } else {
                                startActivity(Intent(this, VaultSettingsActivity::class.java))
                            }
                        }
                    } else {
                        etSearch.visibility = VISIBLE
                        imgClose.visibility = VISIBLE
                        imgOptions.visibility = GONE
                        imgSearch.visibility = GONE
                        tvHeaderTitle.visibility = GONE
                        val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(viewPagerHome.currentItem)
                        if (photoDirectoryFragment is PhotoDirectoryFragment) {
                            if (photoDirectoryFragment.directories_refresh_layout != null)
                                photoDirectoryFragment.directories_refresh_layout.isRefreshing = false
                        }
                        if (photoDirectoryFragment is VideoDirectoryFragment) {
                            if (photoDirectoryFragment.directories_refresh_layout != null)
                                photoDirectoryFragment.directories_refresh_layout.isRefreshing = false
                        }
                        showKeyboard(etSearch)
                    }
                }

                R.id.llSortBy -> {
                    if (drawerLayout != null)
                        drawerLayout.closeDrawers()

                    ChangeSortingDialog(this, true, false) {
                        PhotoDirectoryFragment.isSortingChange = true
                        VideoDirectoryFragment.isSortingChange = true
                        VaultFragment.isSortingChange = true


                        val sortBtn = when {
                            this.config.directorySorting and SORT_BY_SIZE != 0 -> "Size"
                            this.config.directorySorting and SORT_BY_DATE_MODIFIED != 0 -> "Date"
                            this.config.directorySorting and SORT_BY_NAME != 0 -> "Name"
                            else -> "Date"
                        }
                        val sortOrder = when {
                            this.config.directorySorting and SORT_DESCENDING != 0 -> "Descending"
                            else -> "Ascending"
                        }
                        txtSort.text = Html.fromHtml("<font color='#000000'>Sort By </font><font color='#90939c'>($sortBtn, $sortOrder)</font>")

                        viewPagerFragmentAdapter.getFragment(viewPagerHome.currentItem).onResume()
                    }

                }
                R.id.llGridCount -> {
                    if (drawerLayout != null)
                        drawerLayout.closeDrawers()

                    ChangeGridSizeDialog(this, true, false) {
                        PhotoDirectoryFragment.isColumnCountChange = true
                        VideoDirectoryFragment.isColumnCountChange = true
                        VaultFragment.isColumnCountChange = true
                        txtGridCount.text = Html.fromHtml("<font color='#000000'>Grid Size </font><font color='#90939c'>(${this.config.dirColumnCnt} x N)</font>");

                        viewPagerFragmentAdapter.getFragment(viewPagerHome.currentItem).onResume()
                    }


                }

                R.id.llRecoverPhoto -> {

                    if (drawerLayout != null)
                        drawerLayout.closeDrawers()
//                    Intent(this, RecoverPhotoTabActivity::class.java).apply {
//                        startActivity(this)
//                    }
                    Intent(this, RecoverPhotoNewActivity::class.java).apply {
                        putExtra(DIRECTORY, "")
                        startActivity(this)
                    }
                }
                 R.id.llRecoverTrash -> {

                    if (drawerLayout != null)
                        drawerLayout.closeDrawers()
                    if (config.isAnyOperationRunning) {
                        toast(getString(R.string.msg_operation_already_running))
                        return
                    }
                    Intent(this, RecoverPhotoTabActivity::class.java).apply {
                        startActivity(this)
                    }

                }
                R.id.llTimeLine -> {
                    if (drawerLayout != null)
                        drawerLayout.closeDrawers()
                    startActivity(Intent(this, TimeLineActivity::class.java))
                }
                R.id.llDuplicateFinder -> {
                    if (drawerLayout != null)
                        drawerLayout.closeDrawers()
                    startActivity(Intent(this, DuplicateFinderActivity::class.java))
                }
                R.id.llPlaceItem -> {
                    if (drawerLayout != null)
                        drawerLayout.closeDrawers()
                    startActivity(Intent(this, PlaceActivity::class.java))
                }
                R.id.llFavourite -> {
                    if (drawerLayout != null)
                        drawerLayout.closeDrawers()
                    startActivity(Intent(this, FavouriteActivity::class.java))
                }
                R.id.llShareApp -> {
                    isUnLockApp = true
                    isInternalCall = true
                    SettingsFragment.isShareClicked = true
                    if (drawerLayout != null)
                        drawerLayout.closeDrawers()


                    val i = Intent(Intent.ACTION_SEND)
                    i.type = "text/plain"
                    i.putExtra(Intent.EXTRA_SUBJECT, resources.getString(R.string.app_name))
                    var appname = getString(R.string.app_name)
                    val sAux = getString(R.string.msg_share_app, appname, packageName)
                    i.putExtra(Intent.EXTRA_TEXT, sAux)
                    startActivity(Intent.createChooser(i, "Choose one"))
                }
                R.id.llRemoveAds -> {
                    isUnLockApp = true
                    isInternalCall = true
                    SettingsFragment.isShareClicked = true
                    if (drawerLayout != null)
                        drawerLayout.closeDrawers()

                    var intent = Intent(this, SubscriptionActivity::class.java)
                    startActivity(intent)
                }
                R.id.imgOptions -> {
                    if (config.viewTypeFolders == VIEW_TYPE_GRID) {
                        config.viewTypeFolders = VIEW_TYPE_LIST
                        imgOptions.setImageDrawable(getDrawable(R.drawable.ic_gallery_grid))
                    } else {
                        config.viewTypeFolders = VIEW_TYPE_GRID
                        imgOptions.setImageDrawable(getDrawable(R.drawable.ic_gallery_list))
                    }
                    val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(0)
                    if (photoDirectoryFragment is PhotoDirectoryFragment) {
                        photoDirectoryFragment.setupLayoutManager()
                        if (photoDirectoryFragment.directories_refresh_layout != null)
                            photoDirectoryFragment.directories_refresh_layout.isRefreshing = false
                        photoDirectoryFragment.directories_grid.adapter = null
                        photoDirectoryFragment.setupAdapter(photoDirectoryFragment.getRecyclerAdapter()?.dirs ?: photoDirectoryFragment.mDirs)
                    }
                    val videoDirectoryFragment = viewPagerFragmentAdapter.createFragment(1)
                    if (videoDirectoryFragment is VideoDirectoryFragment) {
                        if (videoDirectoryFragment.isAdded) {
                            videoDirectoryFragment.setupLayoutManager()
                            if (videoDirectoryFragment.directories_refresh_layout != null)
                                videoDirectoryFragment.directories_refresh_layout.isRefreshing = false
                            videoDirectoryFragment.directories_grid.adapter = null

                            videoDirectoryFragment.setupAdapter(videoDirectoryFragment.getRecyclerAdapter()?.dirs ?: videoDirectoryFragment.mDirs)
                        }
                    }

                }
                R.id.imgSideMenu -> {

                    val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(viewPagerHome.currentItem)
                    if (photoDirectoryFragment is PhotoDirectoryFragment) {
                        try {
                            if (photoDirectoryFragment.directories_refresh_layout != null)
                                photoDirectoryFragment.directories_refresh_layout.isRefreshing = false

                        } catch (e: java.lang.Exception) {
                        }
                    }
                    if (photoDirectoryFragment is VideoDirectoryFragment) {
                        try {
                            if (photoDirectoryFragment.directories_refresh_layout != null)
                                photoDirectoryFragment.directories_refresh_layout.isRefreshing = false
                        } catch (e: java.lang.Exception) {
                        }
                    }
                    if (!drawerLayout.isDrawerOpen(GravityCompat.START)) {
                        drawerLayout.openDrawer(GravityCompat.START)
                    } else {
                        drawerLayout.closeDrawers()
                    }
                }
                R.id.llCamera -> {
                    drawerLayout.closeDrawers()
                    isVaultCameraClicked = false
                    isUnLockApp = true
                    RxPermissions(this).request(
                        Manifest.permission.CAMERA,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ).subscribe {
                        isUnLockApp = true
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                            && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        ) {
                            val intent = Intent(mContext, com.gallery.photo.image.video.Camera.CameraActivity::class.java)
                            startActivity(intent)
                        } else {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(
                                    this,
                                    Manifest.permission.CAMERA
                                ) && ActivityCompat.shouldShowRequestPermissionRationale(
                                    this,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                ) && ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)
                            ) {
                                isUnLockApp = true
                                llCamera.performClick()
                            } else {
                                showCameraPermissionAlert()
                            }
                        }
                    }
                }
                R.id.imgAddHiddenPhoto -> {
                    if (config.isAnyOperationRunning) {
                        toast(getString(R.string.msg_operation_already_running))
                        return
                    }
                    if (!isFABOpen) {
                        showFABMenu()
                    } else {
                        closeFABMenu()
                    }
                }
                R.id.llHideOpt -> {
                    val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(viewPagerHome.currentItem)
                    if (photoDirectoryFragment is PhotoDirectoryFragment) {
                        try {
                            if (photoDirectoryFragment.directories_grid.adapter != null)
                                (photoDirectoryFragment.directories_grid.adapter as DirectoryAdapter).toggleFoldersVisibility(true)

                        } catch (e: java.lang.Exception) {
                        }
                    }
                    if (photoDirectoryFragment is VideoDirectoryFragment) {
                        try {
                            if (photoDirectoryFragment.directories_grid.adapter != null)
                                (photoDirectoryFragment.directories_grid.adapter as DirectoryAdapter).toggleFoldersVisibility(true)
                        } catch (e: java.lang.Exception) {
                        }
                    }
                    if (photoDirectoryFragment is VaultFragment) {
                        try {
                            if (VaultFragment.isFakeVaultOpen) {
                                if (photoDirectoryFragment.fakeVaultDir_grid.adapter != null)
                                    (photoDirectoryFragment.fakeVaultDir_grid.adapter as DirectoryAdapter).toggleFoldersVisibility(false)

                            } else {

                                if (VaultFragment.isHiddenByGallerySelected) {
                                    if (photoDirectoryFragment.directories_grid.adapter != null)
                                        (photoDirectoryFragment.directories_grid.adapter as DirectoryAdapter).toggleFoldersVisibility(false)
                                } else {
                                    if (photoDirectoryFragment.Alldirectories_grid.adapter != null)
                                        (photoDirectoryFragment.Alldirectories_grid.adapter as DirectoryAdapter).toggleFoldersVisibility(false)
                                }
                            }
                        } catch (e: java.lang.Exception) {
                        }
                    }
                }
                R.id.fabAddHiddenPhotoFromCamera -> {
                    closeFABMenu()
                    isVaultCameraClicked = true
                    isUnLockApp = true
                    VaultFragment.isTabUnlock = true
                    handlePermission(PERMISSION_CAMERA) {
                        isUnLockApp = true

                        VaultFragment.isTabUnlock = true
                        if (it) {
                            var totalImagesCount = config.hidePhotoCountForSubscription
                            var totalVideosCount = config.hideVideoCountForSubscription
                            totalImagesCount++
                            if (AdsManager(this).isNeedToShowAds() && (totalImagesCount > HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION_VAL)
                            ) {
                                Log.d("TAGHiddenCount", "Need Subscription")
                                runOnUiThread {
                                    dismissProgress()
                                    SubscriptionDialog(this, totalImagesCount, totalVideosCount)
                                    {
                                        if (it) {
                                            var intent = Intent(this, SubscriptionActivity::class.java)
                                            launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
                                        } else {
                                            var root = File(CAMERA_DIR_PATH)
                                            if (!root.exists())
                                                root.mkdir()
                                            mCurrentPhotoPath = CAMERA_DIR_PATH + "/." + System.currentTimeMillis() + ".jpeg"
                                            var file = File(mCurrentPhotoPath)
                                            mCurrentPhotoUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                                            isUnLockApp = true

                                            VaultFragment.isTabUnlock = true
                                            val captureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                                            captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mCurrentPhotoUri)
                                            launchActivityForResult(captureIntent, REQUEST_CODE_CAMERA)
                                        }
                                    }
                                }
                            } else {

                                var root = File(CAMERA_DIR_PATH)
                                if (!root.exists())
                                    root.mkdir()
                                mCurrentPhotoPath = CAMERA_DIR_PATH + "/." + System.currentTimeMillis() + ".jpeg"
                                var file = File(mCurrentPhotoPath)
                                mCurrentPhotoUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                                isUnLockApp = true

                                VaultFragment.isTabUnlock = true
                                val captureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                                captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mCurrentPhotoUri)
                                launchActivityForResult(captureIntent, REQUEST_CODE_CAMERA)
                            }
                        } else {
                            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
                                isUnLockApp = true

                                VaultFragment.isTabUnlock = true
                                fabAddHiddenPhotoFromCamera.performClick()
                            } else {
                                showCameraPermissionAlert()
                            }
                        }
                    }
                }
                R.id.flBackground -> {
                    closeFABMenu()
                }
                R.id.fabAddHiddenPhotoFromGallery -> {
                    closeFABMenu()
                    val mSelectionSpec = SelectionSpec.getCleanInstance()
                    mSelectionSpec.mimeTypeSet = MimeType.ofImage()
                    mSelectionSpec.mediaTypeExclusive = true
                    mSelectionSpec.maxSelectable = 5
                    mSelectionSpec.noLimit = true
                    mSelectionSpec.showPreview = false
                    mSelectionSpec.showSingleMediaType = true
                    mSelectionSpec.orientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    launchActivityForResult(VaultGalleryActivity.newIntent(this, CHOOSE_IMAGE_TYPE), REQUEST_SELECT_MEDIA)
                }
                R.id.fabAddHiddenAudio -> {
                    closeFABMenu()
                    GalleryEngine.Builder()
                        .choose(CHOOSE_AUDIO_TYPE)
                        .multiple(true)
                        .maxSelect(5)
                        .forResult(this)
                }
                R.id.fabAddHiddenDocument -> {
                    closeFABMenu()
                    GalleryEngine.Builder()
                        .choose(CHOOSE_DOCUMENT_TYPE)
                        .multiple(true)
                        .maxSelect(5)
                        .forResult(this)
                }
                R.id.fabAddHiddenVideo -> {
                    closeFABMenu()

                    val mSelectionSpec = SelectionSpec.getCleanInstance()
                    mSelectionSpec.mimeTypeSet = MimeType.ofVideo()
                    mSelectionSpec.mediaTypeExclusive = true
                    mSelectionSpec.maxSelectable = 5
                    mSelectionSpec.noLimit = true
                    mSelectionSpec.showPreview = false
                    mSelectionSpec.showSingleMediaType = true
                    mSelectionSpec.orientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    launchActivityForResult(VaultGalleryActivity.newIntent(this, CHOOSE_VIDEO_TYPE), REQUEST_SELECT_MEDIA)
                }
                R.id.fabAddHiddenPhotoFromFolder -> {
                    isUnLockApp = true

                    VaultFragment.isTabUnlock = true
                    closeFABMenu()
                    startActivity(CustomFilePickerActivity.newIntent(this, CHOOSE_ALL_TYPE))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    var mCurrentPhotoUri: Uri? = null
    var mCurrentPhotoPath: String = ""
    override fun onBackPressed() {
        when {
            drawerLayout.isDrawerOpen(GravityCompat.START) -> {
                drawerLayout.closeDrawers()
            }
            isFABOpen -> {
                closeFABMenu()
            }
            viewPagerHome.currentItem != 0 -> {
                viewPagerHome.currentItem = 0
            }
            else -> {
                displayExitDialog()
            }
        }
    }


    override fun initAds() {
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            InterstitialAdHelper.loadInterstitialAd(fContext = mContext, onAdLoaded = {
                Log.e(TAG, "initAds: Ad Loaded" )
            })

//            InterstitialAdHelper.loadInterstitialAd(fContext = this)
//            {
//                if (isFirstTime) {
//                    var msg = getString(R.string.please_wait)
//                    if (AdsManager(this).isNeedToShowAds() && isOnline()) {
//                        msg = getString(R.string.msg_ads_loading)
//                    }
//
//                    if ((Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager())
//                        || (Build.VERSION.SDK_INT < Build.VERSION_CODES.R && hasPermission(PERMISSION_WRITE_STORAGE))
//                    ) {
//
//                        isAdLoaded = true
//                        isAdShown = true
//                        Log.d("ADLoad", "onAdLoaded:isPaused " + isPaused)
//                        if (!isPaused) {
//                            showProgress(msg)
//                        }
//                        Handler(Looper.getMainLooper()).postDelayed({
//
//                            dismissProgress()
//                            isShowInterstitialAd {
//                                // Perform your Action
//                                isAdShown = false
//                                isFirstTime = false
//                                isHideClicked = false
//                            }
//                        }, 2000)
//                    }
//                }
//            }
        }
    }

    private fun removeAds() {
        //  moreAppView.visibility = View.GONE

        adViewContainer.visibility = View.GONE
//        clGiftIcon.visibility = View.INVISIBLE

    }


    override fun onPurchasedSuccess(purchase: Purchase) {
        if (!isAlertDisplay) {
            isAlertDisplay = true
            isRemoveAdClicked = false
            Log.i(TAG, "purchase")
            showPurchaseSuccess()
            removeAds()

        }
    }

    override fun onProductAlreadyOwn() {
        isRemoveAdClicked = false
        Log.i(TAG, "onProductAlreadyOwn")
        showPurchaseSuccess()
        removeAds()
    }


    override fun onBillingSetupFinished(billingResult: BillingResult) {
        Log.e(TAG, "onBillingSetupFinished:InAppActivity:" + billingResult.responseCode)
        Log.e(TAG, "onBillingSetupFinished:InAppActivity:" + billingResult.debugMessage)
        if (!isBillingInit) {
            isBillingInit = true
            GlobalScope.launch(Dispatchers.Main)
            {
                InAppPurchaseHelper.instance!!.initProducts()
                InAppPurchaseHelper.instance!!.initSubscription()

            }
        }
    }

    override fun onBillingUnavailable() {

    }

    override fun onBillingKeyNotFound(productId: String) {
        val message = getString(R.string.msg_sku_detail_not_found) + productId
        toast(message)
    }

    private fun checkStoragePermission() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!checkPermissionabove11()) {

                showGetPermissionDialog11()
            } else {
                setData()
            }

        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

                isUnLockApp = true
            }
            handlePermission(PERMISSION_WRITE_STORAGE) {
                if (it) {
                    setData()
                } else {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        checkStoragePermission()
                    } else {

                        isUnLockApp = true
                        showPermissionAlertBelow11()
                    }
                }
            }
        }
    }

    private fun showPermissionAlertBelow11() {
        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
        alertDialogBuilder.setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>" + getString(R.string.error_permission_required) + "</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))
            .setMessage(getString(R.string.msg_allow_permission_storage))
            .setPositiveButton(getString(R.string.ok))
            { dialog, which ->
                dialog.dismiss()
                dirsDialog1 = null
                isFromSetting = true
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)

            }
            .setNegativeButton(getString(R.string.cancel)) { dialog, which ->
                dialog.dismiss()
                finish()
            }
            .setCancelable(false)
        //alert dialog with theme

        if (dirsDialog1 == null) {
            dirsDialog1 = alertDialogBuilder.create()
            if (!dirsDialog1!!.isShowing()) {
                if (!this@MainActivity.isFinishing) {
                    dirsDialog1!!.show()
                }
                val bgDrawable = resources.getColoredDrawableWithColor(com.gallery.photo.image.video.R.drawable.dialog_bg, baseConfig.backgroundColor)
                dirsDialog1!!.window?.setBackgroundDrawable(bgDrawable)
                dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))
                dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))
                dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))
            }
        }
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            1011 -> {
                checkStoragePermission()
            }
            REQ_CODE_FOR_MANAGE_STORAGE -> {
                if (requestCode == REQ_CODE_FOR_MANAGE_STORAGE && checkPermissionabove11()) {
                    setData()
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        showGetPermissionDialog11()
                    }
                }
            }
            REQUEST_CODE_CAMERA -> {
                isUnLockApp = true

                VaultFragment.isTabUnlock = true
                Log.d(TAG, "onActivityResult: $mCurrentPhotoUri")

                if (resultCode == Activity.RESULT_OK) {
                    isHideClicked = true
                    ensureBackgroundThread {
                        config.hidePhotoCountForSubscription++
                        if (directoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH) != null) {
                            if (VaultFragment.isFakeVaultOpen) {
                                fakeVaultHiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH).getConvertedFakeVaultDirectory())
                            } else {
                                hiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH).getConvertedHiddenDirectory())
                            }
                        } else if (photoDirectoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH) != null) {
                            if (VaultFragment.isFakeVaultOpen) {
                                fakeVaultHiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH).getConvertedFakeVaultDirectory())
                            } else {
                                hiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(CAMERA_DIR_PATH).getConvertedHiddenDirectory())
                            }
                        } else {
                            updatePhotoVideoDirectoryPath(CAMERA_DIR_PATH, true, false, true)
                        }
                        if (VaultFragment.isFakeVaultOpen) {
                            val type = when {
                                mCurrentPhotoPath.isVideoFast() -> TYPE_VIDEOS
                                mCurrentPhotoPath.isGif() -> TYPE_GIFS
                                mCurrentPhotoPath.isSvg() -> TYPE_SVGS
                                mCurrentPhotoPath.isRawFast() -> TYPE_RAWS
                                mCurrentPhotoPath.isPortrait() -> TYPE_PORTRAITS
                                else -> TYPE_IMAGES
                            }
                            val duration = if (type == TYPE_VIDEOS) getDuration(mCurrentPhotoPath) ?: 0 else 0
                            val ts = System.currentTimeMillis()
                            val medium = FakeVaultMedium(
                                null,
                                mCurrentPhotoPath.getFilenameFromPath(),
                                mCurrentPhotoPath,
                                mCurrentPhotoPath.getParentPath(),
                                ts,
                                ts,
                                File(mCurrentPhotoPath).length(),
                                type,
                                duration,
                                false,
                                0
                            )
                            fakeVaultMediumDao.insert(medium)
                        } else {
                            val type = when {
                                mCurrentPhotoPath.isVideoFast() -> TYPE_VIDEOS
                                mCurrentPhotoPath.isGif() -> TYPE_GIFS
                                mCurrentPhotoPath.isSvg() -> TYPE_SVGS
                                mCurrentPhotoPath.isRawFast() -> TYPE_RAWS
                                mCurrentPhotoPath.isPortrait() -> TYPE_PORTRAITS
                                else -> TYPE_IMAGES
                            }
                            val duration = if (type == TYPE_VIDEOS) getDuration(mCurrentPhotoPath) ?: 0 else 0
                            val ts = System.currentTimeMillis()
                            val medium = Medium(
                                null,
                                mCurrentPhotoPath.getFilenameFromPath(),
                                mCurrentPhotoPath,
                                mCurrentPhotoPath.getParentPath(),
                                ts,
                                ts,
                                File(mCurrentPhotoPath).length(),
                                type,
                                duration,
                                false,
                                0
                            )
                            mediaDB.insert(medium)
                        }
                    }
                }
            }

            REQUEST_SELECT_MEDIA -> {
                isUnLockApp = true

                VaultFragment.isTabUnlock = true
                if (resultCode == Activity.RESULT_OK && data != null) {
                    isHideClicked = true
                    var selectedList: List<String> = data?.getStringArrayListExtra(KEY_MEDIA_LIST)!!
                    var filterType: Int = data?.getIntExtra(KEY_MEDIA_TYPE, CHOOSE_IMAGE_TYPE)!!
                    Log.d(TAG, "fromActivityResult:  Filter Type-->$filterType")
                    showProgress(getString(R.string.please_wait))
                    ensureBackgroundThread {
                        if (filterType == CHOOSE_IMAGE_TYPE) {
                            var totalImagesCount = config.hidePhotoCountForSubscription
                            var totalVideosCount = config.hideVideoCountForSubscription
                            totalImagesCount += selectedList.size
                            if (AdsManager(this).isNeedToShowAds() && totalImagesCount > HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION_VAL) {
                                runOnUiThread {
                                    dismissProgress()
                                    SubscriptionDialog(this, totalImagesCount, totalVideosCount)
                                    {
                                        if (it) {
                                            val intent = Intent(this, SubscriptionActivity::class.java)
                                            launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
                                        } else {
                                            mContext.config.hidePhotoCountForSubscription = totalImagesCount
                                            ensureBackgroundThread {
                                                uDataDao.updateCount(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, config.hidePhotoCountForSubscription)
                                            }
                                            hideFiles(selectedList, filterType,false)
                                        }
                                    }
                                }
                            } else {
                                mContext.config.hidePhotoCountForSubscription = totalImagesCount
                                ensureBackgroundThread {
                                    uDataDao.updateCount(HIDE_PHOTO_COUNT_FOR_SUBSCRIPTION, config.hidePhotoCountForSubscription)
                                }
                                hideFiles(selectedList, filterType,true)
                            }

                        } else if (filterType == CHOOSE_VIDEO_TYPE) {
                            var totalImagesCount = config.hidePhotoCountForSubscription
                            var totalVideosCount = config.hideVideoCountForSubscription
                            totalVideosCount += selectedList.size
                            if (AdsManager(this).isNeedToShowAds() && totalVideosCount > HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION_VAL) {
                                runOnUiThread {
                                    dismissProgress()
                                    SubscriptionDialog(this, totalImagesCount, totalVideosCount)
                                    {
                                        if (it) {
                                            var intent = Intent(this, SubscriptionActivity::class.java)
                                            launchActivityForResult(intent, REQUEST_CODE_FOR_SUBSCRIPTION)
                                        } else {
                                            mContext.config.hideVideoCountForSubscription = totalVideosCount
                                            ensureBackgroundThread {
                                                uDataDao.updateCount(HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION, config.hideVideoCountForSubscription)
                                            }
                                            hideFiles(selectedList, filterType,false)
                                        }
                                    }
                                }
                            } else {
                                mContext.config.hideVideoCountForSubscription = totalVideosCount
                                ensureBackgroundThread {
                                    uDataDao.updateCount(HIDE_VIDEO_COUNT_FOR_SUBSCRIPTION, config.hideVideoCountForSubscription)
                                }
                                hideFiles(selectedList, filterType,true)
                            }

                        } else if (filterType == CHOOSE_DOCUMENT_TYPE) {
                            var totalDocumentCount = config.hideDocumentCountForSubscription
                            totalDocumentCount += selectedList.size
                            mContext.config.hideDocumentCountForSubscription = totalDocumentCount
                            hideFiles(selectedList, filterType,true)

                        } else if (filterType == CHOOSE_AUDIO_TYPE) {
                            var totalAudioCount = config.hideAudioCountForSubscription
                            totalAudioCount += selectedList.size
                            mContext.config.hideAudioCountForSubscription = totalAudioCount
                            hideFiles(selectedList, filterType,true)
                        }
                    }
                }
            }
        }
    }

    private fun hideFiles(selectedList: List<String>, filterType: Int,isNeedToShowAd:Boolean) {
        var prevPath = ""
        var hiddenDirectory = ArrayList<String>()
        selectedList.forEach {
            if (prevPath != it.getParentPath()) {
                hiddenDirectory.add(it.getParentPath())
                prevPath = it.getParentPath()
            }
            val type = when {
                it.isVideoFast() -> TYPE_VIDEOS
                it.isGif() -> TYPE_GIFS
                it.isSvg() -> TYPE_SVGS
                it.isRawFast() -> TYPE_RAWS
                it.isPortrait() -> TYPE_PORTRAITS
                it.isAudioFast() -> TYPE_AUDIO
                it.isDocumentFast() -> TYPE_DOCUMENT
                else -> TYPE_IMAGES
            }
            toggleFileVisibility(it, true) {
                val ts1 = System.currentTimeMillis()

                if (filterType == CHOOSE_AUDIO_TYPE || filterType == CHOOSE_DOCUMENT_TYPE) {
                    val file = HideFilesDetail(
                        null,
                        it.getFilenameFromPath(),
                        it,
                        it.getParentPath(),
                        ts1,
                        ts1,
                        File(it).length(),
                        type,
                        false,
                        0
                    )
                    ensureBackgroundThread {
                        if (VaultFragment.isFakeVaultOpen) {
                            try {
                                fakeHideFileDao.insert(file.getConvertedFakeFileDetail())
                            } catch (e: Exception) {
                            }
                        } else {
                            try {
                                hideFileDao.insert(file)
                            } catch (e: Exception) {
                            }
                        }
                    }
                }
                if (filterType == CHOOSE_IMAGE_TYPE || filterType == CHOOSE_VIDEO_TYPE) {
                    if (VaultFragment.isFakeVaultOpen) {
                        val duration = if (type == TYPE_VIDEOS) getDuration(it) ?: 0 else 0
                        val ts = System.currentTimeMillis()
                        val medium = FakeVaultMedium(
                            null,
                            it.getFilenameFromPath(),
                            it,
                            it.getParentPath(),
                            ts,
                            ts,
                            File(it).length(),
                            type,
                            duration,
                            false,
                            0
                        )
                        ensureBackgroundThread {
                            fakeVaultMediumDao.insert(medium)
                        }
                    }
                }
            }
        }
        if (filterType == CHOOSE_IMAGE_TYPE || filterType == CHOOSE_VIDEO_TYPE) {
            try {
                hiddenDirectory.forEach {
                    if (directoryDao.getDirectoryDetailFromDirPath(it) != null) {
                        if (VaultFragment.isFakeVaultOpen) {
                            fakeVaultHiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(it).getConvertedFakeVaultDirectory())
                        } else {
                            hiddenDirectoryDao.insert(directoryDao.getDirectoryDetailFromDirPath(it).getConvertedHiddenDirectory())
                        }
                    } else if (photoDirectoryDao.getDirectoryDetailFromDirPath(it) != null) {
                        if (VaultFragment.isFakeVaultOpen) {
                            fakeVaultHiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(it).getConvertedFakeVaultDirectory())
                        } else {
                            hiddenDirectoryDao.insert(photoDirectoryDao.getDirectoryDetailFromDirPath(it).getConvertedHiddenDirectory())
                        }
                    } else {
                        updatePhotoVideoDirectoryPath(it, true, false, true)
                    }
                    updatePhotoVideoDirectoryPath(it, true, false, false)
                    updatePhotoVideoDirectoryPath(it, false, true, false)

                }
            } catch (e: Exception) {
            }
        }
        runOnUiThread {
            dismissProgress()
            PhotoDirectoryFragment.isNeedToRefresh = true
            VideoDirectoryFragment.isNeedToRefresh = true
            VaultFragment.isNeedToRefresh = true
            isNeedToRefresh = true
            when (filterType) {
                CHOOSE_IMAGE_TYPE -> toast(getString(R.string.msg_image_hide))
                CHOOSE_VIDEO_TYPE -> toast(getString(R.string.msg_video_hide))
                CHOOSE_AUDIO_TYPE -> toast(getString(R.string.msg_audio_hide))
                CHOOSE_DOCUMENT_TYPE -> toast(getString(R.string.msg_document_hide))
                else -> toast(getString(R.string.msg_hide_media_successfully))
            }
//            if (AdsManager(this).isNeedToShowAds() && isOnline() && isNeedToShowAd) {
//                isShowInterstitialAd {
//
//                }
//            } else {
//                isInterstitialShown = false
//            }
        }

    }


    fun toggleToolbar(isShowActionBar: Boolean) {
        isInActionMode = isShowActionBar
        if (isShowActionBar) {
            if (etSearch.visibility == VISIBLE) {
                hideKeyboard(findViewById<EditText>(R.id.etSearch))
                findViewById<EditText>(R.id.etSearch).clearFocus()
            }

            llBottomOption.visibility = VISIBLE
            llBottom.visibility = GONE
            if (viewPagerHome.currentItem == 2) {
                tvHideUnHideText.text = resources.getString(R.string.label_unhide_folder, 0)
                imgOptHideUnHide.setImageDrawable(resources.getDrawable(R.drawable.ic_option_unhide))
            } else {
                tvHideUnHideText.text = resources.getString(R.string.label_hide_folder, 0)
                imgOptHideUnHide.setImageDrawable(resources.getDrawable(R.drawable.ic_option_hide))
            }
            viewPagerHome.isUserInputEnabled = false
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
        } else {
            llBottomOption.visibility = GONE
            llBottom.visibility = VISIBLE
            viewPagerHome.isUserInputEnabled = true
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
        }

    }

    override fun onDestroy() {
        Log.d("TAG_COPY", "on Destroy: base simple activity")
        notificationManager.cancelAll()
        config.isAnyOperationRunning = false
        config.lastDestinationPath = ""
        super.onDestroy()
        isGridSizeChange = false
    }

    override fun onPause() {
        super.onPause()
        isPaused = true
        isSettingClicked = false
        if (!SettingsFragment.isShareClicked)
            isUnLockApp = false
        else {
            SettingsFragment.isShareClicked = false
        }
        if (isInternalCall) {
            isInternalCall = false
            isUnLockApp = true
        }

        closeFABMenu()
        dismissProgress()
        if (viewPagerHome.currentItem == 0 || viewPagerHome.currentItem == 1)
            if (etSearch.visibility == VISIBLE)
                imgClose.performClick()
        if (viewPagerHome.currentItem == 2) {
//            if (menuTarget != null) {
                imgOptionMenu.visibility = GONE
//                config.isDirectoryMenuInfoShown = true
//                menuTarget!!.dismiss(true)
//            }
        }
    }

    fun showToolbar() {
        appBarLayout.setExpanded(true, true)

    }

    fun hideimgOption() {
        imgOptions.visibility = GONE
    }

    fun hideAddItemImage() {
        imgAddHiddenPhoto.visibility = GONE
    }

    fun showAddItemImage() {
        imgAddHiddenPhoto.visibility = VISIBLE
    }

    fun updateCount(size: Int) {
        if (viewPagerHome.currentItem == 2) {
            tvHideUnHideText.text = resources.getString(R.string.label_unhide_folder, size)
        } else {
            tvHideUnHideText.text = resources.getString(R.string.label_hide_folder, size)
        }
    }

    fun performFolderClick(dirPath: String) {

        var fragment = viewPagerFragmentAdapter.createFragment(prevPos)
        when (fragment) {
            is PhotoDirectoryFragment -> {
                try {

                    fragment.getRecyclerAdapter()?.finishActMode()
                    fragment.itemClicked(dirPath)

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            is VideoDirectoryFragment -> {
                try {
                    fragment.getRecyclerAdapter()?.finishActMode()
                    fragment.itemClicked(dirPath)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

        }
    }


    private fun showFABMenu() {
        isFABOpen = true

        imgAddHiddenPhoto.setImageDrawable(resources.getDrawable(R.drawable.ic_vault_close))
        flBackground.beVisible()
        llFromGallery.beVisible()
        llAddVideo.beVisible()
        llAddAudio.beVisible()
        llAddDocument.beVisible()
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
    }

    private fun closeFABMenu() {
        isFABOpen = false
        imgAddHiddenPhoto.setImageDrawable(resources.getDrawable(R.drawable.ic_add_hidden_new))
        flBackground.beGone()
        llFromGallery.beGone()
        llAddVideo.beGone()
        llAddAudio.beGone()
        llAddDocument.beGone()
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
    }
}
