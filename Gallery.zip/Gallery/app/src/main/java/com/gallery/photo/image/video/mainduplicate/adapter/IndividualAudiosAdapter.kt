package com.gallery.photo.image.video.mainduplicate.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.mainduplicate.callbacks.MarkedListener
import com.gallery.photo.image.video.mainduplicate.model.IndividualGroupModel
import com.gallery.photo.image.video.mainduplicate.model.ItemDuplicateModel
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions
import java.util.*

class IndividualAudiosAdapter(
    var individualAudioAdapterContext: Context,
    var individualAudioAdapterActivity: Activity,
    var audiosMarkedListener: MarkedListener,
    var groupOfDupesAudios: List<IndividualGroupModel>) : RecyclerView.Adapter<IndividualAudiosAdapter.MediaViewHolder>() {

    var mLayoutManager: LinearLayoutManager? = null

    class MediaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var checkBox: CheckBox = itemView.findViewById(R.id.cb_grp_checkbox)
        var recyclerView: RecyclerView = itemView.findViewById(R.id.rv_audios)
        var textView: TextView = itemView.findViewById(R.id.tv_grp_name)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MediaViewHolder {
        return MediaViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.adapter_media_audio, parent, false))
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: MediaViewHolder, position: Int) {
        val individualGroup = groupOfDupesAudios[position]
        holder.textView.text = "Set " + individualGroup.groupTag
        holder.checkBox.isChecked = individualGroup.isCheckBox
        mLayoutManager = LinearLayoutManager(individualAudioAdapterContext)
        holder.recyclerView.layoutManager = mLayoutManager

        val listAudioAdapter = ListAudioAdapter(individualAudioAdapterContext, individualAudioAdapterActivity, audiosMarkedListener, groupOfDupesAudios[position],
            individualGroup.individualGrpOfDupes!!, holder.checkBox)
        holder.recyclerView.adapter = listAudioAdapter
        holder.checkBox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            buttonView.setOnClickListener {
                individualGroup.isCheckBox = isChecked
                val listAudioAdapter1 = ListAudioAdapter(individualAudioAdapterContext, individualAudioAdapterActivity, audiosMarkedListener, groupOfDupesAudios[position], setCheckBox(individualGroup.individualGrpOfDupes, isChecked), holder.checkBox)
                holder.recyclerView.adapter = listAudioAdapter1
                listAudioAdapter1.notifyDataSetChanged()
            }
        }
    }

    override fun getItemCount(): Int {
        return groupOfDupesAudios.size
    }

    private fun setCheckBox(audioItems: List<ItemDuplicateModel>?, value: Boolean): List<ItemDuplicateModel> {
        val lListOfDupes: MutableList<ItemDuplicateModel> = ArrayList()
        for (i in audioItems!!.indices) {
            val audioItem = audioItems[i]
            when {
                i != 0 -> {
                    if (!value) {
                        GlobalVarsAndFunctions.file_to_be_deleted_audios.remove(audioItem)
                        GlobalVarsAndFunctions.subSizeAudios(audioItem.sizeOfTheFile)
                        audiosMarkedListener.updateMarked()
                    } else if (!audioItem.isFileCheckBox) {
                        GlobalVarsAndFunctions.file_to_be_deleted_audios.add(audioItem)
                        GlobalVarsAndFunctions.addSizeAudios(audioItem.sizeOfTheFile)
                        audiosMarkedListener.updateMarked()
                    }
                    audioItem.isFileCheckBox = value
                    lListOfDupes.add(audioItem)
                }
                audioItem.isFileCheckBox -> {
                    GlobalVarsAndFunctions.file_to_be_deleted_audios.remove(audioItem)
                    audioItem.isFileCheckBox = false
                    lListOfDupes.add(audioItem)
                }
                else -> {
                    audioItem.isFileCheckBox = false
                    lListOfDupes.add(audioItem)
                }
            }
        }
        return lListOfDupes
    }
}