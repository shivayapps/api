package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.fragment.app.DialogFragment
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogRadioGroupBinding
import com.gallery.photo.image.video.helper.RadioItem
import com.gallery.photo.image.video.utils.Preferences

class RadioGroupDialog(
    val items: ArrayList<RadioItem>,
    val checkedItemId: Int = -1,
    val updateListener: (pos: Int) -> Unit) :
    DialogFragment() {

    lateinit var bindingDialog: DialogRadioGroupBinding
    lateinit var preferences: Preferences
    private var wasInit = false
    private var selectedItemId = -1


    override fun onResume() {
        super.onResume()
        dialog!!.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)
        val window = dialog.window
        val attributes = window?.attributes
//        attributes?.gravity = Gravity.BOTTOM
        window?.attributes = attributes
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        return dialog
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogRadioGroupBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        preferences = Preferences(requireActivity())

        bindingDialog.grpOption.apply {
            for (i in 0 until items.size) {
                val radioButton = (layoutInflater.inflate(R.layout.radio_button, null) as RadioButton).apply {
                    text = items[i].title
                    isChecked = items[i].id == checkedItemId
                    id = i
                    setOnClickListener { itemSelected(i) }
                }

                if (items[i].id == checkedItemId) {
                    selectedItemId = i
                }

                addView(radioButton, RadioGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
        }

        wasInit = true
//        val groupBtn = when (groupBy) {
//            Constant.GROUP_BY_NONE -> bindingDialog.groupingDialogRadioNone
//            else -> bindingDialog.groupingDialogRadioNone
//        }
//        groupBtn.isChecked = true


    }

    private fun itemSelected(checkedId: Int) {
        if (wasInit) {
            dismiss()
            updateListener(items[checkedId].id)
//            callback(items[checkedId].value)
//            dismiss()
        }
    }


//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}