package com.gallery.photo.image.video.cameraview.ui

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import androidx.lifecycle.MutableLiveData
import com.example.app.ads.helper.GiftIconHelper
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.gallery.photo.image.video.Camera.CameraActivity
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.BaseActivity
import com.gallery.photo.image.video.adshelper.AdsManager
//import com.gallery.photo.image.video.cameraview.service.ShortcutAddDetectedService
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.extensions.toast
import kotlinx.android.synthetic.main.activity_camera_shortcut.*
import kotlin.collections.ArrayList


//class CameraShortcutActivity : BaseActivity() {
//
//    private lateinit var shortcutLabelsToRemove: ArrayList<String>
//    private lateinit var shortcutIdsToRemove: ArrayList<String>
//    private val customLabel: MutableLiveData<String> = MutableLiveData()
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_camera_shortcut)
//
//        initToolBar()
//    }
//
//    override fun getContext(): Activity {
//        return this@CameraShortcutActivity
//    }
//
//    override fun initData() {
//
//    }
//
//    override fun initActions() {
//        tvCreateShortcut.setOnClickListener(this)
//    }
//
//    override fun initAds() {
//        super.initAds()
//
//        if (AdsManager(this).isNeedToShowAds()) {
//            GiftIconHelper.loadGiftAd(this, findViewById(R.id.gift_ad_icon), findViewById(R.id.gift_blast_ad_icon))
//            NativeAdvancedModelHelper(this).loadNativeAdvancedAd(NativeAdsSize.Big, findViewById(R.id.ad_view_container))
//        }
//    }
//
//    override fun onClick(view: View) {
//        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
//            return
//        }
//        mLastClickTime = SystemClock.elapsedRealtime()
//        when (view.id) {
//            R.id.tvCreateShortcut -> {
//
//                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N_MR1) {
//                    toast(resources.getString(R.string.your_device_does_not_support_shortcut))
//                } else {
//                    if (isServiceRunning(ShortcutAddDetectedService::class.java)) {
//
////                    val shortcutManager: ShortcutManager? = getSystemService(ShortcutManager::class.java)
////                    shortcutIdsToRemove = ArrayList()
////                    shortcutLabelsToRemove = ArrayList()
//
//                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
//
//                            val shortcutManager: ShortcutManager? =
//                                getSystemService(ShortcutManager::class.java)
//                            shortcutIdsToRemove = ArrayList()
//                            shortcutLabelsToRemove = ArrayList()
//
//                            for (pinnedShortcut in shortcutManager!!.pinnedShortcuts) {
//                                shortcutIdsToRemove.add(pinnedShortcut.id)
//                                shortcutLabelsToRemove.add(pinnedShortcut.shortLabel.toString())
//                            }
//                        } else {
//                            shortcutIdsToRemove = ArrayList()
//                            shortcutLabelsToRemove = ArrayList()
//                        }
//
//                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                            createShortcut()
//                        } else {
//                            addShortcut()
//                        }
//                    } else {
//                        gotoSettings()
//                    }
//                }
//
//
//            }
//        }
//    }
//
//    private fun gotoSettings() {
////        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
////        SharedPrefs.savePref(this, "isOpen", true)
////        launchActivityForResult(intent, 201)
////        overridePendingTransition(ANIM_FADE_IN, ANIM_FADE_OUT)
//    }
//
//    override fun fromActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
//        super.fromActivityResult(requestCode, resultCode, resultData)
////        if(requestCode == 201 && resultCode == RESULT_OK)
////        {
////            toast("Shortcut created successfully")
////        }
//    }
//
//    private fun isServiceRunning(serviceClass: Class<*>): Boolean {
//        val manager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
//        for (service in manager.getRunningServices(Int.MAX_VALUE)) {
//            if (serviceClass.name == service.service.className) {
//                return true
//            }
//        }
//        return false
//    }
//
//    private fun createShortcut() {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//
//            val mShortcutInfoBuilder =
//                ShortcutInfo.Builder(this@CameraShortcutActivity, getString(R.string.stamp_camera))
//            mShortcutInfoBuilder.setShortLabel(getString(R.string.stamp_camera))
//            mShortcutInfoBuilder.setIcon(
//                Icon.createWithResource(
//                    this@CameraShortcutActivity,
//                    R.mipmap.ic_launcher_round_gps_camera
//                )
//            )
//            val shortcutIntent = Intent(applicationContext, CameraActivity::class.java)
//            shortcutIntent.action = Intent.ACTION_CREATE_SHORTCUT
//            shortcutIntent.putExtra(
//                "openShortcutCamera",
//                true
//            ) //may it's already there so don't duplicate
//            mShortcutInfoBuilder.setIntent(shortcutIntent)
//            val mShortcutInfo = mShortcutInfoBuilder.build()
//            val mShortcutManager = getSystemService(ShortcutManager::class.java)
//            if (!shortcutIdsToRemove.contains(mShortcutInfo.id) && !shortcutLabelsToRemove.contains(
//                    mShortcutInfo.shortLabel
//                )
//            ) {
//                addEvent(createShortcut)
////                val targetIntent: Intent = Intent(ShortcutReceiver.kInstalledAction)
////                targetIntent.setPackage(this.packageName)
////                val intent: PendingIntent = PendingIntent.getBroadcast(this, 0, targetIntent, 0)
//                mShortcutManager.requestPinShortcut(mShortcutInfo, null)
//            } else {
//                toast(resources.getString(R.string.shortcut_already_available))
//            }
//
//        }
//    }
//
//    private fun addShortcut() {
//        //Adding shortcut for MainActivity
//        //on Home screen
//        val shortcutIntent = Intent(
//            applicationContext,
//            CameraActivity::class.java
//        )
//        shortcutIntent.action = Intent.ACTION_MAIN
//        val addIntent = Intent()
//        addIntent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent)
//        addIntent.putExtra(Intent.EXTRA_SHORTCUT_NAME, getString(R.string.stamp_camera))
//        addIntent.putExtra(
//            Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
//            Intent.ShortcutIconResource.fromContext(
//                applicationContext,
//                R.mipmap.ic_launcher_round_gps_camera
//            )
//        )
//        addIntent.action = "com.android.launcher.action.INSTALL_SHORTCUT"
//        addIntent.putExtra("openShortcutCamera", true) //may it's already there so don't duplicate
//        if (!shortcutLabelsToRemove.contains("HD Camera")) {
//            addEvent(createShortcut)
//            applicationContext.sendBroadcast(addIntent)
//        } else {
//            toast(resources.getString(R.string.shortcut_already_available))
//        }
//
//    }
//
//    private fun initToolBar() {
//        ivBack.visibility = View.VISIBLE
//        ivBack.setOnClickListener {
//            onBackPressed()
//        }
//        tvTitle.text = resources.getString(R.string.stamp_camera_shortcut)
//    }
//
//    override fun onBackPressed() {
//        super.onBackPressed()
//        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//    }
//}