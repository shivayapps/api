package com.gallery.photo.image.video.cameraview.ui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gallery.photo.image.video.R;
import com.gallery.photo.image.video.cameraview.ui.adapter.ColorAdapter;
import com.gallery.photo.image.video.cameraview.ui.interfaces.OnRecyclerItemClickListener;
import com.gallery.photo.image.video.cameraview.ui.model.ColorModel;
import com.gallery.photo.image.video.fragment.BaseFragment;

import java.util.ArrayList;
import java.util.List;


public class ColorFragment extends BaseFragment {

    private View rootView;
    private static final String TAG = "ColorFragment";

    private ColorAdapter mAdapter;
    List<ColorModel> mList = new ArrayList();
    private RecyclerView mRecyclerview;
    private static final int DIALOG_ID = 0;

    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_color, container, false);
        mRecyclerview = rootView.findViewById(R.id.fragment_recyclerview);
        fillList();
        return rootView;
    }

    private void fillList() {
        List<ColorModel> list = mList;
        if (list != null) {
            if (list.size() > 0) {
                mList.clear();
            }

//            ColorModel colorModel2 = new ColorModel();
//            colorModel2.setTitle(getString(R.string.address_color));
//            colorModel2.setSpKey(SharedPrefs.ADDRESS_COLOR);
//            colorModel2.setColor(SharedPrefs.getInt(getActivity(), colorModel2.getSpKey(), -1));
//            mList.add(colorModel2);
//
//            ColorModel colorModel3 = new ColorModel();
//            colorModel3.setTitle(getString(R.string.date_time_color));
//            colorModel3.setSpKey(SharedPrefs.DATE_TIME_COLOR);
//            colorModel3.setColor(SharedPrefs.getInt(getActivity(), colorModel3.getSpKey(), -1));
//            mList.add(colorModel3);

        }
        setAdapter();
    }

    private void setAdapter() {
        mRecyclerview.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        ColorAdapter colorAdapter = new ColorAdapter(getActivity(), mList, new OnRecyclerItemClickListener() {
            public void OnLongClick_(int i, View view) {
            }

            public void OnClick_(final int pos, final View view) {
//                ColorPickerDialogBuilder
//                        .with(requireContext())
//                        .setTitle(getResources().getString(R.string.choose_color))
//                        .initialColor(SharedPrefs.getInt(mActivity, mList.get(pos).getSpKey(), -1))
//                        .wheelType(ColorPickerView.WHEEL_TYPE.FLOWER)
//                        .density(12)
//                        .setOnColorSelectedListener(selectedColor -> {
//
//                        })
//                        .setPositiveButton(getResources().getString(R.string.ok), (dialog, selectedColor, allColors) -> {
//                            SharedPrefs.save(mActivity, mList.get(pos).getSpKey(), selectedColor);
//                            ((GradientDrawable) view.findViewById(R.id.tv_color_background).getBackground().getCurrent()).setColor(selectedColor);
//                        })
//                        .setNegativeButton(getResources().getString(R.string.cancel), (dialog, which) -> {
//
//                        })
//                        .build()
//                        .show();
            }
        });
        mAdapter = colorAdapter;
        mRecyclerview.setAdapter(colorAdapter);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }



    @Override
    public Integer getLayoutRes() {
        return R.layout.fragment_color;
    }
}
