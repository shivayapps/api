package com.gallery.photo.image.video.fragment

import android.annotation.SuppressLint
import android.app.Activity.RESULT_OK
import android.app.Dialog
import android.app.ProgressDialog
import android.app.Service
import android.content.Intent
import android.content.res.Resources
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.hardware.fingerprint.FingerprintManager
import android.os.*
import android.util.DisplayMetrics
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.Window
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.MainActivity
import com.gallery.photo.image.video.activityBinding.*
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.dialog.EnableFakeVaultDialog
import com.gallery.photo.image.video.dialog.NewRateDialog
import com.gallery.photo.image.video.dialog.SetSecurityQuestionDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.lock.activity.CustomPinActivity
import com.gallery.photo.image.video.lock.enums.KeyboardButtonEnum
import com.gallery.photo.image.video.lock.interfaces.KeyboardButtonClickedListener
import com.gallery.photo.image.video.lock.managers.AppLock
import com.gallery.photo.image.video.lock.managers.FingerprintUiHelper
import com.gallery.photo.image.video.lock.managers.LockManager
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.rateandfeedback.*
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.rateandfeedback.library_feedback.sendEmail
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.android.synthetic.main.activity_main_new.*
import kotlinx.android.synthetic.main.fragment_vault_new.*
import kotlin.math.roundToInt

const val REQUEST_CODE_CHECK_PASSWORD = 501
const val REQUEST_CODE_FAKE_LOCK_SET = 1452

class VaultFragment : BaseFragment(), FingerprintUiHelper.Callback {

    var isEnableFakeVaultDialogDisplay = false
    var fakeVaultDialog: EnableFakeVaultDialog? = null
    var isLoaded = false

    // TODO: 24/07/21 Change for Pin Lock
    var mPinCode: String? = null
    var mLockManager: LockManager<*>? = null
    var mFingerprintManager: FingerprintManager? = null
    var mFingerprintUiHelper: FingerprintUiHelper? = null
    var mTypePin = AppLock.UNLOCK_PIN
    var mOldPinCode: String? = ""
    var mProgressDailog: ProgressDialog? = null

    private var isAuthError = false
//    var menuTarget: TapTargetView? = null
    private var isRateDialogDisplay = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requireContext().addEvent(javaClass.simpleName)

    }

    @SuppressLint("CutPasteId")
    override fun onResume() {
        super.onResume()
        requireActivity().findViewById<TextView>(R.id.tvHeaderTitle).visibility = View.VISIBLE
        if (AdsManager(requireActivity()).isNeedToShowAds() && requireContext().isOnline())
            requireActivity().findViewById<View>(R.id.clGiftIcon).visibility = VISIBLE
        else
            requireActivity().findViewById<View>(R.id.clGiftIcon).visibility = GONE
        requireActivity().findViewById<TextView>(R.id.tvHeaderTitle).text = getString(R.string.label_private_gallery)
        if (requireActivity() is MainActivity) {
            requireActivity().findViewById<ImageView>(R.id.imgOptions).visibility = GONE
            (requireActivity() as MainActivity).hideimgOption()
        }
        if (requireContext().config.isAppPasswordProtectionOn && requireContext().config.isEnableLock) {

            requireActivity().findViewById<ImageView>(R.id.imgSearch).visibility = VISIBLE
            requireActivity().findViewById<ImageView>(R.id.imgSearch).setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.ic_tab_setting))
        } else {
            requireActivity().findViewById<ImageView>(R.id.imgSearch).visibility = GONE

            if (!requireContext().isOnline()) {
                requireActivity().findViewById<View>(R.id.clGiftIcon).visibility = VISIBLE
            }
        }
        Log.d("TagHidden", "onResume: Vault Fragment")
        if (requireContext().config.isAppPasswordProtectionOn && requireContext().config.isEnableLock && !isTabUnlock && isFirstTime) {
            clConfirmLock.visibility = VISIBLE
            requireActivity().findViewById<ImageView>(R.id.imgSearch).visibility = GONE
            showLockAlert()
        } else {
            clConfirmLock.visibility = GONE
            requireActivity().findViewById<View>(R.id.clGiftIcon).visibility = GONE

            if (requireContext().config.isAppPasswordProtectionOn && requireContext().config.isEnableLock) {
                requireActivity().findViewById<ImageView>(R.id.imgSearch).visibility = VISIBLE
            } else {
                requireActivity().findViewById<ImageView>(R.id.imgSearch).visibility = GONE
            }

            if (!isRateDialogDisplay) {
                val sp = ExitSPHelper(requireContext())
                if (!sp.isRated() && !sp.isDismissed() && requireContext().config.hiddenCountForRate >= HIDDEN_COUNT_FOR_RATE_VAL) {
                    isRateDialogDisplay = true
                    NewRateDialog(mContext){
                        if (it > 3) {
                            requireActivity().rateApp()
                        } else if (it >= 0) {
                            requireActivity().sendEmail()
                        }
                    }
                    /*requireActivity().ratingDialog(object : OnRateListener {
                        override fun onRate(rate: Int) {
                            if (rate >= 3) {
                                requireActivity().rateApp()
                            } else if (rate >= 0) {
                                // feedbackDialog()
                                startActivity(FeedbackActivity.newIntent(requireContext(), rate))
                            }
                            isRateDialogDisplay = false
                        }
                    })*/
                }
            }
        }

        if (requireContext().config.isAppPasswordProtectionOn && requireContext().config.isEnableLock) {
            clVault.visibility = VISIBLE
            clSetUpLock.visibility = GONE
            if (clConfirmLock.visibility == GONE)
                requireActivity().findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto).visibility = VISIBLE
            flVaultOptions.beVisible()
            if (isFakeVaultOpen) {
                requireActivity().findViewById<TextView>(R.id.tvHeaderTitle).text = getString(R.string.label_app_vault)
                llLastOption.setPadding(
                    0, 0,
                    0, 0
                )
                llAllHiddenFile.beGone()
            } else {
                llAllHiddenFile.beVisible()
                val dm = DisplayMetrics()
                mContext.windowManager.defaultDisplay.getMetrics(dm)
                val x = Math.pow((dm.widthPixels / dm.xdpi).toDouble(), 2.0)
                val y = Math.pow((dm.heightPixels / dm.ydpi).toDouble(), 2.0)
                val screenInches = Math.sqrt(x + y)

                if (screenInches <= 5 || mContext.isTablet()) {
                    val r: Resources = mContext.resources
                    var dimen = r.getDimension(R.dimen._5sdp)
                    val px = TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
                    ).roundToInt()
                    var fab = requireActivity().findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto)
                    fab.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
                        override fun onGlobalLayout() {
                            fab.viewTreeObserver.removeOnGlobalLayoutListener(this)
                            llLastOption.setPadding(
                                0, 0,
                                0, fab.height + px
                            )
                        }
                    })
                }
            }
        } else {
            clVault.visibility = GONE
            clConfirmLock.visibility = GONE
            clSetUpLock.visibility = VISIBLE
            if (AdsManager(requireActivity()).isNeedToShowAds() && requireContext().isOnline())
                requireActivity().findViewById<View>(R.id.clGiftIcon).visibility = VISIBLE
            else
                requireActivity().findViewById<View>(R.id.clGiftIcon).visibility = GONE
            if (requireContext().config.isAppPasswordProtectionOn && !requireContext().config.isEnableLock) {
                isFirstTime = true
                tvSetSecurity.text = mContext.getString(R.string.label_enable_lock)
            } else {
                tvSetSecurity.text = getString(R.string.label_set_security)
            }

            ll_main_linearlayout.visibility = VISIBLE
            nsvSetUpLock.visibility = VISIBLE
            requireActivity().findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto).visibility = GONE
            if (requireActivity() is MainActivity) {
                (requireActivity() as MainActivity).disableToolbarScrolling()
            }
        }
    }

    override fun getLayoutRes(): Int? {
        return R.layout.fragment_vault_new
    }

    private fun showLockAlert() {
        requireActivity().findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto).visibility = GONE
        mTypePin = AppLock.UNLOCK_PIN
        mPinCode = ""
        isLoaded = false
        isLoadedFakeVaultDir = false
        isLoadedGallery = false
        isFakeVaultOpen = false
        llAllHiddenFile.beVisible()
        try {
            mLockManager = LockManager.getInstance()
            Log.e("TAG", "initPinLockView: ==>$mLockManager")
            if (mLockManager!!.getAppLock() == null) {
                mLockManager!!.useForService(requireContext())
            }
            mLockManager!!.getAppLock().setPinChallengeCancelled(false)
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
            //FirebaseCrash.report(e);
        }
        pin_code_step_textview.text = getText(R.string.pin_code_step_unlock)
        pin_code_round_view.setPinLength(4)
        pin_code_forgot_textview.visibility = View.VISIBLE
        pin_code_forgot_textview.text = getText(R.string.pin_code_forgot_text)
        pin_code_keyboard_view.setKeyboardButtonClickedListener(object : KeyboardButtonClickedListener {
            override fun onKeyboardClick(keyboardButtonEnum: KeyboardButtonEnum) {
                if (mPinCode!!.length < 4) {
                    val value = keyboardButtonEnum.buttonValue
                    if (value == KeyboardButtonEnum.BUTTON_CLEAR.buttonValue) {
                        if (!mPinCode!!.isEmpty()) {
                            setPinCode(mPinCode!!.substring(0, mPinCode!!.length - 1))
                        } else {
                            setPinCode("")
                        }
                    } else {
                        setPinCode(mPinCode + value)
                    }
                }
            }

            override fun onRippleAnimationEnd() {
                if (mPinCode!!.length == 4) {
                    onPinCodeInputed()
                }
            }
        })
        pin_code_forgot_textview.setOnClickListener(View.OnClickListener { openForgotPasswordDialog() })

        pin_code_fingerprint_imageview.setOnClickListener(this)
        initializeFingerprintManager()
    }

    private fun initializeFingerprintManager() {
        Log.d("TAG11", "onResume: Vault Fragment initialize finger")
        if (requireContext().config.isFingerprintEnable && !requireContext().config.isFakeVaultEnable) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                mFingerprintManager = requireContext().getSystemService(Service.FINGERPRINT_SERVICE) as FingerprintManager
                mFingerprintUiHelper = FingerprintUiHelper.FingerprintUiHelperBuilder(mFingerprintManager).build(pin_code_fingerprint_imageview, pin_code_fingerprint_textview, this)
                FingerprintUiHelper.isFromVault = false
                try {
                    if (mFingerprintManager != null && mFingerprintManager!!.isHardwareDetected() && mFingerprintUiHelper!!.isFingerprintAuthAvailable()
                        && mLockManager!!.appLock.isFingerprintAuthEnabled
                    ) {
                        pin_code_fingerprint_imageview.visibility = VISIBLE
                        pin_code_fingerprint_textview.visibility = VISIBLE
                        pin_code_fingerprint_textview.text = requireContext().getString(R.string.pin_code_fingerprint_text)
                        pin_code_fingerprint_textview.setTextColor(
                            requireContext().resources.getColor(R.color.textGray, null)
                        )
                        mFingerprintUiHelper!!.startListening()
                        isAuthError = false
                    } else {
                        pin_code_fingerprint_imageview.visibility = GONE
                        pin_code_fingerprint_textview.visibility = GONE
                    }
                } catch (e: SecurityException) {
                    Log.e("TAG", e.toString())
                    pin_code_fingerprint_imageview.visibility = GONE
                    pin_code_fingerprint_textview.visibility = GONE
                }

            } else {
                pin_code_fingerprint_imageview.visibility = GONE
                pin_code_fingerprint_textview.visibility = GONE
            }
        } else {
            pin_code_fingerprint_imageview.visibility = GONE
            pin_code_fingerprint_textview.visibility = GONE
        }
    }

    private fun openForgotPasswordDialog() {

        val view = layoutInflater.inflate(R.layout.dialog_set_security_question, null)
        val dialog = Dialog(requireContext())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val ivClose = dialog.findViewById<ImageView>(R.id.ivClose)
        val etSeqAns = dialog.findViewById<EditText>(R.id.etSeqAns)
        val spSecQue = dialog.findViewById<Spinner>(R.id.spSecQue)
        val selectedSecQue = arrayOf("")
        val selectedPos = intArrayOf(0)
        spSecQue.setSelection(0)
        etSeqAns.text = null
        spSecQue.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View, position: Int, id: Long) {
                selectedSecQue[0] = spSecQue.selectedItem as String
                selectedPos[0] = spSecQue.selectedItemPosition
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        ivClose.setOnClickListener { dialog.dismiss() }

        val tvDone = dialog.findViewById<TextView>(R.id.tvDone)
        tvDone.setOnClickListener {
            if (selectedPos[0] == 0) {
                Toast.makeText(requireContext(), getString(R.string.error_msg_please_select_que), Toast.LENGTH_SHORT).show()
            } else if (etSeqAns.text.toString().isEmpty()) {
                Toast.makeText(requireContext(), getString(R.string.error_please_enter_answer), Toast.LENGTH_SHORT).show()
            } else if (etSeqAns.text.toString().length < 5) {
                Toast.makeText(requireContext(), getString(R.string.error_msg_please_enter_valid_answer), Toast.LENGTH_SHORT).show()
            } else {
                if (selectedPos[0] != requireContext().config.securityQuestionIndex
                    || etSeqAns.text.toString() != requireContext().config.securityAnswer
                ) {
                    Toast.makeText(requireContext(), getString(R.string.msg_security_invalid), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), getString(R.string.msg_match_successfully), Toast.LENGTH_SHORT).show()
//                    requireContext().config.isFingerprintEnable = false
                    pin_code_fingerprint_imageview.visibility = GONE
                    pin_code_fingerprint_textview.visibility = GONE
                    mTypePin = AppLock.ENABLE_PINLOCK
                    setStepText()
                    pin_code_forgot_textview!!.visibility = View.INVISIBLE
                    setPinCode("")
                }
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    fun setPinCode(pinCode: String?) {
        mPinCode = pinCode
        pin_code_round_view!!.refresh(mPinCode!!.length)
    }

    fun onPinCodeInputed() {
        when (mTypePin) {
            AppLock.ENABLE_PINLOCK -> {
                when {
                    requireContext().config.fakeVaultAppLock == mPinCode -> {
                        Toast.makeText(activity, getString(R.string.error_app_lock_and_fake_lock_not_same), Toast.LENGTH_SHORT).show();
                        setPinCode("")
                    }
                    else -> {
                        mOldPinCode = mPinCode
                        setPinCode("")
                        mTypePin = AppLock.CONFIRM_PIN
                        setStepText()
                        pin_code_forgot_textview.visibility = View.INVISIBLE
                    }
                }
            }
            AppLock.CONFIRM_PIN -> if (mPinCode == mOldPinCode) {
                mLockManager!!.appLock!!.setPasscode(mPinCode)
                requireActivity().config.appVaultAppLock = mPinCode.toString()
                stopAlert()
            } else {
                mOldPinCode = ""
                setPinCode("")
                mTypePin = AppLock.ENABLE_PINLOCK
                setStepText()
                pin_code_forgot_textview.visibility = View.INVISIBLE
                onPinCodeError()
            }
            AppLock.UNLOCK_PIN -> {
                pin_code_forgot_textview.visibility = View.VISIBLE
                try {
                    if (requireContext().config.appVaultAppLock == "") {
                        if (mLockManager!!.appLock!!.checkPasscode(mPinCode)) {
                            requireContext().config.appVaultAppLock = mPinCode.toString()
                            stopAlert()
                        } else {
                            onPinCodeError()
                        }
                    } else {
                        if (requireContext().config.appVaultAppLock == mPinCode) {
                            stopAlert()
                        } else if (requireContext().config.isFakeVaultEnable && requireContext().config.fakeVaultAppLock == mPinCode) {
                            stopAlertForFakeVault()
                        } else {
                            onPinCodeError()
                        }
                    }
                } catch (e: Exception) {
                }
            }
            else -> {
            }
        }
    }

    private fun stopAlertForFakeVault() {
        if (isAdded) {
            mContext.addEvent(fakeVaultOpen)
        }
        isFakeVaultOpen = true
        clConfirmLock.visibility = GONE
        isFirstTime = false
        isTabUnlock = true
        flVaultOptions.beVisible()
        llAllHiddenFile.beGone()

        llLastOption.setPadding(
            0, 0,
            0, 0
        )
        requireActivity().findViewById<TextView>(R.id.tvHeaderTitle).text = getString(R.string.label_app_vault)
        if (requireActivity() is MainActivity) {
            (requireActivity() as MainActivity).enableToolbarScrolling()
            if (requireActivity().viewPagerHome.currentItem == 2) {
                requireActivity().findViewById<View>(R.id.clGiftIcon).visibility = GONE
                requireActivity().findViewById<ImageView>(R.id.imgSearch).visibility = VISIBLE
                requireActivity().findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto).visibility = VISIBLE
                requireActivity().findViewById<ImageView>(R.id.imgSearch).setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.ic_tab_setting))
            }
        }


    }

    private fun stopAlert() {
        if (isAdded) {
            mContext.addEvent(appVaultOpen)
        }
        clConfirmLock.visibility = GONE
        isFirstTime = false
        isTabUnlock = true
        isNeedToRefresh = true
        isLoadedGallery = false
        isLoadedOtherApp = false
        flVaultOptions.beVisible()
        val dm = DisplayMetrics()
        mContext.windowManager.defaultDisplay.getMetrics(dm)
        val x = Math.pow((dm.widthPixels / dm.xdpi).toDouble(), 2.0)
        val y = Math.pow((dm.heightPixels / dm.ydpi).toDouble(), 2.0)
        val screenInches = Math.sqrt(x + y)

        if (screenInches <= 5 || mContext.isTablet()) {
            val r: Resources = mContext.resources
            var dimen = r.getDimension(R.dimen._5sdp)
            val px = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
            ).roundToInt()
            llLastOption.setPadding(
                0, 0,
                0, requireActivity().findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto).height + px
            )
        }
        requireActivity().findViewById<TextView>(R.id.tvHeaderTitle).text = getString(R.string.label_private_gallery)
        if (requireActivity() is MainActivity) {

            (requireActivity() as MainActivity).enableToolbarScrolling()

            if (requireActivity().viewPagerHome.currentItem == 2) {
                requireActivity().findViewById<View>(R.id.clGiftIcon).visibility = GONE
                requireActivity().findViewById<ImageView>(R.id.imgSearch).visibility = VISIBLE
                requireActivity().findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto).visibility = VISIBLE
                requireActivity().findViewById<ImageView>(R.id.imgSearch).setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.ic_tab_setting))

                Log.d("111TAG", "stopAlert: --> Required activity is MainActivity ")
                if (!isRateDialogDisplay) {

                    val sp = ExitSPHelper(requireContext())
                    if (!sp.isRated() && !sp.isDismissed() && requireContext().config.hiddenCountForRate >= HIDDEN_COUNT_FOR_RATE_VAL) {
                        isRateDialogDisplay = true
                        NewRateDialog(mContext){
                            if (it > 3) {
                                mContext.rateApp()
                            } else if (it >= 0) {
                                mContext.sendEmail()
                            }
                        }
                      /*  requireActivity().ratingDialog(object : OnRateListener {
                            override fun onRate(rate: Int) {
                                if (rate >= 3) {
                                    requireActivity().rateApp()
                                } else if (rate >= 0) {
                                    // feedbackDialog()
                                    startActivity(FeedbackActivity.newIntent(requireContext(), rate))
                                }
                                isRateDialogDisplay = false
                            }
                        })*/
                    }
                }
            }
        }

        //Fake Vault
//        if (!isEnableFakeVaultDialogDisplay) {
        if (!requireContext().config.isFakeVaultDialogShown && !requireContext().config.isFakeVaultEnable && requireContext().config.fakeVaultAppLock == "") {
            requireContext().config.isFakeVaultDialogShown = true
            isEnableFakeVaultDialogDisplay = true
            fakeVaultDialog = EnableFakeVaultDialog(requireActivity() as BaseSimpleActivity) {
                if (it) {
                    if (requireContext().config.fakeVaultAppLock == "") {
                        val intent = Intent(requireActivity(), CustomPinActivity::class.java)
                        intent.putExtra(AppLock.EXTRA_TYPE, AppLock.ENABLE_PINLOCK)
                        intent.putExtra(INTENT_LOCK_TYPE, INTENT_LOCK_TYPE_FAKE)
                        launchActivityForResult(intent, REQUEST_CODE_FAKE_LOCK_SET)
//                        startActivityForResult(intent, REQUEST_CODE_CHECK_PASSWORD)
                    } else {
                        requireContext().config.isFakeVaultEnable = true
                    }
                }
            }
        }


    }

    override fun onPause() {
        super.onPause()
        if (mFingerprintUiHelper != null)
            mFingerprintUiHelper!!.stopListening()
        requireActivity().runOnUiThread {
            if (fakeVaultDialog != null) {
                fakeVaultDialog!!.dialog.dismiss()
                isEnableFakeVaultDialogDisplay = false
            }
//            if (menuTarget != null)
//                menuTarget!!.dismiss(true)
        }
    }

    protected fun onPinCodeError() {
        // onPinFailure(mAttempts++);
        //Thread thread = new Thread() {
        //  void run() {
        mPinCode = ""
        pin_code_round_view!!.refresh(mPinCode!!.length)
        val animation = AnimationUtils.loadAnimation(
            requireContext(), R.anim.shake_lock
        )
        pin_code_keyboard_view.startAnimation(animation)
        /*    }
        };
        mAlertView.runOnUiThread(thread);*/
    }

    fun setStepText() {
        pin_code_step_textview.text = getStepText(mTypePin)
    }

    fun getStepText(reason: Int): String? {
        var msg: String? = null
        when (reason) {
            AppLock.DISABLE_PINLOCK -> msg = getString(R.string.pin_code_step_disable, 4)
            AppLock.ENABLE_PINLOCK -> msg = getString(R.string.pin_code_step_create, 4)
            AppLock.CHANGE_PIN -> msg = getString(R.string.pin_code_step_change, 4)
            AppLock.UNLOCK_PIN -> msg = getString(R.string.pin_code_step_unlock) //, this.getPinLength());
            AppLock.CONFIRM_PIN -> msg = getString(R.string.pin_code_step_enable_confirm, 4)
        }
        return msg
    }


    override fun onAuthenticated() {
        stopAlert()
    }

    override fun onError() {
        isAuthError = true
    }


    override fun initView() {
        if (requireContext().config.isAppPasswordProtectionOn && requireContext().config.isEnableLock) {
            clVault.visibility = VISIBLE
            clSetUpLock.visibility = GONE
        } else {
            clVault.visibility = GONE
            clSetUpLock.visibility = VISIBLE
            ll_main_linearlayout.visibility = VISIBLE
            nsvSetUpLock.visibility = VISIBLE
        }

        llSetSecurity.setOnClickListener {
            if (requireContext().config.isAppPasswordProtectionOn && !requireContext().config.isEnableLock) {
                requireContext().config.isEnableLock = true
                isTabUnlock = true
                clConfirmLock.visibility = VISIBLE
                requireActivity().findViewById<ImageView>(R.id.imgSearch).visibility = GONE
                showLockAlert()
                clVault.visibility = VISIBLE
                clSetUpLock.visibility = GONE
            } else {
                SetSecurityQuestionDialog(requireActivity() as BaseSimpleActivity) {
                    val intent = Intent(requireActivity(), CustomPinActivity::class.java)
                    intent.putExtra(AppLock.EXTRA_TYPE, AppLock.ENABLE_PINLOCK)
                    launchActivityForResult(intent, REQUEST_CODE_CHECK_PASSWORD)
                }
            }
        }
        setClickListener(cvScanImages, cvScanVideo, cvScanAudio, cvScanDocument, cvSecretNote, cvPrivateBrowser, cvTrash, cvAllHiddenFile)
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_CODE_CHECK_PASSWORD -> {
                if (resultCode == RESULT_OK) {
                    Toast.makeText(requireContext(), getString(R.string.msg_lock_set_sccessfully), Toast.LENGTH_SHORT).show()
                    clVault.visibility = VISIBLE
                    clSetUpLock.visibility = GONE
                    requireContext().config.isAppPasswordProtectionOn = true
                    requireContext().config.isEnableLock = true
                    isUnLockApp = false
                }
            }
            REQUEST_CODE_FAKE_LOCK_SET -> {
                if (resultCode == RESULT_OK) {
                    Toast.makeText(requireContext(), getString(R.string.msg_fake_vault_set_successfully), Toast.LENGTH_SHORT).show()
                    requireContext().addEvent(fakeVaultSet)
                    clVault.visibility = VISIBLE
                    clSetUpLock.visibility = GONE
                    isUnLockApp = false
//                    menuTarget = TapTargetView.showFor(mContext,
//                        TapTarget.forView(requireActivity().findViewById<ImageView>(R.id.imgSearch), "", requireContext().getString(R.string.msg_switch_fake_vault))
//                            .cancelable(true)
//                            .textColor(R.color.white)
//                            .descriptionTextColor(R.color.white)
//                            .descriptionTextAlpha(1f)
//                            .tintTarget(true),
//                        object : TapTargetView.Listener() {
//                            override fun onTargetClick(view: TapTargetView) {
//                                super.onTargetClick(view)
//                                view.dismiss(true)
//
//                            }
//
//                            override fun onTargetCancel(view: TapTargetView?) {
//                                super.onTargetCancel(view)
//
//                            }
//
//                        })
                }
            }

        }
    }

    companion object {
        var isHiddenByGallerySelected = true
        var isFakeVaultOpen = false
        var isColumnCountChange = false
        var isLanguageChanges = false
        var isSortingChange = false
        var isTabUnlock = false
        var isNeedToRefresh = false
        var isHideUnHideMedia = true
        var isLoadedGallery = false
        var isLoadedOtherApp = false
        var isFirstTime = true
        var isNeedToShowHiddenByGallery = false
        var isLoadedFakeVaultDir = false
        var fabButtonHeight = 0
        var mMedia = ArrayList<ThumbnailItem>()
        fun getInstance(position: Int): Fragment {
            val f: VaultFragment = VaultFragment()
            val args: Bundle = Bundle()
            args.putInt("position", position)
            f.setArguments(args)
            return f
        }
    }

    override fun onClick(v: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        when (v!!.id) {
            R.id.pin_code_fingerprint_imageview -> {
                if (mFingerprintUiHelper != null && isAuthError) {
                    isAuthError = false
                    mFingerprintUiHelper!!.stopListening()
                    initializeFingerprintManager()
                }
            }
            R.id.cvScanImages -> {
                if (isAdded) {
                    mContext.addEvent(vaultImageClick)
                }
                startActivity(HiddenImagesActivity.newIntent(requireContext(), true, false))
            }
            R.id.cvScanVideo -> {
                if (isAdded) {
                    mContext.addEvent(vaultVideoClick)
                }
                startActivity(HiddenImagesActivity.newIntent(requireContext(), false, true))
            }
            R.id.cvScanAudio -> {
                if (isAdded) {
                    mContext.addEvent(vaultAudioClick)
                }
//                requireContext().toast("Coming soon...")
                startActivity(HiddenAudioActivity.newIntent(requireContext(), true))
            }
            R.id.cvScanDocument -> {
                if (isAdded) {
                    mContext.addEvent(vaultDocumentClick)
                }
//                requireContext().toast("Coming soon...")
                startActivity(HiddenAudioActivity.newIntent(requireContext(), false))
            }
            R.id.cvSecretNote -> {
                if (isAdded) {
                    mContext.addEvent(vaultNotesClick)
                }
//                requireContext().toast("Coming soon...")
                startActivity(SecretNotesActivity.newIntent(requireContext()))
            }
            R.id.cvPrivateBrowser -> {
                if (isAdded) {
                    mContext.addEvent(vaultPrivateBrowserClick)
                }
//                requireContext().toast("Coming soon...")
                startActivity(PrivateBrowserActivity.newIntent(requireContext()))
            }
            R.id.cvTrash -> {
                if (isAdded) {
                    mContext.addEvent(vaultTrashClick)
                }
//                requireContext().toast("Coming soon...")
                startActivity(TrashActivity.newIntent(requireContext()))
//                Intent(requireContext(), TempTrashActivity::class.java).apply {
//                    putExtra(SKIP_AUTHENTICATION, true)
//                    flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
//                    putExtra(DIRECTORY, "")
//                    putExtra(SHOW_ONLY_HIDDEN, false)
//                    putExtra(GET_IMAGE_INTENT, true)
//                    putExtra(GET_VIDEO_INTENT, false)
//                    putExtra(GET_ANY_INTENT, false)
//                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
////                startActivityForResult(this, PICK_MEDIA)
//                    launchActivityForResult(this, 455)
//                }
            }
            R.id.cvAllHiddenFile -> {
                if (isAdded) {
                    mContext.addEvent(vaultHiddenAllFileClick)
                }
//                                requireContext().toast("Coming soon...")
                startActivity(AllHiddenFileActivity.newIntent(requireContext()))
            }

        }
    }


}