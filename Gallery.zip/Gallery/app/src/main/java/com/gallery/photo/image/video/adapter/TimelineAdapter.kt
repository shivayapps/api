package com.gallery.photo.image.video.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ItemTimeLineStoryBinding
import com.gallery.photo.image.video.stories.StoryContent

import java.util.*


class TimelineAdapter(
    val context: Context,
    private val list: ArrayList<ArrayList<StoryContent>>,val itemClick: (Int) -> Unit
) : BaseStoryAdapter<ArrayList<ArrayList<StoryContent>>>(list) {


    private var mOverlayListener: OverlayListener? = null

    interface OverlayListener {
        fun onOverlayClicked(position: Int)
    }

    fun setOverlayListener(eventListener: OverlayListener) {
        mOverlayListener = eventListener
    }

    inner class MyView(fBinding: ItemTimeLineStoryBinding) : BaseViewHolder<ItemTimeLineStoryBinding>(fBinding)

    override fun onCreateHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<*> {
        return MyView(ItemTimeLineStoryBinding.inflate(LayoutInflater.from(context), parent, false))
    }

    override fun onBindHolder(holder: BaseViewHolder<*>, position: Int) {
        with(holder as MyView) {
            with(fBinding) {
                with(list[position]) {
                    Glide.with(context)
                        .load(this[0].img)
                        .centerCrop()
                        .into(imgMedia)
                    mediumName.text=context.getString(R.string.label_time_line_year_ago,this[0].index)
                    itemView.setOnClickListener {
                        itemClick.invoke(position)

                    }
                }
            }
        }
    }


    override fun getItemCount(): Int {
        return list.size
    }

}