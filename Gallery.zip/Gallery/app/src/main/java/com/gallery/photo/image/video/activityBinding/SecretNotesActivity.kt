package com.gallery.photo.image.video.activityBinding

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import android.view.ViewTreeObserver
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import com.example.app.ads.helper.GiftIconHelper
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adapter.NotesAdapter
import com.gallery.photo.image.video.adshelper.AdsManager

import com.gallery.photo.image.video.databinding.ActivitySecretNotesBinding
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.extensions.noteDao
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.Note
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.utilities.getDefaultFileFilter
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager
import kotlin.math.roundToInt


class SecretNotesActivity : BaseBindingActivity<ActivitySecretNotesBinding>(), MediaOperationsListener {
    var noteList = ArrayList<Note>()
    private var mIsSearchOpen = false
    private var mAllowPickingMultiple = false
    private var mLastSearchedText = ""
    override fun getContext(): Activity {
        return this
    }

    companion object {
        fun newIntent(mContext: Context): Intent {
            return Intent(mContext, SecretNotesActivity::class.java)
        }

        var isNeedToRefersh = false

    }

    override fun initData() {
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = mBinding.giftLayout.giftAdIcon,
                fivBlastIcon = mBinding.giftLayout.giftBlastAdIcon
            )
        }
        mBinding.imgBack.setOnClickListener(this)
        mBinding.rlAddHiddenPhotoVideo.setOnClickListener(this)
        mBinding.imgAddHiddenPhoto.setOnClickListener(this)
        mBinding.llHideOpt.setOnClickListener(this)
        mBinding.notesRefreshLayout.setOnRefreshListener {
            getNotesData()
        }
        if (mBinding.imgAddHiddenPhoto.isVisible()) {
            try {
                mBinding.imgAddHiddenPhoto.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
                    override fun onGlobalLayout() {
                        mBinding.imgAddHiddenPhoto.viewTreeObserver.removeOnGlobalLayoutListener(this)
                        val r: Resources = resources
                        var dimen = r.getDimension(R.dimen._7sdp)
                        val px = TypedValue.applyDimension(
                            TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
                        ).roundToInt()
                        mBinding.directoriesGrid.setPadding(3, 3, 3, mBinding.imgAddHiddenPhoto.height + px)
                    }
                })
            } catch (e: Exception) {
                val r: Resources = resources
                var dimen = r.getDimension(R.dimen._25sdp)
                val px = TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
                ).roundToInt()
                mBinding.directoriesGrid.setPadding(3, 3, 3, px)
            }
        }
        getNotesData()
    }

    private fun getNotesData() {
        mBinding.llProgress.beVisible()
        ensureBackgroundThread {
            noteList = if (VaultFragment.isFakeVaultOpen) {
                noteDao.getFakeVaultNotes() as ArrayList<Note>
            } else {
                noteDao.getMainVaultNotes() as ArrayList<Note>
            }
            gotNotes()
        }

    }


    override fun initActions() {

    }

    override fun setBinding(): ActivitySecretNotesBinding {
        return ActivitySecretNotesBinding.inflate(inflater)
    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun onResume() {
        super.onResume()
        if (isNeedToRefersh) {
            getNotesData()
        }
    }

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.imgBack -> {
                onBackPressed()
            }
            R.id.rlAddHiddenPhotoVideo, R.id.imgAddHiddenPhoto -> {
                startActivity(AddSecretNoteActivity.newIntent(this))
            }
            R.id.llHideOpt -> {
                if (mBinding.directoriesGrid.adapter != null) {
                    (mBinding.directoriesGrid.adapter as NotesAdapter).checkDeleteConfirmation()
                }
            }
        }
    }

    private fun gotNotes() {
        setupLayoutManager()
        setupAdapter()
        Thread {
            runOnUiThread {
                mBinding.notesRefreshLayout.isRefreshing = false
                VaultFragment.isLoadedGallery = true
                checkPlaceholderVisibility()
                mBinding.llProgress.beGone()
            }
        }.start()
    }

    private fun setupAdapter() {
        runOnUiThread {

            if (mBinding.directoriesGrid != null) {
                val currAdapter = mBinding.directoriesGrid.adapter
                if (currAdapter == null) {
                    val fastscroller = mBinding.directoriesVerticalFastscroller
                    NotesAdapter(
                        this, noteList, this, false,
                        mAllowPickingMultiple, mBinding.directoriesGrid, fastscroller
                    ) {
                        if (it is Note && !isFinishing) {
                            itemClicked(it)
                        }
                    }.apply {
                        mBinding.directoriesGrid.adapter = this
                    }
                    setupLayoutManager()
                } else if (mLastSearchedText.isEmpty()) {
                    (currAdapter as NotesAdapter).updateMedia(noteList)
                }
            }
        }
    }

    private fun itemClicked(note: Note) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        startActivity(Intent(AddSecretNoteActivity.newIntent(this, note)))

    }

    private fun checkPlaceholderVisibility() {
        runOnUiThread {

            mBinding.directoriesEmptyPlaceholder.beGone()
            mBinding.directoriesEmptyPlaceholder2.beGone()
            mBinding.rlAddHiddenPhotoVideo.beVisibleIf(noteList.isEmpty())
            if (mIsSearchOpen) {
                mBinding.directoriesEmptyPlaceholder.beVisibleIf(noteList.isEmpty())
                mBinding.directoriesEmptyPlaceholder.text = getString(R.string.no_items_found)
            } else if (noteList.isEmpty() && config.filterMedia == getDefaultFileFilter()) {
                mBinding.directoriesEmptyPlaceholder.text = getString(R.string.no_media_with_filters)
                mBinding.directoriesEmptyPlaceholder2.text = getString(R.string.add_folder)
            } else {
                mBinding.directoriesEmptyPlaceholder.text = getString(R.string.no_media_with_filters)
                mBinding.directoriesEmptyPlaceholder2.text = getString(R.string.change_filters_underlined)
            }
            mBinding.directoriesEmptyPlaceholder2.underlineText()
            mBinding.directoriesGrid.beVisibleIf(mBinding.rlAddHiddenPhotoVideo.isGone())

        }

    }

    fun setupLayoutManager() {
        runOnUiThread(Runnable {
            setupListLayoutManager()
        })

    }


    private fun setupListLayoutManager() {
        val layoutManager = mBinding.directoriesGrid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL
    }

    fun toggleToolbar(isShowActionBar: Boolean) {
        if (isShowActionBar) {
            if (mBinding.etSearch.visibility == View.VISIBLE) {
                hideKeyboard(findViewById<EditText>(R.id.etSearch))
                findViewById<EditText>(R.id.etSearch).clearFocus()
            }
            mBinding.llBottomOption.beVisible()
            mBinding.tvHideUnHideText.text = resources.getString(R.string.label_delete_count, 0)
            mBinding.imgAddHiddenPhoto.beGone()

            mBinding.directoriesGrid.setPadding(3, 3, 3, 3)
        } else {
            mBinding.llBottomOption.visibility = View.GONE
            mBinding.imgAddHiddenPhoto.beVisible()
            val r: Resources = resources
            var dimen = r.getDimension(R.dimen._7sdp)
            val px = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, dimen, r.displayMetrics
            ).roundToInt()
            mBinding.directoriesGrid.setPadding(3, 3, 3, mBinding.imgAddHiddenPhoto.height + px)
        }
    }

    fun updateCount(size: Int) {
        mBinding.tvHideUnHideText.text = resources.getString(R.string.label_delete_count, size)
    }


    override fun refreshItems() {
        getNotesData()
    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {

    }

    override fun selectedPaths(paths: ArrayList<String>) {

    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {

    }


}