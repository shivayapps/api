package com.gallery.photo.image.video.activity

import android.app.Activity
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.example.app.ads.helper.GiftIconHelper
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adshelper.AdsManager

import com.gallery.photo.image.video.dialog.SetSecurityQuestionDialog
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.extensions.supportFingerPrint
import com.gallery.photo.image.video.fragment.REQUEST_CODE_CHECK_PASSWORD
import com.gallery.photo.image.video.inapp.InAppPurchaseHelper
import com.gallery.photo.image.video.inapp.showPurchaseSuccess
import com.gallery.photo.image.video.lock.activity.CustomPinActivity
import com.gallery.photo.image.video.lock.managers.AppLock
import com.gallery.photo.image.video.lock.managers.LockSettings
import com.gallery.photo.image.video.activityBinding.BaseBindingActivity
import com.gallery.photo.image.video.activityBinding.HelpFAQActivity
import com.gallery.photo.image.video.databinding.ActivityVaultSettingsBinding
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.utilities.INTENT_LOCK_TYPE
import com.gallery.photo.image.video.utilities.INTENT_LOCK_TYPE_FAKE
import com.gallery.photo.image.video.utilities.isUnLockApp
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.extensions.beGone
import com.gallery.photo.image.video.extensions.beVisible
import com.gallery.photo.image.video.extensions.toast
import com.gallery.photo.image.video.rateandfeedback.library_feedback.sendEmail
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

const val REQUEST_CODE_CHANGE_PASSWORD = 101
const val REQUEST_CODE_DISABLE_PASSWORD = 102

class VaultSettingsActivity : BaseBindingActivity<ActivityVaultSettingsBinding>(), InAppPurchaseHelper.OnPurchased {
    var isEnableLock = false
    var isEnableFingerPrint = false
    var isEnableFakeVault = false
    var isRemoveAdClick = false

    // variable to track event time
    override var mLastClickTime: Long = 0
    override var mMinDuration = 1000
    private val REQUEST_CODE_CHECK = 11
    private val REQUEST_CODE_ENABLE_FAKE_VAULT = 10145

    companion object {
        var isUnlock = false
    }


    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        mBinding.imgBack.setOnClickListener {
            onBackPressed()
        }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = findViewById(R.id.gift_ad_icon),
                fivBlastIcon = findViewById(R.id.gift_blast_ad_icon)
            )
            NativeAdvancedModelHelper(this).loadNativeAdvancedAd(
                NativeAdsSize.Medium,
                findViewById(R.id.adViewContainer)
            )
        }
        InAppPurchaseHelper.instance!!.initBillingClient(this, this)
    }


    override fun initActions() {
        mBinding.clChangePin.setOnClickListener(this)
        mBinding.clChangeSecQue.setOnClickListener(this)
        mBinding.clRemoveLock.setOnClickListener(this)
        mBinding.clFeedBack.setOnClickListener(this)
        mBinding.clRemoveAds.setOnClickListener(this)
        mBinding.clSwitchFakeVault.setOnClickListener(this)
        mBinding.clHelp.setOnClickListener(this)
        mBinding.clEnableLock.setOnClickListener {
            if (isEnableLock) {
                mBinding.imgEnableLockRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_on))
                config.isEnableLock = true
                isEnableLock = false
                VaultFragment.isTabUnlock = false
            } else {
                mBinding.imgEnableLockRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_off))
                config.isEnableLock = false
                isEnableLock = true
            }
        }
        mBinding.clUnlockWithFingerPrint.setOnClickListener {
            if (config.isEnableLock) {
                if (isEnableFingerPrint) {
                    mBinding.imgUnlockWithFingerPrintRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_on))
                    config.isFingerprintEnable = true
                    isEnableFingerPrint = false
                } else {
                    mBinding.imgUnlockWithFingerPrintRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_off))
                    config.isFingerprintEnable = false
                    isEnableFingerPrint = true
                }
            } else {
                toast(getString(R.string.error_enable_lock))
            }
        }

        mBinding.clFakeVault.setOnClickListener {
            if (config.isEnableLock) {
                if (isEnableFakeVault) {
                    mBinding.imgFakeVaultRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_on))
                    mBinding.clUnlockWithFingerPrint.visibility = GONE
                    mBinding.dividerRemoveLock.visibility = GONE
                    mBinding.clSwitchFakeVault.visibility = VISIBLE
                    mBinding.dividerSwitchToFakeVault.visibility = VISIBLE
                    isEnableFakeVault = false

                    if (config.fakeVaultAppLock == "") {
                        val intent = Intent(this, CustomPinActivity::class.java)
                        intent.putExtra(AppLock.EXTRA_TYPE, AppLock.ENABLE_PINLOCK)
                        intent.putExtra(INTENT_LOCK_TYPE, INTENT_LOCK_TYPE_FAKE)
                        launchActivityForResult(intent, REQUEST_CODE_ENABLE_FAKE_VAULT)
                    } else {
                        config.isFakeVaultEnable = true
                        mBinding.tvFakeVaultPassword.visibility = VISIBLE
                        mBinding.tvFakeVaultPassword.text = getString(R.string.label_fake_vault_password, config.fakeVaultAppLock)
                    }
                } else {
                    mBinding.imgFakeVaultRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_off))
                    config.isFakeVaultEnable = false
                    if (supportFingerPrint()) {
                        mBinding.clUnlockWithFingerPrint.visibility = VISIBLE
                        mBinding.dividerRemoveLock.visibility = VISIBLE
                    }
                    mBinding.clSwitchFakeVault.visibility = GONE
                    mBinding.dividerSwitchToFakeVault.visibility = GONE
                    mBinding.tvFakeVaultPassword.visibility = GONE
                    isEnableFakeVault = true
                }
            } else {
                toast( getString(R.string.error_enable_lock))
            }
        }

        if (config.isEnableLock) {
            isEnableLock = false
            mBinding.imgEnableLockRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_on))
        } else {
            isEnableLock = true
            mBinding.imgEnableLockRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_off))
        }
        if (config.isFingerprintEnable) {
            isEnableFingerPrint = false
            mBinding.imgUnlockWithFingerPrintRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_on))
        } else {
            isEnableFingerPrint = true
            mBinding.imgUnlockWithFingerPrintRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_off))
        }
        if (config.isFakeVaultEnable) {
            isEnableFakeVault = false
            mBinding.imgFakeVaultRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_on))
            mBinding.tvFakeVaultPassword.visibility = VISIBLE
            mBinding.tvFakeVaultPassword.text = getString(R.string.label_fake_vault_password, config.fakeVaultAppLock)
        } else {
            isEnableFakeVault = true
            mBinding.imgFakeVaultRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_off))
            mBinding.tvFakeVaultPassword.visibility = GONE
            mBinding.clSwitchFakeVault.visibility = GONE
            mBinding.dividerSwitchToFakeVault.visibility = GONE
        }
        if (config.isSwitchFakeVaultClicked) {
            mBinding.imgNewFun.beGone()
        } else {
            mBinding.imgNewFun.beVisible()
        }
    }

    override fun onResume() {
        super.onResume()
        if (AdsManager(this).isNeedToShowAds()) {
            mBinding.clRemoveAds.visibility = VISIBLE
            mBinding.dividerClRemoveAd.visibility = VISIBLE
        } else {
            mBinding.clRemoveAds.visibility = GONE
            mBinding.dividerClRemoveAd.visibility = GONE
            mBinding.adViewContainer.visibility = GONE

        }
        if (supportFingerPrint()) {
            if (!config.isFakeVaultEnable) {
                mBinding.clUnlockWithFingerPrint.visibility = VISIBLE
                mBinding.dividerRemoveLock.visibility = VISIBLE
                mBinding.clSwitchFakeVault.visibility = GONE
                mBinding.dividerSwitchToFakeVault.visibility = GONE
            } else {
                mBinding.clUnlockWithFingerPrint.visibility = GONE
                mBinding.dividerRemoveLock.visibility = GONE
                mBinding.clSwitchFakeVault.visibility = VISIBLE
                mBinding.dividerSwitchToFakeVault.visibility = VISIBLE
            }

        } else {
            mBinding.dividerRemoveLock.visibility = GONE
            mBinding.clUnlockWithFingerPrint.visibility = GONE
            if (config.isFakeVaultEnable) {
                mBinding.clSwitchFakeVault.visibility = VISIBLE
                mBinding.dividerSwitchToFakeVault.visibility = VISIBLE
            } else {
                mBinding.clSwitchFakeVault.visibility = GONE
                mBinding.dividerSwitchToFakeVault.visibility = GONE
            }

        }
        if (config.isFakeVaultEnable) {
            isEnableFakeVault = false
            mBinding.imgFakeVaultRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_on))
            mBinding.tvFakeVaultPassword.visibility = VISIBLE
            mBinding.tvFakeVaultPassword.text = getString(R.string.label_fake_vault_password, config.fakeVaultAppLock)
        } else {
            isEnableFakeVault = true
            mBinding.imgFakeVaultRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_off))
            mBinding.tvFakeVaultPassword.visibility = GONE
        }
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.clChangePin -> {
                if (config.isAppPasswordProtectionOn) {
                    val intent = Intent(this, CustomPinActivity::class.java)
                    intent.putExtra(AppLock.EXTRA_TYPE, AppLock.CHANGE_PIN)
                    intent.putExtra("ChangePatternLock", false)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    launchActivityForResult(intent, REQUEST_CODE_CHANGE_PASSWORD)
                } else {
                    Toast.makeText(this, getString(R.string.error_enable_lock), Toast.LENGTH_SHORT).show()
                }
            }
            R.id.clChangeSecQue -> {
                val intent = Intent(this, CustomPinActivity::class.java)
                intent.putExtra(AppLock.EXTRA_TYPE, AppLock.UNLOCK_PIN)
                launchActivityForResult(intent, REQUEST_CODE_CHECK)
            }
            R.id.clRemoveLock -> {
                if (config.isAppPasswordProtectionOn) {
                    val intent = Intent(this, CustomPinActivity::class.java)
                    intent.putExtra(AppLock.EXTRA_TYPE, AppLock.DISABLE_PINLOCK)
                    intent.putExtra("ChangePatternLock", false)
                    launchActivityForResult(intent, REQUEST_CODE_DISABLE_PASSWORD)
                }
            }
            R.id.clFeedBack -> {
                isUnLockApp = true
                sendEmail()
            }
            R.id.clRemoveAds -> {
                isUnLockApp = true

                val intent = Intent(this, SubscriptionActivity::class.java)
                startActivity(intent)

            }
            R.id.clSwitchFakeVault -> {
                config.isSwitchFakeVaultClicked = true
                mBinding.imgNewFun.beGone()
                VaultFragment.isTabUnlock = false
                VaultFragment.isFirstTime = true
                finish()
            }
            R.id.clHelp->{
                startActivity(Intent(this, HelpFAQActivity::class.java))
            }

        }
    }


    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)

        when (requestCode) {
            REQUEST_CODE_CHECK_PASSWORD -> {
                if (resultCode == RESULT_OK) {
                    Toast.makeText(this, getString(R.string.msg_lock_change_sccessfully), Toast.LENGTH_SHORT).show()

                }
            }
            REQUEST_CODE_ENABLE_FAKE_VAULT -> {
                if (resultCode == RESULT_OK) {
                    config.isFakeVaultEnable = true
                    Toast.makeText(this, getString(R.string.msg_fake_vault_set_successfully), Toast.LENGTH_SHORT).show()

                }
            }
            REQUEST_CODE_DISABLE_PASSWORD -> {
                if (!LockSettings.isPinLockAvl()) {
                    Toast.makeText(
                        this, getString(R.string.msg_lock_remove), Toast.LENGTH_SHORT
                    ).show()
                    config.isAppPasswordProtectionOn = false
                    config.isBatterySecureLock = false
                    config.isChargerSecureLock = false
                    finish()
                }
            }
            REQUEST_CODE_CHECK -> {
                if (resultCode == RESULT_OK) {
                    SetSecurityQuestionDialog(this as BaseSimpleActivity) {
                        Toast.makeText(this, getString(R.string.msg_security_que_ans_change_success), Toast.LENGTH_SHORT).show()
                    }
                }

            }

        }
    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun onPurchasedSuccess(purchase: Purchase) {
        Log.i("TAG", "purchase")
        if (window.decorView.isShown)
            showPurchaseSuccess()
        removeAds()

    }

    private fun removeAds() {
        mBinding.clRemoveAds.visibility = GONE

        mBinding.dividerClRemoveAd.visibility = GONE
    }

    override fun onProductAlreadyOwn() {
        Log.i("TAG", "already purchase")
        showPurchaseSuccess()
        removeAds()
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        GlobalScope.launch(Dispatchers.Main) {
            InAppPurchaseHelper.instance!!.initProducts()
            Log.i("TAG", "IN_APP_BILLING | Done")
        }
    }

    override fun onBackPressed() {
        VaultFragment.isTabUnlock = true
        VaultFragment.isNeedToShowHiddenByGallery = true
        super.onBackPressed()
    }

    override fun onBillingUnavailable() {

    }

    override fun onBillingKeyNotFound(productId: String) {

    }

    override fun setBinding(): ActivityVaultSettingsBinding {
        return ActivityVaultSettingsBinding.inflate(inflater)
    }


}