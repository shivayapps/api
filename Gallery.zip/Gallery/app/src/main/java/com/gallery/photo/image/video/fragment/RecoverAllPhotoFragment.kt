package com.gallery.photo.image.video.fragment

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.RecoverPhotoDateWiseActivity
import com.gallery.photo.image.video.activity.RecoverPhotoNewActivity
import com.gallery.photo.image.video.adapter.RecoverPhotoAdapter
import com.gallery.photo.image.video.databinding.FragmentRecoverAllPhotoBinding
import com.gallery.photo.image.video.dialog.NewRateDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.models.ThumbnailSection
import com.gallery.photo.image.video.rateandfeedback.*
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.helpers.VIEW_TYPE_GRID
import com.gallery.photo.image.video.helpers.VIEW_TYPE_LIST
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.rateandfeedback.library_feedback.sendEmail
import com.gallery.photo.image.video.views.MyGridLayoutManager
import com.gallery.photo.image.video.views.MyRecyclerView


class RecoverAllPhotoFragment : BaseBindingFragment<FragmentRecoverAllPhotoBinding>(), MediaOperationsListener {


    var title: String? = null
    var isFromOneSignal = false
    var isFromSettings = false
    var isScanFinished = false
    val mPermissionStorage = arrayOf(
        android.Manifest.permission.READ_EXTERNAL_STORAGE,
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
    )

    //Add New
    private var mPath = ""
    private var mIsGetImageIntent = false
    private var mIsGetVideoIntent = false
    private var mIsGetAnyIntent = false
    private var mIsGettingMedia = false
    private var mAllowPickingMultiple = false
    private var mShowAll = true
    private var mShowAllGroup = false
    private var mDateFormat = ""
    private var mTimeFormat = ""
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mLastSearchedText = ""
    var isRateDialogDisplay = false
    var isRateDialogDisplayed = false

    companion object {
        var isNeedToRefresh = false

        @JvmStatic
        fun newInstance() =
            RecoverAllPhotoFragment().apply {
            }
    }

    override fun setBinding(layoutInflater: LayoutInflater, container: ViewGroup?): FragmentRecoverAllPhotoBinding {
        return FragmentRecoverAllPhotoBinding.inflate(layoutInflater, container, false)
    }

    override fun initView() {
        super.initView()
        mBinding.mediaRefreshLayout.setOnRefreshListener { getMedia() }
        getMedia()
    }


    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume: isNeedToRefresh" + isNeedToRefresh)
        if (isNeedToRefresh) {
            isNeedToRefresh = false
            getMedia()
        }
    }


    private fun getMedia() {
        startAsyncTask()

    }

    private fun startAsyncTask() {

        mBinding.lottieProgressbar.visibility = View.VISIBLE
        requireContext().getRecoverMedia(mPath, mIsGetImageIntent, mIsGetVideoIntent, mShowAll, TYPE_IMAGES, GROUP_BY_LAST_MODIFIED_DAILY, false, mShowAllGroup, isFromTimeLine = false) {
            ensureBackgroundThread {
                val oldMedia = RecoverPhotoNewActivity.mMedia.clone() as ArrayList<ThumbnailItem>
                val newMedia = it
                try {
                    Log.d("recoverphoto1232", "setupAdapter: " + newMedia.size)
                    gotMedia(newMedia, false)

                    requireActivity().runOnUiThread {
                        Handler(Looper.getMainLooper()).postDelayed({
                            mBinding.lottieProgressbar.visibility = View.GONE
                            if (!isRateDialogDisplay) {
                                if (isAdded) {
                                    val sp = ExitSPHelper(mContext)
                                    if (!sp.isRated() && !isRateDialogDisplayed && mContext.config.recoverCountForRate >= RECOVER_COUNT_FOR_RATE_VAL) {
                                        isRateDialogDisplay = true
                                        isRateDialogDisplayed = true
                                        NewRateDialog(mContext){
                                            if (it > 3) {
                                                mContext.rateApp()
                                            } else if (it >= 0) {
                                                mContext.sendEmail()
                                            }
                                        }
                                        /*mContext.ratingDialog(object : OnRateListener {
                                            override fun onRate(rate: Int) {
                                                isRateDialogDisplay = false
                                                if (rate >= 3) {
                                                    mContext.rateApp()
                                                } else if (rate >= 0) {
                                                    startActivity(FeedbackActivity.newIntent(mContext, rate))
                                                }
                                            }
                                        })*/
                                    }
                                }
                            }

                        }, 500)
                    }
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun gotMedia(media: ArrayList<ThumbnailItem>, isFromCache: Boolean) {
        mIsGettingMedia = false
        RecoverPhotoNewActivity.mMedia = media

        requireActivity().runOnUiThread {
            mBinding.mediaRefreshLayout.isRefreshing = false
            mBinding.mediaEmptyTextPlaceholder.beVisibleIf(media.isEmpty() && !isFromCache)
            mBinding.tvPleaseWait.beGone()

            if (mBinding.mediaEmptyTextPlaceholder.isVisible()) {
                mBinding.mediaEmptyTextPlaceholder.text = getString(R.string.no_media_with_filters)
            }
            mBinding.mediaGrid.beVisibleIf(mBinding.mediaEmptyTextPlaceholder.isGone())

            val viewType = mContext.config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            val allowHorizontalScroll = mContext.config.scrollHorizontally && viewType == VIEW_TYPE_GRID
            mBinding.mediaVerticalFastscroller.beVisibleIf(mBinding.mediaGrid.isVisible() && !allowHorizontalScroll)
            mBinding.mediaVerticalFastscroller.beVisibleIf(mBinding.mediaGrid.isVisible() && allowHorizontalScroll)
            setupAdapter()
        }

    }

    private fun getMediaAdapter() = mBinding.mediaGrid.adapter as? RecoverPhotoAdapter

    private fun setupAdapter() {
        isScanFinished = true
        mBinding.mediaRefreshLayout.isEnabled = true
        if (!mShowAll && isDirEmpty()) {
            return
        }
        Log.d("recoverphoto1232", "setupAdapter: " + RecoverPhotoNewActivity.mMedia.size)

        val currAdapter = mBinding.mediaGrid.adapter
        if (currAdapter == null) {

            val fastscroller = if (mContext.config.scrollHorizontally) mBinding.mediaHorizontalFastscroller else mBinding.mediaVerticalFastscroller
            RecoverPhotoAdapter(
                mContext as BaseSimpleActivity, RecoverPhotoNewActivity.mMedia.clone() as ArrayList<ThumbnailItem>, this, mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent,
                mAllowPickingMultiple, mPath, mBinding.mediaGrid, fastscroller, false
            ) {
                Log.d("ItemClick", "setupAdapter: item Position " + it)
                Log.d("ItemClick", "setupAdapter: item object " + RecoverPhotoNewActivity.mMedia[it as Int])
                itemClicked(RecoverPhotoNewActivity.mMedia[it as Int])
            }.apply {
                mBinding.mediaGrid.adapter = this
            }

            val viewType = mContext.config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            if (viewType == VIEW_TYPE_LIST) {
                mBinding.mediaGrid.scheduleLayoutAnimation()
            }

            setupLayoutManager()
            handleGridSpacing()
        } else if (mLastSearchedText.isEmpty()) {

            (currAdapter as RecoverPhotoAdapter).updateMedia(RecoverPhotoNewActivity.mMedia)
            handleGridSpacing()
        }

        setupScrollDirection()
    }

    private fun itemClicked(item: ThumbnailItem) {
        var title = if (item is ThumbnailSection) {
            (item as ThumbnailSection).title
        } else {
            (item as Medium).titleForRecover
        }
        startActivity(Intent(mContext, RecoverPhotoDateWiseActivity::class.java).putExtra(PATH, title))
    }

    private fun isDirEmpty(): Boolean {
        return RecoverPhotoNewActivity.mMedia.size <= 0 && mContext.config.filterMedia > 0
    }

    private fun setupLayoutManager() {
        val viewType = mContext.config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            setupGridLayoutManager()
        } else {
            setupListLayoutManager()
        }
    }

    private fun setupGridLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = 0
            bottomMargin = 0
        }

        if (mContext.config.scrollHorizontally) {
            layoutManager.orientation = RecyclerView.HORIZONTAL
        } else {
            layoutManager.orientation = RecyclerView.VERTICAL
        }

//        layoutManager.spanCount = mContext.config.mediaColumnCnt
        layoutManager.spanCount = 3
        val adapter = getMediaAdapter()
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter?.isASectionTitle(position) == true) {
                    layoutManager.spanCount
                } else {
                    1
                }
            }
        }
    }

    private fun setupScrollDirection() {
        val viewType = mContext.config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        val allowHorizontalScroll = mContext.config.scrollHorizontally && viewType == VIEW_TYPE_GRID
        mBinding.mediaVerticalFastscroller.isHorizontal = false
        mBinding.mediaVerticalFastscroller.beGoneIf(allowHorizontalScroll)

        mBinding.mediaHorizontalFastscroller.isHorizontal = true
        mBinding.mediaHorizontalFastscroller.beVisibleIf(allowHorizontalScroll)

        val sorting = mContext.config.getFolderSorting(if (mShowAll) SHOW_ALL else mPath)
        if (allowHorizontalScroll) {
            mBinding.mediaHorizontalFastscroller.setViews(mBinding.mediaGrid, mBinding.mediaRefreshLayout) {
                mBinding.mediaHorizontalFastscroller.updateBubbleText(getBubbleTextItem(it, sorting!!))
            }
        } else {
            mBinding.mediaVerticalFastscroller.setViews(mBinding.mediaGrid, mBinding.mediaRefreshLayout) {
                mBinding.mediaVerticalFastscroller.updateBubbleText(getBubbleTextItem(it, sorting!!))
            }
        }
    }

    private fun handleGridSpacing(media: ArrayList<ThumbnailItem> = RecoverPhotoNewActivity.mMedia) {
        val viewType = mContext.config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            val spanCount = mContext.config.mediaColumnCnt
            val spacing = mContext.config.thumbnailSpacing
            val useGridPosition = media.firstOrNull() is ThumbnailSection

            var currentGridDecoration: GridSpacingItemDecoration? = null
            if (mBinding.mediaGrid.itemDecorationCount > 0) {
                currentGridDecoration = mBinding.mediaGrid.getItemDecorationAt(0) as GridSpacingItemDecoration
                currentGridDecoration.items = media
            }

            val newGridDecoration = GridSpacingItemDecoration(spanCount, spacing, mContext.config.scrollHorizontally, mContext.config.fileRoundedCorners, media, useGridPosition)
            if (currentGridDecoration.toString() != newGridDecoration.toString()) {
                if (currentGridDecoration != null) {
                    mBinding.mediaGrid.removeItemDecoration(currentGridDecoration)
                }
                mBinding.mediaGrid.addItemDecoration(newGridDecoration)
            }
        }
    }

    private fun getBubbleTextItem(index: Int, sorting: Int): String {
        var realIndex = index
        val mediaAdapter = getMediaAdapter()
        if (mediaAdapter!!.isASectionTitle(index)) {
            realIndex++
        }
        return mediaAdapter.getItemBubbleText(realIndex, sorting, mDateFormat, mTimeFormat) ?: ""
    }


    private fun setupListLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL

        val smallMargin = resources.getDimension(R.dimen.small_margin).toInt()
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = smallMargin
            bottomMargin = smallMargin
        }

        mZoomListener = null
    }

    override fun refreshItems() {

    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {

    }

    override fun selectedPaths(paths: ArrayList<String>) {

    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {

    }

}