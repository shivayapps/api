package com.gallery.photo.image.video.activity

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.AsyncTask
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.text.HtmlCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.example.jdrodi.utilities.isOnline
import com.flask.colorpicker.ColorPickerView
import com.flask.colorpicker.builder.ColorPickerDialogBuilder
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activityBinding.BaseBindingActivity
import com.gallery.photo.image.video.adapter.FontAdapter
import com.gallery.photo.image.video.databinding.ActivityFontBinding
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.retrofit.APIService
import com.gallery.photo.image.video.retrofit.DowloadUnzip
import com.gallery.photo.image.video.retrofit.model.StickerFont
import com.gallery.photo.image.video.stickerView.DrawableSticker
import com.gallery.photo.image.video.utilities.COLOR
import com.gallery.photo.image.video.utilities.FONT_FLAG
import com.gallery.photo.image.video.utilities.FONT_TEXT
import com.gallery.photo.image.video.utilities.TEXT_DRAWABLE
import com.gallery.photo.image.video.extensions.baseConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.*
import java.util.*


class FontActivity : BaseBindingActivity<ActivityFontBinding>() {

    private val font_array: ArrayList<String> = ArrayList<String>()

    public var base_path = ""
    public var zip_name = ""
    var fontDowload: DowloadUnzip? = null

    interface OnEventListener {
        fun onEvent(event: Int, message: String)
    }

    var eventListener: OnEventListener? = null


    override fun setBinding(): ActivityFontBinding {
        return ActivityFontBinding.inflate(inflater)
    }

    override fun initData() {

        eventListener = object : OnEventListener {
            override fun onEvent(event: Int, message: String) {

                Log.d("reqStickerFont", "onEvent:$event")
                if (event == 1) {

                    mBinding.relProgress.visibility = View.GONE
                    mBinding.relNoInternet.visibility = View.GONE

                    //base_path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).path
                    base_path = "/data/data/" + mContext.packageName + "/stickerfont"

                    Log.d("reqStickerFont", "init zip_name:$zip_name")
                    Log.d("reqStickerFont", "init base_path:$base_path")

                    val directory = File("${base_path}/${zip_name}")
                    val files = directory.listFiles()
                    for (i in files.indices) {
                        Log.d("reqStickerFont", "FileName:" + files[i].name)
                        font_array.add(files[i].path)
                    }

                    val gridLayoutManager = GridLayoutManager(this@FontActivity, 3)
                    mBinding.rvFont.layoutManager = gridLayoutManager

                    val fontAdapter = FontAdapter(this@FontActivity, font_array)
                    mBinding.rvFont.adapter = fontAdapter

                    fontAdapter.setEventListener(object : FontAdapter.EventListener {
                        override fun onItemViewClicked(position: Int) {
                            if (position < font_array.size) {
                                val face = Typeface.createFromFile(font_array[position])
                                mBinding.etText.typeface = face
                            }
                        }

                        override fun onDeleteMember(position: Int) {}
                    })
                }
            }
        }

        setupFont()
    }


    private fun setupFont() {
        zip_name = baseConfig.fontZip
        if (zip_name.isNotEmpty()) {

            val checkFile = "/data/data/" + mContext.packageName + "/stickerfont/${zip_name}"
            if (File(checkFile).exists()) {
                Log.d("reqStickerFont", "zip exists:$zip_name")
                eventListener?.onEvent(1, "done")
            } else {
                Log.d("reqStickerFont", "zip not exists:$zip_name")
                if (isOnline()) {
                    getStickerFont()
                } else {
                    mBinding.relNoInternet.visibility = View.VISIBLE
                }
            }
        } else {
            Log.d("reqStickerFont", "init zip_name:$zip_name")
            if (isOnline()) {
                getStickerFont()
            } else {
                mBinding.relNoInternet.visibility = View.VISIBLE
            }
        }
    }

    private fun getStickerFont() {
        Log.d("reqStickerFont", "getStickerFont:")

        if (fontDowload?.status == AsyncTask.Status.RUNNING) {
            //overlayDialog?.dialog?.show()
            mBinding.relProgress.visibility = View.VISIBLE
            mBinding.relNoInternet.visibility = View.GONE
        } else {
            mBinding.relProgress.visibility = View.VISIBLE
            mBinding.relNoInternet.visibility = View.GONE
            val apiInterface = APIService().getEditorClient(this@FontActivity)
            val call: Call<StickerFont> = apiInterface.doGetStickerFontList()
            call.enqueue(object : Callback<StickerFont> {
                override fun onResponse(call: Call<StickerFont>, response: Response<StickerFont>) {
                    if (response.isSuccessful) {
                        Log.e("reqStickerFont", "response:" + response.body())

                        val zipurl = response.body()?.data?.responseData?.fonts?.path!!
                        zip_name = zipurl.substring(zipurl.lastIndexOf('/') + 1, zipurl.lastIndexOf('.'))
                        baseConfig.fontZip = zip_name

                        fontDowload = DowloadUnzip(this@FontActivity)
                        fontDowload?.setDownloadListener { event, position, message ->

                            if (event == 3) {
                                eventListener?.onEvent(1, "done")
                                mBinding.relProgress.visibility = View.GONE
                                mBinding.relNoInternet.visibility = View.GONE
                                //Toast.makeText(this@FontActivity,"Download Complete",Toast.LENGTH_SHORT).show()
                            } else if (event == 1) {
                                mBinding.relProgress.visibility = View.VISIBLE
                                mBinding.relNoInternet.visibility = View.GONE
                                mBinding.txtProgress.text = getString(R.string.label_downloading_font, "$position%")
//                            pbProgress.setProgress(position)
                            } else {
                                if (event != 2) {
                                    mBinding.relNoInternet.visibility = View.VISIBLE
                                }
                                mBinding.relProgress.visibility = View.GONE
                            }
                            Log.e("reqStickerFont", "dowload progress event:" + event)
                            Log.e("reqStickerFont", "dowload progress position:" + position)
                        }

                        fontDowload?.download(zipurl)

                    } else {
                        Log.e("reqStickerFont", "Connection failed 001:" + response.errorBody())
                        Log.e("reqStickerFont", "Connection failed 002:" + response.message())
                    }
                }

                override fun onFailure(call: Call<StickerFont>, t: Throwable) {
                    Toast.makeText(this@FontActivity, getString(R.string.error_check_internet), Toast.LENGTH_SHORT).show()
                    mBinding.relNoInternet.visibility = View.VISIBLE
                    t.printStackTrace()
                    Log.e("reqStickerFont", "onFailure02:${t.message!!}")
                }
            })
        }

    }


    override fun initActions() {
        mBinding.ivColor.setOnClickListener(this)
        mBinding.ivDone.setOnClickListener(this)
        mBinding.ivClose.setOnClickListener(this)
        mBinding.btnRetry.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.iv_color -> {
                hideKeyboard(this@FontActivity)
                ColorPickerDialogBuilder
                    .with(this@FontActivity)
                    .setTitle("Choose color")
                    .wheelType(ColorPickerView.WHEEL_TYPE.FLOWER)
                    .density(12)
                    .setOnColorSelectedListener { }
                    .setPositiveButton(
                        HtmlCompat.fromHtml("<b>" + "OK" + "<b>", HtmlCompat.FROM_HTML_MODE_LEGACY)
                    ) { dialog, selectedColor, allColors ->
                        mBinding.etText.setTextColor(selectedColor)
//                        Share.COLOR = selectedColor
                    }
                    .setNegativeButton(
                        HtmlCompat.fromHtml("<b>" + "CANCEL" + "<b>", HtmlCompat.FROM_HTML_MODE_LEGACY)
                    ) { dialog, which -> }
                    .build()
                    .show()
            }
            R.id.iv_done -> {
                val str = mBinding.etText.text.toString().trim()
                if (str.length != 0) {
                    val b2: Bitmap = createBitmapFromLayoutWithText(applicationContext, mBinding.etText.text.toString(), mBinding.etText.currentTextColor, 0, mBinding.etText.typeface)
                    val d: Drawable = BitmapDrawable(resources, b2)
                    if (str != "") {
                        FONT_FLAG = true
                        FONT_TEXT = mBinding.etText.text.toString()
                        finish()
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    } else {
                        Toast.makeText(applicationContext, getString(R.string.error_please_enter_text), Toast.LENGTH_LONG).show()
                    }
                    val sticker = DrawableSticker(d)
//                    val face = Typeface.createFromAsset(assets, "$selectedFont.ttf")
                    if (COLOR === 0) {
                        COLOR = resources.getColor(R.color.colorPrimary)
                    }
                    TEXT_DRAWABLE = sticker
                } else {
                    Toast.makeText(this, getString(R.string.error_please_enter_text), Toast.LENGTH_LONG).show()
                }
            }
            R.id.iv_close -> {
                onBackPressed()
            }
            R.id.btnRetry -> {
                setupFont()
            }
        }
    }

    private fun createBitmapFromLayoutWithText(context: Context, s: String, color: Int, i: Int, face: Typeface?): Bitmap {
        val mInflater = context.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view: View = mInflater.inflate(R.layout.row_bitmap, null)
        val tv = view.findViewById<View>(R.id.tv_custom_text1) as TextView
        var j = 0
        while (j < s.length) {
            if (s.length >= 40) {
                if (j <= s.length - 40) {
                    if (j == 0) {
                        val m = s.substring(0, 40)
                        tv.text = m
                    } else {
                        tv.append("\n")
                        val l = s.substring(j, j + 40)
                        tv.append(l)
                    }
                } else {
                    tv.append("\n")
                    val l = s.substring(j, s.length)
                    tv.append(l)
                }
            } else {
                tv.text = s
            }
            j += 40
        }
        tv.setTextColor(color)
        tv.typeface = face
        view.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT)
        view.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        view.layout(0, 0, view.measuredWidth, view.measuredHeight)
        val bitmap = Bitmap.createBitmap(view.measuredWidth, view.measuredHeight, Bitmap.Config.ARGB_8888)
        val c = Canvas(bitmap)
        view.draw(c)
        return bitmap
    }

    private fun hideKeyboard(activity: Activity) {
        val view = activity.findViewById<View>(android.R.id.content)
        if (view != null) {
            val imm = activity.getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }
    }


    override fun getContext(): Activity {
        return this
    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName(): String {
        return getString(R.string.app_name)
    }


}