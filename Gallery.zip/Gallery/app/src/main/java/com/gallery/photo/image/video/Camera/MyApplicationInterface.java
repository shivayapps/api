package com.gallery.photo.image.video.Camera;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.location.Location;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Pair;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Keep;
import androidx.exifinterface.media.ExifInterface;

import com.gallery.photo.image.video.Camera.cameracontroller.CameraController;
import com.gallery.photo.image.video.Camera.cameracontroller.RawImage;

import com.gallery.photo.image.video.Camera.preview.BasicApplicationInterface;
import com.gallery.photo.image.video.Camera.preview.Preview;
import com.gallery.photo.image.video.Camera.preview.VideoProfile;
import com.gallery.photo.image.video.Camera.ui.DrawPreview;
import com.gallery.photo.image.video.R;
import com.gallery.photo.image.video.cameraview.ui.helper.HelperClass;
import com.gallery.photo.image.video.utilities.SharedPrefs;
//import com.google.firebase.analytics.FirebaseAnalytics;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

@Keep
public class MyApplicationInterface extends BasicApplicationInterface {
    private static final String TAG = "MyApplicationInterface";
    private static final float aperture_default = -1.0f;
    private static final int cameraId_default = 0;
    public static final int max_panorama_pics_c = 10;
    private static final String nr_mode_default = "preference_nr_mode_normal";
    private static final float panorama_pics_per_screen = 3.33333f;
    private int DH;
    private int DW;
    private float aperture = -1.0f;
    private int cameraId = 0;
    private final DrawPreview drawPreview;
    /* access modifiers changed from: private */
    public final GyroSensor gyroSensor;
    private boolean has_set_cameraId;
    private final ImageSaver imageSaver;
    Bitmap imagecompress;
    private final List<LastImage> last_images = new ArrayList();
    private boolean last_images_saf;
    private LastImagesType last_images_type = LastImagesType.FILE;
    /* access modifiers changed from: private */
    public File last_video_file = null;
    private Uri last_video_file_saf = null;
    /* access modifiers changed from: private */
    public Uri last_video_file_uri = null;
    private final LocationSupplier locationSupplier;
    private HelperClass mHelperClass;

    TypedArray mWeatherIcon;
    /* access modifiers changed from: private */
    public final CameraActivity main_activity;
    private int n_capture_images = 0;
    private int n_capture_images_raw = 0;
    /* access modifiers changed from: private */
    public int n_panorama_pics = 0;
    private String nr_mode = nr_mode_default;
    /* access modifiers changed from: private */
    public boolean panorama_dir_left_to_right = true;
    private boolean panorama_pic_accepted;
    private final ToastBoxer photo_delete_toast = new ToastBoxer();
    float scale;
    Bitmap stampBitmap;
    /* access modifiers changed from: private */
    public final StorageUtils storageUtils;
    private final Timer subtitleVideoTimer = new Timer();
    private TimerTask subtitleVideoTimerTask;
    public long test_available_memory = 0;
    public volatile int test_max_mp;
    public volatile int test_n_videos_scanned;
    public boolean test_set_available_memory = false;
    private final Rect text_bounds = new Rect();
    private boolean used_front_screen_flash;
    private int zoom_factor;

    public enum Alignment {
        ALIGNMENT_TOP,
        ALIGNMENT_CENTRE,
        ALIGNMENT_BOTTOM
    }

    private enum LastImagesType {
        FILE,
        SAF,
        MEDIASTORE
    }

    public enum PhotoMode {
        Standard,
        DRO,
        HDR,
        ExpoBracketing,
        FocusBracketing,
        FastBurst,
        NoiseReduction,
        Panorama
    }

    public enum Shadow {
        SHADOW_NONE,
        SHADOW_OUTLINE,
        SHADOW_BACKGROUND
    }

    static float getPanoramaPicsPerScreen() {
        return panorama_pics_per_screen;
    }

    private static class LastImage {
        final String name;
        final boolean share;
        Uri uri;

        LastImage(Uri uri2, boolean z) {
            this.name = null;
            this.uri = uri2;
            this.share = z;
        }

        LastImage(String str, boolean z) {
            this.name = str;
            if (Build.VERSION.SDK_INT >= 24) {
                this.uri = null;
            } else {
                this.uri = Uri.parse("file://" + str);
            }
            this.share = z;
        }
    }

    public MyApplicationInterface(CameraActivity cameraActivity, Bundle bundle) {
        Log.d(TAG, TAG);
        long currentTimeMillis = System.currentTimeMillis();
        this.main_activity = cameraActivity;
        this.mHelperClass = new HelperClass();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        cameraActivity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.DW = displayMetrics.heightPixels;
        this.DH = displayMetrics.widthPixels;
        this.scale = displayMetrics.scaledDensity;


        this.locationSupplier = new LocationSupplier(cameraActivity);
        Log.d(TAG, "MyApplicationInterface: time after creating location supplier: " + (System.currentTimeMillis() - currentTimeMillis));
        this.gyroSensor = new GyroSensor(cameraActivity);
        this.storageUtils = new StorageUtils(cameraActivity, this);
        Log.d(TAG, "MyApplicationInterface: time after creating storage utils: " + (System.currentTimeMillis() - currentTimeMillis));
        this.drawPreview = new DrawPreview(cameraActivity, this);
        ImageSaver imageSaver2 = new ImageSaver(cameraActivity);
        this.imageSaver = imageSaver2;
        imageSaver2.start();
        reset(false);
        if (bundle != null) {
            Log.d(TAG, "read from savedInstanceState");
            this.has_set_cameraId = true;
            this.cameraId = bundle.getInt("cameraId", 0);
            Log.d(TAG, "found cameraId: " + this.cameraId);
            this.nr_mode = bundle.getString("nr_mode", nr_mode_default);
            Log.d(TAG, "found nr_mode: " + this.nr_mode);
            this.aperture = bundle.getFloat("aperture", -1.0f);
            Log.d(TAG, "found aperture: " + this.aperture);
        }
        Log.d(TAG, "MyApplicationInterface: total time to create MyApplicationInterface: " + (System.currentTimeMillis() - currentTimeMillis));
    }

    public void onSaveInstanceState(Bundle bundle) {
        Log.d(TAG, "onSaveInstanceState");
        Log.d(TAG, "save cameraId: " + this.cameraId);
        bundle.putInt("cameraId", this.cameraId);
        Log.d(TAG, "save nr_mode: " + this.nr_mode);
        bundle.putString("nr_mode", this.nr_mode);
        Log.d(TAG, "save aperture: " + this.aperture);
        bundle.putFloat("aperture", this.aperture);
    }

    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        DrawPreview drawPreview2 = this.drawPreview;
        if (drawPreview2 != null) {
            drawPreview2.onDestroy();
        }
        ImageSaver imageSaver2 = this.imageSaver;
        if (imageSaver2 != null) {
            imageSaver2.onDestroy();
        }
    }

    public LocationSupplier getLocationSupplier() {
        return this.locationSupplier;
    }

    public GyroSensor getGyroSensor() {
        return this.gyroSensor;
    }

    public StorageUtils getStorageUtils() {
        return this.storageUtils;
    }

    public ImageSaver getImageSaver() {
        return this.imageSaver;
    }

    public DrawPreview getDrawPreview() {
        return this.drawPreview;
    }

    public Context getContext() {
        return this.main_activity;
    }

    public boolean useCamera2() {
        return this.main_activity.supportsCamera2() && "preference_camera_api_camera2".equals(SharedPrefs.getString(main_activity, PreferenceKeys.CameraAPIPreferenceKey, PreferenceKeys.CameraAPIPreferenceDefault));
    }

    public Location getLocation() {
        return this.locationSupplier.getLocation();
    }

    public VideoMethod createOutputVideoMethod() {
        Uri uri;
        if (isVideoCaptureIntent()) {
            Log.d(TAG, "from video capture intent");
            Bundle extras = this.main_activity.getIntent().getExtras();
            if (extras == null || (uri = (Uri) extras.getParcelable("output")) == null) {
                Log.d(TAG, "intent uri not specified");
                if (CameraActivity.useScopedStorage()) {
                    return VideoMethod.MEDIASTORE;
                }
                return VideoMethod.FILE;
            }
            Log.d(TAG, "save to: " + uri);
            return VideoMethod.URI;
        } else if (this.storageUtils.isUsingSAF()) {
            return VideoMethod.SAF;
        } else {
            if (CameraActivity.useScopedStorage()) {
                return VideoMethod.MEDIASTORE;
            }
            return VideoMethod.FILE;
        }
    }

    /* access modifiers changed from: package-private */
    public boolean isVideoCaptureIntent() {
        if (!"android.media.action.VIDEO_CAPTURE".equals(this.main_activity.getIntent().getAction())) {
            return false;
        }
        Log.d(TAG, "from video capture intent");
        return true;
    }

    public File createOutputVideoFile(String str) throws IOException {
        File createOutputMediaFile = this.storageUtils.createOutputMediaFile(2, "", str, new Date());
        this.last_video_file = createOutputMediaFile;
        return createOutputMediaFile;
    }

    public Uri createOutputVideoSAF(String str) throws IOException {
        Uri createOutputMediaFileSAF = this.storageUtils.createOutputMediaFileSAF(2, "", str, new Date());
        this.last_video_file_uri = createOutputMediaFileSAF;
        return createOutputMediaFileSAF;
    }

    public Uri createOutputVideoMediaStore(String str) throws IOException {
        Uri contentUri = Build.VERSION.SDK_INT >= 29 ? MediaStore.Video.Media.getContentUri("external_primary") : MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        ContentValues contentValues = new ContentValues();
        StorageUtils storageUtils2 = this.storageUtils;
        String createMediaFilename = storageUtils2.createMediaFilename(2, "", 0, "." + str, new Date());
        Log.d(TAG, "filename: " + createMediaFilename);
        contentValues.put("_display_name", createMediaFilename);
        String videoMimeType = this.storageUtils.getVideoMimeType(str);
        Log.d(TAG, "mime_type: " + videoMimeType);
        contentValues.put("mime_type", videoMimeType);
        if (Build.VERSION.SDK_INT >= 29) {
            String saveRelativeFolder = this.storageUtils.getSaveRelativeFolder();
            Log.d(TAG, "relative_path: " + saveRelativeFolder);
            contentValues.put("relative_path", saveRelativeFolder);
            contentValues.put("is_pending", 1);
        }
        this.last_video_file_uri = this.main_activity.getContentResolver().insert(contentUri, contentValues);
        Log.d(TAG, "uri: " + this.last_video_file_uri);
        Uri uri = this.last_video_file_uri;
        if (uri != null) {
            return uri;
        }
        throw new IOException();
    }

    public Uri createOutputVideoUri() {
        Uri uri;
        if ("android.media.action.VIDEO_CAPTURE".equals(this.main_activity.getIntent().getAction())) {
            Log.d(TAG, "from video capture intent");
            Bundle extras = this.main_activity.getIntent().getExtras();
            if (!(extras == null || (uri = (Uri) extras.getParcelable("output")) == null)) {
                Log.d(TAG, "save to: " + uri);
                return uri;
            }
        }
        throw new RuntimeException();
    }

    public int getFlashPref_Pos() {
        return SharedPrefs.getInt(main_activity, PreferenceKeys.getFlashPreferenceKey_Pos(this.cameraId), 0);
    }

    public void setFlashPref_Pos(int i) {
        SharedPrefs.save(main_activity, PreferenceKeys.getFlashPreferenceKey_Pos(this.cameraId), i);
    }

    public int getCameraIdPref() {
        return this.cameraId;
    }

    public String getFlashPref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.getFlashPreferenceKey(this.cameraId), "");
    }

    public String getFocusPref(boolean z) {
        if (getPhotoMode() != PhotoMode.FocusBracketing || this.main_activity.getPreview().isVideo()) {
            return SharedPrefs.getString(main_activity, PreferenceKeys.getFocusPreferenceKey(this.cameraId, z), "");
        }
        return "focus_mode_manual2";
    }

    /* access modifiers changed from: package-private */
    public int getFocusAssistPref() {
        int i;
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.FocusAssistPreferenceKey, "0");
        try {
            i = Integer.parseInt(string);
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse focus_assist_value: " + string);
            e.printStackTrace();
            i = 0;
        }
        if (i <= 0 || !this.main_activity.getPreview().isVideoRecording()) {
            return i;
        }
        return 0;
    }

    public boolean isVideoPref() {
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.IsVideoPreferenceKey, false);
    }

    public String getSceneModePref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.SceneModePreferenceKey, "auto");
    }

    public String getColorEffectPref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.ColorEffectPreferenceKey, "none");
    }

    public String getWhiteBalancePref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.WhiteBalancePreferenceKey, "auto");
    }

    public int getWhiteBalanceTemperaturePref() {
        return SharedPrefs.getInt(main_activity, PreferenceKeys.WhiteBalanceTemperaturePreferenceKey, 5000);
    }

    public String getAntiBandingPref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.AntiBandingPreferenceKey, "auto");
    }

    public String getEdgeModePref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.EdgeModePreferenceKey, "default");
    }

    public String getCameraNoiseReductionModePref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.CameraNoiseReductionModePreferenceKey, "default");
    }

    public String getISOPref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.ISOPreferenceKey, "auto");
    }

    public int getExposureCompensationPref() {
        int i;
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.ExposurePreferenceKey, "0");
        Log.d(TAG, "saved exposure value: " + string);
        try {
            i = Integer.parseInt(string);
            try {
                Log.d(TAG, "exposure: " + i);
            } catch (NumberFormatException unused) {
            }
        } catch (NumberFormatException unused2) {
            i = 0;
            Log.d(TAG, "exposure invalid format, can't parse to int");
            return i;
        }
        return i;
    }

    public static CameraController.Size choosePanoramaResolution(List<CameraController.Size> list) {
        boolean z = false;
        CameraController.Size size = null;
        for (CameraController.Size next : list) {
            if (next.width <= 2080 && Math.abs((((double) next.width) / ((double) next.height)) - 1.3333333333333333d) < 1.0E-5d) {
                if (!z || next.width > size.width) {
                    size = next;
                    z = true;
                }
            }
        }
        if (z) {
            return size;
        }
        for (CameraController.Size next2 : list) {
            if (next2.width <= 2080 && (!z || next2.width > size.width)) {
                size = next2;
                z = true;
            }
        }
        if (z) {
            return size;
        }
        for (CameraController.Size next3 : list) {
            if (!z || next3.width < size.width) {
                size = next3;
                z = true;
            }
        }
        return size;
    }

    public Pair<Integer, Integer> getCameraResolutionPref(CameraResolutionConstraints cameraResolutionConstraints) {
        PhotoMode photoMode = getPhotoMode();
        if (photoMode == PhotoMode.Panorama) {
            CameraController.Size choosePanoramaResolution = choosePanoramaResolution(this.main_activity.getPreview().getSupportedPictureSizes(false));
            return new Pair<>(Integer.valueOf(choosePanoramaResolution.width), Integer.valueOf(choosePanoramaResolution.height));
        }
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.getResolutionPreferenceKey(this.cameraId), "");
        Log.d(TAG, "resolution_value: " + string);
        Pair<Integer, Integer> pair = null;
        if (string.length() > 0) {
            int indexOf = string.indexOf(32);
            if (indexOf == -1) {
                Log.d(TAG, "resolution_value invalid format, can't find space");
            } else {
                String substring = string.substring(0, indexOf);
                String substring2 = string.substring(indexOf + 1);
                Log.d(TAG, "resolution_w_s: " + substring);
                Log.d(TAG, "resolution_h_s: " + substring2);
                try {
                    int parseInt = Integer.parseInt(substring);
                    Log.d(TAG, "resolution_w: " + parseInt);
                    int parseInt2 = Integer.parseInt(substring2);
                    Log.d(TAG, "resolution_h: " + parseInt2);
                    pair = new Pair<>(Integer.valueOf(parseInt), Integer.valueOf(parseInt2));
                } catch (NumberFormatException unused) {
                    Log.d(TAG, "resolution_value invalid format, can't parse w or h to int");
                }
            }
        }
        if (photoMode == PhotoMode.NoiseReduction || photoMode == PhotoMode.HDR) {
            cameraResolutionConstraints.has_max_mp = true;
            cameraResolutionConstraints.max_mp = 22000000;
            if (this.main_activity.is_test && this.test_max_mp != 0) {
                cameraResolutionConstraints.max_mp = this.test_max_mp;
            }
        }
        return pair;
    }

    private int getSaveImageQualityPref() {
        int i;
        Log.d(TAG, "getSaveImageQualityPref");
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.QualityPreferenceKey, "90");
        try {
            i = Integer.parseInt(string);
        } catch (NumberFormatException unused) {
            Log.e(TAG, "image_quality_s invalid format: " + string);
            i = 90;
        }
        if (!isRawOnly()) {
            return i;
        }
        Log.d(TAG, "set lower quality for raw_only mode");
        return Math.min(i, 70);
    }

    public int getImageQualityPref() {
        Log.d(TAG, "getImageQualityPref");
        PhotoMode photoMode = getPhotoMode();
        if ((!this.main_activity.getPreview().isVideo() && (photoMode == PhotoMode.DRO || photoMode == PhotoMode.HDR || photoMode == PhotoMode.NoiseReduction)) || getImageFormatPref() != ImageSaver.Request.ImageFormat.STD) {
            return 100;
        }
        return getSaveImageQualityPref();
    }

//    public boolean getFaceDetectionPref() {
//        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.FaceDetectionPreferenceKey, false);
//    }
    public boolean getFaceDetectionPref() {
        return false;
    }

    public boolean fpsIsHighSpeed() {
        return this.main_activity.getPreview().fpsIsHighSpeed(getVideoFPSPref());
    }

    public String getVideoQualityPref() {
        if ("android.media.action.VIDEO_CAPTURE".equals(this.main_activity.getIntent().getAction())) {
            Log.d(TAG, "from video capture intent");
            if (this.main_activity.getIntent().hasExtra("android.intent.extra.videoQuality")) {
                int intExtra = this.main_activity.getIntent().getIntExtra("android.intent.extra.videoQuality", 0);
                Log.d(TAG, "intent_quality: " + intExtra);
                if (intExtra == 0 || intExtra == 1) {
                    List<String> supportedVideoQuality = this.main_activity.getPreview().getVideoQualityHander().getSupportedVideoQuality();
                    if (intExtra == 0) {
                        Log.d(TAG, "return lowest quality");
                        return supportedVideoQuality.get(supportedVideoQuality.size() - 1);
                    }
                    Log.d(TAG, "return highest quality");
                    return supportedVideoQuality.get(0);
                }
            }
        }
        return SharedPrefs.getString(main_activity, PreferenceKeys.getVideoQualityPreferenceKey(this.cameraId, fpsIsHighSpeed()), "");
    }

    public boolean getVideoStabilizationPref() {
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.VideoStabilizationPreferenceKey, false);
    }

    public boolean getForce4KPref() {
        return this.cameraId == 0 && SharedPrefs.getBoolean(main_activity, PreferenceKeys.ForceVideo4KPreferenceKey, false) && this.main_activity.supportsForceVideo4K();
    }

    public String getRecordVideoOutputFormatPref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.VideoFormatPreferenceKey, "preference_video_output_format_default");
    }

    public String getVideoBitratePref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.VideoBitratePreferenceKey, "default");
    }


    public String getVideoFPSPref() {
        return "30fps";
    }

    public float getVideoCaptureRateFactor() {
        float f = SharedPrefs.getFloat(main_activity, PreferenceKeys.getVideoCaptureRatePreferenceKey(this.main_activity.getPreview().getCameraId()), 1.0f);
        Log.d(TAG, "capture_rate_factor: " + f);
        if (((double) Math.abs(f - 1.0f)) > 1.0E-5d) {
            Log.d(TAG, "check stored capture rate is valid");
            List<Float> supportedVideoCaptureRates = getSupportedVideoCaptureRates();
            Log.d(TAG, "supported_capture_rates: " + supportedVideoCaptureRates);
            boolean z = false;
            Iterator<Float> it = supportedVideoCaptureRates.iterator();
            while (true) {
                if (it.hasNext()) {
                    if (((double) Math.abs(f - it.next().floatValue())) < 1.0E-5d) {
                        z = true;
                        break;
                    }
                } else {
                    break;
                }
            }
            if (!z) {
                Log.e(TAG, "stored capture_rate_factor: " + f + " not supported");
                return 1.0f;
            }
        }
        return f;
    }

    public List<Float> getSupportedVideoCaptureRates() {
        ArrayList arrayList = new ArrayList();
        if (this.main_activity.getPreview().supportsVideoHighSpeed()) {
            if (this.main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRateHighSpeed(240) || this.main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRate(240)) {
                arrayList.add(Float.valueOf(0.125f));
                arrayList.add(Float.valueOf(0.25f));
                arrayList.add(Float.valueOf(0.5f));
            } else if (this.main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRateHighSpeed(120) || this.main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRate(120)) {
                arrayList.add(Float.valueOf(0.25f));
                arrayList.add(Float.valueOf(0.5f));
            } else if (this.main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRateHighSpeed(60) || this.main_activity.getPreview().getVideoQualityHander().videoSupportsFrameRate(60)) {
                arrayList.add(Float.valueOf(0.5f));
            }
        }
        arrayList.add(Float.valueOf(1.0f));
        if (Build.VERSION.SDK_INT >= 21) {
            arrayList.add(Float.valueOf(2.0f));
            arrayList.add(Float.valueOf(3.0f));
            arrayList.add(Float.valueOf(4.0f));
            arrayList.add(Float.valueOf(5.0f));
            arrayList.add(Float.valueOf(10.0f));
            arrayList.add(Float.valueOf(20.0f));
            arrayList.add(Float.valueOf(30.0f));
            arrayList.add(Float.valueOf(60.0f));
            arrayList.add(Float.valueOf(120.0f));
            arrayList.add(Float.valueOf(240.0f));
        }
        return arrayList;
    }

    public CameraController.TonemapProfile getVideoTonemapProfile() {
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.VideoLogPreferenceKey, "off");
        string.hashCode();
        char c = 65535;
        switch (string.hashCode()) {
            case -1275673231:
                if (string.equals("jtvideo")) {
                    c = 0;
                    break;
                }
                break;
            case -1149821512:
                if (string.equals("jtlog2")) {
                    c = 1;
                    break;
                }
                break;
//            case -1078030475:
//                if (string.equals(FirebaseAnalytics.Param.MEDIUM)) {
//                    c = 2;
//                    break;
//                }
//                break;
            case -934964752:
                if (string.equals("rec709")) {
                    c = 3;
                    break;
                }
                break;
            case -891980137:
                if (string.equals("strong")) {
                    c = 4;
                    break;
                }
                break;
            case 107348:
                if (string.equals("low")) {
                    c = 5;
                    break;
                }
                break;
            case 109935:
                if (string.equals("off")) {
                    c = 6;
                    break;
                }
                break;
            case 3143098:
                if (string.equals("fine")) {
                    c = 7;
                    break;
                }
                break;
            case 3538810:
                if (string.equals("srgb")) {
                    c = 8;
                    break;
                }
                break;
            case 98120615:
                if (string.equals("gamma")) {
                    c = 9;
                    break;
                }
                break;
            case 101456314:
                if (string.equals("jtlog")) {
                    c = 10;
                    break;
                }
                break;
            case 1419914662:
                if (string.equals("extra_strong")) {
                    c = 11;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                return CameraController.TonemapProfile.TONEMAPPROFILE_JTVIDEO;
            case 1:
                return CameraController.TonemapProfile.TONEMAPPROFILE_JTLOG2;
            case 2:
            case 4:
            case 5:
            case 7:
            case 11:
                return CameraController.TonemapProfile.TONEMAPPROFILE_LOG;
            case 3:
                return CameraController.TonemapProfile.TONEMAPPROFILE_REC709;
            case 6:
                return CameraController.TonemapProfile.TONEMAPPROFILE_OFF;
            case 8:
                return CameraController.TonemapProfile.TONEMAPPROFILE_SRGB;
            case 9:
                return CameraController.TonemapProfile.TONEMAPPROFILE_GAMMA;
            case 10:
                return CameraController.TonemapProfile.TONEMAPPROFILE_JTLOG;
            default:
                return CameraController.TonemapProfile.TONEMAPPROFILE_OFF;
        }
    }

    public float getVideoLogProfileStrength() {
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.VideoLogPreferenceKey, "off");
        string.hashCode();
        char c = 65535;
        switch (string.hashCode()) {
//            case -1078030475:
//                if (string.equals(FirebaseAnalytics.Param.MEDIUM)) {
//                    c = 0;
//                    break;
//                }
//                break;
            case -891980137:
                if (string.equals("strong")) {
                    c = 1;
                    break;
                }
                break;
            case 107348:
                if (string.equals("low")) {
                    c = 2;
                    break;
                }
                break;
            case 3143098:
                if (string.equals("fine")) {
                    c = 3;
                    break;
                }
                break;
            case 1419914662:
                if (string.equals("extra_strong")) {
                    c = 4;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                return 100.0f;
            case 1:
                return 224.0f;
            case 2:
                return 32.0f;
            case 3:
                return 10.0f;
            case 4:
                return 500.0f;
            default:
                return 0.0f;
        }
    }

    public float getVideoProfileGamma() {
        float f;
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.VideoProfileGammaPreferenceKey, "2.2");
        try {
            f = Float.parseFloat(string);
            try {
                Log.d(TAG, "gamma: " + f);
            } catch (NumberFormatException e) {
                e = e;
            }
        } catch (NumberFormatException e) {
            f = 0.0f;
            Log.e(TAG, "failed to parse gamma value: " + string);
            e.printStackTrace();
            return f;
        }
        return f;
    }

    public long getVideoMaxDurationPref() {
        if ("android.media.action.VIDEO_CAPTURE".equals(this.main_activity.getIntent().getAction())) {
            Log.d(TAG, "from video capture intent");
            if (this.main_activity.getIntent().hasExtra("android.intent.extra.durationLimit")) {
                int intExtra = this.main_activity.getIntent().getIntExtra("android.intent.extra.durationLimit", 0);
                Log.d(TAG, "intent_duration_limit: " + intExtra);
                return (long) (intExtra * 1000);
            }
        }
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.VideoMaxDurationPreferenceKey, "0");
        try {
            return ((long) Integer.parseInt(string)) * 1000;
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse preference_video_max_duration value: " + string);
            e.printStackTrace();
            return 0;
        }
    }

    public int getVideoRestartTimesPref() {
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.VideoRestartPreferenceKey, "0");
        try {
            return Integer.parseInt(string);
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse preference_video_restart value: " + string);
            e.printStackTrace();
            return 0;
        }
    }

    /* access modifiers changed from: package-private */
    public long getVideoMaxFileSizeUserPref() {
        Log.d(TAG, "getVideoMaxFileSizeUserPref");
        long j = 0;
        if ("android.media.action.VIDEO_CAPTURE".equals(this.main_activity.getIntent().getAction())) {
            Log.d(TAG, "from video capture intent");
            if (this.main_activity.getIntent().hasExtra("android.intent.extra.sizeLimit")) {
                long longExtra = this.main_activity.getIntent().getLongExtra("android.intent.extra.sizeLimit", 0);
                Log.d(TAG, "intent_size_limit: " + longExtra);
                return longExtra;
            }
        }
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.VideoMaxFileSizePreferenceKey, "0");
        try {
            j = Long.parseLong(string);
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse preference_video_max_filesize value: " + string);
            e.printStackTrace();
        }
        Log.d(TAG, "video_max_filesize: " + j);
        return j;
    }

    private boolean getVideoRestartMaxFileSizeUserPref() {
        if ("android.media.action.VIDEO_CAPTURE".equals(this.main_activity.getIntent().getAction())) {
            Log.d(TAG, "from video capture intent");
            if (this.main_activity.getIntent().hasExtra("android.intent.extra.sizeLimit")) {
                return false;
            }
        }
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.VideoRestartMaxFileSizePreferenceKey, true);
    }

    public VideoMaxFileSize getVideoMaxFileSizePref() throws NoFreeStorageException {
        Log.d(TAG, "getVideoMaxFileSizePref");
        VideoMaxFileSize videoMaxFileSize = new VideoMaxFileSize();
        videoMaxFileSize.max_filesize = getVideoMaxFileSizeUserPref();
        videoMaxFileSize.auto_restart = getVideoRestartMaxFileSizeUserPref();
        boolean z = true;
        if (!this.storageUtils.isUsingSAF()) {
            String saveLocation = this.storageUtils.getSaveLocation();
            Log.d(TAG, "saving to: " + saveLocation);
            if (saveLocation.startsWith("/")) {
                File externalStorageDirectory = Environment.getExternalStorageDirectory();
                Log.d(TAG, "compare to: " + externalStorageDirectory.getAbsolutePath());
                if (!saveLocation.startsWith(externalStorageDirectory.getAbsolutePath())) {
                    z = false;
                }
            }
            Log.d(TAG, "using internal storage?" + z);
        }
        if (z) {
            Log.d(TAG, "try setting max filesize");
            long freeMemory = this.storageUtils.freeMemory();
            if (freeMemory >= 0) {
                long j = freeMemory * PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID * PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID;
                long j2 = j - 50000000;
                if (this.test_set_available_memory) {
                    j2 = this.test_available_memory;
                }
                Log.d(TAG, "free_memory: " + j);
                Log.d(TAG, "available_memory: " + j2);
                if (j2 <= 20000000) {
                    Log.e(TAG, "not enough free storage to record video");
                    throw new NoFreeStorageException();
                } else if (videoMaxFileSize.max_filesize == 0 || videoMaxFileSize.max_filesize > j2) {
                    videoMaxFileSize.max_filesize = j2;
                    Log.d(TAG, "set video_max_filesize to avoid running out of space: " + videoMaxFileSize);
                }
            } else {
                Log.d(TAG, "can't determine remaining free space");
            }
        }
        return videoMaxFileSize;
    }

    public boolean getVideoFlashPref() {
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.VideoFlashPreferenceKey, false);
    }

    public boolean getVideoLowPowerCheckPref() {
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.VideoLowPowerCheckPreferenceKey, true);
    }

    public String getPreviewSizePref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.PreviewSizePreferenceKey, "preference_preview_size_wysiwyg");
    }

    public String getPreviewRotationPref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.RotatePreviewPreferenceKey, "0");
    }

    public String getLockOrientationPref() {
        if (getPhotoMode() == PhotoMode.Panorama) {
            return "portrait";
        }
        return SharedPrefs.getString(main_activity, PreferenceKeys.LockOrientationPreferenceKey, "none");
    }

    public boolean getTouchCapturePref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.TouchCapturePreferenceKey, "none").equals("single");
    }

    public boolean getDoubleTapCapturePref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.TouchCapturePreferenceKey, "none").equals("double");
    }

    public boolean getPausePreviewPref() {
        if (!this.main_activity.getPreview().isVideoRecording() && !this.main_activity.lastContinuousFastBurst() && getPhotoMode() != PhotoMode.Panorama) {
            return SharedPrefs.getBoolean(main_activity, PreferenceKeys.PausePreviewPreferenceKey, false);
        }
        return false;
    }

    public boolean getShowToastsPref() {
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.ShowToastsPreferenceKey, true);
    }

    public boolean getThumbnailAnimationPref() {
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.ThumbnailAnimationPreferenceKey, false);
    }

    public boolean getShutterSoundPref() {
        if (getPhotoMode() == PhotoMode.Panorama) {
            return false;
        }
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.ShutterSoundPreferenceKey, false);
    }

    public boolean getStartupFocusPref() {
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.StartupFocusPreferenceKey, true);
    }

    public long getTimerPref() {
        if (getPhotoMode() == PhotoMode.Panorama) {
            return 0;
        }
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.TimerPreferenceKey, "0");
        try {
            return 1000 * ((long) Integer.parseInt(string));
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse preference_timer value: " + string);
            e.printStackTrace();
            return 0;
        }
    }

    public String getRepeatPref() {
        if (getPhotoMode() == PhotoMode.Panorama) {
            return "1";
        }
        return SharedPrefs.getString(main_activity, PreferenceKeys.RepeatModePreferenceKey, "1");
    }

    public long getRepeatIntervalPref() {
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.RepeatIntervalPreferenceKey, "0");
        try {
            float parseFloat = Float.parseFloat(string);
            Log.d(TAG, "timer_delay_s: " + parseFloat);
            return (long) (parseFloat * 1000.0f);
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse repeat interval value: " + string);
            e.printStackTrace();
            return 0;
        }
    }

    public boolean getGeotaggingPref() {
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.LocationPreferenceKey, true);
    }

    public boolean getRequireLocationPref() {
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.RequireLocationPreferenceKey, false);
    }

    /* access modifiers changed from: package-private */
    public boolean getGeodirectionPref() {
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.GPSDirectionPreferenceKey, false);
    }

    public boolean getRecordAudioPref() {
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.RecordAudioPreferenceKey, true);
    }

    public String getRecordAudioChannelsPref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.RecordAudioChannelsPreferenceKey, "audio_default");
    }

    public String getRecordAudioSourcePref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.RecordAudioSourcePreferenceKey, "audio_src_camcorder");
    }

    public boolean getAutoStabilisePref() {
        if (!SharedPrefs.getBoolean(main_activity, PreferenceKeys.AutoStabilisePreferenceKey, false) || !this.main_activity.supportsAutoStabilise()) {
            return false;
        }
        return true;
    }

    public int getGhostImageAlpha() {
        int i;
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.GhostImageAlphaPreferenceKey, "50");
        try {
            i = Integer.parseInt(string);
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse ghost_image_alpha_value: " + string);
            e.printStackTrace();
            i = 50;
        }
        return (int) ((((float) i) * 2.55f) + 0.1f);
    }

    public String getStampPref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.StampPreferenceKey, "preference_stamp_no");
    }

    private String getStampDateFormatPref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.StampDateFormatPreferenceKey, "preference_stamp_dateformat_default");
    }

    private String getStampTimeFormatPref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.StampTimeFormatPreferenceKey, "preference_stamp_timeformat_default");
    }

    private String getStampGPSFormatPref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.StampGPSFormatPreferenceKey, "preference_stamp_gpsformat_default");
    }

    private String getStampGeoAddressPref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.StampGeoAddressPreferenceKey, "preference_stamp_geo_address_no");
    }

    private String getUnitsDistancePref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.UnitsDistancePreferenceKey, "preference_units_distance_m");
    }

    public String getTextStampPref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.TextStampPreferenceKey, "");
    }

    private int getTextStampFontSizePref() {
        int i;
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.StampFontSizePreferenceKey, "10");
        Log.d(TAG, "saved font size: " + string);
        try {
            i = Integer.parseInt(string);
            try {
                Log.d(TAG, "font_size: " + i);
            } catch (NumberFormatException unused) {
            }
        } catch (NumberFormatException unused2) {
            i = 12;
            Log.d(TAG, "font size invalid format, can't parse to int");
            return i;
        }
        return i;
    }

    private String getVideoSubtitlePref() {
        return SharedPrefs.getString(main_activity, PreferenceKeys.VideoSubtitlePref, "preference_video_subtitle_no");
    }

    public int getZoomPref() {
        Log.d(TAG, "getZoomPref: " + this.zoom_factor);
        return this.zoom_factor;
    }

    public double getCalibratedLevelAngle() {
        return (double) SharedPrefs.getFloat(main_activity, PreferenceKeys.CalibratedLevelAnglePreferenceKey, 0.0f);
    }

    public boolean canTakeNewPhoto() {
        int i;
        int i2;
        Log.d(TAG, "canTakeNewPhoto");
        if (this.main_activity.getPreview().isVideo()) {
            i2 = 0;
            i = 1;
        } else {
            if (this.main_activity.getPreview().supportsExpoBracketing() && isExpoBracketingPref()) {
                i2 = getExpoBracketingNImagesPref();
            } else if ((!this.main_activity.getPreview().supportsFocusBracketing() || !isFocusBracketingPref()) && this.main_activity.getPreview().supportsBurst() && isCameraBurstPref()) {
                i2 = getBurstForNoiseReduction() ? getNRModePref() == NRModePref.NRMODE_LOW_LIGHT ? 15 : 8 : getBurstNImages();
            } else {
                i2 = 1;
            }
            if (!this.main_activity.getPreview().supportsRaw() || getRawPref() != RawPref.RAWPREF_JPEG_DNG) {
                i = i2;
                i2 = 0;
            } else {
                i = i2;
            }
        }
        int computePhotoCost = this.imageSaver.computePhotoCost(i2, i);
        if (this.imageSaver.queueWouldBlock(computePhotoCost)) {
            Log.d(TAG, "canTakeNewPhoto: no, as queue would block");
            return false;
        }
        int nImagesToSave = this.imageSaver.getNImagesToSave();
        PhotoMode photoMode = getPhotoMode();
        if ((photoMode == PhotoMode.FastBurst || photoMode == PhotoMode.Panorama) && nImagesToSave > 0) {
            Log.d(TAG, "canTakeNewPhoto: no, as too many for fast burst");
            return false;
        } else if (photoMode == PhotoMode.NoiseReduction && nImagesToSave >= computePhotoCost * 2) {
            Log.d(TAG, "canTakeNewPhoto: no, as too many for nr");
            return false;
        } else if (i > 1 && nImagesToSave >= computePhotoCost * 3) {
            Log.d(TAG, "canTakeNewPhoto: no, as too many for burst");
            return false;
        } else if (i2 > 0 && nImagesToSave >= computePhotoCost * 3) {
            Log.d(TAG, "canTakeNewPhoto: no, as too many for raw");
            return false;
        } else if (nImagesToSave < computePhotoCost * 5 || (this.main_activity.supportsNoiseReduction() && nImagesToSave <= 8)) {
            return true;
        } else {
            Log.d(TAG, "canTakeNewPhoto: no, as too many for regular");
            return false;
        }
    }

    public boolean imageQueueWouldBlock(int i, int i2) {
        Log.d(TAG, "imageQueueWouldBlock");
        return this.imageSaver.queueWouldBlock(i, i2);
    }

    public long getExposureTimePref() {
        return SharedPrefs.getLong(main_activity, PreferenceKeys.ExposureTimePreferenceKey, CameraController.EXPOSURE_TIME_DEFAULT);
    }

    public float getFocusDistancePref(boolean z) {
        return SharedPrefs.getFloat(main_activity, z ? PreferenceKeys.FocusBracketingTargetDistancePreferenceKey : PreferenceKeys.FocusDistancePreferenceKey, 0.0f);
    }

    public boolean isExpoBracketingPref() {
        PhotoMode photoMode = getPhotoMode();
        return photoMode == PhotoMode.HDR || photoMode == PhotoMode.ExpoBracketing;
    }

    public boolean isFocusBracketingPref() {
        return getPhotoMode() == PhotoMode.FocusBracketing;
    }

    public boolean isCameraBurstPref() {
        PhotoMode photoMode = getPhotoMode();
        return photoMode == PhotoMode.FastBurst || photoMode == PhotoMode.NoiseReduction;
    }

    public int getBurstNImages() {
        if (getPhotoMode() != PhotoMode.FastBurst) {
            return 1;
        }
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.FastBurstNImagesPreferenceKey, "5");
        try {
            return Integer.parseInt(string);
        } catch (NumberFormatException e) {
            Log.e(TAG, "failed to parse FastBurstNImagesPreferenceKey value: " + string);
            e.printStackTrace();
            return 5;
        }
    }

    public boolean getBurstForNoiseReduction() {
        return getPhotoMode() == PhotoMode.NoiseReduction;
    }

    public void setNRMode(String str) {
        this.nr_mode = str;
    }

    public String getNRMode() {
        return this.nr_mode;
    }

    public NRModePref getNRModePref() {
        String str = this.nr_mode;
        str.hashCode();
        if (!str.equals("preference_nr_mode_low_light")) {
            return NRModePref.NRMODE_NORMAL;
        }
        return NRModePref.NRMODE_LOW_LIGHT;
    }

    public void setAperture(float f) {
        this.aperture = f;
    }

    public float getAperturePref() {
        return this.aperture;
    }

    public int getExpoBracketingNImagesPref() {
        Log.d(TAG, "getExpoBracketingNImagesPref");
        int i = 3;
        if (getPhotoMode() != PhotoMode.HDR) {
            String string = SharedPrefs.getString(main_activity, PreferenceKeys.ExpoBracketingNImagesPreferenceKey, ExifInterface.GPS_MEASUREMENT_3D);
            try {
                i = Integer.parseInt(string);
            } catch (NumberFormatException unused) {
                Log.e(TAG, "n_images_s invalid format: " + string);
            }
        }
        Log.d(TAG, "n_images = " + i);
        return i;
    }

    public double getExpoBracketingStopsPref() {
        Log.d(TAG, "getExpoBracketingStopsPref");
        double d = 2.0d;
        if (getPhotoMode() != PhotoMode.HDR) {
            String string = SharedPrefs.getString(main_activity, PreferenceKeys.ExpoBracketingStopsPreferenceKey, ExifInterface.GPS_MEASUREMENT_2D);
            try {
                d = Double.parseDouble(string);
            } catch (NumberFormatException unused) {
                Log.e(TAG, "n_stops_s invalid format: " + string);
            }
        }
        Log.d(TAG, "n_stops = " + d);
        return d;
    }

    public int getFocusBracketingNImagesPref() {
        int i;
        Log.d(TAG, "getFocusBracketingNImagesPref");
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.FocusBracketingNImagesPreferenceKey, ExifInterface.GPS_MEASUREMENT_3D);
        try {
            i = Integer.parseInt(string);
        } catch (NumberFormatException unused) {
            Log.e(TAG, "n_images_s invalid format: " + string);
            i = 3;
        }
        Log.d(TAG, "n_images = " + i);
        return i;
    }

    public boolean getFocusBracketingAddInfinityPref() {
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.FocusBracketingAddInfinityPreferenceKey, false);
    }

    public PhotoMode getPhotoMode() {
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.PhotoModePreferenceKey, "preference_photo_mode_std");
        if (string.equals("preference_photo_mode_dro") && this.main_activity.supportsDRO()) {
            return PhotoMode.DRO;
        }
        if (string.equals("preference_photo_mode_hdr") && this.main_activity.supportsHDR()) {
            return PhotoMode.HDR;
        }
        if (string.equals("preference_photo_mode_expo_bracketing") && this.main_activity.supportsExpoBracketing()) {
            return PhotoMode.ExpoBracketing;
        }
        if (string.equals("preference_photo_mode_focus_bracketing") && this.main_activity.supportsFocusBracketing()) {
            return PhotoMode.FocusBracketing;
        }
        if (string.equals("preference_photo_mode_fast_burst") && this.main_activity.supportsFastBurst()) {
            return PhotoMode.FastBurst;
        }
        if (string.equals("preference_photo_mode_noise_reduction") && this.main_activity.supportsNoiseReduction()) {
            return PhotoMode.NoiseReduction;
        }
        if (!string.equals("preference_photo_mode_panorama") || this.main_activity.getPreview().isVideo() || !this.main_activity.supportsPanorama()) {
            return PhotoMode.Standard;
        }
        return PhotoMode.Panorama;
    }

    public boolean getOptimiseAEForDROPref() {
        return getPhotoMode() == PhotoMode.DRO;
    }

    private ImageSaver.Request.ImageFormat getImageFormatPref() {
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.ImageFormatPreferenceKey, "preference_image_format_jpeg");
        string.hashCode();
        if (string.equals("preference_image_format_png")) {
            return ImageSaver.Request.ImageFormat.PNG;
        }
        if (!string.equals("preference_image_format_webp")) {
            return ImageSaver.Request.ImageFormat.STD;
        }
        return ImageSaver.Request.ImageFormat.WEBP;
    }

    public boolean isRawAllowed(PhotoMode photoMode) {
        if (isImageCaptureIntent() || this.main_activity.getPreview().isVideo()) {
            return false;
        }
        if (photoMode == PhotoMode.Standard || photoMode == PhotoMode.DRO) {
            return true;
        }
        if (photoMode == PhotoMode.ExpoBracketing) {
            if (!SharedPrefs.getBoolean(main_activity, PreferenceKeys.AllowRawForExpoBracketingPreferenceKey, true) || !this.main_activity.supportsBurstRaw()) {
                return false;
            }
            return true;
        } else if (photoMode == PhotoMode.HDR) {
            if (!SharedPrefs.getBoolean(main_activity, PreferenceKeys.HDRSaveExpoPreferenceKey, false) || !SharedPrefs.getBoolean(main_activity, PreferenceKeys.AllowRawForExpoBracketingPreferenceKey, true) || !this.main_activity.supportsBurstRaw()) {
                return false;
            }
            return true;
        } else if (photoMode != PhotoMode.FocusBracketing || !SharedPrefs.getBoolean(main_activity, PreferenceKeys.AllowRawForFocusBracketingPreferenceKey, true) || !this.main_activity.supportsBurstRaw()) {
            return false;
        } else {
            return true;
        }
    }

    public RawPref getRawPref() {
        if (isRawAllowed(getPhotoMode())) {
            String string = SharedPrefs.getString(main_activity, PreferenceKeys.RawPreferenceKey, "preference_raw_no");
            string.hashCode();
            if (string.equals("preference_raw_only") || string.equals("preference_raw_yes")) {
                return RawPref.RAWPREF_JPEG_DNG;
            }
        }
        return RawPref.RAWPREF_JPEG_ONLY;
    }

    public boolean isRawOnly() {
        return isRawOnly(getPhotoMode());
    }

    public boolean isRawOnly(PhotoMode photoMode) {
        if (!isRawAllowed(photoMode)) {
            return false;
        }
        String string = SharedPrefs.getString(main_activity, PreferenceKeys.RawPreferenceKey, "preference_raw_no");
        string.hashCode();
        return string.equals("preference_raw_only");
    }

    public int getMaxRawImages() {
        return this.imageSaver.getMaxDNG();
    }

    public boolean useCamera2FakeFlash() {
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.Camera2FakeFlashPreferenceKey, false);
    }

    public boolean useCamera2FastBurst() {
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.Camera2FastBurstPreferenceKey, true);
    }

    public boolean usePhotoVideoRecording() {
        if (!useCamera2()) {
            return true;
        }
        return SharedPrefs.getBoolean(main_activity, PreferenceKeys.Camera2PhotoVideoRecordingPreferenceKey, true);
    }

    public boolean isPreviewInBackground() {
        return this.main_activity.isCameraInBackground();
    }

    public boolean allowZoom() {
        return getPhotoMode() != PhotoMode.Panorama;
    }

    public boolean isTestAlwaysFocus() {
        Log.d(TAG, "isTestAlwaysFocus: " + this.main_activity.is_test);
        return this.main_activity.is_test;
    }

    public void cameraSetup() {
        this.main_activity.cameraSetup();
        this.drawPreview.clearContinuousFocusMove();
        this.drawPreview.updateSettings();
    }

    public void onContinuousFocusMove(boolean z) {
        Log.d(TAG, "onContinuousFocusMove: " + z);
        this.drawPreview.onContinuousFocusMove(z);
    }

    public void startPanorama() {
        Log.d(TAG, "startPanorama");
        this.gyroSensor.startRecording();
        this.n_panorama_pics = 0;
        this.panorama_pic_accepted = false;
        this.panorama_dir_left_to_right = true;
        this.main_activity.getMainUI().setTakePhotoIcon();
    }

    public void finishPanorama() {
        Log.d(TAG, "finishPanorama");
        this.imageSaver.getImageBatchRequest().panorama_dir_left_to_right = this.panorama_dir_left_to_right;
        stopPanorama(false);
        this.imageSaver.finishImageBatch(saveInBackground(isImageCaptureIntent()));
    }

    public void stopPanorama(boolean z) {
        Log.d(TAG, "stopPanorama");
        if (!this.gyroSensor.isRecording()) {
            Log.d(TAG, "...nothing to stop");
            return;
        }
        this.gyroSensor.stopRecording();
        clearPanoramaPoint();
        if (z) {
            this.imageSaver.flushImageBatch();
        }
        this.main_activity.getMainUI().setTakePhotoIcon();
    }

    private void setNextPanoramaPoint(boolean z) {
        Log.d(TAG, "setNextPanoramaPoint");
        float viewAngleY = this.main_activity.getPreview().getViewAngleY(false);
        if (!z) {
            this.n_panorama_pics++;
        }
        Log.d(TAG, "n_panorama_pics is now: " + this.n_panorama_pics);
        if (this.n_panorama_pics == 10) {
            Log.d(TAG, "reached max panorama limit");
            finishPanorama();
            return;
        }
        float radians = (float) Math.toRadians((double) viewAngleY);
        int i = this.n_panorama_pics;
        float f = radians * ((float) i);
        if (i > 1 && !this.panorama_dir_left_to_right) {
            f = -f;
        }
        double d = (double) (f / panorama_pics_per_screen);
        setNextPanoramaPoint((float) Math.sin(d), 0.0f, (float) (-Math.cos(d)));
        if (this.n_panorama_pics == 1) {
            double d2 = (double) ((-f) / panorama_pics_per_screen);
            float sin = (float) Math.sin(d2);
            float f2 = (float) (-Math.cos(d2));
            this.gyroSensor.addTarget(sin, 0.0f, f2);
            this.drawPreview.addGyroDirectionMarker(sin, 0.0f, f2);
        }
    }

    private void setNextPanoramaPoint(float f, float f2, float f3) {
        Log.d(TAG, "setNextPanoramaPoint : " + f + " , " + f2 + " , " + f3);
        this.gyroSensor.setTarget(f, f2, f3, 0.017453292f, 0.03490481f, 0.7853982f, new GyroSensor.TargetCallback() {
            public void onAchieved(int i) {
                Log.d(MyApplicationInterface.TAG, "TargetCallback.onAchieved: " + i);
                Log.d(MyApplicationInterface.TAG, "    n_panorama_pics: " + MyApplicationInterface.this.n_panorama_pics);
                MyApplicationInterface.this.gyroSensor.disableTargetCallback();
                boolean z = true;
                if (MyApplicationInterface.this.n_panorama_pics == 1) {
                    MyApplicationInterface myApplicationInterface = MyApplicationInterface.this;
                    if (i != 0) {
                        z = false;
                    }
                    boolean unused = myApplicationInterface.panorama_dir_left_to_right = z;
                    Log.d(MyApplicationInterface.TAG, "set panorama_dir_left_to_right to " + MyApplicationInterface.this.panorama_dir_left_to_right);
                }
                MyApplicationInterface.this.main_activity.takePicturePressed(false, false);
            }

            public void onTooFar() {
                Log.d(MyApplicationInterface.TAG, "TargetCallback.onTooFar");
                if (!MyApplicationInterface.this.main_activity.is_test) {
                    MyApplicationInterface.this.main_activity.getPreview().showToast((ToastBoxer) null, (int) R.string.panorama_cancelled);
                    MyApplicationInterface.this.stopPanorama(true);
                }
            }
        });
        this.drawPreview.setGyroDirectionMarker(f, f2, f3);
    }

    private void clearPanoramaPoint() {
        Log.d(TAG, "clearPanoramaPoint");
        this.gyroSensor.clearTarget();
        this.drawPreview.clearGyroDirectionMarker();
    }

    public void touchEvent(MotionEvent motionEvent) {
        this.main_activity.closePopup();
        if (this.main_activity.usingKitKatImmersiveMode()) {
            this.main_activity.setImmersiveMode(false);
        }
    }

    public void startingVideo() {
        if (SharedPrefs.getBoolean(main_activity, PreferenceKeys.LockVideoPreferenceKey, false)) {
            this.main_activity.lockScreen();
        }
        this.main_activity.stopAudioListeners();
        main_activity.findViewById(R.id.take_photo).setContentDescription(getContext().getResources().getString(R.string.stop_video));
        this.main_activity.getMainUI().destroyPopup();
    }

    public void startedVideo() {
        Log.d(TAG, "startedVideo()");
        if (Build.VERSION.SDK_INT >= 24) {
            if (this.main_activity.getMainUI().inImmersiveMode()) {
                this.main_activity.usingKitKatImmersiveModeEverything();
            }
            this.main_activity.getMainUI().setPauseVideoContentDescription();
        }
        if (this.main_activity.getPreview().supportsPhotoVideoRecording() && usePhotoVideoRecording() && this.main_activity.getMainUI().inImmersiveMode()) {
            this.main_activity.usingKitKatImmersiveModeEverything();
        }
        if (this.main_activity.getMainUI().isExposureUIOpen()) {
            Log.d(TAG, "need to update exposure UI for start video recording");
            this.main_activity.getMainUI().setupExposureUI();
        }
        final VideoMethod createOutputVideoMethod = createOutputVideoMethod();
        if (getVideoSubtitlePref().equals("preference_video_subtitle_yes") && createOutputVideoMethod != VideoMethod.URI) {
            final String stampDateFormatPref = getStampDateFormatPref();
            final String stampTimeFormatPref = getStampTimeFormatPref();
            final String stampGPSFormatPref = getStampGPSFormatPref();
            final String unitsDistancePref = getUnitsDistancePref();
            final String stampGeoAddressPref = getStampGeoAddressPref();
            final boolean geotaggingPref = getGeotaggingPref();
            final boolean geodirectionPref = getGeodirectionPref();
            Timer timer = this.subtitleVideoTimer;
            TimerTask r0 = new TimerTask() {
                private int count = 1;
                private long min_video_time_from = 0;
                private ParcelFileDescriptor pfd_saf;
                private Uri uri;
                private OutputStreamWriter writer;

                private String getSubtitleFilename(String str) {
                    Log.d(MyApplicationInterface.TAG, "getSubtitleFilename");
                    int indexOf = str.indexOf(46);
                    if (indexOf != -1) {
                        str = str.substring(0, indexOf);
                    }
                    String str2 = str + ".srt";
                    Log.d(MyApplicationInterface.TAG, "return filename: " + str2);
                    return str2;
                }

                public void run() {

                }

                public boolean cancel() {
                    Log.d(MyApplicationInterface.TAG, "SubtitleVideoTimerTask cancel");
                    synchronized (this) {
                        if (this.writer != null) {
                            Log.d(MyApplicationInterface.TAG, "close writer");
                            try {
                                this.writer.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            this.writer = null;
                        }
                        ParcelFileDescriptor parcelFileDescriptor = this.pfd_saf;
                        if (parcelFileDescriptor != null) {
                            try {
                                parcelFileDescriptor.close();
                            } catch (IOException e2) {
                                e2.printStackTrace();
                            }
                            this.pfd_saf = null;
                        }
                        if (createOutputVideoMethod == VideoMethod.MEDIASTORE && Build.VERSION.SDK_INT >= 29) {
                            ContentValues contentValues = new ContentValues();
                            contentValues.put("is_pending", 0);
                            MyApplicationInterface.this.main_activity.getContentResolver().update(this.uri, contentValues, (String) null, (String[]) null);
                        }
                    }
                    return super.cancel();
                }
            };
            this.subtitleVideoTimerTask = r0;
            timer.schedule(r0, 0, 1000);
        }
    }

    public void stoppingVideo() {
        Log.d(TAG, "stoppingVideo()");
        this.main_activity.unlockScreen();
        this.main_activity.findViewById(R.id.take_photo).setContentDescription(getContext().getResources().getString(R.string.start_video));
    }


    public void stoppedVideo(VideoMethod r8, Uri r9, String r10) {

    }

    private void completeVideo(VideoMethod videoMethod, Uri uri) {
        Log.d(TAG, "completeVideo");
        if (videoMethod == VideoMethod.MEDIASTORE && Build.VERSION.SDK_INT >= 29) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("is_pending", 0);
            this.main_activity.getContentResolver().update(uri, contentValues, (String) null, (String[]) null);
        }
    }

    public void restartedVideo(VideoMethod videoMethod, Uri uri, String str) {
        Log.d(TAG, "restartedVideo");
        Log.d(TAG, "video_method " + videoMethod);
        Log.d(TAG, "uri " + uri);
        Log.d(TAG, "filename " + str);
        completeVideo(videoMethod, uri);
        //TODO Stop broadcastVideo (Method not decompile)
//        broadcastVideo(videoMethod, uri, str);
    }


    public void deleteUnusedVideo(VideoMethod videoMethod, Uri uri, String str) {
        Log.d(TAG, "deleteUnusedVideo");
        Log.d(TAG, "video_method " + videoMethod);
        Log.d(TAG, "uri " + uri);
        Log.d(TAG, "filename " + str);
        if (videoMethod == VideoMethod.FILE) {
            trashImage(LastImagesType.FILE, uri, str, false);
        } else if (videoMethod == VideoMethod.SAF) {
            trashImage(LastImagesType.SAF, uri, str, false);
        } else if (videoMethod == VideoMethod.MEDIASTORE) {
            trashImage(LastImagesType.MEDIASTORE, uri, str, false);
        }
    }

    public void onVideoInfo(int i, int i2) {
        if (Build.VERSION.SDK_INT >= 26 && i == 803) {
            Log.d(TAG, "next output file started");
            this.main_activity.getPreview().showToast((ToastBoxer) null, (int) R.string.video_max_filesize);
        } else if (i == 801) {
            Log.d(TAG, "max filesize reached");
            this.main_activity.getPreview().showToast((ToastBoxer) null, (int) R.string.video_max_filesize);
        }
        String str = "info_" + i + "_" + i2;
        SharedPrefs.save(main_activity, "last_video_error", str);
    }

    public void onFailedStartPreview() {
        this.main_activity.getPreview().showToast((ToastBoxer) null, (int) R.string.failed_to_start_camera_preview);
    }

    public void onCameraError() {
        this.main_activity.getPreview().showToast((ToastBoxer) null, (int) R.string.camera_error);
    }

    public void onPhotoError() {
        this.main_activity.getPreview().showToast((ToastBoxer) null, (int) R.string.failed_to_take_picture);
    }

    public void onVideoError(int i, int i2) {
        int i3;
        Log.d(TAG, "onVideoError: " + i + " extra: " + i2);
        if (i == 100) {
            Log.d(TAG, "error: server died");
            i3 = R.string.video_error_server_died;
        } else {
            i3 = R.string.video_error_unknown;
        }
        this.main_activity.getPreview().showToast((ToastBoxer) null, i3);
        String str = "error_" + i + "_" + i2;
        SharedPrefs.save(main_activity, "last_video_error", str);
    }

    public void onVideoRecordStartError(VideoProfile videoProfile) {
        String str;
        Log.d(TAG, "onVideoRecordStartError");
        String errorFeatures = this.main_activity.getPreview().getErrorFeatures(videoProfile);
        if (errorFeatures.length() > 0) {
            str = getContext().getResources().getString(R.string.sorry) + ", " + errorFeatures + " " + getContext().getResources().getString(R.string.not_supported);
        } else {
            str = getContext().getResources().getString(R.string.failed_to_record_video);
        }
        this.main_activity.getPreview().showToast((ToastBoxer) null, str);
        (this.main_activity.findViewById(R.id.take_photo)).setContentDescription(getContext().getResources().getString(R.string.start_video));
    }

    public void onVideoRecordStopError(VideoProfile videoProfile) {
        Log.d(TAG, "onVideoRecordStopError");
        String errorFeatures = this.main_activity.getPreview().getErrorFeatures(videoProfile);
        String string = getContext().getResources().getString(R.string.video_may_be_corrupted);
        if (errorFeatures.length() > 0) {
            string = string + ", " + errorFeatures + " " + getContext().getResources().getString(R.string.not_supported);
        }
        this.main_activity.getPreview().showToast((ToastBoxer) null, string);
    }

    public void onFailedReconnectError() {
        this.main_activity.getPreview().showToast((ToastBoxer) null, (int) R.string.failed_to_reconnect_camera);
    }

    public void onFailedCreateVideoFileError() {
        this.main_activity.getPreview().showToast((ToastBoxer) null, (int) R.string.failed_to_save_video);
        (this.main_activity.findViewById(R.id.take_photo)).setContentDescription(getContext().getResources().getString(R.string.start_video));
    }

    public void hasPausedPreview(boolean z) {
        Log.d(TAG, "hasPausedPreview: " + z);
        if (!z) {
            clearLastImages();
        }
    }

    public void cameraInOperation(boolean z, boolean z2) {
        Log.d(TAG, "cameraInOperation: " + z);
        if (!z && this.used_front_screen_flash) {
            this.main_activity.setBrightnessForCamera(false);
            this.used_front_screen_flash = false;
        }
        this.drawPreview.cameraInOperation(z);
        this.main_activity.getMainUI().showGUI(!z, z2);
    }

    public void turnFrontScreenFlashOn() {
        Log.d(TAG, "turnFrontScreenFlashOn");
        this.used_front_screen_flash = true;
        this.main_activity.setBrightnessForCamera(true);
        this.drawPreview.turnFrontScreenFlashOn();
    }

    public void onCaptureStarted() {
        Log.d(TAG, "onCaptureStarted");
        this.n_capture_images = 0;
        this.n_capture_images_raw = 0;
        this.drawPreview.onCaptureStarted();
    }

    public void onPictureCompleted() {
        Log.d(TAG, "onPictureCompleted");
        PhotoMode photoMode = getPhotoMode();
        if (this.main_activity.getPreview().isVideo()) {
            Log.d(TAG, "snapshot mode");
            photoMode = PhotoMode.Standard;
        }
        if (photoMode == PhotoMode.NoiseReduction) {
            this.imageSaver.finishImageBatch(saveInBackground(isImageCaptureIntent()));
        } else if (photoMode != PhotoMode.Panorama || !this.gyroSensor.isRecording()) {
            if (photoMode == PhotoMode.FocusBracketing) {
                Log.d(TAG, "focus bracketing completed");
                if (getShutterSoundPref()) {
                    Log.d(TAG, "play completion sound");
                    MediaPlayer create = MediaPlayer.create(getContext(), Settings.System.DEFAULT_NOTIFICATION_URI);
                    if (create != null) {
                        create.start();
                    }
                }
            }
        } else if (this.panorama_pic_accepted) {
            Log.d(TAG, "set next panorama point");
            setNextPanoramaPoint(false);
        } else {
            Log.d(TAG, "panorama pic wasn't accepted");
            setNextPanoramaPoint(true);
        }
        this.drawPreview.cameraInOperation(false);
    }

    public void cameraClosed() {
        Log.d(TAG, "cameraClosed");
        stopPanorama(true);
        this.main_activity.getMainUI().destroyPopup();
        this.drawPreview.clearContinuousFocusMove();
    }

    /* access modifiers changed from: package-private */
    public void updateThumbnail(Bitmap bitmap, boolean z, File file, Uri finalSaveUri) {
        Log.d(TAG, "updateThumbnail");
        this.main_activity.updateGalleryIcon_(bitmap, file, finalSaveUri);
        this.drawPreview.updateThumbnail(bitmap, z, true);
        if (!z && getPausePreviewPref()) {
            this.drawPreview.showLastImage();
        }
    }

    public void timerBeep(long j) {
        Log.d(TAG, "timerBeep()");
        Log.d(TAG, "remaining_time: " + j);
        boolean z = true;
        if (SharedPrefs.getBoolean(main_activity, PreferenceKeys.TimerBeepPreferenceKey, true)) {
            Log.d(TAG, "play beep!");
            if (j > 1000) {
                z = false;
            }
            this.main_activity.getSoundPoolManager().playSound(z ? R.raw.mybeep_hi : R.raw.mybeep);
        }
        if (SharedPrefs.getBoolean(main_activity, PreferenceKeys.TimerSpeakPreferenceKey, false)) {
            Log.d(TAG, "speak countdown!");
            int i = (int) (j / 1000);
            if (i <= 60) {
                CameraActivity cameraActivity = this.main_activity;
                cameraActivity.speak("" + i);
            }
        }
    }

    public void multitouchZoom(int i) {
        this.main_activity.getMainUI().setSeekbarZoom(i);
    }

    public void switchToCamera(boolean z) {
        Log.d(TAG, "switchToCamera: " + z);
        int numberOfCameras = this.main_activity.getPreview().getCameraControllerManager().getNumberOfCameras();
        CameraController.Facing facing = z ? CameraController.Facing.FACING_FRONT : CameraController.Facing.FACING_BACK;
        for (int i = 0; i < numberOfCameras; i++) {
            if (this.main_activity.getPreview().getCameraControllerManager().getFacing(i) == facing) {
                Log.d(TAG, "found desired camera: " + i);
                setCameraIdPref(i);
                return;
            }
        }
    }

    public boolean hasSetCameraId() {
        return this.has_set_cameraId;
    }

    public void setCameraIdPref(int i) {
        this.has_set_cameraId = true;
        this.cameraId = i;
    }

    public void setFlashPref(String str) {
        SharedPrefs.save(main_activity, PreferenceKeys.getFlashPreferenceKey(this.cameraId), str);
    }

    public void setFocusPref(String str, boolean z) {
        SharedPrefs.save(main_activity, PreferenceKeys.getFocusPreferenceKey(this.cameraId, z), str);
        this.main_activity.setManualFocusSeekBarVisibility(false);
    }

    public void setVideoPref(boolean z) {
        SharedPrefs.savePref(main_activity, PreferenceKeys.IsVideoPreferenceKey, z);
    }

    public void setSceneModePref(String str) {
        SharedPrefs.save(main_activity, PreferenceKeys.SceneModePreferenceKey, str);
    }

    public void clearSceneModePref() {
        SharedPrefs.removeKey(main_activity, PreferenceKeys.SceneModePreferenceKey);
    }

    public void setColorEffectPref(String str) {
        SharedPrefs.save(main_activity, PreferenceKeys.ColorEffectPreferenceKey, str);
    }

    public void clearColorEffectPref() {
        SharedPrefs.removeKey(main_activity, PreferenceKeys.ColorEffectPreferenceKey);
    }

    public void setWhiteBalancePref(String str) {
        SharedPrefs.save(main_activity, PreferenceKeys.WhiteBalancePreferenceKey, str);
    }

    public void clearWhiteBalancePref() {
        SharedPrefs.removeKey(main_activity, PreferenceKeys.WhiteBalancePreferenceKey);
    }

    public void setWhiteBalanceTemperaturePref(int i) {
        SharedPrefs.save(main_activity, PreferenceKeys.WhiteBalanceTemperaturePreferenceKey, i);
    }

    public void setISOPref(String str) {
        SharedPrefs.save(main_activity, PreferenceKeys.ISOPreferenceKey, str);
    }

    public void clearISOPref() {
        SharedPrefs.removeKey(main_activity, PreferenceKeys.ISOPreferenceKey);
    }

    public void setExposureCompensationPref(int i) {
        SharedPrefs.save(main_activity, PreferenceKeys.ExposurePreferenceKey, "" + i);
    }

    public void clearExposureCompensationPref() {
        SharedPrefs.removeKey(main_activity, PreferenceKeys.ExposurePreferenceKey);
    }

    public void setCameraResolutionPref(int i, int i2) {
        if (getPhotoMode() != PhotoMode.Panorama) {
            String str = i + " " + i2;
            Log.d(TAG, "save new resolution_value: " + str);
            SharedPrefs.save(main_activity, PreferenceKeys.getResolutionPreferenceKey(this.cameraId), str);
        }
    }

    public void setVideoQualityPref(String str) {
        SharedPrefs.save(main_activity, PreferenceKeys.getVideoQualityPreferenceKey(this.cameraId, fpsIsHighSpeed()), str);
    }

    public void setZoomPref(int i) {
        Log.d(TAG, "setZoomPref: " + i);
        this.zoom_factor = i;
    }

    public void requestCameraPermission() {
        Log.d(TAG, "requestCameraPermission");
        this.main_activity.getPermissionHandler().requestCameraPermission();
    }

    public boolean needsStoragePermission() {
        Log.d(TAG, "needsStoragePermission");
        return !CameraActivity.useScopedStorage();
    }

    public void requestStoragePermission() {
        Log.d(TAG, "requestStoragePermission");
        this.main_activity.getPermissionHandler().requestStoragePermission();
    }

    public void requestRecordAudioPermission() {
        Log.d(TAG, "requestRecordAudioPermission");
        this.main_activity.getPermissionHandler().requestRecordAudioPermission();
    }

    public void setExposureTimePref(long j) {
        SharedPrefs.save(main_activity, PreferenceKeys.ExposureTimePreferenceKey, j);
    }

    public void clearExposureTimePref() {

        SharedPrefs.removeKey(main_activity, PreferenceKeys.ExposureTimePreferenceKey);

    }

    public void setFocusDistancePref(float f, boolean z) {
        SharedPrefs.save(main_activity, z ? PreferenceKeys.FocusBracketingTargetDistancePreferenceKey : PreferenceKeys.FocusDistancePreferenceKey, f);
    }

    private int getStampFontColor() {
        return Color.parseColor(SharedPrefs.getString(main_activity, PreferenceKeys.StampFontColorPreferenceKey, "#ffffff"));
    }

    public void reset(boolean z) {
        Log.d(TAG, "reset");
        if (z) {
            this.aperture = -1.0f;
        }
        this.zoom_factor = 0;
    }

    public void onDrawPreview(Canvas canvas) {
        if (!this.main_activity.isCameraInBackground()) {
            this.drawPreview.onDrawPreview(canvas);
        }
    }

    public int drawTextWithBackground(Canvas canvas, Paint paint, String text, int foreground, int background, int location_x, int location_y) {
        return drawTextWithBackground(canvas, paint, text, foreground, background, location_x, location_y, Alignment.ALIGNMENT_BOTTOM);
    }

    public int drawTextWithBackground(Canvas canvas, Paint paint, String text, int foreground, int background, int location_x, int location_y, Alignment alignment_y) {
        return drawTextWithBackground(canvas, paint, text, foreground, background, location_x, location_y, alignment_y, null, Shadow.SHADOW_OUTLINE);
    }

    public int drawTextWithBackground(Canvas canvas, Paint paint, String text, int foreground, int background, int location_x, int location_y, Alignment alignment_y, String ybounds_text, Shadow shadow) {
        return drawTextWithBackground(canvas, paint, text, foreground, background, location_x, location_y, alignment_y, null, shadow, null);
    }

    public int drawTextWithBackground(Canvas canvas, Paint paint, String text, int foreground, int background, int location_x, int location_y, Alignment alignment_y, String ybounds_text, Shadow shadow, Rect bounds) {
        final float scale = getContext().getResources().getDisplayMetrics().density;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(background);
        paint.setAlpha(255);
//        paint.setTypeface(ResourcesCompat.getFont(main_activity, R.font.avenir_next_pro_medium));
        if (bounds != null) {
            text_bounds.set(bounds);
        } else {
            int alt_height = 0;
            if (ybounds_text != null) {
                paint.getTextBounds(ybounds_text, 0, ybounds_text.length(), text_bounds);
                alt_height = text_bounds.bottom - text_bounds.top;
            }
            paint.getTextBounds(text, 0, text.length(), text_bounds);
            if (ybounds_text != null) {
                text_bounds.bottom = text_bounds.top + alt_height;
            }
        }
        final int padding = (int) (2 * scale + 0.5f); // convert dps to pixels
        if (paint.getTextAlign() == Paint.Align.RIGHT || paint.getTextAlign() == Paint.Align.CENTER) {
            float width = paint.measureText(text); // n.b., need to use measureText rather than getTextBounds here
			/*if( MyDebug.LOG )
				Log.d(TAG, "width: " + width);*/
            if (paint.getTextAlign() == Paint.Align.CENTER)
                width /= 2.0f;
            text_bounds.left -= width;
            text_bounds.right -= width;
        }
		/*if( MyDebug.LOG )
			Log.d(TAG, "text_bounds left-right: " + text_bounds.left + " , " + text_bounds.right);*/
        text_bounds.left += location_x - padding;
        text_bounds.right += location_x + padding;
        // unclear why we need the offset of -1, but need this to align properly on Galaxy Nexus at least
        int top_y_diff = -text_bounds.top + padding - 1;
        if (alignment_y == Alignment.ALIGNMENT_TOP) {
            int height = text_bounds.bottom - text_bounds.top + 2 * padding;
            text_bounds.top = location_y - 1;
            text_bounds.bottom = text_bounds.top + height;
            location_y += top_y_diff;
        } else if (alignment_y == Alignment.ALIGNMENT_CENTRE) {
            int height = text_bounds.bottom - text_bounds.top + 2 * padding;
            //int y_diff = - text_bounds.top + padding - 1;
            text_bounds.top = (int) (0.5 * ((location_y - 1) + (text_bounds.top + location_y - padding))); // average of ALIGNMENT_TOP and ALIGNMENT_BOTTOM
            text_bounds.bottom = text_bounds.top + height;
            location_y += (int) (0.5 * top_y_diff); // average of ALIGNMENT_TOP and ALIGNMENT_BOTTOM
        } else {
            text_bounds.top += location_y - padding;
            text_bounds.bottom += location_y + padding;
        }
//        if (shadow == Shadow.SHADOW_BACKGROUND) {
//            paint.setColor(background);
//            paint.setAlpha(64);
//            canvas.drawRect(text_bounds, paint);
//            paint.setAlpha(255);
//        }
//        paint.setColor(foreground);
        canvas.drawText(text, location_x, location_y, paint);
//        if (shadow == Shadow.SHADOW_OUTLINE) {
//            paint.setColor(background);
//            paint.setStyle(Paint.Style.STROKE);
//            float current_stroke_width = paint.getStrokeWidth();
//            paint.setStrokeWidth(1);
//            canvas.drawText(text, location_x, location_y, paint);
//            paint.setStyle(Paint.Style.FILL); // set back to default
//            paint.setStrokeWidth(current_stroke_width); // reset
//        }
        return text_bounds.bottom - text_bounds.top;
    }

    private boolean saveInBackground(boolean z) {
        return !z && !getPausePreviewPref();
    }

    public boolean isImageCaptureIntent() {
        String action = this.main_activity.getIntent().getAction();
        if (!"android.media.action.IMAGE_CAPTURE".equals(action) && !"android.media.action.IMAGE_CAPTURE_SECURE".equals(action)) {
            return false;
        }
        Log.d(TAG, "from image capture intent");
        return true;
    }

    private boolean forceSuffix(PhotoMode photoMode) {
        return photoMode == PhotoMode.FocusBracketing || photoMode == PhotoMode.FastBurst || (this.main_activity.getPreview().getCameraController() != null && this.main_activity.getPreview().getCameraController().isCapturingBurst());
    }

    private boolean saveImage(boolean save_expo, List<byte[]> images, Date current_date) {
        if (MyDebug.LOG)
            Log.d(TAG, "saveImage");

        System.gc();

        boolean image_capture_intent = isImageCaptureIntent();
        Uri image_capture_intent_uri = null;
        if (image_capture_intent) {
            if (MyDebug.LOG)
                Log.d(TAG, "from image capture intent");
            Bundle myExtras = main_activity.getIntent().getExtras();
            if (myExtras != null) {
                image_capture_intent_uri = myExtras.getParcelable(MediaStore.EXTRA_OUTPUT);
                if (MyDebug.LOG)
                    Log.d(TAG, "save to: " + image_capture_intent_uri);
            }
        }

        boolean using_camera2 = main_activity.getPreview().usingCamera2API();
        ImageSaver.Request.ImageFormat image_format = getImageFormatPref();
        boolean store_ypr = SharedPrefs.getBoolean(main_activity, PreferenceKeys.AddYPRToComments, false) &&
                main_activity.getPreview().hasLevelAngle() &&
                main_activity.getPreview().hasPitchAngle() &&
                main_activity.getPreview().hasGeoDirection();
        if (MyDebug.LOG) {
            Log.d(TAG, "store_ypr: " + store_ypr);
            Log.d(TAG, "has level angle: " + main_activity.getPreview().hasLevelAngle());
            Log.d(TAG, "has pitch angle: " + main_activity.getPreview().hasPitchAngle());
            Log.d(TAG, "has geo direction: " + main_activity.getPreview().hasGeoDirection());
        }
        int image_quality = getSaveImageQualityPref();
        if (MyDebug.LOG)
            Log.d(TAG, "image_quality: " + image_quality);
        boolean do_auto_stabilise = getAutoStabilisePref() && main_activity.getPreview().hasLevelAngleStable();
        double level_angle = (main_activity.getPreview().hasLevelAngle()) ? main_activity.getPreview().getLevelAngle() : 0.0;
        double pitch_angle = (main_activity.getPreview().hasPitchAngle()) ? main_activity.getPreview().getPitchAngle() : 0.0;
        if (do_auto_stabilise && main_activity.test_have_angle)
            level_angle = main_activity.test_angle;
        if (do_auto_stabilise && main_activity.test_low_memory)
            level_angle = 45.0;
        // I have received crashes where camera_controller was null - could perhaps happen if this thread was running just as the camera is closing?
        boolean is_front_facing = main_activity.getPreview().getCameraController() != null && (main_activity.getPreview().getCameraController().getFacing() == CameraController.Facing.FACING_FRONT);

        //TODO Change mirror

        //        boolean mirror = is_front_facing && SharedPrefs.getString(main_activity, PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no").equals("preference_front_camera_mirror_photo");
        boolean mirror = SharedPrefs.getString(main_activity, PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no").equals("preference_front_camera_mirror_photo");
        if (is_front_facing) {
            mirror = !mirror;
        }
        String preference_stamp = this.getStampPref();
        String preference_textstamp = this.getTextStampPref();
        int font_size = getTextStampFontSizePref();
        int color = getStampFontColor();
        String pref_style = SharedPrefs.getString(main_activity, PreferenceKeys.StampStyleKey, "preference_stamp_style_shadowed");
        String preference_stamp_dateformat = this.getStampDateFormatPref();
        String preference_stamp_timeformat = this.getStampTimeFormatPref();
        String preference_stamp_gpsformat = this.getStampGPSFormatPref();
        String preference_stamp_geo_address = this.getStampGeoAddressPref();
        String preference_units_distance = this.getUnitsDistancePref();
        boolean panorama_crop = SharedPrefs.getString(main_activity, PreferenceKeys.PanoramaCropPreferenceKey, "preference_panorama_crop_on").equals("preference_panorama_crop_on");
        boolean store_location = getGeotaggingPref() && getLocation() != null;
        Location location = store_location ? getLocation() : null;
        boolean store_geo_direction = main_activity.getPreview().hasGeoDirection() && getGeodirectionPref();
        double geo_direction = main_activity.getPreview().hasGeoDirection() ? main_activity.getPreview().getGeoDirection() : 0.0;
        String custom_tag_artist = SharedPrefs.getString(main_activity, PreferenceKeys.ExifArtistPreferenceKey, "");
        String custom_tag_copyright = SharedPrefs.getString(main_activity, PreferenceKeys.ExifCopyrightPreferenceKey, "");
        String preference_hdr_contrast_enhancement = SharedPrefs.getString(main_activity, PreferenceKeys.HDRContrastEnhancementPreferenceKey, "preference_hdr_contrast_enhancement_smart");

        int iso = 800; // default value if we can't get ISO
        long exposure_time = 1000000000L / 30; // default value if we can't get shutter speed
        float zoom_factor = 1.0f;
        if (main_activity.getPreview().getCameraController() != null) {
            if (main_activity.getPreview().getCameraController().captureResultHasIso()) {
                iso = main_activity.getPreview().getCameraController().captureResultIso();
                if (MyDebug.LOG)
                    Log.d(TAG, "iso: " + iso);
            }
            if (main_activity.getPreview().getCameraController().captureResultHasExposureTime()) {
                exposure_time = main_activity.getPreview().getCameraController().captureResultExposureTime();
                if (MyDebug.LOG)
                    Log.d(TAG, "exposure_time: " + exposure_time);
            }

            zoom_factor = main_activity.getPreview().getZoomRatio();
        }

        boolean has_thumbnail_animation = getThumbnailAnimationPref();

        boolean do_in_background = saveInBackground(image_capture_intent);

        String ghost_image_pref = SharedPrefs.getString(main_activity, PreferenceKeys.GhostImagePreferenceKey, "preference_ghost_image_off");

        int sample_factor = 1;
        if (!this.getPausePreviewPref() && !ghost_image_pref.equals("preference_ghost_image_last")) {
            // if pausing the preview, we use the thumbnail also for the preview, so don't downsample
            // similarly for ghosting last image
            // otherwise, we can downsample by 4 to increase performance, without noticeable loss in visual quality (even for the thumbnail animation)
            sample_factor *= 4;
            if (!has_thumbnail_animation) {
                // can use even lower resolution if we don't have the thumbnail animation
                sample_factor *= 4;
            }
        }
        if (MyDebug.LOG)
            Log.d(TAG, "sample_factor: " + sample_factor);

        boolean success;
        PhotoMode photo_mode = getPhotoMode();
        if (main_activity.getPreview().isVideo()) {
            if (MyDebug.LOG)
                Log.d(TAG, "snapshot mode");
            // must be in photo snapshot while recording video mode, only support standard photo mode
            photo_mode = PhotoMode.Standard;
        }

        if (!main_activity.is_test && photo_mode == PhotoMode.Panorama && gyroSensor.isRecording() && gyroSensor.hasTarget() && !gyroSensor.isTargetAchieved()) {
            if (MyDebug.LOG)
                Log.d(TAG, "ignore panorama image as target no longer achieved!");
            // n.b., gyroSensor.hasTarget() will be false if this is the first picture in the panorama series
            panorama_pic_accepted = false;
            success = true; // still treat as success
        } else if (photo_mode == PhotoMode.NoiseReduction || photo_mode == PhotoMode.Panorama) {
            boolean first_image;
            if (photo_mode == PhotoMode.Panorama) {
                panorama_pic_accepted = true;
                first_image = n_panorama_pics == 0;
            } else
                first_image = n_capture_images == 1;
            if (first_image) {
                ImageSaver.Request.SaveBase save_base = ImageSaver.Request.SaveBase.SAVEBASE_NONE;
                if (photo_mode == PhotoMode.NoiseReduction) {
                    String save_base_preference = SharedPrefs.getString(main_activity, PreferenceKeys.NRSaveExpoPreferenceKey, "preference_nr_save_no");
                    switch (save_base_preference) {
                        case "preference_nr_save_single":
                            save_base = ImageSaver.Request.SaveBase.SAVEBASE_FIRST;
                            break;
                        case "preference_nr_save_all":
                            save_base = ImageSaver.Request.SaveBase.SAVEBASE_ALL;
                            break;
                    }
                } else if (photo_mode == PhotoMode.Panorama) {
                    String save_base_preference = SharedPrefs.getString(main_activity, PreferenceKeys.PanoramaSaveExpoPreferenceKey, "preference_panorama_save_no");
                    switch (save_base_preference) {
                        case "preference_panorama_save_all":
                            save_base = ImageSaver.Request.SaveBase.SAVEBASE_ALL;
                            break;
                        case "preference_panorama_save_all_plus_debug":
                            save_base = ImageSaver.Request.SaveBase.SAVEBASE_ALL_PLUS_DEBUG;
                            break;
                    }
                }

                imageSaver.startImageBatch(true,
                        photo_mode == PhotoMode.NoiseReduction ? ImageSaver.Request.ProcessType.AVERAGE : ImageSaver.Request.ProcessType.PANORAMA,
                        save_base,
                        image_capture_intent, image_capture_intent_uri,
                        using_camera2,
                        image_format, image_quality,
                        do_auto_stabilise, level_angle, photo_mode == PhotoMode.Panorama,
                        is_front_facing,
                        mirror,
                        current_date,
                        iso,
                        exposure_time,
                        zoom_factor,
                        preference_stamp, preference_textstamp, font_size, color, pref_style, preference_stamp_dateformat, preference_stamp_timeformat, preference_stamp_gpsformat, preference_stamp_geo_address, preference_units_distance,
                        panorama_crop,
                        store_location, location, store_geo_direction, geo_direction,
                        pitch_angle, store_ypr,
                        custom_tag_artist, custom_tag_copyright,
                        sample_factor);

                if (photo_mode == PhotoMode.Panorama) {
                    imageSaver.getImageBatchRequest().camera_view_angle_x = main_activity.getPreview().getViewAngleX(false);
                    imageSaver.getImageBatchRequest().camera_view_angle_y = main_activity.getPreview().getViewAngleY(false);
                }
            }

            float[] gyro_rotation_matrix = null;
            if (photo_mode == PhotoMode.Panorama) {
                gyro_rotation_matrix = new float[9];
                this.gyroSensor.getRotationMatrix(gyro_rotation_matrix);
            }

            imageSaver.addImageBatch(images.get(0), gyro_rotation_matrix);
            success = true;
        } else {
            boolean is_hdr = photo_mode == PhotoMode.DRO || photo_mode == PhotoMode.HDR;
            boolean force_suffix = forceSuffix(photo_mode);
            success = imageSaver.saveImageJpeg(do_in_background, is_hdr,
                    force_suffix,
                    // N.B., n_capture_images will be 1 for first image, not 0, so subtract 1 so we start off from _0.
                    // (It wouldn't be a huge problem if we did start from _1, but it would be inconsistent with the naming
                    // of images where images.size() > 1 (e.g., expo bracketing mode) where we also start from _0.)
                    force_suffix ? (n_capture_images - 1) : 0,
                    save_expo, images,
                    image_capture_intent, image_capture_intent_uri,
                    using_camera2,
                    image_format, image_quality,
                    do_auto_stabilise, level_angle,
                    is_front_facing,
                    mirror,
                    current_date,
                    preference_hdr_contrast_enhancement,
                    iso,
                    exposure_time,
                    zoom_factor,
                    preference_stamp, preference_textstamp, font_size, color, pref_style, preference_stamp_dateformat, preference_stamp_timeformat, preference_stamp_gpsformat, preference_stamp_geo_address, preference_units_distance,
                    false, // panorama doesn't use this codepath
                    store_location, location, store_geo_direction, geo_direction,
                    pitch_angle, store_ypr,
                    custom_tag_artist, custom_tag_copyright,
                    sample_factor);
        }

        if (MyDebug.LOG)
            Log.d(TAG, "saveImage complete, success: " + success);

        return success;
    }

    public boolean onPictureTaken(byte[] bArr, Date date) {
        Log.d(TAG, "onPictureTaken");
        this.n_capture_images++;
        Log.d(TAG, "n_capture_images is now " + this.n_capture_images);
        ArrayList arrayList = new ArrayList();
        arrayList.add(bArr);
        boolean saveImage = saveImage(false, arrayList, date);
        Log.d(TAG, "onPictureTaken complete, success: " + saveImage);
        return saveImage;
    }

    public boolean onBurstPictureTaken(List<byte[]> list, Date date) {
        Log.d(TAG, "onBurstPictureTaken: received " + list.size() + "images");
        PhotoMode photoMode = getPhotoMode();
        if (this.main_activity.getPreview().isVideo()) {
            Log.d(TAG, "snapshot mode");
            photoMode = PhotoMode.Standard;
        }
        if (photoMode == PhotoMode.HDR) {
            Log.d(TAG, "HDR mode");
            boolean z = SharedPrefs.getBoolean(main_activity, PreferenceKeys.HDRSaveExpoPreferenceKey, false);
            Log.d(TAG, "save_expo: " + z);
            return saveImage(z, list, date);
        }
        Log.d(TAG, "exposure/focus bracketing mode mode");
        if (!(photoMode == PhotoMode.ExpoBracketing || photoMode == PhotoMode.FocusBracketing)) {
            Log.e(TAG, "onBurstPictureTaken called with unexpected photo mode?!: " + photoMode);
        }
        return saveImage(true, list, date);
    }

    public boolean onRawPictureTaken(RawImage rawImage, Date date) {
        Log.d(TAG, "onRawPictureTaken");
        System.gc();
        this.n_capture_images_raw++;
        Log.d(TAG, "n_capture_images_raw is now " + this.n_capture_images_raw);
        boolean saveInBackground = saveInBackground(false);
        PhotoMode photoMode = getPhotoMode();
        if (this.main_activity.getPreview().isVideo()) {
            Log.d(TAG, "snapshot mode");
            photoMode = PhotoMode.Standard;
        }
        boolean forceSuffix = forceSuffix(photoMode);
        boolean saveImageRaw = this.imageSaver.saveImageRaw(saveInBackground, forceSuffix, forceSuffix ? this.n_capture_images_raw - 1 : 0, rawImage, date);
        Log.d(TAG, "onRawPictureTaken complete");
        return saveImageRaw;
    }

    public boolean onRawBurstPictureTaken(List<RawImage> list, Date date) {
        Log.d(TAG, "onRawBurstPictureTaken");
        System.gc();
        boolean saveInBackground = saveInBackground(false);
        boolean z = true;
        for (int i = 0; i < list.size() && z; i++) {
            z = this.imageSaver.saveImageRaw(saveInBackground, true, i, list.get(i), date);
        }
        Log.d(TAG, "onRawBurstPictureTaken complete");
        return z;
    }

    public void addLastImage(File file, boolean z) {
        Log.d(TAG, "addLastImage: " + file);
        Log.d(TAG, "share?: " + z);
        this.last_images_saf = false;
        this.last_images.add(new LastImage(file.getAbsolutePath(), z));
    }

    public void addLastImageSAF(Uri uri, boolean z) {
        Log.d(TAG, "addLastImageSAF: " + uri);
        Log.d(TAG, "share?: " + z);
        this.last_images_saf = true;
        this.last_images.add(new LastImage(uri, z));
    }

    public void clearLastImages() {
        Log.d(TAG, "clearLastImages");
        this.last_images_saf = false;
        this.last_images.clear();
        this.drawPreview.clearLastImage();
    }


    private void trashImage(LastImagesType lastImagesType, Uri uri, String str, boolean z) {
        Log.d(TAG, "trashImage");
        Preview preview = this.main_activity.getPreview();
        if (lastImagesType == LastImagesType.SAF && uri != null) {
            Log.d(TAG, "Delete SAF: " + uri);
            File fileFromDocumentUriSAF = this.storageUtils.getFileFromDocumentUriSAF(uri, false);
            try {
                if (!DocumentsContract.deleteDocument(this.main_activity.getContentResolver(), uri)) {
                    Log.e(TAG, "failed to delete " + uri);
                    return;
                }
                Log.d(TAG, "successfully deleted " + uri);
                if (z) {
                    preview.showToast((ToastBoxer) null, (int) R.string.photo_deleted);
                }
                if (fileFromDocumentUriSAF != null) {
                    this.storageUtils.broadcastFile(fileFromDocumentUriSAF, false, false, true);
                }
            } catch (FileNotFoundException e) {
                Log.e(TAG, "exception when deleting " + uri);
                e.printStackTrace();
            }
        } else if (lastImagesType == LastImagesType.MEDIASTORE && uri != null) {
            Log.d(TAG, "Delete MediaStore: " + uri);
            this.main_activity.getContentResolver().delete(uri, (String) null, (String[]) null);
        } else if (str != null) {
            Log.d(TAG, "Delete: " + str);
            File file = new File(str);
            if (!file.delete()) {
                Log.e(TAG, "failed to delete " + str);
                return;
            }
            Log.d(TAG, "successfully deleted " + str);
            if (z) {
                preview.showToast(this.photo_delete_toast, (int) R.string.photo_deleted);
            }
            this.storageUtils.broadcastFile(file, false, false, true);
        }
    }

    public void trashLastImage() {
        Log.d(TAG, "trashLastImage");
        Preview preview = this.main_activity.getPreview();
        if (preview.isPreviewPaused()) {
            for (int i = 0; i < this.last_images.size(); i++) {
                LastImage lastImage = this.last_images.get(i);
                trashImage(this.last_images_type, lastImage.uri, lastImage.name, true);
            }
            clearLastImages();
            this.drawPreview.clearGhostImage();
            preview.startCameraPreview();
        }
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            public void run() {
                MyApplicationInterface.this.main_activity.updateGalleryIcon();
            }
        }, 500);
    }

    public void scannedFile(File file, Uri uri) {
        Log.d(TAG, "scannedFile");
        Log.d(TAG, "file: " + file);
        Log.d(TAG, "uri: " + uri);
        for (int i = 0; i < this.last_images.size(); i++) {
            LastImage lastImage = this.last_images.get(i);
            Log.d(TAG, "compare to last_image: " + lastImage.name);
            if (lastImage.uri == null && lastImage.name != null && lastImage.name.equals(file.getAbsolutePath())) {
                Log.d(TAG, "updated last_image : " + i);
                lastImage.uri = uri;
            }
        }
    }

    public boolean hasThumbnailAnimation() {
        return this.drawPreview.hasThumbnailAnimation();
    }

    public HDRProcessor getHDRProcessor() {
        return this.imageSaver.getHDRProcessor();
    }

    public PanoramaProcessor getPanoramaProcessor() {
        return this.imageSaver.getPanoramaProcessor();
    }

    public int toSP(float f) {
        return (int) TypedValue.applyDimension(2, f, this.main_activity.getResources().getDisplayMetrics());
    }

    public Bitmap loadBitmapFromView(View view) {
        try {

//            view.measure(0, 0);
//            Bitmap createBitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
//            Canvas canvas = new Canvas(createBitmap);
//            view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
//            view.draw(canvas);
//            System.gc();


            view.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
            Bitmap bitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);

            view.draw(canvas);
            System.gc();

            return bitmap;
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
            return null;
        }
    }

    public void finishVideoIntent(Uri uri) {
        Log.d(TAG, "finishVideoIntent:" + uri);
        Intent intent = new Intent();
        intent.setData(uri);
        this.main_activity.setResult(-1, intent);
        this.main_activity.finish();
    }

    public void addLastImageMediaStore(Uri uri, boolean z) {
        Log.d(TAG, "addLastImageMediaStore: " + uri);
        Log.d(TAG, "share?: " + z);
        this.last_images_type = LastImagesType.MEDIASTORE;
        this.last_images.add(new LastImage(uri, z));
    }

    public Bitmap getCameraSnapShot() {
        return main_activity.getCameraSnapShot();
    }

    public View getCameraSnapShotView() {
        return main_activity.getCameraSnapShotView();
    }

    public Float getCameraSnapShotX() {
        return main_activity.getCameraSnapShotX();
    }

    public Float getCameraSnapShotY() {
        return main_activity.getCameraSnapShotY();
    }

    public int getCameraCurrentOrientation() {
        return main_activity.getCameraCurrentOrientation();
    }
}
