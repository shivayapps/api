package com.gallery.photo.image.video.Camera.fragments;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gallery.photo.image.video.Camera.CameraActivity;
import com.gallery.photo.image.video.Camera.PreferenceKeys;
import com.gallery.photo.image.video.Camera.adapter.RatioAdapter;
import com.gallery.photo.image.video.Camera.cameracontroller.CameraController;
import com.gallery.photo.image.video.Camera.onRecyclerClickListener;
import com.gallery.photo.image.video.Camera.preview.Preview;
import com.gallery.photo.image.video.R;
import com.gallery.photo.image.video.utilities.SharedPrefs;

import java.util.ArrayList;
import java.util.List;

public class RatioFragment extends Fragment implements View.OnClickListener {
    public RatioAdapter mRatioAdapter;
    RecyclerView mRatioRecycler;

    private RelativeLayout mToolbar_back;
    private RelativeLayout mToolbar_done;
    private RelativeLayout rlRatioAndGrid;
    CameraActivity cameraActivity;
    private TextView mtv_toolbar_title;
    private Preview preview;
    int ratioPos;
    List<CameraController.Size> ratio_entries = new ArrayList();
    String resolution_string;

    public RatioFragment(CameraActivity cameraActivity2) {
        this.cameraActivity = cameraActivity2;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_ratio, viewGroup, false);
    }

    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
//        this.mToolbar_back = (RelativeLayout) view.findViewById(R.id.toolbar_back);
//        this.mToolbar_done = (RelativeLayout) view.findViewById(R.id.toolbar_done);
//        this.rlRatioAndGrid = (RelativeLayout) view.findViewById(R.id.rlRatioAndGrid);
//        TextView textView = (TextView) view.findViewById(R.id.tv_toolbar_title);
//        this.mtv_toolbar_title = textView;
//        textView.setText(getString(R.string.ratio));
        this.preview = this.cameraActivity.getPreview();

        this.ratioPos = getRatioPos();
        this.ratio_entries = this.preview.getSupportedPictureSizes(true);
        this.mRatioRecycler = (RecyclerView) view.findViewById(R.id.grid_recyclerView);
        setAdapter();
        onCliks();
    }

    private void onCliks() {
        mToolbar_back.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                RatioFragment.this.onClick(view);
            }
        });
        mToolbar_done.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                RatioFragment.this.onClick(view);
            }
        });
        rlRatioAndGrid.setOnClickListener(v -> {

        });
    }


    private int getRatioPos() {
        return SharedPrefs.getInt(getActivity(), PreferenceKeys.getRatioPos_PrefrenceKey(this.preview.getCameraId()), 0);
    }

    private void setAdapter() {
        this.mRatioRecycler.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        RatioAdapter ratioAdapter = new RatioAdapter(getActivity(), this.preview, this.ratio_entries, new onRecyclerClickListener() {
            public void setOnItemClickListener(int i, View view) {
                if (i >= 0 && i < RatioFragment.this.ratio_entries.size()) {
                    RatioFragment.this.ratioPos = i;
                    CameraController.Size size = RatioFragment.this.ratio_entries.get(i);
                    RatioFragment ratioFragment = RatioFragment.this;
                    ratioFragment.resolution_string = size.width + " " + size.height;
                }
            }
        });
        this.mRatioAdapter = ratioAdapter;
        this.mRatioRecycler.setAdapter(ratioAdapter);
    }

    public void onClick(View view) {
        switch (view.getId()) {
//            case R.id.toolbar_back /*2131362454*/:
//                doBack();
//                return;
//            case R.id.toolbar_done /*2131362455*/:
//                saveData();
//                return;
            default:
                return;
        }
    }

    public void onAttach(Context context) {
        super.onAttach(context);
        if (getActivity() != null) {

            ((CameraActivity) getActivity()).hideUi();
            ((CameraActivity) getActivity()).setOnBackPressedListener(new CameraActivity.OnBackPressedListener() {
                public void onBackPressed() {
                    RatioFragment.this.doBack();
                }
            });

        }
    }

    /* access modifiers changed from: private */
    public void doBack() {
        if (isChanges()) {
            confirmDialog_();
        } else {
            getActivity().getSupportFragmentManager().popBackStack();
        }
    }

    private boolean isChanges() {
        return this.ratioPos != getRatioPos();
    }

    public void onDetach() {
        super.onDetach();
        if (getActivity() != null) {
            ((CameraActivity) getActivity()).showUI();
            ((CameraActivity) getActivity()).updateForSettings("", true);
            ((CameraActivity) getActivity()).setOnBackPressedListener((CameraActivity.OnBackPressedListener) null);
        }
    }

    private void confirmDialog() {
        if (!isRemoving()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage((CharSequence) getString(R.string.discard_message));
            builder.setPositiveButton((CharSequence) getString(R.string.save), (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    RatioFragment.this.saveData();
                }
            });
            builder.setNegativeButton((CharSequence) getString(R.string.discard), (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    RatioFragment.this.getActivity().getSupportFragmentManager().popBackStack();
                }
            });
            builder.create().show();
        }
    }

    private void confirmDialog_() {

//        Dialog dialog = new BottomSheetDialog(cameraActivity, R.style.Transparent);
//        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
//        dialog.setContentView(R.layout.dialog_confirm_camera);
//        dialog.setCanceledOnTouchOutside(true);
//
//        TextView tvNo = dialog.findViewById(R.id.tvNo);
//        TextView tvYes = dialog.findViewById(R.id.tvYes);
//
//        tvNo.setOnClickListener(new OnSingleClickListener() {
//            @Override
//            public void onSingleClick(@Nullable View v) {
//
//                dialog.dismiss();
//                RatioFragment.this.getActivity().getSupportFragmentManager().popBackStack();
//
//            }
//        });
//
//        tvYes.setOnClickListener(new OnSingleClickListener() {
//            @Override
//            public void onSingleClick(@Nullable View v) {
//                dialog.dismiss();
//                RatioFragment.this.saveData();
//
//            }
//        });
//
//        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
//        Window window = dialog.getWindow();
//        lp.copyFrom(window.getAttributes());
//        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
//        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
//        window.setAttributes(lp);
//
//        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//        window.setStatusBarColor(Color.TRANSPARENT);
//        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
//        dialog.show();

    }

    public void saveData() {

        if (resolution_string != null && !resolution_string.isEmpty()) {
            SharedPrefs.save(getActivity(), PreferenceKeys.getResolutionPreferenceKey(preview.getCameraId()), resolution_string);
            SharedPrefs.save(getActivity(), PreferenceKeys.getRatioPos_PrefrenceKey(preview.getCameraId()), ratioPos);
        }
        getActivity().getSupportFragmentManager().popBackStack();

    }

}
