package com.gallery.photo.image.video.models

data class AlbumCover(val path: String, val tmb: String)
