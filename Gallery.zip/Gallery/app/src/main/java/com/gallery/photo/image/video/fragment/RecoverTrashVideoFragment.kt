package com.gallery.photo.image.video.fragment

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.MediaActivity
import com.gallery.photo.image.video.activityBinding.RecoverPhotoTabActivity
import com.gallery.photo.image.video.activityBinding.TrashActivity
import com.gallery.photo.image.video.activityBinding.TrashImagePreviewActivity
import com.gallery.photo.image.video.adapter.RecoverTrashAdapter
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.databinding.FragmentTrashImageBinding
import com.gallery.photo.image.video.dialog.DeleteWithRememberDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.videoplayer.VideoPlayerActivity
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.helpers.FAVORITES
import com.gallery.photo.image.video.helpers.VIEW_TYPE_GRID
import com.gallery.photo.image.video.helpers.VIEW_TYPE_LIST
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager
import com.gallery.photo.image.video.views.MyRecyclerView
import org.jetbrains.anko.toast
import java.io.File
import java.util.HashMap


class RecoverTrashVideoFragment : BaseBindingFragment<FragmentTrashImageBinding>(), MediaOperationsListener {


    var title: String? = null
    private var mPath = ""
    private var mIsGetImageIntent = true
    private var mIsGetVideoIntent = false
    private var mIsGetAnyIntent = false
    private var mAllowPickingMultiple = false
    private var mShowAll = false

    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mLastSearchedText = ""
    var itemClickPath: String = ""
    var isShowInfo = false
    var isHide = true
    var isFromVault = false
    var isFromFakeVault = false
    var mMedia = ArrayList<ThumbnailItem>()
    private var uriList = ArrayList<Uri>()
    var isFirstTime = true

    companion object {
        var isNeedToRefresh = false

        @JvmStatic
        fun newInstance() =
            RecoverTrashVideoFragment().apply {
            }
    }

    override fun setBinding(layoutInflater: LayoutInflater, container: ViewGroup?): FragmentTrashImageBinding {
        return FragmentTrashImageBinding.inflate(layoutInflater, container, false)
    }

    override fun initView() {
        super.initView()
        mBinding.mediaRefreshLayout.setOnRefreshListener { getMedia() }
        getMedia()
    }


    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume: isNeedToRefresh" + isNeedToRefresh)
        if (isNeedToRefresh) {
            isNeedToRefresh = false
            getMedia()
        }
    }

    private fun getMedia() {
        mBinding.lottieProgressbar.visibility = View.VISIBLE
        if (getTrashAdapter() != null)
            getTrashAdapter()!!.finishActMode()
        AsyncBackgroundWork(
            {

                if (isFirstTime && !TrashActivity.isTrashDialogShown) {
                    isFirstTime = false
                    if (mContext is TrashActivity) {
                        (mContext as TrashActivity).showProgress(mContext.getString(R.string.please_wait))
                    }
                }
            }, {
                if (isAdded) {
                    var newMedia: ArrayList<Medium> = requireContext().mediaDB.getAllTypeDeletedMedia(RECOVER_TRASH_BIN, TYPE_VIDEOS) as ArrayList<Medium>
                    Log.d(TAG, "getMedia: -->" + newMedia.size)
                    newMedia.filter {
                        var path = File(mContext.recoverTrashPath, it.path.removePrefix(RECOVER_TRASH_BIN)).toString()
                        !mContext.getDoesFilePathExist(path)
                    }.forEach {
                        if (VaultFragment.isFakeVaultOpen)
                            mContext.fakeVaultMediumDao.deleteMediumPath(it.path)
                        else
                            mContext.mediaDB.deleteMediumPath(it.path)
                    }
                    val mediaFetcher = MediaFetcher(mContext)
                    var media = mContext.getUpdatedRecoverTrashMediaPath(newMedia as ArrayList<Medium>)
                    mMedia = mediaFetcher.groupMediaForTimeLine(media, SHOW_ALL, GROUP_BY_LAST_MODIFIED_DAILY, true, false)
                }
            }, {
                if (isAdded) {
                    requireActivity().runOnUiThread {
                        Log.d(TAG, "getMedia: Media size -->" + mMedia.size)
                        mBinding.rlNoFileFound.beVisibleIf(mMedia.isEmpty())
                        mBinding.rlNoFileFound.beGoneIf(mMedia.isNotEmpty())
                        mBinding.mediaGrid.beVisibleIf(mBinding.rlNoFileFound.isGone())
                        mBinding.mediaRefreshLayout.isRefreshing = false
                        if (mContext is RecoverPhotoTabActivity) {
                            if ((mContext as RecoverPhotoTabActivity).mBinding.viewPagerRecover.currentItem == 1) {
                                (mContext as RecoverPhotoTabActivity).mBinding.imgDelete.beGoneIf(mMedia.size <= 0)
                                (mContext as RecoverPhotoTabActivity).mBinding.imgDelete.beVisibleIf(mMedia.size > 0)
                            }
                        }

                        setupAdapter()
                    }
                }
            }
        )

    }

    private fun setupAdapter() {
        Log.d("TAG", "setupAdapter: " + mMedia.size.toString())

        val fastscroller = if (mContext.config.scrollHorizontally) mBinding.mediaHorizontalFastscroller else mBinding.mediaVerticalFastscroller

        RecoverTrashAdapter(
            mContext as BaseSimpleActivity, mMedia, this, mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent,
            mAllowPickingMultiple, mPath, mBinding.mediaGrid, fastscroller, true
        ) {
            if (it is Medium) {
                itemClicked(it.path)
            }
        }.apply {
            mBinding.mediaGrid.adapter = this
        }

        val viewType = mContext.config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_LIST) {
            mBinding.mediaGrid.scheduleLayoutAnimation()
        }
        setupLayoutManager()


        setupScrollDirection()
        Handler(Looper.getMainLooper()).postDelayed({
            if (isAdded) {
                if (mContext is TrashActivity) {
                    (mContext as TrashActivity).dismissProgress()
                }
                mBinding.lottieProgressbar.visibility = View.GONE
            }
        }, 1000)

    }


    private fun itemClicked(path: String) {
        if (isAdded) {
            if (mContext.config.isAnyOperationRunning) {
                mContext.toast(getString(R.string.msg_operation_already_running))
                return
            }
        }

        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        itemClickPath = path

        val isVideo = path.isVideoFast()
        if (isVideo) {
            ensureBackgroundThread {
                var media = MediaActivity.mMedia as ArrayList<Medium>
                media = media.filter { medium ->
                    medium.isVideo() && medium.path.getFilenameExtension() != ".avi" && medium.path.getFilenameExtension() != ".flv"
                } as ArrayList<Medium>
                uriList = media.map {
                    FileProvider.getUriForFile(
                        mContext,
                        "${mContext.packageName}.fileprovider", File(it.path)
                    )
                } as ArrayList<Uri>
            }
//            if (MainActivity.isAdShown) {
            loadVideo(path)
//            } else {
//                if (AdsManager(mContext).isNeedToShowAds() && mContext.isOnline()) {
//                    if (interstitialAdShow != null) {
//                        if (!mContext.config.isAppInBackGround) {
//                            isInterstitialShown = true
//                            interstitialAdShow!!.show(mContext)
//                        }
//                    } else {
//                        if (OfflineNativeAdvancedHelper.unNativeAd != null) {
//                            try {
//                                FullScreenNativeAdDialog(activity = mContext) {
//                                    isInterstitialShown = false
//                                    loadVideo(path)
//                                }.showFullScreenNativeAdDialog()
//                            } catch (e: java.lang.Exception) {
//                                isInterstitialShown = false
//                                loadVideo(path)
//                            }
//                        } else {
//                            isInterstitialShown = false
//                            loadVideo(path)
//                        }
//                    }
//                } else {
//                    isInterstitialShown = false
//                    loadVideo(path)
//                }
//            }
        } else {
            Intent(mContext, TrashImagePreviewActivity::class.java).apply {
                putExtra(SKIP_AUTHENTICATION, false)
                putExtra(PATH, path)
                putExtra(SHOW_ALL, mShowAll)
                putExtra(SHOW_ONLY_HIDDEN, true)
                putExtra(SHOW_FAVORITES, mPath == FAVORITES)
                putExtra(SHOW_RECYCLE_BIN, mPath == RECYCLE_BIN)
                putExtra(IS_FROM_FAKE_VAULT, isFromFakeVault)
                putExtra(IS_FROM_VAULT, isFromVault)
                putExtra(IS_FROM_RECOVER_TRASH, true)

                startActivity(this)
            }
        }

    }

    private fun loadVideo(path: String) {
        val extras = HashMap<String, Boolean>()
        extras[SHOW_FAVORITES] = mPath == FAVORITES
        val uri = FileProvider.getUriForFile(
            mContext,
            "${mContext.packageName}.fileprovider", File(path)
        )


        val mimeType = mContext.getUriMimeType(path, uri)
        if (VideoPlayerActivity.mActivity != null) {
            VideoPlayerActivity.mActivity.finish()
        }

        val extension: String = uri.path!!.substring(uri.path!!.lastIndexOf("."))

        if (extension == ".avi" || extension == ".flv") {
            val file: File = File(uri.path)
            Log.e("TAG", "loadVideo:absolutePath --> " + file.absolutePath)

            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(Uri.parse(file.absolutePath.replace("/external_files", "")), "video/*")
            try {
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(getContext(), R.string.error_no_video_activity, Toast.LENGTH_SHORT).show()
            }

        } else {
            VideoPlayerActivity.UriList = uriList
            VideoPlayerActivity.index = uriList.indexOf(uri)
            Intent(mContext, VideoPlayerActivity::class.java).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT)
                startActivity(this)
            }
        }
    }

    private fun setupLayoutManager() {
        val viewType = mContext.config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            setupGridLayoutManager()
        } else {
            setupListLayoutManager()
        }
    }

    private fun setupGridLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = 0
            bottomMargin = 0
        }

        try {
            if (mContext.config.scrollHorizontally) {
                layoutManager.orientation = RecyclerView.HORIZONTAL
            } else {
                layoutManager.orientation = RecyclerView.VERTICAL
            }
        } catch (e: Exception) {
        }

//        layoutManager.spanCount = mContext.config.mediaColumnCnt
        layoutManager.spanCount = 3
        val adapter = getTrashAdapter()
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter?.isASectionTitle(position) == true) {
                    layoutManager.spanCount
                } else {
                    1
                }
            }
        }
    }

    private fun getTrashAdapter() = mBinding.mediaGrid.adapter as? RecoverTrashAdapter
    private fun setupListLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL

        val smallMargin = resources.getDimension(R.dimen.small_margin).toInt()
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = smallMargin
            bottomMargin = smallMargin
        }
    }

    private fun setupScrollDirection() {
        val viewType = mContext.config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        val allowHorizontalScroll = mContext.config.scrollHorizontally && viewType == VIEW_TYPE_GRID
        mBinding.mediaVerticalFastscroller.isHorizontal = false
        mBinding.mediaVerticalFastscroller.beGoneIf(allowHorizontalScroll)

        mBinding.mediaHorizontalFastscroller.isHorizontal = true
        mBinding.mediaHorizontalFastscroller.beVisibleIf(allowHorizontalScroll)

    }


    override fun refreshItems() {
        if (isAdded) {
            getMedia()
        }

    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {
        val filtered = fileDirItems.filter { !mContext.getIsPathDirectory(it.path) && it.path.isMediaFile() } as ArrayList
        if (filtered.isEmpty()) {
            return
        }
        Log.d(TAG, "tryDeleteFiles: Filtered File size -->" + filtered.size)
        VideoDirectoryFragment.isNeedToRefresh=true
        deleteFilteredFiles(filtered)
    }

    private fun deleteFilteredFiles(filtered: ArrayList<FileDirItem>) {
        (mContext as BaseSimpleActivity).deleteFiles(filtered) {
            if (!it) {
                mContext.toast(R.string.unknown_error_occurred)
                if (getTrashAdapter() != null)
                    getTrashAdapter()!!.dismissProgress()
                if (mContext is TrashActivity)
                    (mContext as TrashActivity).dismissProgress()
                return@deleteFiles
            }

//            mMedia.removeAll { filtered.map { it.path }.contains((it as? Medium)?.path) }

            ensureBackgroundThread {

                filtered.forEach {
                    if (isAdded) {
                        if (VaultFragment.isFakeVaultOpen)
                            mContext.fakeVaultMediumDao.deleteMediumPath(it.path.replace("${mContext.recoverTrashPath}", RECOVER_TRASH_BIN))
                        else
                            mContext.mediaDB.deleteMediumPath(it.path.replace("${mContext.recoverTrashPath}", RECOVER_TRASH_BIN))
                    }
                }
                if (mPath.containsNoMedia() || filtered[0].path.getFilenameFromPath().startsWith(".")) {
                    if (mContext.hiddenDirectoryDao.getDirectoryThumbnail(mPath) != null) {
                        mContext.updatePhotoVideoDirectoryPath(mPath, true, false, true)
                    }
                }
                Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Image  ---> ")
                if (isAdded) {
                    mContext.updatePhotoVideoDirectoryPath(mPath, true, false)
                }

                if (isAdded) {
                    mContext.runOnUiThread {
                        mContext.addEvent(deleteRecoverTrash)
                        if (getTrashAdapter() != null)
                            getTrashAdapter()!!.dismissProgress()
                        if (mContext is TrashActivity)
                            (mContext as TrashActivity).dismissProgress()
                        refreshItems()
                    }
                }
            }


        }
    }

    override fun selectedPaths(paths: ArrayList<String>) {

    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {

    }

    fun restoreVideos() {
        if (getTrashAdapter() != null) {
            getTrashAdapter()!!.restoreFiles(false)
        }
    }

    fun deleteVideos() {
        if (getTrashAdapter() != null) {
            getTrashAdapter()!!.checkDeleteConfirmation()
        }
    }

    fun deleteAllVideos() {
        if (mMedia.isEmpty())
            return
        val deletedMedia = ArrayList<Medium>()
        mMedia.forEach {
            if (it is Medium)
                deletedMedia.add(it)
        }
        val itemsCnt = deletedMedia.size
        val firstPath = deletedMedia.first().path
        val items = if (itemsCnt == 1) {
            "\"${firstPath.getFilenameFromPath()}\""
        } else {
            resources.getQuantityString(R.plurals.delete_items, itemsCnt, itemsCnt)
        }

        val baseString = R.string.deletion_confirmation
        val question = String.format(resources.getString(baseString), items)
        DeleteWithRememberDialog(mContext, question) {
            if (it) {
                RecoverPhotoTabActivity.isDeleteOrRestore=true
                if (mContext is TrashActivity)
                    (mContext as TrashActivity).showProgress(mContext.getString(R.string.msg_deleting))
                mContext.config.tempSkipDeleteConfirmation = it
                val fileDirItems = ArrayList<FileDirItem>(mMedia.size)
                deletedMedia.forEach {
                    fileDirItems.add(FileDirItem(it.path, it.name))
                }
                tryDeleteFiles(fileDirItems)
            }

        }
    }
}