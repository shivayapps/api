package com.gallery.photo.image.video.Camera;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.renderscript.Allocation;
import android.util.Log;
import android.util.Xml;
import android.view.Display;
import android.view.View;

import androidx.exifinterface.media.ExifInterface;

import com.bumptech.glide.load.Key;

import com.example.jdrodi.utilities.GeneralUtilsKt;
import com.gallery.photo.image.video.Camera.cameracontroller.CameraController;
import com.gallery.photo.image.video.Camera.cameracontroller.RawImage;
import com.gallery.photo.image.video.R;
import com.gallery.photo.image.video.cameraview.CameraUtils;
import com.gallery.photo.image.video.utilities.NetworkManager;
import com.gallery.photo.image.video.utilities.SharedPrefs;
import com.gallery.photo.image.video.extensions.ContextKt;
//import com.google.firebase.analytics.FirebaseAnalytics;
//import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlSerializer;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ImageSaver extends Thread {
    private static final String TAG = "ImageSaver";
    private static final String gyro_info_camera_view_angle_x_tag = "camera_view_angle_x";
    private static final String gyro_info_camera_view_angle_y_tag = "camera_view_angle_y";
    private static final String gyro_info_doc_tag = "open_camera_gyro_info";
    private static final String gyro_info_image_tag = "image";
    private static final String gyro_info_panorama_pics_per_screen_tag = "panorama_pics_per_screen";
    private static final String gyro_info_vector_right_type = "X";
    private static final String gyro_info_vector_screen_type = "Z";
    private static final String gyro_info_vector_tag = "vector";
    private static final String gyro_info_vector_up_type = "Y";
    private static final int queue_cost_dng_c = 6;
    private static final int queue_cost_jpeg_c = 1;
    public static volatile boolean test_small_queue_size;
    private boolean app_is_paused = true;
    private final HDRProcessor hdrProcessor;
    /* access modifiers changed from: private */
    public final CameraActivity main_activity;
    private int n_images_to_save = 0;
    private int n_real_images_to_save = 0;
    private final Paint p;
    private final PanoramaProcessor panoramaProcessor;
    private Request pending_image_average_request = null;
    private final BlockingQueue<Request> queue;
    private final int queue_capacity;
    public volatile boolean test_queue_blocked;
    public volatile boolean test_slow_saving;
    private int customOrientation = 0;

    public static class GyroDebugInfo {
        public final List<GyroImageDebugInfo> image_info = new ArrayList();

        public static class GyroImageDebugInfo {
            public float[] vectorRight;
            public float[] vectorScreen;
            public float[] vectorUp;
        }
    }

    private boolean needGPSTimestampHack(boolean z, boolean z2, boolean z3) {
        if (!z || !z2) {
            return false;
        }
        return z3;
    }

    static class Request {
        float camera_view_angle_x;
        float camera_view_angle_y;
        final int color;
        final Date current_date;
        final String custom_tag_artist;
        final String custom_tag_copyright;
        boolean do_auto_stabilise;
        final long exposure_time;
        final int font_size;
        final boolean force_suffix;
        final double geo_direction;
        final List<float[]> gyro_rotation_matrix;
        final boolean image_capture_intent;
        final Uri image_capture_intent_uri;
        ImageFormat image_format;
        int image_quality;
        final boolean is_front_facing;
        final int iso;
        final List<byte[]> jpeg_images;
        final double level_angle;
        final Location location;
        boolean mirror;
        final boolean panorama_crop;
        boolean panorama_dir_left_to_right;
        final double pitch_angle;
        final String pref_style;
        final String preference_hdr_contrast_enhancement;
        String preference_stamp;
        final String preference_stamp_dateformat;
        final String preference_stamp_geo_address;
        final String preference_stamp_gpsformat;
        final String preference_stamp_timeformat;
        String preference_textstamp;
        final String preference_units_distance;
        final ProcessType process_type;
        final RawImage raw_image;
        final int sample_factor;
        final SaveBase save_base;
        final boolean store_geo_direction;
        final boolean store_location;
        final boolean store_ypr;
        final int suffix_offset;
        final Type type;
        final boolean using_camera2;
        final float zoom_factor;

        enum ImageFormat {
            STD,
            WEBP,
            PNG
        }

        enum ProcessType {
            NORMAL,
            HDR,
            AVERAGE,
            PANORAMA
        }

        enum SaveBase {
            SAVEBASE_NONE,
            SAVEBASE_FIRST,
            SAVEBASE_ALL,
            SAVEBASE_ALL_PLUS_DEBUG
        }

        enum Type {
            JPEG,
            RAW,
            DUMMY
        }

        Request(Type type,
                ProcessType process_type,
                boolean force_suffix,
                int suffix_offset,
                SaveBase save_base,
                List<byte[]> jpeg_images,
                RawImage raw_image,
                boolean image_capture_intent, Uri image_capture_intent_uri,
                boolean using_camera2,
                ImageFormat image_format, int image_quality,
                boolean do_auto_stabilise, double level_angle, List<float[]> gyro_rotation_matrix,
                boolean is_front_facing,
                boolean mirror,
                Date current_date,
                String preference_hdr_contrast_enhancement,
                int iso,
                long exposure_time,
                float zoom_factor,
                String preference_stamp, String preference_textstamp, int font_size, int color, String pref_style, String preference_stamp_dateformat, String preference_stamp_timeformat, String preference_stamp_gpsformat, String preference_stamp_geo_address, String preference_units_distance,
                boolean panorama_crop,
                boolean store_location, Location location, boolean store_geo_direction, double geo_direction,
                double pitch_angle, boolean store_ypr,
                String custom_tag_artist,
                String custom_tag_copyright,
                int sample_factor) {
            this.type = type;
            this.process_type = process_type;
            this.force_suffix = force_suffix;
            this.suffix_offset = suffix_offset;
            this.save_base = save_base;
            this.jpeg_images = jpeg_images;
            this.raw_image = raw_image;
            this.image_capture_intent = image_capture_intent;
            this.image_capture_intent_uri = image_capture_intent_uri;
            this.using_camera2 = using_camera2;
            this.image_format = image_format;
            this.image_quality = image_quality;
            this.do_auto_stabilise = do_auto_stabilise;
            this.level_angle = level_angle;
            this.gyro_rotation_matrix = gyro_rotation_matrix;
            this.is_front_facing = is_front_facing;
            this.mirror = mirror;
            this.current_date = current_date;
            this.preference_hdr_contrast_enhancement = preference_hdr_contrast_enhancement;
            this.iso = iso;
            this.exposure_time = exposure_time;
            this.zoom_factor = zoom_factor;
            this.preference_stamp = preference_stamp;
            this.preference_textstamp = preference_textstamp;
            this.font_size = font_size;
            this.color = color;
            this.pref_style = pref_style;
            this.preference_stamp_dateformat = preference_stamp_dateformat;
            this.preference_stamp_timeformat = preference_stamp_timeformat;
            this.preference_stamp_gpsformat = preference_stamp_gpsformat;
            this.preference_stamp_geo_address = preference_stamp_geo_address;
            this.preference_units_distance = preference_units_distance;
            this.panorama_crop = panorama_crop;
            this.store_location = store_location;
            this.location = location;
            this.store_geo_direction = store_geo_direction;
            this.geo_direction = geo_direction;
            this.pitch_angle = pitch_angle;
            this.store_ypr = store_ypr;
            this.custom_tag_artist = custom_tag_artist;
            this.custom_tag_copyright = custom_tag_copyright;
            this.sample_factor = sample_factor;
        }

        /* access modifiers changed from: package-private */
        public Request copy() {
            return new Request(this.type, this.process_type, this.force_suffix, this.suffix_offset, this.save_base, this.jpeg_images, this.raw_image, this.image_capture_intent, this.image_capture_intent_uri, this.using_camera2, this.image_format, this.image_quality, this.do_auto_stabilise, this.level_angle, this.gyro_rotation_matrix, this.is_front_facing, this.mirror, this.current_date, this.preference_hdr_contrast_enhancement, this.iso, this.exposure_time, this.zoom_factor, this.preference_stamp, this.preference_textstamp, this.font_size, this.color, this.pref_style, this.preference_stamp_dateformat, this.preference_stamp_timeformat, this.preference_stamp_gpsformat, this.preference_stamp_geo_address, this.preference_units_distance, this.panorama_crop, this.store_location, this.location, this.store_geo_direction, this.geo_direction, this.pitch_angle, this.store_ypr, this.custom_tag_artist, this.custom_tag_copyright, this.sample_factor);
        }
    }

    ImageSaver(CameraActivity cameraActivity) {
        Paint paint = new Paint();
        this.p = paint;
        Log.d(TAG, TAG);
        this.main_activity = cameraActivity;
        int computeQueueSize = computeQueueSize(((ActivityManager) cameraActivity.getSystemService(Context.ACTIVITY_SERVICE)).getLargeMemoryClass());
        this.queue_capacity = computeQueueSize;
        this.queue = new ArrayBlockingQueue(computeQueueSize);
        HDRProcessor hDRProcessor = new HDRProcessor(cameraActivity, cameraActivity.is_test);
        this.hdrProcessor = hDRProcessor;
        this.panoramaProcessor = new PanoramaProcessor(cameraActivity, hDRProcessor);
        paint.setAntiAlias(true);
    }

    public int getQueueSize() {
        return this.queue_capacity;
    }

    public static int computeQueueSize(int i) {
        Log.d(TAG, "large max memory = " + i + "MB");
        StringBuilder sb = new StringBuilder();
        sb.append("test_small_queue_size?: ");
        sb.append(test_small_queue_size);
        Log.d(TAG, sb.toString());
        if (test_small_queue_size) {
            i = 0;
        }
        int i2 = i >= 512 ? 34 : i >= 256 ? 12 : i >= 128 ? 8 : 6;
        Log.d(TAG, "max_queue_size = " + i2);
        return i2;
    }

    public static int computeRequestCost(boolean z, int i) {
        Log.d(TAG, "computeRequestCost");
        Log.d(TAG, "is_raw: " + z);
        Log.d(TAG, "n_images: " + i);
        return z ? i * 6 : i * 1;
    }

    /* access modifiers changed from: package-private */
    public int computePhotoCost(int i, int i2) {
        Log.d(TAG, "computePhotoCost");
        Log.d(TAG, "n_raw: " + i);
        Log.d(TAG, "n_jpegs: " + i2);
        int computeRequestCost = i > 0 ? computeRequestCost(true, i) + 0 : 0;
        if (i2 > 0) {
            computeRequestCost += computeRequestCost(false, i2);
        }
        Log.d(TAG, "cost: " + computeRequestCost);
        return computeRequestCost;
    }

    /* access modifiers changed from: package-private */
    public boolean queueWouldBlock(int i, int i2) {
        return queueWouldBlock(computePhotoCost(i, i2));
    }

    /* access modifiers changed from: package-private */
    public synchronized boolean queueWouldBlock(int i) {
        Log.d(TAG, "queueWouldBlock");
        Log.d(TAG, "photo_cost: " + i);
        Log.d(TAG, "n_images_to_save: " + this.n_images_to_save);
        Log.d(TAG, "queue_capacity: " + this.queue_capacity);
        int i2 = this.n_images_to_save;
        if (i2 == 0) {
            Log.d(TAG, "queue is empty");
            return false;
        } else if (i2 + i > this.queue_capacity + 1) {
            Log.d(TAG, "queue would block");
            return true;
        } else {
            Log.d(TAG, "queue would not block");
            return false;
        }
    }

    /* access modifiers changed from: package-private */
    public int getMaxDNG() {
        int i = ((this.queue_capacity + 1) / 6) + 1;
        Log.d(TAG, "max_dng = " + i);
        return i;
    }

    public synchronized int getNImagesToSave() {
        return this.n_images_to_save;
    }

    public synchronized int getNRealImagesToSave() {
        return this.n_real_images_to_save;
    }

    /* access modifiers changed from: package-private */
    public void onPause() {
        synchronized (this) {
            this.app_is_paused = true;
        }
    }

    /* access modifiers changed from: package-private */
    public void onResume() {
        synchronized (this) {
            this.app_is_paused = false;
        }
    }

    /* access modifiers changed from: package-private */
    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        PanoramaProcessor panoramaProcessor2 = this.panoramaProcessor;
        if (panoramaProcessor2 != null) {
            panoramaProcessor2.onDestroy();
        }
        HDRProcessor hDRProcessor = this.hdrProcessor;
        if (hDRProcessor != null) {
            hDRProcessor.onDestroy();
        }
    }

    @Override
    public void run() {
        if (MyDebug.LOG)
            Log.d(TAG, "starting ImageSaver thread...");
        while (true) {
            try {
                if (MyDebug.LOG)
                    Log.d(TAG, "ImageSaver thread reading from queue, size: " + queue.size());
                Request request = queue.take(); // if empty, take() blocks until non-empty
                // Only decrement n_images_to_save after we've actually saved the image! Otherwise waitUntilDone() will return
                // even though we still have a last image to be saved.
                if (MyDebug.LOG)
                    Log.d(TAG, "ImageSaver thread found new request from queue, size is now: " + queue.size());
                boolean success;
                switch (request.type) {
                    case RAW:
                        if (MyDebug.LOG)
                            Log.d(TAG, "request is raw");
                        success = saveImageNowRaw(request);
                        break;
                    case JPEG:
                        if (MyDebug.LOG)
                            Log.d(TAG, "request is jpeg");
                        success = saveImageNow(request);
                        break;
                    case DUMMY:
                        if (MyDebug.LOG)
                            Log.d(TAG, "request is dummy");
                        success = true;
                        break;
                    default:
                        if (MyDebug.LOG)
                            Log.e(TAG, "request is unknown type!");
                        success = false;
                        break;
                }
                if (test_slow_saving) {
                    // ignore warning about "Call to Thread.sleep in a loop", this is only activated in test code
                    //noinspection BusyWait
                    Thread.sleep(2000);
                }
                if (MyDebug.LOG) {
                    if (success)
                        Log.d(TAG, "ImageSaver thread successfully saved image");
                    else
                        Log.e(TAG, "ImageSaver thread failed to save image");
                }
                synchronized (this) {
                    n_images_to_save--;
                    if (request.type != Request.Type.DUMMY)
                        n_real_images_to_save--;
                    if (MyDebug.LOG)
                        Log.d(TAG, "ImageSaver thread processed new request from queue, images to save is now: " + n_images_to_save);
                    if (MyDebug.LOG && n_images_to_save < 0) {
                        Log.e(TAG, "images to save has become negative");
                        throw new RuntimeException();
                    } else if (MyDebug.LOG && n_real_images_to_save < 0) {
                        Log.e(TAG, "real images to save has become negative");
                        throw new RuntimeException();
                    }
                    notifyAll();

                    main_activity.runOnUiThread(new Runnable() {
                        public void run() {
                            main_activity.imageQueueChanged();
                        }
                    });
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
                if (MyDebug.LOG)
                    Log.e(TAG, "interrupted while trying to read from ImageSaver queue");
            }
        }
    }

    /* access modifiers changed from: package-private */
    public boolean saveImageJpeg(boolean z, boolean z2, boolean z3, int i, boolean z4, List<byte[]> list, boolean z5, Uri uri, boolean z6, Request.ImageFormat imageFormat, int i2, boolean z7, double d, boolean z8, boolean z9, Date date, String str, int i3, long j, float f, String str2, String str3, int i4, int i5, String str4, String str5, String str6, String str7, String str8, String str9, boolean z10, boolean z11, Location location, boolean z12, double d2, double d3, boolean z13, String str10, String str11, int i6) {
        Log.d(TAG, "saveImageJpeg");
        StringBuilder sb = new StringBuilder();
        sb.append("do_in_background? ");
        sb.append(z);
        Log.d(TAG, sb.toString());
        Log.d(TAG, "number of images: " + list.size());
        return saveImage(z, false, z2, z3, i, z4, list, (RawImage) null, z5, uri, z6, imageFormat, i2, z7, d, z8, z9, date, str, i3, j, f, str2, str3, i4, i5, str4, str5, str6, str7, str8, str9, z10, z11, location, z12, d2, d3, z13, str10, str11, i6);
    }

    /* access modifiers changed from: package-private */
    public boolean saveImageRaw(boolean z, boolean z2, int i, RawImage rawImage, Date date) {
        Log.d(TAG, "saveImageRaw");
        Log.d(TAG, "do_in_background? " + z);
        return saveImage(z, true, false, z2, i, false, (List<byte[]>) null, rawImage, false, (Uri) null, false, Request.ImageFormat.STD, 0, false, 0d, false, false, date, (String) null, 0, 0, 1.0f, (String) null, (String) null, 0, 0, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null, false, false, (Location) null, false, 0d, 0d, false, (String) null, (String) null, 1);
    }

    /* access modifiers changed from: package-private */
    public void startImageBatch(boolean z, Request.ProcessType processType, Request.SaveBase saveBase, boolean z2, Uri uri, boolean z3, Request.ImageFormat imageFormat, int i, boolean z4, double d, boolean z5, boolean z6, boolean z7, Date date, int i2, long j, float f, String str, String str2, int i3, int i4, String str3, String str4, String str5, String str6, String str7, String str8, boolean z8, boolean z9, Location location, boolean z10, double d2, double d3, boolean z11, String str9, String str10, int i5) {
        Log.d(TAG, "startImageBatch");
        Log.d(TAG, "do_in_background? " + z);
        this.pending_image_average_request = new Request(Request.Type.JPEG, processType, false, 0, saveBase, new ArrayList(), (RawImage) null, z2, uri, z3, imageFormat, i, z4, d, z5 ? new ArrayList() : null, z6, z7, date, (String) null, i2, j, f, str, str2, i3, i4, str3, str4, str5, str6, str7, str8, z8, z9, location, z10, d2, d3, z11, str9, str10, i5);
    }

    /* access modifiers changed from: package-private */
    public void addImageBatch(byte[] bArr, float[] fArr) {
        Log.d(TAG, "addImageBatch");
        Request request = this.pending_image_average_request;
        if (request == null) {
            Log.e(TAG, "addImageBatch called but no pending_image_average_request");
            return;
        }
        request.jpeg_images.add(bArr);
        if (fArr != null) {
            float[] fArr2 = new float[fArr.length];
            System.arraycopy(fArr, 0, fArr2, 0, fArr.length);
            this.pending_image_average_request.gyro_rotation_matrix.add(fArr2);
        }
        Log.d(TAG, "image average request images: " + this.pending_image_average_request.jpeg_images.size());
    }

    /* access modifiers changed from: package-private */
    public Request getImageBatchRequest() {
        return this.pending_image_average_request;
    }

    /* access modifiers changed from: package-private */
    public void finishImageBatch(boolean z) {
        Log.d(TAG, "finishImageBatch");
        if (this.pending_image_average_request == null) {
            Log.d(TAG, "finishImageBatch called but no pending_image_average_request");
            return;
        }
        if (z) {
            Log.d(TAG, "add background request");
            addRequest(this.pending_image_average_request, computeRequestCost(false, this.pending_image_average_request.jpeg_images.size()));
        } else {
            waitUntilDone();
            saveImageNow(this.pending_image_average_request);
        }
        this.pending_image_average_request = null;
    }

    /* access modifiers changed from: package-private */
    public void flushImageBatch() {
        Log.d(TAG, "flushImageBatch");
        this.pending_image_average_request = null;
    }

    private boolean saveImage(boolean do_in_background,
                              boolean is_raw,
                              boolean is_hdr,
                              boolean force_suffix,
                              int suffix_offset,
                              boolean save_expo,
                              List<byte[]> jpeg_images,
                              RawImage raw_image,
                              boolean image_capture_intent, Uri image_capture_intent_uri,
                              boolean using_camera2,
                              Request.ImageFormat image_format, int image_quality,
                              boolean do_auto_stabilise, double level_angle,
                              boolean is_front_facing,
                              boolean mirror,
                              Date current_date,
                              String preference_hdr_contrast_enhancement,
                              int iso,
                              long exposure_time,
                              float zoom_factor,
                              String preference_stamp, String preference_textstamp, int font_size, int color, String pref_style, String preference_stamp_dateformat, String preference_stamp_timeformat, String preference_stamp_gpsformat, String preference_stamp_geo_address, String preference_units_distance,
                              boolean panorama_crop,
                              boolean store_location, Location location, boolean store_geo_direction, double geo_direction,
                              double pitch_angle, boolean store_ypr,
                              String custom_tag_artist,
                              String custom_tag_copyright,
                              int sample_factor) {
        if (MyDebug.LOG) {
            Log.d(TAG, "saveImage");
            Log.d(TAG, "do_in_background? " + do_in_background);
        }
        boolean success;

        //do_in_background = false;

        Request request = new Request(is_raw ? Request.Type.RAW : Request.Type.JPEG,
                is_hdr ? Request.ProcessType.HDR : Request.ProcessType.NORMAL,
                force_suffix,
                suffix_offset,
                save_expo ? Request.SaveBase.SAVEBASE_ALL : Request.SaveBase.SAVEBASE_NONE,
                jpeg_images,
                raw_image,
                image_capture_intent, image_capture_intent_uri,
                using_camera2,
                image_format, image_quality,
                do_auto_stabilise, level_angle, null,
                is_front_facing,
                mirror,
                current_date,
                preference_hdr_contrast_enhancement,
                iso,
                exposure_time,
                zoom_factor,
                preference_stamp, preference_textstamp, font_size, color, pref_style, preference_stamp_dateformat, preference_stamp_timeformat, preference_stamp_gpsformat, preference_stamp_geo_address, preference_units_distance,
                panorama_crop, store_location, location, store_geo_direction, geo_direction,
                pitch_angle, store_ypr,
                custom_tag_artist,
                custom_tag_copyright,
                sample_factor);

        if (do_in_background) {
            if (MyDebug.LOG)
                Log.d(TAG, "add background request");
            int cost = computeRequestCost(is_raw, is_raw ? 1 : request.jpeg_images.size());
            addRequest(request, cost);
            success = true; // always return true when done in background
        } else {
            // wait for queue to be empty
            waitUntilDone();
            if (is_raw) {
                success = saveImageNowRaw(request);
            } else {
                success = saveImageNow(request);
            }
        }

        if (MyDebug.LOG)
            Log.d(TAG, "success: " + success);
        return success;
    }

    /**
     * Adds a request to the background queue, blocking if the queue is already full
     */
    private void addRequest(Request request, int cost) {
        if (MyDebug.LOG)
            Log.d(TAG, "addRequest, cost: " + cost);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && main_activity.isDestroyed()) {
            // If the application is being destroyed as a new photo is being taken, it's not safe to continue, e.g., we'll
            // crash if needing to use RenderScript.
            // MainDestroy.onDestroy() does call waitUntilDone(), but this is extra protection in case an image comes in after that.
            Log.e(TAG, "application is destroyed, image lost!");
            return;
        }
        // this should not be synchronized on "this": BlockingQueue is thread safe, and if it's blocking in queue.put(), we'll hang because
        // the saver queue will need to synchronize on "this" in order to notifyAll() the main thread
        boolean done = false;
        while (!done) {
            try {
                if (MyDebug.LOG)
                    Log.d(TAG, "ImageSaver thread adding to queue, size: " + queue.size());
                synchronized (this) {
                    // see above for why we don't synchronize the queue.put call
                    // but we synchronize modification to avoid risk of problems related to compiler optimisation (local caching or reordering)
                    // also see FindBugs warning due to inconsistent synchronisation
                    n_images_to_save++; // increment before adding to the queue, just to make sure the main thread doesn't think we're all done
                    if (request.type != Request.Type.DUMMY)
                        n_real_images_to_save++;

                    main_activity.runOnUiThread(new Runnable() {
                        public void run() {
                            main_activity.imageQueueChanged();
                        }
                    });
                }
                if (queue.size() + 1 > queue_capacity) {
                    Log.e(TAG, "ImageSaver thread is going to block, queue already full: " + queue.size());
                    test_queue_blocked = true;
                    //throw new RuntimeException(); // test
                }
                queue.put(request); // if queue is full, put() blocks until it isn't full
                if (MyDebug.LOG) {
                    synchronized (this) { // keep FindBugs happy
                        Log.d(TAG, "ImageSaver thread added to queue, size is now: " + queue.size());
                        Log.d(TAG, "images still to save is now: " + n_images_to_save);
                        Log.d(TAG, "real images still to save is now: " + n_real_images_to_save);
                    }
                }
                done = true;
            } catch (InterruptedException e) {
                e.printStackTrace();
                if (MyDebug.LOG)
                    Log.e(TAG, "interrupted while trying to add to ImageSaver queue");
            }
        }
        if (cost > 0) {
            // add "dummy" requests to simulate the cost
            for (int i = 0; i < cost - 1; i++) {
                addDummyRequest();
            }
        }
    }

    private void addDummyRequest() {
        Request dummy_request = new Request(Request.Type.DUMMY,
                Request.ProcessType.NORMAL,
                false,
                0,
                Request.SaveBase.SAVEBASE_NONE,
                null,
                null,
                false, null,
                false,
                Request.ImageFormat.STD, 0,
                false, 0.0, null,
                false,
                false,
                null,
                null,
                0,
                0,
                1.0f,
                null, null, 0, 0, null, null, null, null, null, null,
                false, false, null, false, 0.0,
                0.0, false,
                null, null,
                1);
        if (MyDebug.LOG)
            Log.d(TAG, "add dummy request");
        addRequest(dummy_request, 1); // cost must be 1, so we don't have infinite recursion!
    }

    /* access modifiers changed from: package-private */
    public void waitUntilDone() {
        Log.d(TAG, "waitUntilDone");
        synchronized (this) {
            Log.d(TAG, "waitUntilDone: queue is size " + this.queue.size());
            Log.d(TAG, "waitUntilDone: images still to save " + this.n_images_to_save);
            while (this.n_images_to_save > 0) {
                Log.d(TAG, "wait until done...");
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    Log.e(TAG, "interrupted while waiting for ImageSaver queue to be empty");
                }
                Log.d(TAG, "waitUntilDone: queue is size " + this.queue.size());
                Log.d(TAG, "waitUntilDone: images still to save " + this.n_images_to_save);
            }
        }
        Log.d(TAG, "waitUntilDone: images all saved");
    }

    private void setBitmapOptionsSampleSize(BitmapFactory.Options options, int i) {
        Log.d(TAG, "setBitmapOptionsSampleSize: " + i);
        if (i > 1) {
            options.inDensity = i;
            options.inTargetDensity = 1;
        }
    }

    private Bitmap loadBitmap(byte[] bArr, boolean z, int i) {
        Log.d(TAG, "loadBitmap");
        Log.d(TAG, "mutable?: " + z);
        BitmapFactory.Options options = new BitmapFactory.Options();
        Log.d(TAG, "options.inMutable is: " + options.inMutable);
        options.inMutable = z;
        setBitmapOptionsSampleSize(options, i);
        if (Build.VERSION.SDK_INT <= 19) {
            options.inPurgeable = true;
        }
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(bArr, 0, bArr.length, options);
        if (decodeByteArray == null) {
            Log.e(TAG, "failed to decode bitmap");
        }
        return decodeByteArray;
    }

    private static class LoadBitmapThread extends Thread {
        Bitmap bitmap;
        final byte[] jpeg;
        final BitmapFactory.Options options;

        LoadBitmapThread(BitmapFactory.Options options2, byte[] bArr) {
            this.options = options2;
            this.jpeg = bArr;
        }

        public void run() {
            byte[] bArr = this.jpeg;
            this.bitmap = BitmapFactory.decodeByteArray(bArr, 0, bArr.length, this.options);
        }
    }

    private List<Bitmap> loadBitmaps(List<byte[]> list, int i, int i2) {
        Log.d(TAG, "loadBitmaps");
        Log.d(TAG, "mutable_id: " + i);
        BitmapFactory.Options options = new BitmapFactory.Options();
        boolean z = true;
        options.inMutable = true;
        setBitmapOptionsSampleSize(options, i2);
        BitmapFactory.Options options2 = new BitmapFactory.Options();
        options2.inMutable = false;
        setBitmapOptionsSampleSize(options2, i2);
        if (Build.VERSION.SDK_INT <= 19) {
            options.inPurgeable = true;
            options2.inPurgeable = true;
        }
        LoadBitmapThread[] loadBitmapThreadArr = new LoadBitmapThread[list.size()];
        int i3 = 0;
        while (i3 < list.size()) {
            loadBitmapThreadArr[i3] = new LoadBitmapThread(i3 == i ? options : options2, list.get(i3));
            i3++;
        }
        Log.d(TAG, "start threads");
        for (int i4 = 0; i4 < list.size(); i4++) {
            loadBitmapThreadArr[i4].start();
        }
        Log.d(TAG, "wait for threads to complete");
        int i5 = 0;
        while (i5 < list.size()) {
            try {
                loadBitmapThreadArr[i5].join();
                i5++;
            } catch (InterruptedException e) {
                Log.e(TAG, "threads interrupted");
                e.printStackTrace();
                z = false;
            }
        }
        Log.d(TAG, "threads completed");
        ArrayList arrayList = new ArrayList();
        for (int i6 = 0; i6 < list.size() && z; i6++) {
            Bitmap bitmap = loadBitmapThreadArr[i6].bitmap;
            if (bitmap == null) {
                Log.e(TAG, "failed to decode bitmap in thread: " + i6);
                z = false;
            } else {
                Log.d(TAG, "bitmap " + i6 + ": " + bitmap + " is mutable? " + bitmap.isMutable());
            }
            arrayList.add(bitmap);
        }
        if (z) {
            return arrayList;
        }
        Log.d(TAG, "cleanup from failure");
        for (int i7 = 0; i7 < list.size(); i7++) {
            if (loadBitmapThreadArr[i7].bitmap != null) {
                loadBitmapThreadArr[i7].bitmap.recycle();
                loadBitmapThreadArr[i7].bitmap = null;
            }
        }
        arrayList.clear();
        System.gc();
        return null;
    }

    /**
     * Chooses the hdr_alpha to use for contrast enhancement in the HDR algorithm, based on the user
     * preferences and scene details.
     */
    public static float getHDRAlpha(String preference_hdr_contrast_enhancement, long exposure_time, int n_bitmaps) {
        boolean use_hdr_alpha;
        if (n_bitmaps == 1) {
            // DRO always applies hdr_alpha
            use_hdr_alpha = true;
        } else {
            // else HDR
            switch (preference_hdr_contrast_enhancement) {
                case "preference_hdr_contrast_enhancement_off":
                    use_hdr_alpha = false;
                    break;
                case "preference_hdr_contrast_enhancement_smart":
                default:
                    // Using local contrast enhancement helps scenes where the dynamic range is very large, which tends to be when we choose
                    // a short exposure time, due to fixing problems where some regions are too dark.
                    // This helps: testHDR11, testHDR19, testHDR34, testHDR53, testHDR61.
                    // Using local contrast enhancement in all cases can increase noise in darker scenes. This problem would occur
                    // (if we used local contrast enhancement) is: testHDR2, testHDR12, testHDR17, testHDR43, testHDR50, testHDR51,
                    // testHDR54, testHDR55, testHDR56.
                    use_hdr_alpha = (exposure_time < 1000000000L / 59);
                    break;
                case "preference_hdr_contrast_enhancement_always":
                    use_hdr_alpha = true;
                    break;
            }
        }
        //use_hdr_alpha = true; // test
        float hdr_alpha = use_hdr_alpha ? 0.5f : 0.0f;
        if (MyDebug.LOG) {
            Log.d(TAG, "preference_hdr_contrast_enhancement: " + preference_hdr_contrast_enhancement);
            Log.d(TAG, "exposure_time: " + exposure_time);
            Log.d(TAG, "hdr_alpha: " + hdr_alpha);
        }
        return hdr_alpha;
    }

    private void writeGyroDebugXml(Writer writer, Request request) throws IOException {
        Request request2 = request;
        XmlSerializer newSerializer = Xml.newSerializer();
        newSerializer.setOutput(writer);
        char c = 1;
        newSerializer.startDocument(Key.STRING_CHARSET_NAME, true);
        String str = null;
        newSerializer.startTag((String) null, gyro_info_doc_tag);
        newSerializer.attribute((String) null, gyro_info_panorama_pics_per_screen_tag, "" + MyApplicationInterface.getPanoramaPicsPerScreen());
        newSerializer.attribute((String) null, gyro_info_camera_view_angle_x_tag, "" + request2.camera_view_angle_x);
        newSerializer.attribute((String) null, gyro_info_camera_view_angle_y_tag, "" + request2.camera_view_angle_y);
        float[] fArr = new float[3];
        float[] fArr2 = new float[3];
        char c2 = 0;
        int i = 0;
        while (i < request2.gyro_rotation_matrix.size()) {
            newSerializer.startTag(str, gyro_info_image_tag);
            newSerializer.attribute(str, "FirebaseAnalytics.Param.INDEX", "" + i);
            GyroSensor.setVector(fArr, 1.0f, 0.0f, 0.0f);
            GyroSensor.transformVector(fArr2, request2.gyro_rotation_matrix.get(i), fArr);
            newSerializer.startTag(str, gyro_info_vector_tag);
            newSerializer.attribute(str, "type", gyro_info_vector_right_type);
            newSerializer.attribute(str, "x", "" + fArr2[c2]);
            newSerializer.attribute(str, "y", "" + fArr2[c]);
            newSerializer.attribute(str, "z", "" + fArr2[2]);
            newSerializer.endTag(str, gyro_info_vector_tag);
            GyroSensor.setVector(fArr, 0.0f, 1.0f, 0.0f);
            GyroSensor.transformVector(fArr2, request2.gyro_rotation_matrix.get(i), fArr);
            newSerializer.startTag(str, gyro_info_vector_tag);
            newSerializer.attribute(str, "type", gyro_info_vector_up_type);
            newSerializer.attribute(str, "x", "" + fArr2[0]);
            str = null;
            newSerializer.attribute((String) null, "y", "" + fArr2[1]);
            newSerializer.attribute((String) null, "z", "" + fArr2[2]);
            newSerializer.endTag((String) null, gyro_info_vector_tag);
            GyroSensor.setVector(fArr, 0.0f, 0.0f, -1.0f);
            GyroSensor.transformVector(fArr2, request2.gyro_rotation_matrix.get(i), fArr);
            newSerializer.startTag((String) null, gyro_info_vector_tag);
            newSerializer.attribute((String) null, "type", gyro_info_vector_screen_type);
            newSerializer.attribute((String) null, "x", "" + fArr2[0]);
            newSerializer.attribute((String) null, "y", "" + fArr2[1]);
            newSerializer.attribute((String) null, "z", "" + fArr2[2]);
            newSerializer.endTag((String) null, gyro_info_vector_tag);
            newSerializer.endTag((String) null, gyro_info_image_tag);
            i++;
            c = 1;
            c2 = 0;
        }
        newSerializer.endTag(str, gyro_info_doc_tag);
        newSerializer.endDocument();
        newSerializer.flush();
    }

    public static boolean readGyroDebugXml(InputStream inputStream, GyroDebugInfo info) {
        try {
            XmlPullParser parser = Xml.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(inputStream, null);
            parser.nextTag();

            parser.require(XmlPullParser.START_TAG, null, gyro_info_doc_tag);
            GyroDebugInfo.GyroImageDebugInfo image_info = null;

            while (parser.next() != XmlPullParser.END_DOCUMENT) {
                switch (parser.getEventType()) {
                    case XmlPullParser.START_TAG: {
                        String name = parser.getName();
                        if (MyDebug.LOG) {
                            Log.d(TAG, "start tag, name: " + name);
                        }

                        switch (name) {
                            case gyro_info_image_tag:
                                info.image_info.add(image_info = new GyroDebugInfo.GyroImageDebugInfo());
                                break;
                            case gyro_info_vector_tag:
                                if (image_info == null) {
                                    Log.e(TAG, "vector tag outside of image tag");
                                    return false;
                                }
                                String type = parser.getAttributeValue(null, "type");
                                String x_s = parser.getAttributeValue(null, "x");
                                String y_s = parser.getAttributeValue(null, "y");
                                String z_s = parser.getAttributeValue(null, "z");
                                float[] vector = new float[3];
                                vector[0] = Float.parseFloat(x_s);
                                vector[1] = Float.parseFloat(y_s);
                                vector[2] = Float.parseFloat(z_s);
                                switch (type) {
                                    case gyro_info_vector_right_type:
                                        image_info.vectorRight = vector;
                                        break;
                                    case gyro_info_vector_up_type:
                                        image_info.vectorUp = vector;
                                        break;
                                    case gyro_info_vector_screen_type:
                                        image_info.vectorScreen = vector;
                                        break;
                                    default:
                                        Log.e(TAG, "unknown type in vector tag: " + type);
                                        return false;
                                }
                                break;
                        }
                        break;
                    }
                    case XmlPullParser.END_TAG: {
                        String name = parser.getName();
                        if (MyDebug.LOG) {
                            Log.d(TAG, "end tag, name: " + name);
                        }

                        //noinspection SwitchStatementWithTooFewBranches
                        switch (name) {
                            case gyro_info_image_tag:
                                image_info = null;
                                break;
                        }
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return true;
    }

    private boolean saveImageNow(Request request) {
        OutputStream outputStream;
        Bitmap bitmap;
        String str;
        int i;
        Request request2 = request;
        String str2 = "n_load: ";
        Log.d(TAG, "saveImageNow");
        if (request2.type != Request.Type.JPEG) {
            Log.d(TAG, "saveImageNow called with non-jpeg request");
            throw new RuntimeException();
        } else if (request2.jpeg_images.size() != 0) {
            String str3 = " is mutable? ";
            if (request2.process_type == Request.ProcessType.AVERAGE) {
                Log.d(TAG, "average");
                saveBaseImages(request2, "_");
                this.main_activity.savingImage(true);
                if (Build.VERSION.SDK_INT >= 21) {
                    try {
                        long currentTimeMillis = System.currentTimeMillis();
                        int avgSampleSize = this.hdrProcessor.getAvgSampleSize(request2.iso);
                        long currentTimeMillis2 = System.currentTimeMillis();
                        int size = request2.jpeg_images.size();
                        int min = Math.min(4, size);
                        Log.d(TAG, "n_remaining: " + size);
                        Log.d(TAG, str2 + min);
                        ArrayList arrayList = new ArrayList();
                        for (int i2 = 0; i2 < min; i2++) {
                            arrayList.add(request2.jpeg_images.get(i2));
                        }
                        List<Bitmap> loadBitmaps = loadBitmaps(arrayList, -1, avgSampleSize);
                        Log.d(TAG, "length of bitmaps list is now: " + loadBitmaps.size());
                        Bitmap bitmap2 = loadBitmaps.get(0);
                        Log.d(TAG, "*** time for loading first bitmaps: " + (System.currentTimeMillis() - currentTimeMillis2));
                        int width = bitmap2.getWidth();
                        int height = bitmap2.getHeight();
                        long currentTimeMillis3 = System.currentTimeMillis();
                        HDRProcessor.AvgData processAvg = this.hdrProcessor.processAvg(bitmap2, loadBitmaps.get(1), 1.0f, request2.iso, request2.zoom_factor);
                        if (loadBitmaps != null) {
                            loadBitmaps.set(0, null);
                            loadBitmaps.set(1, null);
                        }
                        StringBuilder sb = new StringBuilder();
                        sb.append("*** time for processing first two bitmaps: ");
                        long j = currentTimeMillis;
                        sb.append(System.currentTimeMillis() - currentTimeMillis3);
                        Log.d(TAG, sb.toString());
                        Allocation allocation = processAvg.allocation_out;
                        int i3 = 2;
                        while (i3 < request2.jpeg_images.size()) {
                            Log.d(TAG, "processAvg for image: " + i3);
                            long currentTimeMillis4 = System.currentTimeMillis();
                            String str4 = str3;
                            StringBuilder sb2 = new StringBuilder();
                            Allocation allocation2 = allocation;
                            sb2.append("length of bitmaps list: ");
                            sb2.append(loadBitmaps.size());
                            Log.d(TAG, sb2.toString());
                            if (i3 < loadBitmaps.size()) {
                                Log.d(TAG, "already loaded bitmap from previous iteration with SMP");
                                str = str2;
                                bitmap = loadBitmaps.get(i3);
                                i = height;
                            } else {
                                int size2 = request2.jpeg_images.size() - i3;
                                i = height;
                                int min2 = Math.min(4, size2);
                                Log.d(TAG, "n_remaining: " + size2);
                                Log.d(TAG, str2 + min2);
                                ArrayList arrayList2 = new ArrayList();
                                str = str2;
                                for (int i4 = i3; i4 < i3 + min2; i4++) {
                                    arrayList2.add(request2.jpeg_images.get(i4));
                                }
                                loadBitmaps.addAll(loadBitmaps(arrayList2, -1, avgSampleSize));
                                Log.d(TAG, "length of bitmaps list is now: " + loadBitmaps.size());
                                bitmap = loadBitmaps.get(i3);
                            }
                            Log.d(TAG, "*** time for loading extra bitmap: " + (System.currentTimeMillis() - currentTimeMillis4));
                            long currentTimeMillis5 = System.currentTimeMillis();
                            this.hdrProcessor.updateAvg(processAvg, width, i, bitmap, (float) i3, request2.iso, request2.zoom_factor);
                            if (loadBitmaps != null) {
                                loadBitmaps.set(i3, null);
                            }
                            Log.d(TAG, "*** time for updating extra bitmap: " + (System.currentTimeMillis() - currentTimeMillis5));
                            i3++;
                            str3 = str4;
                            allocation = allocation2;
                            height = i;
                            str2 = str;
                        }
                        String str5 = str3;
                        long currentTimeMillis6 = System.currentTimeMillis();
                        Bitmap avgBrighten = this.hdrProcessor.avgBrighten(allocation, width, height, request2.iso, request2.exposure_time);
                        Log.d(TAG, "*** time for brighten: " + (System.currentTimeMillis() - currentTimeMillis6));
                        processAvg.destroy();
                        Log.d(TAG, "*** total time for saving NR image: " + (System.currentTimeMillis() - j));
                        Log.d(TAG, "nr_bitmap: " + avgBrighten + str5 + avgBrighten.isMutable());
                        System.gc();
                        this.main_activity.savingImage(false);
                        Log.d(TAG, "save NR image");
                        boolean saveSingleImageNow = saveSingleImageNow(request, request2.jpeg_images.get(0), avgBrighten, "_NR", true, true, true, false);
                        if (!saveSingleImageNow) {
                            Log.e(TAG, "saveSingleImageNow failed for nr image");
                        }
                        avgBrighten.recycle();
                        System.gc();
                        return saveSingleImageNow;
                    } catch (HDRProcessorException e) {
                        e.printStackTrace();
                        throw new RuntimeException();
                    }
                } else {
                    Log.e(TAG, "shouldn't have offered NoiseReduction as an option if not on Android 5");
                    throw new RuntimeException();
                }
            } else {
                String str6 = str3;
                if (request2.process_type == Request.ProcessType.HDR) {
                    Log.d(TAG, "hdr");
                    if (request2.jpeg_images.size() == 1 || request2.jpeg_images.size() == 3) {
                        long currentTimeMillis7 = System.currentTimeMillis();
                        if (request2.jpeg_images.size() > 1) {
                            saveBaseImages(request2, "_");
                            Log.d(TAG, "HDR performance: time after saving base exposures: " + (System.currentTimeMillis() - currentTimeMillis7));
                        }
                        Log.d(TAG, "create HDR image");
                        this.main_activity.savingImage(true);
                        int size3 = (request2.jpeg_images.size() - 1) / 2;
                        Log.d(TAG, "base_bitmap: " + size3);
                        List<Bitmap> loadBitmaps2 = loadBitmaps(request2.jpeg_images, size3, 1);
                        if (loadBitmaps2 == null) {
                            Log.e(TAG, "failed to load bitmaps");
                            this.main_activity.savingImage(false);
                            return false;
                        }
                        Log.d(TAG, "HDR performance: time after decompressing base exposures: " + (System.currentTimeMillis() - currentTimeMillis7));
                        float hDRAlpha = getHDRAlpha(request2.preference_hdr_contrast_enhancement, request2.exposure_time, loadBitmaps2.size());
                        Log.d(TAG, "before HDR first bitmap: " + loadBitmaps2.get(0) + str6 + loadBitmaps2.get(0).isMutable());
                        try {
                            if (Build.VERSION.SDK_INT >= 21) {
                                this.hdrProcessor.processHDR(loadBitmaps2, true, (Bitmap) null, true, (HDRProcessor.SortCallback) null, hDRAlpha, 4, true, HDRProcessor.TonemappingAlgorithm.TONEMAPALGORITHM_REINHARD, HDRProcessor.DROTonemappingAlgorithm.DROALGORITHM_GAINGAMMA);
                                Log.d(TAG, "HDR performance: time after creating HDR image: " + (System.currentTimeMillis() - currentTimeMillis7));
                                Log.d(TAG, "after HDR first bitmap: " + loadBitmaps2.get(0) + str6 + loadBitmaps2.get(0).isMutable());
                                Bitmap bitmap3 = loadBitmaps2.get(0);
                                Log.d(TAG, "hdr_bitmap: " + bitmap3 + str6 + bitmap3.isMutable());
                                loadBitmaps2.clear();
                                System.gc();
                                this.main_activity.savingImage(false);
                                Log.d(TAG, "save HDR image");
                                int size4 = (request2.jpeg_images.size() - 1) / 2;
                                Log.d(TAG, "base_image_id: " + size4);
                                boolean saveSingleImageNow2 = saveSingleImageNow(request, request2.jpeg_images.get(size4), bitmap3, request2.jpeg_images.size() == 1 ? "_DRO" : "_HDR", true, true, true, false);
                                if (!saveSingleImageNow2) {
                                    Log.e(TAG, "saveSingleImageNow failed for hdr image");
                                }
                                Log.d(TAG, "HDR performance: time after saving HDR image: " + (System.currentTimeMillis() - currentTimeMillis7));
                                bitmap3.recycle();
                                System.gc();
                                return saveSingleImageNow2;
                            }
                            Log.e(TAG, "shouldn't have offered HDR as an option if not on Android 5");
                            throw new RuntimeException();
                        } catch (HDRProcessorException e2) {
                            Log.e(TAG, "HDRProcessorException from processHDR: " + e2.getCode());
                            e2.printStackTrace();
                            if (e2.getCode() == 1) {
                                this.main_activity.getPreview().showToast((ToastBoxer) null, (int) R.string.failed_to_process_hdr);
                                Log.e(TAG, "UNEQUAL_SIZES");
                                loadBitmaps2.clear();
                                System.gc();
                                this.main_activity.savingImage(false);
                                return false;
                            }
                            throw new RuntimeException();
                        }
                    } else {
                        Log.d(TAG, "saveImageNow expected either 1 or 3 images for hdr, not " + request2.jpeg_images.size());
                        throw new RuntimeException();
                    }
                } else if (request2.process_type != Request.ProcessType.PANORAMA) {
                    return saveImages(request, "_", false, true, true);
                } else {
                    Log.d(TAG, "panorama");
                    if (!request2.image_capture_intent && request2.save_base == Request.SaveBase.SAVEBASE_ALL_PLUS_DEBUG) {
                        try {
                            StringWriter stringWriter = new StringWriter();
                            writeGyroDebugXml(stringWriter, request2);
                            StorageUtils storageUtils = this.main_activity.getStorageUtils();
                            File createOutputMediaFile = storageUtils.createOutputMediaFile(this.main_activity.getExternalFilesDir((String) null), 4, "", "xml", request2.current_date);
                            Log.d(TAG, "save to: " + createOutputMediaFile.getAbsolutePath());
                            if (createOutputMediaFile != null) {
                                outputStream = new FileOutputStream(createOutputMediaFile);
                            } else {
                                outputStream = this.main_activity.getContentResolver().openOutputStream((Uri) null);
                            }
                            outputStream.write(stringWriter.toString().getBytes(Charset.forName(Key.STRING_CHARSET_NAME)));
                            outputStream.close();
                            if (createOutputMediaFile != null) {
                                storageUtils.broadcastFile(createOutputMediaFile, false, false, false);
                            } else {
                                broadcastSAFFile((Uri) null, false);
                            }
                        } catch (IOException e3) {
                            Log.e(TAG, "failed to write gyro text file");
                            e3.printStackTrace();
                        }
                    }
                    saveBaseImages(request2, "_");
                    this.main_activity.savingImage(true);
                    long currentTimeMillis8 = System.currentTimeMillis();
                    Log.d(TAG, "panorama_dir_left_to_right: " + request2.panorama_dir_left_to_right);
                    if (!request2.panorama_dir_left_to_right) {
                        Collections.reverse(request2.jpeg_images);
                        Collections.reverse(request2.gyro_rotation_matrix);
                    }
                    List<Bitmap> loadBitmaps3 = loadBitmaps(request2.jpeg_images, -1, 1);
                    if (loadBitmaps3 == null) {
                        Log.e(TAG, "failed to load bitmaps");
                        this.main_activity.savingImage(false);
                        return false;
                    }
                    Log.d(TAG, "panorama performance: time after decompressing base exposures: " + (System.currentTimeMillis() - currentTimeMillis8));
                    for (int i5 = 0; i5 < loadBitmaps3.size(); i5++) {
                        loadBitmaps3.set(i5, rotateForExif(loadBitmaps3.get(i5), request2.jpeg_images.get(0)));
                    }
                    Log.d(TAG, "panorama performance: time after rotating for exif: " + (System.currentTimeMillis() - currentTimeMillis8));
                    try {
                        if (Build.VERSION.SDK_INT >= 21) {
                            Bitmap panorama = this.panoramaProcessor.panorama(loadBitmaps3, MyApplicationInterface.getPanoramaPicsPerScreen(), request2.camera_view_angle_y, request2.panorama_crop);
                            Log.d(TAG, "panorama performance: time after creating panorama image: " + (System.currentTimeMillis() - currentTimeMillis8));
                            Log.d(TAG, "panorama: " + panorama);
                            loadBitmaps3.clear();
                            System.gc();
                            this.main_activity.savingImage(false);
                            Log.d(TAG, "save panorama image");
                            boolean saveSingleImageNow3 = saveSingleImageNow(request, request2.jpeg_images.get(0), panorama, "_PANO", true, true, true, true);
                            if (!saveSingleImageNow3) {
                                Log.e(TAG, "saveSingleImageNow failed for panorama image");
                            }
                            panorama.recycle();
                            System.gc();
                            return saveSingleImageNow3;
                        }
                        Log.e(TAG, "shouldn't have offered panorama as an option if not on Android 5");
                        throw new RuntimeException();
                    } catch (PanoramaProcessorException e4) {
                        Log.e(TAG, "PanoramaProcessorException from panorama: " + e4.getCode());
                        e4.printStackTrace();
                        if (e4.getCode() == 1 || e4.getCode() == 1) {
                            this.main_activity.getPreview().showToast((ToastBoxer) null, (int) R.string.failed_to_process_panorama);
                            Log.e(TAG, "panorama failed: " + e4.getCode());
                            loadBitmaps3.clear();
                            System.gc();
                            this.main_activity.savingImage(false);
                            return false;
                        }
                        throw new RuntimeException();
                    }
                }
            }
        } else {
            Log.d(TAG, "saveImageNow called with zero images");
            throw new RuntimeException();
        }
    }

    private boolean saveImages(Request request, String str, boolean z, boolean z2, boolean z3) {
        String str2;
        Request request2 = request;
        int size = request2.jpeg_images.size() / 2;
        int i = 0;
        boolean z4 = true;
        while (i < request2.jpeg_images.size()) {
            byte[] bArr = request2.jpeg_images.get(i);
            if ((request2.jpeg_images.size() > 1 && !z) || request2.force_suffix) {
                str2 = str + (request2.suffix_offset + i);
            } else {
                str2 = "";
                String str3 = str;
            }
            if (!saveSingleImageNow(request, bArr, (Bitmap) null, str2, z2, z3 && i == size, false, false)) {
                Log.e(TAG, "saveSingleImageNow failed for image: " + i);
                z4 = false;
            }
            if (z) {
                break;
            }
            i++;
        }
        return z4;
    }

    private void saveBaseImages(Request request, String str) {
        Log.d(TAG, "saveBaseImages");
        if (!request.image_capture_intent && request.save_base != Request.SaveBase.SAVEBASE_NONE) {
            Log.d(TAG, "save base images");
            if (request.process_type == Request.ProcessType.PANORAMA) {
                request = request.copy();
                request.image_format = Request.ImageFormat.PNG;
                request.preference_stamp = "preference_stamp_no";
                request.preference_textstamp = "";
                request.do_auto_stabilise = false;
                request.mirror = false;
            } else if (request.process_type == Request.ProcessType.AVERAGE) {
                request = request.copy();
                request.image_quality = 100;
            }
            Request request2 = request;
            saveImages(request2, str, request2.save_base == Request.SaveBase.SAVEBASE_FIRST, false, false);
        }
    }

    public static boolean autoStabiliseCrop(int[] iArr, double d, double d2, double d3, int i, int i2, int i3, int i4) {
        iArr[0] = 0;
        iArr[1] = 0;
        double tan = Math.tan(d);
        double sin = Math.sin(d);
        double d4 = (d3 / d2) + tan;
        double d5 = (d2 / d3) + tan;
        if (d4 == 0d || d4 < 1.0E-14d) {
            Log.d(TAG, "zero denominator?!");
            return false;
        } else if (d5 == 0d || d5 < 1.0E-14d) {
            Log.d(TAG, "zero alt denominator?!");
            return false;
        } else {
            int i5 = (int) (((d3 + (((((double) i2) * 2.0d) * sin) * tan)) - (d2 * tan)) / d4);
            int i6 = (int) ((((double) i5) * d3) / d2);
            int i7 = (int) (((d2 + (((((double) i) * 2.0d) * sin) * tan)) - (tan * d3)) / d5);
            int i8 = (int) ((((double) i7) * d2) / d3);
            Log.d(TAG, "w2 = " + i5 + " , h2 = " + i6);
            Log.d(TAG, "alt_w2 = " + i8 + " , alt_h2 = " + i7);
            if (i8 < i5) {
                Log.d(TAG, "chose alt!");
                i6 = i7;
                i5 = i8;
            }
            if (i5 <= 0) {
                i5 = 1;
            } else {
                int i9 = i3;
                if (i5 > i9) {
                    i5 = i9;
                }
            }
            if (i6 <= 0) {
                i6 = 1;
            } else {
                int i10 = i4;
                if (i6 > i10) {
                    i6 = i10;
                }
            }
            iArr[0] = i5;
            iArr[1] = i6;
            return true;
        }
    }

    private Bitmap autoStabilise(byte[] bArr, Bitmap bitmap, double d, boolean z) {
        Bitmap bitmap2;
        Bitmap bitmap3;
        boolean z2 = z;
        Log.d(TAG, "autoStabilise");
        StringBuilder sb = new StringBuilder();
        sb.append("level_angle: ");
        double d2 = d;
        sb.append(d2);
        Log.d(TAG, sb.toString());
        Log.d(TAG, "is_front_facing: " + z2);
        while (d2 < -90.0d) {
            d2 += 180.0d;
        }
        while (d2 > 90.0d) {
            d2 -= 180.0d;
        }
        Log.d(TAG, "auto stabilising... angle: " + d2);
        if (bitmap == null) {
            Log.d(TAG, "need to decode bitmap to auto-stabilise");
            bitmap2 = loadBitmapWithRotation(bArr, false);
            if (bitmap2 == null) {
                this.main_activity.getPreview().showToast((ToastBoxer) null, (int) R.string.failed_to_auto_stabilise);
                System.gc();
            }
        } else {
            bitmap2 = bitmap;
        }
        if (bitmap2 != null) {
            int width = bitmap2.getWidth();
            int height = bitmap2.getHeight();
            Log.d(TAG, "level_angle: " + d2);
            Log.d(TAG, "decoded bitmap size " + width + ", " + height);
            StringBuilder sb2 = new StringBuilder();
            sb2.append("bitmap size: ");
            int i = width * height;
            sb2.append(i * 4);
            Log.d(TAG, sb2.toString());
            Matrix matrix = new Matrix();
            double abs = Math.abs(Math.toRadians(d2));
            double d3 = (double) width;
            Matrix matrix2 = matrix;
            double d4 = (double) height;
            double cos = (Math.cos(abs) * d3) + (Math.sin(abs) * d4);
            double sin = (d3 * Math.sin(abs)) + (d4 * Math.cos(abs));
            float f = (float) i;
            Bitmap bitmap4 = bitmap2;
            String str = ", ";
            float f2 = (float) (cos * sin);
            float sqrt = (float) Math.sqrt((double) (f / f2));
            if (this.main_activity.test_low_memory) {
                Log.d(TAG, "TESTING LOW MEMORY");
                Log.d(TAG, "scale was: " + sqrt);
                sqrt *= i >= 7500 ? 1.5f : 2.0f;
            }
            Log.d(TAG, "w0 = " + cos + " , h0 = " + sin);
            Log.d(TAG, "w1 = " + width + " , h1 = " + height);
            StringBuilder sb3 = new StringBuilder();
            double d5 = d2;
            sb3.append("scale = sqrt ");
            sb3.append(f);
            sb3.append(" / ");
            sb3.append(f2);
            sb3.append(" = ");
            sb3.append(sqrt);
            Log.d(TAG, sb3.toString());
            Matrix matrix3 = matrix2;
            matrix3.postScale(sqrt, sqrt);
            double d6 = (double) sqrt;
            double d7 = cos * d6;
            double d8 = d6 * sin;
            int i2 = (int) (((float) width) * sqrt);
            int i3 = (int) (((float) height) * sqrt);
            Log.d(TAG, "after scaling: w0 = " + d7 + " , h0 = " + d8);
            Log.d(TAG, "after scaling: w1 = " + i2 + " , h1 = " + i3);
            if (z2) {
                matrix3.postRotate((float) (-d5));
            } else {
                matrix3.postRotate((float) d5);
            }
            Bitmap createBitmap = Bitmap.createBitmap(bitmap4, 0, 0, width, height, matrix3, true);
            Bitmap bitmap5 = bitmap4;
            if (createBitmap != bitmap5) {
                bitmap5.recycle();
            } else {
                createBitmap = bitmap5;
            }
            System.gc();
            Log.d(TAG, "rotated and scaled bitmap size " + createBitmap.getWidth() + str + createBitmap.getHeight());
            StringBuilder sb4 = new StringBuilder();
            sb4.append("rotated and scaled bitmap size: ");
            sb4.append(createBitmap.getWidth() * createBitmap.getHeight() * 4);
            Log.d(TAG, sb4.toString());
            int[] iArr = new int[2];
            if (!autoStabiliseCrop(iArr, abs, d7, d8, i2, i3, createBitmap.getWidth(), createBitmap.getHeight())) {
                return createBitmap;
            }
            int i4 = iArr[0];
            int i5 = iArr[1];
            int width2 = (createBitmap.getWidth() - i4) / 2;
            int height2 = (createBitmap.getHeight() - i5) / 2;
            Log.d(TAG, "x0 = " + width2 + " , y0 = " + height2);
            Bitmap createBitmap2 = Bitmap.createBitmap(createBitmap, width2, height2, i4, i5);
            if (createBitmap2 != createBitmap) {
                createBitmap.recycle();
                bitmap3 = createBitmap2;
            } else {
                bitmap3 = createBitmap;
            }
            Log.d(TAG, "bitmap is mutable?: " + bitmap3.isMutable());
            System.gc();
            return bitmap3;
        }
        Bitmap bitmap6 = bitmap2;
        return bitmap2;
    }

    private Bitmap mirrorImage(byte[] bArr, Bitmap bitmap) {
        Log.d(TAG, "mirrorImage");
        if (bitmap == null) {
            Log.d(TAG, "need to decode bitmap to mirror");
            bitmap = loadBitmapWithRotation(bArr, false);
            if (bitmap == null) {
                System.gc();
            }
        }
        if (bitmap != null) {
            Matrix matrix = new Matrix();
            matrix.preScale(-1.0f, 1.0f);
            Bitmap createBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
            if (createBitmap != bitmap) {
                bitmap.recycle();
                bitmap = createBitmap;
            }
            Log.d(TAG, "bitmap is mutable?: " + bitmap.isMutable());
        }
        return bitmap;
    }

    public Bitmap loadBitmapFromView(View v) {
//        Bitmap b = Bitmap.createBitmap(v.getLayoutParams().width, v.getLayoutParams().height, Bitmap.Config.ARGB_8888);
        Bitmap b = Bitmap.createBitmap(v.getWidth(), v.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);

        v.layout(v.getLeft(), v.getTop(), v.getRight(), v.getBottom());
        v.draw(c);

        Bitmap b1 = Bitmap.createBitmap(v.getWidth(), v.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c1 = new Canvas(b1);
        Paint alphaPaint = new Paint();
        alphaPaint.setAlpha((int) (v.getAlpha() * 255));
        c1.drawBitmap(b, 0, 0, alphaPaint);

        return b1;
    }

    public Bitmap loadBitmapFromCameraPreview(Bitmap bitmap, View v) {
//        Bitmap b = Bitmap.createBitmap(v.getWidth(), v.getHeight(), Bitmap.Config.ARGB_8888);
        Bitmap b = Bitmap.createScaledBitmap(bitmap, v.getWidth(), v.getHeight(), false);
//        Canvas c = new Canvas(b);
//        v.layout(v.getLeft(), v.getTop(), v.getRight(), v.getBottom());
//        v.draw(c);
        return b;
    }

    private Bitmap stampImage(Request request, byte[] bArr, Bitmap bitmap) {

        Log.d(TAG, "stampImage");
        MyApplicationInterface applicationInterface = this.main_activity.getApplicationInterface();
        if (bitmap == null) {
            Log.d(TAG, "decode bitmap in order to stamp info");
            bitmap = loadBitmapWithRotation(bArr, true);
            if (bitmap == null) {
                this.main_activity.getPreview().showToast((ToastBoxer) null, (int) R.string.failed_to_stamp);
                System.gc();
            }
        }
//// TODO: 18/02/22 For Camera Stamp
        boolean isEnableStamp = SharedPrefs.getBoolean(main_activity, SharedPrefs.IS_ENABLE_STAMP, true);

        View snapShotView = applicationInterface.getCameraSnapShotView();
        View snapView = main_activity.getPreview().getView();

        Bitmap bitmapSnapShot = loadBitmapFromView(snapShotView);
        Bitmap bitmapView = loadBitmapFromCameraPreview(bitmap, snapView);

        Log.e(TAG, "bitmapSnapShot.getWidth: " + bitmapSnapShot.getWidth());
        Log.e(TAG, "bitmapSnapShot.getHeight: " + bitmapSnapShot.getHeight());
        Log.e(TAG, "snapShotView.getX: " + snapShotView.getX());
        Log.e(TAG, "snapShotView.getY: " + snapShotView.getY());
        if (isEnableStamp) {
            Canvas canvas = new Canvas(bitmapView);
            canvas.drawBitmap(bitmapSnapShot, snapShotView.getX(), snapShotView.getY(), null);
        }


        return rotateForExifStamp(bitmapView, bArr);


//        Log.d(TAG, "stampImage");
//        MyApplicationInterface applicationInterface = this.main_activity.getApplicationInterface();
//        if (bitmap == null) {
//            Log.d(TAG, "decode bitmap in order to stamp info");
//            bitmap = loadBitmapWithRotation(bArr, true);
//            if (bitmap == null) {
//                this.main_activity.getPreview().showToast((ToastBoxer) null, (int) R.string.failed_to_stamp);
//                System.gc();
//            }
//        }
//
//        Log.e(TAG, "stampImage: *-121-* " + main_activity.preview.getCameraControllerManager().getFacing(main_activity.preview.getCameraId()));
//        Log.e(TAG, "stampImage: *-121-* " + CameraController.Facing.FACING_FRONT);
//
//        if (!main_activity.preview.getCameraControllerManager().getFacing(main_activity.preview.getCameraId()).toString().equals(CameraController.Facing.FACING_FRONT)) {
//            Log.e(TAG, "stampImage:FACING_FRONT ");
//            View snapShotView = applicationInterface.getCameraSnapShotView();
//            View snapView = main_activity.getPreview().getView();
//
//            Bitmap bitmapSnapShot;
//
//            bitmapSnapShot = loadBitmapFromView(snapShotView);
//            Bitmap bitmapView = loadBitmapFromCameraPreview(bitmap, snapView);
//
//
//            Log.e(TAG, "bitmapSnapShot.getWidth: " + bitmapSnapShot.getWidth());
//            Log.e(TAG, "bitmapSnapShot.getHeight: " + bitmapSnapShot.getHeight());
//            Log.e(TAG, "snapShotView.getX: " + snapShotView.getX());
//            Log.e(TAG, "snapShotView.getY: " + snapShotView.getY());
//
//            Canvas canvas = new Canvas(bitmapView);
//            canvas.drawBitmap(bitmapSnapShot, snapShotView.getX(), snapShotView.getY(), null);
//            return rotateForExifStamp(bitmapView, bArr);
//        }
//
//        return bitmap;

//        if (bitmap != null) {
//            if (MyDebug.LOG)
//                Log.d(TAG, "stamp info to bitmap: " + bitmap);
//            if (MyDebug.LOG)
//                Log.d(TAG, "bitmap is mutable?: " + bitmap.isMutable());
//            int font_size = request.font_size;
//            int color = request.color;
//            String pref_style = request.pref_style;
//            if (MyDebug.LOG)
//                Log.d(TAG, "pref_style: " + pref_style);
//            int width = bitmap.getWidth();
//            int height = bitmap.getHeight();
//            if (MyDebug.LOG) {
//                Log.d(TAG, "decoded bitmap size " + width + ", " + height);
//                Log.d(TAG, "bitmap size: " + width * height * 4);
//            }
//            Canvas canvas = new Canvas(bitmap);
//
//            // we don't use the density of the screen, because we're stamping to the image, not drawing on the screen (we don't want the font height to depend on the device's resolution)
//            // instead we go by 1 pt == 1/72 inch height, and scale for an image height (or width if in portrait) of 4" (this means the font height is also independent of the photo resolution)
//            int smallest_size = Math.min(width, height);
//            float scale = ((float) smallest_size) / (72.0f * 4.0f);
//            int font_size_pixel = (int) (font_size * scale + 0.5f); // convert pt to pixels
//            if (MyDebug.LOG) {
//                Log.d(TAG, "scale: " + scale);
//                Log.d(TAG, "font_size: " + font_size);
//                Log.d(TAG, "font_size_pixel: " + font_size_pixel);
//            }
//            p.setTextSize(font_size_pixel);
//            int offset_x = (int) (8 * scale + 0.5f); // convert pt to pixels
//            int offset_y = (int) (8 * scale + 0.5f); // convert pt to pixels
//            int diff_y = (int) ((font_size + 4) * scale + 0.5f); // convert pt to pixels
//            int ypos = height - offset_y;
//            p.setTextAlign(Paint.Align.RIGHT);
//            MyApplicationInterface.Shadow draw_shadowed = MyApplicationInterface.Shadow.SHADOW_NONE;
//            switch (pref_style) {
//                case "preference_stamp_style_shadowed":
//                    draw_shadowed = MyApplicationInterface.Shadow.SHADOW_OUTLINE;
//                    break;
//                case "preference_stamp_style_plain":
//                    draw_shadowed = MyApplicationInterface.Shadow.SHADOW_NONE;
//                    break;
//                case "preference_stamp_style_background":
//                    draw_shadowed = MyApplicationInterface.Shadow.SHADOW_BACKGROUND;
//                    break;
//            }
//            if (MyDebug.LOG)
//                Log.d(TAG, "draw_shadowed: " + draw_shadowed);
//            if (main_activity.isAddress || main_activity.isStreetAddress || main_activity.isDateTime) {
//                if (MyDebug.LOG)
//                    Log.d(TAG, "stamp date");
//                ArrayList<String> addressLines = new ArrayList<>();
//                if (main_activity.isAddress && main_activity.isStreetAddress) {
//                    for (int i = 0; i < main_activity.tvAddress.getLineCount(); i++) {
//                        int start = main_activity.tvAddress.getLayout().getLineStart((i));
//                        int end;
//                        if ((i) != (main_activity.tvAddress.getLineCount() - 1))
//                            end = main_activity.tvAddress.getLayout().getLineEnd((i));
//                        else
//                            end = main_activity.tvAddress.length();
//
//                        CharSequence substring = main_activity.tvAddress.getText().subSequence(start, end);
//
//                        if (i == (main_activity.tvAddress.getLineCount() - 1))
//                            substring = substring + " ";
//
//                        Log.d(TAG, "Line ===> " + substring);
//                        addressLines.add(substring.toString());
//                    }
//                } else if (main_activity.isAddress) {
//                    for (int i = 0; i < main_activity.tvAddress.getLineCount(); i++) {
//                        int start = main_activity.tvAddress.getLayout().getLineStart((i));
//                        int end;
//                        if ((i) != (main_activity.tvAddress.getLineCount() - 1))
//                            end = main_activity.tvAddress.getLayout().getLineEnd((i));
//                        else
//                            end = main_activity.tvAddress.length();
//
//                        CharSequence substring = main_activity.tvAddress.getText().subSequence(start, end);
//
//                        Log.d(TAG, "Line ===> " + substring);
//                        addressLines.add(substring.toString());
//                    }
//                } else if (main_activity.isStreetAddress) {
//                    for (int i = 0; i < main_activity.tvAddress.getLineCount(); i++) {
//                        int start = main_activity.tvAddress.getLayout().getLineStart((i));
//                        int end;
//                        if ((i) != (main_activity.tvAddress.getLineCount() - 1))
//                            end = main_activity.tvAddress.getLayout().getLineEnd((i));
//                        else
//                            end = main_activity.tvAddress.length();
//
//                        CharSequence substring = main_activity.tvAddress.getText().subSequence(start, end);
//
//                        Log.d(TAG, "Line ===> " + substring);
//                        addressLines.add(substring.toString());
//                    }
//                }
//
//                if (main_activity.isDateTime) {
//                    applicationInterface.drawTextWithBackground(
//                            canvas,
//                            p,
//                            main_activity.tvWaterMark.getText().toString() + " ",
//                            main_activity.dateTimeColor,
//                            main_activity.dateTimeColor,
//                            width - offset_x,
//                            ypos,
//                            MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM,
//                            null,
//                            draw_shadowed
//                    );
//                    ypos -= diff_y;
//                }
//
//                String gps_stamp = main_activity.tvAddress.getText().toString();
//                if (gps_stamp.length() > 0) {
//                    if (addressLines.size() > 0) {
//                        Collections.reverse(addressLines);
//                        for (int i = 0; i < addressLines.size(); i++) {
//                            applicationInterface.drawTextWithBackground(
//                                    canvas,
//                                    p,
//                                    addressLines.get(i),
//                                    main_activity.addressColor,
//                                    main_activity.addressColor,
//                                    width - offset_x,
//                                    ypos,
//                                    MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM,
//                                    null,
//                                    draw_shadowed
//                            );
//                            ypos -= diff_y;
//                        }
//                    }
//                }
//            }
//        }
    }

    private static class PostProcessBitmapResult {
        final Bitmap bitmap;

        PostProcessBitmapResult(Bitmap bitmap2) {
            this.bitmap = bitmap2;
        }
    }

    private PostProcessBitmapResult postProcessBitmap(Request request, byte[] bArr, Bitmap bitmap, boolean z) throws IOException {
        Request request2 = request;
        byte[] bArr2 = bArr;
        Bitmap bitmap2 = bitmap;
        Log.d(TAG, "postProcessBitmap");
        long currentTimeMillis = System.currentTimeMillis();
        boolean equals = request2.preference_stamp.equals("preference_stamp_yes");
        boolean isStampEnable = SharedPrefs.getBoolean(main_activity, SharedPrefs.IS_ENABLE_STAMP, true);
        boolean z2 = request2.preference_textstamp.length() > 0;
        if ((bitmap2 != null || request2.image_format != Request.ImageFormat.STD || request2.do_auto_stabilise || request2.mirror || equals || z2) && !z && bitmap2 != null) {
            Log.d(TAG, "rotate pre-existing bitmap for exif tags?");
            bitmap2 = rotateForExif(bitmap2, bArr);
        }
        Bitmap bitmap3 = bitmap2;
        if (request2.do_auto_stabilise) {
            bitmap3 = autoStabilise(bArr, bitmap3, request2.level_angle, request2.is_front_facing);
        }
        Log.d(TAG, "Save single image performance: time after auto-stabilise: " + (System.currentTimeMillis() - currentTimeMillis));
        if (request2.mirror) {
            bitmap3 = mirrorImage(bArr, bitmap3);
        }
        if (request2.image_format != Request.ImageFormat.STD && bitmap3 == null) {
            Log.d(TAG, "need to decode bitmap to convert file format");
            bitmap3 = loadBitmapWithRotation(bArr, true);
            if (bitmap3 == null) {
                System.gc();
                throw new IOException();
            }
        }
        Bitmap stampImage = stampImage(request, bArr, bitmap3);
        Log.d(TAG, "Save single image performance: time after photostamp: " + (System.currentTimeMillis() - currentTimeMillis));
        return new PostProcessBitmapResult(stampImage);
    }

    /**
     * May be run in saver thread or picture callback thread (depending on whether running in background).
     * The requests.images field is ignored, instead we save the supplied data or bitmap.
     * If bitmap is null, then the supplied jpeg data is saved. If bitmap is non-null, then the bitmap is
     * saved, but the supplied data is still used to read EXIF data from.
     *
     * @param update_thumbnail        - Whether to update the thumbnail (and show the animation).
     * @param share_image             - Whether this image should be marked as the one to share (if multiple images can
     *                                be saved from a single shot (e.g., saving exposure images with HDR).
     * @param ignore_raw_only         - If true, then save even if RAW Only is set (needed for HDR mode
     *                                where we always save the HDR image even though it's a JPEG - the
     *                                RAW preference only affects the base images.
     * @param ignore_exif_orientation - If bitmap is non-null, then set this to true if the bitmap has already
     *                                been rotated to account for Exif orientation tags in the data.
     */
    @SuppressLint("SimpleDateFormat")
    private boolean saveSingleImageNow(final Request request, byte[] data, Bitmap bitmap, String filename_suffix, boolean update_thumbnail, boolean share_image, boolean ignore_raw_only, boolean ignore_exif_orientation) {
        if (MyDebug.LOG)
            Log.d(TAG, "saveSingleImageNow");

        if (request.type != Request.Type.JPEG) {
            if (MyDebug.LOG)
                Log.d(TAG, "saveImageNow called with non-jpeg request");
            // throw runtime exception, as this is a programming error
            throw new RuntimeException();
        } else if (data == null) {
            if (MyDebug.LOG)
                Log.d(TAG, "saveSingleImageNow called with no data");
            // throw runtime exception, as this is a programming error
            throw new RuntimeException();
        }
        long time_s = System.currentTimeMillis();

        boolean success = false;
        final MyApplicationInterface applicationInterface = main_activity.getApplicationInterface();
        boolean raw_only = !ignore_raw_only && applicationInterface.isRawOnly();
        if (MyDebug.LOG)
            Log.d(TAG, "raw_only: " + raw_only);
        StorageUtils storageUtils = main_activity.getStorageUtils();

        String extension;
        switch (request.image_format) {
            case WEBP:
                extension = "webp";
                break;
            case PNG:
                extension = "png";
                break;
            default:
                extension = "jpg";
                break;
        }
        if (MyDebug.LOG)
            Log.d(TAG, "extension: " + extension);

        main_activity.savingImage(true);

        // If using SAF or image_capture_intent is true, or using scoped storage, only saveUri is non-null
        // Otherwise, only picFile is non-null
        File picFile = null;
        Uri saveUri = null;
        boolean use_media_store = false;
        ContentValues contentValues = null; // used if using scoped storage
        try {
            if (!raw_only) {
                PostProcessBitmapResult postProcessBitmapResult = postProcessBitmap(request, data, bitmap, ignore_exif_orientation);

                bitmap = postProcessBitmapResult.bitmap;

//                Bitmap stampBitmap = applicationInterface.getCameraSnapShot();
//                Float stampBitmapX = applicationInterface.getCameraSnapShotX();
//                Float stampBitmapY = applicationInterface.getCameraSnapShotY();
//
//
//                Canvas canvas = new Canvas(bitmap);

//                stampBitmap = Bitmap.createBitmap(stampBitmap, Integer.parseInt(stampBitmapX.toString()), Integer.parseInt(stampBitmapY.toString()), 100, 100);
//                canvas.drawBitmap(stampBitmap, stampBitmapX, stampBitmapY, null);


//                bitmap = applicationInterface.getCameraSnapShot();
            }

            if (raw_only) {
                // don't save the JPEG
                success = true;
            } else if (request.image_capture_intent) {
                if (MyDebug.LOG)
                    Log.d(TAG, "image_capture_intent");
                if (request.image_capture_intent_uri != null) {
                    // Save the bitmap to the specified URI (use a try/catch block)
                    if (MyDebug.LOG)
                        Log.d(TAG, "save to: " + request.image_capture_intent_uri);
                    saveUri = request.image_capture_intent_uri;
                } else {
                    // If the intent doesn't contain an URI, send the bitmap as a parcel
                    // (it is a good idea to reduce its size to ~50k pixels before)
                    if (MyDebug.LOG)
                        Log.d(TAG, "sent to intent via parcel");
                    if (bitmap == null) {
                        if (MyDebug.LOG)
                            Log.d(TAG, "create bitmap");
                        // bitmap we return doesn't need to be mutable
                        bitmap = loadBitmapWithRotation(data, false);
                    }
                    if (bitmap != null) {
                        int width = bitmap.getWidth();
                        int height = bitmap.getHeight();
                        if (MyDebug.LOG) {
                            Log.d(TAG, "decoded bitmap size " + width + ", " + height);
                            Log.d(TAG, "bitmap size: " + width * height * 4);
                        }
                        final int small_size_c = 128;
                        if (width > small_size_c) {
                            float scale = ((float) small_size_c) / (float) width;
                            if (MyDebug.LOG)
                                Log.d(TAG, "scale to " + scale);
                            Matrix matrix = new Matrix();
                            matrix.postScale(scale, scale);
                            Bitmap new_bitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
                            // careful, as new_bitmap is sometimes not a copy!
                            if (new_bitmap != bitmap) {
                                bitmap.recycle();
                                bitmap = new_bitmap;
                            }
                        }
                    }
                    if (MyDebug.LOG) {
                        if (bitmap != null) {
                            Log.d(TAG, "returned bitmap size " + bitmap.getWidth() + ", " + bitmap.getHeight());
                            Log.d(TAG, "returned bitmap size: " + bitmap.getWidth() * bitmap.getHeight() * 4);
                        } else {
                            Log.e(TAG, "no bitmap created");
                        }
                    }
                    if (bitmap != null)
                        main_activity.setResult(Activity.RESULT_OK, new Intent("inline-data").putExtra("data", bitmap));
                    main_activity.finish();
                }
            } else if (storageUtils.isUsingSAF()) {
                saveUri = storageUtils.createOutputMediaFileSAF(StorageUtils.MEDIA_TYPE_IMAGE, filename_suffix, extension, request.current_date);
            } else if (CameraActivity.useScopedStorage()) {
                if (MyDebug.LOG)
                    Log.d(TAG, "use media store");
                use_media_store = true;
                Uri folder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ?
                        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) :
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                contentValues = new ContentValues();
                String picName = storageUtils.createMediaFilename(StorageUtils.MEDIA_TYPE_IMAGE, filename_suffix, 0, "." + extension, request.current_date);
                if (MyDebug.LOG)
                    Log.d(TAG, "picName: " + picName);
                contentValues.put(MediaStore.Images.Media.DISPLAY_NAME, picName);
                String mime_type = storageUtils.getImageMimeType(extension);
                if (MyDebug.LOG)
                    Log.d(TAG, "mime_type: " + mime_type);
                contentValues.put(MediaStore.Images.Media.MIME_TYPE, mime_type);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    String relative_path = storageUtils.getSaveRelativeFolder();
                    if (MyDebug.LOG)
                        Log.d(TAG, "relative_path: " + relative_path);
                    contentValues.put(MediaStore.Images.Media.RELATIVE_PATH, relative_path);
                    contentValues.put(MediaStore.Images.Media.IS_PENDING, 1);
                }

                saveUri = main_activity.getContentResolver().insert(folder, contentValues);
                if (MyDebug.LOG)
                    Log.d(TAG, "saveUri: " + saveUri);
                if (saveUri == null) {
                    throw new IOException();
                }
            } else {
                picFile = storageUtils.createOutputMediaFile(StorageUtils.MEDIA_TYPE_IMAGE, filename_suffix, extension, request.current_date);
                if (MyDebug.LOG)
                    Log.d(TAG, "save to: " + picFile.getAbsolutePath());
            }

            if (MyDebug.LOG)
                Log.d(TAG, "saveUri: " + saveUri);

            if (picFile != null || saveUri != null) {
                OutputStream outputStream;
                if (picFile != null)
                    outputStream = new FileOutputStream(picFile);
                else
                    outputStream = main_activity.getContentResolver().openOutputStream(saveUri);
                try {
                    if (bitmap != null) {
                        if (MyDebug.LOG)
                            Log.d(TAG, "compress bitmap, quality " + request.image_quality);
                        Bitmap.CompressFormat compress_format;
                        switch (request.image_format) {
                            case WEBP:
                                compress_format = Bitmap.CompressFormat.WEBP;
                                break;
                            case PNG:
                                compress_format = Bitmap.CompressFormat.PNG;
                                break;
                            default:
                                compress_format = Bitmap.CompressFormat.JPEG;
                                break;
                        }
                        bitmap.compress(compress_format, request.image_quality, outputStream);
                    } else {
                        outputStream.write(data);
                    }
                } finally {
                    outputStream.close();
                }
                if (MyDebug.LOG)
                    Log.d(TAG, "saveImageNow saved photo");
                if (MyDebug.LOG) {
                    Log.d(TAG, "Save single image performance: time after saving photo: " + (System.currentTimeMillis() - time_s));
                }

                if (saveUri == null) { // if saveUri is non-null, then we haven't succeeded until we've copied to the saveUri
                    success = true;
                }

                if (request.image_format == Request.ImageFormat.STD) {
                    // handle transferring/setting Exif tags (JPEG format only)
                    if (bitmap != null) {
                        // need to update EXIF data! (only supported for JPEG image formats)
                        if (MyDebug.LOG)
                            Log.d(TAG, "set Exif tags from data");
                        if (picFile != null) {
                            setExifFromData(request, data, picFile);
                        } else {
                            ParcelFileDescriptor parcelFileDescriptor = main_activity.getContentResolver().openFileDescriptor(saveUri, "rw");
                            try {
                                if (parcelFileDescriptor != null) {
                                    FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
                                    setExifFromData(request, data, fileDescriptor);
                                } else {
                                    Log.e(TAG, "failed to create ParcelFileDescriptor for saveUri: " + saveUri);
                                }
                            } finally {
                                if (parcelFileDescriptor != null) {
                                    try {
                                        parcelFileDescriptor.close();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }
                    } else {
                        updateExif(request, picFile, saveUri);
                        if (MyDebug.LOG) {
                            Log.d(TAG, "Save single image performance: time after updateExif: " + (System.currentTimeMillis() - time_s));
                        }
                    }
                }

                if (picFile != null && saveUri == null) {
                    // broadcast for SAF is done later, when we've actually written out the file
                    storageUtils.broadcastFile(picFile, true, false, update_thumbnail);
                    main_activity.test_last_saved_image = picFile.getAbsolutePath();
                }

                if (request.image_capture_intent) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "finish activity due to being called from intent");
                    main_activity.setResult(Activity.RESULT_OK);
                    main_activity.finish();
                }
                if (storageUtils.isUsingSAF()) {
                    // most Gallery apps don't seem to recognise the SAF-format Uri, so just clear the field
                    storageUtils.clearLastMediaScanned();
                }

                if (saveUri != null) {
                    success = true;

                    if (use_media_store) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            contentValues.clear();
                            contentValues.put(MediaStore.Images.Media.IS_PENDING, 0);
                            main_activity.getContentResolver().update(saveUri, contentValues, null, null);
                        }

                        // no need to broadcast when using mediastore method
                        if (!request.image_capture_intent) {
                            if (MyDebug.LOG)
                                Log.d(TAG, "announce mediastore uri");
                            // in theory this is pointless, as announceUri no longer does anything on Android 7+,
                            // and mediastore method is only used on Android 10+, but keep this just in case
                            // announceUri does something in future
                            storageUtils.announceUri(saveUri, true, false);
                            // we also want to save the uri - we can use the media uri directly, rather than having to scan it
                            storageUtils.setLastMediaScanned(saveUri);
                        }
                    } else {
                        broadcastSAFFile(saveUri, request.image_capture_intent);
                    }

                    main_activity.test_last_saved_imageuri = saveUri;
                }
            }
        } catch (FileNotFoundException e) {
            if (MyDebug.LOG)
                Log.e(TAG, "File not found: " + e.getMessage());
            e.printStackTrace();
            main_activity.getPreview().showToast(null, R.string.failed_to_save_photo);
        } catch (IOException e) {
            if (MyDebug.LOG)
                Log.e(TAG, "I/O error writing file: " + e.getMessage());
            e.printStackTrace();
            main_activity.getPreview().showToast(null, R.string.failed_to_save_photo);
        } catch (SecurityException e) {
            // received security exception from copyFileToUri()->openOutputStream() from Google Play
            // update: no longer have copyFileToUri() (as no longer use temporary files for SAF), but might as well keep this
            if (MyDebug.LOG)
                Log.e(TAG, "security exception writing file: " + e.getMessage());
            e.printStackTrace();
            main_activity.getPreview().showToast(null, R.string.failed_to_save_photo);
        } catch (IllegalArgumentException e) {
            // can happen for mediastore method if invalid ContentResolver.insert() call
            if (MyDebug.LOG)
                Log.e(TAG, "IllegalArgumentException writing file: " + e.getMessage());
            e.printStackTrace();
            main_activity.getPreview().showToast(null, R.string.failed_to_save_photo);
        }

        if (raw_only) {
            // no saved image to record
        } else if (success && saveUri == null) {
            applicationInterface.addLastImage(picFile, share_image);
        } else if (success && storageUtils.isUsingSAF()) {
            applicationInterface.addLastImageSAF(saveUri, share_image);
        } else if (success && use_media_store) {
            applicationInterface.addLastImageMediaStore(saveUri, share_image);
        }

        // I have received crashes where camera_controller was null - could perhaps happen if this thread was running just as the camera is closing?
        if (success && main_activity.getPreview().getCameraController() != null && update_thumbnail) {
            // update thumbnail - this should be done after restarting preview, so that the preview is started asap
            CameraController.Size size = main_activity.getPreview().getCameraController().getPictureSize();
            int ratio = (int) Math.ceil((double) size.width / main_activity.getPreview().getView().getWidth());
            int sample_size = Integer.highestOneBit(ratio);
            sample_size *= request.sample_factor;
            if (MyDebug.LOG) {
                Log.d(TAG, "    picture width: " + size.width);
                Log.d(TAG, "    preview width: " + main_activity.getPreview().getView().getWidth());
                Log.d(TAG, "    ratio        : " + ratio);
                Log.d(TAG, "    sample_size  : " + sample_size);
            }
            Bitmap thumbnail;
            if (bitmap == null) {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inMutable = false;
                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
                    // setting is ignored in Android 5 onwards
                    options.inPurgeable = true;
                }
                options.inSampleSize = sample_size;
                thumbnail = BitmapFactory.decodeByteArray(data, 0, data.length, options);
                if (MyDebug.LOG) {
                    Log.d(TAG, "thumbnail width: " + thumbnail.getWidth());
                    Log.d(TAG, "thumbnail height: " + thumbnail.getHeight());
                }
                // now get the rotation from the Exif data
                if (MyDebug.LOG)
                    Log.d(TAG, "rotate thumbnail for exif tags?");
                thumbnail = rotateForExif(thumbnail, data);
            } else {
                int width = bitmap.getWidth();
                int height = bitmap.getHeight();
                Matrix matrix = new Matrix();
                float scale = 1.0f / (float) sample_size;
                matrix.postScale(scale, scale);
                if (MyDebug.LOG)
                    Log.d(TAG, "    scale: " + scale);
                try {
                    thumbnail = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
                    if (MyDebug.LOG) {
                        Log.d(TAG, "thumbnail width: " + thumbnail.getWidth());
                        Log.d(TAG, "thumbnail height: " + thumbnail.getHeight());
                    }
                    // don't need to rotate for exif, as we already did that when creating the bitmap
                } catch (IllegalArgumentException e) {
                    // received IllegalArgumentException on Google Play from Bitmap.createBitmap; documentation suggests this
                    // means width or height are 0 - but trapping that didn't fix the problem
                    // or "the x, y, width, height values are outside of the dimensions of the source bitmap", but that can't be
                    // true here
                    // crashes seem to all be Android 7.1 or earlier, so maybe this is a bug that's been fixed - but catch it anyway
                    // as it's grown popular
                    Log.e(TAG, "can't create thumbnail bitmap due to IllegalArgumentException?!");
                    e.printStackTrace();
                    thumbnail = null;
                }
            }
            if (thumbnail == null) {
                // received crashes on Google Play suggesting that thumbnail could not be created
                if (MyDebug.LOG)
                    Log.e(TAG, "failed to create thumbnail bitmap");
            } else {
                final Bitmap thumbnail_f = thumbnail;
                Uri finalSaveUri = saveUri;
                File finalPicFile = picFile;


                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        main_activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                applicationInterface.updateThumbnail(thumbnail_f, false, finalPicFile, finalSaveUri);
                            }
                        });
                    }
                };
                main_activity.getHandler().postDelayed(runnable, 1000);

                if (MyDebug.LOG) {
                    Log.d(TAG, "Save single image performance: time after creating thumbnail: " + (System.currentTimeMillis() - time_s));
                }
            }
        }

        if (bitmap != null) {
            bitmap.recycle();
        }

        System.gc();

        main_activity.savingImage(false);

        if (MyDebug.LOG) {
            Log.d(TAG, "Save single image performance: total time: " + (System.currentTimeMillis() - time_s));
        }
        return success;
    }

    /**
     * As setExifFromFile, but can read the Exif tags directly from the jpeg data rather than a file.
     */
    private void setExifFromData(final Request request, byte[] data, File to_file) throws IOException {
        if (MyDebug.LOG) {
            Log.d(TAG, "setExifFromData");
            Log.d(TAG, "to_file: " + to_file);
        }
        InputStream inputStream = null;
        try {
            inputStream = new ByteArrayInputStream(data);
            ExifInterface exif = new ExifInterface(inputStream);
            ExifInterface exif_new = new ExifInterface(to_file.getAbsolutePath());
            setExif(request, exif, exif_new);
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
    }

    private void broadcastSAFFile(Uri uri, boolean z) {
        Log.d(TAG, "broadcastSAFFile");
        this.main_activity.getStorageUtils().broadcastUri(uri, true, false, true, z);
    }

    /**
     * As setExifFromFile, but can read the Exif tags directly from the jpeg data, and to a file descriptor, rather than a file.
     */
    private void setExifFromData(final Request request, byte[] data, FileDescriptor to_file_descriptor) throws IOException {
        if (MyDebug.LOG) {
            Log.d(TAG, "setExifFromData");
            Log.d(TAG, "to_file_descriptor: " + to_file_descriptor);
        }
        InputStream inputStream = null;
        try {

            inputStream = new ByteArrayInputStream(data);
            ExifInterface exif = new ExifInterface(inputStream);
            ExifInterface exif_new = new ExifInterface(to_file_descriptor);
            if (GeneralUtilsKt.isOnline(main_activity) && NetworkManager.isGPSConnected(main_activity) && main_activity.mLocation != null) {
                exif.setAttribute(ExifInterface.TAG_GPS_LATITUDE, CameraUtils.convert(main_activity.mLocation.getLatitude()));
                exif.setAttribute(ExifInterface.TAG_GPS_LATITUDE_REF, CameraUtils.latitudeRef(main_activity.mLocation.getLatitude()));
                exif.setAttribute(ExifInterface.TAG_GPS_LONGITUDE, CameraUtils.convert(main_activity.mLocation.getLongitude()));
                exif.setAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF, CameraUtils.longitudeRef(main_activity.mLocation.getLongitude()));
            }
            exif.setAttribute(ExifInterface.TAG_DATETIME, ContextKt.getCurrentFormattedDateTime(main_activity));
            setExif(request, exif, exif_new);
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
    }

    private void setExif(Request request, ExifInterface exifInterface, ExifInterface exifInterface2) throws IOException {
        Request request2 = request;
        ExifInterface exifInterface3 = exifInterface;
        ExifInterface exifInterface4 = exifInterface2;
        Log.d(TAG, "setExif");
        Log.d(TAG, "read back EXIF data");
        String attribute = exifInterface3.getAttribute(ExifInterface.TAG_F_NUMBER);
        String attribute2 = exifInterface3.getAttribute(ExifInterface.TAG_DATETIME);
        String attribute3 = exifInterface3.getAttribute(ExifInterface.TAG_EXPOSURE_TIME);
        String attribute4 = exifInterface3.getAttribute(ExifInterface.TAG_FLASH);
        String attribute5 = exifInterface3.getAttribute(ExifInterface.TAG_FOCAL_LENGTH);
        String attribute6 = exifInterface3.getAttribute(ExifInterface.TAG_GPS_ALTITUDE);
        String str = ExifInterface.TAG_GPS_ALTITUDE;
        String attribute7 = exifInterface3.getAttribute(ExifInterface.TAG_GPS_ALTITUDE_REF);
        String str2 = ExifInterface.TAG_GPS_ALTITUDE_REF;
        String str3 = attribute7;
        String attribute8 = exifInterface3.getAttribute(ExifInterface.TAG_GPS_DATESTAMP);
        String str4 = ExifInterface.TAG_GPS_DATESTAMP;
        String str5 = attribute8;
        String attribute9 = exifInterface3.getAttribute(ExifInterface.TAG_GPS_LATITUDE);
        String str6 = ExifInterface.TAG_GPS_LATITUDE;
        String str7 = attribute9;
        String attribute10 = exifInterface3.getAttribute(ExifInterface.TAG_GPS_LATITUDE_REF);
        String str8 = ExifInterface.TAG_GPS_LATITUDE_REF;
        String str9 = attribute10;
        String attribute11 = exifInterface3.getAttribute(ExifInterface.TAG_GPS_LONGITUDE);
        String str10 = ExifInterface.TAG_GPS_LONGITUDE;
        String str11 = attribute11;
        String attribute12 = exifInterface3.getAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF);
        String str12 = ExifInterface.TAG_GPS_LONGITUDE_REF;
        String str13 = attribute12;
        String attribute13 = exifInterface3.getAttribute(ExifInterface.TAG_GPS_PROCESSING_METHOD);
        String str14 = ExifInterface.TAG_GPS_PROCESSING_METHOD;
        String str15 = attribute13;
        String attribute14 = exifInterface3.getAttribute(ExifInterface.TAG_GPS_TIMESTAMP);
        String str16 = ExifInterface.TAG_GPS_TIMESTAMP;
        String str17 = attribute14;
        String attribute15 = exifInterface3.getAttribute(ExifInterface.TAG_ISO_SPEED_RATINGS);
        String str18 = ExifInterface.TAG_ISO_SPEED_RATINGS;
        String str19 = attribute15;
        String attribute16 = exifInterface3.getAttribute(ExifInterface.TAG_MAKE);
        String str20 = ExifInterface.TAG_MAKE;
        String str21 = attribute16;
        String attribute17 = exifInterface3.getAttribute(ExifInterface.TAG_MODEL);
        String str22 = ExifInterface.TAG_MODEL;
        String str23 = attribute17;
        String attribute18 = exifInterface3.getAttribute(ExifInterface.TAG_WHITE_BALANCE);
        String str24 = ExifInterface.TAG_WHITE_BALANCE;
        String str25 = attribute18;
        String attribute19 = exifInterface3.getAttribute(ExifInterface.TAG_DATETIME_DIGITIZED);
        String str26 = ExifInterface.TAG_DATETIME_DIGITIZED;
        String str27 = attribute19;
        String attribute20 = exifInterface3.getAttribute(ExifInterface.TAG_SUBSEC_TIME);
        String str28 = ExifInterface.TAG_SUBSEC_TIME;
        String str29 = attribute20;
        String attribute21 = exifInterface3.getAttribute(ExifInterface.TAG_SUBSEC_TIME_DIGITIZED);
        String str30 = ExifInterface.TAG_SUBSEC_TIME_DIGITIZED;
        String attribute22 = exifInterface3.getAttribute(ExifInterface.TAG_SUBSEC_TIME_ORIGINAL);
        String attribute23 = exifInterface3.getAttribute(ExifInterface.TAG_APERTURE_VALUE);
        String attribute24 = exifInterface3.getAttribute(ExifInterface.TAG_BRIGHTNESS_VALUE);
        String attribute25 = exifInterface3.getAttribute(ExifInterface.TAG_CFA_PATTERN);
        String attribute26 = exifInterface3.getAttribute(ExifInterface.TAG_COLOR_SPACE);
        String attribute27 = exifInterface3.getAttribute(ExifInterface.TAG_COMPONENTS_CONFIGURATION);
        String attribute28 = exifInterface3.getAttribute(ExifInterface.TAG_COMPRESSED_BITS_PER_PIXEL);
        String attribute29 = exifInterface3.getAttribute(ExifInterface.TAG_COMPRESSION);
        String attribute30 = exifInterface3.getAttribute(ExifInterface.TAG_CONTRAST);
        String attribute31 = exifInterface3.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL);
        String attribute32 = exifInterface3.getAttribute(ExifInterface.TAG_DEVICE_SETTING_DESCRIPTION);
        String attribute33 = exifInterface3.getAttribute(ExifInterface.TAG_DIGITAL_ZOOM_RATIO);
        String attribute34 = exifInterface3.getAttribute(ExifInterface.TAG_EXPOSURE_BIAS_VALUE);
        String attribute35 = exifInterface3.getAttribute(ExifInterface.TAG_EXPOSURE_INDEX);
        String attribute36 = exifInterface3.getAttribute(ExifInterface.TAG_EXPOSURE_MODE);
        String attribute37 = exifInterface3.getAttribute(ExifInterface.TAG_EXPOSURE_PROGRAM);
        String attribute38 = exifInterface3.getAttribute(ExifInterface.TAG_FLASH_ENERGY);
        String attribute39 = exifInterface3.getAttribute(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM);
        String attribute40 = exifInterface3.getAttribute(ExifInterface.TAG_FOCAL_PLANE_RESOLUTION_UNIT);
        String attribute41 = exifInterface3.getAttribute(ExifInterface.TAG_FOCAL_PLANE_X_RESOLUTION);
        String attribute42 = exifInterface3.getAttribute(ExifInterface.TAG_FOCAL_PLANE_Y_RESOLUTION);
        String attribute43 = exifInterface3.getAttribute(ExifInterface.TAG_GAIN_CONTROL);
        String attribute44 = exifInterface3.getAttribute(ExifInterface.TAG_GPS_AREA_INFORMATION);
        String attribute45 = exifInterface3.getAttribute(ExifInterface.TAG_GPS_DIFFERENTIAL);
        String attribute46 = exifInterface3.getAttribute(ExifInterface.TAG_GPS_DOP);
        String attribute47 = exifInterface3.getAttribute(ExifInterface.TAG_GPS_MEASURE_MODE);
        String attribute48 = exifInterface3.getAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION);
        String attribute49 = exifInterface3.getAttribute(ExifInterface.TAG_LIGHT_SOURCE);
        String attribute50 = exifInterface3.getAttribute(ExifInterface.TAG_MAKER_NOTE);
        String attribute51 = exifInterface3.getAttribute(ExifInterface.TAG_MAX_APERTURE_VALUE);
        String attribute52 = exifInterface3.getAttribute(ExifInterface.TAG_METERING_MODE);
        String attribute53 = exifInterface3.getAttribute(ExifInterface.TAG_OECF);
        String attribute54 = exifInterface3.getAttribute(ExifInterface.TAG_PHOTOMETRIC_INTERPRETATION);
        String attribute55 = exifInterface3.getAttribute(ExifInterface.TAG_SATURATION);
        String attribute56 = exifInterface3.getAttribute(ExifInterface.TAG_SCENE_CAPTURE_TYPE);
        String attribute57 = exifInterface3.getAttribute(ExifInterface.TAG_SCENE_TYPE);
        String attribute58 = exifInterface3.getAttribute(ExifInterface.TAG_SENSING_METHOD);
        String attribute59 = exifInterface3.getAttribute(ExifInterface.TAG_SHARPNESS);
        String attribute60 = exifInterface3.getAttribute(ExifInterface.TAG_SHUTTER_SPEED_VALUE);
        String attribute61 = exifInterface3.getAttribute(ExifInterface.TAG_SOFTWARE);
        String attribute62 = exifInterface3.getAttribute(ExifInterface.TAG_USER_COMMENT);
        Log.d(TAG, "now write new EXIF data");
        if (attribute != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_F_NUMBER, attribute);
        }
        if (attribute2 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_DATETIME, attribute2);
        }
        if (attribute3 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_EXPOSURE_TIME, attribute3);
        }
        if (attribute4 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_FLASH, attribute4);
        }
        if (attribute5 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_FOCAL_LENGTH, attribute5);
        }
        if (attribute6 != null) {
            exifInterface4.setAttribute(str, attribute6);
        }
        if (str3 != null) {
            exifInterface4.setAttribute(str2, str3);
        }
        if (str5 != null) {
            exifInterface4.setAttribute(str4, str5);
        }
        if (str7 != null) {
            exifInterface4.setAttribute(str6, str7);
        }
        if (str9 != null) {
            exifInterface4.setAttribute(str8, str9);
        }
        if (str11 != null) {
            exifInterface4.setAttribute(str10, str11);
        }
        if (str13 != null) {
            exifInterface4.setAttribute(str12, str13);
        }
        if (str15 != null) {
            exifInterface4.setAttribute(str14, str15);
        }
        if (str17 != null) {
            exifInterface4.setAttribute(str16, str17);
        }
        if (str19 != null) {
            exifInterface4.setAttribute(str18, str19);
        }
        if (str21 != null) {
            exifInterface4.setAttribute(str20, str21);
        }
        if (str23 != null) {
            exifInterface4.setAttribute(str22, str23);
        }
        if (str25 != null) {
            exifInterface4.setAttribute(str24, str25);
        }
        if (str27 != null) {
            exifInterface4.setAttribute(str26, str27);
        }
        if (str29 != null) {
            exifInterface4.setAttribute(str28, str29);
        }
        if (attribute21 != null) {
            exifInterface4.setAttribute(str30, attribute21);
        }
        if (attribute22 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_SUBSEC_TIME_ORIGINAL, attribute22);
        }
        if (attribute23 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_APERTURE_VALUE, attribute23);
        }
        if (attribute24 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_BRIGHTNESS_VALUE, attribute24);
        }
        if (attribute25 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_CFA_PATTERN, attribute25);
        }
        if (attribute26 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_COLOR_SPACE, attribute26);
        }
        if (attribute27 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_COMPONENTS_CONFIGURATION, attribute27);
        }
        if (attribute28 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_COMPRESSED_BITS_PER_PIXEL, attribute28);
        }
        if (attribute29 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_COMPRESSION, attribute29);
        }
        if (attribute30 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_CONTRAST, attribute30);
        }
        if (attribute31 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_DATETIME_ORIGINAL, attribute31);
        }
        if (attribute32 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_DEVICE_SETTING_DESCRIPTION, attribute32);
        }
        if (attribute33 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_DIGITAL_ZOOM_RATIO, attribute33);
        }
        if (attribute34 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_EXPOSURE_BIAS_VALUE, attribute34);
        }
        if (attribute35 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_EXPOSURE_INDEX, attribute35);
        }
        if (attribute36 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_EXPOSURE_MODE, attribute36);
        }
        if (attribute37 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_EXPOSURE_PROGRAM, attribute37);
        }
        if (attribute38 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_FLASH_ENERGY, attribute38);
        }
        if (attribute39 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, attribute39);
        }
        if (attribute40 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_FOCAL_PLANE_RESOLUTION_UNIT, attribute40);
        }
        if (attribute41 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_FOCAL_PLANE_X_RESOLUTION, attribute41);
        }
        if (attribute42 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_FOCAL_PLANE_Y_RESOLUTION, attribute42);
        }
        if (attribute43 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_GAIN_CONTROL, attribute43);
        }
        if (attribute44 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_GPS_AREA_INFORMATION, attribute44);
        }
        if (attribute45 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_GPS_DIFFERENTIAL, attribute45);
        }
        if (attribute46 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_GPS_DOP, attribute46);
        }
        if (attribute47 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_GPS_MEASURE_MODE, attribute47);
        }
        if (attribute48 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION, attribute48);
        }
        if (attribute49 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_LIGHT_SOURCE, attribute49);
        }
        if (attribute50 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_MAKER_NOTE, attribute50);
        }
        if (attribute51 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_MAX_APERTURE_VALUE, attribute51);
        }
        if (attribute52 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_METERING_MODE, attribute52);
        }
        if (attribute53 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_OECF, attribute53);
        }
        if (attribute54 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_PHOTOMETRIC_INTERPRETATION, attribute54);
        }
        if (attribute55 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_SATURATION, attribute55);
        }
        if (attribute56 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_SCENE_CAPTURE_TYPE, attribute56);
        }
        if (attribute57 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_SCENE_TYPE, attribute57);
        }
        if (attribute58 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_SENSING_METHOD, attribute58);
        }
        if (attribute59 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_SHARPNESS, attribute59);
        }
        if (attribute60 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_SHUTTER_SPEED_VALUE, attribute60);
        }
        if (attribute61 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_SOFTWARE, attribute61);
        }
        if (attribute62 != null) {
            exifInterface4.setAttribute(ExifInterface.TAG_USER_COMMENT, attribute62);
        }
        Request request3 = request;
        boolean z = request3.type == Request.Type.JPEG;
        boolean z2 = request3.using_camera2;
        Date date = request3.current_date;
        boolean z3 = request3.store_location;
        boolean z4 = request3.store_geo_direction;
        double d = request3.geo_direction;
        String str31 = request3.custom_tag_artist;
        String str32 = request3.custom_tag_copyright;
        double d2 = request3.level_angle;
        double d3 = request3.pitch_angle;
        boolean z5 = request3.store_ypr;
        boolean z6 = z5;
        ExifInterface exifInterface5 = exifInterface2;
        modifyExif(exifInterface5, z, z2, date, z3, z4, d, str31, str32, d2, d3, z6);
        setDateTimeExif(exifInterface5);
        exifInterface2.saveAttributes();
    }

    /**
     * May be run in saver thread or picture callback thread (depending on whether running in background).
     */
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private boolean saveImageNowRaw(Request request) {
        if (MyDebug.LOG)
            Log.d(TAG, "saveImageNowRaw");

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            if (MyDebug.LOG)
                Log.e(TAG, "RAW requires LOLLIPOP or higher");
            return false;
        }
        StorageUtils storageUtils = main_activity.getStorageUtils();
        boolean success = false;

        main_activity.savingImage(true);

        OutputStream output = null;
        RawImage raw_image = request.raw_image;
        try {
            File picFile = null;
            Uri saveUri = null;
            boolean use_media_store = false;
            ContentValues contentValues = null; // used if using scoped storage

            String suffix = "_";
            String filename_suffix = (request.force_suffix) ? suffix + (request.suffix_offset) : "";
            if (storageUtils.isUsingSAF()) {
                saveUri = storageUtils.createOutputMediaFileSAF(StorageUtils.MEDIA_TYPE_IMAGE, filename_suffix, "dng", request.current_date);
                if (MyDebug.LOG)
                    Log.d(TAG, "saveUri: " + saveUri);
                // When using SAF, we don't save to a temp file first (unlike for JPEGs). Firstly we don't need to modify Exif, so don't
                // need a real file; secondly copying to a temp file is much slower for RAW.
            } else if (CameraActivity.useScopedStorage()) {
                use_media_store = true;
                Uri folder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ?
                        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) :
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                contentValues = new ContentValues();
                String picName = storageUtils.createMediaFilename(StorageUtils.MEDIA_TYPE_IMAGE, filename_suffix, 0, ".dng", request.current_date);
                contentValues.put(MediaStore.Images.Media.DISPLAY_NAME, picName);
                contentValues.put(MediaStore.Images.Media.MIME_TYPE, "image/dng");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    contentValues.put(MediaStore.Images.Media.RELATIVE_PATH, storageUtils.getSaveRelativeFolder());
                    contentValues.put(MediaStore.Images.Media.IS_PENDING, 1);
                }

                saveUri = main_activity.getContentResolver().insert(folder, contentValues);
                if (MyDebug.LOG)
                    Log.d(TAG, "saveUri: " + saveUri);
                if (saveUri == null)
                    throw new IOException();
            } else {
                picFile = storageUtils.createOutputMediaFile(StorageUtils.MEDIA_TYPE_IMAGE, filename_suffix, "dng", request.current_date);
                if (MyDebug.LOG)
                    Log.d(TAG, "save to: " + picFile.getAbsolutePath());
            }

            if (picFile != null) {
                output = new FileOutputStream(picFile);
            } else {
                output = main_activity.getContentResolver().openOutputStream(saveUri);
            }
            raw_image.writeImage(output);
            raw_image.close();
            raw_image = null;
            output.close();
            output = null;
            success = true;

            // set last image for share/trash options for pause preview
            // Must be done before broadcastFile() (because on Android 7+ with non-SAF, we update
            // the LastImage's uri from the MediaScannerConnection.scanFile() callback from
            // StorageUtils.broadcastFile(), which assumes the last image has already been set.
            MyApplicationInterface applicationInterface = main_activity.getApplicationInterface();
            boolean raw_only = applicationInterface.isRawOnly();
            if (MyDebug.LOG)
                Log.d(TAG, "raw_only: " + raw_only);
            if (saveUri == null) {
                applicationInterface.addLastImage(picFile, raw_only);
            } else if (storageUtils.isUsingSAF()) {
                applicationInterface.addLastImageSAF(saveUri, raw_only);
            } else if (success && use_media_store) {
                applicationInterface.addLastImageMediaStore(saveUri, raw_only);
            }

            if (saveUri == null) {
                storageUtils.broadcastFile(picFile, true, false, false);
            } else if (use_media_store) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    contentValues.clear();
                    contentValues.put(MediaStore.Images.Media.IS_PENDING, 0);
                    main_activity.getContentResolver().update(saveUri, contentValues, null, null);
                }

                // no need to broadcast when using mediastore method

                // in theory this is pointless, as announceUri no longer does anything on Android 7+,
                // and mediastore method is only used on Android 10+, but keep this just in case
                // announceUri does something in future
                storageUtils.announceUri(saveUri, true, false);
            } else {
                storageUtils.broadcastUri(saveUri, true, false, false, false);
            }
        } catch (FileNotFoundException e) {
            if (MyDebug.LOG)
                Log.e(TAG, "File not found: " + e.getMessage());
            e.printStackTrace();
            main_activity.getPreview().showToast(null, R.string.failed_to_save_photo_raw);
        } catch (IOException e) {
            if (MyDebug.LOG)
                Log.e(TAG, "ioexception writing raw image file");
            e.printStackTrace();
            main_activity.getPreview().showToast(null, R.string.failed_to_save_photo_raw);
        } finally {
            if (output != null) {
                try {
                    output.close();
                } catch (IOException e) {
                    if (MyDebug.LOG)
                        Log.e(TAG, "ioexception closing raw output");
                    e.printStackTrace();
                }
            }
            if (raw_image != null) {
                raw_image.close();
            }
        }

        System.gc();

        main_activity.savingImage(false);

        return success;
    }

    public int getScreenOrientation() {
        Display getOrient = main_activity.getWindowManager().getDefaultDisplay();
        int orientation = Configuration.ORIENTATION_UNDEFINED;
        if (getOrient.getWidth() == getOrient.getHeight()) {
            orientation = Configuration.ORIENTATION_SQUARE;
        } else {
            if (getOrient.getWidth() < getOrient.getHeight()) {
                orientation = Configuration.ORIENTATION_PORTRAIT;
            } else {
                orientation = Configuration.ORIENTATION_LANDSCAPE;
            }
        }
        return orientation;
    }

    /**
     * Rotates the supplied bitmap according to the orientation tag stored in the exif data. If no
     * rotation is required, the input bitmap is returned. If rotation is required, the input
     * bitmap is recycled.
     *
     * @param data Jpeg data containing the Exif information to use.
     */
    private Bitmap rotateForExif(Bitmap bitmap, byte[] data) {
        if (MyDebug.LOG)
            Log.d(TAG, "rotateForExif");
        InputStream inputStream = null;
        try {
            ExifInterface exif;

            if (MyDebug.LOG)
                Log.d(TAG, "use data stream to read exif tags");
            inputStream = new ByteArrayInputStream(data);
            exif = new ExifInterface(inputStream);

            int exif_orientation_s = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);
            if (MyDebug.LOG)
                Log.d(TAG, "    exif orientation string: " + exif_orientation_s);
            boolean needs_tf = false;
            int exif_orientation = 0;
            // see http://jpegclub.org/exif_orientation.html
            // and http://stackoverflow.com/questions/20478765/how-to-get-the-correct-orientation-of-the-image-selected-from-the-default-image


            switch (main_activity.preview.getCameraControllerManager().getFacing(main_activity.preview.getCameraId())) {
                case FACING_FRONT:

                    switch (exif_orientation_s) {
                        case ExifInterface.ORIENTATION_UNDEFINED:
                            needs_tf = false;
                            break;
                        case ExifInterface.ORIENTATION_NORMAL:
                            // leave unchanged
                            needs_tf = true;
                            exif_orientation = 0;
                            break;
                        case ExifInterface.ORIENTATION_ROTATE_180:
                            needs_tf = true;
                            exif_orientation = 180;
                            break;
                        case ExifInterface.ORIENTATION_ROTATE_90:
                            needs_tf = true;
                            exif_orientation = 90;
                            break;
                        case ExifInterface.ORIENTATION_ROTATE_270:
                            needs_tf = true;
                            exif_orientation = 270;
                            break;
                        default:
                            // just leave unchanged for now
                            if (MyDebug.LOG)
                                Log.e(TAG, "    unsupported exif orientation: " + exif_orientation_s);
                            break;
                    }

                    break;
                case FACING_BACK:
                    switch (exif_orientation_s) {
                        case ExifInterface.ORIENTATION_UNDEFINED:
                            needs_tf = true;
//                    exif.setAttribute(ExifInterface.TAG_ORIENTATION, main_activity.getCameraCurrentOrientation() + "");

                            if (main_activity.getCameraCurrentOrientation() == 90) {
                                exif_orientation = 270;
                            } else if (main_activity.getCameraCurrentOrientation() == 180) {
                                exif_orientation = 180;
                            } else if (main_activity.getCameraCurrentOrientation() == 270) {
                                exif_orientation = 90;
                            } else if (main_activity.getCameraCurrentOrientation() == 0) {
                                exif_orientation = 0;
                            }

                            customOrientation = exif_orientation;

                            Log.e(TAG, "rotateForExif: " + main_activity.getCameraCurrentOrientation());

                            break;
                        case ExifInterface.ORIENTATION_NORMAL:
                            // leave unchanged
                            needs_tf = true;
                            exif_orientation = 90;
                            break;
                        case ExifInterface.ORIENTATION_ROTATE_180:
                            needs_tf = true;
//                    exif_orientation = 180;
                            exif_orientation = 90;
                            break;
                        case ExifInterface.ORIENTATION_ROTATE_90:
                            needs_tf = true;
//                    exif_orientation = 90;
                            exif_orientation = 90;
                            break;
                        case ExifInterface.ORIENTATION_ROTATE_270:
                            needs_tf = true;
//                    exif_orientation = 270;
                            exif_orientation = 90;
                            break;
                        default:
                            // just leave unchanged for now
                            if (MyDebug.LOG)
                                Log.e(TAG, "    unsupported exif orientation: " + exif_orientation_s);
                            break;
                    }
                    break;
            }

            if (MyDebug.LOG)
                Log.d(TAG, "    exif orientation: " + exif_orientation);

            if (needs_tf) {
                if (MyDebug.LOG)
                    Log.d(TAG, "    need to rotate bitmap due to exif orientation tag");
                Matrix m = new Matrix();
                m.setRotate(exif_orientation, bitmap.getWidth() * 0.5f, bitmap.getHeight() * 0.5f);
                Bitmap rotated_bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), m, true);
                if (rotated_bitmap != bitmap) {
                    bitmap.recycle();
                    bitmap = rotated_bitmap;
                }
            }
        } catch (IOException exception) {
            if (MyDebug.LOG)
                Log.e(TAG, "exif orientation ioexception");
            exception.printStackTrace();
        } catch (NoClassDefFoundError exception) {
            // have had Google Play crashes from new ExifInterface() for Galaxy Ace4 (vivalto3g), Galaxy S Duos3 (vivalto3gvn)
            if (MyDebug.LOG)
                Log.e(TAG, "exif orientation NoClassDefFoundError");
            exception.printStackTrace();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return bitmap;
    }

    private Bitmap rotateExifStamp(Bitmap bitmap, byte[] data) {
        if (MyDebug.LOG)
            Log.d(TAG, "rotateForExif");
        InputStream inputStream = null;
        try {
            ExifInterface exif;

            if (MyDebug.LOG)
                Log.d(TAG, "use data stream to read exif tags");
            inputStream = new ByteArrayInputStream(data);
            exif = new ExifInterface(inputStream);

            int exif_orientation_s = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);
            if (MyDebug.LOG)
                Log.d(TAG, "    exif orientation string: " + exif_orientation_s);
            boolean needs_tf = false;
            int exif_orientation = 0;
            // see http://jpegclub.org/exif_orientation.html
            // and http://stackoverflow.com/questions/20478765/how-to-get-the-correct-orientation-of-the-image-selected-from-the-default-image


            switch (main_activity.preview.getCameraControllerManager().getFacing(main_activity.preview.getCameraId())) {
                case FACING_FRONT:
                    switch (exif_orientation_s) {
                        case ExifInterface.ORIENTATION_UNDEFINED:
                            needs_tf = false;
                            break;
                        case ExifInterface.ORIENTATION_NORMAL:
                            // leave unchanged
                            needs_tf = true;
                            exif_orientation = 270;
                            break;
                        case ExifInterface.ORIENTATION_ROTATE_180:
                            needs_tf = true;
                            exif_orientation = 180;
                            break;
                        case ExifInterface.ORIENTATION_ROTATE_90:
                            needs_tf = true;
                            exif_orientation = 90;
                            break;
                        case ExifInterface.ORIENTATION_ROTATE_270:
                            needs_tf = true;
                            exif_orientation = 0;
                            break;
                        default:
                            // just leave unchanged for now
                            if (MyDebug.LOG)
                                Log.e(TAG, "    unsupported exif orientation: " + exif_orientation_s);
                            break;
                    }

                    break;
                case FACING_BACK:
                    needs_tf = false;
                    break;
            }

            if (MyDebug.LOG)
                Log.d(TAG, "    exif orientation: " + exif_orientation);

            if (needs_tf) {
                if (MyDebug.LOG)
                    Log.d(TAG, "    need to rotate bitmap due to exif orientation tag");
                Matrix m = new Matrix();
                m.setRotate(exif_orientation, bitmap.getWidth() * 0.5f, bitmap.getHeight() * 0.5f);
                Bitmap rotated_bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), m, true);
                if (rotated_bitmap != bitmap) {
                    bitmap.recycle();
                    bitmap = rotated_bitmap;
                }
            }
        } catch (IOException exception) {
            if (MyDebug.LOG)
                Log.e(TAG, "exif orientation ioexception");
            exception.printStackTrace();
        } catch (NoClassDefFoundError exception) {
            // have had Google Play crashes from new ExifInterface() for Galaxy Ace4 (vivalto3g), Galaxy S Duos3 (vivalto3gvn)
            if (MyDebug.LOG)
                Log.e(TAG, "exif orientation NoClassDefFoundError");
            exception.printStackTrace();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return bitmap;
    }

    private Bitmap rotateForExifStamp(Bitmap bitmap, byte[] data) {
        if (MyDebug.LOG)
            Log.d(TAG, "rotateForExif");
        InputStream inputStream = null;
        try {
            ExifInterface exif;

            if (MyDebug.LOG)
                Log.d(TAG, "use data stream to read exif tags");
            inputStream = new ByteArrayInputStream(data);
            exif = new ExifInterface(inputStream);

            int exif_orientation_s = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);
            if (MyDebug.LOG)
                Log.d(TAG, "    exif orientation string: " + exif_orientation_s);
            boolean needs_tf = false;
            int exif_orientation = 0;
            // see http://jpegclub.org/exif_orientation.html
            // and http://stackoverflow.com/questions/20478765/how-to-get-the-correct-orientation-of-the-image-selected-from-the-default-image

            if (MyDebug.LOG)
                Log.d(TAG, "    exif orientation: " + exif_orientation);

            switch (main_activity.preview.getCameraControllerManager().getFacing(main_activity.preview.getCameraId())) {
                case FACING_FRONT:
                    needs_tf = false;
                    break;
                case FACING_BACK:
                    switch (exif_orientation_s) {
                        case ExifInterface.ORIENTATION_UNDEFINED:
                            needs_tf = true;

                            // exif_orientation = 90;

                            if (customOrientation == 0) {
                                exif_orientation = 0;
                            } else if (customOrientation == 90) {
                                exif_orientation = 270;
                            } else if (customOrientation == 180) {
                                exif_orientation = 180;
                            } else if (customOrientation == 270) {
                                exif_orientation = 90;
                            }

                            customOrientation = 0;

                            break;
                        case ExifInterface.ORIENTATION_NORMAL:
                            // leave unchanged
                            needs_tf = true;
                            exif_orientation = 270;
                            break;
                        case ExifInterface.ORIENTATION_ROTATE_180:
                            needs_tf = true;
//                    exif_orientation = 180;
                            exif_orientation = 90;
                            break;
                        case ExifInterface.ORIENTATION_ROTATE_90:
                            needs_tf = true;
//                    exif_orientation = 90;
                            exif_orientation = 0;
                            break;
                        case ExifInterface.ORIENTATION_ROTATE_270:
                            needs_tf = true;
//                    exif_orientation = 270;
                            exif_orientation = 180;
                            break;
                        default:
                            // just leave unchanged for now
                            if (MyDebug.LOG)
                                Log.e(TAG, "    unsupported exif orientation: " + exif_orientation_s);
                            break;
                    }
                    break;
            }

            if (needs_tf) {
                if (MyDebug.LOG)
                    Log.d(TAG, "    need to rotate bitmap due to exif orientation tag");
                Matrix m = new Matrix();
                m.setRotate(exif_orientation, bitmap.getWidth() * 0.5f, bitmap.getHeight() * 0.5f);
                Bitmap rotated_bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), m, true);
                if (rotated_bitmap != bitmap) {
                    bitmap.recycle();
                    bitmap = rotated_bitmap;
                }
            }
        } catch (IOException exception) {
            if (MyDebug.LOG)
                Log.e(TAG, "exif orientation ioexception");
            exception.printStackTrace();
        } catch (NoClassDefFoundError exception) {
            // have had Google Play crashes from new ExifInterface() for Galaxy Ace4 (vivalto3g), Galaxy S Duos3 (vivalto3gvn)
            if (MyDebug.LOG)
                Log.e(TAG, "exif orientation NoClassDefFoundError");
            exception.printStackTrace();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return bitmap;
    }


    private Bitmap loadBitmapWithRotation(byte[] bArr, boolean z) {
        Bitmap loadBitmap = loadBitmap(bArr, z, 1);
        if (loadBitmap == null) {
            return loadBitmap;
        }
        Log.d(TAG, "rotate bitmap for exif tags?");
        return rotateForExif(loadBitmap, bArr);
//        return loadBitmap;
    }

    private static class ExifInterfaceHolder {
        private final ExifInterface exif;
        private final ParcelFileDescriptor pfd;

        ExifInterfaceHolder(ParcelFileDescriptor parcelFileDescriptor, ExifInterface exifInterface) {
            this.pfd = parcelFileDescriptor;
            this.exif = exifInterface;
        }

        /* access modifiers changed from: package-private */
        public ExifInterface getExif() {
            return this.exif;
        }

        /* access modifiers changed from: package-private */
        public void close() {
            ParcelFileDescriptor parcelFileDescriptor = this.pfd;
            if (parcelFileDescriptor != null) {
                try {
                    parcelFileDescriptor.close();
                } catch (IOException e) {
                    Log.e(ImageSaver.TAG, "failed to close parcelfiledescriptor");
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Creates a new exif interface for reading and writing.
     * If picFile==null, then saveUri must be non-null, and will be used instead to write the exif
     * tags too.
     * The returned ExifInterfaceHolder will always be non-null, but the contained getExif() may
     * return null if this method was unable to create the exif interface.
     * The caller should call close() on the returned ExifInterfaceHolder when no longer required.
     */
    private ExifInterfaceHolder createExifInterface(File picFile, Uri saveUri) throws IOException {
        ParcelFileDescriptor parcelFileDescriptor = null;
        ExifInterface exif = null;
        if (picFile != null) {
            if (MyDebug.LOG)
                Log.d(TAG, "write to picFile: " + picFile);
            exif = new ExifInterface(picFile.getAbsolutePath());
        } else {
            if (MyDebug.LOG)
                Log.d(TAG, "write direct to saveUri: " + saveUri);
            parcelFileDescriptor = main_activity.getContentResolver().openFileDescriptor(saveUri, "rw");
            if (parcelFileDescriptor != null) {
                FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
                exif = new ExifInterface(fileDescriptor);
            } else {
                Log.e(TAG, "failed to create ParcelFileDescriptor for saveUri: " + saveUri);
            }
        }
        return new ExifInterfaceHolder(parcelFileDescriptor, exif);
    }

    private void updateExif(Request request, File file, Uri uri) throws IOException {
        String str;
        String str2;
        String str3;
        String str4;
        ExifInterfaceHolder createExifInterface;
        Request request2 = request;
        File file2 = file;
        Uri uri2 = uri;
        Log.d(TAG, "updateExif: " + file2);
        boolean z = true;
        if (request2.store_geo_direction || request2.store_ypr || hasCustomExif(request2.custom_tag_artist, request2.custom_tag_copyright)) {
            long currentTimeMillis = System.currentTimeMillis();
            Log.d(TAG, "add additional exif info");
            try {
                ExifInterfaceHolder createExifInterface2 = createExifInterface(file2, uri2);
                try {
                    ExifInterface exif = createExifInterface2.getExif();
                    if (exif != null) {
                        boolean z2 = request2.type == Request.Type.JPEG;
                        boolean z3 = request2.using_camera2;
                        Date date = request2.current_date;
                        boolean z4 = request2.store_location;
                        boolean z5 = request2.store_geo_direction;
                        double d = request2.geo_direction;
                        String str5 = request2.custom_tag_artist;
                        String str6 = request2.custom_tag_copyright;
                        double d2 = request2.level_angle;
                        String str7 = TAG;
                        try {
                            str4 = "exif orientation NoClassDefFoundError";
                            str3 = str7;
                            try {
                                modifyExif(exif, z2, z3, date, z4, z5, d, str5, str6, d2, request2.pitch_angle, request2.store_ypr);
                                exif.saveAttributes();
                            } catch (Exception e) {

                            }
                        } catch (Throwable th2) {
                            Object obj = "exif orientation NoClassDefFoundError";
                            String str8 = str7;
                            createExifInterface2.close();
                            throw th2;
                        }
                    } else {
                        str4 = "exif orientation NoClassDefFoundError";
                        str3 = TAG;
                    }
                } catch (Throwable th) {
                    Object obj2 = "exif orientation NoClassDefFoundError";
                    Object obj3 = TAG;
                    createExifInterface2.close();
                    throw th;
                }
                try {
                    createExifInterface2.close();
                    str = str3;
                } catch (NoClassDefFoundError e) {
                    e = e;
                    str2 = str4;
                    str = str3;
                    Log.e(str, str2);
                    e.printStackTrace();
                    Log.d(str, "*** time to add additional exif info: " + (System.currentTimeMillis() - currentTimeMillis));
                    return;
                }
            } catch (NoClassDefFoundError e) {
                str2 = "exif orientation NoClassDefFoundError";
                str = TAG;
                Log.e(str, str2);
                e.printStackTrace();
                Log.d(str, "*** time to add additional exif info: " + (System.currentTimeMillis() - currentTimeMillis));
                return;
            }
            Log.d(str, "*** time to add additional exif info: " + (System.currentTimeMillis() - currentTimeMillis));
            return;
        }
        if (request2.type != Request.Type.JPEG) {
            z = false;
        }
        if (needGPSTimestampHack(z, request2.using_camera2, request2.store_location)) {
            Log.d(TAG, "remove GPS timestamp hack");
            try {
                createExifInterface = createExifInterface(file2, uri2);
                ExifInterface exif2 = createExifInterface.getExif();
                if (exif2 != null) {
                    fixGPSTimestamp(exif2, request2.current_date);
                    exif2.saveAttributes();
                }
                createExifInterface.close();
            } catch (NoClassDefFoundError e3) {
                Log.e(TAG, "exif orientation NoClassDefFoundError");
                e3.printStackTrace();
            }
        } else {
            Log.d(TAG, "no exif data to update for: " + file2);
        }
    }

    private void modifyExif(ExifInterface exifInterface, boolean z, boolean z2, Date date, boolean z3, boolean z4, double d, String str, String str2, double d2, double d3, boolean z5) {
        ExifInterface exifInterface2 = exifInterface;
        Log.d(TAG, "modifyExif");
        boolean z6 = z4;
        double d4 = d;
        setGPSDirectionExif(exifInterface, z4, d);
        if (z5) {
            float degrees = (float) Math.toDegrees(d);
            if (degrees < 0.0f) {
                degrees += 360.0f;
            }
            exifInterface.setAttribute(ExifInterface.TAG_USER_COMMENT, "ASCII\u0000\u0000\u0000" + "Yaw:" + degrees + ",Pitch:" + d3 + ",Roll:" + d2);
            StringBuilder sb = new StringBuilder();
            sb.append("UserComment: ");
            sb.append(exifInterface.getAttribute(ExifInterface.TAG_USER_COMMENT));
            Log.d(TAG, sb.toString());
        }
        setCustomExif(exifInterface, str, str2);
        boolean z7 = z;
        boolean z8 = z2;
        boolean z9 = z3;
        if (needGPSTimestampHack(z, z2, z3)) {
            Date date2 = date;
            fixGPSTimestamp(exifInterface, date);
        }
    }

    private void setGPSDirectionExif(ExifInterface exifInterface, boolean z, double d) {
        Log.d(TAG, "setGPSDirectionExif");
        if (z) {
            float degrees = (float) Math.toDegrees(d);
            if (degrees < 0.0f) {
                degrees += 360.0f;
            }
            Log.d(TAG, "save geo_angle: " + degrees);
            String str = Math.round(degrees * 100.0f) + "/100";
            Log.d(TAG, "GPSImgDirection_string: " + str);
            exifInterface.setAttribute(ExifInterface.TAG_GPS_IMG_DIRECTION, str);
            exifInterface.setAttribute(ExifInterface.TAG_GPS_IMG_DIRECTION_REF, "M");
        }
    }

    private boolean hasCustomExif(String str, String str2) {
        if (str != null && str.length() > 0) {
            return true;
        }
        if (str2 == null || str2.length() <= 0) {
            return false;
        }
        return true;
    }

    private void setCustomExif(ExifInterface exifInterface, String str, String str2) {
        Log.d(TAG, "setCustomExif");
        if (str != null && str.length() > 0) {
            Log.d(TAG, "apply TAG_ARTIST: " + str);
            exifInterface.setAttribute(ExifInterface.TAG_ARTIST, str);
        }
        if (str2 != null && str2.length() > 0) {
            exifInterface.setAttribute(ExifInterface.TAG_COPYRIGHT, str2);
            Log.d(TAG, "apply TAG_COPYRIGHT: " + str2);
        }
    }

    private void setDateTimeExif(ExifInterface exifInterface) {
        Log.d(TAG, "setDateTimeExif");
        String attribute = exifInterface.getAttribute(ExifInterface.TAG_DATETIME);
        if (attribute != null) {
            Log.d(TAG, "write datetime tags: " + attribute);
            exifInterface.setAttribute(ExifInterface.TAG_DATETIME_ORIGINAL, attribute);
            exifInterface.setAttribute(ExifInterface.TAG_DATETIME_DIGITIZED, attribute);
        }
    }

    private void fixGPSTimestamp(ExifInterface exifInterface, Date date) {
        Log.d(TAG, "fixGPSTimestamp");
        Log.d(TAG, "current datestamp: " + exifInterface.getAttribute(ExifInterface.TAG_GPS_DATESTAMP));
        Log.d(TAG, "current timestamp: " + exifInterface.getAttribute(ExifInterface.TAG_GPS_TIMESTAMP));
        Log.d(TAG, "current datetime: " + exifInterface.getAttribute(ExifInterface.TAG_DATETIME));
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy:MM:dd", Locale.US);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        String format = simpleDateFormat.format(date);
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("HH:mm:ss", Locale.US);
        simpleDateFormat2.setTimeZone(TimeZone.getTimeZone("UTC"));
        String format2 = simpleDateFormat2.format(date);
        Log.d(TAG, "datestamp: " + format);
        Log.d(TAG, "timestamp: " + format2);
        exifInterface.setAttribute(ExifInterface.TAG_GPS_DATESTAMP, format);
        exifInterface.setAttribute(ExifInterface.TAG_GPS_TIMESTAMP, format2);
        Log.d(TAG, "fixGPSTimestamp exit");
    }

    /* access modifiers changed from: package-private */
    public HDRProcessor getHDRProcessor() {
        return this.hdrProcessor;
    }

    public PanoramaProcessor getPanoramaProcessor() {
        return this.panoramaProcessor;
    }
}
