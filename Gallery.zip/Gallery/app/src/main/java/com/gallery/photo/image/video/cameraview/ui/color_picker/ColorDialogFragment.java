package com.gallery.photo.image.video.cameraview.ui.color_picker;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.GridLayout;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;


import com.gallery.photo.image.video.R;

import java.util.ArrayList;
import java.util.List;


public class ColorDialogFragment extends DialogFragment {
    private static final String TAG = "ColorDialogFragment";
    public static final String TRANSPARENT = "#00000000";
    public static final String[] googleColors = {"#F44336", "#E91E63", "#9C27B0", "#673AB7", "#3F51B5", "#2196F3", "#03A9F4", "#00BCD4", "#009688", "#4CAF50", "#8BC34A", "#CDDC39", "#FFEB3B", "#FFC107", "#FF9800", "#FF5722", "#795548", "#9E9E9E", "#607D8B", "#D6CEC3", "#2962ff", "#ffffff"};
    private final List<Integer> colorList = hexToIntList(googleColors);
    private View dialogView;
    private ColorDialog.OnResultListener onResultListener;

    public SelectedColor selectedColor;


    public class SelectedColor {
        public Integer colorInt;
        public View colorView;

        public SelectedColor(Integer num, View view) {
            this.colorInt = num;
            this.colorView = view;
        }
    }

    public void setOnResultListener(ColorDialog.OnResultListener onResultListener2) {
        this.onResultListener = onResultListener2;
    }

    public static int getRandomColor() {
        List<Integer> hexToIntList = hexToIntList(googleColors);
        return hexToIntList.get((int) (((double) (hexToIntList.size() - 1)) * Math.random())).intValue();
    }

    private static List<Integer> hexToIntList(String[] strArr) {
        ArrayList arrayList = new ArrayList();
        for (String parseColor : strArr) {
            arrayList.add(Integer.valueOf(Color.parseColor(parseColor)));
        }
        return arrayList;
    }

    @NonNull
    public Dialog onCreateDialog(Bundle bundle) {
        this.dialogView = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_color_picker, (ViewGroup) null);
        this.dialogView = setupView(this.dialogView);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(this.dialogView);
        return builder.create();
    }

    private View setupView(View view) {
        view.findViewById(R.id.cancelButton).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ColorDialogFragment.this.cancel();
            }
        });
        GridLayout gridLayout = (GridLayout) view.findViewById(R.id.gridView);
        gridLayout.setColumnCount(4);
        fillGridView(gridLayout);
        return view;
    }

    private void fillGridView(GridLayout gridLayout) {
        LayoutInflater from = LayoutInflater.from(getActivity());
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 < this.colorList.size()) {
                final int intValue = this.colorList.get(i2).intValue();
                final View inflate = from.inflate(R.layout.dialog_color_picker_list_item, (ViewGroup) null);
                View findViewById = inflate.findViewById(R.id.colorBubbleView);
                Drawable drawable = getActivity().getResources().getDrawable(R.drawable.shape_rounded);
                drawable.setColorFilter(intValue, PorterDuff.Mode.SRC_ATOP);
                if (Build.VERSION.SDK_INT >= 16) {
                    findViewById.setBackground(drawable);
                } else {
                    findViewById.setBackgroundDrawable(drawable);
                }
                inflate.setOnTouchListener((view, motionEvent) -> {
                    if (motionEvent.getAction() == 0) {
                        ColorDialogFragment.this.animateColorPop(intValue, inflate);
                        return false;
                    } else if (1 != motionEvent.getAction()) {
                        return false;
                    } else {
                        if (ColorDialogFragment.this.selectedColor.colorInt != null && ColorDialogFragment.this.selectedColor.colorInt.intValue() == intValue) {
                            return false;
                        }
                        ColorDialogFragment.this.animateColorPopout(inflate);
                        return false;
                    }
                });
                inflate.setOnClickListener(view -> {
                    Log.d(ColorDialogFragment.TAG, "onClick: " + intValue);
                    if (Build.VERSION.SDK_INT >= 21) {
                        view.setZ(999.0f);
                    }
                    view.animate().scaleX(1.7f).scaleY(1.7f).start();
                    ColorDialogFragment.this.onColorPicked(intValue);
                });
                if (this.selectedColor != null && this.selectedColor.colorInt.intValue() == intValue) {
                    animateColorPop(intValue, inflate);
                }
                gridLayout.addView(inflate);
                i = i2 + 1;
            } else {
                return;
            }
        }
    }


    public void cancel() {
        if (this.onResultListener != null) {
            this.onResultListener.onCancel();
        }
        dismiss();
    }


    public void onColorPicked(int i) {
        if (this.onResultListener != null) {
            this.onResultListener.onColorPicked(i);
        }
        betterDismiss();
    }

    public void betterDismiss() {
        new ValueAnimator();
        ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{1.0f, 0.0f});
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                ColorDialogFragment.this.setViewAlpha(((Float) valueAnimator.getAnimatedValue()).floatValue());
                if (valueAnimator.getAnimatedFraction() >= 0.3f) {
                    ColorDialogFragment.this.dismiss();
                }
            }
        });
        ofFloat.setDuration(250);
        ofFloat.setInterpolator(new AccelerateInterpolator());
        ofFloat.start();
    }


    public void animateColorPop(int i, final View view) {
        view.animate().scaleX(1.6f).scaleY(1.6f).setInterpolator(new OvershootInterpolator()).start();
        if (Build.VERSION.SDK_INT >= 21) {
            new ValueAnimator();
            ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{view.getElevation(), 32.0f});
            ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @SuppressLint({"NewApi"})
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    view.setElevation(((Float) valueAnimator.getAnimatedValue()).floatValue());
                }
            });
            ofFloat.setInterpolator(new OvershootInterpolator());
            ofFloat.start();
        }
        if (this.selectedColor != null && this.selectedColor.colorView != null && this.selectedColor.colorInt.intValue() != i) {
            animateColorPopout(this.selectedColor.colorView);
        }
    }


    public void animateColorPopout(final View view) {
        view.animate().scaleX(1.0f).scaleY(1.0f).setInterpolator(new OvershootInterpolator()).start();
        if (Build.VERSION.SDK_INT >= 21) {
            new ValueAnimator();
            ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{view.getElevation(), 2.0f});
            ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @SuppressLint({"NewApi"})
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    view.setElevation(((Float) valueAnimator.getAnimatedValue()).floatValue());
                }
            });
            ofFloat.setInterpolator(new OvershootInterpolator());
            ofFloat.start();
        }
    }


    public void setViewAlpha(float f) {
        if (getDialog() != null) {
            getDialog().getWindow().getDecorView().setAlpha(f);
        }
    }

    private void setDimAmount(float f) {
        if (getDialog() != null) {
            WindowManager.LayoutParams attributes = getDialog().getWindow().getAttributes();
            attributes.dimAmount = f;
            getDialog().getWindow().setAttributes(attributes);
        }
    }

    public void setSelectedColorInt(int i) {
        this.selectedColor = new SelectedColor(Integer.valueOf(i), (View) null);
    }
}
