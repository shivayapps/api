package com.video.aimagic.utils

import android.content.Context
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import com.video.aimagic.aivideos.EffectAdapter
import com.video.aimagic.aivideos.EffectModel

object AIVideoDataLoder {

    fun loadAndSetEffects(context: Context, recyclerView: RecyclerView, rawResourceId: Int, adapterClickListener: (EffectModel) -> Unit) {
        val jsonString = JSONLoder.loadJSONFromRaw(context, rawResourceId)
        jsonString?.let {
            val effectsList = parseDynamicEffectJson(it)

            val adapter = EffectAdapter(effectsList, context, adapterClickListener)
            recyclerView.adapter = adapter
        }
    }

    private fun parseDynamicEffectJson(jsonStr: String): List<EffectModel> {
        val gson = Gson()
        val root = gson.fromJson(jsonStr, JsonObject::class.java)
        val effectsObject = root.entrySet().first().value.asJsonObject
        val effectsMap = gson.fromJson<Map<String, EffectModel>>(
            effectsObject,
            object : TypeToken<Map<String, EffectModel>>() {}.type
        )
        return effectsMap.values.toList()
    }
}