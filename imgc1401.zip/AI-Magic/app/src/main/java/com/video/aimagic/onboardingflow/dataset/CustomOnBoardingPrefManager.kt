package com.video.aimagic.onboardingflow.dataset

import android.content.Context
import android.content.SharedPreferences

class CustomOnBoardingPrefManager (appContext: Context) {

    private val sharedPreferences: SharedPreferences
    private val preferencesEditor: SharedPreferences.Editor

    var initialAppLaunch: Boolean
        get() = sharedPreferences.getBoolean(FIRST_LAUNCH_KEY, true)
        set(isInitialLaunch) {
            preferencesEditor.putBoolean(FIRST_LAUNCH_KEY, isInitialLaunch)
            preferencesEditor.apply()
        }

    var userProceededAction: Boolean
        get() = sharedPreferences.getBoolean(USER_PROCEEDED_KEY, false)
        set(hasProceeded) {
            preferencesEditor.putBoolean(USER_PROCEEDED_KEY, hasProceeded)
            preferencesEditor.apply()
        }

    init {
        sharedPreferences = appContext.getSharedPreferences(
            ONBOARDING_PREFERENCES,
            Context.MODE_PRIVATE
        )
        preferencesEditor = sharedPreferences.edit()
    }

    companion object {
        private const val ONBOARDING_PREFERENCES = "ImagicOnboardingPrefs"
        private const val FIRST_LAUNCH_KEY = "isInitialAppStart"
        private const val USER_PROCEEDED_KEY = "userCompletedAction"
    }
}