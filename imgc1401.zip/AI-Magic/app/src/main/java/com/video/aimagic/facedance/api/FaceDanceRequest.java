package com.video.aimagic.facedance.api;

import static android.content.ContentValues.TAG;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.adconfig.adsutil.utils.SmUtils;
import com.video.aimagic.R;
import com.video.aimagic.callback.ApiCallback;
import com.video.aimagic.callback.ResponseCallBack;
import com.video.aimagic.commonscreen.screen.CommonResultScreen;
import com.video.aimagic.facedance.UploadRequest;
import com.video.aimagic.singletone.CustomDialogManager;
import com.video.aimagic.singletone.PhotoUploadManager;
import com.video.aimagic.utils.appconfig.AppConfig;
import com.video.aimagic.utils.appconfig.StartActivityGlobally;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.List;

import kotlin.Pair;

public class FaceDanceRequest {
    private final String TAG = "FaceDanceRequest";

    private static FaceDanceRequest instance;
    private Activity context;
    private ResponseCallBack responseCallBack;

    // Private constructor to prevent instantiation
    private FaceDanceRequest(Activity context,ResponseCallBack responseCallBack) {
//        this.context = context.getApplicationContext();
        this.context = context;
        this.responseCallBack = responseCallBack;
    }

    public static synchronized FaceDanceRequest getInstance(Activity context, ResponseCallBack responseCallBack) {
        if (instance == null) {
            instance = new FaceDanceRequest(context,responseCallBack);
        }
        return instance;
    }


    public static String extractFolder(String url) {
        try {
            Uri uri = Uri.parse(url);
            List<String> segments = uri.getPathSegments();

            // Example segments:
            // [iMagic_FaceDance_videos, iMagicFaceDance4.webp]

            if (segments != null && segments.size() >= 2) {
                return segments.get(segments.size() - 2);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String extractMp4FileName(String url) {
        try {
            Uri uri = Uri.parse(url);
            String lastSegment = uri.getLastPathSegment();

            if (lastSegment != null && lastSegment.contains(".")) {
                return lastSegment.substring(0, lastSegment.lastIndexOf(".")) + ".mp4";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public static String buildMp4Url(String webpUrl) {
        final String MP4_BASE = "https://facedance.fra1.cdn.digitaloceanspaces.com/Mp4/";

        String folder = extractFolder(webpUrl);
        String fileName = extractMp4FileName(webpUrl);

        if (folder == null || fileName == null) return null;

        return MP4_BASE + folder + "/" + fileName;
    }

    public void makeRequest() {
        if (context == null) {
            System.out.println("Error: Context is null");
            return;
        }


        Log.d("mg_facedance", "SELECTED_FACE_SWAP_URL:" + AppConfig.SELECTED_FACE_SWAP_URL);
        String selectedUrl=AppConfig.SELECTED_FACE_SWAP_URL;
        String folderName=extractFolder(selectedUrl);
        String fileName=extractMp4FileName(selectedUrl);
        String mp4Url=buildMp4Url(selectedUrl);

        Log.d("mg_facedance", "folderName:" + folderName);
        Log.d("mg_facedance", "fileName:" + fileName);
        Log.d("mg_facedance", "mp4Url:" + mp4Url);

        UploadRequest request = new UploadRequest()
                .withInputImageFile(new File(PhotoUploadManager.getInstance().getCurrentImageUriStringPath()))
                .withAppName("NaturePhotoFramesandEditor")
                .withFolder(folderName)
                .withFileName(fileName)
                .withCountryCode("IN")
                .withPlatform("android")
                .withFirebaseAppCheck("asd")
                .withFcmToken("asd");

        FaceDanceApiClient.getInstance().uploadImage(mp4Url,request, new ApiCallback() {
            @Override
            public void onSuccess(String response) {
//                showToastOnUiThread("Upload successful: " + response);
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    String requestIdFromResponse = jsonResponse.optString("request_id", "default_id");

                    final String numericRequestId = requestIdFromResponse.replaceAll("[^\\d.]", "").trim();

                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "response:===========> " + response);
//                            showToastOnUiThread("Upload successful: " + numericRequestId);
                            processToNextScreen(numericRequestId);
                        }
                    }, 10000);

                } catch (JSONException e) {
                    Log.e(TAG, "Error parsing JSON response: " + e.getMessage());
                    final String fallbackId = String.valueOf(System.currentTimeMillis());
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "response:===========> " + response);
//                            showToastOnUiThread("Upload successful with fallback ID");
                            showNoServer();
                        }
                    }, 10000);
                }
            }

            @Override
            public void onError(String errorMessage) {
                Log.d(TAG, "onError:===========> " + errorMessage);
                showNoServer();
//                showToastOnUiThread("Upload failed: " + errorMessage);
            }
        });
    }

    @SuppressWarnings("unchecked")
    private void processToNextScreen(String requestId) {
        if(SmUtils.INSTANCE.isConnected(context)) {
            Log.d(TAG, "Generate face swap button clicked");
//            StartActivityGlobally.navigateToActivityWithFeature(
//                    context,
//                    CommonResultScreen.class,
//                    new Pair<>(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT, requestId),
//                    new Pair<>(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_FACE_DANCE)
//            );
            Intent intent = new Intent(context, CommonResultScreen.class);
            intent.putExtra(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT, requestId);
            intent.putExtra(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_FACE_DANCE);
            context.startActivity(intent);
            context.overridePendingTransition(
                    R.anim.cusotm_slide_in_right,
                    R.anim.custom_slide_out_left
            );
            context.finish();
        }else {
            Toast.makeText(context,"Please connect to internet.",Toast.LENGTH_SHORT).show();
        }
    }


    private void showNoServer() {
        if (context != null) {
            android.os.Handler handler = new android.os.Handler(context.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Log.e("showNoServer", "007");
                    CustomDialogManager.getInstance().showDialog(
                            context,
                            "No Server",
                            "We are unable to connect to the server at this time. Please check your internet connection and try again",
                            "Got it",
                            R.drawable.ic_brush,
                            new CustomDialogManager.DialogButtonClickListener() {
                                @Override
                                public void onButtonClicked() {
                                    responseCallBack.onSuccess("");
                                    //((Activity) context).finish();
                                }
                            }
                    );
                }
            });
        }
    }


    private void showToastOnUiThread(final String message) {
        if (context != null) {
            android.os.Handler handler = new android.os.Handler(context.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(context, message, Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    public void setContext(Activity context) {
//        this.context = context.getApplicationContext();
        this.context = context;
    }
}