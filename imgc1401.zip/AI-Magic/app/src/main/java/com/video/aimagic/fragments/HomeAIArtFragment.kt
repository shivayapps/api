package com.video.aimagic.fragments

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaPlayer.OnPreparedListener
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigValue
import com.video.aimagic.R
import com.video.aimagic.aienhancer.AiEnhancerUploadScreen
import com.video.aimagic.aivideos.AIVideoSeeAllScreen
import com.video.aimagic.babygen.BabyGenScreen
import com.video.aimagic.backgroundchanger.BackgroundChangeScreen
import com.video.aimagic.backgroundremover.BackgrounRemovalUploadScreen
import com.video.aimagic.bodyeditor.activites.BodyEditorUploadScreen
import com.video.aimagic.databinding.FragmentHomeAIArtBinding
import com.video.aimagic.facedance.FaceDanceSeeAllScreen
import com.video.aimagic.faceswap.FaceSwapSeeAllScreen
import com.video.aimagic.transformation.screens.TransformationSeeAllScreen
import com.video.aimagic.utils.facedance.FaceDanceDataLoader
import com.video.aimagic.utils.faceswap.FaceSwapDataLoader
import com.video.aimagic.utils.transformation.TransformationDataLoader


class HomeAIArtFragment : Fragment() {

    private var _binding: FragmentHomeAIArtBinding? = null
    private val binding get() = _binding!!
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            // Handle arguments if needed
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeAIArtBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupVideoPlayer()
    }

    private fun setupVideoPlayer() {
        val videoUri = Uri.parse("android.resource://" + requireContext().packageName + "/" + R.raw.new_home_screen_vid)
        binding.promoVideoView.setVideoURI(videoUri)

        binding.promoVideoView.setOnPreparedListener(OnPreparedListener { mediaPlayer ->
            this.mediaPlayer = mediaPlayer
            mediaPlayer.isLooping = true
            binding.promoVideoView.start()
        })

        binding.promoVideoView.setOnErrorListener { mp: MediaPlayer?, what: Int, extra: Int ->
            Log.e("VideoError", "Can't play video. what=$what, extra=$extra")
            true
        }

        loadFaceSwapMagicData()
        loadFaceDanceMagicData()
        setUpTransformationRecyclerview()
        setOnClickListeners()
    }

    private fun setOnClickListeners() {
        binding.videoEffectsSection.setOnClickListener {
            navigateToActivity(AIVideoSeeAllScreen::class.java)
        }

        binding.babyGeneratorSection.setOnClickListener {
            navigateToActivity(BabyGenScreen::class.java)
        }

        binding.transformationSeeAllText.setOnClickListener {
            navigateToActivity(TransformationSeeAllScreen::class.java)
        }

        binding.faceSwapSeeAllText.setOnClickListener {
            navigateToActivity(FaceSwapSeeAllScreen::class.java)
        }

        binding.faceDanceSeeAllText.setOnClickListener {
            navigateToActivity(FaceDanceSeeAllScreen::class.java)
        }

//        binding.objectRemoveal.setOnClickListener {
//            navigateToActivity(ObjectRemovalScreen::class.java)
//        }

        binding.imageEnahancer.setOnClickListener {
            navigateToActivity(AiEnhancerUploadScreen::class.java)
        }

        binding.backgroundRemover.setOnClickListener {
            navigateToActivity(BackgrounRemovalUploadScreen::class.java)
        }

        binding.backgroundCHanger.setOnClickListener {
            navigateToActivity(BackgroundChangeScreen::class.java)
        }

        binding.bodyEditor.setOnClickListener {
            navigateToActivity(BodyEditorUploadScreen::class.java)
        }

    }

    private fun navigateToActivity(activityClass: Class<*>) {
        val intent = Intent(requireContext(), activityClass)
        startActivity(intent)
        (context as Activity).apply {
            overridePendingTransition(
                R.anim.cusotm_slide_in_right,
                R.anim.custom_slide_out_left
            )
        }
    }



    private fun loadFaceSwapMagicData() {
        FaceSwapDataLoader.loadFaceSwapMagicData(requireActivity(), binding.faceSwapRecyclerView)
    }

    private fun loadFaceDanceMagicData() {
        FaceDanceDataLoader.loadFaceDanceData(requireActivity(), binding.faceDanceRecyclerView)
    }

    private fun setUpTransformationRecyclerview() {
        TransformationDataLoader.setUpTransformationRecyclerview(
            requireActivity(),
            binding.transformationRecyclerView
        )
    }


    override fun onResume() {
        super.onResume()
        if (mediaPlayer != null) {
            binding.promoVideoView.start()
        }
    }

    override fun onPause() {
        super.onPause()
        // Pause video playback when fragment is not visible
        if (binding.promoVideoView.isPlaying) {
            binding.promoVideoView.pause()
        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        // Release media player resources
        mediaPlayer?.release()
        mediaPlayer = null
        _binding = null
    }

}
