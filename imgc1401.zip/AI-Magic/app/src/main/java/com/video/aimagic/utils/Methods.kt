package com.video.aimagic.utils

import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import com.bumptech.glide.Glide
import com.video.aimagic.R
import com.video.aimagic.commonscreen.screen.FeedbackDialog
import com.video.aimagic.commonscreen.screen.RatingDialog
import com.video.aimagic.utils.appconfig.getAllDeviceInfo


object Methods {

    val emailTo = "ahyansamiapps@gmail.com"

    fun rateApp(context: Context) {
        val uri = Uri.parse("market://details?id=${context.packageName}")
        val goToMarket = Intent(Intent.ACTION_VIEW, uri)
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
        try {
            context.startActivity(goToMarket)
        } catch (e: ActivityNotFoundException) {
            context.startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/details?id=${context.packageName}")
                )
            )
        }
    }

    fun showImagePreviewDialog(context: Context, imageUrl: String?) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)

        val view: View = LayoutInflater.from(context)
            .inflate(R.layout.dialog_image_preview, null)

        val ivPreview = view.findViewById<ImageView?>(R.id.ivPreview)
        val ivClose = view.findViewById<ImageView?>(R.id.ivClose)

        Glide.with(context)
            .load(imageUrl)
            .into(ivPreview)

        ivClose.setOnClickListener(View.OnClickListener { v: View? -> dialog.dismiss() })

        dialog.setContentView(view)

        // 👇 IMPORTANT: wrap content + margin from screen
        val window = dialog.getWindow()
        if (window != null) {
            window.setLayout(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }

        dialog.show()
    }

    fun toastComingSoon(context: Context) {
        Toast.makeText(
            context,
            "Coming Soon",
            Toast.LENGTH_SHORT
        ).show()
    }

    fun feedBackSupport(context: Context, feebBackText: String) {
        val emailText = feebBackText + "\n" + context.getAllDeviceInfo()
        val emailIntent = Intent(Intent.ACTION_SEND_MULTIPLE)
        emailIntent.type = "message/rfc822"
        emailIntent.setPackage("com.google.android.gm")
        emailIntent.putExtra(Intent.EXTRA_EMAIL, arrayOf(emailTo))
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.app_name))
        emailIntent.putExtra(Intent.EXTRA_TEXT, emailText)
        val uris = ArrayList<Uri>()
        emailIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        context.startActivity(Intent.createChooser(emailIntent, "Send mail..."))
    }


    fun showRatingDialog(context: Context) {
        val ratingDialog = RatingDialog(context)
        ratingDialog.show()
    }

    fun showFeedbackDialog(context: Context) {
        val feedbackDialog = FeedbackDialog(context)
        feedbackDialog.show()
    }

    fun requestBook(context: Context, tag: String) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:$emailTo")
            when (tag) {
                "Book" -> putExtra(Intent.EXTRA_SUBJECT, "Empire Lens request")
                "feedback" -> putExtra(Intent.EXTRA_SUBJECT, "Empire Lens app Feedback")
                else -> putExtra(Intent.EXTRA_SUBJECT, "Empire Lens app Feedback")
            }
        }
        if (context.packageManager != null) startActivity(context, intent, null)
    }

    fun openLink(link: String, context: Context) {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
    }


}