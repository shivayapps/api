package com.video.aimagic.facedance.api.get;

import java.io.File;

public interface FaceDanceVideoResponseCallback {
    void onSuccess(File videoFile);
    void onProgress(int progress);
    void onError(String errorMessage);
}