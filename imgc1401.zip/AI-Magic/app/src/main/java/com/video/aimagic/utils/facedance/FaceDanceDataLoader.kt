package com.video.aimagic.utils.facedance

import android.content.Context
import android.util.Log
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.video.aimagic.R
import com.video.aimagic.facedance.FaceDanceModel
import com.video.aimagic.facedance.FaceDanceVideoAdapter
import com.video.aimagic.utils.JSONLoder
import com.video.aimagic.utils.appconfig.RemoteConfigPref
import org.json.JSONException
import org.json.JSONObject

object FaceDanceDataLoader {

    @JvmStatic
    fun faceDanceCategoryLoder(context: Context): List<FaceDanceModel> {
        val faceDanceModels = mutableListOf<FaceDanceModel>()
//        val jsonString = JSONLoder.loadJSONFromRaw(context, R.raw.facedance).toString()
        val jsonString = RemoteConfigPref(context).faceDanceEffectJson

        Log.e("FaceDanceDataLoader", "jsonString:$jsonString")

        try {
            // Parse using Gson like in your Java code
            val gson = Gson()
            val type = object : TypeToken<List<UrlItem>>() {}.type
            val data: List<UrlItem> = gson.fromJson(jsonString, type)

            if (data != null && data.isNotEmpty()) {
                for (urlItem in data) {
                    faceDanceModels.add(FaceDanceModel(
                        urlItem.url,
                        urlItem.user_type ?: "non_pro",
                        urlItem.cat_name_localised ?: mapOf("en" to "Unknown")
                    ))
                }
            } else {
                Log.e("FaceDanceDataLoader", "Parsed JSON data is null or empty!")
            }
        } catch (e: Exception) {
            Log.e("FaceDanceDataLoader", "Error parsing JSON", e)
            try {
                val root = JSONObject(jsonString)
                val keys = root.keys()

                while (keys.hasNext()) {
                    val category = keys.next()
                    val categoryObj = root.getJSONObject(category)
                    val urls = categoryObj.getJSONArray("urls")

                    if (urls.length() > 0) {
                        val urlObj = urls.getJSONObject(0)
                        val imageUrl = urlObj.getString("url")
                        val userType = if (urlObj.has("user_type")) {
                            urlObj.getString("user_type")
                        } else {
                            "non_pro"
                        }
                        val localizedNames = mapOf("en" to category)

                        faceDanceModels.add(FaceDanceModel(imageUrl, userType, localizedNames))
                    }
                }
            } catch (jsonException: JSONException) {
                Log.e("FaceDanceDataLoader", "Fallback parsing also failed", jsonException)
            }
        }
        return faceDanceModels
    }

    @JvmStatic
    fun loadFaceDanceData(context: Context, recyclerView: RecyclerView) {
        val faceDanceModels = faceDanceCategoryLoder(context)
        if (faceDanceModels.isNotEmpty()) {
            val topAdapter = FaceDanceVideoAdapter(context, faceDanceModels)
            recyclerView.adapter = topAdapter
        } else {
            Log.e("FaceDanceDataLoader", "No data to display in RecyclerView")
        }
    }

    data class UrlItem(
        val url: String,
        val user_type: String?,
        val cat_name_localised: Map<String, String>?
    )
}