package com.video.aimagic.callback;

import java.io.File;

public interface VideoResponseCallback {
    void onSuccess(File videoFile);
    void onProgress(int progress);
    void onError(String errorMessage);
}