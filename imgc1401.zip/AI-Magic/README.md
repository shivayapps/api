# AI-Magic-
AI Magic 
testing-first push

Image Enhancer
1. If the user has not uploaded an image and clicks Generate, show a toast message saying ‘Upload image'.
   2.Add a preview screen to the Image Enhancer result so users can preview the generated image. Use an eye icon to open the image preview and a close icon to close the preview.
   3.Once the Save Changes dialog appears, tapping the empty space at the top should allow the dialog to be dragged down, and tapping the phone controls should close the dialog.
4. After clicking Share, the enhanced image is not shared. Instead, another image that I generated earlier is being shared
   5.Remove more faces exception for this feature
   6.On the result screen, tapping the top Back button shows the Save Changes dialog, but tapping the phone Back button takes the user to the Home screen. Both Back actions should display the Save Changes dialog.
   7.For this feature, provide a crop screen with all aspect ratios, not just a single ratio like 3:4."

* image enhance "1. not implemented for image enhance
8. A white screen appears after clicking Cancel & Exit from the result screen.

* After applying the Background Changer, tapping Share shares the background-removed image instead of the background-changed image.
* On the Background Changer result screen:
  Without applying a background change, pressing the system Back button navigates to the Select Image screen. A Save Changes dialog should be shown instead.
  After applying a background change, pressing the system Back button navigates to the Generating screen. A Save Changes dialog should be shown instead."

* When an ad is displayed after the user taps Save, the video playback should be paused until the ad is closed.

* In the Baby Gen saved result screen, tapping the top Back button takes the user to the generating screen, 
* which is not the correct flow. The user should be taken to the Home screen instead.

* face dance :6. Add corner radius to the Face Dance template preview, similar to the Face Swap template preview.
  7.When an ad is displayed after the user taps Save, the video playback should be paused until the ad is closed.

* The images are currently saved as shown in the result screen, but they should be saved exactly as received from the server. 
* No border should be added. Because of this issue, I previously mentioned using a staggered view in Creations



/////////////////
fm

1.After opening Internal Storage, there is no option to switch between Grid view and List view.
Changing the view in other sections (such as Images or Videos) also affects the Files section, which should not happen.
2.All file types should open within the same application, including PDFs, images, videos, ZIP files, etc.
3.When navigating through multiple directories, the folder names overlap.
Please add a background under the Internal Storage section and place the text on top of the background to avoid overlapping.
4.On the Home screen, the font size of “Safe Folder,” “Applications,” and “Trash” does not match the font size used above.
These labels also appear bold, unlike the others.
5.Share and Safe Folder features are not implemented.
6.On the Home screen, the usage percentage is missing from the circular progress bar.
7.Clicking on privacy policies opens storage analysis.
8.In Scan, after clicking Next, show options to select the save format (JPG, PDF, image, etc.), file name, and save directory. Also display recently saved files