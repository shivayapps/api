package com.photogallery.edit

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityStickerBinding
import com.photogallery.dialog.ProgressDialog
import com.photogallery.edit.adapter.ColorAdapter
import com.photogallery.edit.stickerPackage.TextSticker
import com.photogallery.extension.toast
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.dialog.EditTextDialog
import com.photogallery.utils.Constant


class StickerActivity : BaseActivity() {

    lateinit var binding: ActivityStickerBinding
    var imagePath = ""
    var saveImageName = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        applyStatusBar = false
        super.onCreate(savedInstanceState)
        binding = ActivityStickerBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        updateStatusBarColor(Color.parseColor("#151515"))

        intView()
    }


    override fun onResume() {
        applyStatusBar = false
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }


    private fun intView() {

        binding.txtTitle.text = getString(R.string.Sticker)

        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        saveImageName = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_NAME) ?: ""

//        Glide.with(this)
//            .load(imagePath)
//            .diskCacheStrategy(DiskCacheStrategy.NONE)
//            .skipMemoryCache(false)
//            .into(binding.mainImg)

        val bitmap = getBitmapFromFilePath(imagePath)
        binding.mainImg.setImageBitmap(bitmap)
        binding.stickerView.setMainImage(binding.mainImg)
        binding.stickerView.setMainBitmap(bitmap)

        binding.btnAdd.setOnClickListener {
            val editTextDialog = EditTextDialog(
                this@StickerActivity,
                { stringText ->
                    addNewSticker(stringText)
                }
            )
            editTextDialog.show()
        }

        setColorAdapter()
        intListener()

    }

    private fun setColorAdapter() {
        val colorAdapter = ColorAdapter(this, clickListener = {
            onColorChanged(it)
        })
        binding.recyclerView.adapter = colorAdapter
        onColorChanged(colorAdapter.colorList[0])
    }

    fun onColorChanged(colorCode: Int) {
        val sticker = binding.stickerView.currentSticker
        if (sticker is TextSticker) {
            sticker.setTextColor(colorCode)
            sticker.resizeText()
            binding.stickerView.invalidate();
        }
//        mPhotoEditor.setShape(mShapeBuilder.withShapeColor(colorCode))
    }

    fun hideKeyboard(view: EditText) {
        view.clearFocus()
        val methodManager = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun showKeyboard(view: EditText) {
        view.requestFocus()
        val methodManager = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun intListener() {
        binding.icBack.setOnClickListener { onBackPressed() }
        binding.ivDone.setOnClickListener {
            val progressDialog = ProgressDialog(
                this@StickerActivity,
                0,
                0,
                getString(R.string.saving),
                ""
            )

            progressDialog.show()
            Thread {
                try {
                    val bitmap = binding.stickerView.createBitmap()
                    val imagePath = saveEditImage(bitmap, saveImageName)
                    runOnUiThread {
                        if (imagePath != null) {
                            val intent = Intent()
                            intent.putExtra(Constant.EXTRA_EDIT_SAVE_IMAGE, imagePath)
                            setResult(RESULT_OK, intent)
                        }
                        if (!isFinishing && !isDestroyed) {
                            if (progressDialog.isShowing)
                                progressDialog.dismiss()
                        }
                        finish()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        if (!isFinishing && !isDestroyed) {
                            if (progressDialog.isShowing)
                                progressDialog.dismiss()
                        }
                        toast(
                            getString(R.string.image_editing_failed)
                        )
                    }
                }
            }.start()
        }
    }


    private fun addNewSticker(text: String) {
        val sticker = TextSticker(this)
        sticker.text = text
        sticker.resizeText()
        binding.stickerView.addSticker(sticker)
    }

}