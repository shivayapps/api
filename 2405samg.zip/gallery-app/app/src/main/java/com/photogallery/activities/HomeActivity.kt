package com.photogallery.activities

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PorterDuff
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.TelephonyManager
import android.text.format.DateFormat
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.doOnPreDraw
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.photogallery.BuildConfig
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.install.model.InstallStatus
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.photogallery.R
import com.photogallery.inapp_helper.AppUpdateInstallerListener
import com.photogallery.inapp_helper.AppUpdateInstallerManager
import com.photogallery.inapp_helper.InAppUpdateInstallerManager
import com.photogallery.base.BaseActivity
//import com.photogallery.browser.WebBrowserActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.customview.MyRecyclerView
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityHomeBinding
import com.photogallery.databinding.PopBottomMenuBinding
import com.photogallery.dialog.AlbumDetailsDialog
import com.photogallery.dialog.ActionConfirmationDialog

import com.photogallery.dialog.CreateAlbumDialog
import com.photogallery.dialog.DeleteDialog
import com.photogallery.dialog.DetailsDialog
import com.photogallery.dialog.DisplayedColumnsDialog
import com.photogallery.dialog.ExitConfirmationDialog
import com.photogallery.dialog.FilterMediaDialog
import com.photogallery.dialog.GroupDialog
import com.photogallery.dialog.HomeOptionsDialog
import com.photogallery.dialog.ProgressDialog
import com.photogallery.dialog.FileRenameDialog
import com.photogallery.dialog.FolderRenameDialog

import com.photogallery.dialog.SimpleMessageDialog
import com.photogallery.dialog.SimpleProgressDialog
import com.photogallery.dialog.SortingOptionsDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.delayExecution
import com.photogallery.extension.getFinalUriFromPath
import com.photogallery.extension.getUriMimeType
import com.photogallery.extension.isGif
import com.photogallery.extension.openEditorIntent
import com.photogallery.extension.scanPathRecursively
import com.photogallery.extension.showErrorToast
import com.photogallery.extension.showHomeNotification
import com.photogallery.extension.toast
import com.photogallery.jobs.MediaContentObserver
//import com.photogallery.fragment.AlbumFragment
//import com.photogallery.fragment.PhotosFragment
import com.photogallery.jobs.LoaderXMedia
import com.photogallery.jobs.autoclean.startAutoCleanTrashWorker
import com.photogallery.jobs.fetchRecentMedia
import com.photogallery.jobs.startPlacesFetcher
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.model.PlaceData
import com.photogallery.secret.activity.PrivateActivity
import com.photogallery.secret.activity.SelectImageActivity
import com.photogallery.utils.Constant
import com.photogallery.utils.FastScroller
import com.photogallery.utils.MAX_COLUMN_COUNT_ALBUM
import com.photogallery.utils.MAX_COLUMN_COUNT_PICTURE
import com.photogallery.utils.MessageEvent
import com.photogallery.utils.PopupWindowHelper
import com.photogallery.utils.Preferences
import com.photogallery.utils.TYPE_GIFS
import com.photogallery.utils.TYPE_IMAGES
//import com.photogallery.utils.TYPE_PORTRAITS
//import com.photogallery.utils.TYPE_RAWS
//import com.photogallery.utils.TYPE_SVGS
import com.photogallery.utils.TYPE_VIDEOS
import com.photogallery.utils.Utils
import com.photogallery.utils.ensureBackgroundThread
import com.photogallery.utils.sendEvent
import com.photogallery.views.CommonPagerAdapter
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfig.*
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.single.PermissionListener
import com.photogallery.dialog.RateUsDialog
import com.photogallery.dialog.UpdateDialog
import com.photogallery.edit.EditImageActivity
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.fragment.AlbumTab
import com.photogallery.fragment.ExploreTab
import com.photogallery.fragment.PictureTab
import com.photogallery.fragment.StoriesTab
import com.photogallery.jobs.LoaderUtilMedia
import com.photogallery.jobs.startCategoryWorker
import com.photogallery.model.UpdateModel
import com.photogallery.secret.LockSetActivity
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.collections.get
import kotlin.math.max
import kotlin.math.min

class HomeActivity : BaseActivity() {

    lateinit var preferences: Preferences

    var allList = ArrayList<MediaData>()
    var pictures = ArrayList<Any>()

    var albumList: ArrayList<AlbumData> = ArrayList()

    //    var dataBase: AppDatabase? = null
    private val dataBase: AppDatabase by lazy { AppDatabase.getInstance(this) }
    var utilList: ArrayList<AlbumData> = ArrayList()

    //    private var mPhotoZoomListener: MyRecyclerView.MyZoomListener? = null
    var needRefreshMedia = false
    var isSelectAll = false
    var imageFilePath = ""
    var tabPos = 0

    private val photosTab by lazy { PictureTab(this, binding.photosTab) }
    private val albumTab by lazy { AlbumTab(this, binding.albumTab) }
    private val storiesTab by lazy { StoriesTab(this, binding.storiesTab) }
//    private val exploreTab by lazy { ExploreTab(this, binding.exploreTab) }

    lateinit var binding: ActivityHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        updateStatusBarColor(ContextCompat.getColor(this, R.color.status_bar))
        preferences = Preferences(this)

        initView()
        startNewPhotoFetcher()
        startCleanRecycleBin()

        setRvLayoutManager()

        albumTab.onCreate()
        photosTab.onCreate()
        storiesTab.onCreate()

        sendEvent("get_data")
        //startPlacesFetcher()

//        initFirebaseCategoryConfig({
        startCategoryWorker()
//        })

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        if (event.type.equals("get_data")) {
            getData()
        }
        if (event.type.equals("hideCamera")) {
            runOnUiThread {
                toggleCameraVisibility()
            }
        }
        if (event.type.equals("rename")) {
            if (event.data is String) scanPathRecursively(event.data)
        }
        if (event.type.equals("refresh_layoutmanager")) {
            delayExecution(800) {
                setRvLayoutManager()
            }
        }
        if (event.type.equals("refresh")) {
            needRefreshMedia = true
            preferences.refreshMedia = true
        }
    }

    private fun getData() {
        albumTab.utilLoader?.refreshLoader("frag_0")
        albumTab.albumLoader?.refreshLoader("frag_0")
        photosTab.photosLoader?.refreshLoader("frag_1")
        albumTab.getAlbumData()
        photosTab.getPhotoData()
        storiesTab.getData()
    }


    fun toggleMediaSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {
        try {

            if (select && pictures[pos] is AlbumData) {
                return
            }

            if (pictures[pos] is MediaData) {

                if (select) {
                    (pictures[pos] as MediaData).isSelected = true
//                (pictures[pos] as PictureData).isCheckboxVisible = true
//                selectedKeys.add(itemKey)
                } else {
                    (pictures[pos] as MediaData).isSelected = false
//                (pictures[pos] as PictureData).isCheckboxVisible = false
//                selectedKeys.remove(itemKey)
                }
            }
            photosTab.pictureAdapter?.notifyItemChanged(pos)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        photosTab.setSelectedMedia()

    }

    private fun detectRegion() {
        val region = Locale.getDefault().country
        Log.d("detectRegion", "Device Region: $region")

        val telephonyManager = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        val simCountry = telephonyManager.simCountryIso?.uppercase(Locale.US)
        val networkCountry = telephonyManager.networkCountryIso?.uppercase(Locale.US)

        Log.d("detectRegion", "SIM Country: $simCountry, Network Country: $networkCountry")
    }


    fun openStoryView(albumData: AlbumData) {
        val selectedList = ArrayList<String>()
        albumData.mediaData.forEach { media ->
            selectedList.add(media.filePath)
        }
        var strTitle = DateFormat.format("MMMM yyyy", albumData.mediaData[0].date).toString()
        val intent = Intent(this, StoryViewerActivity::class.java)
//        intent.putExtra("TITLE", albumData.title)
        intent.putExtra("TITLE", strTitle)
        intent.putStringArrayListExtra("IMAGE_PATHS", selectedList)
        startActivity(intent)
    }

    fun openCustomImageList(albumData: AlbumData) {
        Constant.albumData = AlbumData(
            albumData.title,
            albumData.mediaData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        val intent = Intent(this, ImageGalleryActivity::class.java)
        if (albumData.lati > 0 && albumData.long > 0) {
            intent.putExtra("isFromMap", true)
            intent.putExtra("lati", albumData.lati)
            intent.putExtra("long", albumData.long)
        }
        startActivity(intent)
    }



    var createPdfLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            Utils.generatePdf(this@HomeActivity, Constant.selectedImageList)
        }
    }


    fun openEditorLauncher() {
        val intent = Intent(this@HomeActivity, SelectImageActivity::class.java)
        intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_EDIT)
        intent.putExtra(Constant.EXTRA_INCLUDE_VIDEO, false)
        editorLauncher.launch(intent)
    }

    var editorLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            val selectedImagePath = Constant.selectedImageList[0].filePath
            val intent = Intent(this, EditImageActivity::class.java)
            intent.putExtra(Constant.EXTRA_EDIT_IMAGE_PATH, selectedImagePath)
            startActivity(intent)
        }
    }

    fun openImageList(albumData: AlbumData) {
        Constant.albumData = AlbumData(
            albumData.title,
            albumData.mediaData,
            albumData.folderPath,
            albumData.date,
            albumData.fileSize
        )
        val intent = Intent(this@HomeActivity, ImageGalleryActivity::class.java)
        intent.putExtra("folderPath", "${albumData.folderPath}")
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT)
        startActivity(intent)
//        setBackAlbumData()

    }

//    public fun setBackAlbumData() {
//        Constant.albumList.clear()
//        for (albumData in albumList) {
//            Constant.albumList.add(
//                AlbumData(
//                    albumData.title,
//                    albumData.mediaData,
//                    albumData.folderPath,
//                    albumData.date,
//                    albumData.fileSize
//                )
//            )
//        }
//    }

    private fun initView() {
        //adsPref = PrefCalls(this)

        Log.e("RateTag", "intView isReCreateHomeSS ${Constant.isReCreateHomeSS}")
        if (Constant.isReCreateHomeSS) {
            Constant.isReCreateHomeSS = false
        }
//        else {
//            Log.e("native_exit", "preferences.appOpenCounter001:${preferences.appOpenCounter}")
//            var appOpenCounter = preferences.appOpenCounter
//            appOpenCounter += 1
//            preferences.appOpenCounter = appOpenCounter
//            Log.e("native_exit", "preferences.appOpenCounter002:${appOpenCounter}")
//        }

        if (preferences.isFirstTimeInstall) {
            preferences.isFirstTimeInstall = false
        }

        //needDialog = adsPref.firstTimeDialog

//        CoroutineScope(Dispatchers.IO).launch {
        setTab()
        setToolbarSelectionMaintain(false, 0, false)
//        }

        intListener()
        initPhotoListener()
        initAlbumListener()
        initExploreListener()

        val remoteConfig = getInstance()
        checkForceAppUpdate(remoteConfig)
//        checkInAppUpdate()

        Log.e("native_exit", "delayExecution")
//        initFirebaseConfig {}
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestNotificationPermission()
        } else {
            //showHomeNotification()
        }

    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private fun requestNotificationPermission() {
        Log.e("POST_NOTIFICATIONS", "requestNotificationPermission")
        Dexter.withContext(this@HomeActivity)
            .withPermission(
                Manifest.permission.POST_NOTIFICATIONS
            )
            .withListener(object : PermissionListener {
                override fun onPermissionGranted(p0: PermissionGrantedResponse?) {
                    Log.e("POST_NOTIFICATIONS", "onPermissionGranted")
                    //showHomeNotification()
                }

                override fun onPermissionDenied(PermissionDeniedResponse: PermissionDeniedResponse?) {
                    Log.e(
                        "POST_NOTIFICATIONS",
                        "onPermissionDenied:${PermissionDeniedResponse?.isPermanentlyDenied}"
                    )
                    if (PermissionDeniedResponse?.isPermanentlyDenied!!) {
                        //showPermissionDeniedDialog(getString(R.string.permission_Needed), getString(R.string.notification_permission_message))
                        showPermissionDeniedDialog(
                            getString(R.string.permission_Needed),
                            "Enable notification permission to stay updated with important alerts and updates."
                        )
                    } else {
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    p0: PermissionRequest?,
                    token: PermissionToken?
                ) {
                    token?.continuePermissionRequest()
                    Log.e("POST_NOTIFICATIONS", "onPermissionRationaleShouldBeShown")
                }

            }).check()
    }

    private fun startCleanRecycleBin() {
        if (preferences.deleteAfter30Days) {
            CoroutineScope(Dispatchers.IO).launch {
                startAutoCleanTrashWorker()
            }
        }
    }

    private fun startNewPhotoFetcher() {
        if (!EventBus.getDefault().isRegistered(this)) EventBus.getDefault().register(this)
        MediaContentObserver.registerContentObserver(this)

    }


    private fun setRvLayoutManager() {
        photosTab.setRvLayoutManager()
        albumTab.setRvLayoutManager()
    }

    override fun onDestroy() {
        super.onDestroy()
        MediaContentObserver.unregisterContentObserver(this)
//        MediaContentObserver.unbindService()
        if (EventBus.getDefault().isRegistered(this)) EventBus.getDefault().unregister(this)
    }


    private fun setTab() {
        binding.groupToolbarHeader.visibility = View.VISIBLE
        toggleCameraVisibility()

        val commonPagerAdapter = CommonPagerAdapter()
        commonPagerAdapter.insertViewId(R.id.albumTab)
        commonPagerAdapter.insertViewId(R.id.photosTab)
        commonPagerAdapter.insertViewId(R.id.storiesTab)
//        commonPagerAdapter.insertViewId(R.id.exploreTab)
        binding.viewPager.offscreenPageLimit = 4
        binding.viewPager.adapter = commonPagerAdapter

        //binding.bottomNavigation.setActiveItem()

        binding.tabAlbum.setData(
            R.drawable.ic_tab_album,
            R.drawable.ic_tab_album_selected,
            getString(R.string.albums)
        )
        binding.tabPhoto.setData(
            R.drawable.ic_tab_photos,
            R.drawable.ic_tab_photos_selected,
            getString(R.string.photos)
        )
        binding.tabStory.setData(
            R.drawable.ic_tab_story,
            R.drawable.ic_tab_story_selected,
            getString(R.string.stories)
        )
//        binding.tabExplore.setData(
//            R.drawable.ic_tab_explore,
//            R.drawable.ic_tab_explore_selected,
//            getString(R.string.explore)
//        )

        val tabs = listOf(
            binding.tabAlbum,
            binding.tabPhoto,
            binding.tabStory,
//            binding.tabExplore
        )
        tabs.forEachIndexed { index, tab ->
            tab.setOnClickListener {
                binding.viewPager.currentItem = index
                selectTab(index)
            }
        }
        selectTab(0)

        binding.viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {

            }

            override fun onPageSelected(position: Int) {
                selectTab(position)
                tabPos = position

                Log.e("HomeActivity", "onPageSelected.refreshMedia:${preferences.refreshMedia}")
                if (preferences.refreshMedia) {
                    preferences.refreshMedia = false
                    albumTab.getAlbumData()
                    photosTab.getPhotoData()
                }

            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })

        var isEmpty = false
        isEmpty = albumTab.isEmptyAlbum && photosTab.isEmptyPhoto
        setEmptyData(isEmpty)
    }

    private fun selectTab(selectedIndex: Int) {

        binding.tabAlbum.isSelectedTab = false
        binding.tabPhoto.isSelectedTab = false
        binding.tabStory.isSelectedTab = false
//        binding.tabExplore.isSelectedTab = false


        when (selectedIndex) {
            0 -> {
                binding.tabAlbum.isSelectedTab = true
            }

            1 -> {
                binding.tabPhoto.isSelectedTab = true
            }

            2 -> {
                binding.tabStory.isSelectedTab = true
            }

//            3 -> {
//                binding.tabExplore.isSelectedTab = true
//            }
        }

    }


    private fun setEmptyData(isEmpty: Boolean) {
//        if (isEmpty) {
//            binding.llAdPlace.beGone()
//        } else {
//            binding.llAdPlace.beVisible()
//        }
    }

    fun longClickListener(isShowSelection: Boolean, selected: Int, isAllSelect: Boolean) {
        Log.e("1712MG", "longClickListener.refreshMedia:${preferences.refreshMedia}")

        if (preferences.refreshMedia) {
            preferences.refreshMedia = false
//            if (albumFragment != null) albumFragment.refreshData()
//            if (photosFragment != null) photosFragment.refreshData()
            albumTab.getAlbumData()
            photosTab.getPhotoData()
        }

        setToolbarSelectionMaintain(
            isShowSelection,
            selected,
            isAllSelect
        )
    }


    //    var needToAddPin = false
//    var needToRemovePin = false
    var mSelectedItem = 0
    private fun setToolbarSelectionMaintain(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean,
    ) {
        runOnUiThread {

            mSelectedItem = selectedItem
            binding.loutToolbar.visibility = View.VISIBLE


//            needToAddPin = false
//            needToRemovePin = false

            if (isShowSelection) {

                binding.btnHide.visibility =
                    if (binding.viewPager.currentItem == 2) View.GONE else View.VISIBLE
                binding.btnMore.visibility =
                    if (binding.viewPager.currentItem == 2) View.GONE else View.VISIBLE

                binding.btnShare.visibility =
                    if (binding.viewPager.currentItem == 0) View.GONE else View.VISIBLE

            }

            binding.groupToolbarSelectHeader.visibility =
                if (isShowSelection) View.VISIBLE else View.GONE

//        binding.viewPager.isUserInputEnabled = !isShowSelection
//        binding.viewPager.isEnabled = !isShowSelection
            binding.viewPager.setPagingEnabled(!isShowSelection)
            isSelectAll = isAllSelect

            binding.loutSelectOption.visibility =
                if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE

            if (binding.viewPager.currentItem == 2) {
//                binding.groupToolbarSettingHeader.visibility = View.GONE
                binding.icSearch.visibility = View.GONE
                binding.icCamera.visibility = View.GONE
                binding.groupToolbarHeaderPrivate.visibility =
                    if (isShowSelection) View.GONE else View.VISIBLE
            } else {
                if (isShowSelection) {
                    binding.groupToolbarHeader.visibility = View.GONE
                    binding.icSearch.visibility = View.GONE
                    binding.icCamera.visibility = View.GONE
                } else {
                    binding.groupToolbarHeader.visibility = View.VISIBLE
                    toggleCameraVisibility()
                }
            }

//        binding.loutTab.visibility = if (isShowSelection) View.GONE else View.VISIBLE
//        binding.cardLoutTab.visibility = if (isShowSelection) View.GONE else View.VISIBLE
            binding.bottomNavigation.visibility = if (isShowSelection) View.GONE else View.VISIBLE
            binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
            setSelectAllColor()

        }
    }

    private fun toggleCameraVisibility() {
        //binding.icCamera.beGoneIf(preferences.hideCamera)
    }

    private fun setSelectAllColor() {
//        val color = ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
//        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.icSelect.setImageResource(if (isSelectAll) R.drawable.ic_select_all else R.drawable.ic_unselect_all)
    }

    private fun getSelectedAlbum(): ArrayList<AlbumData> {
        val selectAlbum: ArrayList<AlbumData> = ArrayList()
        for (i in albumList.indices) {
            if (albumList[i] != null) {
//                if (albumList[i] is PictureData) {
                val model: AlbumData = albumList[i] as AlbumData
                if (model.isSelected) {
                    selectAlbum.add(model)
//                        favList.add(model.filePath)
                }
//                }
            }
        }
        return selectAlbum
    }

    private fun getSelectedPhotos(): ArrayList<MediaData> {
        val selectImage: ArrayList<MediaData> = ArrayList()
//        selectImage.addAll(pictureAdapter?.getSelectedMedia() ?: emptyList())

        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
//                        favList.add(model.filePath)
                    }
                }
        }
        return selectImage
    }

    private fun getSelectedMedia(): ArrayList<MediaData> {
        val selectImage: ArrayList<MediaData> = ArrayList()
        if (binding.viewPager.currentItem == 0) {

            for (i in albumList.indices) {
                if (albumList[i] != null)
                    if (albumList[i].isSelected) {
                        val pictureList = albumList[i].mediaData
                        selectImage.addAll(pictureList)
                    }
            }

        } else if (binding.viewPager.currentItem == 1) {
            selectImage.addAll(getSelectedPhotos())
        }
        return selectImage
    }

    private fun getAlbumListForSelect() {
        setBackAlbumData()
    }

    fun setBackAlbumData() {
        Constant.albumList.clear()
        for (albumData in albumList) {
            Constant.albumList.add(
                AlbumData(
                    albumData.title,
                    albumData.mediaData,
                    albumData.folderPath,
                    albumData.date,
                    albumData.fileSize
                )
            )
        }
    }

    override fun onResume() {
        super.onResume()
        setAppTheme()
        val readPhoneState =
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
        val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }

        Log.e(
            "checkCaller.icCall",
            "onResume.canDrawOverlays>$canDrawOverlays,readPhoneState>$readPhoneState"
        )
//        if (callerCadBaseConfig.callerCadEnable) {
//
//            if (canDrawOverlays && readPhoneState) {
//                binding.icCall.beGone()
//                Log.e("checkCaller.icCall", "onResume.icCall.beGone")
//            } else {
//                binding.icCall.beVisible()
//                Log.e("checkCaller.icCall", "onResume.icCall.beVisible")
//            }
//        }

        Log.e("HomeActivity", "onResume.refreshMedia:${preferences.refreshMedia}")

//        binding.exploreTab.map.onResume()
//        binding.exploreTab.llHidden.beGoneIf(preferences.hideVault)

//        try {
//            val countRecycle = dataBase.dataDao().getCountDelete()
//            binding.exploreTab.txtRecycleCount.text = "$countRecycle"
//        } catch (e: Exception) {
//        }

        delayExecution(120) {
            if (preferences.refreshMedia || needRefreshMedia) {
                needRefreshMedia = false
                preferences.refreshMedia = false
                refreshData()
            }
        }

        if (preferences.scanMedia) {
            preferences.scanMedia = false
            try {
                ensureBackgroundThread {
                    scanPathRecursively(Constant.ROOT_PATH)
                }
            } catch (e: Exception) {
            }
        }

    }

    private fun refreshData() {
        delayExecution(150) {
            preferences.refreshMedia = false
            getData()
//            sendEvent("get_data")
        }
    }


    var isOpenCameraPermission: Boolean = false
    private fun requestPermission() {

        val list: ArrayList<String> = ArrayList()
        if (isOpenCameraPermission) {
            list.add(Manifest.permission.CAMERA)
        } else
            list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            list.add(Manifest.permission.ACCESS_MEDIA_LOCATION)
        }

        Dexter.withContext(this@HomeActivity)
            .withPermissions(
                list
            )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    report?.let {
                        if (report.areAllPermissionsGranted()) {
                            openCamera()
                        } else if (report.isAnyPermissionPermanentlyDenied) {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            val uri = Uri.fromParts("package", packageName, null)
                            intent.data = uri
                            permissionLauncher.launch(intent)
                        } else {
                            toast(
                                if (isOpenCameraPermission) getString(R.string.permission_camera_toast_msg)
                                else getString(R.string.permission_toast_msg)
                            )
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<PermissionRequest>?,
                    token: PermissionToken?,
                ) {
                    token?.continuePermissionRequest()
                }
            }).check()

    }

    private fun intListener() {

//        binding.icDrawer.setOnClickListener {
//            if (binding.drawerLay.isDrawerOpen(GravityCompat.START))
//                binding.drawerLay.closeDrawer(GravityCompat.START)
//            else binding.drawerLay.openDrawer(GravityCompat.START)
//        }
//
//        binding.drawerContent.loutDrawerMain.setOnClickListener {
//
//        }
//        intDrawerListener()

        //binding.icCamera.beGoneIf(preferences.hideCamera)
        binding.icCamera.setOnClickListener {
//            if (checkCameraPermission())
            openCamera()
//            else {
//                isOpenCameraPermission=true
//                requestPermission()
//            }

        }
        binding.icSearch.setOnClickListener {
            val intent = Intent(this, SearchActivity::class.java)
            startActivity(intent)
        }
//        binding.searchTab.btnAllTimeLine.setOnClickListener {
//            startActivity(Intent(this, TimeLineActivity::class.java))
//        }
//        binding.searchTab.btnAllPlace.setOnClickListener {
//            startActivity(Intent(this, LocationAlbumActivity::class.java))
//        }
//        binding.searchTab.edtSearch.setOnClickListener {
//            val intent = Intent(this, SearchActivity::class.java)
//            startActivity(intent)
//        }

        var resultAll = 0
        resultAll += TYPE_IMAGES
        resultAll += TYPE_VIDEOS
        resultAll += TYPE_GIFS
//        resultAll += TYPE_RAWS
//        resultAll += TYPE_SVGS
//        resultAll += TYPE_PORTRAITS

        var resultPhoto = 0
        resultPhoto += TYPE_IMAGES
//        resultPhoto += TYPE_RAWS
//        resultPhoto += TYPE_SVGS
//        resultPhoto += TYPE_PORTRAITS

        var resultVideo = 0
        resultVideo += TYPE_VIDEOS

        var resultGif = 0
        resultGif += TYPE_GIFS

//        when (preferences.getFilterMedia()) {
//            resultAll -> {
//                binding.txtTitle.text = getString(R.string.all)
//            }
//
//            resultPhoto -> {
//                binding.txtTitle.text = getString(R.string.photos)
//            }
//
//            resultVideo -> {
//                binding.txtTitle.text = getString(R.string.videos)
//            }
//
//            resultGif -> {
//                binding.txtTitle.text = getString(R.string.gifs)
//            }
//        }

//        binding.txtTitle.setOnClickListener {
//            showHomeMenuFilter(binding.txtTitle)
//        }
        binding.icMenu.setOnClickListener {
            showMenu()
        }

        binding.icClose.setOnClickListener {
            if (binding.viewPager.currentItem == 1) {
                setCloseToolbar()
                //refreshData()
            } else if (binding.viewPager.currentItem == 0) {
                setCloseToolbar()
                //refreshData()
            }
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            if (binding.viewPager.currentItem == 1) setPhotosSelect(isSelectAll)
            else if (binding.viewPager.currentItem == 0) setAlbumSelect(isSelectAll)
            setSelectAllColor()
        }

        binding.btnShare.setOnClickListener {
            if (binding.viewPager.currentItem == 1) {
                if (photosTab.selectedPhotosCount == 0) {
                    toast(getString(R.string.PleaseSelectImage))
                } else {
                    shareImages()
                }
            }
        }


        binding.btnDelete.setOnClickListener {
            if (binding.viewPager.currentItem == 0) {
                if (albumTab.selectedAlbumCount == 0) {
                    toast(getString(R.string.PleaseSelectAlbum))
                } else {
                    showDeleteDialog(getSelectedMedia())
                }
            } else if (binding.viewPager.currentItem == 1) {
                if (photosTab.selectedPhotosCount == 0) {
                    toast(getString(R.string.PleaseSelectImage))
                } else {
                    showDeleteDialog(getSelectedMedia())
                }
            }
        }


        binding.btnFavorite.setOnClickListener {
            favoriteClick()
        }

        binding.btnHide.setOnClickListener {
            if (binding.viewPager.currentItem == 0) {
//                val selectedItem = getSelectedAlbum()
                if (albumTab.selectedAlbumCount == 0) {
                    toast(getString(R.string.PleaseSelectAlbum))
                } else {
                    showHideDialog(getSelectedMedia())
                }
            } else if (binding.viewPager.currentItem == 1) {
//                val selectedItem = getSelectedPhotos()
                if (photosTab.selectedPhotosCount == 0) {
                    toast(getString(R.string.PleaseSelectImage))
                } else {
                    showHideDialog(getSelectedMedia())
                }
            }
        }

        binding.btnMore.setOnClickListener {
            showDropDown(binding.btnMore)
        }

    }


//    private fun closeDrawer() {
//        if (binding.drawerLay.isDrawerOpen(GravityCompat.START)) {
//            binding.drawerLay.closeDrawer(GravityCompat.START)
//        }
//    }

//    private fun intDrawerListener() {
//        binding.drawerContent.llDwHome.setOnClickListener {
//            closeDrawer()
//            binding.viewPager.currentItem = 0
//        }
//        binding.drawerContent.llDwFavourite.setOnClickListener {
//            closeDrawer()
//            startActivity(Intent(this, FavoritesListActivity::class.java))
//            getAlbumListForSelect()
//
//        }
//
//        binding.drawerContent.llDwPrivate.setOnClickListener {
//            closeDrawer()
//            val intent = Intent(this, LockActivity::class.java)
//            lockActivityResultLauncher.launch(intent)
//        }
//        binding.drawerContent.llDwRecentlyDelete.setOnClickListener {
//            startActivity(Intent(this, RecentlyDeleteActivity::class.java))
//            closeDrawer()
//            getAlbumListForSelect()
//        }
//        binding.drawerContent.llMaps.setOnClickListener {
//            startActivity(Intent(this, LocationAlbumActivity::class.java))
//        }
//        binding.drawerContent.llNote.setOnClickListener {
//            startActivity(Intent(this, NotesActivity::class.java))
//        }
////        binding.drawerContent.llBrowser.setOnClickListener {
////            startActivity(Intent(this, WebBrowserActivity::class.java))
////        }
////        binding.drawerContent.llHidden.setOnClickListener {
////            val intent = Intent(this, LockActivity::class.java)
////            lockActivityResultLauncher.launch(intent)
////        }
//        binding.drawerContent.llTimeLine.setOnClickListener {
//            startActivity(Intent(this, TimeLineActivity::class.java))
//        }
//        binding.drawerContent.llPdf.setOnClickListener {
//            val intent = Intent(this, SelectImageActivity::class.java)
//            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_PDF)
//            intent.putExtra(Constant.EXTRA_INCLUDE_VIDEO, false)
//            startActivity(intent)
//        }
//        binding.drawerContent.llDwDuplicate.setOnClickListener {
//            startActivity(Intent(this, StorageScanActivity::class.java))
//            closeDrawer()
//        }
//        binding.drawerContent.llDwTheme.setOnClickListener {
////            val themeDialog = ThemeDialog(updateListener = {
////                val intent = Intent(this, HomeActivity::class.java)
////                finish()
////                overridePendingTransition(0, 0)
////                startActivity(intent)
////                overridePendingTransition(0, 0)
////            })
////            themeDialog.show(supportFragmentManager, themeDialog.tag)
////            closeDrawer()
//        }
//        binding.drawerContent.llDwSetting.setOnClickListener {
//            settingLauncher.launch(Intent(this, SettingActivity::class.java))
//            closeDrawer()
//        }
//        binding.drawerContent.llDwLanguage.setOnClickListener {
//            languageLauncher.launch(Intent(this, LanguageSelectionActivity::class.java))
//            closeDrawer()
//        }
//        binding.drawerContent.llFeedbackSuggestions.setOnClickListener {
//            closeDrawer()
//            sendEmail("makavanavivek304@gmail.com", "GalleryApp Feedback/Suggestion", "Message:\n")
//        }
//        binding.drawerContent.llShare.setOnClickListener {
//            closeDrawer()
//            try {
//                val sendIntent = Intent()
//                sendIntent.action = Intent.ACTION_SEND
//                sendIntent.putExtra(
//                    Intent.EXTRA_TEXT,
//                    "Check out the App at: https://play.google.com/store/apps/details?id=$packageName"
//                )
//                sendIntent.type = "text/plain"
//                startActivity(sendIntent)
//            } catch (e: Exception) {
//
//            }
//        }
//        binding.drawerContent.llRateUs.setOnClickListener {
//            closeDrawer()
//            launchAppStore()
//        }
//        binding.drawerContent.llDwPrivacyPolicy.setOnClickListener {
//            openPrivacyPolicy()
//            closeDrawer()
//        }
//    }

    private fun launchAppStore() {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${packageName}")
        )
        startActivity(intent)
    }


    var languageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val intent = intent
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
            }
        }


    fun showPermissionDeniedDialog(dialogTitle: String, dialogMsg: String) {
        try {
            val simpleMessageDialog =
                SimpleMessageDialog(this@HomeActivity, dialogTitle, dialogMsg, {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    val uri = Uri.fromParts("package", packageName, null)
                    intent.data = uri
                    startActivity(intent)
                }, {
//            finishAffinity()
                })
            simpleMessageDialog.setCancelable(false)
            simpleMessageDialog.show()
        } catch (e: Exception) {
        }
    }

    private fun initPhotoListener() {
//        binding.photosTab.swipeRefreshPhotos.setOnRefreshListener {
//            if (binding.photosTab.swipeRefreshPhotos.isEnabled) getData()
//            else
//                this@HomeActivity.runOnUiThread {
//                    //binding.photosTab.swipeRefreshPhotos.isRefreshing = false
//                    binding.photosTab.refreshPhotos.beGone()
//                }
//        }
        binding.photosTab.ivScrollTopPhotos.setOnClickListener {
//            binding.pictureRecycler.smoothScrollToPosition(0)
            binding.photosTab.pictureRecycler.scrollToPosition(0)
            binding.photosTab.ivScrollTopPhotos.beGone()
//            binding.pictureRecycler.smoothScrollBy()
        }
        binding.photosTab.root.doOnPreDraw {
            binding.photosTab.pictureRecycler.addOnScrollListener(object :
                RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    val firstPositon =
                        (binding.photosTab.pictureRecycler.layoutManager as MyGridLayoutManager).findFirstVisibleItemPosition()
                    binding.photosTab.ivScrollTopPhotos.beVisibleIf(firstPositon > 3)

//                    if (firstPositon > 0) {
////                        setBubbleText(pictureAdapter?.getBubbleText(firstPositon)!!)
//                        val str = pictureAdapter?.getBubbleText(firstPositon)!!
//                        if (str.isNotEmpty()) binding.photosTab.photosBubbleText.text = str
//                        binding.photosTab.photosBubble.beVisible()
//                    } else {
//                        binding.photosTab.photosBubble.beGone()
//                    }
                }
            })
        }
    }

    private fun initAlbumListener() {
//        binding.albumTab.swipeRefreshAlbum.setOnRefreshListener {
//            if (binding.albumTab.swipeRefreshAlbum.isEnabled) getData()
//            else
//                this@HomeActivity.runOnUiThread {
//                    binding.albumTab.swipeRefreshAlbum.isRefreshing = false
//                }
//        }
//        binding.albumTab.ivScrollTopAlbum.setOnClickListener {
//            binding.albumTab.albumRecycler.scrollToPosition(0)
//            binding.albumTab.ivScrollTopAlbum.beGone()
//        }
//        binding.albumTab.root.doOnPreDraw {
//            binding.albumTab.albumRecycler.addOnScrollListener(object :
//                RecyclerView.OnScrollListener() {
//                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
//                    val firstPositon =
//                        (binding.albumTab.albumRecycler.layoutManager as MyGridLayoutManager).findFirstVisibleItemPosition()
//                    binding.albumTab.ivScrollTopAlbum.beVisibleIf(firstPositon > 3)
//
//                }
//            })
//        }
    }

    private fun initExploreListener() {

//        binding.exploreTab.mapFull.setOnClickListener {
//            val intent = Intent(this@HomeActivity, MapExploreActivity::class.java)
//            intent.putExtra("pos", 0)
//            startActivity(intent)
////            startActivity(Intent(activity, MapActivity::class.java))
//        }
//        binding.exploreTab.cardPeople.setOnClickListener {
//
//            val intent = Intent(this@HomeActivity, MapExploreActivity::class.java)
//            intent.putExtra("pos", 1)
//            startActivity(intent)
//        }
//
//        binding.exploreTab.llHidden.setOnClickListener {
//            val intent = Intent(this@HomeActivity, LockActivity::class.java)
////            intent.putExtra(Constant.EXTRA_IS_OPEN_PRIVATE, true)
////            startActivity(intent)
//            lockActivityResultLauncher.launch(intent)
//        }
//
//
//        binding.exploreTab.llRecover.setOnClickListener {
//            val intent = Intent(this@HomeActivity, RecoverMediaActivity::class.java)
//            startActivity(intent)
//        }
//        binding.exploreTab.llRecycle.setOnClickListener {
//            val intent = Intent(this@HomeActivity, RecentlyDeleteActivity::class.java)
//            recycleLauncher.launch(intent)
//        }
//        binding.exploreTab.txtCleanCount.text = preferences.strCleanCount
//        if (preferences.isNeedCleaner) {
//            binding.exploreTab.hintClean.beVisible()
//        }
//        binding.exploreTab.llCleaner.setOnClickListener {
//            preferences.isNeedCleaner = false
//            startActivity(Intent(this@HomeActivity, JunkScanActivity::class.java))
//        }
//        binding.exploreTab.mCVSuggestion.setOnClickListener {
//            startActivity(Intent(this@HomeActivity, FeedbackActivity::class.java))
//        }
    }

    var lockActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        Log.e("POST_NOTIFICATIONS", "lockActivityResultLauncher:${result.resultCode}")
        if (result.resultCode == RESULT_OK) {
            val intent = Intent(this@HomeActivity, PrivateActivity::class.java)
            privateActivityResultLauncher.launch(intent)
        }
    }
    var privateActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
//        if (result.resultCode == AppCompatActivity.RESULT_OK) {
//            val intent=Intent(getRequireActivity(), PrivateActivity::class.java)
//            startActivity(intent)

//        Constant.isReCreateHomeSS = true
//        val intent = getRequireActivity().intent
//        getRequireActivity().finish()
//        getRequireActivity().overridePendingTransition(0, 0)
//        startActivity(intent!!)
//        getRequireActivity().overridePendingTransition(0, 0)
//        Constant.isChangeLanguage = false
//        }
    }

    private fun showHideDialog(selectImage: ArrayList<MediaData>) {
//        requestStoragePermission(app_private_AFA_allow_nf, app_private_AFA_denied_nf, getActivityName()) {
//            if (it) {
        val hideDialog =
            ActionConfirmationDialog(
                this@HomeActivity,
                getString(R.string.Private),
                getString(R.string.hide_msg),
                getString(R.string.hide),
                positiveBtnClickListener = {
                    hidePhoto(selectImage)
                })
        hideDialog.show()
//            }
//        }
    }

    private fun hidePhoto(selectImage: ArrayList<MediaData>) {
//        val selectImage = mutableSetOf<MediaData>() // Use a set to avoid duplicates
//        val selectedAlbum = ArrayList<AlbumData>()
//        val selectFolder: ArrayList<String> = ArrayList()

//        albumList.filter { it.isSelected }.forEach { album ->
//            selectFolder.add(album.folderPath)
//            selectedAlbum.add(album) // Add selected album
//            album.mediaData.forEach { picture ->
//                if (picture is MediaData) {
//                    selectImage.add(picture) // Add MediaData to the set (duplicates automatically avoided)
//                }
//            }
//        }

//        pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
//            .filter { it.isSelected } // Filter selected MediaData objects
//            .forEach { selectImage.add(it) } // Add to the set

//        val uniqueSelectImage = ArrayList(selectImage)

        Utils.hideFiles(
            this@HomeActivity,
            selectImage,
            selectImage.size,
            hideListener = { deleteList ->
                toast(getString(R.string.hide_successfully))
//            for (folder in selectFolder) {
//                val files = File(folder).listFiles()
//                if (files.isNullOrEmpty()) {
//                    File(folder).delete()
//                }
//            }
                MediaScannerConnection.scanFile(
                    this, deleteList.toTypedArray(), null
                ) { path: String?, uri: Uri? -> }

                longClickListener(false, 0, false)
                setCloseToolbar()
                refreshData()
            })
    }

    private fun showDeleteDialog(selectImage: ArrayList<MediaData>) {
//        requestStoragePermission(app_delete_AFA_allow_nf, app_delete_AFA_denied_nf, getActivityName()) {
//            if (it) {
        val deleteDialog = DeleteDialog.newInstance(this@HomeActivity, btnClickListener = {
            deletePhoto(selectImage, it)
        })
        deleteDialog.show()
//            }
//        }
    }

    private fun deletePhoto(selectImage: ArrayList<MediaData>, isPermanent: Boolean) {

        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            this,
            R.drawable.ic_drawer_delete,
            selectImage.size,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()

        preferences.refreshMedia = true
        preferences.scanMedia = true

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            selectImage.forEach { model ->
                val isDelete = Utils.deleteFile(this, model.filePath, dataBase, isPermanent)
                MediaScannerConnection.scanFile(
                    this,
                    arrayOf<String>(model.filePath),
                    null
                ) { path: String?, uri: Uri? -> }
                if (isDelete) {
                    deleteList.add(model.filePath)
                    runOnUiThread {
                        progressDialog.setProgress(deleteList.size, selectImage.size)
                    }
                }
            }

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    try {
                        if (progressDialog != null
                            && progressDialog.isShowing
                            && !isFinishing
                            && !isDestroyed
                        )
                            progressDialog.dismiss()
                    } catch (e: Exception) {
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    try {
                        if (progressDialog != null
                            && progressDialog.isShowing
                            && !isFinishing
                            && !isDestroyed
                        )
                            progressDialog.dismiss()
                    } catch (e: Exception) {
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun deletePhotos(selectImage: ArrayList<MediaData>, isPermanent: Boolean) {
        preferences.refreshMedia = true
        preferences.scanMedia = true

        Utils.deleteFiles(this@HomeActivity, selectImage, isPermanent) { deleteList ->
            setBeforeDeleteUpdate(deleteList)
        }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {

        photosTab.selectedPhotosCount = 0
        albumTab.selectedAlbumCount = 0
//        enableScroll()
        binding.albumTab.swipeRefreshAlbum.isEnabled = true
        binding.photosTab.swipeRefreshPhotos.isEnabled = true
        setCloseToolbar()
//        longClickListener(false, 0, false)
        toast(getString(R.string.Delete_successfully))
        deleteMainList(deleteList)

        photosTab.notifyAdapter()
        albumTab.notifyAdapter()
        albumTab.setEmptyAlbum()
        photosTab.setEmptyPhoto()
//        runOnUiThread {
//            runOnUiThread {
//                val countRecycle = dataBase.dataDao().getCountDelete()
//                binding.exploreTab.txtRecycleCount.text = "$countRecycle"
//            }
//        }
        refreshData()
    }


    private fun deleteMainList(deleteList: ArrayList<String>) {
//        if (deleteList.size > 0) {
//            allList.removeAll {
//                deleteList.contains(it.filePath)
//            }
//        }
//
//        if (deleteList.size != 0) {
//            for (path in deleteList) {
//                for (pictureData in albumList) {
//                    if (pictureData.folderPath == path) {
//                        albumList.remove(pictureData)
//                        break
//                    }
//                }
//            }
//        }
    }

    private fun shareImages() {
        ensureBackgroundThread {
            val uris = ArrayList<Uri>()
            for (i in pictures.indices) {
                if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    if (model.isSelected) {
                        val uri = FileProvider.getUriForFile(
                            this@HomeActivity,
                            packageName + ".provider",
                            File(model.filePath)
                        )
                        uris.add(uri)
                    }
                }
            }
            runOnUiThread {
                Utils.shareFilesList(this@HomeActivity, uris)
            }
        }
    }

    private fun setPhotosSelect(isSelectAll: Boolean) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                    }
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        albumTab.notifyAdapter()
        photosTab.notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        photosTab.selectedPhotosCount = selected

    }




    private fun setAlbumSelect(isSelectAll: Boolean) {

        var selected = 0
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i] is AlbumData) {
                    val model = albumList[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                        if (isSelectAll) selected++
                    }
                }
        }
        photosTab.notifyAdapter()
        albumTab.notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        albumTab.selectedAlbumCount = selected
    }

    private fun favoriteClick() {
        var needToAddFav = false
        var needToRemoveFav = false

        if (binding.viewPager.currentItem == 1) {
            val selectedItem = getSelectedPhotos()
            for (i in selectedItem.indices) {
                val model: MediaData = selectedItem[i] as MediaData
                if (model.isFavorite)
                    needToRemoveFav = true
                else
                    needToAddFav = true
            }
        }


        if(needToAddFav) {
            if (binding.viewPager.currentItem == 1) setFavorite(true)
        }else{
            if (binding.viewPager.currentItem == 1) setFavorite(false)
        }

    }

    private fun showDropDown(view: View) {

        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)

        val popupWindow = PopupWindowHelper(popUpBinding.root)

//        popUpBinding.menuRename.beVisibleIf(mSelectedItem == 1)
//        popUpBinding.menuCover.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 0)
        //popUpBinding.menuExclude.beVisibleIf(binding.viewPager.currentItem == 0)

//        popUpBinding.menuLock.beVisibleIf(binding.viewPager.currentItem == 0)
        popUpBinding.llMain.beVisible()
//        popUpBinding.llCover.beGone()

        var needToAddFav = false
        var needToRemoveFav = false
        var videoSelected = false

        if (binding.viewPager.currentItem == 1) {
            val selectedItem = getSelectedPhotos()
            for (i in selectedItem.indices) {
                val model: MediaData = selectedItem[i] as MediaData
                if (model.isVideo || model.filePath.isGif()) videoSelected = true
                if (model.isFavorite)
                    needToRemoveFav = true
                else
                    needToAddFav = true
            }
        }

        popUpBinding.menuEdit.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 1 && !videoSelected)
        popUpBinding.menuSetAs.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 1 && !videoSelected)
//        popUpBinding.menuResize.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 1 && !videoSelected)
        popUpBinding.menuRename.beVisibleIf(mSelectedItem == 1)
        popUpBinding.menuPdf.beVisibleIf(binding.viewPager.currentItem == 1 && !videoSelected)

//        popUpBinding.menuAddFavourite.beVisibleIf(needToAddFav)
//        popUpBinding.menuRemoveFavourite.beVisibleIf(needToRemoveFav)

//        popUpBinding.menuInfo.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 1)
        popUpBinding.menuInfo.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem != 2)

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }
        popUpBinding.menuPdf.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) {
                if (albumTab.selectedAlbumCount == 0) {
                    toast(getString(R.string.PleaseSelectAlbum))
                } else {
                    val selectImage = ArrayList<MediaData>()
                    albumList.filter { it.isSelected }.forEach { album ->
                        album.mediaData.forEach { picture ->
                            if (picture is MediaData) {
                                selectImage.add(picture)
                            }
                        }
                    }
                    Utils.generatePdf(this@HomeActivity, selectImage)
                }
            } else if (binding.viewPager.currentItem == 1) {
                if (photosTab.selectedPhotosCount == 0) {
                    toast(getString(R.string.PleaseSelectImage))
                } else {
                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                    pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                        .filter { it.isSelected } // Filter selected MediaData objects
                        .forEach { selectImage.add(it) } // Add to the set

                    Utils.generatePdf(this@HomeActivity, selectImage)
                }
            }

//            val intent = Intent(this@HomeActivity, SelectImageActivity::class.java)
//            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_PDF)
//            intent.putExtra(Constant.EXTRA_INCLUDE_VIDEO, false)
//            createPdfLauncher.launch(intent)
        }

        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) {
                if (mSelectedItem == 1) {
                    showAlbumRenameDialog()
                }
            } else if (binding.viewPager.currentItem == 1) {
                if (mSelectedItem == 1) {
//                    requestStoragePermission(app_rename_AFA_allow_nf, app_rename_AFA_denied_nf, getActivityName()) {
//                        if (it) {
                    showMediaRenameDialog()
//                        }
//                    }
                }
            }
        }

//        popUpBinding.menuCover.setOnClickListener {
////            popupWindow.dismiss()
//            popUpBinding.llMain.beGone()
//            popUpBinding.llCover.beVisible()
//            popupWindow.dismiss()
//            popupWindow.showAsPopUp(view)
//        }

//        popUpBinding.selectPhoto.setOnClickListener {
//            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0)
//                if (mSelectedItem == 1) setCoverImage()
//
//        }
//        popUpBinding.useDefault.setOnClickListener {
//            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0)
//                if (mSelectedItem == 1) setDefaultCoverImage()
//        }

        popUpBinding.menuEdit.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) {
//                requestStoragePermission(app_edit_AFA_allow_nf, app_edit_AFA_denied_nf, getActivityName()) {
//                    if (it) {
                openEditor()
//                    }
//                }
            }

        }

//        var needToLock = false
//        var needToUnLock = false

//        if (binding.viewPager.currentItem == 0) {
//            val selectedItem = albumFragment.getSelected()
//            for (i in selectedItem.indices) {
//                val model: AlbumData = selectedItem[i] as AlbumData
//                if (preferences.isFolderProtected(model.folderPath))
//                    needToUnLock = true
//                else
//                    needToLock = true
//            }
//        }
//
//        popUpBinding.menuLock.beVisibleIf(needToLock)
//        popUpBinding.menuUnlock.beVisibleIf(needToUnLock)

//        popUpBinding.menuLock.setOnClickListener {
//            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0) albumFragment.tryLockFolder()
//        }
//        popUpBinding.menuUnlock.setOnClickListener {
//            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0) albumFragment.tryUnLockFolder()
//        }

        popUpBinding.menuSetAs.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) setAs()
        }

//        popUpBinding.menuResize.setOnClickListener {
//            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 1) showResizeDialog()
//        }

//        popUpBinding.menuExclude.setOnClickListener {
//            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0) {
//                if (!preferences.hintExclude) {
//                    val hintDialog = AnimHintDialog(
//                        this@HomeActivity,
//                        getString(R.string.hint_exclude_msg),
//                        R.drawable.hint_exclude_anim,
//                        updateListener = { btnClicked, isDontShowChecked ->
//                            preferences.hintExclude = isDontShowChecked
//                            if (btnClicked == 1) {
//                                addToExclude()
//                            }
//
//                        })
//                    hintDialog.show()
//                } else {
//                    addToExclude()
//                }
//            }
//        }

//        popUpBinding.menuAddFavourite.setOnClickListener {
//            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 1) setFavorite(true)
//
//        }
//
//        popUpBinding.menuRemoveFavourite.setOnClickListener {
//            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 1) setFavorite(false)
//        }

        popUpBinding.menuInfo.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) showAlbumDetailDialog()
            if (binding.viewPager.currentItem == 1) showMediaDetailsDialog()
        }

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) {
                if (albumTab.selectedAlbumCount == 0) {
                    toast(getString(R.string.PleaseSelectAlbum))
                } else {
                    val selectedAlbum = ArrayList<String>()
                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                    albumList.filter { it.isSelected }.forEach { album ->
                        selectedAlbum.add(album.folderPath) // Add selected album
                        album.mediaData.forEach { picture ->
                            if (picture is MediaData) {
                                selectImage.add(picture) // Add MediaData to the set (duplicates automatically avoided)
                            }
                        }
                    }
                    showAddAlbumDialog(
                        Constant.deviceAlbumList,
                        selectImage,
                        selectedAlbum,
                        true
                    )


                }
            } else if (binding.viewPager.currentItem == 1) {
                if (photosTab.selectedPhotosCount == 0) {
                    toast(getString(R.string.PleaseSelectImage))
                } else {
                    val selectedAlbum = ArrayList<String>()
                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                    pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                        .filter { it.isSelected } // Filter selected MediaData objects
                        .forEach { selectImage.add(it) } // Add to the set
                    showAddAlbumDialog(
                        Constant.deviceAlbumList,
                        selectImage,
                        selectedAlbum,
                        true
                    )
                }
            }
        }

        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) {
                if (albumTab.selectedAlbumCount == 0) {
                    toast(getString(R.string.PleaseSelectAlbum))
                } else {
//                    requestStoragePermission(app_move_to_AFA_allow_nf, app_move_to_AFA_denied_nf, getActivityName()) {
//                        if (it) {

                    val selectedAlbum = ArrayList<String>()
                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                    albumList.filter { it.isSelected }.forEach { album ->
                        selectedAlbum.add(album.folderPath) // Add selected album
                        album.mediaData.forEach { picture ->
                            if (picture is MediaData) {
                                selectImage.add(picture) // Add MediaData to the set (duplicates automatically avoided)
                            }
                        }
                    }
                    showAddAlbumDialog(
                        albumList.filter { it.isCustomAlbum == false } as ArrayList<AlbumData>,
                        selectImage,
                        selectedAlbum,
                        false
                    )
//                        }
//                    }
                }
            } else if (binding.viewPager.currentItem == 1) {
                if (photosTab.selectedPhotosCount == 0) {
                    toast(getString(R.string.PleaseSelectImage))
                } else {
//                    requestStoragePermission(app_move_to_AFA_allow_nf, app_move_to_AFA_denied_nf, getActivityName()) {
//                        if (it) {

                    val selectedAlbum = ArrayList<String>()
                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                    pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                        .filter { it.isSelected } // Filter selected MediaData objects
                        .forEach { selectImage.add(it) } // Add to the set
                    showAddAlbumDialog(
                        albumList.filter { it.isCustomAlbum == false } as ArrayList<AlbumData>,
                        selectImage,
                        selectedAlbum,
                        false
                    )
//                        }
//                    }
                }
            }
        }

        popupWindow.showAsPopUp(view)

    }

    private fun openEditor() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    selectImage.add(model)
                }
            }
        }

        if (selectImage.isNotEmpty()) {
            val path = selectImage[0].filePath
            val newPath = path.removePrefix("file://")
            openEditorIntent(newPath)
        } else {
            toast(getString(R.string.PleaseSelectImage))
        }
    }

//    private fun setDefaultCoverImage() {
//        try {
//            val albumData = albumList.firstOrNull { it.isSelected }
//            preferences.setCoverImage(albumData!!.folderPath, "")
//            setCloseToolbar()
//            refreshData()
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//    }

//    private fun setCoverImage() {
//        try {
//            val albumData = albumList.firstOrNull { it.isSelected }
//            albumData?.let {
//                val addAlbumDialog = SelectAlbumImageFullDialog(
//                    this@HomeActivity,
//                    it.mediaData,
//                    selectPathListener = { selectPath ->
//                        preferences.setCoverImage(albumData.folderPath, selectPath)
//                        //setCopyMove(isCopy, selectPath, selectImage)
//                        setCloseToolbar()
//                        refreshData()
//                    },
//                    createAlbumListener = {
//
//                    })
//                addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)
//            }
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//
//    }


    private fun showAddAlbumDialog(
        albums: ArrayList<AlbumData>,
        selectedMedia: ArrayList<MediaData>,
        selectedAlbum: ArrayList<String>,
//        selectedAlbum: ArrayList<AlbumData>,
        isCopy: Boolean
    ) {

        val uniqueSelectImage = ArrayList(selectedMedia.distinctBy { it.filePath })

        for (media in uniqueSelectImage) {
            Log.e("uniqueSelectImage", "uniqueSelectImage-->:${media.filePath}")
        }

//        val addAlbumDialog =
//            SelectAlbumFullDialog(
//                this@HomeActivity,
//                albums,
//                selectedAlbum,
//                isCopy,
//                selectPathListener = { selectPath ->
//                    setCopyMove(isCopy, selectPath, uniqueSelectImage)
//                },
//                createAlbumListener = {
////                    requestStoragePermission(app_create_album_AFA_allow_nf, app_create_album_AFA_denied_nf, getActivityName()) { value ->
////                        if (value) {
//                    val createDialog = CreateAlbumDialog(this@HomeActivity, createPathListener = {
//                        setCopyMove(isCopy, it, uniqueSelectImage)
//                    })
//                    createDialog.show()
////                        }
////                    }
//                })
//        addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)

        isCopyForResult = isCopy
        selectImageForResult = uniqueSelectImage
        val selectAlbumIntent = Intent(this, AlbumSelectorActivity::class.java)
        selectAlbumIntent.putExtra("selectedAlbum", selectedAlbum)
        selectAlbumIntent.putExtra("isCopy", isCopy)
        addAlbumLauncher.launch(selectAlbumIntent)

    }

    private var isCopyForResult: Boolean = false
    private lateinit var selectImageForResult: ArrayList<MediaData>
    private val addAlbumLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val data = result.data
                when (data?.getStringExtra("action")) {
                    "create" -> {
                        val createDialog = CreateAlbumDialog(this, createPathListener = { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        })
                        createDialog.show()
                    }

                    else -> {
                        data?.getStringExtra("selectedPath")?.let { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        }
                    }
                }
            }
        }

    private fun setCopyMove(
        isCopy: Boolean, selectPath: String, selectImage: java.util.ArrayList<MediaData>,
    ) {
        Log.e("newAlbum", "setCopyMove:$selectPath")
        if (isCopy) {
            Utils.copyFiles(
                this@HomeActivity,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {
                    toast(getString(R.string.copy_successfully))
//                        MediaScannerConnection.scanFile(it, arrayOf<String>(selectPath), null) { path, uri -> }
                    albumTab.selectedAlbumCount = 0
//                getData()
//                longClickListener(false, 0, false)
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
                    refresh()
//                        Handler(Looper.getMainLooper()).postDelayed({
//                        setCloseToolbar()
//                        }, 500)

//                        Handler(Looper.getMainLooper()).postDelayed({
//                            sendEvent("refresh")
//                        }, 500)
                })
        } else {
            Utils.moveFiles(
                this@HomeActivity,
                selectPath,
                selectImage,
                selectImage.size,
                moveListener = {
//                    MediaScannerConnection.scanFile(it, arrayOf<String>(selectPath), null) { path, uri -> }
                    toast(getString(R.string.move_successfully))
                    albumTab.selectedAlbumCount = 0
//            getData()
//            longClickListener(false, 0, false)
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
//                    Handler(Looper.getMainLooper()).postDelayed({
                    refresh()
//                    }, 500)
                })
        }

    }

    private fun showAlbumDetailDialog() {
        try {
            val albumData = albumList.filter { it.isSelected }
            val detailsDialog = AlbumDetailsDialog(this, albumData[0], false)
            detailsDialog.show()
        } catch (e: IndexOutOfBoundsException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showMediaDetailsDialog() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    selectImage.add(model)
                }
            }
        }

        if (selectImage.isNotEmpty()) {
            val pictureData = selectImage[0]

            val detailsDialog = DetailsDialog(this@HomeActivity, pictureData, false)
            detailsDialog.show()
        } else {
            toast(getString(R.string.PleaseSelectImage))
        }

    }

    private fun setFavorite(isFavorite: Boolean) {
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())

        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    if (isFavorite) {
                        if (!favList.contains(model.filePath)) favList.add(model.filePath)
                    } else {
                        if (favList.contains(model.filePath)) favList.remove(model.filePath)
                    }
                }
            }
        }
        preferences.setFavoriteList(favList)
//        preferences.refreshMedia=true

        runOnUiThread {
            setCloseToolbar()
            refreshData()
//            updateData()
        }
    }

    private fun showAlbumRenameDialog() {
        Log.e("AlbumRenameDialog", "albumList.size:${albumList.size}")
        val albumData = albumList.firstOrNull { it.isSelected }
        if (albumData != null) {
            val renameDialog = FolderRenameDialog(
                this,
                albumData,
                positiveBtnClickListener = { renamePath, oldPath ->
                    Log.e(
                        "AlbumRenameDialog",
                        "albumList.renamePath:${renamePath},oldPath:$oldPath,albumData:${albumData.folderPath}"
                    )
                    try {
                        try {
                            scanPathRecursively(albumData.folderPath) {}
                        } catch (e: Exception) {
                        }
                        albumList.removeAll { it.folderPath == albumData.folderPath }
                        Log.e("AlbumRenameDialog", "albumList.size:${albumList.size}")
                    } catch (e: Exception) {
                        Log.e("AlbumRenameDialog", "albumList.Exception:${e}")
                    }
                    runOnUiThread {
//                        MediaScannerConnection.scanFile(this, arrayOf<String>(oldPath), null) { path, uri -> }
                        setClose()
                        setToolbarSelectionMaintain(false, 0, false)
//                        setCloseToolbar()
                        refreshData()
                    }
                })
            renameDialog.show()
        }
    }

    private fun showMediaRenameDialog() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    selectImage.add(model)
                }
            }
        }

        if (selectImage.isNotEmpty()) {
            val pictureData = selectImage[0]
            val renameDialog =
                FileRenameDialog(
                    this,
                    pictureData,
                    positiveBtnClickListener = { renamePath, oldPath ->
//                        sendEvent("rename")
                        MediaScannerConnection.scanFile(
                            this,
                            arrayOf<String>(oldPath),
                            null
                        ) { path, uri -> }
                        MediaScannerConnection.scanFile(
                            this,
                            arrayOf<String>(renamePath),
                            null
                        ) { path, uri -> }
                        runOnUiThread {
                            albumTab.notifyAdapter()
                            photosTab.notifyAdapter()
//                        MediaScannerConnection.scanFile(this, arrayOf<String>(oldPath), null) { path, uri -> }
                            setClose()
                            setToolbarSelectionMaintain(false, 0, false)
//                        setCloseToolbar()
                            refreshData()
                        }
                    })

            renameDialog.show()
        } else {
            toast(getString(R.string.PleaseSelectImage))
        }
    }

//    private fun initSearchAdapter() {
//        timeLineAdapter = TimeLineAdapter(this, clickListener = { albumData ->
//            openCutomImageList(albumData)
//        })
//        timeLineAdapter?.submitList(timeList)
////        binding.searchTab.timeLineRecycler.layoutManager =
////            GridLayoutManager(this, 1, GridLayoutManager.HORIZONTAL, false)
//        binding.searchTab.timeLineRecycler.setHasFixedSize(false)
//        binding.searchTab.timeLineRecycler.adapter = timeLineAdapter
//    }


    fun setSelectionEnable() {
        if (binding.viewPager.currentItem == 1) {
            photosTab.setSelectionEnable()
//            for (i in pictures.indices) {
//                if (pictures[i] != null)
//                    if (pictures[i] is AlbumData) {
//                        val model = pictures[i] as AlbumData
//                        model.isCheckboxVisible = true
//                    } else if (pictures[i] is MediaData) {
//                        val model = pictures[i] as MediaData
//                        model.isCheckboxVisible = true
//                    }
//            }
//            notifyAdapter()
//            setSelectedMedia()
        } else if (binding.viewPager.currentItem == 0) {
            albumTab.setSelectionEnable()
//            for (i in albumList.indices) {
//                val model = albumList[i] as AlbumData
//                model.isCheckboxVisible = true
//            }
//            notifyAdapter()
//            setSelectedAlbum()
        }
    }


    private fun refresh() {
        preferences.refreshMedia = true
        setCloseToolbar()
        refreshData()
//        Handler(Looper.getMainLooper()).postDelayed({
//        sendEvent("refresh")
//        }, 500)
    }

//    private fun addToExclude() {
//        val albumData = albumList.filter { it.isSelected }
//        val excludeList: ArrayList<String> = ArrayList()
//        preferences.getExcludeList().let { excludeList.addAll(it) }
//        for (i in albumData.indices) {
//            if (albumData[i] is AlbumData) {
//                val model = albumData[i] as AlbumData
//                if (model.isSelected && model.folderPath.isNotEmpty()) {
//                    if (!excludeList.contains(model.folderPath)) excludeList.add(model.folderPath)
//                }
//            }
//        }
//        preferences.setExcludeList(excludeList)
//        preferences.refreshMedia = true
//
//        setCloseToolbar()
//        refreshData()
//    }

    private fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)

    }

    private fun setClose() {
        Log.e("", "setClose==>> pictures size ${pictures.size} ")
        albumList.forEach { item ->
            if (item is AlbumData) {
                item.isSelected = false
                item.isCheckboxVisible = false
            }
        }
        pictures.forEach { item ->
            when (item) {
                is AlbumData -> {
                    item.isSelected = false
                    item.isCheckboxVisible = false
                }

                is MediaData -> {
                    item.isSelected = false
                    item.isCheckboxVisible = false
                }
            }
        }
        binding.photosTab.swipeRefreshPhotos.isEnabled = true
        binding.albumTab.swipeRefreshAlbum.isEnabled = true
        albumTab.notifyAdapter()
        photosTab.notifyAdapter()
        setRvLayoutManager()
        photosTab.selectedPhotosCount = 0
    }

//    private fun showResizeDialog() {
//        val selectImage: ArrayList<MediaData> = ArrayList()
//        for (i in pictures.indices) {
//            if (pictures[i] is MediaData) {
//                val model: MediaData = pictures[i] as MediaData
//                if (model.isSelected) {
//                    selectImage.add(model)
//                }
//            }
//        }
//
//        if (selectImage.isNotEmpty()) {
//            val pictureData = selectImage[0]
//            val resizeDialog =
//                ResizeDialog(
//                    this,
//                    pictureData,
//                    updateImageListener = { path ->
//                        val file = File(path)
//                        pictures.add(0,
//                            MediaData(path,
//                                Utils.getUriFromPath(this@HomeActivity,path).toString(),
//                                file.name, file.parent!!, file.lastModified(), file.lastModified(), file.length()))
//                    })
//            resizeDialog.show()
//        } else {
//            toast(getString(R.string.PleaseSelectImage))
//        }
//    }

    private fun setAs() {
        val selectImage = pictures.filterIsInstance<MediaData>()
            .filter { it.isSelected }

        val pictureData = selectImage.firstOrNull()
        val intent = Intent(this@HomeActivity, WallpaperSettingsActivity::class.java)
        intent.putExtra(
            Constant.EXTRA_WALL_PAPER,
            pictureData?.filePath
        )
        startActivity(intent)

//        ensureBackgroundThread {
//            val newUri =
//                pictureData?.let { getFinalUriFromPath(it.filePath, BuildConfig.APPLICATION_ID) }
//                    ?: return@ensureBackgroundThread
//            Intent().apply {
//                action = Intent.ACTION_ATTACH_DATA
//                setDataAndType(newUri, getUriMimeType(pictureData.filePath, newUri))
//                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
//                val chooser = Intent.createChooser(this, getString(R.string.set_as))
//
//                try {
//                    startActivityForResult(chooser, 101)
//                } catch (e: ActivityNotFoundException) {
//                    toast(R.string.no_app_found)
//                } catch (e: Exception) {
//                    showErrorToast(e)
//                }
//            }
//        }
    }

    private fun openCamera() {
        try {
            val cameraIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            startActivity(cameraIntent)
            preferences.refreshMedia = true
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
            toast(getString(R.string.not_found))
        }
    }

    var permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            if (checkStoragePermission())
                openCamera()
            else
                requestPermission()
        }


    private fun hideKeyboard(view: EditText) {
        view.clearFocus()
        val methodManager = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun showKeyboard(view: EditText) {
        view.requestFocus()
        val methodManager = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }


    private fun setFilterMenu() {

    }

    private fun showMenu() {
        val dialog = HomeOptionsDialog(this, binding.viewPager.currentItem, clickListener = {
            when (it) {
                1 -> {
                    showSortDialog()
                }

                2 -> {
                    val filterMediaDialog = FilterMediaDialog(this@HomeActivity, updateListener = {
                        getData()
//                        sendEvent("get_data")
                    })
                    filterMediaDialog.show()
                }

                21 -> {
                    setRvLayoutManager()
                }

                22 -> {
                    setRvLayoutManager()
                }

                3 -> {
//                    requestStoragePermission(app_create_album_AFA_allow_nf, app_create_album_AFA_denied_nf, getActivityName()) {
//                        if (it) {
                    showCreateAlbum()
//                        }
//                    }
                }

                4 -> {
                    // displayed Columns
                    val displayColumnsDialog = DisplayedColumnsDialog(
                        this, "",
                        binding.viewPager.currentItem == 0,
                        updateListener = {
                            setRvLayoutManager()
                        })
                    displayColumnsDialog.show()

                }

                5 -> {
                    //btnRecycleBin
                    val intent = Intent(this, RecentlyDeleteActivity::class.java)
                    recycleLauncher.launch(intent)
                }

                6 -> {
                    //btnFamilyApps
                    toast("Coming Soon..")
//                    val i = Intent(Intent.ACTION_VIEW)
//                    i.data = Uri.parse("https://play.google.com/store/apps/developer?id=AppNovate")
//                    startActivity(i)
                    //startActivity(Intent(this, FamilyAppActivity::class.java))
                }

                7 -> {
                    //btnFeedback
//                    val intent = Intent(this, FeedbackActivity::class.java)
//                    startActivity(intent)
                }

                8 -> {
                    //btnSetting
                    settingLauncher.launch(Intent(this, SettingActivity::class.java))
                }

                9 -> {
                    //showGroupByDialog
                    showGroupByDialog()
                }

                10 -> {
                    //allAlbum
                    preferences.allAlbum = !preferences.allAlbum
                    albumTab.getAlbumData()
                }

                11 -> {
                    setSelectionEnable()
                }

            }
        })
        dialog.show()
    }

    var recycleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            getData()
//            sendEvent("get_data")
        }

    private fun showCreateAlbum() {
        val createDialog = CreateAlbumDialog(this, createPathListener = { newAlbum ->
            setCloseToolbar()
            refreshData()
            val intent = Intent(this, SelectImageActivity::class.java)
            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_ALBUM)
            intent.putExtra(Constant.EXTRA_ALBUM_PATH, newAlbum)
            startActivity(intent)
        }, true)
        createDialog.show()
    }

    private fun showSortDialog() {
        val key = "frag_${binding.viewPager.currentItem}"
        val sortDialog = SortingOptionsDialog(this, key, updateListener = {
            getData()
//            sendEvent("get_data")
        })
        sortDialog.show()
    }

    private fun showGroupByDialog() {
        val groupDialog = GroupDialog(this, updateListener = {
            photosTab.setPhotoGroup()
        })
        groupDialog.show()
    }

    private fun checkForceAppUpdate(remoteConfig: FirebaseRemoteConfig) {

        Log.e("checkForceAppUpdate", "checkForceAppUpdate")

        remoteConfig.setConfigSettingsAsync(
            FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(5)
                .setFetchTimeoutInSeconds(5)
                .build()
        )
        remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)

        // Fetch the remote config
        remoteConfig.fetchAndActivate().addOnCompleteListener { task ->
            if (task.isSuccessful) {

//                try {
                val forceUpdate = remoteConfig.getString("force_update")
                Log.e("checkForceAppUpdate", "force_update:$forceUpdate")
                if (forceUpdate.isNotEmpty()) {

                    val jsonForceUpdateObj = JSONObject(forceUpdate)
                    val isNeedToShow = jsonForceUpdateObj.getBoolean("isNeedToShow")
                    val isCancelable = jsonForceUpdateObj.getBoolean("isCancelable")
                    val latestVersion = jsonForceUpdateObj.getString("latest_version")
                    val mainTitle = jsonForceUpdateObj.getString("main_title")
                    val subTitle = jsonForceUpdateObj.getString("sub_title")
                    val displayFromVersion = jsonForceUpdateObj.getInt("display_from_version")
                    val redirectUrl = jsonForceUpdateObj.getString("redirect_url")
                    val btnText = jsonForceUpdateObj.getString("btn_text")

                    val forceUpdateModel = UpdateModel(
                        isNeedToShow = isNeedToShow,
                        isCancelable = isCancelable,
                        latestVersion = latestVersion,
                        mainTitle = mainTitle,
                        subTitle = subTitle,
                        displayFromVersion = displayFromVersion,
                        redirectUrl = redirectUrl,
                        btnText = btnText,
                    )

                    if (isNeedToShow
                        && BuildConfig.VERSION_CODE <= forceUpdateModel.displayFromVersion
                    ) {
                        val updateDialog = UpdateDialog(this, forceUpdateModel)
                        updateDialog.setCancelable(forceUpdateModel.isCancelable)
                        updateDialog.show()

                        updateDialog.setOnDismissListener {

                        }
                    } else {
                        checkInAppUpdate()
                    }
                } else {
                    checkInAppUpdate()
                }

            } else {
                Log.d("checkForceAppUpdate", "Failed:${task.exception}")
                checkInAppUpdate()
            }
        }
    }

    private fun checkInAppUpdate() {
        try {
            appUpdateInstallerManager.addAppUpdateListener(appUpdateInstallerListener)
            appUpdateInstallerManager.startCheckUpdate()
        } catch (e: Exception) {
            Log.e("UpdateListener", "checkAppUpdate.Exception:$e")
        }
    }

    private val appUpdateInstallerManager: AppUpdateInstallerManager by lazy {
        InAppUpdateInstallerManager(this)
    }

    private val appUpdateInstallerListener by lazy {
        object : AppUpdateInstallerListener() {
            override fun onDownloadedButNotInstalled() {
                Log.e("UpdateListener", "onDownloadedButNotInstalled")
                popupSnackBarForCompleteUpdate()
            }

            override fun onFailure(e: Exception) {
                Log.e("UpdateListener", "onFailure:$e")
            }

            override fun onNotUpdate() {
                Log.e("UpdateListener", "onNotUpdate")
            }

            override fun onCancelled() {
                Log.e("UpdateListener", "onCancelled")
            }

            override fun onStatus(@InstallStatus status: Int) {
                Log.e("UpdateListener", "onStatus:$status")
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        appUpdateInstallerManager.onActivityResult(requestCode, resultCode, data)
    }

    private fun popupSnackBarForCompleteUpdate() {
        val snackBar = Snackbar.make(
            findViewById(android.R.id.content),
            "An update has just been downloaded.",
            Snackbar.LENGTH_INDEFINITE
        )
        snackBar.setAction("RESTART") { appUpdateInstallerManager.completeUpdate() }
        snackBar.setActionTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
        snackBar.show()
    }

    override fun onBackPressed() {
        Log.e(
            "onBackPressed",
            "preferences.appOpenCounter.onBackPressed:${preferences.sessionCounter}"
        )
        Log.e("onBackPressed", "onBackPressed.002")
        if (binding.viewPager.currentItem == 1 && binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
            //refreshData()
        } else if (binding.viewPager.currentItem == 0 && binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
            //refreshData()
        } else if (binding.viewPager.currentItem != 0) {
            binding.viewPager.currentItem = 0
        } else {
            showExitDialog()
        }
//        }
    }

    private fun showExitDialog() {
        val exitDialog = ExitConfirmationDialog(this) { isExit ->
            if (isExit) {
                finishAffinity()
            }
        }
        if (!exitDialog.isShowing) {
            Log.e("onBackPressed", "onBackPressed.006")
            exitDialog.show()
        }
    }

}