package com.saveit.whmedia.status.saver.download.statussaver.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.saveit.whmedia.status.saver.download.statussaver.R;
import com.saveit.whmedia.status.saver.download.statussaver.model.MainModel;

import java.util.List;


public class MainAdapter extends BaseAdapter {

    Context context;
    List<MainModel> arrayList;
//    int width;
    LayoutInflater inflater;
    public OnCheckboxListener onCheckboxListener;

    public MainAdapter(Context context, List<MainModel> arrayList, OnCheckboxListener onCheckboxListener) {
        this.context = context;
        this.arrayList = arrayList;

        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//        DisplayMetrics displayMetrics = context.getResources()
//                .getDisplayMetrics();
//        width = displayMetrics.widthPixels; // width of the device

        this.onCheckboxListener = onCheckboxListener;
    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int arg0) {
        return arg0;
    }

    @Override
    public long getItemId(int arg0) {
        return arg0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        View grid = inflater.inflate(R.layout.ins_row_main, null);

        ImageView ivIcon = (ImageView) grid.findViewById(R.id.iv_icon);
        ivIcon.setImageResource(arrayList.get(position).getResId());

        TextView tvTitle = (TextView) grid.findViewById(R.id.tv_title);
        tvTitle.setText(arrayList.get(position).getTitle());

        grid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("click", "click");
                if (onCheckboxListener != null) {
                    onCheckboxListener.onCheckListener(arrayList.get(position));
                }
            }
        });
//        grid.setLayoutParams(new GridView.LayoutParams((width * 460 / 1080), (width * 460 / 1080)));

        return grid;
    }

    public interface OnCheckboxListener {
        void onCheckListener(MainModel mainModel);
    }

}
