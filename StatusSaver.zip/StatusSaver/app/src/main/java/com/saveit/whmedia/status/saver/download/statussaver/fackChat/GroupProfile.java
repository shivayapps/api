package com.saveit.whmedia.status.saver.download.statussaver.fackChat;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.saveit.whmedia.status.saver.download.statussaver.R;

public class GroupProfile extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.group_profile);
    }
}
