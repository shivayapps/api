package com.saveit.whmedia.status.saver.download.statussaver;

import android.app.Application;
import android.util.Log;

import com.onesignal.OneSignal;

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        // OneSignal Initialization
        try {

            OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
            OneSignal.initWithContext(getApplicationContext());
            OneSignal.setAppId("0");
//            OneSignal.startInit(this)
//                    .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
//                    .setNotificationOpenedHandler(new ExampleNotificationOpenedHandler(MyApplication.this))
//                    .setNotificationReceivedHandler(new ExampleNotificationReceivedHandler(MyApplication.this))
//                    .init();
        }catch (Exception e){
            Log.e("con", "onCreate: ");
        }

    }

}
