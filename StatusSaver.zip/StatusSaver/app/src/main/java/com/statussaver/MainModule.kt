package com.statussaver

import androidx.room.Room
import com.statussaver.WhatSaveViewModel
import com.statussaver.database.MIGRATION_1_2
import com.statussaver.database.StatusDatabase
import com.statussaver.repository.CountryRepository
import com.statussaver.repository.CountryRepositoryImpl

import com.statussaver.repository.Repository
import com.statussaver.repository.RepositoryImpl
import com.statussaver.repository.StatusesRepository
import com.statussaver.repository.StatusesRepositoryImpl
import com.statussaver.storage.Storage
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.dsl.viewModel
import org.koin.dsl.bind
import org.koin.dsl.module

private val dataModule = module {
    single {
        Room.databaseBuilder(androidContext(), StatusDatabase::class.java, "statuses.db")
            .addMigrations(MIGRATION_1_2)
            .build()
    }

    factory {
        androidContext().contentResolver
    }

    factory {
        get<StatusDatabase>().statusDao()
    }

}

private val managerModule = module {
    single {
        PhoneNumberUtil.createInstance(androidContext())
    }
    single {
        Storage(androidContext())
    }
}

private val statusesModule = module {
    single {
        CountryRepositoryImpl(androidContext())
    } bind CountryRepository::class

    single {
        StatusesRepositoryImpl(androidContext(), get(), get())
    } bind StatusesRepository::class

    single {
        RepositoryImpl(get(), get())
    } bind Repository::class
}

private val viewModelModule = module {
    viewModel {
        WhatSaveViewModel(get(), get())
    }
}

val appModules = listOf(dataModule, managerModule, statusesModule, viewModelModule)
