package com.statussaver

import android.app.DownloadManager
import android.app.PendingIntent
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.MediaStore.Audio
import android.provider.MediaStore.Files
import android.provider.MediaStore.Images
import android.provider.MediaStore.Video
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.content.getSystemService
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.statussaver.extensions.blacklistMessageSender
import com.statussaver.extensions.getAllInstalledClients
import com.statussaver.extensions.lastUpdateId
import com.statussaver.extensions.preferences
import com.statussaver.model.Country
import com.statussaver.model.Status
import com.statussaver.model.StatusQueryResult
import com.statussaver.model.StatusQueryResult.ResultCode
import com.statussaver.model.StatusType
import com.statussaver.model.WaClient
import com.statussaver.mvvm.DeletionResult
import com.statussaver.mvvm.SaveResult
import com.statussaver.mvvm.ShareResult
import com.statussaver.repository.Repository
import com.statussaver.storage.Storage
import com.statussaver.storage.StorageDevice
import com.statussaver.utils.Common
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch
import java.io.File
import java.util.EnumMap

class WhatSaveViewModel(
    private val repository: Repository,
    private val storage: Storage
) : ViewModel() {

    private val liveDataMap = newStatusesLiveDataMap()

    private val savedStatuses = MutableLiveData(StatusQueryResult.Idle)
    private val installedClients = MutableLiveData<List<WaClient>>()
    private val storageDevices = MutableLiveData<List<StorageDevice>>()
    private val countries = MutableLiveData<List<Country>>()
    private val selectedCountry = MutableLiveData<Country>()

//    private val unlockMessageView = MutableLiveData(false)

    override fun onCleared() {
        super.onCleared()
        liveDataMap.clear()
    }

//    fun unlockMessageView() {
//        unlockMessageView.value = true
//    }

//    fun getMessageViewLockObservable(): LiveData<Boolean> = unlockMessageView

    fun getInstalledClients(): LiveData<List<WaClient>> = installedClients

    fun getStorageDevices(): LiveData<List<StorageDevice>> = storageDevices

    fun getCountriesObservable(): LiveData<List<Country>> = countries

    fun getSelectedCountryObservable(): LiveData<Country> = selectedCountry

    fun getCountries() = countries.value ?: arrayListOf()

    fun getSelectedCountry() = selectedCountry.value

    fun getSavedStatuses(): LiveData<StatusQueryResult> = savedStatuses

    fun getStatuses(type: StatusType): LiveData<StatusQueryResult> {
        return liveDataMap.getOrCreateLiveData(type)
    }

    fun loadClients() = viewModelScope.launch(IO) {
        val result = getApp().getAllInstalledClients()
        installedClients.postValue(result)
    }

    fun loadStorageDevices() = viewModelScope.launch(IO) {
        storageDevices.postValue(storage.storageVolumes)
    }

    fun loadCountries() = viewModelScope.launch(IO) {
        val result = repository.allCountries()
        countries.postValue(result)
    }

    fun loadSelectedCountry() = viewModelScope.launch(IO) {
        selectedCountry.postValue(repository.defaultCountry())
    }

    fun setSelectedCountry(country: Country) = viewModelScope.launch(IO) {
        repository.defaultCountry(country)
        selectedCountry.postValue(country)
    }

    fun loadStatuses(type: StatusType) = viewModelScope.launch(IO) {
        val liveData = liveDataMap[type]
        if (liveData != null) {
            liveData.postValue(liveData.value?.copy(code = ResultCode.Loading) ?: StatusQueryResult(ResultCode.Loading))
            liveData.postValue(repository.statuses(type))
        }
    }

    fun loadSavedStatuses() = viewModelScope.launch(IO) {
        savedStatuses.postValue(savedStatuses.value?.copy(code = ResultCode.Loading) ?: StatusQueryResult(ResultCode.Loading))
        savedStatuses.postValue(repository.savedStatuses())
    }

    fun reloadAll() {
        StatusType.entries.forEach {
            loadStatuses(it)
        }
        loadSavedStatuses()
    }

    fun statusIsSaved(status: Status): LiveData<Boolean> = repository.statusIsSaved(status)

    fun shareStatus(status: Status): LiveData<ShareResult> = liveData(IO) {
        emit(ShareResult(isLoading = true))
        val data = repository.shareStatus(status)
        emit(ShareResult(data = data))
    }

    fun shareStatuses(statuses: List<Status>): LiveData<ShareResult> = liveData(IO) {
        emit(ShareResult(isLoading = true))
        val data = repository.shareStatuses(statuses)
        emit(ShareResult(data = data))
    }

    fun saveStatus(status: Status, saveName: String? = null): LiveData<SaveResult> = liveData(IO) {
        emit(SaveResult(isSaving = true))
        val result = repository.saveStatus(status, saveName)
        emit(SaveResult.single(status, result))
    }

    fun saveStatuses(statuses: List<Status>): LiveData<SaveResult> = liveData(IO) {
        emit(SaveResult(isSaving = true))
        val result = repository.saveStatuses(statuses)
        val savedStatuses = result.keys.toList()
        val savedUris = result.values.toList()
        emit(SaveResult(statuses = savedStatuses, uris = savedUris, saved = result.size))
    }

    fun deleteStatus(status: Status): LiveData<DeletionResult> = liveData(IO) {
        emit(DeletionResult(isDeleting = true))
        val result = repository.deleteStatus(status)
        emit(DeletionResult.single(status, result))
    }

    fun deleteStatuses(statuses: List<Status>): LiveData<DeletionResult> = liveData(IO) {
        emit(DeletionResult(isDeleting = true))
        val result = repository.deleteStatuses(statuses)
        emit(DeletionResult(statuses = statuses, deleted = result))
    }

    fun removeStatus(status: Status) = viewModelScope.launch(IO) {
        repository.removeStatus(status)
        reloadAll()
    }

    fun removeStatuses(statuses: List<Status>) = viewModelScope.launch(IO) {
        repository.removeStatuses(statuses)
        reloadAll()
    }

    @RequiresApi(Build.VERSION_CODES.R)
    fun createDeleteRequest(context: Context, statuses: List<Status>): LiveData<PendingIntent> = liveData(IO) {
        Log.e("test1234", "createDeleteRequest.statuses:${statuses.size}")
        try {
            val uris = statuses.map { it.fileUri }
            if (uris.isNotEmpty()) {
                emit(MediaStore.createDeleteRequest(context.contentResolver, uris))
            }
        }catch (e:Exception){
            Log.e("test1234", "createDeleteRequest.Exception:${e.message}")
        }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    fun createDeleteRequest1(context: Context, statuses: List<Status>): LiveData<PendingIntent> = liveData(Dispatchers.IO) {
        Log.e("test1234", "createDeleteRequest.statuses:${statuses.size}")
        val uris = mutableListOf<Uri>()

        for (status in statuses) {
//            val mediaStoreUri = getMediaStoreUriFromFileUri(context, status.fileUri)
            val filePath = getRealPathFromUri(context, status.fileUri) ?: ""
            val mediaStoreUri = if (status.type == StatusType.IMAGE) Common.getImageContentUri(context, File(filePath)) else Common.getVideoContentUri(context, File(filePath))
            if (mediaStoreUri != null) {
                uris.add(mediaStoreUri)
//                uris.add(status.fileUri)
            }
        }

        Log.e("test1234", "createDeleteRequest.uris:${uris.size}")
        if (uris.isNotEmpty()) {
            emit(MediaStore.createDeleteRequest(context.contentResolver, uris))
        }
    }

    fun getMediaStoreUriFromFile(context: Context, file: File): Uri? {
        val uriExternal = MediaStore.Files.getContentUri("external")

        val projection = arrayOf(MediaStore.MediaColumns._ID)
        val selection = "${MediaStore.MediaColumns.DATA} = ?"
        val selectionArgs = arrayOf(file.absolutePath)

        val cursor = context.contentResolver.query(
            uriExternal,
            projection,
            selection,
            selectionArgs,
            null
        )

        cursor?.use {
            if (it.moveToFirst()) {
                val id = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns._ID))
                return ContentUris.withAppendedId(uriExternal, id)
            } else {
                Log.w("MediaStoreQuery", "No match found for file: ${file.absolutePath}")
            }
        }

        return null
    }

    fun getRealPathFromUri(context: Context, uri: Uri): String {
        Log.e("test1234", "getRealPathFromUri")
//        val projection = arrayOf(MediaStore.MediaColumns.DATA)

        val documentId = DocumentsContract.getDocumentId(uri)
        val split = documentId.split(":").dropLastWhile { it.isEmpty() }.toTypedArray()
        val type = split[0]

        val contentUri = when (type) {
            "video" -> Video.Media.EXTERNAL_CONTENT_URI
            "audio" -> Audio.Media.EXTERNAL_CONTENT_URI
            else -> Images.Media.EXTERNAL_CONTENT_URI
        }
        val selection = "_id=?"
        val selectionArgs = arrayOf(split[1])
        val path = getDataColumn(context,contentUri, selection, selectionArgs)?:""
//        context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
//            if (cursor.moveToFirst()) {
//                val columnIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
//                val path = cursor.getString(columnIndex)
//                return path
//            }
//        }
        Log.e("test1234", "getRealPathFromUri:$path")
        return path
    }

    fun getDataColumn(context: Context,
        uri: Uri,
        selection: String? = null,
        selectionArgs: Array<String>? = null
    ): String? {
        try {
            val projection = arrayOf(Files.FileColumns.DATA)
            val cursor = context.contentResolver.query(uri, projection, selection, selectionArgs, null)
            cursor?.use {
                if (cursor.moveToFirst()) {
                    val data = cursor.getString(cursor.getColumnIndex(Files.FileColumns.DATA))
                    if (data != "null") {
                        return data
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("test1234", "getDataColumn.Exception:$e")
        }
        return null
    }

    private val SilentHandler = CoroutineExceptionHandler { _, _ -> }
}

internal typealias StatusesLiveData = MutableLiveData<StatusQueryResult>
internal typealias StatusesLiveDataMap = EnumMap<StatusType, StatusesLiveData>

internal fun newStatusesLiveDataMap() = StatusesLiveDataMap(StatusType::class.java)

internal fun StatusesLiveDataMap.getOrCreateLiveData(type: StatusType): StatusesLiveData =
    getOrPut(type) { StatusesLiveData(StatusQueryResult.Idle) }