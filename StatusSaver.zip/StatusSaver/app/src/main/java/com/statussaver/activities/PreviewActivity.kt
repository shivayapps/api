package com.statussaver.activities

//import com.statussaver.extensions.PREFERENCE_GRANT_PERMISSIONS
//import com.statussaver.extensions.PREFERENCE_JUST_BLACK_THEME
//import com.statussaver.extensions.PREFERENCE_USE_CUSTOM_FONT
import android.os.Bundle
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.statussaver.R
import com.statussaver.activities.base.BaseActivity
import com.statussaver.databinding.ActivityPreviewBinding
import com.statussaver.fragments.playback.PlaybackFragment
import com.statussaver.model.Status
import com.statussaver.utils.AdCache

class PreviewActivity : BaseActivity() {

    lateinit var binding : ActivityPreviewBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setSupportActionBar(binding.toolbar)

        val statuses = intent.getParcelableArrayListExtra<Status>("statuses") ?: arrayListOf()
        val startPosition = intent.getIntExtra("startPosition", 0)

        val fragment = PlaybackFragment.newInstance(statuses, startPosition)
//        val fragment = PlaybackFragmentArgs.Builder(statuses.toTypedArray(), startPosition).build()

        supportFragmentManager
            .beginTransaction()
            .replace(R.id.settings_container, fragment)
            .commit()

        loadAds()
    }


    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()

    }
    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadAds() {
        val adId = getString(R.string.b_previewActivity)
        BannerAdHelper.showBanner(
            this,
            binding.frameAds,
            binding.frameAds,
            adId,
            AdCache.previewAdView,
            { isLoaded, adView, message ->
//                if (!isDestroyed) {
                mAdView = adView
                AdCache.previewAdView = adView
                isAdLoaded = isLoaded
//                }
            })
    }

}