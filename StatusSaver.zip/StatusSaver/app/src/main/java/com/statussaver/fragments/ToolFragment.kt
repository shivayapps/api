package com.statussaver.fragments

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.core.view.doOnPreDraw
import com.google.android.material.transition.MaterialSharedAxis
import com.statussaver.R
import com.statussaver.activities.MainActivity
import com.statussaver.activities.ToolsActivity
import com.statussaver.databinding.FragmentToolBinding
import com.statussaver.extensions.startActivitySafe
import com.statussaver.fragments.base.BaseFragment
import com.statussaver.waweb.WAWebActivity

class ToolFragment : BaseFragment(R.layout.fragment_tool) {

    private var _binding: FragmentToolBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentToolBinding.bind(view)
//        statusesActivity.setSupportActionBar(binding.toolbar)

//            val intent= Intent(activity, NewMessageActivity::class.java)
//            startActivitySafe(intent)

        binding.toolWebView.setOnClickListener {
            val intent = Intent(activity, WAWebActivity::class.java)
            startActivitySafe(intent)
        }
        binding.toolDirect.setOnClickListener { redirectTool(0) }
        binding.toolTextRepeater.setOnClickListener { redirectTool(1) }
        binding.toolStylishText.setOnClickListener { redirectTool(2) }
        binding.toolTextDecorator.setOnClickListener { redirectTool(3) }
        binding.toolAsciiFace.setOnClickListener { redirectTool(4) }
        binding.toolSplitLongStatus.setOnClickListener { redirectTool(5) }

        postponeEnterTransition()
        view.doOnPreDraw { startPostponedEnterTransition() }
        enterTransition = MaterialSharedAxis(MaterialSharedAxis.Y, true)
        reenterTransition = MaterialSharedAxis(MaterialSharedAxis.Y, true)
    }

    private fun redirectTool(toolId: Int) {
        val intent = Intent(activity, ToolsActivity::class.java)
        intent.putExtra("id", toolId)
        startActivitySafe(intent)
//        when (toolId) {
//            0 -> showFragment(WaDirectFragment())
//            1 -> showFragment(TextRepeatFragment())
//            2 -> showFragment(StylishTextFragment())
//            3 -> showFragment(TextDecoratorFragment())
//            4 -> showFragment(AsciiFacesFragment())
//            5 -> showFragment(SplitLongStatusFragment())
//        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}