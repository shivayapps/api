package com.statussaver.fragments.binding

import com.statussaver.databinding.FragmentOnboardBinding

class OnboardBinding(binding: FragmentOnboardBinding) {
//    val ivHeader = binding.ivHeader
//    val subtitle = binding.subtitle
//    val agreementText = binding.agreementText
//    val storagePermissionView = binding.storagePermissionView
//    val clientPermissionView = binding.clientPermissionView
//    val recyclerView = binding.recyclerView
//    val noClientText = binding.empty
//    val grantButton = binding.grantButton
//    val continueButton = binding.continueButton
//    val privacyPolicyButton = binding.privacyPolicyButton
}