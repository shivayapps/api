package com.statussaver.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.View.OnLongClickListener
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
//import androidx.appcompat.view.ActionMode
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import coil3.load
import coil3.video.VideoFrameDecoder
import com.google.android.material.card.MaterialCardView
import com.statussaver.R
import com.statussaver.adapter.base.AbsMultiSelectionAdapter
import com.statussaver.databinding.ItemStatusBinding
import com.statussaver.extensions.getClientIfInstalled
import com.statussaver.extensions.getFormattedDate
import com.statussaver.extensions.getState
import com.statussaver.interfaces.IStatusCallback
import com.statussaver.model.Status
import com.statussaver.model.StatusType
import kotlin.properties.Delegates
import kotlin.reflect.KProperty


class StatusAdapter(
    private val activity: FragmentActivity,
    private val callback: IStatusCallback,
    private var isSaveEnabled: Boolean,
    private var isDeleteEnabled: Boolean,
    isWhatsAppIconEnabled: Boolean
) : AbsMultiSelectionAdapter<Status, StatusAdapter.ViewHolder>(
    activity,
    object : MultiSelectionListener<Status> {
        override fun onSelectionChanged(selection: List<Status>) {
            callback.onStatusSelectionChanged(selection.size)
        }

//        override fun onMultiSelectionItemClick(itemId: Int, selection: List<Status>) {
//            callback.multiSelectionItemClick(itemId, selection)
//        }

        override fun onSelectionStarted() {
            callback.onStatusSelectionStarted()
        }

        override fun onSelectionCleared() {
            callback.onStatusSelectionCleared()
        }
    }
) {
    var statuses: List<Status> by Delegates.observable(ArrayList()) { _, _, _ ->
        notifyDataSetChanged()
    }

    var isSavingContent by Delegates.observable(false) { _, _, _ ->
        notifyDataSetChanged()
    }

    var isWhatsAppIconEnabled by Delegates.observable(isWhatsAppIconEnabled) { _, _, _ ->
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(activity).inflate(R.layout.item_status, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val status = statuses[position]

        holder.cardView?.isChecked = isItemSelected(status)
        holder.itemView.isActivated = isItemSelected(status)

        if (isMultiSelectionMode) {
            if (isItemSelected(status)) {
                holder.icSelect.visibility = View.VISIBLE
                holder.icUnSelect.visibility = View.GONE
            } else {
                holder.icSelect.visibility = View.GONE
                holder.icUnSelect.visibility = View.VISIBLE
            }
        } else {
            holder.icUnSelect.visibility = View.GONE
            holder.icSelect.visibility = View.GONE
        }

        if (status.type == StatusType.VIDEO) {
            holder.image?.load(status.fileUri) {
                decoderFactory { result, options, _ -> VideoFrameDecoder(result.source, options) }
            }
        } else {
            holder.image?.load(status.fileUri)
        }

        holder.state?.text = if (isSaveEnabled) {
            status.getState(activity)
        } else {
            status.getFormattedDate(activity)
        }

        holder.playIcon?.isGone = isSaveEnabled || status.type == StatusType.IMAGE

        holder.clientIcon?.apply {
            isVisible = false
            setImageDrawable(null)
            if (isWhatsAppIconEnabled) {
                activity.getClientIfInstalled(status.clientPackage)?.let {
                    isVisible = true
                    setImageDrawable(it.getIcon(activity))
                }
            }
        }
    }

    override fun getItemId(position: Int): Long {
        return statuses[position].hashCode().toLong()
    }

    override fun getItemCount(): Int {
        return statuses.size
    }

    override fun getIdentifier(position: Int): Status {
        return statuses[position]
    }

    @SuppressLint("ClickableViewAccessibility")
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener, OnLongClickListener {
        val image = ItemStatusBinding.bind(itemView).image
        val state = ItemStatusBinding.bind(itemView).state
        val icUnSelect = ItemStatusBinding.bind(itemView).icUnSelect
        val icSelect = ItemStatusBinding.bind(itemView).icSelect
        val clientIcon = ItemStatusBinding.bind(itemView).clientIcon
        val playIcon = ItemStatusBinding.bind(itemView).playIcon
        val cardView = itemView as? MaterialCardView

        private val status: Status
            get() = statuses[layoutPosition]

        init {
//            cardView?.isCheckable = true
            itemView.setOnClickListener(this)
            itemView.setOnLongClickListener(this)
        }

        override fun onClick(view: View) {
            if (!isSavingContent) {
                if (isMultiSelectionMode) {
                    toggleItemChecked(layoutPosition)
                } else {
                    callback.previewStatusesClick(statuses, layoutPosition)
                }
            }
        }

        override fun onLongClick(view: View): Boolean {
            if (!isSavingContent) {
                return toggleItemChecked(layoutPosition)
            }
            return false
        }
    }

    init {
        setHasStableIds(true)
    }
}
