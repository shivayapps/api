package com.statussaver.interfaces

interface IScrollable {
    fun scrollToTop()
}