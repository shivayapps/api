
package com.statussaver.dialogs

import android.app.Dialog
import android.content.res.AssetManager
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.statussaver.R
import com.statussaver.databinding.DialogMarkdownBinding
import com.statussaver.extensions.setMarkdownText


class LicensesDialog : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val licenses = getLicenses(requireContext().assets)
        if (licenses.isNullOrEmpty()) {
            return Dialog(requireContext())
        }
        val binding = DialogMarkdownBinding.inflate(layoutInflater)
        binding.message.setMarkdownText(licenses)
        return MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.oss_licenses_title)
            .setView(binding.root)
            .setPositiveButton(R.string.close_action, null)
            .create()
    }

    private fun getLicenses(assets: AssetManager): String? {
        try {
            return assets.open("licenses.md")
                .bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }
}