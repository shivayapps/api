
package com.statussaver.adapter.base

import android.annotation.SuppressLint
import android.content.Context
import android.view.Menu
import android.view.MenuItem
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
//import androidx.appcompat.view.ActionMode
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.statussaver.R


@SuppressLint("NotifyDataSetChanged")
abstract class AbsMultiSelectionAdapter<Data, VH : ViewHolder>(
    private val context: Context,
    private val listener: MultiSelectionListener<Data>
) : RecyclerView.Adapter<VH>() {

    private val checked = ArrayList<Data>()
    var isMultiSelectionMode = false
        private set

    interface MultiSelectionListener<T> {
        fun onSelectionChanged(selection: List<T>)
//        fun onMultiSelectionItemClick(itemId: Int, selection: List<T>)
        fun onSelectionStarted()
        fun onSelectionCleared()
    }

    protected abstract fun getIdentifier(position: Int): Data?

    protected fun isItemSelected(item: Data): Boolean = checked.contains(item)

    fun toggleItemChecked(position: Int): Boolean {
        val identifier = getIdentifier(position) ?: return false

        if (!checked.remove(identifier)) {
            checked.add(identifier)
        }

        if (checked.isNotEmpty() && !isMultiSelectionMode) {
            isMultiSelectionMode = true
            listener.onSelectionStarted()
            notifyDataSetChanged()
        }

        if (checked.isEmpty()) {
            isMultiSelectionMode = false
            listener.onSelectionCleared()
            notifyDataSetChanged()
        }

        notifyItemChanged(position)
        listener.onSelectionChanged(ArrayList(checked))
        return true
    }

    fun checkAll() {
        checked.clear()
        for (i in 0 until itemCount) {
            getIdentifier(i)?.let { checked.add(it) }
        }
        isMultiSelectionMode = checked.isNotEmpty()
        notifyDataSetChanged()
        listener.onSelectionChanged(ArrayList(checked))
    }

    fun clearSelection() {
        if (checked.isNotEmpty()) {
            checked.clear()
            isMultiSelectionMode = false
            notifyDataSetChanged()
            listener.onSelectionCleared()
        }
    }

    fun getSelected(): ArrayList<Data> {
        if (checked.isEmpty()) return ArrayList<Data>()
        else return checked
    }
//    fun handleMenuAction(itemId: Int): Boolean {
//        if (checked.isEmpty()) return false
//        listener.onMultiSelectionItemClick(itemId, ArrayList(checked))
//        clearSelection()
//        return true
//    }
}
