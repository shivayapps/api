package com.statussaver.fragments

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity.CLIPBOARD_SERVICE
import androidx.core.view.doOnPreDraw
import androidx.fragment.app.Fragment
import com.google.android.material.transition.MaterialSharedAxis
import com.statussaver.R
import com.statussaver.databinding.FragmentTextRepeatBinding

class TextRepeatFragment : Fragment(R.layout.fragment_text_repeat), View.OnClickListener {

    private var _binding: FragmentTextRepeatBinding? = null
    private val binding get() = _binding!!

    var text: String? = null
    var number = 0
    var finalList: MutableList<String>? = null

    private var finalText: String? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentTextRepeatBinding.bind(view)

        setData()

        postponeEnterTransition()
        view.doOnPreDraw { startPostponedEnterTransition() }
        enterTransition = MaterialSharedAxis(MaterialSharedAxis.Y, true)
        reenterTransition = MaterialSharedAxis(MaterialSharedAxis.Y, true)
    }

    private fun setData() {
        finalList = ArrayList()

        binding.convert.setOnClickListener(this)
        binding.copy.setOnClickListener(this)
        binding.whatsapp.setOnClickListener(this)
        binding.clear.setOnClickListener(this)

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onClick(v: View?) {

        when (v?.id) {
            R.id.copy -> {
                val clipboard = requireActivity().getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("emoji", finalText)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(requireActivity(), resources.getString(R.string.copied), Toast.LENGTH_SHORT)
                    .show()
            }

            R.id.whatsapp -> {
                val sharingWhatsApp = Intent(Intent.ACTION_SEND)
                sharingWhatsApp.type = "text/plain"
                sharingWhatsApp.putExtra(Intent.EXTRA_TEXT, finalText)
                sharingWhatsApp.setPackage("com.whatsapp")
                try {
                    startActivity(sharingWhatsApp)
                } catch (e: Exception) {
                    Toast.makeText(requireActivity(), "Whatsapp not found", Toast.LENGTH_SHORT).show()
                    e.printStackTrace()
                }
            }

            R.id.clear -> binding.result.text = " "

            R.id.convert -> {
                finalList!!.clear()
                text = binding.edText.text.toString()
                if (text!!.length == 0) {
                    Toast.makeText(requireActivity(), resources.getString(R.string.enter_text), Toast.LENGTH_SHORT).show()
                    return
                }
                number = if (binding.edEmoji.text.toString().length == 0) {
                    Toast.makeText(requireActivity(), resources.getString(R.string.enter_number), Toast.LENGTH_SHORT).show()
                    return
                } else {
                    binding.edEmoji.text.toString().toInt()
                }
                var i = 0
                while (i < number) {
                    finalList!!.add(text!!)
                    i++
                }
                val builder = StringBuilder()
                if (binding.isNextLine.isChecked) {
                    for (details in finalList!!) {
                        builder.append(
                            """
    $details
    
    """.trimIndent()
                        )
                    }
                } else {
                    for (details in finalList!!) {
                        builder.append(details)
                    }
                }
                finalText = builder.toString()
                binding.result.text = finalText
            }
        }
    }
}