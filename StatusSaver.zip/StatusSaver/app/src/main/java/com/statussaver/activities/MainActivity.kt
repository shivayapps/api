package com.statussaver.activities

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.navigation.findNavController
import androidx.viewpager.widget.ViewPager
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.statussaver.R
import com.statussaver.activities.base.BaseActivity
import com.statussaver.databinding.ActivityMainBinding
import com.statussaver.extensions.getPreferredClient
import com.statussaver.extensions.hasStoragePermissions
import com.statussaver.extensions.setupWhatsAppMenuItem
import com.statussaver.extensions.startActivitySafe
import com.statussaver.extensions.updateStatusBarColor
import com.statussaver.fragments.ToolFragment
import com.statussaver.fragments.statuses.ImageStatusesFragment
import com.statussaver.fragments.statuses.SavedStatusesFragment
import com.statussaver.fragments.statuses.StatusesFragment
import com.statussaver.fragments.statuses.VideoStatusesFragment

import com.statussaver.utils.AdCache


class MainActivity : BaseActivity() {

    //    private val viewModel by viewModel<WhatSaveViewModel>()
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
//        val navHostFragment = supportFragmentManager.findFragmentById(R.id.global_container) as NavHostFragment
//        val navController = navHostFragment.navController
//        navController.addOnDestinationChangedListener(object : NavController.OnDestinationChangedListener {
//            override fun onDestinationChanged(controller: NavController, destination: NavDestination, arguments: Bundle?) {
//                Log.e("navController","destination:${destination.id}")
//                if (destination.id == R.id.onboardFragment) {
//                    binding.llAds.visibility = View.GONE
//                } else {
//                    binding.llAds.visibility = View.VISIBLE
//                }
//            }
//        })

        initView()

        loadAds()
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()

    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadAds() {
        val adId = getString(R.string.b_homeActivity)
        BannerAdHelper.showBanner(
            this,
            binding.frameAds,
            binding.frameAds,
            adId,
            AdCache.homeAdView,
            { isLoaded, adView, message ->
//                if (!isDestroyed) {
                mAdView = adView
                AdCache.homeAdView = adView
                isAdLoaded = isLoaded
//                }
            })
    }

    lateinit var imageStatusesFragment: ImageStatusesFragment
    lateinit var videoStatusesFragment: VideoStatusesFragment
    lateinit var savedStatusesFragment: SavedStatusesFragment
    lateinit var toolFragment: ToolFragment

    fun onSelectionStarted() {
        binding.bottomActionMenu.visibility = View.VISIBLE
        if (binding.viewPager.currentItem == 2) binding.actionDelete.visibility = View.VISIBLE
        else binding.actionDelete.visibility = View.GONE

        binding.toolbar.visibility = View.GONE
        binding.toolbarSelection.visibility = View.VISIBLE
        binding.bottomNavigation.visibility = View.GONE
        binding.viewPager.setPagingEnabled(false)

    }

    fun onSelectionCleared() {
        binding.bottomActionMenu.visibility = View.GONE
        binding.toolbar.visibility = View.VISIBLE
        binding.toolbarSelection.visibility = View.GONE
        binding.bottomNavigation.visibility = View.VISIBLE
        binding.viewPager.setPagingEnabled(true)
        clearSelection()
    }

    fun updateSelectionCount(count: Int) {
        binding.selectionTitle.text = "$count selected"
    }

    fun getStatusesFragment(): StatusesFragment {
        when (binding.viewPager.currentItem) {
            0 -> return imageStatusesFragment
            1 -> return videoStatusesFragment
            2 -> return savedStatusesFragment
            else -> return imageStatusesFragment
        }
    }

    fun clearSelection() {
        getStatusesFragment().statusAdapter?.clearSelection()
        updateSelectionCount(0)
    }

    private fun initView() {

        imageStatusesFragment = ImageStatusesFragment()
        videoStatusesFragment = VideoStatusesFragment()
        savedStatusesFragment = SavedStatusesFragment()
        toolFragment = ToolFragment()

        val adapter = ViewPagerAdapter(this, supportFragmentManager)
        adapter.addFragment(imageStatusesFragment)
        adapter.addFragment(videoStatusesFragment)
        adapter.addFragment(savedStatusesFragment)
        adapter.addFragment(toolFragment)

        binding.viewPager.offscreenPageLimit = 4
        binding.viewPager.adapter = adapter

        binding.bottomNavigation.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.imagesFragment -> {
                    binding.viewPager.post {
                        binding.viewPager.currentItem = 0
                    }
                }

                R.id.videosFragment -> {
                    binding.viewPager.post {
                        binding.viewPager.currentItem = 1
                    }
                }

                R.id.savedFragment -> {
                    binding.viewPager.post {
                        binding.viewPager.currentItem = 2
                    }
                }

                R.id.toolsFragment -> {
                    binding.viewPager.post {
                        binding.viewPager.currentItem = 3
                    }
                }

                else -> {
                    binding.viewPager.post {
                        binding.viewPager.currentItem = 0
                    }
                }
            }
            true
        }

        binding.viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {

            }

            override fun onPageSelected(position: Int) {
                when (position) {
                    0 -> {
//                        setEmptyAlbum()
//                        setEmptyData(isEmptyAlbum)

                        binding.toolbar.setTitle(R.string.type_images)
                        binding.bottomNavigation.selectedItemId = R.id.imagesFragment
                    }

                    1 -> {
//                        setEmptyPhoto()
//                        setEmptyData(isEmptyPhoto)

                        binding.toolbar.setTitle(R.string.type_videos)
                        binding.bottomNavigation.selectedItemId = R.id.videosFragment
                    }

                    2 -> {
//                        var isEmpty = false
//                        isEmpty = isEmptyAlbum && isEmptyPhoto
//                        setEmptyData(isEmpty)

                        binding.toolbar.setTitle(R.string.saved_label)
                        binding.bottomNavigation.selectedItemId = R.id.savedFragment
                    }

                    3 -> {
//                        var isEmpty = false
//                        isEmpty = isEmptyAlbum && isEmptyPhoto
//                        setEmptyData(isEmpty)

                        binding.toolbar.setTitle(R.string.tools_label)
                        binding.bottomNavigation.selectedItemId = R.id.toolsFragment
                    }
                }
//                binding.loutTab.onPageSelected(position)
//                tabPos = position

//                if (position == 2 && binding.titleSwitcher.displayedChild != 1) {
//                    binding.titleSwitcher.displayedChild = 1
//                } else if (binding.titleSwitcher.displayedChild == 1) {
//                    binding.titleSwitcher.displayedChild = 0
//                }

//                Log.e("HomeActivity", "onPageSelected.refreshMedia:${preferences.refreshMedia}")
//                if (preferences.refreshMedia) {
//                    preferences.refreshMedia = false
////                    if (albumFragment != null) albumFragment.getData()
////                    if (photosFragment != null) photosFragment.getData()
//                    getAlbumData()
//                    getPhotoData()
////                    if (albumFragment != null) {
////                        albumFragment.getData()
////                        preferences.refreshMedia = false
////                    }
//                }


            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })

        binding.actionShare.setOnClickListener {
            getStatusesFragment().actionShare()
        }
        binding.actionSave.setOnClickListener {
            getStatusesFragment().actionSave()
        }
        binding.actionDelete.setOnClickListener {
            getStatusesFragment().actionDelete()
        }
        binding.actionClose.setOnClickListener {
            clearSelection()
        }
        binding.actionSelectAll.setOnClickListener {
            getStatusesFragment().statusAdapter?.checkAll()
        }
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        if (!hasStoragePermissions()) {
            startActivity(Intent(this, PermissionActivity::class.java))
//            requestPermissions(preferences().isShownOnboard)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        menu.setupWhatsAppMenuItem(this)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        Log.e("OptionsItem", "OptionsItemSelected:${item.itemId}")
        when (item.itemId) {
            R.id.action_settings -> {
                val intent = Intent(this, SettingsActivity::class.java)
                startActivitySafe(intent)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

//    override fun onSupportNavigateUp(): Boolean =
//        findNavController(R.id.main_container).navigateUp()


    class ViewPagerAdapter(val activity: Activity, fm: FragmentManager) :
        FragmentStatePagerAdapter(fm) {

        private val fragments = mutableListOf<Fragment>()

        fun addFragment(fragment: Fragment) {
            fragments.add(fragment)
            notifyDataSetChanged()
        }

        override fun getCount(): Int {
            return fragments.size
        }

        override fun getItem(position: Int): Fragment {
            return fragments[position]
        }
    }
}
