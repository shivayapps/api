package com.statussaver.fragments.binding

//import com.statussaver.databinding.FragmentMessageANumberBinding
//
//class MessageBinding(binding: FragmentMessageANumberBinding) {
//    val appBar = binding.appBar
//    val toolbar = binding.toolbar
//    val collapsingToolbarLayout = binding.collapsingToolbarLayout
//    val phoneInputLayout = binding.messageANumberContent.phoneNumberInputLayout
//    val messageInputLayout = binding.messageANumberContent.messageInputLayout
//    val phoneNumber = binding.messageANumberContent.phoneNumber
//    val message = binding.messageANumberContent.message
//    val shareButton = binding.messageANumberContent.shareButton
//    val sendButton = binding.messageANumberContent.sendButton
//}