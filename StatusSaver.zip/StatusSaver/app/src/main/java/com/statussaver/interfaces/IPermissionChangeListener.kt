package com.statussaver.interfaces


interface IPermissionChangeListener {
    fun permissionsStateChanged(hasPermissions: Boolean)
}