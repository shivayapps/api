package com.statussaver.extensions

import android.Manifest
//import android.Manifest.permission.READ_EXTERNAL_STORAGE
//import android.Manifest.permission.READ_MEDIA_IMAGES
//import android.Manifest.permission.READ_MEDIA_VIDEO
//import android.Manifest.permission.WRITE_EXTERNAL_STORAGE
import android.content.Context
import android.content.Intent
import android.content.UriPermission
import android.os.Build
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.navigation.findNavController
import com.statussaver.R
import com.statussaver.activities.PermissionActivity
import com.statussaver.model.WaClient

const val STORAGE_PERMISSION_REQUEST = 100

//@SuppressLint("InlinedApi")
//fun getRequestedPermissions(): Array<RequestedPermissions> {
//    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
//        arrayOf(
//            RequestedPermissions(Build.VERSION_CODES.TIRAMISU, Manifest.permission.READ_MEDIA_AUDIO),
//            RequestedPermissions(Build.VERSION_CODES.TIRAMISU, Manifest.permission.READ_MEDIA_IMAGES)
//        )
//    } else if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
//        arrayOf(
//            RequestedPermissions(Build.VERSION_CODES.Q, Manifest.permission.READ_EXTERNAL_STORAGE),
//            RequestedPermissions(Build.VERSION_CODES.Q, Manifest.permission.WRITE_EXTERNAL_STORAGE)
//        )
//    } else {
//        arrayOf(RequestedPermissions(Build.VERSION_CODES.P, Manifest.permission.READ_EXTERNAL_STORAGE))
//    }
////    return arrayOf(
////        RequestedPermissions(1..Build.VERSION_CODES.P, WRITE_EXTERNAL_STORAGE),
////        RequestedPermissions(1..Build.VERSION_CODES.S_V2, READ_EXTERNAL_STORAGE),
////        RequestedPermissions(Build.VERSION_CODES.TIRAMISU, READ_MEDIA_IMAGES, READ_MEDIA_VIDEO)
////    )
//}

val NECESSARY_PERMISSIONS =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        arrayOf(
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.POST_NOTIFICATIONS
        )
    } else if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
        arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
    } else {
        arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE
        )
    }

fun getApplicablePermissions() = NECESSARY_PERMISSIONS
//fun getApplicablePermissions() = getRequestedPermissions()
//    .filter { it.isApplicable() }
//    .flatMap { it.permissions.asIterable() }
//    .toTypedArray()

fun List<UriPermission>.areValidPermissions(): Boolean {
    return isNotEmpty() && WaClient.entries.any { client -> client.hasPermissions(this) }
}

//fun Context.hasStoragePermissions(): Boolean = doIHavePermissions(*getApplicablePermissions())
fun Context.hasStoragePermissions(): Boolean = doIHavePermissions(NECESSARY_PERMISSIONS)

fun Context.hasSAFPermissions(): Boolean {
    return Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || getAllInstalledClients().any { it.hasPermissions(this) }
}

fun Context.hasPermissions() = hasStoragePermissions() && hasSAFPermissions()

fun FragmentActivity.requestWithOnboard() {
    preferences().isShownOnboard = false

    startActivity(Intent(this, PermissionActivity::class.java))
//    findNavController(R.id.main_container).navigate(R.id.onboardFragment)
}

fun FragmentActivity.requestWithoutOnboard() {
    requestPermissions(getApplicablePermissions(), STORAGE_PERMISSION_REQUEST)
}

fun FragmentActivity.requestPermissions(isShowOnboard: Boolean = false) {
    if (isShowOnboard) {
//        val navController = findNavController(R.id.main_container)
//        if (navController.currentDestination?.id == R.id.onboardFragment) {
//            requestWithoutOnboard()
//        } else {
            requestWithOnboard()
//        }
    } else {
        requestWithoutOnboard()
    }
}

fun Fragment.hasStoragePermissions() = requireContext().hasStoragePermissions()

fun Fragment.hasPermissions() = requireContext().hasPermissions()

fun Fragment.requestWithoutOnboard() = requireActivity().requestWithoutOnboard()

fun Fragment.requestPermissions() = requireActivity().requestPermissions(true)