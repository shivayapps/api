package com.statussaver.fragments

import android.os.Bundle
import android.view.View
import androidx.core.view.doOnPreDraw
import androidx.fragment.app.Fragment
import androidx.viewpager.widget.ViewPager
import com.google.android.material.transition.MaterialSharedAxis
import com.statussaver.R
import com.statussaver.adapter.AsciiAdapter
import com.statussaver.databinding.FragmentAsciiFacesBinding
import com.statussaver.views.CommonPagerAdapter

class AsciiFacesFragment : Fragment(R.layout.fragment_ascii_faces) {

    private var _binding: FragmentAsciiFacesBinding? = null
    private val binding get() = _binding!!

    private val happyAscii = arrayOf(
        "¯\\_(ツ)_/¯",
        "(☞ﾟヮﾟ)☞",
        "(◕‿◕)",
        "(｡◕‿◕｡)",
        "( ಠ ͜ʖರೃ)",
        "(⊙﹏⊙)",
        "(◠﹏◠)",
        "(ﾉ◕ヮ◕)ﾉ",
        "( ͡° ͜ʖ ͡°)",
        "( ͡°( ͡° ͜ʖ( ͡° ͜ʖ ͡°)ʖ ͡°) ͡°)",
        "┬┴┬┴┤ ͜ʖ ͡°) ├┬┴┬┴",
        "(◕‿◕✿)",
        "ᕕ(✿◕‿◕)ᕗ",
        "ᕕ(  ◕‿◕)ᕗ",
        "(ᵔᴥᵔ)",
        "(づ￣ ³￣)づ",
        "\\ (•◡•) /",
        "\\(◕◡◕)/",
        "(☞ﾟヮﾟ)☞ ☜(ﾟヮﾟ☜)",
        "☜(ﾟヮﾟ☜)",
        "♪~ ᕕ(ᐛ)ᕗ",
        "༼ʘ̚ل͜ʘ̚༽",
        "ʘ‿ʘ",
        "~ (˘▾˘~)",
        "(~˘▾˘)~",
        "(͡o‿O͡)",
        "(❍ᴥ❍ʋ)",
        "| (• ◡•)| (❍ᴥ❍ʋ)",
        "─=≡Σᕕ( ͡° ͜ʖ ͡°)ᕗ",
        "( ͡° ͜ʖ ͡°)>⌐■-■",
        "( ͡ᶢ ͜ʖ ͡ᶢ)",
        "( ͡^ ͜ʖ ͡^)",
        "( ͡ᵔ ͜ʖ ͡ᵔ )",
        "( ͡° ͜ ͡°)",
        "(˵ ͡° ͜ʖ ͡°˵)",
        "(∩ ͡° ͜ʖ ͡°)⊃━☆ﾟ",
        "ᕦ( ͡° ͜ʖ ͡°)ᕤ",
        "（╯ ͡° ▽ ͡°）╯︵ ┻━┻",
        "( ͡°╭͜ʖ╮͡° )",
        "༼ つ  ͡° ͜ʖ ͡° ༽つ",
        "(｡◕‿‿◕｡)",
        "(ง°ل͜°)ง",
        "ಠ⌣ಠ",
        "♡‿♡",
        "(●´ω｀●)",
        "(╹◡╹)",
        "ლ(╹◡╹ლ)",
        "(づ｡◕‿‿◕｡)づ",
        "┏(＾0＾)┛┗(＾0＾) ┓"
    )
    private val angryAscii = arrayOf(
        "(≖︿≖ )",
        "(ง ͠° ͟ل͜ ͡°)ง",
        "ಠ_ಠ",
        "( ͠°Д°͠ )",
        "ლ(ಠ益ಠლ)",
        "(>ლ)",
        "(ง'-̀'́)ง",
        "(ノಠ益ಠ)ノ彡┻━┻",
        "(╯°□°）╯︵( .o.)",
        "(╯°□°）╯︵ /( ‿⌓‿ )\\",
        "(╯°□°）╯︵ ┻━┻",
        "┻━┻ ︵ヽ(`Д´)ﾉ︵ ┻━┻",
        "(┛◉Д◉)┛彡┻━┻ ",
        "(¬_¬)",
        "ಠoಠ",
        "ᕙ(⇀‸↼‶)ᕗ",
        "ᕦ(ò_óˇ)ᕤ",
        "¯\\_(ʘ_ʘ)_/¯",
        "( ͡°_ʖ ͡°)",
        "( ° ͜ʖ͡°)╭∩╮",
        "( ͡°Ĺ̯ ͡° )",
        "( ͠° ͟ʖ °͠ )",
        "¯\\_( ͠° ͟ʖ °͠ )_/¯",
        "( ͡°⊖ ͡°)",
        "ರ_ರ",
        "(>人<)",
        "ಠ╭╮ಠ",
        "(◣_◢)",
        "(⋋▂⋌)",
        "〴⋋_⋌〵",
        "(╹◡╹)凸",
        "ლ(͠°◞౪◟°͠ლ)",
        "╭∩╮(︶︿︶)╭∩╮",
        "(ㆆ_ㆆ)"
    )
    private val otherAscii = arrayOf(
        "( ཀ ʖ̯ ཀ)",
        "(╥﹏╥)",
        "( ͡°ᴥ ͡° ʋ)",
        "ಠ_ಥ",
        "ಠ~ಠ",
        "ʕ◉.◉ʔ",
        "༼ つ ◕_◕ ༽つ",
        "(ಥ﹏ಥ)",
        "ヾ(⌐■_■)ノ",
        "( ︶︿︶)",
        "(✖╭╮✖)",
        "༼ つ ಥ_ಥ ༽つ",
        "(\"º _ º)",
        "┬─┬ノ( º _ ºノ)",
        "(._.) ( l: ) ( .-. ) ( :l ) (._.)",
        "༼ ºل͟º ༼ ºل͟º ༼ ºل͟º ༽ ºل͟º ༽ ºل͟º ༽",
        "┬┴┬┴┤(･_├┬┴┬┴",
        "(°ロ°)☝",
        "(▀̿Ĺ̯▀̿ ̿)",
        "﴾͡๏̯͡๏﴿ O'RLY?",
        "⚆ _ ⚆",
        "ಠ‿↼",
        "☼.☼",
        "◉_◉",
        "( ✧≖ ͜ʖ≖)",
        "( ͠° ͟ʖ ͡°)",
        "( ‾ ʖ̫ ‾)",
        "(͡ ͡° ͜ つ ͡͡°)",
        "( ﾟдﾟ)",
        "┬──┬ ノ( ゜-゜ノ)",
        "¯\\(°_o)/¯",
        "(ʘᗩʘ')",
        "☜(⌒▽⌒)☞",
        "(;´༎ຶД༎ຶ`)",
        "̿̿ ̿̿ ̿̿ ̿'̿'\\̵͇̿̿\\з= ( ▀ ͜͞ʖ▀) =ε/̵͇̿̿/’̿’̿ ̿ ̿̿ ̿̿ ̿̿",
        "[̲̅$̲̅(̲̅5̲̅)̲̅$̲̅]",
        "(ᇂﮌᇂ)",
        "(≧ω≦)",
        "►_◄",
        "أ ̯ أ",
        "ლ(╹ε╹ლ)",
        "ᇂ_ᇂ",
        "＼(￣ー＼)(／ー￣)／",
        "♪┏ ( ･o･) ┛♪┗ (･o･ ) ┓♪┏(･o･)┛♪",
        "╘[◉﹃◉]╕",
        "( ･_･)♡",
        "(¤﹏¤)",
        "( ˘︹˘ )"
    )

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentAsciiFacesBinding.bind(view)

        addTabs()
        setAdapter()

        postponeEnterTransition()
        view.doOnPreDraw { startPostponedEnterTransition() }
        enterTransition = MaterialSharedAxis(MaterialSharedAxis.Y, true)
        reenterTransition = MaterialSharedAxis(MaterialSharedAxis.Y, true)
    }

    private fun addTabs() {
        val commonPagerAdapter = CommonPagerAdapter()
        commonPagerAdapter.insertViewId(R.id.happyTab, "Happy")
        commonPagerAdapter.insertViewId(R.id.angryTab, "Angry")
        commonPagerAdapter.insertViewId(R.id.otherTab, "Other")
        binding.viewpager.offscreenPageLimit = 3
        binding.viewpager.adapter = commonPagerAdapter

//        binding.tabs.setupWithViewPager(binding.viewpager)

        binding.tabs.observeIndexChange { fromIndex, toIndex, reselect, fromUser ->
            binding.viewpager.currentItem = toIndex
        }
        binding.viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
            override fun onPageSelected(position: Int) {
                binding.tabs.onPageSelected(position)
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })
    }

    private fun setAdapter() {
        binding.angryTab.list.adapter = AsciiAdapter(requireActivity(), angryAscii)
        binding.happyTab.list.adapter = AsciiAdapter(requireActivity(), happyAscii)
        binding.otherTab.list.adapter = AsciiAdapter(requireActivity(), otherAscii)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}