package com.adconfig.adsutil

import android.util.Log
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import java.util.Date

object Config {

    var mAppOpenAd: AppOpenAd? = null
    var mInterstitialAd: InterstitialAd? = null
    var isLibraryInitialized = false

    //    var IS_DEBUG = true
//    var admobInterstitialAdId: String = ""
    var admobAppOpenId: String = ""
    var showInterTime: Long = 0
    var adinterval: Long = 40
    var enablead: Boolean = false

    fun checkReInter(callback: (Boolean) -> Unit) {
        if (showInterTime != 0L) {
            if ( adinterval == 0L || !enablead) return
            val diff = Date().time - showInterTime
            Log.e("LLL_Splash", "loadBackPressInter: $diff")
            if (diff < (adinterval * 1000)) {
                callback.invoke(false)
                return
            }
            callback.invoke(true)
        }
    }
}