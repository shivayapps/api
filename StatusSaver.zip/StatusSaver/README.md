‎Photo viewer screen button and top  option same as v5 
‎
‎Photo tab today , yesterday title like album title same 
‎
‎Info dailog title change to details and remove ok button 
‎
‎Select option 4 to 5 on photo and album selection 
‎
‎Private ui changes 
‎
‎Displayed columns option change 2 to 6
‎ same 
‎
‎Displayed columns in photo tab by default columns 3 to 4
‎
‎Recycle bin page title change to trash bin
‎
‎Search tab add new option  download and gif option etc..
‎
‎Search tab timeline and place album inner 3 dots options (+ -) change 
‎
‎Clener icon change 
‎
‎Album and photo tab 3 dot dailog add select options 
‎
‎possible  hoy to collage option add 
‎
‎Favourite screen at time updat
‎
‎Explore sreen tab name change and ui add 
‎