# AI-Magic-
AI Magic 
testing-first push

1	"On Boarding
Show onboarding only once. If the user does not click ‘Get Started’ and exits the app using the mobile Home button, then from the next launch onward, take the user directly to the Home screen."

2	"Image Enhancer
1. If the user has not uploaded an image and clicks Generate, show a toast message saying ‘Upload image'.
   2.Add a preview screen to the Image Enhancer result so users can preview the generated image. Use an eye icon to open the image preview and a close icon to close the preview.
   3.Once the Save Changes dialog appears, tapping the empty space at the top should allow the dialog to be dragged down, and tapping the phone controls should close the dialog.
4. After clicking Share, the enhanced image is not shared. Instead, another image that I generated earlier is being shared
   5.Remove more faces exception for this feature
   6.On the result screen, tapping the top Back button shows the Save Changes dialog, but tapping the phone Back button takes the user to the Home screen. Both Back actions should display the Save Changes dialog.
   7.For this feature, provide a crop screen with all aspect ratios, not just a single ratio like 3:4."

3	"Background remover
1.If the user has not uploaded an image and clicks Generate, show a toast message saying ‘Upload image'.
2.For this feature, provide a crop screen with all aspect ratios, not just a single ratio like 3:4.
3. Api is not working
   Keep same user flow as image enhancer"

4	"Background changer
Api is not working, Keep same user flow as image enhancer."

5	"Body Editor
1. The green selection icon is not moving to the right, it only moves to the left.
2. Undo is working for both functionalities. Please keep Undo and Redo as separate functionalities.
3. A preview is available in each Shape Changer, but it is not working.
4. In each Shape Changer edit screen, the top Back button is not working
5. Once the Save Changes dialog appears, tapping the empty space at the top should allow the dialog to be dragged down, and tapping the phone controls should close the dialog.
6. After clicking Save, show the Share screen (Image Enhancer result screen) so the user can preview and share the image"

6	"AI Videos
1. it is not sharing the video i generated, it is sharing the previously generated image"

7	"Future Baby Gen
1. Keep the same image picker cards for boy and girl
2. When clicking phone controls back it is taking me to generate screen, it is not the flow, show save changes dialog or if saved take home.
3. it is not sharing the video i generated, it is sharing the previously generated image
4. Once the Save Changes dialog appears, tapping the empty space at the top should allow the dialog to be dragged down, and tapping the phone controls should close the dialog."

8	"Face swap image
1. When using a full-body image template, the result is cropped at the top and bottom because it uses a 9:16 size. Please check and update the aspect ratio on the result screen.
2. Once the Save Changes dialog appears, tapping the empty space at the top should allow the dialog to be dragged down, and tapping the phone controls should close the dialog.
3. When clicking the phone Back button, the app navigates to the Home screen without saving the image and without showing any dialog. A ‘Save Changes’ dialog should be shown when any Back action is triggered"

9	"Transformation
1.Keep the crop size is 3:4
2.When clicking the phone Back button, the app navigates to the Home screen without saving the image and without showing any dialog. A ‘Save Changes’ dialog should be shown when any Back action is triggered.
3. Check share image"

10	"Face Dance
1. keep 1:1 ratio crop screen
2. Unable to pause the video in result screen
3. Show a template preview after clicking on a template, similar to the Face Swap template.
4. When clicking the phone Back button, the app navigates to the Home screen without saving the image and without showing any dialog. A ‘Save Changes’ dialog should be shown when any Back action is triggered.
5. The same audio is playing for every template."

11	"Creations:
1. Use a staggered view for images and videos, since we are using different sizes.
2. show orginal size of the videos, dont stretch the video to full screen."

12	"1. App open ad is not showing,
2.If the user rates the app with 3 stars or below, redirect them to Gmail. If the user rates the app with 4 or 5 stars, redirect them to the Play Store."


/////////////////
fm

