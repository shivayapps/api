// Individual.java
package com.video.aimagic.aivideos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.adconfig.adsutil.utils.SmUtils;
import com.bumptech.glide.Glide;
import com.video.aimagic.databinding.FragmentIndividualBinding;
import com.video.aimagic.commonscreen.screen.CommonProcessing;
import com.video.aimagic.fragments.BaseUploadFragment;
import com.video.aimagic.utils.appconfig.AppConfig;
import com.video.aimagic.utils.appconfig.StartActivityGlobally;

import java.io.File;
import java.io.FileOutputStream;

import kotlin.Pair;

public class Individual extends BaseUploadFragment {
    private static final String UPLOAD_TYPE_FIRST = "individual_1";
    private static final String UPLOAD_TYPE_SECOND = "individual_2";
    private FragmentIndividualBinding binding;

    public Individual() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentIndividualBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.girlfriendUpload.setOnClickListener(v -> {
            photoUploadManager.startPhotoUpload(requireActivity(), AppConfig.FEATURE_INDIVISUAL, UPLOAD_TYPE_FIRST);
        });

        binding.boyFriendUpload.setOnClickListener(v -> {
            photoUploadManager.startPhotoUpload(requireActivity(), AppConfig.FEATURE_INDIVISUAL, UPLOAD_TYPE_SECOND);
        });

        binding.generateButton.setOnClickListener(v -> {
            // Check if both images are uploaded
            if (binding.girlfriend.getDrawable() != null && binding.boyfriend.getDrawable() != null) {
                String path = combineImagesSideBySide(
                        binding.girlfriend,
                        binding.boyfriend,
                        getActivity()
                );
                Log.e("ResultScreen", "path:"+path);
                if (path != null && !path.isEmpty()) {
                    photoUploadManager.setCurrentImageUriStringPath(path);
                    generateResult();
                }
            }else {
                Toast.makeText(getContext(),"Upload image",Toast.LENGTH_SHORT).show();
            }
        });
    }

    public String combineImagesSideBySide(
            ImageView iv1,
            ImageView iv2,
            Context context
    ) {
        Log.e("ResultScreen", "combineImagesSideBySide");

        Drawable d1 = iv1.getDrawable();
        Drawable d2 = iv2.getDrawable();

        if (d1 == null || d2 == null) return null;

        Bitmap b1 = drawableToBitmap(d1);
        Bitmap b2 = drawableToBitmap(d2);

        int width = b1.getWidth() + b2.getWidth();
        int height = Math.max(b1.getHeight(), b2.getHeight());

        Bitmap combinedBitmap =
                Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(combinedBitmap);

        // LEFT image
        canvas.drawBitmap(b1, 0f, 0f, null);

        // RIGHT image
        canvas.drawBitmap(b2, b1.getWidth(), 0f, null);

        return saveBitmapToCache(combinedBitmap, context);
    }

    private String saveBitmapToCache(Bitmap bitmap, Context context) {
        Log.e("ResultScreen", "saveBitmapToCache");
        File cacheDir = context.getCacheDir();
        File imageFile = new File(
                cacheDir,
                "combined_" + System.currentTimeMillis() + ".png"
        );

        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            return imageFile.getAbsolutePath();
        } catch (Exception e) {
            Log.e("ResultScreen", "saveBitmapToCache.Exception:" + e);
            return null;
        }
    }

    private static Bitmap drawableToBitmap(Drawable drawable) {

        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }

        Bitmap bitmap = Bitmap.createBitmap(
                drawable.getIntrinsicWidth(),
                drawable.getIntrinsicHeight(),
                Bitmap.Config.ARGB_8888
        );

        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }

    @Override
    protected void handlePhotoUploaded(Uri imageUri, String uploadType) {
        if (getView() == null) return;
        if (UPLOAD_TYPE_FIRST.equals(uploadType)) {
            Glide.with(requireContext())
                    .load(imageUri.getPath())
                    .centerCrop()
                    .into(binding.girlfriend);
        } else if (UPLOAD_TYPE_SECOND.equals(uploadType)) {
            Glide.with(requireContext())
                    .load(imageUri.getPath())
                    .centerCrop()
                    .into(binding.boyfriend);
        }
    }

    @SuppressWarnings("unchecked")
    private void generateResult() {
        if(SmUtils.INSTANCE.isConnected(getContext())) {
            StartActivityGlobally.navigateToActivityWithFeature(
                    requireActivity(),
                    CommonProcessing.class,
                    new Pair<>(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_AI_VIDEO_SINGLE)
            );
        }else {
            Toast.makeText(getContext(),"Please connect to internet.",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}