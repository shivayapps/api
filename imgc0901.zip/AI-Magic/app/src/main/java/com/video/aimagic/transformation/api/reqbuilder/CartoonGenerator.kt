package com.video.aimagic.transformation.api.reqbuilder

import android.util.Log
import com.video.aimagic.transformation.api.interfaces.CartoonApiService
import com.video.aimagic.transformation.api.resposehandler.CartoonResult
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okio.IOException

class CartoonGenerator(
    private val apiService: CartoonApiService,
    private val fcmToken: String,
    private val appCheckToken: String
) {
    suspend fun generateCartoon(
        appName: String,
        category: String,
        subCategory: String,
        prompt: String,
        negativePrompt: String,
        steps: Int,
        seed: Long,
        cfgScale: Float,
        denoisingStrength: Float,
        samplerIndex: String,
        model: String,
        imageFile: java.io.File
    ): CartoonResult {

//       return try {
            // Create image part only (other parameters are query params)
            val imageRequestBody = imageFile.asRequestBody("image/jpeg".toMediaTypeOrNull())
            val imagePart = MultipartBody.Part.createFormData(
                "input_image",
                imageFile.name,
                imageRequestBody
            )

            val response = apiService.generateCartoon(
                appName = appName,
                category = category,
                subCategory = subCategory,
                prompt = prompt,
                negativePrompt = negativePrompt,
                steps = steps,
                seed = seed,
                cfgScale = cfgScale,
                denoisingStrength = denoisingStrength,
                samplerIndex = samplerIndex,
                model = model,
                inputImage = imagePart,
                fcmToken = fcmToken,
                appCheckToken = appCheckToken
            )

            Log.e("CartoonResult","response:$${response.body()}")

            if (response.isSuccessful) {
                return CartoonResult.Success(response)
            } else {
                Log.e("CartoonResult","API Error:$${response.code()}-${response.message()}")
                return CartoonResult.Error("API Error: ${response.code()}", response.code())
            }
//        } catch (e: IOException) {
//            Log.e("CartoonResult","CartoonResult.UnknownError:$e")
//            CartoonResult.NetworkError
//        } catch (e: Exception) {
//            Log.e("CartoonResult","CartoonResult.UnknownError:$e")
//            CartoonResult.UnknownError
//        }
    }
}