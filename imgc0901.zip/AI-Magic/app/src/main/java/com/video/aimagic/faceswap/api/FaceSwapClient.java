package com.video.aimagic.faceswap.api;

import com.video.aimagic.faceswap.interfaces.FaceSwapCallback;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class FaceSwapClient {
    private static final String BASE_URL = "https://faceswap.aapthi.in/upload/";
    private static final long CONNECT_TIMEOUT = 30;
    private static final long READ_TIMEOUT = 60;
    private static final long WRITE_TIMEOUT = 60;
    private static FaceSwapClient instance;
    private final OkHttpClient client;

    private FaceSwapClient() {
        client = new OkHttpClient.Builder()
                .connectTimeout(CONNECT_TIMEOUT, TimeUnit.SECONDS)
                .readTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
                .writeTimeout(WRITE_TIMEOUT, TimeUnit.SECONDS)
                .build();
    }

    public static synchronized FaceSwapClient getInstance() {
        if (instance == null) {
            instance = new FaceSwapClient();
        }
        return instance;
    }

    public void uploadImages(String bikeImageName,
                             String sourceImagePath,
                             String fcmToken,
                             String firebaseAppCheckToken,
                             String appName,
                             FaceSwapCallback callback) {

        if (bikeImageName == null || bikeImageName.isEmpty()) {
            callback.onError("Bike image name cannot be null or empty");
            return;
        }

        if (sourceImagePath == null || sourceImagePath.isEmpty()) {
            callback.onError("Source image path cannot be null or empty");
            return;
        }

        if (fcmToken == null || fcmToken.isEmpty()) {
            callback.onError("FCM token cannot be null or empty");
            return;
        }

        if (firebaseAppCheckToken == null || firebaseAppCheckToken.isEmpty()) {
            callback.onError("Firebase AppCheck token cannot be null or empty");
            return;
        }

        if (appName == null || appName.isEmpty()) {
            callback.onError("App name cannot be null or empty");
            return;
        }

        HttpUrl.Builder urlBuilder = HttpUrl.parse(BASE_URL + bikeImageName).newBuilder();
        if (appName != null) {
            urlBuilder.addQueryParameter("app_name", appName);
        }
        String url = urlBuilder.build().toString();

        // Create multipart form data
        MultipartBody.Builder requestBodyBuilder = new MultipartBody.Builder()
                .setType(MultipartBody.FORM);

        // Add source image only (remove destImage)
        File sourceFile = new File(sourceImagePath);
        if (!sourceFile.exists()) {
            callback.onError("Source image file does not exist");
            return;
        }


        requestBodyBuilder.addFormDataPart("sourceImage",
                sourceFile.getName(),
                RequestBody.create(sourceFile, MediaType.parse("image/*")));

        RequestBody requestBody = requestBodyBuilder.build();

        // Build request
        Request request = new Request.Builder()
                .url(url)
                .post(requestBody)
                .addHeader("accept", "application/json")
                .addHeader("fcmtoken", fcmToken)
                .addHeader("x-firebase-appcheck", firebaseAppCheckToken)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    String responseBody = response.body().string();
                    callback.onSuccess(responseBody);
                } else {
                    String errorMessage = "Request failed: " + response.code();
                    if (response.body() != null) {
                        errorMessage += " - " + response.body().string();
                    }
                    callback.onError(errorMessage);
                }
                response.close();
            }
        });
    }

    public void cancelAllRequests() {
        client.dispatcher().cancelAll();
    }
}