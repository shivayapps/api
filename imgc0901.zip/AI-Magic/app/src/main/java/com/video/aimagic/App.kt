package com.video.aimagic

import android.app.Activity
import android.content.Context
import androidx.multidex.MultiDexApplication
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.openad.AppOpenApplication
import com.google.android.gms.ads.MobileAds
import com.video.aimagic.commonscreen.adapter.MediaItem


class App : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {
    companion object {
        var displayListItem: ArrayList<MediaItem> = ArrayList()
        lateinit var appContext: Context

    }

    override fun onCreate() {
        super.onCreate()
        appContext = applicationContext


        AdsConfig.builder()
            .setTestDeviceId("123")
            .setAdmobAppOpenId(getString(R.string.open_ad))
            .build(this)
        setAppLifecycleListener(this)
        MobileAds.initialize(applicationContext)
        initMobileAds()
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        return false
    }

    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
    }

    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {
    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {
    }
}