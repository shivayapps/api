package com.video.aimagic.faceswap.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.video.aimagic.R;
import com.video.aimagic.faceswap.model.FaceSwapUrl;

import java.util.List;

public class FaceSwapAdapter extends RecyclerView.Adapter<FaceSwapAdapter.ViewHolder> {
    private List<FaceSwapUrl> urls;
    private OnItemClickListener onItemClickListener;

    public interface OnItemClickListener {
        void onItemClick(FaceSwapUrl faceSwapUrl);
    }

    public FaceSwapAdapter(List<FaceSwapUrl> urls, OnItemClickListener onItemClickListener) {
        this.urls = urls;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_face_swap_image, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        FaceSwapUrl url = urls.get(position);
        Glide.with(holder.itemView.getContext())
                .load(url.getUrl())
                .into(holder.imageView);

        holder.itemView.setOnClickListener(v -> {
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(url);
            }
        });
    }

    @Override
    public int getItemCount() {
        return urls != null ? urls.size() : 0;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }
}