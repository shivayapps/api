package com.video.aimagic.commonscreen.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.video.aimagic.R;

import java.io.IOException;
import java.util.List;
import java.util.Random;

public class CreationAdapter
        extends RecyclerView.Adapter<CreationAdapter.VideoViewHolder> {

    private final Context context;
    private final List<MediaItem> list;

    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public CreationAdapter(Context context, List<MediaItem> list, OnItemClickListener listener) {
        this.context = context;
        this.list = list;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VideoViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_creation, parent, false);

        return new VideoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VideoViewHolder holder, int position) {

        MediaItem item = list.get(position);

        holder.txtName.setText(item.name);

        // Load thumbnail
        Glide.with(context)
                .load(item.uri)
                .thumbnail(0.2f)
                .dontAnimate()
                .into(holder.imgThumbnail);

        if (item.type == MediaItem.TYPE_VIDEO) {
            holder.playIcon.setVisibility(View.VISIBLE);
        } else {
            holder.playIcon.setVisibility(View.GONE);
        }

        holder.imgThumbnail.setOnClickListener(v -> {
            listener.onItemClick(position);
        });

        ViewGroup.LayoutParams lp = holder.itemView.getLayoutParams();
        if (lp instanceof StaggeredGridLayoutManager.LayoutParams) {
            ((StaggeredGridLayoutManager.LayoutParams) lp).setFullSpan(false);
        }
    }

//    @Override
//    public void onBindViewHolder(@NonNull VideoViewHolder holder, int position) {
//
//        MediaItem item = list.get(position);
//
//        holder.txtName.setText(item.name);
//
//        // play icon
//        holder.playIcon.setVisibility(
//                item.type == MediaItem.TYPE_VIDEO ? View.VISIBLE : View.GONE
//        );
//
//        int spanCount = 2; // MUST match StaggeredGridLayoutManager
//        int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
//        int itemWidth = screenWidth / spanCount;
//
//        ViewGroup.LayoutParams params = holder.itemView.getLayoutParams();
//
//        // ================= IMAGE =================
//        if (item.type == MediaItem.TYPE_IMAGE) {
//
//            Glide.with(context)
//                    .asBitmap()
//                    .load(item.uri)
//                    .into(new CustomTarget<Bitmap>() {
//                        @Override
//                        public void onResourceReady(
//                                @NonNull Bitmap bitmap,
//                                @Nullable Transition<? super Bitmap> transition) {
//
//                            int bmpWidth = bitmap.getWidth();
//                            int bmpHeight = bitmap.getHeight();
//
//                            if (bmpWidth > 0 && bmpHeight > 0) {
//                                float ratio = (float) bmpWidth / bmpHeight;
//                                params.height = (int) (itemWidth / ratio);
//                                holder.itemView.setLayoutParams(params);
//                            }
//
//                            holder.imgThumbnail.setImageBitmap(bitmap);
//                        }
//
//                        @Override
//                        public void onLoadCleared(@Nullable Drawable placeholder) {
//                            holder.imgThumbnail.setImageDrawable(placeholder);
//                        }
//                    });
//        }
//
//        // ================= VIDEO =================
//        else {
//
//            MediaMetadataRetriever retriever = new MediaMetadataRetriever();
//            try {
//                retriever.setDataSource(context, item.uri);
//
//                int videoWidth = Integer.parseInt(
//                        retriever.extractMetadata(
//                                MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
//
//                int videoHeight = Integer.parseInt(
//                        retriever.extractMetadata(
//                                MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
//
//                if (videoWidth > 0 && videoHeight > 0) {
//                    float ratio = (float) videoWidth / videoHeight;
//                    params.height = (int) (itemWidth / ratio);
//                    holder.itemView.setLayoutParams(params);
//                }
//
//            } catch (Exception e) {
//                // fallback height
//                params.height = itemWidth;
//                holder.itemView.setLayoutParams(params);
//            } finally {
//                try {
//                    retriever.release();
//                } catch (Exception e) {
//
//                }
//            }
//
//            Glide.with(context)
//                    .load(item.uri)
//                    .thumbnail(0.2f)
//                    .centerCrop()
//                    .into(holder.imgThumbnail);
//        }
//
//        // click
//        holder.imgThumbnail.setOnClickListener(v -> {
//            if (listener != null) {
//                listener.onItemClick(position);
//            }
//        });
//
//        // IMPORTANT: prevent full-span bugs
//        ViewGroup.LayoutParams lp = holder.itemView.getLayoutParams();
//        if (lp instanceof StaggeredGridLayoutManager.LayoutParams) {
//            ((StaggeredGridLayoutManager.LayoutParams) lp).setFullSpan(false);
//        }
//    }

//    @Override
//    public void onBindViewHolder(
//            @NonNull VideoViewHolder holder, int position) {
//
//        MediaItem item = list.get(position);
//
//        holder.txtName.setText(item.name);
//        holder.playIcon.setVisibility(
//                item.type == MediaItem.TYPE_VIDEO ? View.VISIBLE : View.GONE
//        );
//
//        int spanCount = 2;
//        int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
//        int itemWidth = screenWidth / spanCount;
//
//        ViewGroup.LayoutParams params = holder.itemView.getLayoutParams();
//
//        Glide.with(context)
//                .load(item.uri)
//                .listener(new RequestListener<Drawable>() {
//                    @Override
//                    public boolean onLoadFailed(
//                            @Nullable GlideException e,
//                            Object model,
//                            Target<Drawable> target,
//                            boolean isFirstResource) {
//                        return false;
//                    }
//
//                    @Override
//                    public boolean onResourceReady(
//                            Drawable resource,
//                            Object model,
//                            Target<Drawable> target,
//                            DataSource dataSource,
//                            boolean isFirstResource) {
//
//                        int width = resource.getIntrinsicWidth();
//                        int height = resource.getIntrinsicHeight();
//
//                        if (width > 0 && height > 0) {
//                            float ratio = (float) width / height;
//                            params.height = (int) (itemWidth / ratio);
//                            holder.itemView.setLayoutParams(params);
//                        }
//
//                        return false; // let Glide continue
//                    }
//                })
//                .thumbnail(0.2f)
//                .centerCrop()
//                .into(holder.imgThumbnail);
//
//        holder.imgThumbnail.setOnClickListener(v -> {
//            if (listener != null) listener.onItemClick(position);
//        });
//
//        ViewGroup.LayoutParams lp = holder.itemView.getLayoutParams();
//        if (lp instanceof StaggeredGridLayoutManager.LayoutParams) {
//            ((StaggeredGridLayoutManager.LayoutParams) lp).setFullSpan(false);
//        }
//    }


    float[] ratios = {
            1f / 1f,   // 1:1
            3f / 4f,   // 3:4
            2f / 3f    // 2:3
    };

    private void applyRandomRatio(View view) {
        float ratio = ratios[new Random().nextInt(ratios.length)];

        int width = view.getResources().getDisplayMetrics().widthPixels / 2;
        int height = (int) (width / ratio);

        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.height = height;
        view.setLayoutParams(params);
    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    static class VideoViewHolder extends RecyclerView.ViewHolder {

        ImageView imgThumbnail;
        ImageView playIcon;
        TextView txtName;

        public VideoViewHolder(@NonNull View itemView) {
            super(itemView);
            imgThumbnail = itemView.findViewById(R.id.imgThumbnail);
            playIcon = itemView.findViewById(R.id.playIcon);
            txtName = itemView.findViewById(R.id.txtTitle);
        }
    }
}
