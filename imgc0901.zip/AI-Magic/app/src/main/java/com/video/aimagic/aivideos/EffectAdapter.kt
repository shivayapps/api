package com.video.aimagic.aivideos

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.video.aimagic.R


import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class EffectAdapter(
    private val effectsList: List<EffectModel>,
    private val context: Context,
    private val listener: (EffectModel) -> Unit
) : RecyclerView.Adapter<EffectAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.ai_video_effect_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val model = effectsList[position]

        holder.mainHead.text = model.main_head

        Glide.with(context).asGif().load(R.drawable.ai_video_loading_animation).into(holder.animationView)
        Glide.with(context).load(model.output_url).into(holder.videoView)

        holder.itemView.setOnClickListener {
            EffectModel.instance.apply {
                effect_name = model.effect_name
                input_image = model.input_image
                output_url = model.output_url
                type = model.type
            }
            listener(model)
        }
    }

    override fun getItemCount() = effectsList.size

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val mainHead = itemView.findViewById<TextView>(R.id.main_head)
        val videoView = itemView.findViewById<ImageView>(R.id.video_view)
        val animationView = itemView.findViewById<ImageView>(R.id.animation_view)
    }
}