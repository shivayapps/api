package com.video.aimagic.transformation.api.resposehandler

import okhttp3.ResponseBody
import retrofit2.Response

sealed class CartoonResult {
    data class Success(val response: Response<ResponseBody>) : CartoonResult()
    data class Error(val errorMessage: String, val code: Int? = null) : CartoonResult()
    object NetworkError : CartoonResult()
    object UnknownError : CartoonResult()
}