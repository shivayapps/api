package com.video.aimagic.babygen.api;

import static android.content.ContentValues.TAG;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.adconfig.adsutil.utils.SmUtils;
import com.video.aimagic.R;
import com.video.aimagic.callback.ApiCallback;
import com.video.aimagic.callback.ResponseCallBack;
import com.video.aimagic.commonscreen.screen.CommonResultScreen;
import com.video.aimagic.singletone.CustomDialogManager;
import com.video.aimagic.singletone.PhotoUploadManager;
import com.video.aimagic.utils.PrefManager;
import com.video.aimagic.utils.appconfig.AppConfig;
import com.video.aimagic.utils.appconfig.StartActivityGlobally;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.lang.ref.WeakReference;

import kotlin.Pair;


public class BabyPredictorRequest {
    private final String TAG = "BabyPredictorRequest";
    private static BabyPredictorRequest instance;
    private WeakReference<Activity> activityRef;
    private ResponseCallBack responseCallBack;
    private PrefManager prefManager;

    private BabyPredictorRequest(Activity activity, ResponseCallBack responseCallBack) {
        this.activityRef = new WeakReference<>(activity);
        this.responseCallBack = responseCallBack;
        this.prefManager = new PrefManager(activity);
    }

    public static synchronized BabyPredictorRequest getInstance(Activity activity, ResponseCallBack responseCallBack) {
        if (instance == null) {
            instance = new BabyPredictorRequest(activity, responseCallBack);
        } else {
            // Update the activity reference each time, in case activity has changed
            instance.setActivity(activity);
            instance.responseCallBack = responseCallBack;
        }
        return instance;
    }

    public void setActivity(Activity activity) {
        this.activityRef = new WeakReference<>(activity);
    }

    private Activity getActivity() {
        return activityRef != null ? activityRef.get() : null;
    }

    public void makeRequest() {
        Activity activity = getActivity();
        if (activity == null) {
            Log.e(TAG, "Error: Activity context is null");
            return;
        }

        String gender = prefManager.getString("gender", "boy");
        String pathFather = prefManager.getString("father");
        String pathMother = prefManager.getString("mother");
        String skinTone = prefManager.getString("selected_skin_tone", "skintone_1");

        PredictRequest request = new PredictRequest()
                .withBabyGender(gender)
                .withBabyCountry("IN")
                .withAppName("NaturePhotoFramesandEditor")
                .withMotherPercent(50)
                .withFatherPercent(50)
                .withSkinTone(skinTone)
                .withAgeGroup("baby")
                .withCountryCode("IN")
                .withPlatform("android")
                .withFcmToken("asdf")
                .withFirebaseAppCheck("asdf")
                .withMotherList("string")
                .withFatherList("string")
                .withMotherImage(new File(pathMother))
                .withFatherImage(new File(pathFather));

        BabyPredictorApiClient.getInstance().predictBabyFeatures(request, new ApiCallback() {
            @Override
            public void onSuccess(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    String requestIdFromResponse = jsonResponse.optString("request_id", "default_id");
                    final String numericRequestId = requestIdFromResponse.replaceAll("[^\\d.]", "").trim();

                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        Log.d(TAG, "response: " + response);
                        processToNextScreen(gender, numericRequestId);
                    }, 10000); // 10 seconds delay

                } catch (JSONException e) {
                    Log.e(TAG, "Error parsing JSON response: " + e.getMessage());
                    showNoServer();
                }
            }

            @Override
            public void onError(String errorMessage) {
                Log.e(TAG, "onError: " + errorMessage);
                showNoServer();
                showToastOnUiThread("Upload failed: " + errorMessage);
            }
        });
    }

    private void processToNextScreen(String gender, String requestId) {
        Activity activity = getActivity();
        if (activity == null) return;

        if (SmUtils.INSTANCE.isConnected(activity)) {
            Log.d(TAG, "Generating baby result");

            String passedAs = "boy".equals(gender) ? AppConfig.FEATURE_BABY_BOY : AppConfig.FEATURE_BABY_GIRL;

            Intent intent = new Intent(activity, CommonResultScreen.class);
            intent.putExtra(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT, requestId);
            intent.putExtra(AppConfig.INTENT_FEATURED_PASSED_AS, passedAs);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.cusotm_slide_in_right, R.anim.custom_slide_out_left);

            responseCallBack.onSuccess("");

            // Safely finish activity
            activity.finish();
        } else {
            showToastOnUiThread("Please connect to internet.");
        }
    }

    private void showToastOnUiThread(final String message) {
        Activity activity = getActivity();
        if (activity != null) {
            new Handler(activity.getMainLooper()).post(() ->
                    Toast.makeText(activity, message, Toast.LENGTH_LONG).show()
            );
        }
    }

    private void showNoServer() {
        Activity activity = getActivity();
        if (activity != null) {
            new Handler(activity.getMainLooper()).post(() ->
                    CustomDialogManager.getInstance().showDialog(
                            activity,
                            "No Server",
                            "We are unable to connect to the server at this time. Please check your internet connection and try again",
                            "Got it",
                            R.drawable.ic_brush,
                            () -> responseCallBack.onSuccess("")
                    )
            );
        }
    }
}


//public class BabyPredictorRequest {
//    private final String TAG = "BabyPredictorRequest";
//    private static BabyPredictorRequest instance;
//    private Activity context;
//    private ResponseCallBack responseCallBack;
//    private PrefManager prefManager;
//    private transient String requestId;
//
//    private BabyPredictorRequest(Activity context, ResponseCallBack responseCallBack) {
////        this.context = context.getApplicationContext();
//        this.context = context;
//        this.responseCallBack = responseCallBack;
//        prefManager = new PrefManager(context);
//    }
//
//    public static synchronized BabyPredictorRequest getInstance(Activity context, ResponseCallBack responseCallBack) {
//        if (instance == null) {
//            instance = new BabyPredictorRequest(context, responseCallBack);
//        }
//        return instance;
//    }
//
//    public void makeRequest(Activity activity) {
////        context=activity;
//        if (context == null) {
//            System.out.println("Error: Context is null");
//            return;
//        }
//        String gender = prefManager.getString("gender", "boy");
//        String pathFather = prefManager.getString("father");
//        String pathMother = prefManager.getString("mother");
//        String skin_tone = prefManager.getString("selected_skin_tone", "skintone_1");
//
//        PredictRequest request = new PredictRequest()
//                .withBabyGender(gender)
//                .withBabyCountry("IN")
//                .withAppName("NaturePhotoFramesandEditor")
//                .withMotherPercent(50)
//                .withFatherPercent(50)
//                .withSkinTone(skin_tone)
////                .withSkinTone("skintone_1")
//                .withAgeGroup("baby")
//                .withCountryCode("IN")
//                .withPlatform("android")
//                .withFcmToken("asdf")
//                .withFirebaseAppCheck("asdf")
//                .withMotherList("string")
//                .withFatherList("string")
//                .withMotherImage(new File(pathMother))
//                .withFatherImage(new File(pathFather));
////                .withMotherImage(new File(PhotoUploadManager.getInstance().getCurrentImageUriStringPath()))
////                .withFatherImage(new File(PhotoUploadManager.getInstance().getCurrentImageUriStringPath()));
//
//
//        BabyPredictorApiClient.getInstance().predictBabyFeatures(request, new ApiCallback() {
//            @Override
//            public void onSuccess(String response) {
//                try {
//                    JSONObject jsonResponse = new JSONObject(response);
//                    String requestIdFromResponse = jsonResponse.optString("request_id", "default_id");
//
//                    final String numericRequestId = requestIdFromResponse.replaceAll("[^\\d.]", "").trim();
//
//                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            Log.d(TAG, "response:===========> " + response);
////                            showToastOnUiThread("Upload successful: " + numericRequestId);
//                            processToNextScreen(gender, numericRequestId);
//                        }
//                    }, 10000);
//
//                } catch (JSONException e) {
//                    Log.e(TAG, "Error parsing JSON response: " + e.getMessage());
//                    final String fallbackId = String.valueOf(System.currentTimeMillis());
//                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            Log.d(TAG, "response:===========> " + response);
////                            showToastOnUiThread("Upload successful with fallback ID");
//                            showNoServer();
//                        }
//                    }, 10000);
//                }
//            }
//
//            @Override
//            public void onError(String errorMessage) {
//                Log.d(TAG, "onError:===========> " + errorMessage);
//                showNoServer();
//                showToastOnUiThread("Upload failed: " + errorMessage);
//            }
//        });
//    }
//
//    private void showToastOnUiThread(final String message) {
//        if (context != null) {
//            android.os.Handler handler = new android.os.Handler(context.getMainLooper());
//            handler.post(new Runnable() {
//                @Override
//                public void run() {
//                    Toast.makeText(context, message, Toast.LENGTH_LONG).show();
//                }
//            });
//        }
//    }
//
//
//    private void showNoServer() {
//        if (context != null) {
//            android.os.Handler handler = new android.os.Handler(context.getMainLooper());
//            handler.post(new Runnable() {
//                @Override
//                public void run() {
//                    Log.e("showNoServer", "001");
//                    CustomDialogManager.getInstance().showDialog(
//                            context,
//                            "No Server",
//                            "We are unable to connect to the server at this time. Please check your internet connection and try again",
//                            "Got it",
//                            R.drawable.ic_brush,
//                            new CustomDialogManager.DialogButtonClickListener() {
//                                @Override
//                                public void onButtonClicked() {
//                                    responseCallBack.onSuccess("");
//                                    //((Activity) context).finish();
//                                }
//                            }
//                    );
//
//                }
//            });
//        }
//    }
//
//
//    @SuppressWarnings("unchecked")
//    private void processToNextScreen(String gender, String requestId) {
//        if (SmUtils.INSTANCE.isConnected(context)) {
//            Log.d(TAG, "Generate face swap button clicked");
////            StartActivityGlobally.navigateToActivityWithFeature(
////                    context,
////                    CommonResultScreen.class,
////                    new Pair<>(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT, requestId),
////                    new Pair<>(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_BABY_BOY)
////            );
//
//            String PASSED_AS = AppConfig.FEATURE_BABY_BOY;
//            if (gender == "boy") PASSED_AS = AppConfig.FEATURE_BABY_BOY;
//            else PASSED_AS = AppConfig.FEATURE_BABY_GIRL;
//
//
//            Intent intent = new Intent(context, CommonResultScreen.class);
//            intent.putExtra(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT, requestId);
////            intent.putExtra(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_BABY_BOY);
//            intent.putExtra(AppConfig.INTENT_FEATURED_PASSED_AS, PASSED_AS);
//            context.startActivity(intent);
//            context.overridePendingTransition(
//                    R.anim.cusotm_slide_in_right,
//                    R.anim.custom_slide_out_left
//            );
//            responseCallBack.onSuccess("");
//
//            ((Activity) context).finish();
//        } else {
//            Toast.makeText(context, "Please connect to internet.", Toast.LENGTH_SHORT).show();
//        }
//
//    }
//
//
//    public void setContext(Activity context) {
////        this.context = context.getApplicationContext();
//        this.context = context;
//    }
//}