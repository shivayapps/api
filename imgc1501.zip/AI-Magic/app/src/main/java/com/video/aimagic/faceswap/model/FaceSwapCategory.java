package com.video.aimagic.faceswap.model;


import java.util.List;

import java.io.Serializable;

public class FaceSwapCategory implements Serializable {
    private String key;
    private List<FaceSwapUrl> urls;
    private String otherNonProperty;
    private LocalizedName catNameLocalised;
    private String gender;

    public FaceSwapCategory(String key, List<FaceSwapUrl> urls, String otherNonProperty,
                            LocalizedName catNameLocalised, String gender) {
        this.key = key;
        this.urls = urls;
        this.otherNonProperty = otherNonProperty;
        this.catNameLocalised = catNameLocalised;
        this.gender = gender;
    }

    // Getters and setters
    public String getKey() { return key; }
    public void setKey(String key) { this.key = key; }

    public List<FaceSwapUrl> getUrls() { return urls; }
    public void setUrls(List<FaceSwapUrl> urls) { this.urls = urls; }

    public String getOtherNonProperty() { return otherNonProperty; }
    public void setOtherNonProperty(String otherNonProperty) { this.otherNonProperty = otherNonProperty; }

    public LocalizedName getCatNameLocalised() { return catNameLocalised; }
    public void setCatNameLocalised(LocalizedName catNameLocalised) { this.catNameLocalised = catNameLocalised; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
}