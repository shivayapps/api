package com.video.aimagic.commonscreen.screen;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.video.aimagic.R;
import com.video.aimagic.databinding.ActivityOnLaunchBinding;
import com.video.aimagic.extension.ExtensionsKt;
import com.video.aimagic.onboardingflow.dataset.CustomOnBoardingPrefManager;
import com.video.aimagic.onboardingflow.screen.CustomOnBoardingActivity;
import com.video.aimagic.utils.appconfig.AppConfig;
import com.video.aimagic.utils.appconfig.StartActivityGlobally;

public class OnLaunchScreen extends AppCompatActivity {


    private final String TAG = "OnLaunchScreen";
    private ActivityOnLaunchBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOnLaunchBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.setStatusBarFontColor(this,false);
//        ExtensionsKt.applySystemBarInsets(binding.getRoot());

        setGradientColorToText();
        setOnClickListener();
        setUpSplashVideo();

    }

    private void setUpSplashVideo() {

        String videoUriString =
                "android.resource://" + OnLaunchScreen.this.getPackageName() + "/" + R.raw.splash_vid;
        Uri videoUri = Uri.parse(videoUriString);
        binding.splshVideo.setVideoURI(videoUri);

        binding.splshVideo.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {

                mediaPlayer.setLooping(true);
                binding.splshVideo.start();
            }
        });

        binding.splshVideo.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                Log.d(TAG, "onError:===========> " + what + ", extra=" + extra);
                Log.e("VideoError", "Can't play video. what=" + what + ", extra=" + extra);
                return true;
            }
        });

    }

    private void setOnClickListener() {

        binding.getStartedBtn.setOnClickListener(v -> {
            if (new CustomOnBoardingPrefManager(OnLaunchScreen.this).getInitialAppLaunch()) {
//                navigateUser(CustomOnBoardingActivity.class);
                Intent intent = new Intent(OnLaunchScreen.this, CustomOnBoardingActivity.class);
                startActivity(intent);
                finish();
            } else {
//                navigateUser(HomeScreen.class);
                Intent intent = new Intent(OnLaunchScreen.this, HomeScreen.class);
                startActivity(intent);
                finish();
//                navigateUser(CustomOnBoardingActivity.class);
            }
        });
    }


//    @SuppressWarnings("unchecked")
//    private void navigateUser(Class<? extends Activity> targetActivity) {
//        StartActivityGlobally.navigateToActivityWithFeature(OnLaunchScreen.this, targetActivity);
//        finish();
//    }

    private void setGradientColorToText() {
        Shader textShader = new LinearGradient(
                0, 0,
                binding.appName.getPaint().measureText(binding.appName.getText().toString()), // end x
                0,
                new int[]{
                        Color.parseColor("#FB5CD8"),
                        Color.parseColor("#EF60B3"),
                        Color.parseColor("#9F3CD2")
                },
                null,
                Shader.TileMode.CLAMP
        );
        binding.appName.getPaint().setShader(textShader);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}