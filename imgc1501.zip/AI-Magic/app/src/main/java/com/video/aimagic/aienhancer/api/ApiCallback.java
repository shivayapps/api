package com.video.aimagic.aienhancer.api;

public interface ApiCallback {
    void onSuccess(String response);
    void onError(String errorMessage);
}