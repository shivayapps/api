package com.video.aimagic.bodyeditor.screens;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.video.aimagic.R;
import com.video.aimagic.databinding.ActivityChestEditorBinding;
import com.video.aimagic.bodyeditor.manualedit.ViewFace;
import com.video.aimagic.extension.ExtensionsKt;
import com.video.aimagic.singletone.PhotoUploadManager;

import java.util.Stack;

public class ChestEditor extends AppCompatActivity {

    Bitmap mBitmap, faceBitmap, saveBitmap;
    boolean maskareaValuesadded;
    ViewFace breastView1, breastView2;
    private ActivityChestEditorBinding binding;
    private float pw;
    private float px;
    private float py;
    private float ratio;
    private float ph;
    private float pw1;
    private float px1;
    private float py1;
    private float ratio1;
    private float ph1;
    private SeekBar.OnSeekBarChangeListener seekBarChangeListener = new SeekChange();
    private Stack<EditState> undoStack = new Stack<>();
    private Stack<EditState> redoStack = new Stack<>();
    private int lastProgress = 0;
    private boolean isProgrammaticSeekBarChange = false;
    private float[] sourceVerts;
    private float[] warpedVerts;
    private int meshWidth;
    private float cellSize;
    private int faceX, faceY;
    private Bitmap faceBitmap2;
    private float[] sourceVerts2;
    private float[] warpedVerts2;
    private int meshWidth2;
    private float cellSize2;
    private int faceX2, faceY2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityChestEditorBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        ExtensionsKt.setStatusBarFontColor(this,false);
        setInitData();
        setSeekBarView();
        setOnClickListners();
    }

    private void setInitData() {
        mBitmap = PhotoUploadManager.getInstance().getUniversalBitmap();
        this.breastView1 = this.binding.chest1;
        this.breastView2 = this.binding.chest2;
        this.breastView1.imageView = this.binding.bodyPreviewImage;
        this.breastView2.imageView = this.binding.bodyPreviewImage;

        breastView1.setScale(0.3f,1.0f);
        breastView2.setScale(0.3f,1.0f);
        binding.bodyPreviewImage.setImageBitmap(mBitmap);
    }

    private void setSeekBarView() {
        binding.changeHipsSeekBar.setMin(-50);
        binding.changeHipsSeekBar.setMax(50);
        binding.changeHipsSeekBar.setProgress(0);
        binding.changeHipsSeekBar.setOnSeekBarChangeListener(seekBarChangeListener);
    }

    private void setOnClickListners() {
        binding.undoFace.setOnClickListener(v -> {
            undo();
        });
        binding.reduFace.setOnClickListener(v -> {
            redo();
        });

        binding.applyBtn.setOnClickListener(v -> {
            finish();
        });
    }

    private void updateUndoRedoIcons() {
        if (!undoStack.isEmpty()) {
            binding.undoFace.setImageResource(R.drawable.body_undo_enable);
            binding.undoFace.setEnabled(true);
        } else {
            binding.undoFace.setImageResource(R.drawable.body_undo_disable);
            binding.undoFace.setEnabled(false);
        }

        if (!redoStack.isEmpty()) {
            binding.reduFace.setImageResource(R.drawable.body_redu_enable);
            binding.reduFace.setEnabled(true);
        } else {
            binding.reduFace.setImageResource(R.drawable.body_redu_disable);
            binding.reduFace.setEnabled(false);
        }
    }


    public void undo() {
        if (!undoStack.isEmpty()) {
            redoStack.push(new EditState(saveBitmap, lastProgress));

            EditState previous = undoStack.pop();
            binding.bodyPreviewImage.setImageBitmap(previous.bitmap);
            saveBitmap = previous.bitmap;
            lastProgress = previous.progress;

            isProgrammaticSeekBarChange = true;
            binding.changeHipsSeekBar.setProgress(previous.progress);
            isProgrammaticSeekBarChange = false;

        }
    }

    public void redo() {
        if (!redoStack.isEmpty()) {
            undoStack.push(new EditState(saveBitmap, lastProgress));

            EditState next = redoStack.pop();
            binding.bodyPreviewImage.setImageBitmap(next.bitmap);
            saveBitmap = next.bitmap;
            lastProgress = next.progress;

            isProgrammaticSeekBarChange = true;
            binding.changeHipsSeekBar.setProgress(next.progress); // <-- Update SeekBar
            isProgrammaticSeekBarChange = false;


        }
    }

    public void createFilter(int pro) {


        if (saveBitmap != null) {
            undoStack.push(new EditState(saveBitmap, lastProgress));
            PhotoUploadManager.getInstance().setUniversalBitmap(saveBitmap);
            redoStack.clear();
        } else {
            // First time use
            undoStack.push(new EditState(mBitmap, 0));
            redoStack.clear();
        }

        lastProgress = pro; // Save current progress


        Bitmap b = applyWarp(mBitmap, faceX, faceY, pro);
        b = applyWarp2(b, faceX2, faceY2, pro);
        // imageView.setImageBitmap(result);


        binding.bodyPreviewImage.setImageBitmap(b);
        saveBitmap = b;


    }

    public Bitmap applyWarp(Bitmap fullImage, int faceX, int faceY, long progress) {
        float factor = (float) progress / 75.0f;

        for (int i = 0; i < warpedVerts.length; i += 2) {
            int x = (i / 2) % (meshWidth + 1);
            int y = (i / 2) / (meshWidth + 1);
            float fx = x * cellSize;
            float fy = y * cellSize;
            warpedVerts[i] = (sourceVerts[i] * factor) + fx;
            warpedVerts[i + 1] = (sourceVerts[i + 1] * factor) + fy;
        }

        Bitmap result = Bitmap.createBitmap(fullImage.getWidth(), fullImage.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawBitmap(fullImage, 0, 0, null);

        Bitmap faceCopy = faceBitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas faceCanvas = new Canvas(faceCopy);
        faceCanvas.drawBitmapMesh(faceBitmap, meshWidth, meshWidth, warpedVerts, 0, null, 0, null);

        canvas.drawBitmap(faceCopy, faceX, faceY, null);
        faceCopy.recycle();

        return result;
    }

    public Bitmap applyWarp2(Bitmap fullImage, int faceX, int faceY, long progress) {
        float factor = (float) progress / 75.0f;

        for (int i = 0; i < warpedVerts2.length; i += 2) {
            int x = (i / 2) % (meshWidth2 + 1);
            int y = (i / 2) / (meshWidth2 + 1);
            float fx = x * cellSize2;
            float fy = y * cellSize2;
            warpedVerts2[i] = (sourceVerts2[i] * factor) + fx;
            warpedVerts2[i + 1] = (sourceVerts2[i + 1] * factor) + fy;
        }

        Bitmap result = Bitmap.createBitmap(fullImage.getWidth(), fullImage.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawBitmap(fullImage, 0, 0, null);

        Bitmap faceCopy = faceBitmap2.copy(Bitmap.Config.ARGB_8888, true);
        Canvas faceCanvas = new Canvas(faceCopy);
        faceCanvas.drawBitmapMesh(faceBitmap2, meshWidth2, meshWidth2, warpedVerts2, 0, null, 0, null);

        canvas.drawBitmap(faceCopy, faceX, faceY, null);
        faceCopy.recycle();

        return result;
    }

    private void setupMesh() {
        int count = (meshWidth + 1) * (meshWidth + 1) * 2;
        sourceVerts = new float[count];
        warpedVerts = new float[count];
        cellSize = (float) faceBitmap.getWidth() / meshWidth;

        float center = faceBitmap.getWidth() / 2f;
        for (int i = 0; i < count; i += 2) {
            int idx = i / 2;
            int x = idx % (meshWidth + 1);
            int y = idx / (meshWidth + 1);
            float fx = x * cellSize - center;
            float fy = y * cellSize - center;
            float dist = (float) Math.sqrt(fx * fx + fy * fy);
            float scale = (center - dist) / center;
            if (scale < 0) scale = 0;
            sourceVerts[i] = fx * scale;
            sourceVerts[i + 1] = fy * scale;
        }

        int count2 = (meshWidth2 + 1) * (meshWidth2 + 1) * 2;
        sourceVerts2 = new float[count2];
        warpedVerts2 = new float[count2];
        cellSize2 = (float) faceBitmap2.getWidth() / meshWidth2;

        float center2 = faceBitmap2.getWidth() / 2f;
        for (int i = 0; i < count2; i += 2) {
            int idx = i / 2;
            int x = idx % (meshWidth2 + 1);
            int y = idx / (meshWidth2 + 1);
            float fx = x * cellSize2 - center2;
            float fy = y * cellSize2 - center2;
            float dist = (float) Math.sqrt(fx * fx + fy * fy);
            float scale = (center2 - dist) / center2;
            if (scale < 0) scale = 0;
            sourceVerts2[i] = fx * scale;
            sourceVerts2[i + 1] = fy * scale;
        }
    }

    private void showSeekBarView() {

        binding.changeHipsSeekBar.setVisibility(View.VISIBLE);

    }

    private void getMaskArea() {
        if (!maskareaValuesadded) {
            maskareaValuesadded = true;

            pw = breastView1.getWidth() * breastView1.getScaleX();
            ph = breastView1.getHeight() * breastView1.getScaleY();
            px = breastView1.getX() + ((breastView1.getWidth() - pw) / 2.0f);
            py = breastView1.getY() + ((breastView1.getHeight() - ph) / 2.0f);
            ratio = (float) mBitmap.getHeight() / (float) binding.implimentedView.getHeight();

            int cropW = (int) (pw * ratio);
            int cropH = (int) (ph * ratio);
            faceX = (int) (px * ratio);
            faceY = (int) (py * ratio);

            faceBitmap = Bitmap.createBitmap(mBitmap, faceX, faceY, cropW, cropH);

            pw1 = breastView2.getWidth() * breastView2.getScaleX();
            ph1 = breastView2.getHeight() * breastView2.getScaleY();
            px1 = breastView2.getX() + ((breastView2.getWidth() - pw1) / 2.0f);
            py1 = breastView2.getY() + ((breastView2.getHeight() - ph1) / 2.0f);
            ratio1 = (float) mBitmap.getHeight() / (float) binding.implimentedView.getHeight();

            int cropW1 = (int) (pw1 * ratio1);
            int cropH1 = (int) (ph1 * ratio1);
            faceX2 = (int) (px1 * ratio1);
            faceY2 = (int) (py1 * ratio1);

            faceBitmap2 = Bitmap.createBitmap(mBitmap, faceX2, faceY2, cropW1, cropH1);

            showSeekBarView();
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }

    class SeekChange implements SeekBar.OnSeekBarChangeListener {

        @Override
        public void onProgressChanged(SeekBar seekBar, int progress,
                                      boolean fromUser) {
            if (isProgrammaticSeekBarChange) return;
            meshWidth = 10;
            meshWidth2 = 10;
            getMaskArea();
            setupMesh();

            createFilter(seekBar.getProgress());
            if (binding.applyBtn.getVisibility() == View.GONE) {
                binding.applyBtn.setVisibility(View.VISIBLE);
            }


        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            if (isProgrammaticSeekBarChange) return;
            updateUndoRedoIcons();
        }

    }
}