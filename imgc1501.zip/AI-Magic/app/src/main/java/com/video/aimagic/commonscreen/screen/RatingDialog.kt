package com.video.aimagic.commonscreen.screen

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.RatingBar
import com.video.aimagic.R
import com.video.aimagic.databinding.DialogRatingBinding
import com.video.aimagic.utils.Methods

class RatingDialog(context: Context) : Dialog(context), RatingBar.OnRatingBarChangeListener,
    View.OnClickListener {
    private lateinit var binding: DialogRatingBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DialogRatingBinding.inflate(layoutInflater)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        setContentView(
            binding.root
        )
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        initViews()
    }

    private fun initViews() {
        binding.submitBtn.apply {
            setOnClickListener(this@RatingDialog)
        }
        binding.cancelBtn.apply {
            setOnClickListener(this@RatingDialog)
        }
        binding.ratingBar.apply {
            onRatingBarChangeListener = this@RatingDialog
        }
    }

    override fun onRatingChanged(p0: RatingBar?, rating: Float, p2: Boolean) {
        if (p2) {
            binding.ratingBar.rating = rating
            if (rating > 4f) {
                Methods.rateApp(context)
                dismiss()
            } else if (rating != 0f) {
                binding.submitBtn.isEnabled = true
            }
        }
    }

    override fun onClick(p0: View?) {
        when (p0?.id) {
            R.id.submitBtn -> {
                if (binding.ratingBar.rating > 3f) {
                    Methods.rateApp(context)
                } else {
                    Methods.feedBackSupport(context,"")
                }
                dismiss()
            }

            R.id.cancelBtn -> {
                dismiss()
            }
        }
    }
}