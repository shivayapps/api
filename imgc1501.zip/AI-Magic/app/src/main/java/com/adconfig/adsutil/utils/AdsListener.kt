package com.adconfig.adsutil.utils

import com.google.android.gms.ads.AdValue



data class AdsError(
    val code: Int,
    val error: String
)

interface AdsListener {
    fun onAdClicked()

    fun onAdDismissed()

    fun onAdLoaded(appOpenAd: Any)

    fun onAdLoaded()

    fun onAdFailedToShow(adsError: AdsError)

    fun onAdImpression()

    fun onAdShowed()

}

//interface ImpressionListener {
//    fun sendAdImpressionRevenueToFirebase(adValue: AdValue, adUnitId: String)
//}