package com.adconfig.adsutil.admob

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import androidx.constraintlayout.widget.ConstraintLayout

import com.facebook.shimmer.ShimmerFrameLayout
import com.adconfig.checkLibrary
import com.video.aimagic.R

class ShimmerHelper(
    private val mContext: Context,
    private val frameLayout: FrameLayout,
    private val mLayoutType: NativeLayoutType? = NativeLayoutType.NativeMedium,
) {

    val TAG = "ADCONFIG_NativeAdHelper"
    private var mShimmerLayout: Int = R.layout.layout_shimmer_google_native_ad_banner
    private var mShimmerView: ShimmerFrameLayout? = null
    public fun start() {
        try {
            when (mLayoutType) {
                NativeLayoutType.NativeSmall -> {//small
                    mShimmerLayout = R.layout.layout_shimmer_google_native_ad_small
                }
                NativeLayoutType.NativeBanner -> {//banner
                    mShimmerLayout = R.layout.layout_shimmer_google_native_ad_banner
                }
                NativeLayoutType.NativeMedium -> {//medium
                    mShimmerLayout = R.layout.layout_shimmer_google_native_ad_medium
                }
                NativeLayoutType.NativeButtonBottom -> {//button_bottom
                    mShimmerLayout = R.layout.layout_shimmer_google_native_ad_banner_bottom
                }
                NativeLayoutType.NativeBig -> {//big
                    mShimmerLayout = R.layout.layout_shimmer_google_native_ad_big
                }
                else -> {
                    mShimmerLayout = R.layout.layout_shimmer_google_native_ad_medium
                }
            }
        } finally {
//            frameLayout.recycle()
        }


        val mShimmerLayout = LayoutInflater.from(mContext).inflate(mShimmerLayout, null) as ConstraintLayout
        mShimmerView = mShimmerLayout.findViewById(R.id.shimmerView)

        frameLayout.visibility = View.VISIBLE
        frameLayout.removeAllViews()

        frameLayout.addView(mShimmerLayout)
        mShimmerView?.startShimmer()

    }

}