package com.video.aimagic.commonscreen.data

enum class DrawableCategory {
    SOLID,
    GRADIENT,
    TRENDING
}
