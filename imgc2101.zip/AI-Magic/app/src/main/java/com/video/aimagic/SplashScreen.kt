package com.video.aimagic

import android.content.Intent
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.video.aimagic.commonscreen.screen.HomeScreen
import com.video.aimagic.databinding.ActivitySplashBinding
import com.video.aimagic.onboardingflow.dataset.CustomOnBoardingPrefManager
import com.video.aimagic.onboardingflow.screen.CustomOnBoardingActivity
import com.video.aimagic.utils.appconfig.AppConfig
import com.video.aimagic.utils.appconfig.RemoteConfigPref
import com.video.aimagic.utils.appconfig.initFirebaseConfig
import okhttp3.internal.http2.Http2Reader

class SplashScreen : AppCompatActivity() {

    private val TAG = "OnLaunchScreen"
    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        setGradientColorToText()

        if(RemoteConfigPref(this).isRemoteInit) {
            initFirebaseConfig {
                loadAds()
            }
        }else{
            Handler(Looper.getMainLooper()).postDelayed({
                initFirebaseConfig {
                    loadAds()
                }
            }, 3000)
        }
    }

    private fun loadAds() {
        val interAdId = getString(R.string.inter_ad)
        AdmobIntersAdImpl().load(this, interAdId) { isLoaded ->
            Log.d(TAG, "Interstitial loaded: $isLoaded")
            showAdAndNavigate()
        }
    }

    private fun showAdAndNavigate() {
        AdsConfig.showInterstitialAd(this) {
            navigateNext()
            true
        }
    }

    private fun navigateNext() {
        val prefManager = CustomOnBoardingPrefManager(this)

        val targetIntent = if (prefManager.initialAppLaunch) {
            prefManager.initialAppLaunch = false
            Intent(this, CustomOnBoardingActivity::class.java)
        } else {
            Intent(this, HomeScreen::class.java)
        }

        targetIntent.putExtra(
            AppConfig.INTENT_FEATURED_PASSED_AS,
            AppConfig.FEATURE_BABY_GIRL
        )

        startActivity(targetIntent)

        overridePendingTransition(
            R.anim.cusotm_slide_in_right,
            R.anim.custom_slide_out_left
        )
        finish()
    }

    private fun setGradientColorToText() {
        val text = binding.tvTitle.text.toString()
        val textWidth = binding.tvTitle.paint.measureText(text)

        val shader = LinearGradient(
            0f,
            0f,
            textWidth,
            0f,
            intArrayOf(
                Color.parseColor("#FB5CD8"),
                Color.parseColor("#EF60B3"),
                Color.parseColor("#9F3CD2")
            ),
            null,
            Shader.TileMode.CLAMP
        )

        binding.tvTitle.paint.shader = shader
    }

    override fun onDestroy() {
        super.onDestroy()
        // no need to null binding in Kotlin unless using nullable
    }
}
