package com.video.aimagic.aivideos;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.video.aimagic.R;
import com.video.aimagic.databinding.ActivityDoubleAivideoScreenBinding;
import com.video.aimagic.extension.ExtensionsKt;

public class DoubleAIVideoScreen extends AppCompatActivity {

    private ActivityDoubleAivideoScreenBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityDoubleAivideoScreenBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        ExtensionsKt.setStatusBarFontColor(this,false);
        setUpTab();
    }

    private void setUpTab() {
        String[] titles = {"Individual", "Couple"};
        for (int i = 0; i < titles.length; i++) {
            String title = titles[i];
            TabLayout.Tab tab = binding.tabLay.newTab();
            View customView = LayoutInflater.from(this).inflate(R.layout.ai_video_new_custom_tab_layout_new_new, null);

            TextView tabText = customView.findViewById(R.id.tabText);

            tabText.setText(title);

            tab.setCustomView(customView);
            binding.tabLay.addTab(tab);
        }

        // Use CoupleDoubleFragmentLoder instead of AIVideoImageSliderAdapter
        binding.tabviewpager.setAdapter(new CoupleDoubleFragmentLoder(getSupportFragmentManager(), getLifecycle()));

        binding.tabLay.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                binding.tabviewpager.setCurrentItem(tab.getPosition());
                View customView = tab.getCustomView();
                if (customView != null) {
                    customView.setSelected(true);
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                if (customView != null) {
                    customView.setSelected(false);
                }
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // Do nothing
            }
        });

        binding.tabviewpager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                binding.tabLay.selectTab(binding.tabLay.getTabAt(position));
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Clean up binding reference to prevent memory leaks
        binding = null;
    }
}