package com.video.aimagic.utils

import android.app.Activity
import com.video.aimagic.backgroundchanger.BackgroundChangeScreen
import com.video.aimagic.commonscreen.screen.CommonProcessing
import com.video.aimagic.commonscreen.screen.CropScreen
import java.lang.ref.WeakReference
import java.util.Collections

object ActivityUtils {

    private val activityRefs =
        Collections.synchronizedList(mutableListOf<WeakReference<Activity>>())

    /** Register any Activity */
    fun register4Finish(activity: Activity) {
        // Remove dead references
        activityRefs.removeAll { it.get() == null }

        // Avoid duplicate registration
        if (activityRefs.none { it.get() === activity }) {
            activityRefs.add(WeakReference(activity))
        }
    }

    /** Finish all registered activities that are still alive */
    fun finishAllRegistered() {
        val iterator = activityRefs.iterator()
        while (iterator.hasNext()) {
            val activity = iterator.next().get()

            if (activity == null) {
                iterator.remove()
                continue
            }

            if (!activity.isFinishing && !activity.isDestroyed) {
                activity.finish()
            }

            iterator.remove()
        }
    }

//    private var backgroundChangeRef = WeakReference<Activity>(null)
//    private var commonProcessingRef = WeakReference<Activity>(null)
//    private var cropScreenRef = WeakReference<Activity>(null)
//
//    fun registerBackgroundChange(activity: BackgroundChangeScreen) {
//        backgroundChangeRef = WeakReference(activity)
//    }
//
//    fun registerCommonProcessing(activity: CommonProcessing) {
//        commonProcessingRef = WeakReference(activity)
//    }
//
//    fun registerCropScreen(activity: CropScreen) {
//        cropScreenRef = WeakReference(activity)
//    }
//
//    fun finishBackgroundChangeActivity() {
//        backgroundChangeRef.get()?.let { activity ->
//            if (!activity.isFinishing && !activity.isDestroyed) {
//                activity.finish()
//            }
//        }
//        backgroundChangeRef.clear()
//    }
//
//    fun finishCommonProcessingActivity() {
//        commonProcessingRef.get()?.let { activity ->
//            if (!activity.isFinishing && !activity.isDestroyed) {
//                activity.finish()
//            }
//        }
//        commonProcessingRef.clear()
//    }
//
//    fun finishCropActivity() {
//        cropScreenRef.get()?.let { activity ->
//            if (!activity.isFinishing && !activity.isDestroyed) {
//                activity.finish()
//            }
//        }
//        cropScreenRef.clear()
//    }
}
