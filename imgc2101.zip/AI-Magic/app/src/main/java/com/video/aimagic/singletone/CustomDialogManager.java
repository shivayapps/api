package com.video.aimagic.singletone;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.Nullable;

import com.video.aimagic.R;

import java.lang.ref.WeakReference;

public class CustomDialogManager {

    private static CustomDialogManager instance;
    private Dialog currentDialog;
    private WeakReference<Activity> activityRef;

    private CustomDialogManager() {
    }

    public static synchronized CustomDialogManager getInstance() {
        if (instance == null) {
            instance = new CustomDialogManager();
        }
        return instance;
    }

    public interface DialogButtonClickListener {
        void onButtonClicked();
    }


    public void showDialog(Context context,
                           String heading,
                           String description,
                           String buttonText,
                           @Nullable Drawable imageDrawable,
                           @Nullable final DialogButtonClickListener listener) {

        //dismissDialog();

        currentDialog = new Dialog(context);
        currentDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        currentDialog.setContentView(R.layout.custom_dialog);
        currentDialog.setCancelable(false);

        Window window = currentDialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);

            // Set dialog width to match parent and height to wrap content
            WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
            layoutParams.copyFrom(window.getAttributes());
            layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
            layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
            window.setAttributes(layoutParams);
        }

        ImageView imageView = currentDialog.findViewById(R.id.dialog_image);
        TextView headingTextView = currentDialog.findViewById(R.id.dialog_heading);
        TextView descriptionTextView = currentDialog.findViewById(R.id.dialog_description);
        TextView actionButton = currentDialog.findViewById(R.id.dialog_button);

        headingTextView.setText(heading);
        descriptionTextView.setText(description);
        actionButton.setText(buttonText);

        if (imageDrawable != null) {
            imageView.setImageDrawable(imageDrawable);
            imageView.setVisibility(View.VISIBLE);
        } else {
            imageView.setVisibility(View.GONE);
        }

        actionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onButtonClicked();
                }
                dismissDialog();
            }
        });

        currentDialog.show();
    }

    public void showDialog(Activity context,
                           String heading,
                           String description,
                           String buttonText,
                           @DrawableRes int imageResId,
                           @Nullable final DialogButtonClickListener listener) {

        Drawable drawable = null;
        if (imageResId != 0) {
            drawable = context.getResources().getDrawable(imageResId);
        }
        showDialog(context, heading, description, buttonText, drawable, listener);
    }

    public void showDialog(Context context,
                           String heading,
                           String description,
                           String buttonText,
                           @Nullable final DialogButtonClickListener listener) {
        showDialog(context, heading, description, buttonText, (Drawable) null, listener);
    }

    public void dismissDialog() {
        if (currentDialog != null && currentDialog.isShowing()) {
            Activity activity = activityRef != null ? activityRef.get() : null;

            if (activity != null && !activity.isFinishing() && !activity.isDestroyed()) {
                currentDialog.dismiss();
            }
        }
        currentDialog = null;
        activityRef = null;
    }

    public boolean isShowing() {
        return currentDialog != null && currentDialog.isShowing();
    }
}

//public class CustomDialogManager {
//
//    private static CustomDialogManager instance;
//    private Dialog currentDialog;
//
//    private CustomDialogManager() {
//        // Private constructor to prevent instantiation
//    }
//
//    public static synchronized CustomDialogManager getInstance() {
//        if (instance == null) {
//            instance = new CustomDialogManager();
//        }
//        return instance;
//    }
//
//    public interface DialogButtonClickListener {
//        void onButtonClicked();
//    }
//
//    public void showDialog(Context context,
//                           String heading,
//                           String description,
//                           String buttonText,
//                           @Nullable Drawable imageDrawable,
//                           @Nullable final DialogButtonClickListener listener) {
//
//        //dismissDialog();
//
//        currentDialog = new Dialog(context);
//        currentDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        currentDialog.setContentView(R.layout.custom_dialog);
//        currentDialog.setCancelable(false);
//
//        Window window = currentDialog.getWindow();
//        if (window != null) {
//            window.setBackgroundDrawableResource(android.R.color.transparent);
//
//            // Set dialog width to match parent and height to wrap content
//            WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
//            layoutParams.copyFrom(window.getAttributes());
//            layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
//            layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
//            window.setAttributes(layoutParams);
//        }
//
//        ImageView imageView = currentDialog.findViewById(R.id.dialog_image);
//        TextView headingTextView = currentDialog.findViewById(R.id.dialog_heading);
//        TextView descriptionTextView = currentDialog.findViewById(R.id.dialog_description);
//        TextView actionButton = currentDialog.findViewById(R.id.dialog_button);
//
//        headingTextView.setText(heading);
//        descriptionTextView.setText(description);
//        actionButton.setText(buttonText);
//
//        if (imageDrawable != null) {
//            imageView.setImageDrawable(imageDrawable);
//            imageView.setVisibility(View.VISIBLE);
//        } else {
//            imageView.setVisibility(View.GONE);
//        }
//
//        actionButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (listener != null) {
//                    listener.onButtonClicked();
//                }
//                dismissDialog();
//            }
//        });
//
//        currentDialog.show();
//    }
//
//    public void showDialog(Activity context,
//                           String heading,
//                           String description,
//                           String buttonText,
//                           @DrawableRes int imageResId,
//                           @Nullable final DialogButtonClickListener listener) {
//
//        Drawable drawable = null;
//        if (imageResId != 0) {
//            drawable = context.getResources().getDrawable(imageResId);
//        }
//        showDialog(context, heading, description, buttonText, drawable, listener);
//    }
//
//    public void showDialog(Context context,
//                           String heading,
//                           String description,
//                           String buttonText,
//                           @Nullable final DialogButtonClickListener listener) {
//        showDialog(context, heading, description, buttonText, (Drawable) null, listener);
//    }
//
//    public void dismissDialog() {
//        if (currentDialog != null && currentDialog.isShowing()) {
//            currentDialog.dismiss();
//        }
//        currentDialog = null;
//    }
//
//    public boolean isShowing() {
//        return currentDialog != null && currentDialog.isShowing();
//    }
//}