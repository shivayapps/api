package com.video.aimagic.bodyeditor.screens;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.video.aimagic.R;
import com.video.aimagic.databinding.ActivityHipsEditorBinding;
import com.video.aimagic.extension.ExtensionsKt;
import com.video.aimagic.singletone.PhotoUploadManager;

import java.util.Stack;

public class HipsEditor extends AppCompatActivity {

    private final int meshHeight = 10;
    private final int meshWidth = 10;
    Bitmap saveBitmap, mBitmap;
    boolean maskareaValuesadded;
    private ActivityHipsEditorBinding binding;
    private SeekBar.OnSeekBarChangeListener seekBarChangeListener = new seekbarListener();
    private boolean isProgrammaticSeekBarChange = false;
    private Stack<EditState> undoStack = new Stack<>();
    private Stack<EditState> redoStack = new Stack<>();
    private int lastProgress = 0;
    private float[] sourceVerts;
    private float[] warpedVerts;
    private float pw;
    private float px;
    private float py;
    private float ratio;
    private float ph;
    private int bitmapWidth;
    private int bitmapHeight;
    private int regionStartX, regionStartY;
    private int regionWidth, regionHeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityHipsEditorBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        ExtensionsKt.setStatusBarFontColor(this,false);
        mBitmap = PhotoUploadManager.getInstance().getUniversalBitmap();
        bitmapWidth = mBitmap.getWidth();
        bitmapHeight = mBitmap.getHeight();
        setImageAndSeekBar();
        setOnClickListners();
        setupMesh();

    }

    private void setupMesh() {
        int count = (meshWidth + 1) * (meshHeight + 1) * 2;
        sourceVerts = new float[count];
        warpedVerts = new float[count];

        int index = 0;
        for (int y = 0; y <= meshHeight; y++) {
            float fy = ((float) bitmapHeight) * y / meshHeight;
            for (int x = 0; x <= meshWidth; x++) {
                float fx = ((float) bitmapWidth) * x / meshWidth;
                sourceVerts[index * 2] = fx;
                sourceVerts[index * 2 + 1] = fy;

                warpedVerts[index * 2] = fx;
                warpedVerts[index * 2 + 1] = fy;

                index++;
            }
        }
    }

    private void getMaskedValues() {
        if (!maskareaValuesadded) {
            maskareaValuesadded = true;

            pw = binding.hipView.getWidth() * binding.hipView.getScaleX();
            ph = binding.hipView.getHeight() * binding.hipView.getScaleY();
            px = binding.hipView.getX() + ((binding.hipView.getWidth() - pw) / 2.0f);
            py = binding.hipView.getY() + ((binding.hipView.getHeight() - ph) / 2.0f);

            ratio = (float) bitmapHeight / (float) binding.implimentedView.getHeight();

            regionStartX = (int) (px * ratio);
            regionWidth = (int) (pw * ratio);
            regionStartY = (int) (py * ratio);
            regionHeight = (int) (ph * ratio);

            showSeekBarView();
        }

    }

    public void createFilter(int pro) {

        if (saveBitmap != null) {
            undoStack.push(new EditState(saveBitmap, lastProgress));
            PhotoUploadManager.getInstance().setUniversalBitmap(saveBitmap);
            redoStack.clear();
        } else {
            // First time use
            undoStack.push(new EditState(mBitmap, 0));
            redoStack.clear();
        }

        lastProgress = pro;


        Bitmap b = applyHipWarp(mBitmap, pro);

        binding.bodyPreviewImage.setImageBitmap(b);
        saveBitmap = b;

    }

    private Bitmap applyHipWarp(Bitmap bitmap, long progressValue) {
        float factor = progressValue / 30f; // -1 to +1
        float centerX = regionStartX + (regionWidth / 2f);
        float maxOffset = regionWidth * 0.5f;

        System.arraycopy(sourceVerts, 0, warpedVerts, 0, sourceVerts.length);

        for (int i = 0; i < warpedVerts.length; i += 2) {
            float x = sourceVerts[i];
            float y = sourceVerts[i + 1];

            if (y >= regionStartY && y <= regionStartY + regionHeight &&
                    x >= regionStartX && x <= regionStartX + regionWidth) {

                float dx = x - centerX;
                float normalizedDistance = dx / (regionWidth / 2f); // -1 to +1
                float verticalFactor = (float) Math.sin(((y - regionStartY) / (float) regionHeight) * Math.PI);
                float offsetX = -normalizedDistance * maxOffset * factor * verticalFactor;

                warpedVerts[i] = x + offsetX;
            }
        }

        Bitmap warpedBitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(warpedBitmap);
        Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
        canvas.drawBitmapMesh(bitmap, meshWidth, meshHeight, warpedVerts, 0, null, 0, paint);
        return warpedBitmap;
    }

    private void setImageAndSeekBar() {
        binding.changeHipsSeekBar.setMin(-10);
        binding.changeHipsSeekBar.setMax(10);
        binding.changeHipsSeekBar.setProgress(0);
        binding.hipView.imageView = binding.bodyPreviewImage;
        binding.bodyPreviewImage.setImageBitmap(mBitmap);
        binding.changeHipsSeekBar.setOnSeekBarChangeListener(seekBarChangeListener);
    }

    private void setOnClickListners() {
        binding.undoFace.setOnClickListener(v -> {
            undo();
        });
        binding.reduFace.setOnClickListener(v -> {
            redo();
        });

        binding.applyBtn.setOnClickListener(v -> {
            finish();
        });
    }

    private void updateUndoRedoIcons() {
        if (!undoStack.isEmpty()) {
            binding.undoFace.setImageResource(R.drawable.body_undo_enable);
            binding.undoFace.setEnabled(true);
        } else {
            binding.undoFace.setImageResource(R.drawable.body_undo_disable);
            binding.undoFace.setEnabled(false);
        }

        if (!redoStack.isEmpty()) {
            binding.reduFace.setImageResource(R.drawable.body_redu_enable);
            binding.reduFace.setEnabled(true);
        } else {
            binding.reduFace.setImageResource(R.drawable.body_redu_disable);
            binding.reduFace.setEnabled(false);
        }
    }


    public void undo() {
        if (!undoStack.isEmpty()) {
            redoStack.push(new EditState(saveBitmap, lastProgress));

            EditState previous = undoStack.pop();
            binding.bodyPreviewImage.setImageBitmap(previous.bitmap);
            saveBitmap = previous.bitmap;
            lastProgress = previous.progress;

            isProgrammaticSeekBarChange = true;
            binding.changeHipsSeekBar.setProgress(previous.progress);
            isProgrammaticSeekBarChange = false;

        }
    }

    public void redo() {
        if (!redoStack.isEmpty()) {
            undoStack.push(new EditState(saveBitmap, lastProgress));

            EditState next = redoStack.pop();
            binding.bodyPreviewImage.setImageBitmap(next.bitmap);
            saveBitmap = next.bitmap;
            lastProgress = next.progress;

            isProgrammaticSeekBarChange = true;
            binding.changeHipsSeekBar.setProgress(next.progress); // <-- Update SeekBar
            isProgrammaticSeekBarChange = false;


        }
    }

    private void showSeekBarView() {

        binding.changeHipsSeekBar.setVisibility(View.VISIBLE);

    }


    class seekbarListener implements SeekBar.OnSeekBarChangeListener {

        @Override
        public void onProgressChanged(SeekBar seekBar, int progress,
                                      boolean fromUser) {
            if (isProgrammaticSeekBarChange) return;
            getMaskedValues();
            int progressss = seekBar.getProgress();
            progressss = progressss * -1;
            createFilter(progressss);
            if (binding.applyBtn.getVisibility() == View.GONE) {
                binding.applyBtn.setVisibility(View.VISIBLE);
            }
            //updateUndoRedoIcons();

        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            if (isProgrammaticSeekBarChange) return;
            updateUndoRedoIcons();
        }


    }

}