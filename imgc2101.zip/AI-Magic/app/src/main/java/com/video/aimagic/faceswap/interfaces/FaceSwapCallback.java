package com.video.aimagic.faceswap.interfaces;

public interface FaceSwapCallback {
    void onSuccess(String response);
    void onError(String errorMessage);
    void onFailure(Throwable throwable);
}