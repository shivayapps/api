package com.video.aimagic.facedance;

import java.io.File;

public class UploadRequest {
    private File inputImageFile;
    private String appName;
    private String folder;
    private String fileName;
    private String countryCode;
    private String platform;
    private String firebaseAppCheck;
    private String fcmToken;

    // Getters and setters
    public File getInputImageFile() { return inputImageFile; }
    public void setInputImageFile(File inputImageFile) { this.inputImageFile = inputImageFile; }

    public String getAppName() { return appName; }
    public void setAppName(String appName) { this.appName = appName; }

    public String getFolder() { return folder; }
    public void setFolder(String folder) { this.folder = folder; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public String getCountryCode() { return countryCode; }
    public void setCountryCode(String countryCode) { this.countryCode = countryCode; }

    public String getPlatform() { return platform; }
    public void setPlatform(String platform) { this.platform = platform; }

    public String getFirebaseAppCheck() { return firebaseAppCheck; }
    public void setFirebaseAppCheck(String firebaseAppCheck) { this.firebaseAppCheck = firebaseAppCheck; }

    public String getFcmToken() { return fcmToken; }
    public void setFcmToken(String fcmToken) { this.fcmToken = fcmToken; }

    // Builder pattern for easier construction
    public UploadRequest withInputImageFile(File inputImageFile) {
        this.inputImageFile = inputImageFile;
        return this;
    }

    public UploadRequest withAppName(String appName) {
        this.appName = appName;
        return this;
    }

    public UploadRequest withFolder(String folder) {
        this.folder = folder;
        return this;
    }

    public UploadRequest withFileName(String fileName) {
        this.fileName = fileName;
        return this;
    }

    public UploadRequest withCountryCode(String countryCode) {
        this.countryCode = countryCode;
        return this;
    }

    public UploadRequest withPlatform(String platform) {
        this.platform = platform;
        return this;
    }

    public UploadRequest withFirebaseAppCheck(String firebaseAppCheck) {
        this.firebaseAppCheck = firebaseAppCheck;
        return this;
    }

    public UploadRequest withFcmToken(String fcmToken) {
        this.fcmToken = fcmToken;
        return this;
    }
}
