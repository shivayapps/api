package com.video.aimagic.utils

import android.content.Context
import android.graphics.Outline
import android.util.AttributeSet
import android.view.View
import android.view.ViewOutlineProvider
import androidx.appcompat.widget.AppCompatImageView
import com.video.aimagic.R

class AspectRatioImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatImageView(context, attrs, defStyleAttr) {

    var aspectRatio: Double = -1.0
    private var cornerRadius: Float = 0f

    init {
        context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.AspectRatioImageView,
            defStyleAttr,
            0
        ).apply {
            try {
                aspectRatio = getFloat(
                    R.styleable.AspectRatioImageView_aspect_ratio,
                    -1.0f
                ).toDouble()

                cornerRadius = getDimension(
                    R.styleable.AspectRatioImageView_aspect_radius,
                    0f
                )
            } finally {
                recycle()
            }
        }

        // Needed for clipping
        clipToOutline = true
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)

        if (aspectRatio == -1.0) return

        val width = measuredWidth
        val height = (width * aspectRatio).toInt()
        if (height != measuredHeight) {
            setMeasuredDimension(width, height)
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)

        if (cornerRadius > 0f) {
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(
                        0,
                        0,
                        view.width,
                        view.height,
                        cornerRadius
                    )
                }
            }
        }
    }
}


//class AspectRatioImageView @JvmOverloads constructor(
//    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
//) : AppCompatImageView(context, attrs, defStyleAttr) {
//
//    var aspectRatio: Double = -1.0
//
//    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
//        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
//
//        if (aspectRatio == -1.0) return
//        val width = measuredWidth
//        val height = (width * aspectRatio).toInt()
//        if (height == measuredHeight) return
//        setMeasuredDimension(width, height)
//    }
//}