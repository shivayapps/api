package com.domain.interactor

import io.reactivex.Flowable
import com.domain.repository.MessageRepository
import javax.inject.Inject

class StarMessages @Inject constructor(
    private val messageRepo: MessageRepository,
) : Interactor<List<Long>>() {

    override fun buildObservable(list: List<Long>): Flowable<*> {
        return Flowable.just(list.toLongArray())
                .doOnNext { messageIds -> messageRepo.starMessages(*messageIds) } // Star the messages
    }

}