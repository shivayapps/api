package com.domain.manager

interface ShortcutManager {

    fun updateBadge()

    fun updateShortcuts()

}