package com.domain.repository

import io.reactivex.Completable
import io.reactivex.Observable
import io.realm.RealmResults
import com.domain.feature.conversationinfo.ConversationInfoItem
import com.domain.model.Conversation
import com.domain.model.Recipient
import com.domain.model.SearchResult
import com.domain.model.WidgetModel
import java.util.*

interface ConversationRepository {

    fun getAllConversations(
        limit: Long = 100
    ): RealmResults<Conversation>

    /**
     * Added By Jayesh Dankhara
     * for filter of range date selection
     */
    //    fun getConversationsRange(fDate: Long, eDate: Long): RealmResults<Conversation>
    fun getConversationsRange(
        fDate: Date,
        eDate: Date,
        limit: Long = 100,
    ): RealmResults<Conversation>

    fun getConversations(
        archived: Boolean = false,
        limit: Long = 100
    ): Pair<RealmResults<Conversation>, Boolean>

    fun getConversationsFilter(
        archived: Boolean = false,
        limit: Long = 100, fDate: Date, endDate: Date
    ): Pair<RealmResults<Conversation>, Boolean>

    /**
     * Added By Jayesh Dankhara
     * for filter of transaction
     */
    fun getTransactionConversation(limit: Long = 100): RealmResults<Conversation>

    /**
     * Added By Jayesh Dankhara
     * for filter of transaction with date filter
     */
    fun getTransactionConversationFilter(
        limit: Long = 100,
        startDate: Date,
        endDate: Date
    ): RealmResults<Conversation>

    /**
     * Added By Jayesh Dankhara
     * for filter of Known Sender from contact list
     */
    fun getKnownSenderConversation(limit: Long = 100): RealmResults<Conversation>

    /**
     * Added By Jayesh Dankhara
     * for filter of Known Sender from contact list with filter
     */
    fun getKnownSenderConversationFilter(
        limit: Long = 100,
        startDate: Date,
        endDate: Date
    ): RealmResults<Conversation>

    /**
     * Added By Jayesh Dankhara
     * for filter of Offers and promotional message from message list
     */
    fun getPromotionConversation(limit: Long = 100): RealmResults<Conversation>

    /**
     * Added By Jayesh Dankhara
     * for filter of Offers and promotional message from message list with filter
     */
    fun getPromotionConversationFilter(
        limit: Long = 100,
        startDate: Date,
        endDate: Date
    ): RealmResults<Conversation>

    /**
     * Added By Jayesh Dankhara
     * for filter of OTP message from message list
     */
    fun getOtpConversation(limit: Long = 100, status: Int = 2): RealmResults<Conversation>

    /**
     * Added By Jayesh Dankhara
     * for filter of OTP message from message list with filter
     */
    fun getOtpConversationFilter(
        limit: Long = 100,
        startDate: Date,
        endDate: Date
    ): RealmResults<Conversation>


    fun getConversationsSnapshot(): ArrayList<WidgetModel>

    /**
     * Returns the top conversations that were active in the last week
     */
    fun getTopConversations(): List<Conversation>

    fun setConversationName(id: Long, name: String)

    fun searchConversations(query: CharSequence): List<SearchResult>

    fun getBlockedConversations(): RealmResults<Conversation>

    fun getBlockedConversationsAsync(): RealmResults<Conversation>

    fun getConversationAsync(threadId: Long): Conversation
    fun getConversationAsync2(threadId: Long): MutableList<ConversationInfoItem>?

    fun getConversation(threadId: Long): Conversation?
    fun getMoreConversation(from: Long, to: Long): Conversation?

    /**
     * Returns all conversations with an id in [threadIds]
     */
    fun getConversations(vararg threadIds: Long): Pair<RealmResults<Conversation>, Boolean>

    fun getUnmanagedConversations(limit: Long = 100): Observable<List<Conversation>>

    fun getRecipients(): RealmResults<Recipient>

    fun getUnmanagedRecipients(): Observable<List<Recipient>>

    fun getRecipient(recipientId: Long): Recipient?

    fun getThreadId(recipient: String): Long?

    fun getThreadId(recipients: Collection<String>): Long?

    fun getOrCreateConversation(threadId: Long): Conversation?

    fun getOrCreateConversation(address: String): Conversation?

    fun getOrCreateConversation(addresses: List<String>): Conversation?

    fun saveDraft(threadId: Long, draft: String)

    /**
     * Updates message-related fields in the conversation, like the date and snippet
     */
    fun updateConversations(vararg threadIds: Long)


    fun markAllAsRead(vararg threadIds: Long)


    fun markArchived(vararg threadIds: Long)

    fun markUnarchived(vararg threadIds: Long)

    fun markPinned(vararg threadIds: Long)

    fun markUnpinned(vararg threadIds: Long)
    fun deleteConversations(vararg threadIds: Long)
    fun markBlocked(threadIds: List<Long>, blockReason: String?)
    fun markUnblocked(vararg threadIds: Long)
    fun block(addresses: List<String>): Completable
    fun unblock(addresses: List<String>): Completable
    fun getUnreadConversationsSize(): Int
    fun getArchiveConversationsSize(): Int
    fun getAllConversationsSize(): Int
    fun getArchivedConversationsSize(): Int
    fun isConversationAvailable(threadId: Long): Boolean
}