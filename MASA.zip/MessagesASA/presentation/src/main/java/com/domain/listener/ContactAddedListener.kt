package com.domain.listener

import io.reactivex.Observable

interface ContactAddedListener {

    fun listen(): Observable<*>

}
