package com.data.receiver

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.android.AndroidInjection
import com.domain.interactor.MarkFailed
import com.domain.interactor.MarkSent
import javax.inject.Inject

class SmsSentReceiver : BroadcastReceiver() {

    @Inject
    lateinit var markSent: MarkSent

    @Inject
    lateinit var markFailed: MarkFailed

    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)

        val id = intent.getLongExtra("id", 0L)

        when (resultCode) {
            Activity.RESULT_OK -> {
                val pendingResult = goAsync()
                markSent.execute(id) {
                    try {
                        pendingResult.finish()
                    } catch (e: IllegalStateException) {
                        com.data.extensions.LogE(
                            "IllegalStateException: ",
                            e.message.toString()
                        )
                        e.printStackTrace()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
            else -> {
                val pendingResult = goAsync()
                markFailed.execute(MarkFailed.Params(id, resultCode)) {
                    try {
                        pendingResult.finish()
                    } catch (e: IllegalStateException) {
                        com.data.extensions.LogE(
                            "IllegalStateException:",
                            e.message.toString()
                        )
                        e.printStackTrace()
                    } catch (e: Exception) {
                        com.data.extensions.LogE("Exception: ", e.message.toString())
                        e.printStackTrace()
                    }
                }
            }
        }
    }
}
