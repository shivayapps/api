package com.data.migration

import android.content.Context
import com.common.extensions.versionCode
import com.domain.repository.BlockingRepository
import com.domain.repository.ConversationRepository
import com.domain.util.Preferences
import javax.inject.Inject

class MessagesMigration @Inject constructor(
    context: Context,
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val blockingRepository: BlockingRepository
//    private val messagesBlockingClient: messagesBlockingClient
) {

    init {
        val oldVersion = prefs.version.get()
        if (oldVersion < 2199) {
            upgradeTo370()
        }
        prefs.version.set(context.versionCode)
    }

    private fun upgradeTo370() {
        try {
            // Migrate changelog version
            prefs.changelogVersion.set(prefs.version.get())

            // Migrate from old SIA preference to blocking manager preference
//            if (prefs.sia.get()) {
//                prefs.blockingManager.set(Preferences.BLOCKING_MANAGER_SIA)
//                prefs.sia.delete()
//            }

            // Migrate blocked conversations into Quick blocking client
            val addresses = conversationRepo.getBlockedConversations()
                .flatMap { conversation -> conversation.recipients }
                .map { recipient -> recipient.address }
                .distinct()

            blockingRepository.blockNumber(*addresses.toTypedArray())
//            messagesBlockingClient.block(addresses).blockingAwait()
        } catch (e: Exception) {
            com.data.extensions.LogE("upgradeTo370--: ", e.message.toString())
        }

    }

}
