package com.data.receiver

import android.content.Context
import android.content.Intent
import android.provider.Telephony
import dagger.android.AndroidInjection
import com.domain.interactor.ReceiveSms
import com.data.receiver.SmsReceiver
import javax.inject.Inject

class SmsRecevierOnReceive(
    internal val smsReciver: SmsReceiver,
    internal val context: Context,
    internal val intent: Intent
) : Runnable {
    @Inject
    lateinit var receiveMessage: ReceiveSms
    private var TAG = "SmsRecevier+++"
    override fun run() {
        try {
            AndroidInjection.inject(smsReciver, context)
            com.data.extensions.LogW("messageApp : ", " sms onReceive")
            Telephony.Sms.Intents.getMessagesFromIntent(intent)?.let { messages ->
                val subId = intent.extras?.getInt("subscription", -1) ?: -1
                try {
                    receiveMessage.execute(ReceiveSms.Params(subId, messages)) {}
                } catch (e: Exception) {
                    com.data.extensions.LogE(TAG, "run: --" + e.message.toString())
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            com.data.extensions.LogE(TAG, "run: ++" + e.message.toString())
            e.printStackTrace()
        }
    }
}