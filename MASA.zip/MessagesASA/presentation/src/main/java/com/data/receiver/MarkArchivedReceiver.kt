package com.data.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.android.AndroidInjection
import com.domain.interactor.MarkArchived
import javax.inject.Inject

class MarkArchivedReceiver : BroadcastReceiver() {

    @Inject
    lateinit var markArchived: MarkArchived

    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)
        val pendingResult = goAsync()
        val threadId = intent.getLongExtra("threadId", 0)
        markArchived.execute(listOf(threadId)) {
            try {
                pendingResult.finish()
            } catch (e: IllegalStateException) {
                com.data.extensions.LogE(
                    "IllegalStateException: ",
                    e.message.toString()
                )
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}