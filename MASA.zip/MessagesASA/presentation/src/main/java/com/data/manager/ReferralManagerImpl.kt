package com.data.manager

import android.content.Context
import com.android.installreferrer.api.InstallReferrerClient
import com.android.installreferrer.api.InstallReferrerClient.InstallReferrerResponse
import com.android.installreferrer.api.InstallReferrerStateListener
import com.domain.manager.ReferralManager
import com.domain.util.Preferences
import javax.inject.Inject

class ReferralManagerImpl @Inject constructor(
    private val context: Context,
    private val prefs: Preferences
) : ReferralManager {

    override fun trackReferrer() {
        if (prefs.didSetReferrer.get()) {
            return
        }

        val referrerClient = InstallReferrerClient.newBuilder(context).build()

        referrerClient.startConnection(object : InstallReferrerStateListener {
            override fun onInstallReferrerSetupFinished(responseCode: Int) {
                when (responseCode) {
                    InstallReferrerResponse.OK -> {
                        prefs.didSetReferrer.set(true)

                        referrerClient.endConnection()
                    }
                    InstallReferrerResponse.FEATURE_NOT_SUPPORTED -> {
                        prefs.didSetReferrer.set(true)
                    }
                    InstallReferrerResponse.SERVICE_UNAVAILABLE -> {
                    }
                }
            }

            override fun onInstallReferrerServiceDisconnected() {
                // Try to restart the connection on the next request to
                // Google Play by calling the startConnection() method.
            }
        })
    }
}
