package com.photogallery.jobs.cleaner

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import com.photogallery.extension.getParentFolder
import com.photogallery.extension.md5
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.STOP_DUPLICATE_PHOTO_JUNK
import com.photogallery.utils.UPDATE_DUPLICATE_PHOTO_JUNK
import com.photogallery.utils.UPDATE_DUPLICATE_PHOTO_SIZE
import com.photogallery.utils.sendEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

suspend fun Context.startDuplicatePhotoWorker() {
    val mContext = this
    AllMediaLoader(mContext).getAllImageData(onSuccess = { allMedia ->
        CoroutineScope(Dispatchers.IO).launch {
            DuplicatePhotoWorker.doWork(mContext, allMedia)
        }
    })
}

object DuplicatePhotoWorker {

    var duplicatePhotoData: Map<String, List<MediaData>> = emptyMap()
    private var isDuplicateRunning = false
    var totalCounter: Float = 0F
    var scanCounter: Int = 0
    var duplicateSize = 0L

    suspend fun doWork(context: Context, allMedia: List<MediaData>) {

        totalCounter = ((allMedia.size).toFloat())

        val pictures = ArrayList<Any>()
        var totalFileSize = 0L

        if (allMedia.isEmpty()) return
//        CoroutineScope(Dispatchers.IO).launch {
        if (!isDuplicateRunning) {
            isDuplicateRunning = true

            if (Constant.duplicateRealPhotoData.isNotEmpty()) {
                setFilterDuplicate()
            } else {
                val photoData: ArrayList<MediaData> = ArrayList()
                allMedia.map { photo ->
//                        async(Dispatchers.IO) {
                    val bucketMd5 = try {
                        File(photo.filePath).md5()
                    } catch (e: Exception) {
                        ""
                    }
                    photo.bucketPath = bucketMd5
                    scanCounter++
                    updatePercentage()
                    photo
//                        }
                }.let {
                    photoData.addAll(it)
                }

                Log.e("Cleaner.DuplicatePhoto", "duplicate:photoData:${photoData.size}")
                val groupedPhotoData: Map<String, List<MediaData>> = photoData.groupBy { it.bucketPath }
                Log.e("Cleaner.DuplicatePhoto", "duplicate:groupedPhotoData:${groupedPhotoData.size}")
                duplicatePhotoData = groupedPhotoData.filter { (_, list) ->
                    list.size > 1
                }

                Log.e("Cleaner.DuplicatePhoto", "duplicate:multiItemGroups:${duplicatePhotoData.size}")
                val bucketKeys: Set<String> = duplicatePhotoData.keys
                val listFolderkeys = java.util.ArrayList(bucketKeys)

                Log.e("Cleaner.DuplicatePhoto", "RealPhotoData 002 listFolderkeys:${listFolderkeys.size}==>${listFolderkeys}")
                for (index in listFolderkeys.indices) {
                    val list = duplicatePhotoData[listFolderkeys[index]]
                    val bucketData = AlbumData(
                        title = "Set ${index + 1}",
                        folderPath = listFolderkeys[index],
//                        mediaData = list as ArrayList<MediaData>,
                        isCustomAlbum = true,
                        isCheckboxVisible = true
                    )
                    pictures.add(bucketData)
                    pictures.addAll(list as ArrayList<MediaData>)

//                    val list = duplicatePhotoData[listFolderkeys[index]]
//                    val finalList = list?.map { objectModel ->
//                        MediaModel(
//                            filePath = objectModel.filePath,
//                            fileName = objectModel.fileName,
//                            bucketPath = objectModel.bucketPath,
//                            albumTag = listFolderkeys[index],
//                            fileSize = objectModel.fileSize,
//                            mediaType = objectModel.mediaType
//                        )
//                    }!!
//                    val bucketData =
//                        MediaModel().toClass(listFolderkeys[index], "Set ${index + 1}", bucketPath = MEDIA_ITEM_TYPE_HEADER_ID, albumTag = listFolderkeys[index], fileSize = finalList.size.toLong())
//
//                    pictures.add(bucketData)
//                    pictures.addAll(finalList)
                }
                Log.e("Cleaner.DuplicatePhoto", "RealPhotoData duplicateRealPhotoData==>${pictures.size}")

                totalFileSize = pictures
                    .filterIsInstance<MediaData>()
                    .sumOf { it.fileSize }
                duplicateSize = totalFileSize
                Constant.duplicateRealPhotoData = pictures
                setFilterDuplicate()
            }
            sendEvent(STOP_DUPLICATE_PHOTO_JUNK)
        }
//        }
    }

    private fun setFilterDuplicate() {
        Log.e("Cleaner.DuplicatePhoto", "setFilterDuplicate:001")
        val pictures = ArrayList<Any>()
        pictures.addAll(Constant.duplicateRealPhotoData)
//        pictures.removeIf { item ->
//            item.bucketPath != MEDIA_ITEM_TYPE_HEADER_ID && !File(item.filePath).exists()
//        }
        //remove empty album
        val indicesToRemove = mutableListOf<Int>()
        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                var hasMediaData = false
                for (j in (i + 1) until pictures.size) {
                    if (pictures[j] is MediaData) {
                        hasMediaData = true
                    } else if (pictures[j] is AlbumData) {
                        break
                    }
                }
                if (!hasMediaData) {
                    indicesToRemove.add(i)
                }
            }
        }

        for (index in indicesToRemove.reversed()) {
            pictures.removeAt(index)
        }

        Constant.duplicateRealPhotoData = pictures

        val totalFileSize = pictures
            .filterIsInstance<MediaData>()
            .sumOf { it.fileSize }

        duplicateSize = totalFileSize
        val ssSize = pictures.filterIsInstance<AlbumData>().size
        scanCounter += pictures.size

        Log.e("Cleaner.DuplicatePhoto", "duplicateSize:$duplicateSize")
        updatePercentage()

        val sizePair = Pair(totalFileSize.toLong(), ssSize.toInt())
        isDuplicateRunning = false
//        CoroutineScope(Dispatchers.IO).launch {
        sendEvent(UPDATE_DUPLICATE_PHOTO_SIZE, sizePair)
//            Handler(Looper.getMainLooper()).postDelayed({
//                sendEvent(STOP_DUPLICATE_JUNK)
//            },700)
//        }
        Log.e("Cleaner.DuplicatePhoto", "setFilterDuplicate:002")
    }

    private fun updatePercentage() {
//        CoroutineScope(Dispatchers.IO).launch {
//        runOnUiThread {
        val percent: Float = (scanCounter / totalCounter) * 100
        Log.e("Cleaner.DuplicatePhoto", "updatePercentage:${percent},$scanCounter,$totalCounter")
        sendEvent(UPDATE_DUPLICATE_PHOTO_JUNK, percent)
//            binding.tvScanPercent.setText("${percent.toInt()}%")
//        }
    }

}
