package com.photogallery.jobs.autoclean

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import android.util.Log
import com.photogallery.database.AppDatabase
import com.photogallery.database.RecentDeleteData
import com.photogallery.utils.Constant
import java.io.File
import java.util.Calendar
import java.util.Date

suspend fun Context.startAutoCleanTrashWorker() {
    AutoCleanTrashWorker.doWork(this, Constant.DELETE_PATH, 30)
}

object AutoCleanTrashWorker {

    private var isRecoverMediaRunning = false
    lateinit var dataBase: AppDatabase

    suspend fun doWork(context: Context, mRootPath: String, daysToDelete: Int) {

        dataBase = AppDatabase.getInstance(context)
        if (!isRecoverMediaRunning) {
            isRecoverMediaRunning = true

//            val fList = getListAllFiles(mRootPath)
            val recentDeleteList = dataBase.dataDao().getRecentDeleteList()

            val calendar = Calendar.getInstance()
            val currentTime = calendar.timeInMillis

            for (recentDeleteFile in recentDeleteList) {
                val fileToDelete = File(recentDeleteFile.path)
                val date1 = Date()
                date1.time = currentTime
                val daysOld: Long = getDifference(fileToDelete.lastModified(), currentTime)
                Log.e("junkReminder", "doInBackground-daysOld:$daysOld-${fileToDelete.name}")
                try {
                    if (daysOld >= daysToDelete) {
//                    if (daysOld >= 1) {
                        fileToDelete.deleteOnExit();
                        if (fileToDelete.exists()) {
                            val isDelete = fileToDelete.delete();
                            Log.e("junkReminder", "doInBackground-del:" + isDelete);
                            deleteFileFromMediaStore(context, fileToDelete.getAbsolutePath());
                        }
                        dataBase.dataDao()
                            .removeRecentDelete(
                                RecentDeleteData(
                                    recentDeleteFile.id,
                                    recentDeleteFile.path,
                                    recentDeleteFile.restorePath
                                )
                            )
                    }
                } catch (e: Exception) {
                    Log.e("junkReminder", "doInBackground-Exception:$e")
                }
            }
        }
    }


    private fun deleteFileFromMediaStore(context: Context, path: String) {
        try {
//            context.getContentResolver().delete(FilesProtectionContentProvider.a, "trash_path = ? ", new String[]{String.valueOf(path)});

            val projection = arrayOf(MediaStore.Images.Media._ID)
            val selection = MediaStore.Images.Media.DATA + " = ?"
            val selectionArgs = arrayOf(path)
            val queryUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val c = context.contentResolver.query(queryUri, projection, selection, selectionArgs, null)
            if (c!!.moveToFirst()) {
                val id = c!!.getLong(c!!.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                val deleteUri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                context.contentResolver.delete(deleteUri, null, null)
            }
            c!!.close()
        } catch (e: java.lang.Exception) {
            Log.e("printStackTrace", "printStackTrace:\$e")
        }
        System.gc()
    }

    fun getDifference(startDate: Long, endDate: Long): Long {
        var different = endDate - startDate

        val secondsInMilli: Long = 1000
        val minutesInMilli = secondsInMilli * 60
        val hoursInMilli = minutesInMilli * 60
        val daysInMilli = hoursInMilli * 24

        val elapsedDays = different / daysInMilli
        different = different % daysInMilli

        val elapsedHours = different / hoursInMilli
        different = different % hoursInMilli

        val elapsedMinutes = different / minutesInMilli
        different = different % minutesInMilli

        val elapsedSeconds = different / secondsInMilli

        Log.e("AutoCleanTrash", "Days:$elapsedDays")
        Log.e("AutoCleanTrash", "Hours:$elapsedHours")
        Log.e("AutoCleanTrash", "Minutes:$elapsedMinutes")
        Log.e("AutoCleanTrash", "Seconds:$elapsedSeconds")

        return elapsedDays
    }

    fun getListAllFiles(path: String): List<File> {
        Log.e("Utils", "getListAllFiles:$path")
        val fold = File(path)
        val docList: MutableList<File> = java.util.ArrayList()
        val mlist = fold.listFiles()
        val mFilelist = fold.listFiles()
        if (mlist != null) {
            for (f in mlist) {
                if (f.isDirectory) {
                    val fList = getListAllFiles(f.absolutePath)
                    docList.addAll(fList)
                }
            }
            if (mFilelist != null) {
                for (f in mFilelist) {
                    if (!f.name.isEmpty()) {
                        if (f.length() > 0) {
                            docList.add(f)
                        }
                    }
                }
            }
        }
        return docList
    }

}
