package com.ro.hith.imagic.screens.faceswap;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.ro.hith.imagic.R;
import com.ro.hith.imagic.screens.faceswap.model.CategoryItem;

import java.util.ArrayList;
import java.util.List;

public class FaceSwapCategoryAdapter extends RecyclerView.Adapter<FaceSwapCategoryAdapter.CategoryViewHolder> {
    private final Context context;
    private final List<CategoryItem> dataList;
    private final ItemSelectionCallback selectionCallback;

    public interface ItemSelectionCallback {
        void onCategorySelected(CategoryItem item, int adapterPosition);
    }

    public FaceSwapCategoryAdapter(Context context, List<CategoryItem> dataList, ItemSelectionCallback selectionCallback) {
        this.context = context;
        this.dataList = new ArrayList<>(dataList);
        this.selectionCallback = selectionCallback;
        setHasStableIds(true);
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.custom_item_category, parent, false);
        return new CategoryViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
        CategoryItem currentItem = dataList.get(position);
        holder.configureView(currentItem);
        holder.setupClickListener(currentItem, position);
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    @Override
    public long getItemId(int position) {
        return dataList.get(position).getTitle().hashCode();
    }

    public class CategoryViewHolder extends RecyclerView.ViewHolder {
        private final ImageView categoryImageView;
        private final TextView categoryTitleView;

        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);
            categoryImageView = itemView.findViewById(R.id.imgCategory);
            categoryTitleView = itemView.findViewById(R.id.txtCategoryTitle);
        }

        public void configureView(CategoryItem item) {
            categoryTitleView.setText(item.getTitle());
            Glide.with(context)
                    .load(item.getImageUri())
                    .placeholder(R.drawable.custom_ic_tools)
                    .into(categoryImageView);
        }

        public void setupClickListener(CategoryItem item, int position) {
            itemView.setOnClickListener(v -> {
                if (selectionCallback != null) {
                    selectionCallback.onCategorySelected(item, position);
                }
            });
        }
    }
}