package com.ro.hith.imagic.screens.facedance.api.get;

import java.io.File;

public interface FaceDanceVideoResponseCallback {
    void onSuccess(File videoFile);
    void onProgress(int progress);
    void onError(String errorMessage);
}