package com.ro.hith.imagic.screens.facedance.api;

public interface ApiCallback {
    void onSuccess(String response);
    void onError(String errorMessage);
}