package com.ro.hith.imagic.screens.babygen.api;

import java.io.File;

public  class PredictRequest {
    private String babyGender;
    private String babyCountry;
    private String appName;
    private int motherPercent;
    private int fatherPercent;
    private String skinTone;
    private String ageGroup;
    private String countryCode;
    private String platform;
    private String fcmToken;
    private String firebaseAppCheck;
    private String motherList;
    private String fatherList;
    private File motherImage;
    private File fatherImage;

    // Getters and setters
    public String getBabyGender() { return babyGender; }
    public void setBabyGender(String babyGender) { this.babyGender = babyGender; }

    public String getBabyCountry() { return babyCountry; }
    public void setBabyCountry(String babyCountry) { this.babyCountry = babyCountry; }

    public String getAppName() { return appName; }
    public void setAppName(String appName) { this.appName = appName; }

    public int getMotherPercent() { return motherPercent; }
    public void setMotherPercent(int motherPercent) { this.motherPercent = motherPercent; }

    public int getFatherPercent() { return fatherPercent; }
    public void setFatherPercent(int fatherPercent) { this.fatherPercent = fatherPercent; }

    public String getSkinTone() { return skinTone; }
    public void setSkinTone(String skinTone) { this.skinTone = skinTone; }

    public String getAgeGroup() { return ageGroup; }
    public void setAgeGroup(String ageGroup) { this.ageGroup = ageGroup; }

    public String getCountryCode() { return countryCode; }
    public void setCountryCode(String countryCode) { this.countryCode = countryCode; }

    public String getPlatform() { return platform; }
    public void setPlatform(String platform) { this.platform = platform; }

    public String getFcmToken() { return fcmToken; }
    public void setFcmToken(String fcmToken) { this.fcmToken = fcmToken; }

    public String getFirebaseAppCheck() { return firebaseAppCheck; }
    public void setFirebaseAppCheck(String firebaseAppCheck) { this.firebaseAppCheck = firebaseAppCheck; }

    public String getMotherList() { return motherList; }
    public void setMotherList(String motherList) { this.motherList = motherList; }

    public String getFatherList() { return fatherList; }
    public void setFatherList(String fatherList) { this.fatherList = fatherList; }

    public File getMotherImage() { return motherImage; }
    public void setMotherImage(File motherImage) { this.motherImage = motherImage; }

    public File getFatherImage() { return fatherImage; }
    public void setFatherImage(File fatherImage) { this.fatherImage = fatherImage; }

    // Builder pattern methods
    public PredictRequest withBabyGender(String babyGender) {
        this.babyGender = babyGender;
        return this;
    }

    public PredictRequest withBabyCountry(String babyCountry) {
        this.babyCountry = babyCountry;
        return this;
    }

    public PredictRequest withAppName(String appName) {
        this.appName = appName;
        return this;
    }

    public PredictRequest withMotherPercent(int motherPercent) {
        this.motherPercent = motherPercent;
        return this;
    }

    public PredictRequest withFatherPercent(int fatherPercent) {
        this.fatherPercent = fatherPercent;
        return this;
    }

    public PredictRequest withSkinTone(String skinTone) {
        this.skinTone = skinTone;
        return this;
    }

    public PredictRequest withAgeGroup(String ageGroup) {
        this.ageGroup = ageGroup;
        return this;
    }

    public PredictRequest withCountryCode(String countryCode) {
        this.countryCode = countryCode;
        return this;
    }

    public PredictRequest withPlatform(String platform) {
        this.platform = platform;
        return this;
    }

    public PredictRequest withFcmToken(String fcmToken) {
        this.fcmToken = fcmToken;
        return this;
    }

    public PredictRequest withFirebaseAppCheck(String firebaseAppCheck) {
        this.firebaseAppCheck = firebaseAppCheck;
        return this;
    }

    public PredictRequest withMotherList(String motherList) {
        this.motherList = motherList;
        return this;
    }

    public PredictRequest withFatherList(String fatherList) {
        this.fatherList = fatherList;
        return this;
    }

    public PredictRequest withMotherImage(File motherImage) {
        this.motherImage = motherImage;
        return this;
    }

    public PredictRequest withFatherImage(File fatherImage) {
        this.fatherImage = fatherImage;
        return this;
    }
}
