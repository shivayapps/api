package com.ro.hith.imagic.screens.aivideos.api.get;

import java.io.File;

public interface VideoResponseCallback {
    void onSuccess(File videoFile);
    void onProgress(int progress);
    void onError(String errorMessage);
}