// Individual.java
package com.ro.hith.imagic.screens.aivideos;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.ro.hith.imagic.databinding.FragmentIndividualBinding;
import com.ro.hith.imagic.screens.fragments.BaseUploadFragment;
import com.ro.hith.imagic.screens.utils.appconfig.AppConfig;

public class Individual extends BaseUploadFragment {
    private static final String UPLOAD_TYPE_FIRST = "individual_1";
    private static final String UPLOAD_TYPE_SECOND = "individual_2";
    private FragmentIndividualBinding binding;

    public Individual() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentIndividualBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.girlfriendUpload.setOnClickListener(v -> {
            photoUploadManager.startPhotoUpload(requireActivity(), AppConfig.FEATURE_INDIVISUAL, UPLOAD_TYPE_FIRST);
        });

        binding.boyFriendUpload.setOnClickListener(v -> {
            photoUploadManager.startPhotoUpload(requireActivity(), AppConfig.FEATURE_INDIVISUAL, UPLOAD_TYPE_SECOND);
        });

        binding.generateButton.setOnClickListener(v -> {
            // Check if both images are uploaded
            if (binding.girlfriend.getDrawable() != null && binding.boyfriend.getDrawable() != null) {
                generateResult();
            }
        });
    }

    @Override
    protected void handlePhotoUploaded(Uri imageUri, String uploadType) {
        if (getView() == null) return;

        if (UPLOAD_TYPE_FIRST.equals(uploadType)) {
            Glide.with(requireContext())
                    .load(imageUri.getPath())
                    .centerCrop()
                    .into(binding.girlfriend);
        } else if (UPLOAD_TYPE_SECOND.equals(uploadType)) {
            Glide.with(requireContext())
                    .load(imageUri.getPath())
                    .centerCrop()
                    .into(binding.boyfriend);
        }
    }

    private void generateResult() {
        // Implement your generation logic here
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}