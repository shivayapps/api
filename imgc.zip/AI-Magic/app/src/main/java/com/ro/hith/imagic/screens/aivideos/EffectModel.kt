package com.ro.hith.imagic.screens.aivideos


class EffectModel {
    @JvmField var main_head: String = ""
    @JvmField var input_image: String = ""
    @JvmField var type: String = ""
    @JvmField var effect_name: String = ""
    @JvmField var output_url: String = ""

    companion object {
        @JvmField val instance = EffectModel()
    }
}