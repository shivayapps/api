package com.ro.hith.imagic.screens.commonscreen.screen;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.ro.hith.imagic.R;
import com.ro.hith.imagic.databinding.ActivityMainBinding;
import com.ro.hith.imagic.screens.extension.ExtensionsKt;
import com.ro.hith.imagic.screens.settings.SettingScreen;
import com.ro.hith.imagic.screens.singletone.CustomDialogManager;
import com.ro.hith.imagic.screens.singletone.ExitDialog;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class HomeScreen extends AppCompatActivity {
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
//        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(),
                new OnApplyWindowInsetsListener() {
                    @Override
                    public WindowInsetsCompat onApplyWindowInsets(View v, WindowInsetsCompat insets) {
                        Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                        v.setPadding(
                                systemBars.left,
                                systemBars.top,
                                systemBars.right,
                                0
                        );
                        return insets;
                    }
                }
        );

        loadingFragments();
        setOnClickListners();
    }

    private void navigateToActivity(Class<?> activityClass) {
        Intent intent = new Intent(HomeScreen.this, activityClass);
        startActivity(intent);
        overridePendingTransition(
                R.anim.cusotm_slide_in_right,
                R.anim.custom_slide_out_left
        );
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        new ExitDialog(this, new Function1<Boolean, Unit>() {
            @Override
            public Unit invoke(Boolean isExit) {
                if (isExit) {
                    finishAffinity();
                    //finish();
                }
                return null;
            }
        }).show();
    }

    private void setOnClickListners() {
        binding.settingsButton.setOnClickListener(v -> {
            navigateToActivity(SettingScreen.class);
        });
    }

    private void loadingFragments() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationInHomeScreen);
        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.navHostMAneger);
        NavController navController = navHostFragment.getNavController();
        NavigationUI.setupWithNavController(bottomNavigationView, navController);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}