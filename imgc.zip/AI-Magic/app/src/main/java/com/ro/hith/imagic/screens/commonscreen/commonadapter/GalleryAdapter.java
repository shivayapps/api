package com.ro.hith.imagic.screens.commonscreen.commonadapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.ro.hith.imagic.R;

import java.util.List;

public class GalleryAdapter extends RecyclerView.Adapter<GalleryAdapter.ViewHolder> {
    private List<String> images; // Changed from final to mutable
    private final Context context;
    private final OnItemClickListener listener;

    public interface OnItemClickListener {
        void onCameraClick();
        void onGalleryClick();
        void onImageClick(String imagePath);
    }

    public GalleryAdapter(Context context, List<String> images, OnItemClickListener listener) {
        this.context = context;
        this.images = images;
        this.listener = listener;
    }

    // Add this method to update images
    public void updateImages(List<String> newImages) {
        this.images = newImages;
        notifyDataSetChanged(); // Refresh the adapter
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_gallery_image, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (position == 0) {
            holder.iconView.setVisibility(View.VISIBLE);
            holder.iconView.setImageResource(R.drawable.ic_camera);
            holder.imageView.setImageResource(android.R.color.transparent);
            holder.itemView.setOnClickListener(v -> listener.onCameraClick());
        } else if (position == 1) {
            holder.iconView.setVisibility(View.VISIBLE);
            holder.iconView.setImageResource(R.drawable.ic_gallery);
            holder.imageView.setImageResource(android.R.color.transparent);
            holder.itemView.setOnClickListener(v -> listener.onGalleryClick());
        } else {
            holder.iconView.setVisibility(View.GONE);
            String imagePath = images.get(position - 2);
            Glide.with(context).load(imagePath).into(holder.imageView);
            holder.itemView.setOnClickListener(v -> listener.onImageClick(imagePath));
        }
    }

    @Override
    public int getItemCount() {
        return images.size() + 2;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView, iconView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            iconView = itemView.findViewById(R.id.iconView);
        }
    }
}

/*
package com.ro.hith.imagic.screens.commonscreen.commonadapter;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.ro.hith.imagic.R;

import java.util.List;

public class GalleryAdapter extends RecyclerView.Adapter<GalleryAdapter.ViewHolder> {
    private final List<String> images;
    private final Context context;
    private final OnItemClickListener listener;

    public interface OnItemClickListener {
        void onCameraClick();
        void onGalleryClick();
        void onImageClick(String imagePath);
    }

    public GalleryAdapter(Context context, List<String> images, OnItemClickListener listener) {
        this.context = context;
        this.images = images;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_gallery_image, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (position == 0) {
            holder.iconView.setVisibility(View.VISIBLE);
            holder.iconView.setImageResource(R.drawable.ic_camera);
            holder.imageView.setImageResource(android.R.color.transparent);
            holder.itemView.setOnClickListener(v -> listener.onCameraClick());
        } else if (position == 1) {
            holder.iconView.setVisibility(View.VISIBLE);
            holder.iconView.setImageResource(R.drawable.ic_gallery);
            holder.imageView.setImageResource(android.R.color.transparent);
            holder.itemView.setOnClickListener(v -> listener.onGalleryClick());
        } else {
            holder.iconView.setVisibility(View.GONE);
            String imagePath = images.get(position - 2);
            Glide.with(context).load(imagePath).into(holder.imageView);
            holder.itemView.setOnClickListener(v -> listener.onImageClick(imagePath));
        }
    }

    @Override
    public int getItemCount() {
        return images.size() + 2;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView, iconView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            iconView = itemView.findViewById(R.id.iconView);
        }
    }
}*/
