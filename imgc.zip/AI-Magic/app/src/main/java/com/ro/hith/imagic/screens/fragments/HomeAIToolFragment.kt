package com.ro.hith.imagic.screens.fragments

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.ro.hith.imagic.R
import com.ro.hith.imagic.databinding.FragmentHomeAIToolBinding
import com.ro.hith.imagic.screens.aienhancer.AiEnhancerUploadScreen
import com.ro.hith.imagic.screens.backgroundchanger.BackgroundChangeScreen
import com.ro.hith.imagic.screens.backgroundremover.BackgrounRemovalUploadScreen
import com.ro.hith.imagic.screens.bodyeditor.activites.BodyEditorUploadScreen
import com.ro.hith.imagic.screens.objectremoval.ObjectRemovalScreen

class HomeAIToolFragment : Fragment() {

    private var _binding: FragmentHomeAIToolBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeAIToolBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadImagesWithGlide()
        setupClickListeners()

    }

    private fun loadImagesWithGlide() {
        val requests = mapOf(
            R.drawable.custom_object_remover to binding.imageObjectRemover,
            R.drawable.enhancer to binding.enhancer,
            R.drawable.custom_bg_remover to binding.imageBackgroundRemover,
            R.drawable.custom_body_adjust_vid to binding.imageBodyEditor,
            R.drawable.custom_bg_changer to binding.imageBackgroundChanger
        )

        requests.forEach { (drawableRes, imageView) ->
            Glide.with(this)
                .load(drawableRes)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(imageView)
        }
    }

    private fun setupClickListeners() {
        binding.cardObjectRemover.setOnClickListener {

            /*PhotoUploadManager.getInstance().startPhotoUpload(
                requireActivity(),
                AppConfig.FEATURE_OBJECT_REMOVAL,
                "object_remover"
            );*/


            navigateToActivity(ObjectRemovalScreen::class.java)
        }

        binding.cardAiEnhancer.setOnClickListener {
            navigateToActivity(AiEnhancerUploadScreen::class.java)
        }

        binding.cardBackgroundRemover.setOnClickListener {
            navigateToActivity(BackgrounRemovalUploadScreen::class.java)
        }

        binding.cardBodyEditor.setOnClickListener {
            navigateToActivity(BodyEditorUploadScreen::class.java)
        }

        binding.cardBackgroundChanger.setOnClickListener {
            navigateToActivity(BackgroundChangeScreen::class.java)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun navigateToActivity(activityClass: Class<*>) {
        val intent = Intent(requireContext(), activityClass)
        startActivity(intent)
        (context as Activity).apply {
            overridePendingTransition(
                R.anim.cusotm_slide_in_right,
                R.anim.custom_slide_out_left
            )
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            HomeAIToolFragment().apply {

            }
    }
}