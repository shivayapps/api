package com.ro.hith.imagic.screens.babygen.api;

public interface ApiCallback {
    void onSuccess(String response);
    void onError(String errorMessage);
}