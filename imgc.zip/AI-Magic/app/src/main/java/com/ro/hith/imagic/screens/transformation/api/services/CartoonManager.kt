package com.ro.hith.imagic.screens.transformation.api.services

import android.app.Activity
import android.net.Uri
import android.os.Handler
import android.os.Looper
import com.ro.hith.imagic.screens.transformation.api.reqbuilder.CartoonGenerator
import com.ro.hith.imagic.screens.transformation.api.resposehandler.CartoonResult
import com.ro.hith.imagic.screens.transformation.api.interfaces.CartoonCallback
import com.ro.hith.imagic.screens.utils.appconfig.AppConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.ResponseBody
import retrofit2.Response
import java.io.File
import java.io.FileOutputStream
import java.lang.ref.WeakReference

object CartoonManager {
    // Configuration
    private const val DEFAULT_APP_NAME = AppConfig.DEFAULT_APP_NAME
    private const val DEFAULT_CATEGORY = "cartoon"
    private const val DEFAULT_SUB_CATEGORY = "GTA Men"
    private const val DEFAULT_PROMPT =
        "GTA-style portrait of a person, same face and skin tone as original image, realistic facial structure, highly detailed facial features, smooth skin, bold comic-style outlines, clean lighting, semi-realistic rendering, vibrant colors, urban GTA character art style, 3D look, inspired by Rockstar Games poster artwork, symmetrical face, sharp eyes, confident expression"
    private const val DEFAULT_NEGATIVE_PROMPT =
        "cartoon, anime, exaggerated, abstract, distorted face, extra face, unrealistic, washed out, pale skin, blurry, low detail, smudged, painting, sketch"
    private const val DEFAULT_STEPS = 40
    private const val DEFAULT_SEED = 0L
    private const val DEFAULT_CFG_SCALE = 5.5F
    private const val DEFAULT_DENOISING_STRENGTH = 0.3F
    private const val DEFAULT_SAMPLER_INDEX = "DPM++ 2M"
    private const val DEFAULT_MODEL = "protovisionXLHighFidelity3D_releaseV660Bakedvae"

    private var cartoonGenerator: CartoonGenerator? = null
    private var currentActivityRef: WeakReference<Activity>? = null
    private var fcmToken: String = ""
    private var appCheckToken: String = ""
    private val mainHandler = Handler(Looper.getMainLooper())

    @JvmStatic
    fun initialize(fcmToken: String, appCheckToken: String) {
        CartoonManager.fcmToken = fcmToken
        CartoonManager.appCheckToken = appCheckToken
        val apiService = RetrofitClient.createService()
        cartoonGenerator = CartoonGenerator(apiService, fcmToken, appCheckToken)
    }

    @JvmStatic
    fun setActivity(activity: Activity) {
        currentActivityRef = WeakReference(activity)
    }

    @JvmStatic
    fun clearActivity() {
        currentActivityRef = null
    }

    @JvmStatic
    fun generateCartoon(imageUri: String?) {
        val activity = currentActivityRef?.get()
        val generator = cartoonGenerator

        if (activity == null) {
            notifyError("Activity reference lost")
            return
        }

        if (generator == null) {
            notifyError("CartoonGenerator not initialized. Call initialize() first.")
            return
        }

        if (imageUri == null) {
            notifyError("Image URI is null")
            return
        }


        val file = File(imageUri)
        if (!file.exists()) {
            notifyError("Image file does not exist")
            return
        }
      /*  val imageFile = imageUri.toFile(activity) ?: run {
            notifyError("Failed to convert image URI to file")
            return
        }*/

        // Use CoroutineScope instead of lifecycleScope
        CoroutineScope(Dispatchers.IO).launch {
            when (val result = generator.generateCartoon(
                appName = DEFAULT_APP_NAME,
                category = DEFAULT_CATEGORY,
                subCategory = DEFAULT_SUB_CATEGORY,
                prompt = DEFAULT_PROMPT,
                negativePrompt = DEFAULT_NEGATIVE_PROMPT,
                steps = DEFAULT_STEPS,
                seed = DEFAULT_SEED,
                cfgScale = DEFAULT_CFG_SCALE,
                denoisingStrength = DEFAULT_DENOISING_STRENGTH,
                samplerIndex = DEFAULT_SAMPLER_INDEX,
                model = DEFAULT_MODEL,
                imageFile = file
            )) {
                is CartoonResult.Success -> {
                    notifySuccess(result.response)
                }

                is CartoonResult.Error -> {
                    notifyError("API Error: ${result.errorMessage}")
                }

                CartoonResult.NetworkError -> {
                    notifyNetworkError()
                }

                CartoonResult.UnknownError -> {
                    notifyUnknownError()
                }
            }
        }
    }

    private fun notifySuccess(response: Response<ResponseBody>) {
        val activity = currentActivityRef?.get() as? CartoonCallback ?: return
        // Use Handler to post to main thread
        mainHandler.post {
            activity.onCartoonSuccess(response)
        }
    }

    private fun notifyError(errorMessage: String) {
        val activity = currentActivityRef?.get() as? CartoonCallback ?: return
        mainHandler.post {
            activity.onCartoonError(errorMessage)
        }
    }

    private fun notifyNetworkError() {
        val activity = currentActivityRef?.get() as? CartoonCallback ?: return
        mainHandler.post {
            activity.onCartoonNetworkError()
        }
    }

    private fun notifyUnknownError() {
        val activity = currentActivityRef?.get() as? CartoonCallback ?: return
        mainHandler.post {
            activity.onCartoonUnknownError()
        }
    }

    @JvmStatic
    fun isInitialized(): Boolean {
        return cartoonGenerator != null
    }

    private fun Uri.toFile(activity: Activity): File? {
        return try {
            val inputStream = activity.contentResolver.openInputStream(this) ?: return null
            val file = File.createTempFile("cartoon_input", ".jpg", activity.cacheDir)
            FileOutputStream(file).use { output ->
                inputStream.copyTo(output)
            }
            file
        } catch (e: Exception) {
            null
        }
    }
}