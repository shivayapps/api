package com.ro.hith.imagic.screens.utils.faceswap

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.recyclerview.widget.RecyclerView
import com.ro.hith.imagic.R
import com.ro.hith.imagic.screens.faceswap.FaceSwapCategoryAdapter
import com.ro.hith.imagic.screens.faceswap.FaceSwapSeeAllScreen
import com.ro.hith.imagic.screens.faceswap.model.CategoryItem
import com.ro.hith.imagic.screens.utils.JSONLoder
import org.json.JSONException
import org.json.JSONObject


object FaceSwapDataLoader {

    @JvmStatic
    fun faceSwapCategoryLoder(context: Context): List<CategoryItem> {
        val categoryItems = mutableListOf<CategoryItem>()
        val jsonString = JSONLoder.loadJSONFromRaw(context, R.raw.face_swap).toString()

        try {
            val root = JSONObject(jsonString)
            val keys = root.keys()

            while (keys.hasNext()) {
                val category = keys.next()
                val categoryObj = root.getJSONObject(category)
                val urls = categoryObj.getJSONArray("urls")

                if (urls.length() > 0) {
                    val imageUrl = urls.getJSONObject(0).getString("url")
                    Log.d("CategoryImage", "Category: $category, Image URL: $imageUrl")
                    categoryItems.add(CategoryItem(category, imageUrl))
                }
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }
        return categoryItems
    }

    @JvmStatic
    fun loadFaceSwapMagicData(context: Context, recyclerView: RecyclerView) {
        val topAdapter: FaceSwapCategoryAdapter =
            FaceSwapCategoryAdapter(
                context,
                faceSwapCategoryLoder(context)
            ) { item: CategoryItem?, currentPosition: Int ->
                val intent = Intent(
                    context,
                    FaceSwapSeeAllScreen::class.java
                )
                context.startActivity(intent)
                (context as Activity).apply {
                    overridePendingTransition(
                        R.anim.cusotm_slide_in_right,
                        R.anim.custom_slide_out_left
                    )
                }
            }
        recyclerView.adapter = topAdapter
    }
}

