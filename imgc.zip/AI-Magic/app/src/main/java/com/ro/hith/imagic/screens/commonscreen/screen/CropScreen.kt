package com.ro.hith.imagic.screens.commonscreen.screen

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.ro.hith.imagic.R
import com.ro.hith.imagic.databinding.ActivityCropScreenBinding
import com.ro.hith.imagic.screens.extension.applySystemBarInsets
import com.ro.hith.imagic.screens.singletone.CustomDialogManager
import com.ro.hith.imagic.screens.singletone.FileUtils
import com.ro.hith.imagic.screens.singletone.PhotoUploadManager

class CropScreen : AppCompatActivity() {

    private lateinit var binding: ActivityCropScreenBinding
    private var imageUri: Uri? = null
    private lateinit var faceDetector: FaceDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCropScreenBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        binding.root.applySystemBarInsets()

        // Initialize face detector
        initializeFaceDetector()

        // Get image URI from intent
        imageUri = intent.getParcelableExtra("IMAGE_URI")
        if (imageUri != null) {
            loadImageIntoCropper(imageUri!!)
        } else {
            finish()
        }

        setupClickListeners()
        setupCropImageView()
    }

    private fun initializeFaceDetector() {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_NONE)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .build()

        faceDetector = FaceDetection.getClient(options)
    }

    private fun setupCropImageView() {
        binding.cropImgView.setAspectRatio(1, 1)
        binding.cropImgView.setFixedAspectRatio(true)
    }

    private fun loadImageIntoCropper(uri: Uri) {
        binding.cropImgView.setImageUriAsync(uri)
    }

    private fun setupClickListeners() {
        binding.onBackButton.setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }

        binding.rotate.setOnClickListener {
            binding.cropImgView.rotateImage(90)
        }

        binding.cropImg.setOnClickListener {
            cropAndSaveImage()
        }
    }

    private fun cropAndSaveImage() {
        val croppedBitmap = binding.cropImgView.croppedImage
        if (croppedBitmap != null) {
            detectFacesAndSave(croppedBitmap)
        } else {
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    private fun detectFacesAndSave(bitmap: Bitmap) {
        val inputImage = InputImage.fromBitmap(bitmap, 0)

        faceDetector.process(inputImage)
            .addOnSuccessListener { faces ->
                when {
                    faces.isEmpty() -> {
                        // No face detected
                        CustomDialogManager.getInstance().showDialog(
                            this@CropScreen,
                            "No Face Found",
                            " No face detected in the uploaded image. Please upload clearer image",
                            "Try Again",
                            R.drawable.no_face_found,
                            CustomDialogManager.DialogButtonClickListener { this@CropScreen.finish() }
                        )
                    }
                    faces.size > 1 -> {
                        // Multiple faces detected
                        CustomDialogManager.getInstance().showDialog(
                            this@CropScreen,
                            "Multiple Faces Detected",
                            "We’ve detected more than one face in this image.Make sure the image focuses on one face for the best results",
                            "Try Again",
                            R.drawable.multiple_faces,
                            CustomDialogManager.DialogButtonClickListener { this@CropScreen.finish() }
                        )
                    }
                    else -> {
                        // Exactly one face detected
                        saveCroppedImage(bitmap)
                    }
                }
            }
            .addOnFailureListener { e ->
                // Handle detection failure
                CustomDialogManager.getInstance().showDialog(
                    this@CropScreen,
                    "No Face Found",
                    " No face detected in the uploaded image. Please upload clearer image",
                    "Try Again",
                    R.drawable.no_face_found,
                    CustomDialogManager.DialogButtonClickListener { this@CropScreen.finish() }
                )
                Log.e("CropScreen", "Face detection failed", e)
            }
    }

    private fun saveCroppedImage(bitmap: Bitmap) {
        try {
            PhotoUploadManager.getInstance().setUniversalBitmap(bitmap)
            val filePath = bitmapToUri(bitmap)
            if (filePath != null) {
                val croppedUri = Uri.parse(filePath)

                val resultIntent = Intent().apply {
                    putExtra("CROPPED_IMAGE_URI", croppedUri.toString())
                }
                Log.d("InAppGalleryScreen", "Cropped properly: ")
                setResult(RESULT_OK, resultIntent)
                finish()
            } else {
                Log.d("InAppGalleryScreen", "Failed to save image")
                Toast.makeText(
                    this@CropScreen,
                    "Failed to save image. Please try again.",
                    Toast.LENGTH_SHORT
                ).show()
                setResult(RESULT_CANCELED)
                finish()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.d("InAppGalleryScreen", "Error: ${e.message}")
            Toast.makeText(
                this@CropScreen,
                "An error occurred. Please try again.",
                Toast.LENGTH_SHORT
            ).show()
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    private fun bitmapToUri(bitmap: Bitmap): String? {
        val filePath = FileUtils.saveBitmapToInternalStorage(this, bitmap, "FaceSwapImages")
        if (filePath == null) {
            Log.e("CropScreen", "Failed to save cropped image")
        }
        return filePath
    }

    override fun onDestroy() {
        super.onDestroy()
        // Clean up face detector
        faceDetector.close()
    }
}