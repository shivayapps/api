package com.ro.hith.imagic.screens.fragments;

import android.net.Uri;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import com.ro.hith.imagic.screens.singletone.PhotoUploadManager;

public abstract class BaseUploadFragment extends Fragment implements PhotoUploadManager.PhotoUploadCallback {
    protected PhotoUploadManager photoUploadManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        photoUploadManager = PhotoUploadManager.getInstance();
    }

    @Override
    public void onResume() {
        super.onResume();
        // Set callback every time fragment resumes
        photoUploadManager.setCallback(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        // Don't clear the callback entirely, just remove reference to this fragment
        // This allows other fragments to still receive callbacks

    }

    protected abstract void handlePhotoUploaded(Uri imageUri, String uploadType);

    @Override
    public void onPhotoUploaded(Uri imageUri, String feature, String uploadType) {
        if (getActivity() != null && isAdded()) {
            getActivity().runOnUiThread(() -> handlePhotoUploaded(imageUri, uploadType));
        }
    }
}