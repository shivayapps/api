package com.ro.hith.imagic.screens.facedance;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.ro.hith.imagic.databinding.ActivityFaceDanceSeeAllScreenBinding;
import com.ro.hith.imagic.screens.extension.ExtensionsKt;
import com.ro.hith.imagic.screens.utils.facedance.FaceDanceDataLoader;

public class FaceDanceSeeAllScreen extends AppCompatActivity {

    private ActivityFaceDanceSeeAllScreenBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityFaceDanceSeeAllScreenBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        FaceDanceDataLoader.loadFaceDanceData(FaceDanceSeeAllScreen.this, binding.faceDanceRecyclerView);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}