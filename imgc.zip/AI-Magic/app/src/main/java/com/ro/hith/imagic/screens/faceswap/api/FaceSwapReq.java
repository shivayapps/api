package com.ro.hith.imagic.screens.faceswap.api;

import static android.content.ContentValues.TAG;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.ro.hith.imagic.R;
import com.ro.hith.imagic.screens.commonscreen.screen.CommonResultScreen;
import com.ro.hith.imagic.screens.faceswap.interfaces.FaceSwapCallback;
import com.ro.hith.imagic.screens.singletone.CustomDialogManager;
import com.ro.hith.imagic.screens.singletone.FileUtils;
import com.ro.hith.imagic.screens.utils.appconfig.AppConfig;
import com.ro.hith.imagic.screens.utils.appconfig.StartActivityGlobally;

import org.json.JSONException;
import org.json.JSONObject;

import kotlin.Pair;

public class FaceSwapReq {
    private static FaceSwapReq instance;
    private final FaceSwapClient faceSwapClient;

    // Private constructor to prevent instantiation
    private FaceSwapReq() {
        faceSwapClient = FaceSwapClient.getInstance();
    }

    // Singleton instance getter
    public static synchronized FaceSwapReq getInstance() {
        if (instance == null) {
            instance = new FaceSwapReq();
        }
        return instance;
    }

    public static void clearInstance() {
        instance = null;
    }

    public void uploadImages(Activity activity,
                             String bikeImageName,
                             String sourceImagePath,
                             String fcmToken,
                             String appCheckToken,
                             String appName) {

        // Add null checks for all parameters
        if (activity == null) {
            Log.e("FaceSwap", "Activity cannot be null");
            return;
        }

        if (bikeImageName == null || bikeImageName.isEmpty()) {
            showError(activity, "Bike image name cannot be empty");
            return;
        }

        if (sourceImagePath == null || sourceImagePath.isEmpty()) {
            showError(activity, "Source image path cannot be empty");
            return;
        }

        if (!FileUtils.fileExists(sourceImagePath)) {
            showError(activity, "Image file is not available. Please try again.");
            return;
        }

        if (fcmToken == null || fcmToken.isEmpty()) {
            showError(activity, "FCM token cannot be empty");
            return;
        }

        if (appCheckToken == null || appCheckToken.isEmpty()) {
            showError(activity, "App check token cannot be empty");
            return;
        }

        if (appName == null || appName.isEmpty()) {
            showError(activity, "App name cannot be empty");
            return;
        }

        faceSwapClient.uploadImages(
                bikeImageName,
                sourceImagePath,
                fcmToken,
                appCheckToken,
                appName,
                new FaceSwapCallback() {
                    @Override
                    public void onSuccess(String response) {
                        activity.runOnUiThread(() -> {
                            Log.d("FaceSwap", "Success: " + response);
                            Toast.makeText(activity, "Upload successful", Toast.LENGTH_SHORT).show();
                            try {
                                JSONObject jsonResponse = new JSONObject(response);
                                String requestId = jsonResponse.getString("request_id");
                                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        processToNextScreen(activity, requestId);
                                    }
                                }, 10000);
                            } catch (JSONException e) {
                                Log.e("FaceSwap", "Error parsing JSON response: " + e.getMessage());
                                Toast.makeText(activity, "Error processing response", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }

                    @Override
                    public void onError(String errorMessage) {
                        activity.runOnUiThread(() -> {
                            showNoServer(activity);
                            Log.e("FaceSwap", "Error: " + errorMessage);
                            Toast.makeText(activity, "Error: " + errorMessage, Toast.LENGTH_SHORT).show();
                        });
                    }

                    @Override
                    public void onFailure(Throwable throwable) {
                        activity.runOnUiThread(() -> {
                            showNoServer(activity);
                            Log.e("FaceSwap", "Failure: " + throwable.getMessage());
                            Toast.makeText(activity, "Network failure", Toast.LENGTH_SHORT).show();
                        });
                    }
                }
        );
    }

    @SuppressWarnings("unchecked")
    private void processToNextScreen(Activity activity, String requestId) {
        Log.d(TAG, "Generate face swap button clicked");
        StartActivityGlobally.navigateToActivityWithFeature(
                activity,
                CommonResultScreen.class,
                new Pair<>(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT, requestId),
                new Pair<>(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_FACESWAP)
        );
        activity.finish();
    }


    private void showNoServer(Activity activity) {
        if (activity != null) {
            android.os.Handler handler = new android.os.Handler(activity.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    CustomDialogManager.getInstance().showDialog(
                            activity,
                            "No Server",
                            "We are unable to connect to the server at this time. Please check your internet connection and try again",
                            "Got it",
                            R.drawable.ic_brush,
                            new CustomDialogManager.DialogButtonClickListener() {
                                @Override
                                public void onButtonClicked() {
                                    activity.finish();
                                }
                            }
                    );
                }
            });
        }
    }

    private void showError(Activity activity, String message) {
        if (activity != null && !activity.isFinishing()) {
            activity.runOnUiThread(() -> {
                Toast.makeText(activity, message, Toast.LENGTH_SHORT).show();
                Log.e("FaceSwap", message);
            });
        }
    }
}