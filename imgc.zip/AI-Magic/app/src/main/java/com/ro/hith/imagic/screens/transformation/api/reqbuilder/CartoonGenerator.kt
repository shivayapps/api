package com.ro.hith.imagic.screens.transformation.api.reqbuilder

import com.ro.hith.imagic.screens.transformation.api.interfaces.CartoonApiService
import com.ro.hith.imagic.screens.transformation.api.resposehandler.CartoonResult
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okio.IOException

class CartoonGenerator(
    private val apiService: CartoonApiService,
    private val fcmToken: String,
    private val appCheckToken: String
) {
    suspend fun generateCartoon(
        appName: String,
        category: String,
        subCategory: String,
        prompt: String,
        negativePrompt: String,
        steps: Int,
        seed: Long,
        cfgScale: Float,
        denoisingStrength: Float,
        samplerIndex: String,
        model: String,
        imageFile: java.io.File
    ): CartoonResult {
        return try {
            // Create image part only (other parameters are query params)
            val imageRequestBody = imageFile.asRequestBody("image/jpeg".toMediaTypeOrNull())
            val imagePart = MultipartBody.Part.createFormData(
                "input_image",
                imageFile.name,
                imageRequestBody
            )

            val response = apiService.generateCartoon(
                appName = appName,
                category = category,
                subCategory = subCategory,
                prompt = prompt,
                negativePrompt = negativePrompt,
                steps = steps,
                seed = seed,
                cfgScale = cfgScale,
                denoisingStrength = denoisingStrength,
                samplerIndex = samplerIndex,
                model = model,
                inputImage = imagePart,
                fcmToken = fcmToken,
                appCheckToken = appCheckToken
            )

            if (response.isSuccessful) {
                CartoonResult.Success(response)
            } else {
                CartoonResult.Error("API Error: ${response.code()}", response.code())
            }
        } catch (e: IOException) {
            CartoonResult.NetworkError
        } catch (e: Exception) {
            CartoonResult.UnknownError
        }
    }
}