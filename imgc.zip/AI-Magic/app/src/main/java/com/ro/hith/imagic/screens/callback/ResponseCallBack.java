package com.ro.hith.imagic.screens.callback;

public interface ResponseCallBack {
    void onSuccess(String response);

    void onError(String errorMessage);
}