// PhotoUploadManager.java
package com.ro.hith.imagic.screens.singletone;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import androidx.fragment.app.FragmentActivity;

import com.ro.hith.imagic.screens.commonscreen.screen.InAppGalleryScreen;

public class PhotoUploadManager {
    private static PhotoUploadManager instance;
    private Uri currentImageUri;
    private Bitmap universalBitmap;

    public Bitmap getUniversalBitmap() {
        return universalBitmap;
    }

    public void setUniversalBitmap(Bitmap universalBitmap) {
        this.universalBitmap = universalBitmap;
    }

    public String getCurrentImageUriStringPath() {
        return currentImageUriStringPath;
    }

    public void setCurrentImageUriStringPath(String currentImageUriStringPath) {
        this.currentImageUriStringPath = currentImageUriStringPath;
    }

    private String  currentImageUriStringPath;
    private String currentUploadType;
    private String currentFeature;
    private PhotoUploadCallback callback;

    private PhotoUploadManager() {
    }

    public static synchronized PhotoUploadManager getInstance() {
        if (instance == null) {
            instance = new PhotoUploadManager();
        }
        return instance;
    }

    public void startPhotoUpload(FragmentActivity activity, String feature, String uploadType) {
        this.currentFeature = feature;
        this.currentUploadType = uploadType;
        this.currentImageUri = null; // Clear previous image

        Intent intent = new Intent(activity, InAppGalleryScreen.class);
        activity.startActivity(intent);
    }

    public void setImageUri(Uri imageUri) {
        this.currentImageUri = imageUri;
    }

    public Uri getCurrentImageUri() {
        return currentImageUri;
    }

    public String getCurrentUploadType() {
        return currentUploadType;
    }

    public String getCurrentFeature() {
        return currentFeature;
    }

    public void setCallback(PhotoUploadCallback callback) {
        this.callback = callback;
    }

    public PhotoUploadCallback getCallback() {
        return callback;
    }

  /*  public void notifyPhotoUploaded(Uri imageUri) {
        // Store the image URI
        this.currentImageUri = imageUri;

        // Notify callback if available
        if (callback != null && currentUploadType != null && currentFeature != null) {
            callback.onPhotoUploaded(imageUri, currentFeature, currentUploadType);
        }
    }*/

    public void notifyPhotoUploaded(String imagePath) {
        if (imagePath != null) {
            this.currentImageUriStringPath = imagePath;
            this.currentImageUri = Uri.parse(imagePath);

            // Notify callback if available
            if (callback != null && currentUploadType != null && currentFeature != null) {
                callback.onPhotoUploaded(this.currentImageUri, currentFeature, currentUploadType);
            }
        }
    }

    public void clear() {
        currentImageUri = null;
        currentUploadType = null;
        currentFeature = null;
        // Don't clear callback as it might be set by another component
    }

    public interface PhotoUploadCallback {
        void onPhotoUploaded(Uri imageUri, String feature, String uploadType);
    }
}

