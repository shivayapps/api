package com.ro.hith.imagic.screens.aivideos;

import android.util.SparseArray;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.ro.hith.imagic.screens.babygen.fragments.BabyBoy;
import com.ro.hith.imagic.screens.babygen.fragments.BabyGirl;


public class CoupleDoubleFragmentLoder extends FragmentStateAdapter {



    private final SparseArray<Fragment> fragmentList = new SparseArray<>();

    public CoupleDoubleFragmentLoder(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        Fragment fragment;
        if (position == 0) {
            fragment = new Individual();
        } else {
            fragment = new Couple();
        }
        fragmentList.put(position, fragment); // Track fragment instance
        return fragment;
    }

    @Override
    public int getItemCount() {
        return 2;
    }

    public Fragment getFragment(int position) {
        return fragmentList.get(position);
    }
}
