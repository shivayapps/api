package com.ro.hith.imagic.screens.faceswap.model;

import java.io.Serializable;

public class LocalizedName implements Serializable {
    private String en;
    private String hi;
    public LocalizedName(String en, String hi) {
        this.en = en != null ? en : "";
        this.hi = hi != null ? hi : "";
    }

    public String getEn() {
        return en != null ? en : "";
    }

    public String getHi() {
        return hi != null ? hi : "";
    }
}