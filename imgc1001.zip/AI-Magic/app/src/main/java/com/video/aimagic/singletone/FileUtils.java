package com.video.aimagic.singletone;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.util.Log;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileUtils {

    public static String saveBitmapToInternalStorage(Context context, Bitmap bitmap, String directoryName) {
        FileOutputStream outputStream = null;
        try {
            File directory = new File(context.getFilesDir(), directoryName);
            if (!directory.exists()) {
                directory.mkdirs();
            }

            String imageName = "image_" + System.currentTimeMillis() + ".jpg";
            File imageFile = new File(directory, imageName);

            outputStream = new FileOutputStream(imageFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream);
            outputStream.flush();

             Uri contentUri = FileProvider.getUriForFile(
                    context,
                    context.getPackageName() + ".fileprovider",
                    imageFile
            );

            PhotoUploadManager.getInstance().setCurrentImageUriStringPath(imageFile.getAbsolutePath());
            PhotoUploadManager.getInstance().setImageUri(contentUri);
            PhotoUploadManager.getInstance().notifyPhotoUploaded(imageFile.getAbsolutePath());

            PhotoUploadManager.getInstance().setCurrentImageUriStringPath(imageFile.getAbsolutePath());
            Log.d("FileUtils", "Image saved to: " + imageFile.getAbsolutePath());

            return imageFile.getAbsolutePath();

        } catch (IOException e) {
            Log.e("FileUtils", "Error saving image: " + e.getMessage());
            return null;
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    Log.e("FileUtils", "Error closing stream: " + e.getMessage());
                }
            }
        }
    }

    public static boolean fileExists(String filePath) {
        if (filePath == null) return false;
        File file = new File(filePath);
        return file.exists() && file.canRead() && file.length() > 0;
    }

    public static void deleteFile(String filePath) {
        if (filePath != null) {
            File file = new File(filePath);
            if (file.exists()) {
                file.delete();
            }
        }
    }
}