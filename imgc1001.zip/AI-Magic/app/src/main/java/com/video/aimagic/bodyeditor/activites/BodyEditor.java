package com.video.aimagic.bodyeditor.activites;

import android.app.Activity;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.video.aimagic.databinding.ActivityBodyEditorBinding;
import com.video.aimagic.bodyeditor.screens.ChestEditor;
import com.video.aimagic.bodyeditor.screens.FaceEditor;
import com.video.aimagic.bodyeditor.screens.HipsEditor;
import com.video.aimagic.bodyeditor.screens.WaistEditor;
import com.video.aimagic.extension.ExtensionsKt;
import com.video.aimagic.singletone.PhotoUploadManager;
import com.video.aimagic.utils.appconfig.StartActivityGlobally;

public class BodyEditor extends AppCompatActivity {
    private ActivityBodyEditorBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityBodyEditorBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        setOnClickListners();

    }

    private void setOnClickListners() {
        binding.faceControl.setOnClickListener(view -> navigateUser(FaceEditor.class));
        binding.waistControl.setOnClickListener(view -> navigateUser(WaistEditor.class));
        binding.chestControl.setOnClickListener(view -> navigateUser(ChestEditor.class));
        binding.hipsControl.setOnClickListener(view -> navigateUser(HipsEditor.class));
    }

    private void setImageResource() {

        try {
            binding.bodyPreviewImage.setImageBitmap(PhotoUploadManager.getInstance().getUniversalBitmap());
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    protected void onResume() {
        super.onResume();
        setImageResource();
    }

    @SuppressWarnings("unchecked")
    private void navigateUser(Class<? extends Activity> targetActivity) {
        StartActivityGlobally.navigateToActivityWithFeature(
                BodyEditor.this,
                targetActivity);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}