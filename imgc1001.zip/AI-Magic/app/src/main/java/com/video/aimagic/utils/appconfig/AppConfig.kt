package com.video.aimagic.utils.appconfig

import com.google.android.gms.common.Feature


object AppConfig {
    const val FEATURE_COUPLE = "couple"
    const val FEATURE_AIENHANCER = "enhancer"
    const val FEATURE_BODY_EDITOR = "enhancer"
    const val FEATURE_OBJECT_REMOVAL = "object_removal"
    const val FEATURE_OBJECT_R_UPLOAD_PHOTO_ACTION  = "object_remover"
    const val FEATURE_BABY_BOY = "baby_boy"
    const val FEATURE_BABY_GIRL = "baby_girl"
    const val FEATURE_INDIVISUAL = "individual"
    const val FEATURE_FACESWAP = "face_swap"
    const val FEATURE_AI_VIDEO_SINGLE = "single_video"
    const val FEATURE_REMOVE_BG = "remove_bg"
    const val FEATURE_CHANGE_BG = "change_bg"
    const val FEATURE_FACE_DANCE = "face_dance"
    const val FEATURE_TRANSE_FACE_SWAP = "trans_face_swap"
//    const val DEFAULT_APP_NAME  = "aimagic"
    const val DEFAULT_APP_NAME  = "iMagicBlack"

    @JvmField
    var INTENT_FEATURED_PASSED_AS = "user_feature"
    @JvmField
    var INTENT_REQ_ID_FOR_GET_RESULT = "request_id"
    @JvmField
    var SELECTED_FACE_SWAP_URL_NAME_FOLDER_IMAGE_NAME = "selected_image_url"


}