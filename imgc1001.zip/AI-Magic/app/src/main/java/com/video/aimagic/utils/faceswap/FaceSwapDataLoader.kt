package com.video.aimagic.utils.faceswap

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.recyclerview.widget.RecyclerView
import com.video.aimagic.R
import com.video.aimagic.faceswap.FaceSwapCategoryAdapter
import com.video.aimagic.faceswap.FaceSwapSeeAllScreen
import com.video.aimagic.faceswap.model.CategoryItem
import com.video.aimagic.utils.JSONLoder
import org.json.JSONException
import org.json.JSONObject


object FaceSwapDataLoader {

    @JvmStatic
    fun faceSwapCategoryLoder(context: Context): List<CategoryItem> {
        val categoryItems = mutableListOf<CategoryItem>()
        val jsonString = JSONLoder.loadJSONFromRaw(context, R.raw.face_swap).toString()

        try {
            val root = JSONObject(jsonString)
            val keys = root.keys()

            while (keys.hasNext()) {
                val category = keys.next()
                val categoryObj = root.getJSONObject(category)
                val urls = categoryObj.getJSONArray("urls")

                if (urls.length() > 0) {
                    val imageUrl = urls.getJSONObject(0).getString("url")
                    Log.d("CategoryImage", "Category: $category, Image URL: $imageUrl")
                    categoryItems.add(CategoryItem(category, imageUrl))
                }
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }
        return categoryItems
    }

    @JvmStatic
    fun loadFaceSwapMagicData(context: Context, recyclerView: RecyclerView) {
        val topAdapter: FaceSwapCategoryAdapter =
            FaceSwapCategoryAdapter(
                context,
                faceSwapCategoryLoder(context)
            ) { item: CategoryItem?, currentPosition: Int ->
                val intent = Intent(
                    context,
                    FaceSwapSeeAllScreen::class.java
                )
                intent.putExtra("cat",""+item?.title)
                intent.putExtra("position",currentPosition)
                context.startActivity(intent)
                (context as Activity).apply {
                    overridePendingTransition(
                        R.anim.cusotm_slide_in_right,
                        R.anim.custom_slide_out_left
                    )
                }
            }
        recyclerView.adapter = topAdapter
    }
}

