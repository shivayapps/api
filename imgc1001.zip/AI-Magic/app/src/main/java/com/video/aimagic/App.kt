package com.video.aimagic

import android.content.Context
import androidx.multidex.MultiDexApplication
import com.video.aimagic.commonscreen.adapter.MediaItem


class App : MultiDexApplication() {
    companion object {
        var displayListItem: ArrayList<MediaItem> = ArrayList()
        lateinit var appContext: Context

    }

    override fun onCreate() {
        super.onCreate()
        appContext = applicationContext
    }
}