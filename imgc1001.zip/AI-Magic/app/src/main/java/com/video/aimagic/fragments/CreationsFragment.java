package com.video.aimagic.fragments;

import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.video.aimagic.R;
import com.video.aimagic.databinding.FragmentCreationsBinding;
import com.video.aimagic.App;
import com.video.aimagic.commonscreen.adapter.CreationAdapter;
import com.video.aimagic.commonscreen.adapter.MediaItem;
import com.video.aimagic.commonscreen.screen.FileViewerActivity;
import com.video.aimagic.utils.CommonPagerAdapter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CreationsFragment extends Fragment {

    private FragmentCreationsBinding binding;

    public CreationsFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentCreationsBinding.inflate(inflater, container, false);
//        RecyclerView recyclerView = findViewById(R.id.recyclerView);


        setTab();
        setData();

        return binding.getRoot();
    }


    private void setTab() {
        String[] titles = {"Image", "Video"};

        for (int i = 0; i < titles.length; i++) {
            TabLayout.Tab tab = binding.tabLay.newTab();
            View customView = LayoutInflater.from(getActivity()).inflate(R.layout.new_tab_view_for_category, null);
            TextView tabText = customView.findViewById(R.id.tabText);
            tabText.setText(titles[i]);
            tab.setCustomView(customView);
            binding.tabLay.addTab(tab);
        }


        CommonPagerAdapter commonPagerAdapter = new CommonPagerAdapter();
        commonPagerAdapter.insertViewId(R.id.tabImage);
        commonPagerAdapter.insertViewId(R.id.tabVideo);
        binding.viewPager.setOffscreenPageLimit(2);
        binding.viewPager.setAdapter(commonPagerAdapter);
        //binding.viewPager.setPagingEnabled(false);
        binding.tabLay.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                binding.viewPager.setCurrentItem(tab.getPosition());
                if (tab.getCustomView() != null) {
                    tab.getCustomView().setSelected(true);
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                if (tab.getCustomView() != null) {
                    tab.getCustomView().setSelected(false);
                }
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // no-op
            }
        });
        binding.viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                TabLayout.Tab tab = binding.tabLay.getTabAt(position);
                if (tab != null) {
                    binding.tabLay.selectTab(tab);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }

    private void setData() {
        List<MediaItem> imageList = getIMagicImages(); // MediaStore method
        CreationAdapter imageAdapter = new CreationAdapter(getContext(), imageList, new CreationAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                openListItem(imageList, position);
            }
        });
        binding.rvImage.setLayoutManager(new GridLayoutManager(getContext(), 2));
        binding.rvImage.setAdapter(imageAdapter);

        List<MediaItem> videoList = getIMagicVideos(); // MediaStore method
        CreationAdapter videoAdapter = new CreationAdapter(getContext(), videoList, new CreationAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                openListItem(videoList, position);
            }
        });
        binding.rvVideo.setLayoutManager(new GridLayoutManager(getContext(), 2));
        binding.rvVideo.setAdapter(videoAdapter);

    }


    public void openListItem(
            List<MediaItem> listItems,
            int position
    ) {
//        App.Companion.setDisplayListItem(listItems);
        App.Companion.setDisplayListItem(new ArrayList<>(listItems));
        Intent intent = new Intent(getActivity(), FileViewerActivity.class);
        intent.putExtra("POSITION", position);
        startActivity(intent);
    }

    private List<MediaItem> getIMagicMedia() {

        List<MediaItem> list = new ArrayList<>();

        // ---------- IMAGES ----------
        Uri imageUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

        String[] imageProjection = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME
        };

        String imageSelection =
                MediaStore.Images.Media.RELATIVE_PATH + "=?";

        String[] imageArgs = new String[]{
                Environment.DIRECTORY_DCIM + "/iMagic/"
        };

        Cursor imageCursor = getActivity().getContentResolver().query(
                imageUri,
                imageProjection,
                imageSelection,
                imageArgs,
                MediaStore.Images.Media.DATE_ADDED + " DESC"
        );

        if (imageCursor != null) {
            while (imageCursor.moveToNext()) {

                long id = imageCursor.getLong(0);
                String name = imageCursor.getString(1);

                Uri contentUri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);

                list.add(new MediaItem(
                        name,
                        contentUri,
                        MediaItem.TYPE_IMAGE,
                        0
                ));
            }
            imageCursor.close();
        }

        // ---------- VIDEOS ----------
        Uri videoUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;

        String[] videoProjection = {
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION
        };

        String videoSelection =
                MediaStore.Video.Media.RELATIVE_PATH + "=?";

        String[] videoArgs = new String[]{
                Environment.DIRECTORY_DCIM + "/iMagic/"
        };

        Cursor videoCursor = getActivity().getContentResolver().query(
                videoUri,
                videoProjection,
                videoSelection,
                videoArgs,
                MediaStore.Video.Media.DATE_ADDED + " DESC"
        );

        if (videoCursor != null) {
            while (videoCursor.moveToNext()) {

                long id = videoCursor.getLong(0);
                String name = videoCursor.getString(1);
                long duration = videoCursor.getLong(2);

                Uri contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id);

                list.add(new MediaItem(
                        name,
                        contentUri,
                        MediaItem.TYPE_VIDEO,
                        duration
                ));
            }
            videoCursor.close();
        }

        // Optional: sort mixed media by newest
        Collections.sort(list, (a, b) -> b.name.compareTo(a.name));

        return list;
    }

    private List<MediaItem> getIMagicImages() {

        List<MediaItem> imageList = new ArrayList<>();

        Uri imageUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME
        };

        String selection =
                MediaStore.Images.Media.RELATIVE_PATH + "=?";

        String[] selectionArgs = {
                Environment.DIRECTORY_DCIM + "/iMagic/"
        };

        Cursor cursor = requireActivity().getContentResolver().query(
                imageUri,
                projection,
                selection,
                selectionArgs,
                MediaStore.Images.Media.DATE_ADDED + " DESC"
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {

                long id = cursor.getLong(0);
                String name = cursor.getString(1);

                Uri contentUri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id
                );

                imageList.add(new MediaItem(
                        name,
                        contentUri,
                        MediaItem.TYPE_IMAGE,
                        0
                ));
            }
            cursor.close();
        }

        return imageList;
    }

    private List<MediaItem> getIMagicVideos() {

        List<MediaItem> videoList = new ArrayList<>();

        Uri videoUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION
        };

        String selection =
                MediaStore.Video.Media.RELATIVE_PATH + "=?";

        String[] selectionArgs = {
                Environment.DIRECTORY_DCIM + "/iMagic/"
        };

        Cursor cursor = requireActivity().getContentResolver().query(
                videoUri,
                projection,
                selection,
                selectionArgs,
                MediaStore.Video.Media.DATE_ADDED + " DESC"
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {

                long id = cursor.getLong(0);
                String name = cursor.getString(1);
                long duration = cursor.getLong(2);

                Uri contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id
                );

                videoList.add(new MediaItem(
                        name,
                        contentUri,
                        MediaItem.TYPE_VIDEO,
                        duration
                ));
            }
            cursor.close();
        }

        return videoList;
    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}