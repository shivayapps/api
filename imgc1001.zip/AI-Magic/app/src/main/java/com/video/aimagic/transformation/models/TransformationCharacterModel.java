package com.video.aimagic.transformation.models;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.Map;

public class TransformationCharacterModel implements Parcelable {
    public String positive_prompt;
    public String negative_prompt;
    public int Sampling_steps;
    public String type;
    public double CFG_scale;
    public long Seed;
    public String Model;
    public double Denoising_strength;
    public double Time_taken;
    public String ratio;
    public String input_url;
    public String output_url;
    public String sampler_index;
    public Map<String, String> cat_name_localised;

    public TransformationCharacterModel() {
    }

    protected TransformationCharacterModel(Parcel in) {
        positive_prompt = in.readString();
        negative_prompt = in.readString();
        Sampling_steps = in.readInt();
        type = in.readString();
        CFG_scale = in.readDouble();
        Seed = in.readLong();
        Model = in.readString();
        Denoising_strength = in.readDouble();
        Time_taken = in.readDouble();
        ratio = in.readString();
        input_url = in.readString();
        output_url = in.readString();
        sampler_index = in.readString();
        cat_name_localised = in.readHashMap(getClass().getClassLoader());
    }

    public static final Creator<TransformationCharacterModel> CREATOR = new Creator<TransformationCharacterModel>() {
        @Override
        public TransformationCharacterModel createFromParcel(Parcel in) {
            return new TransformationCharacterModel(in);
        }

        @Override
        public TransformationCharacterModel[] newArray(int size) {
            return new TransformationCharacterModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(positive_prompt);
        dest.writeString(negative_prompt);
        dest.writeInt(Sampling_steps);
        dest.writeString(type);
        dest.writeDouble(CFG_scale);
        dest.writeLong(Seed);
        dest.writeString(Model);
        dest.writeDouble(Denoising_strength);
        dest.writeDouble(Time_taken);
        dest.writeString(ratio);
        dest.writeString(input_url);
        dest.writeString(output_url);
        dest.writeString(sampler_index);
        dest.writeMap(cat_name_localised);
    }
}