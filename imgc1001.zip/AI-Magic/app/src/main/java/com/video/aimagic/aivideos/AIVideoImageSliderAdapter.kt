package com.video.aimagic.aivideos

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.viewpager.widget.PagerAdapter
import com.video.aimagic.R

class AIVideoImageSliderAdapter(
    private val context: Context,
    private val images: List<Int>
) : PagerAdapter() {

    private val inflater = LayoutInflater.from(context)

    override fun getCount(): Int = images.size

    override fun isViewFromObject(view: View, obj: Any): Boolean = view == obj

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val view = inflater.inflate(R.layout.ai_video_slide_item, container, false)
        val imageView = view.findViewById<ImageView>(R.id.aivideoSliderImage)
        imageView.setImageResource(images[position])
        container.addView(view)
        return view
    }

    override fun destroyItem(container: ViewGroup, position: Int, obj: Any) {
        container.removeView(obj as View)
    }
}