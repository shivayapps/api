package com.video.aimagic.transformation.models;

import android.os.Parcel;
import android.os.Parcelable;

public class TransformationCharacterItem implements Parcelable {
    public String category;
    public String subCategory;
    public TransformationCharacterModel model;

    public TransformationCharacterItem(String category, String subCategory, TransformationCharacterModel model) {
        this.category = category;
        this.subCategory = subCategory;
        this.model = model;
    }

    protected TransformationCharacterItem(Parcel in) {
        category = in.readString();
        subCategory = in.readString();
        model = in.readParcelable(TransformationCharacterModel.class.getClassLoader());
    }

    public static final Creator<TransformationCharacterItem> CREATOR = new Creator<TransformationCharacterItem>() {
        @Override
        public TransformationCharacterItem createFromParcel(Parcel in) {
            return new TransformationCharacterItem(in);
        }

        @Override
        public TransformationCharacterItem[] newArray(int size) {
            return new TransformationCharacterItem[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(category);
        dest.writeString(subCategory);
        dest.writeParcelable(model, flags);
    }
}