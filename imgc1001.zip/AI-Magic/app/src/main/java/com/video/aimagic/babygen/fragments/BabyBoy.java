// BabyBoy.java
package com.video.aimagic.babygen.fragments;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.video.aimagic.R;
import com.video.aimagic.databinding.FragmentBabyBoyBinding;
import com.video.aimagic.commonscreen.screen.CommonProcessing;
import com.video.aimagic.fragments.BaseUploadFragment;
import com.video.aimagic.utils.appconfig.AppConfig;
import com.video.aimagic.utils.appconfig.StartActivityGlobally;

import kotlin.Pair;

public class BabyBoy extends BaseUploadFragment {

    private static final String UPLOAD_TYPE_FATHER = "father_boy";
    private static final String UPLOAD_TYPE_MOTHER = "mother_boy";
    private FragmentBabyBoyBinding binding;

    public BabyBoy() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentBabyBoyBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.uploadFather.setOnClickListener(v -> {
            photoUploadManager.startPhotoUpload(
                    requireActivity(),
                    AppConfig.FEATURE_BABY_BOY,
                    UPLOAD_TYPE_FATHER
            );
        });

        binding.uploadMother.setOnClickListener(v -> {
            photoUploadManager.startPhotoUpload(
                    requireActivity(),
                    AppConfig.FEATURE_BABY_BOY,
                    UPLOAD_TYPE_MOTHER
            );
        });

        setupSkinToneSelection();

        binding.generateButton.setOnClickListener(v -> {
            if (binding.fatherPhoto.getDrawable() != null && binding.motherPhoto.getDrawable() != null) {
                generateFaceSwap();
            } else {
                Toast.makeText(requireActivity(), "Please upload both photo", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupSkinToneSelection() {
        int[] skinToneIds = {
                R.id.skinToneOption1,
                R.id.skinToneOption2,
                R.id.skinToneOption3,
                R.id.skinToneOption4
        };

        for (int i = 0; i < skinToneIds.length; i++) {
            final int index = i;
            requireView().findViewById(skinToneIds[i]).setOnClickListener(v -> {
                updateSkinToneSelection(index);
            });
        }
    }

    private void updateSkinToneSelection(int selectedIndex) {
        int[] skinToneIds = {
                R.id.skinToneOption1,
                R.id.skinToneOption2,
                R.id.skinToneOption3,
                R.id.skinToneOption4
        };

        for (int i = 0; i < skinToneIds.length; i++) {
            ImageView skinToneView = requireView().findViewById(skinToneIds[i]);
            if (i == selectedIndex) {
                skinToneView.setBackgroundResource(R.drawable.pro_gradient);
            } else {
                skinToneView.setBackgroundResource(R.drawable.not_selected_item);
            }
        }
    }

    @Override
    protected void handlePhotoUploaded(Uri imageUri, String uploadType) {
        Log.d("UploadPhotoTask", "====>>>imageUri     : " + imageUri + "====>>>   Type :::::: " + uploadType);
        if (UPLOAD_TYPE_FATHER.equals(uploadType)) {
            // Load the image using Glide
            Glide.with(this)
                    .load(imageUri.getPath())
                    .centerCrop()
                    .into(binding.fatherPhoto);

            binding.fatherPhoto.setVisibility(View.VISIBLE);
            binding.fatherPlaceholder.setVisibility(View.GONE);
        } else if (UPLOAD_TYPE_MOTHER.equals(uploadType)) {
            // Load the image using Glide
            Glide.with(this)
                    .load(imageUri.getPath())
                    .centerCrop()
                    .into(binding.motherPhoto);

            binding.motherPhoto.setVisibility(View.VISIBLE);
            binding.motherPlaceholder.setVisibility(View.GONE);
        }
    }

    @SuppressWarnings("unchecked")
    private void generateFaceSwap() {
        Log.d("BabyBoy", "Generate face swap button clicked");
        StartActivityGlobally.navigateToActivityWithFeature(
                requireActivity(),
                CommonProcessing.class,
                new Pair<>(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_BABY_BOY)
        );
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}