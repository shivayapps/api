package com.explorefile.filemanager.helpers

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import com.google.common.reflect.TypeToken
import com.google.gson.Gson
import java.lang.reflect.Type

class Preferences(val context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("aapthi_file_manager", Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = sharedPreferences.edit()

    fun setBoolean(key: String, result: Boolean) {
        editor.putBoolean(key, result)
        editor.apply()
    }

    fun getBoolean(key: String, default: Boolean? = false): Boolean {
        return sharedPreferences.getBoolean(key, default!!)
    }

    var enableFingerprint: Boolean
        get() = sharedPreferences.getBoolean("USE_FINGERPRINT", false)
        set(enableFingerprint) = sharedPreferences.edit()
            .putBoolean("USE_FINGERPRINT", enableFingerprint).apply()

    fun putPattern(result: String) {
        editor.putString(PREF_KEY_PATTERN, result)
        editor.apply()
    }

    fun getPattern(): String? {
        return sharedPreferences.getString(PREF_KEY_PATTERN, "")
    }

    fun putSetQuestion(result: Boolean) {
        editor.putBoolean(PREF_KEY_SECURITY_SET, result)
        editor.apply()
    }

    fun getSetQuestion(): Boolean {
        return sharedPreferences.getBoolean(PREF_KEY_SECURITY_SET, false)
    }

    fun putSetPattern(result: Boolean) {
        editor.putBoolean(PREF_KEY_PATTERN_SET, result)
        editor.apply()
    }

    fun putPass(result: String) {
        editor.putString(PREF_KEY_PASSCODE, result)
        editor.apply()
    }

    fun getPass(): String? {
        return sharedPreferences.getString(PREF_KEY_PASSCODE, "")
    }

    fun putSetPass(result: Boolean) {
        editor.putBoolean("passcode_set", result)
        editor.apply()
    }

    fun getSetPass(): Boolean {
        return sharedPreferences.getBoolean("passcode_set", false)
    }

    fun getSetPattern(): Boolean {
        return sharedPreferences.getBoolean(PREF_KEY_PATTERN_SET, false)
    }

    fun putAnswerQuestion(result: String) {
        editor.putString(PREF_KEY_SECURITY_ANS, result)
        editor.apply()
    }

    fun getAnswerQuestion(): String? {
        return sharedPreferences.getString(PREF_KEY_SECURITY_ANS, "")
    }

    fun putSecurityQuestion(result: Int) {
        editor.putInt(PREF_KEY_SECURITY_QUESTION, result)
        editor.apply()
    }

    fun getSecurityQuestion(): Int {
        return sharedPreferences.getInt(PREF_KEY_SECURITY_QUESTION, 0)
    }

    fun putShowPinLock(result: Boolean) {
        editor.putBoolean(PREF_KEY_LOCK_STYLE, result)
        editor.apply()
    }

    fun getShowPINLock(): Boolean {
        return sharedPreferences.getBoolean(PREF_KEY_LOCK_STYLE, true)
    }

}