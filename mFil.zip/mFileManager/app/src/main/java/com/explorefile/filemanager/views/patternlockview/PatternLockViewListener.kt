package com.explorefile.filemanager.views.patternlockview


interface PatternLockViewListener {
    fun onStarted()

    fun onProgress(progressPattern: List<PatternLockView.Dot>)

    fun onComplete(pattern: List<PatternLockView.Dot>)

    fun onCleared()
}