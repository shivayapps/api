package com.explorefile.filemanager.extensions

import android.app.Activity
import com.explorefile.filemanager.R

fun Activity.getThemeId(showTransparentTop: Boolean = false) = when {
    isBlackAndWhiteTheme() -> when {
        showTransparentTop -> R.style.AppTheme_BlackAndWhite_NoActionBar
        else -> R.style.AppTheme_BlackAndWhite
    }
    isWhiteTheme() -> when {
        showTransparentTop -> R.style.AppTheme_White_NoActionBar
        else -> R.style.AppTheme_White
    }
   
    else -> R.style.AppTheme_White
}
