package com.explorefile.filemanager

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.WelcomeBackActivity
import com.explorefile.filemanager.activities.SplashActivity
import com.explorefile.filemanager.database.DatabaseProvider
import com.explorefile.filemanager.models.ListItem
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.tans.tuiutils.systembar.AutoApplySystemBarAnnotation
import com.tfiletransporter.Settings


class App : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {
    companion object {
        var displayListItem: ArrayList<ListItem> = ArrayList()
        lateinit var appContext: Context
        var isOpenAdHide = false

        fun disabledOpenAds() {
            isOpenAdHide = true
        }

        fun enabledOpenAds() {
            Handler(Looper.getMainLooper()).postDelayed({ isOpenAdHide = false }, 500)
        }
    }

    override fun onCreate() {
        super.onCreate()
        DatabaseProvider.init(this)
        appContext = applicationContext

        AutoApplySystemBarAnnotation.init(this)
        Settings.init(this)

        val openAdId = getString(R.string.open_all)
        AdsConfig.builder()
            .setTestDeviceId("")
            .setAdmobAppOpenId(openAdId)
            .build(this)
        setAppLifecycleListener(this)
        initMobileAds()
        fireBaseConfigGet()
//        OpenAdHelper.loadOpenAd(this) { null }
    }

    private fun fireBaseConfigGet() {
        try {
            val mFirebaseRemoteConfig: FirebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
            mFirebaseRemoteConfig.reset()
            //Setting Developer Mode enabled to fast retrieve the values
            mFirebaseRemoteConfig.setConfigSettingsAsync(
                FirebaseRemoteConfigSettings.Builder()
                    .setMinimumFetchIntervalInSeconds(5)
                    .build()
            )
            mFirebaseRemoteConfig.setDefaultsAsync(R.xml.remote_confing_defaults)
            mFirebaseRemoteConfig.fetchAndActivate()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.e("fireBaseConfigGet", "isSuccessful")
                        mFirebaseRemoteConfig.activate()

                    } else {
                        Log.e("fireBaseConfigGet", "taskFailed")
                    }
                }
        } catch (e: Exception) {
            Log.e("fireBaseConfigGet", "Exception:$e")
            e.printStackTrace()
        }
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (fCurrentActivity is SplashActivity) return false
        else if (isOpenAdHide) {
            enabledOpenAds()
            return false
        }
        return true
    }

    override fun onActivityCreated(fCurrentActivity: Activity, savedInstanceState: Bundle?) {

    }

    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity)) {
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
                if (OpenAdHelper.isAdAvailable()) {
                    val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
                    intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
                    fCurrentActivity.startActivity(intent)
                }
            }
        }
    }

    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {
    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {
    }
}