package com.explorefile.filemanager.dialogs

import android.app.Dialog
import android.content.*
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.DialogAppActionBinding
import com.explorefile.filemanager.extensions.baseConfig
import com.explorefile.filemanager.extensions.getAlertDialogBuilder
import com.explorefile.filemanager.extensions.setupDialogStuff
import com.explorefile.filemanager.helpers.CreateShortcutTool
import com.explorefile.filemanager.models.AppInfo
import com.explorefile.filemanager.views.LinearRadioGroup

class AppActionDialog(
    private val activity: BaseActivity,
    private val appInfo: AppInfo,
    private val appType: String = "",
) {

    private val binding: DialogAppActionBinding =
        DialogAppActionBinding.inflate((activity as android.app.Activity).layoutInflater)

    init {
        activity.getAlertDialogBuilder()
            .apply {
                activity.setupDialogStuff(binding.root, this) { alertDialog ->
                    binding.dialogButtonClose.setOnClickListener {
                        alertDialog.dismiss()
                    }
                    binding.dialogButtonOk.setOnClickListener {
                        handleAction(alertDialog)
                        alertDialog.dismiss()
                    }
                }
            }

        setupUI()
        setupActions()
        unSelectAll()
    }

    private fun setupUI() {
        val tint=activity.baseConfig.textColor
        binding.iconUninstall.imageTintList= ColorStateList.valueOf(tint)
        binding.iconDetail.imageTintList= ColorStateList.valueOf(tint)
        binding.iconLaunch.imageTintList= ColorStateList.valueOf(tint)
        binding.iconShortcut.imageTintList= ColorStateList.valueOf(tint)
        binding.iconPlayStore.imageTintList= ColorStateList.valueOf(tint)

        binding.txtTitle.text = appInfo.appName

        // Load app icon with Glide or fallback
        try {
            if (appInfo.appDrawableURI != Uri.EMPTY) {
                Glide.with(activity)
                    .load(appInfo.appDrawableURI)
                    .into(binding.imageIcon)
            } else {
                binding.imageIcon.setImageDrawable(
                    ContextCompat.getDrawable(activity, R.drawable.ic_apk)
                )
            }
        } catch (e: Exception) {
            binding.imageIcon.setImageDrawable(
                ContextCompat.getDrawable(activity, R.drawable.ic_apk)
            )
        }

        // Hide uninstall for system apps
        if (appType == "system") {
            binding.llUninstall.visibility = View.GONE
            //binding.llRadio.check(R.id.rb_launch)
        }

//        // Hide shortcut option for Android below O
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            binding.llShortcut.visibility = View.GONE
        }

//
//        // Button shadow styling
//        arrayOf(
//            binding.rbUninstall, binding.rbLaunch, binding.rbDetail,
//            binding.rbPlaystore, binding.rbShortcut
//        ).forEach {
//            it.setShadowLayer(1.5f, -1f, 1f, Color.WHITE)
//        }

//        dialog.setOnDismissListener { callback() }

        // Handle Cancel / OK actions
//        binding.dialogButtonClose.setOnClickListener { dialog.dismiss() }
//        binding.dialogButtonOk.setOnClickListener {
//            handleAction(this)
//        }

//        dialog.show()
    }

    var selectedAction=0

    private fun unSelectAll() {
        binding.checkUninstall.setImageResource(R.drawable.ic_checkbox_unchecked)
        binding.checkLaunch.setImageResource(R.drawable.ic_checkbox_unchecked)
        binding.checkDetail.setImageResource(R.drawable.ic_checkbox_unchecked)
        binding.checkPlayStore.setImageResource(R.drawable.ic_checkbox_unchecked)
        binding.checkShortcut.setImageResource(R.drawable.ic_checkbox_unchecked)
    }
    private fun setupActions() {

        binding.llUninstall.setOnClickListener {
            selectedAction=1
            unSelectAll()
            binding.checkUninstall.setImageResource(R.drawable.ic_checkbox_checked)
        }

        binding.llLaunch.setOnClickListener {
            selectedAction=2
            unSelectAll()
            binding.checkLaunch.setImageResource(R.drawable.ic_checkbox_checked)
        }
        binding.llDetail.setOnClickListener {
            selectedAction=3
            unSelectAll()
            binding.checkDetail.setImageResource(R.drawable.ic_checkbox_checked)
        }
        binding.llPlayStore.setOnClickListener {
            selectedAction=4
            unSelectAll()
            binding.checkPlayStore.setImageResource(R.drawable.ic_checkbox_checked)
        }
        binding.llShortcut.setOnClickListener {
            selectedAction=5
            unSelectAll()
            binding.checkShortcut.setImageResource(R.drawable.ic_checkbox_checked)
        }
    }

    private fun handleAction(dialog: Dialog) {
        when (selectedAction) {
            1 -> {
                dialog.dismiss()
//                val uri = Uri.parse("package:${appInfo.appPackage}")
//                val intent = Intent(Intent.ACTION_UNINSTALL_PACKAGE, uri)
//                (activity as? android.app.Activity)?.startActivityForResult(intent, 112)
                try {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.parse("package:${appInfo.appPackage}")
                    }
                    if (intent != null) {
                        activity.startActivity(intent)
                        Toast.makeText(activity,"Select Uninstall", Toast.LENGTH_SHORT).show()
                    }
                    else Log.d("AppActionDialog", "Launch intent not found")
                } catch (e: Exception) {
                    Log.d("AppActionDialog", "Launch failed: ${e.message}")
                }
            }

            2 -> {
                dialog.dismiss()
                try {
                    val intent =
                        activity.packageManager.getLaunchIntentForPackage(appInfo.appPackage!!)
                    if (intent != null) activity.startActivity(intent)
                    else Log.d("AppActionDialog", "Launch intent not found")
                } catch (e: Exception) {
                    Log.d("AppActionDialog", "Launch failed: ${e.message}")
                }
            }

            3 -> {
                dialog.dismiss()
                try {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.parse("package:${appInfo.appPackage}")
                    }
                    activity.startActivity(intent)
                } catch (e: ActivityNotFoundException) {
                    activity.startActivity(Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS))
                }
            }

            4 -> {
                dialog.dismiss()
                try {
                    val marketUri = Uri.parse("market://details?id=${appInfo.appPackage}")
                    activity.startActivity(Intent(Intent.ACTION_VIEW, marketUri))
                } catch (e: ActivityNotFoundException) {
                    val marketUri =
                        Uri.parse("https://play.google.com/store/apps/details?id=${appInfo.appPackage}")
                    activity.startActivity(Intent(Intent.ACTION_VIEW, marketUri))
                }
            }

            5 -> {
                dialog.dismiss()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    CreateShortcutTool.createHomeScreenShortcutNew(activity, appInfo.appPackage!!)
                } else {
                    Toast.makeText(
                        activity,
                        activity.getString(R.string.shortcut_can_only_be_pinned_on_oreo_and_above),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }
}
