package com.explorefile.filemanager.helpers

import android.annotation.SuppressLint
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.UserHandle
import android.os.storage.StorageManager
import androidx.annotation.Keep
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import com.explorefile.filemanager.R
import com.explorefile.filemanager.models.AppInfo
import java.io.File
import java.text.SimpleDateFormat
import java.util.*


/**
 * Created by Mahendra Gohil on 07-12-2021.
 * Apk Info Extractor
 */

@Keep
class ApkInformationExtractor(private val mContext: Context) {

//    fun appManagerInitValues(): AppManager {
//        val ob = AppManager()
//
//        val intent = Intent(Intent.ACTION_MAIN, null)
//
//        intent.addCategory(Intent.CATEGORY_LAUNCHER)
//
//        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
//
//        val resolveInfoList = mContext.packageManager.queryIntentActivities(intent, 0)
//
//        for (resolveInfo in resolveInfoList) {
//
//            val activityInfo = resolveInfo.activityInfo
//
//            if (!isSystemPackage(resolveInfo)) {
//
//                ob.userAppSize = ob.userAppSize + 1
//                val appPackageName = activityInfo.applicationInfo.packageName.toString()
//                if (!appPackageName.equals("com.file.filemanager", true)) {
//                    ob.userApps.add(
//                        AppInfo(
//                            getAppName(appPackageName),
//                            appPackageName,
//                            getFirstInstalledDate(appPackageName),
//                            getLastUpdatedDate(appPackageName),
//                            getAppVersion(appPackageName),
//                            getAppIconURIByPackageName(appPackageName),
//                            getPublicSourceDir(appPackageName),
//                            getAppSize(appPackageName),
//                            getAppUsageTime(appPackageName)
//                        )
//                    )
//
//                    ob.userApps.sortWith { o1, o2 ->
//                        o1.appName!!.compareTo(
//                            o2.appName!!,
//                            ignoreCase = true
//                        )
//                    }
//                }
//
//            } else if (isSystemPackage(resolveInfo)) {
//                ob.systemAppSize = ob.systemAppSize + 1
//                val appPackageName = activityInfo.applicationInfo.packageName.toString()
//
//                if (!appPackageName.equals("com.file.filemanager", true)) {
//                    ob.systemApps.add(
//                        AppInfo(
//                            getAppName(appPackageName),
//                            appPackageName,
//                            getFirstInstalledDate(appPackageName),
//                            getLastUpdatedDate(appPackageName),
//                            getAppVersion(appPackageName),
//                            getAppIconURIByPackageName(appPackageName),
//                            getPublicSourceDir(appPackageName),
//                            getAppSize(appPackageName),
//                            getAppUsageTime(appPackageName)
//                        )
//                    )
//
//                    ob.systemApps.sortWith { o1, o2 ->
//                        o1.appName!!.compareTo(
//                            o2.appName!!,
//                            ignoreCase = true
//                        )
//                    }
//                }
//            }
//        }
//        return ob
//    }


    fun appManagerInitValues(): AppManager {
        val ob = AppManager()

        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolveInfoList = mContext.packageManager.queryIntentActivities(intent, 0)

        val usageMap = getUsageMap()

        for (resolveInfo in resolveInfoList) {
            val appInfo = resolveInfo.activityInfo.applicationInfo
            val pkg = appInfo.packageName

            if (pkg.equals("com.file.filemanager", true)) continue

            val isSystem = isSystemPackage(resolveInfo)

            val info = AppInfo(
                getAppName(pkg),
                pkg,
                getFirstInstalledDate(pkg),
                getLastUpdatedDate(pkg),
                getAppVersion(pkg),
                getAppIconURIByPackageName(pkg),
                getPublicSourceDir(pkg),
                getAppSize(pkg),
                usageMap[pkg] ?: 0L
            )

            if (isSystem) {
                ob.systemApps.add(info)
            } else {
                ob.userApps.add(info)
            }
        }

        // 🔥 SORT ONLY ONCE
        ob.userApps.sortBy { it.appName?.lowercase() }
        ob.systemApps.sortBy { it.appName?.lowercase() }

        ob.userAppSize = ob.userApps.size
        ob.systemAppSize = ob.systemApps.size

        return ob
    }
    private fun getUsageMap(days: Int = 7): Map<String, Long> {
        return try {
            val usm = mContext.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis()
            val start = end - days * 24 * 60 * 60 * 1000L

            usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
                .associate { it.packageName to it.totalTimeInForeground }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun getAppUsageTime(packageName: String, days: Int = 7): Long {
        return try {
            val usageStatsManager =
                mContext.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val endTime = System.currentTimeMillis()
            val startTime = endTime - days * 24 * 60 * 60 * 1000L

            val usageStatsList: List<UsageStats> = usageStatsManager.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY, startTime, endTime
            )

            usageStatsList
                .firstOrNull { it.packageName == packageName }
                ?.totalTimeInForeground ?: 0L
        } catch (e: Exception) {
            0L
        }
    }

    fun getAllUserAppPackage(): List<String> {
        val apkPackageName = ArrayList<String>()

        val intent = Intent(Intent.ACTION_MAIN, null)

        intent.addCategory(Intent.CATEGORY_LAUNCHER)

        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED

        val resolveInfoList = mContext.packageManager.queryIntentActivities(intent, 0)

        for (resolveInfo in resolveInfoList) {

            val activityInfo = resolveInfo.activityInfo

            if (!isSystemPackage(resolveInfo)) apkPackageName.add(activityInfo.applicationInfo.packageName)
        }
        return apkPackageName
    }

    fun getAllSystemAppPackage(): List<String> {
        val apkPackageName = ArrayList<String>()

        val intent = Intent(Intent.ACTION_MAIN, null)

        intent.addCategory(Intent.CATEGORY_LAUNCHER)

        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED

        val resolveInfoList = mContext.packageManager.queryIntentActivities(intent, 0)

        for (resolveInfo in resolveInfoList) {

            val activityInfo = resolveInfo.activityInfo

            if (isSystemPackage(resolveInfo))
                apkPackageName.add(activityInfo.applicationInfo.packageName)

        }
        return apkPackageName
    }

    //Returns App Name
    fun getAllInstalledApkInfoAppName(): List<String> {
        val apkName = ArrayList<String>()

        val intent = Intent(Intent.ACTION_MAIN, null)

        intent.addCategory(Intent.CATEGORY_LAUNCHER)

        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED

        val resolveInfoList = mContext.packageManager.queryIntentActivities(intent, 0)

        for (resolveInfo in resolveInfoList) {

            val activityInfo = resolveInfo.activityInfo

            if (!isSystemPackage(resolveInfo)) {
                apkName.add(getAppName(activityInfo.applicationInfo.packageName))
            }
        }
        return apkName
    }

    private fun isSystemPackage(resolveInfo: ResolveInfo): Boolean {
        return resolveInfo.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM != 0
    }

    fun getAppIconDrawableByPackageName(ApkTempPackageName: String): Drawable? {
        val drawable: Drawable? = try {
            mContext.packageManager.getApplicationIcon(ApkTempPackageName)
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
            ContextCompat.getDrawable(mContext, R.mipmap.ic_launcher)
        }
        return drawable
    }

    fun getAppIconByPackageName(ApkTempPackageName: String): Int {
        var icon = 0
        try {
            val pm = mContext.packageManager
            val appInfo = pm.getApplicationInfo(ApkTempPackageName, 0)

            if (appInfo.icon != 0) {
                icon = appInfo.icon
            }

        } catch (e: PackageManager.NameNotFoundException) {
            icon = 0
            e.printStackTrace()
        }

        return icon
    }

    private fun getPublicSourceDir(packageName: String?): String {
        try {
            return mContext.packageManager.getApplicationInfo(packageName!!, 0).publicSourceDir
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }
        return ""
    }

    private fun getAppSize(packageName: String?): Double {


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            var sizeBytes = 0L

            try {
                val packageManager = mContext.packageManager
                val storageStatsManager =
                    mContext.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager

                val appInfo = packageManager.getApplicationInfo(packageName!!, 0)
                val user: UserHandle = UserHandle.getUserHandleForUid(appInfo.uid)

                // Default storage UUID
                val uuid = android.os.storage.StorageManager.UUID_DEFAULT

                val stats = storageStatsManager.queryStatsForPackage(uuid, packageName!!, user)
                sizeBytes = stats.cacheBytes + stats.dataBytes + stats.appBytes

            } catch (e: PackageManager.NameNotFoundException) {
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // Convert bytes to MB
            return sizeBytes.toDouble() / (1024.0 * 1024.0)
        } else {
            var size = 0.0
            try {
                val file: File = File(
                    mContext.packageManager.getApplicationInfo(
                        packageName!!,
                        0
                    ).publicSourceDir
                )
                size = file.length().toDouble()
            } catch (e: PackageManager.NameNotFoundException) {
                e.printStackTrace()
            }
            size /= 1000000.0
            return size
        }
    }

    private fun getAppIconURIByPackageName(ApkTempPackageName: String): Uri {
        var resUri = Uri.EMPTY
        try {
            val pm = mContext.packageManager
            val appInfo = pm.getApplicationInfo(ApkTempPackageName, 0)

            if (appInfo.icon != 0) {
                resUri = Uri.parse("android.resource://" + ApkTempPackageName + "/" + appInfo.icon)
            }

        } catch (e: PackageManager.NameNotFoundException) {
            resUri = Uri.EMPTY
            e.printStackTrace()
        }

        return resUri
    }

    private fun getAppName(ApkPackageName: String): String {
        var name = " "

        val applicationInfo: ApplicationInfo?

        val packageManager = mContext.packageManager

        try {
            applicationInfo = packageManager.getApplicationInfo(ApkPackageName, 0)
            name = packageManager.getApplicationLabel(applicationInfo) as String
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }

        return name
    }

    public fun isPackageInstalled(packageName: String): Boolean {
        val packageManager = mContext.packageManager
        return try {
            packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun getAppVersion(ApkPackageName: String): String {
        var versionName = ""
        val applicationInfo: ApplicationInfo?
        val packageManager = mContext.packageManager
        try {
            applicationInfo = packageManager.getApplicationInfo(ApkPackageName, 0)
            versionName = packageManager.getPackageInfo(ApkPackageName, 0).versionName ?: ""
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }
        return "v$versionName"
    }

    private fun getFirstInstalledDate(ApkPackageName: String): String {
        var firstInstalled = "-"
        val manager = mContext.packageManager

        try {
            val info = manager.getPackageInfo(ApkPackageName, 0)
            if (info != null) {

                val temp = info.firstInstallTime
                firstInstalled = "" + getDate(temp)
            }
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }

        return firstInstalled
    }

    private fun getLastUpdatedDate(ApkPackageName: String): String {
        var lastUpdated = "-"
        val manager = mContext.packageManager

        try {
            val info = manager.getPackageInfo(ApkPackageName, 0)
            if (info != null) {
                val temp = info.lastUpdateTime
                lastUpdated = "" + getDate(temp)
            }
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }

        return lastUpdated
    }

    @SuppressLint("SimpleDateFormat")
    private fun getDate(milliSeconds: Long): String {
        val formatter = SimpleDateFormat("EEE-MMM dd,yyyy")
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = milliSeconds
        return formatter.format(calendar.time)
    }

}