/*
 * SkyTube
 * Copyright (C) 2017  Ramon Mifsud
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation (version 3 of the License).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.tubeplayer.tube.gui.businessobjects.fragments;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import butterknife.BindView;
import butterknife.ButterKnife;
import com.tubeplayer.tube.R;
import com.tubeplayer.tube.businessobjects.db.PlaybackStatusDb;
import com.tubeplayer.tube.gui.businessobjects.adapters.VideoGridAdapter;
import com.tubeplayer.tube.gui.fragments.VideosGridFragment;

/**
 * A class that supports swipe-to-refresh on {@link VideosGridFragment}.
 */
public abstract class BaseVideosGridFragment extends TabFragment implements SwipeRefreshLayout.OnRefreshListener {

	protected final VideoGridAdapter  videoGridAdapter;
	private int updateCount = 0;

	@BindView(R.id.swipeRefreshLayout)
	protected SwipeRefreshLayout swipeRefreshLayout;

	public BaseVideosGridFragment(VideoGridAdapter videoGrid) {
		this.videoGridAdapter = videoGrid;
	}

	@Nullable
	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		videoGridAdapter.setContext(getActivity());

		View view = inflater.inflate(getLayoutResource(), container, false);

		ButterKnife.bind(this, view);
		swipeRefreshLayout.setOnRefreshListener(this);

		return view;
	}


	@Override
	public void onRefresh() {
		videoGridAdapter.refresh(true);
		updateCount = PlaybackStatusDb.getPlaybackStatusDb().getUpdateCounter();
	}

	/**
	 * If the PlaybackStatusDb has been updated (due to clearing or disabling it), refresh the entire VideoGrid.
	 */
	@Override
	public void onResume() {
		super.onResume();
		int newUpdateCounter = PlaybackStatusDb.getPlaybackStatusDb().getUpdateCounter();
		if(newUpdateCounter != updateCount) {
			videoGridAdapter.notifyDataSetChanged();
			updateCount = newUpdateCounter;
		}
	}

	@Override
	public void onFragmentSelected() {
		super.onFragmentSelected();
		videoGridAdapter.initializeList();
	}

	/**
	 * Set the layout resource (e.g. Subscriptions resource layout, R.id.grid_view, ...etc).
	 */
	protected  abstract int getLayoutResource();

}
