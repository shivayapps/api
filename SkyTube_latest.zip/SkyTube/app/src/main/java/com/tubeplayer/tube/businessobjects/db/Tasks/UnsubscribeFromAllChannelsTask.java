package com.tubeplayer.tube.businessobjects.db.Tasks;

import android.os.Handler;

import java.util.List;

import com.tubeplayer.tube.app.SkyTubeApp;
import com.tubeplayer.tube.businessobjects.AsyncTaskParallel;
import com.tubeplayer.tube.businessobjects.YouTube.POJOs.YouTubeChannel;
import com.tubeplayer.tube.businessobjects.db.SubscriptionsDb;
import com.tubeplayer.tube.gui.businessobjects.adapters.SubsAdapter;

/**
 * An Asynctask class that unsubscribes user from all the channels at once.
 */
public class UnsubscribeFromAllChannelsTask extends AsyncTaskParallel<YouTubeChannel, Void, Void> {

	private Handler handler = new Handler();

	@Override
	protected Void doInBackground(YouTubeChannel... youTubeChannels) {
		List<String> channelList = SubscriptionsDb.getSubscriptionsDb().getSubscribedChannelIds();

		for (final String channelId : channelList) {
			SubscriptionsDb.getSubscriptionsDb().unsubscribe(channelId);

			handler.post(() -> SubsAdapter.get(SkyTubeApp.getContext()).removeChannel(channelId));
		}

		return null;
	}

}
