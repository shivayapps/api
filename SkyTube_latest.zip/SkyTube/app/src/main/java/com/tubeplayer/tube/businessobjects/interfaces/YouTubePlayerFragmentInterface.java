package com.tubeplayer.tube.businessobjects.interfaces;

import com.tubeplayer.tube.businessobjects.YouTube.POJOs.YouTubeVideo;

/**
 * Interface used by {@link com.tubeplayer.tube.gui.fragments.YouTubePlayerV1Fragment} & {@link com.tubeplayer.tube.gui.fragments.YouTubePlayerV2Fragment}
 * Also, when a video is playing on a Chromecast, and the user disconnects from the Chromecast, that video will begin playing on the device.
 */

public interface YouTubePlayerFragmentInterface {
	void videoPlaybackStopped();

	/**
	 * Return the video being played in this fragment
	 * @return {@link YouTubeVideo}
	 */
	YouTubeVideo getYouTubeVideo();

	/**
	 * Return the current video position.
	 * @return
	 */
	int getCurrentVideoPosition();

	/**
	 * Pause the currently playing video.
	 */
	void pause();
}
