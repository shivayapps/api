package com.tubeplayer.tube.gui.businessobjects;


import com.tubeplayer.tube.businessobjects.YouTube.POJOs.YouTubePlaylist;

/**
 * An interface to return a YouTube Playlist
 */
public interface YouTubePlaylistListener {
	void onYouTubePlaylist(YouTubePlaylist playlist);

}
