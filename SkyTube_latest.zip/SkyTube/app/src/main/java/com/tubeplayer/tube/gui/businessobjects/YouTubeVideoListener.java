package com.tubeplayer.tube.gui.businessobjects;


import com.tubeplayer.tube.businessobjects.YouTube.POJOs.YouTubeVideo;
import com.tubeplayer.tube.businessobjects.YouTube.newpipe.ContentId;

/**
 * Interface to return a YouTubeVideo via an url to the video. Returns the url as well as the video, if one was found.
 */
public interface YouTubeVideoListener {
	void onYouTubeVideo(ContentId videoUrl, YouTubeVideo video);
}
