package com.tubeplayer.tube.businessobjects.interfaces;

import android.view.Menu;

/**
 * In order for the Cast icon to be shown in the menu bar while playing a video, BaseActivity will have to be notified
 * that the options menu has been created. This interface will allow {@link com.tubeplayer.tube.gui.fragments.YouTubePlayerV1Fragment}
 * and {@link com.tubeplayer.tube.gui.fragments.YouTubePlayerV2Fragment} to do that notification.
 */
public interface YouTubePlayerActivityListener {
	void onOptionsMenuCreated(Menu menu);
}
