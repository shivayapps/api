package com.tubeplayer.tube.gui.businessobjects.adapters;

import java.util.List;

import com.tubeplayer.tube.businessobjects.AsyncTaskParallel;
import com.tubeplayer.tube.businessobjects.YouTube.POJOs.YouTubeCommentThread;

public class NewPipeCommentsTask extends AsyncTaskParallel<Void, Void, List<YouTubeCommentThread>> {

    private String nextPageUrl;
    private boolean hasNextPage = true;

    @Override
    protected List<YouTubeCommentThread> doInBackground(Void... voids) {
        return null;
    }
}
