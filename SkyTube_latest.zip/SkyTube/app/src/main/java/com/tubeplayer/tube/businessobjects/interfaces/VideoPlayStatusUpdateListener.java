package com.tubeplayer.tube.businessobjects.interfaces;

/**
 * Interface that is used to alert {@link com.tubeplayer.tube.gui.businessobjects.adapters.VideoGridAdapter} that a video's playback status
 * has been updated. This is needed in order to set the watch status after a video has been viewed via Chromecast. Since previously, this was
 * happening in MainActivity's onResume, when playing a video through Chromecast, this onResume method is never called, since the Activity
 * is never left.
 */
public interface VideoPlayStatusUpdateListener {
	void onVideoStatusUpdated();
}
