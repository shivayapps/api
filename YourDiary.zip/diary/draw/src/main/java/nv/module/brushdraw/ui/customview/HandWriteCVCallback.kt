package nv.module.brushdraw.ui.customview

interface HandWriteCVCallback {
    fun onUndo(b:Boolean)
    fun onRedo(b:Boolean)
}