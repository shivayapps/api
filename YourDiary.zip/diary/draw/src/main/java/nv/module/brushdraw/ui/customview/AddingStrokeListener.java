package nv.module.brushdraw.ui.customview;

public interface AddingStrokeListener {
    void onStrokeAddListener();
}