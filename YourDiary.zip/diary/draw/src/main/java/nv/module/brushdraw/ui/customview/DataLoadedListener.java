package nv.module.brushdraw.ui.customview;

public interface DataLoadedListener {
    void onDataLoaded();
}