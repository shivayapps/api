package com.test.dialognew

import android.view.View
import kotlinx.android.synthetic.main.dialog_rate.view.*

object RateUtil {
     internal fun star1(view: View){
        view.ivStar1.setImageResource(R.drawable.ic_star_up2)
        view.ivStar2.setImageResource(R.drawable.ic_un_star_up)
        view.ivStar3.setImageResource(R.drawable.ic_un_star_up)
        view.ivStar4.setImageResource(R.drawable.ic_un_star_up)
        view.ivStar5.setImageResource(R.drawable.ic_un_star_up)
    }
    internal fun star2(view: View){
        view.ivStar1.setImageResource(R.drawable.ic_star_up2)
        view.ivStar2.setImageResource(R.drawable.ic_star_up2)
        view.ivStar3.setImageResource(R.drawable.ic_un_star_up)
        view.ivStar4.setImageResource(R.drawable.ic_un_star_up)
        view.ivStar5.setImageResource(R.drawable.ic_un_star_up)
    }
    internal fun star3(view: View){
        view.ivStar1.setImageResource(R.drawable.ic_star_up2)
        view.ivStar2.setImageResource(R.drawable.ic_star_up2)
        view.ivStar3.setImageResource(R.drawable.ic_star_up2)
        view.ivStar4.setImageResource(R.drawable.ic_un_star_up)
        view.ivStar5.setImageResource(R.drawable.ic_un_star_up)
    }
    internal fun star4(view: View){
        view.ivStar1.setImageResource(R.drawable.ic_star_up2)
        view.ivStar2.setImageResource(R.drawable.ic_star_up2)
        view.ivStar3.setImageResource(R.drawable.ic_star_up2)
        view.ivStar4.setImageResource(R.drawable.ic_star_up2)
        view.ivStar5.setImageResource(R.drawable.ic_un_star_up)
    }
    internal fun star5(view: View){
        view.ivStar1.setImageResource(R.drawable.ic_star_up2)
        view.ivStar2.setImageResource(R.drawable.ic_star_up2)
        view.ivStar3.setImageResource(R.drawable.ic_star_up2)
        view.ivStar4.setImageResource(R.drawable.ic_star_up2)
        view.ivStar5.setImageResource(R.drawable.ic_star_up2)
    }
}