package com.test.dialognew

public interface DialogNewInterface {
    fun onClickStar(rate: Int)
    fun onRate(rate: Int)

    fun onFB(choice: Int)

    fun onCancel()

    fun onCancelFb()
}