package com.test.dialognew

interface RateCallback {

    fun onFBShow()

}