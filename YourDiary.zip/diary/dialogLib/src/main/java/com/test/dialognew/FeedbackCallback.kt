package com.test.dialognew

interface FeedbackCallback {
    fun onFeedback()
}