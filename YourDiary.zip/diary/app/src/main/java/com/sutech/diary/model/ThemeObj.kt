package com.sutech.diary.model

import com.sutech.journal.diary.diarywriting.lockdiary.R

data class ThemeObj(
    var textColor: Int,
    var imageResource: Int = R.drawable.default_background
)