package com.sutech.diary.model

data class Hashtag(
    var content: String = "",
)