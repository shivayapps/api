package com.sutech.diary.model

data class HashtagQuantity(val hashtag: String, val quantity: Int)
