package com.sutech.diary.model

data class MoodObj(val id: Int, val name: String, val imageResource: Int)
