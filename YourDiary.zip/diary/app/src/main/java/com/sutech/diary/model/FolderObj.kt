package com.sutech.diary.model

data class FolderObj(
    val id: Long,
    val name: String,
    var size: Long =0
)
