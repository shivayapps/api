package com.sutech.diary

import android.app.Application
import androidx.multidex.MultiDexApplication

class DiaryApplication : MultiDexApplication(){
    companion object{
        var interCount = 0;
    }
    override fun onCreate() {
        super.onCreate()
    }
}