package com.explorefile.filemanager.fragments

import android.content.Context
import android.util.AttributeSet
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.MainShareFragmentBinding
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.updateTextColors
import java.text.DecimalFormat

class ShareFragment(context: Context, attributeSet: AttributeSet) :
    MyViewPagerFragment<MyViewPagerFragment.ShareInnerBinding>(context, attributeSet){


    lateinit var binding: MainShareFragmentBinding

    override fun onFinishInflate() {
        super.onFinishInflate()
        binding = MainShareFragmentBinding.bind(this)
        innerBinding = ShareInnerBinding(binding)
    }

    override fun setupFragment(activity: BaseActivity) {
        if (this.activity == null) {
            this.activity = activity
        }
    }

    override fun setupCategoriesBinding(activity: BaseActivity) {

    }

    override fun onResume(textColor: Int) {
        context.updateTextColors(binding.root)
        val properPrimaryColor = context.getProperPrimaryColor()

    }

    override fun refreshFragment() {

    }



}