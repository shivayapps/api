package com.explorefile.filemanager.activities

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType

import com.explorefile.filemanager.App
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.ActivityLanguageBinding
import com.explorefile.filemanager.extensions.beGone
import com.explorefile.filemanager.extensions.beVisible
import com.explorefile.filemanager.extensions.config
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.helpers.FIRST_TIME_KEY
import com.explorefile.filemanager.helpers.INTENT_KEY
import com.explorefile.filemanager.helpers.LANGUAGE_KEY
import com.explorefile.filemanager.helpers.LocaleHelper.onAttach
import com.explorefile.filemanager.helpers.LocaleHelper.setLocale

class LanguageActivity : BaseActivity() {
    val binding by viewBinding(ActivityLanguageBinding::inflate)
    private var languageSting = ""
    private var intentValue = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        init()
        clickEvents()
    }

    override fun onBackPressed() {
        if (LANGUAGE_KEY == intentValue) {
            gotoMain()
        } else {
            doneAndNext()
        }
    }

    private fun clickEvents() {
        binding.ivBack.setOnClickListener {
            onBackPressed()
        }
        binding.llEng.setOnClickListener {
            changeIcon(binding.ivEng, "en")
        }
        binding.llGerman.setOnClickListener {
            changeIcon(binding.ivGerman, "de")
        }
        binding.llSpanish.setOnClickListener {
            changeIcon(binding.ivSpanish, "es")
        }
        binding.llFilipino.setOnClickListener {
            changeIcon(binding.ivFilipino, "fil")
        }
        binding.llFrench.setOnClickListener {
            changeIcon(binding.ivFrench, "fr")
        }
        binding.llHindi.setOnClickListener {
            changeIcon(binding.ivHindi, "hi")
        }
        binding.llIndonesian.setOnClickListener {
            changeIcon(binding.ivIndonesian, "in")
        }
        binding.llItalian.setOnClickListener {
            changeIcon(binding.ivItalian, "it")
        }
        binding.llTurkish.setOnClickListener {
            changeIcon(binding.ivTurkish, "tr")
        }
        binding.llChinese.setOnClickListener {
            changeIcon(binding.ivChinese, "zh")
        }
        binding.llArabic.setOnClickListener {
            changeIcon(binding.ivArabic, "ar")
        }
        binding.llRussian.setOnClickListener {
            changeIcon(binding.ivRussian, "ru")
        }
        binding.llJapanese.setOnClickListener {
            changeIcon(binding.ivJapanese, "ja")
        }
        binding.ivDone.setOnClickListener {
            doneAndNext()
        }
    }

    private fun gotoMain(){
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
    private fun doneAndNext(){
        config.isGetStarted = true
        config.languageSting = languageSting
        updateViews(languageSting)
        if (LANGUAGE_KEY == intentValue) {
            onBackPressed()
        } else {
            startActivity(Intent(this, PermissionActivity::class.java))
            finish()
        }
    }

    private fun updateViews(languageCode: String) {
        setLocale(this, languageCode)
    }

    private fun init() {
        intentValue = intent.getStringExtra(INTENT_KEY).toString()
        if (FIRST_TIME_KEY == intentValue) {

            val adId =getString(R.string.native_all)
            NativeAdHelper(this, binding.frameAds, binding.frameAds, NativeLayoutType.NativeBig,adId).loadAd()
            binding.ivBack.beGone()
        }
        binding.tvToolbarText.text = getString(R.string.language)
        binding.ivDone.beVisible()
        languageSting = config.languageSting
        when (languageSting) {
            "en" -> {
                changeIcon(binding.ivEng, languageSting)
            }

            "de" -> {
                changeIcon(binding.ivGerman, languageSting)
            }

            "es" -> {
                changeIcon(binding.ivSpanish, languageSting)
            }

            "fil" -> {
                changeIcon(binding.ivFilipino, languageSting)
            }

            "fr" -> {
                changeIcon(binding.ivFrench, languageSting)
            }

            "hi" -> {
                changeIcon(binding.ivHindi, languageSting)
            }

            "in" -> {
                changeIcon(binding.ivIndonesian, languageSting)
            }

            "it" -> {
                changeIcon(binding.ivItalian, languageSting)
            }

            "tr" -> {
                changeIcon(binding.ivTurkish, languageSting)
            }

            "zh" -> {
                changeIcon(binding.ivChinese, languageSting)
            }

            "ar" -> {
                changeIcon(binding.ivArabic, languageSting)
            }

            "ru" -> {
                changeIcon(binding.ivRussian, languageSting)
            }

            "ja" -> {
                changeIcon(binding.ivJapanese, languageSting)
            }
        }
    }

    private fun changeIcon(selectImage: ImageView, selectValue: String) {
        binding.ivEng.setImageResource(R.drawable.ic_un_check_radio)
        binding.ivSpanish.setImageResource(R.drawable.ic_un_check_radio)
        binding.ivGerman.setImageResource(R.drawable.ic_un_check_radio)
        binding.ivFrench.setImageResource(R.drawable.ic_un_check_radio)
        binding.ivHindi.setImageResource(R.drawable.ic_un_check_radio)
        binding.ivFilipino.setImageResource(R.drawable.ic_un_check_radio)
        binding.ivChinese.setImageResource(R.drawable.ic_un_check_radio)
        binding.ivItalian.setImageResource(R.drawable.ic_un_check_radio)
        binding.ivTurkish.setImageResource(R.drawable.ic_un_check_radio)
        binding.ivIndonesian.setImageResource(R.drawable.ic_un_check_radio)
        binding.ivRussian.setImageResource(R.drawable.ic_un_check_radio)
        binding.ivArabic.setImageResource(R.drawable.ic_un_check_radio)
        binding.ivJapanese.setImageResource(R.drawable.ic_un_check_radio)
        selectImage.setImageResource(R.drawable.ic_check_radio)
        languageSting = selectValue
    }

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(onAttach(base!!, "en"))
    }

    override fun onResume() {
        super.onResume()
        updateStatusbarColor(getProperBackgroundColor())
        setLocale(this, config.languageSting)
        binding.ivBack.setColorFilter(getProperTextColor())
        binding.ivDone.setColorFilter(getProperTextColor())
        binding.tvToolbarText.setTextColor(getProperTextColor())
    }
}