package com.explorefile.filemanager.dialogs

import android.app.Activity
import android.net.Uri
import android.provider.MediaStore
import android.view.View
import android.widget.LinearLayout
import androidx.exifinterface.media.ExifInterface
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.extensions.*
import com.explorefile.filemanager.helpers.*
import com.explorefile.filemanager.views.MyTextView
import java.io.File
import java.util.*

class PropertiesDialog : BasePropertiesDialog {
    private var mCountHiddenItems = false

    constructor(activity: Activity, path: String, countHiddenItems: Boolean = false) : super(
        activity
    ) {
        if (!activity.getDoesFilePathExist(path) && !path.startsWith("content://")) {
            activity.toast(
                String.format(
                    activity.getString(R.string.source_file_doesnt_exist),
                    path
                )
            )
            return
        }

        mCountHiddenItems = countHiddenItems
        addProperties(path)

        val builder = activity.getAlertDialogBuilder()


        builder.apply {
            mActivity.setupDialogStuff(mDialogView.root, this) { alertDialog ->
                mDialogView.txtOk.setOnClickListener {
                    alertDialog.dismiss()
                }
            }
        }
    }

    private fun addProperties(path: String) {
        val fileDirItem = com.explorefile.filemanager.models.FileDirItem(
            path,
            path.getFilenameFromPath(),
            mActivity.getIsPathDirectory(path)
        )

        addProperty(
            R.string.name,
            if (fileDirItem.name.startsWith(".trashed")) fileDirItem.name.substring(
                9,
                fileDirItem.name.length
            ) else fileDirItem.name
        )
        addProperty(R.string.path, fileDirItem.getParentPath())
        addProperty(R.string.size, "…", R.id.properties_size)

        ensureBackgroundThread {
            val fileCount = fileDirItem.getProperFileCount(mActivity, mCountHiddenItems)
            val size = fileDirItem.getProperSize(mActivity, mCountHiddenItems).formatSize()

            val directChildrenCount = if (fileDirItem.isDirectory) {
                fileDirItem.getDirectChildrenCount(mActivity, mCountHiddenItems).toString()
            } else {
                0
            }

            this.mActivity.runOnUiThread {
                (mDialogView.propertiesHolder.findViewById<LinearLayout>(R.id.properties_size)
                    .findViewById<MyTextView>(R.id.property_value)).text = size

                if (fileDirItem.isDirectory) {
                    (mDialogView.propertiesHolder.findViewById<LinearLayout>(R.id.properties_file_count)
                        .findViewById<MyTextView>(R.id.property_value)).text = fileCount.toString()
                    (mDialogView.propertiesHolder.findViewById<LinearLayout>(R.id.properties_direct_children_count)
                        .findViewById<MyTextView>(R.id.property_value)).text =
                        directChildrenCount.toString()
                }
            }

            if (!fileDirItem.isDirectory) {
                val projection = arrayOf(MediaStore.Images.Media.DATE_MODIFIED)
                val uri = MediaStore.Files.getContentUri("external")
                val selection = "${MediaStore.MediaColumns.DATA} = ?"
                val selectionArgs = arrayOf(path)
                val cursor =
                    mActivity.contentResolver.query(uri, projection, selection, selectionArgs, null)
                cursor?.use {
                    if (cursor.moveToFirst()) {
                        val dateModified =
                            cursor.getLongValue(MediaStore.Images.Media.DATE_MODIFIED) * 1000L
                        updateLastModified(mActivity, mDialogView.root, dateModified)
                    } else {
                        updateLastModified(
                            mActivity,
                            mDialogView.root,
                            fileDirItem.getLastModified(mActivity)
                        )
                    }
                }

                val exif = if (isNougatPlus() && mActivity.isPathOnOTG(fileDirItem.path)) {
                    ExifInterface((mActivity as BaseActivity).getFileInputStreamSync(fileDirItem.path)!!)
                } else if (isNougatPlus() && fileDirItem.path.startsWith("content://")) {
                    try {
                        ExifInterface(
                            mActivity.contentResolver.openInputStream(
                                Uri.parse(
                                    fileDirItem.path
                                )
                            )!!
                        )
                    } catch (e: Exception) {
                        return@ensureBackgroundThread
                    }
                } else if (mActivity.isRestrictedSAFOnlyRoot(path)) {
                    try {
                        ExifInterface(
                            mActivity.contentResolver.openInputStream(
                                mActivity.getAndroidSAFUri(
                                    path
                                )
                            )!!
                        )
                    } catch (e: Exception) {
                        return@ensureBackgroundThread
                    }
                } else {
                    try {
                        ExifInterface(fileDirItem.path)
                    } catch (e: Exception) {
                        return@ensureBackgroundThread
                    }
                }

                val latLon = FloatArray(2)
                if (exif.getLatLong(latLon)) {
                    mActivity.runOnUiThread {
                        addProperty(R.string.gps_coordinates, "${latLon[0]}, ${latLon[1]}")
                    }
                }

                val altitude = exif.getAltitude(0.0)
                if (altitude != 0.0) {
                    mActivity.runOnUiThread {
                        addProperty(R.string.altitude, "${altitude}m")
                    }
                }
            }
        }

        when {
            fileDirItem.isDirectory -> {
                addProperty(
                    R.string.direct_children_count,
                    "…",
                    R.id.properties_direct_children_count
                )
                addProperty(R.string.files_count, "…", R.id.properties_file_count)
            }

            fileDirItem.path.isImageSlow() -> {
                fileDirItem.getResolution(mActivity)
                    ?.let { addProperty(R.string.resolution, it.formatAsResolution()) }
            }

            fileDirItem.path.isAudioSlow() -> {
                fileDirItem.getDuration(mActivity)?.let { addProperty(R.string.duration, it) }
                fileDirItem.getTitle(mActivity)?.let { addProperty(R.string.song_title, it) }
                fileDirItem.getArtist(mActivity)?.let { addProperty(R.string.artist, it) }
                fileDirItem.getAlbum(mActivity)?.let { addProperty(R.string.album, it) }
            }

            fileDirItem.path.isVideoSlow() -> {
                fileDirItem.getDuration(mActivity)?.let { addProperty(R.string.duration, it) }
                fileDirItem.getResolution(mActivity)
                    ?.let { addProperty(R.string.resolution, it.formatAsResolution()) }
                fileDirItem.getArtist(mActivity)?.let { addProperty(R.string.artist, it) }
                fileDirItem.getAlbum(mActivity)?.let { addProperty(R.string.album, it) }
            }
        }

        if (fileDirItem.isDirectory) {
            addProperty(
                R.string.last_modified,
                fileDirItem.getLastModified(mActivity).formatDate(mActivity)
            )
        } else {
            addProperty(R.string.last_modified, "…", R.id.properties_last_modified)
            try {
                addExifProperties(path, mActivity)
            } catch (e: Exception) {
                mActivity.showErrorToast(e)
                return
            }

            addProperty(R.string.md5, "…", R.id.properties_md5)
            ensureBackgroundThread {
                val md5 = if (mActivity.isRestrictedSAFOnlyRoot(path)) {
                    mActivity.contentResolver.openInputStream(mActivity.getAndroidSAFUri(path))
                        ?.md5()
                } else {
                    File(path).md5()
                }

                mActivity.runOnUiThread {
                    if (md5 != null) {
                        (mDialogView.propertiesHolder.findViewById<LinearLayout>(R.id.properties_md5)
                            .findViewById<MyTextView>(R.id.property_value)).text = md5
                    } else {
                        mDialogView.propertiesHolder.findViewById<LinearLayout>(R.id.properties_md5)
                            .beGone()
                    }
                }
            }
        }
    }

    private fun updateLastModified(activity: Activity, view: View, timestamp: Long) {
        activity.runOnUiThread {
            (view.findViewById<LinearLayout>(R.id.properties_last_modified)
                .findViewById<MyTextView>(R.id.property_value)).text =
                timestamp.formatDate(activity)
        }
    }

    constructor(activity: Activity, paths: List<String>, countHiddenItems: Boolean = false) : super(
        activity
    ) {
        mCountHiddenItems = countHiddenItems

        val fileDirItems = ArrayList<com.explorefile.filemanager.models.FileDirItem>(paths.size)
        paths.forEach {
            val fileDirItem = com.explorefile.filemanager.models.FileDirItem(
                it,
                it.getFilenameFromPath(),
                activity.getIsPathDirectory(it)
            )
            fileDirItems.add(fileDirItem)
        }

        val isSameParent = isSameParent(fileDirItems)

        addProperty(R.string.items_selected, paths.size.toString())
        if (isSameParent) {
            addProperty(R.string.path, fileDirItems[0].getParentPath())
        }

        addProperty(R.string.size, "…", R.id.properties_size)
        addProperty(R.string.files_count, "…", R.id.properties_file_count)

        ensureBackgroundThread {
            val fileCount =
                fileDirItems.sumByInt { it.getProperFileCount(activity, countHiddenItems) }
            val size =
                fileDirItems.sumByLong { it.getProperSize(activity, countHiddenItems) }.formatSize()
            activity.runOnUiThread {
                (mDialogView.propertiesHolder.findViewById<LinearLayout>(R.id.properties_size)
                    .findViewById<MyTextView>(R.id.property_value)).text = size
                (mDialogView.propertiesHolder.findViewById<LinearLayout>(R.id.properties_file_count)
                    .findViewById<MyTextView>(R.id.property_value)).text = fileCount.toString()
            }
        }

        val builder = activity.getAlertDialogBuilder()

        builder.apply {
            mActivity.setupDialogStuff(mDialogView.root, this) { alertDialog ->
                mDialogView.txtOk.setOnClickListener {
                    alertDialog.dismiss()
                }
            }
        }
    }

    private fun addExifProperties(path: String, activity: Activity) {
        val exif = if (isNougatPlus() && activity.isPathOnOTG(path)) {
            ExifInterface((activity as BaseActivity).getFileInputStreamSync(path)!!)
        } else if (isNougatPlus() && path.startsWith("content://")) {
            try {
                ExifInterface(activity.contentResolver.openInputStream(Uri.parse(path))!!)
            } catch (e: Exception) {
                return
            }
        } else if (activity.isRestrictedSAFOnlyRoot(path)) {
            try {
                ExifInterface(
                    activity.contentResolver.openInputStream(
                        activity.getAndroidSAFUri(
                            path
                        )
                    )!!
                )
            } catch (e: Exception) {
                return
            }
        } else {
            ExifInterface(path)
        }

        val dateTaken = exif.getExifDateTaken(activity)
        if (dateTaken.isNotEmpty()) {
            addProperty(R.string.date_taken, dateTaken)
        }

        val cameraModel = exif.getExifCameraModel()
        if (cameraModel.isNotEmpty()) {
            addProperty(R.string.camera, cameraModel)
        }

        val exifString = exif.getExifProperties()
        if (exifString.isNotEmpty()) {
            addProperty(R.string.exif, exifString)
        }
    }

    private fun isSameParent(fileDirItems: List<com.explorefile.filemanager.models.FileDirItem>): Boolean {
        var parent = fileDirItems[0].getParentPath()
        for (file in fileDirItems) {
            val curParent = file.getParentPath()
            if (curParent != parent) {
                return false
            }

            parent = curParent
        }
        return true
    }
}
