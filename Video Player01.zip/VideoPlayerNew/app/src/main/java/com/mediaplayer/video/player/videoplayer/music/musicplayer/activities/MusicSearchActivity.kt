package com.mediaplayer.video.player.videoplayer.music.musicplayer.activities

import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.commit
import androidx.preference.PreferenceManager
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityMusicSearchBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME


import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.search.SearchFragment

class MusicSearchActivity : BaseBindingActivity<ActivityMusicSearchBinding>() {

    private val playingQueueFragment = SearchFragment.newInstance()
    override fun getActivityContext(): FragmentActivity {
        return this@MusicSearchActivity
    }

    override fun setBinding(): ActivityMusicSearchBinding {
      return ActivityMusicSearchBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()
        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(IMAGE_THEME,"")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(GENERAL_THEME,"")

        if (editors == "theme_one")
        {
            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_one)
        }
        else if (editors == "theme_two")
        {
            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_two)
        }
        else if (edit == "ligt" || edit == "dark")
        {
            mBinding.root.background = null
        }

        supportFragmentManager.commit {
            replace(R.id.fm_container, playingQueueFragment)
        }

    }

}