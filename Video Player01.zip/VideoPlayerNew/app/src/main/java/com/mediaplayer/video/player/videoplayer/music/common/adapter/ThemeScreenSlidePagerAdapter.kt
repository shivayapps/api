package com.mediaplayer.video.player.videoplayer.music.common.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.mediaplayer.video.player.videoplayer.music.common.fragment.ThemeListFragment

class ThemeScreenSlidePagerAdapter(fa: FragmentActivity) : FragmentStateAdapter(fa) {
        override fun getItemCount(): Int = 4

        override fun createFragment(position: Int): Fragment = ThemeListFragment.newInstance(position)
    }