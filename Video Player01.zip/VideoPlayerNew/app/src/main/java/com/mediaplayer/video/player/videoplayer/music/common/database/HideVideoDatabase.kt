package com.mediaplayer.video.player.videoplayer.music.common.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.mediaplayer.video.player.videoplayer.music.common.utils.DATABASE_PATH
import java.io.File

@Database(entities = [HideVideo::class], version = 1)
abstract class HideVideoDatabase : RoomDatabase() {

    abstract fun hideVideoDao(): HideVideoDao?
    companion object {
        private var db: HideVideoDatabase? = null

        fun getInstance(context: Context): HideVideoDatabase {
            if (db == null) {
                synchronized(HideVideoDatabase::class) {
                    if (db == null) {
                        var sdir = File(DATABASE_PATH)
                        var parentFile=File(sdir.parentFile!!.absolutePath)
                        if (!parentFile.exists()) {
                            parentFile.mkdir()
                        }
                        if (!sdir.exists()) {
                            sdir.mkdir()
                        }
                        db = Room.databaseBuilder(context.applicationContext, HideVideoDatabase::class.java, "$DATABASE_PATH/videoplayer.db")
                            .fallbackToDestructiveMigration()
                            .allowMainThreadQueries()
                            .build()
                    }
                }
            }
            return db!!
        }

        fun destroyInstance() {
            db = null
        }


    }
}
