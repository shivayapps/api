package com.mediaplayer.video.player.videoplayer.music.common.utils

import android.net.Uri
import com.mediaplayer.video.player.videoplayer.music.videoplayer.model.VideoData

class AppConstant {

    companion object{

        const val TYPE_VIDEO_LIST = "type_video_list"
        const val TYPE_MUSIC_LIST = "type_music_list"
        const val DOWNLOAD = "Download"
        const val MUSIC = "MUSIC"
        const val LOCK = "LOCK"
        const val THEME = "THEME"
        const val SETTING = "SETTING"
        const val WHATSAPP_VIDEO = "Whatsapp video"
        const val CAMERA = "Camera"
        const val MOVIES = "Movies"
        const val ALL_VIDEOS = "All Videos"
        const val SCREEN_RECORDER = "Screen Recorder"
        const val VIDEO = "Video"
        const val VIDEOS = "Videos"
        const val EVENT_NOTIFY_PLAYLIST = "NotifyPlaylist"
        const val LAYOUT_TYPE_GRID = 1
        const val LAYOUT_TYPE_LIN = 0
        var LAYOUT_TYPE = 0
        const val VIDEO_LIST = "VideoList"
        const val BUNDDLE = "bunddle"
        const val POSITION = "position"
        const val HIDDEN = "hidden"
        const val VIDEO_FRAGMENT_TAG =  "VIDEO_FRAGMENT_TAG"
        const val MUSIC_FRAGMENT_TAG =  "MUSIC_FRAGMENT_TAG"
        const val LOCK_FRAGMENT_TAG =  "LOCK_FRAGMENT_TAG"
        const val THEME_FRAGMENT_TAG =  "THEME_FRAGMENT_TAG"
        const val SETTING_FRAGMENT_TAG =  "SETTING_FRAGMENT_TAG"
        const val FOLDER_NAME = "FolderName"
        const val PLAYLIST_NAME = "PlaylistName"
        val artworkUri = Uri.parse("content://media/external/audio/albumart")
        var ADS_CLICK = 0
        var  mDataVideo : ArrayList<VideoData> = ArrayList()
        const val CHOOSE_IMAGE_TYPE = 1
        const val CHOOSE_VIDEO_TYPE = 2
        const val GIF_TYPE = 3
        const val CHOOSE_DOCUMENT_TYPE = 4
        const val CHOOSE_AUDIO_TYPE = 5
        const val CHOOSE_ALL_TYPE = 6
        const val KEY_MEDIA_LIST = "mediaList"
        const val KEY_MEDIA_TYPE = "mediaType"
        const val GET_VIDEO_INTENT = "get_video_intent"
        const val GET_ANY_INTENT = "get_any_intent"
        const val GET_IMAGE_INTENT = "get_image_intent"
        const val SECURITY_QUESTION = "security_question"
        const val SECURITY_ANSWER = "security_answer"
        const val FOLDER_NAMES = "folder_name"
        const val FOLDER_PATHS = "folder_path"
        var mFirstTime = false
        var isLong = false
        const val NOMEDIA = ".nomedia"


    }
}