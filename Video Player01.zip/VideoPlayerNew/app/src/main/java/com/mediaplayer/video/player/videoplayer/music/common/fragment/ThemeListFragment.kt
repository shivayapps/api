package com.mediaplayer.video.player.videoplayer.music.common.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseFragment
import com.mediaplayer.video.player.videoplayer.music.common.utils.ThemeListViewModel
import kotlinx.android.synthetic.main.fragment_theme_item.*

/**
 * A placeholder fragment containing a simple view.
 */
class ThemeListFragment : BaseFragment() {

    private lateinit var themeListViewModel: ThemeListViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            themeListViewModel = ViewModelProviders.of(this).get(ThemeListViewModel::class.java).apply {
                val selItem = arguments?.getInt(ARG_SECTION_NUMBER) ?: 1
                when (selItem) {
                    0 -> {
                        setImageDrawable(R.drawable.ic_light_theme)
                    }
                    1 -> {
                        setImageDrawable(R.drawable.ic_dark_theme)
                    }
                    2 -> {
                        setImageDrawable(R.drawable.ic_one_theme)
                    }
                    3 -> {
                        setImageDrawable(R.drawable.ic_two_theme)
                    }
                }
            }
        }catch (e :Exception)
        {}

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val root = inflater.inflate(R.layout.fragment_theme_item, container, false)
        themeListViewModel.imageDrawable.observe(this, Observer<Int> {
            ivThemeItem.setImageDrawable(resources.getDrawable(it))
        })
        return root
    }

    override fun getLayoutRes(): Int {
       return R.layout.fragment_theme_item
    }


    companion object {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private const val ARG_SECTION_NUMBER = "section_number"

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        @JvmStatic
        fun newInstance(sectionNumber: Int): ThemeListFragment {
            return ThemeListFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_SECTION_NUMBER, sectionNumber)
                }
            }
        }
    }
}