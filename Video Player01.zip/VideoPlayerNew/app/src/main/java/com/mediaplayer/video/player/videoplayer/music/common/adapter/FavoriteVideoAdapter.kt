package com.mediaplayer.video.player.videoplayer.music.common.adapter

import android.app.Activity
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.database.FavoriteVideo
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.AdsManager
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant
import com.mediaplayer.video.player.videoplayer.music.common.utils.formateSize
import com.mediaplayer.video.player.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.common.utils.setDuration
import kotlinx.android.synthetic.main.layout_google_native_banner_small_ad_grid.view.*
import java.util.ArrayList


class FavoriteVideoAdapter(val mContext: Activity,val listFile: ArrayList<FavoriteVideo>, private val clickListener : View.OnClickListener, private val typesss : String): RecyclerView.Adapter<RecyclerView.ViewHolder>()  {

    inner class AdView(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var ad_view = itemView.findViewById<FrameLayout>(R.id.ad_view_container_mob)
    }
    inner class myclass(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var ivMainImage: ImageView = itemView.findViewById(R.id.iv_all_video_icon)
        var iv_options: ImageView = itemView.findViewById(R.id.iv_all_option)
        var txtTitle: TextView = itemView.findViewById(R.id.tv_video_name)
        var txtduration: TextView = itemView.findViewById(R.id.tv_recent_video_lenth)
        var txtfolder: TextView = itemView.findViewById(R.id.tv_name_fol)
        var txtSize: TextView = itemView.findViewById(R.id.tv_size)
        var ivResolution: TextView = itemView.findViewById(R.id.tv_reso)
        var ivFolder: ImageView = itemView.findViewById(R.id.iv_folder)
        var ivCon: ConstraintLayout = itemView.findViewById(R.id.con_main)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        var mView: View? = null

        if (viewType == 1)
        {

            mView = LayoutInflater.from(mContext).inflate(R.layout.layout_ad_view, parent, false)

        }else
        {
            mView = LayoutInflater.from(mContext).inflate(R.layout.all_video_list, parent, false)
        }

        return if (viewType == 1)
        {

            AdView(mView!!)

        }else
        {
            myclass(mView!!)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.setIsRecyclable(false)
        if (holder is AdView)
        {

            if (AdsManager(mContext).isNeedToShowAds() && mContext.isOnline) {
                NativeAdvancedModelHelper(mContext).loadNativeAdvancedAd(NativeAdsSize.Custom,holder.ad_view,LayoutInflater.from(mContext).inflate(R.layout.layout_google_native_banner_small_ad, holder.ad_view, false), isAdLoaded = {
                    val name = NativeAdvancedModelHelper.getNativeAd!!.callToAction


                    Log.e("TAG", "populateNativeAdViewTextdghdh: $name", )
                    if (name != null) {
                        when {
                            name.equals("Learn More") -> {

                                holder.ad_view.iv_folder.setImageDrawable(ContextCompat.getDrawable(mContext,R.drawable.ic_ads_learn_more))


                            }
                            name.equals("Open") -> {

                                holder.ad_view.iv_folder.setImageDrawable(ContextCompat.getDrawable(mContext,R.drawable.ic_ads_open))

                            }
                            name.equals("Install") -> {

                                holder.ad_view.iv_folder.setImageDrawable(ContextCompat.getDrawable(mContext,R.drawable.ic_ads_install))
                            }
                            name.equals("Download") -> {

                                holder.ad_view.iv_folder.setImageDrawable(ContextCompat.getDrawable(mContext,R.drawable.ic_ads_download))
                            }
                            name.equals("Visit", true) -> {

                                holder.ad_view.iv_folder.setImageDrawable(ContextCompat.getDrawable(mContext,R.drawable.ic_ads_visit))
                            }
                            name.equals("Visit Site", true) -> {

                                holder.ad_view.iv_folder.setImageDrawable(ContextCompat.getDrawable(mContext,R.drawable.ic_ads_visit))
                            }
                        }
                    }
                })

            }
            else{
                holder.ad_view.removeAllViews()
                holder.ad_view.visibility = View.GONE
            }
        } else if (holder is myclass) {

            with(holder) {

                val lPos = position
                if (lPos >= 0 && lPos < listFile.size) {
                    with(listFile[lPos]) {

                            val item = this

                            Glide.with(mContext).load(item.path).override(300,300).into(holder.ivMainImage)
                            holder.txtduration.text = setDuration(item.duration)
                            holder.txtTitle.text = item.name
                            holder.txtfolder.text = item.bucketName

                            if (item.bucketName.equals(AppConstant.DOWNLOAD)){
                                Glide.with(mContext).load(R.drawable.ic_dowanloadssss).into(holder.ivFolder)
                            }
                            else if(item.bucketName.equals(AppConstant.WHATSAPP_VIDEO))
                            {
                                Glide.with(mContext).load(R.drawable.ic_whatsapp_folder).into(holder.ivFolder)
                            }
                            else if(item.bucketName.equals(AppConstant.MOVIES))
                            {
                                Glide.with(mContext).load(R.drawable.ic_movie).into(holder.ivFolder)
                            }
                            else if(item.bucketName.equals(AppConstant.CAMERA))
                            {
                                Glide.with(mContext).load(R.drawable.ic_camera).into(holder.ivFolder)
                            }
                            else if(item.bucketName.equals(AppConstant.SCREEN_RECORDER))
                            {
                                Glide.with(mContext).load(R.drawable.ic_screenrecorder_folder).into(holder.ivFolder)
                            }
                            else if(item.bucketName.equals(AppConstant.VIDEOS) || item.bucketName.equals(AppConstant.VIDEO))
                            {
                                Glide.with(mContext).load(R.drawable.ic_video).into(holder.ivFolder)
                            }
                            else {
                                Glide.with(mContext).load(R.drawable.ic_folder).into(holder.ivFolder)
                            }
                            holder.txtSize.text = formateSize(item.size)
                            holder.ivResolution.text = item.width.toString()+"p"
                            holder.ivCon.setOnClickListener(clickListener)
                            holder.ivCon.tag = lPos
                            holder.ivCon.setTag(R.id.TYPE,typesss)
                            holder.iv_options.setOnClickListener(clickListener)
                            holder.iv_options.tag = lPos
                            holder.iv_options.setTag(R.id.TYPE,typesss)


                    }
                } else {
                 holder.itemView.visibility = View.GONE
                }

            }

        }
    }

    fun getAll(): ArrayList<FavoriteVideo> {
        return listFile
    }

    fun getItem(position: Int): FavoriteVideo {
        return listFile[position]
    }

    override fun getItemViewType(position: Int): Int {
        val returnPos = if (listFile[position].path.isEmpty()) {
                1
            } else {
                0
            }
        return returnPos
    }

    override fun getItemCount(): Int {
        return listFile.size
    }

}