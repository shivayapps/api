package com.mediaplayer.video.player.videoplayer.music.musicplayer.activities

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.afollestad.materialcab.attached.AttachedCab
import com.afollestad.materialcab.attached.destroy
import com.afollestad.materialcab.attached.isActive
import com.afollestad.materialcab.createCab
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityPlaylistDetailBinding

import com.mediaplayer.video.player.videoplayer.music.musicplayer.App

import com.mediaplayer.video.player.videoplayer.music.musicplayer.EXTRA_PLAYLIST
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.adapter.song.OrderablePlaylistSongAdapter
import com.mediaplayer.video.player.videoplayer.music.musicplayer.db.PlaylistWithSongs
import com.mediaplayer.video.player.videoplayer.music.musicplayer.db.toSongs
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.dip
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.surfaceColor
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.LibraryViewModel
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.playlists.PlaylistDetailsViewModel

import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.RetroMusicColoredTarget
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.playlistPreview.PlaylistPreview
import com.mediaplayer.video.player.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces.ICabCallback
import com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces.ICabHolder
import com.mediaplayer.video.player.videoplayer.music.musicplayer.model.Song
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.MusicUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.RetroColorUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor
import com.h6ah4i.android.widget.advrecyclerview.animator.DraggableItemAnimator
import com.h6ah4i.android.widget.advrecyclerview.animator.GeneralItemAnimator
import com.h6ah4i.android.widget.advrecyclerview.draggable.RecyclerViewDragDropManager
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.AdsManager
import com.mediaplayer.video.player.videoplayer.music.common.utils.isOnline
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.GlideApp
import kotlinx.android.synthetic.main.activity_playlist_detail.*
import kotlinx.android.synthetic.main.layout_google_native_banner_small_ad_grid.view.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koin.androidx.viewmodel.ext.android.viewModel
import org.koin.core.parameter.parametersOf

class PlaylistDetailActivity : BaseBindingActivity<ActivityPlaylistDetailBinding>() , ICabHolder {


    private lateinit var playlist : PlaylistWithSongs
    private lateinit var viewModel: PlaylistDetailsViewModel
    val libraryViewModel: LibraryViewModel by viewModel()
    private lateinit var playlistSongAdapter: OrderablePlaylistSongAdapter

    override fun initView() {
        super.initView()

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME,"")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            GENERAL_THEME,"")

        if (editors == "theme_one")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_one)
        }
        else if (editors == "theme_two")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_two)
        }
        else if (edit == "ligt" || edit == "dark")
        {
            mBinding.root.background = null
        }

        val intent: Intent = intent
        val args : Bundle = intent.getBundleExtra(AppConstant.BUNDDLE)!!
        playlist = args.getParcelable(EXTRA_PLAYLIST)!!
        val view by viewModel<PlaylistDetailsViewModel> {
            parametersOf(playlist)
        }
        viewModel = view
        addMusicServiceEventListener(viewModel)

        setUpRecyclerView()
        viewModel.getSongs().observe(this@PlaylistDetailActivity) {
            songs(it.toSongs())
        }

//        GlideApp.with(this@PlaylistDetailActivity)
//            .load(PlaylistPreview(playlist))
//            .playlistOptions()
//            .into(binding.imgBlur)

       mBinding.tvPlaylistName.text = playlist.playlistEntity.playlistName
        mBinding.tvPlaylistDura.text = getPlaylistText(playlist)

        GlideApp.with(this).asBitmapPalette().playlistOptions()
            //.checkIgnoreMediaStore()
            .load(PlaylistPreview(playlist))
            .into(object : RetroMusicColoredTarget(mBinding.imgBlur) {
                override fun onColorReady(colors: MediaNotificationProcessor) {
                    setColors(Color.WHITE)
                }
            })

        mBinding.ivBack.setOnClickListener {

            onBackPressed()

        }
    }

    override fun onResume() {
        super.onResume()
        if (AdsManager(mActivity).isNeedToShowAds() && isOnline) {

//            NativeAdvancedModelHelper(mActivity).loadNativeAdvancedAd(
//                NativeAdsSize.Custom,banner_ad as FrameLayout,
//                LayoutInflater.from(mActivity).inflate(R.layout.layout_google_native_banner_small_ad_small, banner_ad as FrameLayout, false))

            NativeAdvancedModelHelper(mActivity).loadNativeAdvancedAd(
                NativeAdsSize.Custom,
                banner_ad as FrameLayout,
                LayoutInflater.from(mActivity).inflate(
                    R.layout.layout_google_native_ad_medium_custom,
                    banner_ad as FrameLayout,
                    false
                ), isAdLoaded = {
                    val name = NativeAdvancedModelHelper.getNativeAd!!.callToAction
                    Log.e("TAG", "populateNativeAdViewTextdghdh: $name", )
                    when {
                        name.equals("Learn More") -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_learn_more))
                        }
                        name.equals("Open") -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_open))

                        }
                        name.equals("Install") -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_install))
                        }
                        name.equals("Download") -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_download))
                        }
                        name.equals("Visit", true) -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_visit))
                        }
                        name.equals("Visit Site", true) -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_visit))
                        }
                    }
                }
            )

        }
        else
        {
            banner_ad.visibility = View.GONE
        }
    }

    private fun getPlaylistText(playlist: PlaylistWithSongs): String {
        return MusicUtil.getPlaylistInfoString(mActivity, playlist.songs.toSongs())
    }

    override fun onPause() {
        mActivity.lifecycleScope.launch(Dispatchers.IO) {
             playlistSongAdapter.saveSongs(playlist.playlistEntity)

        }

        super.onPause()
    }


    override fun getActivityContext(): FragmentActivity {
        return this@PlaylistDetailActivity
    }

    protected open fun setColors(color: Int) {
        mBinding.img.backgroundTintList = ColorStateList.valueOf(color)
    }

    fun songs(songs: List<Song>) {
        mBinding.progressIndicator.hide()
        if (songs.isNotEmpty()) {
            playlistSongAdapter.swapDataSet(songs)
        } else {
            showEmptyView()
        }
    }
    private fun showEmptyView() {
        mBinding.empty.isVisible = true
        mBinding.emptyText.isVisible = true
    }



    private fun setUpRecyclerView() {
        playlistSongAdapter = OrderablePlaylistSongAdapter(
            playlist.playlistEntity,
            this@PlaylistDetailActivity,
            ArrayList(),
            R.layout.item_queue,
            this
        )

        val dragDropManager = RecyclerViewDragDropManager()

        val wrappedAdapter: RecyclerView.Adapter<*> =
            dragDropManager.createWrappedAdapter(playlistSongAdapter)


        val animator: GeneralItemAnimator = DraggableItemAnimator()
        mBinding.recyclerView.itemAnimator = animator

        dragDropManager.attachRecyclerView(mBinding.recyclerView)

        mBinding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@PlaylistDetailActivity)
            mBinding.recyclerView.adapter = wrappedAdapter
        }
        playlistSongAdapter.registerAdapterDataObserver(object :
            RecyclerView.AdapterDataObserver() {
            override fun onChanged() {
                super.onChanged()
                checkIsEmpty()
            }
        })
    }
    private fun checkIsEmpty() {
        checkForPadding()
        mBinding.empty.isVisible = playlistSongAdapter.itemCount == 0
        mBinding.emptyText.isVisible = playlistSongAdapter.itemCount == 0
    }
    private fun checkForPadding() {
        val itemCount: Int = playlistSongAdapter.itemCount
        if (itemCount > 0 && MusicPlayerRemote.playingQueue.isNotEmpty()) {
            mBinding.recyclerView.updatePadding(bottom = dip(R.dimen.mini_player_height))
        } else {
            mBinding.recyclerView.updatePadding(bottom = 0)
        }
    }

    private var cab: AttachedCab? = null

    override fun openCab(menuRes: Int, callback: ICabCallback): AttachedCab {
        cab?.let {
            println("Cab")
            if (it.isActive()) {
                it.destroy()
            }
        }
        cab = createCab(R.id.toolbar_container) {
            menu(menuRes)
            closeDrawable(R.drawable.ic_close)
            backgroundColor(literal = RetroColorUtil.shiftBackgroundColor(surfaceColor()))
            slideDown()
            onCreate { cab, menu -> callback.onCabCreated(cab, menu) }
            onSelection {
                callback.onCabItemClicked(it)
            }
            onDestroy { callback.onCabFinished(it) }
        }
        return cab as AttachedCab
    }

    override fun setBinding(): ActivityPlaylistDetailBinding {
       return ActivityPlaylistDetailBinding.inflate(layoutInflater)
    }
}