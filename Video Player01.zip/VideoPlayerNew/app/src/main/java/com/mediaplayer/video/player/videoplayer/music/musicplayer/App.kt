/*
 * Copyright (c) 2020 Hemanth Savarla.
 *
 * Licensed under the GNU General Public License v3
 *
 * This is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 */
package com.mediaplayer.video.player.videoplayer.music.musicplayer

import android.app.Activity
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import code.name.monkey.appthemehelper.ThemeStore
import code.name.monkey.appthemehelper.util.VersionUtils
import com.example.app.ads.helper.VasuAdsConfig
import com.example.app.ads.helper.openad.AppOpenApplication
import com.example.app.ads.helper.openad.OpenAdHelper
import com.mediaplayer.video.player.videoplayer.music.musicplayer.appshortcuts.DynamicShortcutManager
import com.mediaplayer.video.player.videoplayer.music.musicplayer.helper.WallpaperAccentManager
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.activity.SplashActivity
import com.mediaplayer.video.player.videoplayer.music.common.activity.SubscriptionActivity
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.AdsManager
import com.onesignal.OneSignal
import com.mediaplayer.video.player.videoplayer.music.common.activity.OutMusicActivity
import com.mediaplayer.video.player.videoplayer.music.common.utils.NetworkChangeReceiver
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import java.security.MessageDigest

class App : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {


    private val wallpaperAccentManager = WallpaperAccentManager(this)

    override fun onCreate() {
        super.onCreate()

        instance = this

        startKoin {
            androidContext(this@App)
            modules(appModules)
        }

        if (!ThemeStore.isConfigured(this, 3)) {
            ThemeStore.editTheme(this)
                .accentColorRes(R.color.select_text_color)
                .coloredNavigationBar(true)
                .commit()
        }
        wallpaperAccentManager.init()

        if (VersionUtils.hasNougatMR())
            DynamicShortcutManager(this).initDynamicShortcuts()


        try {

            setAppLifecycleListener(this)

            VasuAdsConfig.with(applicationContext)
                .isEnableOpenAd(true)
                .setAdmobAppId(getString(R.string.admob_app_id))
                .setAdmobInterstitialAdId(getString(R.string.admob_interstitial_ad_id))
                .setAdmobNativeAdvancedAdId(getString(R.string.admob_native_advanced_ad_id))
                .setAdmobOpenAdId(getString(R.string.admob_open_ad_id))
                .initialize()

//            initMobileAds("45A39CCB14A7A2B5FFDC591EA2F9CA29")

            OpenAdHelper.destroy()
            OpenAdHelper.loadOpenAd(applicationContext)

            OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE)
            OneSignal.initWithContext(applicationContext)
            OneSignal.setAppId("642658f3-86ea-4035-b48b-157a06751b85")

            val filter = IntentFilter()
            filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
            registerReceiver(NetworkChangeReceiver(), filter)

            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())

                //Log.e("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT))
            }

        } catch (e: Exception) {

        }

    }

    override fun onTerminate() {
        super.onTerminate()

        wallpaperAccentManager.release()
    }

    companion object {
        private var instance: App? = null

        fun getContext(): App {
            return instance!!
        }

        fun isProVersion(): Boolean {
            return AdsManager(instance!!.applicationContext).isNeedToShowAds()
        }
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        return when {
            fCurrentActivity is SplashActivity -> {
                false
            }
            fCurrentActivity is SubscriptionActivity -> {
                false
            }
            fCurrentActivity is OutMusicActivity -> {
                false
            }
            AdsManager(fCurrentActivity).isNeedToShowAds() -> {
                true
            }
            else -> {
                false
            }
        }
    }
}
