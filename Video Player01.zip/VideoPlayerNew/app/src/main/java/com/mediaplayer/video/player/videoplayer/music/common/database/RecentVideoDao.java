package com.mediaplayer.video.player.videoplayer.music.common.database;


import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.mediaplayer.video.player.videoplayer.music.common.database.RecentVideo;

import java.util.List;

@Dao
public interface RecentVideoDao
{
    @Query("Select * from recent_video ORDER BY ID DESC")
    LiveData<List<RecentVideo>> getRecentVideoList();

    @Query("Select * from recent_video")
    List<RecentVideo> getRecentVideoListSearch();

    @Insert
    void insertRecentVideo(RecentVideo recent);

    @Query("DELETE FROM recent_video")
    void deleteRecentVideo();

    @Query("DELETE from recent_video WHERE path = :filepath")
    void deleteRecentVideo(String filepath);

    @Query("Select count(*) from recent_video WHERE path = :filepath")
    int isRecentVideo(String filepath);

    @Query("Select * from recent_video WHERE Type = :type")
    LiveData<List<RecentVideo>>getTypeRecentVideo(String type);

    @Query("UPDATE recent_video SET path = :nfilepath WHERE path = :filepath")
    void updateRecentVideo(String nfilepath,String filepath);
}
