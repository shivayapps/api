package com.mediaplayer.video.player.videoplayer.music.common.newInApp

import android.content.Context
import android.util.Log

class AdsManager(val mActivity: Context) {

    // SP to be save & retrieve
//    private val isNeedToShow = "isNeedToShow"
//    private val isNeedToShow1 = "isNeedToShow1"
    private val isShowing = "isShowing"
//    private val sp: SharedPreferences = SharedPreferences(mActivity)

    // SP to be save & retrieve
    private val isNeedToShow = "isNeedToShow"
    private val isSubscribe = "isSubscribe"
    private val sp: SharedPreferences = SharedPreferences(mActivity)

    fun onProductPurchased() {
        Log.e("IN_APP_BILLING","onProductPurchased")
        sp.save(isNeedToShow, true)
    }

    fun onProductSubscribed() {
        Log.e("IN_APP_BILLING","onProductSubscribed")
        sp.save(isSubscribe, true)
    }

    fun onProductExpired() {
        Log.e("IN_APP_BILLING","onProductExpired")
        sp.save(isNeedToShow, false)
    }
    fun onSubscribeExpired() {
        Log.e("IN_APP_BILLING","onProductExpired")
        sp.save(isSubscribe, false)
    }

    fun isNeedToShowAds(): Boolean {
        com.example.app.ads.helper.isNeedToShowAds=true

        val isProductPurchased = sp.read(isNeedToShow, false)
        val isSubscribe = sp.read(isSubscribe, false)

//        if(BuildConfig.DEBUG) return false
        if(isProductPurchased || isSubscribe) com.example.app.ads.helper.isNeedToShowAds=false

        return com.example.app.ads.helper.isNeedToShowAds
       // return false
    }

    fun saveDialogStatus(status: Boolean) {
        sp.save(isShowing, status)
    }

    fun isDialogShowing(): Boolean {
        return sp.read(isShowing, false)
    }

    /**
     *   SharedPreferences helper class
     */
    private inner class SharedPreferences//  Default constructor
    (private val mActivity: Context) {
        private val myPreferences = "ads_pref"

        //  Save boolean value
        fun save(key: String, value: Boolean) {
            val editor = mActivity.getSharedPreferences(myPreferences, 0).edit()
            editor.putBoolean(key, value)
            editor.apply()
        }

        //  Read Boolean value
        fun read(key: String, defValue: Boolean): Boolean {
            return mActivity.getSharedPreferences(myPreferences, 0).getBoolean(key, defValue)
        }

    }
}