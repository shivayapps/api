package com.mediaplayer.video.player.videoplayer.music.common.fragment

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.activity.FavoriteActivity
import com.mediaplayer.video.player.videoplayer.music.common.activity.SubscriptionActivity
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingFragment
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.AdsManager
import com.mediaplayer.video.player.videoplayer.music.common.rateandfeedback.library_feedback.sendEmail
import com.mediaplayer.video.player.videoplayer.music.databinding.FragmentSettingMainBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.activities.SettingsActivity


class SettingMainFragment : BaseBindingFragment<FragmentSettingMainBinding>() {
    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentSettingMainBinding {
       return FragmentSettingMainBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()

        if (AdsManager(mContext).isNeedToShowAds())
        {
            mBinding.conSub.visibility = View.VISIBLE
//            mBinding.conMoreApp.visibility = View.VISIBLE
//            mBinding.view6.visibility = View.VISIBLE
        }
        else{
            mBinding.conSub.visibility = View.GONE
//            mBinding.conMoreApp.visibility = View.GONE
//            mBinding.view6.visibility = View.GONE
        }

    }

    override fun onResume() {
        super.onResume()
        if (AdsManager(mContext).isNeedToShowAds())
        {
            mBinding.conSub.visibility = View.VISIBLE
//            mBinding.conMoreApp.visibility = View.VISIBLE
//            mBinding.view6.visibility = View.VISIBLE
        }
        else{
            mBinding.conSub.visibility = View.GONE
//            mBinding.conMoreApp.visibility = View.GONE
//            mBinding.view6.visibility = View.GONE
        }
    }

    override fun initViewListener() {
        super.initViewListener()

        mBinding.conFav.setOnClickListener(this)
        mBinding.conFeedback.setOnClickListener(this)
        mBinding.conMoreApp.setOnClickListener(this)
        mBinding.conPrivacy.setOnClickListener(this)
        mBinding.conShareApp.setOnClickListener(this)
        mBinding.conRateApp.setOnClickListener(this)
        mBinding.conMusic.setOnClickListener(this)
        mBinding.conSub.setOnClickListener(this)

    }

    override fun onClick(v: View) {
        super.onClick(v)
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        when(v.id)
        {
            R.id.con_fav ->
            {
                val intent = Intent(mContext,FavoriteActivity::class.java)
                launchActivity(intent)
            }
            R.id.con_share_app ->
            {

                val intent = Intent("android.intent.action.SEND")
//                intent.setType(HTTP.PLAIN_TEXT_TYPE);
                //                intent.setType(HTTP.PLAIN_TEXT_TYPE);
                intent.type = "text/plain"
                intent.putExtra(
                    "android.intent.extra.SUBJECT",
                    resources.getString(R.string.app_name)
                )
                val sb = StringBuilder()
                sb.append(getString(R.string.share_msg))
                val sb2 = sb.toString()
                val sb3 = StringBuilder()
                sb3.append(sb2)
//                sb3.append("https://play.google.com/store/apps/details?id=")
//                sb3.append(activity!!.packageName)
//                sb3.append("\n\n")
                intent.putExtra("android.intent.extra.TEXT", sb3.toString())
                startActivity(Intent.createChooser(intent, "Choose one"))

//                val intent = Intent(Intent.ACTION_SEND)
//                intent.type = "text/*"
//                intent.putExtra(Intent.EXTRA_TEXT, getString(R.string.share_msg) )
//                startActivity(Intent.createChooser(intent,"Video Player"))
            }
//            R.id.con_more_app ->
//            {
//
//            }
            R.id.con_privacy ->
            {
                openURL("https://sites.google.com/view/shivayapps/home")
            }
            R.id.con_rate_app ->
            {

                val webpage =
                    Uri.parse("https://play.google.com/store/apps/details?id="+activity!!.packageName)
                val i = Intent(Intent.ACTION_VIEW, webpage)
                if (i.resolveActivity(activity!!.packageManager) != null) {
                    startActivity(i)
                }
            }
            R.id.con_feedback ->
            {
                mContext.sendEmail()
            }
            R.id.con_music ->
            {
                val intent = Intent(mContext,SettingsActivity::class.java)
                launchActivity(intent)
            }
            R.id.con_sub ->
            {
                val intent = Intent(mContext,SubscriptionActivity::class.java)
                launchActivity(intent)
            }
        }
    }

    private fun openURL(fURL: String) {
        try {

            val customTabsIntent: CustomTabsIntent = CustomTabsIntent.Builder()
                .addDefaultShareMenuItem()
                .setToolbarColor(ContextCompat.getColor(mContext, R.color.bg_light_color))
                .setShowTitle(true)
                .addDefaultShareMenuItem()
                .build()
            customTabsIntent.launchUrl(mContext, Uri.parse(fURL.replace(" ", "+")))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(mContext, "No application can handle this request."
                    + " Please install a web browser", Toast.LENGTH_LONG).show()

        }
    }

    companion object{
        fun newInstance(): SettingMainFragment {
            return SettingMainFragment()
        }
    }

}