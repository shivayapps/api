package com.mediaplayer.video.player.videoplayer.music.common.activity

import android.view.View
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.widgets.OnSingleClickListener
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityMonthlySubscriptionSuccessBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil

class YearSubscriptionSuccessActivity : BaseBindingActivity<ActivityMonthlySubscriptionSuccessBinding>() {


    override fun getActivityContext(): FragmentActivity {
       return this@YearSubscriptionSuccessActivity
    }

    override fun setBinding(): ActivityMonthlySubscriptionSuccessBinding {
       return ActivityMonthlySubscriptionSuccessBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        }
        else{
            setImmersiveFullscreen()
        }
        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME,"")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            GENERAL_THEME,"")

        if (editors == "theme_one")
        {
            mBinding.root.background = ContextCompat.getDrawable(mActivity, R.drawable.img_theme_one)
        }
        else if (editors == "theme_two")
        {
            mBinding.root.background = ContextCompat.getDrawable(mActivity, R.drawable.img_theme_two)
        }
        else if (edit == "ligt" || edit == "dark")
        {
            mBinding.root.background = null
        }

        mBinding.btnGetStarted.setOnClickListener(object : OnSingleClickListener() {
            override fun onSingleClick(v: View?) {
                onBackPressed()
            }
        })
    }

    override fun onBackPressed() {
        setResult(RESULT_OK)
        super.onBackPressed()

    }


}