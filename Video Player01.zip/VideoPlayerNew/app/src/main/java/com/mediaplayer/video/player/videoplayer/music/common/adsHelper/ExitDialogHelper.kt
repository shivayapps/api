package com.mediaplayer.video.player.videoplayer.music.common.adsHelper

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import com.mediaplayer.video.player.videoplayer.music.common.adsHelper.*
import com.mediaplayer.video.player.videoplayer.music.common.rateandfeedback.library_feedback.sendEmail


const val rateDialogCount = 5

fun AppCompatActivity.displayExitDialog(isRating: Boolean) {
    val sp = ExitSPHelper(this)

    if (isRating) {
        if (!sp.isRated()) {
            ratingDialog(object : OnRateListener {
                override fun onRate(rate: Int) {
                    sp.saveRatingCount(rate)
                    if(rate > 0){
                        if (rate > 3) {
                            rateApp()
                        } else {
                            sendEmail()
                        }
                    }
                }
            })
        }
    } else {
        if (!sp.isRated() && sp.getExitCount() >= rateDialogCount && !sp.isDismissed()) {
            ratingDialog(object : OnRateListener {
                override fun onRate(rate: Int) {
                    if(rate > 0){
                        if (rate > 3) {
                            rateApp()
                        } else {
                            sendEmail()
                        }
                    }
                }
            })
        } else {
            sp.saveDismissed(false)
            exitDialog()
        }
    }


}