package com.mediaplayer.video.player.videoplayer.music.common.activity

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.google.firebase.analytics.FirebaseAnalytics
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.adapter.ImgAdapter
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.*
import com.mediaplayer.video.player.videoplayer.music.common.utils.ItemOffsetDecoration
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivitySubscriptionBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME

import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil
import org.json.JSONObject

class SubscriptionActivity : BaseBindingActivity<ActivitySubscriptionBinding>(),
    ProductPurchaseHelper.ProductPurchaseListener {

//    private lateinit var mImgAdapter: ImgAdapter
    private var mSelectedSubscriptionPeriod = ""

    var skuYearly: ProductPurchaseHelper.ProductInfo? = null
    var skuWeekly: ProductPurchaseHelper.ProductInfo? = null
//    lateinit var mBinding: ActivitySubscriptionBinding
    private lateinit var mImgAdapter: ImgAdapter
//    var TAG = javaClass.simpleName
    var mSelectedSku = ""
    var REQUEST_CODE_CHECK = 101


    private var mFirebaseAnalytics: FirebaseAnalytics? = null

//    private enum class SubUI {
//        _Month, _6_Month, _Year, Life
//    }

    override fun getActivityContext(): FragmentActivity {
        return this@SubscriptionActivity
    }

    override fun setBinding(): ActivitySubscriptionBinding {
        return ActivitySubscriptionBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()

        initBilling()

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }
        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME, ""
        )
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            GENERAL_THEME, ""
        )

        if (editors == "theme_one") {

            mBinding.root.background =
                ContextCompat.getDrawable(mActivity, R.drawable.img_theme_one)
        } else if (editors == "theme_two") {

            mBinding.root.background =
                ContextCompat.getDrawable(mActivity, R.drawable.img_theme_two)
        } else if (edit == "ligt" || edit == "dark") {
            mBinding.root.background = null
        }
        val img = intArrayOf(
            R.drawable.img_one,
            R.drawable.img_two,
            R.drawable.img_three,
            R.drawable.img_four,
            R.drawable.img_five,
            R.drawable.img_six,
            R.drawable.img_seven,
            R.drawable.img_eight
        )

        mImgAdapter = ImgAdapter(mActivity, img)

        mBinding.rvSubImg.run {
            adapter = mImgAdapter
            addItemDecoration(ItemOffsetDecoration(mActivity, R.dimen._4sdp))
        }

        val duration = 10
        val pixelsToMove = 25
        val mHandler: Handler = Handler(Looper.getMainLooper())
        val SCROLLING_RUNNABLE: Runnable = object : Runnable {
            override fun run() {
                mBinding.rvSubImg.smoothScrollBy(pixelsToMove, 0)
                mHandler.postDelayed(this, duration.toLong())
            }
        }

        mBinding.rvSubImg.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                val lastItem: Int =
                    (mBinding.rvSubImg.layoutManager as LinearLayoutManager).findLastCompletelyVisibleItemPosition()
                if (lastItem == mBinding.rvSubImg.layoutManager!!.itemCount - 1) {
                    (mBinding.rvSubImg.layoutManager as LinearLayoutManager).smoothScrollToPosition(
                        mBinding.rvSubImg,
                        RecyclerView.State(),
                        0
                    )
                }
            }
        })
        mHandler.postDelayed(SCROLLING_RUNNABLE, 500)

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this)

    }

    override fun initViewAction() {
        super.initViewAction()

//        productKeyYear = InAppPurchaseHelper.instance!!.getProductPrice(YEAR_SKU)
//        productKeyMonth = InAppPurchaseHelper.instance!!.getProductPrice(MONTH_SKU)

//        mBinding.tvYearlyPrice.text = productKeyYear
//        mBinding.tvMonthlyPrice.text = productKeyMonth
//        Log.e(TAG, "initViewAction: $productKeyYear : $productKeyMonth", )
//
//        try {
//
//            val lYearNumber: String = productKeyYear.replace("""[^0-9.]""".toRegex(), "")
//            val lWeekNumber: String = productKeyMonth.replace("""[^0-9.]""".toRegex(), "")
//
//            Log.e(TAG, "getSubscriptionPrice: lYearNumber $lYearNumber")
//            Log.e(TAG, "getSubscriptionPrice: lWeekNumber $lWeekNumber")
//
//            if (lYearNumber.isNotEmpty()) {
//
//                val lWeekPrize: Double = (lWeekNumber.toDouble() * 52) - lYearNumber.toDouble() //5300
//                Log.e(TAG, "getSubscriptionPrice: lWeekPrize $lWeekPrize")
//
//                val lYearPrizeBaseOfWeek = (lWeekNumber.toDouble() * 52)//7800
//                Log.e(TAG, "getSubscriptionPrice: lYearPrizeBaseOfWeek $lYearPrizeBaseOfWeek")
//
//                val lDiscount = (lWeekPrize / lYearPrizeBaseOfWeek) * 100//67
//                Log.e(TAG, "getSubscriptionPrice: lDiscount $lDiscount")
//
//                val countedWeekPrice: String = productKeyMonth.replace(
//                    lWeekNumber,
//                    String.format("%.2f", (lYearNumber.toDouble() / 52))
//                )
//                Log.e(TAG, "getSubscriptionPrice: countedWeekPrice $countedWeekPrice")
//
//               mBinding.tvYearMonthPrize.text = "$countedWeekPrice /${resources.getString(R.string.week)}"
//
////                mBinding.tvSaveSpecial.text = "${resources.getString(R.string.save)} ${lDiscount.toInt()}%"
//
//
//            }
//
//        } catch (e: Exception) {
//
//        }

//        try {
//            trialYear = ProductPurchaseHelper.instance!!.getSkuDetails(YEAR_SKU)!!.freeTrialPeriod[1].toString().plus(" " + "Days free trial" )
//            Log.e(TAG, "initViewAction: $trialYear", )
//            trial = InAppPurchaseHelper.instance!!.getSkuDetails(YEAR_SKU)!!.freeTrialPeriod[1].toString()
//            Log.e(TAG, "initViewAction: $trial", )
//        }catch (e:Exception) {
//        }

//        setupUI(SubUI._6_Month)

    }

    override fun initViewListener() {
        super.initViewListener()

        mBinding.btnSubscription.setOnClickListener(this)
        mBinding.cardOne.setOnClickListener(this)
        mBinding.cardTwo.setOnClickListener(this)
        mBinding.cardThree.setOnClickListener(this)
        mBinding.btnSubscription.setOnClickListener(this)
        mBinding.ivClose.setOnClickListener(this)
        mBinding.tvPrivacy.setOnClickListener(this)

    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.iv_close -> {
                onBackPressed()
            }
            R.id.tv_privacy -> {
                openURL("https://sites.google.com/view/shivayapps/home")
            }
            R.id.card_one -> {
                mSelectedSubscriptionPeriod= SUBSCRIPTION_ONE_WEEK
                setupUI(mSelectedSubscriptionPeriod)
            }
            R.id.card_two -> {
                mSelectedSubscriptionPeriod= SUBSCRIPTION_SIX_MONTH
                setupUI(mSelectedSubscriptionPeriod)
            }
            R.id.card_three -> {
                mSelectedSubscriptionPeriod= SUBSCRIPTION_ONE_YEAR
                setupUI(mSelectedSubscriptionPeriod)
            }
//            R.id.card_lifetime -> {
//                mSelectedSubscriptionPeriod= SUBSCRIPTION_LIFE_TIME
//                setupUI(mSelectedSubscriptionPeriod)
//            }
            R.id.btn_subscription -> {
                ProductPurchaseHelper.subscribeProduct(
                    this@SubscriptionActivity,
                    mSelectedSku,
                    false
                )
            }
        }
    }

    private fun openURL(fURL: String) {
        try {
            val customTabsIntent: CustomTabsIntent = CustomTabsIntent.Builder()
                .addDefaultShareMenuItem()
                .setToolbarColor(ContextCompat.getColor(mActivity, R.color.bg_light_color))
                .setShowTitle(true)
                .addDefaultShareMenuItem()
                .build()
            customTabsIntent.launchUrl(mActivity, Uri.parse(fURL.replace(" ", "+")))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                mActivity, "No application can handle this request."
                        + " Please install a web browser", Toast.LENGTH_LONG
            ).show()

        }
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        if (requestCode == 111 && resultCode == RESULT_OK) {
            setResult(RESULT_OK)
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }


    private fun setupUI(fType: String) {
        mSelectedSku = fType

        when (fType) {

            SUBSCRIPTION_ONE_WEEK -> {
                mBinding.planOne.background = ContextCompat.getDrawable(
                    this@SubscriptionActivity,
                    R.drawable.rounded_selected_special
                )
                mBinding.planTwo.background = null
                mBinding.planThree.background = null
                mBinding.btnSubscription.text = "Subscribe Now"
                val product = ProductPurchaseHelper.getProductInfo(SUBSCRIPTION_ONE_WEEK)
                mBinding.lblPeriodOne.text = product?.billingPeriod
                if (!product?.freeTrialPeriod.equals("Not Found")) {
                    mBinding.btnSubscription.text =
                        "Start your ${product?.freeTrialPeriod?.replace(" ", "-")} Trial"
                } else {
                    mBinding.btnSubscription.text = "Subscribe Now"
                }
            }
            SUBSCRIPTION_SIX_MONTH -> {
                mBinding.planOne.background = null
                mBinding.planTwo.background = ContextCompat.getDrawable(
                    this@SubscriptionActivity,
                    R.drawable.rounded_selected_special
                )
                mBinding.planThree.background = null
                mBinding.btnSubscription.text = "Subscribe Now"
                val product = ProductPurchaseHelper.getProductInfo(SUBSCRIPTION_SIX_MONTH)
                mBinding.lblPeriodTwo.text = product?.billingPeriod
                if (!product?.freeTrialPeriod.equals("Not Found")) {
                    mBinding.btnSubscription.text =
                        "Start your ${product?.freeTrialPeriod?.replace(" ", "-")} Trial"
                } else {
                    mBinding.btnSubscription.text = "Subscribe Now"
                }
            }
            SUBSCRIPTION_ONE_YEAR -> {
                mBinding.planOne.background = null
                mBinding.planTwo.background = null
                mBinding.planThree.background = ContextCompat.getDrawable(
                    this@SubscriptionActivity,
                    R.drawable.rounded_selected_special
                )
                mBinding.btnSubscription.text = "Subscribe Now"
                val product = ProductPurchaseHelper.getProductInfo(SUBSCRIPTION_ONE_YEAR)
                mBinding.lblPeriodThree.text = product?.billingPeriod
                if (!product?.freeTrialPeriod.equals("Not Found")) {
                    mBinding.btnSubscription.text =
                        "Start your ${product?.freeTrialPeriod?.replace(" ", "-")} Trial"
                } else {
                    mBinding.btnSubscription.text = "Subscribe Now"
                }
            }
        }

    }

    private fun initBilling() {
        try {
            ProductPurchaseHelper.setSubscriptionKey(
                SUBSCRIPTION_ONE_WEEK,
                SUBSCRIPTION_SIX_MONTH,
                SUBSCRIPTION_ONE_YEAR
            )
            ProductPurchaseHelper.initBillingClient(this@SubscriptionActivity, this)
        } catch (e: Exception) {

        }
    }

    override fun onPurchasedExpired(productType: String) {

    }

    override fun onPurchasedSuccess(purchase: Purchase) {
        val json = JSONObject(purchase.originalJson)
        when (json.getString("productId")) {
//            SUBSCRIPTION_ONE_MONTH -> {
//                val bundle = Bundle()
//                bundle.putString("WEEKLY_SUBSCRIPTION_SUCCESSFUL", "WEEKLY_SUBSCRIPTION_SUCCESSFUL")
//                mFirebaseAnalytics!!.logEvent("WEEKLY_SUBSCRIPTION_SUCCESSFUL", bundle)
//            }

        }

        val intent = Intent(mActivity, YearSubscriptionSuccessActivity::class.java)
        launchActivityForResult(intent, 111)
    }

    override fun onPurchasedFound(productType: String, purchaseList: MutableList<Purchase>?) {
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        Log.e(TAG, "onBillingSetupFinished:InAppActivity:" + billingResult.responseCode)
        Log.e(TAG, "onBillingSetupFinished:InAppActivity:" + billingResult.debugMessage)
        ProductPurchaseHelper.initSubscriptionKeys(this@SubscriptionActivity) {
            skuWeekly = ProductPurchaseHelper.getProductInfo(SUBSCRIPTION_ONE_WEEK)
            mBinding.tvPriceOne.text = skuWeekly?.formattedPrice
            mBinding.lblPeriodOne.text = skuWeekly?.billingPeriod

            skuYearly = ProductPurchaseHelper.getProductInfo(SUBSCRIPTION_SIX_MONTH)
            mBinding.tvPriceTwo.text = skuYearly?.formattedPrice
            mBinding.lblPeriodTwo.text = skuYearly?.billingPeriod
            skuYearly = ProductPurchaseHelper.getProductInfo(SUBSCRIPTION_ONE_YEAR)
            mBinding.tvPriceThree.text = skuYearly?.formattedPrice
            mBinding.lblPeriodThree.text = skuYearly?.billingPeriod

            Log.e(TAG, "onBillingSetupFinished:skuWeekly:" + skuWeekly?.priceAmountMicros)
            Log.e(TAG, "onBillingSetupFinished:skuYearly:" + skuYearly?.priceAmountMicros)

            setupUI(SUBSCRIPTION_ONE_YEAR)
        }
    }

    override fun onBillingKeyNotFound(productId: String) {

    }

}