package com.mediaplayer.video.player.videoplayer.music.common.rateandfeedback

import android.app.Activity
import com.mediaplayer.video.player.videoplayer.music.common.rateandfeedback.library_feedback.sendEmail


const val rateDialogCount = 2

fun Activity.displayExitDialog() {
    val sp = ExitSPHelper(this)
    if (!sp.isRated() && sp.getExitCount() >= rateDialogCount && !sp.isDismissed()) {
        ratingDialog(object : OnRateListener {
            override fun onRate(rate: Int) {
                if (rate >= 4) {
                    rateApp()
                } else if (rate >= 0) {
                    sendEmail()
                }
            }
        })
    } else {
        finishAffinity()
    }
}