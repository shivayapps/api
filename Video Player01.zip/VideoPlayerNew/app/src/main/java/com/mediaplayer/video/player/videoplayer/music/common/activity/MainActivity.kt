package com.mediaplayer.video.player.videoplayer.music.common.activity


import android.content.*
import android.content.pm.ActivityInfo
import android.database.Cursor
import android.graphics.drawable.BitmapDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Parcel
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.PopupWindow
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.example.app.ads.helper.InterstitialAdHelper
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.adsHelper.*
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.fragment.SettingMainFragment
import com.mediaplayer.video.player.videoplayer.music.common.fragment.ThemeMainFragment
import com.mediaplayer.video.player.videoplayer.music.common.gallery.entity.Album
import com.mediaplayer.video.player.videoplayer.music.common.gallery.entity.Item
import com.mediaplayer.video.player.videoplayer.music.common.gallery.entity.SelectionSpec
import com.mediaplayer.video.player.videoplayer.music.common.gallery.model.AlbumMediaCollection
import com.mediaplayer.video.player.videoplayer.music.common.gallery.utils.MimeType
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.*
import com.mediaplayer.video.player.videoplayer.music.common.rateandfeedback.library_feedback.sendEmail
import com.mediaplayer.video.player.videoplayer.music.common.utils.*
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant.Companion.LOCK
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant.Companion.LOCK_FRAGMENT_TAG
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant.Companion.MUSIC
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant.Companion.MUSIC_FRAGMENT_TAG
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant.Companion.SETTING
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant.Companion.SETTING_FRAGMENT_TAG
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant.Companion.THEME
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant.Companion.THEME_FRAGMENT_TAG
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant.Companion.VIDEO
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant.Companion.VIDEO_FRAGMENT_TAG
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityMainBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.*
import com.mediaplayer.video.player.videoplayer.music.musicplayer.activities.MusicSearchActivity
import com.mediaplayer.video.player.videoplayer.music.musicplayer.db.toPlayCount
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.dip
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.extra
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragment.MusicMainFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.AlbumCoverStyle
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.LibraryViewModel
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.NowPlayingScreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.mediaplayer.video.player.videoplayer.music.musicplayer.service.MusicService
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil
import com.mediaplayer.video.player.videoplayer.music.videoplayer.activity.VideoSearchActivity
import com.mediaplayer.video.player.videoplayer.music.videoplayer.fragment.LockFragment
import com.mediaplayer.video.player.videoplayer.music.videoplayer.fragment.VideoMainFragment
import com.mediaplayer.video.player.videoplayer.music.videoplayer.model.VideoData
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.lang.ref.WeakReference
import java.util.*


class MainActivity() : BaseBindingActivity<ActivityMainBinding>(),SharedPreferences.OnSharedPreferenceChangeListener,
    ProductPurchaseHelper.ProductPurchaseListener {
    companion object {
        const val TAG = "MainActivity"
        const val EXPAND_PANEL = "expand_panel"
    }

    private var lExitDialog: ExitDialogWithNativeAd? = null
    private var lExitDialogNew: ExitDialogWithNativeAdNew? = null
    private var mVideoDataList : ArrayList<VideoData> = ArrayList()
    private val fm = supportFragmentManager
    private val videoMainFragment : Fragment = VideoMainFragment.newInstance()
    private val musicMainFragment : Fragment = MusicMainFragment.newInstance()
    private val themeMainFragment : Fragment = ThemeMainFragment.newInstance()
    private val settingMainFragment : Fragment = SettingMainFragment.newInstance()
    private val lockMainFragment : Fragment = LockFragment.newInstance()
    private var activeFragment = videoMainFragment
    var isneedtoShaow = false
    protected val libraryViewModel by viewModel<LibraryViewModel>()


    constructor(parcel: Parcel) : this() {
        receiverRegistered = parcel.readByte() != 0.toByte()
    }

    override fun getActivityContext(): FragmentActivity {
       return this@MainActivity
    }

    override fun setBinding(): ActivityMainBinding {
        return ActivityMainBinding.inflate(layoutInflater)
    }
    override fun initAds() {
        super.initAds()
//        NativeAdvancedModelHelper.destroy()
        if (AdsManager(mActivity).isNeedToShowAds() && isOnline) {
//            GiftIconHelper.loadGiftAd(mActivity, main_la_gift, main_la_gift_blast)
            InterstitialAdHelper.loadInterstitialAd(mActivity)
        }

    }

    override fun initViewAction() {
        super.initViewAction()
// Dynamic Links will start with https://fuunly.com
//"appAssociation": "AUTO",
//"rewrites": [ { "source": "/**", "dynamicLinks": true } ]
        //https://assets-1.entertainvideo.com/assets/video/enc/2a466887c80c5ee9473b2fcc3476596a.mp4#Intent;action=com.young.simple.player.playback_online;package=com.young.simple.player;b.decode_mode=2;S.mx_stream_url=https%3A%2F%2Fassets-1.entertainvideo.com%2Fassets%2Fvideo%2Fenc%2F2a466887c80c5ee9473b2fcc3476596a.mp4;S.download_url=https%3A%2F%2Fassets-1.entertainvideo.com%2Fassets%2Fvideo%2Fenc%2F2a466887c80c5ee9473b2fcc3476596a.mp4;S.id=8c09a90421c3232e6f94e52e8c40c74daa67c2d87e57;S.title=Surya%20The%20Soldier%20(20***)%20Hindi%20720p%20Bluray%20%C3%97264%20AAC;l.total_size=1534025345;S.tr_parameter=%7B%22fromuser%22%3A%22612139148%22%2C%22video%22%3A%228c09a90421c3232e6f94e52e8c40c74daa67c2d87e57%22%2C%22source%22%3A%22telegram_bot%22%2C%22duration%22%3A9941%2C%22domain%22%3A%22assets-1.entertainvideo.com%22%7D;end
       // val link = "https://tokitokiplayer.page.link/stream_url=https://assets-1.entertainvideo.com/assets/media/b4804a11fd9810942e581cbaab2941b7/dash/04a1a92621ea950984b02fc48b362a45.mpd"
          //  buildDeepLink(Uri.parse(link))

//
        if (AdsManager(mActivity).isNeedToShowAds()) {

            val nowPlayingScreen = PreferenceUtil.nowPlayingScreen

            val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
            val fid: Int = when (nowPlayingScreen.id) {
                NowPlayingScreen.Normal.id -> nowPlayingScreen.id
                NowPlayingScreen.Material.id -> nowPlayingScreen.id
                NowPlayingScreen.Gradient.id -> nowPlayingScreen.id
                NowPlayingScreen.Flat.id -> nowPlayingScreen.id
                NowPlayingScreen.Fit.id -> nowPlayingScreen.id
                NowPlayingScreen.Classic.id -> nowPlayingScreen.id
                NowPlayingScreen.Peek.id -> nowPlayingScreen.id
                NowPlayingScreen.Tiny.id -> nowPlayingScreen.id
                else -> {
                    0
                }
            }
            val albumtheme = PreferenceUtil.albumCoverStyle
            val aid : Int = when(albumtheme.id)
            {
                AlbumCoverStyle.Normal.id -> albumtheme.id
                AlbumCoverStyle.Full.id -> albumtheme.id
                AlbumCoverStyle.Flat.id -> albumtheme.id
                else -> {
                    0
                }
            }
            edit.putInt(NOW_PLAYING_SCREEN_ID, fid)
            edit.putInt(ALBUM_COVER_STYLE, aid)
            edit.apply()

        }
    }

    override fun initView() {
        super.initView()
        EventBus.getDefault().register(this)
        PreferenceUtil.registerOnSharedPreferenceChangedListener(this)
        if (PreferenceUtil.isFullScreenMode) {
           setDrawBehindSystemBars()
        }
        else{
            setImmersiveFullscreen()
        }
        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(IMAGE_THEME,"")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(GENERAL_THEME,"")
        Log.e(TAG, "initView: ${edit}")

            if (editors == "theme_one")
            {
                mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_one)
            }
            else if (editors == "theme_two")
            {

                mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_two)
            }
            else if (edit == "light" || edit == "dark")
            {
                mBinding.root.background = null
            }

        serviceToken = MusicPlayerRemote.bindToService(this, object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, service: IBinder) {
                onServiceConnected()
            }

            override fun onServiceDisconnected(name: ComponentName) {
                onServiceDisconnected()
            }
        })

        setUpViewPager()
        Handler().postDelayed({
            getVideo()
        },1000)

        try {
            NetworkChangeModel.getInstance().setListener(mActivity) { fIsConnected: Boolean ->

                if (videoMainFragment != null)
                {
                    (videoMainFragment as VideoMainFragment).onConnection(fIsConnected)
                }
            }
        }catch(e : Exception)
        { }
    }

    override fun initViewListener() {
        super.initViewListener()

        mBinding.clVideo.setOnClickListener(this)
        mBinding.clMusic.setOnClickListener(this)
        mBinding.clTheme.setOnClickListener(this)
        mBinding.clSetting.setOnClickListener(this)
        mBinding.clLock.setOnClickListener(this)
        mBinding.ivSearch.setOnClickListener(this)
        mBinding.ivOptions.setOnClickListener(this)
        mBinding.ivSubPro.setOnClickListener(this)
        initBilling()
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when(v.id)
        {
            R.id.clVideo ->
            {
                if (activeFragment.tag != VIDEO_FRAGMENT_TAG )
                {
                    bottomBarText(VIDEO)
                    fm.beginTransaction().setCustomAnimations(android.R.anim.fade_in,android.R.anim.fade_out).hide(activeFragment).show(videoMainFragment).commit()
                    activeFragment = videoMainFragment
                    mBinding.tvFmName.text = getString(R.string.video)
                    mBinding.ivOptions.visibility = View.VISIBLE
                    if (AdsManager(mActivity).isNeedToShowAds())
                    {
                        mBinding.ivSubPro.visibility = View.VISIBLE
                    }
                    else{
                        mBinding.ivSubPro.visibility = View.GONE
                    }
                    mBinding.ivSearch.visibility = View.VISIBLE
                    mBinding.clGiftIcon.visibility = View.GONE

                }
            }
            R.id.clMusic ->
            {
                if (activeFragment.tag != MUSIC_FRAGMENT_TAG )
                {
                    bottomBarText(MUSIC)
                    fm.beginTransaction().setCustomAnimations(android.R.anim.fade_in,android.R.anim.fade_out).hide(activeFragment).show(musicMainFragment).commit()
                    activeFragment = musicMainFragment
                    mBinding.tvFmName.text = getString(R.string.music)
                    mBinding.ivOptions.visibility = View.VISIBLE
                    if (AdsManager(mActivity).isNeedToShowAds())
                    {
                        mBinding.ivSubPro.visibility = View.VISIBLE
                    }
                    else{
                        mBinding.ivSubPro.visibility = View.GONE
                    }
                    mBinding.ivSearch.visibility = View.VISIBLE
                    mBinding.clGiftIcon.visibility = View.GONE

                }
            }
            R.id.clTheme ->
            {
                if (activeFragment.tag != THEME_FRAGMENT_TAG )
                {
                    bottomBarText(THEME)
                    fm.beginTransaction().setCustomAnimations(android.R.anim.fade_in,android.R.anim.fade_out).hide(activeFragment).show(themeMainFragment).commit()
                    activeFragment = themeMainFragment
                    mBinding.tvFmName.text = getString(R.string.theme)
                    mBinding.ivOptions.visibility = View.GONE
                    if (AdsManager(mActivity).isNeedToShowAds())
                    {
                        mBinding.ivSubPro.visibility = View.VISIBLE
                    }
                    else{
                        mBinding.ivSubPro.visibility = View.GONE
                    }
                    mBinding.ivSearch.visibility = View.GONE
                    if (AdsManager(mActivity).isNeedToShowAds())
                    {
                        mBinding.clGiftIcon.visibility = View.VISIBLE
                    }
                    else{
                        mBinding.clGiftIcon.visibility = View.GONE
                    }

                }
            }
            R.id.clLock ->
            {
                if (activeFragment.tag != LOCK_FRAGMENT_TAG )
                {
                    bottomBarText(LOCK)

                    fm.beginTransaction().setCustomAnimations(android.R.anim.fade_in,android.R.anim.fade_out).hide(activeFragment).show(lockMainFragment).commit()
                    activeFragment = lockMainFragment
                    mBinding.tvFmName.text = "Vault"
                    mBinding.ivOptions.visibility = View.GONE
                    if (AdsManager(mActivity).isNeedToShowAds())
                    {
                        mBinding.ivSubPro.visibility = View.VISIBLE
                    }
                    else{
                        mBinding.ivSubPro.visibility = View.GONE
                    }
                    mBinding.ivSearch.visibility = View.GONE
                    if (AdsManager(mActivity).isNeedToShowAds())
                    {
                        mBinding.clGiftIcon.visibility = View.VISIBLE
                    }
                    else{
                        mBinding.clGiftIcon.visibility = View.GONE
                    }

                }
            }
            R.id.clSetting ->
            {
                if (activeFragment.tag != SETTING_FRAGMENT_TAG )
                {
                    bottomBarText(SETTING)
                    fm.beginTransaction().setCustomAnimations(android.R.anim.fade_in,android.R.anim.fade_out).hide(activeFragment).show(settingMainFragment).commit()
                    activeFragment = settingMainFragment
                    mBinding.tvFmName.text = "Settings"
                    mBinding.ivOptions.visibility = View.GONE
                    mBinding.ivSubPro.visibility = View.GONE
                    mBinding.ivSearch.visibility = View.GONE
                    if (AdsManager(mActivity).isNeedToShowAds())
                    {
                        mBinding.clGiftIcon.visibility = View.VISIBLE
                    }
                    else{
                        mBinding.clGiftIcon.visibility = View.GONE
                    }
                }
            }

            R.id.iv_search ->
            {

                if (activeFragment.tag == VIDEO_FRAGMENT_TAG) {

                    VideoSearchActivity.mVideoData.removeAll(VideoSearchActivity.mVideoData)
                    VideoSearchActivity.mVideoData.addAll(mVideoDataList)
                    val intent = Intent(mActivity, VideoSearchActivity::class.java)
                    launchActivity(intent)
                }
                else if (activeFragment.tag == MUSIC_FRAGMENT_TAG)
                {
                    val intent = Intent(mActivity, MusicSearchActivity::class.java)
                    launchActivity(intent)
                }

            }
            R.id.iv_options ->
            {
                showStatusPopup()
            }
            R.id.iv_sub_pro ->
            {
                val intent = Intent(mActivity,SubscriptionActivity::class.java)
                launchActivityForResult(intent,123)
            }

        }
    }

    private fun initBilling() {
        try {
            ProductPurchaseHelper.setSubscriptionKey(
                SUBSCRIPTION_ONE_WEEK,
                SUBSCRIPTION_SIX_MONTH,
                SUBSCRIPTION_ONE_YEAR
            )
            ProductPurchaseHelper.initBillingClient(this@MainActivity, this)
        } catch (e: Exception) {

        }
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)

        if (requestCode == 123 && resultCode == RESULT_OK)
        {
            callActivity()
        }

    }

    override fun onResume() {
        super.onResume()
        if (!AdsManager(mActivity).isNeedToShowAds())
            {
            mBinding.ivSubPro.visibility = View.GONE
            mBinding.clGiftIcon.visibility = View.GONE
        }
    }

    private fun setUpViewPager(){

        fm.beginTransaction().add(R.id.fm_main, videoMainFragment, VIDEO_FRAGMENT_TAG).commit()
        fm.beginTransaction().add(R.id.fm_main, musicMainFragment, MUSIC_FRAGMENT_TAG).hide(musicMainFragment).commit()
        fm.beginTransaction().add(R.id.fm_main, themeMainFragment, THEME_FRAGMENT_TAG).hide(themeMainFragment).commit()
        fm.beginTransaction().add(R.id.fm_main, lockMainFragment, LOCK_FRAGMENT_TAG).hide(lockMainFragment).commit()
        fm.beginTransaction().add(R.id.fm_main, settingMainFragment, SETTING_FRAGMENT_TAG).hide(settingMainFragment).commit()

        mBinding.clVideo.performClick()

    }

    private fun bottomBarText(name : String)
    {
        when (name) {
            VIDEO -> {
                mBinding.imgHome.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_video_select))
                mBinding.tvHome.setTextColor(ContextCompat.getColor(mActivity, R.color.select_text_color))
                mBinding.imgMusic.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_music))
                mBinding.tvMusic.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgTheme.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_themes))
                mBinding.tvTheme.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgLock.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_hide_lock))
                mBinding.tvLock.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgSetting.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_settings))
                mBinding.tvSetting.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
            }
            MUSIC -> {
                mBinding.imgHome.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_video_d))
                mBinding.tvHome.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgMusic.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_music_select))
                mBinding.tvMusic.setTextColor(ContextCompat.getColor(mActivity, R.color.select_text_color))
                mBinding.imgTheme.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_themes))
                mBinding.tvTheme.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgLock.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_hide_lock))
                mBinding.tvLock.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgSetting.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_settings))
                mBinding.tvSetting.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
            }
            THEME -> {
                mBinding.imgHome.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_video_d))
                mBinding.tvHome.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgMusic.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_music))
                mBinding.tvMusic.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgTheme.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_themes_select))
                mBinding.tvTheme.setTextColor(ContextCompat.getColor(mActivity, R.color.select_text_color))
                mBinding.imgLock.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_hide_lock))
                mBinding.tvLock.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgSetting.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_settings))
                mBinding.tvSetting.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
            }
            LOCK -> {
                mBinding.imgHome.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_video_d))
                mBinding.tvHome.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgMusic.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_music))
                mBinding.tvMusic.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgTheme.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_themes))
                mBinding.tvTheme.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgLock.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_hide_lock_sel))
                mBinding.tvLock.setTextColor(ContextCompat.getColor(mActivity, R.color.select_text_color))
                mBinding.imgSetting.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_settings))
                mBinding.tvSetting.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
            }
            SETTING -> {
                mBinding.imgHome.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_video_d))
                mBinding.tvHome.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgMusic.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_music))
                mBinding.tvMusic.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgTheme.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_themes))
                mBinding.tvTheme.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgLock.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_hide_lock))
                mBinding.tvLock.setTextColor(ContextCompat.getColor(mActivity, R.color.text_color))
                mBinding.imgSetting.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_settings_select))
                mBinding.tvSetting.setTextColor(ContextCompat.getColor(mActivity, R.color.select_text_color))
            }
        }
    }

    private fun showStatusPopup() {

        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val layout: View = inflater.inflate(R.layout.option_popup_layout, null)

        val pw : PopupWindow = PopupWindow(mActivity)
        pw.contentView = layout
        pw.width = LinearLayout.LayoutParams.WRAP_CONTENT
        pw.height = LinearLayout.LayoutParams.WRAP_CONTENT
        pw.setBackgroundDrawable(BitmapDrawable())
        pw.isOutsideTouchable = true
        pw.showAsDropDown(mBinding.ivOptions)

        val printDocument = layout.findViewById<LinearLayout>(R.id.printdocument)
        val rename = layout.findViewById<LinearLayout>(R.id.rename)

        printDocument.setOnClickListener {
            getVideo()
            pw.dismiss()
        }
        rename.setOnClickListener {
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "text/*"
            intent.putExtra(Intent.EXTRA_TEXT, getString(R.string.share_msg))
            startActivity(Intent.createChooser(intent,"Share App"))
            pw.dismiss()
        }
    }

    override fun onBackPressed() {

        val editor = PreferenceManager.getDefaultSharedPreferences(App.getContext())
        if (editor.getInt(RATE_COUNT, 0) >= 5) {
            if (!isneedtoShaow) {
                if (editor.getString(RATE_,"")!!.isEmpty())
                {
                    editor.edit().putInt(RATE_COUNT,0).apply()
                    mActivity.ratingDialog(object : OnRateListener{
                        override fun onRate(rate: Int) {

                            if(rate > 0){
                                if (rate > 3) {
                                    rateApp()
                                } else {
                                    sendEmail()
                                }
                            }
                        }
                    })
                    isneedtoShaow = true
                }
                else {
                    if (!mActivity.isFinishing)
                    {
                        if (isOnline && AdsManager(mActivity).isNeedToShowAds())
                        {
                            showExitDialogNew()
                        }
                        else {
                            showExitDialog()
                        }
                    }
                }
            }
            else {
                if (!mActivity.isFinishing) {
                    if (isOnline && AdsManager(mActivity).isNeedToShowAds())
                    {
                        showExitDialogNew()
                    }
                    else {
                        showExitDialog()
                    }
                }
            }
        }
        else{
            if (!mActivity.isFinishing) {
                if (isOnline && AdsManager(mActivity).isNeedToShowAds())
                {
                    showExitDialogNew()
                }
                else {
                    showExitDialog()
                }
            }
        }

    }

    private fun showExitDialog() {
        lExitDialog = ExitDialogWithNativeAd(this)
        lExitDialog!!.show()
    }

    private fun showExitDialogNew() {
        lExitDialogNew = ExitDialogWithNativeAdNew(this)
        lExitDialogNew!!.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        PreferenceUtil.unregisterOnSharedPreferenceChangedListener(this)
        if (receiverRegistered) {
            unregisterReceiver(musicStateReceiver)
            receiverRegistered = false
        }

    }

    private fun getVideo()
    {

        val mSelectionSpec = SelectionSpec.getCleanInstance()
        mSelectionSpec.mimeTypeSet = MimeType.ofVideo()
        mSelectionSpec.mediaTypeExclusive = true
        mSelectionSpec.maxSelectable = 5
        mSelectionSpec.showPreview = false
        mSelectionSpec.showSingleMediaType = true
        mSelectionSpec.orientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val mAlbumMediaCollection = AlbumMediaCollection()

        mAlbumMediaCollection.onCreate(this, object : AlbumMediaCollection.AlbumMediaCallbacks {
            override fun onAlbumMediaLoad(cursor: Cursor?) {

                mVideoDataList.removeAll(mVideoDataList)

                asyncBackgroundWork({

                },{
                    if (cursor != null && cursor.count >0) {
                        cursor.moveToFirst()
                        do {

                            val item = Item.valueOf(cursor)
                            if (item.bucketName != null && item.name != null) {
                                val video = VideoData(
                                    item.path,
                                    item.bucketName,
                                    item.name,
                                    item.date * 1000,
                                    item.mimeType ?: "mp4",
                                    item.size,
                                    item.duration,
                                    item.width,
                                    item.height
                                )
                                mVideoDataList.add(video)
                            } else {
                                val video = VideoData(
                                    item.path,
                                    "Internal",
                                    "Empty",
                                    item.date * 1000,
                                    item.mimeType ?: "mp4",
                                    item.size,
                                    item.duration,
                                    item.width,
                                    item.height
                                )
                                mVideoDataList.add(video)
                            }


                        } while (cursor.moveToNext())
                    }

                },{
                    mAlbumMediaCollection.onDestroy()
                   (videoMainFragment as VideoMainFragment).setVideo(mVideoDataList)

                })

            }

            override fun onAlbumMediaReset() {
            }

        })
        mAlbumMediaCollection.load(Album(Album.ALBUM_ID_ALL, null, Album.ALBUM_ID_ALL, 0), mSelectionSpec.capture)

    }

    override fun onServiceConnected() {
        if (!receiverRegistered) {
            musicStateReceiver = MusicStateReceiver(this)

            val filter = IntentFilter()
            filter.addAction(MusicService.PLAY_STATE_CHANGED)
            filter.addAction(MusicService.SHUFFLE_MODE_CHANGED)
            filter.addAction(MusicService.REPEAT_MODE_CHANGED)
            filter.addAction(MusicService.META_CHANGED)
            filter.addAction(MusicService.QUEUE_CHANGED)
            filter.addAction(MusicService.MEDIA_STORE_CHANGED)
            filter.addAction(MusicService.FAVORITE_STATE_CHANGED)

            registerReceiver(musicStateReceiver, filter)

            receiverRegistered = true
        }

        for (listener in mMusicServiceEventListeners) {
            listener.onServiceConnected()
        }


            if (MusicPlayerRemote.playingQueue.isNotEmpty()) {

                (musicMainFragment as MusicMainFragment).hideBottomSheet(false)
                (musicMainFragment as MusicMainFragment).getBottomSheetBehavior().setAllowDragging(false)
                (musicMainFragment as MusicMainFragment).getBottomSheetBehavior().isDraggable = false

            }
            else
            {
                (musicMainFragment as MusicMainFragment).getBottomSheetBehavior().setAllowDragging(false)
                (musicMainFragment as MusicMainFragment).getBottomSheetBehavior().isDraggable = false
            }
    }


    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        PreferenceUtil.registerOnSharedPreferenceChangedListener(this)
        val expand = intent?.extra<Boolean>(EXPAND_PANEL)?.value ?: false

        if (expand && PreferenceUtil.isExpandPanel) {

            intent?.removeExtra(EXPAND_PANEL)

        }
    }

    fun callActivity()
    {
        AppConstant.LAYOUT_TYPE = 0
        val intent : Intent = intent
        launchActivity(intent)
        finishAffinity()
    }

    var musicStateReceiver: MusicStateReceiver? = null

    class MusicStateReceiver(activity: MainActivity) : BroadcastReceiver() {

        val reference: WeakReference<MainActivity> = WeakReference(activity)

        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            val activity = reference.get()
            if (activity != null && action != null) {
                when (action) {
                    MusicService.FAVORITE_STATE_CHANGED -> activity.onFavoriteStateChanged()
                    MusicService.META_CHANGED -> activity.onPlayingMetaChanged()
                    MusicService.QUEUE_CHANGED -> activity.onQueueChanged()
                    MusicService.PLAY_STATE_CHANGED -> activity.onPlayStateChanged()
                    MusicService.REPEAT_MODE_CHANGED -> activity.onRepeatModeChanged()
                    MusicService.SHUFFLE_MODE_CHANGED -> activity.onShuffleModeChanged()
                    MusicService.MEDIA_STORE_CHANGED -> activity.onMediaStoreChanged()
                }
            }
        }
    }


    override fun onServiceDisconnected() {
        if (receiverRegistered) {
            unregisterReceiver(musicStateReceiver)
            receiverRegistered = false
        }

        for (listener in mMusicServiceEventListeners) {
            listener.onServiceDisconnected()
        }
    }

    override fun onQueueChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onQueueChanged()
        }

        libraryViewModel.setFabMargin(dip(R.dimen.mini_cast_player_height_expanded))
        (musicMainFragment as MusicMainFragment).hideBottomSheet(MusicPlayerRemote.playingQueue.isEmpty())

    }

    override fun onPlayingMetaChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onPlayingMetaChanged()
        }
        lifecycleScope.launch(Dispatchers.IO) {
            val entity = repository.songPresentInHistory(MusicPlayerRemote.currentSong)
            if (entity != null) {
                repository.updateHistorySong(MusicPlayerRemote.currentSong)
            } else {
                repository.addSongToHistory(MusicPlayerRemote.currentSong)
            }
            val songs = repository.checkSongExistInPlayCount(MusicPlayerRemote.currentSong.id)
            if (songs.isNotEmpty()) {
                repository.updateSongInPlayCount(songs.first().apply {
                    playCount += 1
                })
            } else {
                repository.insertSongInPlayCount(MusicPlayerRemote.currentSong.toPlayCount())
            }
        }
    }

    override fun onPlayStateChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onPlayStateChanged()
        }
    }

    override fun onRepeatModeChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onRepeatModeChanged()
        }
    }

    override fun onShuffleModeChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onShuffleModeChanged()
        }
    }

    override fun onFavoriteStateChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onFavoriteStateChanged()
        }
    }

    override fun onMediaStoreChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onMediaStoreChanged()
        }
    }

    override fun onSharedPreferenceChanged(p0: SharedPreferences?, key: String?) {
        if ( key == MATERIAL_YOU || key == WALLPAPER_ACCENT || key == BLACK_THEME || key == ADAPTIVE_COLOR_APP || key == USER_NAME || key == TOGGLE_FULL_SCREEN || key == TOGGLE_VOLUME || key == ROUND_CORNERS || key == CAROUSEL_EFFECT || key == TOGGLE_GENRE || key == BANNER_IMAGE_PATH || key == PROFILE_IMAGE_PATH || key == CIRCULAR_ALBUM_ART || key == KEEP_SCREEN_ON || key == TOGGLE_SEPARATE_LINE || key == TOGGLE_HOME_BANNER || key == TOGGLE_ADD_CONTROLS  || key == HOME_ARTIST_GRID_STYLE || key == ALBUM_COVER_TRANSFORM || key == DESATURATED_COLOR || key == EXTRA_SONG_INFO || key == TAB_TEXT_MODE || key == LANGUAGE_NAME || key == LIBRARY_CATEGORIES || key == CUSTOM_FONT || key == APPBAR_MODE || key == CIRCLE_PLAY_BUTTON) {
           postRecreate()
        }
    }

    @Subscribe
    fun OnEvent(str: String?) {
        when (str) {
            "getVideo" -> {
                getVideo()
            }
        }
    }

    override fun onPurchasedExpired(productType: String) {

    }

    override fun onPurchasedSuccess(purchase: Purchase) {
    }

    override fun onPurchasedFound(productType: String, purchaseList: MutableList<Purchase>?) {
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        Log.e(TAG, "onBillingSetupFinished:InAppActivity:" + billingResult.responseCode)
        Log.e(TAG, "onBillingSetupFinished:InAppActivity:" + billingResult.debugMessage)
        ProductPurchaseHelper.initSubscriptionKeys(this@MainActivity) {
            ProductPurchaseHelper.getProductInfo(SUBSCRIPTION_ONE_WEEK)
            ProductPurchaseHelper.getProductInfo(SUBSCRIPTION_SIX_MONTH)
            ProductPurchaseHelper.getProductInfo(SUBSCRIPTION_ONE_YEAR)
        }
    }


    override fun onBillingKeyNotFound(productId: String) {
    }
}