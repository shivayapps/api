package com.mediaplayer.video.player.videoplayer.music.common.database

import java.io.Serializable


data class HideFolder(var name: String = "", var path: String = "", var videoList : ArrayList<HideVideo> = ArrayList()) : Serializable
