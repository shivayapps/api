package com.mediaplayer.video.player.videoplayer.music.common.utils

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel

class ThemeListViewModel : ViewModel() {

    private val _index = MutableLiveData<Int>()
    private val _imageDrawable = MutableLiveData<Int>()


    val text: LiveData<String> = Transformations.map(_index) {
        "Hello world from section: $it"
    }

    val imageDrawable: LiveData<Int> = Transformations.map(_imageDrawable) {
        it
    }

    fun setIndex(index: Int) {
        _index.value = index
    }

    fun setImageDrawable(imageDrawable: Int) {
        _imageDrawable.value = imageDrawable
    }
}