package com.mediaplayer.video.player.videoplayer.music.musicplayer.activities

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.widget.FrameLayout
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.afollestad.materialcab.attached.AttachedCab
import com.afollestad.materialcab.attached.destroy
import com.afollestad.materialcab.attached.isActive
import com.afollestad.materialcab.createCab
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.artistdatabase.ArtistDatabase
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.AdsManager
import com.mediaplayer.video.player.videoplayer.music.common.utils.isOnline

import com.mediaplayer.video.player.videoplayer.music.common.widgets.OnSingleClickListener
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityAlbumDetalitBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App


import com.mediaplayer.video.player.videoplayer.music.musicplayer.EXTRA_ALBUM_ID
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.adapter.album.HorizontalAlbumAdapter
import com.mediaplayer.video.player.videoplayer.music.musicplayer.adapter.song.SimpleSongAdapter
import com.mediaplayer.video.player.videoplayer.music.musicplayer.dialogs.AddToPlaylistDialog
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.*
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.albums.AlbumDetailsViewModel
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.*
import com.mediaplayer.video.player.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces.IAlbumClickListener
import com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces.ICabCallback
import com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces.ICabHolder
import com.mediaplayer.video.player.videoplayer.music.musicplayer.model.Album
import com.mediaplayer.video.player.videoplayer.music.musicplayer.model.Artist
import com.mediaplayer.video.player.videoplayer.music.musicplayer.repository.RealRepository
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.MusicUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.RetroColorUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.color.MediaNotificationProcessor
import kotlinx.android.synthetic.main.activity_album_detalit.*
import kotlinx.android.synthetic.main.fragment_main_recycler.*
import kotlinx.android.synthetic.main.layout_google_native_banner_small_ad_grid.view.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.koin.android.ext.android.get
import org.koin.androidx.viewmodel.ext.android.viewModel
import org.koin.core.parameter.parametersOf

class AlbumDetalitActivity : BaseBindingActivity<ActivityAlbumDetalitBinding>() , IAlbumClickListener, ICabHolder,
    PopupMenu.OnMenuItemClickListener {


    private lateinit var simpleSongAdapter: SimpleSongAdapter
    private lateinit var album: Album
    private var albumArtistExists = false

    private val savedSortOrder: String
        get() = PreferenceUtil.albumDetailSongSortOrder

    override fun initView() {
        super.initView()


        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        }
        else{
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(IMAGE_THEME,"")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            GENERAL_THEME,"")

        if (editors == "theme_one")
        {
            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_one)
        }
        else if (editors == "theme_two")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_two)
        }
        else if (edit == "ligt" || edit == "dark")
        {
            mBinding.root.background = null
        }

        showProgressDialog(mActivity,"Please wait...")

        val id = intent.getLongExtra(EXTRA_ALBUM_ID,0)

        val detailsViewModel by viewModel<AlbumDetailsViewModel> {
            parametersOf(id)
        }

        addMusicServiceEventListener(detailsViewModel)

        detailsViewModel.getAlbum().observe(this) {
            showAlbum(it,detailsViewModel)
        }



        setupRecyclerView()
        setupMenu()

        mBinding.icBack.setOnClickListener(object : OnSingleClickListener(){
            override fun onSingleClick(v: View?) {
                onBackPressed()
            }

        })

        mBinding.fragmentAlbumContent.playAction.setOnClickListener {
            MusicPlayerRemote.openQueue(album.songs, 0, true)
        }
        mBinding.fragmentAlbumContent.shuffleAction.setOnClickListener {
            MusicPlayerRemote.openAndShuffleQueue(
                album.songs,
                true
            )
        }
    }



    override fun getActivityContext(): FragmentActivity {
      return this@AlbumDetalitActivity
    }

    override fun onResume() {
        super.onResume()
        if (AdsManager(mActivity).isNeedToShowAds() && isOnline) {

//            NativeAdvancedModelHelper(mActivity).loadNativeAdvancedAd(NativeAdsSize.Custom,banner_ad as FrameLayout,
//                LayoutInflater.from(mActivity).inflate(R.layout.layout_google_native_banner_small_ad_small, banner_ad as FrameLayout, false))

            NativeAdvancedModelHelper(mActivity).loadNativeAdvancedAd(
                NativeAdsSize.Custom,
                banner_ad as FrameLayout,
                LayoutInflater.from(mActivity).inflate(
                    R.layout.layout_google_native_ad_medium_custom,
                    banner_ad as FrameLayout,
                    false
                ), isAdLoaded = {
                    val name = NativeAdvancedModelHelper.getNativeAd!!.callToAction
                    Log.e("TAG", "populateNativeAdViewTextdghdh: $name", )
                    when {
                        name.equals("Learn More") -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_learn_more))
                        }
                        name.equals("Open") -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_open))

                        }
                        name.equals("Install") -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_install))
                        }
                        name.equals("Download") -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_download))
                        }
                        name.equals("Visit", true) -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_visit))
                        }
                        name.equals("Visit Site", true) -> {

                            banner_ad.iv_folder.setImageDrawable(ContextCompat.getDrawable(mActivity,R.drawable.ic_ads_visit))
                        }
                    }
                }
            )

        }
        else
        {
            banner_ad.visibility = View.GONE
        }
    }

    private fun setupMenu() {
        mBinding.ivOption.setOnClickListener {
            val popupMenu = PopupMenu(mActivity, it)
            popupMenu.setOnMenuItemClickListener(this)
            val menu = popupMenu.menu
            val sortOrder = menu.findItem(R.id.action_sort_order)
            sortOrder.isVisible = false
            val tag = menu.findItem(R.id.action_tag_editor)
            tag.isVisible = false
            popupMenu.inflate(R.menu.menu_album_detail)
            popupMenu.show()
        }
    }


    private fun setupRecyclerView() {
        simpleSongAdapter = SimpleSongAdapter(
           this,
            ArrayList(),
            R.layout.item_song,
            this
        )
        mBinding.fragmentAlbumContent.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@AlbumDetalitActivity)
            itemAnimator = DefaultItemAnimator()
            isNestedScrollingEnabled = false
            adapter = simpleSongAdapter
        }


    }

    private fun showAlbum(album: Album, detailsViewModel: AlbumDetailsViewModel) {

        this.album = album

        mBinding.albumTitle.text = album.title
        val songText = resources.getQuantityString(
            R.plurals.albumSongs,
            album.songCount,
            album.songCount
        )
        mBinding.albumYear.text = MusicUtil.getYearString(album.year)
        mBinding.fragmentAlbumContent.songTitle.text = songText
        if (MusicUtil.getYearString(album.year) == "-") {
            mBinding.albumText.text =   if (albumArtistExists) album.albumArtist else album.artistName

        } else {
            mBinding.albumText.text = album.artistName
        }
        mBinding.albumlength.text = MusicUtil.getReadableDurationString(MusicUtil.getTotalDuration(album.songs))
        loadAlbumCover(album)
        simpleSongAdapter.swapDataSet(album.songs)
        if (albumArtistExists) {
            detailsViewModel.getAlbumArtist(album.albumArtist.toString())
                .observe(this@AlbumDetalitActivity) {
                    loadArtistImage(it,detailsViewModel)
                }
        } else {
            detailsViewModel.getArtist(album.artistId).observe(this) {
                loadArtistImage(it, detailsViewModel)
            }
        }

    }
    private fun loadAlbumCover(album: Album) {
        GlideApp.with(this@AlbumDetalitActivity).asBitmapPalette()
            .albumCoverOptions(album.safeGetFirstSong())
            //.checkIgnoreMediaStore()
            .load(RetroGlideExtension.getSongModel(album.safeGetFirstSong()))
            .into(object : SingleColorTarget(mBinding.image) {
                override fun onColorReady(color: Int) {
                    setColors(color)
                }
            })

        GlideApp.with(this)
            .asBitmapPalette()
            .albumCoverOptions(album.safeGetFirstSong())
            .load(RetroGlideExtension.getSongModel(album.safeGetFirstSong()))
            .transform(BlurTransformation.Builder(this@AlbumDetalitActivity).build())
            .into(object : RetroMusicColoredTarget(mBinding.imgBlur) {
                override fun onColorReady(colors: MediaNotificationProcessor) {
                }
            })


    }

    private fun loadArtistImage(artist: Artist, detailsViewModel: AlbumDetailsViewModel) {
        detailsViewModel.getMoreAlbums(artist).observe(this@AlbumDetalitActivity) {
            moreAlbums(it)
        }
        val artists = artist.name.split(",", "&")
        val m = ArtistDatabase.getInstance(mActivity)
        val image = m.artistDao().getArtist(artists[0])
        if (image != null)
        {
            GlideApp.with(mActivity)
                .asBitmapPalette()
                .load(image.picture)
                .placeholder( R.drawable.default_artist_art)
                .transition(RetroGlideExtension.getDefaultTransition())
                .into(object : SingleColorTarget(mBinding.artistImage) {
                    override fun onColorReady(color: Int) {
                        setColors(color)
                    }
                })
        }
        else
        {
            GlideApp.with(mActivity)
                .asBitmapPalette()
                .load(RetroGlideExtension.getArtistModel(artist))
                .artistImageOptions(artist)
                .transition(RetroGlideExtension.getDefaultTransition())
                .into(object : SingleColorTarget(mBinding.artistImage) {
                    override fun onColorReady(color: Int) {
                        setColors(color)
                    }
                })
        }


    }
    private fun moreAlbums(albums: List<Album>) {
        mBinding.fragmentAlbumContent.moreTitle.show()
        mBinding.fragmentAlbumContent.moreRecyclerView.show()
        mBinding.fragmentAlbumContent.moreTitle.text =
            String.format(getString(R.string.label_more_from), album.artistName)

        val albumAdapter = HorizontalAlbumAdapter(this@AlbumDetalitActivity, albums, this, this)
        mBinding.fragmentAlbumContent.moreRecyclerView.layoutManager = GridLayoutManager(
            this@AlbumDetalitActivity,
            1,
            GridLayoutManager.HORIZONTAL,
            false
        )
        mBinding.fragmentAlbumContent.moreRecyclerView.adapter = albumAdapter

    }

    private fun setColors(color: Int) {
        mBinding.fragmentAlbumContent.apply {
            shuffleAction.applyColor(color)
            playAction.applyOutlineColor(color)
        }
        hideProgressDialog()
    }

    override fun onAlbumClick(albumId: Long, view: View) {
        val intent = Intent(mActivity,AlbumDetalitActivity::class.java)
        intent.putExtra(EXTRA_ALBUM_ID,albumId)
        launchActivity(intent)
    }
    private var cab: AttachedCab? = null
    override fun openCab(menuRes: Int, callback: ICabCallback): AttachedCab {
        cab?.let {
            if (it.isActive()) {
                it.destroy()
            }
        }
        cab = createCab(R.id.toolbar_container) {
            menu(menuRes)
            closeDrawable(R.drawable.ic_close)
            backgroundColor(literal = RetroColorUtil.shiftBackgroundColor(surfaceColor()))
            slideDown()
            onCreate { cab, menu -> callback.onCabCreated(cab, menu) }
            onSelection {
                callback.onCabItemClicked(it)
            }
            onDestroy { callback.onCabFinished(it) }
        }
        return cab as AttachedCab
    }

    override fun setBinding(): ActivityAlbumDetalitBinding {
        return ActivityAlbumDetalitBinding.inflate(layoutInflater)
    }

    override fun onMenuItemClick(item: MenuItem?): Boolean {
        val song = MusicPlayerRemote.currentSong
        when (item!!.itemId)
        {
            R.id.action_add_to_playlist -> {
                lifecycleScope.launch(Dispatchers.IO) {
                    val playlists = get<RealRepository>().fetchPlaylists()
                    withContext(Dispatchers.Main) {
                        AddToPlaylistDialog.create(playlists, song)
                            .show(supportFragmentManager, "ADD_PLAYLIST")
                    }
                }
                return true
            }
        }
        return false
    }
}