package com.mediaplayer.video.player.videoplayer.music.common.activity

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.widget.PopupMenu

import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.DefaultItemAnimator
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.mediaplayer.video.player.videoplayer.music.BuildConfig
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityFavoriteBinding

import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.adapter.FavoriteVideoAdapter
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.database.*
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.AdsManager
import com.mediaplayer.video.player.videoplayer.music.common.utils.*

import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil
import com.mediaplayer.video.player.videoplayer.music.videoplayer.activity.VideoSearchActivity
import com.mediaplayer.video.player.videoplayer.music.videoplayer.adapter.AddPlaylistAdapter
import com.mediaplayer.video.player.videoplayer.music.videoplayer.model.VideoData
import com.mediaplayer.video.player.videoplayer.music.videoplayer.player.PlayerActivity
import kotlinx.android.synthetic.main.add_playlist_dialog.*
import kotlinx.android.synthetic.main.file_info_dialog.*
import kotlinx.android.synthetic.main.remove_playlist_dialog.*
import org.greenrobot.eventbus.EventBus
import org.jetbrains.anko.toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class FavoriteActivity : BaseBindingActivity<ActivityFavoriteBinding>() {

    private lateinit var mVideoAdapter: FavoriteVideoAdapter
    private lateinit var mDB : VideoPlayerDatabase
    private var mVideoData : ArrayList<VideoData> = java.util.ArrayList()

    private var mVideoDataList : java.util.ArrayList<FavoriteVideo> = java.util.ArrayList()

    private var mVideoDataFav: java.util.ArrayList<FavoriteVideo> = java.util.ArrayList()

    private lateinit var mPlayListVideoAdapter: AddPlaylistAdapter

    override fun getActivityContext(): FragmentActivity {
       return this@FavoriteActivity
    }

    override fun setBinding(): ActivityFavoriteBinding {
        return ActivityFavoriteBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        }
        else{
            setImmersiveFullscreen()
        }
        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME,"")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            GENERAL_THEME,"")

        if (editors == "theme_one")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_one)
        }
        else if (editors == "theme_two")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_two)
        }
        else if (edit == "ligt" || edit == "dark")
        {
            mBinding.root.background = null
        }

        mDB = VideoPlayerDatabase.getInstance(mActivity)

    }

    override fun initViewAction() {
        super.initViewAction()

        mDB.favoriteVideoDao().getFavoriteVideoLive().observe(mActivity) { mList ->

            if (mList.isEmpty()) {
                mVideoData.removeAll(mVideoData)
                mBinding.conEmptyView.visibility = View.VISIBLE
                mBinding.rvFavorite.visibility = View.GONE
            } else {
                mVideoDataFav.removeAll(mVideoDataFav)
                mVideoDataFav.addAll(mList)
                mVideoDataList.removeAll(mVideoDataList)
                mVideoDataList.addAll(mList)
                mBinding.conEmptyView.visibility = View.GONE
                mBinding.rvFavorite.visibility = View.VISIBLE

                val lSize = (mVideoDataList.size - 2)
                val adSize = (lSize / 9)

                val finalAdSize = (mVideoDataList.size + (adSize + 1))
                val posList: ArrayList<Int> = ArrayList()

                for (position in 0..finalAdSize) {
                    if (((position == 2) || (position > 3 && ((position - 2) % 9) == 0))) {
                        if (!posList.contains(position)) {
                            posList.add(position)
                        }
                    }
                }
                for (pos in posList) {
                    if (mVideoDataList.size > 1)
                        mVideoDataList.add(pos, FavoriteVideo(null, "", "", "", 0, "", 0, 0, 0, 0))
                }

                if (mVideoDataList[mVideoDataList.size - 1].path.isEmpty()) {
                    mVideoDataList.removeAt(mVideoDataList.size - 1)
                }

                mVideoAdapter = FavoriteVideoAdapter(
                    mActivity,
                    mVideoDataList,
                    this,
                    AppConstant.TYPE_VIDEO_LIST
                )
                mBinding.rvFavorite.run {
                    adapter = mVideoAdapter
                    itemAnimator = DefaultItemAnimator()
                }

                while (mBinding.rvFavorite.itemDecorationCount > 0) {
                    mBinding.rvFavorite.removeItemDecorationAt(0)
                }
                mBinding.rvFavorite.addItemDecoration(ItemOffsetDecoration(mActivity, R.dimen._2sdp)
                )

                mVideoData.removeAll(mVideoData)

                for (data in mList) {

                    mVideoData.add(
                        VideoData(
                            data.path,
                            data.bucketName,
                            data.name,
                            data.date,
                            data.type,
                            data.size,
                            data.duration,
                            data.width,
                            data.height
                        )
                    )
                }
            }


        }
    }

    override fun initAds() {
        super.initAds()
        if (AdsManager(mActivity).isNeedToShowAds() )
        {
            InterstitialAdHelper.loadInterstitialAd(mActivity)
        }

    }

    override fun initViewListener() {
        super.initViewListener()

        mBinding.ivSearch.setOnClickListener(this)
        mBinding.ivBack.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when(v.id)
        {
            R.id.iv_all_option ->
            {
                val pos = v.tag as Int
                val data = getRecyclerVideoPlaylistData(v.getTag(R.id.TYPE).toString(), pos)
                getMenu(v,data)

            }
            R.id.con_main ->
            {
                AppConstant.ADS_CLICK += 1
                if (AdsManager(mActivity).isNeedToShowAds() && isOnline && AppConstant.ADS_CLICK %2 != 0) {
                    isShowInterstitialAd {

                        val position = v.tag as Int

                        val posistion = mVideoDataFav.indexOf(mVideoAdapter.getItem(position))

                        val data =
                            getRecyclerVideoPlaylistData(v.getTag(R.id.TYPE).toString(), posistion)
                        if (PlayerActivity.mActivity != null) {
                            PlayerActivity.mActivity.finish()
                        }
                        PlayerActivity.mVideoData.removeAll(PlayerActivity.mVideoData)
                        PlayerActivity.mVideoData.addAll(mVideoData)
                        val intent = Intent(mActivity, PlayerActivity::class.java)
                        intent.putExtra(AppConstant.POSITION, posistion)
                        launchActivity(intent)

                        val db = VideoPlayerDatabase.getInstance(mActivity)
                        val contain = db!!.recentVideoDao()!!.isRecentVideo(data.path)

                        if (contain == 0) {

                            val bookmark = RecentVideo(
                                null,
                                data.path,
                                data.bucketName,
                                data.name,
                                data.date,
                                data.type,
                                data.size,
                                data.duration,
                                data.width,
                                data.height
                            )
                            db.recentVideoDao()!!.insertRecentVideo(bookmark)

                        } else {
                            db.recentVideoDao().deleteRecentVideo(data.path)
                            val bookmark = RecentVideo(
                                null,
                                data.path,
                                data.bucketName,
                                data.name,
                                data.date,
                                data.type,
                                data.size,
                                data.duration,
                                data.width,
                                data.height
                            )
                            db.recentVideoDao()!!.insertRecentVideo(bookmark)
                        }
                    }
                }
                else
                {
                    val position = v.tag as Int

                    val posistion = mVideoDataFav.indexOf(mVideoAdapter.getItem(position))

                    val data =
                        getRecyclerVideoPlaylistData(v.getTag(R.id.TYPE).toString(), posistion)
                    if (PlayerActivity.mActivity != null) {
                        PlayerActivity.mActivity.finish()
                    }
                    PlayerActivity.mVideoData.removeAll(PlayerActivity.mVideoData)
                    PlayerActivity.mVideoData.addAll(mVideoData)
                    val intent = Intent(mActivity, PlayerActivity::class.java)
                    intent.putExtra(AppConstant.POSITION, posistion)
                    launchActivity(intent)

                    val db = VideoPlayerDatabase.getInstance(mActivity)
                    val contain = db!!.recentVideoDao()!!.isRecentVideo(data.path)

                    if (contain == 0) {

                        val bookmark = RecentVideo(
                            null,
                            data.path,
                            data.bucketName,
                            data.name,
                            data.date,
                            data.type,
                            data.size,
                            data.duration,
                            data.width,
                            data.height
                        )
                        db.recentVideoDao()!!.insertRecentVideo(bookmark)

                    } else {
                        db.recentVideoDao().deleteRecentVideo(data.path)
                        val bookmark = RecentVideo(
                            null,
                            data.path,
                            data.bucketName,
                            data.name,
                            data.date,
                            data.type,
                            data.size,
                            data.duration,
                            data.width,
                            data.height
                        )
                        db.recentVideoDao()!!.insertRecentVideo(bookmark)
                    }
                }

            }
            R.id.iv_search ->
            {
                if (mVideoData.isNotEmpty()) {
                    VideoSearchActivity.mVideoData.removeAll(VideoSearchActivity.mVideoData)
                    VideoSearchActivity.mVideoData.addAll(mVideoData)
                    val intent = Intent(mActivity, VideoSearchActivity::class.java)
                    launchActivity(intent)
                }
            }
            R.id.iv_back ->
            {
                onBackPressed()
            }
        }
    }

    fun getMenu(v: View, data: FavoriteVideo) {

        val popupMenu = PopupMenu(mActivity, v)
        popupMenu.menuInflater.inflate(R.menu.video_option, popupMenu.menu)
        val m = popupMenu.menu

        val contain = mDB.favoriteVideoDao().isFavoriteVideo(data.path)
        if (contain == 0)
        {
            m.findItem(R.id.menuUnFav).isVisible = false
            m.findItem(R.id.menuFavorite).isVisible = true
        }
        else
        {
            m.findItem(R.id.menuUnFav).isVisible = true
            m.findItem(R.id.menuFavorite).isVisible = false
        }

        popupMenu.setOnMenuItemClickListener { item ->
            when (item.itemId) {

                R.id.menuAddPlaylist -> {
                  addToPlaylistDialog(data)

                }
                R.id.menuFavorite -> {

                    val favorite = FavoriteVideo(null,data.path,data.bucketName,data.name,data.date,data.type,data.size,data.duration,data.width,data.height)
                    mDB.favoriteVideoDao().insertFavoriteVideo(favorite)

                }

                R.id.menuUnFav -> {
                    mDB.favoriteVideoDao().deleteFavoriteVideo(data.path)
                }

                R.id.menuFileInfo -> {

                    fileInfoDialog(data)
                }

                R.id.menuShare -> {

                    val uri = FileProvider.getUriForFile(mActivity,BuildConfig.APPLICATION_ID+".provider", File(data.path))
                    val intent = Intent(Intent.ACTION_SEND)
                    intent.type = "video/*"
                    intent.putExtra(Intent.EXTRA_TEXT, getString(R.string.share_msg) )
                    intent.putExtra(Intent.EXTRA_STREAM,uri)
                    startActivity(Intent.createChooser(intent,"Share Video"))
                }
                R.id.menuDelete -> {

                }

            }
            true
        }


        val menuHelper: Any
        val argTypes: Array<Class<*>?>
        try {
            val fMenuHelper: java.lang.reflect.Field =
                PopupMenu::class.java.getDeclaredField("mPopup")
            fMenuHelper.isAccessible = true
            menuHelper = fMenuHelper.get(popupMenu)!!
            argTypes = arrayOf(Boolean::class.javaPrimitiveType)
            menuHelper.javaClass.getDeclaredMethod("setForceShowIcon", *argTypes).invoke(menuHelper, true)
        } catch (e: Exception) { }

        popupMenu.show()

    }
    private fun addToPlaylistDialog(data :FavoriteVideo){

        val addToPlatlistDialog = Dialog(mActivity)
        addToPlatlistDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        addToPlatlistDialog.setCancelable(false)
        addToPlatlistDialog.setContentView(R.layout.add_playlist_dialog)

        val lp = WindowManager.LayoutParams()
        lp.copyFrom(addToPlatlistDialog.window!!.attributes)
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.gravity = Gravity.CENTER

        addToPlatlistDialog.window!!.attributes = lp
        addToPlatlistDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        addToPlatlistDialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)

        val mDB = VideoPlayerDatabase.getInstance(mActivity)

        mPlayListVideoAdapter = AddPlaylistAdapter(R.layout.playlistname_list,
            {
                when(it.id){

                    R.id.con_add_main ->
                    {
                        val pos = it.tag as Int
                        val datas = getRecyclerVideo(it.getTag(R.id.TYPE).toString(), pos)
                        val added = mDB.videoDataDao().isAdded(data.path,datas.PlaylistName)
                        if (added == 0)
                        {
                            val add = VideoDatalist(
                                null,
                                datas.PlaylistName,
                                data.path,
                                data.bucketName,
                                data.name,
                                data.date,
                                data.type,
                                data.size,
                                data.duration,
                                data.width,
                                data.height
                            )
                            mDB.videoDataDao().insertPlaylistVideo(add)
                            EventBus.getDefault().post(AppConstant.EVENT_NOTIFY_PLAYLIST)
                        }
                        else{
                            toast("Already exists in playlist")
                        }
                        addToPlatlistDialog.cancel()
                        addToPlatlistDialog.dismiss()
                    }
                }

            }, AppConstant.TYPE_VIDEO_LIST)
        addToPlatlistDialog.rv_listname.run {
            adapter = mPlayListVideoAdapter
        }
        val mList = mDB.videoPlaylistDao().getPlaylist()

        if (mList.isEmpty())
        {
            addToPlatlistDialog.tv_choose_playlist_lbl.visibility = View.GONE
            addToPlatlistDialog.rv_listname.visibility = View.GONE
            // addToPlatlistDialog.rv_listname.visibility = View.GONE

        }else{
            addToPlatlistDialog.tv_choose_playlist_lbl.visibility = View.VISIBLE
            addToPlatlistDialog.rv_listname.visibility = View.VISIBLE
            mPlayListVideoAdapter.removeAll()
            mPlayListVideoAdapter.addAll(mList as java.util.ArrayList<VideoPlaylist>)
        }

        addToPlatlistDialog.iv_close_add_playlist.setOnClickListener {
            addToPlatlistDialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            addToPlatlistDialog.cancel()
            addToPlatlistDialog.dismiss()

        }

        addToPlatlistDialog.btn_add_create.setOnClickListener {
            addToPlatlistDialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            val name = addToPlatlistDialog.et_add_playlist_name.text.toString().trim()
            if (name.isNotEmpty()) {
                val playlist = VideoPlaylist(name)
                val exists = mDB.videoPlaylistDao().isAdded(name)
                if (exists == 0) {
                    mDB.videoPlaylistDao().insertPlaylist(playlist)
                    val added = mDB.videoDataDao().isAdded(data.path,name)
                    if (added == 0) {
                        val add = VideoDatalist(
                            null,
                            name,
                            data.path,
                            data.bucketName,
                            data.name,
                            data.date,
                            data.type,
                            data.size,
                            data.duration,
                            data.width,
                            data.height
                        )
                        mDB.videoDataDao().insertPlaylistVideo(add)
                        EventBus.getDefault().post(AppConstant.EVENT_NOTIFY_PLAYLIST)
                    }
                    else{
                        toast("Already exists in playlist")
                    }
                    addToPlatlistDialog.cancel()
                    addToPlatlistDialog.dismiss()
                }
                else
                {
                    toast("Playlist name already exists")
                }
            }
            else
            {
                toast("Please enter playlist name")
            }

        }

        addToPlatlistDialog.show()

    }

    private fun fileInfoDialog(data: FavoriteVideo) {

        val dialog = Dialog(mActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.file_info_dialog)

        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.gravity = Gravity.CENTER

        dialog.window!!.attributes = lp
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        var outputFormat = SimpleDateFormat("EEE d MMM yyyy HH:mm")
        dialog.tv_file_title.text = data.name
        dialog.tv_file_path.text = data.path
        dialog.tv_file_size.text = formateSize(data.size)
        dialog.tv_file_formate.text = data.type
        dialog.tv_file_dura.text = setDuration(data.duration)
        dialog.tv_file_dimen.text = "${data.width} x ${data.height}"
        dialog.tv_file_date.text = outputFormat.format(Date(data.date))

        dialog.iv_close_file_info.setOnClickListener {
            dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            dialog.cancel()
            dialog.dismiss()

        }

        dialog.show()

    }

    private fun getRecyclerVideoPlaylistData(type: String, pos: Int): FavoriteVideo {
        var data: FavoriteVideo? = null
        when (type) {
            AppConstant.TYPE_VIDEO_LIST -> {
                data = mVideoAdapter.getItem(pos)
            }
        }
        return data!!
    }

    private fun getRecyclerVideo(type: String, pos: Int): VideoPlaylist {
        var data: VideoPlaylist? = null
        when (type) {
            AppConstant.TYPE_VIDEO_LIST -> {
                data = mPlayListVideoAdapter.getItem(pos)
            }
        }
        return data!!
    }


}