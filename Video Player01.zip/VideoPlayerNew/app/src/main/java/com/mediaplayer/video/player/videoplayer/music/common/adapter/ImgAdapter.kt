package com.mediaplayer.video.player.videoplayer.music.common.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.mediaplayer.video.player.videoplayer.music.R

class ImgAdapter(val mContext: Activity, var mVideoList: IntArray) : RecyclerView.Adapter<ImgAdapter.ImgClass>() {
    class ImgClass(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val img : ImageView = itemView.findViewById(R.id.iv_img)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImgClass {
        val mView = LayoutInflater.from(mContext).inflate(R.layout.img_item_list, parent, false)
        return ImgClass(mView)
    }

    override fun onBindViewHolder(holder: ImgClass, position: Int) {

        val newPos = position % mVideoList.size
        holder.img.setImageDrawable(ContextCompat.getDrawable(mContext,mVideoList[newPos]))
    }



    override fun getItemCount(): Int {
      return Int.MAX_VALUE
    }
}