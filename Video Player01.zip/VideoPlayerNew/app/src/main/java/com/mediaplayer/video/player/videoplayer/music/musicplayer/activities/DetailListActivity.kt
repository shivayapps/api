package com.mediaplayer.video.player.videoplayer.music.musicplayer.activities

import android.content.Intent
import android.view.View
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager

import com.afollestad.materialcab.attached.AttachedCab
import com.afollestad.materialcab.attached.destroy
import com.afollestad.materialcab.attached.isActive
import com.afollestad.materialcab.createCab
import com.example.app.ads.helper.GiftIconHelper
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.newInApp.AdsManager
import com.mediaplayer.video.player.videoplayer.music.common.widgets.OnSingleClickListener
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityDetailListBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.*
import com.mediaplayer.video.player.videoplayer.music.musicplayer.adapter.album.AlbumAdapter
import com.mediaplayer.video.player.videoplayer.music.musicplayer.adapter.artist.ArtistAdapter
import com.mediaplayer.video.player.videoplayer.music.musicplayer.adapter.song.ShuffleButtonSongAdapter
import com.mediaplayer.video.player.videoplayer.music.musicplayer.adapter.song.SongAdapter
import com.mediaplayer.video.player.videoplayer.music.musicplayer.db.toSong
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.surfaceColor
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.LibraryViewModel
import com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces.IAlbumClickListener
import com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces.IArtistClickListener
import com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces.ICabCallback
import com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces.ICabHolder
import com.mediaplayer.video.player.videoplayer.music.musicplayer.model.Album
import com.mediaplayer.video.player.videoplayer.music.musicplayer.model.Artist
import com.mediaplayer.video.player.videoplayer.music.musicplayer.repository.RealRepository
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.RetroColorUtil
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.RetroUtil
import kotlinx.android.synthetic.main.activity_detail_list.*


class DetailListActivity : BaseBindingActivity<ActivityDetailListBinding>(), IArtistClickListener, IAlbumClickListener,
    ICabHolder {

    private val getRepository: RealRepository get() = repository
  lateinit var libraryViewModel : LibraryViewModel
    override fun initView() {
        super.initView()

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        }
        else{
            setImmersiveFullscreen()
        }
        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            IMAGE_THEME,"")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getString(
            GENERAL_THEME,"")

        if (editors == "theme_one")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_one)
        }
        else if (editors == "theme_two")
        {

            mBinding.root.background = ContextCompat.getDrawable(mActivity,R.drawable.img_theme_two)
        }
        else if (edit == "ligt" || edit == "dark")
        {
            mBinding.root.background = null
        }

        val id = intent.getIntExtra(EXTRA_PLAYLIST_TYPE,0 )

        mBinding.progressIndicator.hide()

        libraryViewModel = LibraryViewModel(getRepository)

        when (id) {
            TOP_ARTISTS -> loadArtists(R.string.top_artists, TOP_ARTISTS)
            RECENT_ARTISTS -> loadArtists(R.string.recent_artists, RECENT_ARTISTS)
            TOP_ALBUMS -> loadAlbums(R.string.top_albums, TOP_ALBUMS)
            RECENT_ALBUMS -> loadAlbums(R.string.recent_albums, RECENT_ALBUMS)
            FAVOURITES -> loadFavorite()
            HISTORY_PLAYLIST -> loadHistory()
            LAST_ADDED_PLAYLIST -> lastAddedSongs()
            TOP_PLAYED_PLAYLIST -> topPlayed()
        }

        mBinding.ivBack.setOnClickListener(object : OnSingleClickListener(){
            override fun onSingleClick(v: View?) {
                onBackPressed()
            }

        })
    }

    override fun initAds() {
        super.initAds()
        if (AdsManager(mActivity).isNeedToShowAds()) {
            GiftIconHelper.loadGiftAd(mActivity, main_la_gift, main_la_gift_blast)
        }
    }

    override fun getActivityContext(): FragmentActivity {
       return this@DetailListActivity
    }

    private fun artistAdapter(artists: List<Artist>): ArtistAdapter = ArtistAdapter(
        this@DetailListActivity,
        artists,
        R.layout.item_grid_circle,
        this, this@DetailListActivity
    )

    private fun albumAdapter(albums: List<Album>): AlbumAdapter = AlbumAdapter(
        this@DetailListActivity,
        albums,
        R.layout.item_grid,
        this, this@DetailListActivity
    )

    private fun loadArtists(title: Int, type: Int) {
        mBinding.tvFmName.text = getString(title)
        val artistAdapter = artistAdapter(listOf())
        mBinding.recyclerView.apply {
            adapter = artistAdapter
            layoutManager = gridLayoutManager()
        }
        libraryViewModel.artists(type).observe(this@DetailListActivity) { artists ->
            artistAdapter.swapDataSet(artists)
        }
    }
    private fun loadAlbums(title: Int, type: Int) {
        mBinding.tvFmName.text = getString(title)
        val albumAdapter = albumAdapter(listOf())
        mBinding.recyclerView.apply {
            adapter = albumAdapter
            layoutManager = gridLayoutManager()
        }
        libraryViewModel.albums(type).observe(this@DetailListActivity) { albums ->
            albumAdapter.swapDataSet(albums)
        }
    }
    private fun loadHistory() {

        mBinding.tvFmName.text =getString(R.string.history)
        val songAdapter = ShuffleButtonSongAdapter(
            this@DetailListActivity,
            mutableListOf(),
            R.layout.item_list, this
        )
        mBinding.recyclerView.apply {
            adapter = songAdapter
            layoutManager = linearLayoutManager()
        }
        libraryViewModel.observableHistorySongs().observe(this@DetailListActivity) {
            if (it.isEmpty())
            {
                mBinding.empty.visibility =View.VISIBLE
            }else {
                mBinding.empty.visibility =View.GONE
                songAdapter.swapDataSet(it)
            }
        }
    }

    private fun lastAddedSongs() {
        mBinding.tvFmName.text = getString(R.string.last_added)
        val songAdapter = ShuffleButtonSongAdapter(
            this@DetailListActivity,
            mutableListOf(),
            R.layout.item_list, this
        )
        mBinding.recyclerView.apply {
            adapter = songAdapter
            layoutManager = linearLayoutManager()
            scheduleLayoutAnimation()
        }
        libraryViewModel.recentSongs().observe(this@DetailListActivity) { songs ->
            if (songs.isEmpty())
            {
                mBinding.empty.visibility =View.VISIBLE
            }else {
                mBinding.empty.visibility =View.GONE
                songAdapter.swapDataSet(songs)
            }
        }
    }

    private fun topPlayed() {
        mBinding.tvFmName.text =getString(R.string.my_top_tracks)
        val songAdapter = ShuffleButtonSongAdapter(
            this@DetailListActivity,
            mutableListOf(),
            R.layout.item_list, this
        )
        mBinding.recyclerView.apply {
            adapter = songAdapter
            layoutManager = linearLayoutManager()
        }
        libraryViewModel.playCountSongs().observe(this@DetailListActivity) { songs ->
            if (songs.isEmpty())
            {
                mBinding.empty.visibility =View.VISIBLE
            }else {
                mBinding.empty.visibility =View.GONE
                songAdapter.swapDataSet(songs)
            }
        }
    }

    private fun loadFavorite() {
        mBinding.tvFmName.text = getString(R.string.favorites)
        val songAdapter = SongAdapter(
            this@DetailListActivity,
            mutableListOf(),
            R.layout.item_list, this
        )
        mBinding.recyclerView.apply {
            adapter = songAdapter
            layoutManager = linearLayoutManager()
        }
        libraryViewModel.favorites().observe(this@DetailListActivity) { songEntities ->
            val songs = songEntities.map { songEntity -> songEntity.toSong() }
            songAdapter.swapDataSet(songs)
        }
    }


    private fun linearLayoutManager(): LinearLayoutManager =
        LinearLayoutManager(this@DetailListActivity, LinearLayoutManager.VERTICAL, false)

    private fun gridLayoutManager(): GridLayoutManager =
        GridLayoutManager(this@DetailListActivity, gridCount(), GridLayoutManager.VERTICAL, false)

    private fun gridCount(): Int {
        if (RetroUtil.isTablet()) {
            return if (RetroUtil.isLandscape()) 6 else 4
        }
        return if (RetroUtil.isLandscape()) 4 else 2
    }

    override fun onAlbumClick(albumId: Long, view: View) {
        val intent = Intent(this@DetailListActivity,AlbumDetalitActivity::class.java)
        intent.putExtra(EXTRA_ALBUM_ID,albumId)
        launchActivity(intent)

    }

    override fun onArtist(artistId: Long, view: View) {
        val intent = Intent(this@DetailListActivity,ArtistDetailActivity::class.java)
        intent.putExtra(EXTRA_ARTIST_ID,artistId)
        launchActivity(intent)
    }
    private var cab: AttachedCab? = null
    override fun openCab(menuRes: Int, callback: ICabCallback): AttachedCab {
        cab?.let {
            println("Cab")
            if (it.isActive()) {
                it.destroy()
            }
        }
        cab = createCab(R.id.toolbar_container) {
            menu(menuRes)
            closeDrawable(R.drawable.ic_close)
            backgroundColor(literal = RetroColorUtil.shiftBackgroundColor(surfaceColor()))
            slideDown()
            onCreate { cab, menu -> callback.onCabCreated(cab, menu) }
            onSelection {
                callback.onCabItemClicked(it)
            }
            onDestroy { callback.onCabFinished(it) }
        }
        return cab as AttachedCab
    }


    override fun setBinding(): ActivityDetailListBinding {
       return ActivityDetailListBinding.inflate(layoutInflater)
    }
}