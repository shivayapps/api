package com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces

interface IScrollHelper {
    fun scrollToTop()
}