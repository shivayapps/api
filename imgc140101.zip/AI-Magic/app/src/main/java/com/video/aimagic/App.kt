package com.video.aimagic

import android.app.Activity
import android.content.Context
import androidx.multidex.MultiDexApplication
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd
import com.google.android.gms.ads.MobileAds
import com.video.aimagic.commonscreen.adapter.MediaItem
import com.video.aimagic.commonscreen.screen.CommonResultScreen
import com.video.aimagic.commonscreen.screen.OnLaunchScreen
import com.video.aimagic.onboardingflow.screen.CustomOnBoardingActivity


class App : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {
    companion object {
        var displayListItem: ArrayList<MediaItem> = ArrayList()
        lateinit var appContext: Context

    }

    override fun onCreate() {
        super.onCreate()
        appContext = applicationContext


        AdsConfig.builder()
            .setTestDeviceId("123")
            .setAdmobAppOpenId(getString(R.string.open_ad))
            .build(this)
        setAppLifecycleListener(this)
        MobileAds.initialize(applicationContext)
        initMobileAds()
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {

        if(fCurrentActivity is SplashScreen){
            return false
        }else if(fCurrentActivity is OnLaunchScreen){
            return false
        }else if(fCurrentActivity is CustomOnBoardingActivity){
            return false
        }
        return true
    }


    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
                if (OpenAdHelper.isAdAvailable()) {
//                    if(fCurrentActivity is CommonResultScreen){
//                        fCurrentActivity.playPauseForAd(true)
//                    }
                    fCurrentActivity.isShowOpenAd { success ->
//                        if(fCurrentActivity is CommonResultScreen){
//                            fCurrentActivity.playPauseForAd(false)
//                        }
                        //finish()
                    }
                }
            }
    }

}