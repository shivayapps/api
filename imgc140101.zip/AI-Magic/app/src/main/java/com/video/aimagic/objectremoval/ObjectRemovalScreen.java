package com.video.aimagic.objectremoval;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.SeekBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.video.aimagic.databinding.ActivityObjectRemovalScreenBinding;
import com.video.aimagic.extension.ExtensionsKt;
import com.video.aimagic.singletone.PhotoUploadManager;
import com.video.aimagic.utils.appconfig.AppConfig;

import java.io.File;

public class ObjectRemovalScreen extends AppCompatActivity implements PhotoUploadManager.PhotoUploadCallback {

    private static final String TAG = "ObjectRemovalScreen";
    int brushStrength = 50;
    private ActivityObjectRemovalScreenBinding binding;
    private PhotoUploadManager photoUploadManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityObjectRemovalScreenBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        photoUploadManager = PhotoUploadManager.getInstance();
        setUpView();
        setOnClickListners();
        setUpBrushSeekBar();


    }

    private void setUpView() {
        binding.drawingCanvas.setZoomDisplay(binding.zoomPreviewView);
    }

    private void setUpBrushSeekBar() {
        binding.brushSizeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                brushStrength = Math.max(1, progress);
                binding.drawingCanvas.adjustBrushSize(brushStrength);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    private void setOnClickListners() {
        binding.backButton.setOnClickListener(v -> {
            finish();
        });
        binding.processButton.setOnClickListener(v -> {
            Log.d(TAG, "Upload button clicked");
//            photoUploadManager.startPhotoUpload(ObjectRemovalScreen.this, AppConfig.FEATURE_AIENHANCER, AppConfig.FEATURE_OBJECT_R_UPLOAD_PHOTO_ACTION);
            photoUploadManager.startPhotoUpload(ObjectRemovalScreen.this, AppConfig.FEATURE_OBJECT_REMOVAL, AppConfig.FEATURE_OBJECT_R_UPLOAD_PHOTO_ACTION);
        });

        binding.undoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.drawingCanvas.performUndo();
            }
        });

        binding.redoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.drawingCanvas.performRedo();
            }
        });
    }


    public void adjustUndoOpacity(float alpha) {
        binding.undoButton.setAlpha(alpha);
    }


    public void adjustRedoOpacity(float alpha) {
        binding.redoButton.setAlpha(alpha);
    }

    private void settingCanvas() {
        binding.drawingCanvas.setParentActivity(this);
        if (PhotoUploadManager.getInstance().getCurrentImageUriStringPath() == null) return;
        File file = new File(PhotoUploadManager.getInstance().getCurrentImageUriStringPath());
        if (file.exists()) {
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            binding.inputImageView.setImageBitmap(bitmap);
            if (binding.drawingCanvas != null) {
                binding.drawingCanvas.loadImage(bitmap, ObjectRemovalScreen.this);
                binding.drawingCanvas.getLayoutParams().width = bitmap.getWidth();
                binding.drawingCanvas.getLayoutParams().height = bitmap.getHeight();
                binding.drawingCanvas.requestLayout();
            }
        }

        binding.drawingCanvas.setOnClickListener(v -> {
            Log.d(TAG, "Upload button clicked");
            photoUploadManager.startPhotoUpload(ObjectRemovalScreen.this, AppConfig.FEATURE_AIENHANCER, AppConfig.FEATURE_OBJECT_R_UPLOAD_PHOTO_ACTION);
        });


    }


    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: Setting callback to this activity");
        // Set callback when activity resumes
        photoUploadManager.setCallback(this);

        // Check if we already have an image URI from a previous upload
        Uri existingUri = photoUploadManager.getCurrentImageUri();
        String uploadType = photoUploadManager.getCurrentUploadType();
        String feature = photoUploadManager.getCurrentFeature();

        if (existingUri != null && AppConfig.FEATURE_OBJECT_R_UPLOAD_PHOTO_ACTION.equals(uploadType) && AppConfig.FEATURE_OBJECT_REMOVAL.equals(feature)) {
            Log.d(TAG, "Found existing image URI: " + existingUri);
            onPhotoUploaded(existingUri, feature, uploadType);
        }

        settingCanvas();

    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: Removing callback");
        // Remove callback when activity pauses
        if (photoUploadManager.getCallback() == this) {
            photoUploadManager.setCallback(null);
        }
    }

    @Override
    public void onPhotoUploaded(Uri imageUri, String feature, String uploadType) {
        Log.d(TAG, "onPhotoUploaded called - URI: " + imageUri + ", Feature: " + feature + ", Type: " + uploadType);
        if (AppConfig.FEATURE_OBJECT_R_UPLOAD_PHOTO_ACTION.equals(uploadType) && AppConfig.FEATURE_OBJECT_REMOVAL.equals(feature)) {
            runOnUiThread(() -> {
                Log.d(TAG, "Loading image into ImageView: " + imageUri);
                try {
                    Glide.with(this).load(imageUri.getPath()).centerCrop().into(binding.inputImageView);
                    Log.d(TAG, "Glide image load attempted");
                } catch (Exception e) {
                    Log.e(TAG, "Error loading image with Glide: " + e.getMessage());
                    e.printStackTrace();
                }
            });
        } else {
            Log.d(TAG, "Upload type or feature mismatch. Expected: " + AppConfig.FEATURE_OBJECT_R_UPLOAD_PHOTO_ACTION + "/" + AppConfig.FEATURE_OBJECT_REMOVAL + ", Got: " + uploadType + "/" + feature);
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }


}