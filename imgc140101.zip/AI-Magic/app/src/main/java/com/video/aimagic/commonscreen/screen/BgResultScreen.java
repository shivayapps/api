package com.video.aimagic.commonscreen.screen;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.adconfig.AdsConfig;
import com.adconfig.adsutil.admob.AdmobIntersAdImpl;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.video.aimagic.R;
import com.video.aimagic.databinding.ActivityBgResultScreenBinding;
import com.video.aimagic.aivideos.api.get.DownloadVideoAndPlay;
import com.video.aimagic.callback.ResponseCallBack;
import com.video.aimagic.commonscreen.data.DrawableCategory;
import com.video.aimagic.commonscreen.data.OnDrawableSelectedListener;
import com.video.aimagic.extension.ExtensionsKt;
import com.video.aimagic.facedance.api.get.FaceDanceDownloadVideoAndPlay;
import com.video.aimagic.singletone.ConfirmDialog;
import com.video.aimagic.singletone.PhotoUploadManager;
import com.video.aimagic.utils.Methods;
import com.video.aimagic.utils.appconfig.AppConfig;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class BgResultScreen extends AppCompatActivity implements OnDrawableSelectedListener {

    private ActivityBgResultScreenBinding binding;
    private boolean isImageSaved = false;
    private boolean isOutputImage = true;
    private String currentImageUrl = "";
    private String currentVideoUrl = "";
    private String currentFeature = "";
    private String requestID = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBgResultScreenBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());

        requestID = getIntent().getStringExtra(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT);
        currentFeature = getIntent().getStringExtra(AppConfig.INTENT_FEATURED_PASSED_AS);

        setupClickListeners();


        Log.e("ResultScreen", "BgResultScreen.currentFeature:" + currentFeature);
        if (currentFeature != null) {
            if (currentFeature.equals(AppConfig.FEATURE_CHANGE_BG)) {
                isOutputImage = true;
                currentImageUrl = "https://faceswapmagic.com/pixellab/examples/results/NaturePhotoFramesandEditor/" + requestID;
                loadRemoveBGImage(requestID);
            }

        }
        PhotoUploadManager.getInstance().clear();
    }

    private void setupClickListeners() {
        loadAds();
        binding.buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isImageSaved) {
                    new ConfirmDialog(BgResultScreen.this,0, new Function1<Boolean, Unit>() {
                        @Override
                        public Unit invoke(Boolean isSave) {
                            if (isSave) {
                                showAdThenSave();
                            } else {
                                finish();
                            }
                            return null;
                        }
                    }).show();
                }else {
                    finish();
                }
            }
        });

        binding.ivPreview.setOnClickListener(v -> {
            Methods.INSTANCE.showImagePreviewDialog(BgResultScreen.this,currentImageUrl);
        });
        binding.changeBg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new MyBottomSheet().show(getSupportFragmentManager(), "MyBottomSheet");
            }
        });
        binding.saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAdThenSave();
            }
        });

        binding.shareButton.setOnClickListener(v -> shareImage());
        binding.buttonSupport.setOnClickListener(v -> Methods.INSTANCE.showFeedbackDialog(this));

        // Social media share buttons
        binding.instagramShare.setOnClickListener(v -> shareToSocialMedia("com.instagram.android"));
        binding.facebookShare.setOnClickListener(v -> shareToSocialMedia("com.facebook.katana"));
        binding.whatsappShare.setOnClickListener(v -> shareToSocialMedia("com.whatsapp"));
        binding.twitterShare.setOnClickListener(v -> shareToSocialMedia("com.twitter.android"));
        binding.snapchatShare.setOnClickListener(v -> shareToSocialMedia("com.snapchat.android"));
    }

    private void loadAds() {
        String interAdId = getString(R.string.inter_ad);
        new AdmobIntersAdImpl().load(this, interAdId, new Function1<Boolean, Unit>() {
            @Override
            public Unit invoke(Boolean isLoaded) {

                return null;
            }
        });
    }

    private void showAdThenSave() {
        AdsConfig.Companion.showInterstitialAd(this, new Function1<Boolean, Unit>() {
            @Override
            public Unit invoke(Boolean aBoolean) {
                saveImageToGallery();
                return null;
            }
        });
    }

    private void loadRemoveBGImage(String requestID) {


        Glide.with(BgResultScreen.this)
                .load(currentImageUrl)
                .centerCrop()
                .into(binding.generatedImage);
    }

    private void saveImageToGallery() {
        if (isImageSaved) {
            Toast.makeText(this, "Image already saved", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get the bitmap from the ImageView
        binding.generatedFrame.setDrawingCacheEnabled(true);
        binding.generatedFrame.buildDrawingCache();
        Bitmap bitmap = binding.generatedFrame.getDrawingCache();

        if (bitmap != null) {
            try {
                String storageDirPath =
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
                                .getPath() + "/AiMagic/";

                File storageDir = new File(storageDirPath);
                if (!storageDir.exists()) {
                    storageDir.mkdirs(); // ✅ create folder
                }

                File imageFile = new File(
                        storageDir,
                        "Imagic_img_" + System.currentTimeMillis() + ".jpg"
                );

                FileOutputStream outputStream = new FileOutputStream(imageFile);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                outputStream.flush();
                outputStream.close();

                Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                mediaScanIntent.setData(Uri.fromFile(imageFile));
                sendBroadcast(mediaScanIntent);
                isImageSaved = true;
                updateSaveButtonState();
                Toast.makeText(this, "Image saved to gallery", Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to save image", Toast.LENGTH_SHORT).show();
            }
        } else {
            // If we don't have a bitmap, download and save it
            downloadAndSaveImage();
        }
    }

    private InputStream getInputStreamFromPath(String path) throws Exception {

        if (path.startsWith("content://")) {
            return getContentResolver().openInputStream(Uri.parse(path));
        }

        if (path.startsWith("file://")) {
            return new FileInputStream(new File(Uri.parse(path).getPath()));
        }

        // normal file path
        return new FileInputStream(new File(path));
    }

    private void downloadAndSaveImage() {
        Glide.with(this)
                .asBitmap()
                .load(currentImageUrl)
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                        try {
                            File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                            File imageFile = new File(storageDir, "Imagic_" + System.currentTimeMillis() + ".jpg");

                            FileOutputStream outputStream = new FileOutputStream(imageFile);
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                            outputStream.flush();
                            outputStream.close();

                            // Notify the system that a new image has been added
                            Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                            mediaScanIntent.setData(Uri.fromFile(imageFile));
                            sendBroadcast(mediaScanIntent);

                            isImageSaved = true;
                            updateSaveButtonState();

                            Toast.makeText(BgResultScreen.this, "Image saved to gallery", Toast.LENGTH_SHORT).show();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Toast.makeText(BgResultScreen.this, "Failed to save image", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onLoadCleared(Drawable placeholder) {
                    }
                });
    }

    private void updateSaveButtonState() {
        if (isImageSaved) {
            binding.saveButton.setAlpha(0.5f);
            binding.saveButton.setClickable(false);
        } else {
            binding.saveButton.setAlpha(1.0f);
            binding.saveButton.setClickable(true);
        }
    }

    private void shareImage() {
        // Get the bitmap from the ImageView
        binding.generatedFrame.setDrawingCacheEnabled(true);
        binding.generatedFrame.buildDrawingCache();
        Bitmap bitmap = binding.generatedFrame.getDrawingCache();

        if (bitmap != null) {
            try {
                // Save the image to cache
                File cachePath = new File(getCacheDir(), "images");
                cachePath.mkdirs();
                File file = new File(cachePath, "shared_image.jpg");
                FileOutputStream outputStream = new FileOutputStream(file);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                outputStream.flush();
                outputStream.close();

                // Share the image
                Uri contentUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);

                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("image/jpeg");
                shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(shareIntent, "Share image via"));
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to share image", Toast.LENGTH_SHORT).show();
            }
        } else {
            // If we don't have a bitmap, share the URL
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, currentImageUrl);
            startActivity(Intent.createChooser(shareIntent, "Share via"));
        }
    }

    private File getSharedImageFile() throws IOException {

        File cachePath = new File(getCacheDir(), "share");
        cachePath.mkdirs();

        File file = new File(cachePath, "image.jpg");

        binding.generatedFrame.setDrawingCacheEnabled(true);
        binding.generatedFrame.buildDrawingCache();
        Bitmap bitmap = binding.generatedFrame.getDrawingCache();
//        Bitmap bitmap = ((BitmapDrawable) binding.generatedFrame.getDrawable()).getBitmap();

        FileOutputStream fos = new FileOutputStream(file);
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
        fos.close();

        return file;
    }

    private void shareToSocialMedia(String packageName) {
        Log.e("ResultScreen", "BgResult:" + packageName);

        try {
            getPackageManager().getPackageInfo(packageName, 0);

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setPackage(packageName);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            Uri uri;
            String mimeType;

            if (isOutputImage) {
                // IMAGE SHARE
                File file = getSharedImageFile();
                uri = FileProvider.getUriForFile(
                        this,
                        getPackageName() + ".fileprovider",
                        file
                );
                mimeType = "image/jpeg";

            } else {
                // VIDEO SHARE
                File videoFile = new File(currentVideoUrl);
                uri = FileProvider.getUriForFile(
                        this,
                        getPackageName() + ".fileprovider",
                        videoFile
                );
                mimeType = "video/mp4";
            }

            shareIntent.setType(mimeType);
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            shareIntent.setClipData(ClipData.newRawUri("", uri));

            startActivity(shareIntent);

        } catch (Exception e) {
            Log.e("ResultScreen", "BgResult.Exception:" + e);
            e.printStackTrace();
            Toast.makeText(this, "App not installed or cannot share", Toast.LENGTH_SHORT).show();
        }
    }

//    private void shareToSocialMedia1(String packageName) {
//        // Check if the app is installed
//        try {
//            getPackageManager().getPackageInfo(packageName, 0);
//
//            // Get the bitmap from the ImageView
//            binding.generatedImage.setDrawingCacheEnabled(true);
//            binding.generatedImage.buildDrawingCache();
//            Bitmap bitmap = binding.generatedImage.getDrawingCache();
//
//            if (bitmap != null) {
//                try {
//                    // Save the image to cache
//                    File cachePath = new File(getCacheDir(), "images");
//                    cachePath.mkdirs();
//                    File file = new File(cachePath, "shared_image.jpg");
//                    FileOutputStream outputStream = new FileOutputStream(file);
//                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
//                    outputStream.flush();
//                    outputStream.close();
//
//                    // Share to specific app
//                    Uri contentUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
//
//                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
//                    shareIntent.setType("image/jpeg");
//                    shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
//                    shareIntent.setPackage(packageName);
//                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
//                    startActivity(shareIntent);
//                } catch (IOException e) {
//                    e.printStackTrace();
//                    Toast.makeText(this, "Failed to share image", Toast.LENGTH_SHORT).show();
//                }
//            } else {
//                // If we don't have a bitmap, share the URL
//                Intent shareIntent = new Intent(Intent.ACTION_SEND);
//                shareIntent.setType("text/plain");
//                shareIntent.putExtra(Intent.EXTRA_TEXT, currentImageUrl);
//                shareIntent.setPackage(packageName);
//                startActivity(shareIntent);
//            }
//        } catch (Exception e) {
//            // App is not installed
//            Toast.makeText(this, "App not installed", Toast.LENGTH_SHORT).show();
//        }
//    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }

    @Override
    public void onDrawableSelected(@NotNull DrawableCategory category, int drawableRes) {
        Log.e("ResultScreen", "onDrawableSelected.category:" + category);
        Log.e("ResultScreen", "onDrawableSelected.drawableRes:" + drawableRes);
        isImageSaved = false;
        binding.bgImage.setImageResource(drawableRes);
        updateSaveButtonState();
    }
}