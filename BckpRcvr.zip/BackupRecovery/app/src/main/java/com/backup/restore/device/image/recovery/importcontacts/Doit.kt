package com.backup.restore.device.image.recovery.importcontacts

import android.app.Dialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.utilities.changeLanguage

class Doit : WizardActivity() {
    private var _started_progress = false
    private var _max_progress = 0
    private var _tmp_progress = 0
    private var _progress = 0
    protected var _dialog_message: String? = null
    private var _merge_prompt_dialog: Dialog? = null
    private var _merge_prompt_always_selected = false
    private var _next_action = 0
    private var _current_dialog_id = 0
    private var _count_overwrites = 0
    private var _count_creates = 0
    private var _count_merges = 0
    private var _count_skips = 0
    protected var _importer: Importer? = null
    var _handler: Handler? = null
    //var _handler: DoitHandler? = null

    inner class DoitHandler : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            when (msg.what) {
                MESSAGE_ALLDONE -> {
                    onBackPressed()
                    this@Doit.finish()
                    Toast.makeText(
                        this@Doit,
                        getString(R.string.backup_save_successfully),
                        Toast.LENGTH_SHORT
                    ).show()
                    (findViewById<View>(R.id.back) as Button).isEnabled = false
                    updateNext(NEXT_CLOSE)
//                    findViewById<View>(R.id.doit_abort_disp).visibility = View.GONE
                }
                MESSAGE_ABORT -> manualAbort()
                MESSAGE_ERROR -> {
                    _dialog_message = msg.obj as String
                    showDialog(DIALOG_ERROR)
                }
                MESSAGE_CONTINUEORABORT -> {
                    _dialog_message = msg.obj as String
                    showDialog(DIALOG_CONTINUEORABORT)
                }
                MESSAGE_SETPROGRESSMESSAGE -> (findViewById<View>(R.id.doit_percentage) as TextView).text =
                    msg.obj as String
                MESSAGE_SETMAXPROGRESS -> {
                    if (_max_progress > 0) {
                        if (_tmp_progress == _max_progress - 1) _tmp_progress = msg.obj as Int
                        if (_progress == _max_progress - 1) _progress = msg.obj as Int
                    }
                    _max_progress = msg.obj as Int
                    updateProgress()
                }
                MESSAGE_SETTMPPROGRESS -> {
                    _tmp_progress = msg.obj as Int
                    updateProgress()
                }
                MESSAGE_SETPROGRESS -> {
                    _started_progress = true
                    _progress = msg.obj as Int
                    updateProgress()
                }
                MESSAGE_MERGEPROMPT -> {
                    _dialog_message = msg.obj as String
                    showDialog(DIALOG_MERGEPROMPT)
                }
                MESSAGE_CONTACTOVERWRITTEN -> {
                    _count_overwrites++
                    updateStats()
                }
                MESSAGE_CONTACTCREATED -> {
                    _count_creates++
                    updateStats()
                }
                MESSAGE_CONTACTMERGED -> {
                    _count_merges++
                    updateStats()
                }
                MESSAGE_CONTACTSKIPPED -> {
                    _count_skips++
                    updateStats()
                }
                else -> super.handleMessage(msg)
            }
        }
    }

    override fun onCreate(saved_instance_state: Bundle?) {
        setContentView(R.layout.doit)
        super.onCreate(saved_instance_state)

        // hide page 2
        findViewById<View>(R.id.doit_page_2).visibility = View.GONE

        // set up abort button
        val begin = findViewById<View>(R.id.abort) as Button
        begin.setOnClickListener { manualAbort() }
        _started_progress = false
        _max_progress = 0
        _tmp_progress = 0
        _progress = 0
        _handler = DoitHandler()
        _count_overwrites = 0
        _count_creates = 0
        _count_merges = 0
        _count_skips = 0
        importContacts()
        updateProgress()
        updateStats()
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
    }

    override fun onPause() {
        super.onPause()

        // saving the state of an import sounds complicated! Lets just abort!
//        if (_next_action != NEXT_CLOSE) manualAbort(true)
    }

    override fun onCreateDialog(id: Int): Dialog? {
        when (id) {
            DIALOG_ERROR -> return AlertDialog.Builder(this)
                .setIcon(R.drawable.ic_error)
                .setTitle(R.string.error_title)
                .setMessage("")
                .setPositiveButton(
                    R.string.error_ok
                ) { dialog, whichButton -> if (this@Doit != null) _importer!!.wake() }
                .setOnCancelListener(_dialog_on_cancel_listener)
                .create()
            DIALOG_CONTINUEORABORT -> return AlertDialog.Builder(this)
                .setIcon(R.drawable.ic_error)
                .setTitle(R.string.error_title)
                .setMessage("")
                .setPositiveButton(R.string.error_continue) { dialog, which_button ->
                    if (this@Doit != null) _importer!!.wake(
                        Importer.RESPONSE_POSITIVE
                    )
                }
                .setNegativeButton(R.string.error_abort) { dialog, which_button ->
                    if (this@Doit != null) _importer!!.wake(
                        Importer.RESPONSE_NEGATIVE
                    )
                }
                .setOnCancelListener(_dialog_on_cancel_listener)
                .create()
            DIALOG_MERGEPROMPT -> {
                // custom layout in an AlertDialog
                val factory = LayoutInflater.from(this)
                val dialog_view = factory.inflate(
                    R.layout.mergeprompt, null
                )
                (dialog_view.findViewById<View>(R.id.mergeprompt_always) as CheckBox).setOnCheckedChangeListener { button_view, is_checked ->
                    if (this@Doit != null) _merge_prompt_always_selected = is_checked
                }
//                (dialog_view.findViewById<View>(R.id.merge_keep) as Button).setOnClickListener(_merge_prompt_button_listener)
//                (dialog_view.findViewById<View>(R.id.merge_overwrite) as Button).setOnClickListener(_merge_prompt_button_listener)
//                (dialog_view.findViewById<View>(R.id.merge_merge) as Button).setOnClickListener(_merge_prompt_button_listener)

                (dialog_view.findViewById<View>(R.id.dialogButtonClose) as Button).setOnClickListener(_merge_prompt_button_listener)
                (dialog_view.findViewById<View>(R.id.dialogButtonok) as Button).setOnClickListener(_merge_prompt_button_listener)


                val llSkip=(dialog_view.findViewById<View>(R.id.ll_skip) as LinearLayout)
                val llMerge=(dialog_view.findViewById<View>(R.id.ll_merge) as LinearLayout)
                val llReplace=(dialog_view.findViewById<View>(R.id.ll_replace) as LinearLayout)

                val checkSkip=(dialog_view.findViewById<View>(R.id.cb_skip) as RadioButton)
                val checkMerge=(dialog_view.findViewById<View>(R.id.cb_merge) as RadioButton)
                val checkReplace=(dialog_view.findViewById<View>(R.id.cb_replace) as RadioButton)

                llSkip.setOnClickListener {
                    checkSkip.isChecked=true
//                    if(checkSkip.isChecked) {
                        actionInt = ACTION_KEEP
                        checkMerge.isChecked=false
                        checkReplace.isChecked=false
//                    }
                }
                llMerge.setOnClickListener {
                    checkMerge.isChecked=true
//                    if(checkMerge.isChecked) {
                        actionInt = ACTION_MERGE_MERGE
                        checkSkip.isChecked=false
                        checkReplace.isChecked=false
//                    }
                }
                llReplace.setOnClickListener {
                    checkReplace.isChecked=true
//                    if(checkReplace.isChecked) {
                        actionInt = ACTION_OVERWRITE
                        checkMerge.isChecked=false
                        checkSkip.isChecked=false
//                    }
                }

//                checkSkip.setOnCheckedChangeListener { buttonView, isChecked ->
//                    if(isChecked) {
//                        actionInt = ACTION_KEEP
//                        checkMerge.isChecked=false
//                        checkReplace.isChecked=false
//                    }
//                }
//                checkMerge.setOnCheckedChangeListener { buttonView, isChecked ->
//                    if(isChecked) {
//                        actionInt = ACTION_MERGE_MERGE
//                        checkSkip.isChecked=false
//                        checkReplace.isChecked=false
//                    }
//                }
//                checkReplace.setOnCheckedChangeListener { buttonView, isChecked ->
//                    if(isChecked) {
//                        actionInt = ACTION_OVERWRITE
//                        checkMerge.isChecked=false
//                        checkSkip.isChecked=false
//                    }
//                }

                _merge_prompt_always_selected = false
                val dialog = AlertDialog.Builder(this)
                    .setView(dialog_view)
                    .setCancelable(false)
                    .setOnCancelListener(_dialog_on_cancel_listener)
                    .create()
                dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                return dialog
            }
        }
        return null
    }

    private val _merge_prompt_button_listener = View.OnClickListener { view ->
        if (this@Doit == null) return@OnClickListener

        // handle abort
        if (view.id == R.id.dialogButtonClose) manualAbort() else if (_importer != null) {
            val response_extra =
                if (_merge_prompt_always_selected) Importer.RESPONSEEXTRA_ALWAYS
                else Importer.RESPONSEEXTRA_NONE
            _importer!!.wake(actionInt, response_extra)
        }

        // close dialog and free (don't keep a reference)
        _merge_prompt_dialog!!.dismiss()
        _merge_prompt_dialog = null
    }

    override fun onNext() {
        val next = findViewById<View>(R.id.next) as Button
        next.isEnabled = false
        when (_next_action) {
            NEXT_CLOSE -> {
                setResult(RESULT_OK)
                finish()
            }
        }
    }

    private fun manualAbort(show_toaster_popup: Boolean = false) {
        abortImport(show_toaster_popup)
        updateNext(NEXT_CLOSE)
        (findViewById<View>(R.id.back) as Button).isEnabled = true
//        findViewById<View>(R.id.doit_abort_disp).visibility = View.GONE
//        (findViewById<View>(R.id.doit_aborted) as TextView).visibility = View.VISIBLE
//        (findViewById<View>(R.id.doit_alldone) as TextView).visibility = View.GONE

        onBackPressed()
        this@Doit.finish()

        // close any open dialogs
        try {
            dismissDialog(_current_dialog_id)
        } catch (e: Exception) {
            // ignore errors
        }
    }

    override fun onBackPressed() {
//        super.onBackPressed()
    }


    private fun updateNext(next_action: Int) {
        val next = findViewById<View>(R.id.next) as Button
        when (next_action) {
            NEXT_CLOSE -> next.setText(R.string.doit_close)
        }
        next.isEnabled = true
        _next_action = next_action
    }

    private val _dialog_on_cancel_listener = DialogInterface.OnCancelListener { manualAbort() }
    override fun onActivityResult(request_code: Int, result_code: Int, data: Intent?) {
        // if we're cancelling, abort any import
        super.onActivityResult(request_code, result_code, data)
        if (result_code == RESULT_CANCELED) abortImport(true)
    }

    override fun onPrepareDialog(id: Int, dialog: Dialog) {
        _current_dialog_id = id
        when (id) {
            DIALOG_ERROR, DIALOG_CONTINUEORABORT ->            // set dialog message
                (dialog as AlertDialog).setMessage(_dialog_message)
            DIALOG_MERGEPROMPT -> {
                // set contact's name
                (dialog.findViewById<View>(R.id.sub_title) as TextView).text =
                    _dialog_message
                // and set up reference to dialog
                _merge_prompt_dialog = dialog
            }
        }
        super.onPrepareDialog(id, dialog)
    }

    private fun importContacts() {
        // switch interfaces
        findViewById<View>(R.id.doit_page_2).visibility = View.VISIBLE

        // disable back button
        (findViewById<View>(R.id.back) as Button).isEnabled = false

        // create importer
        _importer = VcardImporter(this)

        // start the service's thread
        _importer?.start()
    }

    private fun updateProgress() {
        val bar = findViewById<View>(R.id.doit_progress) as ProgressBar
        val out_of = findViewById<View>(R.id.doit_outof) as TextView
        if (_max_progress > 0) {
            bar.max = _max_progress
            bar.secondaryProgress = _tmp_progress
            if (_started_progress) {
                (findViewById<View>(R.id.doit_percentage) as TextView).setText(
                    Math.round((100 * _progress / _max_progress).toFloat()).toString() + "%"
                )
                out_of.text = "${getString(R.string.import_contact)}  $_progress/$_max_progress"
                bar.progress = _progress
            }
        }
    }

    private fun updateStats() {
        (findViewById<View>(R.id.doit_overwrites) as TextView).text = "" + _count_overwrites
        (findViewById<View>(R.id.doit_creates) as TextView).text = "" + _count_creates
        (findViewById<View>(R.id.doit_merges) as TextView).text = "" + _count_merges
        (findViewById<View>(R.id.doit_skips) as TextView).text = "" + _count_skips
    }

    private fun abortImport(show_toaster_popup: Boolean) {
        if (_importer != null) {
            // try and flag worker thread - did we need to?
            if (_importer!!.setAbort()) {
                // wait for worker thread to end
                while (true) {
                    try {
                        _importer!!.join()
                        break
                    } catch (e: InterruptedException) {
                    }
                }

                // notify the user
                if (show_toaster_popup) Toast.makeText(
                    this, R.string.doit_importaborted,
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        // destroy some stuff
        _importer = null
        _handler = null
    }

    companion object {
        private const val DIALOG_ERROR = 0
        private const val DIALOG_CONTINUEORABORT = 1
        private const val DIALOG_MERGEPROMPT = 2
        const val MESSAGE_ALLDONE = 0
        const val MESSAGE_ABORT = 1
        const val MESSAGE_ERROR = 3
        const val MESSAGE_CONTINUEORABORT = 4
        const val MESSAGE_SETPROGRESSMESSAGE = 5
        const val MESSAGE_SETMAXPROGRESS = 6
        const val MESSAGE_SETTMPPROGRESS = 7
        const val MESSAGE_SETPROGRESS = 8
        const val MESSAGE_MERGEPROMPT = 9
        const val MESSAGE_CONTACTOVERWRITTEN = 10
        const val MESSAGE_CONTACTCREATED = 11
        const val MESSAGE_CONTACTMERGED = 12
        const val MESSAGE_CONTACTSKIPPED = 13
        const val ACTION_PROMPT = 0
        const val ACTION_KEEP = 1
        const val ACTION_MERGE_MERGE = 2
        const val ACTION_OVERWRITE = 3
        const val NEXT_CLOSE = 1
        var actionInt=ACTION_KEEP

//        fun convertIdToAction(id: Int): Int {
//            return when (id) {
//                R.id.merge_keep -> ACTION_KEEP
//                R.id.merge_merge -> ACTION_MERGE_MERGE
//                R.id.merge_overwrite -> ACTION_OVERWRITE
//                else -> ACTION_PROMPT
//            }
//        }
//        fun convertActionToId(action: Int): Int {
//            return when (action) {
//                ACTION_KEEP -> R.id.merge_keep
//                ACTION_MERGE_MERGE -> R.id.merge_merge
//                ACTION_OVERWRITE -> R.id.merge_overwrite
//                else -> R.id.merge_prompt
//            }
//        }

    }
}