package com.backup.restore.device.image.recovery.maincontact.adapter

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.maincontact.adapter.ContactBackupAdapter.MyBackup
import com.backup.restore.device.image.recovery.maincontact.callbacks.OnBackupItemClick
import com.backup.restore.device.image.recovery.maincontact.model.CountNameModel
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import ezvcard.Ezvcard
import ezvcard.VCard
import java.io.File
import java.util.*

class ContactBackupAdapter(
    private val mContext: Context,
    var mContactList: ArrayList<File?>?,
    var mCountNameModels: ArrayList<CountNameModel>,
    private val moOnBackupItemClick: OnBackupItemClick
) : RecyclerView.Adapter<MyBackup>() {

    class MyBackup(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvDate: TextView = itemView.findViewById(R.id.tvDate)
        var tvCount: TextView = itemView.findViewById(R.id.tvCount)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyBackup {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.raw_backup_row_item, parent, false)
        return MyBackup(view)
    }

    override fun onBindViewHolder(holder: MyBackup, position: Int) {
        val path = mContactList!![position]!!.absolutePath
        val filename = path.substring(path.lastIndexOf("/") + 1)
        val vCards: List<VCard> = Ezvcard.parse(path).all()

        holder.tvDate.text = filename.replace(".vcf", "")
        holder.tvCount.text = "(" + mCountNameModels[position].count +")"
//        holder.tvCount.text = "(" + vCards.size +")"

        holder.itemView.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            val file = mContactList!![position]
            if (file!!.exists()) {
                moOnBackupItemClick.onItemClick(mCountNameModels[position], mContactList!![position], position)
                val i = Intent("intentFilter")
                mContext.sendBroadcast(i)
            } else {
                Toast.makeText(mContext, mContext.getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun getItemCount(): Int {
        return mContactList!!.size
    }
}