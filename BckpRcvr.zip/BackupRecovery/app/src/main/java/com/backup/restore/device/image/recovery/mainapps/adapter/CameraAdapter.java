/*
Copyright 2020 Mrudul Tora (ToraLabs)
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
package com.backup.restore.device.image.recovery.mainapps.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.backup.restore.device.image.recovery.R;
import com.backup.restore.device.image.recovery.mainapps.model.CameraModel;

import java.util.List;

/**
 * Created by @mrudultora
 */

public class CameraAdapter extends RecyclerView.Adapter<CameraAdapter.Viewholder> {
    private final Context context;
    List<CameraModel> list;
    CameraClickListener clickListener;

    public CameraAdapter(Context context, List<CameraModel> list, CameraClickListener clickListener) {
        this.context = context;
        this.list = list;
        this.clickListener = clickListener;
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_camera_layout, parent, false);
        return new Viewholder(view, clickListener);
    }


//    @Override
//    public void onBindViewHolder(@NonNull Viewholder holder, int position, @NonNull List<Object> payloads) {
//        if (!payloads.isEmpty()) {
//            if (payloads.get(0) instanceof Integer) {
//                if ((Integer) payloads.get(0) == 1 && list.get(position).isSelected()) {
//                    holder.checkBox.setVisibility(View.VISIBLE);
//                    holder.title.setTextColor(context.getResources().getColor(R.color.colorPrimary));
//                } else if ((Integer) payloads.get(0) == 2) {
//                    holder.checkBox.setVisibility(View.GONE);
//                    holder.title.setTextColor(context.getResources().getColor(R.color.black));
//                }
//            }
//        } else
//            super.onBindViewHolder(holder, position, payloads);
//    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, int position) {
//        holder.cardView.setCardBackgroundColor(color);
        holder.txtFocal.setText(list.get(position).getTxtFocal());
        holder.title.setText(list.get(position).getTitle());
        holder.txtPixel.setText(list.get(position).getTxtPixel());
        holder.checkBox.setEnabled(false);
        holder.checkBox.setVisibility(View.INVISIBLE);
        holder.title.setTextColor(context.getResources().getColor(R.color.black));
        if (list.get(position).isSelected()) {
            holder.checkBox.setEnabled(true);
            holder.checkBox.setVisibility(View.VISIBLE);
            holder.title.setTextColor(context.getResources().getColor(R.color.colorPrimary));
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class Viewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
//        CardView cardView;
        TextView title, txtPixel, txtFocal;
        View checkBox;
        ConstraintLayout rel_cam;
        CameraClickListener cameraClickListener;

        public Viewholder(@NonNull View itemView, CameraClickListener clickListener) {
            super(itemView);
//            cardView = itemView.findViewById(R.id.cardView);
            this.cameraClickListener = clickListener;
            title = itemView.findViewById(R.id.title);
            txtPixel = itemView.findViewById(R.id.txtPixel);
            txtFocal = itemView.findViewById(R.id.txtFocal);
            checkBox = itemView.findViewById(R.id.checkbox);
            rel_cam = itemView.findViewById(R.id.rel_cam);
            rel_cam.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            cameraClickListener.onClickItem(getAdapterPosition(), checkBox);
        }
    }

    public interface CameraClickListener {
        void onClickItem(int position, View v);
    }
}
