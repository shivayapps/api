package com.backup.restore.device.image.recovery.mainduplicate.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateNumberListModel

class IndividualContactAdapter(
    var individualContactAdapterContext: Context,
    var groupOfDupesContacts: ArrayList<DuplicateNumberListModel>,
    var isSelected: Boolean
) : RecyclerView.Adapter<IndividualContactAdapter.ContactViewHolder>() {

    var mLayoutManager: LinearLayoutManager? = null

    class ContactViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var checkBox: CheckBox = itemView.findViewById<View>(R.id.cb_grp_checkbox) as CheckBox
        var recyclerView: RecyclerView = itemView.findViewById<View>(R.id.rv_contact) as RecyclerView
        var textView: TextView = itemView.findViewById(R.id.tv_grp_name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        return ContactViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.adapter_media_contact, parent, false)
        )
    }

    public fun setSelection(isSelect: Boolean){
        for (i in groupOfDupesContacts.indices)
            groupOfDupesContacts[i].isFileCheckBox=isSelect
    }

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
//        groupOfDupesContacts[holder.adapterPosition].isFileCheckBox=isSelected
        val individualGroup = groupOfDupesContacts[holder.adapterPosition]
//        holder.textView.text = "Set " + individualGroup.mMainKey!!.replace("[", "").replace("]", "").replace("\"", "").replace(",", "")
        holder.textView.text = "${individualContactAdapterContext.getString(R.string.set)} ${position + 1}"

//        holder.checkBox.isChecked = boolean
        holder.checkBox.isChecked = individualGroup.isFileCheckBox
//        holder.checkBox.isChecked = SharedPrefsConstant.getBooleanNoti(individualContactAdapterContext, "duplicateSelection", true)
//        individualGroup.isFileCheckBox = holder.checkBox.isChecked

        mLayoutManager = LinearLayoutManager(individualContactAdapterContext)

        val lListContactAdapter = ListContactAdapter(individualContactAdapterContext, individualGroup.mNumberList)
        holder.recyclerView.layoutManager = mLayoutManager
        holder.recyclerView.adapter = lListContactAdapter

        holder.checkBox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            buttonView.setOnClickListener {
                groupOfDupesContacts[holder.adapterPosition].isFileCheckBox=isChecked
//                individualGroup.isFileCheckBox = isChecked
                val lListContactAdapter1 = ListContactAdapter(individualContactAdapterContext, individualGroup.mNumberList)
                holder.recyclerView.adapter = lListContactAdapter1
                lListContactAdapter1.notifyDataSetChanged()
            }
        }
    }

    fun getSelectedCounted(): Int {
        val selectedList = groupOfDupesContacts.filter { it.isFileCheckBox!! }
        return selectedList.size
    }

    fun getSelectedList(): ArrayList<DuplicateNumberListModel> {
        val list = ArrayList<DuplicateNumberListModel>()
        groupOfDupesContacts.forEach {
            if (it.isFileCheckBox!!) {
                list.add(it)
            }
        }
        return list
    }

    override fun getItemCount(): Int {
        return groupOfDupesContacts.size
    }

}