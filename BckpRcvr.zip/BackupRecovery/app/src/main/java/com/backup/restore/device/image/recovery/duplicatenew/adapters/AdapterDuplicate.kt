package com.backup.restore.device.image.recovery.duplicatenew.adapters

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.duplicatenew.adapters.AdapterDuplicate.ContactsViewHolder
import com.backup.restore.device.image.recovery.duplicatenew.models.FileDetails
import com.backup.restore.device.image.recovery.duplicatenew.utils.Constants
import com.backup.restore.device.image.recovery.mainduplicate.activity.duplicateactivities.NewDuplicateMediaActivityNEW
import com.backup.restore.device.image.recovery.mainduplicate.callbacks.MarkedListener
import com.backup.restore.device.image.recovery.utilities.MyAnnotations
import com.backup.restore.device.image.recovery.utilities.common.GlobalVarsAndFunctions

public class AdapterDuplicate(
    private val individualOtherAdapterContext: Context,
    private val duplicateListener: MarkedListener,
    var scanType: String
) : RecyclerView.Adapter<ContactsViewHolder>() {

    var duplicateListAdapter: AdapterGroup? = null

    inner class ContactsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val recyclerView: RecyclerView = itemView.findViewById(R.id.rv_documents)
        val textView: TextView = itemView.findViewById(R.id.tv_grp_name)
        val checkboxGroup: CheckBox = itemView.findViewById(R.id.checkbox_group)
        val llCheckbox: LinearLayout = itemView.findViewById(R.id.ll_checkbox)

        init {
            recyclerView.isNestedScrollingEnabled = false
        }
    }

    fun getSelectedFile(): ArrayList<FileDetails> {
        val fileToBeDeleted: ArrayList<FileDetails> = ArrayList()
        for(group in GlobalVarsAndFunctions.listOfDuplicates){
            for(fileDetail in group.individualGrpOfDupes!!) {
                if(fileDetail.isChecked) {
                    fileToBeDeleted.add(fileDetail)
                }
            }
        }
        return fileToBeDeleted
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactsViewHolder {
        if(scanType==MyAnnotations.IMAGES || scanType==MyAnnotations.VIDEOS) {
            return ContactsViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.adapter_similar_document, parent, false))
        } else if(scanType==MyAnnotations.AUDIOS || scanType==MyAnnotations.DOCUMENTS|| scanType==MyAnnotations.OTHER) {
            return ContactsViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.adapter_media_document, parent, false))
        } else  {
            return ContactsViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.adapter_media_document, parent, false))
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ContactsViewHolder, @SuppressLint("RecyclerView") position: Int) {

        holder.textView.text = "${individualOtherAdapterContext.getString(R.string.set)} " + (position + 1)
        val mLayoutManager = GridLayoutManager(individualOtherAdapterContext, 2)
        if (scanType == MyAnnotations.AUDIOS || scanType == MyAnnotations.DOCUMENTS || scanType == MyAnnotations.OTHER) {
            mLayoutManager.spanCount = 1
        }

        holder.checkboxGroup.isChecked = GlobalVarsAndFunctions.listOfDuplicates[position].isCheckBox
        var checkCount = 0
        for (fileDetails in GlobalVarsAndFunctions.listOfDuplicates[position].individualGrpOfDupes!!) {
            if (fileDetails.isChecked) checkCount++
        }

        if (checkCount == GlobalVarsAndFunctions.listOfDuplicates.size - 1) holder.checkboxGroup.isChecked = true

        duplicateListAdapter = AdapterGroup(
            individualOtherAdapterContext,
            scanType, position, holder.checkboxGroup
        ) {
            duplicateListAdapter!!.getTotalSize()
            GlobalVarsAndFunctions.fileToBeDeleted.addAll(duplicateListAdapter!!.getSelectedFiles())
            duplicateListener.updateMarked()
        }

        holder.recyclerView.layoutManager = mLayoutManager
        holder.recyclerView.adapter = duplicateListAdapter

//        holder.checkboxGroup.setOnCheckedChangeListener { buttonView, isChecked ->
        holder.llCheckbox.setOnClickListener {
            if(NewDuplicateMediaActivityNEW.isScanRunning) {
                Toast.makeText(individualOtherAdapterContext,individualOtherAdapterContext.getString(R.string.process_running_please_wait), Toast.LENGTH_SHORT).show()
            } else {
                holder.checkboxGroup.toggle()
                setCheckBox(GlobalVarsAndFunctions.listOfDuplicates[position].individualGrpOfDupes!!, holder.checkboxGroup.isChecked)
                duplicateListAdapter = AdapterGroup(
                    individualOtherAdapterContext,
                    scanType, position, holder.checkboxGroup
                ) {
                    duplicateListAdapter!!.getTotalSize()
                    GlobalVarsAndFunctions.fileToBeDeleted.addAll(duplicateListAdapter!!.getSelectedFiles())
                    duplicateListener.updateMarked()
                }
                holder.recyclerView.layoutManager = mLayoutManager
                holder.recyclerView.adapter = duplicateListAdapter
                duplicateListener.updateMarked()
                duplicateListAdapter?.notifyDataSetChanged()
            }

        }
    }


    private fun setCheckBox(imageItems: List<FileDetails>, value: Boolean){
//    private fun setCheckBox(value: Boolean): List<FileDetails> {
//        val lListOfDupes: MutableList<FileDetails> = ArrayList()
        for (i in imageItems.indices) {
            val imageItem = imageItems[i]
            when {
                i != 0 -> {
                    if (!value) {
                        GlobalVarsAndFunctions.fileToBeDeleted.remove((imageItem))
                        Constants.minusSize(imageItem.fileSize)
                    } else if (!imageItem.isChecked) {
                        GlobalVarsAndFunctions.fileToBeDeleted.add(imageItem)
                        Constants.addSize(imageItem.fileSize)
                    }
                    imageItem.isChecked = value
//                    lListOfDupes.add(imageItem)
//                    duplicateListener.updateMarked()
                }
                imageItem.isChecked -> {
//                    GlobalVarsAndFunctions.fileToBeDeleted.remove((imageItem))
//                    Constants.fileSize -= imageItem.fileSize
                    imageItem.isChecked = false
//                    lListOfDupes.add(imageItem)
//                    duplicateListener.updateMarked()
                }
                else -> {
                    imageItem.isChecked = false
//                    lListOfDupes.add(imageItem)
//                    duplicateListener.updateMarked()
                }
            }
        }
//        return lListOfDupes
    }

    private fun getSelectedItem(): List<FileDetails> {
        val lListOfSelected: MutableList<FileDetails> = ArrayList()
        return lListOfSelected
    }

    override fun getItemCount(): Int {
        return GlobalVarsAndFunctions.listOfDuplicates.size
    }
}