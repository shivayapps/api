package com.backup.restore.device.image.recovery.mainduplicate.asynctask;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.backup.restore.device.image.recovery.R;
import com.backup.restore.device.image.recovery.mainduplicate.callbacks.MarkedListener;
import com.backup.restore.device.image.recovery.mainduplicate.model.IndividualGroupModel;
import com.backup.restore.device.image.recovery.mainduplicate.model.ItemDuplicateModel;
import com.backup.restore.device.image.recovery.mainduplicate.model.PopUp;
import com.backup.restore.device.image.recovery.utilities.common.GlobalVarsAndFunctions;
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants;

import java.util.ArrayList;
import java.util.List;


public class DeleteDuplicateFileAsyncTask extends AsyncTask<Void, Void, Void> {

    Activity deleteActivity;
    Context deleteContext;
    //    private ProgressDialog deleteDialog;
    Dialog dialog;
    TextView tv_permission_Text;
    long deleteFileSize;
    int FileDeletingCount = 0;
    ArrayList<ItemDuplicateModel> fileToBeDeleted;
    List<IndividualGroupModel> groupOfDuplicates;
    MarkedListener mMarkedListener;
    String message;
    String mIsType;

    public DeleteDuplicateFileAsyncTask(String isType, Context context, Activity activity, MarkedListener imagesMarkedListener, String messages, ArrayList<ItemDuplicateModel> fileToDeletedList, long deletingFileSize, List<IndividualGroupModel> groupOfDuplicatesList) {
        mIsType = isType;
        deleteContext = context;
        deleteActivity = activity;
        mMarkedListener = imagesMarkedListener;
        message = messages;
        fileToBeDeleted = fileToDeletedList;
        deleteFileSize = deletingFileSize;
        groupOfDuplicates = groupOfDuplicatesList;
//        mBuilder = new NotificationCompat.Builder(deleteContext, type);
//        mNoti=context.getString(R.string.deleting_files);
        if (fileToDeletedList != null) {
            FileDeletingCount = fileToDeletedList.size();
        }
    }

    protected void onPreExecute() {
        super.onPreExecute();
        dialog = new Dialog(deleteActivity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_delete_progress);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        tv_permission_Text = dialog.findViewById(R.id.permission_text);
        tv_permission_Text.setText(message);
        Button dialogButtonCancel = dialog.findViewById(R.id.dialogButtonCancel);
        dialogButtonCancel.setVisibility(View.GONE);
//        dialogButtonCancel.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (dialog != null) {
//                    if(dialog.isShowing()) dialog.dismiss();
//                }
//            }
//        });

    }

    protected Void doInBackground(Void... params) {
        Log.e("GlobalVarsAndFunctions", "deletePhotosByPosition:doInBackground:" + fileToBeDeleted.size());
        if (fileToBeDeleted != null) {
            deletePhotosByPosition();
        }
        return null;
    }

    private void deletePhotosByPosition() {
        List<IndividualGroupModel> groupOfDuplicatesLocal = groupOfDuplicates;
        List<ItemDuplicateModel> listOfFilesToBeDeleted = fileToBeDeleted;
        Log.e("GlobalVarsAndFunctions", "deletePhotosByPosition:fromAsync");
        Log.e("GlobalVarsAndFunctions", "deletePhotosByPosition-listOfFilesToBeDeleted:" + listOfFilesToBeDeleted.size());
        Log.e("GlobalVarsAndFunctions", "deletePhotosByPosition-groupOfDuplicatesLocal:" + groupOfDuplicatesLocal.size());

        for (ItemDuplicateModel item : listOfFilesToBeDeleted) {
            Log.e("GlobalVarsAndFunctions", "ToBeDeleted:" + item.getFilePath());
            Log.e("GlobalVarsAndFunctions", "ToBeDeleted:" + item.getFilePosition());
            Log.e("GlobalVarsAndFunctions", "ToBeDeleted:" + item.getFileItemGrpTag());
        }

        for (int i = 0; i < listOfFilesToBeDeleted.size(); i++) {
            ItemDuplicateModel imageItem = listOfFilesToBeDeleted.get(i);
//            GlobalVarsAndFunctions.deleteFile(deleteActivity, deleteContext, imageItem.getFilePath());

            int imageTag = imageItem.getFileItemGrpTag();
            int position = imageItem.getFilePosition();
            Log.e("GlobalVarsAndFunctions", "deletePhotosByPosition:position:" + position);
            Log.e("GlobalVarsAndFunctions", "deletePhotosByPosition:imageTag:" + imageTag);
//            IndividualGroupModel individualGroup = groupOfDuplicatesLocal.get(imageTag - 1);

            for (int j = 0; j < groupOfDuplicatesLocal.size(); j++) {
                IndividualGroupModel individualGroup = groupOfDuplicatesLocal.get(j);
                if (individualGroup.getGroupTag() == imageTag) {
                    List<ItemDuplicateModel> imageItems = individualGroup.getIndividualGrpOfDupes();
                    if (imageItems != null) {
                        for (int k = 0; k < imageItems.size(); k++) {
                            ItemDuplicateModel imageItem1 = imageItems.get(k);
                            if (imageItem1.getFilePosition() == position) {
                                Log.e("GlobalVarsAndFunctions", "deleteFile:fromAsync");
                                GlobalVarsAndFunctions.deleteFile(deleteActivity, deleteContext, imageItem1.getFilePath());
                                imageItems.remove(imageItem1);
                            }
                        }
                    }
                    individualGroup.setIndividualGrpOfDupes(imageItems);
                }
                individualGroup.setCheckBox(false);
            }

//            Log.e("GlobalVarsAndFunctions", "deletePhotosByPosition:imageItems:" + imageItems.size());

//            for (int j = 0; j < imageItems.size(); j++) {
//                ItemDuplicateModel imageItem1 = imageItems.get(j);
//                if (imageItem1.getFilePosition() == position) {
//                    Log.e("GlobalVarsAndFunctions", "deleteFile:fromAsync");
//                    GlobalVarsAndFunctions.deleteFile(deleteActivity, deleteContext, imageItem1.getFilePath());
//                    imageItems.remove(imageItem1);
//                }
//            }
//            individualGroup.setIndividualGrpOfDupes(imageItems);
//            individualGroup.setCheckBox(false);

            int finalI = i;
            deleteActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    tv_permission_Text.setText(finalI + "/" + listOfFilesToBeDeleted.size() + "\n" + message);
                }
            });

        }
    }


    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        if (dialog.isShowing()) {
            dialog.cancel();
//            setOtherDuplicateAdapterWithData(mMarkedListener);
            new PopUp(deleteContext, deleteActivity).showSpaceRecoveredPopUp(mIsType, FileDeletingCount == 1 ? deleteContext.getString(R.string.others_cleaned_single) + FileDeletingCount : deleteContext.getString(R.string.others_cleaned) + FileDeletingCount, deleteContext.getString(R.string.space_regained) + ShareConstants.getReadableFileSize(deleteFileSize), mMarkedListener, FileDeletingCount);
        }
    }


//    private void setOtherDuplicateAdapterWithData(MarkedListener otherMarkedListener) {
//        DuplicateOthersActivity.groupOfDupes = PopUp.sortByPhotosDateAscending(GlobalVarsAndFunctions.listOfGroupedDuplicatesOthers);
//        if (DuplicateOthersActivity.filterListOthers.size() != GlobalVarsAndFunctions.uniqueOthersExtensionAfterDuplicates.size() && DuplicateOthersActivity.filterListOthers.size() > 0) {
//            List<IndividualGroupModel> newIndividualGroupOthers = new ArrayList<>();
//            for (Entry<String, Boolean> entry : DuplicateOthersActivity.filterListOthers.entrySet()) {
//                String ext = (String) entry.getKey();
//                if (DuplicateOthersActivity.groupOfDupes != null) {
//                    for (int j = 0; j < DuplicateOthersActivity.groupOfDupes.size(); j++) {
//                        IndividualGroupModel individualGroupOthers1 = (IndividualGroupModel) DuplicateOthersActivity.groupOfDupes.get(j);
//                        if (individualGroupOthers1.getGroupExtension().equalsIgnoreCase(ext)) {
//                            newIndividualGroupOthers.add(individualGroupOthers1);
//                        }
//                    }
//                }
//            }
//            DuplicateOthersActivity.groupOfDupes = newIndividualGroupOthers;
//        }
//        IndividualOtherAdapter individualOtherAdapter = new IndividualOtherAdapter(deleteContext, deleteActivity, otherMarkedListener, setOthersCheckBox(otherMarkedListener));
//        if (DuplicateOthersActivity.recyclerViewForIndividualGrp != null) {
//            DuplicateOthersActivity.recyclerViewForIndividualGrp.setAdapter(individualOtherAdapter);
//        }
//        individualOtherAdapter.notifyDataSetChanged();
//    }

//    private List<IndividualGroupModel> setOthersCheckBox(MarkedListener otherMarkedListener) {
//        List<IndividualGroupModel> listOfDupes = new ArrayList<>();
//        GlobalVarsAndFunctions.file_to_be_deleted_others.clear();
//        GlobalVarsAndFunctions.size_Of_File_others = 0;
//        if (DuplicateOthersActivity.groupOfDupes != null) {
//            for (int i = 0; i < DuplicateOthersActivity.groupOfDupes.size(); i++) {
//                IndividualGroupModel individualGroup = (IndividualGroupModel) DuplicateOthersActivity.groupOfDupes.get(i);
//                individualGroup.setCheckBox(false);
//                List<ItemDuplicateModel> list = new ArrayList<>();
//                for (int j = 0; j < individualGroup.getIndividualGrpOfDupes().size(); j++) {
//                    ItemDuplicateModel otherItem = (ItemDuplicateModel) individualGroup.getIndividualGrpOfDupes().get(j);
//                    if (j != 0) {
//                        if (otherItem.isFileCheckBox()) {
//                            GlobalVarsAndFunctions.file_to_be_deleted_others.add(otherItem);
//                            GlobalVarsAndFunctions.addSizeOthers(otherItem.getSizeOfTheFile());
//                        }
//                        otherMarkedListener.updateMarked();
//                    }
//                    otherItem.setFileCheckBox(otherItem.isFileCheckBox());
//                    list.add(otherItem);
//                }
//                individualGroup.setIndividualGrpOfDupes(list);
//                listOfDupes.add(individualGroup);
//            }
//        }
//        return listOfDupes;
//    }
}
