package com.backup.restore.device.image.recovery.mainduplicate.model

class IgnorePath {
    var pathId: Long = 0
    var name: String = ""
    var path: String = ""
}