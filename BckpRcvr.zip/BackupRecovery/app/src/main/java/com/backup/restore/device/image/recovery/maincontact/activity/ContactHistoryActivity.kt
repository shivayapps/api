package com.backup.restore.device.image.recovery.maincontact.activity

import android.Manifest
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.ViewPager
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.mainapps.fragment.HistoryExcelFragment
import com.backup.restore.device.image.recovery.mainapps.fragment.HistoryPdfFragment
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.checkPermissionStorage
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlinx.android.synthetic.main.activity_contact_history.*
import org.greenrobot.eventbus.EventBus
import java.util.*


class ContactHistoryActivity : MyCommonBaseActivity() {

    var mViewPager: ViewPager? = null
    var lViewPagerAdapter : ViewPagerAdapter? = null
    val mPermissionStorage = arrayOf(
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    )

    var fragmentExcel: HistoryExcelFragment?=null
    var fragmentPdf: HistoryPdfFragment?=null
    var selectedPos = 0

    companion object {
        @JvmField
        var isFrom = ""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact_history)
        addEvent(ContactHistoryActivity::class.simpleName!!)
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
    }

    override fun getContext(): AppCompatActivity {
        return this@ContactHistoryActivity
    }

    override fun initData() {
        mViewPager = findViewById(R.id.viewpager)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            checkAllFilePermission()
        } else {
            if (checkPermissionStorage(mContext)) {
                setAllData()
            } else {
                givePermissions(mPermissionStorage)
            }
        }
    }

    override fun initActions() {
        ivDeleteAll.setOnClickListener {
            if(mViewPager?.currentItem==0) {
                fragmentExcel?.deleteAll()
            } else {
                fragmentPdf?.deleteAll()
            }
        }
    }

    private fun setAllData() {
        fragmentExcel = HistoryExcelFragment.newInstance()
        fragmentPdf = HistoryPdfFragment.newInstance()

        setupViewPager(mViewPager)
        mViewPager!!.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
            }

            override fun onPageSelected(position: Int) {
                Log.e("mTAG", "onPageSelected: $position")
                if (position == 0) {
                    isFrom = "BackUpExcel"
                } else {
                    isFrom = "BackUpPdf"
                }
                initViewActions(position)
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })
        viewExcel!!.setOnClickListener(this)
        viewPdf!!.setOnClickListener(this)
        iv_back.setOnClickListener(this)
        Handler(Looper.getMainLooper()).postDelayed(Runnable {
            initViewActions(0)
        },1000)

    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 100) {
            return
        }
        ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.viewExcel -> {
                isFrom = "PdfBack"
                EventBus.getDefault().post("ExcelBack")
                mViewPager!!.currentItem = 0
            }
            R.id.viewPdf -> {
                isFrom = "PdfBack"
                EventBus.getDefault().post("PdfBack")
                mViewPager!!.currentItem = 1
            }
            R.id.iv_back -> onBackPressed()
        }
    }

    private fun setupViewPager(viewPager: ViewPager?) {
        lViewPagerAdapter = ViewPagerAdapter(supportFragmentManager)
        lViewPagerAdapter!!.addFrag(fragmentExcel!!, "HistoryExcel")
        lViewPagerAdapter!!.addFrag(fragmentPdf!!, "HistoryPdf")

        viewPager!!.adapter = lViewPagerAdapter
    }

    private fun givePermissions(permissions: Array<String>) {

        MyApplication.isInternalCall = true

        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                setAllData()
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionStorage)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest>,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            }).check()
    }

    fun showSettingsDialog() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            openSettings()
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            finish()
//            if(isFromOneSignal) {
//                startActivity(NewHomeActivity.newIntent(this))
//                finish()
//            }else{
//                finish()
//            }
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }


        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun openSettings() {
        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        MyApplication.isInternalCall = true
        startActivityForResult(intent, 200)
    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                setAllData()
            } else {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse(String.format("package:%s", packageName)))
                try {
                    MyApplication.isInternalCall = true
                    startActivityForResult(intent, 2296)
                } catch (e: ActivityNotFoundException) {
                }
            }
        }
    }

    private fun initViewActions(pos: Int) {
        if (pos == 0) {
            selectedPos=0
            isFrom = "ExcelBackUp"
            viewExcel.setBackgroundColor(Color.parseColor("#4EAF4F"))
            viewPdf.setBackgroundColor(Color.parseColor("#FFFFFF"))
            if(fragmentExcel?.mExcelFiles!!.size==0) ivDeleteAll.visibility=View.INVISIBLE
            else ivDeleteAll.visibility=View.VISIBLE
//            viewExcel!!.setTextColor(Color.parseColor("#FFFFFF"))
//            viewPdf!!.setTextColor(Color.parseColor("#4EAF4F"))
        } else if (pos == 1) {
            selectedPos=1
            isFrom = "PdfBackUp"
            viewExcel.setBackgroundColor(Color.parseColor("#FFFFFF"))
            viewPdf.setBackgroundColor(Color.parseColor("#4EAF4F"))

            if(fragmentPdf?.mPdfFiles!!.size==0) ivDeleteAll.visibility=View.INVISIBLE
            else ivDeleteAll.visibility=View.VISIBLE
//            viewExcel!!.setTextColor(Color.parseColor("#4EAF4F"))
//            viewPdf!!.setTextColor(Color.parseColor("#FFFFFF"))
        }
    }

    class ViewPagerAdapter(manager: FragmentManager?) : FragmentPagerAdapter(manager!!) {

        private val mFragmentList: MutableList<Fragment> = ArrayList()
        private val mFragmentTitleList: MutableList<String> = ArrayList()

        override fun getItem(position: Int): Fragment {
            return mFragmentList[position]
        }

        override fun getCount(): Int {
            return mFragmentList.size
        }

        fun addFrag(fragment: Fragment, title: String) {
            mFragmentList.add(fragment)
            mFragmentTitleList.add(title)
        }

        override fun getPageTitle(position: Int): CharSequence {
            return mFragmentTitleList[position]
        }
    }
}