package com.backup.restore.device.image.recovery.newsecurity;

//import static com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant.flgNew;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.backup.restore.device.image.recovery.R;
import com.backup.restore.device.image.recovery.ads.openad.MyApplication;
import com.backup.restore.device.image.recovery.maincontact.activity.HideContactActivity;
import com.backup.restore.device.image.recovery.multilang.LocaleManager;
import com.backup.restore.device.image.recovery.multilang.Locales;
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant;

import java.util.ArrayList;
import java.util.Arrays;


public class MyPatternActivity extends AppCompatActivity {

    private static final String TAG = "MyPatternActivity";
    private static final PatternLockView.Password sDefaultPassword = new PatternLockView.Password(Arrays.asList(0, 1, 2, 3, 4, 5));

    public static String forWhat = "new_pattern";
    private static final int REQ_CODE_NEW_PATTERN_LOCK = 447;
    private PatternLockView mCurLockView;
    private PatternLockView mCircleLockView;
    private TextView mPasswordTextView;

    ImageView ivBack;

    Dialog SecurityDialog;
    TextView mLeftButton;
    Boolean flgNextActivity = false;
    Boolean isBackfromHalf = false;
    public int testPattern = 0;
    private PatternLockView.Password mPassword = sDefaultPassword;
    String mPreviousSelectedLanguageKey = Locales.INSTANCE.getEnglish().toString();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        LocaleManager.setLocale(MyPatternActivity.this);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        super.onCreate(savedInstanceState);
     /*   if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }*/
//        Utils.changeLanguage(this);
        setContentView(R.layout.activity_pattern_lock);
        mPreviousSelectedLanguageKey = LocaleManager.getLanguagePref(MyPatternActivity.this);

        mCircleLockView = (PatternLockView) findViewById(R.id.lock_view_circle);
        mPasswordTextView = (TextView) findViewById(R.id.password_text);
        mLeftButton = (TextView) findViewById(R.id.mLeftButton);
        ivBack = (ImageView) findViewById(R.id.ivBack);

        mPasswordTextView.setText(R.string.draw_a_pattern);

        switchLockViews();

        String patternValue = SharedPrefsConstant.getPattern(MyPatternActivity.this, SharedPrefsConstant.SAVEPATTERN);
        Log.e(TAG, "onCreate: patternValue -=-= > " + patternValue);
        Log.e(TAG, "onCreate: forWhat -=-= > " + forWhat);
//        if (patternValue != "") {
//            mLeftButton.setVisibility(View.VISIBLE);
//        } else {
//            mLeftButton.setVisibility(View.INVISIBLE);
//        }

        if (forWhat.equalsIgnoreCase("new_pattern")) {
            mPasswordTextView.setText(R.string.draw_a_pattern);
        } else if (forWhat.equalsIgnoreCase("unLock")) {
            if (SharedPrefsConstant.getBoolean(MyPatternActivity.this, SharedPrefsConstant.BREAKS_ALERT_ENABLE)) {
            }
            mLeftButton.setVisibility(View.VISIBLE);
            SharedPrefsConstant.alreadyIN = true;
            mPasswordTextView.setText(R.string.draw_a_pattern_unlock);
        } else if (forWhat.equalsIgnoreCase("remove")) {
            mPasswordTextView.setText(R.string.draw_a_pattern_remove_lock);
        } else if (forWhat.equalsIgnoreCase("change")) {
            mPasswordTextView.setText(R.string.draw_current_pattern);
        }
        String getPatternValue = SharedPrefsConstant.getPattern(MyPatternActivity.this, SharedPrefsConstant.SAVEPATTERN);
        if (getPatternValue != "") {
            if (SharedPrefsConstant.flgNew) {
                testPattern = 0;
            } else {
                Log.e(TAG, "onCreate: flgNextActivity = true");
                flgNextActivity = true;
                testPattern = 1;
                mPassword.string = getPatternValue;
            }
        }

        ivBack.setOnClickListener(v -> onBackPressed());

    }

    @Override
    protected void onResume() {
        super.onResume();
        restartIfRequires();
//        Utils.changeLanguage(this);
    }

    private void restartIfRequires() {
        if (mPreviousSelectedLanguageKey != LocaleManager.getLanguagePref(MyPatternActivity.this)) {
            SharedPrefsConstant.savePref(this, SharedPrefsConstant.IS_REFRESH_HOME, true);
            Log.e("TAG", "restartIfRequires: ");
            recreate();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        } else {
            SharedPrefsConstant.savePref(this, SharedPrefsConstant.IS_REFRESH_HOME, false);
        }
    }


    @Override
    public void onBackPressed() {

        if (forWhat.equalsIgnoreCase("unLock")) {
            Log.e(TAG, "onBackPressed: Start ");
//            SharedPrefsConstant.savePref(this,"IsFromHideActivity",true);
            super.onBackPressed();
//            startActivity(new Intent(this, ContactMainActivity.class).putExtra("IsFromHideActivity", true));
        }

        if (SharedPrefsConstant.getBoolean(MyPatternActivity.this, SharedPrefsConstant.isBackfromHalf)) {
            Log.e(TAG, "onBackPressed: " + isBackfromHalf);
            SharedPrefsConstant.savePattern(MyPatternActivity.this, SharedPrefsConstant.SAVEPATTERN, sDefaultPassword.string);
            SharedPrefsConstant.savePref(MyPatternActivity.this, SharedPrefsConstant.isBackfromHalf, false);
            SharedPrefsConstant.isfromFake = false;
            forWhat = "new_pattern";
            super.onBackPressed();
            testPattern = 0;
            SharedPrefsConstant.flgNew = false;
            forWhat = "unLock";

        }
//        startActivity(new Intent(this, ContactMainActivity.class).putExtra("IsFromHideActivity", true));
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

    }

    private void switchLockViews() {
        mPassword = sDefaultPassword;
        //  mCurLockView.stopPasswordAnim();

        mCurLockView = mCircleLockView;
        mCurLockView.setVisibility(View.VISIBLE);

        mCurLockView.reset();
        if (mCurLockView != mCircleLockView) {
            mCircleLockView.setVisibility(View.GONE);
            mCircleLockView.setCallBack(null);
            mCircleLockView.setOnNodeTouchListener(null);
            //        mSwitchButton.setText("switch to circle lock view");
        } else {
            //      mSwitchButton.setText("switch to dot lock view");
        }

        mCurLockView.setCallBack(new PatternLockView.CallBack() {
            @Override
            public int onFinish(PatternLockView.Password password) {

                if (forWhat.equalsIgnoreCase("new_pattern")) {
                    Log.e(TAG, "onFinish: new_pattern ");

                    if (testPattern == 0) {
                        if (mCircleLockView.nodeSize() < 4) {
                            testPattern = 0;
                            Toast.makeText(getApplicationContext(), getString(R.string.connect_dots), Toast.LENGTH_LONG).show();
                            // mPassword = password;
                            errorAction();
                            Log.e(TAG, "onFinish: IF testPattern == 0 ");

                            return PatternLockView.CODE_PASSWORD_ERROR;
                        } else {
                            testPattern = 1;
                            mPassword = password;
                            Log.e("testPattern", "testPattern == re_draw_pattern 001");
                            mPasswordTextView.setText(R.string.re_draw_pattern);
                            Log.e(TAG, "onFinish: password.string : " + password.string);
                            return PatternLockView.CODE_PASSWORD_CORRECT;
                        }

                    } else if (testPattern == 1) {
                        if (mPassword.equals(password)) {
                            Log.e(TAG, "onFinish : testPattern == 1");
//                            isBackfromHalf = true;
                            SharedPrefsConstant.save(MyPatternActivity.this, SharedPrefsConstant.PATTERN, password.string);
                            SharedPrefsConstant.save(MyPatternActivity.this, SharedPrefsConstant.LOCK, "pattern");
                            SharedPrefsConstant.savePattern(MyPatternActivity.this, SharedPrefsConstant.SAVEPATTERN, password.string);
                            SharedPrefsConstant.alreadyIN = false;
                            if (flgNextActivity) {

                            } else {
                                Toast.makeText(getApplicationContext(), getString(R.string.pattern_set_successfully), Toast.LENGTH_LONG).show();

                            }
                            SharedPrefsConstant.flgNew = false;
                            Log.e("testPattern", "testPattern == ok 002");
                            Intent intent = new Intent(MyPatternActivity.this, HideContactActivity.class);
                            startActivity(intent);
                            setResult(RESULT_OK, intent);
                            finish();
                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

                            return PatternLockView.CODE_PASSWORD_CORRECT;
                        } else {
                            Log.e(TAG, "onFinish : testPattern == 1 else");
                            Toast.makeText(getApplicationContext(), getString(R.string.wrong_pattern), Toast.LENGTH_LONG).show();
                            // mPassword = password;
                            errorAction();
                            return PatternLockView.CODE_PASSWORD_ERROR;
                        }
                    }
                } else {

                    Log.e(TAG, "onFinish: ");
                    String patternValue = SharedPrefsConstant.getPattern(MyPatternActivity.this, SharedPrefsConstant.SAVEPATTERN);
                    if (!patternValue.equals("")) {

//                        String pattern = patternValue.toString();

                        Log.e(TAG, "onFinish : patternValue != null patternValue : " + patternValue + " password " + password);
                        Log.e(TAG, "onFinish : new password : " + password.string);

                        if (password.string.equals(patternValue)) {
                            Log.e(TAG, "onFinish : patternValue != null if ");

                            Log.e("testPattern", "testPattern == ok 003");
                            Intent intent = new Intent(MyPatternActivity.this, HideContactActivity.class);
                            startActivity(intent);
                            setResult(RESULT_OK, intent);
                            finish();
                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        } else {
                            Log.e(TAG, "onFinish : patternValue != null else ");
                            Toast.makeText(getApplicationContext(), getString(R.string.wrong_pattern), Toast.LENGTH_LONG).show();

                            errorAction();
                            return PatternLockView.CODE_PASSWORD_ERROR;
                        }


                    } else {
                        Log.e(TAG, "onFinish : patternValue != null outer else ");

                        mLeftButton.setVisibility(View.INVISIBLE);

                        if (testPattern == 0) {
                            if (mCircleLockView.nodeSize() < 4) {
                                Log.e(TAG, "onFinish: else testPattern == 0 ");

                                testPattern = 0;
                                Toast.makeText(getApplicationContext(), getString(R.string.connect_dots), Toast.LENGTH_LONG).show();
                                // mPassword = password;

                                errorAction();
                                return PatternLockView.CODE_PASSWORD_ERROR;
                            } else {
                                testPattern = 1;
                                mPassword = password;
                                Log.e("testPattern", "testPattern == re_draw_pattern 002");
                                mPasswordTextView.setText(R.string.re_draw_pattern);
                                Log.e(TAG, "onFinish: password.string else : " + password.string);
                                return PatternLockView.CODE_PASSWORD_CORRECT;
                            }

                        } else if (testPattern == 1) {
                            if (mPassword.equals(password)) {

                                Log.e(TAG, "onFinish : testPattern == 1");

                                SharedPrefsConstant.save(MyPatternActivity.this, SharedPrefsConstant.PATTERN, password.string);
                                SharedPrefsConstant.save(MyPatternActivity.this, SharedPrefsConstant.LOCK, "pattern");

//                            isBackfromHalf = true;

                                SharedPrefsConstant.savePattern(MyPatternActivity.this, SharedPrefsConstant.SAVEPATTERN, password.string);
                                SharedPrefsConstant.alreadyIN = false;

                                SharedPrefsConstant.flgNew = false;

                                Log.e("testPattern", "testPattern == ok 001");
                                Intent intent = new Intent(MyPatternActivity.this, HideContactActivity.class);
                                startActivity(intent);
                                setResult(RESULT_OK, intent);
                                finish();
                                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

                                return PatternLockView.CODE_PASSWORD_CORRECT;
                            } else {
                                Log.e(TAG, "onFinish : testPattern == 1 else else part ");
                                Toast.makeText(getApplicationContext(), getString(R.string.wrong_pattern), Toast.LENGTH_LONG).show();

                                mPassword = password;
                                errorAction();
                                return PatternLockView.CODE_PASSWORD_ERROR;
                            }
                        }
                    }

                }
            /*    if (mPassword.equals(password)) {
                    return PatternLockView.CODE_PASSWORD_CORRECT;
                } else {
                    mPassword = password;
                    return PatternLockView.CODE_PASSWORD_ERROR;
                }*/
                return PatternLockView.CODE_PASSWORD_CORRECT;


            }
        });

        mCurLockView.setOnNodeTouchListener(new PatternLockView.OnNodeTouchListener() {
            @Override
            public void onNodeTouched(int NodeId) {
                Log.d(TAG, "node " + NodeId + " has touched!");
            }
        });

        mLeftButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSecurityDialog();
            }
        });


    }

    private void errorAction() {
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null) {
            v.vibrate(400);
        }
        final Animation animShake = AnimationUtils.loadAnimation(MyPatternActivity.this, R.anim.shake_lock);
        mCircleLockView.startAnimation(animShake);

    }

    private void openSecurityDialog() {

        View view = getLayoutInflater().inflate(R.layout.dialog_set_security_question, null);
        SecurityDialog = new Dialog(this);
        SecurityDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        SecurityDialog.setCanceledOnTouchOutside(false);
        SecurityDialog.setContentView(view);
        SecurityDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        SecurityDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        EditText et_enteranswer = SecurityDialog.findViewById(R.id.et_enteranswer);
        ArrayList<String> list = new ArrayList();
        list.add(getString(R.string.select_your_question));
        list.add(getString(R.string.which_is_your_favorite_movie));
        list.add(getString(R.string.what_is_your_favorite_food));
        list.add(getString(R.string.who_is_your_favorite_actress));
        list.add(getString(R.string.whats_your_lucky_number));
        list.add(getString(R.string.in_which_city_were_you_born));
        String[] que = {""};

        et_enteranswer.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        ((ImageView) SecurityDialog.findViewById(R.id.ivCloseDialog)).setOnClickListener(v -> {
            SecurityDialog.cancel();
            MyApplication.Companion.setDialogOpen(false);
        });
        ((ImageView) SecurityDialog.findViewById(R.id.ivDrop)).setOnClickListener(v -> {
            SecurityDialog.findViewById(R.id.spinner_d).performClick();
        });

        ((Spinner) SecurityDialog.findViewById(R.id.spinner_d)).setOnTouchListener((v, event) -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(((Spinner) SecurityDialog.findViewById(R.id.spinner_d)).getWindowToken(), 0);
            return false;
        });

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_layout, list);
        ((Spinner) SecurityDialog.findViewById(R.id.spinner_d)).setAdapter(adapter);

        ((Spinner) SecurityDialog.findViewById(R.id.spinner_d)).setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                et_enteranswer.getText().clear();
                que[0] = String.valueOf(parent.getItemAtPosition(position));
                if (position == 0) {
                    et_enteranswer.setEnabled(false);
                    que[0] = "none";
                } else {
                    et_enteranswer.setEnabled(true);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        ((CardView) SecurityDialog.findViewById(R.id.ln_submit)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (que[0] == "none") {
                    Toast.makeText(getApplicationContext(), getString(R.string.select_question), Toast.LENGTH_SHORT).show();
                } else {
                    if (et_enteranswer.getText().toString().trim().equals(""))
                        Toast.makeText(MyPatternActivity.this.getApplicationContext(), getString(R.string.enter_answer), Toast.LENGTH_SHORT).show();
                    else if (et_enteranswer.getText().toString().length() < 5)
                        Toast.makeText(MyPatternActivity.this.getApplicationContext(), getString(R.string.at_least_5_character), Toast.LENGTH_SHORT).show();
                    else {
                        if (que[0].equalsIgnoreCase(SharedPrefsConstant.getString(MyPatternActivity.this, SharedPrefsConstant.BACKUP_QUESTION))
                                && SharedPrefsConstant.getString(MyPatternActivity.this, SharedPrefsConstant.BACKUP_ANSWER).equalsIgnoreCase(et_enteranswer.getText().toString().trim())) {
                            SharedPrefsConstant.isfromFake = true;
                            forWhat = "new_pattern";
                            testPattern = 0;
                            SharedPrefsConstant.flgNew = true;
                            finish();
                            startActivityForResult(new Intent(MyPatternActivity.this, MyPatternActivity.class), REQ_CODE_NEW_PATTERN_LOCK);
                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        } else {
                            Toast.makeText(getApplicationContext(), getString(R.string.sorry_wrong), Toast.LENGTH_SHORT).show();
                        }
                        SecurityDialog.cancel();
                        MyApplication.Companion.setDialogOpen(false);
                    }
                }
            }
        });

        SecurityDialog.show();
        MyApplication.Companion.setDialogOpen(true);
    }

//    private void openSecurityDialog() {
//        final Dialog dialog = new Dialog(MyPatternActivity.this);
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        dialog.setContentView(R.layout.dialog_set_security_question);
//        Objects.requireNonNull(dialog.getWindow()).setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.95), ViewGroup.LayoutParams.WRAP_CONTENT);
//        //hide keyboard :
//        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
//        dialog.setCancelable(true);
//        dialog.setCanceledOnTouchOutside(false);
//
//
//        final EditText et_enteranswer = dialog.findViewById(R.id.et_enteranswer);
//        //  final LinearLayout im_remove = dialog.findViewById(R.id.im_remove);
//        final CardView ln_submit = dialog.findViewById(R.id.ln_submit);
//        final CardView ln_cancle = dialog.findViewById(R.id.ln_cancle);
//        final TextView txt_submit = dialog.findViewById(R.id.txt_submit);
//        final LinearLayout btnCancle1 = dialog.findViewById(R.id.btnCancle1);
//        final TextView tv_msg = dialog.findViewById(R.id.tv_msg);
//        final TextView tv_question = dialog.findViewById(R.id.tv_question);
//        final LinearLayout bothButton = dialog.findViewById(R.id.bothButton);
//        final LinearLayout btnVerify = dialog.findViewById(R.id.btnVerify);
//        final Spinner spinner = dialog.findViewById(R.id.spinner_d);
//        final TextView txtSecurity = dialog.findViewById(R.id.txtSecurity);
//        final ImageView ivCloseDialog = dialog.findViewById(R.id.ivCloseDialog);
//
//
//       /* final TextView tv_q = dialog.findViewById(R.id.tv_q);
//        final TextView tv_a = dialog.findViewById(R.id.tv_a);
//*/
//        txtSecurity.setVisibility(View.VISIBLE);
//        ln_submit.setVisibility(View.GONE);
//        bothButton.setVisibility(View.VISIBLE);
//        ln_cancle.setVisibility(View.GONE);
//        tv_question.setVisibility(View.VISIBLE);
//        spinner.setVisibility(View.GONE);
//        et_enteranswer.setEnabled(true);
//        txt_submit.setText("VERIFY");
////        tv_question.setText(SharedPrefsConstant.getString(MyPatternActivity.this, SharedPrefsConstant.BACKUP_QUESTION));
//        tv_msg.setVisibility(View.VISIBLE);
//
//        tv_msg.setText("Verify Question");
//
//        ivCloseDialog.setOnClickListener(new OnSingleClickListener() {
//            @Override
//            public void onSingleClick(View v) {
//                dialog.dismiss();
//                try {
//                    dialog.dismiss();
//                } catch (Exception e) {
//                }
//            }
//        });
//
//        btnVerify.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (et_enteranswer.getText().toString().trim().equals(""))
//                    Toast.makeText(MyPatternActivity.this.getApplicationContext(), "Please Enter Answer", Toast.LENGTH_SHORT).show();
//                else if (et_enteranswer.getText().toString().length() < 5)
//                    Toast.makeText(MyPatternActivity.this.getApplicationContext(), "Please Enter At Least 5 Character In Answer", Toast.LENGTH_SHORT).show();
//                else {
//                    if (tv_question.getText().toString().equalsIgnoreCase(SharedPrefsConstant.getString(MyPatternActivity.this, SharedPrefsConstant.BACKUP_QUESTION))
//                            && SharedPrefsConstant.getString(MyPatternActivity.this, SharedPrefsConstant.BACKUP_ANSWER).equalsIgnoreCase(et_enteranswer.getText().toString().trim())) {
//                        SharedPrefsConstant.savePattern(MyPatternActivity.this, SharedPrefsConstant.SAVEPATTERN, "");
//                        SharedPrefsConstant.isfromFake = true;
//                        forWhat = "new_pattern";
//                        testPattern = 0;
//                        flgNew = true;
//                        SharedPrefsConstant.savePref(MyPatternActivity.this, SharedPrefsConstant.isBackfromHalf, true);
//
//                        finish();
//                        startActivityForResult(new Intent(MyPatternActivity.this, MyPatternActivity.class), REQ_CODE_NEW_PATTERN_LOCK);
//                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
//                        dialog.dismiss();
//                    } else {
//                        et_enteranswer.setError("Doesn't match");
//                        et_enteranswer.setText("");
//                    }
//                }
//            }
//        });
//
//        btnCancle1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                dialog.dismiss();
//            }
//        });
//        et_enteranswer.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                if (et_enteranswer.getText().toString().length() == 0) {
//                    txt_submit.setTextColor(getResources().getColor(R.color.white));
//                } else {
//                    txt_submit.setTextColor(getResources().getColor(R.color.white));
//                }
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//            }
//        });
//
//
//        ln_submit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (et_enteranswer.getText().toString().trim().equals(""))
//                    Toast.makeText(MyPatternActivity.this.getApplicationContext(), "Please Enter Answer", Toast.LENGTH_SHORT).show();
//                else if (et_enteranswer.getText().toString().length() < 5)
//                    Toast.makeText(MyPatternActivity.this.getApplicationContext(), "Please Enter At Least 5 Character In Answer", Toast.LENGTH_SHORT).show();
//                else {
//                    if (tv_question.getText().toString().equalsIgnoreCase(SharedPrefsConstant.getString(MyPatternActivity.this, SharedPrefsConstant.BACKUP_QUESTION))
//                            && SharedPrefsConstant.getString(MyPatternActivity.this, SharedPrefsConstant.BACKUP_ANSWER).equalsIgnoreCase(et_enteranswer.getText().toString().trim())) {
//                        SharedPrefsConstant.isfromFake = true;
//                        forWhat = "new_pattern";
//                        testPattern = 0;
//                        flgNew = true;
//                        finish();
//                        startActivityForResult(new Intent(MyPatternActivity.this, MyPatternActivity.class), REQ_CODE_NEW_PATTERN_LOCK);
//                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
//                        dialog.dismiss();
//                    } else {
//                        et_enteranswer.setError("Doesn't match");
//                        et_enteranswer.setText("");
//                    }
//                }
//            }
//        });
//
//        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
//            @Override
//            public void onDismiss(DialogInterface dialogInterface) {
//
//            }
//        });
//
//        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
//            @Override
//            public void onShow(DialogInterface dialogInterface) {
//
//            }
//        });
//
//        ln_cancle.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                dialog.dismiss();
//            }
//        });
//        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
//        dialog.show();
//    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CODE_NEW_PATTERN_LOCK) {
            if (resultCode == RESULT_OK) {
                finish();
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            } else {
                forWhat = "unLock";
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // DO NOT FORGET TO CALL IT!
        mCurLockView.stopPasswordAnim();
    }
}
