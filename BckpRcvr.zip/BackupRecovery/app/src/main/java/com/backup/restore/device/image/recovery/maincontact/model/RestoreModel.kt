package com.backup.restore.device.image.recovery.maincontact.model

import android.graphics.Bitmap

class RestoreModel {
    var name: String? = null
    var number: String? = null
    var bitmap: Bitmap? = null
    var imageUri : String? = null
}