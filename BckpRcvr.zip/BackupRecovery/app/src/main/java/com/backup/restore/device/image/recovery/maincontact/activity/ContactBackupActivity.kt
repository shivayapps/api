package com.backup.restore.device.image.recovery.maincontact.activity

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.*
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.ads.rateandfeedback.ExitSPHelper
import com.backup.restore.device.image.recovery.maincontact.adapter.ContactBackupAdapter
import com.backup.restore.device.image.recovery.maincontact.callbacks.OnBackupItemClick
import com.backup.restore.device.image.recovery.maincontact.model.ContactModel
import com.backup.restore.device.image.recovery.maincontact.model.CountNameModel
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.RatingDialog
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import ezvcard.Ezvcard
import ezvcard.VCard
import kotlinx.android.synthetic.main.activity_backup.*
import java.io.File
import java.io.IOException
import java.util.*

class ContactBackupActivity : MyCommonBaseActivity(), View.OnClickListener {

    private val mTAG : String = ContactBackupActivity::class.java.simpleName

    private var mAllFiles: Array<File>? = null
    private var mContactBackupAdapter: ContactBackupAdapter? = null
//    private var mInterstitial: InterstitialAd? = null

    companion object {
        var CAlMyFile: ArrayList<File?>? = ArrayList()
        var count_name_array = ArrayList<CountNameModel>()
    }

//    override fun attachBaseContext(newBase: Context) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_backup)

    }

    override fun getContext(): AppCompatActivity {
        return this@ContactBackupActivity
    }

    override fun initData() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
        } else {
            ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString() + File.separator + "Android" + File.separator + "data" + File.separator + packageName + File.separator
        }

        val gridLayoutManager = GridLayoutManager(mContext, 1)
        rvBackup!!.layoutManager = gridLayoutManager
        ivDelete!!.alpha = 0.5f
        ivDelete!!.isEnabled = false
        loadBackupFile()

        if (AdsManager(this).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            NativeAdvancedModelHelper(mContext).loadNativeAdvancedAd(
                NativeAdsSize.Medium,
                findViewById(R.id.ad_view_container)
            )
        }else{
            findViewById<FrameLayout>(R.id.ad_view_container).visibility = View.GONE
        }
    }

    override fun initActions() {

        if (AdsManager(this).isNeedToShowAds()) {
            InterstitialAdHelper.loadInterstitialAd(fContext = mContext)
        }

        ivBack!!.setOnClickListener(this)
        ivDelete!!.setOnClickListener(this)
    }

    private fun loadBackupFile() {
        BackupListAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
    }

    private inner class BackupListAsyncTask : AsyncTask<Void?, Void?, Void?>() {
        val dialog = Dialog(mContext)

        override fun onPreExecute() {
            super.onPreExecute()

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

            dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.label_please_wait)
            dialog.findViewById<TextView>(R.id.permission_text).text = getString(R.string.fetching_backups)
            dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
                cancel(true)
                onBackPressed()
            }
            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }


            if (!dialog.isShowing) {
                dialog.show()
                MyApplication.isDialogOpen = true
            }
            CAlMyFile!!.clear()
            count_name_array.clear()
        }

        override fun doInBackground(vararg voids: Void?): Void? {
            try {
                val path = File(ShareConstants.mRootPath + "/Backup And Recovery/Contacts Backup")
                Log.e(mTAG, "PATH ===>$path")
                if (path.exists()) {
                    mAllFiles = path.listFiles { _, name -> name.endsWith(".vcf") }
                }

                if (mAllFiles != null) {
                    if (mAllFiles!!.isNotEmpty()) {
                        for (i in mAllFiles!!.indices) {
                            if (isCancelled) {
                                break
                            }
                            CAlMyFile!!.add(mAllFiles!![i])
                            var vcard: List<VCard>
                            try {
                                vcard = Ezvcard.parse(mAllFiles!![i]).all()
                                val name = StringBuffer()
                                val test: MutableList<String> = ArrayList()
//                                var count = 0
                                var count = vcard.size
                                for (vCard2 in vcard) {
                                    if (isCancelled) {
                                        break
                                    }
                                    val numbers = vCard2.telephoneNumbers
                                    if (vCard2.formattedName != null) {
                                        test.add(vCard2.formattedName.value)
                                    }
//                                    if (numbers.size != 0) {
//                                        count++
//                                    }
                                }
                                test.sortWith({ o1, o2 -> o1.compareTo(o2) })
                                for (j in test.indices) {
                                    name.append(test[j])
                                    name.append(", ")
                                }
                                val countNameModel = CountNameModel()
                                countNameModel.count = count
                                countNameModel.name = name.toString()
                                count_name_array.add(countNameModel)
                            } catch (e1: IOException) {
                                Log.e("TAG", "doInBackground: " + e1)
                                e1.printStackTrace()
                            }
                        }
                        CAlMyFile!!.reverse()
                        reverse(count_name_array)
                        runOnUiThread {
                            rvBackup!!.visibility = View.VISIBLE
                            tvEmpty!!.visibility = View.GONE
                            ivDelete!!.alpha = 1f
                            ivDelete!!.isEnabled = true
                        }
                    } else {
                        runOnUiThread {
                            rvBackup!!.visibility = View.GONE
                            tvEmpty!!.visibility = View.VISIBLE
                            ivDelete!!.alpha = 0.5f
                            ivDelete!!.isEnabled = false
                        }
                    }
                } else {
                    runOnUiThread {
                        rvBackup!!.visibility = View.GONE
                        tvEmpty!!.visibility = View.VISIBLE
                        ivDelete!!.alpha = 0.5f
                        ivDelete!!.isEnabled = false
                    }
                }
            }catch (e: Exception) {
                e.printStackTrace()
            }
            return null
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            if (isCancelled) {
                return
            }
            dialog.cancel()
            MyApplication.isDialogOpen = false
//            if (CAlMyFile != null && CAlMyFile!!.isNotEmpty()) {
//                rvBackup!!.visibility = View.VISIBLE
//                tvEmpty!!.visibility = View.GONE
//                ivDelete!!.alpha = 1f
//                ivDelete!!.isEnabled = true
//            } else {
//                rvBackup!!.visibility = View.GONE
//                tvEmpty!!.visibility = View.VISIBLE
//                ivDelete!!.alpha = 0.5f
//                ivDelete!!.isEnabled = false
//            }
            try {
                mContactBackupAdapter = ContactBackupAdapter(mContext, CAlMyFile, count_name_array,
                    object : OnBackupItemClick {
                        override fun onItemClick(contact: CountNameModel?, backupFile: File?, position: Int) {
                            ShareConstants.path = backupFile
                            ShareConstants.position = position
                            ShareConstants.count = contact!!.count
                            val path = backupFile!!.absolutePath
                            ShareConstants.date_time = path.substring(path.lastIndexOf("/") + 1)
                            MyApplication.isInterstitialShown = true
                            if (AdsManager(mContext).isNeedToShowAds()) {
                                if (!SharedPrefsConstant.getBoolean(mContext, SharedPrefsConstant.IS_APP_IN_BACKGROUND, true)) {
                                    mContext.isShowInterstitialAd { isShowFullScreenAd ->
                                        Log.e(mTAG, "onClick: isShowFullScreenAd::$isShowFullScreenAd")
                                        MyApplication.isInterstitialShown = false
                                        val intent = Intent(mContext, BackupSavedActivity::class.java)
                                        intent.putExtra("list", CAlMyFile!![position].toString())
                                        Log.e(mTAG, "onPostExecute: onAdClose " + CAlMyFile!![0].toString())
                                        startActivity(intent)
                                    }
                                }
                            } else {
                                val intent = Intent(mContext, BackupSavedActivity::class.java)
                                intent.putExtra("list", CAlMyFile!![position].toString())
                                startActivity(intent)
                                Log.e(mTAG, "onPostExecute: else  " + CAlMyFile!![position].toString())
                            }
                        }

                        override fun onContactItemClick(contact: ContactModel?, position: Int) {}
                    })
                rvBackup!!.adapter = mContactBackupAdapter
                mContactBackupAdapter!!.notifyDataSetChanged()
            } catch (e1: Exception) {
                println("ERROR__2:$e1")
                Log.e("TAG", "Exception: ERROR__2 " + e1.message )
            }
        }
    }

    fun reverse(list: ArrayList<CountNameModel>): ArrayList<CountNameModel> {
        var i = 0
        val j = list.size - 1
        while (i < j) {
            list.add(i, list.removeAt(j))
            i++
        }
        return list
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
            return
        }
        ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
        if (view == ivBack) {
            onBackPressed()
        } else if (view == ivDelete) {
            deleteBackups()
        }
    }

    private fun deleteBackups() {

        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

//        dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(resources.getDrawable(R.drawable.ic_dialog_delete))
        dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.confirm_delete)
        dialog.findViewById<TextView>(R.id.permission_text).text = getString(R.string.delete_backup)
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            for (i in CAlMyFile!!.indices) {
                CAlMyFile!![i]!!.delete()
            }
            val handler = Handler()
            handler.postDelayed({
                rvBackup!!.visibility = View.GONE
                tvEmpty!!.visibility = View.VISIBLE
                ivDelete!!.alpha = 0.5f
                ivDelete!!.isEnabled = false
                Toast.makeText(mContext, getString(R.string.contact_backup_delete_successfully), Toast.LENGTH_SHORT).show()
                SharedPrefsConstant.save(mContext, SharedPrefsConstant.LAST_BACKUP, "")
            }, 500)

        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
    }

    override fun onBackPressed() {

        val isRated = ExitSPHelper(mContext).isRated()
            if (!isRated) {
                if (SharedPrefsConstant.getInt(mContext, ShareConstants.RATE_BACKUP_CONTACT_COUNT) >= 3 && SharedPrefsConstant.getInt(mContext,ShareConstants.RATE_LATTER,1)==0) {
                    RatingDialog.smileyRatingDialog(mContext)
                } else {
                    super.onBackPressed()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    SharedPrefsConstant.save(mContext, ShareConstants.RATE_BACKUP_CONTACT_COUNT, SharedPrefsConstant.getInt(mContext, ShareConstants.RATE_BACKUP_CONTACT_COUNT) + 1)
                }
            }else {
                super.onBackPressed()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }

    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
        if (mContactBackupAdapter != null) {
            mContactBackupAdapter!!.notifyDataSetChanged()
        }
    }

}