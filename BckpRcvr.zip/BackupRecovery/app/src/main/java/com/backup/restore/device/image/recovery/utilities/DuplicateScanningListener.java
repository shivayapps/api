package com.backup.restore.device.image.recovery.utilities;

import androidx.annotation.Keep;

import com.backup.restore.device.image.recovery.duplicatenew.models.DuplicateGroupModel;

import java.util.List;

@Keep
public interface DuplicateScanningListener {
    void checkScanning();
    void publishProgress(String... strArr);
    //void publishProgress(List<ArrayList<FileDetails>> duplicatesList);
    void publishProgress(List<DuplicateGroupModel> duplicatesList);
}
