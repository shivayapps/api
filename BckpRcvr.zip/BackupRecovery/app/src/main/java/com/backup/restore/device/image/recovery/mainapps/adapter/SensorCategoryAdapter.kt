package com.backup.restore.device.image.recovery.mainapps.adapter

import android.app.Activity
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ItemDecoration
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainapps.model.FeaturesHW
import com.backup.restore.device.image.recovery.mainapps.model.SensorModel
import java.util.*


class SensorCategoryAdapter( internal var mContext: Activity,internal var appslist: List<SensorModel>) :
    RecyclerView.Adapter<SensorCategoryAdapter.DeviceVH>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SensorCategoryAdapter.DeviceVH {
        val itemView = LayoutInflater.from(mContext).inflate(R.layout.row_cpu_item, parent, false)
        return DeviceVH(itemView)
    }

    override fun onBindViewHolder(holder: SensorCategoryAdapter.DeviceVH, position: Int) {
        Log.e("CPUAdapter", "onBindViewHolder:position:" + position)
        holder.bindData(appslist[position], position)
    }

    override fun getItemCount(): Int = appslist.size

    inner class DeviceVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindData(parentModel: SensorModel, position: Int) {

            Log.e("CPUAdapter", "DeviceVH:featureHW:" + parentModel.lists.size)
            val tvTitle: TextView = itemView.findViewById(R.id.mTitle)
            val rvFeatureList: RecyclerView = itemView.findViewById(R.id.rv_cpu_feature_list)

            tvTitle.text = parentModel.title

            val listFeaturesHW = parentModel.lists

            val layoutManager = GridLayoutManager(mContext, 1)

            rvFeatureList.layoutManager = layoutManager
//            rvFeatureList.adapter = SensorAdapter(mContext,listFeaturesHW)

//            val dividerItemDecoration = DividerItemDecoration(mContext, layoutManager.orientation)
//            dividerItemDecoration.setDrawable(mContext.resources.getDrawable(R.drawable.sk_line_divider))
//            rvFeatureList.addItemDecoration(dividerItemDecoration)
//            rvFeatureList.addItemDecoration(DividerItemDecorator(mContext.resources.getDrawable(R.drawable.sk_line_divider)))

//            rvFeatureList.addItemDecoration(
//                GridItemDecoration.Builder(mContext, OrientationHelper.HORIZONTAL)
//                    .setDividerWidthPx(DensityUtils.dpToPx(1))
//                    .setRecyclerViewTopSpacePx(0)
//                    .setRecyclerViewBottomSpacePx(0)
//                    .setIgnoreHeadItemCount(singleItem.size)
//                    .setDividerMarginPx(0, 0, 0, 0)
//                    .setDividerColorProvider(object : BaseItemDecoration.DividerColorProvider {
//                        override fun getDividerColor(position: Int, parent: RecyclerView): Int {
//                            return Color.parseColor("#DBDBDB")
//                        }
//                    })
//                    .build()
//            )
        }
    }

    fun getLargeCount(listFeaturesHW: List<FeaturesHW>): List<FeaturesHW> {
        return listFeaturesHW.filter { it.featureValue.length > 20 }
    }
    fun getLengthCount(listFeaturesHW: List<FeaturesHW>): List<FeaturesHW> {
        return listFeaturesHW.filter { it.featureValue.length < 20 }
    }

    class FeaturesSorter : Comparator<FeaturesHW> {
        override fun compare(lhs: FeaturesHW, rhs: FeaturesHW): Int {
            return rhs.featureValue.length.compareTo(lhs.featureValue.length)
        }
    }

    class DividerItemDecorator(divider: Drawable) : ItemDecoration() {
        private val mDivider: Drawable = divider
        override fun onDrawOver(canvas: Canvas, parent: RecyclerView, state: RecyclerView.State) {
            val dividerLeft = parent.paddingLeft
            val dividerRight = parent.width - parent.paddingRight
            val childCount = parent.childCount
            for (i in 0..childCount - 2) {
                val child = parent.getChildAt(i)
                val params = child.layoutParams as RecyclerView.LayoutParams
                val dividerTop = child.bottom + params.bottomMargin
                val dividerBottom: Int = dividerTop + mDivider.getIntrinsicHeight()
                mDivider.setBounds(dividerLeft, dividerTop, dividerRight, dividerBottom)
                mDivider.draw(canvas)
            }
        }
    }
}
