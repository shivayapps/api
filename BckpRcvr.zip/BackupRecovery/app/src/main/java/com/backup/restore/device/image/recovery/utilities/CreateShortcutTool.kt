package com.backup.restore.device.image.recovery.utilities

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.SystemClock
import android.util.Log
import android.widget.Toast
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainapps.activity.ShortcutActivity
import java.util.*


object CreateShortcutTool {


    var mLastClickTime: Long = 0
    fun createHomeScreenShortcutNew(context: Context, packageName: String) {
        if (ShortcutManagerCompat.isRequestPinShortcutSupported(context)) {
            val packageManager = context.packageManager
            val iconBitmap = packageManager.getApplicationIcon(packageName).toBitmap()
            val appName = packageManager.getApplicationInfo(packageName, 0).loadLabel(packageManager)

            val intent = Intent(context, ShortcutActivity::class.java)
            intent.action = "android.intent.action.MAIN"
            intent.putExtra("appName", appName)
            intent.putExtra("pkgName", packageName)
            val build: ShortcutInfoCompat =
                ShortcutInfoCompat.Builder(context, generateId(packageName))
                    .setIntent(intent).setShortLabel(
                        appName
                    ).setIcon(IconCompat.createWithBitmap(iconBitmap)).build()

            //val shortcutManager = context.getSystemService(ShortcutManager::class.java)
            //context is required when call from the fragment
            context.registerReceiver(object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent) {
                    if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
                        return
                    }
                    mLastClickTime = SystemClock.elapsedRealtime()
                    //this method is called when shortcut is created
                    Log.e("AppShortcut", "onReceive:123 " );
                    Log.e("AppShortcut", "onReceive:123 intent:"+intent.data );
                    Toast.makeText(context, context.getString(R.string.the_shortcut_has_been_added), Toast.LENGTH_SHORT).show()
                }
            }, IntentFilter("test_action"))

            val receiverIntent = Intent("test_action")
            val pendingIntent = PendingIntent.getBroadcast(context, 123, receiverIntent, 0)
            ShortcutManagerCompat.requestPinShortcut(
                context,
                build,
                pendingIntent.intentSender
            )
            return
        }
        Toast.makeText(
            context,
            "launcher does not support short cut icon",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun generateId(str: String): String {
        return str + (Random().nextInt(91) + 10)
    }

}