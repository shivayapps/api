package com.backup.restore.device.image.recovery.ads.openad

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.util.Log
import android.webkit.WebView
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.multidex.MultiDex
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.inapp.InAppActivity
import com.backup.restore.device.image.recovery.main.ExitActivity
import com.backup.restore.device.image.recovery.main.HowToUseActivity
import com.backup.restore.device.image.recovery.main.NewSplashActivity
import com.backup.restore.device.image.recovery.main.ProgressbarActivity
import com.backup.restore.device.image.recovery.mainapps.activity.AppHistoryActivity
import com.backup.restore.device.image.recovery.mainapps.activity.AppManagerActivity
import com.backup.restore.device.image.recovery.maincontact.activity.HideContactActivity
import com.backup.restore.device.image.recovery.mainduplicate.activity.scanningactivities.DuplicateContactScanningActivity
import com.backup.restore.device.image.recovery.mainduplicate.activity.scanningactivities.EmptyFolderScanningActivity
import com.backup.restore.device.image.recovery.newsecurity.MyPatternActivity
import com.backup.restore.device.image.recovery.newsecurity.PinActivity
import com.backup.restore.device.image.recovery.observer.Analytics
import com.backup.restore.device.image.recovery.observer.ApplicationObserver
import com.backup.restore.device.image.recovery.observer.LogReporter
import com.backup.restore.device.image.recovery.utilities.common.ApplicationLifecycleHandler
import com.backup.restore.device.image.recovery.utilities.isMainProcess
import com.backup.restore.device.image.recovery.utilities.prepareShareApp
import com.example.app.ads.helper.VasuAdsConfig
import com.example.app.ads.helper.openad.AppOpenApplication
import com.example.app.ads.helper.openad.OpenAdHelper
//import com.onesignal.OSNotificationOpenedResult
//import com.onesignal.OneSignal
//import com.yandex.metrica.YandexMetrica
//import com.yandex.metrica.YandexMetricaConfig

/**
 * The Application class that manages AppOpenManager.
 *
 *
 * def lifecycle_version = "2.2.0"
 * implementation "androidx.lifecycle:lifecycle-extensions:$lifecycle_version"
 * implementation "androidx.lifecycle:lifecycle-runtime-ktx:$lifecycle_version"
 * annotationProcessor "androidx.lifecycle:lifecycle-compiler:$lifecycle_version"
 */
class MyApplication : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
//        super.attachBaseContext(localeAppDelegate.attachBaseContext(base))
        MultiDex.install(this)
    }


    override fun onCreate() {
        super.onCreate()
        Log.e(mTAG, " onCreate Okay")

        setAppLifecycleListener(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val process = getProcessName()
            if (packageName != process) WebView.setDataDirectorySuffix(process);
        }

        // All Ad-Ids are Optional
        VasuAdsConfig.with(this)
            .isEnableOpenAd(true)
            .needToTakeAllTestAdID(true)
            .setAdmobAppId(getString(R.string.admob_app_id))
            .setAdmobInterstitialAdId(getString(R.string.interstitial_ad_id))
            .setAdmobNativeAdvancedAdId(getString(R.string.native_ad_id))
            .setAdmobOpenAdId(getString(R.string.open_ad_id))
            .setAdmobRewardVideoAdId(getString(R.string.rewarded_ad_id))
//            .setAdmobInterstitialAdRewardId(getString(R.string.interstitial_rewarded_ad_id))
            .initialize()

        initMobileAds(isAppInTesting = true)

        OpenAdHelper.loadOpenAd(fContext = this)

        prepareShareApp()

        if (isMainProcess()) {
            instance = this
            application = this

            val analytics = Analytics()
            analytics.addReporter(LogReporter())
            ProcessLifecycleOwner.get().lifecycle.addObserver(
                ApplicationObserver(
                    analytics,
                    applicationContext
                )
            )

            val handler = ApplicationLifecycleHandler()
            registerActivityLifecycleCallbacks(handler)
            registerComponentCallbacks(handler)

            initImageLoader(this)

//            OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE)

//            try {
//                if (applicationContext != null) {
//                    OneSignal.initWithContext(applicationContext)
//                    OneSignal.setAppId("469231a5-25e9-4687-9ad3-872ff133169c")
//                    OneSignal.setNotificationOpenedHandler(NotificationOpenedHandler(this))
//                    OneSignal.unsubscribeWhenNotificationsAreDisabled(true)
//                    OneSignal.setLocationShared(true)
//                    OneSignal.addSubscriptionObserver { stateChanges ->
//                        Log.e(mTAG, "onCreate: || => ---3-.-3  " + stateChanges.to.userId)
//                        if (!stateChanges.from.isSubscribed && stateChanges.to.isSubscribed) {
//                            Log.e(mTAG, "onCreate: || => " + stateChanges.to.userId)
//                        }
//                    }
//                } else {
//                    Log.e(mTAG, " context null")
//                }
//            } catch (e: java.lang.RuntimeException) {
//                Log.e(mTAG, " RuntimeException")
//            } catch (e: Exception) {
//                Log.e(mTAG, " Exception")
//            }

        }

//        ViewPump.init(
//            ViewPump.builder().addInterceptor(
//                CalligraphyInterceptor(CalligraphyConfig.Builder().setDefaultFontPath("app_font/firasans_medium.ttf").build())
//            ).build()
//        )
//        StrictMode.setThreadPolicy(
//            StrictMode.ThreadPolicy.Builder()
//                .detectDiskReads()
//                .detectDiskWrites()
//                .detectNetwork() // or .detectAll() for all detectable problems
//                .penaltyLog()
//                .build()
//        )
//        StrictMode.setVmPolicy(
//            StrictMode.VmPolicy.Builder()
//                .detectLeakedClosableObjects()
//                .penaltyLog()
//                .build()
//        )

        Log.e(mTAG, " onCreate exit")
    }


    fun initImageLoader(context: Context?) {
//        val config = ImageLoaderConfiguration.Builder(context)
//        config.threadPriority(Thread.NORM_PRIORITY - 2)
//        config.denyCacheImageMultipleSizesInMemory()
//        config.diskCacheFileNameGenerator(Md5FileNameGenerator())
//        config.diskCacheSize(50 * 1024 * 1024) // 50 MiB
//        config.tasksProcessingOrder(QueueProcessingType.LIFO)
//        config.writeDebugLogs() // Remove for release app
//        ImageLoader.getInstance().init(config.build())
    }

//    class NotificationOpenedHandler(private var mContext: Context) :
//        OneSignal.OSNotificationOpenedHandler {
//        override fun notificationOpened(result: OSNotificationOpenedResult?) {
//            val data = result!!.notification.additionalData
//
//            Log.e(mTAG, "startHome: $data")
//
//            if (data != null) {
//                val customKey = data.optString("OpenActivity", null)
//                if (customKey != null) {
//                    when (customKey) {
//                        "AppsBackupActivity" -> {
//                            val intent = Intent(mContext, AppsBackupActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "ContactMainActivity" -> {
//                            val intent = Intent(mContext, ContactMainActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "ScanningActivity_Image" -> {
//                            val intent = Intent(mContext, ScanningActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Image")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "ScanningActivity_Video" -> {
//                            val intent = Intent(mContext, ScanningActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Video")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "ScanningActivity_Audio" -> {
//                            val intent = Intent(mContext, ScanningActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Audio")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "ScanningActivity_Document" -> {
//                            val intent = Intent(mContext, ScanningActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Document")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "ScanningActivity_Other" -> {
//                            val intent = Intent(mContext, ScanningActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Other")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "RecoverImageActivity" -> {
//                            val intent = Intent(mContext, NewRecoverImageActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsFromNotification", "Yes")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "EmptyFolderActivity" -> {
//                            val intent = Intent(mContext, EmptyFolderScanningActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "DuplicateContactScanningActivity" -> {
//                            val intent =
//                                Intent(mContext, DuplicateContactScanningActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "JunkActivity" -> {
//                            val intent = Intent(mContext, JunkActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "AppManagerActivity_UserApps" -> {
//                            val intent = Intent(mContext, AppManagerActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "UserApps")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "AppManagerActivity_SystemApps" -> {
//                            val intent = Intent(mContext, AppManagerActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "SystemApps")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "DeepScanActivity_Image" -> {
//                            val intent = Intent(mContext, DeepScanActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Image")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "DeepScanActivity_Video" -> {
//                            val intent = Intent(mContext, DeepScanActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Video")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "DeepScanActivity_Audio" -> {
//                            val intent = Intent(mContext, DeepScanActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Audio")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                        "DeepScanActivity_Document" -> {
//                            val intent = Intent(mContext, DeepScanActivity::class.java)
//                            intent.flags =
//                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//                            intent.putExtra("IsCheckOneSignalNotification", true)
//                            intent.putExtra("IsCheckType", "Document")
//                            mContext.startActivity(intent)
//                            SharedPrefsConstant.savePref(
//                                mContext,
//                                "isFromOneSignalNotificationForAd",
//                                true
//                            )
//                        }
//                    }
//                }
//            }
//        }
//    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
//        localeAppDelegate.onConfigurationChanged(this)
    }

    companion object {
        var mTAG: String = "MyApplication"

        private const val isShowingAd = false
        var isInternalCall = false
        var isExit = false
        var isInterstitialShown = false
        var isDialogOpen = false

        @JvmField
        var isAppRunning = true

        var application: MyApplication? = null

        var instance: MyApplication? = null
            private set

        @JvmStatic
        val appContext: Context?
            get() {
                if (application == null) {
                    application = MyApplication()
                }
                return application
            }

//        var mInitApkData: InitApkData? = null
//        var mInitTempData: InitTempData? = null
//        var mInitEmptyData: InitEmptyData? = null
//        var mInitTrashData: InitTrashData? = null
//        var mInitUninstalledData: InitUninstalledData? = null

    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {

        Log.e(mTAG, "onResumeApp: fCurrentActivity::${fCurrentActivity.localClassName}")
        val isNeedToShowAd: Boolean = when {
//            if (!isMoreAppsOpenAdShow) {
//                Log.d(mTAG, "ON_RESUME: More App Open")
//                false
//            }
            (fCurrentActivity is NewSplashActivity) -> {
                Log.e(mTAG, "ON_RESUME: SPLASH")
                false
            }
            (fCurrentActivity is DuplicateContactScanningActivity) -> {
                Log.e(mTAG, "ON_RESUME: DuplicateContactScanningActivity")
                false
            }
            (fCurrentActivity is EmptyFolderScanningActivity) -> {
                Log.d(mTAG, "ON_RESUME: EmptyFolderScanningActivity")
                false
            }
            (fCurrentActivity is HowToUseActivity) -> {
                Log.e(mTAG, "ON_RESUME: HowToUseActivity")
                false
            }
            (fCurrentActivity is ExitActivity) -> {
                Log.e(mTAG, "ON_RESUME: ExitActivity")
                false
            }
            (fCurrentActivity is HideContactActivity) -> {
                Log.e(mTAG, "ON_RESUME: HideContactActivity")
                false
            }
            (fCurrentActivity is MyPatternActivity) -> {
                Log.e(mTAG, "ON_RESUME: MyPatternActivity")
                false
            }
            (fCurrentActivity is PinActivity) -> {
                Log.e(mTAG, "ON_RESUME: PinActivity")
                false
            }
            (fCurrentActivity is ProgressbarActivity) -> {
                Log.d(mTAG, "ON_RESUME: ProgressbarActivity")
                false
            }
            (fCurrentActivity is InAppActivity) -> {
                Log.e(mTAG, "ON_RESUME: InAppActivity")
                false
            }
            (fCurrentActivity is AppHistoryActivity) -> {
                Log.e(mTAG, "ON_RESUME: AppHistoryActivity")
                false
            }
            (fCurrentActivity is AppManagerActivity) -> {
                Log.d(mTAG, "ON_RESUME: AppManagerActivity")
                false
            }
//            (isMoreAppsClick) -> {
//                Log.e(mTAG, "ON_RESUME: isMoreAppsClick")
//                false
//            }
//            (isAnimationRunning) -> {
//                Log.e(mTAG, "ON_RESUME :isAnimationRunning")
//                false
//            }
            (MyApplication.isInterstitialShown) -> {
                Log.e(mTAG, "ON_RESUME: isInterstitialShown")
                false
            }
            (MyApplication.isInternalCall) -> {
                Log.e(mTAG, "ON_RESUME: isInternalCall")
                false
            }
            (MyApplication.isDialogOpen) -> {
                Log.e(mTAG, "ON_RESUME: isDialogOpen")
                false
            }
            (MyApplication.isExit) -> {
                Log.e(mTAG, "ON_RESUME: isExit")
                false
            }
            (AdsManager(fCurrentActivity).isNeedToShowAds()) -> {
                Log.d(mTAG, "ON_RESUME: isNeedToShowAds")
                true
            }
            else -> {
                false
            }
        }
        MyApplication.isInternalCall = false
        Log.e(mTAG, "ON_RESUME: isNeedToShowAds:$isNeedToShowAd")
        return isNeedToShowAd
    }
}