package com.backup.restore.device.image.recovery.duplicatenew.utils.algorathm;

import android.content.Context;
import android.util.Log;

import com.backup.restore.device.image.recovery.duplicatenew.utils.DuplicatePreferences;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5 {


    public String fileToMD5(String filePath, Context context) {
        String str = null;
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            InputStream is = new FileInputStream(new File(filePath));
            byte[] buffer = new byte[8192];
            while (true) {
                try {
                    int read = is.read(buffer);
                    if (read <= 0 || DuplicatePreferences.isScanningStopped(context)) {
                        is.close();
                        break;
                    }
                    digest.update(buffer, 0, read);
                } catch (IOException e) {
                    Log.e("MD5Checksum", "IOException:001 :" + e.getMessage());
                    e.printStackTrace();
//                    throw new RuntimeException("Unable to process file for MD5", e);
                } catch (Exception th) {
                    Log.e("MD5Checksum", "Exception:002 :" + th.getMessage());
                    is.close();
                }
            }
            str = String.format("%32s", new BigInteger(1, digest.digest()).toString(16)).replace(' ', '0');
            is.close();
        } catch (NoSuchAlgorithmException | IOException e5) {
            Log.e("MD5Checksum", "Exception:003 :" + e5.getMessage());
        }
        Log.e("MD5Checksum", "filePath:" + filePath);
        Log.e("MD5Checksum", "str:" + str);
        return str;
    }

    public String fileToMD5Old(String filePath, Context context) {
        try {
            String output;
            MessageDigest digest = MessageDigest.getInstance("MD5");
            InputStream is = new FileInputStream(filePath);
            byte[] buffer = new byte[8192];
            while (true) {
                int read = is.read(buffer);
                if (read <= 0 || DuplicatePreferences.isScanningStopped(context)) {
                    output = String.format("%32s", new Object[]{new BigInteger(1, digest.digest()).toString(16)}).replace(' ', '0');
                    is.close();
                } else {
                    digest.update(buffer, 0, read);
                }

                output = String.format("%32s", new Object[]{new BigInteger(1, digest.digest()).toString(16)}).replace(' ', '0');
                is.close();
                return output;
            }
        } catch (NoSuchAlgorithmException e) {
            return null;
        } catch (FileNotFoundException e2) {
            return null;
        } catch (IOException e3) {
            return null;
        }
    }

}