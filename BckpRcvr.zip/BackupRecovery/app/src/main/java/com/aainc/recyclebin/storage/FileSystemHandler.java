package com.aainc.recyclebin.storage;

import static android.app.NotificationManager.IMPORTANCE_MIN;
import static android.content.Context.NOTIFICATION_SERVICE;
import static com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant.AudioArray;
import static com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant.DocumentArray;
import static com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant.ImageArray;
import static com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant.OtherArray;
import static com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant.VideoArray;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.FileObserver;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import android.util.Pair;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.aainc.recyclebin.b.myclass;
import com.aainc.recyclebin.c.myFileObserver;
import com.aainc.recyclebin.database.FilesProtectionContentProvider;
import com.backup.restore.device.image.recovery.R;
import com.backup.restore.device.image.recovery.mainphotos.activity.NewRecoverImageActivity;
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant;
import com.google.common.collect.LinkedListMultimap;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class FileSystemHandler {

    private static final String TAG = "FileObserver";
    private static FileSystemHandler b = null;
    private static Context c = null;
    private Context context = null;
    private List<FileObserver> d = new LinkedList();

    static {
        System.loadLibrary("native-lib");
    }

    public static ArrayList<String> strList;
    public static ArrayList<String> strListVideo;
    ArrayList<String> strListDocument;
    ArrayList<String> strListAudio;
    ArrayList<String> strListOther;
    private Activity currentActivity;
    long lCount = 0;

    public static NotificationManager mNotificationManager;
    Boolean isSendNotification = false;
    public static String CHANNEL_ID = "BackupAndRecoveryForegroundServiceChannel";

    private FileSystemHandler(Context context) {

        strList = new ArrayList<>(Arrays.asList(ImageArray));
        strListVideo = new ArrayList<>(Arrays.asList(VideoArray));
        strListAudio = new ArrayList<>(Arrays.asList(AudioArray));
        strListDocument = new ArrayList<>(Arrays.asList(DocumentArray));
        strListOther = new ArrayList<>(Arrays.asList(OtherArray));

        c = context;
        this.context = context;
    }

    private android.util.Pair<java.util.Map<java.lang.String, java.lang.Integer>, java.util.Map<java.lang.String, java.lang.Long>>
    a(java.util.List<java.lang.String> r11) {

        java.util.HashMap r3 = new java.util.HashMap<>();
        java.util.HashMap r4 = new java.util.HashMap<>();

        FileSystemHandler r10 = this;
        int r2 = -1;
        if (r11 != null) {
            java.util.Iterator r5 = r11.iterator();

            boolean r1012 = r5.hasNext();
            if (!r1012) {
            } else {

                while (r5.hasNext()) {

                    java.lang.Object rg0 = r5.next();

                    java.lang.String fr0 = (java.lang.String) rg0;

                    try {
                        Boolean r0 = com.aainc.recyclebin.d.c.b(fr0);
                        if(!r0) {
//                            Log.e("DemoTag", "nativeOpen-fr0 --> " + fr0);
                            int r1 = r10.nativeOpen(fr0);
                            long r6 = r10.nativeGetFileSize(r1);
                            int r8 = 0;
                            int r84 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1));

                            if (r84 >= 0) {
                                java.lang.Integer rb8 = r1;
                                r3.put(fr0, rb8);
                                java.lang.Long r6b = r6;
                                r4.put(fr0, r6b);
                            }
                        }
                    } catch (Exception e) {

                        Log.e(TAG, "Exception_011 Exception in native.");
                    }
                }
            }
        }

        android.util.Pair pair = new android.util.Pair(r3, r4);

        return pair;
    }

    public static synchronized FileSystemHandler a() {
        FileSystemHandler fileSystemHandler;
        synchronized (FileSystemHandler.class) {
            if (b == null) {
                if (c == null) {
                    fileSystemHandler = null;
                } else {
                    b = new FileSystemHandler(c);
                }
            }
            fileSystemHandler = b;
        }
        return fileSystemHandler;
    }

    public String a(String str) {
        if (str == null) {
//            return "";
            throw new IllegalArgumentException("Parameter is invalid. File path can't be null.");
        }
        StringBuilder sb = new StringBuilder();
        try {


            String mRootPath = Environment.getExternalStorageDirectory().toString() + File.separator + "DCIM/Backup And Recovery";
            sb.append(mRootPath);

        } catch (IllegalArgumentException | NullPointerException e) {
            String mRootPath = Environment.getExternalStorageDirectory().toString() + File.separator + "DCIM/Backup And Recovery";
            sb.append(mRootPath);
        }


        sb.append(File.separator);
        sb.append(".trash");
        sb.append(File.separator);
        return sb.toString();
    }

    private List<String> a(String str, Collection<myclass> collection) {
        boolean z;

        if (str == null || collection == null) {
            Log.e(TAG, "str:" + str);
            Log.e(TAG, "collection:" + collection);
//            return new ArrayList<>();
            throw new IllegalArgumentException(str == null ? "First parameter is invalid. Directory path can't be null." : "Second parameter is invalid. Root info collection can't be null.");
        }
        Iterator<myclass> it = collection.iterator();


        while (true) {
            if (it.hasNext()) {
                if (!it.next().b()) {
                    z = false;
                    break;
                }
            } else {
                z = true;
                break;
            }
        }
        File file = new File(str);

        if (file == null || !file.exists() || !file.isDirectory()) {
            Log.e(TAG, "Exception_001 First parameter is invalid. First parameter must be myfrgamant directory path.");
//            return new ArrayList<>();
            throw new IllegalArgumentException("First parameter is invalid. First parameter must be myfrgamant directory path.");
        }
        File[] listFiles = file.listFiles();

//        Log.e(TAG, "a:file.getAbsolutePath() " + file.getAbsolutePath() );
        ArrayList arrayList = null;
        if (listFiles != null) {
            arrayList = z ? new ArrayList(collection.size()) : new ArrayList(listFiles.length);
        }


        if (!z) {

            for (myclass next : collection) {

                int length = 0;
                if (listFiles != null) {
                    length = listFiles.length;

                    int i = 0;

                    while (true) {
                        if (i >= length) {
                            break;
                        }
                        File file2 = listFiles[i];

                        if (next.a().equals(file2.getAbsolutePath())) {
                            arrayList.add(file2.getAbsolutePath());
                            break;
                        }
                        i++;
                    }
                }


            }
        } else {
            if (listFiles != null) {
                for (File file3 : listFiles) {
                    if (file3.isFile()) {
                        arrayList.add(file3.getAbsolutePath());
                        lCount++;
//                        Log.e(TAG, "a:aaa file3--> " + lCount);
                        context.sendBroadcast(new Intent().putExtra("count", lCount).setAction("com.progress.count.Refresh"));
                    }
                }
            }
        }

        Log.e(TAG, "a:file arraylist.size " + arrayList.size());
        return arrayList;
    }

    private List<String> a(String str, boolean z) {
        LinkedList linkedList = new LinkedList<>();
//        Log.e(TAG, "a:str " + str );
        try {
            File file = new File(str);
            if (file == null || !file.exists()) {
                Log.e(TAG, "Exception_002 First parameter is invalid. Can't find myfrgamant file or directory.");
//                return null;
                throw new IllegalArgumentException("First parameter is invalid. Can't find myfrgamant file or directory.");
            }
            if (file.isFile()) {
                File parentFile = file.getParentFile();
                if (parentFile == null || !parentFile.exists()) {
                    Log.e(TAG, "Exception_003 File with name \" + file.getAbsolutePath() + \" must have myfrgamant parent folder.");
//                    return null;
                    throw new IllegalArgumentException("File with name " + file.getAbsolutePath() + " must have myfrgamant parent folder.");
                }
                linkedList.add(parentFile.getAbsolutePath());

            } else {
                a(file.getAbsolutePath(), (List<String>) linkedList);
            }
            return linkedList;
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void a(int i) {
//        Log.e(TAG, "closeFileDescriptor method");
//        Log.e("DemoTag", "nativeClose-i --> " + i);
        nativeClose(i);
    }

    public static synchronized void a(Context context) {

        synchronized (FileSystemHandler.class) {
            if (context == null) {
                Log.e(TAG, "Exception_004 Parameter is invalid. Context can't be null.");
//                return;
                throw new NullPointerException("Parameter is invalid. Context can't be null.");
            }
            c = context;

        }
    }

    private void a(String str, List<String> list) {
        if (str == null || list == null) {
            try {
                Log.e(TAG, "Exception_005 str:" + str);
                Log.e(TAG, "Exception_005 list:" + list);
//                return;
                throw new NullPointerException(str == null ? "First parameter is invalid. Path directory can't be null." : "Second parameter is invalid. List<String> can't be null.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
//            Log.e(TAG, "ResearchDirTree --> " + str);
            File file = new File(str);
            if (file == null || !file.exists()) {
            } else if (file.isFile()) {
                Log.e(TAG, "Exception_006 First parameter is invalid. Path can't be myfrgamant file.");
//                return;
                throw new IllegalArgumentException("First parameter is invalid. Path can't be myfrgamant file.");
            } else if (file.isDirectory()) {
                for (File file2 : file.listFiles()) {
                    if (file2.isDirectory()) {
                        a(file2.getAbsolutePath(), list);
                    }
                }
                list.add(file.getAbsolutePath());
            }
        }
    }

    private List<Pair<String, Boolean>> c(Set<String> set, List<Boolean> list) {
        ArrayList arrayList = new ArrayList<>();
        try {
            Iterator<String> it = set.iterator();
            int i = 0;
            while (it.hasNext()) {
                String next = it.next();
                if (next == null || list.get(i) == null) {
                    throw new IllegalArgumentException((next == null ? "Root path" : "isRecursive property") + " with order number " + i + 1 + " can't be null.");
                }
                arrayList.add(new Pair(next, list.get(i)));
                i++;
            }
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
//        Log.e(TAG, "c:arrayList " + arrayList.size() );
        return arrayList;
    }

    private native int nativeClose(int i);

    private native boolean nativeCopy(int i, long j, String str);

    private native long nativeGetFileSize(int i);

    private native int nativeOpen(String str);


    //TAG
    public synchronized void a(int i, long j, String str) {
        String str2 = "";
        Notification mBuilder;
        if (str != null) {
//            Log.e(TAG, "file_name-length --> " + new File(str).length() );
            if (!str.isEmpty()) {
                String[] split = str.split(File.separator);
                String str3 = split[split.length - 1];
                try {
                    str2 = a(str);
                } catch (Exception e) {
                    e.printStackTrace();
                }

//                Log.e(TAG, "file_name-str --> " + str );
//                Log.e(TAG, "file_name-str3-> " + str3);

                String lExtension = (str.substring(str.lastIndexOf(".")).replace(".", ""));
                String tyepe = "";

                if (strList.contains(lExtension)) {
                    str2 = str2 + "Images/";
                    tyepe = "Image";
                } else if (strListVideo.contains(lExtension)) {
                    str2 = str2 + "Videos/";
                    tyepe = "Video";
                } else if (strListAudio.contains(lExtension)) {
                    str2 = str2 + "Audios/";
                    tyepe = "Audio";
                } else if (strListDocument.contains(lExtension)) {
                    str2 = str2 + "Documents/";
                    tyepe = "Document";
                } else if (strListOther.contains(lExtension)) {
                    str2 = str2 + "Other/";
                    tyepe = "Other";
                }
                boolean notifyImages = SharedPrefsConstant.getBoolean(context, "sw_trash_images", true);
                boolean notifyVideos = SharedPrefsConstant.getBoolean(context, "sw_trash_videos", true);
                boolean notifyAudios = SharedPrefsConstant.getBoolean(context, "sw_trash_audios", true);
                boolean notifyDocument = SharedPrefsConstant.getBoolean(context, "sw_trash_document", true);
                boolean notifyOther = SharedPrefsConstant.getBoolean(context, "sw_trash_other", true);

                boolean needToSave = false;

                switch (tyepe) {
                    case "Image":
                        needToSave = notifyImages;
                        break;
                    case "Video":
                        needToSave = notifyVideos;
                        break;
                    case "Audio":
                        needToSave = notifyAudios;
                        break;
                    case "Document":
                        needToSave = notifyDocument;
                        break;
                    case "Other":
                        needToSave = notifyOther;
                        break;
                }

                if (!tyepe.equals("") && needToSave) {
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hhmmss");
                    Date date = new Date(System.currentTimeMillis());
                    String time = simpleDateFormat.format(date);

                    String str4 = str2 + str3 + "#$" + time;
//                    Log.e(TAG, "str4: " + str4);
//                    Log.e(TAG, " new File(str4).length()  " + new File(str4).length() );
                    File file = new File(str2);
                    if (!file.mkdirs()) {
                        file.mkdirs();
                    }

                    if (file.mkdirs() || file.isDirectory()) {
                        Log.e(TAG, "====bfour>>>: " + new File(str4).length());

//                        Log.e("DemoTag", "nativeCopy-i --> " + i);
//                        Log.e("DemoTag", "nativeCopy-j --> " + j);
//                        Log.e("DemoTag", "nativeCopy-str4 --> " + str4);

                        nativeCopy(i, j, str4);
//                        Log.e(TAG, "====>>>: " + new File(str4).length());

                        if (new File(str4).length() != 0) {

                            try {
                                String[] split2 = str.split(str3);
                                Uri uri = FilesProtectionContentProvider.a;
                                ContentValues contentValues = new ContentValues();
                                contentValues.put("file_name", str3);
                                contentValues.put("original_path", split2[0]);
                                contentValues.put("trash_path", str4);
                                contentValues.put("type_file", tyepe);
                                contentValues.put("file_size", new File(str4).length());
                                contentValues.put("deleted_at", new File(str4).lastModified());
                                if (new File(str4).length() > 0) {
                                    c.getContentResolver().insert(uri, contentValues);
                                }
                                if (new File(str4).exists()) {
//                                    Log.e(TAG, "insert file_size " +  getReadableFileSize(new File(str4).length()));
                                }
//                                Log.e(TAG, "noti a: " + SharedPrefsConstant.getBooleanNoti(context,"NotificationForDelete", true));
//                                Log.e(TAG, "a: split2[0] " + split2[0] );
                                if (SharedPrefsConstant.getBooleanNoti(context, "NotificationForDelete", true)) {

                                    try {
                                        if (mNotificationManager == null) {
                                            mNotificationManager = (NotificationManager) (context).getSystemService(NOTIFICATION_SERVICE);
                                        }
                                        String mPath = split2[0] + str3;
                                        String lFileExtensions = mPath.substring(mPath.lastIndexOf(".")).replace(".", "");
                                        String type = "";

                                        String mNoti = "";
                                        int notificationId = 0;
                                        if (strList.contains(lFileExtensions)) {
                                            type = "Image";
                                            mNoti = c.getString(R.string.noti_delete_image);
                                            notificationId = 150;
                                        } else if (strListVideo.contains(lFileExtensions)) {
                                            type = "Video";
                                            mNoti = c.getString(R.string.noti_delete_video);
                                            notificationId = 151;
                                        } else if (strListAudio.contains(lFileExtensions)) {
                                            type = "Audio";
                                            mNoti = c.getString(R.string.noti_delete_audio);
                                            notificationId = 152;
                                        } else if (strListDocument.contains(lFileExtensions)) {
                                            type = "Document";
                                            mNoti = c.getString(R.string.noti_delete_document);
                                            notificationId = 153;
                                        } else if (strListOther.contains(lFileExtensions)) {
                                            type = "Other";
                                            mNoti = c.getString(R.string.noti_delete_file);
                                            notificationId = 154;
                                        }

//                                        Log.e("Mahendra-test", "notificationId-001: " + notificationId);

                                        if (notificationId != 0) {
                                            StatusBarNotification[] notifications;
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                notifications = mNotificationManager.getActiveNotifications();
                                                for (StatusBarNotification notification : notifications) {
                                                    if (notification.getId() == notificationId) {
                                                        isSendNotification = true;
                                                        break;
                                                    } else if (notification.getId() != notificationId) {
                                                        isSendNotification = false;
                                                    }
                                                }
                                            }
                                            if (!isSendNotification) {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                                    if (mNotificationManager.getNotificationChannel(CHANNEL_ID) == null) {
                                                        NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, "BackupAndRecovery", NotificationManager.IMPORTANCE_HIGH);
                                                        notificationChannel.enableVibration(true);
                                                        notificationChannel.setVibrationPattern(new long[]{0, 250, 250, 250});
                                                        mNotificationManager.createNotificationChannel(notificationChannel);
                                                    }
                                                }
                                                Intent intent = new Intent(context, NewRecoverImageActivity.class);
                                                intent.putExtra("IsFromNotification", "yes");
                                                SharedPrefsConstant.saveStringNoti(context, "IsTypeFor", type);
                                                intent.putExtra("Typess", type);
                                                intent.setAction(Long.toString(System.currentTimeMillis()));
                                                PendingIntent pendingIntent = PendingIntent.getActivity(context, notificationId, intent, PendingIntent.FLAG_ONE_SHOT);
//                                            Log.e(TAG, "a: setAllData " +intent.getStringExtra("IsFromNotification") );
                                                mBuilder = new NotificationCompat.Builder(context, CHANNEL_ID)
                                                        .setContentTitle(context.getString(R.string.app_name))
                                                        .setSmallIcon(R.drawable.ic_icon)
                                                        .setContentText(mNoti)
                                                        .setColor(ContextCompat.getColor(context, R.color.colorPrimary))
                                                        .setPriority(IMPORTANCE_MIN)
                                                        .setContent(null)
                                                        .setAutoCancel(true)
                                                        .setContentIntent(pendingIntent).build();
                                                mNotificationManager.notify(notificationId, mBuilder);
                                            }
                                        }

                                    } catch (Exception e9) {
                                        Log.e(TAG, "copyImageBeforeDelete: " + e9.getMessage());
                                    }
                                }

                            } catch (NullPointerException e3) {
                                e3.printStackTrace();
                                Log.e(TAG, "Error message: " + e3.getMessage() + e3.getCause());
                            }

                        }

                        switch (tyepe) {
                            case "Image":
                                context.sendBroadcast(new Intent().setAction("com.progress.image.Refresh"));
                                break;
                            case "Video":
                                context.sendBroadcast(new Intent().setAction("com.progress.video.Refresh"));
                                break;
                            case "Audio":
                                context.sendBroadcast(new Intent().setAction("com.progress.audio.Refresh"));
                                break;
                            case "Document":
                                context.sendBroadcast(new Intent().setAction("com.progress.document.Refresh"));
                                break;
                            case "Other":
                                context.sendBroadcast(new Intent().setAction("com.progress.other.Refresh"));
                                break;
                        }

//                        Log.e("TrashVideoFragment", "SendBroadCast ");
                    } else {
//                        Log.e("Todo==>", " Else:--> : " + file.mkdirs());

                    }
                }
            }
        }
        throw new IllegalArgumentException("argument. Arguments can't be null or empty");
    }


    public synchronized void a(myFileObserver aVar) {
        if (aVar == null) {
//            Log.e(TAG, "Exception_008 aVar == null");
//            return;
            throw new IllegalArgumentException("Parameter is invalid. FileObserver can't be null.");
        }
        aVar.stopWatching();
        try {
            for (Integer next : aVar.setImageMap().values()) {
                if (next != null) {
                    try {
                        a(next.intValue());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (NullPointerException e2) {
            e2.printStackTrace();
            Log.e("MAlu ", "Error message: " + e2.getMessage() + e2.getCause());
        }
        boolean a = this.d.remove(aVar);
        Log.e("MAlu    ", "myfrgamant: STOPWATCHING  " + a);

    }

    public synchronized void a(myFileObserver aVar, String str) {
        if (aVar == null || str == null) {
            Log.e(TAG, "Exception_009");
//            return;
            throw new IllegalArgumentException(aVar == null ? "First parameter is invalid. FileObserver can't be null." : "Parameter is invalid. File path can't be null.");
        }
        Integer num = aVar.setImageMap().get(str);
        if (num != null) {
            a(num);
        }
        aVar.setImageMap().remove(str);
        aVar.setLoadMap().remove(str);
        return;
    }


    public boolean a(Set<String> set, List<Boolean> list) {
        try {

            List<Pair<String, Boolean>> c2 = c(set, list);
            LinkedListMultimap a2 = LinkedListMultimap.create();

            for (Pair next : c2) {
                List<String> a3 = a((String) next.first, (Boolean) next.second);
                boolean b2 = true;
                for (String a4 : a3) {
                    a2.put(a4, new myclass((String) next.first, (Boolean) next.second, b2));
                }
            }

            int i = 0;
            for (Object str : a2.keySet()) {
                try {

                    Collection c3 = a2.get(str);
                    List aaa = a(str.toString(), c3);
//                    Log.e(TAG, "a:aaa  " + aaa.size() );

                    Pair<Map<String, Integer>, Map<String, Long>> a5 = a(aaa);
//                    Log.e(TAG, "a:aaa a5.first " + a5.first );
//                    Log.e(TAG, "a:aaa a5.second " + a5.second );
//                    Log.e(TAG, "a:aaa str " + str );

                    this.d.add(new myFileObserver(a5.first, a5.second, (String) str, 4038, this, c3, context));
                    i++;

//                    Log.e(TAG, "adapters: " + i + "==========" + a2.keySet().size());
                    if (a2.keySet().size() == i) {
//                        Log.e(TAG, "startServiceMethod IsFromService " + SharedPrefsConstant.getBooleanNoti(context,"IsFromService", false));

                        if (SharedPrefsConstant.getBooleanNoti(context, "IsFromService", false)) {
//                            Log.e(TAG, "startServiceMethod hello : new Activity() ");
                            c.startActivity(new Intent(c, NewRecoverImageActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("IsFromNotification", "Yes"));
//                            ((ProgressbarActivity)c).finish();
                        } else {
                            Log.e(TAG, "startServiceMethod: finish ");
//                            ((ProgressbarActivity)c).finish();
                        }
                    }
                } catch (ClassCastException | IllegalArgumentException | UnsupportedOperationException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return true;
        } catch (IllegalArgumentException e2) {
            e2.printStackTrace();
            return false;
        }

    }

    public List<FileObserver> b() {
        return this.d;
    }

    public synchronized void b(myFileObserver r9, java.lang.String r10) throws IOException {

        FileSystemHandler r8 = this;
        int r2 = -1;
        synchronized (r8) {
            if (r9 == null) {

                if (r9 != null) {
                    java.lang.String r0 = "Second parameter is invalid. File path can't be null.";
                    java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException(r0);
                    throw r1;
                }
                java.lang.String r0 = "First parameter is invalid. FileObserver can't be null.";

            }

            Log.e("nativeGetFileSize", "nativeOpen:check contents====>>>> " + r10.contains("com.aainc.recyclebin"));

            if (r10 != null && !r10.contains("com.aainc.recyclebin")) {
                try {
                    Boolean r0 = com.aainc.recyclebin.d.c.b(r10);
                    if(!r0) {
                        Log.e("DemoTag", "nativeOpen-r10 --> " + r10);
                        int r1 = r8.nativeOpen(r10);
                        if (r1 >= 0) {
                            long r4 = r8.nativeGetFileSize(r1);

                            int r6 = 0;

                            int r0s = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
                            if (r0s >= 0) {
                                java.util.Map r0ss = r9.setImageMap();
                                java.lang.Integer r3 = new java.lang.Integer(r1);
                                r0ss.put(r10, r3);
                                java.util.Map r0v = r9.setLoadMap();
                                java.lang.Long rd3 = new java.lang.Long(r4);
                                r0v.put(r10, rd3);
                                return;
                            }
                        }
                    }
                } catch (Exception e) {

                }

            } else {
            }

        }


    }

    public boolean b(Set<String> set, List<Boolean> list) {
        d();
        boolean a2 = a(set, list);
        if (a2) {
            c();
        }
        return a2;
    }

    public void c() {
        for (FileObserver startWatching : this.d) {
            startWatching.startWatching();
        }
    }

    public void d() {
        try {
            if (this.d == null) {
                Log.e(TAG, "Exception_009 d == null");
//                return;
                throw new NullPointerException("List of File Observers is null.");
            }
            List<FileObserver> observers = this.d;
            for (FileObserver next : observers) {
                next.stopWatching();
                try {
                    for (Map.Entry value : ((myFileObserver) next).setImageMap().entrySet()) {
                        try {
                            a(((Integer) value.getValue()).intValue());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                } catch (NullPointerException e2) {
                    Log.e(TAG, "Error message: " + e2.getMessage() + e2.getCause());
                }
            }
            this.d.clear();
        } catch (NullPointerException e3) {
            Log.e(TAG, "Error message: " + e3.getMessage() + e3.getCause());
        }
    }
}
