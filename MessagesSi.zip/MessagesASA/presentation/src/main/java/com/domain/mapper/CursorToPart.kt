package com.domain.mapper

import android.database.Cursor
import com.domain.model.MmsPart

interface CursorToPart : Mapper<Cursor, MmsPart> {

    fun getPartsCursor(messageId: Long?=null): Cursor?

}