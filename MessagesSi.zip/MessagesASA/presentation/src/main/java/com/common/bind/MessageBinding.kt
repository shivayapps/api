package com.common.bind

import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.TextView
import com.messenger.sms.text.databinding.MessageListItemInBinding
import com.messenger.sms.text.databinding.MessageListItemOutBinding

interface MessageListItemBinding {
    val root: View
    val backBtnAtTheme: ImageView
    val mTitleAtTheme: TextView
    val rbRecentMoments: RadioButton?
    val rbFavoriteMemories: RadioButton?
    val rbRecentVisitedPlaces: RadioButton?
    val rbCleanStorage: RadioButton?
    val llOptPlace: LinearLayout?
    val rbRandom: RadioButton?
    val llPreview: LinearLayout?
    val mApplyBtn: TextView?
}

class MessageInBinding(val binding: MessageListItemInBinding) : MessageListItemBinding {
    override val root: View = binding.root
    override val backBtnAtTheme: ImageView = ImageView(binding.root.context)
    override val mTitleAtTheme: TextView = TextView(binding.root.context)
    override val rbRecentMoments: RadioButton = RadioButton(binding.root.context)
    override val rbFavoriteMemories: RadioButton = RadioButton(binding.root.context)
    override val rbRecentVisitedPlaces: RadioButton = RadioButton(binding.root.context)
    override val rbCleanStorage: RadioButton = RadioButton(binding.root.context)
    override val llOptPlace: LinearLayout = LinearLayout(binding.root.context)
    override val rbRandom: RadioButton = RadioButton(binding.root.context)
    override val llPreview: LinearLayout = LinearLayout(binding.root.context)
    override val mApplyBtn: TextView = TextView(binding.root.context)
}

fun MessageListItemInBinding.toMessageBinding() = MessageInBinding(this)

class MessageOutBinding(val binding: MessageListItemOutBinding) : MessageListItemBinding {
    override val root: View = binding.root
    override val backBtnAtTheme: ImageView = ImageView(binding.root.context)
    override val mTitleAtTheme: TextView = TextView(binding.root.context)
    override val rbRecentMoments: RadioButton = RadioButton(binding.root.context)
    override val rbFavoriteMemories: RadioButton = RadioButton(binding.root.context)
    override val rbRecentVisitedPlaces: RadioButton = RadioButton(binding.root.context)
    override val rbCleanStorage: RadioButton = RadioButton(binding.root.context)
    override val llOptPlace: LinearLayout = LinearLayout(binding.root.context)
    override val rbRandom: RadioButton = RadioButton(binding.root.context)
    override val llPreview: LinearLayout = LinearLayout(binding.root.context)
    override val mApplyBtn: TextView = TextView(binding.root.context)
}

fun MessageListItemOutBinding.toMessageBinding() = MessageOutBinding(this)