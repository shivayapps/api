package com.video.aimagic.commonscreen.screen;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.GravityCompat;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.video.aimagic.R;
import com.video.aimagic.databinding.ActivityMainBinding;
import com.video.aimagic.extension.ExtensionsKt;
import com.video.aimagic.settings.SettingScreen;
import com.video.aimagic.singletone.CustomDialogManager;
import com.video.aimagic.singletone.ExitDialog;
import com.video.aimagic.utils.Methods;

import java.lang.reflect.Method;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class HomeScreen extends AppCompatActivity {
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
//        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(),
                new OnApplyWindowInsetsListener() {
                    @Override
                    public WindowInsetsCompat onApplyWindowInsets(View v, WindowInsetsCompat insets) {
                        Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                        v.setPadding(
                                systemBars.left,
                                systemBars.top,
                                systemBars.right,
                                0
                        );
                        return insets;
                    }
                }
        );

        loadingFragments();
        setOnClickListners();
    }

    private void navigateToActivity(Class<?> activityClass) {
        Intent intent = new Intent(HomeScreen.this, activityClass);
        startActivity(intent);
        overridePendingTransition(
                R.anim.cusotm_slide_in_right,
                R.anim.custom_slide_out_left
        );
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        new ExitDialog(this, new Function1<Boolean, Unit>() {
            @Override
            public Unit invoke(Boolean isExit) {
                if (isExit) {
                    finishAffinity();
                    //finish();
                }
                return null;
            }
        }).show();
    }

    private void setOnClickListners() {
//        binding.settingsButton.setOnClickListener(v -> {
////            navigateToActivity(SettingScreen.class);
//
//        });
        binding.icDrawer.setOnClickListener(v -> {
            if (binding.drawerLay.isDrawerOpen(GravityCompat.START))
                binding.drawerLay.closeDrawer(GravityCompat.START);
            else binding.drawerLay.openDrawer(GravityCompat.START);
        });

//        binding.icDrawer.setOnClickListener {
//            if (binding.drawerLay.isDrawerOpen(GravityCompat.START))
//                binding.drawerLay.closeDrawer(GravityCompat.START)
//            else binding.drawerLay.openDrawer(GravityCompat.START)
//        }


        binding.drawerContent.setOnClickListener(v -> {

        });


        binding.creationsOption.setOnClickListener(v -> {
            //showToast("Creations")
            closeDrawer();
//            BottomNavigationView bottomNav = findViewById(R.id.bottomNavigationInHomeScreen);
//            bottomNav.setSelectedItemId(R.id.CreationsFragment);
            binding.bottomNavigationInHomeScreen.setSelectedItemId(R.id.CreationsFragment);
//            NavController navController = Navigation.findNavController(this, R.id.navHostMAneger);
//            navController.navigate(R.id.CreationsFragment);
        });

        binding.rateOption.setOnClickListener(v -> {
            //showToast("Rate App")
            closeDrawer();
            Methods.INSTANCE.showRatingDialog(this);

        });
        binding.shareOption.setOnClickListener(v -> {
            //showToast("Share App")
            closeDrawer();
            shareApp();
        });
        binding.supportOption.setOnClickListener(v -> {
            //showToast("Support")
            closeDrawer();
            Methods.INSTANCE.showFeedbackDialog(this);
        });
        binding.privacyOption.setOnClickListener(v -> {
            //showToast("Privacy Policy")
            closeDrawer();
            openPrivacyPolicy();
        });
    }
    private void shareApp() {
        try {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(
                    Intent.EXTRA_TEXT,
                    "Check out the App at: https://play.google.com/store/apps/details?id=$packageName"
            );
            sendIntent.setType("text/plain");
            startActivity(sendIntent);
        } catch (Exception e) {

        }
    }
    private void launchAppStore() {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id="+getPackageName()));
        startActivity(intent);
    }

    private void openPrivacyPolicy() {
        String url = "https://ahyanapps.blogspot.com/2023/04/ahyan-apps-privacy.html";
        if (url != null && !url.isEmpty()) {
            try {
                CustomTabsIntent.Builder builder  = new CustomTabsIntent.Builder();
                builder.setToolbarColor(ContextCompat.getColor(this, R.color.white));
                CustomTabsIntent customTabsIntent = builder.build();
                customTabsIntent.intent.setPackage("com.android.chrome");
                customTabsIntent.launchUrl(this, Uri.parse(url));
            } catch (Exception e) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        }
    }

    private void closeDrawer() {
        if (binding.drawerLay.isDrawerOpen(GravityCompat.START)) {
            binding.drawerLay.closeDrawer(GravityCompat.START);
        }
    }

    private void loadingFragments() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationInHomeScreen);
        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.navHostMAneger);
        NavController navController = navHostFragment.getNavController();
        NavigationUI.setupWithNavController(bottomNavigationView, navController);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}