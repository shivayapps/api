package com.video.aimagic.facedance.api;

public interface ApiCallback {
    void onSuccess(String response);
    void onError(String errorMessage);
}