package com.video.aimagic.utils.appconfig

import android.app.Activity
import android.content.Intent
import android.os.Parcelable
import com.video.aimagic.R
import com.video.aimagic.backgroundchanger.BackgroundChangeScreen
import com.video.aimagic.bodyeditor.activites.BodyEditor
import com.video.aimagic.commonscreen.screen.CommonProcessing
import java.io.Serializable

object StartActivityGlobally {


    /*@SuppressWarnings("unchecked")
    @JvmStatic
    fun navigateToActivityWithFeature(context: Activity, targetActivity: Class<*>, vararg extras: Pair<String, Any?>) {
        val intent = Intent(context, targetActivity)

        extras.forEach { (key, value) ->
            when (value) {
                is String -> intent.putExtra(key, value)
                is Int -> intent.putExtra(key, value)
                is Boolean -> intent.putExtra(key, value)
                is Long -> intent.putExtra(key, value)
                is Float -> intent.putExtra(key, value)
                is Double -> intent.putExtra(key, value)
                is Serializable -> intent.putExtra(key, value)
                is Parcelable -> intent.putExtra(key, value)
                null -> intent.putExtra(key, null as String?)
            }
        }

        context.startActivity(intent)
        context.overridePendingTransition(
            R.anim.cusotm_slide_in_right,
            R.anim.custom_slide_out_left
        )
    }*/

    @SuppressWarnings("unchecked")
    @JvmStatic
    fun navigateToActivityWithFeature(
        activity: Activity,
        targetActivity: Class<*>,
        vararg extras: Pair<String, Any?>
    ) {
        val intent = Intent(activity, targetActivity)

        // Add this flag if context is not an Activity
        if (activity !is Activity) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        extras.forEach { (key, value) ->
            when (value) {
                is String -> intent.putExtra(key, value)
                is Int -> intent.putExtra(key, value)
                is Boolean -> intent.putExtra(key, value)
                is Long -> intent.putExtra(key, value)
                is Float -> intent.putExtra(key, value)
                is Double -> intent.putExtra(key, value)
                is Serializable -> intent.putExtra(key, value)
                is Parcelable -> intent.putExtra(key, value)
                null -> intent.putExtra(key, null as String?)
            }
        }

        activity.startActivity(intent)

        // Only apply transition if context is an Activity
        if (activity is Activity) {
            activity.overridePendingTransition(
                R.anim.cusotm_slide_in_right,
                R.anim.custom_slide_out_left
            )
        }
        if (activity is CommonProcessing) {
            activity.finish()
        } else if (
            activity is Activity
            && !(activity is BackgroundChangeScreen)
            && !(activity is BodyEditor)
        ) {
            activity.finish()
        }

    }
}