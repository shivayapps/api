package com.video.aimagic.commonscreen.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.bumptech.glide.Glide;
import com.video.aimagic.R;

import java.util.List;
import java.util.Random;

public class CreationAdapter
        extends RecyclerView.Adapter<CreationAdapter.VideoViewHolder> {

    private final Context context;
    private final List<MediaItem> list;

    private OnItemClickListener listener;
    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public CreationAdapter(Context context, List<MediaItem> list,OnItemClickListener listener) {
        this.context = context;
        this.list = list;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VideoViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_creation, parent, false);

        return new VideoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull VideoViewHolder holder, int position) {

        MediaItem item = list.get(position);

        holder.txtName.setText(item.name);

        // Load thumbnail
        Glide.with(context)
                .load(item.uri)
                .thumbnail(0.2f)
                .dontAnimate()
                .into(holder.imgThumbnail);

        if (item.type == MediaItem.TYPE_VIDEO) {
            holder.playIcon.setVisibility(View.VISIBLE);
        } else {
            holder.playIcon.setVisibility(View.GONE);
        }

        holder.imgThumbnail.setOnClickListener(v -> {
            listener.onItemClick(position);
        });
//        applyRandomRatio(holder.itemView);
        ViewGroup.LayoutParams lp = holder.itemView.getLayoutParams();
        if (lp instanceof StaggeredGridLayoutManager.LayoutParams) {
            ((StaggeredGridLayoutManager.LayoutParams) lp).setFullSpan(false);
        }
    }
    float[] ratios = {
            1f / 1f,   // 1:1
            3f / 4f,   // 3:4
            2f / 3f    // 2:3
    };

    private void applyRandomRatio(View view) {
        float ratio = ratios[new Random().nextInt(ratios.length)];

        int width = view.getResources().getDisplayMetrics().widthPixels / 2;
        int height = (int) (width / ratio);

        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.height = height;
        view.setLayoutParams(params);
    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    static class VideoViewHolder extends RecyclerView.ViewHolder {

        ImageView imgThumbnail;
        ImageView playIcon;
        TextView txtName;

        public VideoViewHolder(@NonNull View itemView) {
            super(itemView);
            imgThumbnail = itemView.findViewById(R.id.imgThumbnail);
            playIcon = itemView.findViewById(R.id.playIcon);
            txtName = itemView.findViewById(R.id.txtTitle);
        }
    }
}
