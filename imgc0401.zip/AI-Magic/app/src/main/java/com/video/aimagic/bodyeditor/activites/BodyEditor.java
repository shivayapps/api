package com.video.aimagic.bodyeditor.activites;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.adconfig.AdsConfig;
import com.video.aimagic.databinding.ActivityBodyEditorBinding;
import com.video.aimagic.bodyeditor.screens.ChestEditor;
import com.video.aimagic.bodyeditor.screens.FaceEditor;
import com.video.aimagic.bodyeditor.screens.HipsEditor;
import com.video.aimagic.bodyeditor.screens.WaistEditor;
import com.video.aimagic.extension.ExtensionsKt;
import com.video.aimagic.singletone.PhotoUploadManager;
import com.video.aimagic.utils.appconfig.StartActivityGlobally;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class BodyEditor extends AppCompatActivity {
    private ActivityBodyEditorBinding binding;
    private boolean isImageSaved = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityBodyEditorBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        setOnClickListners();

    }

    private void setOnClickListners() {
        binding.faceControl.setOnClickListener(view -> navigateUser(FaceEditor.class));
        binding.waistControl.setOnClickListener(view -> navigateUser(WaistEditor.class));
        binding.chestControl.setOnClickListener(view -> navigateUser(ChestEditor.class));
        binding.hipsControl.setOnClickListener(view -> navigateUser(HipsEditor.class));
        binding.saveButtonContainer.setOnClickListener(view -> showAdThenSave());
    }

    private void saveImageToGallery() {
        if (isImageSaved) {
            Toast.makeText(this, "Image already saved", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get the bitmap from the ImageView
//        binding.bodyPreviewImage.setDrawingCacheEnabled(true);
//        binding.bodyPreviewImage.buildDrawingCache();
//        Bitmap bitmap = binding.bodyPreviewImage.getDrawingCache();
        Bitmap bitmap = PhotoUploadManager.getInstance().getUniversalBitmap();

        if (bitmap != null) {
            try {
                String storageDirPath =
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
                                .getPath() + "/AiMagic/";

                File storageDir = new File(storageDirPath);
                if (!storageDir.exists()) {
                    storageDir.mkdirs(); // ✅ create folder
                }

                File imageFile = new File(
                        storageDir,
                        "Imagic_img_" + System.currentTimeMillis() + ".jpg"
                );

                FileOutputStream outputStream = new FileOutputStream(imageFile);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                outputStream.flush();
                outputStream.close();

                Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                mediaScanIntent.setData(Uri.fromFile(imageFile));
                sendBroadcast(mediaScanIntent);
                isImageSaved = true;
                updateSaveButtonState();
                Toast.makeText(this, "Image saved to gallery", Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to save image", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void updateSaveButtonState() {}
    private void showAdThenSave() {
        AdsConfig.Companion.showInterstitialAd(this, new Function1<Boolean, Unit>() {
            @Override
            public Unit invoke(Boolean aBoolean) {
                saveImageToGallery();
                return null;
            }
        });
    }

    private void setImageResource() {

        try {
            binding.bodyPreviewImage.setImageBitmap(PhotoUploadManager.getInstance().getUniversalBitmap());
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    protected void onResume() {
        super.onResume();
        setImageResource();
    }

    @SuppressWarnings("unchecked")
    private void navigateUser(Class<? extends Activity> targetActivity) {
        StartActivityGlobally.navigateToActivityWithFeature(
                BodyEditor.this,
                targetActivity);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}