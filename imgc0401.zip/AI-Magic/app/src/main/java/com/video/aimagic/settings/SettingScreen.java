package com.video.aimagic.settings;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import com.video.aimagic.databinding.ActivitySettingBinding;
import com.video.aimagic.extension.ExtensionsKt;

public class SettingScreen extends AppCompatActivity {

    private ActivitySettingBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivitySettingBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());

        setupClickListeners();
    }

    private void setupClickListeners() {
        binding.creationsOption.setOnClickListener(v -> showToast("Creations"));
        binding.videosOption.setOnClickListener(v -> showToast("Saved Videos"));
        binding.rateOption.setOnClickListener(v -> showToast("Rate App"));
        binding.shareOption.setOnClickListener(v -> showToast("Share App"));
        binding.supportOption.setOnClickListener(v -> showToast("Support"));
        binding.privacyOption.setOnClickListener(v -> showToast("Privacy Policy"));
        binding.onBackButton.setOnClickListener(v -> onBackPressed());
    }

    private void showToast(String message) {
        Toast.makeText(this, message + " clicked", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}