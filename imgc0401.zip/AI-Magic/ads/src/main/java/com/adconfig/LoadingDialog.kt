package com.adconfig

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.Window
import android.view.WindowManager
import androidx.annotation.DrawableRes
import com.adconfig.databinding.DialogLoadingBinding


class LoadingDialog(
    val activity: Activity,
    val txtTitle: String,
) : Dialog(activity) {

    lateinit var bindingDialog: DialogLoadingBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)

        bindingDialog = DialogLoadingBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)

        intView()
    }

    private fun intView() {
        bindingDialog.tvLoading.text = txtTitle
//        bindingDialog.progressBar.isIndeterminate = true
    }

}