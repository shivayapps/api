package com.natara.photo.collage.maker.collage.customviews.layers.straight;

import com.natara.photo.collage.maker.collage.customviews.grid.NataraLayout;
import com.natara.photo.collage.maker.collage.customviews.grid.NataraLine;

public class EightStraightLayout extends NumberStraightLayout {
    public int getThemeCount() {
        return 11;
    }


    public EightStraightLayout(StraightCollageLayout straightPuzzleLayout, boolean z) {
        super(straightPuzzleLayout, z);
    }

    public EightStraightLayout(int i) {
        super(i);
    }

    public void layout() {
        switch (this.theme) {
            case 0:
                cutAreaEqualPart(0, 3, 1);
                return;
            case 1:
                cutAreaEqualPart(0, 1, 3);
                return;
            case 2:
                cutAreaEqualPart(0, 4, NataraLine.Direction.VERTICAL);
                addLine(3, NataraLine.Direction.HORIZONTAL, 0.8f);
                addLine(2, NataraLine.Direction.HORIZONTAL, 0.6f);
                addLine(1, NataraLine.Direction.HORIZONTAL, 0.4f);
                addLine(0, NataraLine.Direction.HORIZONTAL, 0.2f);
                return;
            case 3:
                cutAreaEqualPart(0, 4, NataraLine.Direction.HORIZONTAL);
                addLine(3, NataraLine.Direction.VERTICAL, 0.8f);
                addLine(2, NataraLine.Direction.VERTICAL, 0.6f);
                addLine(1, NataraLine.Direction.VERTICAL, 0.4f);
                addLine(0, NataraLine.Direction.VERTICAL, 0.2f);
                return;
            case 4:
                cutAreaEqualPart(0, 4, NataraLine.Direction.VERTICAL);
                addLine(3, NataraLine.Direction.HORIZONTAL, 0.2f);
                addLine(2, NataraLine.Direction.HORIZONTAL, 0.4f);
                addLine(1, NataraLine.Direction.HORIZONTAL, 0.6f);
                addLine(0, NataraLine.Direction.HORIZONTAL, 0.8f);
                return;
            case 5:
                cutAreaEqualPart(0, 4, NataraLine.Direction.HORIZONTAL);
                addLine(3, NataraLine.Direction.VERTICAL, 0.2f);
                addLine(2, NataraLine.Direction.VERTICAL, 0.4f);
                addLine(1, NataraLine.Direction.VERTICAL, 0.6f);
                addLine(0, NataraLine.Direction.VERTICAL, 0.8f);
                return;
            case 6:
                cutAreaEqualPart(0, 3, NataraLine.Direction.HORIZONTAL);
                cutAreaEqualPart(2, 3, NataraLine.Direction.VERTICAL);
                cutAreaEqualPart(1, 2, NataraLine.Direction.VERTICAL);
                cutAreaEqualPart(0, 3, NataraLine.Direction.VERTICAL);
                return;
            case 7:
                cutAreaEqualPart(0, 3, NataraLine.Direction.VERTICAL);
                cutAreaEqualPart(2, 3, NataraLine.Direction.HORIZONTAL);
                cutAreaEqualPart(1, 2, NataraLine.Direction.HORIZONTAL);
                cutAreaEqualPart(0, 3, NataraLine.Direction.HORIZONTAL);
                return;
            case 8:
                addLine(0, NataraLine.Direction.HORIZONTAL, 0.8f);
                cutAreaEqualPart(1, 5, NataraLine.Direction.VERTICAL);
                addLine(0, NataraLine.Direction.HORIZONTAL, 0.5f);
                addLine(1, NataraLine.Direction.VERTICAL, 0.5f);
                return;
            case 9:
                cutAreaEqualPart(0, 3, NataraLine.Direction.HORIZONTAL);
                cutAreaEqualPart(2, 2, NataraLine.Direction.VERTICAL);
                cutAreaEqualPart(1, 3, NataraLine.Direction.VERTICAL);
                addLine(0, NataraLine.Direction.VERTICAL, 0.75f);
                addLine(0, NataraLine.Direction.VERTICAL, 0.33333334f);
                return;
            case 10:
                cutAreaEqualPart(0, 2, 1);
                addLine(5, NataraLine.Direction.VERTICAL, 0.5f);
                addLine(4, NataraLine.Direction.VERTICAL, 0.5f);
                return;
            default:
                return;
        }
    }

    public NataraLayout clone(NataraLayout quShotLayout) {
        return new EightStraightLayout((StraightCollageLayout) quShotLayout, true);
    }
}
