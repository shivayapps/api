package com.natara.photo.collage.maker.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.huawei.hms.mlsdk.MLAnalyzerFactory
import com.huawei.hms.mlsdk.common.MLFrame
import com.huawei.hms.mlsdk.imgseg.MLImageSegmentationAnalyzer
import com.huawei.hms.mlsdk.imgseg.MLImageSegmentationScene
import com.huawei.hms.mlsdk.imgseg.MLImageSegmentationSetting
import com.natara.photo.collage.maker.bgremover.utils.ChromeFloatingCirclesDrawable
import com.natara.photo.collage.maker.extentions.getProgressDrawableColors
import com.natara.photo.collage.maker.picker.util.ToastUtil.showToast

open class BaseActivity : AppCompatActivity() {
    private lateinit var mAnalyzer: MLImageSegmentationAnalyzer

    fun createAnalyzer(): MLImageSegmentationAnalyzer {
        val analyzerSetting = MLImageSegmentationSetting.Factory()
            .setExact(true)
            .setAnalyzerType(MLImageSegmentationSetting.BODY_SEG)
            .setScene(MLImageSegmentationScene.FOREGROUND_ONLY)
            .create()

        return MLAnalyzerFactory.getInstance().getImageSegmentationAnalyzer(analyzerSetting).also {
            mAnalyzer = it
        }
    }

    fun analyse(bmp: Bitmap, cropBitmap: (Bitmap) -> Unit) {
        val mlFrame = MLFrame.fromBitmap(bmp)
        mAnalyzer.asyncAnalyseFrame(mlFrame)
            .addOnSuccessListener {
                cropBitmap(it.foreground)
            }
            .addOnFailureListener {
                showToast("Face Not Found.")
            }

    }

    fun Context.showGoogleProgressBar(): Drawable =
        ChromeFloatingCirclesDrawable.Builder(this)
            .colors(getProgressDrawableColors())
            .build()
}