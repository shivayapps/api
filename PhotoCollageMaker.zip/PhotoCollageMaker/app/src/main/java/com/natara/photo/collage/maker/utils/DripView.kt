package com.natara.photo.collage.maker.utils

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatImageView
import com.natara.photo.collage.maker.bgremover.MTouch.MultiTouchListener

class DripView(context: Context, attributeSet: AttributeSet?, i: Int) : AppCompatImageView(
    context, attributeSet, i
) {
    var multiTouchListener: MultiTouchListener? = null

    constructor(context: Context, attributeSet: AttributeSet) : this(
        context,
        attributeSet,
        0
    ) {
        setPadding(0, 0, 0, 0)
    }

    init {
        initBorderPaint()
    }

    private fun initBorderPaint() {
        val paint = Paint()
        paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE
        paint.color = -1
        paint.strokeWidth = 0.0f
    }

    public override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
    }

    fun setOnTouchListenerCustom(multiTouchListener2: MultiTouchListener?) {
        multiTouchListener = multiTouchListener2
        setOnTouchListener(multiTouchListener2)
    }
}