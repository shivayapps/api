package com.natara.photo.collage.maker.utils

import android.content.Context
import android.content.res.Resources
import android.graphics.*
import java.io.IOException

object DripUtils {
    fun getBitmapFromAsset(context: Context, str: String?): Bitmap? {
        return if (str == null) {
            null
        } else try {
            BitmapFactory.decodeStream(context.assets.open(str))
        } catch (unused: IOException) {
            null
        }
    }

    fun changeBitmapColor(bitmap: Bitmap, i: Int): Bitmap {
        val copy = bitmap.copy(bitmap.config, true)
        val paint = Paint()
        paint.colorFilter = LightingColorFilter(i, 1)
        Canvas(copy).drawBitmap(copy, 0.0f, 0.0f, paint)
        return copy
    }

    fun dpToPx(i: Int): Int {
        return (i.toFloat() * Resources.getSystem().displayMetrics.density).toInt()
    }
}