package com.natara.photo.collage.maker.collage.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.natara.photo.collage.maker.collage.models.CollageModels
import com.natara.photo.collage.maker.collage.module.Module
import com.natara.photo.collage.maker.collage.utils.CustomDiffUtils.TOOLS_DIFF
import com.natara.photo.collage.maker.databinding.LayoutCollageToolsBinding

class CollageToolsAdapter(val mOnItemSelected: OnItemSelected) :
    ListAdapter<CollageModels.ToolModel, CollageToolsAdapter.ViewHolder>(TOOLS_DIFF) {

    interface OnItemSelected {
        fun onToolSelected(toolType: Module)
    }


    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        return ViewHolder(
            LayoutCollageToolsBinding.inflate(
                LayoutInflater.from(viewGroup.context),
                viewGroup,
                false
            )
        )
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {
        val toolModel = currentList[i]
        viewHolder.bind(toolModel)
    }

    override fun getItemCount(): Int {
        return currentList.size
    }

    inner class ViewHolder(private val binding: LayoutCollageToolsBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(toolModel: CollageModels.ToolModel) {
            binding.textViewToolName.text = toolModel.mToolName
            binding.imageViewToolIcon.setImageResource(toolModel.mToolIcon)
            binding.relativeLayoutWrapperTool.setOnClickListener {
                mOnItemSelected.onToolSelected(
                    toolModel.mToolType
                )
            }
        }
    }
}
