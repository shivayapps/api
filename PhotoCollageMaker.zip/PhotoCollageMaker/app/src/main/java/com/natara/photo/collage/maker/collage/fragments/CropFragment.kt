package com.natara.photo.collage.maker.collage.fragments

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.isseiaoki.simplecropview.CropImageView
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.adapter.AspectAdapter
import com.natara.photo.collage.maker.collage.adapter.AspectAdapter.OnNewSelectedListener
import com.natara.photo.collage.maker.collage.viewmodels.CollageViewModel
import com.natara.photo.collage.maker.databinding.FragmentCropBinding
import com.natara.photo.collage.maker.utils.FlipDirection
import com.natara.photo.collage.maker.utils.ImageFlipper
import com.steelkiwi.cropiwa.AspectRatio
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CropFragment : DialogFragment() {
    private var bitmap: Bitmap? = null
    private var onCropPhoto: OnCropPhoto? = null
    private val collageViewModel: CollageViewModel by viewModels()

    private lateinit var binding: FragmentCropBinding

    private val aspectRatioPreviewAdapter by lazy {
        AspectAdapter(object : OnNewSelectedListener {
            override fun onNewAspectRatioSelected(aspectRatio: AspectRatio?) {
                if (aspectRatio != null) {
                    if (aspectRatio.width == 10 && aspectRatio.height == 10) {
                        binding.cropImageView.setCropMode(CropImageView.CropMode.FREE)
                    } else {
                        binding.cropImageView.setCustomRatio(
                            aspectRatio.width,
                            aspectRatio.height
                        )
                    }
                }
            }
        })
    }


    interface OnCropPhoto {
        fun finishCrop(bitmap: Bitmap?)
    }

    fun setBitmap(bitmap2: Bitmap?) {
        bitmap = bitmap2
    }

    fun setOnCropPhoto(onCropPhoto2: OnCropPhoto?) {
        onCropPhoto = onCropPhoto2
    }

    override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)
        retainInstance = true
    }

    override fun onStart() {
        super.onStart()
        val dialog = dialog
        if (dialog != null) {
//            val width = (resources.displayMetrics.widthPixels * 1)
//            val height = (resources.displayMetrics.heightPixels * 1)
//            dialog.window?.setLayout(width,height)
            dialog.window?.setLayout(-1, -1)
            dialog.window?.setBackgroundDrawable(ColorDrawable(-16777216))
        }
    }

    @SuppressLint("WrongConstant")
    override fun onCreateView(
        layoutInflater: LayoutInflater,
        viewGroup: ViewGroup?,
        bundle: Bundle?,
    ): View {
        dialog?.window?.attributes?.windowAnimations = R.style.DialogAnimation
        dialog?.window?.requestFeature(1)
        dialog?.window?.setFlags(1024, 1024)
        binding = FragmentCropBinding.inflate(layoutInflater)

        setUpCrop()
        initListeners()

        binding.relativeLayoutLoading.visibility = View.GONE
        return binding.root
    }

    override fun onViewCreated(view: View, bundle: Bundle?) {
        super.onViewCreated(view, bundle)
        binding.cropImageView.imageBitmap = bitmap
    }

    private fun setUpCrop() {

        binding.cropImageView.setCropMode(CropImageView.CropMode.FREE)
        binding.recyclerViewRatio.layoutManager =
            LinearLayoutManager(requireContext(), RecyclerView.HORIZONTAL, false)
        binding.recyclerViewRatio.adapter = aspectRatioPreviewAdapter

        aspectRatioPreviewAdapter.submitList(collageViewModel.getRatioModelList(true))
    }

    private fun initListeners() {
        binding.relativeLayoutRotate.setOnClickListener {
            binding.cropImageView.rotateImage(
                CropImageView.RotateDegrees.ROTATE_M90D
            )
        }
        binding.relativeLayouRotate90.setOnClickListener {
            binding.cropImageView.rotateImage(
                CropImageView.RotateDegrees.ROTATE_90D
            )
        }
        binding.relativeLayoutVFlip.setOnClickListener {
            ImageFlipper.flip(
                binding.cropImageView,
                FlipDirection.VERTICAL
            )
        }
        binding.relativeLayoutHFlip.setOnClickListener {
            ImageFlipper.flip(
                binding.cropImageView,
                FlipDirection.HORIZONTAL
            )
        }
        binding.imageViewSaveCrop.setOnClickListener {
            onSaveCrop()
        }
        binding.imageViewCloseCrop.setOnClickListener { dismiss() }
    }

    private fun onSaveCrop() = CoroutineScope(Dispatchers.Main).launch {
        mLoading(true)
        bitmap = binding.cropImageView.croppedBitmap
        mLoading(false)
        onCropPhoto?.finishCrop(bitmap)
        dismiss()
    }

    private fun mLoading(z: Boolean) {
        if (z) {
            requireActivity().window.setFlags(16, 16)
            binding.relativeLayoutLoading.visibility = View.VISIBLE
            return
        }
        requireActivity().window.clearFlags(16)
        binding.relativeLayoutLoading.visibility = View.GONE
    }

    companion object {
        private const val TAG = "CropFragment"
        fun show(
            appCompatActivity: AppCompatActivity,
            onCropPhoto2: OnCropPhoto?,
            bitmap2: Bitmap?,
        ): CropFragment {
            val cropDialogFragment = CropFragment()
            cropDialogFragment.setBitmap(bitmap2)
            cropDialogFragment.setOnCropPhoto(onCropPhoto2)
            cropDialogFragment.show(appCompatActivity.supportFragmentManager, TAG)
            return cropDialogFragment
        }
    }
}
