package com.natara.photo.collage.maker.collage.viewmodels

import android.app.Application
import android.content.ContentUris
import android.content.Context
import android.database.ContentObserver
import android.database.Cursor
import android.os.Environment
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.models.MediaItemObj
import com.natara.photo.collage.maker.collage.utils.registerMediaObserver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MediaViewModel(context: Context) : AndroidViewModel(context as Application) {

    private val mediaItemMLD = MutableLiveData<List<MediaItemObj>>()
    val mediaItemList: LiveData<List<MediaItemObj>> = mediaItemMLD
    private var contentObserver: ContentObserver? = null

    val savePath =
        "${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath}${File.separator}${
            context.getString(
                R.string.app_name
            )
        }${File.separator}"


    private fun getAllImages() = CoroutineScope(Dispatchers.IO).launch {
        val images = arrayListOf<MediaItemObj>()

        val contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Images.ImageColumns._ID,
            MediaStore.Images.ImageColumns.DATA
        )

        val selection = "${MediaStore.Images.Media.DATA} LIKE ?"
        val selectionArgs = arrayOf("%$savePath%")
        val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"

        val cursor: Cursor? = getApplication<Application>().contentResolver.query(
            contentUri, projection, selection, selectionArgs, sortOrder
        )

        try {

            cursor?.let { c ->
                while (c.moveToNext()) {
                    val imgPath: String = (cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)))
                    if (File(imgPath).exists()) {
                        val mediaItem = MediaItemObj(
                            id = (cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID))),
                            path = (cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))),
                            uri = ContentUris.withAppendedId(
                                MediaStore.Images.Media.getContentUri("external"),
                                (cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)))
                            )
                        )
                        images += mediaItem
                    }
                }
                cursor.close()

                withContext(Dispatchers.Main) {
                    mediaItemMLD.postValue(images)
                }
//                emit(images)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }


    }

    fun loadMediaItems() {
        viewModelScope.launch {
            getAllImages()
            if (contentObserver == null) {
                contentObserver =
                    getApplication<Application>().contentResolver.registerMediaObserver {
                        loadMediaItems()
                    }
            }
        }
    }
}