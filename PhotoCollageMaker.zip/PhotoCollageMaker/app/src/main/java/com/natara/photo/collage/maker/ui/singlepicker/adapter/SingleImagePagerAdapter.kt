package com.natara.photo.collage.maker.ui.singlepicker.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.natara.photo.collage.maker.models.Album
import com.natara.photo.collage.maker.ui.singlepicker.fragment.SingleImageFolderFragment

class SingleImagePagerAdapter(
    fragmentManager: FragmentManager,
    lifecycle: Lifecycle,
    private val imagesByFolder: List<Album>
) : FragmentStateAdapter(fragmentManager, lifecycle) {

    override fun getItemCount(): Int {
        return imagesByFolder.size
    }

    override fun createFragment(position: Int): Fragment {
        val imagesInFolder = imagesByFolder[position].mediaUris
        return SingleImageFolderFragment(imagesInFolder)
    }

    fun getFolderName(position: Int): String {
        return imagesByFolder[position].name
    }
}
