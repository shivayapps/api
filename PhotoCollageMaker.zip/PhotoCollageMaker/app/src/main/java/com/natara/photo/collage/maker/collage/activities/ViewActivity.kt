package com.natara.photo.collage.maker.collage.activities

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.content.FileProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.adapter.ViewPagerAdapter
import com.natara.photo.collage.maker.collage.models.MediaItemObj
import com.natara.photo.collage.maker.collage.viewmodels.MediaViewModel
import com.natara.photo.collage.maker.databinding.ActivityViewBinding
import com.natara.photo.collage.maker.ui.home.activity.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class ViewActivity : AppCompatActivity() {

    private val adapter: ViewPagerAdapter by lazy {
        ViewPagerAdapter()
    }

    private val mDataViewModel: MediaViewModel by lazy {
        MediaViewModel(this.applicationContext)
    }

    private lateinit var binding: ActivityViewBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityViewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.mToolBar.mTVSave.text = "Home"
        binding.mToolBar.mTVTitle.text = "Share"

        loadUiData()
        observeImage()
        clickListeners()

    }

    private fun observeImage() = CoroutineScope(Dispatchers.Main).launch {
        mDataViewModel.loadMediaItems()
        val targetPosition = intent?.getIntExtra("position", 0) ?: 0
        binding.mVPCreation.orientation = ViewPager2.ORIENTATION_HORIZONTAL

        mDataViewModel.mediaItemList.observe(this@ViewActivity) { imageList ->
            if (imageList.isNotEmpty()) {
                adapter.submitList(imageList).apply {
                    binding.mVPCreation.adapter = adapter
                    binding.mVPCreation.setCurrentItem(targetPosition, false)
                }
            }
        }
    }

    private fun clickListeners() {

        binding.mToolBar.mIVBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        binding.mToolBar.mTVSave.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
        }

        binding.mShareFb.root.setOnClickListener {
            sharePhoto("com.facebook.katana", adapter.currentList[binding.mVPCreation.currentItem])
        }
        binding.mShareEmail.root.setOnClickListener {
            sharePhoto(
                "com.google.android.gm",
                adapter.currentList[binding.mVPCreation.currentItem]
            )
        }
        binding.mShareInsta.root.setOnClickListener {
            sharePhoto(
                "com.instagram.android",
                adapter.currentList[binding.mVPCreation.currentItem]
            )
        }
        binding.mShareTelegram.root.setOnClickListener {
            sharePhoto(
                "org.telegram.messenger",
                adapter.currentList[binding.mVPCreation.currentItem]
            )
        }
        binding.mShareTwitter.root.setOnClickListener {
            sharePhoto("com.twitter.android", adapter.currentList[binding.mVPCreation.currentItem])
        }

        binding.mShareWp.root.setOnClickListener {
            sharePhoto("com.whatsapp", adapter.currentList[binding.mVPCreation.currentItem])
        }
        binding.mShareOther.root.setOnClickListener {
            sendImage(adapter.currentList[binding.mVPCreation.currentItem])
        }

    }

    private fun sendImage(mediaItemObj: MediaItemObj) {
        val shareIntent: Intent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_STREAM, mediaItemObj.uri)
            putExtra(Intent.EXTRA_TITLE, getString(R.string.app_name))
            putExtra(
                Intent.EXTRA_TEXT,
                "https://play.google.com/store/apps/developer?id=Unique+Thinker"
            )

            val data = mediaItemObj.uri
            val type = "image/*"

            setDataAndType(data, type)

            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        startActivity(Intent.createChooser(shareIntent, null))
    }

    private fun sharePhoto(packageName: String, mediaItemObj: MediaItemObj) {

        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "image/*"
        intent.putExtra(Intent.EXTRA_STREAM, mediaItemObj.uri)
        intent.setPackage(packageName)

        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Can't find this App, please download and try it again", Toast.LENGTH_SHORT).show()
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
            startActivity(intent)
        }
    }

    private fun loadUiData() {
        val arrayList = arrayListOf<Pair<String, Int>>(
            Pair("WhatsApp", R.drawable.ic_wp),
            Pair("Facebook", R.drawable.ic_fb),
            Pair("Instagram", R.drawable.ic_insta),
            Pair("Twitter", R.drawable.ic_twitter),
            Pair("Telegram", R.drawable.ic_tel),
            Pair("Mail", R.drawable.ic_mail),
            Pair("", 0),
            Pair("Other", R.drawable.ic_send)
        )
        val parent = binding.mCLShare

        for (i in 0 until parent.childCount) {
            val include = parent.getChildAt(i) as? ConstraintLayout

            include?.let {
                for (j in 0 until it.childCount) {
                    if (it.getChildAt(j) is ImageView) {
                        Glide.with(this).load(arrayList[i].second)
                            .into(include.getChildAt(j) as ImageView)
                    } else {
                        (it.getChildAt(j) as TextView).text = arrayList[i].first
                    }
                }
            }

        }

    }

}