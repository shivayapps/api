package com.natara.photo.collage.maker.ui.picker.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}