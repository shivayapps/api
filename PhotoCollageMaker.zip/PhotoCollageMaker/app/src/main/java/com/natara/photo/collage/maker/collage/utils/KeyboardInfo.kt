package com.natara.photo.collage.maker.collage.utils

object KeyboardInfo {
    const val HEIGHT_NOT_COMPUTED = -1
    const val STATE_UNKNOWN = -1
    const val STATE_CLOSED = 0
    const val STATE_OPENED = 1

    var keyboardHeight = HEIGHT_NOT_COMPUTED

    var keyboardState = STATE_UNKNOWN
}