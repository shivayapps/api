package com.natara.photo.collage.maker.ui.home.activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback
import com.lyrebirdstudio.croppylib.Croppy
import com.lyrebirdstudio.croppylib.main.CropRequest
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.bgremover.activity.BgRemoveActivity
import com.natara.photo.collage.maker.databinding.ActivityMainBinding
import com.natara.photo.collage.maker.extentions.customDialog
import com.natara.photo.collage.maker.extentions.requestMultiplePermissions
import com.natara.photo.collage.maker.picker.ImagePicker
import com.natara.photo.collage.maker.ui.doubleexposure.BlenderActivity
import com.natara.photo.collage.maker.ui.drip.DripEditorActivity
import com.natara.photo.collage.maker.ui.home.adapter.FeatureAdapter
import com.natara.photo.collage.maker.ui.home.creation.activity.CreationActivity
import com.natara.photo.collage.maker.ui.picker.activity.CollagePickerActivity
import com.natara.photo.collage.maker.ui.pixlab.activity.ArtActivity
import com.natara.photo.collage.maker.ui.settings.activity.SettingsActivity
import java.io.File


class MainActivity : AppCompatActivity() {


    private lateinit var binding: ActivityMainBinding
    var type = ""

    private var scrollHandler = Handler(Looper.getMainLooper())

    var scrollRunnable = Runnable {
        binding.mVPFeature.currentItem = binding.mVPFeature.currentItem + 1
    }

    private val mFeatureList = arrayListOf(
        Pair(R.drawable.ic_photo_collage_home, "Photo\nCollage"),
        Pair(R.drawable.ic_remove_bg_home, "Background\nRemover")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initView()
        initListeners()

        onBackPressedDispatcher.addCallback(this, onBackPressCallback)

    }

    private fun initView() {
        binding.mVPFeature.apply {
            adapter = FeatureAdapter(mFeatureList, this, object : FeatureAdapter.OnFeatureClick {
                override fun onItemClick() {

                    if (binding.mVPFeature.currentItem % 2 == 1) {
                        requestMultiplePermissions {
                            ImagePicker.ActivityBuilder(this@MainActivity).setRequestCode(103)
                                .setResult(startEditActivity).start()
                        }
                    } else {
                        requestMultiplePermissions {
                            startActivity(
                                Intent(
                                    this@MainActivity,
                                    CollagePickerActivity::class.java
                                )
                            )
                        }
                    }

                }

            })
            clipToPadding = false
            clipChildren = false
            offscreenPageLimit = 3
            getChildAt(0).overScrollMode = RecyclerView.OVER_SCROLL_NEVER
        }

        binding.mVPFeature.registerOnPageChangeCallback(object : OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                scrollHandler.removeCallbacks(scrollRunnable)
                scrollHandler.postDelayed(scrollRunnable, 2000)

                binding.mIVDot0.setImageResource(if (position % 2 == 0) R.drawable.ic_filled_round else R.drawable.ic_line_round)
                binding.mIVDot1.setImageResource(if (position % 2 == 1) R.drawable.ic_filled_round else R.drawable.ic_line_round)

            }
        })
    }

    private fun initListeners() {
        binding.mCVCollage.setOnClickListener {
            requestMultiplePermissions {
                startActivity(Intent(this, CollagePickerActivity::class.java))
            }
        }
        binding.mCVCreation.setOnClickListener {
            startActivity(Intent(this, CreationActivity::class.java))
        }

        binding.mIVSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.mCVPixLab.setOnClickListener {
            type = "PixLab"
            ImagePicker.ActivityBuilder(this).setRequestCode(103)
                .setResult(startEditActivity).start()
        }

        binding.mCVDoubleExpo.setOnClickListener {
            type = "DoubleExposure"
            ImagePicker.ActivityBuilder(this).setRequestCode(103)
                .setResult(startEditActivity).start()
        }
        binding.mCVDrip.setOnClickListener {
            type = "Drip"
            ImagePicker.ActivityBuilder(this).setRequestCode(103)
                .setResult(startEditActivity).start()
        }

        binding.mCVRemoveBg.setOnClickListener {
            requestMultiplePermissions {
                type = "RemoveBg"
                ImagePicker.ActivityBuilder(this).setRequestCode(103)
                    .setResult(startEditActivity).start()
            }
        }
    }

    private val startEditActivity: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->

            if (result.resultCode == 103) {
                val data = result.data

                val cropRequest = CropRequest.Auto(
                    sourceUri = Uri.parse(data?.extras?.getString("EXTRA_SELECTED_URI"))
                )
                Croppy.start(this, cropRequest, startCropActivity)
            }
        }

    private val startCropActivity =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            if (result.resultCode == RESULT_OK) {
                when (type) {
                    "DoubleExposure" -> {
                        startActivity(
                            Intent(this, BlenderActivity::class.java)
                                .putExtra(
                                    "path",
                                    result.data?.data?.path?.let { File(it).absolutePath })
                        )
                    }

                    "Drip" -> {
                        startActivity(
                            Intent(this, DripEditorActivity::class.java)
                                .putExtra(
                                    "path",
                                    result.data?.data?.path?.let { File(it).absolutePath })
                        )
                    }

                    "RemoveBg" -> {
                        startActivity(
                            Intent(this, BgRemoveActivity::class.java)
                                .putExtra(
                                    "path",
                                    result.data?.data?.path?.let { File(it).absolutePath })
                        )
                    }

                    "PixLab" -> {
                        startActivity(
                            Intent(this, ArtActivity::class.java)
                                .putExtra(
                                    "path",
                                    result.data?.data?.path?.let { File(it).absolutePath })
                        )
                    }
                }


            }
        }

    override fun onPause() {
        super.onPause()
        scrollHandler.removeCallbacks(scrollRunnable)
    }

    override fun onResume() {
        super.onResume()
        scrollHandler.postDelayed(scrollRunnable, 2000)
    }


    private val onBackPressCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            customDialog(getString(R.string.exit_app), getString(R.string.exit_msg)) {
                finishAffinity()
            }
        }
    }
}