package com.natara.photo.collage.maker.utils

import android.content.Context

class PreferenceManager(context: Context) {

    val sharedPreference = context.getSharedPreferences("PREFERENCE_NAME", Context.MODE_PRIVATE)
    var editor = sharedPreference.edit()

    private val INTERSTITIAL_COUNT = "INTERSTITIAL_COUNT"
    private val NEED_LANGUAGE = "NEED_LANGUAGE"
    private val NEED_INTRO = "NEED_INTRO"
    private val LANGUAGE = "LANGUAGE"
    private val DAY_NIGHT = "DAY_NIGHT"
    private val PAGE_NAME = "PAGE_NAME"
    private val USERNAME = "USERNAME"
    private val PROFILE_PHOTO = "PROFILE_PHOTO"
    private val PROFILE_SAVED = "PROFILE_SAVED"
    private val PREF_KEY_QUOTE_INDEX = "last_quote_index"

    var dailyQuoteIndex: Int
        get() {
            return sharedPreference.getInt(PREF_KEY_QUOTE_INDEX, 0)
        }
        set(value) {
            editor.putInt(PREF_KEY_QUOTE_INDEX, value)
            editor.commit()
        }

    var isNight: Boolean
        get() {
            return sharedPreference.getBoolean(DAY_NIGHT, false)
        }
        set(value) {
            editor.putBoolean(DAY_NIGHT, value)
            editor.commit()
        }

    var pageName: String
        get() {
            return sharedPreference.getString(PAGE_NAME, "QuotesMaker") ?: "QuotesMaker"
        }
        set(value) {
            editor.putString(PAGE_NAME, value)
            editor.commit()
        }

    var userName: String
        get() {
            return sharedPreference.getString(USERNAME, "@quotesmaker") ?: "@quotesmaker"
        }
        set(value) {
            editor.putString(USERNAME, value)
            editor.commit()
        }

    var profilePhoto: String
        get() {
            return sharedPreference.getString(PROFILE_PHOTO, "") ?: ""
        }
        set(value) {
            editor.putString(PROFILE_PHOTO, value)
            editor.commit()
        }

    var isProfileSaved: Boolean
        get() {
            return sharedPreference.getBoolean(PROFILE_SAVED, false)
        }
        set(value) {
            editor.putBoolean(PROFILE_SAVED, value)
            editor.commit()
        }

    var interstitialCount: Int
        get() {
            return sharedPreference.getInt(INTERSTITIAL_COUNT, 3)
        }
        set(value) {
            editor.putInt(INTERSTITIAL_COUNT, value)
            editor.commit()
        }

    var needToShowLanguage: Boolean
        get() {
            return sharedPreference.getBoolean(NEED_LANGUAGE, true)
        }
        set(value) {
            editor.putBoolean(NEED_LANGUAGE, value)
            editor.commit()
        }


    var needToShowIntro: Boolean
        get() {
            return sharedPreference.getBoolean(NEED_INTRO, true)
        }
        set(value) {
            editor.putBoolean(NEED_INTRO, value)
            editor.apply()
        }

    var setAppLanguage: String
        get() {
            return sharedPreference.getString(LANGUAGE, "en") ?: "en"
        }
        set(value) {
            editor.putString(LANGUAGE, value)
            editor.apply()
        }

}