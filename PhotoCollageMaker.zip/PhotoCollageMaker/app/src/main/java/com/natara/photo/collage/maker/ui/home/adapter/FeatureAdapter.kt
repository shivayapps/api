package com.natara.photo.collage.maker.ui.home.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.natara.photo.collage.maker.databinding.LayoutItemViewpagerBinding

class FeatureAdapter(
    private val mFeatureList: MutableList<Pair<Int, String>>,
    private val viewPager2: ViewPager2,
    private val mOnFeatureClick: OnFeatureClick,
) :
    RecyclerView.Adapter<FeatureAdapter.FeatureViewHolder>() {


    private var runnable = Runnable {
        mFeatureList.addAll(mFeatureList)
        notifyDataSetChanged()
    }

    inner class FeatureViewHolder(val binding: LayoutItemViewpagerBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Pair<Int, String>) {
            binding.mIVFeature.setImageResource(item.first)
            binding.mTVFeature.text = item.second
            binding.root.setOnClickListener {
                mOnFeatureClick.onItemClick()
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FeatureViewHolder {
        return FeatureViewHolder(
            LayoutItemViewpagerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun getItemCount(): Int = mFeatureList.size

    override fun onBindViewHolder(holder: FeatureViewHolder, position: Int) {
        holder.bind(mFeatureList[position])

        if (position == mFeatureList.size - 2) {
            viewPager2.post(runnable)
        }
    }

    interface OnFeatureClick {
        fun onItemClick()
    }
}