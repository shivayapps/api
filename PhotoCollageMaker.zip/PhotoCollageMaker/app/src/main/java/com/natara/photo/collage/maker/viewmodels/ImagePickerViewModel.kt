package com.natara.photo.collage.maker.viewmodels

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.models.Album
import com.natara.photo.collage.maker.models.Media
import com.natara.photo.collage.maker.models.MediaType
import com.natara.photo.collage.maker.ui.picker.utils.Resource
import kotlinx.coroutines.Dispatchers
import java.io.File


class ImagePickerViewModel : ViewModel() {

    private val INDEX_MEDIA_ID = MediaStore.MediaColumns._ID
    private val INDEX_MEDIA_URI = MediaStore.MediaColumns.DATA
    private val INDEX_DATE_ADDED = MediaStore.MediaColumns.DATE_ADDED


    private lateinit var albumName: String

    fun getMediaList(context: Context, mediaType: MediaType = MediaType.IMAGE) =
        liveData(Dispatchers.IO) {
            emit(Resource.loading(data = null))
            try {
                emit(Resource.success(data = getMedia(context, mediaType)))
            } catch (exception: Exception) {
                emit(Resource.error(data = null, message = exception.message ?: "Error Occurred!"))
            }
        }

    private suspend fun getMedia(
        context: Context,
        mediaType: MediaType = MediaType.IMAGE,
    ): List<Album> {

        val uri: Uri
        val where: String

        when (mediaType) {
            MediaType.IMAGE -> {
                uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                albumName = MediaStore.Images.Media.BUCKET_DISPLAY_NAME
                where =
                    "(" + "NOT " + MediaStore.Images.Media.MIME_TYPE + " = 'image/gif'" + " and " + MediaStore.Images.Media.SIZE + " > 0" + ")"
            }

            MediaType.VIDEO -> {
                uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                albumName = MediaStore.Video.Media.BUCKET_DISPLAY_NAME
                where =
                    "(" + MediaStore.Video.Media.MIME_TYPE + " = 'video/mp4'" + " and " + MediaStore.Video.Media.SIZE + " > 0" + ")"
            }
        }

        val sortOrder = "$INDEX_DATE_ADDED DESC"
        val projection =
            arrayOf(INDEX_MEDIA_ID, INDEX_MEDIA_URI, albumName, INDEX_DATE_ADDED)

        val cursor =
            context.contentResolver.query(
                uri,
                projection,
                where,
                null,
                sortOrder
            )
        val albumList: List<Album> = cursor?.let {


            val totalImageList =
                generateSequence { if (cursor.moveToNext()) cursor else null }
                    .map { getImage(it, mediaType) }
                    .filterNotNull()
                    .toList()

            val albumList: List<Album> = totalImageList.asSequence()
                .groupBy { media: Media -> media.albumName }
                .toSortedMap { albumName1: String, albumName2: String ->
                    if (albumName2 == "Camera") {
                        1
                    } else {
                        albumName1.compareTo(albumName2, true)
                    }
                }
                .map { entry -> getAlbum(entry) }
                .toList()


            val totalAlbum = totalImageList.run {
                val albumName = context.getString(R.string.album_all)
                Album(
                    albumName,
                    getOrElse(0) { Media(albumName, Uri.EMPTY, "", 0, false) }.uri,
                    this
                )
            }

            mutableListOf<Album>(totalAlbum).apply {
                addAll(albumList)
            }
        } ?: emptyList()

        cursor?.close()

        return albumList

    }

    private fun getAlbum(entry: Map.Entry<String, List<Media>>) =
        Album(entry.key, entry.value[0].uri, entry.value)

    private fun getImage(cursor: Cursor, mediaType: MediaType): Media? =
        try {
            cursor.run {
                var folderName = getString(getColumnIndexOrThrow(albumName))
                val mediaUri = getMediaUri(mediaType).first
                val mediaPath = getMediaUri(mediaType).second
                val datedAddedSecond = getLong(getColumnIndexOrThrow(INDEX_DATE_ADDED))
                if (folderName == null || folderName.isBlank() || folderName.isEmpty()) {
                    folderName = "0"
                }
                Media(folderName, mediaUri, mediaPath, datedAddedSecond, false)
            }
        } catch (exception: Exception) {
            exception.printStackTrace()
            null
        }

    private fun Cursor.getMediaUri(mediaType: MediaType): Pair<Uri, String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val id = getLong(getColumnIndexOrThrow(INDEX_MEDIA_ID))
            val mediaPath = getString(getColumnIndexOrThrow(INDEX_MEDIA_URI))

            val contentUri = when (mediaType) {
                MediaType.IMAGE -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                MediaType.VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            }
            Pair(ContentUris.withAppendedId(contentUri, id), mediaPath)
        } else {
            val mediaPath = getString(getColumnIndexOrThrow(INDEX_MEDIA_URI))
            Pair(Uri.fromFile(File(mediaPath)), mediaPath)
        }

}