package com.natara.photo.collage.maker.collage.customviews.layers.slant;

import com.natara.photo.collage.maker.collage.customviews.grid.NataraLayout;
import com.natara.photo.collage.maker.collage.customviews.grid.NataraLine;

public class SevenSlantLayout extends NumberSlantLayout {
    public int getThemeCount() {
        return 2;
    }

    public SevenSlantLayout(SlantCollageLayout slantPuzzleLayout, boolean z) {
        super(slantPuzzleLayout, z);
    }

    public SevenSlantLayout(int i) {
        super(i);
    }

    public void layout() {
        if (this.theme == 0) {
            addLine(0, NataraLine.Direction.VERTICAL, 0.33333334f);
            addLine(1, NataraLine.Direction.VERTICAL, 0.5f);
            addLine(0, NataraLine.Direction.HORIZONTAL, 0.5f, 0.5f);
            addLine(1, NataraLine.Direction.HORIZONTAL, 0.33f, 0.33f);
            addLine(3, NataraLine.Direction.HORIZONTAL, 0.5f, 0.5f);
            addLine(2, NataraLine.Direction.HORIZONTAL, 0.5f, 0.5f);
        }
    }

    public NataraLayout clone(NataraLayout quShotLayout) {
        return new SevenSlantLayout((SlantCollageLayout) quShotLayout, true);
    }
}
