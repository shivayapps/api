package com.natara.photo.collage.maker.bgremover.adapter

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.natara.photo.collage.maker.extentions.hide
import com.natara.photo.collage.maker.extentions.show
import com.natara.photo.collage.maker.databinding.SingleColorBinding
import com.natara.photo.collage.maker.diffutils.DiffUtilsCallBacks

class GradientAdapter(var gradientClickListener: GradientClickListener) :
    ListAdapter<String, GradientAdapter.ItemViewHolder>(DiffUtilsCallBacks.DiffCallbackGradient()) {

    var selectedItemPos = ""
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    var lastItemSelectedPos = ""

    interface GradientClickListener {
        fun gradientItemClick(position: Int)
    }

    inner class ItemViewHolder(private val binding: SingleColorBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(gradient: String, position: Int) =
            with(itemView) {

                with(binding) {

                    try {
                        val split: Array<String> = gradient.split(",".toRegex()).toTypedArray()
                        val color1 = split[0]
                        val color2 = split[1]

                        val gradientDrawable = GradientDrawable(
                            GradientDrawable.Orientation.TOP_BOTTOM,
                            intArrayOf(
                                Color.parseColor(color1),
                                Color.parseColor(color2)
                            )
                        )
                        gradientDrawable.cornerRadius = 22f

                        //Set Gradient
                        colorHoldingImageView.setImageDrawable(gradientDrawable)
                    } catch (ex: Exception) {
                        ex.printStackTrace()
                    }

                }

                setOnClickListener {
                    selectedItemPos = gradient
                    if (lastItemSelectedPos == "")
                        lastItemSelectedPos = selectedItemPos
                    else {
                        notifyItemChanged(currentList.indexOf(lastItemSelectedPos))
                        lastItemSelectedPos = selectedItemPos
                    }
                    notifyItemChanged(currentList.indexOf(selectedItemPos))

                    gradientClickListener.gradientItemClick(position)
                }
            }

        fun selectedBg() = binding.colorSelectionIndicator.show()

        fun defaultBg() = binding.colorSelectionIndicator.hide()
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            SingleColorBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {

        holder.setIsRecyclable(false)

        if (getItem(position) == selectedItemPos)
            holder.selectedBg()
        else
            holder.defaultBg()

        holder.bind(getItem(position), position)
    }

}

