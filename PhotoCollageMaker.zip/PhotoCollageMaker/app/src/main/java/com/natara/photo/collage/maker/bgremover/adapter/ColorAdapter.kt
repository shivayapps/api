package com.natara.photo.collage.maker.bgremover.adapter

import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.natara.photo.collage.maker.extentions.hide
import com.natara.photo.collage.maker.extentions.show
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.databinding.SingleColorBinding
import com.natara.photo.collage.maker.databinding.SingleImgItemBinding
import com.natara.photo.collage.maker.diffutils.DiffUtilsCallBacks

class ColorAdapter(var colorClickListener: ColorClickListener) :
    ListAdapter<Int, RecyclerView.ViewHolder>(DiffUtilsCallBacks.DiffCallbackColor()) {

    init {
//        setHasStableIds(true)
    }

    private val VIEW_TYPE_IMAGE = 1
    private val VIEW_TYPE_COLOR = 2

    var lastItemSelectedPos = 0
    var selectedItemPos = Color.parseColor("#000000")
        set(value) {
            field = value
            lastItemSelectedPos = if (lastItemSelectedPos == 0)
                selectedItemPos
            else {
                notifyItemChanged(currentList.indexOf(lastItemSelectedPos))
                selectedItemPos
            }
            notifyItemChanged(currentList.indexOf(selectedItemPos))
        }


    interface ColorClickListener {
        fun colorItemClick(position: Int)
    }

    inner class ItemViewHolder(private val binding: SingleColorBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(color: Int, position: Int) =
            with(itemView) {

                with(binding) {
                    with(colorHoldingImageView) {
                        this.setBackgroundColor(color)
                        if (Color.red(color) == 255 && Color.blue(color) == 255 && Color.green(
                                color
                            ) == 255
                        ) {
                            colorSelectionIndicator.setColorFilter(
                                ContextCompat.getColor(binding.root.context, R.color.black)
                            )
//                                whiteColorIndicator.show()
                        } else {
//                                whiteColorIndicator.hide()
                        }
                    }
                }

                setOnClickListener {
                    if (position > 1) {
                        selectedItemPos = color
                        if (lastItemSelectedPos == 0)
                            lastItemSelectedPos = selectedItemPos
                        else {
                            notifyItemChanged(lastItemSelectedPos)
                            lastItemSelectedPos = selectedItemPos
                        }
                        notifyItemChanged(selectedItemPos)
                    } else {
                        Log.d(
                            "TAG",
                            "bind: selectedItemPos \n red  ${Color.red(color)}\n blue  ${
                                Color.blue(color)
                            }\n green  ${Color.green(color)}"
                        )
                    }

                    colorClickListener.colorItemClick(position)
                }
            }

        fun selectedBg() = binding.colorSelectionIndicator.show()

        fun defaultBg() = binding.colorSelectionIndicator.hide()
    }

    inner class ImageViewHolder(private val binding: SingleImgItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bindImage() {
            with(binding) {
                with(colorHoldingImageView) {
                    if (adapterPosition == 1) {
                        setImageResource(R.drawable.ic_color_palet)
                    } else if (adapterPosition == 0) {
                        setImageResource(R.drawable.ic_color_dropper)
                    }
                }

                root.setOnClickListener {
                    colorClickListener.colorItemClick(adapterPosition)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_IMAGE -> {
                ImageViewHolder(
                    SingleImgItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                )
            }

            VIEW_TYPE_COLOR -> {
                ItemViewHolder(
                    SingleColorBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                )
            }

            else -> throw IllegalArgumentException("Invalid view type")
        }

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        when (holder) {
            is ImageViewHolder -> holder.bindImage()
            is ItemViewHolder -> {

                if (getItem(position) == selectedItemPos)
                    holder.selectedBg()
                else
                    holder.defaultBg()

                holder.bind(getItem(position), position)
            }
        }



    }

    override fun getItemViewType(position: Int): Int {
        return if (position == 0 || position == 1) {
            VIEW_TYPE_IMAGE
        } else {
            VIEW_TYPE_COLOR
        }
    }
}
