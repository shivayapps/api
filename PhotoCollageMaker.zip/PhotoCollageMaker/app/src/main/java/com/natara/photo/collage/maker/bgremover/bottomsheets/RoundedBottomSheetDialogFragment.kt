package com.natara.photo.collage.maker.bgremover.bottomsheets
import android.app.Activity
import android.app.Dialog
import android.os.Bundle
import android.util.DisplayMetrics
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.natara.photo.collage.maker.R


abstract class RoundedBottomSheetDialogFragment : BottomSheetDialogFragment() {
    override fun getTheme(): Int = R.style.BaseBottomSheetDialog

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog = BottomSheetDialog(requireContext(), theme)

    override fun onStart() {
        (dialog as BottomSheetDialog).behavior.setPeekHeight(getBottomSheetDialogDefaultHeight(),true)
        super.onStart()
    }

    private fun getBottomSheetDialogDefaultHeight(): Int {
        val displayMetrics = DisplayMetrics()
        (context as Activity?)?.windowManager?.defaultDisplay?.getMetrics(displayMetrics)
        return displayMetrics.heightPixels * 24 / 100
    }
}