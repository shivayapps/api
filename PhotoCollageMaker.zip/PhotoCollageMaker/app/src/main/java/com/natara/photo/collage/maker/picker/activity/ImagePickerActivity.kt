package com.natara.photo.collage.maker.picker.activity

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.PorterDuff
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.DrawableRes
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.databinding.ActivityImagePickerBinding
import com.natara.photo.collage.maker.picker.adapter.AlbumAdapter
import com.natara.photo.collage.maker.picker.adapter.ImageAdapter
import com.natara.photo.collage.maker.picker.builder.type.MediaType
import com.natara.photo.collage.maker.picker.helper.Constant
import com.natara.photo.collage.maker.picker.model.Album
import com.natara.photo.collage.maker.picker.model.Config
import com.natara.photo.collage.maker.picker.util.GalleryUtil
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import java.util.*


class ImagePickerActivity : AppCompatActivity() {

    lateinit var binding: ActivityImagePickerBinding

    //Album Activity
    private lateinit var disposable: Disposable
    private lateinit var albumAdapter: AlbumAdapter
    private lateinit var mRVAlbum: RecyclerView
    private lateinit var mPBAlbum: ProgressBar
    private lateinit var mAlbumList: List<Album>
    private var config: Config? = null

    //Image Activity
    private lateinit var mImageAdapter: ImageAdapter
    private lateinit var mRVImage: RecyclerView
    private lateinit var mImageList: List<Album>
    private lateinit var path: Uri

    //Ucrop Fragment
//    private var uCropFragment: UCropFragment? = null
    private var position = 0
    private var mToolbarColor = 0
    private var mStatusBarColor = 0
    private var mToolbarWidgetColor = 0
    private var mToolbarTitle: String? = null
    private var isCropViewOpen = false

    @DrawableRes
    private var mToolbarCancelDrawable = 0

    @DrawableRes
    private var mToolbarCropDrawable = 0
    private var croptoolbar: Toolbar? = null
    private var mShowLoader = false


    companion object {
        private const val EXTRA_SELECTED_URI = "EXTRA_SELECTED_URI"
        private const val TAG = "ImagePickerActivity"
        private const val SAMPLE_CROPPED_IMAGE_NAME = "SampleCropImage.jpg"
    }

    private fun checkPermission(): Boolean =
        ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.READ_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED

    override fun onResume() {
        super.onResume()
    }

    @SuppressLint("MissingSuperCall")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            if (!checkPermission()) {
                finish()
            }
        }
        binding = ActivityImagePickerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initView()
        Constant.lastSelectedPosition = -1
        config = intent.getParcelableExtra(Config.EXTRA_CONFIG)
        if (config!!.isKeepScreenOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        val window = window
//        window.statusBarColor = config!!.statusBarColor
        mPBAlbum.indeterminateTintList = ColorStateList.valueOf(config!!.progressBarColor)
        binding.toolbar.setBackgroundColor(config!!.toolbarColor)
//        binding.toolbarTitle.setTextColor(config!!.toolbarTextColor)
        binding.mToolbarTitle.text = config!!.folderTitle
//        binding.imgBack.setColorFilter(config!!.toolbarIconColor)
        binding.mainConstraint.setBackgroundColor(config!!.backgroundColor)



        binding.toolbarImage.setBackgroundColor(config!!.toolbarColor)
//        binding.imgBackImage.setColorFilter(config!!.toolbarIconColor)
//        binding.imgDoneImage.setColorFilter(config!!.toolbarIconColor)
//        binding.txtFolderName.setTextColor(config!!.toolbarTextColor)


        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            if (checkPermission()) {
                loadMedia(true)
            }
        }else{
            loadMedia(true)
        }

        mAlbumList = arrayListOf()

        binding.imgBack.setOnClickListener {
            onBackPressed()
        }

        binding.imgBackImage.setOnClickListener {
            onBackPressed()
        }

        binding.imgDoneImage.setOnClickListener {
            val uri = path
            finishPickImages(uri)
        }

    }


    private fun setupViews(extras: Bundle?) {
        mStatusBarColor = config!!.statusBarColor
        mToolbarColor = config!!.toolbarColor
        mToolbarCancelDrawable = R.drawable.ic_round_close
        mToolbarCropDrawable = R.drawable.ic_select
        mToolbarWidgetColor = ContextCompat.getColor(this@ImagePickerActivity, R.color.black)
        mToolbarTitle = "Crop Image"
        setupAppBar()
    }

    private fun setupAppBar() {
        croptoolbar = findViewById(R.id.croptoolbarAlbum)

        // Set Toolbar Color
        croptoolbar!!.setBackgroundColor(config!!.toolbarColor)
        croptoolbar!!.setTitleTextColor(config!!.toolbarTextColor)
        croptoolbar!!.visibility = View.VISIBLE

        binding.toolbarImage.visibility = View.GONE
        mRVImage.visibility = View.GONE


        val cropToolBarTitle = croptoolbar!!.findViewById<TextView>(R.id.toolbar_title)!!
        cropToolBarTitle.setTextColor(config!!.toolbarTextColor)
        cropToolBarTitle.text = mToolbarTitle

        // Color Toolbar Icons
        val stateButtonDrawable = ContextCompat.getDrawable(baseContext, mToolbarCancelDrawable)
        if (stateButtonDrawable != null) {
            stateButtonDrawable.mutate()
            stateButtonDrawable.setColorFilter(config!!.toolbarIconColor, PorterDuff.Mode.SRC_ATOP)
            croptoolbar!!.navigationIcon = stateButtonDrawable
        }
        setSupportActionBar(croptoolbar)
        val actionBar = supportActionBar
        actionBar?.setDisplayShowTitleEnabled(false)
    }


    private fun initView() {
        mRVAlbum = findViewById(R.id.rv_album)
        mRVImage = findViewById(R.id.rv_image)
        mPBAlbum = findViewById(R.id.pb_album)
    }

    private fun loadMedia(isRefresh: Boolean = false) {

        val mediaType: MediaType = MediaType.IMAGE
        disposable = GalleryUtil.getMedia(this, mediaType)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { albumList: List<Album> ->
                mAlbumList = albumList
                mRVAlbum.addItemDecoration(
                    DividerItemDecoration(
                        mRVAlbum.context,
                        DividerItemDecoration.VERTICAL
                    )
                )
                val layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
//                layoutManager = GridLayoutManager(this, 2)
                albumAdapter = AlbumAdapter(
                    this@ImagePickerActivity,
                    mAlbumList,
                    object : AlbumAdapter.OnAlbumSelected {
                        override fun onAlbumClicked(
                            position: Int,
                            folderName: String
                        ) {
                            setImageAdapter(position, folderName)
                            binding.toolbarImage.visibility = View.VISIBLE
                            binding.txtFolderName.text = folderName
                        }

                    })
                mPBAlbum.visibility = View.GONE
                mRVAlbum.visibility = View.VISIBLE
                mRVAlbum.layoutManager = layoutManager
                mRVAlbum.adapter = albumAdapter

            }
    }

    override fun onBackPressed() {
        when {
            mRVImage.visibility == View.VISIBLE -> {
                showImage(false)
                binding.imgDoneImage.visibility = View.GONE
                Constant.lastSelectedPosition = -1
            }
            else -> {
                super.onBackPressed()
            }
        }
    }

    private fun setImageAdapter(position: Int, folderName: String) {
        binding.toolbarImage.visibility = View.VISIBLE
        binding.txtFolderName.text = folderName

        showImage(true)
        var layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        layoutManager = GridLayoutManager(this, 4)
        mImageAdapter = ImageAdapter(
            this@ImagePickerActivity,
            mAlbumList[position].mediaUris,
            object : ImageAdapter.OnImageClick {
                override fun selectMedia(uri: Uri) {
                    if (uri.toString().isNotEmpty()) {
                        binding.imgDoneImage.visibility = View.VISIBLE
                        path = uri
                    } else {
                        binding.imgDoneImage.visibility = View.INVISIBLE
                        Toast.makeText(
                            this@ImagePickerActivity,
                            "Please Select Image",
                            Toast.LENGTH_SHORT
                        ).show()
                    }


                }

            })
        mRVImage.layoutManager = layoutManager
        mRVImage.adapter = mImageAdapter
    }

    private fun showImage(b: Boolean) {
        if (b) {
            mRVAlbum.visibility = View.GONE
            binding.toolbar.visibility = View.GONE
            mRVImage.visibility = View.VISIBLE
            binding.toolbarImage.visibility = View.VISIBLE
        } else {
            mRVAlbum.visibility = View.VISIBLE
            binding.toolbar.visibility = View.VISIBLE
            mRVImage.visibility = View.INVISIBLE
            binding.toolbarImage.visibility = View.INVISIBLE
        }
    }

    private fun finishPickImages(uri: Uri) {
        //Ucrop ON/OFF
//        isCropViewOpen = true
//        startCrop(uri)

        val data = Intent()
        data.putExtra(EXTRA_SELECTED_URI, uri.toString())
        setResult(config!!.requestCode, data)
        finish()
    }
}