package com.natara.photo.collage.maker

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.multidex.MultiDexApplication
import com.natara.photo.collage.maker.utils.PreferenceManager

class CollageMaker : MultiDexApplication(), Application.ActivityLifecycleCallbacks,
    DefaultLifecycleObserver {

    companion object {
        var prefManager: PreferenceManager? = null
    }

    override fun onCreate() {
        super<MultiDexApplication>.onCreate()
        prefManager = PreferenceManager(applicationContext)
        registerActivityLifecycleCallbacks(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
    }


    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}

    override fun onActivityStarted(activity: Activity) {}

    override fun onActivityResumed(activity: Activity) {}

    override fun onActivityPaused(activity: Activity) {}

    override fun onActivityStopped(activity: Activity) {}

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

    override fun onActivityDestroyed(activity: Activity) {}

}