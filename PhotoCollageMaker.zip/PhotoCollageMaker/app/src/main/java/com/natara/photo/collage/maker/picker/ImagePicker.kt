package com.natara.photo.collage.maker.picker

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.activity.result.ActivityResultLauncher
import androidx.fragment.app.Fragment
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.picker.activity.ImagePickerActivity
import com.natara.photo.collage.maker.picker.model.Config
import com.natara.photo.collage.maker.picker.model.SavePath


open class ImagePicker {
    private var config: Config? = null


    public class ActivityBuilder(private val activity: Activity) :
        Builder(
            activity
        ) {
        override fun start() {
            val intent = intent
            config.result.launch(intent)
        }

        override val intent: Intent
            get() {
                val intent: Intent = Intent(activity, ImagePickerActivity::class.java)
                intent.putExtra(Config.EXTRA_CONFIG, config)
                return intent
            }

    }

    abstract class Builder : BaseBuilder {
        constructor(activity: Activity?) : super(activity) {}
        constructor(fragment: Fragment) : super(fragment.context) {}

        fun setToolbarColor(toolbarColor: String?): Builder {
            config.setToolbarColor(toolbarColor)
            return this
        }

        fun setStatusBarColor(statusBarColor: String?): Builder {
            config.setStatusBarColor(statusBarColor)
            return this
        }

        fun setToolbarTextColor(toolbarTextColor: String?): Builder {
            config.setToolbarTextColor(toolbarTextColor)
            return this
        }

        fun setToolbarIconColor(toolbarIconColor: String?): Builder {
            config.setToolbarIconColor(toolbarIconColor)
            return this
        }

        fun setProgressBarColor(progressBarColor: String?): Builder {
            config.setProgressBarColor(progressBarColor)
            return this
        }

        fun setBackgroundColor(backgroundColor: String?): Builder {
            config.setBackgroundColor(backgroundColor)
            return this
        }

        fun setMultipleMode(isMultipleMode: Boolean): Builder {
            config.isMultipleMode = true
            return this
        }

        fun setImageCount(count: Int): Builder {
            config.imageCount = count
            return this
        }

        fun setFolderMode(isFolderMode: Boolean): Builder {
            config.isFolderMode = true
            return this
        }

        fun setMaxSize(maxSize: Int): Builder {
            config.maxSize = maxSize
            return this
        }

        fun setDoneTitle(doneTitle: String?): Builder {
            config.doneTitle = doneTitle
            return this
        }

        fun setFolderTitle(folderTitle: String?): Builder {
            config.folderTitle = folderTitle
            return this
        }

        fun setImageTitle(imageTitle: String?): Builder {
            config.imageTitle = imageTitle
            return this
        }

        fun setLimitMessage(message: String?): Builder {
            config.limitMessage = message
            return this
        }

        fun setSavePath(path: String?): Builder {
            config.savePath = SavePath(path, false)
            return this
        }

        fun setAlwaysShowDoneButton(isAlwaysShowDoneButton: Boolean): Builder {
            config.isAlwaysShowDoneButton = isAlwaysShowDoneButton
            return this
        }

        fun setKeepScreenOn(keepScreenOn: Boolean): Builder {
            config.isKeepScreenOn = keepScreenOn
            return this
        }

//        fun setSelectedImages(selectedImages: ArrayList<Image?>?): Builder {
//            config.setSelectedImages(selectedImages)
//            return this
//        }

        fun setResult(startForResult: ActivityResultLauncher<Intent>): Builder {
            config.result = startForResult
            return this
        }

        fun setRequestCode(requestCode: Int): Builder {
            config.requestCode = requestCode
            return this
        }

        abstract fun start()
        abstract val intent: Intent?
    }

    abstract class BaseBuilder(context: Context?) {
        var config: Config = Config()

        init {
            val resources = context!!.resources
            config.isMultipleMode = true
            config.isFolderMode = true
            config.maxSize = Config.MAX_SIZE
            config.doneTitle = resources.getString(R.string.action_done)
            config.folderTitle = resources.getString(R.string.title_folder)
            config.imageTitle = resources.getString(R.string.title_image)
            config.limitMessage = resources.getString(R.string.msg_limit_images)
            config.savePath = SavePath.DEFAULT
            config.isAlwaysShowDoneButton = false
            config.isKeepScreenOn = false
//            config.setSelectedImages(ArrayList<Image>())
        }
    }
}