package com.natara.photo.collage.maker.picker.model

import android.net.Uri

data class Media(
    val albumName: String,
    val uri: Uri,
    val dateAddedSecond: Long,
    var isCorrupted : Boolean
)