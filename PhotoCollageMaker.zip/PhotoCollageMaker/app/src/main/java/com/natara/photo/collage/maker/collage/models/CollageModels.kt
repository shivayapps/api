package com.natara.photo.collage.maker.collage.models

import android.graphics.drawable.Drawable
import com.natara.photo.collage.maker.collage.module.Module
import com.steelkiwi.cropiwa.AspectRatio

sealed class CollageModels {
    data class ToolModel(var mToolName: String, var mToolIcon: Int, var mToolType: Module)
    data class SquareView(
        var drawable: Drawable? = null,
        var drawableId: Int,
        var isBitmap: Boolean = false,
        var isColor: Boolean = false,
        var text: String,
    )

    data class RatioModel(
        var i: Int,
        var i2: Int,
        val unselectItem: Int,
        val selectedIem: Int,
        var name: String,
    ) : AspectRatio(i, i2)


    data class FiltersCode(var code: String, var name: String)

}