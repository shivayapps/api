package com.natara.photo.collage.maker.ui.drip

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isVisible
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import codes.side.andcolorpicker.converter.ColorConverterHub
import codes.side.andcolorpicker.group.PickerGroup
import codes.side.andcolorpicker.group.registerPickers
import codes.side.andcolorpicker.hsl.HSLColorPickerSeekBar
import codes.side.andcolorpicker.model.IntegerHSLColor
import codes.side.andcolorpicker.view.picker.ColorSeekBar
import codes.side.andcolorpicker.view.picker.OnIntegerHSLColorPickListener
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.ktx.Firebase
import com.lyrebirdstudio.croppylib.Croppy
import com.lyrebirdstudio.croppylib.main.CropRequest
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.bgremover.adapter.ColorAdapter
import com.natara.photo.collage.maker.bgremover.utils.BitmapUtil
import com.natara.photo.collage.maker.bgremover.viewmodel.EditorViewModel
import com.natara.photo.collage.maker.collage.activities.ViewActivity
import com.natara.photo.collage.maker.databinding.ActivityDripEditorBinding
import com.natara.photo.collage.maker.databinding.CustomColorBottomSheetBinding
import com.natara.photo.collage.maker.databinding.CustomColorDropBottomSheetBinding
import com.natara.photo.collage.maker.extentions.click
import com.natara.photo.collage.maker.extentions.customDialog
import com.natara.photo.collage.maker.extentions.getStringByLocal
import com.natara.photo.collage.maker.extentions.hide
import com.natara.photo.collage.maker.extentions.loadBitmapFromView
import com.natara.photo.collage.maker.extentions.requestMultiplePermissions
import com.natara.photo.collage.maker.extentions.show
import com.natara.photo.collage.maker.extentions.startTouch
import com.natara.photo.collage.maker.picker.ImagePicker
import com.natara.photo.collage.maker.ui.BaseActivity
import com.natara.photo.collage.maker.ui.drip.adapter.DripAdapter
import com.natara.photo.collage.maker.utils.DripUtils
import com.skydoves.colorpickerview.ColorPickerView
import com.skydoves.colorpickerview.listeners.ColorEnvelopeListener
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

class DripEditorActivity : BaseActivity(), DripAdapter.PatternClickListener,
    ColorAdapter.ColorClickListener {

    private lateinit var binding: ActivityDripEditorBinding
    private lateinit var firebaseAnalytics: FirebaseAnalytics
    var mCropBitmap: Bitmap? = null
    var mOriginalBitmap: Bitmap? = null
    var mColorPickerView: ColorPickerView? = null

    private var selectedBitmap: Bitmap? = null
    private var mainBitmap: Bitmap? = null
    private var bitmapColor: Bitmap? = null

    private val mEditorViewModel by lazy {
        EditorViewModel()
    }

    private val colorAdapter by lazy {
        ColorAdapter(this)
    }

    private val dripStyleAdapter by lazy {
        DripAdapter(this)
    }

    private val dripBackgroundAdapter by lazy {
        DripAdapter(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDripEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        firebaseAnalytics = Firebase.analytics

        initData()
        initView()
        initBitmapData()
        initLister()
    }

    private fun initData() {

        mEditorViewModel.dripStyle.observe(this, Observer {
            dripStyleAdapter.submitList(it)
            dripStyleAdapter.selectedItemPos = dripStyleAdapter.currentList[0]
        })

        mEditorViewModel.dripBackground.observe(this, Observer {
            dripBackgroundAdapter.submitList(it)
        })

        mEditorViewModel.colors.observe(this, Observer {
            colorAdapter.submitList(it)
        })

        mEditorViewModel.loadDripStyle()
        mEditorViewModel.loadColorData(this)
    }

    private fun initView() {
        binding.include.mTVTitle.text = getStringByLocal(R.string.drip_effect)
        binding.recyclerViewStyle.adapter = dripStyleAdapter
        binding.recyclerViewBackground.adapter = dripBackgroundAdapter
        binding.recyclerViewColor.adapter = colorAdapter
    }

    private fun initLister() {
        binding.rippleStyle.setOnClickListener {
            hideRV(binding.recyclerViewStyle)
        }
        binding.rippleBackground.setOnClickListener {
            hideRV(binding.recyclerViewBackground)
        }
        binding.rippleColor.setOnClickListener {
            hideRV(binding.recyclerViewColor)
        }

        binding.include.mIVBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        binding.include.mTVSave.setOnClickListener {
            requestMultiplePermissions {

                customDialog(
                    getStringByLocal(R.string.save_design),
                    getStringByLocal(R.string.save_msg)
                ) {
                    saveImg()
                }

            }
        }
    }

    private fun hideRV(view: View) {
        binding.recyclerViewStyle.hide()
        binding.recyclerViewBackground.hide()
        binding.recyclerViewColor.hide()

        view.show()
    }

    private fun initBitmapData() {
        lifecycleScope.launchWhenCreated {

            val bitmap = intent?.getStringExtra("path")?.let {
                BitmapFactory.decodeFile(it)
            }

            mOriginalBitmap = bitmap

            val file = intent?.getStringExtra("path")?.let {
                File(it)
            }

            val degree = BitmapUtil().getBitmapDegree(file?.absolutePath)

            val newBitmap = mOriginalBitmap?.let {
                BitmapUtil().rotateBitmapByDegree(it, degree)
            }

            binding.googleProgress.indeterminateDrawable = showGoogleProgressBar()

            createAnalyzer()
            newBitmap?.let { newbmp ->
                analyse(newbmp, cropBitmap = {
                    mCropBitmap = it
                    setDripEffect(it)
                })
            }

        }
    }

    private fun setDripEffect(it: Bitmap) {
        selectedBitmap = it

        mainBitmap = DripUtils.getBitmapFromAsset(
            this@DripEditorActivity,
            "drip/style/white.webp"
        )?.let { it1 ->
            Bitmap.createScaledBitmap(
                it1, selectedBitmap?.width ?: 1024, selectedBitmap?.height ?: 1024, true
            )
        }

        bitmapColor = mainBitmap

        Glide.with(this).load(R.drawable.drip_1).into(binding.dripViewStyle)

        Glide.with(this).load(it).diskCacheStrategy(
            DiskCacheStrategy.ALL
        ).into(binding.dripViewImage)

        binding.googleProgress.visibility = View.GONE

        binding.dripViewImage.startTouch()
        binding.dripViewStyle.startTouch()
        binding.dripViewBackground.startTouch()

    }

    override fun patternItemClick(position: Int) {
        if (binding.recyclerViewStyle.isVisible) {
            Glide.with(this).load(dripStyleAdapter.currentList[position])
                .into(binding.dripViewStyle)
        } else {
            if (position == 0) {
                requestMultiplePermissions {
                    ImagePicker.ActivityBuilder(this)
                        .setRequestCode(104)
                        .setResult(startEditActivity).start()
                }
            } else {
                Glide.with(this).load(dripBackgroundAdapter.currentList[position])
                    .into(binding.dripViewBackground)
            }

        }
    }

    override fun colorItemClick(position: Int) {
        when (position) {
            0 -> {
                var firstClick = false

                val dialog =
                    BottomSheetDialog(this, R.style.CustomDialogTheme)
                dialog.window?.setWindowAnimations(R.style.DialogAnimation)
                val view = CustomColorDropBottomSheetBinding.inflate(layoutInflater)

                val bitmap = loadBitmapFromView(
                    binding.frameLayoutBackground,
                    binding.frameLayoutBackground.width,
                    binding.frameLayoutBackground.height
                )

                view.mCPView.setPaletteDrawable(
                    BitmapDrawable(
                        resources,
                        bitmap
                    )
                )

                view.mTVApply.setOnClickListener {
                    dialog.dismiss()
                }

                view.ibClose.click {
                    dialog.dismiss()
                }
                view.mCPView.setColorListener(ColorEnvelopeListener { envelope, fromUser ->
                    if (firstClick) {
                        binding.dripViewColor.setBackgroundColor(envelope.color)
                        binding.frameLayoutBackground.setBackgroundColor(envelope.color)
                        binding.dripViewStyle.setColorFilter(envelope.color)
                    }
                    firstClick = true
                    view.mIVColorCode.setColorFilter(envelope.color)
                    view.mTVColorCode.setText("#" + envelope.hexCode)
                })
                mColorPickerView = view.mCPView
                view.constraintLayout22.setOnClickListener {
                    requestMultiplePermissions {
                        ImagePicker.ActivityBuilder(this)
                            .setRequestCode(103)
                            .setResult(startEditActivity).start()
                    }
                }

                dialog.setCancelable(false)
                dialog.setContentView(view.root)
                dialog.show()
            }

            1 -> {
                var firstClick = false
                val dialog =
                    BottomSheetDialog(this, R.style.CustomDialogTheme)
                dialog.window?.setWindowAnimations(R.style.DialogAnimation)
                val view = CustomColorBottomSheetBinding.inflate(layoutInflater)
                view.alphaColorPickerSeekBar.hide()

                // Configure picker color model programmatically
                view.hueSeekBar.mode =
                    HSLColorPickerSeekBar.Mode.MODE_HUE // Mode.MODE_SATURATION, Mode.MODE_LIGHTNESS

                // Configure coloring mode programmatically
                view.hueSeekBar.coloringMode =
                    HSLColorPickerSeekBar.ColoringMode.PURE_COLOR // ColoringMode.OUTPUT_COLOR

                // Group pickers with PickerGroup to automatically synchronize color across them
                val pickerGroup = PickerGroup<IntegerHSLColor>().also {
                    it.registerPickers(
                        view.hueSeekBar,
                        view.lightnessColorPickerSeekBar,
                        view.alphaColorPickerSeekBar
                    )
                }


                // Listen individual pickers or groups for changes
                pickerGroup.addListener(object : OnIntegerHSLColorPickListener() {
                    override fun onColorChanged(
                        picker: ColorSeekBar<IntegerHSLColor>,
                        color: IntegerHSLColor,
                        value: Int
                    ) {
                        val newColor =
                            ColorConverterHub.getConverterByKey(color.colorKey)
                                .convertToColorInt(color)
                        if (firstClick) {
                            binding.dripViewColor.setBackgroundColor(newColor)
                            binding.frameLayoutBackground.setBackgroundColor(newColor)
                            binding.dripViewStyle.setColorFilter(newColor)
                        }
                        firstClick = true

                    }
                })

                view.hueSeekBar.progress = 50
                view.ibClose.click {
                    dialog.dismiss()
                }
                dialog.setCancelable(true)
                dialog.setContentView(view.root)
                dialog.show()
            }

            else -> {
                binding.dripViewColor.setBackgroundColor(colorAdapter.currentList[position])
                binding.frameLayoutBackground.setBackgroundColor(colorAdapter.currentList[position])
                binding.dripViewStyle.setColorFilter(colorAdapter.currentList[position])
            }
        }
    }

    private val startEditActivity =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->

            when (result.resultCode) {
                103 -> {
                    val data = result.data

                    val cropRequest = CropRequest.Auto(
                        sourceUri = Uri.parse(data?.extras?.getString("EXTRA_SELECTED_URI"))
                    )
                    Croppy.start(this, cropRequest, startCropActivity)
                }


                104 -> {
                    val data = result.data

                    val cropRequest = CropRequest.Auto(
                        sourceUri = Uri.parse(data?.extras?.getString("EXTRA_SELECTED_URI"))
                    )
                    Croppy.start(this, cropRequest, startBgCropActivity)

                }
            }
        }

    private val startCropActivity =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            val bitmap = BitmapFactory.decodeFile(File(result.data?.data?.path).absolutePath)
            runOnUiThread {
                mColorPickerView?.setPaletteDrawable(null)
                mColorPickerView?.setPaletteDrawable(
                    BitmapDrawable(
                        resources,
                        bitmap
                    )
                )
                mColorPickerView?.invalidate()
            }
        }

    private val startBgCropActivity =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            val bitmap = BitmapFactory.decodeFile(File(result.data?.data?.path).absolutePath)
            runOnUiThread {
                binding.dripViewBackground.setImageBitmap(bitmap)
            }
        }

    private fun saveImg() {
        val bundle = Bundle()
        bundle.putString("collage_save", "drip_effect")
        firebaseAnalytics.logEvent("snap_collage", bundle)

        val bitmap = loadBitmapFromView(
            binding.frameLayoutBackground,
            binding.frameLayoutBackground.width,
            binding.frameLayoutBackground.height
        )

        val f: File?
        val file: File = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                getString(R.string.app_name)
            )
        } else {
            File(
                getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                getString(R.string.app_name)
            )
        }

        if (!file.exists()) {
            file.mkdirs()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            var path = saveImageToStorage(
                bitmap,
                "${System.currentTimeMillis()}" + ".png",
                "image/png",
                Environment.DIRECTORY_PICTURES + "/" + getString(R.string.app_name)
            )
            path =
                Environment.getExternalStorageDirectory().absolutePath + File.separator + path

            startActivity(
                Intent(
                    this@DripEditorActivity,
                    ViewActivity::class.java
                ).putExtra("imgPath", path)
            )

        } else {

            f =
                File(file.absolutePath + File.separator + "${System.currentTimeMillis()}" + ".png")

            f.let {
                val ostream = FileOutputStream(f)
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, ostream)
                ostream.close()
                //Toast.makeText(mContext, "Image Save", Toast.LENGTH_SHORT).show()
                lifecycleScope.launch {


                    val image = ContentValues()
                    image.put(MediaStore.Images.Media.TITLE, f.name)
                    image.put(MediaStore.Images.Media.DISPLAY_NAME, f.name)
                    image.put(
                        MediaStore.Images.Media.DESCRIPTION,
                        "${getString(R.string.app_name)}"
                    )
                    image.put(
                        MediaStore.Images.Media.DATE_ADDED,
                        System.currentTimeMillis()
                    )
                    image.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    image.put(MediaStore.Images.Media.ORIENTATION, 0)
                    val parent: File = f.parentFile
                    image.put(
                        MediaStore.Images.ImageColumns.BUCKET_ID, parent.toString()
                            .lowercase().hashCode()
                    )
                    image.put(
                        MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME, parent.name
                            .lowercase()
                    )
                    image.put(MediaStore.Images.Media.SIZE, f.length())
                    image.put(MediaStore.Images.Media.DATA, f.absolutePath)
                    contentResolver.insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, image
                    )
                }

                startActivity(
                    Intent(
                        this@DripEditorActivity,
                        ViewActivity::class.java
                    ).putExtra("imgPath", it.absolutePath)
                )
            }
        }

    }

    private fun saveImageToStorage(
        bitmap: Bitmap,
        filename: String = "screenshot.jpg",
        mimeType: String = "image/png",
        directory: String = Environment.DIRECTORY_PICTURES,
        mediaContentUri: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    ): String {
        val imageOutStream: OutputStream
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                put(MediaStore.Images.Media.RELATIVE_PATH, directory)
            }

            contentResolver.run {
                val uri =
                    contentResolver.insert(mediaContentUri, values)
                        ?: return ""
                imageOutStream = openOutputStream(uri) ?: return ""
            }

        } else {
            val imagePath = Environment.getExternalStoragePublicDirectory(directory).absolutePath
            val image = File(imagePath, filename)
            imageOutStream = FileOutputStream(image)
        }

        imageOutStream.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return "$directory/$filename"
    }

    val backPressedCallback =
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {

                customDialog(
                    getStringByLocal(R.string.discard_design),
                    getStringByLocal(R.string.discard_msg)
                ) {
                    finish()
                }
            }
        })
}