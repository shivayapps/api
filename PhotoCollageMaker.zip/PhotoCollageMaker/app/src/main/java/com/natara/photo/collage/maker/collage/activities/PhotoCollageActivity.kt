package com.natara.photo.collage.maker.collage.activities

import android.animation.ObjectAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Point
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.viewpager.widget.PagerAdapter
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.adapter.AspectAdapter
import com.natara.photo.collage.maker.collage.adapter.CollageBackgroundAdapter
import com.natara.photo.collage.maker.collage.adapter.CollageColorAdapter
import com.natara.photo.collage.maker.collage.adapter.CollageToolsAdapter
import com.natara.photo.collage.maker.collage.adapter.FilterAdapter
import com.natara.photo.collage.maker.collage.adapter.GridAdapter
import com.natara.photo.collage.maker.collage.adapter.StickerAdapter
import com.natara.photo.collage.maker.collage.adapter.StickersTabAdapter
import com.natara.photo.collage.maker.collage.customviews.NataraStickerIcons
import com.natara.photo.collage.maker.collage.customviews.NataraStickerView.OnStickerOperationListener
import com.natara.photo.collage.maker.collage.customviews.NataraText
import com.natara.photo.collage.maker.collage.customviews.NataraTextView
import com.natara.photo.collage.maker.collage.customviews.grid.NataraLayout
import com.natara.photo.collage.maker.collage.customviews.grid.NataraLayoutParser
import com.natara.photo.collage.maker.collage.events.AlignHorizontallyEvent
import com.natara.photo.collage.maker.collage.events.DeleteIconEvent
import com.natara.photo.collage.maker.collage.events.EditTextIconEvent
import com.natara.photo.collage.maker.collage.events.FlipHorizontallyEvent
import com.natara.photo.collage.maker.collage.events.ZoomIconEvent
import com.natara.photo.collage.maker.collage.fragments.CropFragment
import com.natara.photo.collage.maker.collage.fragments.TextFragment
import com.natara.photo.collage.maker.collage.models.CollageModels
import com.natara.photo.collage.maker.collage.module.Module
import com.natara.photo.collage.maker.collage.sticker.DrawableSticker
import com.natara.photo.collage.maker.collage.sticker.Sticker
import com.natara.photo.collage.maker.collage.utils.CollageUtils
import com.natara.photo.collage.maker.collage.utils.FilterUtils
import com.natara.photo.collage.maker.collage.utils.KeyboardHeightProvider
import com.natara.photo.collage.maker.collage.utils.SaveFileUtils
import com.natara.photo.collage.maker.collage.utils.StickerFileAsset
import com.natara.photo.collage.maker.collage.utils.SystemUtil
import com.natara.photo.collage.maker.collage.viewmodels.CollageViewModel
import com.natara.photo.collage.maker.databinding.ActivityPhotoCollageBinding
import com.natara.photo.collage.maker.databinding.LayoutListStickerBinding
import com.natara.photo.collage.maker.extentions.customDialog
import com.natara.photo.collage.maker.extentions.customStickerDialog
import com.natara.photo.collage.maker.extentions.getStringByLocal
import com.natara.photo.collage.maker.extentions.hide
import com.natara.photo.collage.maker.extentions.requestMultiplePermissions
import com.natara.photo.collage.maker.extentions.show
import com.natara.photo.collage.maker.ui.picker.activity.CollagePickerActivity
import com.natara.photo.collage.maker.ui.singlepicker.activity.SinglePickerActivity
import com.squareup.picasso.Picasso
import com.squareup.picasso.Target
import com.steelkiwi.cropiwa.AspectRatio
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.wysaid.common.SharedContext
import org.wysaid.nativePort.CGEImageHandler
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class PhotoCollageActivity : AppCompatActivity(), StickerAdapter.OnClickSplashListener {

    private lateinit var binding: ActivityPhotoCollageBinding

    private var stringList: ArrayList<String> = arrayListOf()
    var targets: ArrayList<Target> = arrayListOf()
    var moduleToolsId: Module = Module.NONE
    var mBorderRadius = 0f
    var mPadding = 0f
    var aspectRatio: AspectRatio = AspectRatio(1, 1)
    var drawableList: ArrayList<Drawable> = arrayListOf()
    private var addTextFragment: TextFragment? = null
    private var textEditor: TextFragment.TextEditor? = null
    private var keyboardHeightProvider: KeyboardHeightProvider? = null


    private lateinit var currentBackgroundState: CollageModels.SquareView

    private val collageViewModel: CollageViewModel by viewModels()

    private val aspectAdapter: AspectAdapter by lazy {
        AspectAdapter(object : AspectAdapter.OnNewSelectedListener {
            override fun onNewAspectRatioSelected(aspectRatio: AspectRatio?) {
                aspectRatio?.let {
                    this@PhotoCollageActivity.onNewAspectRatioSelected(it)
                }
            }

        })
    }

    private val filterAdapter: FilterAdapter by lazy {
        FilterAdapter(object : FilterAdapter.AdapterClickListener {
            override fun filtersCLick(position: CollageModels.FiltersCode) {
                CoroutineScope(Dispatchers.IO).launch {

                    val arrayList = arrayListOf<Bitmap>()
                    for (drawable in drawableList) {
                        getBitmapWithFilter(
                            (drawable as BitmapDrawable).bitmap, position.code
                        )?.let {
                            arrayList.add(
                                it
                            )
                        }
                    }
                    withContext(Dispatchers.Main) {
                        for (i in arrayList.indices) {
                            val bitmapDrawable = BitmapDrawable(resources, arrayList[i])
                            bitmapDrawable.setAntiAlias(true)
                            bitmapDrawable.isFilterBitmap = true
                            binding.collageView.getQueShotGrids()[i].drawable = bitmapDrawable
                        }

                        binding.collageView.invalidate()
                    }
                }
            }
        })
    }

    private val gridAdapter: GridAdapter by lazy {
        GridAdapter(object : GridAdapter.OnItemClickListener {
            override fun onItemClick(puzzleLayout: NataraLayout) {
                val parse: NataraLayout = NataraLayoutParser.parse(puzzleLayout.generateInfo())
                puzzleLayout.radian = binding.collageView.collageRadian
                puzzleLayout.padding = binding.collageView.collagePadding
                binding.collageView.updateLayout(parse)
            }

        })
    }

    private val gridItemToolsAdapter: CollageToolsAdapter by lazy {
        CollageToolsAdapter(object : CollageToolsAdapter.OnItemSelected {
            override fun onToolSelected(toolType: Module) {
                when (toolType) {
                    Module.REPLACE -> {
                        onReplacePhotoLauncher.launch(
                            Intent(
                                this@PhotoCollageActivity,
                                SinglePickerActivity::class.java
                            )
                        )
                        return
                    }

                    Module.H_FLIP -> {
                        binding.collageView.flipHorizontally()
                        return
                    }

                    Module.V_FLIP -> {
                        binding.collageView.flipVertically()
                        return
                    }

                    Module.ROTATE -> {
                        binding.collageView.rotate(90.0f)
                        return
                    }

                    Module.CROP -> {
                        CropFragment.show(
                            this@PhotoCollageActivity,
                            object : CropFragment.OnCropPhoto {
                                override fun finishCrop(bitmap: Bitmap?) {
                                    binding.collageView.replace(bitmap, "")
                                }
                            },
                            (binding.collageView.getQueShotGrid().drawable as BitmapDrawable).bitmap
                        )
                        return
                    }

                    Module.FILTER -> {

                        return
                    }

                    else -> {

                    }
                }
            }

        })
    }

    val onReplacePhotoLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {

                binding.relativeLayoutLoading.visibility = View.VISIBLE

                CoroutineScope(Dispatchers.IO).launch {
                    val data: Intent? = result.data
                    data?.getStringArrayListExtra(CollagePickerActivity.KEY_DATA_RESULT)?.let {
                        val fromFile = Uri.fromFile(File(it[0]))

                        val rotateBitmap: Bitmap = SystemUtil.rotateBitmap(
                            MediaStore.Images.Media.getBitmap(
                                contentResolver,
                                fromFile
                            ),
                            ExifInterface(
                                contentResolver.openInputStream(fromFile)!!
                            ).getAttributeInt(
                                ExifInterface.TAG_ORIENTATION, 1
                            )
                        )

                        withContext(Dispatchers.Main) {
                            binding.relativeLayoutLoading.visibility = View.GONE
                            binding.collageView.replace(rotateBitmap, "")
                        }
                    }
                }


            }
        }

    private val collageColorAdapter: CollageColorAdapter by lazy {
        CollageColorAdapter(object : CollageColorAdapter.BackgroundColorListener {
            override fun onBackgroundColorSelected(i: Int, squareView: CollageModels.SquareView) {
                if (squareView.isColor) {
                    binding.collageView.setBackgroundColor(squareView.drawableId)
                    binding.collageView.backgroundResourceMode = 0
                }
            }
        })
    }

    private val backgroundBlurAdapter =
        CollageBackgroundAdapter(object : CollageBackgroundAdapter.BackgroundGridListener {
            override fun onBackgroundSelected(i: Int, squareView: CollageModels.SquareView) {
                binding.collageView.backgroundResourceMode = 2

                CoroutineScope(Dispatchers.IO).launch {
                    val bitmap = FilterUtils.getBlurImageFromBitmap(
                        (squareView.drawable as BitmapDrawable).bitmap, 5.0f
                    )
                    withContext(Dispatchers.Main) {
                        binding.collageView.background = BitmapDrawable(
                            resources, bitmap
                        )
                    }
                }
            }

        })

    private val collageBackgroundAdapter: CollageBackgroundAdapter by lazy {
        CollageBackgroundAdapter(object : CollageBackgroundAdapter.BackgroundGridListener {

            override fun onBackgroundSelected(
                i: Int,
                squareView: CollageModels.SquareView,
            ) {
                binding.collageView.setBackgroundResource(squareView.drawableId)
                binding.collageView.backgroundResourceMode = 1
            }
        })
    }

    private val collageToolsAdapter: CollageToolsAdapter by lazy {
        CollageToolsAdapter(object : CollageToolsAdapter.OnItemSelected {
            override fun onToolSelected(toolType: Module) {
                moduleToolsId = toolType

                when (toolType) {
                    Module.LAYER -> {
                        setLayer()
                        setGuideLine()
                        binding.constrantLayoutChangeLayout.visibility = View.VISIBLE
                        binding.recyclerViewTools.visibility = View.GONE
                        binding.mCLBottomTools.visibility = View.GONE

                        queShotLayout = binding.collageView.queShotLayout
                        aspectRatio = binding.collageView.aspectRatio
                        mBorderRadius = binding.collageView.collageRadian
                        mPadding = binding.collageView.collagePadding

                        binding.recyclerViewCollage.scrollToPosition(0)
                        (binding.recyclerViewCollage.adapter as GridAdapter).selectedIndex = -1
                        binding.recyclerViewCollage.adapter?.notifyDataSetChanged()
                        binding.recyclerViewRatio.scrollToPosition(0)
                        (binding.recyclerViewRatio.adapter as AspectAdapter).lastSelectedView = -1
                        binding.recyclerViewRatio.adapter?.notifyDataSetChanged()
                        binding.collageView.setLocked(false)
                        binding.collageView.setTouchEnable(false)
                        setGoneSave()
                    }

                    Module.PADDING -> {
                        setBorder()
                        setGuideLine()
                        binding.constrantLayoutChangeLayout.visibility = View.VISIBLE
                        binding.recyclerViewTools.visibility = View.GONE
                        binding.mCLBottomTools.visibility = View.GONE
                        queShotLayout = binding.collageView.queShotLayout
                        aspectRatio = binding.collageView.aspectRatio
                        mBorderRadius = binding.collageView.collageRadian
                        mPadding = binding.collageView.collagePadding
                        binding.recyclerViewCollage.scrollToPosition(0)
                        (binding.recyclerViewCollage.adapter as GridAdapter).selectedIndex = -1
                        binding.recyclerViewCollage.adapter?.notifyDataSetChanged()
                        binding.recyclerViewRatio.scrollToPosition(0)
                        (binding.recyclerViewRatio.adapter as AspectAdapter).lastSelectedView = -1
                        binding.recyclerViewRatio.adapter?.notifyDataSetChanged()
                        binding.collageView.setLocked(false)
                        binding.collageView.setTouchEnable(false)
                        setGoneSave()
                    }

                    Module.RATIO -> {
                        setRatio()
                        setGuideLine()
                        binding.constrantLayoutChangeLayout.visibility = View.VISIBLE
                        binding.recyclerViewTools.visibility = View.GONE
                        binding.mCLBottomTools.visibility = View.GONE
                        queShotLayout = binding.collageView.queShotLayout
                        aspectRatio = binding.collageView.aspectRatio
                        mBorderRadius = binding.collageView.collageRadian
                        mPadding = binding.collageView.collagePadding
                        binding.recyclerViewCollage.scrollToPosition(0)
                        (binding.recyclerViewCollage.adapter as GridAdapter).selectedIndex = -1
                        binding.recyclerViewCollage.adapter?.notifyDataSetChanged()
                        binding.recyclerViewRatio.scrollToPosition(0)
                        (binding.recyclerViewRatio.adapter as AspectAdapter).lastSelectedView = -1
                        binding.recyclerViewRatio.adapter?.notifyDataSetChanged()
                        binding.collageView.setLocked(false)
                        binding.collageView.setTouchEnable(false)
                        setGoneSave()
                    }

                    Module.FILTER -> {
                        if (drawableList.isEmpty()) {
                            for (drawable in binding.collageView.getQueShotGrids()) {
                                drawableList.add(drawable.drawable)
                            }
                        }
                        setFilter()
                        setGoneSave()
                    }

                    Module.TEXT -> {
                        binding.collageView.setTouchEnable(false)
                        setGoneSave()
                        setGuideLine()
                        binding.collageView.setLocked(false)
                        openTextFragment()
                        binding.constraintLayoutConfirmText.visibility = View.VISIBLE
                        binding.recyclerViewTools.visibility = View.GONE
                        binding.constraintLayoutConfirmSaveText.visibility = View.VISIBLE
                        binding.relativeLayoutAddText.visibility = View.VISIBLE
                    }

                    Module.STICKER -> {
                        setGuideLine()
                        binding.constraintLayoutSticker.visibility = View.VISIBLE
                        binding.recyclerViewTools.visibility = View.GONE
                        binding.mCLBottomTools.visibility = View.GONE
                        binding.constraintLayoutConfirmSaveSticker.visibility = View.VISIBLE
                        binding.linearLayoutWrapperStickerList.visibility = View.VISIBLE
                        setGoneSave()

                        queShotLayout = binding.collageView.queShotLayout
                        aspectRatio = binding.collageView.aspectRatio
                        mBorderRadius = binding.collageView.collageRadian
                        mPadding = binding.collageView.collagePadding

                        binding.collageView.collagePadding = mPadding
                        binding.collageView.collageRadian = mBorderRadius
                        binding.collageView.aspectRatio = aspectRatio

                        for (i in drawableList.indices) {
                            binding.collageView.getQueShotGrids()[i].drawable = drawableList[i]
                        }
                        binding.collageView.invalidate()
                        if (currentBackgroundState.isColor) {
                            binding.collageView.backgroundResourceMode = 0
                            binding.collageView.setBackgroundColor(currentBackgroundState.drawableId)
                        } else {
                            binding.collageView.backgroundResourceMode = 1
                            if (currentBackgroundState.drawable != null) {
                                binding.collageView.background = currentBackgroundState.drawable
                            } else {
                                binding.collageView.setBackgroundResource(currentBackgroundState.drawableId)
                            }
                        }
                        binding.collageView.setLocked(false)
                        binding.collageView.setTouchEnable(false)

                    }

                    Module.GRADIENT -> {
                        setGuideLine()
                        binding.constrantLayoutChangeBackground.visibility = View.VISIBLE
                        binding.recyclerViewTools.visibility = View.GONE
                        binding.mCLBottomTools.visibility = View.GONE
                        binding.collageView.setLocked(false)
                        binding.collageView.setTouchEnable(false)
                        setGoneSave()
                        setBackgroundColor()
                        if (binding.collageView.backgroundResourceMode == 0) {
                            currentBackgroundState.isColor = true
                            currentBackgroundState.isBitmap = false
                            currentBackgroundState.drawableId =
                                (binding.collageView.background as ColorDrawable).color
                            return
                        } else if (binding.collageView.backgroundResourceMode == 2 || binding.collageView.background is ColorDrawable) {
                            currentBackgroundState.isBitmap = true
                            currentBackgroundState.isColor = false
                            currentBackgroundState.drawable = binding.collageView.background
                            return
                        } else if (binding.collageView.background is GradientDrawable) {
                            currentBackgroundState.isBitmap = false
                            currentBackgroundState.isColor = false
                            currentBackgroundState.drawable = binding.collageView.background
                            return
                        } else {
                            return
                        }
                    }

                    else -> {

                    }
                }

            }

        })
    }

    private lateinit var queShotLayout: NataraLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_photo_collage)

        binding.mToolBar.mTVTitle.text = "Photo Collage"

        currentBackgroundState = CollageModels.SquareView(
            drawableId = Color.parseColor("#ffffff"), text = "", isColor = true
        )

        intent.getStringArrayListExtra(CollagePickerActivity.KEY_DATA_RESULT)?.let {
            stringList = it
        }

//        stringList.add("/storage/emulated/0/ad-1.png")
//        stringList.add("/storage/emulated/0/ad-2.png")
//        stringList.add("/storage/emulated/0/ad-3.png")
//        stringList.add("/storage/emulated/0/ad-4.png")
        setUpCollage()
        setUpDataTools()
        initRecyclerView()
        initClickListeners()
        initStickerData()
        onBackPressedDispatcher.addCallback(this, onBackPressCallback)


    }

    private fun setUpCollage() {
        queShotLayout = CollageUtils.getCollageLayouts(stringList.size)[0]
        binding.collageView.queShotLayout = queShotLayout
        binding.collageView.setTouchEnable(true)
        binding.collageView.setNeedDrawLine(false)
        binding.collageView.setNeedDrawOuterLine(false)
        binding.collageView.setLineSize(4)
        binding.collageView.collagePadding = 6.0f
        binding.collageView.collageRadian = 15.0f
        binding.collageView.setLineColor(ContextCompat.getColor(this, R.color.white))
        binding.collageView.setSelectedLineColor(ContextCompat.getColor(this, R.color.mainColor))
        binding.collageView.setHandleBarColor(ContextCompat.getColor(this, R.color.mainColor))
        binding.collageView.setAnimateDuration(300)
        binding.collageView.post { loadPhoto() }

        val defaultDisplay = windowManager.defaultDisplay
        val point = Point()
        defaultDisplay.getSize(point)

        val layoutParams = binding.collageView.layoutParams
        layoutParams.height = point.x
        layoutParams.width = point.x
        binding.collageView.layoutParams = layoutParams
        binding.collageView.aspectRatio = AspectRatio(1, 1)

    }

    private fun loadPhoto() = CoroutineScope(Dispatchers.Main).launch {
        val arrayList: ArrayList<Bitmap> = arrayListOf()
        val i: Int = if (stringList.size > queShotLayout.areaCount) {
            queShotLayout.areaCount
        } else {
            stringList.size
        }


        for (i2 in 0 until i) {
            val target = object : Target {
                override fun onBitmapFailed(exc: Exception?, drawable: Drawable?) {
                    Log.d("TAG", "onBitmapFailed: ${exc?.message}")
                }

                override fun onPrepareLoad(drawable: Drawable?) {}
                override fun onBitmapLoaded(bitmap: Bitmap, loadedFrom: Picasso.LoadedFrom?) {
                    val mBitmap = bitmap
//                    val width = mBitmap.width
//                    val f = width.toFloat()
//                    val height = mBitmap.height.toFloat()
//                    val max = (f / f).coerceAtLeast(height / f)
//                    if (max > 1.0f) {
//                        mBitmap = Bitmap.createScaledBitmap(
//                            mBitmap, (f / max).toInt(), (height / max).toInt(), false
//                        )
//                    }
                    arrayList.add(mBitmap)
                    if (arrayList.size == i) {
                        if (stringList.size < queShotLayout.areaCount) {
                            for (i in 0 until queShotLayout.areaCount) {
                                binding.collageView.addQuShotCollage(
                                    arrayList[i % i]
                                )
                            }
                        } else {
                            binding.collageView.addPieces(arrayList)
                        }
                    }
                    targets.remove(this)
                    binding.relativeLayoutLoading.visibility = View.GONE
                }
            }
            val deviceWidth = resources.displayMetrics.widthPixels

            val picasso: Picasso = Picasso.get()
            picasso.load("file:///" + stringList[i2]).resize(deviceWidth, deviceWidth)
                .centerInside().config(
                    Bitmap.Config.RGB_565
                ).into(
                    target
                )
            targets.add(target)
        }
    }

    private fun setUpDataTools() = lifecycleScope.launch {
        collageViewModel.getFilters().collectLatest {
            filterAdapter.submitList(it)
        }
        gridAdapter.submitList(CollageUtils.getCollageLayouts(stringList.size))
        gridItemToolsAdapter.submitList(collageViewModel.getCollageSecondToolsList())
        aspectAdapter.submitList(collageViewModel.getRatioModelList(false))
        collageToolsAdapter.submitList(collageViewModel.getCollageToolsList())
        collageBackgroundAdapter.submitList(collageViewModel.getGradientColorList())
    }

    private fun initRecyclerView() {
        binding.recyclerViewCollage.adapter = gridAdapter
        binding.recyclerViewRatio.adapter = aspectAdapter
        binding.recyclerViewTools.adapter = collageToolsAdapter
        binding.recyclerViewFilter.adapter = filterAdapter
        binding.recyclerViewToolsCollage.adapter = gridItemToolsAdapter
        binding.recyclerViewColor.adapter = collageColorAdapter
        binding.recyclerViewGradient.adapter = collageBackgroundAdapter
        binding.recyclerViewBlur.adapter = backgroundBlurAdapter
    }


    private fun setGuideLine() {
        val constraintSet = ConstraintSet()
        constraintSet.clone(binding.constraintLayoutCollageLayout)
        constraintSet.connect(
            binding.constraintLayoutWrapperCollageView.id,
            1,
            binding.constraintLayoutCollageLayout.id,
            1,
            0
        )
        constraintSet.connect(
            binding.constraintLayoutWrapperCollageView.id, 4, binding.guideline.id, 3, 0
        )
        constraintSet.connect(
            binding.constraintLayoutWrapperCollageView.id,
            2,
            binding.constraintLayoutCollageLayout.id,
            2,
            0
        )
        constraintSet.connect(
            binding.constraintLayoutWrapperCollageView.id,
            3,
            binding.constraintLayoutCollageLayout.id,
            3,
            0
        )
        constraintSet.applyTo(binding.constraintLayoutCollageLayout)
    }

    private fun setGuideLineTools() {
        val constraintSet = ConstraintSet()
        constraintSet.clone(binding.constraintLayoutCollageLayout)
        constraintSet.connect(
            binding.constraintLayoutWrapperCollageView.id,
            1,
            binding.constraintLayoutCollageLayout.id,
            1,
            0
        )
        constraintSet.connect(
            binding.constraintLayoutWrapperCollageView.id, 4, binding.guidelineTools.id, 3, 0
        )
        constraintSet.connect(
            binding.constraintLayoutWrapperCollageView.id,
            2,
            binding.constraintLayoutCollageLayout.id,
            2,
            0
        )
        constraintSet.applyTo(binding.constraintLayoutCollageLayout)
    }

    fun setBackgroundColor() {
        binding.recyclerViewColor.scrollToPosition(0)
        (binding.recyclerViewColor.adapter as CollageColorAdapter).selectedIndex = -1
        binding.recyclerViewColor.adapter?.notifyDataSetChanged()
        binding.recyclerViewColor.visibility = View.VISIBLE
        binding.recyclerViewGradient.visibility = View.GONE
        binding.recyclerViewBlur.visibility = View.GONE
        binding.textViewColor.setTextColor(ContextCompat.getColor(this, R.color.colorAccent))
        binding.textViewGradient.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.textViewBlur.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.viewColor.visibility = View.VISIBLE
        binding.viewGradient.visibility = View.INVISIBLE
        binding.viewBlur.visibility = View.INVISIBLE
    }

    private fun setBackgroundGradient() {
        binding.recyclerViewGradient.scrollToPosition(0)
        (binding.recyclerViewGradient.adapter as CollageBackgroundAdapter).selectedIndex = -1
        binding.recyclerViewGradient.adapter?.notifyDataSetChanged()
        binding.recyclerViewColor.visibility = View.GONE
        binding.recyclerViewGradient.visibility = View.VISIBLE
        binding.recyclerViewBlur.visibility = View.GONE
        binding.textViewColor.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.textViewGradient.setTextColor(ContextCompat.getColor(this, R.color.colorAccent))
        binding.textViewBlur.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.viewColor.visibility = View.INVISIBLE
        binding.viewGradient.visibility = View.VISIBLE
        binding.viewBlur.visibility = View.INVISIBLE
    }

    private fun selectBackgroundBlur() {

        val arrayList: ArrayList<Drawable> = arrayListOf()
        for (drawable in binding.collageView.getQueShotGrids()) {
            arrayList.add(drawable.drawable)
        }
        val squareViewList = arrayList.map {
            CollageModels.SquareView(
                drawableId = 1, text = "", isColor = false, isBitmap = true, drawable = it
            )
        }

        backgroundBlurAdapter.submitList(squareViewList)

        backgroundBlurAdapter.selectedIndex = -1
        binding.recyclerViewBlur.adapter = backgroundBlurAdapter
        binding.recyclerViewColor.visibility = View.GONE
        binding.recyclerViewGradient.visibility = View.GONE
        binding.recyclerViewBlur.visibility = View.VISIBLE
        binding.textViewColor.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.textViewGradient.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.textViewBlur.setTextColor(ContextCompat.getColor(this, R.color.colorAccent))
        binding.viewColor.visibility = View.INVISIBLE
        binding.viewGradient.visibility = View.INVISIBLE
        binding.viewBlur.visibility = View.VISIBLE
    }


    private fun setGoneSave() {
        binding.mToolBar.root.visibility = View.GONE
    }

    private fun setVisibleSave() {
        binding.mToolBar.root.visibility = View.VISIBLE
    }

    private fun setLayer() {
        binding.recyclerViewCollage.visibility = View.VISIBLE
        binding.recyclerViewRatio.visibility = View.GONE
        binding.linearLayoutPadding.visibility = View.GONE
        binding.textViewCollage.setTextColor(ContextCompat.getColor(this, R.color.colorAccent))
        binding.textViewBorder.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.textViewRatio.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.viewCollage.visibility = View.VISIBLE
        binding.viewBorder.visibility = View.INVISIBLE
        binding.viewRatio.visibility = View.INVISIBLE
    }

    private fun setFilter() {

        binding.mCLBottomTools.visibility = View.GONE
        binding.collageView.setLocked(false)
        binding.collageView.setTouchEnable(false)
        setGuideLine()
        binding.constraintLayoutFilterLayout.visibility = View.VISIBLE
        binding.recyclerViewTools.visibility = View.GONE
    }

    private fun setBorder() {
        binding.recyclerViewCollage.visibility = View.GONE
        binding.recyclerViewRatio.visibility = View.GONE
        binding.linearLayoutPadding.visibility = View.VISIBLE
        binding.textViewCollage.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.textViewBorder.setTextColor(ContextCompat.getColor(this, R.color.colorAccent))
        binding.textViewRatio.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.viewCollage.visibility = View.INVISIBLE
        binding.viewBorder.visibility = View.VISIBLE
        binding.viewRatio.visibility = View.INVISIBLE
        binding.seekbarBorder.progress = binding.collageView.collagePadding.toInt()
        binding.seekbarRadius.progress = binding.collageView.collageRadian.toInt()
    }

    private fun setRatio() {
        binding.recyclerViewCollage.visibility = View.GONE
        binding.recyclerViewRatio.visibility = View.VISIBLE
        binding.linearLayoutPadding.visibility = View.GONE
        binding.textViewCollage.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.textViewBorder.setTextColor(ContextCompat.getColor(this, R.color.black))
        binding.textViewRatio.setTextColor(ContextCompat.getColor(this, R.color.colorAccent))
        binding.viewCollage.visibility = View.INVISIBLE
        binding.viewBorder.visibility = View.INVISIBLE
        binding.viewRatio.visibility = View.VISIBLE
    }

    private fun initClickListeners() {

        binding.collageView.setOnQueShotSelectedListener { collage, i ->
            if (!binding.mCLBottomTools.isVisible || binding.recyclerViewTools.isVisible) {
                binding.recyclerViewTools.visibility = View.GONE
                binding.mCLBottomTools.visibility = View.VISIBLE
                slideUp(binding.mCLBottomTools)
                setGoneSave()
                moduleToolsId = Module.COLLAGE
            }
        }

        binding.collageView.setOnQueShotUnSelectedListener {
            binding.mCLBottomTools.visibility = View.GONE
            binding.recyclerViewTools.visibility = View.VISIBLE
            setVisibleSave()
            moduleToolsId = Module.NONE
        }

        binding.linearLayoutColor.setOnClickListener { setBackgroundColor() }
        binding.linearLayoutGradient.setOnClickListener { setBackgroundGradient() }
        binding.linearLayoutBlur.setOnClickListener { selectBackgroundBlur() }
        binding.linearLayoutCollage.setOnClickListener { setLayer() }
        binding.linearLayoutBorder.setOnClickListener { setBorder() }
        binding.linearLayoutRatio.setOnClickListener { setRatio() }

        binding.seekbarRadius.setOnSeekBarChangeListener(onSeekBarChangeListener)
        binding.seekbarBorder.setOnSeekBarChangeListener(onSeekBarChangeListener)

        binding.imageViewSavebackground.setOnClickListener {
            setGuideLineTools()
            binding.recyclerViewTools.visibility = View.VISIBLE
            binding.constrantLayoutChangeBackground.visibility = View.GONE
            binding.mCLBottomTools.visibility = View.VISIBLE
            setVisibleSave()
            binding.collageView.setLocked(true)
            binding.collageView.setTouchEnable(true)
            when (binding.collageView.backgroundResourceMode) {
                0 -> {
                    currentBackgroundState.isColor = true
                    currentBackgroundState.isBitmap = false
                    currentBackgroundState.drawableId =
                        (binding.collageView.background as ColorDrawable).color
                    currentBackgroundState.drawable = null
                }

                1 -> {
                    currentBackgroundState.isColor = false
                    currentBackgroundState.isBitmap = false
                    currentBackgroundState.drawable = binding.collageView.background
                }

                else -> {
                    currentBackgroundState.isColor = false
                    currentBackgroundState.isBitmap = true
                    currentBackgroundState.drawable = binding.collageView.background
                }
            }
            moduleToolsId = Module.NONE
        }

        binding.imageViewClosebackground.setOnClickListener {
            setVisibleSave()
            onBackPressedDispatcher.onBackPressed()
        }

        binding.imageViewCloseTools.setOnClickListener {
            setVisibleSave()
            onBackPressedDispatcher.onBackPressed()
        }

        binding.imageViewSaveLayer.setOnClickListener {
            setGuideLineTools()
            binding.recyclerViewTools.visibility = View.VISIBLE
            binding.constrantLayoutChangeLayout.visibility = View.GONE
            setVisibleSave()
            binding.mCLBottomTools.visibility = View.VISIBLE
            queShotLayout = binding.collageView.queShotLayout
            mBorderRadius = binding.collageView.collageRadian
            mPadding = binding.collageView.collagePadding
            binding.collageView.setLocked(true)
            binding.collageView.setTouchEnable(true)
            aspectRatio = binding.collageView.aspectRatio
            moduleToolsId = Module.NONE
        }
        binding.imageViewCloseLayer.setOnClickListener {
            setVisibleSave()
            onBackPressedDispatcher.onBackPressed()
        }

        binding.imageViewSaveSticker.setOnClickListener {
            setGuideLineTools()
            binding.recyclerViewTools.visibility = View.VISIBLE
            binding.constraintLayoutSticker.visibility = View.GONE
            binding.constraintLayoutConfirmSaveSticker.visibility = View.GONE
            binding.collageView.setHandlingSticker(null)
            binding.seekbarStickerAlpha.visibility = View.GONE
            binding.imageViewAddSticker.visibility = View.GONE
            binding.linearLayoutWrapperStickerList.visibility = View.VISIBLE
            binding.mCLBottomTools.visibility = View.GONE
            setVisibleSave()
            binding.collageView.setLocked(true)
            binding.collageView.setTouchEnable(true)
            moduleToolsId = Module.NONE

        }
        binding.imageViewCloseSticker.setOnClickListener {
            setVisibleSave()
            onBackPressedDispatcher.onBackPressed()
        }

        binding.imageViewSaveText.setOnClickListener {
            setGuideLineTools()
            binding.recyclerViewTools.visibility = View.VISIBLE
            binding.constraintLayoutSticker.visibility = View.GONE
            binding.constraintLayoutConfirmText.visibility = View.GONE
            binding.constraintLayoutConfirmSaveText.visibility = View.GONE
            binding.collageView.setHandlingSticker(null)
            binding.seekbarStickerAlpha.visibility = View.GONE
            binding.imageViewAddSticker.visibility = View.GONE
            binding.collageView.setLocked(true)
            binding.collageView.setTouchEnable(true)
            moduleToolsId = Module.NONE

            binding.linearLayoutWrapperStickerList.visibility = View.VISIBLE
//            binding.mCLBottomTools.visibility = View.VISIBLE
            setVisibleSave()
        }

        binding.imageViewCloseText.setOnClickListener {
            setVisibleSave()
            onBackPressedDispatcher.onBackPressed()
        }

        binding.imageViewAddSticker.setOnClickListener {
            binding.imageViewAddSticker.visibility = View.GONE
            binding.linearLayoutWrapperStickerList.visibility = View.VISIBLE
        }
        binding.imageViewSaveFilter.setOnClickListener {
            setGuideLineTools()
            setVisibleSave()
            binding.recyclerViewTools.visibility = View.VISIBLE
            binding.constraintLayoutFilterLayout.visibility = View.GONE
            binding.mCLBottomTools.visibility = View.VISIBLE
            moduleToolsId = Module.NONE
            drawableList.clear()
            drawableList.addAll(binding.collageView.getQueShotGrids().map {
                it.drawable
            })
            binding.collageView.setLocked(true)
            binding.collageView.setTouchEnable(true)
        }
        binding.imageViewCloseFilter.setOnClickListener {
            setVisibleSave()
            onBackPressedDispatcher.onBackPressed()
        }

        val minOpacity = 75

        binding.seekbarStickerAlpha.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
            override fun onProgressChanged(seekBar: SeekBar, i: Int, z: Boolean) {

                if (seekBar.progress >= minOpacity) {

                    val currentSticker: Sticker? = binding.collageView.currentSticker
                    currentSticker?.setAlpha(i)

                } else {
                    seekBar.progress = minOpacity


                    val currentSticker: Sticker? = binding.collageView.currentSticker
                    currentSticker?.setAlpha(i)
                }

            }
        })

        binding.mToolBar.mIVBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        binding.relativeLayoutAddText.setOnClickListener {
            binding.collageView.setHandlingSticker(null)
            openTextFragment()
        }

        binding.mToolBar.mTVSave.setOnClickListener {
            requestMultiplePermissions {

                customDialog(
                    getStringByLocal(R.string.save_design),
                    getStringByLocal(R.string.save_msg)
                ) {
                    saveView()
                }
            }
        }
    }

    fun slideDown(view: View) {
        ObjectAnimator.ofFloat(view, "translationY", 0.0f, view.height.toFloat()).start()
    }

    private fun slideUp(view: View) {
        ObjectAnimator.ofFloat(view, "translationY", *floatArrayOf(view.height.toFloat(), 0.0f))
            .start()
    }

    private var onSeekBarChangeListener: OnSeekBarChangeListener =
        object : OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
            override fun onProgressChanged(seekBar: SeekBar, i: Int, z: Boolean) {
                when (seekBar.id) {
                    R.id.seekbar_border -> {
                        binding.collageView.collagePadding = i.toFloat()
                        val valuePadding = i.toString()
                        binding.seekbarPadding.text = valuePadding
                    }

                    R.id.seekbar_radius -> {
                        binding.collageView.collageRadian = i.toFloat()
                        val valueRadius = i.toString()
                        binding.mSeekbarRadius.text = valueRadius
                    }
                }
                binding.collageView.invalidate()
            }
        }

    fun onNewAspectRatioSelected(aspectRatio: AspectRatio) {
        val defaultDisplay = windowManager.defaultDisplay
        val point = Point()
        defaultDisplay.getSize(point)

        val calculateWidthAndHeight: IntArray = calculateWidthAndHeight(aspectRatio, point)
        binding.collageView.layoutParams = ConstraintLayout.LayoutParams(
            calculateWidthAndHeight[0], calculateWidthAndHeight[1]
        )
        val constraintSet = ConstraintSet()
        constraintSet.clone(binding.constraintLayoutWrapperCollageView)
        constraintSet.connect(
            binding.collageView.id, 3, binding.constraintLayoutWrapperCollageView.id, 3, 0
        )
        constraintSet.connect(
            binding.collageView.id, 1, binding.constraintLayoutWrapperCollageView.id, 1, 0
        )
        constraintSet.connect(
            binding.collageView.id, 4, binding.constraintLayoutWrapperCollageView.id, 4, 0
        )
        constraintSet.connect(
            binding.collageView.id, 2, binding.constraintLayoutWrapperCollageView.id, 2, 0
        )
        constraintSet.applyTo(binding.constraintLayoutWrapperCollageView)
        binding.collageView.aspectRatio = aspectRatio
    }

    private fun calculateWidthAndHeight(aspectRatio: AspectRatio, point: Point): IntArray {
        val height: Int = binding.constraintLayoutWrapperCollageView.height
        if (aspectRatio.height > aspectRatio.width) {
            val ratio = (aspectRatio.ratio * height.toFloat()).toInt()
            return if (ratio < point.x) {
                intArrayOf(ratio, height)
            } else intArrayOf(point.x, (point.x.toFloat() / aspectRatio.ratio).toInt())
        }
        val ratio2 = (point.x.toFloat() / aspectRatio.ratio).toInt()
        return if (ratio2 > height) {
            intArrayOf((height.toFloat() * aspectRatio.ratio).toInt(), height)
        } else intArrayOf(point.x, ratio2)
    }

    private val onBackPressCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {

            when (moduleToolsId) {
                Module.PADDING, Module.RATIO, Module.LAYER -> {
                    setGuideLineTools()
                    binding.recyclerViewTools.visibility = View.VISIBLE
                    binding.constrantLayoutChangeLayout.visibility = View.GONE
                    binding.mCLBottomTools.visibility = View.VISIBLE
                    setVisibleSave()
//                    binding.collageView.updateLayout(queShotLayout)
                    binding.collageView.collagePadding = mPadding
                    binding.collageView.collageRadian = mBorderRadius
                    moduleToolsId = Module.NONE
                    windowManager.defaultDisplay.getSize(Point())
                    onNewAspectRatioSelected(aspectRatio)
                    binding.collageView.aspectRatio = aspectRatio
                    binding.collageView.setLocked(true)
                    binding.collageView.setTouchEnable(true)


                }

                Module.TEXT -> {

                    if (binding.collageView.stickers.size > 0) {
                        customStickerDialog(
                            getStringByLocal(R.string.save_text),
                            getStringByLocal(R.string.discard_text_msg), onPositiveClick = {
                                binding.imageViewSaveText.performClick()
                                return@customStickerDialog
                            }, {
                                discardTextSticker()
                            })
                    }else{
                        discardTextSticker()
                    }

                    return

                }

                Module.FILTER -> {
                    setGuideLineTools()
                    binding.recyclerViewTools.visibility = View.VISIBLE
                    binding.constraintLayoutFilterLayout.visibility = View.GONE
                    binding.mCLBottomTools.visibility = View.VISIBLE
                    binding.collageView.setLocked(true)
                    binding.collageView.setTouchEnable(true)
                    var i = 0
                    while (i < drawableList.size) {
                        binding.collageView.getQueShotGrids().get(i).drawable = drawableList.get(i)
                        i++
                    }
                    binding.collageView.invalidate()
                    setVisibleSave()
                    moduleToolsId = Module.NONE
                    return
                }

                Module.STICKER -> {

                    if (binding.collageView.stickers.size > 0) {
                        customStickerDialog(
                            getStringByLocal(R.string.save_sticker),
                            getStringByLocal(R.string.discard_sticker_msg), onPositiveClick = {
                                binding.imageViewSaveSticker.performClick()
                                return@customStickerDialog
                            }, {
                                discardSticker()
                            })
                    } else {
                        discardSticker()
                    }

                    return
                }

                Module.GRADIENT -> {
                    setGuideLineTools()
                    binding.recyclerViewTools.visibility = View.VISIBLE
                    binding.constrantLayoutChangeBackground.visibility = View.GONE
                    binding.mCLBottomTools.visibility = View.VISIBLE
                    binding.collageView.setLocked(true)
                    binding.collageView.setTouchEnable(true)
                    if (currentBackgroundState.isColor) {
                        binding.collageView.backgroundResourceMode = 0
                        binding.collageView.setBackgroundColor(currentBackgroundState.drawableId)
                    } else if (currentBackgroundState.isBitmap) {
                        binding.collageView.backgroundResourceMode = 2
                        binding.collageView.background = currentBackgroundState.drawable
                    } else {
                        binding.collageView.backgroundResourceMode = 1
                        if (currentBackgroundState.drawable != null) {
                            binding.collageView.background = currentBackgroundState.drawable
                        } else {
                            binding.collageView.setBackgroundResource(currentBackgroundState.drawableId)
                        }
                    }
                    setVisibleSave()
                    moduleToolsId = Module.NONE
                }

                Module.COLLAGE -> {
                    setVisibleSave()
                    setGuideLineTools()
                    binding.recyclerViewTools.visibility = View.VISIBLE
                    binding.mCLBottomTools.visibility = View.GONE
                    moduleToolsId = Module.NONE
                    binding.collageView.setQueShotGrid(null)
                    binding.collageView.setPrevHandlingQueShotGrid(null)
                    binding.collageView.invalidate()
                    moduleToolsId = Module.NONE
                    return
                }

                Module.NONE -> {
                    customDialog(
                        getStringByLocal(R.string.discard_design),
                        getStringByLocal(R.string.discard_msg)
                    ) {
                        finish()
                    }
                    return
                }

                else -> {
                    customDialog(
                        getStringByLocal(R.string.discard_design),
                        getStringByLocal(R.string.discard_msg)
                    ) {
                        finish()
                    }
                }
            }

        }
    }

    private fun discardTextSticker(){
        setGuideLineTools()
        binding.recyclerViewTools.visibility = View.VISIBLE
        binding.constraintLayoutConfirmText.visibility = View.GONE
        binding.constraintLayoutConfirmSaveText.visibility = View.GONE
        if (binding.collageView.stickers.isNotEmpty()) {
            binding.collageView.stickers.clear()
            binding.collageView.setHandlingSticker(null)
        }
        moduleToolsId = Module.NONE
        binding.relativeLayoutAddText.visibility = View.GONE
        binding.collageView.setHandlingSticker(null)
        setVisibleSave()
        binding.collageView.setLocked(true)
        binding.collageView.setTouchEnable(true)
    }

    private fun discardSticker() {
        setGuideLineTools()
        binding.constraintLayoutConfirmSaveSticker.visibility = View.GONE
        if (binding.collageView.stickers.size <= 0) {
            binding.linearLayoutWrapperStickerList.visibility = View.VISIBLE
            binding.imageViewAddSticker.visibility = View.GONE
            binding.collageView.setHandlingSticker(null)
            binding.recyclerViewTools.visibility = View.VISIBLE
            binding.constraintLayoutSticker.visibility = View.GONE
            binding.mCLBottomTools.visibility = View.GONE
            binding.collageView.setLocked(true)
            binding.collageView.setTouchEnable(true)
            moduleToolsId = Module.NONE
        } else if (binding.imageViewAddSticker.visibility == View.VISIBLE) {
            binding.collageView.stickers.clear()
            binding.imageViewAddSticker.visibility = View.GONE
            binding.collageView.setHandlingSticker(null)
            binding.linearLayoutWrapperStickerList.visibility = View.VISIBLE
            binding.mCLBottomTools.visibility = View.GONE
            binding.recyclerViewTools.visibility = View.VISIBLE
            binding.constraintLayoutSticker.visibility = View.GONE
            binding.collageView.setLocked(true)
            binding.collageView.setTouchEnable(true)
            moduleToolsId = Module.NONE
        } else {
            binding.linearLayoutWrapperStickerList.visibility = View.GONE
            binding.imageViewAddSticker.visibility = View.VISIBLE
            binding.mCLBottomTools.visibility = View.GONE
            binding.recyclerViewTools.visibility = View.VISIBLE
        }
        binding.linearLayoutWrapperStickerList.visibility = View.VISIBLE
        binding.recyclerViewTools.visibility = View.VISIBLE
        binding.constraintLayoutSticker.visibility = View.GONE
        binding.mCLBottomTools.visibility = View.GONE
        setVisibleSave()
    }

    private fun initStickerData() {
        binding.stickerViewpaper.adapter = object : PagerAdapter() {
            override fun getCount(): Int {
                return 15
            }

            override fun isViewFromObject(view: View, obj: Any): Boolean {
                return view == obj
            }

            override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
                container.removeView(`object` as View)
            }

            override fun instantiateItem(viewGroup: ViewGroup, i: Int): Any {

                val stickerBinding: LayoutListStickerBinding =
                    LayoutListStickerBinding.inflate(layoutInflater)

                stickerBinding.recyclerViewSticker.setHasFixedSize(true)
                stickerBinding.recyclerViewSticker.layoutManager =
                    GridLayoutManager(this@PhotoCollageActivity, 7)

                when (i) {
                    0 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.bubbleList(), this@PhotoCollageActivity
                    )

                    1 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.rainbowList(), this@PhotoCollageActivity
                    )

                    2 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.cartoonList(), this@PhotoCollageActivity
                    )

                    3 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.childList(), this@PhotoCollageActivity
                    )

                    4 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.flowerList(), this@PhotoCollageActivity
                    )

                    5 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.amojiList(), this@PhotoCollageActivity
                    )

                    6 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.deliciousList(), this@PhotoCollageActivity
                    )

                    7 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.handList(), this@PhotoCollageActivity
                    )

                    8 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.popularList(), this@PhotoCollageActivity
                    )

                    9 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.valentineList(), this@PhotoCollageActivity
                    )

                    10 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.emojList(), this@PhotoCollageActivity
                    )

                    11 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.rageList(), this@PhotoCollageActivity
                    )

                    12 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.christmasList(), this@PhotoCollageActivity
                    )

                    13 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.unicornList(), this@PhotoCollageActivity
                    )

                    14 -> stickerBinding.recyclerViewSticker.adapter = StickerAdapter(
                        StickerFileAsset.stickerList(), this@PhotoCollageActivity
                    )
                }

                viewGroup.addView(stickerBinding.root)
                return stickerBinding.root
            }
        }

        binding.recyclerTabLayout.setUpWithAdapter(
            StickersTabAdapter(
                binding.stickerViewpaper
            )
        )
        binding.recyclerTabLayout.setPositionThreshold(0.5f)
        binding.recyclerTabLayout.setBackgroundColor(
            ContextCompat.getColor(
                this, R.color.grayColor
            )
        )

        val quShotStickerIconClose = NataraStickerIcons(
            ContextCompat.getDrawable(this, R.drawable.ic_outline_close),
            0,
            NataraStickerIcons.DELETE
        )
        quShotStickerIconClose.setIconEvent(DeleteIconEvent())
        val quShotStickerIconScale = NataraStickerIcons(
            ContextCompat.getDrawable(this, R.drawable.ic_outline_scale),
            3,
            NataraStickerIcons.SCALE
        )
        quShotStickerIconScale.setIconEvent(ZoomIconEvent())
        val quShotStickerIconFlip = NataraStickerIcons(
            ContextCompat.getDrawable(this, R.drawable.ic_outline_flip), 1, NataraStickerIcons.FLIP
        )
        quShotStickerIconFlip.setIconEvent(FlipHorizontallyEvent())
        val quShotStickerIconCenter = NataraStickerIcons(
            ContextCompat.getDrawable(this, R.drawable.ic_outline_center),
            2,
            NataraStickerIcons.ALIGN
        )
        quShotStickerIconCenter.setIconEvent(AlignHorizontallyEvent())
        val quShotStickerIconRotate = NataraStickerIcons(
            ContextCompat.getDrawable(this, R.drawable.ic_outline_rotate),
            3,
            NataraStickerIcons.ROTATE
        )
        quShotStickerIconRotate.setIconEvent(ZoomIconEvent())
        val quShotStickerIconEdit = NataraStickerIcons(
            ContextCompat.getDrawable(this, R.drawable.ic_outline_edit), 1, NataraStickerIcons.EDIT
        )
        quShotStickerIconEdit.setIconEvent(EditTextIconEvent())
        binding.collageView.icons = listOf(
            quShotStickerIconClose,
            quShotStickerIconScale,
            quShotStickerIconFlip,
            quShotStickerIconEdit,
            quShotStickerIconRotate,
            quShotStickerIconCenter
        )
        binding.collageView.setConstrained(true)
        binding.collageView.setOnStickerOperationListener(onStickerOperationListener)

        /*        Preference.setKeyboard(applicationContext, 0)
                keyboardHeightProvider = KeyboardHeightProvider(this)
                keyboardHeightProvider?.addKeyboardListener(object : KeyboardHeightProvider.KeyboardListener {
                    override fun onHeightChanged(height: Int) {

                        Log.d("TAG", "onHeightChanged: $height")

                        if (height <= 0) {
                            Preference.setHeightOfNotch(applicationContext, -height)
                        } else if (addTextFragment != null) {
                            addTextFragment?.updateAddTextBottomToolbarHeight(
                                Preference.getHeightOfNotch(
                                    applicationContext
                                ) + height
                            )
                            Preference.setKeyboard(
                                applicationContext,
                                height + Preference.getHeightOfNotch(applicationContext)
                            )
                        }
                    }
                })*/
    }

    private val onStickerOperationListener: OnStickerOperationListener =
        object : OnStickerOperationListener {
            override fun onStickerDrag(sticker: Sticker) {}
            override fun onStickerFlip(sticker: Sticker) {}
            override fun onStickerTouchedDown(sticker: Sticker) {
                binding.constraintLayoutAddSticker.visibility = View.VISIBLE
                binding.seekbarStickerAlpha.progress = sticker.alpha
                binding.linearLayoutWrapperStickerList.visibility = View.GONE
            }

            override fun onStickerZoom(sticker: Sticker) {}
            override fun onTouchDownBeauty(f: Float, f2: Float) {}
            override fun onTouchDragBeauty(f: Float, f2: Float) {}
            override fun onTouchUpBeauty(f: Float, f2: Float) {}
            override fun onAddSticker(sticker: Sticker) {
                binding.constraintLayoutAddSticker.visibility = View.VISIBLE
                binding.seekbarStickerAlpha.progress = sticker.alpha
                binding.linearLayoutWrapperStickerList.visibility = View.GONE

            }

            override fun onStickerSelected(sticker: Sticker) {
                binding.constraintLayoutAddSticker.visibility = View.VISIBLE
                binding.seekbarStickerAlpha.progress = sticker.alpha
                binding.linearLayoutWrapperStickerList.visibility = View.GONE
            }

            override fun onStickerDeleted(sticker: Sticker) {
                binding.constraintLayoutAddSticker.visibility = View.GONE
                binding.linearLayoutWrapperStickerList.visibility = View.VISIBLE
            }

            override fun onStickerTouchOutside() {
                binding.constraintLayoutAddSticker.visibility = View.GONE
                binding.linearLayoutWrapperStickerList.visibility = View.VISIBLE
            }

            override fun onStickerDoubleTap(sticker: Sticker) {
                if (sticker is NataraTextView) {
                    sticker.isShow = false
                    binding.collageView.setHandlingSticker(null)
                    addTextFragment = TextFragment.show(
                        this@PhotoCollageActivity, sticker.polishText
                    )
                    textEditor = object : TextFragment.TextEditor {
                        override fun onDone(addTextProperties: NataraText?) {
                            binding.collageView.stickers
                                .remove(binding.collageView.lastHandlingSticker)
                            binding.collageView.addSticker(
                                NataraTextView(
                                    this@PhotoCollageActivity, addTextProperties
                                )
                            )
                        }

                        override fun onBackButton() {
                            binding.collageView.showLastHandlingSticker()
                        }
                    }
                    addTextFragment?.setOnTextEditorListener(this@PhotoCollageActivity.textEditor)
                }
            }
        }

    override fun addSticker(i: Int, bitmap: Bitmap?) {
        binding.collageView.addSticker(DrawableSticker(BitmapDrawable(resources, bitmap)))
        binding.linearLayoutWrapperStickerList.visibility = View.GONE
//        binding.imageViewAddSticker.visibility = View.VISIBLE
    }

    fun getBitmapWithFilter(bitmap: Bitmap?, str: String?): Bitmap? {
        val create = SharedContext.create()
        create.makeCurrent()
        val cGEImageHandler = CGEImageHandler()
        cGEImageHandler.initWithBitmap(bitmap)
        cGEImageHandler.setFilterWithConfig(str)
        cGEImageHandler.setFilterIntensity(0.5f)
        cGEImageHandler.processFilters()
        val resultBitmap = cGEImageHandler.resultBitmap
        create.release()
        return resultBitmap
    }

    private fun openTextFragment() {
        addTextFragment = TextFragment.show(this)
        textEditor = object : TextFragment.TextEditor {
            override fun onDone(addTextProperties: NataraText?) {
                binding.collageView.addSticker(
                    NataraTextView(
                        this@PhotoCollageActivity, addTextProperties
                    )
                )
            }

            override fun onBackButton() {
                if (binding.collageView.stickers.isEmpty()) {
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        }
        addTextFragment?.setOnTextEditorListener(this.textEditor)


    }

    private fun saveView() {
        val createBitmap: Bitmap = SaveFileUtils.createBitmap(binding.collageView, 1920)
        val createBitmap2: Bitmap = binding.collageView.createBitmap()
        saveCollageAsFile(createBitmap, createBitmap2)
    }

    private fun saveCollageAsFile(bitmap: Bitmap, bitmap2: Bitmap) {

        binding.relativeLayoutLoading.visibility = View.VISIBLE

        CoroutineScope(Dispatchers.IO).launch {
            val createBitmap =
                Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(createBitmap)
            val paint: Paint? = null
            canvas.drawBitmap(
                bitmap,
                null as Rect?,
                RectF(0.0f, 0.0f, bitmap.width.toFloat(), bitmap.height.toFloat()),
                paint
            )
            canvas.drawBitmap(
                bitmap2,
                null as Rect?,
                RectF(0.0f, 0.0f, bitmap.width.toFloat(), bitmap.height.toFloat()),
                paint
            )
            bitmap.recycle()
            bitmap2.recycle()
            val image = SaveFileUtils.saveBitmapFileCollage(
                this@PhotoCollageActivity,
                createBitmap,
                SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(
                    Date()
                )
            )
            createBitmap.recycle()

            withContext(Dispatchers.Main) {
                binding.relativeLayoutLoading.visibility = View.GONE
                val intent = Intent(
                    this@PhotoCollageActivity,
                    ViewActivity::class.java
                )
                intent.putExtra("path", image!!.absolutePath)
                startActivity(intent)
            }

        }
    }

    override fun onPause() {
        super.onPause()
        keyboardHeightProvider?.onPause()
    }

    override fun onResume() {
        super.onResume()
        keyboardHeightProvider?.onResume()
    }
}