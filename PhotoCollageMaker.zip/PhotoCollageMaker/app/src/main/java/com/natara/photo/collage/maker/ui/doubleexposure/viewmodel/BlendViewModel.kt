package com.natara.photo.collage.maker.ui.doubleexposure.viewmodel

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BlendViewModel() : ViewModel() {

    val pattern = MutableLiveData<ArrayList<String>>()
    val patterns: LiveData<ArrayList<String>> = pattern

    fun loadPatternData() {
        CoroutineScope(Dispatchers.Main).launch {
            loadPatterns()
        }
    }

    suspend fun loadPatterns() {
        return withContext(Dispatchers.IO) {
            val patternList = arrayListOf<String>()
            patternList.add("")
            patternList.add("file:///android_asset/olverlays/overlay0.webp")
            patternList.add("file:///android_asset/olverlays/overlay1.webp")
            patternList.add("file:///android_asset/olverlays/overlay3.webp")
            patternList.add("file:///android_asset/olverlays/overlay4.webp")
            patternList.add("file:///android_asset/olverlays/overlay5.webp")
            patternList.add("file:///android_asset/olverlays/overlay6.webp")
            patternList.add("file:///android_asset/olverlays/overlay7.webp")
            patternList.add("file:///android_asset/olverlays/overlay8.webp")
            patternList.add("file:///android_asset/olverlays/overlay9.webp")
            patternList.add("file:///android_asset/olverlays/overlay10.webp")
            patternList.add("file:///android_asset/olverlays/overlay11.webp")
            patternList.add("file:///android_asset/olverlays/overlay12.webp")
            patternList.add("file:///android_asset/olverlays/overlay13.webp")
            patternList.add("file:///android_asset/olverlays/overlay14.webp")
            patternList.add("file:///android_asset/olverlays/overlay15.webp")
            patternList.add("file:///android_asset/olverlays/overlay16.webp")
            patternList.add("file:///android_asset/olverlays/overlay17.webp")
            patternList.add("file:///android_asset/olverlays/overlay18.webp")
            patternList.add("file:///android_asset/olverlays/overlay19.webp")
            patternList.add("file:///android_asset/olverlays/overlay20.webp")
            patternList.add("file:///android_asset/olverlays/overlay21.webp")
            patternList.add("file:///android_asset/olverlays/overlay22.webp")
            patternList.add("file:///android_asset/olverlays/overlay23.webp")
            patternList.add("file:///android_asset/olverlays/overlay24.webp")
            patternList.add("file:///android_asset/olverlays/overlay25.webp")
            patternList.add("file:///android_asset/olverlays/overlay26.webp")
            patternList.add("file:///android_asset/olverlays/overlay27.webp")
            Log.d("TAG", "loadPatterns: ${patternList.size}")
            pattern.postValue(patternList)
        }
    }
}