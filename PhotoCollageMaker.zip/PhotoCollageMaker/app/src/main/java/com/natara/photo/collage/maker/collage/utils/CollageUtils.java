package com.natara.photo.collage.maker.collage.utils;

import com.natara.photo.collage.maker.collage.customviews.grid.NataraLayout;
import com.natara.photo.collage.maker.collage.customviews.layers.slant.SlantLayoutHelper;
import com.natara.photo.collage.maker.collage.customviews.layers.straight.StraightLayoutHelper;

import java.util.ArrayList;
import java.util.List;

public class CollageUtils {

    private CollageUtils() {
    }

    public static List<NataraLayout> getCollageLayouts(int i) {
        ArrayList<NataraLayout> arrayList = new ArrayList<>();
        arrayList.addAll(SlantLayoutHelper.getAllThemeLayout(i));
        arrayList.addAll(StraightLayoutHelper.getAllThemeLayout(i));
        return arrayList;
    }
}
