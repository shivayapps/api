package com.natara.photo.collage.maker.picker.util

import android.content.Context
import android.widget.Toast

object ToastUtil {
    var toastAction: ((String) -> Unit)? = null

    fun Context.showToast(text: String) {
        toastAction?.invoke(text) ?: Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }
}
