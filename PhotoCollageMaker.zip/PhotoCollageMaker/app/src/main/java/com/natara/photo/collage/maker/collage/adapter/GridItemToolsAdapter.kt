package com.natara.photo.collage.maker.collage.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.models.CollageModels
import com.natara.photo.collage.maker.collage.module.Module
import com.natara.photo.collage.maker.collage.utils.CustomDiffUtils.TOOLS_DIFF
import com.natara.photo.collage.maker.databinding.LayoutCollageItemSecondToolBinding

class GridItemToolsAdapter(var onPieceFuncItemSelected: OnPieceFuncItemSelected) :
    ListAdapter<CollageModels.ToolModel, GridItemToolsAdapter.ViewHolder>(TOOLS_DIFF) {

    interface OnPieceFuncItemSelected {
        fun onPieceFuncSelected(toolType: Module?)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        return ViewHolder(
            LayoutCollageItemSecondToolBinding.inflate(
                LayoutInflater.from(viewGroup.context),
                viewGroup, false
            )
        )
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {
        val toolModel = currentList[i]
        viewHolder.bind(toolModel)

    }

    override fun getItemCount(): Int {
        return currentList.size
    }

    inner class ViewHolder(private val binding: LayoutCollageItemSecondToolBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(toolModel: CollageModels.ToolModel) {

            binding.textViewToolName.text = toolModel.mToolName
            binding.imageViewToolIcon.setImageResource(toolModel.mToolIcon)

            binding.root.setOnClickListener { view1: View? ->
                val toolType = toolModel.mToolType
                onPieceFuncItemSelected.onPieceFuncSelected(toolType)
            }
        }

    }
}
