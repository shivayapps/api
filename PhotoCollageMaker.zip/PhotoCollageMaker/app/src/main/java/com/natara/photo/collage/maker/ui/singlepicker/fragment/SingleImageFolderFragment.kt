package com.natara.photo.collage.maker.ui.singlepicker.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.databinding.FragmentImagePickerBinding
import com.natara.photo.collage.maker.models.Media
import com.natara.photo.collage.maker.ui.singlepicker.adapter.SingleImagePickerAdapter
import com.natara.photo.collage.maker.ui.singlepicker.activity.SinglePickerActivity

class SingleImageFolderFragment(private val images: List<Media>) : Fragment() {

    private lateinit var binding: FragmentImagePickerBinding

    private val mImagePickerAdapter by lazy {
        SingleImagePickerAdapter(object : SingleImagePickerAdapter.ImagePickerListener {
            override fun onImageClickListener(media: Media) {
                setImage(media)
            }

        })
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_image_picker, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.mRVImages.adapter = mImagePickerAdapter

        mImagePickerAdapter.submitList(images)

        SinglePickerActivity.mSingleSelectionList.observe(viewLifecycleOwner) { mediaList ->
            val pathCountMap: Map<String, Int> = mediaList
                .groupBy { it.path }
                .mapValues { it.value.size }
            mImagePickerAdapter.getSelectedData(pathCountMap)
        }

    }

    private fun setImage(media: Media) {
        val newList = arrayListOf(media)
        SinglePickerActivity._mSingleSelection.value = newList
    }
}
