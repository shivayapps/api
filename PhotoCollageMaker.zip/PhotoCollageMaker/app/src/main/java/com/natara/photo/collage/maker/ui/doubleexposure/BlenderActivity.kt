package com.natara.photo.collage.maker.ui.doubleexposure

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.ImageView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.constraintlayout.widget.ConstraintSet
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.ktx.Firebase
import com.lyrebirdstudio.croppylib.Croppy
import com.lyrebirdstudio.croppylib.main.CropRequest
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.bgremover.utils.BitmapUtil
import com.natara.photo.collage.maker.collage.activities.ViewActivity
import com.natara.photo.collage.maker.databinding.ActivityBlenderBinding
import com.natara.photo.collage.maker.extentions.calculateRatio
import com.natara.photo.collage.maker.extentions.customDialog
import com.natara.photo.collage.maker.extentions.getStringByLocal
import com.natara.photo.collage.maker.extentions.loadBitmapFromView
import com.natara.photo.collage.maker.extentions.requestMultiplePermissions
import com.natara.photo.collage.maker.extentions.show
import com.natara.photo.collage.maker.extentions.startTouch
import com.natara.photo.collage.maker.picker.ImagePicker
import com.natara.photo.collage.maker.ui.BaseActivity
import com.natara.photo.collage.maker.ui.doubleexposure.viewmodel.BlendViewModel
import com.natara.photo.collage.maker.ui.drip.adapter.DripAdapter
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream


class BlenderActivity : BaseActivity(), DripAdapter.PatternClickListener {

    lateinit var binding: ActivityBlenderBinding

    var mCropBitmap: Bitmap? = null
    var mOriginalBitmap: Bitmap? = null

    var isGray = false
    private lateinit var firebaseAnalytics: FirebaseAnalytics

    private val patternAdapter by lazy {
        DripAdapter(this)
    }

    private val mBlendViewModel by lazy {
        BlendViewModel()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBlenderBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        binding.include2.mTVTitle.text = getStringByLocal(R.string.double_exposure)
        firebaseAnalytics = Firebase.analytics

        lifecycleScope.launchWhenCreated {

            val bitmap = intent?.getStringExtra("path")?.let {
                BitmapFactory.decodeFile(it)
            }

            mOriginalBitmap = bitmap

            val file = intent?.getStringExtra("path")?.let {
                File(it)
            }

            val degree = BitmapUtil().getBitmapDegree(file?.absolutePath)

            val newBitmap = mOriginalBitmap?.let {
                BitmapUtil().rotateBitmapByDegree(it, degree)
            }

            binding.googleProgress.indeterminateDrawable = showGoogleProgressBar()


            createAnalyzer()
            newBitmap?.let { newBmp ->
                analyse(newBmp, cropBitmap = {
                    mCropBitmap = it
                    setCropImage(it)
                })
            }
        }

        initListener()
        initViewModel()
        initRecyclerView()
    }

    private fun initViewModel() {

        //PatternList
        mBlendViewModel.patterns.observe(this@BlenderActivity, Observer {
            Log.d("mEditorViewModel", "loadPatterns: ${it.size}")
            patternAdapter.submitList(it)
        })
        mBlendViewModel.loadPatternData()

    }

    private fun initRecyclerView() {
        binding.mRVBackground.adapter = patternAdapter
    }

    private fun initListener() {
        binding.mOpacity.addOnChangeListener { slider, value, fromUser ->
            binding.mIVCenter.alpha = value
        }

        mIVCenter.startTouch()

        binding.mBlackWhite.setOnClickListener {
            if (isGray) {
                binding.mIVBackground.setImageBitmap(mOriginalBitmap)
                isGray = false
            } else {
                binding.mIVBackground.setImageBitmap(getGrayscale(mOriginalBitmap!!, true))
                isGray = true
            }

        }

        binding.include2.mIVBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        binding.include2.mTVSave.setOnClickListener {
            requestMultiplePermissions {

                customDialog(
                    getStringByLocal(R.string.save_design),
                    getStringByLocal(R.string.save_msg)
                ) {
                    saveImg()
                }
            }
        }
    }

    private fun setCropImage(mlImageSegmentation: Bitmap) {
        binding.googleProgress.visibility = View.GONE
        binding.mBlackWhite.show()
        Glide.with(this).load(getGrayscale(mlImageSegmentation, false)).diskCacheStrategy(
            DiskCacheStrategy.ALL
        ).into(binding.mIVBackground)

        val set = ConstraintSet()
        set.clone(binding.mParent)
        val ratio = calculateRatio(
            mlImageSegmentation.width,
            mlImageSegmentation.height
        )
        set.setDimensionRatio(binding.mCLCardMain.id, ratio)
        set.applyTo(binding.mParent)

        Glide.with(this).load(R.drawable.sample).diskCacheStrategy(
            DiskCacheStrategy.ALL
        ).into(binding.mIVCenter)


        val bitmap1 = BitmapFactory.decodeResource(resources, R.drawable.white_bg)

        val paint1 = Paint()

        val canvas = Canvas(mlImageSegmentation)
        paint1.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_OUT)

        canvas.drawBitmap(
            getResizedBitmap(
                bitmap1,
                mlImageSegmentation.width,
                mlImageSegmentation.height
            ), 0f, 0f, paint1
        )
        binding.mIVTop.setImageBitmap(mlImageSegmentation)
        binding.mIVTop.visibility = View.VISIBLE


        //eraser
        /* val sampleBitmap = BitmapFactory.decodeResource(resources,R.drawable.sample)
           Glide.with(this@BlenderActivity).asBitmap().load(sampleBitmap).into(object :CustomTarget<Bitmap>(){
                    override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {

                        mIVCenter = HoverView(
                            this@BlenderActivity,
                            resource,
                            resource.width,
                            resource.height,
                            binding.mMainContainer.measuredWidth,
                            binding.mMainContainer.measuredHeight
                        )
                        mIVCenter.layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        binding.mMainContainer.addView(mIVBackground)
                        binding.mMainContainer.addView(mIVCenter)
                        binding.mMainContainer.addView(mIVTop)


                    }

                    override fun onLoadCleared(placeholder: Drawable?) {

                    }
                })
        */

    }

    private fun getGrayscale(src: Bitmap, isGray: Boolean): Bitmap {

        val matrix = floatArrayOf(
            0.3f, 0.59f, 0.11f, 0f, 0f,
            0.3f, 0.59f, 0.11f, 0f, 0f,
            0.3f, 0.59f, 0.11f, 0f, 0f, 0f, 0f, 0f, 1f, 0f
        )
        val dest = Bitmap.createBitmap(
            src.width,
            src.height,
            src.config
        )
        val canvas = Canvas(dest)
        val paint = Paint()
        val filter = ColorMatrixColorFilter(matrix)
        if (isGray)
            paint.colorFilter = filter
        canvas.drawBitmap(src, 0f, 0f, paint)
        return dest
    }

    private fun getResizedBitmap(bm: Bitmap, newWidth: Int, newHeight: Int): Bitmap {
        val width = bm.width
        val height = bm.height
        val scaleWidth = newWidth.toFloat() / width
        val scaleHeight = newHeight.toFloat() / height
        // CREATE A MATRIX FOR THE MANIPULATION
        val matrix = Matrix()
        // RESIZE THE BIT MAP
        matrix.postScale(scaleWidth, scaleHeight)

        // "RECREATE" THE NEW BITMAP
        val resizedBitmap = Bitmap.createBitmap(
            bm, 0, 0, width, height, matrix, false
        )
        bm.recycle()
        return resizedBitmap
    }

    private val mIVCenter: ImageView
        get() {
            return binding.mIVCenter
        }

    override fun patternItemClick(position: Int) {
        when (position) {
            0 -> {
                requestMultiplePermissions {
                    ImagePicker.ActivityBuilder(this@BlenderActivity).setRequestCode(103)
                        .setResult(startEditActivity).start()
                }
            }

            else -> {
                Glide.with(this).load(patternAdapter.currentList[position]).into(binding.mIVCenter)
            }
        }
    }

    private val startEditActivity =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->

            if (result.resultCode == 103) {
                val data = result.data

                val cropRequest = CropRequest.Auto(
                    sourceUri = Uri.parse(data?.extras?.getString("EXTRA_SELECTED_URI"))
                )
                Croppy.start(this@BlenderActivity, cropRequest, startCropActivity)
            }
        }

    private val startCropActivity =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            if (result.resultCode == RESULT_OK) {
                Glide.with(this).load(File(result.data?.data?.path).absolutePath)
                    .into(binding.mIVCenter)
            }
        }


    private fun saveImg() {
        val bundle = Bundle()
        bundle.putString("curve_save", "double_exposure")
        firebaseAnalytics.logEvent("curve_text", bundle)

        val bitmap = loadBitmapFromView(
            binding.mCLCardMain,
            binding.mCLCardMain.width,
            binding.mCLCardMain.height
        )

        val f: File?
        val file: File = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                getString(R.string.app_name)
            )
        } else {
            File(
                getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                getString(R.string.app_name)
            )
        }

        if (!file.exists()) {
            file.mkdirs()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            var path = saveImageToStorage(
                bitmap,
                "${System.currentTimeMillis()}" + ".png",
                "image/png",
                Environment.DIRECTORY_PICTURES + "/" + getString(R.string.app_name)
            )
            path =
                Environment.getExternalStorageDirectory().absolutePath + File.separator + path

            startActivity(
                Intent(
                    this@BlenderActivity,
                    ViewActivity::class.java
                ).putExtra("imgPath", path)
            )


        } else {

            f =
                File(file.absolutePath + File.separator + "${System.currentTimeMillis()}" + ".png")

            f.let {
                val ostream = FileOutputStream(f)
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, ostream)
                ostream.close()
                lifecycleScope.launch {


                    val image = ContentValues()
                    image.put(MediaStore.Images.Media.TITLE, f.name)
                    image.put(MediaStore.Images.Media.DISPLAY_NAME, f.name)
                    image.put(
                        MediaStore.Images.Media.DESCRIPTION,
                        "${getString(R.string.app_name)}"
                    )
                    image.put(
                        MediaStore.Images.Media.DATE_ADDED,
                        System.currentTimeMillis()
                    )
                    image.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    image.put(MediaStore.Images.Media.ORIENTATION, 0)
                    val parent: File = f.parentFile
                    image.put(
                        MediaStore.Images.ImageColumns.BUCKET_ID, parent.toString()
                            .lowercase().hashCode()
                    )
                    image.put(
                        MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME, parent.name
                            .lowercase()
                    )
                    image.put(MediaStore.Images.Media.SIZE, f.length())
                    image.put(MediaStore.Images.Media.DATA, f.absolutePath)
                    contentResolver.insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, image
                    )
                }
                startActivity(
                    Intent(
                        this@BlenderActivity,
                        ViewActivity::class.java
                    ).putExtra("imgPath", it.absolutePath)
                )
            }
        }

    }

    private fun saveImageToStorage(
        bitmap: Bitmap,
        filename: String = "screenshot.jpg",
        mimeType: String = "image/png",
        directory: String = Environment.DIRECTORY_PICTURES,
        mediaContentUri: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
    ): String {
        val imageOutStream: OutputStream
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                put(MediaStore.Images.Media.RELATIVE_PATH, directory)
            }

            contentResolver.run {
                val uri =
                    contentResolver.insert(mediaContentUri, values)
                        ?: return ""
                imageOutStream = openOutputStream(uri) ?: return ""
            }

        } else {
            val imagePath = Environment.getExternalStoragePublicDirectory(directory).absolutePath
            val image = File(imagePath, filename)
            imageOutStream = FileOutputStream(image)
        }

        imageOutStream.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return "$directory/$filename"
    }

    val backPressedCallback =
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {

                customDialog(
                    getStringByLocal(R.string.discard_design),
                    getStringByLocal(R.string.discard_msg)
                ) {
                    finish()
                }

            }
        })

}