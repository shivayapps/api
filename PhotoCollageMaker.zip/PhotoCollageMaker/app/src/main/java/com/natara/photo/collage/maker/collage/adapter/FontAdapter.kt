package com.natara.photo.collage.maker.collage.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.assets.FontFileAsset
import com.natara.photo.collage.maker.collage.utils.CustomDiffUtils.FONT_SHADOW
import com.natara.photo.collage.maker.databinding.ItemFontBinding

class FontAdapter(private var mClickListener: ItemClickListener) :
    ListAdapter<String, FontAdapter.ViewHolder>(FONT_SHADOW) {
    @JvmField
    var selectedItem = 0

    interface ItemClickListener {
        fun onItemClick(view: View?, i: Int)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        return ViewHolder(
            ItemFontBinding.inflate(
                LayoutInflater.from(viewGroup.context), viewGroup, false
            )
        )
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {
        viewHolder.bind()
    }

    override fun getItemCount(): Int {
        return currentList.size
    }

    inner class ViewHolder internal constructor(private val binding: ItemFontBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind() {
            FontFileAsset.setFontByName(
                binding.root.context,
                binding.textViewFontItem,
                currentList[adapterPosition]
            )

            val i2: Int = if (selectedItem != adapterPosition) {
                R.drawable.border_view
            } else {
                R.drawable.border_black_view
            }
            binding.constraintLayoutWrapperFontItem.background =
                ContextCompat.getDrawable(binding.root.context, i2)

            binding.root.setOnClickListener {
                selectedItem = adapterPosition
                mClickListener.onItemClick(it, selectedItem)
                notifyDataSetChanged()
            }
        }
    }

    fun setSelectedItem(i: Int) {
        selectedItem = i
    }
}
