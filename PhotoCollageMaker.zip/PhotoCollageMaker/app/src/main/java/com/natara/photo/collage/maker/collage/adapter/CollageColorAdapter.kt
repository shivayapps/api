package com.natara.photo.collage.maker.collage.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.natara.photo.collage.maker.collage.assets.BrushColorAsset
import com.natara.photo.collage.maker.collage.models.CollageModels
import com.natara.photo.collage.maker.databinding.LayoutBackgroundItemsBinding

class CollageColorAdapter(
    var backgroundListener: BackgroundColorListener,
) : RecyclerView.Adapter<CollageColorAdapter.ViewHolder>() {
    var selectedIndex = 0
    var squareViewList: MutableList<CollageModels.SquareView> = arrayListOf()

    interface BackgroundColorListener {
        fun onBackgroundColorSelected(i: Int, squareView: CollageModels.SquareView)
    }

    init {
        val lstColorForBrush: List<String> = BrushColorAsset.listColorBrush()
        for (i in 0 until lstColorForBrush.size - 2) {
            squareViewList.add(
                CollageModels.SquareView(
                    drawableId = Color.parseColor(lstColorForBrush[i]), text = "", isColor = true
                )
            )
        }
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        return ViewHolder(
            LayoutBackgroundItemsBinding.inflate(
                LayoutInflater.from(viewGroup.context),
                viewGroup,
                false
            )
        )
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {
        val squareView = squareViewList[i]
        viewHolder.bind(squareView, i)
    }

    override fun getItemCount(): Int {
        return squareViewList.size
    }

    inner class ViewHolder(private val binding: LayoutBackgroundItemsBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(squareView: CollageModels.SquareView, position: Int) {
            binding.imageViewSquare.visibility = View.GONE
            binding.root.setOnClickListener {
                selectedIndex = adapterPosition
                backgroundListener.onBackgroundColorSelected(
                    selectedIndex,
                    squareViewList[selectedIndex]
                )
                notifyDataSetChanged()
            }

            if (squareView.isColor) {
                binding.squareView.setBackgroundColor(squareView.drawableId)
            } else if (squareView.drawable != null) {
                binding.squareView.visibility = View.GONE
                binding.imageViewSquare.visibility = View.VISIBLE
                binding.imageViewSquare.setImageDrawable(squareView.drawable)
            } else {
                binding.squareView.setBackgroundResource(squareView.drawableId)
            }

            if (selectedIndex == position) {
                binding.viewSelected.visibility = View.VISIBLE
            } else {
                binding.viewSelected.visibility = View.GONE
            }
        }
    }


}
