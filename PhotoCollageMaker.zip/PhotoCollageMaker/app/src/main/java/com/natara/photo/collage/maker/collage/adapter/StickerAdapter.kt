package com.natara.photo.collage.maker.collage.adapter

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.natara.photo.collage.maker.collage.utils.StickerFileAsset
import com.natara.photo.collage.maker.databinding.LayoutStickerItemBinding

class StickerAdapter(
    var stringList: List<String>,
    var onClickSplashListener: OnClickSplashListener
) : RecyclerView.Adapter<StickerAdapter.ViewHolder>() {
    interface OnClickSplashListener {
        fun addSticker(i: Int, bitmap: Bitmap?)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        return ViewHolder(
            LayoutStickerItemBinding.inflate(
                LayoutInflater.from(
                    viewGroup.context
                ),
                viewGroup,
                false
            )
        )
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {

        viewHolder.bind(stringList[i])


    }

    override fun getItemCount(): Int {
        return stringList.size
    }

    inner class ViewHolder(private val binding: LayoutStickerItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: String) {

            binding.root.context.let { context ->

                val bitmap: Bitmap? = StickerFileAsset.loadBitmapFromAssets(context, item)
                Glide.with(context).load(bitmap).into(binding.imageViewItemSticker)

                binding.root.setOnClickListener {
                    onClickSplashListener.addSticker(
                        adapterPosition, StickerFileAsset.loadBitmapFromAssets(
                            context, stringList[adapterPosition]
                        )
                    )
                }
            }
        }
    }
}
