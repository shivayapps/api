package com.natara.photo.collage.maker.collage.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.customviews.NataraText.TextShadow
import com.natara.photo.collage.maker.collage.utils.CustomDiffUtils.TEXT_SHADOW
import com.natara.photo.collage.maker.databinding.ItemFontBinding

class ShadowAdapter(private var mClickListener: ShadowItemClickListener) :
    ListAdapter<TextShadow, ShadowAdapter.ViewHolder>(TEXT_SHADOW) {
    @JvmField
    var selectedItem = 0

    interface ShadowItemClickListener {
        fun onShadowItemClick(view: View?, i: Int)
    }

    override fun getItemViewType(i: Int): Int {
        return i
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        return ViewHolder(
            ItemFontBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false)
        )
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {
        val textShadow = currentList[i]
        viewHolder.bind(textShadow)
    }

    override fun getItemCount(): Int {
        return currentList.size
    }

    inner class ViewHolder(private val binding: ItemFontBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(textShadow: TextShadow) {


            binding.textViewFontItem.setShadowLayer(
                textShadow.radius.toFloat(),
                textShadow.dx.toFloat(),
                textShadow.dy.toFloat(),
                textShadow.colorShadow
            )

            val i2: Int = if (selectedItem != adapterPosition) {
                R.drawable.border_view
            } else {
                R.drawable.border_black_view
            }

            binding.constraintLayoutWrapperFontItem.background =
                ContextCompat.getDrawable(binding.root.context, i2)

            binding.root.setOnClickListener {
                mClickListener.onShadowItemClick(it, adapterPosition)
                selectedItem = adapterPosition
                notifyDataSetChanged()
            }
        }

    }

    fun setSelectedItem(i: Int) {
        selectedItem = i
    }

}
