package com.natara.photo.collage.maker.bgremover.activity

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.view.children
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.huawei.hms.mlsdk.MLAnalyzerFactory
import com.huawei.hms.mlsdk.common.MLFrame
import com.huawei.hms.mlsdk.imgseg.MLImageSegmentationAnalyzer
import com.huawei.hms.mlsdk.imgseg.MLImageSegmentationScene
import com.huawei.hms.mlsdk.imgseg.MLImageSegmentationSetting
import com.lyrebirdstudio.croppylib.Croppy
import com.lyrebirdstudio.croppylib.main.CropRequest
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.bgremover.adapter.BgPagerAdapter
import com.natara.photo.collage.maker.bgremover.adapter.ColorAdapter
import com.natara.photo.collage.maker.bgremover.adapter.GradientAdapter
import com.natara.photo.collage.maker.bgremover.fragment.BackgroundApiFragment
import com.natara.photo.collage.maker.bgremover.utils.BitmapUtil
import com.natara.photo.collage.maker.bgremover.utils.ChromeFloatingCirclesDrawable
import com.natara.photo.collage.maker.bgremover.viewmodel.EditorViewModel
import com.natara.photo.collage.maker.collage.activities.ViewActivity
import com.natara.photo.collage.maker.databinding.ActivityBgRemoveBinding
import com.natara.photo.collage.maker.databinding.CustomColorDropBottomSheetBinding
import com.natara.photo.collage.maker.extentions.click
import com.natara.photo.collage.maker.extentions.customDialog
import com.natara.photo.collage.maker.extentions.getProgressDrawableColors
import com.natara.photo.collage.maker.extentions.getStringByLocal
import com.natara.photo.collage.maker.extentions.hide
import com.natara.photo.collage.maker.extentions.invisible
import com.natara.photo.collage.maker.extentions.isOnline
import com.natara.photo.collage.maker.extentions.loadBitmapFromView
import com.natara.photo.collage.maker.extentions.requestMultiplePermissions
import com.natara.photo.collage.maker.extentions.show
import com.natara.photo.collage.maker.extentions.startTouch
import com.natara.photo.collage.maker.extentions.viewSlideDown
import com.natara.photo.collage.maker.extentions.viewSlideUp
import com.natara.photo.collage.maker.picker.ImagePicker
import com.natara.photo.collage.maker.picker.util.ToastUtil.showToast
import com.skydoves.colorpickerview.ColorPickerView
import com.skydoves.colorpickerview.listeners.ColorEnvelopeListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

class BgRemoveActivity : AppCompatActivity(), GradientAdapter.GradientClickListener,
    ColorAdapter.ColorClickListener {

    private lateinit var binding: ActivityBgRemoveBinding
    private lateinit var mAnalyzer: MLImageSegmentationAnalyzer
    private var mCropBitmap: Bitmap? = null
    private var mOriginalBitmap: Bitmap? = null

    private var bgColor: Int = Color.parseColor("#ffffff")
    private var bgGradient: String = ""
    private var bgTemplate: String = ""
    private var mColorPickerView: ColorPickerView? = null

    private val gradientAdapter by lazy {
        GradientAdapter(this)
    }

    private val colorAdapter by lazy {
        ColorAdapter(this)
    }

    private val mEditorViewModel by lazy {
        EditorViewModel()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBgRemoveBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.mLBGEditor.mCLBack.hide()

        lifecycleScope.launch {

            val bitmap = intent?.getStringExtra("path")?.let {
                BitmapFactory.decodeFile(it)
            }

            mOriginalBitmap = bitmap

            val file = intent?.getStringExtra("path")?.let {
                File(it)
            }

            val degree = BitmapUtil().getBitmapDegree(file?.absolutePath)

            val newBitmap = mOriginalBitmap?.let {
                BitmapUtil().rotateBitmapByDegree(it, degree)
            }

            Glide.with(this@BgRemoveActivity).load(newBitmap).diskCacheStrategy(
                DiskCacheStrategy.ALL
            ).into(binding.mIVBackground)

            binding.googleProgress.indeterminateDrawable =
                ChromeFloatingCirclesDrawable.Builder(this@BgRemoveActivity)
                    .colors(getProgressDrawableColors())
                    .build()


            createAnalyzer()
            newBitmap?.let { newbmp ->
                analyse(newbmp) {
                    setCropImage(it)
                    mCropBitmap = it
                }
            }

            defaultObserver()

            binding.mRVFontColor.adapter = colorAdapter
            binding.mRVTextGradient.adapter = gradientAdapter

        }
        initListeners()
        initBGEditor()
        CoroutineScope(Dispatchers.Main).launch {
            loadBackgrounds()
        }
    }


    private suspend fun defaultObserver() {

        //ColorList
        mEditorViewModel.loadColor(this).collectLatest {
            colorAdapter.submitList(it)
        }
        //Gradient
        mEditorViewModel.getGradientColor().collectLatest {
            gradientAdapter.submitList(it)
        }
    }

    //BG Editor
    private fun initBGEditor() {

        binding.mLBGEditor.mCLBgGradient.setOnClickListener {
            if (binding.mCLTextGradient.isVisible) return@setOnClickListener
            gradientAdapter.selectedItemPos = bgGradient

            hideSubBottomLayout()
            viewSlideUp(binding.mCLTextGradient)
            selectBottom(binding.mLBGEditor.mCLBgGradient, binding.mLBGEditor.mLLBackgrounds)
        }

        binding.mLBGEditor.mCLBgColor.click {
            if (binding.mCLTextColor.isVisible) return@click
            colorAdapter.selectedItemPos = bgColor

            hideSubBottomLayout()
            viewSlideUp(binding.mCLTextColor)
            selectBottom(binding.mLBGEditor.mCLBgColor, binding.mLBGEditor.mLLBackgrounds)
        }

        binding.mLBGEditor.mCLBGTemplate.click {
            if (binding.mCLBackgrounds.isVisible) return@click
            if (isOnline()) {
                hideSubBottomLayout()
                viewSlideUp(binding.mCLBackgrounds)
                selectBottom(binding.mLBGEditor.mCLBGTemplate, binding.mLBGEditor.mLLBackgrounds)
//                BgBottomSheet.newInstance().show(supportFragmentManager)
//                startBgActivity.launch(Intent(this, BgStoreActivity::class.java))
            } else {
                Toast.makeText(this, "No Internet", Toast.LENGTH_SHORT).show()
            }
        }

        binding.mLBGEditor.mCLBgGallery.click {
            requestMultiplePermissions {
                ImagePicker.ActivityBuilder(this).setRequestCode(105).setResult(startEditActivity)
                    .start()
            }
        }

    }


    private val startBgActivity =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            if (result.resultCode == Activity.RESULT_OK) {
                result.data?.getStringExtra("path")?.let { setBgLayout(it) }
            }
        }

    fun setBgLayout(path: String) {
        bgColor = Color.parseColor("#00000000")
        bgGradient = ""
        bgTemplate = path
        Glide.with(this).load(path).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
            .into(binding.mIVBackground)
        return
    }

    private fun hideSubBottomLayout() {
        viewSlideDown(binding.mCLTextColor)
        viewSlideDown(binding.mCLTextGradient)
        viewSlideDown(binding.mCLBackgrounds)
    }

    private fun selectBottom(
        selectedView: View?, parentView: ViewGroup,
    ) {
        parentView.children.forEach { view ->
            if (view is ConstraintLayout) {
                view.children.forEach { clView ->
                    if (selectedView?.id == view.id) {
                        if (clView is ImageView) {
                            clView.colorFilter = PorterDuffColorFilter(
                                ContextCompat.getColor(this, R.color.colorPrimary),
                                PorterDuff.Mode.SRC_ATOP
                            )
                        }
                        if (clView is TextView) {
                            clView.setTextColor(
                                ContextCompat.getColor(
                                    this, R.color.colorPrimary
                                )
                            )
                            clView.setTypeface(
                                clView.typeface, Typeface.BOLD
                            )
                        }
                    } else {
                        if (clView is ImageView) {
                            clView.colorFilter = PorterDuffColorFilter(
                                ContextCompat.getColor(this, R.color.black),
                                PorterDuff.Mode.SRC_ATOP
                            )
                        }
                        if (clView is TextView) {
                            clView.setTextColor(
                                ContextCompat.getColor(
                                    this, R.color.black
                                )
                            )
                            clView.setTypeface(
                                clView.typeface, Typeface.NORMAL
                            )
                        }
                    }
                }

            }
        }
    }

    private fun initListeners() {
        binding.toolbar.mTVTitle.text = getText(R.string.remove_bg)
        binding.toolbar.mTVSave.setOnClickListener {
            requestMultiplePermissions {

                customDialog(
                    getStringByLocal(R.string.save_design), getStringByLocal(R.string.save_msg)
                ) {
                    saveImg()
                }
            }
        }
        binding.toolbar.mIVBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun setCropImage(bitmap: Bitmap) {

        binding.googleProgress.visibility = View.GONE
        binding.mIVCrop.visibility = View.GONE

        Glide.with(this).load(bitmap).diskCacheStrategy(
            DiskCacheStrategy.ALL
        ).into(binding.mIVCrop)

        Glide.with(this).load(bitmap).diskCacheStrategy(
            DiskCacheStrategy.ALL
        ).into(binding.mIVAnimation)

        Log.d("TAG", "setCropImage: ${bitmap.height} ${bitmap.width}")


        binding.mIVAnimation.startAnimation(AnimationUtils.loadAnimation(this, R.anim.blink))
        binding.mIVAnimation.setColorFilter(
            ContextCompat.getColor(this, R.color.colorPrimary),
            PorterDuff.Mode.SRC_ATOP
        )

        Handler(Looper.getMainLooper()).postDelayed({
            binding.mIVAnimation.setColorFilter(
                ContextCompat.getColor(this, android.R.color.transparent),
                PorterDuff.Mode.SRC_ATOP
            )

            binding.mIVAnimation.clearAnimation()
            binding.mIVCrop.isEnabled = true

            binding.mIVCrop.show()
            binding.mIVAnimation.hide()
            binding.mIVBackground.setImageResource(0)

        }, 1500)

        binding.mIVCrop.startTouch()

    }


    private fun createAnalyzer(): MLImageSegmentationAnalyzer {
        val analyzerSetting = MLImageSegmentationSetting.Factory()
            .setExact(true)
            .setAnalyzerType(MLImageSegmentationSetting.BODY_SEG)
            .setScene(MLImageSegmentationScene.FOREGROUND_ONLY)
            .create()

        return MLAnalyzerFactory.getInstance().getImageSegmentationAnalyzer(analyzerSetting).also {
            mAnalyzer = it
        }
    }

    private fun analyse(bmp: Bitmap, cropBitmap: (Bitmap) -> Unit) {
        val mlFrame = MLFrame.fromBitmap(bmp)
        mAnalyzer.asyncAnalyseFrame(mlFrame)
            .addOnSuccessListener {
                cropBitmap(it.foreground)
            }
            .addOnFailureListener {
                showToast("Face Not Found.")
            }

        mAnalyzer.analyseFrame(mlFrame)


    }

    private fun saveImg() {
        lifecycleScope.launch(Dispatchers.Main) {


            val bitmap = Bitmap.createBitmap(
                binding.mContainer.width,
                binding.mContainer.height,
                Bitmap.Config.ARGB_8888
            )

            val canvas = Canvas(bitmap)

            loadBitmapFromView(
                binding.mIVBackground, binding.mContainer.width, binding.mContainer.height
            ).let { it1 ->
                canvas.drawBitmap(
                    it1, Matrix(), Paint()
                )
            }

            binding.mContainer.draw(canvas)


            val f: File?
            val file: File = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    getString(R.string.app_name)
                )
            } else {
                File(
                    getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                    getString(R.string.app_name)
                )
            }

            if (!file.exists()) {
                file.mkdirs()
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                var path = saveImageToStorage(
                    bitmap,
                    "${System.currentTimeMillis()}" + ".png",
                    "image/png",
                    Environment.DIRECTORY_PICTURES + "/" + getString(R.string.app_name)
                )
                path =
                    Environment.getExternalStorageDirectory().absolutePath + File.separator + path

                MediaScannerConnection.scanFile(
                    this@BgRemoveActivity, arrayOf(path), null
                ) { _, _ ->
                    // Scan completed, use the resulting URI if needed
                }

                startActivity(
                    Intent(
                        this@BgRemoveActivity,
                        ViewActivity::class.java
                    ).putExtra("imgPath", path)
                )


            } else {

                f =
                    File(file.absolutePath + File.separator + "${System.currentTimeMillis()}" + ".png")

                f.let {
                    val ostream = FileOutputStream(f)
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, ostream)
                    ostream.close()
                    //Toast.makeText(mContext, "Image Save", Toast.LENGTH_SHORT).show()
                    lifecycleScope.launch {


                        val image = ContentValues()
                        image.put(MediaStore.Images.Media.TITLE, f.name)
                        image.put(MediaStore.Images.Media.DISPLAY_NAME, f.name)
                        image.put(
                            MediaStore.Images.Media.DESCRIPTION, "${getString(R.string.app_name)}"
                        )
                        image.put(
                            MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis()
                        )
                        image.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        image.put(MediaStore.Images.Media.ORIENTATION, 0)
                        val parent: File? = f.parentFile
                        image.put(
                            MediaStore.Images.ImageColumns.BUCKET_ID,
                            parent.toString().lowercase().hashCode()
                        )
                        image.put(
                            MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME,
                            parent?.name?.lowercase()
                        )
                        image.put(MediaStore.Images.Media.SIZE, f.length())
                        image.put(MediaStore.Images.Media.DATA, f.absolutePath)
                        contentResolver.insert(
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, image
                        )
                    }

                    MediaScannerConnection.scanFile(
                        this@BgRemoveActivity, arrayOf(it.absolutePath), null
                    ) { _, _ ->
                        // Scan completed, use the resulting URI if needed
                    }

                    startActivity(
                        Intent(
                            this@BgRemoveActivity,
                            ViewActivity::class.java
                        ).putExtra("imgPath", it.absolutePath)
                    )
                }
            }

        }
    }

    private fun saveImageToStorage(
        bitmap: Bitmap,
        filename: String = "screenshot.jpg",
        mimeType: String = "image/png",
        directory: String = Environment.DIRECTORY_PICTURES,
        mediaContentUri: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
    ): String {
        val imageOutStream: OutputStream
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                put(MediaStore.Images.Media.RELATIVE_PATH, directory)
            }

            contentResolver.run {
                val uri = contentResolver.insert(mediaContentUri, values) ?: return ""
                imageOutStream = openOutputStream(uri) ?: return ""
            }

        } else {
            val imagePath = Environment.getExternalStoragePublicDirectory(directory).absolutePath
            val image = File(imagePath, filename)
            imageOutStream = FileOutputStream(image)
        }

        imageOutStream.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return "$directory/$filename"
    }

    val mOnBackPress =
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {

                customDialog(
                    getStringByLocal(R.string.discard_design),
                    getStringByLocal(R.string.discard_msg)
                ) {
                    finish()
                }

            }
        })

    override fun gradientItemClick(position: Int) {
        bgColor = Color.parseColor("#00000000")
        bgTemplate = ""
        binding.mIVBackground.setImageResource(0)
        val gradient = gradientAdapter.currentList[position]
        bgGradient = gradient
        val split: Array<String> = gradient.split(",".toRegex()).toTypedArray()
        val color1 = split[0]
        val color2 = split[1]

        val gradientDrawable = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(
                Color.parseColor(color1), Color.parseColor(color2)
            )
        )

        binding.mIVBackground.background = gradientDrawable
    }

    override fun colorItemClick(position: Int) {

        when (position) {
            0 -> {
                var firstClick = false

                val dialog = BottomSheetDialog(this, R.style.CustomDialogTheme)
                dialog.window?.setWindowAnimations(R.style.ColorDialogAnimation)
                val view = CustomColorDropBottomSheetBinding.inflate(layoutInflater)

                val tempBitmap: Bitmap = loadBitmapFromView(
                    binding.mCLCardMain,
                    binding.mCLCardMain.measuredWidth,
                    binding.mCLCardMain.measuredHeight
                )

                view.mCPView.setPaletteDrawable(
                    BitmapDrawable(
                        resources, tempBitmap
                    )
                )

                var tempColor = bgColor

                view.ibClose.click {
                    binding.mIVBackground.setBackgroundColor(bgColor)
                    dialog.dismiss()
                }

                view.mCPView.setColorListener(ColorEnvelopeListener { envelope, fromUser ->
                    if (firstClick) {
                        tempColor = envelope.color
                        binding.mIVBackground.setBackgroundColor(envelope.color)
                        view.mIVColorCode.setColorFilter(envelope.color)
                        view.mTVColorCode.setText("#" + envelope.hexCode)
                        return@ColorEnvelopeListener
                    }
                    firstClick = true
                    view.mIVColorCode.setColorFilter(envelope.color)
                    view.mTVColorCode.setText("#" + envelope.hexCode)
                })

                view.mTVApply.setOnClickListener {
                    bgColor = tempColor
                    addColorToAdapter()
                    dialog.dismiss()
                }

                mColorPickerView = view.mCPView
                view.constraintLayout22.setOnClickListener {
                    requestMultiplePermissions {
                        ImagePicker.ActivityBuilder(this).setRequestCode(103)
                            .setResult(startEditActivity).start()
                    }
                }

                dialog.setCancelable(false)
                dialog.setContentView(view.root)
                dialog.show()
            }

            1 -> {
                var firstClick = false

                val dialog = BottomSheetDialog(this, R.style.CustomDialogTheme)
                dialog.window?.setWindowAnimations(R.style.ColorDialogAnimation)
                val view = CustomColorDropBottomSheetBinding.inflate(layoutInflater)

                view.mClBottom.invisible()
                var tempColor = bgColor

                view.ibClose.click {

                    binding.mIVBackground.setBackgroundColor(bgColor)
                    dialog.dismiss()
                }

                view.mCPView.setColorListener(ColorEnvelopeListener { envelope, fromUser ->
                    if (firstClick) {

                        tempColor = envelope.color
                        binding.mIVBackground.setBackgroundColor(envelope.color)
                        view.mIVColorCode.setColorFilter(envelope.color)
                        view.mTVColorCode.setText("#" + envelope.hexCode)
                        return@ColorEnvelopeListener

                    }
                    firstClick = true
                    view.mIVColorCode.setColorFilter(envelope.color)
                    view.mTVColorCode.setText("#" + envelope.hexCode)
                })

                view.mTVApply.setOnClickListener {
                    bgColor = tempColor
                    addColorToAdapter()
                    dialog.dismiss()
                }

                dialog.setCancelable(false)
                dialog.setContentView(view.root)
                dialog.show()
            }

            else -> {

                //For BG
                bgGradient = ""
                bgTemplate = ""
                binding.mIVBackground.setImageResource(0)
                bgColor = colorAdapter.currentList[position]
                binding.mIVBackground.setBackgroundColor(colorAdapter.currentList[position])
                return

            }
        }

    }

    private fun addColorToAdapter() {

        bgGradient = ""
        bgTemplate = ""
        binding.mIVBackground.setImageResource(0)

        if (!colorAdapter.currentList.contains(bgColor)) {
            val newColorList = arrayListOf<Int>()
            newColorList.addAll(colorAdapter.currentList)
            newColorList.add(2, bgColor)
            colorAdapter.submitList(null)
            colorAdapter.submitList(newColorList)
            colorAdapter.selectedItemPos =
                colorAdapter.currentList[colorAdapter.currentList.indexOf(
                    bgColor
                )]
        }


    }

    private fun setBgData(bgCategoryList: ArrayList<String>) =
        CoroutineScope(Dispatchers.Main).launch {

            if (bgCategoryList.size == 0) {
                return@launch
            }

            val viewPagerAdapter = BgPagerAdapter(
                supportFragmentManager,
                lifecycle,
                bgCategoryList,
                object : BackgroundApiFragment.OnActionCompleteListener {
                    override fun onBackgroundItemClick(path: String?) {
                        path?.let {
                            setBgLayout(it)
                        }
                    }
                })

            binding.mViewPager.adapter = viewPagerAdapter

            TabLayoutMediator(
                binding.mTabs, binding.mViewPager, true
            ) { tab, position ->
                tab.setCustomView(R.layout.layout_album_item)
                val textView = tab.customView?.findViewById<TextView>(R.id.mTVAlbum)
                textView?.text = bgCategoryList[position].replace("_", " ")
            }.attach()

            binding.mTabs.addOnTabSelectedListener(object :
                TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab2: TabLayout.Tab) {
                    binding.mViewPager.currentItem = tab2.position
                }

                override fun onTabUnselected(tab2: TabLayout.Tab) {
                }

                override fun onTabReselected(tab2: TabLayout.Tab) {}
            })

            binding.mTabs.setTabRippleColorResource(android.R.color.transparent);

        }

    private fun loadBackgrounds() {

        mEditorViewModel.loadCategoryData()

        mEditorViewModel.bgCategory.observe(this) {
            CoroutineScope(Dispatchers.IO).launch {
                setBgData(it)
            }
        }
    }

    private val startEditActivity =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->

            if (result.resultCode == 105) {
                val data = result.data

                val cropRequest = CropRequest.Auto(
                    sourceUri = Uri.parse(data?.extras?.getString("EXTRA_SELECTED_URI"))
                )
                Croppy.start(this, cropRequest, startBGCropActivity)

            }

        }

    private val startBGCropActivity =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            if (result.resultCode == Activity.RESULT_OK) {
                val bitmap = BitmapFactory.decodeFile(File(result.data?.data?.path).absolutePath)

                bgColor = Color.parseColor("#00000000")
                bgGradient = ""
                bgTemplate = ""
                Glide.with(this)
                    .load(bitmap)
                    .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                    .into(binding.mIVBackground)
            }
        }


}