package com.natara.photo.collage.maker.ui.picker.adapters

import android.content.Context
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.natara.photo.collage.maker.databinding.LayoutImageItemBinding
import com.natara.photo.collage.maker.databinding.LayoutSelectedImageItemBinding
import com.natara.photo.collage.maker.diffutils.DiffUtilsCallBacks
import com.natara.photo.collage.maker.models.Media

class ImagePickerAdapter(
    private val mImagePickerListener: ImagePickerListener,
    private val isSelected: Boolean = false,
) :
    ListAdapter<Media, ImagePickerAdapter.ImagePickerViewHolder>(
        DiffUtilsCallBacks.DiffCallbackPicker()
    ) {

    private val mSelectedList = arrayListOf<Pair<String, Int>>()

    interface ImagePickerListener {
        fun onImageClickListener(media: Media)
        fun onImageRemoveClickListener(media: Media)
    }

    inner class ImagePickerViewHolder(private var binding: ViewBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(media: Media) {


            if (isSelected) {
                val binding = (binding as LayoutSelectedImageItemBinding)

                val requestOption = RequestOptions
                    .overrideOf(300, 300)

                Glide.with(binding.root)
                    .applyDefaultRequestOptions(requestOption)
                    .load(media.uri)
                    .into(binding.mIVImage)

                binding.root.setOnClickListener {
                    mImagePickerListener.onImageClickListener(media)
                }

                binding.mCVClose.setOnClickListener {
                    mImagePickerListener.onImageRemoveClickListener(media)
                }
            } else {
                val binding = (binding as LayoutImageItemBinding)


                val requestOptions = RequestOptions().dontAnimate().override(
                    setColumnNumber(binding.root.context),
                    setColumnNumber(binding.root.context)
                )
                Glide.with(binding.root).setDefaultRequestOptions(requestOptions).load(media.uri)
                    .thumbnail(0.5f).into(binding.mIVImage)


//                val requestOption = RequestOptions
//                    .overrideOf(300, 300)
//                    .diskCacheStrategy(DiskCacheStrategy.ALL)
//
//                Glide.with(binding.root)
//                    .applyDefaultRequestOptions(requestOption)
//                    .load(media.uri)
//                    .into(binding.mIVImage)

                binding.root.setOnClickListener {
                    mImagePickerListener.onImageClickListener(media)
                }


                for (item in mSelectedList) {
                    if (item.first == media.path) {
                        binding.mTVCount.text = "${item.second}"
                        binding.mTVCount.visibility = View.VISIBLE
                        return
                    } else {
                        binding.mTVCount.visibility = View.GONE
                    }
                }
            }


        }

        private fun setColumnNumber(context: Context): Int {
            val displayMetrics = DisplayMetrics()
            (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getMetrics(
                displayMetrics
            )
            return displayMetrics.widthPixels / 3
        }

        fun clearImage() {
            (binding as? LayoutImageItemBinding)?.mIVImage?.let {
                Glide.with(binding.root).clear(it)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImagePickerViewHolder {
        return if (isSelected) {
            ImagePickerViewHolder(
                LayoutSelectedImageItemBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
            )
        } else {
            ImagePickerViewHolder(
                LayoutImageItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            )
        }
    }

    override fun onBindViewHolder(holder: ImagePickerViewHolder, position: Int) {
        holder.bind(currentList[position])
    }

    override fun onViewRecycled(holder: ImagePickerViewHolder) {
        holder.clearImage()
        super.onViewRecycled(holder)
    }

    fun getSelectedData(mSelectedList: Map<String, Int>) {
        this.mSelectedList.clear()
        this.mSelectedList.addAll(mSelectedList.toList())
        notifyDataSetChanged()
    }
}