package com.natara.photo.collage.maker.bgremover.bottomsheets

import android.R.attr.height
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.FragmentManager
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.bgremover.activity.BgRemoveActivity
import com.natara.photo.collage.maker.bgremover.adapter.BgPagerAdapter
import com.natara.photo.collage.maker.bgremover.fragment.BackgroundApiFragment
import com.natara.photo.collage.maker.bgremover.viewmodel.EditorViewModel
import com.natara.photo.collage.maker.databinding.LayoutBottomSheetBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class BgBottomSheet : BottomSheetDialogFragment() {

    private val mEditorViewModel by lazy {
        EditorViewModel()
    }

    private lateinit var binding: LayoutBottomSheetBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        (dialog as? BottomSheetDialog)?.let {
            it.behavior.peekHeight = requireActivity().resources.getDimension(com.intuit.sdp.R.dimen._200sdp).toInt()
        }

        binding = LayoutBottomSheetBinding.inflate(
            inflater,
            container,
            false
        )


        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        CoroutineScope(Dispatchers.Main).launch {
            loadBackgrounds()
        }
    }

    fun show(fragmentManager: FragmentManager) {
        super.show(fragmentManager, TAG)
    }

    private fun setBgData(bgCategoryList: ArrayList<String>) =
        CoroutineScope(Dispatchers.Main).launch {

            if (bgCategoryList.size == 0) {
                return@launch
            }

            val viewPagerAdapter = BgPagerAdapter(
                childFragmentManager,
                lifecycle,
                bgCategoryList,
                object : BackgroundApiFragment.OnActionCompleteListener {
                    override fun onBackgroundItemClick(path: String?) {

                        if (requireActivity() is BgRemoveActivity) {
                            path?.let {
                                (requireActivity() as BgRemoveActivity).setBgLayout(it)
                            }
                        }
                        dismiss()
                    }

                })

            binding.mViewPager.adapter = viewPagerAdapter

            TabLayoutMediator(
                binding.mTabs, binding.mViewPager, true
            ) { tab, position ->
                tab.setCustomView(R.layout.layout_album_item)
                val textView = tab.customView?.findViewById<TextView>(R.id.mTVAlbum)
                textView?.text = bgCategoryList[position].replace("_", " ")
            }.attach()

            binding.mTabs.addOnTabSelectedListener(object :
                TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab2: TabLayout.Tab) {
                    binding.mViewPager.currentItem = tab2.position
                }

                override fun onTabUnselected(tab2: TabLayout.Tab) {
                }

                override fun onTabReselected(tab2: TabLayout.Tab) {}
            })

            binding.mTabs.setTabRippleColorResource(android.R.color.transparent);

        }

    private fun loadBackgrounds() {

        mEditorViewModel.loadCategoryData()

        mEditorViewModel.bgCategory.observe(viewLifecycleOwner) {
            CoroutineScope(Dispatchers.IO).launch {
                setBgData(it)
            }
        }

        /* mEditorViewModel.getAllBgCategory()?.observe(this) {

             CoroutineScope(Dispatchers.IO).launch {
                 it.forEach { category ->
                     async {
                         if (!bgCategoryList.contains(category)) {
                             bgCategoryList.add(category)
                         }
                     }.await()
                 }
                 withContext(Dispatchers.Main) {
                     setBgData()
                 }
             }

         }*/

    }


    companion object {

        val TAG = BgBottomSheet::class.java.simpleName
        fun newInstance(): BgBottomSheet {
            val fragment = BgBottomSheet()
            val bundle = Bundle()
            fragment.arguments = bundle
            return fragment
        }

    }


}