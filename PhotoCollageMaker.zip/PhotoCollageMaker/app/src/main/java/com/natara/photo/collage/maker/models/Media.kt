package com.natara.photo.collage.maker.models

import android.net.Uri
import java.security.cert.CertPath

data class Media(
    val albumName: String,
    val uri: Uri,
    val path: String,
    val dateAddedSecond: Long,
    var isCorrupted: Boolean
)