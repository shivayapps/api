package com.natara.photo.collage.maker.collage.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.customviews.RecyclerTabLayout
import com.natara.photo.collage.maker.databinding.LayoutTabStickerItemBinding

class StickersTabAdapter(viewPager: ViewPager) :
    RecyclerTabLayout.Adapter<StickersTabAdapter.ViewHolder>(viewPager) {

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        return ViewHolder(
            LayoutTabStickerItemBinding.inflate(
                LayoutInflater.from(viewGroup.context),
                viewGroup,
                false
            )
        )
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {

        viewHolder.bind(i)

    }

    override fun getItemCount(): Int {
        return mViewPager.adapter!!.count
    }

    inner class ViewHolder(private val binding: LayoutTabStickerItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(position: Int) {


            when (position) {
                0 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.bubble
                    )
                )

                1 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.rainbow
                    )
                )

                2 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.cartoon
                    )
                )

                3 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.child
                    )
                )

                4 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.flower
                    )
                )

                5 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.amoji
                    )
                )

                6 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.delicious
                    )
                )

                7 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.hand
                    )
                )

                8 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.popular
                    )
                )

                9 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.valentine
                    )
                )

                10 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.emoj
                    )
                )

                11 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.rage
                    )
                )

                12 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.christmas
                    )
                )

                13 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.unicorn
                    )
                )

                14 -> binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        binding.root.context,
                        R.drawable.sticker
                    )
                )
            }

            binding.image.isSelected = position == currentIndicatorPosition
            binding.viewImage.setBackgroundColor(
                if (position == currentIndicatorPosition) ContextCompat.getColor(
                    binding.root.context,
                    R.color.colorPrimary
                ) else Color.BLACK
            )


            binding.root.setOnClickListener {
                viewPager.currentItem = this@ViewHolder.adapterPosition
            }
        }
    }
}
