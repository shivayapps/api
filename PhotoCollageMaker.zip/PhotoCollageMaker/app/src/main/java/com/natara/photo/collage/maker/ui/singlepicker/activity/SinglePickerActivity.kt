package com.natara.photo.collage.maker.ui.singlepicker.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.android.material.tabs.TabLayoutMediator
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.activities.PhotoCollageActivity
import com.natara.photo.collage.maker.databinding.ActivityCollagePickerBinding
import com.natara.photo.collage.maker.databinding.ActivityImagePickerBinding
import com.natara.photo.collage.maker.models.Media
import com.natara.photo.collage.maker.ui.picker.utils.Status
import com.natara.photo.collage.maker.ui.singlepicker.adapter.SingleImagePagerAdapter
import com.natara.photo.collage.maker.viewmodels.ImagePickerViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SinglePickerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCollagePickerBinding

    private val viewModel: ImagePickerViewModel by viewModels()

    companion object {
        const val KEY_DATA_RESULT = "KEY_DATA_RESULT"
        val _mSingleSelection: MutableLiveData<List<Media>> = MutableLiveData()
        val mSingleSelectionList: LiveData<List<Media>> = _mSingleSelection
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding =
            DataBindingUtil.inflate(layoutInflater, R.layout.activity_collage_picker, null, false)
        setContentView(binding.root)
        binding.mCVBottom.visibility = View.GONE
        binding.mToolBar.mTVSave.text = "Select"
        loadData()

        binding.mToolBar.mTVSave.setOnClickListener {
            if (!mSingleSelectionList.value.isNullOrEmpty()) {
                intent.putStringArrayListExtra(
                    KEY_DATA_RESULT,
                    mSingleSelectionList.value!!.map {
                        it.path
                    } as ArrayList<String>
                )
                setResult(RESULT_OK,intent)
                finish()
            } else {
                Toast.makeText(this, "Please select image", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun loadData() {
        CoroutineScope(Dispatchers.Main).launch {
            viewModel.getMediaList(this@SinglePickerActivity).observe(this@SinglePickerActivity) {

                when (it.status) {

                    Status.SUCCESS -> {

                        it.data?.let { data ->
                            binding.mVPImageList.adapter =
                                SingleImagePagerAdapter(supportFragmentManager, lifecycle, data)

                            TabLayoutMediator(
                                binding.mTBAlbumList,
                                binding.mVPImageList
                            ) { tab, position ->
                                tab.setCustomView(R.layout.layout_album_item)
                                val textView = tab.customView?.findViewById<TextView>(R.id.mTVAlbum)
                                textView?.text = data[position].name
                            }.attach()

                            binding.mProgressBar.visibility = View.GONE
                        }


                    }

                    Status.ERROR -> {

                    }

                    Status.LOADING -> {
                        binding.mProgressBar.visibility = View.VISIBLE
                    }

                }
            }
        }
    }

    private fun removeImage(media: Media) {
        val list = _mSingleSelection.value
        val newList = arrayListOf<Media>()
        if (!list.isNullOrEmpty()) {
            newList.addAll(list)
        }
        newList.remove(media)
        _mSingleSelection.value = newList
    }
}