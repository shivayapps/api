package com.natara.photo.collage.maker.ui.language.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.natara.photo.collage.maker.databinding.SingleLanguageBinding
import com.natara.photo.collage.maker.diffutils.DiffUtilsCallBacks
import com.natara.photo.collage.maker.extentions.defaultLanguage
import com.natara.photo.collage.maker.extentions.hide
import com.natara.photo.collage.maker.extentions.show
import com.natara.photo.collage.maker.ui.language.model.LanguageModel

class LanguageAdapter(var languageClickListener: LanguageClickListener) :
    ListAdapter<LanguageModel, LanguageAdapter.ItemViewHolder>(DiffUtilsCallBacks.DiffCallbackLanguage()) {


    var selectedItemPos = defaultLanguage
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    var lastItemSelectedPos = defaultLanguage

    interface LanguageClickListener {
        fun languageItemClick(item: LanguageModel)
    }

    inner class ItemViewHolder(private val binding: SingleLanguageBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: LanguageModel, position: Int) =
            with(itemView) {

                with(binding) {
                    mTVLanguage.text = item.name
                    Glide.with(root.context).load(item.flag).circleCrop().into(mIVCountry)
                }

                setOnClickListener {
                    selectedItemPos = item.code
                    lastItemSelectedPos = if (lastItemSelectedPos == defaultLanguage)
                        selectedItemPos
                    else {
                        notifyItemChanged(position)
                        selectedItemPos
                    }
                    notifyItemChanged(position)
                    languageClickListener.languageItemClick(item)
                }
            }

        fun selectedBg() = binding.mIVSelection.show()

        fun defaultBg() = binding.mIVSelection.hide()
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            SingleLanguageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {

        if (getItem(position).code == selectedItemPos)
            holder.selectedBg()
        else
            holder.defaultBg()

        holder.bind(getItem(position), position)
    }

}