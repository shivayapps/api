package com.natara.photo.collage.maker.ui.pixlab.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.natara.photo.collage.maker.databinding.FramesItemBinding
import com.natara.photo.collage.maker.diffutils.DiffUtilsCallBacks
import com.natara.photo.collage.maker.extentions.setThumbnail
import com.natara.photo.collage.maker.ui.pixlab.model.StylesModel

class StylesAdapter(
    private var onFilterClick: OnFilterFrame,
) : ListAdapter<StylesModel, StylesAdapter.ViewHolder>(DiffUtilsCallBacks.DiffCallbackStyles()) {

    var selectedFrame: String? = ""
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    interface OnFilterFrame {
        fun onClickFrame(position: Int, item: StylesModel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            FramesItemBinding.inflate(LayoutInflater.from(parent.context))
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(currentList[position])
    }

    inner class ViewHolder(private val binding: FramesItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: StylesModel) {

            binding.selectIV.visibility = View.GONE

            item.image?.let { binding.frameIV.setThumbnail(binding.root.context, it) }

            binding.frameIV.setOnClickListener {
                onFilterClick.onClickFrame(adapterPosition, item)
            }
        }
    }

}