package com.natara.photo.collage.maker.ui.pixlab.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.databinding.SinglePatternBinding
import com.natara.photo.collage.maker.diffutils.DiffUtilsCallBacks
import com.natara.photo.collage.maker.extentions.hide
import com.natara.photo.collage.maker.extentions.show

class PixLabAdapter(var patternClickListener: PatternClickListener) :
    ListAdapter<String, PixLabAdapter.ItemViewHolder>(DiffUtilsCallBacks.DiffCallbackGradient()) {

    var selectedItemPos = ""
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    var lastItemSelectedPos = ""

    interface PatternClickListener {
        fun patternItemClick(position: Int)
    }

    inner class ItemViewHolder(private val binding: SinglePatternBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(pattern: String, position: Int) =
            with(itemView) {

                with(binding) {

                    mCardFilter.setCardBackgroundColor(
                        ContextCompat.getColor(
                            root.context,
                            R.color.colorAccent
                        )
                    )

                    if (position == 0 && pattern == "") {
                        colorSelectionIndicator.hide()
                        with(colorHoldingImageView) {
                            this.scaleType = ImageView.ScaleType.FIT_CENTER
                            val padding =
                                context.resources.getDimension(com.intuit.sdp.R.dimen._6sdp).toInt()
                            this.setPadding(padding, padding, padding, padding)
                            setImageResource(R.drawable.ic_photo_gallery)
                        }
                    } else if (position == 1 && pattern == "") {
                        colorSelectionIndicator.hide()
                        with(colorHoldingImageView) {
                            this.scaleType = ImageView.ScaleType.FIT_CENTER
                            val padding =
                                context.resources.getDimension(com.intuit.sdp.R.dimen._6sdp)
                                    .toInt()
                            this.setPadding(padding, padding, padding, padding)
                            setImageResource(R.drawable.ic_shop)
                        }
                    } else {

                        with(colorHoldingImageView) {
                            this.scaleType = ImageView.ScaleType.CENTER_CROP
                            Glide.with(this).load(pattern)
                                .diskCacheStrategy(
                                    DiskCacheStrategy.AUTOMATIC
                                ).into(this)
                        }
                    }
                }

                setOnClickListener {
                    if (pattern != "") {
                        selectedItemPos = pattern
                        if (lastItemSelectedPos == "") {
                            lastItemSelectedPos = selectedItemPos
                        } else {
                            notifyItemChanged(currentList.indexOf(lastItemSelectedPos))
                            lastItemSelectedPos = selectedItemPos
                        }
                        notifyItemChanged(currentList.indexOf(selectedItemPos))
                    }

                    patternClickListener.patternItemClick(position)
                }
            }

        fun selectedBg() = binding.colorSelectionIndicator.show()

        fun defaultBg() = binding.colorSelectionIndicator.hide()
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            SinglePatternBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {

        holder.setIsRecyclable(false)

        if (getItem(position) == selectedItemPos)
            holder.selectedBg()
        else
            holder.defaultBg()

        holder.bind(getItem(position), position)
    }

}