package com.natara.photo.collage.maker.picker.builder.listener

import android.net.Uri

interface OnImageSelectionListener {
    fun onSelectionUpdate(images: Uri?)
}