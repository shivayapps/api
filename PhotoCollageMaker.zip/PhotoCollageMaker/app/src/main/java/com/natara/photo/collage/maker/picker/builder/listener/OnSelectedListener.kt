package com.natara.photo.collage.maker.picker.builder.listener

import android.net.Uri

interface OnSelectedListener {
    fun onSelected(uri: Uri)
}