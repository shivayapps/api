package com.natara.photo.collage.maker.collage.events;

import android.view.MotionEvent;

import com.natara.photo.collage.maker.collage.customviews.NataraStickerView;

public class ZoomIconEvent implements StickerIconEvent {
    public void onActionDown(NataraStickerView paramStickerView, MotionEvent paramMotionEvent) {
    }

    public void onActionMove(NataraStickerView paramStickerView, MotionEvent paramMotionEvent) {
        paramStickerView.zoomAndRotateCurrentSticker(paramMotionEvent);
    }

    public void onActionUp(NataraStickerView paramStickerView, MotionEvent paramMotionEvent) {
        if (paramStickerView.getOnStickerOperationListener() != null)
            paramStickerView.getOnStickerOperationListener().onStickerZoom(paramStickerView.getCurrentSticker());
    }
}
