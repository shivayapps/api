package com.natara.photo.collage.maker.ui.pixlab.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.natara.photo.collage.maker.ui.pixlab.model.StylesModel

class StylesViewModel : ViewModel() {

    private val _stylesCategory = MutableLiveData<ArrayList<String>>()
    val stylesCategory: LiveData<ArrayList<String>> = _stylesCategory

    private val _stylesItem = MutableLiveData<ArrayList<StylesModel>>()
    val styleItemList: LiveData<ArrayList<StylesModel>> = _stylesItem

    fun loadCategoryData() {

        val db = Firebase.firestore
        db.collection("pix_lab")
            .get()
            .addOnSuccessListener { result ->

                result.forEach {
                    it.data.forEach { (t, u) ->
                        _stylesCategory.value = u as ArrayList<String>?
                    }
                }
            }
            .addOnFailureListener { exception ->
                Log.w("TAG", "Error getting documents.", exception)
            }
    }

    fun loadCategoryItem(item: String) {
        val db = Firebase.firestore
        db.collection("pix_lab")
            .document("styles")
            .collection(item)
            .get()
            .addOnSuccessListener { result ->

                val list  =  result.documents.mapNotNull {  doc ->
                    doc.toObject(StylesModel::class.java)
                }.toList() as ArrayList<StylesModel>
                _stylesItem.value = list
            }
    }

}