package com.natara.photo.collage.maker.ui.intro.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.natara.photo.collage.maker.databinding.ActivityIntroBinding
import com.natara.photo.collage.maker.ui.intro.adapter.HomeViewPagerAdapter
import com.natara.photo.collage.maker.ui.intro.fragment.IntroFourFragment
import com.natara.photo.collage.maker.ui.intro.fragment.IntroOneFragment
import com.natara.photo.collage.maker.ui.intro.fragment.IntroThreeFragment
import com.natara.photo.collage.maker.ui.intro.fragment.IntroTwoFragment

class IntroActivity : AppCompatActivity() {
    lateinit var binding: ActivityIntroBinding
    private lateinit var mHomeAdapter: HomeViewPagerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIntroBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setUpViewPager()
    }

    private fun setUpViewPager() {
        binding.viewPager.adapter = HomeViewPagerAdapter(this).apply {
            addFragments(IntroOneFragment())
            addFragments(IntroTwoFragment())
            addFragments(IntroThreeFragment())
            addFragments(IntroFourFragment())
            mHomeAdapter = this
        }
    }

}