package com.natara.photo.collage.maker.picker.helper

import android.net.Uri
import java.util.*

object Constant {
    var lastSelectedURI: Uri? = null
    var lastSelectedPosition: Int = -1
    var selectedImage: List<Uri> = ArrayList<Uri>()
    @JvmField
    var scaleFactor:Float = 1f

}