package com.natara.photo.collage.maker.ui.picker.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.databinding.FragmentImagePickerBinding
import com.natara.photo.collage.maker.models.Media
import com.natara.photo.collage.maker.ui.picker.activity.CollagePickerActivity
import com.natara.photo.collage.maker.ui.picker.adapters.ImagePickerAdapter
import com.natara.photo.collage.maker.viewmodels.ImagePickerViewModel

class ImageFolderFragment(private val images: List<Media>) : Fragment() {

    private lateinit var binding: FragmentImagePickerBinding
    private val viewModel: ImagePickerViewModel by viewModels()

    private val mImagePickerAdapter by lazy {
        ImagePickerAdapter(object : ImagePickerAdapter.ImagePickerListener {
            override fun onImageClickListener(media: Media) {
                if (!CollagePickerActivity.mImageSelectedList.value.isNullOrEmpty()) {
                    if (CollagePickerActivity.mImageSelectedList.value!!.size > 8) {
                        Toast.makeText(requireContext(), "Select Between 2 - 9", Toast.LENGTH_SHORT).show()
                        return
                    }
                }
                setImage(media)
            }

            override fun onImageRemoveClickListener(media: Media) {

            }

        })
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_image_picker, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.mRVImages.adapter = mImagePickerAdapter

        mImagePickerAdapter.submitList(images)

        // Observe the LiveData and perform grouping when the data changes
        CollagePickerActivity.mImageSelectedList.observe(viewLifecycleOwner) { mediaList ->
            val pathCountMap: Map<String, Int> = mediaList
                .groupBy { it.path }
                .mapValues { it.value.size }
            mImagePickerAdapter.getSelectedData(pathCountMap)
        }

    }

    private fun setImage(media: Media) {
        val list = CollagePickerActivity._mImageSelectedList.value
        val newList = arrayListOf<Media>()
        if (!list.isNullOrEmpty()) {
            newList.addAll(list)
        }
        newList.add(media)
        CollagePickerActivity._mImageSelectedList.value = newList
    }
}
