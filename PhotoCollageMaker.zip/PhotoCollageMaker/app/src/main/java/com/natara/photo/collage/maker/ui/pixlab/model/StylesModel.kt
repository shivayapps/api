package com.natara.photo.collage.maker.ui.pixlab.model

import java.io.Serializable


data class StylesModel(
    val id: String?,
    val path: String?,
    val image: String?,
    val pro: Boolean?,
    val lock: Boolean?,
    val sub_category: String?
): Serializable {
    constructor() : this("", "", "", false, false, "")
}