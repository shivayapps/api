package com.natara.photo.collage.maker.utils;

public enum FlipDirection {
    VERTICAL,
    HORIZONTAL
}
