package com.natara.photo.collage.maker.ui.start

import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.natara.photo.collage.maker.CollageMaker
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.databinding.ActivityStartBinding
import com.natara.photo.collage.maker.extentions.show
import com.natara.photo.collage.maker.ui.home.activity.MainActivity
import com.natara.photo.collage.maker.ui.intro.activity.IntroActivity
import com.natara.photo.collage.maker.ui.language.activity.LanguageActivity

class StartActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStartBinding
    private var countDownTimer: CountDownTimer? = null
    private var secondsRemaining: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        animateFrame()

        animateFrame()
        startProgress(5000L)
        createTimer(5000L)
    }

    private fun createTimer(time: Long) {
        countDownTimer =
            object : CountDownTimer(time, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                }

                override fun onFinish() {
                    binding.mLPStart.progress = 100
                    secondsRemaining = 0
                    startMainActivity()
                }
            }
        countDownTimer?.start()
    }

    private fun animateFrame() {

        val animation = AnimationUtils.loadAnimation(
            applicationContext, R.anim.rotate
        )
        binding.mIVLogo.startAnimation(animation)
        animation.duration = 2000
        animation.repeatMode = 0
        animation.repeatCount = 1

        Handler(Looper.getMainLooper()).postDelayed({
            binding.mTVLogo.show()
            val fadeIn = ObjectAnimator.ofFloat(binding.mTVLogo, "alpha", 0f, 1f)
            fadeIn.duration = 1500 // Set animation duration in milliseconds
            fadeIn.start() // Start the animation
        }, 1500)
    }

    private fun startProgress(time: Long) {
        binding.mLPStart.max = 100

        object : CountDownTimer(time, 10) {
            override fun onTick(millisUntilFinished: Long) {
                val progress = (time - millisUntilFinished) * 100 / time
                binding.mLPStart.progress = progress.toInt()
            }

            override fun onFinish() {
                // Perform action after progress completes
                binding.mLPStart.setProgress(100, true)
            }
        }.start()
    }

    fun startMainActivity() {
        val intent = if (CollageMaker.prefManager?.needToShowLanguage == true) {
            Intent(this, LanguageActivity::class.java)
        } else if (CollageMaker.prefManager?.needToShowIntro == true) {
            Intent(this, IntroActivity::class.java)
        } else {
            Intent(this, MainActivity::class.java)
        }
        startActivity(intent)
        Handler(Looper.getMainLooper()).postDelayed({
            finish()
        }, 50)
    }

}