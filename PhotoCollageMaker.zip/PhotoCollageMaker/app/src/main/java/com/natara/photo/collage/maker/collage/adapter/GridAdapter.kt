package com.natara.photo.collage.maker.collage.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.adapter.GridAdapter.GridViewHolder
import com.natara.photo.collage.maker.collage.customviews.grid.NataraLayout
import com.natara.photo.collage.maker.collage.customviews.layers.slant.NumberSlantLayout
import com.natara.photo.collage.maker.collage.customviews.layers.straight.NumberStraightLayout
import com.natara.photo.collage.maker.collage.utils.CustomDiffUtils.SQUARE_LAYOUT_DIFF
import com.natara.photo.collage.maker.databinding.LayoutCollageItemBinding

class GridAdapter(var onItemClickListener: OnItemClickListener) :
    ListAdapter<NataraLayout, GridViewHolder>(SQUARE_LAYOUT_DIFF) {
    var selectedIndex = 0

    interface OnItemClickListener {
        fun onItemClick(puzzleLayout: NataraLayout)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): GridViewHolder {
        return GridViewHolder(
            LayoutCollageItemBinding.inflate(
                LayoutInflater.from(viewGroup.context),
                viewGroup,
                false
            )
        )
    }

    override fun onBindViewHolder(collageViewHolder: GridViewHolder, i: Int) {
        val collageLayout = currentList[i]
        collageViewHolder.bind(collageLayout, i)
    }

    override fun getItemCount(): Int {
        return currentList.size
    }

    inner class GridViewHolder(private val binding: LayoutCollageItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(collageLayout: NataraLayout, position: Int) {
            binding.squareCollageView.setNeedDrawLine(true)
            binding.squareCollageView.setNeedDrawOuterLine(true)
            binding.squareCollageView.setTouchEnable(false)
            binding.squareCollageView.setLineSize(6)
            binding.squareCollageView.queShotLayout = collageLayout
            if (selectedIndex == position) {
                binding.squareCollageView.setBackgroundColor(Color.parseColor("#1B6EF3"))
            } else {
                binding.squareCollageView.setBackgroundColor(
                    ContextCompat.getColor(
                        binding.root.context,
                        R.color.cropItem
                    )
                )
            }
            binding.root.setOnClickListener {
                onItemClickListener.onItemClick(collageLayout)
                selectedIndex = position
                notifyDataSetChanged()
            }
        }

    }
}
