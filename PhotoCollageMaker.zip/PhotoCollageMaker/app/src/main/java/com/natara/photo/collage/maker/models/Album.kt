package com.natara.photo.collage.maker.models

import android.net.Uri
import com.natara.photo.collage.maker.models.Media

data class Album(
    val name: String,
    val thumbnailUri: Uri,
    val mediaUris: List<Media>
) {
    val mediaCount: Int = mediaUris.size
}