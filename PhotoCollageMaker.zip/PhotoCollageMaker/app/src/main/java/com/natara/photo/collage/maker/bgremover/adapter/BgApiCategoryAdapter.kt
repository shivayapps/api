package com.natara.photo.collage.maker.bgremover.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.natara.photo.collage.maker.bgremover.model.BackgroundEntity
import com.natara.photo.collage.maker.databinding.BgItemBinding
import com.natara.photo.collage.maker.diffutils.DiffUtilsCallBacks
import com.natara.photo.collage.maker.extentions.setThumbnail

class BgApiCategoryAdapter(
    private var onFilterClick: OnFilterFrame
) : ListAdapter<BackgroundEntity, BgApiCategoryAdapter.ViewHolder>(DiffUtilsCallBacks.DiffCallbackBackgroundEntity()) {



    interface OnFilterFrame {
        fun onClickFrame(item: BackgroundEntity)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            BgItemBinding.inflate(LayoutInflater.from(parent.context))
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(currentList[position])
    }

    inner class ViewHolder(private val binding: BgItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: BackgroundEntity) {

            binding.selectIV.visibility = View.GONE

            item.image?.let { binding.frameIV.setThumbnail(binding.root.context, it) }

            binding.frameIV.setOnClickListener {
                onFilterClick.onClickFrame(item)
            }
        }
    }

}