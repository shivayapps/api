package com.natara.photo.collage.maker.collage.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.MediaScannerConnection
import android.media.MediaScannerConnection.MediaScannerConnectionClient
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.customviews.NataraGridView
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream

object SaveFileUtils {
    private val isExternalStorageWritable: Boolean
        private get() = Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED

    fun saveBitmapFileCollage(context: Context, bitmap: Bitmap, name: String): File? {
        if (Build.VERSION.SDK_INT >= 29) {
            val isWritable = isExternalStorageWritable
            var imagesRelPath: String? = null
            if (isWritable) {
                var fos: FileOutputStream? = null
                try {
                    val relativePath = Environment.DIRECTORY_PICTURES + File.separator + ContextCompat.getString(context, R.string.app_name)
                    val resolver = context.contentResolver
                    val contentValues = ContentValues()
                    contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                    val contUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                    imagesRelPath = FilePathUtil.getPath(context, contUri)
                    fos = resolver.openOutputStream(contUri!!) as FileOutputStream?
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos!!)
                    fos.flush()
                } catch (e: Exception) {
                    val err = e.message
                } finally {
                    fos?.close()
                }
            }
            return if (imagesRelPath != null) File(imagesRelPath) else null
        }
        val imagesDir2 = Environment.getExternalStorageDirectory().toString() + File.separator + Environment.DIRECTORY_PICTURES + File.separator + ContextCompat.getString(context, R.string.app_name)
        val file2 = File(imagesDir2)
        if (!file2.exists()) {
            file2.mkdir()
        }
        val image = File(imagesDir2, "$name.png")
        val fos2: OutputStream = FileOutputStream(image)
        MediaScannerConnection.scanFile(
            context,
            arrayOf(image.absolutePath),
            null as Array<String?>?,
            object : MediaScannerConnectionClient {
                override fun onMediaScannerConnected() {}
                override fun onScanCompleted(path: String, uri: Uri) {}
            })
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos2)
        fos2.flush()
        fos2.close()
        return image
    }

    fun createBitmap(quShotCollageView: NataraGridView, i: Int): Bitmap {
        quShotCollageView.clearHandling()
        quShotCollageView.invalidate()
        val createBitmap = Bitmap.createBitmap(
            i,
            (i.toFloat() / (quShotCollageView.width.toFloat() / quShotCollageView.height.toFloat())).toInt(),
            Bitmap.Config.ARGB_8888
        )
        quShotCollageView.draw(Canvas(createBitmap))
        return createBitmap
    }

    fun createBitmap(quShotCollageView: NataraGridView): Bitmap {
        quShotCollageView.clearHandling()
        quShotCollageView.invalidate()
        val createBitmap = Bitmap.createBitmap(
            quShotCollageView.width,
            quShotCollageView.height,
            Bitmap.Config.ARGB_8888
        )
        quShotCollageView.draw(Canvas(createBitmap))
        return createBitmap
    }
}