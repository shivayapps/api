package com.natara.photo.collage.maker.ui.settings.activity

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.natara.photo.collage.maker.databinding.ActivitySettingsBinding
import com.natara.photo.collage.maker.extentions.disableNew
import com.natara.photo.collage.maker.extentions.enable
import com.natara.photo.collage.maker.extentions.hide
import com.natara.photo.collage.maker.extentions.rateApp
import com.natara.photo.collage.maker.extentions.shareOwnApp

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initView()
        initListeners()
    }

    private fun initView() {
        binding.mToolBar.mTVTitle.text = "Settings"
        binding.mToolBar.mTVSave.hide()
        binding.mToolBar.mIVBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun initListeners() {

        binding.mCLShare.setOnClickListener {
            binding.mCLShare.disableNew()
            Handler(Looper.getMainLooper()).postDelayed({
                binding.mCLShare.enable()
            }, 3000)
            shareOwnApp()
        }

        binding.mCLUpdate.setOnClickListener {
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("market://details?id=${packageName}")
                    )
                )
            } catch (anfe: ActivityNotFoundException) {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=${packageName}")
                    )
                )
            }
        }

        binding.mCLRate.setOnClickListener {
            rateApp()
        }
    }
}