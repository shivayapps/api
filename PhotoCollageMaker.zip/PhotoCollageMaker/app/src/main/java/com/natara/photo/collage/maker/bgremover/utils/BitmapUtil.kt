package com.natara.photo.collage.maker.bgremover.utils

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.graphics.*
import android.media.ExifInterface
import android.net.Uri
import java.io.*


class BitmapUtil {

    fun getBitmapFormUri(ac: Activity, uri: Uri?): Bitmap? {
        var input: InputStream? = ac.contentResolver.openInputStream(uri!!)
        val onlyBoundsOptions = BitmapFactory.Options()
        onlyBoundsOptions.inJustDecodeBounds = true
        onlyBoundsOptions.inDither = true //optional
        onlyBoundsOptions.inPreferredConfig = Bitmap.Config.ARGB_8888 //optional
        BitmapFactory.decodeStream(input, null, onlyBoundsOptions)
        input?.close()
        val originalWidth = onlyBoundsOptions.outWidth
        val originalHeight = onlyBoundsOptions.outHeight
        if (originalWidth == -1 || originalHeight == -1) return null
        //Image resolution is based on 480x800
        val hh = 2000 //The height is set as 800f here
        val ww = 2000 //Set the width here to 480f
        //Zoom ratio. Because it is a fixed scale, only one data of height or width is used for calculation
        var be = 1 //be=1 means no scaling
        if (originalWidth > originalHeight && originalWidth > ww) { //If the width is large, scale according to the fixed size of the width
            be = (originalWidth / ww).toInt()
        } else if (originalWidth < originalHeight && originalHeight > hh) { //If the height is high, scale according to the fixed size of the width
            be = (originalHeight / hh).toInt()
        }
        if (be <= 0) be = 1
        //Proportional compression
        val bitmapOptions = BitmapFactory.Options()
        bitmapOptions.inSampleSize = be //Set scaling
        bitmapOptions.inDither = true //optional
        bitmapOptions.inPreferredConfig = Bitmap.Config.ARGB_8888 //optional
        input = ac.contentResolver.openInputStream(uri)
        val bitmap = BitmapFactory.decodeStream(input, null, bitmapOptions)
        input?.close()
        return (bitmap!!) //Mass compression again
    }

    fun compressImage(image: Bitmap): Bitmap? {
        val baos = ByteArrayOutputStream()
        image.compress(
            Bitmap.CompressFormat.JPEG,
            100,
            baos
        ) //Quality compression method, here 100 means no compression, store the compressed data in the BIOS
        var options = 100
        while (baos.toByteArray().size / 1024 > 1024) {  //Cycle to determine if the compressed image is greater than 100kb, greater than continue compression
            baos.reset() //Reset the BIOS to clear it
            //First parameter: picture format, second parameter: picture quality, 100 is the highest, 0 is the worst, third parameter: save the compressed data stream
            image.compress(
                Bitmap.CompressFormat.JPEG,
                options,
                baos
            ) //Here, the compression options are used to store the compressed data in the BIOS
            options -= 10 //10 less each time
        }
        val isBm =
            ByteArrayInputStream(baos.toByteArray()) //Store the compressed data in ByteArrayInputStream
        return BitmapFactory.decodeStream(
            isBm,
            null,
            null
        ) //Generate image from ByteArrayInputStream data
    }

    fun getBitmapDegree(path: String?): Int {
        var degree = 0
        try {
            // Read the picture from the specified path and obtain its EXIF information
            val exifInterface = ExifInterface(path!!)
            // Get rotation information for pictures
            val orientation: Int = exifInterface.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> degree = 90
                ExifInterface.ORIENTATION_ROTATE_180 -> degree = 180
                ExifInterface.ORIENTATION_ROTATE_270 -> degree = 270
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return degree
    }

    @SuppressLint("Range")
    fun getFileFromMediaUri(ac: Context, uri: Uri): File? {
        if (uri.scheme.toString().compareTo("content") == 0) {
            val cr: ContentResolver = ac.getContentResolver()
            val cursor: Cursor? =
                cr.query(uri, null, null, null, null) // Find from database according to Uri
            if (cursor != null) {
                cursor.moveToFirst()
                val filePath: String =
                    cursor.getString(cursor.getColumnIndex("_data")) // Get picture path
                cursor.close()
                if (filePath != null) {
                    return File(filePath)
                }
            }
        } else if (uri.scheme.toString().compareTo("file") == 0) {
            return File(uri.toString().replace("file://", ""))
        }
        return null
    }

    fun rotateBitmapByDegree(bm: Bitmap, degree: Int): Bitmap {
        var returnBm: Bitmap? = null

        // Generate rotation matrix according to rotation angle
        val matrix = Matrix()
        matrix.postRotate(degree.toFloat())
        try {
            // Rotate the original image according to the rotation matrix and get a new image
            returnBm = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, matrix, true)
        } catch (e: OutOfMemoryError) {
        }
        if (returnBm == null) {
            returnBm = bm
        }
        if (bm != returnBm) {
            bm.recycle()
        }
        return returnBm
    }

    fun drawLines(src:Bitmap,size:Int):Bitmap{
        // create new bitmap, which will be painted and becomes result image
        val bmOut = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)

        for (i in 0 until size){
            val canvas = Canvas(bmOut)
            // setup default color
//            canvas.drawColor(0, PorterDuff.Mode.CLEAR)
            // create a blur paint for capturing alpha
            val ptBlur = Paint()
//            ptBlur.alpha = (size-i)/10
            // ptBlur.maskFilter = BlurMaskFilter(radius, Blur.NORMAL)
            val offsetXY = IntArray(2)
            // capture alpha into a bitmap
            val bmAlpha = src.extractAlpha(ptBlur, offsetXY)
            // create a color paint
            val ptAlphaColor = Paint()
            // paint color for captured alpha region (bitmap)
            canvas.drawBitmap(bmAlpha, offsetXY[0].toFloat()+50, offsetXY[1].toFloat()+50, ptAlphaColor)
            // free memory
            bmAlpha.recycle()

            // paint the image source
            canvas.drawBitmap(src, i.toFloat()+50, i.toFloat()+50, null)
        }
        // setup canvas for painting


        // return out final image
        return bmOut
    }

    fun highlightImage(src: Bitmap,color:Int,size:Int,radius:Float): Bitmap? {
        // create new bitmap, which will be painted and becomes result image
        val bmOut = Bitmap.createBitmap(src.width + size, src.height + size, Bitmap.Config.ARGB_8888)
        // setup canvas for painting
        val canvas = Canvas(bmOut)
        // setup default color
        canvas.drawColor(0, PorterDuff.Mode.CLEAR)
        // create a blur paint for capturing alpha
        val ptBlur = Paint()
//        ptBlur.maskFilter = BlurMaskFilter(radius, Blur.NORMAL)
        val offsetXY = IntArray(2)
        // capture alpha into a bitmap
        val bmAlpha = src.extractAlpha(ptBlur, offsetXY)
        // create a color paint
        val ptAlphaColor = Paint()
        ptAlphaColor.color = color
        // paint color for captured alpha region (bitmap)
        canvas.drawBitmap(bmAlpha, offsetXY[0].toFloat(), offsetXY[1].toFloat(), ptAlphaColor)
        // free memory
        bmAlpha.recycle()

        // paint the image source
        canvas.drawBitmap(src, 0f, 0f, null)

        // return out final image
        return bmOut
    }


}