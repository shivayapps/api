package com.natara.photo.collage.maker.collage.events;

import android.view.MotionEvent;

import com.natara.photo.collage.maker.collage.customviews.NataraStickerView;


public interface StickerIconEvent {
    void onActionDown(NataraStickerView paramStickerView, MotionEvent paramMotionEvent);

    void onActionMove(NataraStickerView paramStickerView, MotionEvent paramMotionEvent);

    void onActionUp(NataraStickerView paramStickerView, MotionEvent paramMotionEvent);
}
