package com.natara.photo.collage.maker.collage.adapter

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintSet
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.natara.photo.collage.maker.collage.models.MediaItemObj
import com.natara.photo.collage.maker.databinding.SingleCreationBinding
import com.natara.photo.collage.maker.diffutils.DiffUtilsCallBacks
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ViewPagerAdapter :
    ListAdapter<MediaItemObj, ViewPagerAdapter.ItemViewHolder>(DiffUtilsCallBacks.DiffCallbackCreation()) {


    inner class ItemViewHolder(private val binding: SingleCreationBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(mediaItem: MediaItemObj) = CoroutineScope(Dispatchers.Main).launch {

            with(itemView) {
                with(binding) {
                    with(mIVImage) {
                        Glide.with(this)
                            .asBitmap()
                            .load(mediaItem.path).listener(object : RequestListener<Bitmap> {
                                override fun onLoadFailed(
                                    e: GlideException?,
                                    model: Any?,
                                    target: Target<Bitmap>,
                                    isFirstResource: Boolean,
                                ): Boolean {
                                    return false
                                }

                                override fun onResourceReady(
                                    resource: Bitmap,
                                    model: Any,
                                    target: Target<Bitmap>?,
                                    dataSource: DataSource,
                                    isFirstResource: Boolean,
                                ): Boolean {

                                    val constraintSet = ConstraintSet()
                                    constraintSet.clone(mCLRoot)
                                    constraintSet.setDimensionRatio(
                                        mCVImage.id,
                                        "${resource.width}:${resource.height}"
                                    )
                                    constraintSet.applyTo(mCLRoot)
                                    return false
                                }

                            })
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(this)
                    }
                }
            }

        }

    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            SingleCreationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

}

