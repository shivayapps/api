package com.natara.photo.collage.maker.ui.intro.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class HomeViewPagerAdapter(fragmentActivity: FragmentActivity) :
    FragmentStateAdapter(fragmentActivity) {

    private var mFragmentList = mutableListOf<Fragment>()

    override fun getItemCount(): Int = mFragmentList.size

    override fun createFragment(position: Int): Fragment {
        return mFragmentList[position]
    }

    fun addFragments(fragment: Fragment) {
        mFragmentList.add(fragment)
    }

    fun getFragment(position: Int): Fragment {
        return mFragmentList[position]
    }

}