package com.natara.photo.collage.maker.collage.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.natara.photo.collage.maker.collage.models.CollageModels
import com.natara.photo.collage.maker.collage.utils.CustomDiffUtils.SQUARE_DIFF
import com.natara.photo.collage.maker.databinding.LayoutBackgroundItemsBinding

class CollageBackgroundAdapter(var backgroundListener: BackgroundGridListener) :
    ListAdapter<CollageModels.SquareView, CollageBackgroundAdapter.ViewHolder>(SQUARE_DIFF) {

    var selectedIndex = 0

    interface BackgroundGridListener {
        fun onBackgroundSelected(i: Int, squareView: CollageModels.SquareView)
    }


    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        return ViewHolder(
            LayoutBackgroundItemsBinding.inflate(
                LayoutInflater.from(viewGroup.context),
                viewGroup,
                false
            )
        )
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {
        val squareView = currentList[i]
        viewHolder.bind(squareView, i)
    }

    override fun getItemCount(): Int {
        return currentList.size
    }

    inner class ViewHolder(private val binding: LayoutBackgroundItemsBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(squareView: CollageModels.SquareView, position: Int) {

            binding.imageViewSquare.visibility = View.GONE

            if (squareView.isColor) {
                binding.squareView.setBackgroundColor(squareView.drawableId)
            } else if (squareView.drawable != null) {
                binding.squareView.visibility = View.GONE
                binding.imageViewSquare.visibility = View.VISIBLE
                binding.imageViewSquare.setImageDrawable(squareView.drawable)
            } else {
                binding.squareView.setBackgroundResource(squareView.drawableId)
            }
            if (selectedIndex == position) {
                binding.viewSelected.visibility = View.VISIBLE
            } else {
                binding.viewSelected.visibility = View.GONE
            }

            binding.root.setOnClickListener {
                selectedIndex = adapterPosition
                backgroundListener.onBackgroundSelected(
                    selectedIndex,
                    squareView
                )
                notifyDataSetChanged()
            }

        }
    }
}
