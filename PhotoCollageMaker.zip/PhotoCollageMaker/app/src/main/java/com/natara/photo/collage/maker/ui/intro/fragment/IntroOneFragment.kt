package com.natara.photo.collage.maker.ui.intro.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.natara.photo.collage.maker.databinding.FragmentIntroOneBinding
import com.natara.photo.collage.maker.ui.intro.activity.IntroActivity

class IntroOneFragment : Fragment() {

    lateinit var binding: FragmentIntroOneBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentIntroOneBinding.inflate(inflater, container, false)
//        Glide.with(this).load(R.drawable.intro_1).into(binding.mIVImage)

        binding.mTVText.text = "Get Daily Motivational quotes to\ninspire you."
        binding.mTVBtn.setOnClickListener {
            (requireActivity() as IntroActivity).binding.viewPager.setCurrentItem(1, true)
        }
        return binding.root
    }

}