package com.natara.photo.collage.maker.collage.utils

import android.annotation.SuppressLint
import androidx.recyclerview.widget.DiffUtil
import com.natara.photo.collage.maker.collage.customviews.NataraText.TextShadow
import com.natara.photo.collage.maker.collage.customviews.grid.NataraLayout
import com.natara.photo.collage.maker.collage.models.CollageModels

object CustomDiffUtils {

    val TOOLS_DIFF = object : DiffUtil.ItemCallback<CollageModels.ToolModel>() {
        override fun areItemsTheSame(
            oldItem: CollageModels.ToolModel,
            newItem: CollageModels.ToolModel,
        ): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(
            oldItem: CollageModels.ToolModel,
            newItem: CollageModels.ToolModel,
        ): Boolean {
            return oldItem.mToolName == newItem.mToolName
        }

    }
    val SQUARE_DIFF = object : DiffUtil.ItemCallback<CollageModels.SquareView>() {
        override fun areItemsTheSame(
            oldItem: CollageModels.SquareView,
            newItem: CollageModels.SquareView,
        ): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(
            oldItem: CollageModels.SquareView,
            newItem: CollageModels.SquareView,
        ): Boolean {
            return oldItem.text == newItem.text
        }

    }
    val RATIO_DIFF = object : DiffUtil.ItemCallback<CollageModels.RatioModel>() {
        override fun areItemsTheSame(
            oldItem: CollageModels.RatioModel,
            newItem: CollageModels.RatioModel,
        ): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(
            oldItem: CollageModels.RatioModel,
            newItem: CollageModels.RatioModel,
        ): Boolean {
            return oldItem.name == newItem.name
        }

    }
    val SQUARE_LAYOUT_DIFF = object : DiffUtil.ItemCallback<NataraLayout>() {
        override fun areItemsTheSame(oldItem: NataraLayout, newItem: NataraLayout): Boolean {
            return oldItem == newItem
        }

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: NataraLayout, newItem: NataraLayout): Boolean {
            return oldItem == newItem
        }

    }
    val FILTERS_LAYOUT_DIFF = object : DiffUtil.ItemCallback<CollageModels.FiltersCode>() {
        override fun areItemsTheSame(
            oldItem: CollageModels.FiltersCode,
            newItem: CollageModels.FiltersCode,
        ): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(
            oldItem: CollageModels.FiltersCode,
            newItem: CollageModels.FiltersCode,
        ): Boolean {
            return oldItem.code == newItem.code
        }

    }

    val TEXT_SHADOW = object : DiffUtil.ItemCallback<TextShadow>() {
        override fun areItemsTheSame(oldItem: TextShadow, newItem: TextShadow): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(oldItem: TextShadow, newItem: TextShadow): Boolean {
            return oldItem.colorShadow == newItem.colorShadow
        }
    }

    val FONT_SHADOW = object : DiffUtil.ItemCallback<String>() {
        override fun areItemsTheSame(oldItem: String, newItem: String): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(oldItem: String, newItem: String): Boolean {
            return oldItem == newItem
        }
    }

}