package com.natara.photo.collage.maker.ui.home.creation.adapter

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintSet
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.models.MediaItemObj
import com.natara.photo.collage.maker.databinding.SingleImgBinding
import com.natara.photo.collage.maker.diffutils.DiffUtilsCallBacks
import com.natara.photo.collage.maker.extentions.hide
import com.natara.photo.collage.maker.extentions.show
import com.natara.photo.collage.maker.ui.home.creation.activity.CreationActivity.Companion.isMultiSelection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CreationAdapter(
    var itemClickListener: ItemClickListener,
) :
    ListAdapter<MediaItemObj, CreationAdapter.ItemViewHolder>(DiffUtilsCallBacks.DiffCallbackCreation()) {

    interface ItemClickListener {
        fun itemClick(mediaItem: MediaItemObj)
        fun itemLongClick(mediaItem: MediaItemObj)
    }

    inner class ItemViewHolder(private val binding: SingleImgBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(mediaItem: MediaItemObj) = CoroutineScope(Dispatchers.Main).launch {

            with(itemView) {
                with(binding) {
                    with(mIVImage) {
                        Glide.with(this)
                            .asBitmap()
                            .load(mediaItem.path).listener(object : RequestListener<Bitmap> {
                                override fun onLoadFailed(
                                    e: GlideException?,
                                    model: Any?,
                                    target: Target<Bitmap>,
                                    isFirstResource: Boolean,
                                ): Boolean {
                                    return false
                                }

                                override fun onResourceReady(
                                    resource: Bitmap,
                                    model: Any,
                                    target: Target<Bitmap>?,
                                    dataSource: DataSource,
                                    isFirstResource: Boolean,
                                ): Boolean {

                                    val constraintSet = ConstraintSet()
                                    constraintSet.clone(mCLRoot)
                                    constraintSet.setDimensionRatio(
                                        mCVImage.id,
                                        "${resource.width}:${resource.height}"
                                    )
                                    constraintSet.applyTo(mCLRoot)
                                    return false
                                }

                            })
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(this)
                    }
                }

                setOnClickListener {
                    itemClickListener.itemClick(mediaItem)
                }

                setOnLongClickListener {
                    itemClickListener.itemLongClick(mediaItem)
                    return@setOnLongClickListener false
                }
            }

        }

        fun selectedBg(itemObj: MediaItemObj) {
            if (isMultiSelection && itemObj.isSelected == 1) {
                binding.colorSelectionIndicator.show()
                binding.colorSelectionIndicator.setImageResource(R.drawable.ic_checked_box)
            } else if (isMultiSelection && itemObj.isSelected == 0) {
                binding.colorSelectionIndicator.show()
                binding.colorSelectionIndicator.setImageResource(R.drawable.ic_unchecked_box)
            } else {
                binding.colorSelectionIndicator.hide()
            }
        }

        fun defaultBg() = binding.colorSelectionIndicator.hide()
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            SingleImgBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        holder.bind(getItem(position))
        holder.selectedBg(getItem(position))
    }

}

