package com.natara.photo.collage.maker.picker.builder.listener

interface OnErrorListener {
    fun onError(throwable: Throwable)
}
