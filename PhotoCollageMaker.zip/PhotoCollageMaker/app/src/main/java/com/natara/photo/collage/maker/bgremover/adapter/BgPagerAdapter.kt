package com.natara.photo.collage.maker.bgremover.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.natara.photo.collage.maker.bgremover.fragment.BackgroundApiFragment

class BgPagerAdapter(
    fragmentManager: FragmentManager,
    lifecycle: Lifecycle,
    private val fragments: ArrayList<String>,
    private val listener: BackgroundApiFragment.OnActionCompleteListener
) : FragmentStateAdapter(fragmentManager,lifecycle) {

    override fun getItemCount(): Int {
        return fragments.size
    }

    override fun createFragment(position: Int): Fragment {
        return BackgroundApiFragment.newInstance(fragments[position],listener)
    }
}
