package com.natara.photo.collage.maker.collage.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.view.isVisible
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.models.CollageModels
import com.natara.photo.collage.maker.collage.utils.CustomDiffUtils
import com.natara.photo.collage.maker.databinding.SingleFilterItemBinding

class FilterAdapter(private val listener: AdapterClickListener) :
    ListAdapter<CollageModels.FiltersCode,FilterAdapter.FilterHolder>(CustomDiffUtils.FILTERS_LAYOUT_DIFF) {

    interface AdapterClickListener {
        fun filtersCLick(position: CollageModels.FiltersCode)
    }

    var selectedFilter: CollageModels.FiltersCode =
        CollageModels.FiltersCode("", "file:///android_asset/filters/filter0.webp")
        set(value) {
            field = value
            notifyDataSetChanged()
        }
    var previousFilter: CollageModels.FiltersCode =
        CollageModels.FiltersCode("", "file:///android_asset/filters/filter0.webp")



    inner class FilterHolder(val binding: SingleFilterItemBinding) :
        RecyclerView.ViewHolder(binding.root)


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilterHolder {
        val binding = SingleFilterItemBinding.inflate(LayoutInflater.from(parent.context))
        return FilterHolder(binding)
    }

    override fun onBindViewHolder(holder: FilterHolder, position: Int) {
        holder.setIsRecyclable(false)
        val color = currentList[position]

        with(holder) {
            with(binding) {

                filterSelectionIndicator.isVisible = selectedFilter == color && position != 0

                with(filterSelection) {
                    when (position) {
                        0 -> {
                            this.scaleType = ImageView.ScaleType.FIT_CENTER
                            val padding =
                                context.resources.getDimension(com.intuit.sdp.R.dimen._5sdp)
                                    .toInt()
                            this.setPadding(padding, padding, padding, padding)
                            Glide.with(root.context).load(R.drawable.ic_none)
                                .diskCacheStrategy(
                                    DiskCacheStrategy.AUTOMATIC
                                ).into(this)
                        }

                        else -> {
                            Glide.with(root.context).load(currentList[position].name)
                                .diskCacheStrategy(
                                    DiskCacheStrategy.AUTOMATIC
                                ).into(this)
                        }
                    }

                }

                with(mCardFilter) {
                    setOnClickListener {
                        previousFilter = selectedFilter
                        selectedFilter = color
                        listener.filtersCLick(color)
                    }
                }

            }
        }

    }

    override fun getItemCount(): Int {
        return currentList.size
    }
}