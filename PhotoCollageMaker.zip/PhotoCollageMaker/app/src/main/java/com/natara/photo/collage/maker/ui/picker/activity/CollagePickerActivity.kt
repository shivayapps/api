package com.natara.photo.collage.maker.ui.picker.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.android.material.tabs.TabLayoutMediator
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.activities.PhotoCollageActivity
import com.natara.photo.collage.maker.databinding.ActivityCollagePickerBinding
import com.natara.photo.collage.maker.models.Media
import com.natara.photo.collage.maker.ui.picker.adapters.ImagePagerAdapter
import com.natara.photo.collage.maker.ui.picker.adapters.ImagePickerAdapter
import com.natara.photo.collage.maker.ui.picker.utils.Status
import com.natara.photo.collage.maker.viewmodels.ImagePickerViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CollagePickerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCollagePickerBinding

    private val viewModel: ImagePickerViewModel by viewModels()

    companion object {
        const val KEY_DATA_RESULT = "KEY_DATA_RESULT"
        val _mImageSelectedList: MutableLiveData<List<Media>> = MutableLiveData()
        val mImageSelectedList: LiveData<List<Media>> = _mImageSelectedList
    }

    private val mImagePickerAdapter by lazy {
        ImagePickerAdapter(object : ImagePickerAdapter.ImagePickerListener {
            override fun onImageClickListener(media: Media) {

            }

            override fun onImageRemoveClickListener(media: Media) {
                removeImage(media)
            }

        }, true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding =
            DataBindingUtil.inflate(
                layoutInflater,
                R.layout.activity_collage_picker,
                null,
                false
            )
        setContentView(binding.root)
        binding.mToolBar.mTVSave.visibility = View.GONE

        loadData()
        selectedImageData()

        _mImageSelectedList.value = arrayListOf()

        binding.mIVSelect.setOnClickListener {
            if (!mImageSelectedList.value.isNullOrEmpty()) {
                if (mImageSelectedList.value!!.size <= 1 || mImageSelectedList.value!!.size > 9) {
                    Toast.makeText(this, "Select Between 2 - 9", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                } else {
                    val intent = Intent(this, PhotoCollageActivity::class.java)
                    intent.putStringArrayListExtra(
                        KEY_DATA_RESULT,
                        mImageSelectedList.value!!.map {
                            it.path
                        } as ArrayList<String>
                    )
                    startActivity(intent)
                }
            } else {
                Toast.makeText(this, "Select Between 2 - 9", Toast.LENGTH_SHORT).show()
            }
        }

        binding.mToolBar.mIVBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun selectedImageData() {
        binding.mRVSelectedImageList.adapter = mImagePickerAdapter

        mImageSelectedList.observe(this) {
            binding.mTVSelectCount.text = "SELECT 2-9 PHOTOS (${it.size})"
            mImagePickerAdapter.submitList(it)
            mImagePickerAdapter.notifyDataSetChanged()
        }
    }

    private fun loadData() {
        CoroutineScope(Dispatchers.Main).launch {
            viewModel.getMediaList(this@CollagePickerActivity).observe(this@CollagePickerActivity) {

                when (it.status) {

                    Status.SUCCESS -> {

                        it.data?.let { data ->
                            binding.mVPImageList.adapter =
                                ImagePagerAdapter(supportFragmentManager, lifecycle, data)

                            TabLayoutMediator(
                                binding.mTBAlbumList,
                                binding.mVPImageList
                            ) { tab, position ->
                                tab.setCustomView(R.layout.layout_album_item)
                                val textView = tab.customView?.findViewById<TextView>(R.id.mTVAlbum)
                                textView?.text = data[position].name
                            }.attach()

                            binding.mProgressBar.visibility = View.GONE
                        }


                    }

                    Status.ERROR -> {

                    }

                    Status.LOADING -> {
                        binding.mProgressBar.visibility = View.VISIBLE
                    }

                }
            }
        }
    }

    private fun removeImage(media: Media) {
        val list = _mImageSelectedList.value
        val newList = arrayListOf<Media>()
        if (!list.isNullOrEmpty()) {
            newList.addAll(list)
        }
        newList.remove(media)
        _mImageSelectedList.value = newList
    }


}