package com.natara.photo.collage.maker.ui.home.creation.activity

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.activities.ViewActivity
import com.natara.photo.collage.maker.collage.models.MediaItemObj
import com.natara.photo.collage.maker.collage.viewmodels.MediaViewModel
import com.natara.photo.collage.maker.databinding.ActivityCreationBinding
import com.natara.photo.collage.maker.extentions.customDialog
import com.natara.photo.collage.maker.extentions.fadeIn
import com.natara.photo.collage.maker.extentions.fadeOut
import com.natara.photo.collage.maker.extentions.hide
import com.natara.photo.collage.maker.extentions.show
import com.natara.photo.collage.maker.ui.home.creation.adapter.CreationAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class CreationActivity : AppCompatActivity(), CreationAdapter.ItemClickListener {

    private var selectedList: ArrayList<MediaItemObj> = arrayListOf()

    private val mDataViewModel: MediaViewModel by lazy {
        MediaViewModel(applicationContext)
    }
    private var mLastClickTime: Long = 0
    private lateinit var binding: ActivityCreationBinding
    private val adapter: CreationAdapter by lazy {
        CreationAdapter(this)
    }

    companion object {
        var isMultiSelection: Boolean = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreationBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initListener()
        setUpRecyclerView()

        onBackPressedDispatcher.addCallback(this, mBackPressCallback)
    }

    private fun initListener() {
        binding.include.mIVShare.setOnClickListener {
            if (SystemClock.elapsedRealtime() - mLastClickTime < 500) {
                return@setOnClickListener
            }
            mLastClickTime = SystemClock.elapsedRealtime()

            shareImages(selectedList)
        }
        binding.include.mIVDelete.setOnClickListener {
            if (SystemClock.elapsedRealtime() - mLastClickTime < 500) {
                return@setOnClickListener
            }
            mLastClickTime = SystemClock.elapsedRealtime()

            if (selectedList.size == 0) {
                Toast.makeText(this, "Please Select Images", Toast.LENGTH_SHORT).show()
            } else {

                customDialog(
                    getString(R.string.delete),
                    getString(R.string.delete_msg)
                ) {
                    deleteImages(selectedList)
                }

            }

        }
        binding.mLVBlank.setOnClickListener {
            clearAll()
        }
    }


    private fun shareImages(filesToSend: ArrayList<MediaItemObj>) {
        val intent = Intent()
        intent.action = Intent.ACTION_SEND_MULTIPLE
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.putExtra(Intent.EXTRA_SUBJECT, "Here are some files.")
        intent.type = "image/*"

        val files: ArrayList<Uri> = ArrayList<Uri>()

        for (path in filesToSend) {
            val file = path.path?.let { File(it) }
            val uri: Uri = FileProvider.getUriForFile(
                this,
                "$packageName.provider",
                file!!
            )
            files.add(uri)
            Log.e("TAG", "shareImages: $uri")
        }
        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, files)
        startActivity(intent)
    }

    private fun deleteImages(filesToSend: ArrayList<MediaItemObj>) {

        val mDeleteList = arrayListOf<Uri>()
        var isDelete = false

        filesToSend.forEach {
            val file = File(it.path!!)

            mDeleteList.add(it.uri!!)

            if (file.exists()) {
                isDelete = file.delete()
            }
        }

        if (!isDelete) {
            Log.e("TAG", "deleteImages: 11")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                deleteImages11(mDeleteList)
            }
        } else {
            Log.e("TAG", "deleteImages: 8")
            clearAll()
        }

    }

    @RequiresApi(Build.VERSION_CODES.R)
    fun deleteImages11(uris: List<Uri>) {
        val pendingIntent =
            MediaStore.createDeleteRequest(contentResolver, uris.filter {
                checkUriPermission(
                    it,
                    Binder.getCallingPid(),
                    Binder.getCallingUid(),
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                ) != PackageManager.PERMISSION_GRANTED
            })
        Log.e("TAG", "deleteImages11: this is delete 11")

        val request = IntentSenderRequest.Builder(pendingIntent.intentSender).build()

        startDelete.launch(request)

    }

    private val startDelete =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
            clearAll()
        }


    private fun setUpRecyclerView() = CoroutineScope(Dispatchers.Main).launch {

        binding.include.mTVTitle.text = getString(R.string.creation)
        binding.include.mTVSave.visibility = View.GONE
        binding.include.mIVBack.setOnClickListener {
            finish()
        }

        binding.mRVImages.adapter = adapter

        mDataViewModel.loadMediaItems()

        mDataViewModel.mediaItemList.observe(this@CreationActivity) { imageList ->
            if (imageList.isEmpty()) {
                binding.mInclude.mCLNoData.show()
            } else {
                binding.mInclude.mCLNoData.hide()
                adapter.submitList(imageList)
            }
        }

    }

    override fun itemClick(mediaItem: MediaItemObj) {

        if (SystemClock.elapsedRealtime() - mLastClickTime < 200) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()

        if (isMultiSelection) {
            if (mediaItem.isSelected == 1) {
                mediaItem.isSelected = 0
                selectedList.remove(mediaItem)
            } else {
                mediaItem.isSelected = 1
                selectedList.add(mediaItem)
            }
            adapter.notifyItemChanged(adapter.currentList.indexOf(mediaItem))
            return
        }

        startActivity(
            Intent(this, ViewActivity::class.java).putExtra(
                "position", adapter.currentList.indexOf(mediaItem)
            )
        )
    }

    override fun itemLongClick(mediaItem: MediaItemObj) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < 500) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()

        if (!isMultiSelection) {
            isMultiSelection = true

            mediaItem.isSelected = 1
            selectedList.add(mediaItem)
            adapter.notifyItemRangeChanged(0, adapter.currentList.size)
            showDelete()
        } else {
            mediaItem.isSelected = 1
            selectedList.add(mediaItem)
            adapter.notifyItemChanged(adapter.currentList.indexOf(mediaItem))
        }
    }

    private fun showDelete() {
        fadeIn(binding.include.mIVShare,700)
        fadeIn(binding.include.mIVDelete, 700)

//
//        viewSlideUp(
//            binding.mCVDelete, false
//        )
    }

    private fun hideDelete() {
        fadeOut(binding.include.mIVShare,500)
        fadeOut(binding.include.mIVDelete, 500)
//        binding.include.mIVDelete.visibility = View.GONE
//        binding.include.mIVShare.visibility = View.GONE
//        viewSlideDown(binding.mCVDelete, true)
    }

    private fun clearAll() = CoroutineScope(Dispatchers.Main).launch {
        if (!::binding.isInitialized) return@launch
        isMultiSelection = false
        selectedList.forEach {
            it.isSelected = 0
        }
        selectedList.clear()
        adapter.notifyItemRangeChanged(0, adapter.currentList.size)
        hideDelete()
    }

    override fun onDestroy() {
        super.onDestroy()
        isMultiSelection = false
    }

    private val mBackPressCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {

            if (isMultiSelection) {
                isMultiSelection = false
                clearAll()
                return
            } else {
                finish()
            }

        }
    }

}