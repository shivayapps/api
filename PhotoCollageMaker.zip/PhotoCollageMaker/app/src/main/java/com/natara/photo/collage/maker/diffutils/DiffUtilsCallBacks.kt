package com.natara.photo.collage.maker.diffutils

import androidx.recyclerview.widget.DiffUtil
import com.natara.photo.collage.maker.bgremover.model.BackgroundEntity
import com.natara.photo.collage.maker.collage.models.MediaItemObj
import com.natara.photo.collage.maker.models.Media
import com.natara.photo.collage.maker.ui.language.model.LanguageModel
import com.natara.photo.collage.maker.ui.pixlab.model.StylesModel

sealed class DiffUtilsCallBacks {
    class DiffCallbackPicker : DiffUtil.ItemCallback<Media>() {
        override fun areItemsTheSame(oldItem: Media, newItem: Media): Boolean {
            return oldItem.uri == newItem.uri
        }

        override fun areContentsTheSame(oldItem: Media, newItem: Media): Boolean {
            return oldItem == newItem
        }
    }

    class DiffCallbackStyles : DiffUtil.ItemCallback<StylesModel>() {
        override fun areItemsTheSame(oldItem: StylesModel, newItem: StylesModel): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: StylesModel, newItem: StylesModel): Boolean {
            return oldItem == newItem
        }
    }



    class DiffCallbackLanguage : DiffUtil.ItemCallback<LanguageModel>() {
        override fun areItemsTheSame(oldItem: LanguageModel, newItem: LanguageModel): Boolean {
            return oldItem.code == newItem.code
        }

        override fun areContentsTheSame(oldItem: LanguageModel, newItem: LanguageModel): Boolean {
            return oldItem == newItem
        }
    }

    class DiffCallbackCreation : DiffUtil.ItemCallback<MediaItemObj>() {
        override fun areItemsTheSame(oldItem: MediaItemObj, newItem: MediaItemObj): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: MediaItemObj, newItem: MediaItemObj): Boolean {
            return oldItem == newItem
        }
    }

    class DiffCallbackGradient : DiffUtil.ItemCallback<String>() {
        override fun areItemsTheSame(oldItem: String, newItem: String): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(oldItem: String, newItem: String): Boolean {
            return oldItem == newItem
        }
    }

    class DiffCallbackColor : DiffUtil.ItemCallback<Int>() {
        override fun areItemsTheSame(oldItem: Int, newItem: Int): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(oldItem: Int, newItem: Int): Boolean {
            return oldItem == newItem
        }
    }


    class DiffCallbackBackgroundEntity : DiffUtil.ItemCallback<BackgroundEntity>() {
        override fun areItemsTheSame(oldItem: BackgroundEntity, newItem: BackgroundEntity): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(oldItem: BackgroundEntity, newItem: BackgroundEntity): Boolean {
            return oldItem.id == newItem.id
        }
    }

}