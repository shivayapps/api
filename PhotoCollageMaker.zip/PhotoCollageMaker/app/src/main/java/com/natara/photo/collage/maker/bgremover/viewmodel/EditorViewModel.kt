package com.natara.photo.collage.maker.bgremover.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.bgremover.model.BackgroundEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class EditorViewModel : ViewModel() {
    val drip = MutableLiveData<ArrayList<String>>()
    val dripStyle: LiveData<ArrayList<String>> = drip

    val dripBg = MutableLiveData<ArrayList<String>>()
    val dripBackground: LiveData<ArrayList<String>> = dripBg


    private val mColorList = MutableLiveData<ArrayList<Int>>()
    val colors: LiveData<ArrayList<Int>> = mColorList

    private val gradient = MutableLiveData<ArrayList<String>>()
    val gradients: LiveData<ArrayList<String>> = gradient

    private val pattern = MutableLiveData<ArrayList<String>>()
    val patterns: LiveData<ArrayList<String>> = pattern

    private val _bgCategory = MutableLiveData<ArrayList<String>>()
    val bgCategory: LiveData<ArrayList<String>> = _bgCategory

    private val _bgItem = MutableLiveData<ArrayList<BackgroundEntity>>()
    val bgItemList: LiveData<ArrayList<BackgroundEntity>> = _bgItem

    fun getLogo(context: Context, type: String): Flow<List<String>> = flow {

        val tempList = arrayListOf<String>()
        val assets = context.assets
        val templates = assets.list(type)

        templates?.let { s ->
            s.reverse()
            tempList.addAll(s)
        }

        emit(tempList)

    }.flowOn(Dispatchers.IO)

    fun loadDripStyle() {
        CoroutineScope(Dispatchers.Main).launch {
            loadDrip()
            loadDripBg()
        }
    }


    fun loadColorData(context: Context) {
        viewModelScope.launch {
            loadColors(context)
        }
    }

    fun loadPatternData() {
        viewModelScope.launch {
            loadPatterns()
        }
    }

    fun loadGradientData() {
        viewModelScope.launch {
            getGradientColors()
        }
    }


    private fun loadColors(context: Context) = CoroutineScope(Dispatchers.IO).launch {
        mColorList.postValue(
            context.resources.getIntArray(R.array.rainbow).toCollection(ArrayList())
        )
    }

    fun loadColor(context: Context) = flow {
        emit(context.resources.getIntArray(R.array.rainbow).toCollection(ArrayList()))
    }.flowOn(Dispatchers.IO)

    private fun loadPatterns() = CoroutineScope(Dispatchers.IO).launch {
        val patternList = arrayListOf<String>()
        patternList.add("")
        patternList.add("")
        patternList.add("file:///android_asset/pattern/btxt0.png")
        patternList.add("file:///android_asset/pattern/btxt1.png")
        patternList.add("file:///android_asset/pattern/btxt2.png")
        patternList.add("file:///android_asset/pattern/btxt3.png")
        patternList.add("file:///android_asset/pattern/btxt4.png")
        patternList.add("file:///android_asset/pattern/btxt5.png")
        patternList.add("file:///android_asset/pattern/btxt6.png")
        patternList.add("file:///android_asset/pattern/btxt7.png")
        patternList.add("file:///android_asset/pattern/btxt8.png")
        patternList.add("file:///android_asset/pattern/btxt9.png")
        patternList.add("file:///android_asset/pattern/btxt10.png")
        patternList.add("file:///android_asset/pattern/btxt11.png")
        patternList.add("file:///android_asset/pattern/btxt12.png")
        patternList.add("file:///android_asset/pattern/btxt13.png")
        patternList.add("file:///android_asset/pattern/btxt14.png")
        patternList.add("file:///android_asset/pattern/btxt15.png")
        patternList.add("file:///android_asset/pattern/btxt16.png")
        patternList.add("file:///android_asset/pattern/btxt17.png")
        patternList.add("file:///android_asset/pattern/btxt18.png")
        patternList.add("file:///android_asset/pattern/btxt19.png")
        patternList.add("file:///android_asset/pattern/btxt20.png")
        patternList.add("file:///android_asset/pattern/btxt21.png")
        patternList.add("file:///android_asset/pattern/btxt22.png")
        patternList.add("file:///android_asset/pattern/btxt23.png")
        patternList.add("file:///android_asset/pattern/btxt24.png")
        patternList.add("file:///android_asset/pattern/btxt25.png")
        patternList.add("file:///android_asset/pattern/btxt26.png")
        patternList.add("file:///android_asset/pattern/btxt27.png")
        patternList.add("file:///android_asset/pattern/btxt28.png")
        patternList.add("file:///android_asset/pattern/btxt29.png")
        patternList.add("file:///android_asset/pattern/btxt30.png")
        patternList.add("file:///android_asset/pattern/btxt31.png")
        patternList.add("file:///android_asset/pattern/btxt32.png")
        patternList.add("file:///android_asset/pattern/btxt33.png")
        patternList.add("file:///android_asset/pattern/btxt34.png")
        patternList.add("file:///android_asset/pattern/btxt35.png")
        patternList.add("file:///android_asset/pattern/btxt36.png")
        patternList.add("file:///android_asset/pattern/btxt37.png")
        patternList.add("file:///android_asset/pattern/btxt38.png")
        patternList.add("file:///android_asset/pattern/btxt39.png")
        Log.d("TAG", "loadPatterns: ${patternList.size}")
        pattern.postValue(patternList)
    }

    fun loadPatternsData() = flow {
        val patternList = arrayListOf<String>()
        patternList.add("")
        patternList.add("")
        patternList.add("file:///android_asset/pattern/btxt0.png")
        patternList.add("file:///android_asset/pattern/btxt1.png")
        patternList.add("file:///android_asset/pattern/btxt2.png")
        patternList.add("file:///android_asset/pattern/btxt3.png")
        patternList.add("file:///android_asset/pattern/btxt4.png")
        patternList.add("file:///android_asset/pattern/btxt5.png")
        patternList.add("file:///android_asset/pattern/btxt6.png")
        patternList.add("file:///android_asset/pattern/btxt7.png")
        patternList.add("file:///android_asset/pattern/btxt8.png")
        patternList.add("file:///android_asset/pattern/btxt9.png")
        patternList.add("file:///android_asset/pattern/btxt10.png")
        patternList.add("file:///android_asset/pattern/btxt11.png")
        patternList.add("file:///android_asset/pattern/btxt12.png")
        patternList.add("file:///android_asset/pattern/btxt13.png")
        patternList.add("file:///android_asset/pattern/btxt14.png")
        patternList.add("file:///android_asset/pattern/btxt15.png")
        patternList.add("file:///android_asset/pattern/btxt16.png")
        patternList.add("file:///android_asset/pattern/btxt17.png")
        patternList.add("file:///android_asset/pattern/btxt18.png")
        patternList.add("file:///android_asset/pattern/btxt19.png")
        patternList.add("file:///android_asset/pattern/btxt20.png")
        patternList.add("file:///android_asset/pattern/btxt21.png")
        patternList.add("file:///android_asset/pattern/btxt22.png")
        patternList.add("file:///android_asset/pattern/btxt23.png")
        patternList.add("file:///android_asset/pattern/btxt24.png")
        patternList.add("file:///android_asset/pattern/btxt25.png")
        patternList.add("file:///android_asset/pattern/btxt26.png")
        patternList.add("file:///android_asset/pattern/btxt27.png")
        patternList.add("file:///android_asset/pattern/btxt28.png")
        patternList.add("file:///android_asset/pattern/btxt29.png")
        patternList.add("file:///android_asset/pattern/btxt30.png")
        patternList.add("file:///android_asset/pattern/btxt31.png")
        patternList.add("file:///android_asset/pattern/btxt32.png")
        patternList.add("file:///android_asset/pattern/btxt33.png")
        patternList.add("file:///android_asset/pattern/btxt34.png")
        patternList.add("file:///android_asset/pattern/btxt35.png")
        patternList.add("file:///android_asset/pattern/btxt36.png")
        patternList.add("file:///android_asset/pattern/btxt37.png")
        patternList.add("file:///android_asset/pattern/btxt38.png")
        patternList.add("file:///android_asset/pattern/btxt39.png")
        Log.d("TAG", "loadPatterns: ${patternList.size}")
        emit(patternList)
    }.flowOn(Dispatchers.IO)

    private fun getGradientColors() = CoroutineScope(Dispatchers.IO).launch {
        val gradientList = arrayListOf<String>().apply {
            this.add("#2E3192,#1BFFFF")
            this.add("#D4145A,#FBB03B")
            this.add("#009245,#FCEE21")
            this.add("#662D8C,#ED1E79")
            this.add("#EE9CA7,#FFDDE1")
            this.add("#614385,#516395")
            this.add("#02AABD,#00CDAC")
            this.add("#FF512F,#DD2476")
            this.add("#FF5F6D,#FFC371")
            this.add("#BFF098,#6FD6FF")
            this.add("#4E65FF,#92EFFD")
            this.add("#A9F1DF,#FFBBBB")
            this.add("#93A5CF,#E4EfE9")
            this.add("#09203F,#537895")
            this.add("#FFECD2,#FCB69F")
            this.add("#6a11cb,#2575fc")
            this.add("#11998E,#38EF7D")
            this.add("#C6EA8D,#FE90AF")
            this.add("#EA8D8D,#A890FE")
            this.add("#D8B5FF,#1EAE98")
            this.add("#FF61D2,#FE9090")
            this.add("#FDC928,#FFFFFF")
            this.add("#D5B33E,#CB403C")
            this.add("#D5B33E,#5E8915")
            this.add("#56DC3E,#EB6561")
            this.add("#2478FF,#E8F2FF")
            this.add("#131CCF,#BC00E5")
            this.add("#DF15AF,#5F236C")
            this.add("#3FF65E,#A3FFA7")
            this.add("#27B7F5,#D43F49")
            this.add("#242016,#EBECE8")
            this.add("#F90062,#B5992E")
            this.add("#48DC3E,#EE7017")
            this.add("#2C2C2C,#E7E7E7")
            this.add("#D9B23B,#FEEDA5")
            this.add("#3B2666,#B778EC")
            this.add("#B99AE2,#F97392")
            this.add("#D64155,#89226B")
            this.add("#87CCD0,#6C49DB")
            this.add("#CF2B00,#EEED36")
            this.add("#F26DF6,#1C94FF")
            this.add("#FF9933,#FFFFFF")
            this.add("#FD8A00,#0B6D28")
        }
        gradient.postValue(gradientList)
    }

    fun getGradientColor() = flow {
        val gradientList = arrayListOf<String>().apply {
            this.add("#2E3192,#1BFFFF")
            this.add("#D4145A,#FBB03B")
            this.add("#009245,#FCEE21")
            this.add("#662D8C,#ED1E79")
            this.add("#EE9CA7,#FFDDE1")
            this.add("#614385,#516395")
            this.add("#02AABD,#00CDAC")
            this.add("#FF512F,#DD2476")
            this.add("#FF5F6D,#FFC371")
            this.add("#BFF098,#6FD6FF")
            this.add("#4E65FF,#92EFFD")
            this.add("#A9F1DF,#FFBBBB")
            this.add("#93A5CF,#E4EfE9")
            this.add("#09203F,#537895")
            this.add("#FFECD2,#FCB69F")
            this.add("#6a11cb,#2575fc")
            this.add("#11998E,#38EF7D")
            this.add("#C6EA8D,#FE90AF")
            this.add("#EA8D8D,#A890FE")
            this.add("#D8B5FF,#1EAE98")
            this.add("#FF61D2,#FE9090")
            this.add("#FDC928,#FFFFFF")
            this.add("#D5B33E,#CB403C")
            this.add("#D5B33E,#5E8915")
            this.add("#56DC3E,#EB6561")
            this.add("#2478FF,#E8F2FF")
            this.add("#131CCF,#BC00E5")
            this.add("#DF15AF,#5F236C")
            this.add("#3FF65E,#A3FFA7")
            this.add("#27B7F5,#D43F49")
            this.add("#242016,#EBECE8")
            this.add("#F90062,#B5992E")
            this.add("#48DC3E,#EE7017")
            this.add("#2C2C2C,#E7E7E7")
            this.add("#D9B23B,#FEEDA5")
            this.add("#3B2666,#B778EC")
            this.add("#B99AE2,#F97392")
            this.add("#D64155,#89226B")
            this.add("#87CCD0,#6C49DB")
            this.add("#CF2B00,#EEED36")
            this.add("#F26DF6,#1C94FF")
            this.add("#FF9933,#FFFFFF")
            this.add("#FD8A00,#0B6D28")
        }
        emit(gradientList)
    }.flowOn(Dispatchers.IO)

    private suspend fun getMultipleColors() = withContext(Dispatchers.IO) {
        val multi21 = arrayListOf<Int>(
            Color.parseColor("#c79237"),
            Color.parseColor("#000000")
        )
        val multi22 = arrayListOf<Int>(
            Color.parseColor("#fde8cd"),
            Color.parseColor("#8ad0bf")
        )
        val multi23 = arrayListOf<Int>(
            Color.parseColor("#fbeeac"),
            Color.parseColor("#8ac4d0")
        )
        val multi24 = arrayListOf<Int>(
            Color.parseColor("#6553de"),
            Color.parseColor("#63c9fa")
        )
        val multi25 = arrayListOf<Int>(
            Color.parseColor("#f34d5a"),
            Color.parseColor("#fbfbfb")
        )
        val multi26 = arrayListOf<Int>(
            Color.parseColor("#49c97e"),
            Color.parseColor("#ffd959")
        )
        val multi27 = arrayListOf<Int>(
            Color.parseColor("#09c5eb"),
            Color.parseColor("#f12a72")
        )
        val multi28 = arrayListOf<Int>(
            Color.parseColor("#da41e4"),
            Color.parseColor("#41d3e4")
        )
        val multi29 = arrayListOf<Int>(
            Color.parseColor("#f67280"),
            Color.parseColor("#35477d")
        )
        val multi210 = arrayListOf<Int>(
            Color.parseColor("#ea907a"),
            Color.parseColor("#4f8a8b")
        )
        val multi211 = arrayListOf<Int>(
            Color.parseColor("#951556"),
            Color.parseColor("#e9b5d2")
        )
        val multi212 = arrayListOf<Int>(
            Color.parseColor("#ffb5b5"),
            Color.parseColor("#407088")
        )
        val multi213 = arrayListOf<Int>(
            Color.parseColor("#949cdf"),
            Color.parseColor("#a7c5eb")
        )

        val multi31 = arrayListOf<Int>(
            Color.parseColor("#d67e20"),
            Color.parseColor("#f2f0f0"),
            Color.parseColor("#1e8514")
        )
        val multi32 = arrayListOf<Int>(
            Color.parseColor("#92039a"),
            Color.parseColor("#e36611"),
            Color.parseColor("#0891d3")
        )
        val multi33 = arrayListOf<Int>(
            Color.parseColor("#02b6cd"),
            Color.parseColor("#f15a5b"),
            Color.parseColor("#faa71a")
        )
        val multi34 = arrayListOf<Int>(
            Color.parseColor("#8a73b4"),
            Color.parseColor("#02b7ce"),
            Color.parseColor("#f15b5c")
        )
        val multi35 = arrayListOf<Int>(
            Color.parseColor("#ffd300"),
            Color.parseColor("#f48ab5"),
            Color.parseColor("#71c462")
        )
        val multi36 = arrayListOf<Int>(
            Color.parseColor("#fe403e"),
            Color.parseColor("#ff852e"),
            Color.parseColor("#febf31")
        )
        val multi37 = arrayListOf<Int>(
            Color.parseColor("#d566d4"),
            Color.parseColor("#399a39"),
            Color.parseColor("#30b1e1")
        )
        val multi38 = arrayListOf<Int>(
            Color.parseColor("#ffe547"),
            Color.parseColor("#49d0ff"),
            Color.parseColor("#ff4fef")
        )
        val multi39 = arrayListOf<Int>(
            Color.parseColor("#3f3351"),
            Color.parseColor("#864879"),
            Color.parseColor("#e9a6a6")
        )
        val multi310 = arrayListOf<Int>(
            Color.parseColor("#035397"),
            Color.parseColor("#5089c6"),
            Color.parseColor("#ffaa4c")
        )
        val multi311 = arrayListOf<Int>(
            Color.parseColor("#94b49f"),
            Color.parseColor("#b4cfb0"),
            Color.parseColor("#e5e3c9")
        )
        val multi312 = arrayListOf<Int>(
            Color.parseColor("#e3bec6"),
            Color.parseColor("#efdad7"),
            Color.parseColor("#9ad0ec")
        )
        val multi313 = arrayListOf<Int>(
            Color.parseColor("#e05d5d"),
            Color.parseColor("#ffb344"),
            Color.parseColor("#00a19d")
        )

        val multi41 = arrayListOf<Int>(
            Color.parseColor("#a33cc8"),
            Color.parseColor("#ff613d"),
            Color.parseColor("#ffc43d"),
            Color.parseColor("#55cfc3")
        )
        val multi42 = arrayListOf<Int>(
            Color.parseColor("#e43137"),
            Color.parseColor("#005dd0"),
            Color.parseColor("#eeac08"),
            Color.parseColor("#7aa320")
        )
        val multi43 = arrayListOf<Int>(
            Color.parseColor("#7cf2bb"),
            Color.parseColor("#fff927"),
            Color.parseColor("#fe6383"),
            Color.parseColor("#ffac7e")
        )
        val multi44 = arrayListOf<Int>(
            Color.parseColor("#ef025e"),
            Color.parseColor("#2e45c4"),
            Color.parseColor("#ff5600"),
            Color.parseColor("#06a4ff")
        )
        val multi45 = arrayListOf<Int>(
            Color.parseColor("#0bb592"),
            Color.parseColor("#eb4d56"),
            Color.parseColor("#d3e761"),
            Color.parseColor("#c89add")
        )
        val multi46 = arrayListOf<Int>(
            Color.parseColor("#582da7"),
            Color.parseColor("#44e700"),
            Color.parseColor("#025ec0"),
            Color.parseColor("#fee500")
        )
        val multi47 = arrayListOf<Int>(
            Color.parseColor("#0262aa"),
            Color.parseColor("#00b727"),
            Color.parseColor("#cc42fa"),
            Color.parseColor("#ff8b03")
        )
        val multi48 = arrayListOf<Int>(
            Color.parseColor("#fcde29"),
            Color.parseColor("#d52d5b"),
            Color.parseColor("#0284ab"),
            Color.parseColor("#df4e38")
        )
        val multi49 = arrayListOf<Int>(
            Color.parseColor("#94b4a4"),
            Color.parseColor("#d2f5e3"),
            Color.parseColor("#e5c5b5"),
            Color.parseColor("#f4d9c6")
        )
        val multi410 = arrayListOf<Int>(
            Color.parseColor("#00334e"),
            Color.parseColor("#145374"),
            Color.parseColor("#5588a3"),
            Color.parseColor("#e8e8e8")
        )
        val multi411 = arrayListOf<Int>(
            Color.parseColor("#f7e8f6"),
            Color.parseColor("#f1c6e7"),
            Color.parseColor("#e5b0ea"),
            Color.parseColor("#bd83ce")
        )
        val multi412 = arrayListOf<Int>(
            Color.parseColor("#fb5b5a"),
            Color.parseColor("#bc4873"),
            Color.parseColor("#472b62"),
            Color.parseColor("#003f5c")
        )
        val multi413 = arrayListOf<Int>(
            Color.parseColor("#321d2f"),
            Color.parseColor("#3d2e4f"),
            Color.parseColor("#393e6f"),
            Color.parseColor("#4c5f7a")
        )

        val multi51 = arrayListOf<Int>(
            Color.parseColor("#43c7da"),
            Color.parseColor("#3fa71b"),
            Color.parseColor("#e54cdf"),
            Color.parseColor("#ffb22b"),
            Color.parseColor("#f43b38")
        )
        val multi52 = arrayListOf<Int>(
            Color.parseColor("#8cf267"),
            Color.parseColor("#fe7742"),
            Color.parseColor("#d83755"),
            Color.parseColor("#7035a2"),
            Color.parseColor("#04a0f3")
        )
        val multi53 = arrayListOf<Int>(
            Color.parseColor("#ffef00"),
            Color.parseColor("#ff8900"),
            Color.parseColor("#83f600"),
            Color.parseColor("#7035a2"),
            Color.parseColor("#0368ce")
        )
        val multi54 = arrayListOf<Int>(
            Color.parseColor("#d9e613"),
            Color.parseColor("#d098f0"),
            Color.parseColor("#2be0d5"),
            Color.parseColor("#04bae9"),
            Color.parseColor("#ff63de")
        )
        val multi55 = arrayListOf<Int>(
            Color.parseColor("#da43b5"),
            Color.parseColor("#06abec"),
            Color.parseColor("#fbdd00"),
            Color.parseColor("#e8f0f2"),
            Color.parseColor("#ff688e")
        )
        val multi56 = arrayListOf<Int>(
            Color.parseColor("#d64eff"),
            Color.parseColor("#feb41a"),
            Color.parseColor("#27d5ff"),
            Color.parseColor("#5e5e5e"),
            Color.parseColor("#90fc1c")
        )
        val multi57 = arrayListOf<Int>(
            Color.parseColor("#e8985d"),
            Color.parseColor("#ee2b5d"),
            Color.parseColor("#9a29a3"),
            Color.parseColor("#3f26f6"),
            Color.parseColor("#39c4fa")
        )
        val multi58 = arrayListOf<Int>(
            Color.parseColor("#fcca0c"),
            Color.parseColor("#2091d0"),
            Color.parseColor("#90c143"),
            Color.parseColor("#7852a3"),
            Color.parseColor("#ef8922")
        )
        val multi59 = arrayListOf<Int>(
            Color.parseColor("#9fa2cc"),
            Color.parseColor("#896c7c"),
            Color.parseColor("#7d81ba"),
            Color.parseColor("#17222b"),
            Color.parseColor("#ddac98")
        )
        val multi510 = arrayListOf<Int>(
            Color.parseColor("#4c1130"),
            Color.parseColor("#741b47"),
            Color.parseColor("#990000"),
            Color.parseColor("#ea9999"),
            Color.parseColor("#ffd966")
        )
        val multi511 = arrayListOf<Int>(
            Color.parseColor("#c7daa9"),
            Color.parseColor("#a6c578"),
            Color.parseColor("#88b04b"),
            Color.parseColor("#6b8b3a"),
            Color.parseColor("#51692c")
        )
        val multi512 = arrayListOf<Int>(
            Color.parseColor("#505a56"),
            Color.parseColor("#67787d"),
            Color.parseColor("#8aa4b3"),
            Color.parseColor("#a7c4dd"),
            Color.parseColor("#c4deff")
        )
        val multi513 = arrayListOf<Int>(
            Color.parseColor("#655f68"),
            Color.parseColor("#816b6a"),
            Color.parseColor("#a47a6a"),
            Color.parseColor("#cb9576"),
            Color.parseColor("#edb587")
        )
        val multi514 = arrayListOf<Int>(
            Color.parseColor("#ffbbbb"),
            Color.parseColor("#ffe4c0"),
            Color.parseColor("#f0ffc2"),
            Color.parseColor("#bffff0"),
            Color.parseColor("#f6dfeb")
        )
        val multi515 = arrayListOf<Int>(
            Color.parseColor("#f0eee0"),
            Color.parseColor("#fffdf1"),
            Color.parseColor("#cfdbc6"),
            Color.parseColor("#f4e1db"),
            Color.parseColor("#f6e9d3")
        )
        val multi516 = arrayListOf<Int>(
            Color.parseColor("#e4bad4"),
            Color.parseColor("#f6dfeb"),
            Color.parseColor("#edffec"),
            Color.parseColor("#caf7e3"),
            Color.parseColor("#d3eef6")
        )
        val multi517 = arrayListOf<Int>(
            Color.parseColor("#ffc1b6"),
            Color.parseColor("#ffdcb8"),
            Color.parseColor("#ffeebb"),
            Color.parseColor("#fdffbc"),
            Color.parseColor("#f1f2d6")
        )
        val multi518 = arrayListOf<Int>(
            Color.parseColor("#83a9d4"),
            Color.parseColor("#b9d7ea"),
            Color.parseColor("#d6e6f2"),
            Color.parseColor("#e6f1f9"),
            Color.parseColor("#f7fbfc")
        )
    }

    fun loadCategoryData() {

        val db = Firebase.firestore
        db.collection("collage_maker")
            .get()
            .addOnSuccessListener { result ->

                result.forEach {
                    it.data.forEach { (t, u) ->

                        Log.d("TAG", "loadCategoryData: $t $u")
                        _bgCategory.value = u as ArrayList<String>?
                    }
                }
//                _bgCategory.value = result.map {
//                    it.data.values
//                }
            }
            .addOnFailureListener { exception ->
                Log.w("TAG", "Error getting documents.", exception)
            }
    }

    fun loadCategoryItem(item: String) {
        val db = Firebase.firestore
        db.collection("collage_maker")
            .document("background")
            .collection(item)
            .get()
            .addOnSuccessListener { result ->

                val list  =  result.documents.mapNotNull {  doc ->
                    doc.toObject(BackgroundEntity::class.java)
                }.toList() as ArrayList<BackgroundEntity>

                _bgItem.value = list

            }

    }

    private suspend fun loadDrip() {
        return withContext(Dispatchers.IO) {
            val patternList = arrayListOf<String>()
            patternList.add("file:///android_asset/drip/style/drip_1.webp")
            patternList.add("file:///android_asset/drip/style/drip_2.webp")
            patternList.add("file:///android_asset/drip/style/drip_3.webp")
            patternList.add("file:///android_asset/drip/style/drip_4.webp")
            patternList.add("file:///android_asset/drip/style/drip_5.webp")
            patternList.add("file:///android_asset/drip/style/drip_6.webp")
            patternList.add("file:///android_asset/drip/style/drip_7.webp")
            patternList.add("file:///android_asset/drip/style/drip_8.webp")
            patternList.add("file:///android_asset/drip/style/drip_9.webp")
            patternList.add("file:///android_asset/drip/style/drip_10.webp")
            drip.postValue(patternList)
        }
    }

    private suspend fun loadDripBg() {
        return withContext(Dispatchers.IO) {
            val patternList = arrayListOf<String>()
            patternList.add("")
            patternList.add("file:///android_asset/drip/background/background_1.webp")
            patternList.add("file:///android_asset/drip/background/background_2.webp")
            patternList.add("file:///android_asset/drip/background/background_3.webp")
            patternList.add("file:///android_asset/drip/background/background_4.webp")
            patternList.add("file:///android_asset/drip/background/background_5.webp")
            patternList.add("file:///android_asset/drip/background/background_6.webp")
            patternList.add("file:///android_asset/drip/background/background_7.webp")
            patternList.add("file:///android_asset/drip/background/background_8.webp")
            patternList.add("file:///android_asset/drip/background/background_9.webp")
            patternList.add("file:///android_asset/drip/background/background_10.webp")
            patternList.add("file:///android_asset/drip/background/background_11.webp")
            patternList.add("file:///android_asset/drip/background/background_12.webp")
            patternList.add("file:///android_asset/drip/background/background_13.webp")
            patternList.add("file:///android_asset/drip/background/background_14.webp")
            patternList.add("file:///android_asset/drip/background/background_15.webp")
            patternList.add("file:///android_asset/drip/background/background_16.webp")
            patternList.add("file:///android_asset/drip/background/background_17.webp")
            patternList.add("file:///android_asset/drip/background/background_18.webp")
            patternList.add("file:///android_asset/drip/background/background_19.webp")
            patternList.add("file:///android_asset/drip/background/background_20.webp")
            dripBg.postValue(patternList)
        }
    }
}