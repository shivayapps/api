package com.natara.photo.collage.maker.bgremover.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

data class BackgroundEntity(
    val id: String = "",
    val path: String?,
    val image: String?,
    val pro: Boolean?,
    val lock: Boolean?,
    val sub_category: String?
)  {
    constructor() : this("", "", "", false, false, "")
}