package com.natara.photo.collage.maker.collage.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.natara.photo.collage.maker.collage.models.CollageModels.RatioModel
import com.natara.photo.collage.maker.collage.utils.CustomDiffUtils.RATIO_DIFF
import com.natara.photo.collage.maker.databinding.LayoutCropItemBinding
import com.steelkiwi.cropiwa.AspectRatio

class AspectAdapter(var listener: OnNewSelectedListener) :
    ListAdapter<RatioModel, AspectAdapter.ViewHolder>(RATIO_DIFF) {
    var lastSelectedView = 0

    interface OnNewSelectedListener {
        fun onNewAspectRatioSelected(aspectRatio: AspectRatio?)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        return ViewHolder(
            LayoutCropItemBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false)
        )
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {
        val ratioModel = currentList[i]
        viewHolder.bind(ratioModel, i)
    }

    override fun getItemCount(): Int {
        return currentList.size
    }


    inner class ViewHolder(private val binding: LayoutCropItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(ratioModel: RatioModel, i: Int) {

            if (i == lastSelectedView) {
                binding.imageViewAspectRatio.setImageResource(ratioModel.selectedIem)
                binding.textViewFilterName.text = ratioModel.name
                binding.textViewFilterName.setTextColor(Color.parseColor("#1B6EF3"))
            } else {
                binding.imageViewAspectRatio.setImageResource(ratioModel.unselectItem)
                binding.textViewFilterName.text = ratioModel.name
                binding.textViewFilterName.setTextColor(Color.parseColor("#000000"))
            }

            binding.root.setOnClickListener {
                if (lastSelectedView != adapterPosition) {
                    lastSelectedView = adapterPosition
                    listener.onNewAspectRatioSelected(ratioModel)
                    notifyDataSetChanged()
                }
            }
        }
    }
}
