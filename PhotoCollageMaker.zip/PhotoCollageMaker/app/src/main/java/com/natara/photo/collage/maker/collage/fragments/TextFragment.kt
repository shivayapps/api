package com.natara.photo.collage.maker.collage.fragments

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.BitmapShader
import android.graphics.Color
import android.graphics.Shader
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import android.widget.Toast
import androidx.annotation.ColorInt
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.view.OnApplyWindowInsetsListener
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.collage.adapter.CollageColorAdapter
import com.natara.photo.collage.maker.collage.adapter.CollageColorAdapter.BackgroundColorListener
import com.natara.photo.collage.maker.collage.adapter.FontAdapter
import com.natara.photo.collage.maker.collage.adapter.FontAdapter.ItemClickListener
import com.natara.photo.collage.maker.collage.adapter.ShadowAdapter
import com.natara.photo.collage.maker.collage.adapter.ShadowAdapter.ShadowItemClickListener
import com.natara.photo.collage.maker.collage.assets.FontFileAsset
import com.natara.photo.collage.maker.collage.customviews.NataraCarouselPicker.CarouselViewAdapter
import com.natara.photo.collage.maker.collage.customviews.NataraCarouselPicker.ColorItem
import com.natara.photo.collage.maker.collage.customviews.NataraCarouselPicker.DrawableItem
import com.natara.photo.collage.maker.collage.customviews.NataraCarouselPicker.PickerItem
import com.natara.photo.collage.maker.collage.customviews.NataraText
import com.natara.photo.collage.maker.collage.models.CollageModels.SquareView
import com.natara.photo.collage.maker.collage.utils.SystemUtil
import com.natara.photo.collage.maker.databinding.FragmentAddTextBinding


class TextFragment : DialogFragment(), ShadowItemClickListener {

    private lateinit var binding: FragmentAddTextBinding

    var nataraText: NataraText? = null

    private var colorItems: ArrayList<PickerItem> = arrayListOf()
    private var fontAdapter: FontAdapter? = null
    private var shadowAdapter: ShadowAdapter? = null


    private var inputMethodManager: InputMethodManager? = null


    private var textEditor: TextEditor? = null
    private var textFunctions: List<ImageView>? = null

    var textTextureItems: List<PickerItem>? = null

    interface TextEditor {
        fun onBackButton()
        fun onDone(nataraText: NataraText?)
    }

    override fun onShadowItemClick(view: View?, i: Int) {
        val textShadow = NataraText.getLstTextShadow()[i]
        binding.textViewPreviewEffect.setShadowLayer(
            textShadow.radius.toFloat(),
            textShadow.dx.toFloat(),
            textShadow.dy.toFloat(),
            textShadow.colorShadow
        )
        binding.textViewPreviewEffect.invalidate()
        nataraText!!.textShadow = textShadow
        nataraText!!.textShadowIndex = i
    }

    fun setPolishText(nataraText: NataraText?) {
        this.nataraText = nataraText
    }

    override fun onStart() {
        super.onStart()
        val dialog = dialog
        if (dialog != null) {
            dialog.window!!.setLayout(-1, -1)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(0))
        }
    }

    override fun onCreateView(
        layoutInflater: LayoutInflater,
        viewGroup: ViewGroup?,
        bundle: Bundle?,
    ): View {
        dialog?.window?.requestFeature(1)
        dialog?.window?.setFlags(1024, 1024)
        binding = FragmentAddTextBinding.inflate(layoutInflater)
        return binding.root
    }

    fun dismissAndShowSticker() {
        if (textEditor != null) {
            textEditor!!.onBackButton()
        }
        dismiss()
    }

    override fun onViewCreated(view: View, bundle: Bundle?) {
        super.onViewCreated(view, bundle)
        initView()

        if (nataraText == null) {
            nataraText = NataraText.getDefaultProperties()
        }

        binding.addTextEditText.setTextFragment(this)
        initAddTextLayout()

        inputMethodManager =
            requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        setDefaultStyleForEdittext()

        binding.addTextEditText.requestFocus()
        Handler(Looper.getMainLooper()).postDelayed({
            inputMethodManager?.showSoftInput(
                binding.addTextEditText,
                0
            )
        }, 200)

        highlightFunction(binding.imageViewKeyboard)
        binding.recyclerViewFonts.layoutManager = GridLayoutManager(context, 5)
        fontAdapter = FontAdapter(object : ItemClickListener {
            override fun onItemClick(view: View?, i: Int) {
                FontFileAsset.setFontByName(
                    requireContext(),
                    binding.textViewPreviewEffect,
                    FontFileAsset.getListFonts()[i]
                )
                nataraText!!.fontName = FontFileAsset.getListFonts().get(i)
                nataraText!!.fontIndex = i
            }
        })
        fontAdapter!!.submitList(FontFileAsset.getListFonts())
        binding.recyclerViewFonts.adapter = fontAdapter
        binding.recyclerViewShadow.layoutManager = GridLayoutManager(context, 5)
        shadowAdapter = ShadowAdapter(this)
        shadowAdapter!!.submitList(NataraText.getLstTextShadow())
        binding.recyclerViewShadow.adapter = shadowAdapter
        binding.textureCarouselPicker.adapter = CarouselViewAdapter(context, textTextureItems, 0)
        binding.textureCarouselPicker.addOnPageChangeListener(object : OnPageChangeListener {
            override fun onPageScrollStateChanged(i: Int) {}
            override fun onPageSelected(i: Int) {}
            override fun onPageScrolled(i: Int, f: Float, i2: Int) {
                if (f > 0.0f) {
                    if (binding.imageViewTextTexture.visibility == View.INVISIBLE) {
                        binding.imageViewTextTexture.visibility = View.VISIBLE
                        binding.viewHighlightTexture.visibility = View.VISIBLE
                    }
                    val f2 = (i.toFloat()) + f
                    val bitmapShader = BitmapShader(
                        (textTextureItems!![Math.round(f2)]).bitmap,
                        Shader.TileMode.MIRROR,
                        Shader.TileMode.MIRROR
                    )
                    binding.textViewPreviewEffect.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                    binding.textViewPreviewEffect.paint.setShader(bitmapShader)
                    nataraText!!.textShader = bitmapShader
                    nataraText!!.textShaderIndex = Math.round(f2)
                }
            }
        })
        binding.seekbarTextOpacity.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
            override fun onProgressChanged(seekBar: SeekBar, i: Int, z: Boolean) {
                val value = i.toString()
                binding.mTVSeekbarColor.text = value
                val i2 = 255 - i
                nataraText!!.textAlpha = i2
                binding.textViewPreviewEffect.setTextColor(
                    Color.argb(
                        i2, Color.red(
                            nataraText!!.textColor
                        ), Color.green(
                            nataraText!!.textColor
                        ), Color.blue(
                            nataraText!!.textColor
                        )
                    )
                )
            }
        })
        binding.addTextEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(editable: Editable) {}
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i2: Int, i3: Int) {}
            override fun onTextChanged(charSequence: CharSequence, i: Int, i2: Int, i3: Int) {
                binding.textViewPreviewEffect.text = charSequence.toString()
                nataraText!!.text = charSequence.toString()
            }
        })

        binding.checkboxBackground.setOnCheckedChangeListener({ compoundButton, z ->
            if (!z) {
                nataraText!!.isShowBackground = false
                binding.textViewPreviewEffect.setBackgroundResource(0)
                binding.textViewPreviewEffect.layoutParams = LinearLayout.LayoutParams(-2, -2)
            } else if (binding.checkboxBackground.isPressed || nataraText!!.isShowBackground) {
                nataraText!!.isShowBackground = true
                initPreviewText()
            } else {
                binding.checkboxBackground.isChecked = false
                nataraText!!.isShowBackground = false
                initPreviewText()
            }
        })
        binding.seekbarWidth.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
            override fun onProgressChanged(seekBar: SeekBar, i: Int, z: Boolean) {
                val value = i.toString()
                binding.mTVSeekbarWith.text = value
                binding.textViewPreviewEffect.setPadding(
                    SystemUtil.dpToPx(
                        requireContext(), i
                    ),
                    binding.textViewPreviewEffect.paddingTop,
                    SystemUtil.dpToPx(this@TextFragment.context, i),
                    binding.textViewPreviewEffect.paddingBottom
                )
                nataraText!!.paddingWidth = i
            }
        })
        binding.seekbarHeight.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
            override fun onProgressChanged(seekBar: SeekBar, i: Int, z: Boolean) {
                val value = i.toString()
                binding.mTVSeekbarHeight.text = value
                binding.textViewPreviewEffect.setPadding(
                    binding.textViewPreviewEffect.paddingLeft,
                    SystemUtil.dpToPx(
                        requireContext(), i
                    ),
                    binding.textViewPreviewEffect.paddingRight,
                    SystemUtil.dpToPx(this@TextFragment.context, i)
                )
                nataraText!!.paddingHeight = i
            }
        })
        binding.seekbarBackgroundOpacity.setOnSeekBarChangeListener(object :
            OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
            override fun onProgressChanged(seekBar: SeekBar, i: Int, z: Boolean) {
                val value = i.toString()
                binding.mTVSeekbarBackground.text = value
                nataraText!!.backgroundAlpha = 255 - i
                val red = Color.red(nataraText!!.backgroundColor)
                val green = Color.green(nataraText!!.backgroundColor)
                val blue = Color.blue(nataraText!!.backgroundColor)
                val gradientDrawable = GradientDrawable()
                gradientDrawable.setColor(
                    Color.argb(
                        nataraText!!.backgroundAlpha,
                        red,
                        green,
                        blue
                    )
                )
                gradientDrawable.cornerRadius = SystemUtil.dpToPx(
                    requireContext(), nataraText!!.backgroundBorder
                ).toFloat()
                binding.textViewPreviewEffect.background = gradientDrawable

            }
        })
        binding.seekbarTextSize.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
            override fun onProgressChanged(seekBar: SeekBar, i: Int, z: Boolean) {
                val value = i.toString()
                binding.mTVSeekbarSize.text = value
                var i2 = 15
                if (i >= 15) {
                    i2 = i
                }
                binding.textViewPreviewEffect.textSize = i2.toFloat()
                nataraText!!.textSize = i2
            }
        })
        binding.seekbarRadius.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
            override fun onProgressChanged(seekBar: SeekBar, i: Int, z: Boolean) {
                val value = i.toString()
                binding.mTVSeekbarRadius.text = value
                nataraText!!.backgroundBorder = i
                val gradientDrawable = GradientDrawable()
                gradientDrawable.cornerRadius = SystemUtil.dpToPx(
                    requireContext(), i
                ).toFloat()
                gradientDrawable.setColor(
                    Color.argb(
                        nataraText!!.backgroundAlpha, Color.red(
                            nataraText!!.backgroundColor
                        ), Color.green(
                            nataraText!!.backgroundColor
                        ), Color.blue(
                            nataraText!!.backgroundColor
                        )
                    )
                )
                binding.textViewPreviewEffect.background = gradientDrawable
            }
        })

        /*        if (Preference.getKeyboard(requireContext()) > 0) {
                    updateAddTextBottomToolbarHeight(
                        Preference.getKeyboard(
                            context
                        )
                    )
                }*/
        initPreviewText()
    }

    private fun initView() {


        binding.recyclerViewColor.layoutManager = LinearLayoutManager(
            context,
            RecyclerView.HORIZONTAL,
            false
        )
        binding.recyclerViewColor.adapter =
            CollageColorAdapter(object : BackgroundColorListener {
                override fun onBackgroundColorSelected(i: Int, squareView: SquareView) {
                    if (squareView.isColor) {
                        binding.textViewPreviewEffect.setTextColor(squareView.drawableId)
                        nataraText!!.textColor = squareView.drawableId
                        binding.textViewPreviewEffect.paint.setShader(null)
                        nataraText!!.textShader = null
                    } else {
                        binding.textViewPreviewEffect.setTextColor(squareView.drawableId)
                        nataraText!!.textColor = squareView.drawableId
                        binding.textViewPreviewEffect.paint.setShader(null)
                        nataraText!!.textShader = null
                    }
                }

            })
        binding.recyclerViewColor.visibility = View.VISIBLE

        binding.recyclerViewBackground.layoutManager = LinearLayoutManager(
            context,
            RecyclerView.HORIZONTAL,
            false
        )
        binding.recyclerViewBackground.adapter =
            CollageColorAdapter(object : BackgroundColorListener {
                override fun onBackgroundColorSelected(i: Int, squareView: SquareView) {
                    if (squareView.isColor) {
                        binding.textViewPreviewEffect.setBackgroundColor(squareView.drawableId)
                        nataraText!!.backgroundColor = squareView.drawableId
                        binding.seekbarRadius.isEnabled = true
                        nataraText!!.isShowBackground = true
                        if (!binding.checkboxBackground.isChecked) {
                            binding.checkboxBackground.isChecked = true
                        }
                        val red: Int = Color.red(nataraText!!.backgroundColor)
                        val green: Int = Color.green(nataraText!!.backgroundColor)
                        val blue: Int = Color.blue(nataraText!!.backgroundColor)
                        val gradientDrawable: GradientDrawable = GradientDrawable()
                        gradientDrawable.setColor(
                            Color.argb(
                                nataraText!!.backgroundAlpha,
                                red,
                                green,
                                blue
                            )
                        )
                        gradientDrawable.cornerRadius = SystemUtil.dpToPx(
                            requireContext(), nataraText!!.backgroundBorder
                        ).toFloat()
                        binding.textViewPreviewEffect.background = gradientDrawable
                    } else {
                        binding.textViewPreviewEffect.setBackgroundColor(squareView.drawableId)
                        nataraText!!.backgroundColor = squareView.drawableId
                        binding.seekbarRadius.isEnabled = true
                        nataraText!!.isShowBackground = true
                        if (!binding.checkboxBackground.isChecked) {
                            binding.checkboxBackground.isChecked = true
                        }
                        val red: Int = Color.red(nataraText!!.backgroundColor)
                        val green: Int = Color.green(nataraText!!.backgroundColor)
                        val blue: Int = Color.blue(nataraText!!.backgroundColor)
                        val gradientDrawable: GradientDrawable = GradientDrawable()
                        gradientDrawable.setColor(
                            Color.argb(
                                nataraText!!.backgroundAlpha,
                                red,
                                green,
                                blue
                            )
                        )
                        gradientDrawable.cornerRadius = SystemUtil.dpToPx(
                            requireContext(), nataraText!!.backgroundBorder
                        ).toFloat()
                        binding.textViewPreviewEffect.background = gradientDrawable
                    }

                }

            })
        binding.recyclerViewBackground.visibility = View.VISIBLE
    }

    private fun initPreviewText() {
        if (nataraText!!.isShowBackground) {
            if (nataraText!!.backgroundColor != 0) {
                binding.textViewPreviewEffect.setBackgroundColor(nataraText!!.backgroundColor)
            }
            if (nataraText!!.backgroundAlpha < 255) {
                binding.textViewPreviewEffect.setBackgroundColor(
                    Color.argb(
                        nataraText!!.backgroundAlpha, Color.red(
                            nataraText!!.backgroundColor
                        ), Color.green(nataraText!!.backgroundColor), Color.blue(
                            nataraText!!.backgroundColor
                        )
                    )
                )
            }
            if (nataraText!!.backgroundBorder > 0) {
                val gradientDrawable = GradientDrawable()
                gradientDrawable.cornerRadius =
                    SystemUtil.dpToPx(requireContext(), nataraText!!.backgroundBorder).toFloat()
                gradientDrawable.setColor(
                    Color.argb(
                        nataraText!!.backgroundAlpha, Color.red(
                            nataraText!!.backgroundColor
                        ), Color.green(nataraText!!.backgroundColor), Color.blue(
                            nataraText!!.backgroundColor
                        )
                    )
                )
                binding.textViewPreviewEffect.background = gradientDrawable
            }
        }
        if (nataraText!!.paddingHeight > 0) {
            binding.textViewPreviewEffect.setPadding(
                binding.textViewPreviewEffect.paddingLeft,
                nataraText!!.paddingHeight,
                binding.textViewPreviewEffect.paddingRight,
                nataraText!!.paddingHeight
            )
            binding.seekbarHeight.progress = nataraText!!.paddingHeight
        }
        if (nataraText!!.paddingWidth > 0) {
            binding.textViewPreviewEffect.setPadding(
                nataraText!!.paddingWidth,
                binding.textViewPreviewEffect.paddingTop,
                nataraText!!.paddingWidth,
                binding.textViewPreviewEffect.paddingBottom
            )
            binding.seekbarWidth.progress = nataraText!!.paddingWidth
        }
        if (nataraText!!.text != null) {
            binding.textViewPreviewEffect.text = nataraText!!.text
            binding.addTextEditText.setText(nataraText!!.text)
        }
        if (nataraText!!.textShader != null) {
            binding.textViewPreviewEffect.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            binding.textViewPreviewEffect.paint.setShader(nataraText!!.textShader)
        }
        if (nataraText!!.textAlign == 4) {
            binding.imageViewAlignCenter.setImageDrawable(
                ContextCompat.getDrawable(
                    requireContext(),
                    R.drawable.ic_format_align_center_select
                )
            )
        } else if (nataraText!!.textAlign == 3) {
            binding.imageViewAlignRight.setImageDrawable(
                ContextCompat.getDrawable(
                    requireContext(),
                    R.drawable.ic_format_align_right
                )
            )
        } else if (nataraText!!.textAlign == 2) {
            binding.imageViewAlignLeft.setImageDrawable(
                ContextCompat.getDrawable(
                    requireContext(),
                    R.drawable.ic_format_align_left
                )
            )
        }
        binding.textViewPreviewEffect.setPadding(
            SystemUtil.dpToPx(
                context, nataraText!!.paddingWidth
            ), binding.textViewPreviewEffect.paddingTop, SystemUtil.dpToPx(
                context, nataraText!!.paddingWidth
            ), binding.textViewPreviewEffect.paddingBottom
        )
        binding.textViewPreviewEffect.setTextColor(nataraText!!.textColor)
        binding.textViewPreviewEffect.textAlignment = nataraText!!.textAlign
        binding.textViewPreviewEffect.textSize = nataraText!!.textSize.toFloat()
        FontFileAsset.setFontByName(context, binding.textViewPreviewEffect, nataraText!!.fontName)
        binding.textViewPreviewEffect.invalidate()
    }

    private fun setDefaultStyleForEdittext() {
        binding.addTextEditText.requestFocus()
        binding.addTextEditText.textSize = 20.0f
        binding.addTextEditText.textAlignment = View.TEXT_ALIGNMENT_CENTER
        binding.addTextEditText.setTextColor(Color.parseColor("#000000"))
    }

    private fun initAddTextLayout() {
        textFunctions = getTextFunctions()

        binding.imageViewKeyboard.setOnClickListener {
            reMoveBottomSpace(0F)
            toggleTextEditEditable(true)
            binding.addTextEditText.visibility = View.VISIBLE
            binding.addTextEditText.requestFocus()
            highlightFunction(binding.imageViewKeyboard)
            binding.scrollViewChangeFontLayout.visibility = View.GONE
            binding.scrollViewChangeColorLayout.visibility = View.GONE
            binding.scrollViewChangeColorAdjust.visibility = View.GONE
            binding.linearLayoutEditTextTools.invalidate()
            inputMethodManager!!.toggleSoftInput(2, 0)
        }

        binding.imageViewFonts.setOnClickListener {
            reMoveBottomSpace(0.3F)
            inputMethodManager?.hideSoftInputFromWindow(it.windowToken, 0)
            binding.scrollViewChangeFontLayout.visibility = View.VISIBLE
            binding.scrollViewChangeColorLayout.visibility = View.GONE
            binding.scrollViewChangeColorAdjust.visibility = View.GONE
            binding.addTextEditText.visibility = View.GONE
            toggleTextEditEditable(false)
            highlightFunction(binding.imageViewFonts)
            shadowAdapter!!.setSelectedItem(nataraText!!.fontIndex)
            fontAdapter!!.setSelectedItem(nataraText!!.fontIndex)
        }

        binding.textViewFont.setOnClickListener {
            binding.textViewShadow.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.black
                )
            )
            binding.textViewFont.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.mainColor
                )
            )
            binding.recyclerViewFonts.visibility = View.VISIBLE
            binding.recyclerViewShadow.visibility = View.GONE
        }
        binding.textViewShadow.setOnClickListener {
            binding.textViewShadow.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.mainColor
                )
            )
            binding.textViewFont.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.black
                )
            )
            binding.recyclerViewFonts.visibility = View.GONE
            binding.recyclerViewShadow.visibility = View.VISIBLE
        }
        binding.imageViewAdjust.setOnClickListener {
            reMoveBottomSpace(0.3F)
            inputMethodManager?.hideSoftInputFromWindow(it.windowToken, 0)
            binding.scrollViewChangeColorLayout.visibility = View.GONE
            binding.scrollViewChangeColorAdjust.visibility = View.VISIBLE
            binding.scrollViewChangeFontLayout.visibility = View.GONE
            binding.seekbarBackgroundOpacity.progress = 255 - nataraText!!.backgroundAlpha
            binding.seekbarTextSize.progress = nataraText!!.textSize
            binding.seekbarRadius.progress = nataraText!!.backgroundBorder
            binding.seekbarWidth.progress = nataraText!!.paddingWidth
            binding.seekbarHeight.progress = nataraText!!.paddingHeight
            binding.seekbarTextOpacity.progress = 255 - nataraText!!.textAlpha
            toggleTextEditEditable(false)
            highlightFunction(binding.imageViewAdjust)
        }

        binding.imageViewColor.setOnClickListener {
            reMoveBottomSpace(0.3F)

            inputMethodManager?.hideSoftInputFromWindow(it.windowToken, 0)
            binding.scrollViewChangeColorLayout.visibility = View.VISIBLE
            binding.scrollViewChangeColorAdjust.visibility = View.GONE
            toggleTextEditEditable(false)
            highlightFunction(binding.imageViewColor)
            binding.scrollViewChangeFontLayout.visibility = View.GONE
            binding.addTextEditText.visibility = View.GONE
            binding.textureCarouselPicker.currentItem = nataraText!!.textShaderIndex
            binding.checkboxBackground.isChecked = nataraText!!.isShowBackground
            binding.checkboxBackground.isChecked = nataraText!!.isShowBackground
            if (nataraText!!.textShader != null && binding.imageViewTextTexture.visibility == View.INVISIBLE) {
                binding.imageViewTextTexture.visibility = View.VISIBLE
                binding.viewHighlightTexture.visibility = View.VISIBLE
                return@setOnClickListener
            }
        }

        binding.imageViewSaveChange.setOnClickListener {
            if (nataraText!!.text == null || nataraText!!.text.isEmpty()) {
//                inputMethodManager!!.hideSoftInputFromWindow(view?.windowToken, 0)
//                textEditor!!.onBackButton()
//                dismiss()
                Toast.makeText(requireContext(), "Please add text.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            nataraText!!.textWidth = binding.textViewPreviewEffect.measuredWidth
            nataraText!!.textHeight = binding.textViewPreviewEffect.measuredHeight
            inputMethodManager!!.hideSoftInputFromWindow(view?.windowToken, 0)
            textEditor!!.onDone(nataraText)
            dismiss()
        }
        binding.imageViewAlignLeft.setOnClickListener {
            if (nataraText!!.textAlign == 3 || nataraText!!.textAlign == 4) {
                nataraText!!.textAlign = 2
                binding.imageViewAlignLeft.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.ic_format_align_left_select
                    )
                )
                binding.imageViewAlignCenter.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.ic_format_align_center
                    )
                )
                binding.imageViewAlignRight.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.ic_format_align_right
                    )
                )
            }
            binding.textViewPreviewEffect.textAlignment = nataraText!!.textAlign
            val textView = binding.textViewPreviewEffect
            textView.text =
                binding.textViewPreviewEffect.text.toString().trim { it <= ' ' } + " "
            binding.textViewPreviewEffect.text =
                binding.textViewPreviewEffect.text.toString().trim { it <= ' ' }
        }
        binding.imageViewAlignCenter.setOnClickListener {
            if (nataraText!!.textAlign == 2 || nataraText!!.textAlign == 3) {
                nataraText!!.textAlign = 4
                binding.imageViewAlignCenter.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.ic_format_align_center_select
                    )
                )
                binding.imageViewAlignLeft.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.ic_format_align_left
                    )
                )
                binding.imageViewAlignRight.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.ic_format_align_right
                    )
                )
            }
            binding.textViewPreviewEffect.textAlignment = nataraText!!.textAlign
            val textViews = binding.textViewPreviewEffect
            textViews.text =
                binding.textViewPreviewEffect.text.toString().trim { it <= ' ' } + " "
            binding.textViewPreviewEffect.text =
                binding.textViewPreviewEffect.text.toString().trim { it <= ' ' }
        }
        binding.imageViewAlignRight.setOnClickListener {
            if (nataraText!!.textAlign == 4 || nataraText!!.textAlign == 2) {
                nataraText!!.textAlign = 3
                binding.imageViewAlignLeft.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.ic_format_align_left
                    )
                )
                binding.imageViewAlignCenter.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.ic_format_align_center
                    )
                )
                binding.imageViewAlignRight.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.ic_format_align_right_select
                    )
                )
            }
            binding.textViewPreviewEffect.textAlignment = nataraText!!.textAlign
            val textViewz = binding.textViewPreviewEffect
            textViewz.text =
                binding.textViewPreviewEffect.text.toString().trim { it <= ' ' } + " "
            binding.textViewPreviewEffect.text =
                binding.textViewPreviewEffect.text.toString().trim { it <= ' ' }
        }
        binding.scrollViewChangeFontLayout.visibility = View.GONE
        binding.scrollViewChangeColorAdjust.visibility = View.GONE
        binding.scrollViewChangeColorLayout.visibility = View.GONE
        binding.imageViewTextTexture.visibility = View.INVISIBLE
        binding.viewHighlightTexture.visibility = View.GONE
        binding.seekbarWidth.progress = nataraText!!.paddingWidth
        colorItems = getColorItems()
        textTextureItems = textTextures
    }

    override fun onResume() {
        super.onResume()
        ViewCompat.setOnApplyWindowInsetsListener(
            dialog!!.window!!.decorView,
            object : OnApplyWindowInsetsListener {
                override fun onApplyWindowInsets(
                    view: View,
                    windowInsetsCompat: WindowInsetsCompat,
                ): WindowInsetsCompat {
                    return ViewCompat.onApplyWindowInsets(
                        this@TextFragment.dialog!!.window!!.decorView,
                        windowInsetsCompat.inset(
                            windowInsetsCompat.systemWindowInsetLeft,
                            0,
                            windowInsetsCompat.systemWindowInsetRight,
                            windowInsetsCompat.systemWindowInsetBottom
                        )
                    )
                }
            })
    }

    fun setOnTextEditorListener(textEditor2: TextEditor?) {
        textEditor = textEditor2
    }

    private fun highlightFunction(imageView: ImageView?) {
        for (next: ImageView in textFunctions!!) {
            if (next == imageView) {
                imageView.background = ContextCompat.getDrawable(requireContext(), R.drawable.line)
                imageView.imageTintList = ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.mainColor))
            } else {
                next.background = ContextCompat.getDrawable(requireContext(), R.drawable.line_fake)
                next.imageTintList = ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.white))
            }
        }
    }

    private fun toggleTextEditEditable(z: Boolean) {
        binding.addTextEditText.isFocusable = z
        binding.addTextEditText.isFocusableInTouchMode = z
        binding.addTextEditText.isClickable = z
    }

    private fun getTextFunctions(): List<ImageView> {
        val arrayList: ArrayList<ImageView> = arrayListOf()
        arrayList.add(binding.imageViewKeyboard)
        arrayList.add(binding.imageViewFonts)
        arrayList.add(binding.imageViewColor)
        arrayList.add(binding.imageViewAdjust)
        arrayList.add(binding.imageViewSaveChange)
        return arrayList
    }

    val textTextures: List<PickerItem>
        get() {
            val arrayList: ArrayList<PickerItem> = arrayListOf()
            for (i in 0..41) {
                try {
                    val assets = requireContext().assets
                    arrayList.add(
                        DrawableItem(
                            Drawable.createFromStream(
                                assets.open("texture/texture_" + (i + 1) + ".webp"),
                                null as String?
                            )
                        )
                    )
                } catch (e: Exception) {
                }
            }
            return arrayList
        }

    private fun getColorItems() = arrayListOf<PickerItem>().apply {
        //FREE
        add(ColorItem("#FFFFFF"))
        add(ColorItem("#BBBBBB"))
        add(ColorItem("#4E4E4E"))
        add(ColorItem("#212121"))
        add(ColorItem("#000000"))
        add(ColorItem("#FFD7CD"))
        add(ColorItem("#F9AB9D"))
        add(ColorItem("#EC5C60"))
        add(ColorItem("#CB3243"))
        add(ColorItem("#CD181F"))
        add(ColorItem("#FF0000"))
        add(ColorItem("#FFF2CA"))
        add(ColorItem("#FDE472"))
        add(ColorItem("#F3AF59"))
        add(ColorItem("#FC7F3D"))
        add(ColorItem("#ED3F0F"))
        add(ColorItem("#FFF1F1"))
        add(ColorItem("#FFE1E4"))
        add(ColorItem("#FFA4B9"))
        add(ColorItem("#FF679F"))
        add(ColorItem("#FB2C78"))
        add(ColorItem("#E7D5E7"))
        add(ColorItem("#D3A6D8"))
        add(ColorItem("#BA66AF"))
        add(ColorItem("#A53B8E"))
        add(ColorItem("#65218C"))
        add(ColorItem("#99D2F9"))
        add(ColorItem("#81ADEA"))
        add(ColorItem("#2961A9"))
        add(ColorItem("#0E2E89"))
        add(ColorItem("#171982"))
        add(ColorItem("#A5E7F6"))
        add(ColorItem("#7CE3FF"))
        add(ColorItem("#00B0D0"))
        add(ColorItem("#058BC0"))
        add(ColorItem("#08447E"))
        add(ColorItem("#DEEEE9"))
        add(ColorItem("#B3D0C5"))
        add(ColorItem("#4DAF9D"))
        add(ColorItem("#21887C"))
        add(ColorItem("#0F664E"))
        add(ColorItem("#D3E5A6"))
        add(ColorItem("#AACE87"))
        add(ColorItem("#A3AF38"))
        add(ColorItem("#6D822B"))
        add(ColorItem("#366131"))
        add(ColorItem("#E4D9C0"))
        add(ColorItem("#D6C392"))
        add(ColorItem("#A3815A"))
        add(ColorItem("#72462F"))
        add(ColorItem("#3E3129"))

        add(ColorItem("#A7A7A7"))
        add(ColorItem("#995452"))
        add(ColorItem("#E1D6D7"))
        add(ColorItem("#CCBFD4"))
        add(ColorItem("#A67C80"))
        add(ColorItem("#D4D3CF"))
        add(ColorItem("#7A7185"))
        add(ColorItem("#6E5055"))
        add(ColorItem("#666563"))
        add(ColorItem("#F0E4FB"))
        add(ColorItem("#EED0D5"))
        add(ColorItem("#E1CCD1"))
        add(ColorItem("#C3C9DF"))
        add(ColorItem("#929493"))
        add(ColorItem("#807D5C"))
        add(ColorItem("#E2E4E1"))
        add(ColorItem("#8596A4"))
        add(ColorItem("#ECECEC"))
        add(ColorItem("#96A48C"))
        add(ColorItem("#AFB0B2"))
        add(ColorItem("#BEC0BF"))
        add(ColorItem("#B7C5B3"))
        add(ColorItem("#A0A7BA"))
        add(ColorItem("#FFFAF7"))
        add(ColorItem("#7D8970"))

        add(ColorItem("#FF7063"))
        add(ColorItem("#FF3274"))
        add(ColorItem("#3EA2D7"))
        add(ColorItem("#FFA258"))
        add(ColorItem("#F22D52"))
        add(ColorItem("#F2A0B6"))
        add(ColorItem("#7285F2"))
        add(ColorItem("#3ADB7C"))
        add(ColorItem("#F2C4CD"))
        add(ColorItem("#129AEF"))
        add(ColorItem("#0278A6"))
        add(ColorItem("#0D8C39"))
        add(ColorItem("#5639A5"))
        add(ColorItem("#A482F4"))
        add(ColorItem("#4AE3D2"))
        add(ColorItem("#00D28E"))
        add(ColorItem("#FA4848"))
        add(ColorItem("#434882"))
        add(ColorItem("#730068"))
        add(ColorItem("#729D38"))
        add(ColorItem("#C6E377"))
        add(ColorItem("#022D3C"))
        add(ColorItem("#900C3F"))
        add(ColorItem("#FF5733"))
        add(ColorItem("#FFC300"))
    }

    private fun reMoveBottomSpace(floatValue: Float) {
        val mConstrainLayout = binding.mCLBottom
        val lp = mConstrainLayout.layoutParams as ConstraintLayout.LayoutParams
        lp.matchConstraintPercentHeight = floatValue
        mConstrainLayout.layoutParams = lp
    }

    companion object {
        val EXTRA_COLOR_CODE = "extra_color_code"
        val EXTRA_INPUT_TEXT = "extra_input_text"
        val TAG = "TextFragment"

        @JvmOverloads
        fun show(
            appCompatActivity: AppCompatActivity,
            str: String = "Test",
            @ColorInt i: Int = ContextCompat.getColor(appCompatActivity, R.color.black),
        ): TextFragment {
            val bundle = Bundle()
            bundle.putString(EXTRA_INPUT_TEXT, str)
            bundle.putInt(EXTRA_COLOR_CODE, i)
            val textFragment = TextFragment()
            textFragment.arguments = bundle
            textFragment.show(appCompatActivity.supportFragmentManager, TAG)
            return textFragment
        }

        fun show(
            appCompatActivity: AppCompatActivity,
            addTextProperties: NataraText?,
        ): TextFragment {
            val addTextFragment = TextFragment()
            addTextFragment.setPolishText(addTextProperties)
            addTextFragment.show(appCompatActivity.supportFragmentManager, TAG)
            return addTextFragment
        }
    }
}
