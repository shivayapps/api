package com.natara.photo.collage.maker.bgremover.fragment

import android.app.Activity.RESULT_OK
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.lyrebirdstudio.croppylib.Croppy
import com.lyrebirdstudio.croppylib.main.CropRequest
import com.natara.photo.collage.maker.bgremover.adapter.BgApiCategoryAdapter
import com.natara.photo.collage.maker.bgremover.model.BackgroundEntity
import com.natara.photo.collage.maker.bgremover.viewmodel.EditorViewModel
import com.natara.photo.collage.maker.databinding.FragmentBackgroundBinding
import com.natara.photo.collage.maker.extentions.hide
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream


class BackgroundApiFragment : Fragment() {
    private var folderName: String? = null

    private val mEditorViewModel by lazy {
        EditorViewModel()
    }

    private lateinit var listener: OnActionCompleteListener

    private fun setOnActionCompleteListener(listener: OnActionCompleteListener) {
        this.listener = listener
    }

    interface OnActionCompleteListener {
        fun onBackgroundItemClick(path: String?)
    }

    private val stickerAdapter: BgApiCategoryAdapter by lazy {
        BgApiCategoryAdapter(object : BgApiCategoryAdapter.OnFilterFrame {
            override fun onClickFrame(item: BackgroundEntity) {
//                setResult(RESULT_OK, intent.putExtra("path", item.image))
//                finish()
                listener.onBackgroundItemClick(item.image)
            }

        })
    }

    private lateinit var binding: FragmentBackgroundBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentBackgroundBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        folderName = arguments?.getString("folderName")

        binding.framesRV.apply {
            adapter = stickerAdapter
        }

        binding.progress.visibility = View.VISIBLE
        binding.framesRV.visibility = View.VISIBLE

        Handler(Looper.getMainLooper()).postDelayed({
            if (!isDetached) {
                loadData()
            }
        }, 500)

        val listener =  object : RecyclerView.OnItemTouchListener {
            private var startX = 0f

            override fun onInterceptTouchEvent(
                recyclerView: RecyclerView,
                event: MotionEvent
            ): Boolean =
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { startX = event.x }
                    MotionEvent.ACTION_MOVE -> {
                        val isScrollingRight = event.x < startX
                        val scrollItemsToRight = isScrollingRight && recyclerView.canScrollRight
                        val scrollItemsToLeft = !isScrollingRight && recyclerView.canScrollLeft
                        val disallowIntercept = scrollItemsToRight || scrollItemsToLeft
                        recyclerView.parent.requestDisallowInterceptTouchEvent(disallowIntercept)
                    }
                    MotionEvent.ACTION_UP -> { startX = 0f }
                    else -> Unit
                }.let { false }

            override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) = Unit
            override fun onRequestDisallowInterceptTouchEvent(disallowIntercept: Boolean) = Unit
        }

        binding.framesRV.addOnItemTouchListener(listener)
    }



    private fun loadData() {
        lifecycleScope.launch {
            if (folderName != null) {

                mEditorViewModel.loadCategoryItem(folderName!!)
                mEditorViewModel.bgItemList.observe(viewLifecycleOwner) {
                    Log.d("TAG", "loadData: ${it.size}")
                    stickerAdapter.submitList(it)
                }
                binding.progress.hide()

            }
        }
    }

    companion object {
        @JvmStatic
        fun newInstance(
            folderName: String?,
            listener: OnActionCompleteListener
        ): BackgroundApiFragment {
            val framesFrag = BackgroundApiFragment()
            framesFrag.setOnActionCompleteListener(listener)
            val bundle = Bundle()
            bundle.putString("folderName", folderName)
            framesFrag.arguments = bundle
            return framesFrag
        }
    }

    private val RecyclerView.canScrollRight: Boolean
        get() = canScrollHorizontally(SCROLL_DIRECTION_RIGHT)

    private val RecyclerView.canScrollLeft: Boolean
        get() = canScrollHorizontally(SCROLL_DIRECTION_LEFT)

    private val SCROLL_DIRECTION_RIGHT = 1
    private val SCROLL_DIRECTION_LEFT = -1
}