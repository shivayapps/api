package com.natara.photo.collage.maker.ui.language.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.natara.photo.collage.maker.CollageMaker
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.databinding.ActivityLanguageBinding
import com.natara.photo.collage.maker.extentions.changeLanguage
import com.natara.photo.collage.maker.extentions.defaultLanguage
import com.natara.photo.collage.maker.extentions.hide
import com.natara.photo.collage.maker.extentions.languageList
import com.natara.photo.collage.maker.extentions.show
import com.natara.photo.collage.maker.ui.home.activity.MainActivity
import com.natara.photo.collage.maker.ui.intro.activity.IntroActivity
import com.natara.photo.collage.maker.ui.language.adapter.LanguageAdapter
import com.natara.photo.collage.maker.ui.language.model.LanguageModel

class LanguageActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLanguageBinding

    var tempLanguage = defaultLanguage

    private val adapter: LanguageAdapter by lazy {
        LanguageAdapter(object : LanguageAdapter.LanguageClickListener {
            override fun languageItemClick(item: LanguageModel) {
                tempLanguage = item.code
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLanguageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Glide.with(this).load(R.drawable.baseline_language_24).into(binding.toolbar.mIVBack)
        binding.toolbar.mTVSave.text = getString(R.string.select)
        binding.toolbar.mTVTitle.text = getString(R.string.language)
        binding.mRVLanguage.adapter = adapter
        adapter.selectedItemPos = CollageMaker.prefManager?.setAppLanguage.toString()

        binding.toolbar.mTVSave.setOnClickListener {

            binding.toolbar.mTVSave.hide()
            binding.toolbar.progressBar.show()
            Handler(Looper.getMainLooper()).postDelayed({

                CollageMaker.prefManager?.needToShowLanguage = false
                changeLanguage(tempLanguage)
                if (CollageMaker.prefManager?.needToShowIntro == true) {
                    startActivity(
                        Intent(
                            this,
                            IntroActivity::class.java
                        ).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    )
                    finish()
                } else {
                    startActivity(
                        Intent(
                            this,
                            MainActivity::class.java
                        ).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    )
                    finish()
                }
            }, 3000)


        }

        adapter.submitList(languageList)
    }
}