package com.natara.photo.collage.maker.ui.language.model

data class LanguageModel(val flag: Int, val name: String, val code: String)
