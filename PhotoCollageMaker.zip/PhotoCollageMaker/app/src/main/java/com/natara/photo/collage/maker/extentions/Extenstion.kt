package com.natara.photo.collage.maker.extentions

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.res.AssetManager
import android.content.res.Configuration
import android.graphics.*
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.view.animation.TranslateAnimation
import android.widget.ImageView
import android.widget.Toast
import androidx.annotation.ColorInt
import androidx.annotation.NonNull
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.LinearSmoothScroller
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.bumptech.glide.Priority
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.karumi.dexter.Dexter
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.single.PermissionListener
import com.natara.photo.collage.maker.CollageMaker
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.bgremover.MTouch.MultiTouchListener
import com.natara.photo.collage.maker.databinding.DialogCustomLayoutBinding
import com.natara.photo.collage.maker.ui.language.model.LanguageModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.*
import kotlin.math.roundToInt

fun ImageView.setThumbnail(context: Context, path: String) {
    val requestOptions = RequestOptions
        .placeholderOf(R.drawable.ic_loading)
        .override(200, 200)
        .diskCacheStrategy(DiskCacheStrategy.ALL)
        .skipMemoryCache(false)
        .priority(Priority.IMMEDIATE)
        .dontAnimate()
        .dontTransform()
        .encodeFormat(Bitmap.CompressFormat.PNG)

    Glide.with(context)
        .load(path)
        .apply(requestOptions)
        .into(this@setThumbnail)

}

fun View.click(action: (View) -> Unit) = setOnClickListener {
    action(it)
}

fun calculateRatio(width: Int, height: Int): String {
    var gcd = 1
    var ratio = ""
    var i = 1
    while (i <= width && i <= height) {

        if (width % i == 0 && height % i == 0) {
            gcd = i
        }
        i++
    }
    ratio = "${width / gcd}:${height / gcd}"
    return ratio
}

//fun View.clickWithAd(activity: Activity, action: (View) -> Unit) = setOnClickListener {
//    (activity as AdsActivity).showInterstitialAdsWithCounter {
//        action(it)
//    }
//}


fun getProgressDrawableColors(): IntArray {
    val colors = IntArray(4)
    colors[0] = Color.RED
    colors[1] = Color.BLUE
    colors[2] = Color.YELLOW
    colors[3] = Color.GREEN
    return colors
}

fun ImageView.startTouch() {
    setOnTouchListener(object : MultiTouchListener() {
        @SuppressLint("ClickableViewAccessibility")
        override fun onTouch(view: View?, event: MotionEvent?): Boolean {
            return super.onTouch(view, event)
        }
    })
}

fun getBitmapFromAsset(context: Context, filePath: String?): Bitmap? {
    val assetManager = context.assets
    var bitmap: Bitmap? = null
    try {
        val istr: InputStream = assetManager.open(filePath!!)
        bitmap = BitmapFactory.decodeStream(istr)
    } catch (e: IOException) {
        // handle exception
    }
    return bitmap
}

fun createDynamicGradient(color: String): Bitmap? {
    val split: Array<String> = color.split(",".toRegex()).toTypedArray()
    val color1 = split[0]
    val color2 = split[1]
    val gradient =
        LinearGradient(
            0f,
            0f,
            0f,
            1024f,
            Color.parseColor(color1),
            Color.parseColor(color2),
            Shader.TileMode.CLAMP
        )
    val p = Paint()
    p.isDither = true
    p.shader = gradient
    val bitmap = Bitmap.createBitmap(1024, 1024, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawRect(
        RectF(
            0f, 0f, 1024f,
            1024f
        ), p
    )
    return bitmap
}

fun createDynamicColor(context: Context, color: Int): Bitmap {
    var mPath = ""
    val bitmap = Bitmap.createBitmap(
        1024,
        1024,
        Bitmap.Config.ARGB_8888
    )
    val canvas = Canvas(bitmap)
    canvas.drawColor(color)
    bitmap?.let {
        val myDir = File("${context.cacheDir}/color")
        myDir.mkdirs()
        val fname = "temp.png"
        val file = File(myDir, fname)
        if (file.exists()) file.delete()
        mPath = try {
            val out = FileOutputStream(file)
            it.compress(Bitmap.CompressFormat.PNG, 100, out)
            out.flush()
            out.close()
            file.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
        it.recycle()
    }
    return BitmapFactory.decodeFile(mPath)
}

fun Context.openActivity(cls: Class<*>, action: (Bundle.() -> Unit)? = null) {
    action?.let {
        startActivity(Intent(this, cls).apply { putExtras(Bundle().apply { action(this) }) })
    } ?: startActivity(Intent(this, cls))
}

/**
 * This method converts dp unit to equivalent pixels, depending on device density.
 *
 * @param dp A value in dp (density independent pixels) unit. Which we need to convert into pixels
 * @param context Context to get resources and device specific display metrics
 * @return A float value to represent px equivalent to dp depending on device density
 */
fun dp2px(dp: Float, context: Context): Float {
    return dp * (context.resources.displayMetrics.densityDpi.toFloat() / DisplayMetrics.DENSITY_DEFAULT)
}

fun Float.dp(context: Context): Float {
    return this * (context.resources.displayMetrics.densityDpi.toFloat() / DisplayMetrics.DENSITY_DEFAULT)
}

private fun Context.rateIntentForUrl(url: String): Intent {
    val intent = Intent(
        Intent.ACTION_VIEW,
        Uri.parse(java.lang.String.format("%s?id=%s", url, getPackageName()))
    )
    var flags = Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_MULTIPLE_TASK
    flags = if (Build.VERSION.SDK_INT >= 21) {
        flags or Intent.FLAG_ACTIVITY_NEW_DOCUMENT
    } else {
        flags or Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET
    }
    intent.addFlags(flags)
    return intent
}

fun Context.isOnline(): Boolean {
    val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val capabilities =
            connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
        if (capabilities != null) {
            when {
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                    return true
                }

                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                    return true
                }

                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> {
                    return true
                }
            }
        }
    } else {
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        if (activeNetworkInfo != null && activeNetworkInfo.isConnected) {
            return true
        }
    }
    return false
}

/**
 * This method converts device specific pixels to density independent pixels.
 *
 * @param px A value in px (pixels) unit. Which we need to convert into db
 * @param context Context to get resources and device specific display metrics
 * @return A float value to represent dp equivalent to px value
 */

fun getHexCode(@ColorInt color: Int): String {
    val a = Color.alpha(color)
    val r = Color.red(color)
    val g = Color.green(color)
    val b = Color.blue(color)
    return String.format(Locale.getDefault(), "%02X%02X%02X%02X", a, r, g, b)
}

fun Context.px2dp(px: Float): Float {
    return px / (resources.displayMetrics.densityDpi.toFloat() / DisplayMetrics.DENSITY_DEFAULT)
}

fun View.show() = apply {
    visibility = View.VISIBLE
}

fun View.hide() = apply {
    visibility = View.GONE
}

fun View.invisible() = apply {
    visibility = View.INVISIBLE
}

fun numberOfAd(coin: Int): Int {
    return if (coin < 5) 1 else (coin / 10.0).roundToInt().toInt()
}

fun Activity.adWidth(frameLayout: View): Int {
    val display = windowManager.defaultDisplay
    val outMetrics = DisplayMetrics()
    display.getMetrics(outMetrics)

    val density = outMetrics.density

    var adWidthPixels = frameLayout.width.toFloat()
    if (adWidthPixels == 0f) {
        adWidthPixels = outMetrics.widthPixels.toFloat()
    }

    return (adWidthPixels / density).toInt()
}


fun View.disable(isAlpha: Boolean = true) {
    isEnabled = false
    if (isAlpha)
        alpha = 0.4f
}

fun View.disableNew(isAlpha: Boolean = true) {
    isEnabled = false
}

fun View.enable(isAlpha: Boolean = true) {
    isEnabled = true
    if (isAlpha)
        alpha = 1f
}

fun ViewGroup.getAllChildren(): List<View> {
    val children = ArrayList<View>()
    for (i in 0 until this.childCount) {
        children.add(this.getChildAt(i))
    }
    return children
}

fun getAssetsData(context: Context, name: String): ArrayList<String?> {
    val assetManager: AssetManager = context.assets
    val list: ArrayList<String?> = arrayListOf()
    val path: ArrayList<String?> = arrayListOf()
    val files = assetManager.list(name)
    list.addAll(files!!)
    for (i in list.indices) {
        path.add(Uri.parse("file:///android_asset/$name/${list[i]}").path)
    }
    return path
}

fun getBitmapFromAssets(context: Context, str: String): Bitmap {
    val open = context.assets.open(str)
    val decodeStream = BitmapFactory.decodeStream(open)
    open.close()
    return decodeStream
}


fun RecyclerView.smoothSnapToPosition(
    position: Int,
    snapMode: Int = LinearSmoothScroller.SNAP_TO_START,
) {
    val smoothScroller = object : LinearSmoothScroller(this.context) {
        override fun getVerticalSnapPreference(): Int = snapMode
        override fun getHorizontalSnapPreference(): Int = snapMode
    }
    smoothScroller.targetPosition = position
    layoutManager?.startSmoothScroll(smoothScroller)
}

fun RecyclerView?.perfectScroll(size: Int, up: Boolean = true, smooth: Boolean = true) {
    this?.apply {
        if (size > 0) {
            if (smooth) {
                val minDirectScroll = 10 // left item to scroll
                //smooth scroll
                if (size > minDirectScroll) {
                    //scroll directly to certain position
                    val newSize = if (up) minDirectScroll else size - minDirectScroll
                    //scroll to new position
                    val newPos = newSize - 1
                    //direct scroll
                    scrollToPosition(newPos)
                    //smooth scroll to rest
                    perfectScroll(minDirectScroll, true)

                } else {
                    //direct smooth scroll
                    smoothScrollToPosition(if (up) 0 else size - 1)
                }
            } else {
                //direct scroll
                scrollToPosition(if (up) 0 else size - 1)
            }
        }
    }
}

fun loadBitmapFromView(v: View, width: Int, height: Int): Bitmap {
    val b: Bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val c = Canvas(b)
    v.draw(c)
    return b
}

fun getResizedBitmap(bm: Bitmap, newWidth: Int, newHeight: Int): Bitmap? {
    val width = bm.width
    val height = bm.height
    val scaleWidth = newWidth.toFloat() / width
    val scaleHeight = newHeight.toFloat() / height
    // CREATE A MATRIX FOR THE MANIPULATION
    val matrix = Matrix()
    // RESIZE THE BIT MAP
    matrix.postScale(scaleWidth, scaleHeight)

    // "RECREATE" THE NEW BITMAP
    val resizedBitmap = Bitmap.createBitmap(
        bm, 0, 0, width, height, matrix, false
    )
    bm.recycle()
    return resizedBitmap
}

fun Activity.requestCameraPermission(onPermissionGranted: () -> Unit) {
    Dexter.withContext(this).withPermission(Manifest.permission.CAMERA)
        .withListener(object : PermissionListener {
            override fun onPermissionGranted(p0: PermissionGrantedResponse?) {
                onPermissionGranted()
            }

            override fun onPermissionDenied(p0: PermissionDeniedResponse?) {
                permissionCameraDialog()
            }

            override fun onPermissionRationaleShouldBeShown(
                p0: com.karumi.dexter.listener.PermissionRequest?,
                p1: PermissionToken?,
            ) {
                p1?.continuePermissionRequest()
            }

        }).check()
}

fun Activity.requestMultiplePermissions(onPermissionGranted: () -> Unit) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Dexter.withContext(this)
            .withPermission(
                Manifest.permission.READ_MEDIA_IMAGES
            ).withListener(object : PermissionListener {
                override fun onPermissionGranted(p0: PermissionGrantedResponse?) {
                    onPermissionGranted()
                }

                override fun onPermissionDenied(p0: PermissionDeniedResponse?) {
                    permissionDialog()
                }

                override fun onPermissionRationaleShouldBeShown(
                    p0: com.karumi.dexter.listener.PermissionRequest?,
                    p1: PermissionToken?,
                ) {
                    p1?.continuePermissionRequest()
                }

            }).withErrorListener {
                permissionDialog()
            }
            .check()
    } else {
        Dexter.withContext(this)
            .withPermission(
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ).withListener(object : PermissionListener {
                override fun onPermissionGranted(p0: PermissionGrantedResponse?) {
                    onPermissionGranted()
                }

                override fun onPermissionDenied(p0: PermissionDeniedResponse?) {
                    permissionDialog()
                }

                override fun onPermissionRationaleShouldBeShown(
                    p0: com.karumi.dexter.listener.PermissionRequest?,
                    p1: PermissionToken?,
                ) {
                    p1?.continuePermissionRequest()
                }

            }).withErrorListener {
                permissionDialog()
            }
            .check()
    }
}

private fun Activity.permissionDialog() {
    val alertDialog = MaterialAlertDialogBuilder(this)
    alertDialog.setMessage("Storage Permission Required To Load Image From External Storage.")
    alertDialog.setNegativeButton("Cancel") { dialog, witch ->
        dialog.dismiss()
        Toast.makeText(this, "Permission Required!", Toast.LENGTH_SHORT).show()
    }
    alertDialog.setPositiveButton("OK") { dialog, witch ->
        dialog.dismiss()
        startInstalledAppDetailsActivity(this)
    }
    alertDialog.setOnDismissListener {
    }
    alertDialog.show()
}

private fun Activity.permissionCameraDialog() {
    val alertDialog = MaterialAlertDialogBuilder(this)
    alertDialog.setMessage("Camera Permission Required To Capture Image.")
    alertDialog.setNegativeButton("Cancel") { dialog, witch ->
        dialog.dismiss()
        Toast.makeText(this, "Permission Required!", Toast.LENGTH_SHORT).show()
    }
    alertDialog.setPositiveButton("OK") { dialog, witch ->
        dialog.dismiss()
        startInstalledAppDetailsActivity(this)
    }
    alertDialog.setOnDismissListener {
    }
    alertDialog.show()
}

private fun startInstalledAppDetailsActivity(context: Activity?) {
    if (context == null) {
        return
    }
    val i = Intent()
    i.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
    i.addCategory(Intent.CATEGORY_DEFAULT)
    i.data = Uri.parse("package:" + context.packageName)
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
    i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
    context.startActivity(i)
}

fun slideUp(view: View) {
    view.visibility = View.VISIBLE
    val animate = TranslateAnimation(
        0f,  // fromXDelta
        0f,  // toXDelta
        view.height.toFloat(),
        0f
    ) // toYDelta
    animate.duration = 200
    animate.fillAfter = true
    view.startAnimation(animate)
}

// slide the view from its current position to below itself
fun slideDown(view: View) {
    val animate = TranslateAnimation(
        0f,  // fromXDelta
        0f,  // toXDelta
        0f,  // fromYDelta
        view.height.toFloat()
    ) // toYDelta
    animate.duration = 400
    animate.fillAfter = true
    view.startAnimation(animate)
}

fun Context.shareOwnApp() {
    val shareIntent = Intent(Intent.ACTION_SEND)
    shareIntent.type = "text/plain"
    shareIntent.putExtra(
        Intent.EXTRA_SUBJECT,
        "Go with Collage Maker to Create amazing Photo Collage"
    )
    val shareMessage =
        "https://play.google.com/store/apps/details?id=${packageName}"
    shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
    startActivity(Intent.createChooser(shareIntent, "Choose One"))
}

fun Context.rateApp() {
    try {
        val rateIntent = rateIntentForUrl("market://details")
        startActivity(rateIntent)
    } catch (e: ActivityNotFoundException) {
        val rateIntent = rateIntentForUrl("https://play.google.com/store/apps/details")
        startActivity(rateIntent)
    }
}

fun fadeOut(v: View, duration: Int) {
    v.animate().alpha(0f).setDuration(duration.toLong())
    Handler(Looper.getMainLooper()).postDelayed({
        v.visibility = View.GONE
    },500)
}

fun fadeIn(v: View, duration: Int) {
    v.animate().alpha(1f).setDuration(duration.toLong())
    v.visibility = View.VISIBLE
}

fun Context.viewSlideUp(showLayout: View, isFast: Boolean = false) =
    CoroutineScope(Dispatchers.Main).launch {
        showLayout.visibility = View.VISIBLE
        val slideUpAnimation =
            AnimationUtils.loadAnimation(
                this@viewSlideUp,
                if (isFast) R.anim.slide_up_fast else R.anim.slide_up
            )
        showLayout.startAnimation(slideUpAnimation)
        slideUpAnimation.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(animation: Animation) {}
            override fun onAnimationEnd(animation: Animation) {}
            override fun onAnimationRepeat(animation: Animation) {}
        })
    }

fun Context.viewSlideLeft(hideLayout: View, isFast: Boolean = false) {
    if (hideLayout.visibility == View.VISIBLE) {
        val slideUpAnimation =
            AnimationUtils.loadAnimation(
                this,
                if (isFast) R.anim.slide_left_fast else R.anim.slide_left
            )
        hideLayout.visibility = View.GONE
        hideLayout.startAnimation(slideUpAnimation)
        slideUpAnimation.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(animation: Animation) {}
            override fun onAnimationEnd(animation: Animation) {}
            override fun onAnimationRepeat(animation: Animation) {}
        })
    }
}

fun Context.viewSlideRight(showLayout: View, isFast: Boolean = false) {
    showLayout.visibility = View.VISIBLE

    val slideDownAnimation = AnimationUtils.loadAnimation(
        this,
        if (isFast) R.anim.slide_right_fast else R.anim.slide_right
    )
    showLayout.startAnimation(slideDownAnimation)
    slideDownAnimation.setAnimationListener(object : Animation.AnimationListener {
        override fun onAnimationStart(animation: Animation) {}
        override fun onAnimationEnd(animation: Animation) {}
        override fun onAnimationRepeat(animation: Animation) {}
    })

}

fun Context.viewSlideDown(hideLayout: View, isFast: Boolean = false) =
    CoroutineScope(Dispatchers.Main).launch {

        if (hideLayout.visibility == View.VISIBLE) {

            val slideDownAnimation = AnimationUtils.loadAnimation(
                this@viewSlideDown,
                if (isFast) R.anim.slide_down_fast else R.anim.slide_down
            )
            hideLayout.visibility = View.GONE
            hideLayout.startAnimation(slideDownAnimation)
            slideDownAnimation.setAnimationListener(object : Animation.AnimationListener {
                override fun onAnimationStart(animation: Animation) {}
                override fun onAnimationEnd(animation: Animation) {}
                override fun onAnimationRepeat(animation: Animation) {}
            })

        }
    }


fun Context.layerSlideLeft(showLayout: View, isFast: Boolean = false) {
    showLayout.visibility = View.VISIBLE
    val slideUpAnimation =
        AnimationUtils.loadAnimation(
            this,
            if (isFast) R.anim.layer_slide_left_fast else R.anim.layer_slide_left
        )
    showLayout.startAnimation(slideUpAnimation)
    slideUpAnimation.setAnimationListener(object : Animation.AnimationListener {
        override fun onAnimationStart(animation: Animation) {}
        override fun onAnimationEnd(animation: Animation) {}
        override fun onAnimationRepeat(animation: Animation) {}
    })
}

fun Context.layerSlideRight(hideLayout: View, isFast: Boolean = false) {

    if (hideLayout.visibility == View.VISIBLE) {

        val slideDownAnimation = AnimationUtils.loadAnimation(
            this,
            if (isFast) R.anim.layer_slide_right_fast else R.anim.layer_slide_right
        )
        hideLayout.visibility = View.GONE
        hideLayout.startAnimation(slideDownAnimation)
        slideDownAnimation.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(animation: Animation) {}
            override fun onAnimationEnd(animation: Animation) {}
            override fun onAnimationRepeat(animation: Animation) {}
        })

    }
}


fun Context.getStringByLocal(resId: Int): String {
    return getStringByLocalPlus17(
        this,
        resId,
         "en"
    )
}

@NonNull
private fun getStringByLocalPlus17(context: Context, resId: Int, locale: String): String {
    val configuration = Configuration(context.resources.configuration)
    configuration.setLocale(Locale(locale))
    return context.createConfigurationContext(configuration).resources.getString(resId)
}

fun Activity.customStickerDialog(title: String, subTitle: String, onPositiveClick: () -> Unit, onNativeClick: () -> Unit) {
    val dialogBinding = DialogCustomLayoutBinding.inflate(layoutInflater)
    val discardDialog = AlertDialog.Builder(this@customStickerDialog).setView(dialogBinding.root).create()
    discardDialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
    discardDialog.show()
    dialogBinding.txtTitle.text = title
    dialogBinding.txtMessage.text = subTitle
    with(dialogBinding.btnNagative) {
        text = getStringByLocal(R.string.no)
        click {
            discardDialog.dismiss()
            onNativeClick()
        }
    }
    with(dialogBinding.btnPositive) {
        text = getStringByLocal(R.string.yes)
        click {
            discardDialog.dismiss()
            onPositiveClick()
        }
    }
}

fun Activity.customDialog(title: String, subTitle: String, onPositiveClick: () -> Unit) {
    val dialogBinding = DialogCustomLayoutBinding.inflate(layoutInflater)
    val discardDialog = AlertDialog.Builder(this@customDialog).setView(dialogBinding.root).create()
    discardDialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
    discardDialog.show()
    dialogBinding.txtTitle.text = title
    dialogBinding.txtMessage.text = subTitle
    with(dialogBinding.btnNagative) {
        text = getStringByLocal(R.string.no)
        click {
            discardDialog.dismiss()
        }
    }
    with(dialogBinding.btnPositive) {
        text = getStringByLocal(R.string.yes)
        click {
            discardDialog.dismiss()
            onPositiveClick()
        }
    }

    /*if (AdsActivity.dialogNative != null) {
        BannerHelper.showNativeAd(
            activity = this@customDialog,
            fAdContainer = dialogBinding.mFLad,
            adLayout = R.layout.native_ad_for_dialog,
            adEnable = true,
            nativeAd = AdsActivity.dialogNative,
            onShow = {
                dialogBinding.mFLad.show()
            },
            onHide = {
                dialogBinding.mFLad.hide()
            }
        )
    } else {

        loadOfflineNative(
            fAdContainer = dialogBinding.mFLad,
            adLayout = R.layout.native_ad_for_dialog,
            adEnable = true,
            admobNativeIds = getString(R.string.dialogue_native),
            onLoad = {
                dialogBinding.mFLad.show()
            },
            onFail = {
                dialogBinding.mFLad.hide()
            },
            onClick = {}
        )
    }*/

}

fun Activity.customWatchAdDialog(title: String, subTitle: String, onPositiveClick: () -> Unit) {
    val dialogBinding = DialogCustomLayoutBinding.inflate(layoutInflater)
    val discardDialog = AlertDialog.Builder(this@customWatchAdDialog).setView(dialogBinding.root).create()
    discardDialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
    discardDialog.show()
    dialogBinding.txtTitle.text = title
    dialogBinding.txtMessage.text = subTitle
    with(dialogBinding.btnNagative) {
        text = getStringByLocal(com.google.android.material.R.string.mtrl_picker_cancel)
        click {
            discardDialog.dismiss()
        }
    }
    with(dialogBinding.btnPositive) {
        text = getStringByLocal(R.string.watch_ad)
        click {
            discardDialog.dismiss()
            onPositiveClick()
        }
    }

    dialogBinding.mFLad.hide()

}

fun ViewPager2.findCurrentFragment(fragmentManager: FragmentManager): Fragment? {
    return fragmentManager.findFragmentByTag("f$currentItem")
}

fun ViewPager2.findFragmentAtPosition(
    fragmentManager: FragmentManager,
    position: Int
): Fragment? {
    return fragmentManager.findFragmentByTag("f$position")
}

val defaultLanguage = "en"

fun Context.changeLanguage(language: String) {
    val config = resources.configuration
    val locale = Locale(language)
    Locale.setDefault(locale)
    config.setLocale(locale)

    createConfigurationContext(config)
    resources.updateConfiguration(config, resources.displayMetrics)

    CollageMaker.prefManager?.setAppLanguage = language
}

val languageList = arrayListOf(
    LanguageModel(R.drawable.chinaa, "中國人", "zh"),
    LanguageModel(R.drawable.dutch, "Nederlands", "nl"),
    LanguageModel(R.drawable.ic_america, "English", "en"),
    LanguageModel(R.drawable.finnish, "Suomalainen", "fi"),
    LanguageModel(R.drawable.french, "Français", "fr"),
    LanguageModel(R.drawable.german, "Allemand", "de"),
    LanguageModel(R.drawable.india, "ગુજરાતી", "gu"),
    LanguageModel(R.drawable.india, "हिंदी", "hi"),
    LanguageModel(R.drawable.indonesia, "bahasa Indonesia", "in"),
    LanguageModel(R.drawable.italy, "Italiano", "it"),
    LanguageModel(R.drawable.korea, "한국인", "ko"),
    LanguageModel(R.drawable.portugal, "Português", "pt"),
    LanguageModel(R.drawable.slovakia, "slovenský", "sk"),
    LanguageModel(R.drawable.spanish, "Español", "es")
)