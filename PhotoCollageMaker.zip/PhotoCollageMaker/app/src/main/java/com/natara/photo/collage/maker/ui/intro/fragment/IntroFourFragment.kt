package com.natara.photo.collage.maker.ui.intro.fragment

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.natara.photo.collage.maker.CollageMaker
import com.natara.photo.collage.maker.R
import com.natara.photo.collage.maker.databinding.FragmentIntroOneBinding
import com.natara.photo.collage.maker.ui.home.activity.MainActivity


class IntroFourFragment : Fragment() {

    lateinit var binding: FragmentIntroOneBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentIntroOneBinding.inflate(inflater, container, false)

        Glide.with(this).load(R.drawable.ic_intro_unselect).into(binding.mIVDot1)
        Glide.with(this).load(R.drawable.ic_intro_unselect).into(binding.mIVDot2)
        Glide.with(this).load(R.drawable.ic_intro_unselect).into(binding.mIVDot3)
        Glide.with(this).load(R.drawable.ic_intro_select).into(binding.mIVDot4)
//        Glide.with(this).load(R.drawable.intro_4).into(binding.mIVImage)

        binding.mIVSubImage.setBackgroundColor(Color.WHITE)
        binding.mTVText.text = "Share you quotes on multiple\nsocial media account."
        binding.mTVBtn.text = "Get Started"
        binding.mTVBtn.setOnClickListener {
            CollageMaker.prefManager?.needToShowIntro = false
            startMain()
        }
        return binding.root
    }

    private fun startMain() {
        startActivity(
            Intent(
                requireActivity(),
                MainActivity::class.java
            ).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
        requireActivity().finish()
    }

}