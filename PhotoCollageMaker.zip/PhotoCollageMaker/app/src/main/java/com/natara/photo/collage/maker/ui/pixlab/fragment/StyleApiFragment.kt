package com.natara.photo.collage.maker.ui.pixlab.fragment

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.asFlow
import androidx.recyclerview.widget.GridLayoutManager
import com.bumptech.glide.Glide
import com.natara.photo.collage.maker.databinding.FragmentFramesBinding
import com.natara.photo.collage.maker.extentions.hide
import com.natara.photo.collage.maker.extentions.requestMultiplePermissions
import com.natara.photo.collage.maker.ui.pixlab.activity.ArtActivity
import com.natara.photo.collage.maker.ui.pixlab.adapter.StylesAdapter
import com.natara.photo.collage.maker.ui.pixlab.model.StylesModel
import com.natara.photo.collage.maker.ui.pixlab.viewmodel.StylesViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch


class StyleApiFragment : Fragment() {
    private var folderName: String? = null
    private var frameId: StylesModel? = null

    private val mStylesViewModel by lazy {
        StylesViewModel()
    }


    private val framesAdapter: StylesAdapter by lazy {
        StylesAdapter(object : StylesAdapter.OnFilterFrame {
            override fun onClickFrame(position: Int, item: StylesModel) {
                requireActivity().requestMultiplePermissions {
                    Glide.with(requireContext()).load(item.image)
                        .into((requireActivity() as ArtActivity).binding.dripViewStyle)
                }
            }

        })
    }

    private lateinit var binding: FragmentFramesBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentFramesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        folderName = arguments?.getString("folderName")

        binding.framesRV.apply {
            layoutManager = GridLayoutManager(requireContext(),6)
            adapter = framesAdapter
        }

        binding.progress.visibility = View.VISIBLE
        binding.framesRV.visibility = View.VISIBLE

        Handler(Looper.getMainLooper()).postDelayed({
            if (!isDetached) {
                loadData()
            }
        }, 500)
    }


    private fun loadData() {
        CoroutineScope(Dispatchers.Main).launch {
            if (folderName != null) {

                mStylesViewModel.loadCategoryItem(folderName!!)
                mStylesViewModel.styleItemList.asFlow().collectLatest {
                    framesAdapter.submitList(it)
                    binding.progress.hide()
                }
            }
        }
    }


    companion object {

        @JvmStatic
        fun newInstance(
            folderName: String?,
        ): StyleApiFragment {
            val framesFrag = StyleApiFragment()
            val bundle = Bundle()
            bundle.putString("folderName", folderName)
            framesFrag.arguments = bundle
            return framesFrag
        }
    }

}