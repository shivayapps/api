package com.natara.photo.collage.maker.ui.singlepicker.adapter

import android.content.Context
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.natara.photo.collage.maker.databinding.LayoutImageItemBinding
import com.natara.photo.collage.maker.diffutils.DiffUtilsCallBacks
import com.natara.photo.collage.maker.models.Media

class SingleImagePickerAdapter(
    private val mImagePickerListener: ImagePickerListener,
) :
    ListAdapter<Media, SingleImagePickerAdapter.ImagePickerViewHolder>(
        DiffUtilsCallBacks.DiffCallbackPicker()
    ) {

    private val mSelectedList = arrayListOf<Pair<String, Int>>()

    interface ImagePickerListener {
        fun onImageClickListener(media: Media)
    }

    inner class ImagePickerViewHolder(private var binding: ViewBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(media: Media) {

            val binding = (binding as LayoutImageItemBinding)

            val requestOptions = RequestOptions().dontAnimate().override(
                setColumnNumber(binding.root.context),
                setColumnNumber(binding.root.context)
            )
            Glide.with(binding.root).setDefaultRequestOptions(requestOptions).load(media.uri)
                .thumbnail(0.5f).into(binding.mIVImage)

            binding.root.setOnClickListener {
                mImagePickerListener.onImageClickListener(media)
            }


            for (item in mSelectedList) {
                if (item.first == media.path) {
                    binding.mTVCount.text = "${item.second}"
                    binding.mTVCount.visibility = View.VISIBLE
                    return
                } else {
                    binding.mTVCount.visibility = View.GONE
                }
            }
        }


        private fun setColumnNumber(context: Context): Int {
            val displayMetrics = DisplayMetrics()
            (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getMetrics(
                displayMetrics
            )
            return displayMetrics.widthPixels / 3
        }

        fun clearImage() {
            (binding as? LayoutImageItemBinding)?.mIVImage?.let {
                Glide.with(binding.root).clear(it)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImagePickerViewHolder {
        return ImagePickerViewHolder(
                LayoutImageItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            )
    }

    override fun onBindViewHolder(holder: ImagePickerViewHolder, position: Int) {
        holder.bind(currentList[position])
    }

    override fun onViewRecycled(holder: ImagePickerViewHolder) {
        holder.clearImage()
        super.onViewRecycled(holder)
    }

    fun getSelectedData(mSelectedList: Map<String, Int>) {
        this.mSelectedList.clear()
        this.mSelectedList.addAll(mSelectedList.toList())
        notifyDataSetChanged()
    }
}