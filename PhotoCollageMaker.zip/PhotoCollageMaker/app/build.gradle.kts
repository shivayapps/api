plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("kotlin-android")
    id("kotlin-kapt")
    id("kotlin-parcelize")
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
}

android {
    signingConfigs {
        create("release") {
            storeFile =
                file("C:\\Users\\Admin\\Chintan\\Projects\\Make3LM\\PhotoCollageMaker\\KeyStore\\photocollagemaker.jks")
            storePassword = "7567072207"
            keyAlias = "Photo Collage Maker"
            keyPassword = "7567072207"
        }
    }
    namespace = "com.natara.photo.collage.maker"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.natara.photo.collage.maker"
        minSdk = 24
        targetSdk = 34
        versionCode = 5
        versionName = "5.0"
        multiDexEnabled = true
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {

        debug {

            resValue(type = "string", name = "app_open_id", value = "ca-app-pub-3940256099942544/9257395921")
            resValue(type = "string", name = "native_id", value = "ca-app-pub-3940256099942544/2247696110")
            resValue(type = "string", name = "interstitial_id", value = "ca-app-pub-3940256099942544/1033173712")
            resValue(type = "string", name = "banner_id", value = "ca-app-pub-3940256099942544/6300978111")
            resValue(type = "string", name = "admob_app_id", value = "ca-app-pub-3940256099942544~3347511713")

            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }

        release {

//            resValue(type = "string", name = "app_open_id", value = "ca-app-pub-6858868385525065/1077173091")
//            resValue(type = "string", name = "native_id", value = "ca-app-pub-6858868385525065/2665586937")
//            resValue(type = "string", name = "interstitial_id", value = "ca-app-pub-6858868385525065/5291750273")
//            resValue(type = "string", name = "banner_id", value = "ca-app-pub-6858868385525065/4421521730")
//            resValue(type = "string", name = "admob_app_id", value = "ca-app-pub-6858868385525065~8909423478")

            resValue(type = "string", name = "app_open_id", value = "ca-app-pub-3940256099942544/9257395921")
            resValue(type = "string", name = "native_id", value = "ca-app-pub-3940256099942544/2247696110")
            resValue(type = "string", name = "interstitial_id", value = "ca-app-pub-3940256099942544/1033173712")
            resValue(type = "string", name = "banner_id", value = "ca-app-pub-3940256099942544/6300978111")
            resValue(type = "string", name = "admob_app_id", value = "ca-app-pub-3940256099942544~3347511713")


            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }

    buildFeatures {
        viewBinding = true
        dataBinding = true
        buildConfig = true
    }
    sourceSets {
        getByName("main") {
            assets {
                srcDirs("src\\main\\assets", "src\\main\\assets")
            }
        }
    }
}

dependencies {

    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.multidex:multidex:2.0.1")

    implementation(project(mapOf("path" to ":croppylib")))
    implementation(project(mapOf("path" to ":colorpicker")))
    implementation(project(mapOf("path" to ":colordrop")))
    implementation(project(mapOf("path" to ":simplecropview")))
    implementation(project(mapOf("path" to ":cropiwa")))

    implementation("androidx.work:work-runtime-ktx:2.9.0")
    implementation("androidx.fragment:fragment-ktx:1.6.2")
    implementation("androidx.activity:activity-ktx:1.6.1")

    //sdp & ssp
    implementation("com.intuit.sdp:sdp-android:1.1.0")
    implementation("com.intuit.ssp:ssp-android:1.1.0")

    //Glide
    implementation("com.github.bumptech.glide:glide:4.16.0")
    annotationProcessor("com.github.bumptech.glide:compiler:4.13.2")

    //Picasso
    implementation("com.squareup.picasso:picasso:2.8")

    // GPU Image Filter
    implementation("org.wysaid:gpuimage-plus:3.0.0-min")

    // Bg Remover
    implementation ("com.huawei.hms:ml-computer-vision-segmentation:3.7.0.302")
    implementation ("com.huawei.hms:ml-computer-vision-image-segmentation-body-model:3.7.0.302")

    // Lottie
    implementation ("com.airbnb.android:lottie:6.0.0")

    // Shimmer
    implementation("com.facebook.shimmer:shimmer:0.5.0")

    // Dexter
    implementation("com.karumi:dexter:6.2.3")


    implementation("io.reactivex.rxjava2:rxjava:2.2.19")
    implementation("io.reactivex.rxjava2:rxandroid:2.1.1")

    // Lifecycle
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.fragment:fragment-ktx:1.6.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.7.0")
    kapt("androidx.lifecycle:lifecycle-compiler:2.7.0")
    implementation("androidx.lifecycle:lifecycle-extensions:2.2.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.2")
    annotationProcessor("androidx.lifecycle:lifecycle-compiler:2.6.2")

    //Firebase
    implementation(platform("com.google.firebase:firebase-bom:32.7.1"))
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-firestore")
    implementation("com.google.firebase:firebase-crashlytics")

    implementation("com.google.android.gms:play-services-ads:24.7.0")


    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}