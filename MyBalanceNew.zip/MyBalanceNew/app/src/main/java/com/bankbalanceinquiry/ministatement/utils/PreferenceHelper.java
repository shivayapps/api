package com.bankbalanceinquiry.ministatement.utils;

import static com.bankbalanceinquiry.ministatement.utils.Constant.PREF_Notification_ID;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;

public class PreferenceHelper {

    public static String SHARED_PREF = "bankbalance";

//    var isNeedInterAd: Boolean
//    get() = preferences.getBoolean("isNeedInterAd", true)
//    set(value) = preferences.edit().putBoolean("isNeedInterAd", value).apply()

    public static void saveToUserDefaults(Context context, String key, String value) {
        if (context != null) {
            SharedPreferences preferences = context.getSharedPreferences(SHARED_PREF, Context.MODE_PRIVATE);
            Editor editor = preferences.edit();
            editor.putString(key, value);
            editor.commit();
        }
    }

    public static void saveToBooleans(Context context, String key, boolean value) {
        if (context != null) {
            SharedPreferences preferences = context.getSharedPreferences(SHARED_PREF, Context.MODE_PRIVATE);
            Editor editor = preferences.edit();
            editor.putBoolean(key, value);
            editor.commit();
        }
    }

    public static boolean getFromBooleans(Context context, String key, boolean defaultValue) {
        SharedPreferences preferences = context.getSharedPreferences(SHARED_PREF, Context.MODE_PRIVATE);
        return preferences.getBoolean(key, defaultValue);

    }

    public static String getFromUserDefaults(Context context, String key) {
        SharedPreferences preferences = context.getSharedPreferences(
                SHARED_PREF, Context.MODE_PRIVATE);
        return preferences.getString(key, "");
    }

    public static String getFromUserDefaults(Context context, String key, String defaultValue) {
        SharedPreferences preferences = context.getSharedPreferences(
                SHARED_PREF, Context.MODE_PRIVATE);
        return preferences.getString(key, defaultValue);
    }

    public static void setNotificationRequestCode(Context context, int notificationId) {
        if (context != null) {
            SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
            sp.edit().putInt(PREF_Notification_ID, notificationId).apply();
        }

    }

    public static int getNotificationRequestCode(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        return sp.getInt(PREF_Notification_ID, 1);
    }
}
