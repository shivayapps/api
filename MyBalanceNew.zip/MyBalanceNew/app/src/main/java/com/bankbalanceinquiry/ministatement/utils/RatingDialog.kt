package com.bankbalanceinquiry.ministatement.utils

import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import com.adconfig.AdsConfig
import com.bankbalanceinquiry.ministatement.BuildConfig
import com.bankbalanceinquiry.ministatement.R
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import java.lang.ref.WeakReference


class RatingDialog(
    var activity: Activity,
    val clickListener: (isExit: Boolean) -> Unit
) : Dialog(activity) {

    private var rate: Float = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
//        window?.navigationBarColor = ContextCompat.getColor(activity, R.color.dialogBg)
        window?.setGravity(Gravity.BOTTOM)

        setContentView(R.layout.dialog_rating)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )

        AdsConfig.isSystemDialogOpen = true
        initView()
    }

    private fun initView() {
        val ratingBar = findViewById<RatingBar>(R.id.rating_bar)
        val titleText = findViewById<TextView>(R.id.txtTitle)
//        val ivTop = findViewById<ImageView>(R.id.ivTop)

        ratingBar.setOnRatingBarChangeListener { _, rating, _ ->
            rate = rating
            when (rating) {
                0f -> {
                    titleText.setText(activity.getString(R.string.rate_title_good))
//                    ivTop.setImageResource(R.drawable.rate_five)
                }

                1f -> {
                    titleText.setText(activity.getString(R.string.rate_title_fair))
//                    ivTop.setImageResource(R.drawable.rate_one)
                }

                2f -> {
                    titleText.setText(activity.getString(R.string.rate_title_fair))
//                    ivTop.setImageResource(R.drawable.rate_two)
                }

                3f -> {
                    titleText.setText(activity.getString(R.string.rate_title_good))
//                    ivTop.setImageResource(R.drawable.rate_three)
                }

                4f -> {
                    titleText.setText(activity.getString(R.string.rate_title_good))
//                    ivTop.setImageResource(R.drawable.rate_four)
                }

                5f -> {
                    titleText.setText(activity.getString(R.string.rate_title_good))
//                    ivTop.setImageResource(R.drawable.rate_five)
                }
            }
        }

        findViewById<TextView>(R.id.btnOK).setOnClickListener {
            if (rate >= 4) {
                SharedPreferenceClass.setBoolean(activity, "apprate", true)
                //Preferences(activity).isRatingDone = true
                showInAppRateDialog(activity)
            } else if (rate >= 1) {
                launchEmail()
            } else {
                Toast.makeText(activity, "Please rate us. Your opinion is important to us.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            dismiss()
        }
    }

    private fun showInAppRateDialog(activity: Activity) {
        AdsConfig.isSystemDialogOpen = true
        val reviewManager = ReviewManagerFactory.create(activity)
        val activityRef = WeakReference(activity)
        reviewManager.requestReviewFlow().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                activityRef.get()?.let {
                    showInAppRateDialogInternal(reviewManager, it, task.result)
                }
            } else {
                Log.e("RatingDialog", "In-app review request failed", task.exception)
            }
        }
    }

    private fun showInAppRateDialogInternal(
        reviewManager: ReviewManager,
        activity: Activity,
        reviewInfo: ReviewInfo
    ) {
        val activityRef = WeakReference(activity)
        reviewManager.launchReviewFlow(activity, reviewInfo).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                activityRef.get()?.let {
                    launchAppStore()
                }
            } else {
                Log.e("RatingDialog", "In-app review launch failed", task.exception)
            }
        }
    }

    private fun launchAppStore() {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${activity.packageName}")
        )
        activity.startActivity(intent)
    }

    private fun launchEmail() {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "message/rfc822"
            putExtra(Intent.EXTRA_EMAIL, arrayOf(activity.getString(R.string.email)))
            putExtra(
                Intent.EXTRA_SUBJECT,
                "${activity.getString(R.string.app_name)}}"
            )
            putExtra(Intent.EXTRA_TEXT, "")
            setPackage("com.google.android.gm")
        }

        try {
            activity.startActivity(Intent.createChooser(i, "Send Mail"))
        } catch (ex: ActivityNotFoundException) {
            Toast.makeText(activity, activity.getString(R.string.email_warning), Toast.LENGTH_SHORT).show()
        }
    }
}
