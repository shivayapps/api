package com.bankbalanceinquiry.ministatement.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bankbalanceinquiry.ministatement.R


class StateAdapter(var mContext: Context, var mStateList: ArrayList<String>, var clickListener: ClickListener) : RecyclerView.Adapter<StateAdapter.StateViewHolder>() {
    class StateViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var mTVState: TextView = view.findViewById(R.id.mTVText)
        var mIVBank: TextView = view.findViewById(R.id.mIVCall)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StateViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.single_state, parent, false)
        return StateViewHolder(view)
    }

    override fun getItemCount(): Int = mStateList.size

    override fun onBindViewHolder(holder: StateViewHolder, position: Int) {
        val mList = mStateList[position]

        holder.mTVState.text = mList
        holder.mIVBank.text = (mList[0]).toString()

        holder.itemView.setOnClickListener {
            clickListener.onItemClick(mList)
        }
    }

    interface ClickListener {
        fun onItemClick(position: String)
    }

    fun filterList(filterdNames: ArrayList<String>) {
        this.mStateList = filterdNames
        notifyDataSetChanged()
    }
}