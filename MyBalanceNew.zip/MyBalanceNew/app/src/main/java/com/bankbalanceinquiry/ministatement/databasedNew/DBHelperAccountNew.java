package com.bankbalanceinquiry.ministatement.databasedNew;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;
import android.util.Log;

import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class DBHelperAccountNew extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "MyDBNameNew.db";
    public final String CONTACTS_TABLE_NAME = "transactionData";
    private HashMap hp;

    public DBHelperAccountNew(Context context) {
        super(context, DATABASE_NAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        if (!checkForTableExists("transactionData", db)) {
            db.execSQL("create table transactionData " +
                    "(id integer primary key,FinalAccountNo,FinalAccountBalance,full_name,finalTransactionDesc" +
                    ",account_type" +
                    ",sms_type" +
                    ",body" +
                    ",transactionDescs" +
                    ",dates" +
                    ",dateFormats" +
                    ",amounts" +
                    ",eventNames" +
                    ",eventLocations" +
                    ",eventInfos" +
                    ",panValue" +
                    ",mTransactionType" +
                    ",transactionDesc" +
                    ",transactionPos" +
                    ",date" +
                    ",amount" +
                    ",eventName" +
                    ",eventLocation" +
                    ",eventInfo" +
                    ",txn_type" +
                    ",isDebited" +
                    ",isAtmWithDraw" +
                    ",use_sms_time" +
                    ",dateValAccount, DateTransactionHistory, dateValHistory)"
            );
        }
        if (!checkForTableExists("accountsData", db)) {
            db.execSQL("create table accountsData " +
                    "(id integer primary key,FinalAccountNo,FinalAccountBalance,full_name,dateValAccount,bankNickName)"
            );
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS transactionData");
        //db.execSQL("DROP TABLE IF EXISTS accountsData");
        if (newVersion > oldVersion) {
            try {
                db.execSQL("ALTER TABLE accountsData ADD COLUMN bankNickName TEXT");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        onCreate(db);
    }

    public void InsertTransaction(HomeAccoutList homeAccount) {
        Gson gson = new Gson();
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("FinalAccountNo", homeAccount.FinalAccountNo);
        contentValues.put("FinalAccountBalance", homeAccount.FinalAccountBalance);
        contentValues.put("full_name", homeAccount.full_name);
        contentValues.put("finalTransactionDesc", homeAccount.finalTransactionDesc);
        contentValues.put("account_type", homeAccount.account_type);
        contentValues.put("sms_type", homeAccount.sms_type);
        contentValues.put("body", homeAccount.body);
        contentValues.put("transactionDescs", homeAccount.transactionDescs.size() != 0 ? gson.toJson(homeAccount.transactionDescs) : "");
        contentValues.put("dates", homeAccount.dates.size() != 0 ? gson.toJson(homeAccount.dates) : "");
        contentValues.put("dateFormats", homeAccount.dateFormats.size() != 0 ? gson.toJson(homeAccount.dateFormats) : "");
        contentValues.put("amounts", homeAccount.amounts.size() != 0 ? gson.toJson(homeAccount.amounts) : "");
        contentValues.put("eventNames", homeAccount.eventNames.size() != 0 ? gson.toJson(homeAccount.eventNames) : "");
        contentValues.put("eventLocations", homeAccount.eventLocations.size() != 0 ? gson.toJson(homeAccount.eventLocations) : "");
        contentValues.put("eventInfos", homeAccount.eventInfos.size() != 0 ? gson.toJson(homeAccount.eventInfos) : "");
        contentValues.put("panValue", homeAccount.panValue);
        contentValues.put("mTransactionType", homeAccount.mTransactionType);
        contentValues.put("transactionDesc", homeAccount.transactionDesc);
        contentValues.put("transactionPos", homeAccount.transactionPos);
        contentValues.put("date", homeAccount.date);
        contentValues.put("amount", homeAccount.amount);
        contentValues.put("eventName", homeAccount.eventName);
        contentValues.put("eventLocation", homeAccount.eventLocation);
        contentValues.put("eventInfo", homeAccount.eventInfo);
        contentValues.put("txn_type", homeAccount.txn_type);
        contentValues.put("isDebited", String.valueOf(homeAccount.isDebited));
        contentValues.put("isAtmWithDraw", String.valueOf(homeAccount.isAtmWithDraw));
        contentValues.put("use_sms_time", String.valueOf(homeAccount.use_sms_time));
        contentValues.put("dateValAccount", homeAccount.dateValAccount);
        contentValues.put("DateTransactionHistory", homeAccount.DateTransactionHistory);
        contentValues.put("dateValHistory", homeAccount.dateValHistory);
        db.insert("transactionData", null, contentValues);
    }

    public boolean isDataAvailable() {
        ArrayList<HomeAccoutList> arrayDataList = GetAllAccountNew();
        if (arrayDataList.size() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public Date getLastTransactionDate() {

        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<String> dateString = new ArrayList<>();
        ArrayList<Long> dateLong = new ArrayList<>();
        ArrayList<Date> dateLong1 = new ArrayList<>();
        Date lastTransactionDate1 = null;
        long lastTransactionDate = 0;
        Cursor res = db.rawQuery("select DISTINCT dateValAccount from transactionData", null);
        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                String date = res.getString(res.getColumnIndexOrThrow("dateValAccount"));
                dateString.add(date);
            }
        }
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd MMM yyyy", Locale.US);

        for (int i = 0; i < dateString.size(); i++) {
            try {
                Date date3 = simpleDateFormat1.parse(dateString.get(i));
                if (date3 != null) {
                    long valueDate = date3.getTime();/*
                    if (lastTransactionDate < valueDate) {
                        lastTransactionDate = valueDate;
                    }*/
                    if (lastTransactionDate1 == null) {
                        lastTransactionDate1 = date3;
                    } else {
                        if (date3.after(lastTransactionDate1)) {
                            lastTransactionDate1 = date3;
                        }
                    }
                    dateLong.add(date3.getTime());
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return lastTransactionDate1;
    }

    public void removeduplicateData() {
        SQLiteDatabase db = this.getWritableDatabase();
//        String duplicateQuery = "DELETE FROM accountsData WHERE id NOT IN (SELECT MAX(id) FROM accountsData GROUP BY 'FinalAccountNo','full_name')";
        String duplicateQuery = "DELETE FROM accountsData WHERE id  NOT IN ( SELECT id FROM accountsData GROUP BY finalaccountno,full_name)";
        db.execSQL(duplicateQuery);
    }


    public void removeAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("accountsData", null, null);
        db.delete("transactionData", null, null);
    }

    public boolean InsertAccount(HomeAccoutList homeAccount) {

        SQLiteDatabase db = this.getWritableDatabase();
        boolean isInsert = false;
        ContentValues contentValues = new ContentValues();
        contentValues.put("FinalAccountNo", homeAccount.FinalAccountNo);
        contentValues.put("FinalAccountBalance", homeAccount.FinalAccountBalance);
        contentValues.put("full_name", homeAccount.full_name);
        contentValues.put("dateValAccount", homeAccount.dateValAccount);
        try {
            String query = "select * from accountsData WHERE FinalAccountNo = '"
                    + homeAccount.FinalAccountNo + "' AND " + "full_name = '" + homeAccount.full_name + "'";
            Cursor res = db.rawQuery(query, null);
            Log.e("Ajhgvahcfagvsc", query + "::");
            int id = -1;
            if (res != null && res.getCount() != 0) {
                while (res.moveToNext()) {
                    id = 0;
                }
                res.close();
            }
            if (id == -1) {
                db.insert("accountsData", null, contentValues);
                isInsert = true;
            } else {
                String[] args = new String[]{homeAccount.FinalAccountNo, homeAccount.full_name};
                db.update("accountsData", contentValues, "FinalAccountNo=? AND full_name=?", args);
                isInsert = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isInsert;
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from transactionData where id=" + id + "", null);
        return res;
    }

    public int numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        return (int) DatabaseUtils.queryNumEntries(db, CONTACTS_TABLE_NAME);
    }
    public int numberOfAccounts() {
        SQLiteDatabase db = this.getReadableDatabase();
        return (int) DatabaseUtils.queryNumEntries(db, "accountsData");
    }


    public ArrayList<HomeAccoutList> GetAllAccountNew() {
        ArrayList<HomeAccoutList> ownerDetails = new ArrayList<HomeAccoutList>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from accountsData", null);
        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                HomeAccoutList homeAccount = new HomeAccoutList();
                homeAccount.FinalAccountNo = res.getString(res.getColumnIndexOrThrow("FinalAccountNo"));
                homeAccount.FinalAccountBalance = res.getString(res.getColumnIndexOrThrow("FinalAccountBalance"));
                homeAccount.full_name = res.getString(res.getColumnIndexOrThrow("full_name"));
                homeAccount.dateValAccount = res.getString(res.getColumnIndexOrThrow("dateValAccount"));
                homeAccount.id = res.getInt(res.getColumnIndexOrThrow("id"));
                homeAccount.bankNickName = res.getString(res.getColumnIndexOrThrow("bankNickName"));
                ownerDetails.add(homeAccount);
            }
            res.close();
        }
        return ownerDetails;
    }

    public int changeAccountName(String newBankName, HomeAccoutList accountInfo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id", accountInfo.id);
        contentValues.put("FinalAccountNo", accountInfo.FinalAccountNo);
        contentValues.put("FinalAccountBalance", accountInfo.FinalAccountBalance);
        contentValues.put("full_name", accountInfo.full_name);
        contentValues.put("bankNickName", newBankName);
        contentValues.put("dateValAccount", accountInfo.dateValAccount);

        int accountsDataStatus = db.update("accountsData", contentValues, "id=?", new String[]{String.valueOf(accountInfo.id)});
        db.close();
        return accountsDataStatus;
    }

    public ArrayList<HomeAccoutList> GetAllTransaction() {
        Gson gson = new Gson();
        ArrayList<HomeAccoutList> ownerDetails = new ArrayList<>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from transactionData", null);
        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                HomeAccoutList homeAccount = getItem(res, gson);
                ownerDetails.add(homeAccount);
            }
            res.close();
        }
        return ownerDetails;
    }


    public ArrayList<HomeAccoutList> GetTransactions(String accountNo, String accountName) {
        Gson gson = new Gson();
        ArrayList<HomeAccoutList> ownerDetails = new ArrayList<>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res;
        if (TextUtils.isEmpty(accountNo)) {
            res = db.rawQuery("select * from transactionData where full_name='" + accountName + "'", null);
        } else if (TextUtils.isEmpty(accountName)) {
            res = db.rawQuery("select * from transactionData where FinalAccountNo='" + accountNo + "'", null);
        } else {
            res = db.rawQuery("select * from transactionData where FinalAccountNo='" + accountNo + "' AND full_name='" + accountName + "'", null);
        }

        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                HomeAccoutList homeAccount = getItem(res, gson);
                ownerDetails.add(homeAccount);
            }
            res.close();
        }
        return ownerDetails;
    }


    public ArrayList<HomeAccoutList> GetTransactionsType(String accountNo, String accountName, String type) {
        Gson gson = new Gson();
        ArrayList<HomeAccoutList> ownerDetails = new ArrayList<>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res;
        String whereCondition = "";
        if (!type.equalsIgnoreCase("All")) {
            if (type.equalsIgnoreCase("Debited")) {
                whereCondition = " AND isDebited='true'";
            } else {
                whereCondition = " AND isDebited='false'";
            }
        }
        if (TextUtils.isEmpty(accountNo)) {
            res = db.rawQuery("select * from transactionData where full_name='" + accountName + "'" + whereCondition, null);
        } else if (TextUtils.isEmpty(accountName)) {
            res = db.rawQuery("select * from transactionData where FinalAccountNo='" + accountNo + "'" + whereCondition, null);
        } else {
            res = db.rawQuery("select * from transactionData where FinalAccountNo='" + accountNo + "' AND full_name='" + accountName + "'" + whereCondition, null);
        }

        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                HomeAccoutList homeAccount = getItem(res, gson);
                ownerDetails.add(homeAccount);
            }
            res.close();
        }
        return ownerDetails;
    }

    public ArrayList<HomeAccoutList> GetSpecificBills(String key) {
        Gson gson = new Gson();
        ArrayList<HomeAccoutList> ownerDetails = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from transactionData  where account_type = ?",
                new String[]{key});
        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                HomeAccoutList homeAccount = getItem(res, gson);
                if (homeAccount.account_type.equalsIgnoreCase("credit_card")) {
                    if (homeAccount.mTransactionType.equalsIgnoreCase("credit_card_bill")) {
                        ownerDetails.add(homeAccount);
                    }
                } else {
                    ownerDetails.add(homeAccount);
                }

            }
            res.close();
        }
        return ownerDetails;
    }

    public ArrayList<HomeAccoutList> GetAllBills() {
        Gson gson = new Gson();
        ArrayList<HomeAccoutList> ownerDetails = new ArrayList<HomeAccoutList>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
//        Cursor res = db.rawQuery("select * from transactionData ", null);
        Cursor res = db.rawQuery("select * from transactionData  where account_type = ? OR account_type = ? OR  account_type = ? OR" +
                        " account_type = ?" + "OR account_type = ? OR  account_type = ? OR account_type = ? OR" +
                        " account_type = ?",
                new String[]{"loan", "prepaid", "phone", "credit_card", "generic", "electricity", "insurance", "gas"});
        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                HomeAccoutList homeAccount = getItem(res, gson);
                if (homeAccount.account_type.equalsIgnoreCase("credit_card")) {
                    if (homeAccount.mTransactionType.equalsIgnoreCase("credit_card_bill")) {
                        ownerDetails.add(homeAccount);
                    }
                } else {
                    ownerDetails.add(homeAccount);
                }

            }
            res.close();
        }
        return ownerDetails;
    }

    public ArrayList<HomeAccoutList> GetAllAtmWithdraw() {
        Gson gson = new Gson();
        ArrayList<HomeAccoutList> ownerDetails = new ArrayList<HomeAccoutList>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
//        Cursor res = db.rawQuery("select * from transactionData ", null);
        Cursor res = db.rawQuery("select * from transactionData  where isAtmWithDraw = ? OR mTransactionType = ?",
                new String[]{"true", "cheque"});
        if (res != null && res.getCount() != 0) {
            while (res.moveToNext()) {
                HomeAccoutList homeAccount = getItem(res, gson);
                ownerDetails.add(homeAccount);
            }
            res.close();
        }
        return ownerDetails;
    }


    private HomeAccoutList getItem(Cursor res, Gson gson) {
        HomeAccoutList homeAccount = new HomeAccoutList();
        homeAccount.FinalAccountNo = res.getString(res.getColumnIndexOrThrow("FinalAccountNo"));
        homeAccount.FinalAccountBalance = res.getString(res.getColumnIndexOrThrow("FinalAccountBalance"));
        homeAccount.full_name = res.getString(res.getColumnIndexOrThrow("full_name"));
        homeAccount.finalTransactionDesc = res.getString(res.getColumnIndexOrThrow("finalTransactionDesc"));

        homeAccount.account_type = res.getString(res.getColumnIndexOrThrow("account_type"));
        homeAccount.sms_type = res.getString(res.getColumnIndexOrThrow("sms_type"));
        homeAccount.body = res.getString(res.getColumnIndexOrThrow("body"));
        String transactionDescs = res.getString(res.getColumnIndexOrThrow("transactionDescs"));
        if (!TextUtils.isEmpty(transactionDescs)) {
            homeAccount.transactionDescs = gson.fromJson(transactionDescs, new TypeToken<List<String>>() {
            }.getType());
        }
        String dates = res.getString(res.getColumnIndexOrThrow("dates"));
        if (!TextUtils.isEmpty(dates)) {
            homeAccount.dates = gson.fromJson(dates, new TypeToken<List<String>>() {
            }.getType());
        }
        String dateFormats = res.getString(res.getColumnIndexOrThrow("dateFormats"));
        if (!TextUtils.isEmpty(dateFormats)) {
            homeAccount.dateFormats = gson.fromJson(dateFormats, new TypeToken<List<String>>() {
            }.getType());
        }
        String amounts = res.getString(res.getColumnIndexOrThrow("amounts"));
        if (!TextUtils.isEmpty(amounts)) {
            homeAccount.amounts = gson.fromJson(amounts, new TypeToken<List<String>>() {
            }.getType());
        }
        String eventNames = res.getString(res.getColumnIndexOrThrow("eventNames"));
        if (!TextUtils.isEmpty(eventNames)) {
            homeAccount.eventNames = gson.fromJson(eventNames, new TypeToken<List<String>>() {
            }.getType());
        }
        String eventLocations = res.getString(res.getColumnIndexOrThrow("eventLocations"));
        if (!TextUtils.isEmpty(eventLocations)) {
            homeAccount.eventLocations = gson.fromJson(eventLocations, new TypeToken<List<String>>() {
            }.getType());
        }
        String eventInfos = res.getString(res.getColumnIndexOrThrow("eventInfos"));
        if (!TextUtils.isEmpty(eventInfos)) {
            homeAccount.eventInfos = gson.fromJson(eventInfos, new TypeToken<List<String>>() {
            }.getType());
        }

        homeAccount.panValue = res.getString(res.getColumnIndexOrThrow("panValue"));
        homeAccount.mTransactionType = res.getString(res.getColumnIndexOrThrow("mTransactionType"));
        homeAccount.transactionDesc = res.getString(res.getColumnIndexOrThrow("transactionDesc"));
        homeAccount.transactionPos = res.getString(res.getColumnIndexOrThrow("transactionPos"));

        homeAccount.date = res.getString(res.getColumnIndexOrThrow("date"));
        homeAccount.amount = res.getString(res.getColumnIndexOrThrow("amount"));
        homeAccount.eventName = res.getString(res.getColumnIndexOrThrow("eventName"));
        homeAccount.eventLocation = res.getString(res.getColumnIndexOrThrow("eventLocation"));
        homeAccount.eventInfo = res.getString(res.getColumnIndexOrThrow("eventInfo"));
        homeAccount.txn_type = res.getString(res.getColumnIndexOrThrow("txn_type"));
        String s = res.getString(res.getColumnIndexOrThrow("isDebited"));
        homeAccount.isDebited = Boolean.parseBoolean(s);
        homeAccount.isAtmWithDraw = Boolean.parseBoolean(res.getString(res.getColumnIndexOrThrow("isAtmWithDraw")));
        homeAccount.use_sms_time = Boolean.parseBoolean(res.getString(res.getColumnIndexOrThrow("use_sms_time")));
        homeAccount.dateValAccount = res.getString(res.getColumnIndexOrThrow("dateValAccount"));
        homeAccount.DateTransactionHistory = res.getString(res.getColumnIndexOrThrow("DateTransactionHistory"));
        homeAccount.dateValHistory = res.getString(res.getColumnIndexOrThrow("dateValHistory"));

        return homeAccount;
    }

    public boolean checkForTableExists(String tableName, SQLiteDatabase db) {
        String sql = "SELECT name FROM sqlite_master WHERE type='table' AND name='" + tableName + "'";
        Cursor mCursor = db.rawQuery(sql, null);
        if (mCursor != null && mCursor.getCount() > 0) {
            mCursor.close();
            return true;
        }
        return false;
    }

}
