package com.bankbalanceinquiry.ministatement.model

data class StateModel(var mDate: String, var mDay: String, var mHoliday: String)