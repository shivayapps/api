package com.bankbalanceinquiry.ministatement.model;

import java.io.Serializable;

public class AvilabeBalanceModel implements Serializable {
    private String BankName;
    private String AvilableMsg;
    private String DateonMsg;
    private String BankSMSTile;
    private int bankicon;

    public AvilabeBalanceModel(String bankName, String dateonMsg,
                               String avilableMsg, String bankSMSTile, int bBankicon) {
        BankName = bankName;
        DateonMsg = dateonMsg;
        AvilableMsg = avilableMsg;
        BankSMSTile = bankSMSTile;
        bankicon = bBankicon;

    }

    public String getBankName() {
        return BankName;
    }

    public void setBankName(String bankName) {
        BankName = bankName;
    }

    public String getAvilableMsg() {
        return AvilableMsg;
    }

    public void setAvilableMsg(String avilableMsg) {
        AvilableMsg = avilableMsg;
    }

    public String getDateonMsg() {
        return DateonMsg;
    }

    public void setDateonMsg(String dateonMsg) {
        DateonMsg = dateonMsg;
    }

    public String getBankSMSTile() {
        return BankSMSTile;
    }

    public void setBankSMSTile(String bankSMSTile) {
        BankSMSTile = bankSMSTile;
    }

    public int getBankicon() {
        return bankicon;
    }

    public void setBankicon(int bankicon) {
        this.bankicon = bankicon;
    }
}
