package com.bankbalanceinquiry.ministatement.activity;

import static com.bankbalanceinquiry.ministatement.utils.Constant.setLocale;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.Events.SmsProgress;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.adapter.CashMultiViewTypeAdapter;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.model.FirstTimeSmsModel;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;
import com.bankbalanceinquiry.ministatement.utils.SmsService;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;


public class CashWithdrawalActivity extends AppCompatActivity {

    private Activity activity;
    private Toolbar toolbar;

    private RecyclerView rvAccountList;
    private ProgressBar pbLoading;


    private final ArrayList<HomeAccoutList> cashModelHistories = new ArrayList<>();
    private CashMultiViewTypeAdapter cashMultiViewTypeAdapter;
    private String BankName = "";

    private LinearLayout llEmpty;
    private TextView tvEmptyMessage;
    private ImageView ivEmptyImage;

    private final ArrayList<FirstTimeSmsModel> AccountHistory = new ArrayList<>();
    private DBHelperAccountNew mydbCash;

    private LinearProgressIndicator progress;
    private TextView count;
    private LinearLayout progress_lay;


    private FrameLayout adLayout;


    @Subscribe
    public void OnSmsProgress(final SmsProgress smsProgress) {
        if (!isFinishing()) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (smsProgress.isShowProgress()) {
                        if (progress_lay.getVisibility() != View.VISIBLE) {
                            progress_lay.setVisibility(View.VISIBLE);
                        }
                    } else {
                        progress_lay.setVisibility(View.GONE);
                    }
                    //  count.setText(SmsService.smsCount + "/" + SmsService.TotalCount);
                    int per = (SmsService.smsCount * 100) / SmsService.TotalCount;
                    //moneyBinding.count.setText(SmsService.smsCount + "/" + SmsService.TotalCount);
                    //count.setText(per + "%");
                    count.setText(getResources().getString(R.string.analyzing_from_sms_service) + " " + per + "%");

                    //progress.setMax(SmsService.TotalCount);
                    //progress.setProgress(smsProgress.getProgress());
                    if (SmsService.smsCount == (SmsService.TotalCount - 1)) {
                        PreferenceHelper.saveToUserDefaults(CashWithdrawalActivity.this, Constant.TRACK_PREF, "1");
                        progress_lay.setVisibility(View.GONE);
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (manager != null) {
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (serviceClass.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLocale(this);
        setContentView(R.layout.activity_cash_withdrawal);

        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this);

        adLayout = findViewById(R.id.adLayout);
       /* if (getIntent().hasExtra("showAd") && getIntent().getBooleanExtra("showAd", false)) {
            AdmobAdManager.getInstance().loadInterstitialAd(this, getString(R.string.interstitial_id), 1, (AdmobAdManager.OnAdClosedListener) () -> {
            });
        } else {
            AdmobAdManager.getInstance().loadInterstitialAd(this, getString(R.string.interstitial_id), 3, (AdmobAdManager.OnAdClosedListener) () -> {
            });
        }*/
        progress = findViewById(R.id.progress);
        count = findViewById(R.id.count);
        progress_lay = findViewById(R.id.progress_lay);

        /*if (isProcessRunning) {
            if (isShowProgress) {
                progress_lay.setVisibility(View.VISIBLE);
            } else {
                progress_lay.setVisibility(View.GONE);
            }
        } else {
            progress_lay.setVisibility(View.GONE);
        }*/
        /* if (isMyServiceRunning(SmsService.class)) {
            progress_lay.setVisibility(View.VISIBLE);
        } else {
            progress_lay.setVisibility(View.GONE);
        }*/

        activity = this;

        mydbCash = new DBHelperAccountNew(activity);

        InitToolBar();

        InitComponent();
    }


    private void InitToolBar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.home_cash));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    private void InitComponent() {
        rvAccountList = findViewById(R.id.rvAccountList);
        pbLoading = findViewById(R.id.pbLoading);
        pbLoading.setVisibility(View.VISIBLE);
        CommonFun.RecyclerViewLinearLayout(activity, rvAccountList);

        llEmpty = findViewById(R.id.llEmpty);
        tvEmptyMessage = findViewById(R.id.tvEmptyMessage);
        ivEmptyImage = findViewById(R.id.ivEmptyImage);
        tvEmptyMessage.setText(getString(R.string.empty_cash_transaction_msg));

        pbLoading.setVisibility(View.GONE);


        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        CheckDataNotifyOrNot();
                    }
                });
            }
        }, 300);


        // CallDataIsLodingOrNot();
//        pbLoading.setVisibility(View.VISIBLE);


//        CheckDataNotifyOrNot();
//
//        CallDb();
//
//        CallSinglesmsTogetCashAtmWidh();
    }

    private void CheckDataNotifyOrNot() {
        cashModelHistories.addAll(mydbCash.GetAllAtmWithdraw());
        ArrayList<HomeAccoutList> cashModelHistoriestmp = new ArrayList<>();
        if (cashModelHistories.size() > 0) {
            String header = "";
            ArrayList<String> CreditData = new ArrayList<>();
            ArrayList<String> DebitData = new ArrayList<>();
            boolean istitlefound = false;
            for (int i = 0; i < cashModelHistories.size(); i++) {
                istitlefound = false;
                //If it is the start of a new section we create a new listcell and add it to our array
                HomeAccoutList adddata = cashModelHistories.get(i);
                if (!(header.equals(adddata.DateTransactionHistory))) {

                    String CheckCreditDebit = isDebitedOrCredited(cashModelHistories.get(i));
                    CreditData = new ArrayList<>();
                    DebitData = new ArrayList<>();

                    if (CheckCreditDebit.equalsIgnoreCase("1")) {
                        DebitData.add(cashModelHistories.get(i).amount);
                    } else {
                        CreditData.add(cashModelHistories.get(i).amount);
                    }

                    istitlefound = true;
                    HomeAccoutList sectionCell = new HomeAccoutList();
                    sectionCell.DateTransactionHistory = adddata.DateTransactionHistory;
                    sectionCell.isSectionHeader = true;
                    sectionCell.GetTitleType = 0;
                    //cashModelHistoriestmp.add(sectionCell);
                    header = adddata.DateTransactionHistory;

                    sectionCell.CreditedData = CreditData;
                    sectionCell.DebitedData = DebitData;

                }

                if (!istitlefound) {
                    String CheckCreditDebit = isDebitedOrCredited(cashModelHistories.get(i));
                    if (CheckCreditDebit.equalsIgnoreCase("1")) {
                        DebitData.add(cashModelHistories.get(i).amount);
                    } else {
                        CreditData.add(cashModelHistories.get(i).amount);
                    }
                }
                adddata.GetTitleType = 1;
                cashModelHistoriestmp.add(adddata);
            }
        }

        cashModelHistories.clear();
        cashModelHistories.addAll(cashModelHistoriestmp);
//        CommonFun.CashModelHistoriesTmp.clear();
//        CommonFun.CashModelHistoriesTmp.addAll(cashModelHistories);
        CallAdapterSetFun();

    }

    private String isDebitedOrCredited(HomeAccoutList homeAccount) {
        String isDebitedOrCredited = "1";
        if (homeAccount.isAtmWithDraw) {
            isDebitedOrCredited = "1";
        } else if (homeAccount.isDebited) {
            isDebitedOrCredited = "1";
        } else {
            isDebitedOrCredited = "0";
        }
        return isDebitedOrCredited;
    }

//
//    private void CallDb() {
//        if (TextUtils.isEmpty(CommonFun.IsAllSmsmFill)) {
//            new Handler().postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    CallDb();
//                    Log.e("CashWidthFirstime==>", "Loading Wait");
//                }
//            }, 700);
//        } else {
//            if (CommonFun.CashModelHistoriesTmp.size() > 0) {
//                Log.e("CashWidthFirstime==>", "Already Loded");
//                pbLoading.setVisibility(View.GONE);
//                cashModelHistories = new ArrayList<>();
//                cashModelHistories.addAll(CommonFun.CashModelHistoriesTmp);
//                CallAdapterSetFun();
//            } else {
//                pbLoading.setVisibility(View.GONE);
//                cashModelHistories = new ArrayList<>();
//                cashModelHistories.addAll(mydbCash.GetCash());
//                ArrayList<CashModelHistory> cashModelHistoriestmp = new ArrayList<>();
//                if (cashModelHistories.size() > 0) {
//                    String header = "";
//                    ArrayList<String> CreditData = new ArrayList<>();
//                    ArrayList<String> DebitData = new ArrayList<>();
//                    boolean istitlefound = false;
//                    for (int i = 0; i < cashModelHistories.size(); i++) {
//                        istitlefound = false;
//                        //If it is the start of a new section we create a new listcell and add it to our array
//                        CashModelHistory adddata = cashModelHistories.get(i);
//                        if (!(header.equals(adddata.getTitleDate()))) {
//
//                            String CheckCreditDebit = cashModelHistories.get(i).getCreditdebit();
//                            CreditData = new ArrayList<>();
//                            DebitData = new ArrayList<>();
//
//                            if (CheckCreditDebit.equalsIgnoreCase("1")) {
//                                DebitData.add(cashModelHistories.get(i).getAccountamount());
//                            } else {
//                                CreditData.add(cashModelHistories.get(i).getAccountamount());
//                            }
//
//                            istitlefound = true;
//                            CashModelHistory sectionCell = new CashModelHistory(adddata.getTitleDate(), "", "", "", "", "", "", "");
//                            sectionCell.setSectionHeader(true);
//                            sectionCell.setGetTitleType(0);
//                            cashModelHistoriestmp.add(sectionCell);
//                            header = adddata.getTitleDate();
//
//                            sectionCell.setCreditedData(CreditData);
//                            sectionCell.setDebitedData(DebitData);
//
//                        }
//
//                        if (!istitlefound) {
//                            String CheckCreditDebit = cashModelHistories.get(i).getCreditdebit();
//                            if (CheckCreditDebit.equalsIgnoreCase("1")) {
//                                DebitData.add(cashModelHistories.get(i).getAccountamount());
//                            } else {
//                                CreditData.add(cashModelHistories.get(i).getAccountamount());
//                            }
//                        }
//                        adddata.setGetTitleType(1);
//                        cashModelHistoriestmp.add(adddata);
//                    }
//                }
//
//                cashModelHistories.clear();
//                cashModelHistories.addAll(cashModelHistoriestmp);
//                CommonFun.CashModelHistoriesTmp.clear();
//                CommonFun.CashModelHistoriesTmp.addAll(cashModelHistories);
//                CallAdapterSetFun();
//            }
//        }
//    }
//
//    private void CallDataIsLodingOrNot() {
//        if (TextUtils.isEmpty(CommonFun.IsAllSmsmFill)) {
//            new Handler().postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    CallDataIsLodingOrNot();
//                    Log.e("CashWidthFirstime==>", "Loading Wait");
//                }
//            }, 700);
//        } else {
//            if (CommonFun.CashModelHistoriesTmp.size() > 0) {
//                Log.e("CashWidthFirstime==>", "Already Loded");
//                pbLoading.setVisibility(View.GONE);
//                cashModelHistories = new ArrayList<>();
//                cashModelHistories.addAll(CommonFun.CashModelHistoriesTmp);
//                CallAdapterSetFun();
//            } else {
//                Log.e("CashWidthFirstime==>", "Yes");
//                mMyTask = new GetAllCashWithdrawal().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
//            }
//        }
//    }
//
//    private void CallSinglesmsTogetCashAtmWidh() {
//        String smsDto = "Acct XX983 debited with INR 4,000.00 on 10-Feb-20.Info: ATM*SACWM176*.Avbl Bal:INR 13,723.00.Call 18002662 for dispute or SMS BLOCK 983 to 9215676766";
//
//        if (smsDto.contains("debited") || smsDto.contains("withdrawal") ||
//                smsDto.contains("purchasing") || smsDto.contains("purchase") || smsDto.contains("dr")) {
//            Log.e("Withdraweal====>", "Yes");
//        } else if (smsDto.contains("credited") || smsDto.contains("cr")) {
//            Log.e("Withdraweal====>", " no");
//        }
//    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

//    private class GetAllCashWithdrawal extends AsyncTask<String, String, String> {
//        @Override
//        protected void onPreExecute() {
//            super.onPreExecute();
//            cashModelHistories = new ArrayList<>();
//        }
//
//        @Override
//        protected void onPostExecute(String s) {
//            super.onPostExecute(s);
//            pbLoading.setVisibility(View.GONE);
//            CallFilterDataMultiviewType();
//        }
//
//        @Override
//        protected String doInBackground(String... strings) {
//            //getAllSms();
//            CallAllSmsDataCommonGet();
//            return null;
//        }
//    }
//
//    private void CallAllSmsDataCommonGet() {
//        AccountHistory = new ArrayList<>();
//        AccountHistory.addAll(CommonFun.firstTimeSmsModels);
//        Log.e("DataLoadingDone", "Yes " + AccountHistory.size());
//
//        SimpleDateFormat formatter = new SimpleDateFormat("dd MMMM yyyy");
//        SimpleDateFormat FormateMont = new SimpleDateFormat("MMMM yyyy");
//        String dateVal = "";
//        String TitleDate = "";
//        if (AccountHistory.size() > 0) {
//            for (int i = 0; i < AccountHistory.size(); i++) {
//                String id = AccountHistory.get(i).getId();
//                String BankNameTitle = AccountHistory.get(i).getBankNameTitle();
//                String body = AccountHistory.get(i).getBody();
//                String read = AccountHistory.get(i).getRead();
//                String date = AccountHistory.get(i).getDate();
//                String type = AccountHistory.get(i).getType();
//                if (BankNameTitle != null) {
//                    if (!BankNameTitle.equals("BX-ATMSBI")) {
//                        String smsDto = "Acct XX983 debited with INR 4,000.00 on 10-Feb-20.Info: ATM*SACWM176*.Avbl Bal:INR 13,723.00.Call 18002662 for dispute or SMS BLOCK 983 to 9215676766";
//                        Pattern regEx = Pattern.compile("Acct");
//                        Matcher m = regEx.matcher(body);
//                        if (m.find()) {
//                            String amount = (m.group());
//                            Log.e("IsFountAc", "Yes" + amount);
//                        } else {
//                            Log.e("IsFountAc", " no");
//                        }
//
//                        if (body.contains("ATM") || body.contains("w/d")
//                                || body.contains("Cash")) {
//
//                            // && !body.contains("not w/d")
//                            if (!body.contains("inconvenience") && !body.contains("OTP")) {
//                                if (body.contains("debited") || body.contains("withdrawal") ||
//                                        body.contains("purchasing") || body.contains("purchase") ||
//                                        body.contains("dr") || body.contains("w/d")) {
//
//                                    Log.e("MarchantNameWD", " ATM W/D");
//                                    // String CheckIsDebitCredit = BankingSmsRead.SMSBodyToGetCreditDabitCash(body);
//                                    //String CheckIsDebitCredit = BankingSmsRead.SMSBodyToGetCreditDabitCash(body);
//                                    String CheckIsDebitCredit = BankingSmsRead.SMSBodyToGetCreditDabit(body);
//
//                                    String AccountNo = BankingSmsRead.SMSBodyToGetAccountNumberWithoutHideNo(body);
//                                    String AccountAmount = BankingSmsRead.SMSBodyToGetTotalAmountCash(body);
//
//                                    //   String GetAvilable = BankingSmsRead.SMSBodyToAvilableBalance(body);
//                                    String GetAvilableClear = GetTotalAmount(body);
//                                    String GetBankingSMSDate = "";
//                                    // String GetBankingSMSDate = GetBankingSMSDate(body);
//                                    String Namee = BankingSmsRead.SMSMerchantName(body);
//                                    Log.e("NameeNameeNamee", Namee);
//                                    Long dateV = Long.parseLong(date);
//                                    dateVal = formatter.format(new Date(dateV));
//                                    TitleDate = FormateMont.format(new Date(dateV));
//                                    Testing(body);
//                                    BankName = GetAccountIcon(BankNameTitle);
//                                    Log.e("Withdraweal====>", "Yes");
//                                    Log.e("BodySMSWithdrawal", " id " + id + "\naddress " + BankNameTitle +
//                                            "\nbody " + body +
//                                            "\nAccountNo " + AccountNo +
//                                            "\nAccountAmount " + AccountAmount +
//                                            "\nCheckIsDebitCredit " + CheckIsDebitCredit +
//                                            "\ndate " + dateVal +
//                                            "\nGetAvilable " + GetAvilableClear +
//                                            "\nGetBankingSMSDate " + GetBankingSMSDate +
//                                            "\nGetTitleDate " + TitleDate +
//                                            "\nBankName " + BankName +
//                                            "\nFinalDescription " + "no");
//
//                                    if (!AccountNo.isEmpty()) {
//                                        String CheckisAccoutOrNot = "No Account";
//                                        if (TextUtils.isDigitsOnly(AccountNo)) {
//                                            CheckisAccoutOrNot = "Yes Digit";
//                                        } else if (AccountNo.contains("x")) {
//                                            CheckisAccoutOrNot = "Yes Account valid";
//                                        } else {
//                                            CheckisAccoutOrNot = "No Account";
//                                        }
//
//                                        if (!CheckisAccoutOrNot.equalsIgnoreCase("No Account")) {
//                                            cashModelHistories.add(new CashModelHistory(
//                                                    TitleDate, dateVal, AccountNo,
//                                                    AccountAmount, CheckIsDebitCredit, "", "", BankName));
//
//                                        }
//                                    }
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//        }
//    }
//
//    private void CallFilterDataMultiviewType() {
//        ArrayList<CashModelHistory> cashModelHistoriestmp = new ArrayList<>();
//        if (cashModelHistories.size() > 0) {
//            String header = "";
//            ArrayList<String> CreditData = new ArrayList<>();
//            ArrayList<String> DebitData = new ArrayList<>();
//            boolean istitlefound = false;
//            for (int i = 0; i < cashModelHistories.size(); i++) {
//                istitlefound = false;
//                //If it is the start of a new section we create a new listcell and add it to our array
//                CashModelHistory adddata = cashModelHistories.get(i);
//                if (!(header.equals(adddata.getTitleDate()))) {
//
//                    String CheckCreditDebit = cashModelHistories.get(i).getCreditdebit();
//                    CreditData = new ArrayList<>();
//                    DebitData = new ArrayList<>();
//
//                    if (CheckCreditDebit.equalsIgnoreCase("1")) {
//                        DebitData.add(cashModelHistories.get(i).getAccountamount());
//                    } else {
//                        CreditData.add(cashModelHistories.get(i).getAccountamount());
//                    }
//
//                    istitlefound = true;
//
//
//                    CashModelHistory sectionCell = new CashModelHistory(adddata.getTitleDate(), "", "", "", "", "", "", "");
//                    sectionCell.setSectionHeader(true);
//                    sectionCell.setGetTitleType(0);
//                    cashModelHistoriestmp.add(sectionCell);
//                    header = adddata.getTitleDate();
//
//                    sectionCell.setCreditedData(CreditData);
//                    sectionCell.setDebitedData(DebitData);
//
//                }
//
//                if (!istitlefound) {
//                    String CheckCreditDebit = cashModelHistories.get(i).getCreditdebit();
//                    if (CheckCreditDebit.equalsIgnoreCase("1")) {
//                        DebitData.add(cashModelHistories.get(i).getAccountamount());
//                    } else {
//                        CreditData.add(cashModelHistories.get(i).getAccountamount());
//                    }
//                }
//                adddata.setGetTitleType(1);
//                cashModelHistoriestmp.add(adddata);
//            }
//        }
//
//        cashModelHistories.clear();
//        cashModelHistories.addAll(cashModelHistoriestmp);
//        CommonFun.CashModelHistoriesTmp.clear();
//        CommonFun.CashModelHistoriesTmp.addAll(cashModelHistories);
//        CallAdapterSetFun();
//    }

    private void CallAdapterSetFun() {
        if (cashModelHistories.size() > 0) {
            Log.e("cashModelHistories", cashModelHistories.size() + "");
            rvAccountList.setVisibility(View.VISIBLE);
            llEmpty.setVisibility(View.GONE);
            cashMultiViewTypeAdapter = new CashMultiViewTypeAdapter(activity, cashModelHistories);
            rvAccountList.setAdapter(cashMultiViewTypeAdapter);
            //  if (!isAdLoaded) {
//            loadNative();
            //}
        } else {
            Log.e("cashModelHistories", cashModelHistories.size() + "");
            rvAccountList.setVisibility(View.GONE);
            llEmpty.setVisibility(View.VISIBLE);
        }
    }


//    public void loadNative() {
//        Log.e("HOMEMMEMMEEMEE", "JKSDFHCJS");
//        AdmobAdManager.getInstance().LoadNativeAd(this, getString(R.string.admob_native_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
//                AdmobAdManager.getInstance().populateUnifiedNativeAdView(CashWithdrawalActivity.this, adLayout, (NativeAd) object, false, false);
//            }
//
//            @Override
//            public void onAdClosed() {
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
//            }
//
//        }, true);
//    }


}
