package com.bankbalanceinquiry.ministatement.fragment;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.widget.ImageViewCompat;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.renderer.CustomBarChartRender;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

public class AccountHisotryTrendFragment extends Fragment {

    private Activity activity;

    private ProgressBar pbLoading;
    private HomeAccoutList allAccountModel;

    private LinearLayout llEmpty;
    private TextView tvEmptyMessage;


    private DBHelperAccountNew dbHelperAccountHistory;


    private final ArrayList<HomeAccoutList> allData = new ArrayList<>();
    private final ArrayList<HomeAccoutList> titlesdata = new ArrayList<>();
    ArrayList<String> dateList = new ArrayList<>();

    int color, colorTransparent;

    View root;

    private BarChart chart;
    View leftView;
    LinearLayout li_1;
    LinearLayout li_tab_credited, li_tab_debited;
    TextView txt_tab_debited, txt_tab_credited;
    ImageView img_debited_bullet, img_credited_bullet;
    int typeData = 0;


    public AccountHisotryTrendFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.activity_account_hisotry_trend_fragment, container, false);
        initView();
        return root;
    }

    private void initView() {

        txt_tab_credited = root.findViewById(R.id.txt_tab_credited);
        txt_tab_debited = root.findViewById(R.id.txt_tab_debited);
        img_credited_bullet = root.findViewById(R.id.img_credited_bullet);
        img_debited_bullet = root.findViewById(R.id.img_debited_bullet);
        li_tab_debited = root.findViewById(R.id.li_tab_debited);
        li_tab_credited = root.findViewById(R.id.li_tab_credited);
        li_1 = root.findViewById(R.id.li_1);
        pbLoading = root.findViewById(R.id.pbLoading);

        activity = getActivity();
        dbHelperAccountHistory = new DBHelperAccountNew(activity);

        pbLoading.setVisibility(View.VISIBLE);
        if (getArguments() != null) {
            allAccountModel = (HomeAccoutList) getArguments().getSerializable("OBJ");
            color = getArguments().getInt("color", ContextCompat.getColor(getContext(), R.color.colorPrimary));
            colorTransparent = getArguments().getInt("colorTransparent", ContextCompat.getColor(getContext(), R.color.colorPrimary));
            if (color == 0 || color == -1) {
                color = ContextCompat.getColor(getContext(), R.color.colorPrimary);
            }
            if (colorTransparent == 0 || colorTransparent == -1) {
                colorTransparent = ContextCompat.getColor(getContext(), R.color.app_color_transparant1);
            }
            if (allAccountModel != null) {
                String name = allAccountModel.full_name.replace(" Bank", "");
            }
            //InitComponent();
            InitComponentNew();
            li_1.setBackgroundColor(colorTransparent);
            leftView.setBackgroundColor(color);

        }
        setClicklisteners();

    }

    private void setClicklisteners() {
        li_tab_debited.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ChangeTabView(0);
            }
        });
        li_tab_credited.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ChangeTabView(1);
            }
        });
    }

    private void ChangeTabView(int i) {
        typeData = i;
        switch (i) {
            case 0:
                li_tab_debited.setBackgroundColor(ContextCompat.getColor(getContext(), R.color.white));
                li_tab_credited.setBackgroundColor(ContextCompat.getColor(getContext(), R.color.light_grey_2));

                txt_tab_debited.setTextColor(ContextCompat.getColor(getContext(), R.color.black));
                txt_tab_credited.setTextColor(ContextCompat.getColor(getContext(), R.color.light_grey_bullet_color));

                ImageViewCompat.setImageTintList(img_debited_bullet, ColorStateList.valueOf(ContextCompat.getColor(getContext(), R.color.google_red)));
                ImageViewCompat.setImageTintList(img_credited_bullet, ColorStateList.valueOf(ContextCompat.getColor(getContext(), R.color.light_grey_bullet_color)));

                break;
            case 1:

                li_tab_debited.setBackgroundColor(ContextCompat.getColor(getContext(), R.color.light_grey_2));
                li_tab_credited.setBackgroundColor(ContextCompat.getColor(getContext(), R.color.white));

                txt_tab_debited.setTextColor(ContextCompat.getColor(getContext(), R.color.light_grey_bullet_color));
                txt_tab_credited.setTextColor(ContextCompat.getColor(getContext(), R.color.black));

                ImageViewCompat.setImageTintList(img_debited_bullet, ColorStateList.valueOf(ContextCompat.getColor(getContext(), R.color.light_grey_bullet_color)));
                ImageViewCompat.setImageTintList(img_credited_bullet, ColorStateList.valueOf(ContextCompat.getColor(getContext(), R.color.google_green)));


                break;
        }
        CallDb();

    }


    private void InitComponentNew() {
        chart = root.findViewById(R.id.chart1);
        leftView = root.findViewById(R.id.leftView);


        llEmpty = root.findViewById(R.id.llEmpty);
        tvEmptyMessage = root.findViewById(R.id.tvEmptyMessage);
        tvEmptyMessage.setText(getString(R.string.empty_transaction_history));

        CheckDataNotifyOrNot();
        ChangeTabView(0);

    }

    private void CheckDataNotifyOrNot() {
        if (CommonFun.isIncommingSmsNotify.equalsIgnoreCase("")) {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    CheckDataNotifyOrNot();
                }
            }, 2000);
        } else {
            CommonFun.isIncommingSmsNotify = "";
            CallDb();
        }
    }

    private void CallDb() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                titlesdata.clear();
                allData.clear();
                allData.addAll(dbHelperAccountHistory.GetTransactionsType(allAccountModel.FinalAccountNo, allAccountModel.full_name, "All"));
                ArrayList<HomeAccoutList> tmpdata = new ArrayList<>();
                ArrayList<HomeAccoutList> tmpdataFinal = new ArrayList<>();
                SimpleDateFormat formatterHistory = new SimpleDateFormat("dd MMMM yyyy, hh:mm aa", Locale.US);

                if (allData.size() > 0) {
                    for (HomeAccoutList allDatum : allData) {
                        try {
                            Date date3 = formatterHistory.parse(allDatum.dateValHistory);
                            allDatum.dateLongValue = date3.getTime();
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                    Collections.sort(allData, new Comparator<HomeAccoutList>() {
                        @Override
                        public int compare(HomeAccoutList t1, HomeAccoutList t2) {
                            return Long.valueOf(t2.dateLongValue).compareTo(Long.valueOf(t1.dateLongValue));
                        }
                    });
                    String ModelClickAccountNo = allAccountModel.FinalAccountNo;
                    for (int i = 0; i < allData.size(); i++) {
                        String ForiAccountName = allData.get(i).FinalAccountNo;
                        if (ModelClickAccountNo.equalsIgnoreCase(ForiAccountName)) {
                            tmpdata.add(allData.get(i));
                        }
                    }
                    if (tmpdata.size() > 0) {
                        String header = "";
                        ArrayList<String> CreditData = new ArrayList<>();
                        ArrayList<String> DebitData = new ArrayList<>();
                        boolean istitlefound = false;
                        for (int i = 0; i < tmpdata.size(); i++) {
                            istitlefound = false;
                            HomeAccoutList adddata = tmpdata.get(i);
                            if (!(header.equals(adddata.DateTransactionHistory))) {

                                String CheckCreditDebit = isDebitedOrCredited(adddata);
                                CreditData = new ArrayList<>();
                                DebitData = new ArrayList<>();

                                if (CheckCreditDebit.equalsIgnoreCase("1")) {
                                    CreditData.add(tmpdata.get(i).amount);
                                } else {
                                    DebitData.add(tmpdata.get(i).amount);
                                }

                                istitlefound = true;
                                HomeAccoutList sectionCell = new HomeAccoutList();
                                sectionCell.DateTransactionHistory = adddata.DateTransactionHistory;
                                sectionCell.dateLongValue = adddata.dateLongValue;
                                sectionCell.isSectionHeader = true;
                                sectionCell.GetTitleType = 0;
                                sectionCell.CreditedData = CreditData;
                                sectionCell.DebitedData = DebitData;
                                if (titlesdata.size() < 6) {
                                    titlesdata.add(sectionCell);
                                }
                                tmpdataFinal.add(sectionCell);
                                header = adddata.DateTransactionHistory;
                            }

                            if (!istitlefound) {
                                String CheckCreditDebit = isDebitedOrCredited(tmpdata.get(i));
                                if (CheckCreditDebit.equalsIgnoreCase("1")) {
                                    CreditData.add(tmpdata.get(i).amount);
                                } else {
                                    DebitData.add(tmpdata.get(i).amount);
                                }
                            }

                            adddata.GetTitleType = 1;
                            tmpdataFinal.add(adddata);
                        }
                    }

                    allData.clear();
                    allData.addAll(tmpdataFinal);

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            pbLoading.setVisibility(View.GONE);
                            if (titlesdata.size() > 0) {
                                llEmpty.setVisibility(View.GONE);
                                setChartdata();
                            } else {
                                llEmpty.setVisibility(View.VISIBLE);
                            }
                        }
                    });

                } else {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            pbLoading.setVisibility(View.GONE);
                            llEmpty.setVisibility(View.VISIBLE);
                        }
                    });
                }
            }
        }).start();


    }


    public void setChartdata() {
        dateList.clear();
        chart.clear();
        chart.clearValues();
        chart.zoomOut();
        chart.clearAllViewportJobs();

        CustomBarChartRender barChartRenderer = new CustomBarChartRender(chart, chart.getAnimator(), chart.getViewPortHandler());
        chart.setRenderer(barChartRenderer);
        chart.setDrawBarShadow(false);
        chart.setDrawValueAboveBar(true);
        chart.setViewPortOffsets(100, 50, 100, 50);
        chart.getDescription().setEnabled(false);
        chart.canScrollVertically(View.SCROLL_AXIS_HORIZONTAL);
//        chart.enableScroll();
        chart.setPinchZoom(false);

        chart.setDrawGridBackground(false);
        chart.setEnabled(false);
        chart.setFitBars(true);
//        chart.setVisibleXRangeMinimum(5);


        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setEnabled(true);
        xAxis.setDrawGridLines(false);
        if (titlesdata.size() < 7) {
            xAxis.setAxisMaximum(6);
        } else {
            // xAxis.setAxisMaximum(titlesdata.size()+10);
        }

        xAxis.setTextSize(8f);
        xAxis.setGranularity(1f); // only intervals of 1 day
        xAxis.setTextColor(ContextCompat.getColor(getContext(), R.color.black));

        xAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                int pos = (int) value;
                if (pos < dateList.size()) {
                    return String.valueOf(dateList.get((int) value));
                } else {
                    return "";
                }
            }
        });

        YAxis leftAxis = chart.getAxisLeft();

        leftAxis.setPosition(YAxis.YAxisLabelPosition.INSIDE_CHART);
        leftAxis.setSpaceTop(0f);
//        leftAxis.setAxisMinimum(10);// this replaces setStartAtZero(true)
        leftAxis.setAxisMinimum(0);
        leftAxis.setDrawGridLines(false);
        leftAxis.setGridColor(ContextCompat.getColor(getContext(), R.color.light_grey));
        leftAxis.setTextSize(10f);
        leftAxis.setTextColor(ContextCompat.getColor(getContext(), R.color.black));
        leftAxis.setEnabled(false);


        YAxis rightAxis = chart.getAxisRight();
        rightAxis.setEnabled(false);

        Legend l = chart.getLegend();
        l.setEnabled(true);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        l.setFormSize(0f);
        l.setTextSize(10f);


//        cycleChart.animateX(500);

        setCycleData();
        // chart.zoomIn();
        if (dateList.size() < 7) {
            //chart.zoom(0.06f, 0, 0, 0);
        } else {
            float zoomValue = ((dateList.size() * 4) / 18);
            chart.zoom(zoomValue, 0, 0, 0);
        }

        chart.setDragYEnabled(false);
        chart.setScaleXEnabled(false);
        chart.setScaleYEnabled(false);

        chart.setDrawBarShadow(false);
        chart.setDrawValueAboveBar(true);

    }


    private void setCycleData() {
        ArrayList<BarEntry> values = new ArrayList<>();
        ArrayList<Double> valuesData = new ArrayList<>();

        for (int i = 0; i < titlesdata.size(); i++) {
            String Amout;
            if (typeData == 0) {
                Amout = CallAccountBalanceTesting(titlesdata.get(i).DebitedData);
            } else {
                Amout = CallAccountBalanceTesting(titlesdata.get(i).CreditedData);
            }

            if (TextUtils.isEmpty(Amout)) {
                Amout = "0";
            }
            if (Amout.contains(",")) {
                Amout = Amout.replaceAll(",", "");
            }
            double d = Double.parseDouble(Amout);
            valuesData.add(d);
            Log.e("AjhGVBCHasvc", d + "::" + Amout + "::");
            values.add(new BarEntry(i, (float) (d)));
            SimpleDateFormat formatterHistory1 = new SimpleDateFormat("MMM yy", Locale.US);
            String date = formatterHistory1.format(new Date(titlesdata.get(i).dateLongValue));
            dateList.add(date);
        }

        double average = 0;
        for (Double valuesDatum : valuesData) {
            average = average + valuesDatum;
        }
        average = average / 6;
        setAverageValue(average);
        BarDataSet set1;

        if (chart.getData() != null && chart.getData().getDataSetCount() > 0) {
            set1 = (BarDataSet) chart.getData().getDataSetByIndex(0);

            set1.setValueTextColor(getResources().getColor(R.color.black));
            set1.setValues(values);
            chart.getData().notifyDataChanged();
            chart.notifyDataSetChanged();

        } else {
            set1 = new BarDataSet(values, "");
            set1.setDrawIcons(false);
//            set1.setColor(Color.rgb(248, 175, 191));
            set1.setValueTextColor(getResources().getColor(R.color.black));
            if (typeData == 0) {
                set1.setColor(ContextCompat.getColor(getContext(), R.color.google_red));
//                set1.setColor(Color.rgb(248, 175, 191));
            } else {
                set1.setColor(ContextCompat.getColor(getContext(), R.color.google_green));

            }

            ArrayList<IBarDataSet> dataSets = new ArrayList<>();
            dataSets.add(set1);

            BarData data = new BarData(dataSets);
            data.setValueTextSize(10f);
            data.setBarWidth(0.20f);
            chart.setData(data);

        }
    }

    private void setAverageValue(double d) {
        NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
        DecimalFormat decim = (DecimalFormat) nf;
        decim.applyPattern("#,##,###.##");

        String Amout = decim.format(d);
        TextView tvTitle = root.findViewById(R.id.tvTitle);
        tvTitle.setTextColor(color);
        try {
            String finalAmout = Amout;
            String Rs = activity.getString(R.string.Rs);
            tvTitle.setText("6 Month Average: " + Rs + " " + finalAmout + "/Month");
        } catch (Exception e) {
        }
    }


    private String CallAccountBalanceTesting(ArrayList<String> tempList) {
//        StringBuilder finalallbalance = new StringBuilder();
        double sum = 0;
        for (int i = 0; i < tempList.size(); i++) {
            String AmoutValue = tempList.get(i);
            if (!TextUtils.isEmpty(AmoutValue)) {
                double value = Double.parseDouble(AmoutValue);
                sum += value;
//                finalallbalance.append(AmoutValue);
            }
        }
        String s = String.valueOf(sum);
        NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
        DecimalFormat decim = (DecimalFormat) nf;
        decim.applyPattern("#,##,###.##");
        if (s.contains(".")) {
            String afterPoint = s.substring(s.indexOf(".") + 1);
            if (afterPoint.length() > 2) {
//                DecimalFormat decim = new DecimalFormat("#,##,###.##");
                return decim.format(sum);
            }
        }
//        DecimalFormat decim = new DecimalFormat("#,##,###.##");
        return decim.format(sum);
//        return String.valueOf(CommonFun.findSum(finalallbalance.toString()));
    }

    private String isDebitedOrCredited(HomeAccoutList homeAccount) {
        String isDebitedOrCredited = "0";
        if (homeAccount.isAtmWithDraw) {
            isDebitedOrCredited = "0";
        } else if (homeAccount.isDebited) {
            isDebitedOrCredited = "0";
        } else {
            isDebitedOrCredited = "1";
        }
        return isDebitedOrCredited;
    }
}

