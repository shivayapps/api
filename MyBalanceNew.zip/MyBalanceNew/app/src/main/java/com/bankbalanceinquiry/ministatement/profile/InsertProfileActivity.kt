package com.bankbalanceinquiry.ministatement.profile

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.view.View.OnFocusChangeListener
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import com.bankbalanceinquiry.ministatement.R
import com.bankbalanceinquiry.ministatement.databinding.ActivityInsertProfileBinding
import com.bankbalanceinquiry.ministatement.profile.cardinputhelper.CardMonthYearError
import com.bankbalanceinquiry.ministatement.profile.cardinputhelper.CardMonthYearTextWatcher
import com.bankbalanceinquiry.ministatement.profile.cardinputhelper.OnCardMonthYearFocusChangeListener
import com.bankbalanceinquiry.ministatement.profile.data.BankAccount
import com.bankbalanceinquiry.ministatement.profile.data.BankAccountDao
import com.bankbalanceinquiry.ministatement.utils.MyApplication
import com.bankbalanceinquiry.ministatement.yearmonthpicker.screen.PickerDialogFragment
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.util.Calendar

class InsertProfileActivity : AppCompatActivity() {

    lateinit var bankDao: BankAccountDao
    var bankAccount: BankAccount? = null

    lateinit var binding: ActivityInsertProfileBinding
    var accountId = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInsertProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val autoTextViewBank: AutoCompleteTextView = binding.bankName

        val bankName: Array<out String> = resources.getStringArray(R.array.BankNames)
        val bankNamearrayAdapter =
            ArrayAdapter(this, android.R.layout.simple_list_item_1, bankName)
        autoTextViewBank.setAdapter(bankNamearrayAdapter)

        val autoTextView: AutoCompleteTextView = binding.accountType
        val typeOfAccount: Array<out String> = resources.getStringArray(R.array.AccountTypes)
        val arrayAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, typeOfAccount)
        autoTextView.setAdapter(arrayAdapter)

        val expiryDateLayout: TextInputLayout = binding.cardExpiryDateLayout
        val expiryDateEdit: TextInputEditText = binding.cardExpiryDate
//        expiryDateEdit.onFocusChangeListener = OnFocusChangeListener { p0, p1 ->
//            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
//            imm.hideSoftInputFromWindow(currentFocus!!.windowToken, 0)
//        }

        expiryDateEdit.apply {
            addTextChangedListener(object : CardMonthYearTextWatcher() {
                override fun onCardMonthYearErrorChanged(error: CardMonthYearError) = bindMonthYearError(error)

                override fun onCardMonthYearCompleted() {
//                    binding.cvv2Edit.requestFocus()
                    binding.cardCvv.requestFocus()
                }
            })
            onFocusChangeListener = object : OnCardMonthYearFocusChangeListener(true) {
                override fun onErrorDetected(error: CardMonthYearError) = bindMonthYearError(error)
            }
        }

//        expiryDateLayout.setOnClickListener {
//            val fragmentTransaction = supportFragmentManager.beginTransaction()
//            val dialogPicker = PickerDialogFragment()
//            dialogPicker
//                .setTitleText("Expire Date")
//                .setColorTitleText(Color.BLACK)
//                .setListener { bottomAction, timeMillis ->
//                    val cal = Calendar.getInstance()
//                    cal.timeInMillis = timeMillis
//                }
//            dialogPicker.show(fragmentTransaction, "picker")
//
//        }

//        expiryDate.setEndIconOnClickListener {
//            val fragmentTransaction = supportFragmentManager.beginTransaction()
//
//            // Create the dialog itself, then set it up and show it to the user
//            val dialogPicker = PickerDialogFragment()
//
//            dialogPicker
//                .setTitleText("Expire Date")
//                .setColorTitleText(Color.BLACK)
//                .setListener { bottomAction, timeMillis ->
//                    val cal = Calendar.getInstance()
//                    cal.timeInMillis = timeMillis
//                }
//
//            // Show the DialogFragment by specifying the tag you like
//            dialogPicker.show(fragmentTransaction, "picker")
//
////            // Create new instance of DatePickerFragment
////            val datePickerFragment = DatePickerFragment()
////            val supportFragmentManager = supportFragmentManager
////            supportFragmentManager.setFragmentResultListener(
////                "REQUEST_KEY",
////                viewLifecycleOwner
////            ) { resultKey, bundle ->
////                if (resultKey == "REQUEST_KEY") {
////                    val date = bundle.getString("SELECTED_DATE")
////                    dateentered.setText(date)
////                }
////            }
////            // show
////            datePickerFragment.show(supportFragmentManager, "DatePickerFragment")
//        }

//        val id = navigationArgs.itemId
        accountId = intent.getIntExtra("account_id", -1)
        bankDao = (application as MyApplication).bankDatabase.bankAccountDao()
        if (accountId > 0) {
            // edit account0
//            bankViewModel.retrieveAccount(id).observe(this.viewLifecycleOwner) { selectedAccount ->
//                bankAccount = bankDao.getItem(accountId)
//                bind(bankAccount)
//            }
            bankAccount = bankDao.getItem(accountId)
            bind(bankAccount!!)
            binding.ivDelete.visibility = View.VISIBLE
            disableEdit()
        } else {
            binding.apply {
                ivDelete.visibility = View.GONE
                ivEdit.visibility = View.GONE
                bankLogo.setImageResource(R.drawable.bank_category_image)

//                atmCardOptions.check(R.id.atm_card_option_yes)
//                upiOption.check(R.id.upi_option_yes)
//                bankingAppOption.check(R.id.banking_app_option_yes)
                atmCardOptions.check(R.id.atm_card_option_no)
                upiOption.check(R.id.upi_option_no)
                bankingAppOption.check(R.id.banking_app_option_no)

                submitButtonBankTwo.setOnClickListener {
                    Log.e("InsertProfile", "addBankAccount")
                    addBankAccount()
                }
            }
        }

//        binding.editButtonBank.setOnClickListener {
        binding.ivEdit.setOnClickListener {
            enableEdit()
        }
        binding.ivDelete.setOnClickListener {
            bankDao.delete(bankAccount!!)
            setResult(Activity.RESULT_OK)
            finish()
        }

        binding.atmCardOptionYes.setOnClickListener {
            yesOptionCardClick()
        }
        binding.atmCardOptionNo.setOnClickListener {
            noOptionCardClick()
        }
        binding.upiOptionYes.setOnClickListener {
            yesUpiOptionClick()
        }
        binding.upiOptionNo.setOnClickListener {
            noUpiOptionClick()
        }
        binding.bankingAppOptionYes.setOnClickListener {
            yesBankingAppOptionClick()
        }
        binding.bankingAppOptionNo.setOnClickListener {
            noBankingAppOptionClick()
        }
        noUpiOptionClick()
        noBankingAppOptionClick()
        noOptionCardClick()

        initToolBar()
    }

    private fun bindMonthYearError(error: CardMonthYearError) {
        val errorResId = when (error) {
            CardMonthYearError.EXPIRED -> R.string.month_year_error_expired
            CardMonthYearError.YEAR_OVER_20_YEARS_LATER -> R.string.month_year_error_year_invalid
            CardMonthYearError.YEAR_REQUIRED -> R.string.month_year_error_year_required
            CardMonthYearError.MONTH_INVALID -> R.string.month_year_error_month_invalid
            CardMonthYearError.YEAR_INVALID -> R.string.month_year_error_year_invalid
            CardMonthYearError.MONTH_REQUIRED -> R.string.month_year_error_month_required
            CardMonthYearError.EMPTY -> R.string.month_year_error_empty
            else -> 0
        }

        if (errorResId > 0) {
            binding.cardExpiryDate.error = getString(errorResId)
        } else {
            binding.cardExpiryDate.error = null
        }
    }

    private fun initToolBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = getColor(R.color.app_color)
        }
//        val toolbar = findViewById<Toolbar>(R.id.toolbar)

//        if (bankAccount?.bankName?.length==0) {
        if (accountId > 0) {
            binding.tvTitle.text=bankAccount!!.bankName
        } else {
            binding.tvTitle.text =getString(R.string.insert_profile)
        }
        setSupportActionBar(binding.toolbar)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }


    private fun bind(bankAccount: BankAccount) {
        binding.apply {
            bankName.setText(bankAccount.bankName, TextView.BufferType.SPANNABLE)
            accountHolderName.setText(bankAccount.accountHolderName, TextView.BufferType.SPANNABLE)
            accountType.setText(bankAccount.accountType, TextView.BufferType.SPANNABLE)
            accountNo.setText(bankAccount.accountNo, TextView.BufferType.SPANNABLE)
            ifscCode.setText(bankAccount.ifscNo, TextView.BufferType.SPANNABLE)
            mobileNo.setText(bankAccount.regMobileNo, TextView.BufferType.SPANNABLE)
            bankEmail.setText(bankAccount.regEmailId, TextView.BufferType.SPANNABLE)
            bankRemarks.setText(bankAccount.accountRemarks, TextView.BufferType.SPANNABLE)
            cardHolderName.setText(bankAccount.nameOnCard, TextView.BufferType.SPANNABLE)
            cardNo.setText(bankAccount.cardNumber, TextView.BufferType.SPANNABLE)
            cardCvv.setText(bankAccount.cardCVV, TextView.BufferType.SPANNABLE)
            cardExpiryDate.setText(bankAccount.cardExpiryDate, TextView.BufferType.SPANNABLE)
            atmPin.setText(bankAccount.cardAtmPin, TextView.BufferType.SPANNABLE)
            upiPin.setText(bankAccount.upiPin, TextView.BufferType.SPANNABLE)
            bankingAppLogin.setText(bankAccount.mobileLoginPin, TextView.BufferType.SPANNABLE)
            bankingAppPassword.setText(bankAccount.transactionPin, TextView.BufferType.SPANNABLE)
            submitButtonBankTwo.setOnClickListener {
                Log.e("InsertProfile", "updateAccount")
                updateAccount()
            }
        }
//        when (bankAccount.bankName) {
//            getString(R.string.bank_of_baroda) -> {
//                binding.bankLogo.setImageResource(R.drawable.bank_of_baroda_logo)
//            }
//
//            getString(R.string.kalupur_bank) -> {
//                binding.bankLogo.setImageResource(R.drawable.kalupur_bank_logo)
//            }
//
//            getString(R.string.state_bank_india) -> {
//                binding.bankLogo.setImageResource(R.drawable.sbi_logo)
//            }
//
//            getString(R.string.bank_of_india) -> {
//                binding.bankLogo.setImageResource(R.drawable.boi)
//            }
//
//            getString(R.string.union_bank) -> {
//                binding.bankLogo.setImageResource(R.drawable.union_bank)
//            }
//
//            getString(R.string.icici_bank) -> {
//                binding.bankLogo.setImageResource(R.drawable.icici_logo)
//            }
//
//            else -> {
//                binding.bankLogo.setImageResource(R.drawable.bank_image_2)
//            }
//        }
        if (bankAccount.haveCard) {
            binding.atmCardOptions.check(R.id.atm_card_option_yes)
            unhideCardView()
        } else {
            binding.atmCardOptions.check(R.id.atm_card_option_no)
            hideCardView()
        }
        if (bankAccount.haveUpi) {
            binding.upiOption.check(R.id.upi_option_yes)
            unhideUPIView()
        } else {
            binding.upiOption.check(R.id.upi_option_no)
            hideUPIView()
        }
        if (bankAccount.haveApp) {
            binding.bankingAppOption.check(R.id.banking_app_option_yes)
            unhideAppView()
        } else {
            binding.bankingAppOption.check(R.id.banking_app_option_no)
            hideAppView()
        }
    }

    private fun disableEdit() {
//        binding.editButtonBank.visibility=View.VISIBLE
        binding.ivEdit.visibility = View.VISIBLE
//        binding.ivDone.visibility=View.GONE
        binding.submitButtonBankTwo.visibility = View.GONE
        binding.bankName.isEnabled = false
        binding.accountHolderName.isEnabled = false
        binding.accountType.isEnabled = false
        binding.accountNo.isEnabled = false
        binding.ifscCode.isEnabled = false
        binding.mobileNo.isEnabled = false
        binding.bankEmail.isEnabled = false
        binding.bankRemarks.isEnabled = false
        binding.cardHolderName.isEnabled = false
        binding.cardNo.isEnabled = false
        binding.cardExpiryDate.isEnabled = false
        binding.cardCvv.isEnabled = false
        binding.atmPin.isEnabled = false
        binding.upiPin.isEnabled = false
        binding.bankingAppLogin.isEnabled = false
        binding.bankingAppPassword.isEnabled = false
        binding.atmCardOptionYes.isEnabled = false
        binding.atmCardOptionNo.isEnabled = false
        binding.upiOptionYes.isEnabled = false
        binding.upiOptionNo.isEnabled = false
        binding.bankingAppOptionYes.isEnabled = false
        binding.bankingAppOptionNo.isEnabled = false
    }

    private fun enableEdit() {
//        binding.editButtonBank.visibility=View.GONE
        binding.ivEdit.visibility = View.GONE
//        binding.ivDone.visibility=View.VISIBLE
        binding.submitButtonBankTwo.visibility = View.VISIBLE
        binding.bankName.isEnabled = true
        binding.accountHolderName.isEnabled = true
        binding.accountType.isEnabled = true
        binding.accountNo.isEnabled = true
        binding.ifscCode.isEnabled = true
        binding.mobileNo.isEnabled = true
        binding.bankEmail.isEnabled = true
        binding.bankRemarks.isEnabled = true
        binding.cardHolderName.isEnabled = true
        binding.cardNo.isEnabled = true
        binding.cardExpiryDate.isEnabled = true
        binding.cardCvv.isEnabled = true
        binding.atmPin.isEnabled = true
        binding.upiPin.isEnabled = true
        binding.bankingAppLogin.isEnabled = true
        binding.bankingAppPassword.isEnabled = true
        binding.atmCardOptionYes.isEnabled = true
        binding.atmCardOptionNo.isEnabled = true
        binding.upiOptionYes.isEnabled = true
        binding.upiOptionNo.isEnabled = true
        binding.bankingAppOptionYes.isEnabled = true
        binding.bankingAppOptionNo.isEnabled = true
    }


    private fun addBankAccount() {
        if (isEntryValid()) {

            addNewAccount(
                binding.bankName.text.toString(),
                binding.accountHolderName.text.toString(),
                binding.accountType.text.toString(),
                binding.accountNo.text.toString(),
                binding.ifscCode.text.toString(),
                binding.mobileNo.text.toString(),
                binding.bankEmail.text.toString(),
                binding.bankRemarks.text.toString(),
                binding.cardHolderName.text.toString(),
                binding.cardNo.text.toString(),
                binding.cardExpiryDate.text.toString(),
                binding.cardCvv.text.toString(),
                binding.atmPin.text.toString(),
                binding.upiPin.text.toString(),
                binding.bankingAppLogin.text.toString(),
                binding.bankingAppPassword.text.toString(),
                binding.atmCardOptionYes.isChecked,
                binding.upiOptionYes.isChecked,
                binding.bankingAppOptionYes.isChecked
            )
//            val action = InsertBankFragmentDirections.actionInsertBankFragmentToBankFinalFragment()
//            val action = InsertBankFragmentDirections.actionInsertBankFragmentToViewBankDetailFragment()
//            findNavController().navigate(action)
        } else {
            Log.e("InsertProfile", "addBankAccount-Not-EntryValid")
        }
    }

    private fun getNewAccountEntry(
        bankName: String,
        holderName: String,
        type: String,
        acNumber: String,
        ifsc: String,
        mobileNo: String,
        email: String,
        remarks: String,
        nameOnCard: String,
        cardNo: String,
        expDate: String,
        cvc: String,
        atmPin: String,
        upiPin: String,
        loginPin: String,
        tPin: String,
        haveCard: Boolean,
        haveUpi: Boolean,
        haveApp: Boolean
    ): BankAccount {
        return BankAccount(
            bankName = bankName,
            accountHolderName = holderName,
            accountType = type,
            accountNo = acNumber,
            ifscNo = ifsc,
            regMobileNo = mobileNo,
            regEmailId = email,
            accountRemarks = remarks,
            nameOnCard = nameOnCard,
            cardNumber = cardNo,
            cardCVV = cvc,
            cardAtmPin = atmPin,
            upiPin = upiPin,
            mobileLoginPin = loginPin,
            transactionPin = tPin,
            cardExpiryDate = expDate,
            haveCard = haveCard,
            haveUpi = haveUpi,
            haveApp = haveApp
        )
    }

    fun addNewAccount(
        bankName: String,
        holderName: String,
        type: String,
        acNumber: String,
        ifsc: String,
        mobileNo: String,
        email: String,
        remarks: String,
        nameOnCard: String,
        cardNo: String,
        expDate: String,
        cvc: String,
        atmPin: String,
        upiPin: String,
        loginPin: String,
        tPin: String,
        haveCard: Boolean,
        haveUpi: Boolean,
        haveApp: Boolean
    ) {
        val newAccount = getNewAccountEntry(
            bankName,
            holderName,
            type,
            acNumber,
            ifsc,
            mobileNo,
            email,
            remarks,
            nameOnCard,
            cardNo,
            expDate,
            cvc,
            atmPin,
            upiPin,
            loginPin,
            tPin,
            haveCard,
            haveUpi,
            haveApp
        )
        bankDao.insert(newAccount)

        setResult(Activity.RESULT_OK)
        finish()
    }

    fun isEntryValid(bankName: String, holderName: String): Boolean {
        if (bankName.isBlank() || holderName.isBlank()) {
            return false
        }
        return true
    }

    private fun isEntryValid(): Boolean {
        return isEntryValid(
            binding.bankName.text.toString(),
            binding.accountHolderName.text.toString()
        )
    }

    private fun getUpdatedEntry(
        accountId: Int,
        bankName: String,
        holderName: String,
        type: String,
        acNumber: String,
        ifsc: String,
        mobileNo: String,
        email: String,
        remarks: String,
        nameOnCard: String,
        cardNo: String,
        expDate: String,
        cvc: String,
        atmPin: String,
        upiPin: String,
        loginPin: String,
        tPin: String,
        haveCard: Boolean,
        haveUpi: Boolean,
        haveApp: Boolean
    ): BankAccount {
        return BankAccount(
            id = accountId,
            bankName = bankName,
            accountHolderName = holderName,
            accountType = type,
            accountNo = acNumber,
            ifscNo = ifsc,
            regMobileNo = mobileNo,
            regEmailId = email,
            accountRemarks = remarks,
            nameOnCard = nameOnCard,
            cardNumber = cardNo,
            cardCVV = cvc,
            cardAtmPin = atmPin,
            upiPin = upiPin,
            mobileLoginPin = loginPin,
            transactionPin = tPin,
            cardExpiryDate = expDate,
            haveCard = haveCard,
            haveUpi = haveUpi,
            haveApp = haveApp
        )
    }

    fun updateAccount(
        accountId: Int,
        bankName: String,
        holderName: String,
        type: String,
        acNumber: String,
        ifsc: String,
        mobileNo: String,
        email: String,
        remarks: String,
        nameOnCard: String,
        cardNo: String,
        expDate: String,
        cvc: String,
        atmPin: String,
        upiPin: String,
        loginPin: String,
        tPin: String,
        haveCard: Boolean,
        haveUpi: Boolean,
        haveApp: Boolean
    ) {
        val updatedAccount = getUpdatedEntry(
            accountId,
            bankName,
            holderName,
            type,
            acNumber,
            ifsc,
            mobileNo,
            email,
            remarks,
            nameOnCard,
            cardNo,
            expDate,
            cvc,
            atmPin,
            upiPin,
            loginPin,
            tPin,
            haveCard,
            haveUpi,
            haveApp
        )
        bankDao.update(updatedAccount)

        setResult(Activity.RESULT_OK)
        finish()
//        updateAccount(updatedAccount)
    }

    private fun updateAccount() {
        if (isEntryValid()) {
            updateAccount(
//                this.navigationArgs.itemId,
                accountId,
                this.binding.bankName.text.toString(),
                this.binding.accountHolderName.text.toString(),
                this.binding.accountType.text.toString(),
                this.binding.accountNo.text.toString(),
                this.binding.ifscCode.text.toString(),
                this.binding.mobileNo.text.toString(),
                this.binding.bankEmail.text.toString(),
                this.binding.bankRemarks.text.toString(),
                this.binding.cardHolderName.text.toString(),
                this.binding.cardNo.text.toString(),
                this.binding.cardExpiryDate.text.toString(),
                this.binding.cardCvv.text.toString(),
                this.binding.atmPin.text.toString(),
                this.binding.upiPin.text.toString(),
                this.binding.bankingAppLogin.text.toString(),
                this.binding.bankingAppPassword.text.toString(),
                this.binding.atmCardOptionYes.isChecked,
                this.binding.upiOptionYes.isChecked,
                this.binding.bankingAppOptionYes.isChecked
            )
//            val action = InsertBankFragmentDirections.actionInsertBankFragmentToBankFinalFragment(this.navigationArgs.itemId)
//            val action = InsertBankFragmentDirections.actionInsertBankFragmentToViewBankDetailFragment(this.navigationArgs.itemId)
//            findNavController().navigate(action)
        } else {
            Log.e("InsertProfile", "updateAccount-Not-EntryValid")
        }
    }

    private fun hideCardView() {
        val cardHolderName: TextInputLayout = binding.cardHolderNameLayout
        val cardNumber: TextInputLayout = binding.cardNoLayout
        val expiryDate: TextInputLayout = binding.cardExpiryDateLayout
        val cvv: TextInputLayout = binding.cardCvvLayout
        val atmPin: TextInputLayout = binding.atmPinLayout
        cardHolderName.visibility = (View.GONE)
        cardNumber.visibility = (View.GONE)
        expiryDate.visibility = (View.GONE)
        cvv.visibility = (View.GONE)
        atmPin.visibility = (View.GONE)
        val constraintLayout: ConstraintLayout = binding.bankLayout
        val constraintSet = ConstraintSet()
        constraintSet.clone(constraintLayout)
        constraintSet.connect(
            R.id.upi_option_question,
            ConstraintSet.START,
            R.id.atm_card_options,
            ConstraintSet.START,
            0
        )
        constraintSet.connect(
            R.id.upi_option_question,
            ConstraintSet.TOP,
            R.id.atm_card_options,
            ConstraintSet.BOTTOM,
            0
        )
        constraintSet.applyTo(constraintLayout)

    }

    private fun unhideCardView() {
        val cardHolderName: TextInputLayout = binding.cardHolderNameLayout
        val cardNumber: TextInputLayout = binding.cardNoLayout
        val expiryDate: TextInputLayout = binding.cardExpiryDateLayout
        val cvv: TextInputLayout = binding.cardCvvLayout
        val atmPin: TextInputLayout = binding.atmPinLayout
        cardHolderName.visibility = (View.VISIBLE)
        cardNumber.visibility = (View.VISIBLE)
        expiryDate.visibility = (View.VISIBLE)
        cvv.visibility = (View.VISIBLE)
        atmPin.visibility = (View.VISIBLE)
        val constraintLayout: ConstraintLayout = binding.bankLayout
        val constraintSet = ConstraintSet()
        constraintSet.clone(constraintLayout)
        constraintSet.connect(
            R.id.upi_option_question,
            ConstraintSet.START,
            R.id.atm_pin_layout,
            ConstraintSet.START,
            0
        )
        constraintSet.connect(
            R.id.upi_option_question,
            ConstraintSet.TOP,
            R.id.atm_pin_layout,
            ConstraintSet.BOTTOM,
            18
        )
        constraintSet.applyTo(constraintLayout)
    }

    private fun hideUPIView() {
        val upiPIN: TextInputLayout = binding.upiPinLayout
        upiPIN.visibility = (View.GONE)
        val constraintLayout: ConstraintLayout = binding.bankLayout
        val constraintSet = ConstraintSet()
        constraintSet.clone(constraintLayout)
        constraintSet.connect(
            R.id.mobile_banking_app_question,
            ConstraintSet.START,
            R.id.upi_option,
            ConstraintSet.START,
            0
        )
        constraintSet.connect(
            R.id.mobile_banking_app_question,
            ConstraintSet.TOP,
            R.id.upi_option,
            ConstraintSet.BOTTOM,
            0
        )
        constraintSet.applyTo(constraintLayout)
    }

    private fun unhideUPIView() {
        val upiPIN: TextInputLayout = binding.upiPinLayout
        upiPIN.visibility = (View.VISIBLE)
        val constraintLayout: ConstraintLayout = binding.bankLayout
        val constraintSet = ConstraintSet()
        constraintSet.clone(constraintLayout)
        constraintSet.connect(
            R.id.mobile_banking_app_question,
            ConstraintSet.START,
            R.id.upi_pin_layout,
            ConstraintSet.START,
            0
        )
        constraintSet.connect(
            R.id.mobile_banking_app_question,
            ConstraintSet.TOP,
            R.id.upi_pin_layout,
            ConstraintSet.BOTTOM,
            18
        )
        constraintSet.applyTo(constraintLayout)
    }

    private fun hideAppView() {
        val appLogin: TextInputLayout = binding.bankingAppLoginLayout
        appLogin.visibility = (View.GONE)
        val appPassword: TextInputLayout = binding.bankingAppPasswordLayout
        appPassword.visibility = (View.GONE)
        val constraintLayout: ConstraintLayout = binding.bankLayout
        val constraintSet = ConstraintSet()
        constraintSet.clone(constraintLayout)
        constraintSet.connect(
            R.id.submit_button_bank_two,
            ConstraintSet.TOP,
            R.id.banking_app_option,
            ConstraintSet.BOTTOM,
            0
        )
        constraintSet.applyTo(constraintLayout)
    }

    private fun unhideAppView() {
        val appLogin: TextInputLayout = binding.bankingAppLoginLayout
        appLogin.visibility = (View.VISIBLE)
        val appPassword: TextInputLayout = binding.bankingAppPasswordLayout
        appPassword.visibility = (View.VISIBLE)
        val constraintLayout: ConstraintLayout = binding.bankLayout
        val constraintSet = ConstraintSet()
        constraintSet.clone(constraintLayout)
        constraintSet.connect(
            R.id.submit_button_bank_two,
            ConstraintSet.TOP,
            R.id.banking_app_password_layout,
            ConstraintSet.BOTTOM,
            16
        )
        constraintSet.applyTo(constraintLayout)
    }

    fun noOptionCardClick() {
        val noOptionCard: RadioButton = binding.atmCardOptionNo
        if (noOptionCard.isChecked) {
            hideCardView()
        }
    }

    fun yesOptionCardClick() {
        val yesOptionCard: RadioButton = binding.atmCardOptionYes
        if (yesOptionCard.isChecked) {
            unhideCardView()
        }
    }

    fun noUpiOptionClick() {
        val noOptionUPI: RadioButton = binding.upiOptionNo
        if (noOptionUPI.isChecked) {
            hideUPIView()
        }
    }

    fun yesUpiOptionClick() {
        val yesOptionUPI: RadioButton = binding.upiOptionYes
        if (yesOptionUPI.isChecked) {
            unhideUPIView()
        }
    }

    fun noBankingAppOptionClick() {
        val noOptionApp: RadioButton = binding.bankingAppOptionNo
        if (noOptionApp.isChecked) {
            hideAppView()
        }
    }

    fun yesBankingAppOptionClick() {
        val yesOptionApp: RadioButton = binding.bankingAppOptionYes
        if (yesOptionApp.isChecked) {
            unhideAppView()
        }
    }


}