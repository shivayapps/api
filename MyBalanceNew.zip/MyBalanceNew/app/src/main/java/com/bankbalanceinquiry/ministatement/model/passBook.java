package com.bankbalanceinquiry.ministatement.model;

public class passBook {

    String pass_dec;
    String pass_date;
    String pass_which;
    String pass_amount;
    String ava_balance;
    int bank_type;

    public int getBank_type() {
        return bank_type;
    }

    public void setBank_type(int bank_type) {
        this.bank_type = bank_type;
    }

    public String getAva_balance() {
        return ava_balance;
    }

    public void setAva_balance(String ava_balance) {
        this.ava_balance = ava_balance;
    }

    public String getPass_dec() {
        return pass_dec;
    }

    public void setPass_dec(String pass_dec) {
        this.pass_dec = pass_dec;
    }

    public String getPass_date() {
        return pass_date;
    }

    public void setPass_date(String pass_date) {
        this.pass_date = pass_date;
    }

    public String getPass_which() {
        return pass_which;
    }

    public void setPass_which(String pass_which) {
        this.pass_which = pass_which;
    }

    public String getPass_amount() {
        return pass_amount;
    }

    public void setPass_amount(String pass_amount) {
        this.pass_amount = pass_amount;
    }

//    public passBook(String pass_dec, String pass_date, String pass_which, String pass_amount) {
//        this.pass_dec = pass_dec;
//        this.pass_date = pass_date;
//        this.pass_which = pass_which;
//        this.pass_amount = pass_amount;
//    }


}
