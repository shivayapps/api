package com.bankbalanceinquiry.ministatement.Admanager;


public interface AdEventListener {
    void onAdLoaded(Object object);
    void onAdClosed();
    void onLoadError(String errorCode);
}