package com.bankbalanceinquiry.ministatement.store.util

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.View
import com.bankbalanceinquiry.ministatement.R
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

enum class PasswordStrength {
    WEAK,
    MEDIUM,
    STRONG,
    VERY_STRONG
}

class Util {
    companion object{
        fun log(message: String) {
            Log.d("", message)
        }

        fun getBaseStringForFiltering(originalString: String) : String {
            val stringBuilder = StringBuilder()

            for (char in originalString.toCharArray()) {
                if (char.isLetter())
                    stringBuilder.append(char)
            }

            return stringBuilder.toString()
        }

        fun Context.createBottomSheet(): BottomSheetDialog {
            return BottomSheetDialog(this, R.style.BottomSheetDialogTheme)
        }

        fun Activity.createBottomSheet(): BottomSheetDialog {
            return BottomSheetDialog(this, R.style.BottomSheetDialogTheme)
        }

        fun View.setBottomSheet(bottomSheet: BottomSheetDialog) {
            bottomSheet.behavior.state = BottomSheetBehavior.STATE_EXPANDED
            bottomSheet.setContentView(this)
            bottomSheet.create()
            bottomSheet.show()
        }
    }


    fun getPasswordStrength(password: String): PasswordStrength {
        val length = password.length
        val hasUpperCase = password.any { it.isUpperCase() }
        val hasLowerCase = password.any { it.isLowerCase() }
        val hasDigit = password.any { it.isDigit() }
        val hasSpecialChar = password.any { !it.isLetterOrDigit() }

        // Determine password strength based on various criteria
        return when {
            length < 8 -> PasswordStrength.WEAK
            length < 12 -> {
                if (hasUpperCase && hasLowerCase && hasDigit && hasSpecialChar) {
                    PasswordStrength.STRONG
                } else {
                    PasswordStrength.MEDIUM
                }
            }
            else -> PasswordStrength.VERY_STRONG
        }
    }

}