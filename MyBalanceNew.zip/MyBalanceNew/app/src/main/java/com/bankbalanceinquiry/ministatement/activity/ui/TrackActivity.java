package com.bankbalanceinquiry.ministatement.activity.ui;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bankbalanceinquiry.ministatement.Events.SmsList;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.BaseActivity;
import com.bankbalanceinquiry.ministatement.activity.drawerActivity;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;
import com.bankbalanceinquiry.ministatement.utils.SmsService;
//import com.tbuonomo.viewpagerdotsindicator.WormDotsIndicator;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class TrackActivity extends BaseActivity {


    ViewPager viewPager;
    ScreenSlidePagerAdapter pagerAdapter;
//    private WormDotsIndicator worm_dots_indicator;
    private ImageView previous;
    private TextView next;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track);

        pagerAdapter = new ScreenSlidePagerAdapter(getSupportFragmentManager());
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this);

        viewPager = findViewById(R.id.viewPager);
//        worm_dots_indicator = findViewById(R.id.worm_dots_indicator);
        previous = findViewById(R.id.previous);
        next = findViewById(R.id.next);
        viewPager.setAdapter(pagerAdapter);
        viewPager.setOffscreenPageLimit(4);
//        worm_dots_indicator.setViewPager(viewPager);
        if (!isMyServiceRunning(SmsService.class)) {
            ContextCompat.startForegroundService(this, new Intent(TrackActivity.this, SmsService.class));
        }
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (position == 3) {
                    next.setText(getResources().getString(R.string.done));
                } else {
                    next.setText(getResources().getString(R.string.next));
                }
                if (position == 0) {
                    previous.setVisibility(View.INVISIBLE);
                } else {
                    previous.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (next.getText().equals(getResources().getText(R.string.next))) {
                    viewPager.setCurrentItem(viewPager.getCurrentItem() + 1);
                } else if (next.getText().equals(getResources().getString(R.string.done))) {
                    PreferenceHelper.saveToUserDefaults(getApplicationContext(), Constant.TRACK_PREF, "1");
                    Intent i = new Intent(TrackActivity.this, drawerActivity.class);
                    startActivity(i);
                    finish();
                }
            }
        });
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (previous.getVisibility() == View.VISIBLE) {
                    viewPager.setCurrentItem(viewPager.getCurrentItem() - 1);
                }
            }
        });
    }

    @Subscribe
    public void getAllSms(SmsList smsList) {/*
        ArrayList<HomeAccoutList> allTransactionList = smsList.getAllTransactionList();
        ArrayList<HomeAccoutList> homeAccoutLists = smsList.getHomeAccoutLists();*/
    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (manager != null) {
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (serviceClass.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    private class ScreenSlidePagerAdapter extends FragmentStatePagerAdapter {
        public ScreenSlidePagerAdapter(FragmentManager fm) {
            super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        @Override
        public Fragment getItem(int position) {
            return new IntroFragment(position);
        }

        @Override
        public int getCount() {
            return 4;
        }
    }
}
