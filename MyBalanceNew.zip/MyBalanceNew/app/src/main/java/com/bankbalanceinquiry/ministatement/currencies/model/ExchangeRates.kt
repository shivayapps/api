package com.bankbalanceinquiry.ministatement.currencies.model

import androidx.annotation.Keep
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import java.time.LocalDate
import java.util.Date

@Keep
@JsonClass(generateAdapter = true)
data class ExchangeRates(
    @field:Json(name = "success") val success: Boolean?,
    @field:Json(name = "error") val error: String?,

    @field:Json(name = "base") val base: String?,
    @field:Json(name = "date") val date: String?,
    @field:Json(name = "rates") val rates: List<Rate>?
)
