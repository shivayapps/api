package com.bankbalanceinquiry.ministatement.store.ui.fragments.account

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.KeyEvent
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.core.view.children
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.bankbalanceinquiry.ministatement.BuildConfig
import com.bankbalanceinquiry.ministatement.R
import com.bankbalanceinquiry.ministatement.store.data.model.Account
import com.bankbalanceinquiry.ministatement.databinding.FragmentAddBinding
import com.bankbalanceinquiry.ministatement.databinding.OptionsModalBinding
import com.bankbalanceinquiry.ministatement.databinding.SavepasswordModalBinding
import com.bankbalanceinquiry.ministatement.store.util.Encryption
import com.bankbalanceinquiry.ministatement.store.util.Util.Companion.createBottomSheet
import com.bankbalanceinquiry.ministatement.store.util.Util.Companion.setBottomSheet
import com.bankbalanceinquiry.ministatement.store.viewModel.AccountViewModel
import com.bankbalanceinquiry.ministatement.store.viewModel.AddEditViewModel
import com.bankbalanceinquiry.ministatement.utils.TextDrawable
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.chip.Chip
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch
import java.util.Random


class AddFragment : Fragment() {

    private var _binding: FragmentAddBinding? = null
    private val binding get() = _binding!!
    private var selectedAccount: String? = null

    private lateinit var viewModel: AccountViewModel
    private lateinit var myViewModel: AddEditViewModel

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentAddBinding.inflate(inflater, container, false)


        initialization()

        requireActivity().findViewById<BottomNavigationView>(R.id.bottom_nav).visibility = View.GONE

        init()

        binding.accType.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                selectedAccount = p0.toString()
                val color =
                    Color.argb(
                        255,
                        Random().nextInt(256),
                        Random().nextInt(256),
                        Random().nextInt(256)
                    )
                if (p0?.length!! > 0) {
                    val drawable = TextDrawable.builder()
                        .buildRoundRect(p0?.substring(0, 1), color, 8)
                    binding.accountLogo.setImageDrawable(drawable)
                }
            }

            override fun afterTextChanged(p0: Editable?) {
            }
        })

//        binding.accType.afterTextChanged{
//            selectedAccount = it
//
//            val color =
//                Color.argb(255, Random().nextInt(256), Random().nextInt(256), Random().nextInt(256))
//            val drawable = TextDrawable.builder()
//                .buildRoundRect(it.substring(0,1),color,8)
//
//            binding.accountLogo.setImageDrawable(drawable)
////            when(it.toLowerCase()){
////                "paypal" -> setImageOnAccountNameChange(R.drawable.paypal)
////                "instagram" -> setImageOnAccountNameChange(R.drawable.instagram)
////                "facebook" -> setImageOnAccountNameChange(R.drawable.facebook)
////                "linkedin" -> setImageOnAccountNameChange(R.drawable.linkedin)
////                "snapchat" -> setImageOnAccountNameChange(R.drawable.snapchat)
////                "youtube" -> setImageOnAccountNameChange(R.drawable.youtube)
////                "dropbox" -> setImageOnAccountNameChange(R.drawable.dropbox)
////                "twitter" -> setImageOnAccountNameChange(R.drawable.twitter)
////                "google drive" -> setImageOnAccountNameChange(R.drawable.drive)
////                "netflix" -> {
//////                    binding.btnShare.visibility = View.VISIBLE
////                    setImageOnAccountNameChange(R.drawable.netflix_logo)
////                }
////                "amazon prime" -> {
//////                    binding.btnShare.visibility = View.VISIBLE
////                    setImageOnAccountNameChange(R.drawable.amazon_logo)
////                }
////                "spotify" -> setImageOnAccountNameChange(R.drawable.spotify)
////                "discord" -> setImageOnAccountNameChange(R.drawable.discord)
////                "others" -> setImageOnAccountNameChange(R.drawable.general_account)
////            }
//        }

        binding.btnSave.setOnClickListener {

            val company = binding.accType.text.toString()
            val email = binding.email.text.toString()
            val password = binding.password.text.toString()

            if (company.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Snackbar.make(it, "Please fill all the details", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Snackbar.make(it, "Please check your Email Id", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val saveDialog = SavepasswordModalBinding.inflate(layoutInflater)
            val bottomSheet = requireContext().createBottomSheet()

            saveDialog.apply {
                optionsHeading.text = "Confirm Changes"
                optionsContent.text = "Are you sure you want save?"
                positiveOption.text = "Save Changes"
                negativeOption.text = "Don't Save"

                positiveOption.setOnClickListener {
                    bottomSheet.dismiss()
                    insertDataToDB()
                    val frag = PasswordFragment()
                    val trans = fragmentManager?.beginTransaction()
                    trans?.replace(R.id.fragment, frag)?.commit()
                }
                negativeOption.setOnClickListener {
                    bottomSheet.dismiss()
                }
            }
            saveDialog.root.setBottomSheet(bottomSheet)


        }
        binding.back.setOnClickListener {
            handleBackButtonPress()
        }
        // Account List
//        val accounts = resources.getStringArray(R.array.accounts)
//        val arrayAdapter = ArrayAdapter(requireContext(),R.layout.list_items,accounts)
//        binding.accType.setAdapter(arrayAdapter)

        setImageOnAccountNameChange(R.drawable.general_account)

        return binding.root

    }

    private fun initialization() {
        viewModel = ViewModelProvider(this)[AccountViewModel::class.java]
        myViewModel = ViewModelProvider(
            this,
            ViewModelProvider.AndroidViewModelFactory
                .getInstance(requireActivity().application)
        )[AddEditViewModel::class.java]
    }

    private fun init() {
        myViewModel.saveStatus.observe(viewLifecycleOwner) {

            if (it == 2) {
                Toast.makeText(requireContext(), "Successful Saved", Toast.LENGTH_SHORT).show()
                // Moving into HomeFragment after saving
                val frag = PasswordFragment()
                val trans = fragmentManager?.beginTransaction()
                trans?.replace(R.id.fragment, frag)?.commit()

            } else if (it == 6) {
                Toast.makeText(requireContext(), "Failed to save", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun setImageOnAccountNameChange(imageID: Int) {
        binding.accountLogo.apply {
            setImageResource(imageID)
//            visibility = View.VISIBLE
        }
//        binding.remainingLayout.visibility = View.VISIBLE
//        binding.btnSave.visibility = View.VISIBLE
    }

    private fun handleBackButtonPress() {
        val inputAccountType = binding.accType.text.toString().trim()
        val inputEmail = binding.email.text.toString().trim()
        val inputUserName = binding.username.text.toString().trim()
        val inputPassword = binding.password.text.toString().trim()

        if (inputAccountType.isNotEmpty() || inputEmail.isNotEmpty() || inputUserName.isNotEmpty() || inputPassword.isNotEmpty()) {

            val dialog = OptionsModalBinding.inflate(layoutInflater)
            val bottomSheet = requireContext().createBottomSheet()
            dialog.apply {

                optionsHeading.text = "Discard changes"
                optionsContent.text = "Are you sure you discard changes?"
                positiveOption.text = "Discard"
                positiveOption.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.white
                    )
                )
                negativeOption.text = "Continue editing"
                negativeOption.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.black
                    )
                )
                positiveOption.setOnClickListener {
                    bottomSheet.dismiss()
                    val frag = PasswordFragment()
                    val trans = fragmentManager?.beginTransaction()
                    trans?.replace(R.id.fragment, frag)?.commit()
                }
                negativeOption.setOnClickListener {
                    bottomSheet.dismiss()

                }
            }
            dialog.root.setBottomSheet(bottomSheet)
        } else {
            val frag = PasswordFragment()
            val trans = fragmentManager?.beginTransaction()
            trans?.replace(R.id.fragment, frag)?.commit()
        }
    }

    override fun onResume() {
        super.onResume()
        requireView().isFocusableInTouchMode = true
        requireView().requestFocus()
        requireView().setOnKeyListener { _, keyCode, event ->
            if (event.action === KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                handleBackButtonPress()
                true
            } else false
        }
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun insertDataToDB() {
        val company = binding.accType.text.toString()
        val email = binding.email.text.toString()
        val category: String = (binding.categoryChipGroup.children.toList().filter {
            (it as Chip).isChecked
        }[0] as Chip).text.toString()
        val password = binding.password.text.toString()
        val userName = binding.username.text.toString()

        // Encrypt the password field
        val encryption = com.bankbalanceinquiry.ministatement.store.util.Encryption.getDefault(
            "Key",
            BuildConfig.Elephant,
            ByteArray(16)
        )
        val encryptedPassword = encryption.encryptOrNull(password)

        val account = Account(0, company, email, category, userName, encryptedPassword)

        lifecycleScope.launch {
            myViewModel.saveData(viewModel, account)
        }

    }

    private fun AutoCompleteTextView.afterTextChanged(afterTextChanged: (String) -> Unit) {

        this.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(editable: Editable?) {
                afterTextChanged.invoke(editable.toString())
            }

        })

    }
}