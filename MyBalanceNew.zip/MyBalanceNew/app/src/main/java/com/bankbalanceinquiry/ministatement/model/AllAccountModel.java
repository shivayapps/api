package com.bankbalanceinquiry.ministatement.model;

import java.io.Serializable;

public class AllAccountModel implements Serializable {

    private String bankNameTitle;
    private String accountNo;
    private String accountAmount;
    private String dateVal;
    private String checkIsDebitCredit;
    private String AvilabeClearBalance;
    private String GetBankingSMSDate;
    private boolean IsActiveOrInActive = true;
    private boolean isBusinessOrPersion = true;
    private String FinalDescription;
    private int BankIcon;
    private String BankName;

    public AllAccountModel(String bankNameTitle, String accountNo, String accountAmount,
                           String dateVal, String checkIsDebitCredit,
                           String AvilabeClearBalance, String getBankingSMSDate,
                           int BankIcon,String BankName) {
        this.bankNameTitle = bankNameTitle;
        this.accountNo = accountNo;
        this.accountAmount = accountAmount;
        this.dateVal = dateVal;
        this.checkIsDebitCredit = checkIsDebitCredit;
        this.AvilabeClearBalance = AvilabeClearBalance;
        this.GetBankingSMSDate = getBankingSMSDate;
        this.BankIcon = BankIcon;
        this.BankName = BankName;
    }

    public String getBankNameTitle() {
        return bankNameTitle;
    }

    public void setBankNameTitle(String bankNameTitle) {
        this.bankNameTitle = bankNameTitle;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getAccountAmount() {
        return accountAmount;
    }

    public void setAccountAmount(String accountAmount) {
        this.accountAmount = accountAmount;
    }

    public String getDateVal() {
        return dateVal;
    }

    public void setDateVal(String dateVal) {
        this.dateVal = dateVal;
    }

    public String getCheckIsDebitCredit() {
        return checkIsDebitCredit;
    }

    public void setCheckIsDebitCredit(String checkIsDebitCredit) {
        this.checkIsDebitCredit = checkIsDebitCredit;
    }

    public boolean isActiveOrInActive() {
        return IsActiveOrInActive;
    }

    public void setActiveOrInActive(boolean activeOrInActive) {
        IsActiveOrInActive = activeOrInActive;
    }

    public boolean isBusinessOrPersion() {
        return isBusinessOrPersion;
    }

    public void setBusinessOrPersion(boolean businessOrPersion) {
        isBusinessOrPersion = businessOrPersion;
    }


    public String getAvilabeClearBalance() {
        return AvilabeClearBalance;
    }

    public void setAvilabeClearBalance(String avilabeClearBalance) {
        AvilabeClearBalance = avilabeClearBalance;
    }

    public String getGetBankingSMSDate() {
        return GetBankingSMSDate;
    }

    public void setGetBankingSMSDate(String getBankingSMSDate) {
        GetBankingSMSDate = getBankingSMSDate;
    }

    public String getFinalDescription() {
        return FinalDescription;
    }

    public void setFinalDescription(String finalDescription) {
        FinalDescription = finalDescription;
    }

    public int getBankIcon() {
        return BankIcon;
    }

    public void setBankIcon(int bankIcon) {
        BankIcon = bankIcon;
    }

    public String getBankName() {
        return BankName;
    }

    public void setBankName(String bankName) {
        BankName = bankName;
    }
}
