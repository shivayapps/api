@file:Suppress("unused")

package com.bankbalanceinquiry.ministatement.inapp

import android.app.Activity
import android.content.Context
import android.os.Parcelable
import android.os.SystemClock
import android.widget.Toast
import androidx.annotation.Keep
import androidx.annotation.NonNull
import com.android.billingclient.api.*
import com.bankbalanceinquiry.ministatement.financialcalculator.helper.PreferenceManager
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize
import kotlinx.android.parcel.RawValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.annotations.NotNull
import java.text.SimpleDateFormat
import java.util.*


object ProductPurchaseHelper {

    @Keep
    @Parcelize
    data class ProductInfo(
        @SerializedName("id")
        @Expose
        val id: String,
        @SerializedName("formatted_price")
        @Expose
        val formattedPrice: String,
        @SerializedName("price_amount_micros")
        @Expose
        val priceAmountMicros: Long,
        @SerializedName("price_currency_code")
        @Expose
        val priceCurrencyCode: String,
        @SerializedName("billing_period")
        @Expose
        val billingPeriod: String,
        @SerializedName("free_trial_period")
        @Expose
        val freeTrialPeriod: String,
        @SerializedName("renewal_time")
        @Expose
        var renewalTime: Long,
        @SerializedName("product_detail")
        @Expose
        val productDetail: @RawValue ProductDetails
    ) : Parcelable

    private val TAG: String = javaClass.simpleName

    private val lifeTimeProductKeyList: ArrayList<String> = ArrayList()
    private val subscriptionKeyList: ArrayList<String> = ArrayList()
    private val PRODUCT_LIST: ArrayList<ProductInfo> = ArrayList()

    private var mPurchaseListener: ProductPurchaseListener? =
        null // Callback for listen purchase states
    private var mBillingClient: BillingClient? = null // Object of BillingClient

    private var isConsumable: Boolean =
        false // Flag if purchase need to consume so user can buy again

    // variable to track event time
    private var mLastClickTime: Long = 0
    private const val mMinDuration = 1000

    private val Int.getPurchaseState: String
        get() {
            return when (this) {
                Purchase.PurchaseState.UNSPECIFIED_STATE -> {
                    "UNSPECIFIED_STATE"
                }
                Purchase.PurchaseState.PURCHASED -> {
                    "PURCHASED"
                }
                Purchase.PurchaseState.PENDING -> {
                    "PENDING"
                }
                else -> {
                    "Unknown"
                }
            }
        }

    fun getProductInfo(id: String): ProductInfo? {
        return PRODUCT_LIST.find { it.id.equals(id, true) }
    }

    private fun setRenewalDate(id: String, renewalDate: Long) {
        for (i in PRODUCT_LIST.indices) {
            if (PRODUCT_LIST[i].id.equals(id, true)) {
                PRODUCT_LIST[i].renewalTime = renewalDate
            }
        }
        //return PRODUCT_LIST.find { it.id.equals(id, true) }
    }

    private val String.getPriceInDouble: Double
        get() {
            return if (this.isNotEmpty() && !(this.equals("Not Found", ignoreCase = false))) {
                this.replace("""[^0-9.]""".toRegex(), "").toDouble()
            } else {
                0.0
            }
        }

    fun setLifeTimeProductKey(vararg keys: String) {
        lifeTimeProductKeyList.removeAll(lifeTimeProductKeyList.toSet())
        lifeTimeProductKeyList.clear()
        lifeTimeProductKeyList.addAll(keys.filter { it.isNotEmpty() })
    }

    fun setSubscriptionKey(vararg keys: String) {
        subscriptionKeyList.removeAll(subscriptionKeyList.toSet())
        subscriptionKeyList.clear()
        subscriptionKeyList.addAll(keys.filter { it.isNotEmpty() })
    }

    fun initBillingClient(context: Context, purchaseListener: ProductPurchaseListener) {
        mPurchaseListener = purchaseListener

        mBillingClient = BillingClient.newBuilder(context)
            .enablePendingPurchases()
            .setListener { billingResult, purchases ->
                if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
                    return@setListener
                } else {
                    mLastClickTime = SystemClock.elapsedRealtime()
                    when (billingResult.responseCode) {
                        BillingClient.BillingResponseCode.OK -> {
                            if (purchases != null) {
                                for (purchase in purchases) {
                                    purchase?.let {
                                        handlePurchase(context, it)
                                    }
                                }
                            } else {
//                                logI(
//                                    tag = TAG,
//                                    message = "onPurchasesUpdated: =>> Response OK But Purchase List Null Found"
//                                )
                            }
                        }
                        else -> {
                            when (billingResult.responseCode) {
                                BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED,
                                BillingClient.BillingResponseCode.BILLING_UNAVAILABLE,
                                BillingClient.BillingResponseCode.USER_CANCELED -> {
                                    if (billingResult.responseCode == BillingClient.BillingResponseCode.USER_CANCELED) {
                                        Toast.makeText(
                                            context,
                                            "You've cancelled the Google play billing process",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                                else -> {
                                    Toast.makeText(
                                        context,
                                        "Item not found or Google play billing error",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                            logResponseCode(context = context, responseMsg = "onPurchasesUpdated: ", billingResult = billingResult)
                        }
                    }
                }
            }
            .build()

        mBillingClient?.startConnection(object : BillingClientStateListener {
            override fun onBillingServiceDisconnected() {
//                logI(tag = TAG, message = "onBillingServiceDisconnected: =>> DISCONNECTED")
            }

            override fun onBillingSetupFinished(billingResult: BillingResult) {
                logResponseCode(context = context, responseMsg = "onBillingSetupFinished: ", billingResult = billingResult)
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK
                    || billingResult.responseCode == BillingClient.BillingResponseCode.BILLING_UNAVAILABLE
                ) {
                    mPurchaseListener?.onBillingSetupFinished(billingResult)
                }
            }
        })
    }

    private fun getRenewalTime(purchaseTime: Long?, period: String): Long {

        val cal = Calendar.getInstance()
        cal.timeInMillis = purchaseTime!!
        if (!period.equals("Not Found", ignoreCase = true)) {
            var num = 1
            var prefix = "Month"
            if (period.contains(" ")) {
                num = period.substring(0, period.indexOf(" ")).trim { it <= ' ' }.toInt()
                prefix = period.substring(period.indexOf(" ")).trim { it <= ' ' }
            } else {
                num = 1
                prefix = period.trim { it <= ' ' }
            }

//            logI(tag = TAG, message = "getRenewalTime:period:${period}")
//            logI(tag = TAG, message = "getRenewalTime:prefix:${prefix}")
//            logI(tag = TAG, message = "getRenewalTime:num:${num}")

            if (prefix.equals("Day", ignoreCase = true)) {
                cal.add(Calendar.DAY_OF_MONTH, num)
            } else if (prefix.equals("Week", ignoreCase = true)) {
                cal.add(Calendar.WEEK_OF_MONTH, num)
            } else if (prefix.equals("Month", ignoreCase = true)) {
                cal.add(Calendar.MONTH, num)
            } else if (prefix.equals("Year", ignoreCase = true)) {
                cal.add(Calendar.YEAR, num)
            }
        }
        return cal.timeInMillis
    }

    fun initProductsKeys(context: Context, onInitializationComplete: () -> Unit) {
        CoroutineScope(Dispatchers.Main).launch {
            initProducts(
                context = context,
                onComplete = {
                    CoroutineScope(Dispatchers.Main).launch {
                        onInitializationComplete.invoke()
                    }
                }
            )
        }
    }

    fun initSubscriptionKeys(context: Context, onInitializationComplete: () -> Unit) {
        CoroutineScope(Dispatchers.Main).launch {
            initSubscription(
                context = context,
                onComplete = {
                    CoroutineScope(Dispatchers.Main).launch {
                        onInitializationComplete.invoke()
                    }
                }
            )
        }
    }

    private suspend fun initProducts(context: Context, onComplete: () -> Unit) {
        if (lifeTimeProductKeyList.isNotEmpty()) {
            val params = QueryProductDetailsParams.newBuilder()
                .setProductList(
                    lifeTimeProductKeyList.map { productId ->
                        QueryProductDetailsParams.Product.newBuilder()
                            .setProductId(productId)
                            .setProductType(BillingClient.ProductType.INAPP)
                            .build()
                    }
                )
                .build()

            initProductParams(
                context = context,
                methodName = "initProducts",
                params = params,
                productType = BillingClient.ProductType.INAPP,
                onComplete = onComplete
            )
        } else {
            onComplete.invoke()
        }
    }

    private suspend fun initSubscription(context: Context, onComplete: () -> Unit) {
        if (subscriptionKeyList.isNotEmpty()) {
            val historyParams = QueryPurchaseHistoryParams.newBuilder()
                .setProductType(BillingClient.ProductType.SUBS)
                .build()

            if (mBillingClient != null && mBillingClient?.isReady == true) {
                mBillingClient?.let { billingClient ->
                    val purchasesHistoryResult = billingClient.queryPurchaseHistory(historyParams)
                    if (purchasesHistoryResult.billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                        purchasesHistoryResult.purchaseHistoryRecordList?.let { listOfHistoryProducts ->
                            val idList =
                                listOfHistoryProducts.flatMap { it.products } as ArrayList<String>
                            initSubscription(
                                context = context,
                                historyList = idList,
                                onComplete = onComplete
                            )
                        } ?: initSubscription(
                            context = context,
                            historyList = ArrayList(),
                            onComplete = onComplete
                        )
                    } else {
                        initSubscription(
                            context = context,
                            historyList = ArrayList(),
                            onComplete = onComplete
                        )
                    }
                }
            } else {
//                logE(TAG, "initSubscription: =>> The billing client is not ready")
                onComplete.invoke()
            }
        } else {
            onComplete.invoke()
        }
    }

    private suspend fun initSubscription(
        context: Context,
        historyList: ArrayList<String>,
        onComplete: () -> Unit
    ) {
        if (subscriptionKeyList.isNotEmpty()) {
            val params = QueryProductDetailsParams.newBuilder()
                .setProductList(
                    subscriptionKeyList.map { productId ->
                        QueryProductDetailsParams.Product.newBuilder()
                            .setProductId(productId)
                            .setProductType(BillingClient.ProductType.SUBS)
                            .build()
                    }
                )
                .build()

            initProductParams(
                context = context,
                methodName = "initSubscription",
                params = params,
                productType = BillingClient.ProductType.SUBS,
                historyList = historyList,
                onComplete = onComplete
            )
        } else {
            onComplete.invoke()
        }
    }

    private suspend fun initProductParams(
        context: Context,
        methodName: String,
        @NotNull params: QueryProductDetailsParams,
        @NonNull productType: String,
        historyList: ArrayList<String> = ArrayList(),
        onComplete: () -> Unit
    ) {
//        logI(tag = TAG, message = "initProductParams: =>> 0001")
        if (mBillingClient != null && mBillingClient?.isReady == true) {
            mBillingClient?.let { billingClient ->
                val productDetails = billingClient.queryProductDetails(params = params)

//                logI(
//                    tag = TAG,
//                    message = "initProductParams: =>> responseCode -> ${productDetails.billingResult.responseCode}"
//                )
                if (productDetails.billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    productDetails.productDetailsList?.let { listOfProducts ->
                        for (productDetail in listOfProducts) {
                            val productID = productDetail.productId

                            val formattedPrice = when (productType) {
                                BillingClient.ProductType.INAPP -> {
                                    productDetail.oneTimePurchaseOfferDetails?.formattedPrice
                                        ?: "Not Found"
                                }
                                BillingClient.ProductType.SUBS -> {
                                    val pricingList =
                                        productDetail.subscriptionOfferDetails?.get(0)?.pricingPhases?.pricingPhaseList?.filter {
                                            !it.formattedPrice.equals(
                                                "Free",
                                                ignoreCase = true
                                            )
                                        }
                                    if (pricingList?.isNotEmpty() == true) {
                                        pricingList[0]?.formattedPrice ?: "Not Found"
                                    } else {
                                        "Not Found"
                                    }
                                }
                                else -> {
                                    "Not Found"
                                }
                            }

                            val priceAmountMicros = when (productType) {
                                BillingClient.ProductType.INAPP -> {
                                    productDetail.oneTimePurchaseOfferDetails?.priceAmountMicros
                                        ?: 0
                                }
                                BillingClient.ProductType.SUBS -> {
                                    val pricingList =
                                        productDetail.subscriptionOfferDetails?.get(0)?.pricingPhases?.pricingPhaseList?.filter {
                                            !it.formattedPrice.equals(
                                                "Free",
                                                ignoreCase = true
                                            )
                                        }
                                    if (pricingList?.isNotEmpty() == true) {
                                        pricingList[0]?.priceAmountMicros ?: 0
                                    } else {
                                        0
                                    }
                                }
                                else -> {
                                    0
                                }
                            }

                            val priceCurrencyCode = when (productType) {
                                BillingClient.ProductType.INAPP -> {
                                    productDetail.oneTimePurchaseOfferDetails?.priceCurrencyCode
                                        ?: "Not Found"
                                }
                                BillingClient.ProductType.SUBS -> {
                                    val pricingList =
                                        productDetail.subscriptionOfferDetails?.get(0)?.pricingPhases?.pricingPhaseList?.filter {
                                            !it.formattedPrice.equals(
                                                "Free",
                                                ignoreCase = true
                                            )
                                        }
                                    if (pricingList?.isNotEmpty() == true) {
                                        pricingList[0]?.priceCurrencyCode ?: "Not Found"
                                    } else {
                                        "Not Found"
                                    }
                                }
                                else -> {
                                    "Not Found"
                                }
                            }

                            val billingPeriod = when (productType) {
                                BillingClient.ProductType.INAPP -> {
                                    "One Time Purchase"
                                }
                                BillingClient.ProductType.SUBS -> {
                                    val pricingList =
                                        productDetail.subscriptionOfferDetails?.get(0)?.pricingPhases?.pricingPhaseList?.filter {
                                            !it.formattedPrice.equals(
                                                "Free",
                                                ignoreCase = true
                                            )
                                        }
                                    if (pricingList?.isNotEmpty() == true) {
                                        pricingList[0]?.billingPeriod?.getFullBillingPeriod()
                                            ?: "Not Found"
                                    } else {
                                        "Not Found"
                                    }
                                }
                                else -> {
                                    "Not Found"
                                }
                            }

                            val freeTrialPeriod = when (productType) {
                                BillingClient.ProductType.INAPP -> {
                                    "Not Found"
                                }
                                BillingClient.ProductType.SUBS -> {
                                    val index = if (historyList.contains(productID)) {
                                        (productDetail.subscriptionOfferDetails?.size ?: 1) - 1
                                    } else {
                                        0
                                    }
                                    val pricingList =
                                        productDetail.subscriptionOfferDetails?.get(index)?.pricingPhases?.pricingPhaseList?.filter {
                                            it.formattedPrice.equals(
                                                "Free",
                                                ignoreCase = true
                                            )
                                        }
                                    if (pricingList?.isNotEmpty() == true) {
                                        pricingList[0]?.billingPeriod?.getFullBillingPeriod()
                                            ?: "Not Found"
                                    } else {
                                        "Not Found"
                                    }
                                }
                                else -> {
                                    "Not Found"
                                }
                            }

//                            logI(
//                                tag = TAG,
//                                message = "initProductParams: =>> ++++++++++++++++++++++++++++++++++"
//                            )
//                            logI(
//                                tag = TAG,
//                                message = "initProductParams: =>> productID -> $productID"
//                            )
//                            logI(
//                                tag = TAG,
//                                message = "initProductParams: =>> formattedPrice -> $formattedPrice"
//                            )
//                            logI(
//                                tag = TAG,
//                                message = "initProductParams: =>> priceAmountMicros -> $priceAmountMicros"
//                            )
//                            logI(
//                                tag = TAG,
//                                message = "initProductParams: =>> priceCurrencyCode -> $priceCurrencyCode"
//                            )
//                            logI(
//                                tag = TAG,
//                                message = "initProductParams: =>> billingPeriod -> $billingPeriod"
//                            )
//                            logI(
//                                tag = TAG,
//                                message = "initProductParams: =>> freeTrialPeriod -> $freeTrialPeriod"
//                            )
//                            logI(
//                                tag = TAG,
//                                message = "initProductParams: =>> productDetail -> $productDetail"
//                            )
                            PRODUCT_LIST.add(
                                ProductInfo(
                                    id = productID,
                                    formattedPrice = formattedPrice,
                                    priceAmountMicros = priceAmountMicros,
                                    priceCurrencyCode = priceCurrencyCode,
                                    billingPeriod = billingPeriod,
//                                    freeTrialPeriod = "Not Found",
                                    freeTrialPeriod = freeTrialPeriod,
                                    renewalTime = 0,
                                    productDetail = productDetail
                                )
                            )

                            logProductDetail(
                                fMethodName = methodName,
                                fProductDetail = productDetail
                            )
                        }
                    }
                } else {
                    logResponseCode(context = context, responseMsg = "$methodName: ", billingResult = productDetails.billingResult)
                }

                billingClient.queryPurchasesAsync(
                    QueryPurchasesParams.newBuilder()
                        .setProductType(productType)
                        .build()
                ) { billingResult, purchaseList ->
                    when (billingResult.responseCode) {
                        BillingClient.BillingResponseCode.OK,
                        BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> {
                            if (purchaseList.isNotEmpty()) {
                                onPurchased(context, productType, purchaseList)
                            } else {
                                onExpired(context, productType)
//                                logI(
//                                    tag = TAG,
//                                    message = "$methodName: =>> Purchases History Not Found"
//                                )
                            }
                        }
                        else -> {
                            onExpired(context, productType)
                            logResponseCode(context = context, responseMsg = "$methodName: ", billingResult = billingResult)
                        }
                    }
                    onComplete.invoke()
                }
            }
        } else {
//            logE(tag = TAG, message = "$methodName: =>> The billing client is not ready")
            onComplete.invoke()
        }
    }

    private fun onPurchased(
        context: Context,
        @NonNull productType: String,
        purchaseList: MutableList<Purchase>?
    ) {
//        logI(tag = TAG, message = "onPurchased: Purchase Success")
//        logI(tag = TAG, message = "productType: =>> $productType")
//        logI(tag = TAG, message = "purchaseList: =>> " + purchaseList!!.size)
        if (purchaseList != null) {
            for (purchase in purchaseList) {
    //            logI(tag = TAG, message = "getPackageName: =>> " + purchase.packageName)
    //            logI(tag = TAG, message = "getPurchaseToken: =>> " + purchase.purchaseToken)
    //            logI(tag = TAG, message = "getOriginalJson: =>> " + purchase.originalJson)
    //            logI(tag = TAG, message = "getPurchaseTime: =>> " + purchase.purchaseTime)
                val purchaseDate =
                    SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(purchase.purchaseTime)
                PreferenceManager(context).addStringPreference("purchase_date", purchaseDate)
    //            logI(tag = TAG, message = "getPurchaseDate: =>> $purchaseDate")
                for (ids in purchase.products) {
    //                logI(tag = TAG, message = "ids: =>> $ids")
                    val renewalTime = getRenewalTime(
                        purchase.purchaseTime,
                        getProductInfo(ids)!!.billingPeriod.trim()
                    )
                    setRenewalDate(ids, renewalTime)
                    //val renewalDate = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(renewalTime)
                    //logI(tag = TAG, message = "renewalDate: =>> $renewalDate")
                }
            }
        }

//        PreferenceManager(context).addBooleanPreference("is_remove_ads", true)
        AdsManager(context).onProductPurchased()
        if (productType == BillingClient.ProductType.INAPP) {
            mPurchaseListener?.onPurchasedFound(productType, purchaseList)
        } else if (productType == BillingClient.ProductType.SUBS) {
            mPurchaseListener?.onPurchasedFound(productType, purchaseList)
        }
    }

    private fun onExpired(context: Context, @NonNull productType: String) {
//        logI(tag = TAG, message = "onExpired: Purchase Expired")
        if (productType == BillingClient.ProductType.INAPP) {
            AdsManager(context).onProductExpired()
//            PreferenceManager(context).addBooleanPreference("is_remove_ads", false)
        } else if (productType == BillingClient.ProductType.SUBS) {
//            AdsManager(context).onSubscribeExpired()
            AdsManager(context).onSubscribeExpired()
//            PreferenceManager(context).addBooleanPreference("is_remove_ads", false)
        }
    }

    private fun handlePurchase(context: Context, purchase: Purchase) {
//        PreferenceManager.saveData(context, FirebaseConfig_var.is_remove_ads, true)
        AdsManager(context).onProductPurchased()
        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
            for (product in purchase.products) {
                if (lifeTimeProductKeyList.contains(product)) {
//                    logI(tag = TAG, message = "handlePurchase: =>> productId -> $product")
//                    PreferenceManager.saveData(
//                        context,
//                        PreferenceKeys.inAppSubscriptionenabled,
//                        purchase.isAutoRenewing
//                    )
                    AdsManager(context).onProductPurchased()
//                    PreferenceManager.saveData(context, FirebaseConfig_var.is_remove_ads, true)
//                    PreferenceManager.saveData(context, FirebaseConfig_var.purchased_sku, product)
                } else if (subscriptionKeyList.contains(product)) {
//                    logI(tag = TAG, message = "handlePurchase: =>> productId -> $product")
//                    PreferenceManager.saveData(
//                        context,
//                        PreferenceKeys.inAppSubscriptionenabled,
//                        purchase.isAutoRenewing
//                    )
                    AdsManager(context).onProductSubscribed()
//                    PreferenceManager.saveData(context, FirebaseConfig_var.is_remove_ads, true)
//                    PreferenceManager.saveData(context, FirebaseConfig_var.purchased_sku, product)
                }
            }

            mPurchaseListener?.onPurchasedSuccess(purchase = purchase)
        }

        CoroutineScope(Dispatchers.IO).launch {
            acknowledgePurchase(context = context, purchase = purchase)
            if (isConsumable) {
                consumePurchase(context = context, purchase = purchase)
            }
        }
    }

    private suspend fun acknowledgePurchase(context: Context, purchase: Purchase) {
        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED && !purchase.isAcknowledged) {
            val acknowledgePurchaseParams =
                AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.purchaseToken)
            val ackPurchaseResult = withContext(Dispatchers.IO) {
                mBillingClient?.acknowledgePurchase(acknowledgePurchaseParams.build())
            }
            if (ackPurchaseResult != null) {
                logResponseCode(context = context, responseMsg = "acknowledgePurchase: ", billingResult = ackPurchaseResult)
            } else {
//                logE(tag = TAG, message = "acknowledgePurchase: =>> Not Found Any Purchase Result")
            }
        }

        logPurchaseItem(context = context, purchase = purchase)
    }

    private suspend fun consumePurchase(context: Context, purchase: Purchase) {
        val consumeParams =
            ConsumeParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build()
        mBillingClient?.let {
            val consumeResult = it.consumePurchase(consumeParams)
            logResponseCode(context = context, responseMsg = "consumePurchase: ", billingResult = consumeResult.billingResult)
        }
    }

    fun purchaseProduct(
        activity: Activity,
        @NotNull productId: String,
        fIsConsumable: Boolean = false
    ) {
        isConsumable = fIsConsumable
        CoroutineScope(Dispatchers.Main).launch {
            purchaseSelectedProduct(
                methodName = "purchaseProduct",
                activity = activity,
                productId = productId,
                productKeyList = lifeTimeProductKeyList,
                productType = BillingClient.ProductType.INAPP
            )
        }
    }

    fun subscribeProduct(
        activity: Activity,
        @NotNull productId: String,
        fIsConsumable: Boolean = false
    ) {
        isConsumable = fIsConsumable
        CoroutineScope(Dispatchers.Main).launch {
            purchaseSelectedProduct(
                methodName = "subscribeProduct",
                activity = activity,
                productId = productId,
                productKeyList = subscriptionKeyList,
                productType = BillingClient.ProductType.SUBS
            )
        }
    }

    private suspend fun purchaseSelectedProduct(
        methodName: String,
        activity: Activity,
        @NotNull productId: String,
        @NotNull productKeyList: ArrayList<String>,
        @NonNull productType: String
    ) {
        if (mBillingClient != null && mBillingClient?.isReady == true) {
            mBillingClient?.let { billingClient ->
                val params = QueryProductDetailsParams.newBuilder()
                    .setProductList(
                        productKeyList.map { keyId ->
                            QueryProductDetailsParams.Product.newBuilder()
                                .setProductId(keyId)
                                .setProductType(productType)
                                .build()
                        }
                    )
                    .build()

                val productDetailsResult = withContext(Dispatchers.IO) {
                    billingClient.queryProductDetails(params)
                }

                val productDetail = getProductDetails(
                    productId = productId,
                    productDetailsList = productDetailsResult.productDetailsList
                )

                if (productDetail != null) {

                    val offerToken = if (productType == BillingClient.ProductType.SUBS) {
                        productDetail.subscriptionOfferDetails?.get(0)?.offerToken
                    } else {
                        null
                    }

                    if (offerToken == null && productType == BillingClient.ProductType.SUBS) {
                        return
                    }

                    val lBuilder: BillingFlowParams.ProductDetailsParams.Builder =
                        BillingFlowParams.ProductDetailsParams.newBuilder()
                    lBuilder.apply {
                        setProductDetails(productDetail)
                        offerToken?.let {
                            setOfferToken(it)
                        }
                    }

                    val billingFlowParams = BillingFlowParams.newBuilder()
                        .setProductDetailsParamsList(mutableListOf(lBuilder.build()))
                        .build()


                    val billingResult = billingClient.launchBillingFlow(activity, billingFlowParams)

                    when (billingResult.responseCode) {
                        BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> {
//                            logE(tag = TAG, message = "$methodName: =>> ITEM_ALREADY_OWNED")

                            onPurchased(context = activity, productType = productType, null)
//                            PreferenceManager.saveData(
//                                activity,
//                                FirebaseConfig_var.is_remove_ads,
//                                true
//                            )
                            AdsManager(activity).onProductPurchased()
                            mPurchaseListener?.onPurchasedFound(productType, null)
                            logProductDetail(
                                fMethodName = methodName,
                                fProductDetail = productDetail
                            )
                        }
                        BillingClient.BillingResponseCode.OK -> {
//                            logE(tag = TAG, message = "$methodName: =>> Purchase in Progress")
                        }
                        else -> {
                            logResponseCode(context = activity, responseMsg = methodName, billingResult = billingResult)
                        }
                    }

                } else {
                    CoroutineScope(Dispatchers.Main).launch {
                        mPurchaseListener?.onBillingKeyNotFound(productId)
                    }
//                    logE(
//                        tag = TAG,
//                        message = "$methodName: =>> Product Detail not found for product id:: $productId"
//                    )
                }
            }
        } else {
            CoroutineScope(Dispatchers.Main).launch {
                Toast.makeText(activity, "The Billing Client Is Not Ready", Toast.LENGTH_SHORT)
                    .show()
            }
//            logE(tag = TAG, message = "$methodName: =>> The billing client is not ready")
        }
    }

    private fun getProductDetails(
        @NotNull productId: String,
        productDetailsList: List<ProductDetails>?
    ): ProductDetails? {
        return productDetailsList?.find { it.productId.equals(productId, true) }
    }

    private fun String.getFullBillingPeriod(): String {
        var billingPeriod = ""
        try {
            val size = this.length
            var period = this.substring(1, size - 1)
            if (period.equals("1", true)) period = ""
            billingPeriod = when (this.substring(size - 1, size)) {
                "D", "d" -> "$period Day"
                "W", "w" -> "$period Week"
                "M", "m" -> "$period Month"
                "Y", "y" -> "$period Year"
                else -> "Not Found"
            }
            if (period.isNotEmpty() && period != "Not Found") billingPeriod = "${billingPeriod}s"
        } catch (e: Exception) {
            billingPeriod = "Not Found"
        }
        return billingPeriod
    }

    fun getWeekBaseYearlyDiscount(
        weekPrice: String,
        yearPrice: String,
        onDiscountCalculated: (yearlyDiscountPercentage: Double, yearlyWeekBaseDiscountPrice: String) -> Unit
    ) {
        weekPrice.getPriceInDouble.let { lWeekNumber ->
            yearPrice.getPriceInDouble.let { lYearNumber ->
                val lWeekPrize: Double = (lWeekNumber * 52) - lYearNumber
                val lYearPrizeBaseOfWeek = (lWeekNumber * 52)
                var lDiscountPercentage: Double = (lWeekPrize / lYearPrizeBaseOfWeek) * 100

                lDiscountPercentage *= 100
                lDiscountPercentage = lDiscountPercentage.toInt().toDouble()
                lDiscountPercentage /= 100

                val lDiscountPrice = weekPrice.replace(
                    String.format("%.2f", lWeekNumber),
                    String.format("%.2f", (lYearNumber / 52)),
                    false
                )

                onDiscountCalculated.invoke(lDiscountPercentage, lDiscountPrice)
            }
        }
    }

    fun getWeekBaseMonthlyDiscount(
        weekPrice: String,
        monthPrice: String,
        onDiscountCalculated: (monthlyDiscountPercentage: Double, monthlyWeekBaseDiscountPrice: String) -> Unit
    ) {
        weekPrice.getPriceInDouble.let { lWeekNumber ->
            monthPrice.getPriceInDouble.let { lMonthNumber ->
                val lWeekPrize: Double = (lWeekNumber * 4) - lMonthNumber
                val lMonthPrizeBaseOfWeek = (lWeekNumber * 4)
                var lDiscountPercentage: Double = (lWeekPrize / lMonthPrizeBaseOfWeek) * 100

                lDiscountPercentage *= 100
                lDiscountPercentage = lDiscountPercentage.toInt().toDouble()
                lDiscountPercentage /= 100

                val lDiscountPrice = weekPrice.replace(
                    String.format("%.2f", lWeekNumber),
                    String.format("%.2f", (lMonthNumber / 4)),
                    false
                )

                onDiscountCalculated.invoke(lDiscountPercentage, lDiscountPrice)
            }
        }
    }

    fun getMonthBaseYearlyDiscount(
        monthPrice: String,
        yearPrice: String,
        onDiscountCalculated: (yearlyDiscountPercentage: Double, yearlyMonthBaseDiscountPrice: String) -> Unit
    ) {
        monthPrice.getPriceInDouble.let { lMonthNumber ->
            yearPrice.getPriceInDouble.let { lYearNumber ->
                val lMonthPrize: Double = (lMonthNumber * 12) - lYearNumber
                val lYearPrizeBaseOfMonth = (lMonthNumber * 12)
                var lDiscountPercentage: Double = (lMonthPrize / lYearPrizeBaseOfMonth) * 100

                lDiscountPercentage *= 100
                lDiscountPercentage = lDiscountPercentage.toInt().toDouble()
                lDiscountPercentage /= 100

                val lDiscountPrice = monthPrice.replace(
                    String.format("%.2f", lMonthNumber),
                    String.format("%.2f", (lYearNumber / 12)),
                    false
                )

                onDiscountCalculated.invoke(lDiscountPercentage, lDiscountPrice)
            }
        }
    }

    internal fun logResponseCode(
        context: Context,
        responseMsg: String,
        @NotNull billingResult: BillingResult
    ) {
        val errorCode = when (billingResult.responseCode) {
            BillingClient.BillingResponseCode.OK -> "RESULT OK"
            BillingClient.BillingResponseCode.ERROR -> "ERROR"
            BillingClient.BillingResponseCode.BILLING_UNAVAILABLE -> "BILLING_UNAVAILABLE"
            BillingClient.BillingResponseCode.DEVELOPER_ERROR -> "DEVELOPER_ERROR"
            BillingClient.BillingResponseCode.FEATURE_NOT_SUPPORTED -> "FEATURE_NOT_SUPPORTED"
            BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> "ITEM_ALREADY_OWNED"
            BillingClient.BillingResponseCode.ITEM_NOT_OWNED -> "ITEM_NOT_OWNED"
            BillingClient.BillingResponseCode.ITEM_UNAVAILABLE -> "ITEM_UNAVAILABLE"
            BillingClient.BillingResponseCode.SERVICE_DISCONNECTED -> "SERVICE_DISCONNECTED"
            BillingClient.BillingResponseCode.SERVICE_TIMEOUT -> "SERVICE_TIMEOUT"
            BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE -> "SERVICE_UNAVAILABLE"
            BillingClient.BillingResponseCode.USER_CANCELED -> "USER_CANCELED"
            else -> "unDefined Error"
        }
//        if (billingResult.responseCode != BillingClient.BillingResponseCode.OK)
//            Utils.addEvent(context, "${errorCode}", "failed", "subscription")

//        logE(
//            tag = TAG,
//            message = "$responseMsg :: \nerrorCode::$errorCode,\nMessage::${billingResult.debugMessage}"
//        )
    }

    private fun logPurchaseItem(context: Context, purchase: Purchase) {
        with(purchase) {
//            logW(
//                tag = TAG,
//                message = "<<<-----------------   Purchase Details   ----------------->>>"
//            )
//            logW(tag = TAG, message = "Order Id: $orderId")
//            logW(tag = TAG, message = "Original Json: $originalJson")
//            logW(tag = TAG, message = "Package Name: $packageName")
//            logW(tag = TAG, message = "Purchase Token: $purchaseToken")
//            logW(tag = TAG, message = "Signature: $signature")
//            products.forEach {
//                logW(tag = TAG, message = "Products: $it")
//                logW(tag = TAG, message = "Price: ${getProductInfo(it)?.formattedPrice}")
//            }
//            logW(tag = TAG, message = "Purchase State: ${purchaseState.getPurchaseState}")
//            logW(tag = TAG, message = "Quantity: $quantity")

//            val purchaseDate = SimpleDateFormat("dd-MM-yyyy hh:mm:ss", Locale.getDefault()).format(purchaseTime)
            val purchaseDate =
                SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(purchase.purchaseTime)
//            PreferenceManager.saveData(context, "purchase_date", purchaseDate)
//            logW(tag = TAG, message = "Purchase Time: $purchaseTime")
//            logW(tag = TAG, message = "Purchase Time Formatted: $purchaseDate")
//            logW(tag = TAG, message = "Acknowledged: $isAcknowledged")
//            logW(tag = TAG, message = "AutoRenewing: $isAutoRenewing")
//            logW(
//                tag = TAG,
//                message = "<<<-----------------   End of Purchase Details   ----------------->>>"
//            )
        }
    }

    private fun logProductDetail(fMethodName: String, @NotNull fProductDetail: ProductDetails) {
        with(fProductDetail) {
//            logW(tag = TAG, message = "\n")
//            logW(
//                tag = TAG,
//                message = "$fMethodName: <<<-----------------   \"$productId\" Product Details   ----------------->>>"
//            )
//            logW(tag = TAG, message = "$fMethodName: Product Id:: $productId")
//            logW(tag = TAG, message = "$fMethodName: Name:: $name")
//            logW(tag = TAG, message = "$fMethodName: Title:: $title")
//            logW(tag = TAG, message = "$fMethodName: Description:: $description")
//            logW(tag = TAG, message = "$fMethodName: Product Type:: $productType")
            oneTimePurchaseOfferDetails?.let { details ->
                with(details) {
//                    logW(tag = TAG, message = "\n")
//                    logW(
//                        tag = TAG,
//                        message = "$fMethodName: <<<-----------------   Life-Time Purchase Product Price Details   ----------------->>>"
//                    )
//                    logW(
//                        tag = TAG,
//                        message = "$fMethodName: Price Amount Micros:: $priceAmountMicros"
//                    )
//                    logW(tag = TAG, message = "$fMethodName: Formatted Price:: $formattedPrice")
//                    logW(
//                        tag = TAG,
//                        message = "$fMethodName: Price Currency Code:: $priceCurrencyCode"
//                    )
//                    logW(
//                        tag = TAG,
//                        message = "$fMethodName: <<<-----------------   End of Life-Time Purchase Product Price Details   ----------------->>>"
//                    )
                }
            }
            subscriptionOfferDetails?.let { details ->
                if (details.isNotEmpty()) {
                    details.forEachIndexed { index, subscriptionOfferDetails ->
                        subscriptionOfferDetails?.let { offerDetails ->
                            with(offerDetails) {
//                                logW(tag = "", message = "\n")
//                                logW(
//                                    tag = TAG,
//                                    message = "$fMethodName: <<<-----------------   Product Offer Details of Index:: $index   ----------------->>>"
//                                )
//                                logW(tag = TAG, message = "$fMethodName: Offer Token:: $offerToken")
//                                logW(tag = TAG, message = "$fMethodName: Offer Tags:: $offerTags")
//                                logW(
//                                    tag = TAG,
//                                    message = "$fMethodName: Installment Plan Details:: $installmentPlanDetails"
//                                )

                                if (pricingPhases.pricingPhaseList.isNotEmpty()) {
                                    pricingPhases.pricingPhaseList.forEachIndexed { index, pricingPhase1 ->
                                        pricingPhase1?.let { pricingPhase ->
                                            with(pricingPhase) {
//                                                logW(tag = "", message = "\n")
//                                                logW(
//                                                    tag = TAG,
//                                                    message = "$fMethodName: <<<-----------------   Product Offer Price Details of Index:: $index   ----------------->>>"
//                                                )
//                                                logW(
//                                                    tag = TAG,
//                                                    message = "$fMethodName: Billing Period:: $billingPeriod"
//                                                )
//                                                logW(
//                                                    tag = TAG,
//                                                    message = "$fMethodName: Formatted Price:: $formattedPrice"
//                                                )
//                                                logW(
//                                                    tag = TAG,
//                                                    message = "$fMethodName: Price Amount Micros:: $priceAmountMicros"
//                                                )
//                                                logW(
//                                                    tag = TAG,
//                                                    message = "$fMethodName: Price Currency Code:: $priceCurrencyCode"
//                                                )
//                                                logW(
//                                                    tag = TAG,
//                                                    message = "$fMethodName: Recurrence Mode:: $recurrenceMode"
//                                                )
//                                                logW(
//                                                    tag = TAG,
//                                                    message = "$fMethodName: Billing Cycle Count:: $billingCycleCount"
//                                                )
//                                                logW(
//                                                    tag = TAG,
//                                                    message = "$fMethodName: <<<-----------------   End of Product Offer Price Details of Index:: $index   ----------------->>>"
//                                                )
                                            }
                                        }
                                    }
                                }

//                                logW(
//                                    tag = TAG,
//                                    message = "$fMethodName: <<<-----------------   End of Product Offer Details of Index:: $index   ----------------->>>"
//                                )
                            }
                        }
                    }
                }
            }
//            logW(
//                tag = TAG,
//                message = "$fMethodName: <<<-----------------   End of \"$productId\" Product Details   ----------------->>>"
//            )
        }
    }

    interface ProductPurchaseListener {
        fun onPurchasedSuccess(purchase: Purchase)
        fun onPurchasedFound(productType: String, purchaseList: MutableList<Purchase>?)
        fun onBillingSetupFinished(billingResult: BillingResult)
        fun onBillingKeyNotFound(productId: String)
    }
}