package com.bankbalanceinquiry.ministatement.currencies.widget.searchablespinner

import java.io.Serializable

interface OnSearchableItemClick<T> : Serializable {
    fun onSearchableItemClicked(item: T?, position: Int)
}
