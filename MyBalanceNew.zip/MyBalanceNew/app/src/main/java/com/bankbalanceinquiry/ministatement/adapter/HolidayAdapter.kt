package com.bankbalanceinquiry.ministatement.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bankbalanceinquiry.ministatement.R
import com.bankbalanceinquiry.ministatement.model.StateModel

class HolidayAdapter(var mContext: Context, var mStateList: ArrayList<StateModel>) : RecyclerView.Adapter<HolidayAdapter.HolidayViewHolder>() {
    class HolidayViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var mTVDate: TextView = view.findViewById(R.id.mTVDate)
        var mTVDay: TextView = view.findViewById(R.id.mTVDay)
        var mTVHoliday: TextView = view.findViewById(R.id.mTVHoliday)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolidayViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.single_holiday, parent, false)
        return HolidayViewHolder(view)
    }

    override fun getItemCount(): Int {
        Log.d("2222", "getItemCount: ${mStateList.size}")
            return mStateList.size
        }

    override fun onBindViewHolder(holder: HolidayViewHolder, position: Int) {
        val mList = mStateList[position]
        Log.d("TAG11", "onBindViewHolder: "+mStateList.size)

        val date = (mList.mDate).substringAfter(" ")
        Log.d("date", "onBindViewHolder: $date")
        holder.mTVDate.text = "-"
        holder.mTVDay.text = date+" "+(mList.mDate).substring(0,3)+", "+(mList.mDay).substring(0,3)+", "+" 2021"
        holder.mTVHoliday.text = mList.mHoliday
    }
}