package com.bankbalanceinquiry.ministatement.model

data class UpdateModel(
    val isNeedToShow: Boolean = false,
    val isCancelable: Boolean = false,
    val cancelCounter: Int = 0,
    val latestVersion: String = "",
    val updateDescription: String = "",
    val updateFeatures: String = "",
    val displayFromVersion: Int = 0,
)