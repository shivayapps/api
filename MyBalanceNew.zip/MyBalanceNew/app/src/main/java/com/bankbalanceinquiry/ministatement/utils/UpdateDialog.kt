package com.bankbalanceinquiry.ministatement.utils

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Window
import android.view.WindowManager
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.adconfig.AdsConfig
import com.bankbalanceinquiry.ministatement.R
import com.bankbalanceinquiry.ministatement.databinding.DialogUpdateBinding
import com.bankbalanceinquiry.ministatement.model.UpdateModel

class UpdateDialog(
    var activity: Activity,
    val forceUpdateModel: UpdateModel
) : Dialog(activity) {

    lateinit var bindingDialog: DialogUpdateBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
        //window?.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.navigationBarColor = ContextCompat.getColor(activity, R.color.white)
        window?.setGravity(Gravity.BOTTOM)

        bindingDialog = DialogUpdateBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT
        )
        setCancelable(forceUpdateModel.isCancelable)
        AdsConfig.isSystemDialogOpen = true
        intView()

    }

    private fun intView() {
        intListener()

        val inflater = LayoutInflater.from(activity)
        bindingDialog.txtVersion.text = forceUpdateModel.latestVersion
        bindingDialog.txtMsg.text = forceUpdateModel.updateDescription

        val points = forceUpdateModel.updateFeatures.split(",")
        for (feature in points) {
            val itemView = inflater.inflate(R.layout.item_text, null)
            val txtPoint: TextView = itemView.findViewById(R.id.txtPoint)
            txtPoint.text = feature.trim()
            bindingDialog.llPoints.addView(itemView)
        }
    }

    private fun launchAppStore() {
        AdsConfig.isSystemDialogOpen = true
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${activity.packageName}")
        )
        activity.startActivity(intent)
    }

    private fun intListener() {
        bindingDialog.btnOK.setOnClickListener {
            launchAppStore()
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}