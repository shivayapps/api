package com.bankbalanceinquiry.ministatement.activity.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.adapter.BillsAndEmilAdapter2;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.model.AvilabeBalanceModel;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;


public class BillsFragment extends Fragment {

    private RecyclerView rvAccountList;
    private ProgressBar pbLoading;
    private ArrayList<AvilabeBalanceModel> avilabeBalanceModels;
    private ArrayList<HomeAccoutList> bilsEmiModels;
    private DBHelperAccountNew mydbBill;
    private BillsAndEmilAdapter2 billsAndEmilAdapter;

    private LinearLayout llEmpty;
    private TextView tvEmptyMessage;
    private ImageView ivEmptyImage;

    private String mKey = "";

    public BillsFragment() {
        this.mKey = "loan";

    }

    public BillsFragment(String mKey) {
        this.mKey = mKey;
    }

    @Override
    public void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragments_bill, container, false);
        EventBus.getDefault().register(this);
        mydbBill = new DBHelperAccountNew(getActivity());
        InitComponent(root);
        return root;
    }


    @Subscribe
    public void OnSmsProgress(final Intent intent) {
        if (intent != null) {
            if (intent.getAction() == "CHECK_FOR_UPDATE") {
                String billType = intent.getStringExtra("billType");
                if (mKey.equals(billType)) {
                    Intent ii = new Intent().setAction("UPDATEVIEW");
                    ii.putExtra("billType", mKey);
                    ii.putExtra("itemCount", bilsEmiModels.size());
                    EventBus.getDefault().post(ii);
                }

            }
        }
    }


    private void InitComponent(View root) {

        rvAccountList = root.findViewById(R.id.rvAccountList);
        pbLoading = root.findViewById(R.id.pbLoading);
        CommonFun.RecyclerViewLinearLayout(getActivity(), rvAccountList);
        pbLoading.setVisibility(View.VISIBLE);

        llEmpty = root.findViewById(R.id.llEmpty);
        tvEmptyMessage = root.findViewById(R.id.tvEmptyMessage);
        ivEmptyImage = root.findViewById(R.id.ivEmptyImage);
        tvEmptyMessage.setText(getEmptyMessage());

        avilabeBalanceModels = new ArrayList<>();

        pbLoading.setVisibility(View.GONE);

        CheckDataNotifyOrNot();

    }

    private void CheckDataNotifyOrNot() {
        CommonFun.isIncommingSmsNotify = "";
        bilsEmiModels = new ArrayList<>();
        new Thread(new Runnable() {
            @Override
            public void run() {
                bilsEmiModels.addAll(mydbBill.GetSpecificBills(mKey));
                CallBillsAdapterSet();
            }
        }
        ).start();
    }

    private void CallBillsAdapterSet() {
        Log.e("bilsEmiModels", bilsEmiModels.size() + "");
        if (bilsEmiModels.size() > 0) {
            if (getActivity() != null && !getActivity().isFinishing()) {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        rvAccountList.setVisibility(View.VISIBLE);
                        llEmpty.setVisibility(View.GONE);
                    }
                });
            }
            SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd MMM yyyy", Locale.US);
            SimpleDateFormat monthFormate = new SimpleDateFormat("M", Locale.US);
            SimpleDateFormat monthFormate1 = new SimpleDateFormat("MMM", Locale.US);
            SimpleDateFormat dateFormate = new SimpleDateFormat("dd", Locale.US);
            SimpleDateFormat yearFormate = new SimpleDateFormat("yyyy", Locale.US);
            for (HomeAccoutList bilsEmiModel : bilsEmiModels) {
                Calendar cc = Calendar.getInstance();
                try {
                    Date date3 = simpleDateFormat1.parse(bilsEmiModel.dateValAccount);
                    if (date3 != null) {
                        String mMonth = monthFormate.format(date3);
                        String mMonthString = monthFormate1.format(date3);
                        String mDate = dateFormate.format(date3);
                        String mYear = yearFormate.format(date3);
                        cc.set(Integer.parseInt(mYear), Integer.parseInt(mMonth), Integer.parseInt(mDate));
                        bilsEmiModel.dateLongValue = cc.getTimeInMillis();
                        bilsEmiModel.dateValue = Integer.parseInt(mDate);
                        bilsEmiModel.monthValue = Integer.parseInt(mMonth);
                        bilsEmiModel.monthValueString = mMonthString;
                        bilsEmiModel.yearValue = Integer.parseInt(mYear);
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
            Collections.sort(bilsEmiModels, new Comparator<HomeAccoutList>() {
                @Override
                public int compare(HomeAccoutList t1, HomeAccoutList t2) {
                    return Long.valueOf(t2.dateLongValue).compareTo(Long.valueOf(t1.dateLongValue));
                }
            });
            ArrayList<Object> bilsEmiModels1 = new ArrayList<>();

            String last_monthYear = "";
            for (HomeAccoutList bilsEmiModel : bilsEmiModels) {
                String date_month = bilsEmiModel.monthValueString + " " + bilsEmiModel.yearValue;
                if (TextUtils.isEmpty(last_monthYear)) {
                    bilsEmiModels1.add(date_month);
                    last_monthYear = date_month;
                } else {
                    if (!date_month.equalsIgnoreCase(last_monthYear)) {
                        bilsEmiModels1.add(date_month);
                        last_monthYear = date_month;
                    }
                }
                bilsEmiModels1.add(bilsEmiModel);
            }
            if (getActivity() != null && !getActivity().isFinishing()) {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        billsAndEmilAdapter = new BillsAndEmilAdapter2(getActivity(), bilsEmiModels1);
                        rvAccountList.setAdapter(billsAndEmilAdapter);
                        rvAccountList.setHasFixedSize(true);
                    }
                });
            }

        } else {
            if (getActivity() != null && !getActivity().isFinishing()) {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        rvAccountList.setVisibility(View.GONE);
                        llEmpty.setVisibility(View.VISIBLE);
                    }
                });
            }

        }
    }


    private String getEmptyMessage() {
        switch (mKey) {
            case "loan":
                return getString(R.string.loan_list_empty);
            case "prepaid":
                return getString(R.string.prepaid_list_empty);
            case "phone":
                return getString(R.string.phone_list_empty);
            case "credit_card":
                return getString(R.string.credit_card_list_empty);
            case "generic":
                return getString(R.string.generic_card_list_empty);
            case "electricity":
                return getString(R.string.electricity_card_list_empty);
            case "insurance":
                return getString(R.string.insurance_card_list_empty);
            case "gas":
                return getString(R.string.gas_card_list_empty);
            default:
                return getString(R.string.bills_emi_list_empty);
        }
    }
}
