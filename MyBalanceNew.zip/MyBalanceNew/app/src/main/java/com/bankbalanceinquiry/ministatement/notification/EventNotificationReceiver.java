package com.bankbalanceinquiry.ministatement.notification;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.provider.Settings;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.drawerActivity;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;

public class EventNotificationReceiver extends BroadcastReceiver {
    private static final String NOTIFICATION_CHANNEL_ID = "10002";

    String title, description, amount;

    @Override
    public void onReceive(Context context, Intent intent) {
        title = intent.getStringExtra("title");
        description = intent.getStringExtra("description");
        amount = intent.getStringExtra("amount");
        createNotification(context, title, description, amount);
    }

    void createNotification(Context context, String title, String description, String amount) {
        /*RemoteViews notificationLayout = new RemoteViews(context.getPackageName(), R.layout.notification_pay_small);
        RemoteViews notificationLayoutExpanded = new RemoteViews(context.getPackageName(), R.layout.notification_pay_large);*/

        Log.e("TAG", "onInstantReceive: " + title);

        Intent intentEvent = new Intent(context, drawerActivity.class);
        intentEvent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        PendingIntent resultPendingIntent = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            resultPendingIntent = PendingIntent.getActivity(context, PreferenceHelper.getNotificationRequestCode(context), intentEvent, PendingIntent.FLAG_IMMUTABLE);
        } else
            resultPendingIntent = PendingIntent.getActivity(context, PreferenceHelper.getNotificationRequestCode(context), intentEvent, PendingIntent.FLAG_UPDATE_CURRENT);


        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID);
        mBuilder.setSmallIcon(R.drawable.app_icon_new);

        /*mBuilder.setCustomContentView(notificationLayout)
                .setCustomBigContentView(notificationLayoutExpanded)
                .setStyle(new NotificationCompat.DecoratedCustomViewStyle())
                .setContentIntent(resultPendingIntent)
                .build();*/

        mBuilder.setContentTitle(title)
                .setContentText(description)
                .setAutoCancel(true)
                .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                .setContentIntent(resultPendingIntent)
                .build();

        NotificationManager mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, Constant.DEFAULT_NOTIFICATION_NAME, importance);
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.enableVibration(true);
            notificationChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
            assert mNotificationManager != null;
            mBuilder.setChannelId(NOTIFICATION_CHANNEL_ID);
            mNotificationManager.createNotificationChannel(notificationChannel);
        }
        assert mNotificationManager != null;
        mNotificationManager.notify(PreferenceHelper.getNotificationRequestCode(context), mBuilder.build());
        PreferenceHelper.setNotificationRequestCode(context, PreferenceHelper.getNotificationRequestCode(context) + 1);
        Log.e("TAG", "event notification receiver: ");
    }
}
