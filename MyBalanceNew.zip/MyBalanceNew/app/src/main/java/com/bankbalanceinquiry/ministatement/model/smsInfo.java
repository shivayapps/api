package com.bankbalanceinquiry.ministatement.model;

public class smsInfo {

    int type = 0;

    String s_title;
    String s_bankname;
    String s_message;
    String s_mobile;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getS_mobile() {
        return s_mobile;
    }

    public void setS_mobile(String s_mobile) {
        this.s_mobile = s_mobile;
    }


    public String getS_title() {
        return s_title;
    }

    public void setS_title(String s_title) {
        this.s_title = s_title;
    }

    public String getS_bankname() {
        return s_bankname;
    }

    public void setS_bankname(String s_bankname) {
        this.s_bankname = s_bankname;
    }

    public String getS_message() {
        return s_message;
    }

    public void setS_message(String s_message) {
        this.s_message = s_message;
    }
}
