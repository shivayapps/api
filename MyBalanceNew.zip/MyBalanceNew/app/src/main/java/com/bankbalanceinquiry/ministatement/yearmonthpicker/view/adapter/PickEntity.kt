package com.bankbalanceinquiry.ministatement.yearmonthpicker.view.adapter

data class PickEntity(
    val id: Int,
    val value: String,
    val isEnabled: Boolean
)
