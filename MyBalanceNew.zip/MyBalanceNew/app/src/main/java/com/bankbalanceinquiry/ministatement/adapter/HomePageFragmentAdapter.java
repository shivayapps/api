package com.bankbalanceinquiry.ministatement.adapter;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.bankbalanceinquiry.ministatement.activity.ui.BoxviewFragment;
import com.bankbalanceinquiry.ministatement.fragment.MyMoneyFragment;
import com.bankbalanceinquiry.ministatement.profile.ProfileFragment;


public class HomePageFragmentAdapter extends FragmentPagerAdapter {

    Context context;
    int TotalTabs;
    // public PhotosFragment photosFragment;
    public BoxviewFragment boxviewFragment;
//    public CredentialFragment credentialFragment;
    public MyMoneyFragment mymoneyFragment;
    public ProfileFragment profileFragment;

    public HomePageFragmentAdapter(@NonNull FragmentManager fm, Context context, int TotalTabs) {
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        this.context = context;
        this.TotalTabs = TotalTabs;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                boxviewFragment = new BoxviewFragment();
                return boxviewFragment;
            case 1:
                mymoneyFragment = new MyMoneyFragment();
                return mymoneyFragment;
            case 2:
                profileFragment = new ProfileFragment();
                return profileFragment;
//            case 2:
//                credentialFragment = new CredentialFragment();
//                return credentialFragment;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return TotalTabs;
    }
}
