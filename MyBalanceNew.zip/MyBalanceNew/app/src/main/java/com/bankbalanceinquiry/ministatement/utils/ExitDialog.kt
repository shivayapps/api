package com.bankbalanceinquiry.ministatement.utils

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobNative
import com.google.android.gms.ads.nativead.NativeAd
import com.bankbalanceinquiry.ministatement.R


class ExitDialog(
    val activity: Activity,
    val mNativeAd: NativeAd?,
    val clickListener: (isExit: Boolean) -> Unit
) : Dialog(activity) {

    private lateinit var mAdmobNative: AdmobNative

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
//        window?.navigationBarColor = ContextCompat.getColor(activity, R.color.dialogBg)
        window?.setGravity(Gravity.BOTTOM)

        setContentView(R.layout.dialog_exit)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )

        AdsConfig.isSystemDialogOpen = true

        findViewById<TextView>(R.id.btnExit).setOnClickListener {
            dismiss()
            clickListener.invoke(true)
        }

        loadNativeAd()
    }

    private fun loadNativeAd() {
        mAdmobNative = AdmobNative()
        val nativeTemplate = findViewById<FrameLayout>(R.id.nativeTemplate)

        val adId = activity.getString(R.string.g_native_exit)
        if (mNativeAd != null) mAdmobNative.showNativeAd(activity, nativeTemplate, mNativeAd, adId)
        else {
            mAdmobNative.preLoad(activity, mNativeAd, { isLoaded, nativeAd ->
                Log.e("native_exit", "native_exit.preLoad:$isLoaded")
                if (isLoaded) {
                    AdCache.exitNative = nativeAd
                    mAdmobNative.showNativeAd(activity, nativeTemplate, mNativeAd, adId)
                } else {
                    nativeTemplate.visibility = View.GONE
                }
            }, { onImpression ->
                //AdCache.exitNative = null
            }, adId)
        }
    }
}



