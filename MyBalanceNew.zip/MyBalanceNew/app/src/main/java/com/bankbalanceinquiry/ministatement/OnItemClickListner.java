package com.bankbalanceinquiry.ministatement;

public interface OnItemClickListner {
    void onItemClick();

}
