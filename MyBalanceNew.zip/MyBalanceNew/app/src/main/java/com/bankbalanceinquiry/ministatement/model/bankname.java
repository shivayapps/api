package com.bankbalanceinquiry.ministatement.model;

public class bankname
{

    int type = 0;

    int b_id;
    String b_name;
    String b_inquiry;
    String b_care;
    int b_fav;
    String b_netbank;
    String b_mini;
    String b_short;
    String image_name ="";


    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public bankname(int b_id, String b_name, String b_inquiry, String b_care, int b_fav, String b_netbank, String b_mini, String b_short) {
        this.b_id = b_id;
        this.b_name = b_name;
        this.b_inquiry = b_inquiry;
        this.b_care = b_care;
        this.b_fav=b_fav;
        this.b_netbank = b_netbank;
        this.b_mini = b_mini;
        this.b_short = b_short;
    }

    public String getImage_name() {
        return image_name;
    }

    public void setImage_name(String image_name) {
        this.image_name = image_name;
    }

    public  bankname()
    {}

    public int getB_id() {
        return b_id;
    }

    public int getB_fav() {
        return b_fav;
    }

    public void setB_fav(int b_fav) {
        this.b_fav = b_fav;
    }

    public void setB_id(int b_id) {
        this.b_id = b_id;
    }

    public String getB_name() {
        return b_name;
    }

    public void setB_name(String b_name) {
        this.b_name = b_name;
    }

    public String getB_inquiry() {
        return b_inquiry;
    }

    public void setB_inquiry(String b_inquiry) {
        this.b_inquiry = b_inquiry;
    }

    public String getB_care() {
        return b_care;
    }

    public void setB_care(String b_care) {
        this.b_care = b_care;
    }

    public String getB_netbank() {
        return b_netbank;
    }

    public void setB_netbank(String b_netbank) {
        this.b_netbank = b_netbank;
    }

    public String getB_mini() {
        return b_mini;
    }

    public void setB_mini(String b_mini) {
        this.b_mini = b_mini;
    }

    public String getB_short() {
        return b_short;
    }

    public void setB_short(String b_short) {
        this.b_short = b_short;
    }

}

