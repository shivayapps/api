package com.bankbalanceinquiry.ministatement.databased;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.bankbalanceinquiry.ministatement.model.BilsEmiModel;

import java.util.ArrayList;
import java.util.HashMap;

public class DBHelperBills extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "MyDBNameBILL.db";
    public static final String CONTACTS_TABLE_NAME = "BILLS";
    public static final String CONTACTS_COLUMN_NAME = "name";
    private HashMap hp;

    public DBHelperBills(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table BILLS " +
                "(id integer primary key,AccountNo,AccountAmount,FinalDueDate,BankNameFinal,DisplayPaynow,FinalPendingDay)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS BILLS");
        onCreate(db);
    }




    public void DeleteAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from " + CONTACTS_TABLE_NAME);
    }




    public void InsertBill(String AccountNo, String AccountAmount,
                           String FinalDueDate, String BankNameFinal,
                           String DisplayPaynow, String FinalPendingDay) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put("AccountNo", AccountNo);
        contentValues.put("AccountAmount", AccountAmount);
        contentValues.put("FinalDueDate", FinalDueDate);
        contentValues.put("BankNameFinal", BankNameFinal);
        contentValues.put("DisplayPaynow", DisplayPaynow);
        contentValues.put("FinalPendingDay", FinalPendingDay);
        db.insert("BILLS", null, contentValues);
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from BILLS where id=" + id + "", null);
        return res;
    }

    public int numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, CONTACTS_TABLE_NAME);
        return numRows;
    }


    public Integer deleteContact(String OwnerId) {
      /*  SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("BILLS",
                "id = ? ",
                new String[]{Integer.toString(id)});*/
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("BILLS",
                "OwnerId = ? ",
                new String[]{OwnerId});
    }


    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from BILLS", null);
        return res;
    }

    public ArrayList<BilsEmiModel> GetBills() {
        ArrayList<BilsEmiModel> ownerDetails = new ArrayList<BilsEmiModel>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from BILLS", null);
        if (res.getCount() == 0) {

        } else {
            while (res.moveToNext()) {
                String AccountNo = res.getString(res.getColumnIndex("AccountNo"));
                String AccountAmount = res.getString(res.getColumnIndex("AccountAmount"));
                String FinalDueDate = res.getString(res.getColumnIndex("FinalDueDate"));
                String BankNameFinal = res.getString(res.getColumnIndex("BankNameFinal"));
                String DisplayPaynow = res.getString(res.getColumnIndex("DisplayPaynow"));
                String FinalPendingDay = res.getString(res.getColumnIndex("FinalPendingDay"));

                ownerDetails.add(new BilsEmiModel(AccountNo, AccountAmount,
                        FinalDueDate, BankNameFinal,
                        0, DisplayPaynow, FinalPendingDay));
            }
        }
        return ownerDetails;
    }
}
