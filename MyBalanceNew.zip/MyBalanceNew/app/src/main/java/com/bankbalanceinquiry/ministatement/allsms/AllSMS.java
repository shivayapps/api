package com.bankbalanceinquiry.ministatement.allsms;

import android.app.Activity;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;

import com.bankbalanceinquiry.ministatement.common.BankingSmsRead;
import com.bankbalanceinquiry.ministatement.databased.DBHelperAccount;
import com.bankbalanceinquiry.ministatement.model.AvilabeBalanceModel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AllSMS {

    public static AsyncTask mMyTask;
    public static Activity activity;
    public static String BankName = "";

    private DBHelperAccount mydb;

    public static ArrayList<AvilabeBalanceModel> avilabeBalanceModels;
    public static ArrayList<String> avilabestringarray;


    public static String BankNameFinal = "";
    public static int BankIconFinal = 0;

    public static void CallAllSMSFilter(Activity activityy) {
        activity = activityy;

        avilabeBalanceModels = new ArrayList<>();

        mMyTask = new GetAllSMSDATABASD().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    public static class GetAllSMSDATABASD extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
        }

        @Override
        protected String doInBackground(String... strings) {
            getAllSms();
            return null;
        }
    }

    public static List<String> getAllSms() {
        Uri message = Uri.parse("content://sms/inbox");
        ContentResolver cr = activity.getContentResolver();
        Cursor c = cr.query(message, null, null, null, null);
        //activity.startManagingCursor(c);
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
        String dateVal = "";
        int totalSMS = c.getCount();
        if (c.moveToFirst()) {
            Log.e("okHeader", "Blabk");
            for (int i = 0; i < totalSMS; i++) {
                String id = c.getString(c.getColumnIndexOrThrow("_id"));
                String BankNameTitle = c.getString(c.getColumnIndexOrThrow("address"));
                String body = c.getString(c.getColumnIndexOrThrow("body"));
                String read = c.getString(c.getColumnIndexOrThrow("read"));
                String date = c.getString(c.getColumnIndexOrThrow("date"));
                String type = c.getString(c.getColumnIndexOrThrow("type"));
                String person = c.getString(c.getColumnIndexOrThrow("person"));
                String TransactionSmsOrNot = BankingSmsRead.CheckIsTransactionSmsOrNot(body);
                if (TextUtils.isEmpty(TransactionSmsOrNot)) {
                    Log.e("TransactionSmsOrNot", " Not");
                } else {
                    if (BankNameTitle != null) {
                        BankName = "";
                        int BankIcon = GetAccountIcon(BankNameTitle);
                        String CheckIsDebitCredit = BankingSmsRead.SMSBodyToGetCreditDabit(body);
                        if (!CheckIsDebitCredit.equalsIgnoreCase("NoTransaction")) {
                            Log.e("MessgeBodyTransaction", body);
                            String AccountNo = BankingSmsRead.SMSBodyToGetAccountNumber(body);
                            String AccountAmount = BankingSmsRead.SMSBodyToGetTotalAmount(body);
                            //   String GetAvilable = BankingSmsRead.SMSBodyToAvilableBalance(body);
                            String GetAvilableClear = GetTotalAmount(body);
                            String GetBankingSMSDate = GetBankingSMSDate(body);
                            Long dateV = Long.parseLong(date);

                            dateVal = formatter.format(new Date(dateV));

                           // CallMontManagerCode(body);

                          //  getBankNameIconGet(BankNameTitle);

                            if (TextUtils.isEmpty(BankNameFinal)) {
                                BankNameFinal = BankName;
                            }

                            if (TextUtils.isEmpty(BankNameFinal)) {
                                BankNameFinal = BankNameTitle;
                            }

                            String CheckNoAccountAvilabeBalance = GetAVILABLEBALANCE(body);
                            if (!CheckNoAccountAvilabeBalance.equals("NoAccount")) {
                                Log.e("BodySMSACCOUNT", " id " + id + "\naddress " + BankNameTitle +
                                        "\nbody " + body +
                                        "\nAccountNo " + AccountNo +
                                        "\nAccountAmount " + AccountAmount +
                                        "\nCheckIsDebitCredit " + CheckIsDebitCredit +
                                        "\ndate " + dateVal +
                                        "\nGetAvilableCLR " + CheckNoAccountAvilabeBalance +
                                        "\nGetBankingSMSDate " + GetBankingSMSDate);
                               /* allAccountModelstmp.add(new AllAccountModel(BankNameTitle, AccountNo,
                                        AccountAmount, dateVal, CheckIsDebitCredit,
                                        CheckNoAccountAvilabeBalance, GetBankingSMSDate, BankIconFinal, BankNameFinal));
*/
                                if (!TextUtils.isEmpty(AccountNo)) {
                                    String CheckisAccoutOrNot = "No Account";
                                    if (TextUtils.isDigitsOnly(AccountNo)) {
                                        CheckisAccoutOrNot = "Yes Digit";
                                    } else if (AccountNo.toLowerCase().contains("x")) {
                                        CheckisAccoutOrNot = "Yes Account valid";
                                    } else {
                                        CheckisAccoutOrNot = "No Account";
                                    }

                                    if (!CheckisAccoutOrNot.equalsIgnoreCase("No Account")) {
//                                        allAccountModelstmp.add(new AllAccountModel(BankNameTitle, AccountNo,
//                                                AccountAmount, dateVal, CheckIsDebitCredit,
//                                                CheckNoAccountAvilabeBalance, GetBankingSMSDate, BankIconFinal, BankNameFinal));

                                    }
                                }
                            }
                        }
                    }

                }
                c.moveToNext();
            }
        }
        c.close();
        return null;
    }


    public static int GetAccountIcon(String bankNameTitle) {
        int icon = 0;
        BankName = "";
        if (bankNameTitle != null) {
            for (int i = 0; i < avilabeBalanceModels.size(); i++) {
                String BankNameold = avilabeBalanceModels.get(i).getBankSMSTile();
                if (TextUtils.equals(BankNameold, bankNameTitle)) {
                    icon = avilabeBalanceModels.get(i).getBankicon();
                    BankName = avilabeBalanceModels.get(i).getBankName();
                    break;
                }
            }
            return icon;
        }
        return 0;
    }

    public static String GetTotalAmount(String fullText) {
        Log.e("Msgbbb", fullText);
        Log.e("avilabeBalanceModels", avilabeBalanceModels.size() + "");
        boolean isFount = false;
        for (int i = 0; i < avilabeBalanceModels.size(); i++) {
            String AvilableMsg = avilabeBalanceModels.get(i).getAvilableMsg();
            String BankName = avilabeBalanceModels.get(i).getBankName();
            if (fullText.toLowerCase().indexOf(AvilableMsg.toLowerCase()) > -1) {
                isFount = true;
                Log.e("BankNameBankName", BankName);
                String[] separated = fullText.split(AvilableMsg);
                if (separated.length > 1) {
                    //fullText = separated[1];
                    Log.e("ASSSS", separated[1]);
                    String[] separatednew = separated[1].split(" ");
                    for (int ii = 0; ii < separatednew.length; ii++) {
                        String FinalDate = separatednew[ii];
                        Log.e("FinalDate", FinalDate);
                        if (!TextUtils.isEmpty(FinalDate) && !FinalDate.equals(".")) {
                            fullText = FinalDate;
                            break;
                        }
                    }

                    Log.e("separatedseparated ", fullText + "\n");
                } else {
                    fullText = "";
                    Log.e("separatedseparated", " Nuu");
                }
                break;
            }
        }
        if (!isFount) {
            fullText = "";
        }

        /*if (fullText.endsWith(".")) {
            String fl = fullText.replace(".", " ");
            fullText = fl;
        }*/

        if (fullText.contains(".")) {
            Log.e("Yesok", "Dot" + fullText);
            String Replacedot = fullText.replace(".", " ");
            String[] separated = Replacedot.split(" ");
            if (!TextUtils.isEmpty(Replacedot)) {
                if (separated.length > 0) {
                    Log.e("ReplacedotReplacedot", separated[0]);
                    fullText = separated[0];
                }
            }
            if (fullText.equals(".")) {
                fullText = "";
            }
        }
        return fullText;
    }

    public static String GetAVILABLEBALANCE(String fullText) {
        Log.e("GetAVILABLEBALANCE==>", fullText);
        boolean isFount = false;
        for (int i = 0; i < avilabestringarray.size(); i++) {
            String ForiAvlMessage = avilabestringarray.get(i);
            if (fullText.toLowerCase().indexOf(ForiAvlMessage.toLowerCase()) > -1) {
                isFount = true;
                String[] separated = fullText.split(ForiAvlMessage);
                if (separated.length > 1) {
                    String[] separatednew = separated[1].split(" ");
                    for (int ii = 0; ii < separatednew.length; ii++) {
                        String FinalDate = separatednew[ii];
                        if (FinalDate.startsWith(".")) {
                            FinalDate = FinalDate.substring(1);
                        }
                        Log.e("MatchFounr==>", FinalDate);
                        if (!TextUtils.isEmpty(FinalDate) && !FinalDate.equals(".")) {
                            fullText = FinalDate;
                            Log.e("breakMatchFounr==>", fullText);
                            break;
                        }
                    }
                } else {
                    fullText = "";
                }
                break;
            }
        }

        if (!isFount) {
            fullText = "NoAccount";
        } else {
            if (fullText.contains(".")) {
                String Replacedot = fullText.replace(".", " ");
                String[] separated = Replacedot.split(" ");
                if (!TextUtils.isEmpty(Replacedot)) {
                    if (separated.length > 0) {
                        fullText = separated[0];
                    }
                }
                if (fullText.equals(".")) {
                    fullText = "";
                }
            }
        }
        Log.e("FIndingAccount", fullText);
        return fullText;
    }

    public static String GetBankingSMSDate(String fullText) {
//        fullText = "Dear Customer, your Acct XX983 is credited with salary of INR 21,000.00 on 07-Apr-20. Info: NEFT-N098200390. The Available Balance is INR 2,23,017.00";
        boolean isFount = false;
        for (int i = 0; i < avilabeBalanceModels.size(); i++) {
            String AvilableMsg = avilabeBalanceModels.get(i).getDateonMsg();
            String BankName = avilabeBalanceModels.get(i).getBankName();
            if (fullText.toLowerCase().indexOf(AvilableMsg.toLowerCase()) > -1) {
                Log.e("BankNameBankNameDate", BankName);
                String[] separated = fullText.split(AvilableMsg);
                if (separated.length > 1) {
                    isFount = true;
                    fullText = separated[1];
                    String[] fullTextnew = fullText.split(" ");
                    if (fullTextnew.length > 1) {
                        fullText = fullTextnew[1];
                        Log.e("fullTextnew", fullText);
                    }

                }
                break;
            }
        }
        if (!isFount) {
            fullText = "";
        }
        return fullText;
    }


}
