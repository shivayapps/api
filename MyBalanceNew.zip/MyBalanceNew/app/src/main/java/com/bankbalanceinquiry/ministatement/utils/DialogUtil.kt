package com.bankbalanceinquiry.ministatement.utils

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.util.TypedValue
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.bankbalanceinquiry.ministatement.R


fun Activity.showPurchaseSuccess() {
    val title = getString(R.string.app_name)
    val message = resources.getString(R.string.remove_ads_msg)
    val positiveBtn = resources.getString(R.string.dialog_restart)

//    if (!AdsManager(this).isDialogShowing()) {
//        AdsManager(this).saveDialogStatus(true)
    showAlert(title, message, positiveBtn, null, object : OnPositive {
        override fun onYes() {
//                AdsManager(this@showPurchaseSuccess).saveDialogStatus(false)
        }
    })
//    }
}


fun Activity.showAlert(
    title: String? = null,
    msg: String? = null,
    positiveText: String? = null,
    negativeText: String? = null,
    positive: OnPositive? = null
) {

    val dialog = AlertDialog.Builder(this)
    var alert: AlertDialog? = null

    dialog.setCancelable(false)
    if (title != null) {
        // Initialize a new foreground color span instance
        val foregroundColorSpan =
            ForegroundColorSpan(ContextCompat.getColor(this, R.color.colorPrimaryDark))
        val ssBuilder = SpannableStringBuilder(title)
        ssBuilder.setSpan(foregroundColorSpan, 0, title.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        dialog.setTitle(ssBuilder)
    }
    if (msg != null) {
        dialog.setMessage(msg)
    }
    if (positiveText != null) {
        dialog.setPositiveButton(positiveText) { _, _ ->
            this.triggerRebirth()
            alert?.dismiss()
            positive?.onYes()
        }
    }
    if (negativeText != null) {
        dialog.setNegativeButton(negativeText) { _, _ ->
            alert?.dismiss()
            positive?.onNo()
        }
    }

    alert = dialog.create()
    alert.show()


    val textView = alert.findViewById<TextView>(android.R.id.message)
    try {
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
    } catch (e: Exception) {
        Log.e("showAlert", e.toString())
    }
}

fun Activity.triggerRebirth() {
    val packageManager = this.packageManager
    val intent = packageManager.getLaunchIntentForPackage(this.packageName)
    val componentName = intent!!.component
    val mainIntent = Intent.makeRestartActivityTask(componentName)
    this.startActivity(mainIntent)
    Runtime.getRuntime().exit(0)
}

interface OnPositive {
    fun onYes()
    fun onNo() {}
}