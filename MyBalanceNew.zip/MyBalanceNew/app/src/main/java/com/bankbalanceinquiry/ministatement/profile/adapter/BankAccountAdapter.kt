package com.bankbalanceinquiry.ministatement.profile.adapter

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.adsutil.admob.BannerAdHelper
import com.bankbalanceinquiry.ministatement.R
import com.bankbalanceinquiry.ministatement.databinding.ListItemProfileBinding
import com.bankbalanceinquiry.ministatement.profile.data.BankAccount
import com.bankbalanceinquiry.ministatement.utils.AdCache
import com.google.android.gms.ads.AdView
import java.util.Random

class BankAccountAdapter(val bankAccountList :ArrayList<BankAccount>,private val onItemClicked: (BankAccount, Int) -> Unit) : RecyclerView.Adapter<BankAccountAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ListItemProfileBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return bankAccountList.size
    }

    var isAdLoaded = false
    var mAdView: AdView?=null
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val current = bankAccountList[position]
//        if(current is BankAccount) {
            holder.itemView.setOnClickListener {
                onItemClicked(current, 0)
            }
            holder.binding.adsView.visibility= View.GONE
            val color = Color.argb(
                255,
                Random().nextInt(256),
                Random().nextInt(256),
                Random().nextInt(256)
            )
//            val drawable = TextDrawable.builder()
//                .buildRoundRect(item.bankName.substring(0, 1), color, 8)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                holder.binding.bankLogo2.backgroundTintList= ColorStateList.valueOf(
                    color
                )
            }
            holder.binding.bankLogo2.text=current.bankName.substring(0,1)
            holder.binding.title.text = "Bank Name:"+current.bankName
            holder.binding.holderName.text = "Holder Name:"+current.accountHolderName
            holder.binding.accntType.text = "Account Type:"+current.accountType
            holder.binding.accntNo.text = "Account No:"+current.accountNo
            holder.binding.btnDelete.setOnClickListener {
                onItemClicked(current,1)
            }
            holder.binding.btnShare.setOnClickListener {
                onItemClicked(current,2)
            }
//            holder.bind(current)
//        } else {
//            val adId: String = holder.binding.adsView.context.getString(R.string.g_banner_bankacct)
//            BannerAdHelper.showBanner(
//                holder.binding.adsView.context,
//                holder.binding.adsView,
//                adId,
//                AdCache.bannerBankacct,
//                { aBoolean: Boolean?, adView: AdView?, s: String? ->
//                    AdCache.bannerBankacct = adView
//                    mAdView = adView
//                    isAdLoaded = true
//                    null
//                },
//                null
//            )
//            holder.bindAds()
//        }


    }

    class ViewHolder(var binding: ListItemProfileBinding) : RecyclerView.ViewHolder(binding.root)
}