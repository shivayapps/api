package com.bankbalanceinquiry.ministatement.profile.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bankbalanceinquiry.ministatement.R
import com.bankbalanceinquiry.ministatement.databinding.ListItemProfileBinding
import com.bankbalanceinquiry.ministatement.profile.data.BankAccount
import com.bankbalanceinquiry.ministatement.utils.TextDrawable
import java.util.Random

class BankAccountAdapter(private val onItemClicked: (BankAccount,Int) -> Unit) :
    ListAdapter<BankAccount, BankAccountAdapter.BankAccountViewHolder>(
        DiffCallback
    ) {

    class BankAccountViewHolder(private var binding: ListItemProfileBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: BankAccount) {
            val color =
                Color.argb(255, Random().nextInt(256), Random().nextInt(256), Random().nextInt(256))
            val drawable = TextDrawable.builder()
                .buildRoundRect(item.bankName.substring(0, 1), color, 8)

//            binding.bankLogo2.setImageResource(R.drawable.bank_category_image)
            binding.bankLogo2.setImageDrawable(drawable)
            binding.title.text = item.bankName
            binding.holderName.text = item.accountHolderName
        }
    }

    companion object {
        private val DiffCallback = object : DiffUtil.ItemCallback<BankAccount>() {
            override fun areContentsTheSame(oldItem: BankAccount, newItem: BankAccount): Boolean {
                return oldItem.accountNo == newItem.accountNo
            }

            override fun areItemsTheSame(oldItem: BankAccount, newItem: BankAccount): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BankAccountViewHolder {
        return BankAccountViewHolder(
            ListItemProfileBinding.inflate(
                LayoutInflater.from(
                    parent.context
                )
            )
        )
    }

    override fun onBindViewHolder(holder: BankAccountViewHolder, position: Int) {
        val current = getItem(position)
        holder.itemView.setOnClickListener {
            onItemClicked(current,0)
        }
        holder.bind(current)
    }
}