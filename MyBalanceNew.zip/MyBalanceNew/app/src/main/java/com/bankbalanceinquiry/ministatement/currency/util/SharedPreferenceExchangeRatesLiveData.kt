package com.bankbalanceinquiry.ministatement.currency.util

import android.content.SharedPreferences
import android.content.SharedPreferences.OnSharedPreferenceChangeListener
import androidx.lifecycle.LiveData
import com.bankbalanceinquiry.ministatement.currency.data.ExchangeRates

class SharedPreferenceExchangeRatesLiveData(private val sharedPrefs: SharedPreferences) : LiveData<ExchangeRates?>() {

    private fun getValueFromPreferences(): ExchangeRates? {
        return if (sharedPrefs.getString("_base", null) == null || sharedPrefs.getString("_date", null) == null)
            null
        else
            ExchangeRates(
                true, // success always true, when serving cached data
                null, // error message always null, when serving cached data
                sharedPrefs.getString("_base", null)!!,
                sharedPrefs.getString("_date", null)!!,
                sharedPrefs.all.entries
                    .filter { !it.key.startsWith("_") }
                    .sortedBy { it.key }
                    .map {
                        com.bankbalanceinquiry.ministatement.currency.data.Rate(
                            it.key!!,
                            (it.value as Float)
                        )
                    }
                    .toList()
            )
    }

    private val preferenceChangeListener = OnSharedPreferenceChangeListener { _: SharedPreferences?, _: String? ->
            postValue(getValueFromPreferences())
    }

    override fun onActive() {
        super.onActive()
        postValue(getValueFromPreferences())
        sharedPrefs.registerOnSharedPreferenceChangeListener(preferenceChangeListener)
    }

    override fun onInactive() {
        sharedPrefs.unregisterOnSharedPreferenceChangeListener(preferenceChangeListener)
        super.onInactive()
    }

}
