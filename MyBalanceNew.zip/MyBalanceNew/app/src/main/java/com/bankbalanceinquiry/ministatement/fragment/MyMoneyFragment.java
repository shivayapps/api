package com.bankbalanceinquiry.ministatement.fragment;

import android.app.ActivityManager;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.bankbalanceinquiry.ministatement.Events.SmsList;
import com.bankbalanceinquiry.ministatement.Events.SmsProgress;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.AccountHisotryActivity1;
import com.bankbalanceinquiry.ministatement.adapter.AllAccountListAdapter;
import com.bankbalanceinquiry.ministatement.adapternew.AllAccountListNewAdapter;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.databased.StoreValue;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.databinding.FragmentMyMoneyBinding;
import com.bankbalanceinquiry.ministatement.model.AllAccountModel;
import com.bankbalanceinquiry.ministatement.model.newTransactionDataEvent;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;
import com.bankbalanceinquiry.ministatement.utils.SmsService;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class MyMoneyFragment extends Fragment implements AllAccountListNewAdapter.ClickActivDeactiveint {
    FragmentMyMoneyBinding moneyBinding;
    FragmentActivity fragmentActivity;

    private AllAccountListNewAdapter allAccountListNewAdapter;
    private final ArrayList<HomeAccoutList> homeAccoutLists = new ArrayList<>();
    private final ArrayList<HomeAccoutList> homeAccoutLists1 = new ArrayList<>();
    HashMap<String, HomeAccoutList> hashData = new HashMap<>();

    boolean isCountRunning = true;
    private DBHelperAccountNew mydbAccountNew;
    private final Dialog DialogProgress = null;
    private String BankName = "";
    private ArrayList<AllAccountModel> allAccountModels;
    private AllAccountListAdapter allAccountListAdapter;

    private final AsyncTask mMyTask = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fragmentActivity = requireActivity();
    }


    @Subscribe
    public void OnSmsProgress(final Intent intent) {
        if (intent != null && intent.getAction().equalsIgnoreCase("RefreshData")) {
            if (!isMyServiceRunning(SmsService.class)) {
                // ContextCompat.startForegroundService(fragmentActivity, new Intent(fragmentActivity, SmsService.class));
                moneyBinding.count.setText(getResources().getString(R.string.analyzing_from_sms_service) + "0" + "%");

                moneyBinding.progressLay.setVisibility(View.VISIBLE);
                disableMenuItems(true);
            }
        } else if (intent != null && intent.getAction().equalsIgnoreCase("NEW_BANK_FOUND")) {
            int count = intent.getIntExtra("count", 0);
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    moneyBinding.liNewFound.setVisibility(View.VISIBLE);
                    moneyBinding.txtNewAddedBanks.setText(count + " " + getString(R.string.new_found_bank));
                }
            });
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        moneyBinding = FragmentMyMoneyBinding.inflate(getLayoutInflater());
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this);

        /*if (!isMyServiceRunning(SmsService.class)) {
            ContextCompat.startForegroundService(fragmentActivity, new Intent(fragmentActivity, SmsService.class));
        }*/

        mydbAccountNew = new DBHelperAccountNew(fragmentActivity);
        ArrayList<HomeAccoutList> homeAccoutListArrayList = mydbAccountNew.GetAllAccountNew();
        mydbAccountNew = new DBHelperAccountNew(fragmentActivity);

        LinearLayoutManager linearLayoutManagern = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        moneyBinding.rvAccountList.setLayoutManager(linearLayoutManagern);


        if (isMyServiceRunning(SmsService.class)) {
           /* if (isShowProgress) {
                moneyBinding.progressLay.setVisibility(View.VISIBLE);
            } else {
                moneyBinding.progressLay.setVisibility(View.GONE);
            }*/
            disableMenuItems(true);
        } else {
            //moneyBinding.progressLay.setVisibility(View.GONE);
            disableMenuItems(false);
        }


        if (CommonFun.IsAllSmsmFill.equalsIgnoreCase("")) {
            String FirstTime = StoreValue.GetFirstime("OK");
            if (FirstTime.equalsIgnoreCase("")) {
                CommonFun.IsAllSmsmFill = "";
                Log.e("FIRSTIMEINSERDATA==>", "FirstTime");
                if (mMyTask != null) {
                    if (mMyTask.getStatus() == AsyncTask.Status.RUNNING) {
                        // My AsyncTask is currently doing work in doInBackground()
                    }
                } else {
                    // mMyTask = new AllOptionFilterFirstTime().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                    String FirstTimeON = StoreValue.GetLodingData("DOUBLE");
                    if (FirstTimeON.equalsIgnoreCase("")) {
                        StoreValue.SetLodingData("DOUBLE", "Ok");
                        Log.e("FirstTimeON", FirstTimeON);
                    } else {
                        Log.e("FirstTimeON", " AfterLoad");
                        moneyBinding.loading.setVisibility(View.VISIBLE);
                        moneyBinding.accountPassbook.setVisibility(View.GONE);

                    }
                }

            } else {
                moneyBinding.loading.setVisibility(View.GONE);
                moneyBinding.accountPassbook.setVisibility(View.VISIBLE);
                CommonFun.IsAllSmsmFill = "AllFill";
                CallNewHomeAccount();
            }
        } else {
            moneyBinding.loading.setVisibility(View.GONE);
            moneyBinding.accountPassbook.setVisibility(View.VISIBLE);
            CallNewHomeAccount();
        }
        moneyBinding.txtNewAddOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moneyBinding.liNewFound.setVisibility(View.GONE);
            }
        });
        return moneyBinding.getRoot();
    }

    private void disableMenuItems(boolean isDisable) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                EventBus.getDefault().post(new Intent().setAction("DisableOptionMenu").putExtra("disabled", isDisable));
            }
        }, 200);
    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        if (getActivity() != null) {
            ActivityManager manager = (ActivityManager) getActivity().getSystemService(Context.ACTIVITY_SERVICE);
            if (manager != null) {
                for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                    if (serviceClass.getName().equals(service.service.getClassName())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public void onDestroyView() {
        EventBus.getDefault().unregister(this);
        super.onDestroyView();
    }

    private void CallNewHomeAccount() {
//        moneyBinding.pbLoading.setVisibility(View.GONE);
        homeAccoutLists.clear();
        ArrayList<HomeAccoutList> homeAccoutListArrayList = mydbAccountNew.GetAllAccountNew();
        ArrayList<HomeAccoutList> transactionListListArrayList = mydbAccountNew.GetAllTransaction();
        homeAccoutLists.addAll(homeAccoutListArrayList);
        SimpleDateFormat formatterHistory = new SimpleDateFormat("dd MMMM yyyy, hh:mm aa", Locale.US);
        HashMap<String, Date> timeDateList = new HashMap<>();
        HashMap<String, String> finalBalanceList = new HashMap<>();

        for (HomeAccoutList homeAccoutList : transactionListListArrayList) {
            try {
                Date date3 = formatterHistory.parse(homeAccoutList.dateValHistory);
                long time = date3.getTime();
                homeAccoutList.dateLongValue = time;

                if (homeAccoutList.FinalAccountNo.equals("3414")) {
                    Log.e("YTCFGHSXCFUJHGVXS", time + "::" + homeAccoutList.FinalAccountBalance);
                }
                String nameKey = homeAccoutList.full_name + "_" + homeAccoutList.FinalAccountNo;
                if (timeDateList.containsKey(nameKey) && !timeDateList.get(nameKey).after(date3)) {
                    if (!timeDateList.get(nameKey).equals(date3)) {
                        timeDateList.put(nameKey, date3);
                        finalBalanceList.put(nameKey, homeAccoutList.FinalAccountBalance);
                    }
                } else if (!timeDateList.containsKey(nameKey)) {
                    timeDateList.put(nameKey, date3);
                    finalBalanceList.put(nameKey, homeAccoutList.FinalAccountBalance);
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        Collections.sort(transactionListListArrayList, new Comparator<HomeAccoutList>() {
            @Override
            public int compare(HomeAccoutList t1, HomeAccoutList t2) {
                return Long.valueOf(t2.dateLongValue).compareTo(Long.valueOf(t1.dateLongValue));
            }
        });

        for (String s : finalBalanceList.keySet()) {
            String balance = finalBalanceList.get(s);
            if (TextUtils.isEmpty(balance)) {
                String lastBalance = findLastFoundBalance(s, transactionListListArrayList);
                finalBalanceList.put(s, lastBalance);
            }

        }


        for (HomeAccoutList homeAccoutList : homeAccoutLists) {
            String nameKey = homeAccoutList.full_name + "_" + homeAccoutList.FinalAccountNo;
            SimpleDateFormat formatterAccount = new SimpleDateFormat("dd MMM yyyy", Locale.US);
            if (timeDateList.containsKey(nameKey)) {
                homeAccoutList.dateValAccount = formatterAccount.format(timeDateList.get(nameKey));
                homeAccoutList.dateLongValue = timeDateList.get(nameKey).getTime();
            }
            if (finalBalanceList.containsKey(nameKey)) {
                Log.e("HAGSFDCGHASCFGAFc", finalBalanceList.get(nameKey) + ":::");
                homeAccoutList.FinalAccountBalance = finalBalanceList.get(nameKey);
            }
        }


        Collections.sort(homeAccoutLists, new Comparator<HomeAccoutList>() {
            @Override
            public int compare(HomeAccoutList t1, HomeAccoutList t2) {
                return Long.valueOf(t2.dateLongValue).compareTo(Long.valueOf(t1.dateLongValue));
            }
        });


        if (homeAccoutLists.size() > 0) {
            //navBalance.setText("\u20B9" + calculateTotalBal(homeAccoutListArrayList));
            //homeAccoutLists.add(1, new HomeAccoutList(1));
            //   homeAccoutLists.addAll(homeAccoutLists);
            allAccountListNewAdapter = new AllAccountListNewAdapter(fragmentActivity, homeAccoutLists);
            allAccountListNewAdapter.RegisterInterface(MyMoneyFragment.this);
            moneyBinding.rvAccountList.setAdapter(allAccountListNewAdapter);
            allAccountListNewAdapter.notifyDataSetChanged();
            moneyBinding.tvNoData.setVisibility(View.GONE);
        } else {
            moneyBinding.tvNoData.setVisibility(View.VISIBLE);
        }
    }


    public String findLastFoundBalance(String key, ArrayList<HomeAccoutList> transactionListListArrayList) {
        SimpleDateFormat formatterHistory = new SimpleDateFormat("dd MMMM yyyy, hh:mm aa", Locale.US);
        long foundLong = -1;
        String finalBalance = "0.00";
        for (HomeAccoutList homeAccoutList : transactionListListArrayList) {
            try {
                String nameKey = homeAccoutList.full_name + "_" + homeAccoutList.FinalAccountNo;
                if (key.equals(nameKey)) {
                    Date date3 = formatterHistory.parse(homeAccoutList.dateValHistory);
                    long time = date3.getTime();
                    if (foundLong == -1 && !TextUtils.isEmpty(homeAccoutList.FinalAccountBalance)) {
                        finalBalance = homeAccoutList.FinalAccountBalance;
                        foundLong = time;
                        break;
                    }
                }

            } catch (Exception e) {

            }

        }
        return finalBalance;
    }

    @Override
    public void ClickActiveDeactive(final int position, final int color, HomeAccoutList modelData) {
        Log.e("PositionAccount", position + "");
        if (modelData != null) {
            Intent i = new Intent(getActivity(), AccountHisotryActivity1.class);
            i.putExtra("OBJ", modelData);
            i.putExtra("color", color);
            startActivity(i);
        }
    }

    @Override
    public void ClickBusinessOrPersion(int position) {
        if (allAccountModels.size() > 0) {
            boolean isActivinactive = allAccountModels.get(position).isBusinessOrPersion();
            allAccountModels.get(position).setBusinessOrPersion(!isActivinactive);

            if (allAccountListAdapter != null) {
                allAccountListAdapter.notifyDataSetChanged();
            }
        }
    }

    @Subscribe
    public void OnSmsProgress(final SmsProgress smsProgress) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(() -> {
                if (smsProgress.isShowProgress()) {
                    if (moneyBinding.progressLay.getVisibility() != View.VISIBLE) {
                        moneyBinding.progressLay.setVisibility(View.VISIBLE);
                    }
                } else {
                    moneyBinding.progressLay.setVisibility(View.GONE);
                }
                int per = (SmsService.smsCount * 100) / SmsService.TotalCount;
                if (!isAdded()){
                    return;
                }
                try {
                    moneyBinding.count.setText(getActivity().getString(R.string.analyzing_from_sms_service) + " " + per + "%");
                    if (SmsService.smsCount == (SmsService.TotalCount - 1)) {
                        PreferenceHelper.saveToUserDefaults(getActivity(), Constant.TRACK_PREF, "1");
                    }
                }catch (Exception e){
                    Log.e("TAG", "OnSmsProgressError: ",e);
                }
            });
        }
    }
    /**/

    @Subscribe
    public void OnSmsList(final SmsList smsList) {
        isCountRunning = false;
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    moneyBinding.progressLay.setVisibility(View.GONE);
                    disableMenuItems(false);
                    moneyBinding.accountPassbook.setVisibility(View.VISIBLE);
                    moneyBinding.loading.setVisibility(View.GONE);
                    if (allAccountListNewAdapter != null && allAccountListNewAdapter.getItemCount() > 0) {
                        moneyBinding.tvNoData.setVisibility(View.GONE);
                    } else {
                        moneyBinding.tvNoData.setVisibility(View.VISIBLE);
                    }

                }
            });
        }

    }

    @Subscribe
    public void OnSmsList(final newTransactionDataEvent transactionData) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (moneyBinding.accountPassbook.getVisibility() != View.VISIBLE) {
                        moneyBinding.accountPassbook.setVisibility(View.VISIBLE);
                    }
                    if (moneyBinding.progressLay.getVisibility() != View.VISIBLE) {
                        moneyBinding.count.setText(getResources().getString(R.string.analyzing_from_sms_service) + "0" + "%");

                        moneyBinding.progressLay.setVisibility(View.VISIBLE);
                        moneyBinding.tvNoData.setVisibility(View.GONE);
                    }
                    moneyBinding.loading.setVisibility(View.GONE);
                    if (hashData.size() == 0) {
                        allAccountListNewAdapter = new AllAccountListNewAdapter(fragmentActivity, homeAccoutLists1);
                        allAccountListNewAdapter.RegisterInterface(MyMoneyFragment.this);
                        moneyBinding.rvAccountList.setAdapter(allAccountListNewAdapter);
                    }
                    if (transactionData.isIslangChanged()) {
                        if (PreferenceHelper.getFromBooleans(getContext(), Constant.IS_FIRST_LOADING_DONE, false)) {
                            CallNewHomeAccount();
                        } else {
                            for (int i = 0; i < transactionData.getHomeAccoutLists1().size(); i++) {
                                HomeAccoutList data = transactionData.getHomeAccoutLists1().get(i);
                                allAccountListNewAdapter.addData(data);
                            }
                        }
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                EventBus.getDefault().post(new Intent("LANG_CHANGED").putExtra("isUpdate", true));
                            }
                        }, 500);

                    } else {
                        for (int i = 0; i < transactionData.getHomeAccoutLists1().size(); i++) {
                            HomeAccoutList data = transactionData.getHomeAccoutLists1().get(i);
                            String key = data.full_name + "_" + data.FinalAccountNo;
                            if (hashData.containsKey(key)) {
                                if (transactionData.isUpdateBalance()) {
                                    HomeAccoutList data1 = hashData.get(transactionData.getUpdatedKey());
                                    data1.FinalAccountBalance = transactionData.getHashData().get(transactionData.getUpdatedKey()).FinalAccountBalance;
                                    hashData.put(key, data1);
                                    allAccountListNewAdapter.updateDataBalance(data1);
                                }
                            } else {
                                if (transactionData.isAccount()) {
                                    hashData.put(key, data);
                                    allAccountListNewAdapter.addData(data);
                                }
                            }
                        }

                    }
                }
            });
        }

    }
}