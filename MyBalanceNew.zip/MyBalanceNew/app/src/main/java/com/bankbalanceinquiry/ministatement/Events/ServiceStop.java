package com.bankbalanceinquiry.ministatement.Events;

public class ServiceStop {

    private boolean isStop;

    public ServiceStop(boolean isStop) {
        this.isStop = isStop;
    }

    public boolean isStop() {
        return isStop;
    }

    public void setStop(boolean stop) {
        isStop = stop;
    }
}
