package com.bankbalanceinquiry.ministatement.activity;

import static com.bankbalanceinquiry.ministatement.utils.Constant.isFromLanguage;
import static com.bankbalanceinquiry.ministatement.utils.Constant.setLocale;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.adconfig.adsutil.admob.NativeAdHelper;
import com.adconfig.adsutil.admob.NativeLayoutType;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.databinding.ActivityLanguageSelectBinding;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;

import org.greenrobot.eventbus.EventBus;

public class LanguageSelectActivity extends AppCompatActivity {
    ActivityLanguageSelectBinding binding;
    AppCompatImageView[] rbImages;
    String[] allAvailableLanguages;
    String userSelectedLanguageCode = "en";

    boolean isFromSettings = false;

    public boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(LanguageSelectActivity.this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= 33) {
                    if (ActivityCompat.checkSelfPermission(LanguageSelectActivity.this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return true;
                }
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLanguageSelectBinding.inflate(getLayoutInflater());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.app_color));
        }
        setContentView(binding.getRoot());

        if (getIntent() != null) {
            isFromSettings = getIntent().getBooleanExtra("isFromSetting", false);
            if (isFromSettings) {
                binding.imgBack.setVisibility(View.VISIBLE);
                binding.imgBack.setOnClickListener(v -> onBackPressed());
            }
        }

        rbImages = new AppCompatImageView[]{binding.rbLang1, binding.rbLang2, binding.rbLang3, binding.rbLang4, binding.rbLang5,
                binding.rbLang6, binding.rbLang7};
        allAvailableLanguages = new String[]{"en", "hi", "gu", "mr", "ta", "te", "kn"};
        String laguagesSaved = PreferenceHelper.getFromUserDefaults(getApplicationContext(), Constant.LANG_PREF, "en");

        for (int i = 0; i < allAvailableLanguages.length; i++) {
            if (laguagesSaved.equalsIgnoreCase(allAvailableLanguages[i])) {
                rbImages[i].setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_checked));
                break;
            }
        }
        binding.imgLanguageSelect.setOnClickListener(v -> {
            PreferenceHelper.saveToUserDefaults(this, Constant.LANG_PREF, userSelectedLanguageCode);
            PreferenceHelper.saveToBooleans(this, Constant.LANG_SELECTED, true);
            setLocale(this);
            if (isFromSettings) {
                isFromLanguage = true;
            }
            binding.imgLanguageSelect.setClickable(false);
            if (isFromSettings) {
                Intent intent = new Intent(LanguageSelectActivity.this, drawerActivity.class);
                startActivity(intent);
                EventBus.getDefault().post(new Intent("LANG_CHANGED").putExtra("isUpdate", false));
            } else {

                if (isStoragePermissionGranted()) {
                    Intent i = new Intent(getApplicationContext(), drawerActivity.class);
                    startActivity(i);
                } else {
                    startActivity(new Intent(this, PermissionActivity.class).putExtra("isFromSetting", false));
                }
            }
            finish();


        });

        binding.lang1.setOnClickListener(v -> selectLanguage(1));
        binding.lang2.setOnClickListener(v -> selectLanguage(2));
        binding.lang3.setOnClickListener(v -> selectLanguage(3));
        binding.lang4.setOnClickListener(v -> selectLanguage(4));
        binding.lang5.setOnClickListener(v -> selectLanguage(5));
        binding.lang6.setOnClickListener(v -> selectLanguage(6));
        binding.lang7.setOnClickListener(v -> selectLanguage(7));

//        AdmobAdManager.getInstance().LoadLanguageNativeAd(this,
//                getString(R.string.admob_native_language_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
//                AdmobAdManager.getInstance()
//                        .populateUnifiedNativeAdView(LanguageSelectActivity.this,
//                                binding.frameAd, (NativeAd) object, true, false);
//            }
//
//            @Override
//            public void onAdClosed() {
//
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
//                Log.e("TAG", "onLanguageAdLoadError: " + errorCode);
//            }
//        });

        new NativeAdHelper(this, binding.frameAd, NativeLayoutType.NativeBig, getString(R.string.g_native_language)).loadAd();

    }

    private void selectLanguage(int position) {
        for (AppCompatImageView item : rbImages) {
            item.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_unchecked));
        }
        userSelectedLanguageCode = allAvailableLanguages[position - 1];
        rbImages[position - 1].setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_checked));
    }
}