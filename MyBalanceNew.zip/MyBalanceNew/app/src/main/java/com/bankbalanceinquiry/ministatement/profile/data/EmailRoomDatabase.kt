package com.bankbalanceinquiry.ministatement.profile.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.bankbalanceinquiry.ministatement.profile.data.EmailAccount
import com.bankbalanceinquiry.ministatement.profile.data.EmailDao

@Database(entities = [EmailAccount::class], version = 1, exportSchema = false)
abstract class EmailRoomDatabase: RoomDatabase() {

    abstract fun emailDao(): EmailDao

    companion object {

        @Volatile
        private var INSTANCE: EmailRoomDatabase? = null
        fun getDatabase(context: Context): EmailRoomDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    EmailRoomDatabase::class.java,
                    "emailaccount_database"
                )
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build()
                    INSTANCE = instance
                return instance
            }
        }
    }
}