package com.bankbalanceinquiry.ministatement.utils;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.drawerActivity;

public class SmsDoneDataService extends Service {


    private final int SCREEN_RECORDER_NOTIFICATION_ID = 99;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        if (intent != null) {
            setNotification(false, intent);
        }


        // setNotification(true, intent);

        return START_STICKY;
    }


    public void setNotification(boolean isUpdate, Intent intent) {
        String CHANNEL_ID = "com.balancecheck";
//        Intent notificationIntent = new Intent();
        PendingIntent pendingIntent = null;
        Intent notificationIntent = new Intent(this, drawerActivity.class);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

        //  notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    /*    notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_CLEAR_TASK);*/
//        intent.addFlags(FLAG_ACTIVITY_NO_ANIMATION);

        notificationIntent.putExtra("FromNotification", true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pendingIntent = PendingIntent.getActivity(
                    this, 1, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        } else {
            pendingIntent = PendingIntent.getActivity(
                    this, 1, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        }

        int notificationId = SCREEN_RECORDER_NOTIFICATION_ID;
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        String channelName = "balancecheck";
        String description = "balancecheck";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel chan = new NotificationChannel(CHANNEL_ID, channelName, NotificationManager.IMPORTANCE_LOW);
            chan.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            chan.setDescription(description);
            chan.setSound(null, null);
            chan.enableLights(false);
            chan.setLightColor(Color.BLUE);
            chan.enableVibration(false);
            chan.setShowBadge(false);
            if (manager != null) {
                manager.createNotificationChannel(chan);
            }
        }

        int totalMessages = intent.getIntExtra("MsgCount", 0);
        int totalApps = intent.getIntExtra("AccountCount", 0);

        NotificationCompat.Builder notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.account_balance)
                .setContentTitle("All SMS done check bank details")
                .setContentText(totalMessages + "SMS, " + totalApps + " Bank A/c Found.")
                .setAutoCancel(true)
                .setOngoing(false)
                .setContentIntent(pendingIntent);

        if (manager != null) {
            manager.notify(notificationId, notification.build());
        }
    }

}
