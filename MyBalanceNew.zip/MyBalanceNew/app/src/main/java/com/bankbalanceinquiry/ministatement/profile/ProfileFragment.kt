package com.bankbalanceinquiry.ministatement.profile

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.bankbalanceinquiry.ministatement.databinding.FragmentMyMoneyBinding
import com.bankbalanceinquiry.ministatement.databinding.FragmentProfileBinding
import com.bankbalanceinquiry.ministatement.profile.adapter.BankAccountAdapter
import com.bankbalanceinquiry.ministatement.profile.data.BankAccountDao
import com.bankbalanceinquiry.ministatement.profile.data.BankRoomDatabase

class ProfileFragment : Fragment() {
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//    }

//    private val bankViewModel: BankViewModel by activityViewModels {
//        BankViewModelFactory(
//            (activity?.application as MyApplication).bankDatabase.bankAccountDao()
//        )
//    }

    val accountId: Int = 0
    lateinit var bankDao: BankAccountDao
    lateinit var mBinding: FragmentProfileBinding
    lateinit var adapter: BankAccountAdapter
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        mBinding = FragmentProfileBinding.inflate(getLayoutInflater())
//        mBinding = FragmentProfileBinding.inflate(
//            layoutInflater, container, false
//        )

        val bankDatabase = BankRoomDatabase.getDatabase(requireActivity())
//        bankDao = (activity?.applicationContext as MyApplication).bankDatabase.bankAccountDao()
        bankDao = bankDatabase.bankAccountDao()

        adapter = BankAccountAdapter { bankaccount, operation ->

            val intent = Intent(context, InsertProfileActivity::class.java)
            intent.putExtra("account_id", bankaccount.id)
//            startActivity(intent)
            startForResult.launch(intent)

//            val action = BankCategoryFragmentDirections.actionBankCategoryFragmentToBankFinalFragment(it.id)
//            this.findNavController().navigate(action)
        }

        mBinding.recyclerView.layoutManager = LinearLayoutManager(this.context)
        mBinding.recyclerView.adapter = adapter

        getData()
//        mBinding.refreshSwipe.setOnRefreshListener {
//            mBinding.refreshSwipe.isRefreshing = true
//            getData()
//        }

        mBinding.btnAdd.setOnClickListener {
            val intent = Intent(context, InsertProfileActivity::class.java)
//            intent.putExtra("account_id",0)
//            startActivity(intent)
            startForResult.launch(intent)
        }
        return mBinding.root
    }

    val startForResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == Activity.RESULT_OK) {
            getData()
        }
    }

    private fun getData() {

        val accountList = bankDao.getItems()
//        bankViewModel.allAccounts.observe(this.viewLifecycleOwner) { bankAccounts ->
//            bankAccounts.let {

        Log.e("InsertProfile", "accountList:${accountList.size}")
        if (accountList.size > 0) mBinding.llEmpty.visibility = View.GONE
        else mBinding.llEmpty.visibility = View.VISIBLE

        adapter.submitList(accountList)
//        mBinding.refreshSwipe.isRefreshing = false
//            }
//        }
    }

}