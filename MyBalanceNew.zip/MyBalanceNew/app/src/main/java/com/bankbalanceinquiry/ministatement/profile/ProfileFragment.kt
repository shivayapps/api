package com.bankbalanceinquiry.ministatement.profile

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.bankbalanceinquiry.ministatement.databinding.FragmentMyMoneyBinding
import com.bankbalanceinquiry.ministatement.databinding.FragmentProfileBinding
import com.bankbalanceinquiry.ministatement.profile.adapter.BankAccountAdapter
import com.bankbalanceinquiry.ministatement.profile.data.BankAccount
import com.bankbalanceinquiry.ministatement.profile.data.BankAccountDao
import com.bankbalanceinquiry.ministatement.profile.data.BankRoomDatabase

class ProfileFragment : Fragment() {


//    val accountId: Int = 0
    lateinit var bankDao: BankAccountDao
    lateinit var mBinding: FragmentProfileBinding
    lateinit var adapter: BankAccountAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        mBinding = FragmentProfileBinding.inflate(getLayoutInflater())
//        mBinding = FragmentProfileBinding.inflate(
//            layoutInflater, container, false
//        )

        val bankDatabase = BankRoomDatabase.getDatabase(requireActivity())
//        bankDao = (activity?.applicationContext as MyApplication).bankDatabase.bankAccountDao()
        bankDao = bankDatabase.bankAccountDao()

        adapter = BankAccountAdapter(bankAccountList) { bankaccount, operation ->

            if(operation==0){
                //edit
                val intent = Intent(context, InsertProfileActivity::class.java)
                intent.putExtra("account_id", bankaccount.id)
//            startActivity(intent)
                startForResult.launch(intent)
            } else if(operation==1) {
                //delete
                bankDao.delete(bankaccount)
            } else if(operation==2) {
                //share
                shareAccountDetail(bankaccount)
            }

//            val action = BankCategoryFragmentDirections.actionBankCategoryFragmentToBankFinalFragment(it.id)
//            this.findNavController().navigate(action)
        }

        mBinding.recyclerView.layoutManager = LinearLayoutManager(this.context)
        mBinding.recyclerView.adapter = adapter

        getData()
//        mBinding.refreshSwipe.setOnRefreshListener {
//            mBinding.refreshSwipe.isRefreshing = true
//            getData()
//        }

        mBinding.btnAdd.setOnClickListener {
            val intent = Intent(context, InsertProfileActivity::class.java)
//            intent.putExtra("account_id",0)
//            startActivity(intent)
            startForResult.launch(intent)
        }
        return mBinding.root
    }

    val startForResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == Activity.RESULT_OK) {
            getData()
        }
    }

    private fun shareAccountDetail(account: BankAccount){

        val shareNote =
            "Bank Name: ${account.bankName}\n" +
                    "Account Holder Name: ${account.accountHolderName}\n" +
                    "Account No: ${account.accountNo}\n" +
                    "Account Type: ${account.accountType}\n" +
                    "IFSC No: ${account.ifscNo}"

        val myIntent = Intent(Intent.ACTION_SEND)
        myIntent.type = "text/plane"
        myIntent.putExtra(Intent.EXTRA_TEXT, shareNote)
        context?.startActivity(myIntent)
    }

    private val bankAccountList = ArrayList<Any>()
    private fun getData() {

        val accountList = bankDao.getItems()
        bankAccountList.clear()
        bankAccountList.addAll(accountList)
        if(bankAccountList.size>2) {
            bankAccountList.add(1,"adView")
        }
        adapter.notifyDataSetChanged()
//        bankViewModel.allAccounts.observe(this.viewLifecycleOwner) { bankAccounts ->
//            bankAccounts.let {

        Log.e("InsertProfile", "accountList:${bankAccountList.size}")
        if (bankAccountList.size > 0) mBinding.llEmpty.visibility = View.GONE
        else mBinding.llEmpty.visibility = View.VISIBLE

//        adapter.submitList(accountList)
//        mBinding.refreshSwipe.isRefreshing = false
//            }
//        }
    }

}