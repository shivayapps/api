package com.bankbalanceinquiry.ministatement.profile

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.viewmodel.viewModelFactory
import com.bankbalanceinquiry.ministatement.databinding.ActivityViewProfileBinding
import com.bankbalanceinquiry.ministatement.profile.data.BankAccount
import com.bankbalanceinquiry.ministatement.utils.MyApplication
import com.bankbalanceinquiry.ministatement.profile.model.BankViewModel
import com.bankbalanceinquiry.ministatement.profile.model.BankViewModelFactory

class ViewProfileActivity : AppCompatActivity() {


    private val bankViewModel: BankViewModel by viewModels()
//    private val bankViewModel: BankViewModel by activityViewModels {
//        BankViewModelFactory(
//            (application as MyApplication).bankDatabase.bankAccountDao()
//        )
//    }

    lateinit var bankAccount: BankAccount

    lateinit var binding:ActivityViewProfileBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityViewProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }


}