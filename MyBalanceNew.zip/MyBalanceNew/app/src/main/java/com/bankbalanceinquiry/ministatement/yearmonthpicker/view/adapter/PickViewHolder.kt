package com.bankbalanceinquiry.ministatement.yearmonthpicker.view.adapter

import androidx.recyclerview.widget.RecyclerView
import com.bankbalanceinquiry.ministatement.databinding.ItemPickBinding

class PickViewHolder(val binding: ItemPickBinding) : RecyclerView.ViewHolder(binding.root) {
}