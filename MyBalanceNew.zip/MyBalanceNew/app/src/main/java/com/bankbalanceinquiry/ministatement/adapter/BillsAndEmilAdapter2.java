package com.bankbalanceinquiry.ministatement.adapter;

import static com.bankbalanceinquiry.ministatement.utils.Constant.findBankIcon;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.ColorUtils;
import androidx.palette.graphics.Palette;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.common.ReadJsonFile;
import com.bankbalanceinquiry.ministatement.database.DatabaseAccess;
import com.bankbalanceinquiry.ministatement.model.BilsEmiModel;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.amulyakhare.textdrawable.TextDrawable;
import com.marcoscg.dialogsheet.DialogSheet;

import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import de.hdodenhof.circleimageview.CircleImageView;

public class BillsAndEmilAdapter2 extends
        RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final Activity activity;
    //    private final ArrayList<HomeAccoutList> bilsEmiModels;
    private final ArrayList<Object> bilsEmiModels = new ArrayList<>();
    private final String rsString;

    public ClickApkList ApkDetails;
    String[] bankColor_array;

    JSONObject jsonObject;


    private static final int HEADER = 0;
    private static final int ITEM = 1;
    private static final int HEADER_MONTH = 2;

    public interface ClickApkList {
        void ClickValue(int position, BilsEmiModel alldata);
    }

    public void RegisterInterface(ClickApkList photoInterface) {
        this.ApkDetails = photoInterface;
    }

    public BillsAndEmilAdapter2(Activity activity, ArrayList<Object> listOfAllImages) {
        this.activity = activity;
        this.bilsEmiModels.clear();
        this.bilsEmiModels.addAll(listOfAllImages);
        rsString = activity.getString(R.string.Rs);
        List<Integer> adsPos = new ArrayList<>();
        if (bilsEmiModels != null && bilsEmiModels.size() > 0) {
            int size = 0;
            for (int i = 0; i < bilsEmiModels.size(); i++) {
                if (bilsEmiModels.get(i) instanceof String) {
                    if (size > 1) {
                        adsPos.add(i + adsPos.size());
                    }
                    size = 0;
                } else {
                    size = size + 1;
                }
                if (i == (bilsEmiModels.size() - 1)) {
                    if (size > 1) {
                        adsPos.add(i + adsPos.size() + 1);
                    }
                    size = 0;
                }
            }
        }
        /*for (int i = 0; i < adsPos.size(); i++) {
            HomeAccoutList info = new HomeAccoutList();
            info.setType(1);
            bilsEmiModels.add(adsPos.get(i), info);
            notifyItemInserted(adsPos.get(i));
        }*/

        bankColor_array = activity.getResources().getStringArray(R.array.billscolors);
        jsonObject = ReadJsonFile.GetAssetsFileGetDataJsonObject(activity, "sms/bank_list_icons");
    }


//    public void loadNativeAd(AdViewHolder holder1) {
//        holder1.layout_shimmer.setVisibility(View.VISIBLE);
//
//        AdmobAdManager.getInstance().LoadNativeAd(activity, activity.getString(R.string.temp_adx_native_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
////                nativeAd = object;
//                populateNativeAds(holder1, object);
//            }
//
//            @Override
//            public void onAdClosed() {
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
//                holder1.layout_shimmer.setVisibility(View.GONE);
//                removeAdpos(holder1.getAdapterPosition());
//            }
//
//        }, false);
//    }

    public void removeAdpos(int adapterPosition) {
        //  for (int i = 0; i < bilsEmiModels.size(); i++) {
        if (bilsEmiModels.size() > adapterPosition) {
            if (bilsEmiModels.get(adapterPosition) instanceof HomeAccoutList) {
                if (((HomeAccoutList) (bilsEmiModels.get(adapterPosition))).getType() == 1) {
                    bilsEmiModels.remove(adapterPosition);
                    notifyItemRemoved(adapterPosition);
                }
            }
        }

        //  }
      /*  for (int i = 0; i < bilsEmiModels.size(); i++) {
            if (bilsEmiModels.get(i) instanceof HomeAccoutList) {
                if (((HomeAccoutList) (bilsEmiModels.get(i))).getType() == 1) {
                    bilsEmiModels.remove(i);
                    notifyItemRemoved(i);
                    break;
                }
            }
        }*/
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v;
        LayoutInflater layoutInflater = LayoutInflater.from(viewGroup.getContext());
        switch (i) {
            case HEADER:
                v = layoutInflater.inflate(R.layout.native_frame_layout_bill, viewGroup, false);
                return new AdViewHolder(v);
            case HEADER_MONTH:
                v = layoutInflater.inflate(R.layout.date_title_layout, viewGroup, false);
                return new DateHeaderHolder(v);
            default:
                View view = LayoutInflater.from(activity).inflate(R.layout.raw_bills_emi_1, viewGroup, false);
                return new MyViewHolder(view);
        }


    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {
        if (holder.getItemViewType() == ITEM) {
            loadItemData((MyViewHolder) holder, position);
        } else if (holder.getItemViewType() == HEADER_MONTH) {
            DateHeaderHolder holder1 = (DateHeaderHolder) holder;
            String alldata = (String) bilsEmiModels.get(position);
            holder1.txt_title.setText(alldata);

        } else if (holder.getItemViewType() == HEADER) {
//            loadNativeAd((AdViewHolder) holder);

            /*if (nativeAd != null) {
                populateNativeAds((AdViewHolder) holder);
            } else {
                loadNativeAd((AdViewHolder) holder);
            }*/
        }
    }

//    private void populateNativeAds(AdViewHolder holder1, Object nativeAd) {
//        holder1.layout_shimmer.setVisibility(View.GONE);
//        if (nativeAd instanceof NativeAd) {
//            AdmobAdManager.getInstance()
//                    .populateUnifiedSmallNativeAdView(activity, holder1.adLayout, (NativeAd) nativeAd, 3);
//        } /*else {
//            AdmobAdManager.getInstance()
//                    .populateUnifiedSmallNativeApplovin(activity, holder1.adLayout, (MaxNativeAdView) nativeAd, null, false);
//        }*/
//    }


    public class AdViewHolder extends RecyclerView.ViewHolder {

        private final FrameLayout adLayout;
        LinearLayout li_adss;
        FrameLayout layout_shimmer;

        AdViewHolder(View itemView) {
            super(itemView);
            adLayout = itemView.findViewById(R.id.adLayout);
            li_adss = itemView.findViewById(R.id.li_adss);
            layout_shimmer = itemView.findViewById(R.id.layout_shimmer);
        }
    }

    public class DateHeaderHolder extends RecyclerView.ViewHolder {

        private final TextView txt_title;

        DateHeaderHolder(View itemView) {
            super(itemView);
            txt_title = itemView.findViewById(R.id.txt_title);
        }
    }

    private void loadItemData(MyViewHolder holder, int position) {
        final HomeAccoutList alldata = (HomeAccoutList) bilsEmiModels.get(position);
        String mMonth = null, mDate = null, mYear = null;
        String Accountno = alldata.FinalAccountNo;
        if (!TextUtils.isEmpty(Accountno)) {
            holder.tvAccountNo.setVisibility(View.VISIBLE);
            holder.mDot.setVisibility(View.GONE);

            if (alldata.account_type.equalsIgnoreCase("electricity")
                    || alldata.account_type.equalsIgnoreCase("insurance")
                    || alldata.account_type.equalsIgnoreCase("gas")) {
                holder.tvAccountNo.setText(Accountno + "");
            } else {
                holder.tvAccountNo.setText("xxx" + Accountno);
            }
        } else {
            holder.mDot.setVisibility(View.GONE);
            holder.tvAccountNo.setVisibility(View.GONE);
        }

        holder.tvBankName.setText(alldata.full_name);
        String Amount = alldata.amount;
        if (TextUtils.isEmpty(Amount)) {
            Amount = "0";
        }

        String FirstName = alldata.full_name;
        Random rnd = new Random();
        int color;
     /*   int drawable1 = getTransactionImage(alldata.transactionDesc);
        List<bankname> MDetail = new ArrayList<>();*/
        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(activity);
        databaseAccess.open();
    /*    MDetail = databaseAccess.getBalance_details(alldata.full_name);
        boolean isMatched = false;
        if (MDetail.size() > 0) {
            int id = activity.getResources().getIdentifier("ic_" + MDetail.get(0).getB_short().toLowerCase(), "drawable", activity.getPackageName());
            if (id != -1) {
                isMatched = true;
                drawable1 = id;
            }
        }


        if (drawable1 != -1) {
            if (isMatched) {
                holder.ivBankLogo2.setImageResource(drawable1);
                holder.ivBankLogo1.setVisibility(View.GONE);
                holder.ivBankLogo2.setVisibility(View.VISIBLE);
                holder.ivBankLogo.setVisibility(View.GONE);
                Bitmap bb = BitmapFactory.decodeResource(activity.getResources(), drawable1);
                Palette palette = Palette.from(bb).generate();
                // color = palette.getVibrantSwatch().getRgb();
                color = palette.getDarkVibrantColor(ContextCompat.getColor(activity, R.color.colorPrimary));
            } else {
                holder.ivBankLogo.setImageResource(drawable1);
                holder.ivBankLogo1.setVisibility(View.GONE);
                holder.ivBankLogo2.setVisibility(View.GONE);
                holder.ivBankLogo.setVisibility(View.VISIBLE);
                Bitmap bb = BitmapFactory.decodeResource(activity.getResources(), drawable1);
                Palette palette = Palette.from(bb).generate();
                // color = palette.getVibrantSwatch().getRgb();
                color = palette.getDarkVibrantColor(ContextCompat.getColor(activity, R.color.colorPrimary));
            }

        } else {
            holder.ivBankLogo.setVisibility(View.GONE);
            holder.ivBankLogo2.setVisibility(View.GONE);

            holder.ivBankLogo1.setVisibility(View.VISIBLE);
            // int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
            color = Color.parseColor(bankColor_array[rnd.nextInt(bankColor_array.length)]);

            if (!TextUtils.isEmpty(FirstName) && !FirstName.equalsIgnoreCase("")) {
                String FirstLetter = FirstName.substring(0, 1);
                TextDrawable drawable = TextDrawable.builder()
                        .buildRound(FirstLetter, color);
                holder.ivBankLogo1.setImageDrawable(drawable);
               *//* Palette palette = Palette.from(bb).generate();
                color = palette.getVibrantSwatch().getRgb();*//*

            } else {
                TextDrawable drawable = TextDrawable.builder()
                        .buildRound("U", color);
                holder.ivBankLogo1.setImageDrawable(drawable);
            }

        }*/

        holder.ivBankLogo1.setVisibility(View.GONE);
        holder.ivBankLogo2.setVisibility(View.VISIBLE);
        holder.ivBankLogo.setVisibility(View.GONE);


        String nameImage = findBankIcon(activity, alldata.full_name, jsonObject);
        int id = activity.getResources().getIdentifier(/*"ic_" +*/ nameImage, "drawable", activity.getPackageName());

        if ((nameImage != null) && !(TextUtils.isEmpty(nameImage)) && (id != -1)) {
            holder.ivBankLogo2.setVisibility(View.VISIBLE);

            holder.ivBankLogo2.setImageResource(id);
            Bitmap bb = BitmapFactory.decodeResource(activity.getResources(), id);
            Palette palette = Palette.from(bb).generate();
            color = palette.getDarkVibrantColor(ContextCompat.getColor(activity, R.color.colorPrimary));
        } else {
            holder.ivBankLogo2.setVisibility(View.VISIBLE);
            // int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
            color = Color.parseColor(bankColor_array[rnd.nextInt(bankColor_array.length)]);
            if (!TextUtils.isEmpty(FirstName) && !FirstName.equalsIgnoreCase("")) {
                String FirstLetter = FirstName.substring(0, 1);
                TextDrawable drawable = TextDrawable.builder()
                        .buildRound(FirstLetter, color);
                holder.ivBankLogo2.setImageDrawable(drawable);

            } else {
                TextDrawable drawable = TextDrawable.builder()
                        .buildRound("U", color);
                holder.ivBankLogo2.setImageDrawable(drawable);
            }
        }


        int colorTransparent = ColorUtils.setAlphaComponent(color, 25);
        holder.card_amount.setCardBackgroundColor(color);
        holder.li_Title.setBackgroundColor(colorTransparent);


        String PayNowPaid = "0";

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yy");

        DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
        Date date = new Date();

        String TodayDatefind = dateFormat.format(date);
        String TodayDate = TodayDatefind.toUpperCase();
        Date date1 = null, date2 = null;
        try {
            date1 = simpleDateFormat.parse(TodayDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        String dueDate = "";
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("EEE,dd MMM", Locale.US);

        if (alldata.dateFormats.size() != 0) {
            if (TextUtils.isEmpty(alldata.date)) {
                if (alldata.dates.size() != 0) {
                    alldata.date = alldata.dates.get(0);
                }
            }
            if (!TextUtils.isEmpty(alldata.date)) {
                for (String format : alldata.dateFormats) {
                    SimpleDateFormat format1 = new SimpleDateFormat(format, Locale.US);
                    try {
                        date2 = format1.parse(alldata.date);
                        SimpleDateFormat monthFormate = new SimpleDateFormat("MMM", Locale.US);
                        SimpleDateFormat dateFormate = new SimpleDateFormat("dd", Locale.US);
                        SimpleDateFormat yearFormate = new SimpleDateFormat("yyyy", Locale.US);
                        mMonth = monthFormate.format(date2);
                        mDate = dateFormate.format(date2);
                        mYear = yearFormate.format(date2);
                        dueDate = simpleDateFormat2.format(date2);
                        break;
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        if (TextUtils.isEmpty(alldata.date)) {
            if (alldata.use_sms_time) {
                alldata.date = alldata.dateValHistory;
            }
        }

        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd MMM yyyy", Locale.US);
        if (TextUtils.isEmpty(mMonth) && TextUtils.isEmpty(mDate) && TextUtils.isEmpty(mYear)) {
            SimpleDateFormat monthFormate = new SimpleDateFormat("MMM", Locale.US);
            SimpleDateFormat dateFormate = new SimpleDateFormat("dd", Locale.US);
            SimpleDateFormat yearFormate = new SimpleDateFormat("yyyy", Locale.US);
            try {
                Date date3 = simpleDateFormat1.parse(alldata.date);
                if (date3 != null) {
                    mMonth = monthFormate.format(date3);
                    mDate = dateFormate.format(date3);
                    mYear = yearFormate.format(date3);
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }


        SimpleDateFormat monthFormate = new SimpleDateFormat("MMM", Locale.US);
        SimpleDateFormat dateFormate = new SimpleDateFormat("dd", Locale.US);
        SimpleDateFormat yearFormate = new SimpleDateFormat("yyyy", Locale.US);
        try {
            Date date3 = simpleDateFormat1.parse(alldata.dateValAccount);
            if (date3 != null) {
                if (TextUtils.isEmpty(dueDate)) {
                    dueDate = simpleDateFormat2.format(date3);
                }
                mMonth = monthFormate.format(date3);
                mDate = dateFormate.format(date3);
                mYear = yearFormate.format(date3);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        holder.li_date.setText(dueDate + "");


        if (!TextUtils.isEmpty(mMonth) && !TextUtils.isEmpty(mDate) && !TextUtils.isEmpty(mYear)) {
            holder.tvDateMonth.setText(mMonth);
            holder.tvDate.setText(mDate);
            holder.tvDate_year.setText(mYear);
        }


        String FinalPendingDay = null;
        if (date1 != null && date2 != null) {
            FinalPendingDay = String.valueOf(printDifference(date1, date2));
        }

        if (!TextUtils.isEmpty(FinalPendingDay)) {
            try {
                double value = Double.parseDouble(FinalPendingDay);
                if (value < 0) {
                    PayNowPaid = "0";
                } else {
                    PayNowPaid = FinalPendingDay;
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }

        if (TextUtils.equals("0", PayNowPaid)) {
            holder.llPayNowPaid.setVisibility(View.GONE);
//            holder.tvPaidUnPaid.setText("Paid");
//            holder.tvDate.setText("Paid on: " + alldata.date);
//            holder.tvDate.setTextColor(ContextCompat.getColor(activity, R.color.rs_emi_paid));
            //      holder.tvAmount.setTextColor(ContextCompat.getColor(activity, R.color.rs_emi_paid));
            holder.ivDayToPay.setVisibility(View.GONE);
//            holder.ivPaid.setImageResource(R.drawable.ic_bill_emi_done);
            holder.ivPaid.setVisibility(View.GONE);
            //
        } else {
            holder.llPayNowPaid.setVisibility(View.GONE);
//            holder.tvPaidUnPaid.setText("Day to pay");
//            holder.tvDate.setText("Due on: " + alldata.date);
//            holder.tvDate.setTextColor(ContextCompat.getColor(activity, R.color.colorPrimary));
            // holder.tvAmount.setTextColor(ContextCompat.getColor(activity, R.color.rs_emi_due));

            if (!TextUtils.isEmpty(FinalPendingDay)) {
                //String FirstLetter = FirstName.substring(0, 1);
                TextDrawable drawable = TextDrawable.builder()
                        .buildRound(FinalPendingDay, Color.parseColor("#faa43a"));
                holder.ivPaid.setImageDrawable(drawable);
            } else {
                TextDrawable drawable = TextDrawable.builder()
                        .buildRound("0", Color.parseColor("#faa43a"));
                holder.ivPaid.setImageDrawable(drawable);
            }

        }
        if (!TextUtils.isEmpty(alldata.transactionPos)) {
            holder.txt_pos.setVisibility(View.VISIBLE);

            holder.txt_pos.setText(alldata.transactionPos);
        } else {
            holder.txt_pos.setVisibility(View.GONE);
        }
        holder.txt_desc.setText(alldata.transactionDesc);
        holder.tvAmount.setText(rsString + " " + Amount);


        holder.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DialogSheet(activity)
                        .setTitle("Account no" + (alldata.FinalAccountNo.length() < 4 ? " - X" : " - ") + alldata.FinalAccountNo)
                        .setMessage(alldata.body)
                        .setColoredNavigationBar(true)
                        .setTitleTextSize(20)
                        .setButtonsTextSize(15)
                        .setBackgroundColor(Color.WHITE)
                        .show();
            }
        });
    }

    private int getTransactionImage(String transactionType) {
        switch (transactionType) {
            case "Your Account Balance":
                return R.drawable.your_account_balance_1;
            case "UPI Transaction":
                return R.drawable.upi_transaction_1;
            case "Debit Card Transaction":
                return R.drawable.debit_card_transaction_1;
            case "Net Banking":
                return R.drawable.net_banking_1;
            case "Credited to your Account":
                return R.drawable.credited_to_your_account_1;
            case "Cheque Transaction":
                return R.drawable.cheque_transaction_1;
            case "ATM withdrawal":
                return R.drawable.atm_withdrawal_1;
            case "Credit Card Transaction":
                return R.drawable.credit_card_transaction_1;
            case "Credit Card Bill":
                return R.drawable.credit_card_bill_1;
            case "Loan EMI":
                return R.drawable.loan_emi_1;
            case "Mobile Bill":
                return R.drawable.mobile_bill_1;
            case "Prepaid Debit Card Transaction":
                return R.drawable.prepaid_debit_card_transaction_1;
            case "Bill":
                return R.drawable.bill_1;
            case "Internet Bill":
                return R.drawable.internet_bill_1;
            case "Electricity Bill":
                return R.drawable.electricity_bill_1;
            case "Insurance Premium":
                return R.drawable.insurance_premium_1;
            case "Gas Bill":
                return R.drawable.gas_bill_1;
        }
        return -1;
    }

    @Override
    public int getItemViewType(int position) {
        if (bilsEmiModels.get(position) instanceof HomeAccoutList) {
            if (((HomeAccoutList) (bilsEmiModels.get(position))).getType() == 0) {
                return ITEM;
            } else {
                return HEADER;
            }
        } else {
            return HEADER_MONTH;
        }

    }

    @Override
    public int getItemCount() {
        return bilsEmiModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private final LinearLayout llMain;
        private final LinearLayout llPayNowPaid;
        private final TextView tvAccountNo;
        private final TextView mDot;
        private final CircleImageView ivBankLogo;
        ImageView ivBankLogo1, ivBankLogo2;
        private final TextView tvBankName;
        private final ImageView ivDayToPay;
        private final ImageView ivPaid;
        //        private TextView tvPaidUnPaid;
        private final TextView tvAmount;
        private final TextView txt_pos;
        private final TextView tvDate;
        private final TextView tvDateMonth;
        private final TextView tvDate_year;
        private final TextView txt_desc;
        CardView card_amount;
        TextView li_Title, li_date;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            li_Title = itemView.findViewById(R.id.li_Title);
            card_amount = itemView.findViewById(R.id.card_amount);
            llMain = itemView.findViewById(R.id.llMain);
            li_date = itemView.findViewById(R.id.li_date);
            ivBankLogo = itemView.findViewById(R.id.ivBankLogo);
            ivBankLogo1 = itemView.findViewById(R.id.ivBankLogo1);
            ivBankLogo2 = itemView.findViewById(R.id.ivBankLogo2);
            tvBankName = itemView.findViewById(R.id.tvBankName);
            tvAccountNo = itemView.findViewById(R.id.tvAccountNo);
            tvDateMonth = itemView.findViewById(R.id.tvDate_month);
            mDot = itemView.findViewById(R.id.dot);
            ivDayToPay = itemView.findViewById(R.id.ivDayToPay);
            ivPaid = itemView.findViewById(R.id.ivPaid);
            tvDate_year = itemView.findViewById(R.id.tvDate_year);
//            tvPaidUnPaid = itemView.findViewById(R.id.tvPaidUnPaid);
            tvAmount = itemView.findViewById(R.id.tvAmount);
            tvDate = itemView.findViewById(R.id.tvDate);
            llPayNowPaid = itemView.findViewById(R.id.llPayNowPaid);
            txt_desc = itemView.findViewById(R.id.txt_desc);
            txt_pos = itemView.findViewById(R.id.txt_pos);
        }
    }


    public long printDifference(Date startDate, Date endDate) {
        //milliseconds
        Log.e("DateDifference==<", " \n TodayDateStart" + startDate + "" +
                " \n DudateDateendDate" + endDate + ""
        );
        long different = endDate.getTime() - startDate.getTime();
        System.out.println("startDate : " + startDate);
        System.out.println("endDate : " + endDate);
        System.out.println("different : " + different);

        long secondsInMilli = 1000;
        long minutesInMilli = secondsInMilli * 60;
        long hoursInMilli = minutesInMilli * 60;
        long daysInMilli = hoursInMilli * 24;

        long elapsedDays = different / daysInMilli;
        different = different % daysInMilli;

        long elapsedHours = different / hoursInMilli;
        different = different % hoursInMilli;

        long elapsedMinutes = different / minutesInMilli;
        different = different % minutesInMilli;

        long elapsedSeconds = different / secondsInMilli;

        Log.e("DayyyPending", elapsedDays + "");
        System.out.printf(
                "%d days, %d hours, %d minutes, %d seconds%n",
                elapsedDays, elapsedHours, elapsedMinutes, elapsedSeconds);
        return elapsedDays;
    }
}
