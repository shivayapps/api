package com.bankbalanceinquiry.ministatement.model;

import java.io.Serializable;

public class BilsEmiModel implements Serializable {

    private String AccountNo;
    private String Amount;
    private String Date;
    private String BankName;
    private int icon;
    private String DisplayPaynow;
    private String FinalPendingDay="";

    public BilsEmiModel(String accountNo, String amount,
                        String date, String bankName,
                        int icon,String DisplayPaynow,String FinalPendingDay) {
        AccountNo = accountNo;
        Amount = amount;
        Date = date;
        BankName = bankName;
        this.icon = icon;
        this.DisplayPaynow = DisplayPaynow;
        this.FinalPendingDay = FinalPendingDay;
    }

    public String getAccountNo() {
        return AccountNo;
    }

    public void setAccountNo(String accountNo) {
        AccountNo = accountNo;
    }

    public String getAmount() {
        return Amount;
    }

    public void setAmount(String amount) {
        Amount = amount;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getBankName() {
        return BankName;
    }

    public void setBankName(String bankName) {
        BankName = bankName;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getDisplayPaynow() {
        return DisplayPaynow;
    }

    public void setDisplayPaynow(String displayPaynow) {
        DisplayPaynow = displayPaynow;
    }


    public String getFinalPendingDay() {
        return FinalPendingDay;
    }

    public void setFinalPendingDay(String finalPendingDay) {
        FinalPendingDay = finalPendingDay;
    }
}
