package com.bankbalanceinquiry.ministatement.utils;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.text.TextUtils;
import android.util.Log;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Constant {
    public final static String SHARED_PREFS = "MyBalance";

//    public static int isInterstitialCount = 1;
//    public static int adShowCount = 1;
//    public static int removeAdCount = 0;
    public static String LOGIN_PREF = "login_pref";
    public static String LANG_PREF = "lang_pref";
    public static String LANG_SELECTED = "lang_selected";
    public static String TRACK_PREF = "track_pref";
    public static String IS_FIRST_LOADING_DONE = "is_first_loading_done";

    public static String[] TRACK_TITLE = new String[]{"YOUR MONEY MADE SIMPLE", "BILL REMINDERS", "ATM CASH DETAILS", "KNOW YOUR EXPENSES"};
    public static String[] TRACK_DESCRIPTION = new String[]{
            "Transform your SMS inbox into\na daily interactive report",
            "Automatic billdetection. \n No more late fees",
            "See All your\nWithdrawals in one place",
            "Calculate Your budget\naccording your expenses"};

    public static String PREF_SHOW_PLATEFORM_ID = "show_plateform_id";
    public static String PREF_NATIVE_AD_ID = "native_ad_id";
    public static String PREF_BANNER_AD_ID = "banner_ad_id";
    public static String PREF_INTERSIAL_AD_ID = "intersial_ad_id";
    public static String PREF_ADMOB_UNIT_ID = "admob_unit_id";
    public static String PREF_APP_OPEN_ID = "admob_unit_id";

    public static String NATIVE_AD_KEY = "native_id";
    public static String INTERSIAL_AD_KEY = "interstitial_id";
    public static String BANNER_AD_KEY = "banner_id";
    public static String UNIT_AD_KEY = "app_id";
    public static String APP_OPEN_AD_KEY = "app_open_id";

    public static String APP_NEXT_AD_KEY = "appnext";
    public static String FACEBOOK_AD_KEY = "facebook";
    public static String ADMOB_AD_KEY = "admob";
    public static String SHOW_PLATEFORM_AD_KEY = "showplatform";

    public static String Last_Time_Show_Interstitial = "lastTimeShowInterstitial";

    public static boolean isFromLanguage = false;
    public static boolean isShplashScreen = false;
    public static boolean isFirsttimeshow = false;

    public static String PREF_Notification_ID = "PREF_Notification_ID";
    public static final String DEFAULT_NOTIFICATION_NAME = "BankBalance Default Notification";

    public static void setLocale(Context activity) {
        String languageCode = PreferenceHelper.getFromUserDefaults(activity, Constant.LANG_PREF, "en");
        Locale locale = new Locale(languageCode);
        Locale.setDefault(locale);
        Resources resources = activity.getResources();
        Configuration config = resources.getConfiguration();
        config.setLocale(locale);
        resources.updateConfiguration(config, resources.getDisplayMetrics());
    }


    public static String generateHtmlString1(ArrayList<HomeAccoutList> dataSetFinal, String bankName,
                                             String balance, int bgColor, String type, Context context) {
        int r = (bgColor >> 16) & 0xFF;
        int g = (bgColor >> 8) & 0xFF;
        int b = (bgColor >> 0) & 0xFF;
        String hexColor = String.format("%#06X", (0xFFFFFF & bgColor));

        String colorBg = "rgb(" + r + "," + g + "," + b + ",0.2)";
        String colorBg1 = "rgb(" + r + "," + g + "," + b + ")";
        String finalString = "";
        String header = "<html>\n" +
                "  <head>\n" +
                "    <title>SMS</title>\n" +
                "    <meta\n" +
                "      name=\"viewport\"\n" +
                "      content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\"\n" +
                "    />\n" +
                "    <style>\n" +
                "      .text-success {\n" +
                "        color: " + "#0F9D58" + ";\n" +
                "      }\n" +
                "      .text-danger {\n" +
                "        color: #cd5151;\n" +
                "      }\n" +
                "\n" + "\n" +
                "      .text-danger1 {\n" +
                "        color: " + colorBg1 + ";\n" +
                "      }" +
                "      .bg-danger {\n" +
                "        background-color: " + colorBg + ";\n" +
                "      }\n" +
                "\n" +
                "      table {\n" +
                "        width: 100%;\n" +
                "        border: 1px solid black !important;\n" +
                "        border-collapse: collapse;\n" +
                "      }\n" +
                "\n" +
                "      td {\n" +
                "        padding: 5px;\n" +
                "        border: none;\n" +
                "        outline: none;\n" +
                "      }\n" +
                "\n" +
                "      .info-padding {\n" +
                "        padding: 20px 5px;\n" +
                "      }\n" +
                "\n" +
                "      .text-grey {\n" +
                "        color: grey;\n" +
                "        text-align: center;\n" +
                "      }\n" +
                "\n" +
                "      .float-right {\n" +
                "        float: right;\n" +
                "      }\n" +
                "\n" +
                "      .border-bottom {\n" +
                "        border-bottom: 1px solid lightgrey;\n" +
                "      }\n" +
                "\n" +
                "      .text-center {\n" +
                "        text-align: center;\n" +
                "      }\n" +
                "    </style>\n" +
                "  </head>";
        String body_1 = "<body>\n" +
                "    <h3 class=\"text-center\" style=\"margin-top: 5%\">" + bankName + "</h3>\n" +
                "    <h3 class=\"text-center\">" + balance + "</h3>\n" +
                "    <table>";
        String tableData = "";
        for (int i = 0; i < dataSetFinal.size(); i++) {
            HomeAccoutList homeAccoutList = dataSetFinal.get(i);
            if (homeAccoutList.GetTitleType == 0) {
                tableData = tableData + "<tr class=\"bg-danger border-bottom\">\n" +
                        "        <td\n" +
                        "          colspan=\"2\"\n" +
                        "          class=\"text-danger1\"\n" +
                        "          style=\"width: 20%; font-weight: bold; padding: 20px\"\n" +
                        "        >\n" +
                        "          " + homeAccoutList.DateTransactionHistory + "\n" +
                        "        </td>";
                String AmoutCredited = CallAccountBalanceTesting(homeAccoutList.CreditedData);
                String AmoutDebited = CallAccountBalanceTesting(homeAccoutList.DebitedData);

                if (type.equalsIgnoreCase("All")) {
                    tableData = tableData + "<td>\n" +
                            "          <span class=\"text-success float-right\">+ &#8377; " + AmoutCredited + "</span>\n" +
                            "          <br />\n" +
                            "          <span class=\"text-danger float-right\">- &#8377; " + AmoutDebited + "</span>\n" +
                            "        </td>\n" +
                            "      </tr>";
                } else if (type.equalsIgnoreCase("Debited")) {
                    tableData = tableData + " <td>\n" +
                            "           <span class=\"text-danger float-right\">- &#8377; " + AmoutDebited + "</span>\n" +
                            "        </td>\n" +
                            "      </tr>";
                } else {
                    tableData = tableData + "<td>\n" +
                            "          <span class=\"text-success float-right\">+ &#8377; " + AmoutCredited + "</span>\n" +
                            "        </td>\n" +
                            "      </tr>";
                }
            } else {
                SimpleDateFormat formatterHistory = new SimpleDateFormat("dd MMMM yyyy, hh:mm aa", Locale.US);
                SimpleDateFormat formatterHistory1 = new SimpleDateFormat("dd MMM", Locale.US);
                Date date3 = null;
                try {
                    date3 = formatterHistory.parse(homeAccoutList.dateValHistory);
                    homeAccoutList.dateValHistory = formatterHistory1.format(date3);

                } catch (ParseException e) {
                    e.printStackTrace();
                }
                String dataDescription;
                if (!TextUtils.isEmpty(homeAccoutList.finalTransactionDesc)) {
                    dataDescription = homeAccoutList.finalTransactionDesc + " ";
                } else {
                    if (TextUtils.isEmpty(homeAccoutList.transactionDesc)) {
                        if (homeAccoutList.isDebited) {
                            dataDescription = context.getResources().getString(R.string.debited);
                        } else {
                            dataDescription = context.getResources().getString(R.string.credited);
                        }
                    } else {
                        dataDescription = homeAccoutList.transactionDesc + " ";
                    }
                }


                String Amout = homeAccoutList.amount;
                if (TextUtils.isEmpty(Amout)) {
                    Amout = "0";
                }
                if (Amout.contains(",")) {
                    Amout = Amout.replace(",", "");
                }
                double d = Double.parseDouble(Amout);
                NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
                DecimalFormat decim = (DecimalFormat) nf;
                decim.applyPattern("#,##,###.##");
                if (Amout.contains(".")) {
                    String afterPoint = Amout.substring(Amout.indexOf(".") + 1);
                    if (afterPoint.length() > 2) {
                        Amout = decim.format(d);
                    }
                }
                Amout = decim.format(d);

                String dateVal = homeAccoutList.dateValHistory;
                String classname = "text-danger";
                if (homeAccoutList.isDebited) {
                    classname = "text-danger";
                } else {
                    classname = "text-success";
                }
                if (i == (dataSetFinal.size() - 1)) {
                    tableData = tableData + "<tr>\n" +
                            "        <td class=\"text-grey\" style=\"width: 20%\">" + dateVal + "</td>\n" +
                            "        <td class=\"info-padding\">" + dataDescription + "</td>\n" +
                            "        <td>\n" +
                            "          <span class=\"" + classname + " float-right\">&#8377; " + Amout + "</span>\n" +
                            "        </td>\n" +
                            "      </tr>";
                } else {
                    tableData = tableData + "<tr>\n" +
                            "        <td class=\"text-grey\" style=\"width: 20%\">" + dateVal + "</td>\n" +
                            "        <td class=\"border-bottom info-padding\">" + dataDescription + "</td>\n" +
                            "        <td class=\"border-bottom\">\n" +
                            "          <span class=\"" + classname + " float-right\">&#8377; " + Amout + "</span>\n" +
                            "        </td>\n" +
                            "      </tr>\n" +
                            "      <tr>";
                }

            }
        }

        String body_2 = "</table>\n" +
                "  </body>\n" +
                "</html>";
        finalString = finalString + header + body_1 + tableData + body_2;
        Log.e("SJKBHcjab", finalString + "::");

        return finalString;
    }


    private static String CallAccountBalanceTesting(ArrayList<String> tempList) {
        double sum = 0;
        for (int i = 0; i < tempList.size(); i++) {
            String AmoutValue = tempList.get(i);
            if (!TextUtils.isEmpty(AmoutValue)) {
                double value = Double.parseDouble(AmoutValue);
                sum += value;
            }
        }
        String s = String.valueOf(sum);
        NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
        DecimalFormat decim = (DecimalFormat) nf;
        decim.applyPattern("#,##,###.##");
        if (s.contains(".")) {
            String afterPoint = s.substring(s.indexOf(".") + 1);
            if (afterPoint.length() > 2) {
                return decim.format(sum);
            }
        }
        return decim.format(sum);
//        return String.valueOf(CommonFun.findSum(finalallbalance.toString()));
    }




    public static String findBankIcon(Context context,String bankName, JSONObject jsonObject) {
        JSONArray jsonArray = jsonObject.optJSONArray("rules");
        if (jsonArray != null) {
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.optJSONObject(i);
                if (obj != null) {
                    String bankData = obj.optString("full_name");
                    String imageData = obj.optString("image");
                    if (bankData != null) {
                        if (bankName.trim().equalsIgnoreCase(bankData.trim())) {
                            return imageData;
                        }
                    }

                }

            }
        }
        return "";
    }


}
