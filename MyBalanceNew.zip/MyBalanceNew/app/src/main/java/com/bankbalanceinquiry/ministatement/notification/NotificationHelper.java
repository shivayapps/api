package com.bankbalanceinquiry.ministatement.notification;

import static android.content.Context.ALARM_SERVICE;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class NotificationHelper {
    private final Context mContext;

    NotificationHelper(Context context) {
        mContext = context;
    }

    void createNotification() {
        String[] keys = new String[]{"loan", "prepaid", "phone", "credit_card", "generic", "electricity", "insurance", "gas"};
        ArrayList<HomeAccoutList> bilEmiModels = new ArrayList<>();
        DBHelperAccountNew myDbBill = new DBHelperAccountNew(mContext);
        for (String keyItem : keys)
            bilEmiModels.addAll(myDbBill.GetSpecificBills(keyItem));

        for (HomeAccoutList bilItem : bilEmiModels) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
            try {
                //SimpleDateFormat sdf = new SimpleDateFormat("dd MMMMM yyyy", Locale.US);
                SimpleDateFormat sdf = new SimpleDateFormat("dd MMMMM yyyy, hh:mm a", Locale.US);
                Date date = sdf.parse(bilItem.dateValHistory);
                long billTimeInMillis = date.getTime();

                Calendar billDateCalendar = Calendar.getInstance();
                billDateCalendar.setTimeInMillis(billTimeInMillis);
                String eventItemDate = dateFormat.format(billDateCalendar.getTime());

                Calendar tomorrowDateCalendar = Calendar.getInstance();
                tomorrowDateCalendar.setTimeInMillis(Calendar.getInstance().getTimeInMillis() + (24 * 60 * 60 * 1000));
                int tomorrowDayMonth = tomorrowDateCalendar.get(Calendar.MONTH) + 1;
                int tomorrowDay = tomorrowDateCalendar.get(Calendar.DAY_OF_MONTH);

                String[] splitTime = eventItemDate.split("-");
                if (splitTime[0] != null && splitTime[1] != null && splitTime[2] != null &&
                        Integer.parseInt(splitTime[0]) == tomorrowDay &&
                        Integer.parseInt(splitTime[1]) == tomorrowDayMonth) {
                    long finalNotificationTime = tomorrowDateCalendar.getTimeInMillis() - (24 * 60 * 60 * 1000);
                    Intent intent = new Intent(mContext, EventNotificationReceiver.class);
                    intent.putExtra("title", bilItem.sms_type);
                    intent.putExtra("amount", bilItem.amount);
                    if (bilItem.full_name == null)
                        intent.putExtra("description", "Description not provided");
                    else
                        intent.putExtra("description", bilItem.full_name);
                    PendingIntent pendingIntent = null;
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        pendingIntent = PendingIntent.getBroadcast(mContext, PreferenceHelper.getNotificationRequestCode(mContext), intent, PendingIntent.FLAG_IMMUTABLE);
                    }else {
                        pendingIntent = PendingIntent.getBroadcast(mContext, PreferenceHelper.getNotificationRequestCode(mContext), intent, PendingIntent.FLAG_UPDATE_CURRENT);
                    }
                    AlarmManager alarmManager = (AlarmManager) mContext.getSystemService(ALARM_SERVICE);
                    if (alarmManager != null) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, finalNotificationTime, pendingIntent);
                        else
                            alarmManager.setExact(AlarmManager.RTC_WAKEUP, finalNotificationTime, pendingIntent);
                        PreferenceHelper.setNotificationRequestCode(mContext, PreferenceHelper.getNotificationRequestCode(mContext) + 1);
                    }
                    Log.e("TAG", "database notification time: " + finalNotificationTime);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
