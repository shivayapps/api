package com.bankbalanceinquiry.ministatement.Admanager;

public interface appOpenLifeCycleChange {

    void onForeground();
    void onBackground();
}