package com.adconfig.adsutil.admob

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.lifecycle.ProcessLifecycleOwner
import com.google.android.gms.ads.*
import com.google.android.gms.ads.appopen.AppOpenAd
import java.util.*

//class AppOpenAdsManager(
//  private val appApplication: Application
//) : LifecycleObserver, Application.ActivityLifecycleCallbacks {
//
//  private var ad: AppOpenAd? = null
//  private var activity: Activity? = null
//  private var loadTime: Long = 0
//  private var showed = false
//
//  init {
//    appApplication.registerActivityLifecycleCallbacks(this)
//    ProcessLifecycleOwner.get().lifecycle.addObserver(this)
//  }
//
//  @OnLifecycleEvent(Lifecycle.Event.ON_START)
//  fun onAppForeground() {
//    load()
//  }
//
//  @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
//  fun onAppBackground() {
//  }
//
//  override fun onActivityResumed(activity: Activity) {
//    this.activity = activity
//    load()
//  }
//
//  override fun onActivityDestroyed(activity: Activity) {
//    this.activity = null
//  }
//
//  override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
//  override fun onActivityStarted(activity: Activity) = Unit
//  override fun onActivityPaused(activity: Activity) = Unit
//  override fun onActivityStopped(activity: Activity) = Unit
//  override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
//
//
//  private fun load() {
//    if (loaded) {
//      show()
//    } else {
//      val loadCallback = object : AppOpenAd.AppOpenAdLoadCallback() {
//        override fun onAdLoaded(appOpenAd: AppOpenAd) {
//          this@AppOpenAdsManager.ad = ad
//          loadTime = Date().time
//          show()
//        }
//
//        override fun onAdFailedToLoad(loadAdError: LoadAdError) {
//          Log.i("ADCONFIG_OpnedAdManager", "onAdFailedToLoad:"+loadAdError.message)
//
//        }
//      }
//      AppOpenAd.load(
//        appApplication, UNIT_ID, AdRequest.Builder().build(),
//        AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback
//      )
//    }
//  }
//
//  private fun show() {
//    if (showed) return
//
//    val contentCallback = object : FullScreenContentCallback() {
//      override fun onAdShowedFullScreenContent() {
//        showed = true
//      }
//      override fun onAdDismissedFullScreenContent() {
//        this@AppOpenAdsManager.ad = null
//        showed = false
//        load()
//      }
//      override fun onAdFailedToShowFullScreenContent(adError: AdError) = Unit
//    }
//    this.ad?.apply {
//      fullScreenContentCallback = contentCallback
//      activity?.run {
//        show(this)
//      }
//    }
//
//  }
//
//  private val loaded: Boolean
//    get() = ad != null && Date().time - loadTime < 60 * 60 * 1000 * LIFETIME_HOUR
//
//  companion object {
////    private const val UNIT_ID = "ca-app-pub-3940256099942544/3419835294" // TEST ID
//    private const val LIFETIME_HOUR = 4
//  }
//
//}