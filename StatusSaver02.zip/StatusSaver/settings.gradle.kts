pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
        maven { setUrl("https://maven.google.com/") }
        maven { setUrl("https://jitpack.io") }
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { setUrl("https://maven.google.com/") }
        maven { setUrl("https://jitpack.io") }
    }
}
include(":app")
include(":ads")

//google.com, pub-2750800778809761, DIRECT, f08c47fec0942fa0
//https://www.transfernow.net/dl/20250401eoxlnWWu
