plugins {
    alias(libs.plugins.agp)
    alias(libs.plugins.kotlin.android)
    id("kotlin-parcelize")
    alias(libs.plugins.google.ksp)
    alias(libs.plugins.androidx.safeargs)
    alias(libs.plugins.crashlytics)
    id("com.google.gms.google-services")
}

android {
    compileSdk = 35
    namespace = "com.statussaver"

    defaultConfig {
        minSdk = 24
        targetSdk = 34

        applicationId = "com.quickgrab.statussaver.download"
        versionCode = 13
        versionName = "1.3"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro")
//            signingConfig = releaseSigning
        }
        debug {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro")
//            signingConfig = releaseSigning
        }
    }
//    flavorDimensions += "version"
//    productFlavors {
//        create("normal") {
//            dimension = "version"
//        }
//        create("fdroid") {
//            dimension = "version"
//            versionNameSuffix = " (F-Droid)"
//        }
//    }

    flavorDimensions("default")
    productFlavors {

        create("TestAd") {
            isDefault = true

            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")

            resValue("string", "b_homeActivity", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "b_toolsActivity", "ca-app-pub-3940256099942544/9214589741")

            resValue("string", "native_language", "ca-app-pub-3940256099942544/2247696110")

            resValue("string", "inter_language", "ca-app-pub-3940256099942544/1033173712")

            resValue("string", "open_splash", "ca-app-pub-3940256099942544/9257395921")
            resValue("string", "open_all", "ca-app-pub-3940256099942544/9257395921")
        }
        create("LiveAd") {
            isDefault = false

            resValue("string", "ads_application_id", "ca-app-pub-2750800778809761~5232957440")

            resValue("string", "b_homeActivity", "ca-app-pub-2750800778809761/1607738903")
            resValue("string", "b_toolsActivity", "ca-app-pub-2750800778809761/2496312570")

            resValue("string", "native_language", "ca-app-pub-2750800778809761/7981575560")

            resValue("string", "inter_language", "ca-app-pub-2750800778809761/6668493897")

            resValue("string", "open_splash", "ca-app-pub-2750800778809761/8423933859")
            resValue("string", "open_all", "ca-app-pub-2750800778809761/5355412223")
        }
    }
    applicationVariants.all {
        outputs.all {
            (this as com.android.build.gradle.internal.api.BaseVariantOutputImpl).outputFileName =
                "WhatSave-v${defaultConfig.versionName}-${name}.apk"
        }
    }
    buildFeatures {
        buildConfig = true
        viewBinding = true
    }
    androidResources {
        generateLocaleConfig = true
    }
    packaging {
        resources {
            excludes += listOf("META-INF/LICENSE", "META-INF/NOTICE", "META-INF/java.properties")
        }
    }
    lint {
        abortOnError = true
        warning += listOf("ImpliedQuantity", "Instantiatable", "MissingQuantity", "MissingTranslation")
    }
    kotlinOptions {
        freeCompilerArgs += "-opt-in=kotlin.RequiresOptIn"
    }
    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }
}

kotlin {
    jvmToolchain(21)
}

dependencies {
    //https://developer.android.com/jetpack/androidx/versions
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.splashscreen)
    implementation(libs.androidx.annotation)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.fragment.ktx)

    implementation("com.android.support:multidex:2.0.0")
//    api("androidx.multidex:multidex:multidex:2.0.0")
    implementation(libs.lifecycle.runtime.ktx)
    implementation(libs.lifecycle.viewmodel.ktx)
    implementation(libs.lifecycle.livedata.ktx)
    implementation(libs.lifecycle.common.java8)

    implementation(libs.navigation.fragment.ktx)
    implementation(libs.navigation.ui.ktx)

    implementation(libs.room.ktx)
    implementation(libs.androidx.activity)
    ksp(libs.room.compiler)

    implementation(libs.androidx.media3.exoplayer)
    implementation(libs.androidx.media3.ui)
    implementation(libs.androidx.loader)
    implementation(libs.androidx.cardview)
    implementation(libs.androidx.recyclerview)
    implementation(libs.androidx.viewpager2)
    implementation(libs.androidx.swiperefreshlayout)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.preference.ktx)
    implementation(libs.material.components)

    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.analytics)
    implementation(libs.firebase.auth)
    implementation(libs.firebase.perf)
    implementation(libs.firebase.messaging)
    implementation(libs.firebase.config)
    implementation(libs.firebase.crashlytics)

    implementation(libs.koin.core)
    implementation(libs.koin.android)

    implementation(libs.coil)
    implementation(libs.coil.video)

    implementation(libs.photoview)
//    implementation(libs.insetter)
//    implementation(libs.retrofit)
//    implementation(libs.retrofit.converter.gson)
    implementation(libs.okhttp3.logging)
    implementation(libs.gson)
    implementation(libs.versioncompare)
    implementation(libs.libphonenumber)
    implementation(libs.prettytime)
    implementation(libs.advrecyclerview)

    implementation(libs.markdown.core)
    implementation(libs.markdown.html)

    // Kotlin
    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.kotlinx.coroutines.android)

    implementation("com.hbb20:ccp:2.7.0")
    implementation("com.intuit.sdp:sdp-android:1.1.1")
    implementation("com.intuit.ssp:ssp-android:1.1.1")
    implementation("com.github.DroidNinja:Android-FilePicker:113495abc8")

//    implementation("com.github.FunkyMuse.MediaPicker:imagepicker:1.0.0")
//    implementation("com.github.FunkyMuse.MediaPicker:audiopicker:1.0.0")
    implementation("com.github.FunkyMuse.MediaPicker:videopicker:1.0.0")
    implementation("com.github.FunkyMuse.MediaPicker:extensions:1.0.0")
    implementation("com.github.FunkyMuse.MediaPicker:core:1.0.0")


    implementation("com.google.android.gms:play-services-ads:23.0.0")
    implementation(project(":ads"))
}