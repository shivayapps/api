package com.statussaver.utils

import com.google.android.gms.ads.AdView

class AdCache {
    companion object {
        var homeAdView:AdView?=null

    }
}


