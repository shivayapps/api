package com.statussaver.interfaces

import android.view.MenuItem
import com.statussaver.model.Status


interface IStatusCallback {
    fun previewStatusesClick(statuses: List<Status>, startPosition: Int)
    fun multiSelectionItemClick(item: MenuItem, selection: List<Status>)
}