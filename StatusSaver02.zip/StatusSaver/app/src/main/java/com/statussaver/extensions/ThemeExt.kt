package com.statussaver.extensions

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.view.View
import com.google.android.material.color.MaterialColors
import com.statussaver.R

//val Context.isNightModeEnabled: Boolean
//    get() = resources.configuration.run {
//        this.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
//    }

fun Context.getGeneralThemeRes(): Int =
    R.style.Theme_WhatSave
//    if (isNightModeEnabled) R.style.Theme_WhatSave_Black else R.style.Theme_WhatSave
//    if (isNightModeEnabled && preferences().isJustBlack()) R.style.Theme_WhatSave_Black else R.style.Theme_WhatSave

fun Context.primaryColor() =
    MaterialColors.getColor(this, com.google.android.material.R.attr.colorPrimary, Color.TRANSPARENT)

fun Context.surfaceColor(fallback: Int = Color.TRANSPARENT) =
    MaterialColors.getColor(this, com.google.android.material.R.attr.colorSurface, fallback)

fun Activity.updateStatusBarColor(color: Int) {
    window.statusBarColor = color

    if (color.getContrastColor() == DARK_GREY) {
        window.decorView.systemUiVisibility = window.decorView.systemUiVisibility.addBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
    } else {
        window.decorView.systemUiVisibility = window.decorView.systemUiVisibility.removeBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
    }
}

val DARK_GREY = 0xFF333333.toInt()
fun Int.getContrastColor(): Int {
    val y = (299 * Color.red(this) + 587 * Color.green(this) + 114 * Color.blue(this)) / 1000
    return if (y >= 149 && this != Color.BLACK) DARK_GREY else Color.WHITE
}
fun Int.removeBit(bit: Int) = addBit(bit) - bit

fun Int.addBit(bit: Int) = this or bit