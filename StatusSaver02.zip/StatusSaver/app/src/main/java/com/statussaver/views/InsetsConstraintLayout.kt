
package com.statussaver.views

import android.content.Context
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout
import com.statussaver.extensions.applyLandscapeInsetter
import com.statussaver.extensions.applyPortraitInsetter


class InsetsConstraintLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr) {

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        var hasInsetsParent = false
        var parent = parent
        while (parent != null) {
            if (parent is InsetsConstraintLayout) {
                hasInsetsParent = true
                break
            }
            parent = parent.parent
        }
        if (!hasInsetsParent) {
//            applyPortraitInsetter {
//                type(navigationBars = true) {
//                    padding()
//                }
//            }
//            applyLandscapeInsetter {
//                type(navigationBars = true, displayCutout = true) {
//                    padding(horizontal = true)
//                }
//            }
        }
    }
}