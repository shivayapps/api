package com.statussaver.interfaces

import com.statussaver.model.Country

interface ICountryCallback {
    fun countryClick(country: Country)
}