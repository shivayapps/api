package com.statussaver.activities

import android.os.Bundle
import androidx.fragment.app.Fragment
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.statussaver.R
import com.statussaver.activities.base.BaseActivity
import com.statussaver.databinding.ActivityToolsBinding
import com.statussaver.extensions.applyPortraitInsetter
import com.statussaver.fragments.AsciiFacesFragment
import com.statussaver.fragments.SplitLongStatusFragment
import com.statussaver.fragments.StylishTextFragment
import com.statussaver.fragments.TextDecoratorFragment
import com.statussaver.fragments.TextRepeatFragment
import com.statussaver.fragments.WaDirectFragment
import com.statussaver.utils.AdCache

class ToolsActivity : BaseActivity() {

    lateinit var binding: ActivityToolsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityToolsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val itemId = intent.getIntExtra("id", 1)
        when (itemId) {
            0 -> {
                binding.toolbar.setTitle(getString(R.string.quick_message))
                showFragment(WaDirectFragment())
            }

            1 -> {
                binding.toolbar.setTitle(getString(R.string.text_repeater))
                showFragment(TextRepeatFragment())
            }

            2 -> {
                binding.toolbar.setTitle(getString(R.string.stylish_text))
                showFragment(StylishTextFragment())
            }

            3 -> {
                binding.toolbar.setTitle(getString(R.string.text_decorator))
                showFragment(TextDecoratorFragment())
            }

            4 -> {
                binding.toolbar.setTitle(getString(R.string.ascii_face))
                showFragment(AsciiFacesFragment())
            }

            5 -> {
                binding.toolbar.setTitle(getString(R.string.split_long_status))
                showFragment(SplitLongStatusFragment())
            }
        }
//        binding.fragmentContainer.applyPortraitInsetter {
//            type(navigationBars = true) {
//                padding(vertical = true)
//            }
//        }
        loadAds()
    }

    private fun showFragment(fragment: Fragment) {
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()

    }
    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadAds() {
        val adId = getString(R.string.b_toolsActivity)
        BannerAdHelper.showBanner(
            this,
            binding.frameAds,
            binding.frameAds,
            adId,
            AdCache.toolsAdView,
            { isLoaded, adView, message ->
//                if (!isDestroyed) {
                mAdView = adView
                AdCache.toolsAdView = adView
                isAdLoaded = isLoaded
//                }
            })
    }

}