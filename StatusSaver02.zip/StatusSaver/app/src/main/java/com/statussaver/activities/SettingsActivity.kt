package com.statussaver.activities

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatDelegate
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat
import com.adconfig.AdsConfig
import com.statussaver.R
import com.statussaver.activities.base.BaseActivity
import com.statussaver.databinding.ActivitySettingsBinding
import com.statussaver.extensions.PREFERENCE_DEFAULT_CLIENT
//import com.statussaver.extensions.PREFERENCE_GRANT_PERMISSIONS
//import com.statussaver.extensions.PREFERENCE_JUST_BLACK_THEME
import com.statussaver.extensions.PREFERENCE_LANGUAGE
import com.statussaver.extensions.PREFERENCE_QUICK_DELETION
import com.statussaver.extensions.PREFERENCE_STATUSES_LOCATION
import com.statussaver.extensions.Preferences
//import com.statussaver.extensions.PREFERENCE_THEME_MODE
//import com.statussaver.extensions.PREFERENCE_USE_CUSTOM_FONT
import com.statussaver.extensions.applyPortraitInsetter
import com.statussaver.extensions.findActivityNavController
//import com.statussaver.extensions.getDefaultDayNightMode
//import com.statussaver.extensions.isNightModeEnabled
import com.statussaver.preferences.DefaultClientPreference
import com.statussaver.preferences.DefaultClientPreferenceDialog
import com.statussaver.preferences.SaveLocationPreference
import com.statussaver.preferences.SaveLocationPreferenceDialog
import com.statussaver.preferences.StoragePreference
import com.statussaver.preferences.StoragePreferenceDialog

class SettingsActivity : BaseActivity() {

    lateinit var preference: Preferences
    lateinit var binding: ActivitySettingsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        preference = Preferences(this)

        initSettings()
//        supportFragmentManager
//            .beginTransaction()
//            .replace(R.id.settings_container, SettingsFragment())
//            .commit()
    }

    private fun initSettings() {
        binding.statusesLocation.setOnClickListener {
            StoragePreferenceDialog().show(supportFragmentManager, "STORAGE_DIALOG")
        }
        binding.preferredSaveLocation.setOnClickListener {
            SaveLocationPreferenceDialog().show(supportFragmentManager, "SAVE_LOCATION")
        }

        binding.swExcludeSavedStatuses.isChecked = preference.exclude_saved_statuses
        binding.excludeSavedStatuses.setOnClickListener {
            val newValue = !binding.swExcludeSavedStatuses.isChecked
            binding.swExcludeSavedStatuses.isChecked = newValue
            preference.exclude_saved_statuses = newValue

        }
        binding.swQuickDeletion.isChecked = preference.quick_deletion
        binding.quickDeletion.setOnClickListener {
            val newValue = !binding.swQuickDeletion.isChecked
            binding.swQuickDeletion.isChecked = newValue
            preference.quick_deletion = newValue
        }

        binding.swWhatsappIcon.isChecked = preference.whatsapp_icon
        binding.whatsappIcon.setOnClickListener {
            val newValue = !binding.swWhatsappIcon.isChecked
            binding.swWhatsappIcon.isChecked = newValue
            preference.whatsapp_icon = newValue
        }
        binding.defaultClient.setOnClickListener {
            DefaultClientPreferenceDialog().show(supportFragmentManager, "INSTALLED_CLIENTS")
        }

        binding.rateApp.setOnClickListener { rateApp() }
        binding.shareApp.setOnClickListener { shareApp() }
        binding.privacyPolicy.setOnClickListener { openPrivacyPolicy() }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            binding.statusesLocation.isVisible = false
            binding.defaultClient.isVisible = false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                binding.quickDeletion.isVisible = false
            }
        }
    }


    fun rateApp() {
        AdsConfig.isSystemDialogOpen = true
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${packageName}")
        )
        startActivity(intent)
    }

    fun shareApp() {
        try {
            val sendIntent = Intent()
            sendIntent.action = Intent.ACTION_SEND
            sendIntent.putExtra(
                Intent.EXTRA_TEXT,
                "Check out the App at: https://play.google.com/store/apps/details?id=${packageName}"
            )
            sendIntent.type = "text/plain"
            AdsConfig.isSystemDialogOpen = true
            startActivity(sendIntent)
        } catch (e: Exception) {

        }
    }

    fun openPrivacyPolicy() {
        val url = "https://sites.google.com/view/shivayapps/home"
        if (url != null && url.isNotEmpty()) {
            try {
                val builder: CustomTabsIntent.Builder = CustomTabsIntent.Builder()
                builder.setToolbarColor(ContextCompat.getColor(this, R.color.toolbar_color))
                AdsConfig.isSystemDialogOpen = true
                val customTabsIntent: CustomTabsIntent = builder.build()
                customTabsIntent.intent.setPackage("com.android.chrome")
                customTabsIntent.launchUrl(this, Uri.parse(url))

            } catch (e: Exception) {
                val i = Intent(Intent.ACTION_VIEW)
                i.data = Uri.parse(url)
                AdsConfig.isSystemDialogOpen = true
                startActivity(i)
            }
        }
    }

    class SettingsFragment : PreferenceFragmentCompat() {

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            addPreferencesFromResource(R.xml.preferences)
        }

        override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
            super.onViewCreated(view, savedInstanceState)
//            listView.applyPortraitInsetter {
//                type(navigationBars = true) {
//                    padding(vertical = true)
//                }
//            }
            invalidatePreferences()
        }

        override fun onDisplayPreferenceDialog(preference: Preference) {
            when (preference) {
                is SaveLocationPreference -> {
                    SaveLocationPreferenceDialog().show(childFragmentManager, "SAVE_LOCATION")
                    return
                }

                is DefaultClientPreference -> {
                    DefaultClientPreferenceDialog().show(childFragmentManager, "INSTALLED_CLIENTS")
                    return
                }

                is StoragePreference -> {
                    StoragePreferenceDialog().show(childFragmentManager, "STORAGE_DIALOG")
                    return
                }
            }
            super.onDisplayPreferenceDialog(preference)
        }

        fun invalidatePreferences() {
//            findPreference<Preference>("rate_app")?.setOnPreferenceClickListener {
//                rateApp()
//                true
//            }
//            findPreference<Preference>("share_app")?.setOnPreferenceClickListener {
//                shareApp()
//                true
//            }
//            findPreference<Preference>("privacy_policy")?.setOnPreferenceClickListener {
//                openPrivacyPolicy()
//                true
//            }

//            findPreference<Preference>(PREFERENCE_THEME_MODE)
//                ?.setOnPreferenceChangeListener { _: Preference?, newValue: Any? ->
//                    val themeName = newValue as String
//                    AppCompatDelegate.setDefaultNightMode(getDefaultDayNightMode(themeName))
//                    true
//                }
//            findPreference<SwitchPreferenceCompat>(PREFERENCE_JUST_BLACK_THEME)
//                ?.apply {
//                    isEnabled = requireContext().isNightModeEnabled
//                    setOnPreferenceChangeListener { _, _ ->
//                        requireActivity().recreate()
//                        true
//                    }
//                }
//            findPreference<Preference>(PREFERENCE_USE_CUSTOM_FONT)
//                ?.setOnPreferenceChangeListener { _, _ ->
//                    requireActivity().recreate()
//                    true
//                }
//            findPreference<Preference>(PREFERENCE_LANGUAGE)?.setOnPreferenceChangeListener { _, newValue ->
//                val languageName = newValue as String
//                if (languageName == "auto") {
//                    AppCompatDelegate.setApplicationLocales(LocaleListCompat.getEmptyLocaleList())
//                } else {
//                    AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(languageName))
//                }
//                true
//            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                findPreference<Preference>(PREFERENCE_STATUSES_LOCATION)?.isVisible = false
                findPreference<Preference>(PREFERENCE_DEFAULT_CLIENT)?.isVisible = false
//                findPreference<Preference>(PREFERENCE_GRANT_PERMISSIONS)?.apply {
//                    isVisible = true
//                    setOnPreferenceClickListener {
//                        findActivityNavController(R.id.main_container)
//                            .navigate(R.id.onboardFragment, bundleOf("isFromSettings" to true))
//                        true
//                    }
//                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    findPreference<Preference>(PREFERENCE_QUICK_DELETION)?.isVisible = false
                }
            }
        }
    }

}