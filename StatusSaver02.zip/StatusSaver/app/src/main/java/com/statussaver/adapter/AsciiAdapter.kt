package com.statussaver.adapter

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.statussaver.R
import com.statussaver.adapter.AsciiAdapter.MyViewHolder

internal class AsciiAdapter(val mContext: Context, val strAscii: Array<String>?) : RecyclerView.Adapter<MyViewHolder>() {
//    private val AngryAscii = angryAscii

//    private val context: Context = activity

    internal inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var Share: ImageView = itemView.findViewById(R.id.share)

        var TextFaces: TextView = itemView.findViewById(R.id.txt)
        var WhatsApp: ImageView = itemView.findViewById(R.id.whats)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_ascii, parent, false))
    }

    @SuppressLint("LongLogTag")
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.TextFaces.text = strAscii!![position]
        holder.WhatsApp.setOnClickListener {
            val FACE = strAscii[position]
            val whatsappIntent = Intent("android.intent.action.SEND")
            whatsappIntent.setType("text/plain")
            whatsappIntent.setPackage("com.whatsapp")
            whatsappIntent.putExtra("android.intent.extra.TEXT", FACE)
            try {
                mContext.startActivity(whatsappIntent)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(mContext, "Whatsapp have not been installed.", Toast.LENGTH_SHORT).show()
            }
        }


        //Share button clicked event
        holder.Share.setOnClickListener {
            val FACE = strAscii[position]
            val whatsappIntent = Intent("android.intent.action.SEND")
            whatsappIntent.setType("text/plain")
            whatsappIntent.putExtra("android.intent.extra.TEXT", FACE)
            try {
                mContext.startActivity(whatsappIntent)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(mContext, "Some problems", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun getItemCount(): Int {
        return if ((this.strAscii == null)) 0 else strAscii.size
    }
}
