package com.statussaver.model

import android.annotation.TargetApi
import android.content.Context
import android.content.Intent
import android.content.UriPermission
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Environment
import com.statussaver.R
import com.statussaver.extensions.getDrawableCompat
import com.statussaver.extensions.isFromClient
import com.statussaver.extensions.packageInfo

enum class WaClient(
    val displayName: String,
    private val internalName: String,
    val packageName: String,
    private val iconRes: Int
) {
    WhatsApp("WA Messenger", "WhatsApp", "com.whatsapp", R.drawable.icon_wa),
    Business("WA Business", "WhatsApp Business", "com.whatsapp.w4b", R.drawable.icon_business);

    fun getIcon(context: Context): Drawable? = context.getDrawableCompat(iconRes)

    fun isInstalled(context: Context): Boolean {
        return try {
            context.packageManager.packageInfo(packageName)
            true
        } catch (ignored: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun hasPermissions(context: Context): Boolean {
        return hasPermissions(context.contentResolver.persistedUriPermissions)
    }

    fun hasPermissions(uriPermissions: List<UriPermission>): Boolean {
        return uriPermissions.any { it.isReadPermission && it.uri.isFromClient(this) }
    }

    fun releasePermissions(context: Context): Boolean {
        val uriPermissions = context.contentResolver.persistedUriPermissions
        for (perm in uriPermissions) {
            if (perm.uri.isFromClient(this)) {
                val flags =
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION
                context.contentResolver.releasePersistableUriPermission(perm.uri, flags)
                return true
            }
        }
        return false
    }

    fun getLaunchIntent(packageManager: PackageManager): Intent? {
        return packageManager.getLaunchIntentForPackage(packageName)
    }

    fun getDirectoryPath(): Array<String> {
        val waPath = if (Build.VERSION.SDK_INT < 30) {
            Environment.getExternalStorageDirectory().absolutePath + "/$internalName/Media/.Statuses"
        } else {
            Environment.getExternalStorageDirectory().absolutePath + "Android/media/$packageName/$internalName/Media/.Statuses"
        }
        return arrayOf(
//            "$internalName/Media/.Statuses",
            waPath
        )
    }

    fun getSAFDirectoryPath(): String {
        if (Build.VERSION.SDK_INT < 30) {
            return Environment.getExternalStorageDirectory().absolutePath + "/$internalName/Media/.Statuses"
//            return "$internalName/Media/.Statuses"
        } else {
            return Environment.getExternalStorageDirectory().absolutePath + "Android/media/$packageName/$internalName/Media/.Statuses"
//            return Environment.getExternalStorageDirectory().absolutePath + "/$internalName/Media/.Statuses"
        }
    }
}