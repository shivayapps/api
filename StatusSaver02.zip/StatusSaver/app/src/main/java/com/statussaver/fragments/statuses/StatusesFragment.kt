package com.statussaver.fragments.statuses

import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.doOnPreDraw
import androidx.core.view.isVisible
import androidx.core.view.setPadding
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView.AdapterDataObserver
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.transition.MaterialSharedAxis
import com.statussaver.R
import com.statussaver.WhatSaveViewModel
import com.statussaver.activities.MainActivity
import com.statussaver.activities.PermissionActivity
import com.statussaver.activities.PreviewActivity
import com.statussaver.adapter.StatusAdapter
import com.statussaver.databinding.FragmentStatusesBinding
import com.statussaver.extensions.PREFERENCE_DEFAULT_CLIENT
import com.statussaver.extensions.PREFERENCE_EXCLUDE_SAVED_STATUSES
import com.statussaver.extensions.PREFERENCE_STATUSES_LOCATION
import com.statussaver.extensions.PREFERENCE_WHATSAPP_ICON
import com.statussaver.extensions.createProgressDialog
import com.statussaver.extensions.dip
import com.statussaver.extensions.findActivityNavController
import com.statussaver.extensions.formattedAsHtml
import com.statussaver.extensions.getClientSAFIntent
import com.statussaver.extensions.getPreferredClient
import com.statussaver.extensions.hasQ
import com.statussaver.extensions.hasR
import com.statussaver.extensions.isNullOrEmpty
import com.statussaver.extensions.isQuickDeletion
import com.statussaver.extensions.isShownOnboard
import com.statussaver.extensions.isWhatsappIcon
import com.statussaver.extensions.launchSafe
import com.statussaver.extensions.preferences
import com.statussaver.extensions.primaryColor
import com.statussaver.extensions.requestPermissions
import com.statussaver.extensions.requestView
import com.statussaver.extensions.requestWithOnboard
import com.statussaver.extensions.showToast
import com.statussaver.extensions.startActivitySafe
import com.statussaver.extensions.takePermissions
import com.statussaver.fragments.base.BaseFragment
import com.statussaver.fragments.binding.StatusesBinding
import com.statussaver.fragments.playback.PlaybackFragmentArgs
import com.statussaver.interfaces.IPermissionChangeListener
import com.statussaver.interfaces.IScrollable
import com.statussaver.interfaces.IStatusCallback
import com.statussaver.model.Status
import com.statussaver.model.StatusQueryResult
import com.statussaver.model.WaClient
import com.statussaver.mvvm.DeletionResult
import com.statussaver.mvvm.SaveResult
import org.koin.androidx.viewmodel.ext.android.activityViewModel


abstract class StatusesFragment : BaseFragment(R.layout.fragment_statuses),
    View.OnClickListener, SharedPreferences.OnSharedPreferenceChangeListener,
    OnRefreshListener, IScrollable, IPermissionChangeListener, IStatusCallback {

    protected val statusesActivity: MainActivity
        get() = activity as MainActivity

    private var _binding: StatusesBinding? = null
    private lateinit var deletionRequestLauncher: ActivityResultLauncher<IntentSenderRequest>
    private val progressDialog by lazy { requireContext().createProgressDialog() }
    private var deletedStatuses = mutableListOf<Status>()
//    private var clients: List<WaClient> = ArrayList()
//    private var selectedClient: WaClient? = null

    protected val binding get() = _binding!!
    protected val viewModel by activityViewModel<WhatSaveViewModel>()
    protected var statusAdapter: StatusAdapter? = null

    protected abstract val lastResult: StatusQueryResult?

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        postponeEnterTransition()
        view.doOnPreDraw { startPostponedEnterTransition() }
        enterTransition = MaterialSharedAxis(MaterialSharedAxis.Y, true)
        reenterTransition = MaterialSharedAxis(MaterialSharedAxis.Y, true)
        _binding = StatusesBinding(FragmentStatusesBinding.bind(view)).apply {
            swipeRefreshLayout.setOnRefreshListener(this@StatusesFragment)
            swipeRefreshLayout.setColorSchemeColors(view.context.primaryColor())

            recyclerView.setPadding(dip(R.dimen.status_item_margin))
            recyclerView.layoutManager = GridLayoutManager(requireActivity(), resources.getInteger(R.integer.statuses_grid_span_count))
            recyclerView.adapter = createAdapter().apply {
                registerAdapterDataObserver(adapterDataObserver)
            }.also { newStatusAdapter ->
                statusAdapter = newStatusAdapter
            }

            emptyButton.setOnClickListener(this@StatusesFragment)
        }
        deletionRequestLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {
                viewModel.removeStatuses(deletedStatuses)
                showToast(R.string.deletion_success)
            }
        }
        preferences().registerOnSharedPreferenceChangeListener(this)

//        viewModel.getInstalledClients().observe(requireActivity()) {
//            clients = it
//        }
    }

    override fun onStart() {
        super.onStart()
        statusesActivity.addPermissionsChangeListener(this)
    }

    override fun onStop() {
        super.onStop()
        statusesActivity.removePermissionsChangeListener(this)
    }

    protected open fun createAdapter(): StatusAdapter {
        return StatusAdapter(
            requireActivity(),
            this,
            isSaveEnabled = true,
            isDeleteEnabled = false,
            isWhatsAppIconEnabled = preferences().isWhatsappIcon()
        )
    }

    override fun scrollToTop() {
        binding.recyclerView.scrollToPosition(0)
    }

    override fun onClick(view: View) {
        if (view == binding.emptyButton) {
            val resultCode = lastResult?.code
            Log.e("onClick", "resultCode.001:$resultCode}")
            if (resultCode != StatusQueryResult.ResultCode.Loading) {
                Log.e("onClick", "resultCode.002:$resultCode, ${getString(resultCode?.titleRes!!)}")
                when (resultCode) {
                    StatusQueryResult.ResultCode.PermissionError -> {
//                        val clientsWithoutPermissions = clients.filterNot { it.hasPermissions(requireContext()) }
//                        clientClick(clientsWithoutPermissions.first())
                        //requestPermissions()
                        preferences().isShownOnboard = false
                        startActivity(Intent(requireActivity(), PermissionActivity::class.java))
                    }

                    StatusQueryResult.ResultCode.NotInstalled -> requireActivity().finish()
                    StatusQueryResult.ResultCode.NoStatuses -> requireContext().getPreferredClient()?.let {
                        startActivitySafe(it.getLaunchIntent(requireContext().packageManager))
                    }

                    else -> onRefresh()
                }
            }
        }
    }

//    fun clientClick(client: WaClient) {
//        if (client.hasPermissions(requireContext())) {
//            MaterialAlertDialogBuilder(requireContext())
//                .setTitle(R.string.revoke_permissions_title)
//                .setMessage(
//                    getString(
//                        R.string.revoke_permissions_message,
//                        client.displayName
//                    ).formattedAsHtml()
//                )
//                .setPositiveButton(R.string.revoke_action) { _: DialogInterface, _: Int ->
//                    if (client.releasePermissions(requireContext())) {
//                        showToast(R.string.permissions_revoked_successfully)
//                        viewModel.reloadAll()
////                        clientAdapter?.notifyDataSetChanged()
//                    }
//                }
//                .setNegativeButton(android.R.string.cancel, null)
//                .show()
//        } else if (hasQ()) { // Just to remove the Lint warning
//            MaterialAlertDialogBuilder(requireContext())
//                .setMessage(getString(R.string.saf_tutorial, client.getSAFDirectoryPath()).formattedAsHtml())
//                .setPositiveButton(android.R.string.ok) { _: DialogInterface, _: Int ->
//                    this.selectedClient = client
//                    permissionRequest.launchSafe(requireContext().getClientSAFIntent(client))
//                }
//                .show()
//        }
//    }

//    val permissionRequest = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult? ->
//        if (result != null && selectedClient?.takePermissions(requireContext(), result) == true) {
//            viewModel.reloadAll()
//            onRefresh()
//        }
//    }

    override fun permissionsStateChanged(hasPermissions: Boolean) {
        viewModel.reloadAll()
    }

    override fun multiSelectionItemClick(item: MenuItem, selection: List<Status>) = requestView {
        when (item.itemId) {
            R.id.action_share -> {
                viewModel.shareStatuses(selection).observe(viewLifecycleOwner) {
                    if (it.isLoading) {
                        progressDialog.show()
                    } else {
                        progressDialog.dismiss()
                        if (it.isSuccess) {
                            startActivitySafe(it.data.createIntent(requireContext()))
                        }
                    }
                }
            }

            R.id.action_save -> {
                viewModel.saveStatuses(selection).observe(viewLifecycleOwner) {
                    processSaveResult(it)
                }
            }

            R.id.action_delete -> {
                if (hasR()) {
                    viewModel.createDeleteRequest(requireContext(), selection).observe(viewLifecycleOwner) {
                        deletedStatuses = selection.toMutableList()
                        deletionRequestLauncher.launchSafe(IntentSenderRequest.Builder(it).build())
                    }
                } else {
                    if (!preferences().isQuickDeletion()) {
                        MaterialAlertDialogBuilder(requireContext())
                            .setTitle(R.string.delete_saved_statuses_title)
                            .setMessage(
                                getString(R.string.x_saved_statuses_will_be_permanently_deleted, selection.size)
                            )
                            .setPositiveButton(R.string.delete_action) { _: DialogInterface, _: Int ->
                                viewModel.deleteStatuses(selection).observe(viewLifecycleOwner) {
                                    processDeletionResult(it)
                                }
                            }
                            .setNegativeButton(android.R.string.cancel, null)
                            .show()
                    } else {
                        viewModel.deleteStatuses(selection).observe(viewLifecycleOwner) {
                            processDeletionResult(it)
                        }
                    }
                }
            }
        }
    }

    override fun previewStatusesClick(statuses: List<Status>, startPosition: Int) {
        val intent = Intent(activity, PreviewActivity::class.java).apply {
            putParcelableArrayListExtra("statuses", ArrayList(statuses))
            putExtra("startPosition", startPosition)
        }
        startActivity(intent)
//        findActivityNavController(R.id.global_container).navigate(
//            R.id.playbackFragment,
//            PlaybackFragmentArgs.Builder(statuses.toTypedArray(), startPosition).build()
//                .toBundle()
//        )
    }

    protected fun data(result: StatusQueryResult) {
        statusAdapter?.statuses = result.statuses
        binding.swipeRefreshLayout.isRefreshing = result.isLoading
        if (result.code.titleRes != 0) {
            binding.emptyTitle.text = getString(result.code.titleRes)
            binding.emptyTitle.isVisible = true
        } else {
            binding.emptyTitle.isVisible = false
        }
        if (result.code.descriptionRes != 0) {
            binding.emptyText.text = getString(result.code.descriptionRes)
            binding.emptyText.isVisible = true
        } else {
            binding.emptyText.isVisible = false
        }
        if (result.code.buttonTextRes != 0) {
            binding.emptyButton.text = getString(result.code.buttonTextRes)
            binding.emptyButton.isVisible = true
        } else {
            binding.emptyButton.isVisible = false
        }
    }

    private fun processSaveResult(result: SaveResult) = requestView { view ->
        if (result.isSaving) {
            Snackbar.make(view, R.string.saving_status, Snackbar.LENGTH_SHORT).show()
        } else {
            if (result.isSuccess) {
                if (result.saved == 1) {
                    Snackbar.make(view, R.string.saved_successfully, Snackbar.LENGTH_SHORT).show()
                } else {
                    Snackbar.make(view, getString(R.string.saved_x_statuses, result.saved), Snackbar.LENGTH_SHORT).show()
                }
                viewModel.reloadAll()
            } else {
                Snackbar.make(view, R.string.failed_to_save, Snackbar.LENGTH_SHORT).show()
            }
        }
        statusAdapter?.isSavingContent = result.isSaving
    }

    private fun processDeletionResult(result: DeletionResult) = requestView { view ->
        if (result.isDeleting) {
            Snackbar.make(view, R.string.deleting_please_wait, Snackbar.LENGTH_SHORT).show()
        } else if (result.isSuccess) {
            Snackbar.make(view, R.string.deletion_success, Snackbar.LENGTH_SHORT).show()
            viewModel.reloadAll()
        } else {
            Snackbar.make(view, R.string.deletion_failed, Snackbar.LENGTH_SHORT).show()
        }
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences, key: String?) {
        when (key) {
            PREFERENCE_DEFAULT_CLIENT,
            PREFERENCE_STATUSES_LOCATION,
            PREFERENCE_EXCLUDE_SAVED_STATUSES -> onRefresh()

            PREFERENCE_WHATSAPP_ICON -> statusAdapter?.isWhatsAppIconEnabled = sharedPreferences.isWhatsappIcon()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        preferences().unregisterOnSharedPreferenceChangeListener(this)
        deletedStatuses.clear()
        statusAdapter?.unregisterAdapterDataObserver(adapterDataObserver)
        statusAdapter = null
    }

    private val adapterDataObserver = object : AdapterDataObserver() {
        override fun onChanged() {
            binding.emptyView.isVisible = statusAdapter.isNullOrEmpty()
        }
    }
}