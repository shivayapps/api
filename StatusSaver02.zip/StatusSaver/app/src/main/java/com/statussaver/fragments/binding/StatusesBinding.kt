package com.statussaver.fragments.binding

import androidx.appcompat.widget.Toolbar
import com.statussaver.databinding.FragmentStatusesBinding

class StatusesBinding(binding: FragmentStatusesBinding) {
//    val toolbar = binding.toolbar
//    val toolbar = Toolbar(binding.root.context)
//    val collapsingToolbar = binding.collapsingToolbarLayout
    val swipeRefreshLayout = binding.swipeRefreshLayout
    val recyclerView = binding.recyclerView
    val emptyView = binding.emptyView.root
    val emptyTitle = binding.emptyView.emptyTitle
    val emptyText = binding.emptyView.emptyText
    val emptyButton = binding.emptyView.emptyButton
}