package com.statussaver.activities

//import com.statussaver.extensions.PREFERENCE_GRANT_PERMISSIONS
//import com.statussaver.extensions.PREFERENCE_JUST_BLACK_THEME
//import com.statussaver.extensions.PREFERENCE_USE_CUSTOM_FONT
import android.os.Bundle
import com.statussaver.R
import com.statussaver.activities.base.BaseActivity
import com.statussaver.databinding.ActivitySettingsBinding
import com.statussaver.fragments.playback.PlaybackFragment
import com.statussaver.fragments.playback.PlaybackFragmentArgs
import com.statussaver.model.Status

class PreviewActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val statuses = intent.getParcelableArrayListExtra<Status>("statuses") ?: arrayListOf()
        val startPosition = intent.getIntExtra("startPosition", 0)

        val fragment = PlaybackFragment.newInstance(statuses, startPosition)
//        val fragment = PlaybackFragmentArgs.Builder(statuses.toTypedArray(), startPosition).build()

        supportFragmentManager
            .beginTransaction()
            .replace(R.id.settings_container, fragment)
            .commit()
    }
}