package com.explorefile.filemanager.helpers

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import com.explorefile.filemanager.R
import java.util.Locale
import java.util.TimeZone

object Helpers {

    val emailTo = "ahyansamiapps@gmail.com"
    fun feedBackSupport(context: Context, feebBackText: String) {
        val emailText = feebBackText + "\n" + context.getAllDeviceInfo()
        val emailIntent = Intent(Intent.ACTION_SEND_MULTIPLE)
        emailIntent.type = "message/rfc822"
        emailIntent.setPackage("com.google.android.gm")
        emailIntent.putExtra(Intent.EXTRA_EMAIL, arrayOf(emailTo))
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.app_name))
        emailIntent.putExtra(Intent.EXTRA_TEXT, emailText)
        val uris = ArrayList<Uri>()
        emailIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        context.startActivity(Intent.createChooser(emailIntent, "Send mail..."))
    }

}


