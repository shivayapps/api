package com.explorefile.filemanager.interfaces

import com.explorefile.filemanager.models.FileDirItem


interface ItemOperationsListener {
    fun refreshFragment()

    fun deleteFiles(files: ArrayList<FileDirItem>)

    fun selectedPaths(paths: ArrayList<String>)

    fun setupDateTimeFormat()

    fun toggleFilenameVisibility()

    fun columnCountChanged()

    fun finishActMode()
}
