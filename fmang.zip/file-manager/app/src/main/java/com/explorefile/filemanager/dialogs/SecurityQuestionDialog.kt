package com.explorefile.filemanager.dialogs

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.DialogSecurityQuestionBinding
import com.explorefile.filemanager.extensions.baseConfig
import com.explorefile.filemanager.extensions.getColoredDrawableWithColor
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.isBlackAndWhiteTheme
import com.explorefile.filemanager.extensions.isWhiteTheme
import com.explorefile.filemanager.extensions.setupDialogStuff
import com.explorefile.filemanager.extensions.updateTextColors
import com.explorefile.filemanager.helpers.Preferences
import com.explorefile.filemanager.views.MyTextView
import kotlin.text.equals
import kotlin.text.isEmpty
import kotlin.toString

class SecurityQuestionDialog(
    var mContext: Activity,
    private val preferences: Preferences,
    var type: Int = 0,//1-> Reset, 0->Set Question
    var isChangePass: Boolean = false,
    val updateListener: (isSuccess: Boolean) -> Unit,
    val useDarkMode: Boolean? = false
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogSecurityQuestionBinding
    var isShowPinLock = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
        //window?.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
//        window?.navigationBarColor = ContextCompat.getColor(mContext, R.color.dialogBg)
        window?.setGravity(Gravity.BOTTOM)
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
//                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
//                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        bindingDialog = DialogSecurityQuestionBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )

        val textColor = mContext.getProperTextColor()
        val backgroundColor = mContext.getProperBackgroundColor()
        val primaryColor = mContext.getProperPrimaryColor()
        val dialogButtonColor = if (primaryColor == mContext.baseConfig.backgroundColor) {
            textColor
        } else {
            primaryColor
        }

        val bgDrawable = when {
            mContext.isBlackAndWhiteTheme() -> mContext.resources.getDrawable(
                R.drawable.black_dialog_background,
                mContext.theme
            )

            else -> mContext.resources.getColoredDrawableWithColor(
                R.drawable.dialog_bg,
                mContext.baseConfig.backgroundColor
            )
        }

        window?.setBackgroundDrawable(bgDrawable)

        bindingDialog.tvOk.setTextColor(dialogButtonColor)
        bindingDialog.tvCancel.setTextColor(dialogButtonColor)
        if (bindingDialog.root is ViewGroup) {
            mContext.updateTextColors(bindingDialog.root)
        }
//        else if (bindingDialog.root is MyTextView) {
//            view.setColors(textColor, primaryColor, backgroundColor)
//        }

        intView()
        intListener()
    }

    private fun intView() {
        isShowPinLock = preferences.getShowPINLock()

        val adapter = SpinnerQueAdapter(mContext, mContext.resources.getStringArray(R.array.security_question))
//        bindingDialog.questionSpinner.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#222222"))
        bindingDialog.questionSpinner.adapter = adapter

        if (type == 1) {
            bindingDialog.questionSpinner.setSelection(preferences.getSecurityQuestion())
        }
        if (isChangePass) {
            bindingDialog.securityAnswer.setText(preferences.getAnswerQuestion())
        }
    }

    private fun intListener() {

        bindingDialog.btnCancel.setOnClickListener {
            if (isChangePass) {
                updateListener.invoke(false)
                dismiss()
            } else {
                updateListener.invoke(false)
                dismiss()
            }
        }

        bindingDialog.btnOk.setOnClickListener {
            val answer = bindingDialog.securityAnswer.text.toString()
            if (bindingDialog.questionSpinner.selectedItemPosition == 0)
                Toast.makeText(
                    mContext,
                    mContext.getString(R.string.please_select_que),
                    Toast.LENGTH_SHORT
                ).show()
            else if (answer.isEmpty()) {
                Toast.makeText(
                    mContext,
                    mContext.getString(R.string.please_select_que),
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                hideSoftKeyboard()
                if (isChangePass) {
                    preferences.putSecurityQuestion(bindingDialog.questionSpinner.selectedItemPosition)
                    preferences.putAnswerQuestion(answer)
                    Toast.makeText(
                        mContext,
                        mContext.getString(R.string.question_change_successfully),
                        Toast.LENGTH_SHORT
                    ).show()

                    updateListener.invoke(true)
                    dismiss()
                } else if (!preferences.getSetQuestion()) {
                    preferences.putSetQuestion(true)
                    preferences.putSecurityQuestion(bindingDialog.questionSpinner.selectedItemPosition)
                    preferences.putAnswerQuestion(answer)

                    updateListener.invoke(true)
                    dismiss()

                } else {
                    if (bindingDialog.questionSpinner.selectedItemPosition == preferences.getSecurityQuestion()) {
                        if (preferences.getAnswerQuestion().equals(answer)) {
                            if (preferences.getShowPINLock()) {
                                preferences.putSetPass(false)
                                preferences.putPass("")
                            } else {
                                preferences.putSetPattern(false)
                                preferences.putPattern("")
                            }
                            updateListener.invoke(true)
                            dismiss()
                        } else {
                            Toast.makeText(
                                mContext,
                                R.string.msg_security_ans,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else Toast.makeText(
                        mContext,
                        R.string.msg_security_que,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

        }
    }

    fun hideSoftKeyboard() {
        val inputMethodManager = mContext.getSystemService(AppCompatActivity.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(bindingDialog.securityAnswer.windowToken, 0)
    }

    class SpinnerQueAdapter(
        private val context: Context,
        private val itemList: Array<String>
    ) :
        BaseAdapter() {

        override fun getCount(): Int {
            return itemList.size
        }

        override fun getItem(position: Int): Any {
            return itemList[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view: View
            val viewHolder: ViewHolder

            val textColor = context.baseConfig.textColor
            val accentColor = context.baseConfig.backgroundColor


            if (convertView == null) {
                view = LayoutInflater.from(context).inflate(R.layout.item_spinner_que, parent, false)
                viewHolder = ViewHolder(view)
                view.tag = viewHolder
            } else {
                view = convertView
                viewHolder = view.tag as ViewHolder
            }

//            view.setBackgroundColor(accentColor)
            viewHolder.itemTextView.setTextColor(textColor)
            val item = itemList[position]
            viewHolder.itemTextView.text = item
            viewHolder.itemTextView.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.hint_black
                )
            )

            viewHolder.itemTextView.visibility = if (position == 0) View.GONE else View.VISIBLE

            return view
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view: View
            val viewHolder: ViewHolder

            val textColor = context. baseConfig.textColor
//            val accentColor = context.baseConfig.backgroundColor

            if (convertView == null) {
                view = LayoutInflater.from(context).inflate(R.layout.item_spinner_que, parent, false)
                viewHolder = ViewHolder(view)
                view.tag = viewHolder
            } else {
                view = convertView
                viewHolder = view.tag as ViewHolder
            }

//            view.setBackgroundColor(accentColor)
            val item = itemList[position]
            viewHolder.itemTextView.text = item
            viewHolder.itemTextView.setTextColor(textColor)
            if (position == 0) {
                viewHolder.itemTextView.setTextColor(ContextCompat.getColor(context, R.color.sm_colorGray))
            }
            else {
                viewHolder.itemTextView.setTextColor(Color.WHITE)
            }

            return view
        }


        private class ViewHolder(view: View) {
            val itemTextView: TextView = view.findViewById(R.id.txtItem)
        }
    }
}

