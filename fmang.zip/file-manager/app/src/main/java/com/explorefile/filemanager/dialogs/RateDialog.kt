package com.explorefile.filemanager.dialogs

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.explorefile.filemanager.App
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.MainActivity
import com.explorefile.filemanager.databinding.DialogRateUsBinding
import com.explorefile.filemanager.extensions.adjustAlpha
import com.explorefile.filemanager.extensions.getAlertDialogBuilder
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.setupDialogStuff
import com.explorefile.filemanager.extensions.showErrorToast
import com.explorefile.filemanager.helpers.Helpers
import com.explorefile.filemanager.helpers.MEDIUM_ALPHA
import com.journeyapps.barcodescanner.Util

class RateDialog(
    activity: Activity,
    positive: Int = R.string.ok,
    negative: Int = R.string.cancel,
    val callback: (result: Boolean) -> Unit
) {
    private var dialog: AlertDialog? = null

    init {
        val view = DialogRateUsBinding.inflate(activity.layoutInflater, null, false)

        val builder = activity.getAlertDialogBuilder()

        view.txtCancel.text = activity.resources.getText(negative)
        view.txtOk.text = activity.resources.getText(positive)

        builder.apply {
            activity.setupDialogStuff(
                view.root,
                this
            ) { alertDialog ->
                dialog = alertDialog
            }
        }

        view.txtCancel.setOnClickListener {
            dialog?.dismiss()
            callback(false)
        }

        with(view) {
            icRateDe1.setOnClickListener {
                is5Star = false
                setIcon(activity, view, icRateDe1)
//                icRateDe1.setImageResource(R.drawable.ic_rate_1)
                icRateDe1.setImageResource(R.drawable.ic_star_fill)
            }

            icRateDe2.setOnClickListener {
                is5Star = false
                setIcon(activity, view, icRateDe1)
//                icRateDe1.setImageResource(R.drawable.ic_rate_2)
//                icRateDe2.setImageResource(R.drawable.ic_rate_2)
                icRateDe1.setImageResource(R.drawable.ic_star_fill)
                icRateDe2.setImageResource(R.drawable.ic_star_fill)
            }

            icRateDe3.setOnClickListener {
                is5Star = false
                setIcon(activity, view, icRateDe3)
//                icRateDe1.setImageResource(R.drawable.ic_rate_3)
//                icRateDe2.setImageResource(R.drawable.ic_rate_3)
//                icRateDe3.setImageResource(R.drawable.ic_rate_3)
                icRateDe1.setImageResource(R.drawable.ic_star_fill)
                icRateDe2.setImageResource(R.drawable.ic_star_fill)
                icRateDe3.setImageResource(R.drawable.ic_star_fill)
            }

            icRateDe4.setOnClickListener {
                is5Star = true
                setIcon(activity, view, icRateDe4)
//                icRateDe1.setImageResource(R.drawable.ic_rate_4)
//                icRateDe2.setImageResource(R.drawable.ic_rate_4)
//                icRateDe3.setImageResource(R.drawable.ic_rate_4)
//                icRateDe4.setImageResource(R.drawable.ic_rate_4)
                icRateDe1.setImageResource(R.drawable.ic_star_fill)
                icRateDe2.setImageResource(R.drawable.ic_star_fill)
                icRateDe3.setImageResource(R.drawable.ic_star_fill)
                icRateDe4.setImageResource(R.drawable.ic_star_fill)
            }

            icRateDe5.setOnClickListener {
                is5Star = true
                setIcon(activity, view, icRateDe5)
//                icRateDe1.setImageResource(R.drawable.ic_rate_5)
//                icRateDe2.setImageResource(R.drawable.ic_rate_5)
//                icRateDe3.setImageResource(R.drawable.ic_rate_5)
//                icRateDe4.setImageResource(R.drawable.ic_rate_5)
//                icRateDe5.setImageResource(R.drawable.ic_rate_5)
                icRateDe1.setImageResource(R.drawable.ic_star_fill)
                icRateDe2.setImageResource(R.drawable.ic_star_fill)
                icRateDe3.setImageResource(R.drawable.ic_star_fill)
                icRateDe4.setImageResource(R.drawable.ic_star_fill)
                icRateDe5.setImageResource(R.drawable.ic_star_fill)
            }

            view.txtCancel.setTextColor(activity.getProperPrimaryColor())
            view.txtOk.setTextColor(activity.getProperTextColor().adjustAlpha(MEDIUM_ALPHA))

            txtOk.setOnClickListener {
                if (isSelect) {
                    dialog?.dismiss()
                    if (!is5Star) {
                        //Toast.makeText(activity, "Thanks for Rating.", Toast.LENGTH_LONG).show()
                        Helpers.feedBackSupport(activity,"")
                        callback(true)
                    } else {
//                        (activity as MainActivity).rateDoneReviewCounter()
                        App.disabledOpenAds()
                        activity.startActivity(
                            Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse("http://play.google.com/store/apps/details?id=${activity.packageName}")
                            )
                        )
                        callback(true)
                    }
                }
            }
        }

    }


    private var is5Star = false
    private var isSelect = false

    private fun setIcon(
        activity: Activity,
        bindingRate: DialogRateUsBinding,
        selectImage: ImageView
    ) {
        isSelect = true
        with(bindingRate) {
            icRateDe1.setImageResource(R.drawable.ic_star_unfill)
            icRateDe2.setImageResource(R.drawable.ic_star_unfill)
            icRateDe3.setImageResource(R.drawable.ic_star_unfill)
            icRateDe4.setImageResource(R.drawable.ic_star_unfill)
            icRateDe5.setImageResource(R.drawable.ic_star_unfill)
            if (selectImage == icRateDe5) {
                message.text = activity.getString(R.string.nice_thank_you_for_rate_us)
            } else {
                message.text = activity.getString(R.string.rate_this_app_amp_share_your_experience)
            }
        }

        bindingRate.txtOk.setTextColor(activity.getProperPrimaryColor())
        bindingRate.txtCancel.setTextColor(
            activity.getProperTextColor().adjustAlpha(MEDIUM_ALPHA)
        )
    }
}
