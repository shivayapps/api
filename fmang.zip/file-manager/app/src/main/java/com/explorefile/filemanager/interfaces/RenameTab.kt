package com.explorefile.filemanager.interfaces

import com.explorefile.filemanager.activities.BaseActivity

interface RenameTab {
    fun initTab(activity: BaseActivity, paths: ArrayList<String>)

    fun dialogConfirmed(useMediaFileExtension: Boolean, callback: (success: Boolean) -> Unit)
}
