package com.explorefile.filemanager.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.FilesTypesActivity
import com.explorefile.filemanager.extensions.adjustAlpha
import com.explorefile.filemanager.extensions.beGone
import com.explorefile.filemanager.extensions.beVisible
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.helpers.MEDIUM_ALPHA

class MimeTypesFolderAdapter(
    val context: FilesTypesActivity,
    private val dataList: List<String>,
    val itemClick: (String) -> Unit
) :
    RecyclerView.Adapter<MimeTypesFolderAdapter.ViewHolder>() {
    private var selectedItemPosition = 0
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_mime_typle_folder, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = dataList[position]
        holder.bind(item.substringAfterLast("/"))

        holder.itemView.setOnClickListener {
            itemClick(item)
            val clickedPosition = holder.adapterPosition
            if (selectedItemPosition != clickedPosition) {
                val previousSelectedItemPosition = selectedItemPosition
                selectedItemPosition = clickedPosition
                notifyItemChanged(previousSelectedItemPosition)
                notifyItemChanged(clickedPosition)
            }
        }

        if (selectedItemPosition == position) {
            holder.itemView.findViewById<ImageView>(R.id.image_line).beVisible()
            holder.itemView.findViewById<TextView>(R.id.txt_folder_name)
                .setTextColor(context.getProperPrimaryColor())
        } else {
            holder.itemView.findViewById<ImageView>(R.id.image_line).beGone()
            holder.itemView.findViewById<TextView>(R.id.txt_folder_name)
                .setTextColor(context.getProperTextColor().adjustAlpha(MEDIUM_ALPHA))
        }
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(item: String) {
            itemView.findViewById<TextView>(R.id.txt_folder_name).text = item
        }
    }
}