package com.explorefile.filemanager.extensions

import android.content.Context
import android.content.res.Configuration
import android.view.ViewGroup
import com.explorefile.filemanager.R
import com.explorefile.filemanager.views.MyAppCompatCheckbox
import com.explorefile.filemanager.views.MyButton
import com.explorefile.filemanager.views.MyCompatRadioButton
import com.explorefile.filemanager.views.MyEditText
import com.explorefile.filemanager.views.MyFloatingActionButton
import com.explorefile.filemanager.views.MyTextInputLayout
import com.explorefile.filemanager.views.MyTextView

// handle system default theme (Material You) specially as the color is taken from the system, not hardcoded by us
fun Context.getProperTextColor() = baseConfig.textColor

fun Context.getProperBackgroundColor() = baseConfig.backgroundColor
fun Context.getCardBackgroundColor() = baseConfig.cardColor

fun Context.getProperPrimaryColor() = when {
    isWhiteTheme() || isBlackAndWhiteTheme() -> baseConfig.accentColor
    else -> baseConfig.primaryColor
}

fun Context.getProperStatusBarColor() = when {
    else -> getProperBackgroundColor()
}

// get the color of the statusbar with material activity, if the layout is scrolled down a bit
fun Context.getColoredMaterialStatusBarColor(): Int {
    return getProperPrimaryColor()
}

fun Context.updateTextColors(viewGroup: ViewGroup) {
    val textColor = baseConfig.textColor

    val backgroundColor = baseConfig.backgroundColor
    val accentColor = when {
        isWhiteTheme() || isBlackAndWhiteTheme() -> baseConfig.accentColor
        else -> getProperPrimaryColor()
    }

    val cnt = viewGroup.childCount
    (0 until cnt).map { viewGroup.getChildAt(it) }.forEach {
        when (it) {
            is MyTextView -> it.setColors(textColor, accentColor, backgroundColor)
            is MyCompatRadioButton -> it.setColors(textColor, accentColor, backgroundColor)
            is MyAppCompatCheckbox -> it.setColors(textColor, accentColor, backgroundColor)
            is MyEditText -> it.setColors(textColor, accentColor, backgroundColor)
            is MyFloatingActionButton -> it.setColors(textColor, accentColor, backgroundColor)
            is MyButton -> it.setColors(textColor, accentColor, backgroundColor)
            is MyTextInputLayout -> it.setColors(textColor, accentColor, backgroundColor)
            is ViewGroup -> updateTextColors(it)
        }
    }
}

fun Context.isBlackAndWhiteTheme() =
    baseConfig.textColor == getColor(R.color.theme_dark_text_color) && baseConfig.primaryColor == getColor(
        R.color.color_primary
    ) && baseConfig.backgroundColor == getColor(R.color.theme_dark_background_color)

fun Context.isWhiteTheme() =
    baseConfig.textColor == getColor(R.color.theme_light_text_color) && baseConfig.primaryColor == getColor(
        R.color.color_primary
    ) && baseConfig.backgroundColor == getColor(R.color.theme_light_background_color)

fun Context.isUsingSystemDarkTheme() =
    resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_YES != 0

