package com.explorefile.filemanager.filecleaner.viewmodel

import android.graphics.Color
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.explorefile.filemanager.filecleaner.entity.StorageScanResult
import com.explorefile.filemanager.filecleaner.service.FileScanService

import java.util.concurrent.CancellationException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors

class StorageAnalysisVM : ViewModel() {

    private val fileScanService = FileScanService()
    private val scanExecutors = Executors.newFixedThreadPool(2)

    val scanResult = MutableLiveData<StorageScanResult>()

    val sabData = MutableLiveData<Array<Pair<Float, Int>>?>()

    fun startScanStorage() {
        val storageScanResult = StorageScanResult()
        scanResult.value = storageScanResult
        sabData.value = null
        viewModelScope.launch(Dispatchers.IO) {
            val countDownLatch = CountDownLatch(1)
            scanExecutors.execute {
                try {
                    val fileScanResultSummary = try {
                        fileScanService.start()
                    } catch (e: CancellationException) {
                        return@execute
                    }
                    storageScanResult.file = fileScanResultSummary
                    scanResult.postValue(storageScanResult)
                } finally {
                    countDownLatch.countDown()
                }
            }

            countDownLatch.await()
//            val appResult = storageScanResult.app
            val fileResult = storageScanResult.file
//            if (appResult!= null && fileResult != null) {
            if (fileResult != null) {
                val storageStat = fileScanService.calcStorageStatFs()
                val storageTotalSize = storageStat.totalSize
                storageScanResult.stat = storageStat
                storageScanResult.calcOtherSizeIfCan()
                scanResult.postValue(storageScanResult)
                sabData.postValue(
                    arrayOf(
//                        (appResult.queueSize.get() * 1000 / storageTotalSize / 1000f) to ContextCompat.getColor(app.applicationContext,R.color.ff00bcd4),
                        (fileResult.image.queueSize.get() * 1000 / storageTotalSize / 1000f) to Color.parseColor("#fff08273"),
                        (fileResult.video.queueSize.get() * 1000 / storageTotalSize / 1000f) to Color.parseColor("#ffc897f0"),
                        (fileResult.audio.queueSize.get() * 1000 / storageTotalSize / 1000f) to Color.parseColor("#ff8cb2fc"),
                        (fileResult.document.queueSize.get() * 1000 / storageTotalSize / 1000f) to Color.parseColor("#ffceaf81"),
                        (fileResult.apkFile.queueSize.get() * 1000 / storageTotalSize / 1000f) to Color.parseColor("#ffa5d934"),
                        (fileResult.compressedFile.queueSize.get() * 1000 / storageTotalSize / 1000f) to Color.parseColor("#ff94a6be"),
                        (fileResult.emptyDir.queueSize.get() * 1000 / storageTotalSize / 1000f) to Color.parseColor("#ff55afb7"),
                        (fileResult.noExt.queueSize.get() * 1000 / storageTotalSize / 1000f) to Color.parseColor("#ff4673ab"),
                        (fileResult.unknownExt.queueSize.get() * 1000 / storageTotalSize / 1000f) to Color.parseColor("#ff8ea9bc"),
                        (storageScanResult.other!! * 1000 / storageTotalSize / 1000f) to Color.parseColor("#ff868895"),
                    )
                )
            }
        }
    }

    fun stopScanStorageIfNeed() {
        fileScanService.stopIfNeed()
    }

    override fun onCleared() {
        super.onCleared()
        scanExecutors.shutdownNow()
    }

}