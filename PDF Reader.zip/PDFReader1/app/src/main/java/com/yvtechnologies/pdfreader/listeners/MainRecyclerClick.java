package com.yvtechnologies.pdfreader.listeners;

import java.io.File;

public interface MainRecyclerClick {
    void onItemClick(int position);
    void onEditClick(int position);
}

