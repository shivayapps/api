package com.yvtechnologies.pdfreader.utils;

public class Constants {
    public static String PDFPATH = "pdfpath";
    public static String PDFFEEDBACK = "PDF Reader Send Feedback";
}
