package com.hd.wallpaper.solid.color.background.model

import android.graphics.Color
import android.graphics.drawable.GradientDrawable

class ColorModel {
    var color1 = 0
    var color2 = 0
    var orientation: GradientDrawable.Orientation? = null
    var circle = false
    var imagePosition = -1
    var imageColor = Color.WHITE
    var colorFilterColor = Color.WHITE

}