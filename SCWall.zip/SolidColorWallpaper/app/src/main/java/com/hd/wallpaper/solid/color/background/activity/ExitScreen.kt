package com.hd.wallpaper.solid.color.background.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.databinding.ActivityExitBinding

class ExitScreen : AppCompatActivity() {


    lateinit var binding:ActivityExitBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_exit_screen)
        binding= ActivityExitBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Handler(Looper.getMainLooper()).postDelayed({
           finishAffinity()
        },2000)
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finishAffinity()
    }

    override fun onPause() {
        super.onPause()
        finishAffinity()
    }
}