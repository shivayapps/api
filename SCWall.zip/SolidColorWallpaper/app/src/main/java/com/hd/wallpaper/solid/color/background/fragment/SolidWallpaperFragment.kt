package com.hd.wallpaper.solid.color.background.fragment

import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.activity.HomeActivity
import com.hd.wallpaper.solid.color.background.activity.SetWallpaperActivity
import com.hd.wallpaper.solid.color.background.adapter.ColorAdepter
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.custom.GridSpacingItemDecoration
import com.hd.wallpaper.solid.color.background.model.SolidColorModel
import java.util.*

class SolidWallpaperFragment : Fragment {
    // TODO: Rename and change types of parameters
    private var mParam1: String? = null
    private var mParam2: String? = null
    private var mColors: ArrayList<SolidColorModel>? = null
    private var mListener: OnFragmentInteractionListener? = null
    private var onScrollChangeevent: onScrollChange? = null

    constructor() {
        // Required empty public constructor
    }

    constructor(onScrollCh: onScrollChange?) {
        // Required empty public constructor
        onScrollChangeevent = onScrollCh
    }

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null) {
            mParam1 = arguments!!.getString(ARG_PARAM1)
            mParam2 = arguments!!.getString(ARG_PARAM2)
        }
    }

    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                     savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_solid_wallpaper, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mColors = ArrayList()
        val allColors: Array<String> = resources.getStringArray(R.array.colors)
        for (i in allColors.indices) {
            val model: SolidColorModel = SolidColorModel()
            model.color = Color.parseColor(allColors[i])
            mColors!!.add(model)
        }
        Constants.mEmojiList.clear()

        /* String[] files = new String[0];
        try {
            files = getActivity().getAssets().list("emoji");
        } catch (IOException e) {
            e.printStackTrace();
        }
        assert files != null;
        for (String name : files) {
            Constants.mEmojiList.add("file:///android_asset/emoji" + File.separator + name);
        }*/

        /*      int k=1;
        for (int i = 0; i < allColors.length; i++) {
            SolidColorModel model=new SolidColorModel();
            model.setColor(Color.parseColor(allColors[i]));
            if (k>12){
                k=1;
            }
            model.setImagePosition(k);
            k++;
            mColors.add(model);
        }*/

        recyclerColor = view.findViewById(R.id.recyclerColor)
        recyclerColor!!.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            public override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (onScrollChangeevent != null) {
                    onScrollChangeevent!!.onScrollChangeinit(dx, dy)
                }
                super.onScrolled(recyclerView, dx, dy)
            }
        })
        val manager: GridLayoutManager = GridLayoutManager(activity, 3)
        recyclerColor!!.layoutManager = manager
        recyclerColor!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(6), true))
        recyclerColor!!.itemAnimator = DefaultItemAnimator()
        setColors()
    }

    open interface onScrollChange {
        fun onScrollChangeinit(dx: Int, dy: Int)
    }

    private fun setColors() {
        val listener: ColorAdepter.setOnItemClickListener = object : ColorAdepter.setOnItemClickListener {
            public override fun OnItemClicked(model: SolidColorModel?, i: Int) {
                if (HomeActivity.prompt != null) {
                    HomeActivity.prompt!!.dismiss()
                }
                Constants.isGradient = false
                Constants.selectedWallpaper = model
                Constants.mSolidColorWallpapers = mColors!!
                Constants.solidPosition = i
                startActivity(Intent(activity, SetWallpaperActivity::class.java))
            }
        }
        val colorAdepter: ColorAdepter = ColorAdepter(mColors!!, activity!!, listener)
        recyclerColor!!.adapter = colorAdepter
    }

    // TODO: Rename method, update argument and hook method into UI event
    fun onButtonPressed(uri: Uri?) {
        if (mListener != null) {
            mListener!!.onFragmentInteraction(uri)
        }
    }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }

    public override fun onAttach(context: Context) {
        super.onAttach(context)
    }

    public override fun onDetach() {
        super.onDetach()
        mListener = null
    }

    public override fun onResume() {
        super.onResume()
    }

    open interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        fun onFragmentInteraction(uri: Uri?)
    }

    companion object {
        // TODO: Rename parameter arguments, choose names that match
        // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
        private val ARG_PARAM1: String = "param1"
        private val ARG_PARAM2: String = "param2"
        var recyclerColor: RecyclerView? = null
    }
}