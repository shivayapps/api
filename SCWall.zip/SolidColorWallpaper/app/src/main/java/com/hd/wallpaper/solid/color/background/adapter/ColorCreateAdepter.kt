package com.hd.wallpaper.solid.color.background.adapter

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.hd.wallpaper.solid.color.background.R
import java.util.*

class ColorCreateAdepter(private val mColors: ArrayList<Int>, private val mContext: Activity, private val mListener: setOnItemClickListener) : RecyclerView.Adapter<ColorCreateAdepter.MyViewHolder>() {
    private var LastSelectedView: MyViewHolder? = null
    private var LastSelectedItem = 0
    private val isFirst = true

    interface setOnItemClickListener {
        fun OnItemClicked(color: Int,activity: Activity)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.row_color_small, null))
    }

    override fun onBindViewHolder(myViewHolder: MyViewHolder, i: Int) {
        val shape = GradientDrawable()
        shape.shape = GradientDrawable.RECTANGLE
        shape.setColor(mColors[i])
        shape.cornerRadius = 10f
        shape.setStroke(2, Color.BLACK)
        myViewHolder.imgColor.background = shape
        if (LastSelectedItem == mColors[i]) {
            myViewHolder.selectedView.visibility = View.VISIBLE
        } else {
            myViewHolder.selectedView.visibility = View.GONE
        }
        myViewHolder.imgColor.setOnClickListener {
            mListener.OnItemClicked(mColors[i],mContext)
            LastSelectedView = myViewHolder
            LastSelectedItem = mColors[i]
            notifyDataSetChanged()
        }
    }

    override fun getItemCount(): Int {
        return mColors.size
    }

    fun setColor(color: Int) {
        LastSelectedItem = color
        notifyDataSetChanged()
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgColor: ImageButton = itemView.findViewById(R.id.imgThumbColor)
        var txtNone: ImageView = itemView.findViewById(R.id.txtNone)
        var selectedView: ImageView = itemView.findViewById(R.id.selectedView)

    }

}