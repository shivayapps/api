package com.hd.wallpaper.solid.color.background.model

class GradientSelectableModel(var colorModel: ColorModel, var isDeletable: Boolean)