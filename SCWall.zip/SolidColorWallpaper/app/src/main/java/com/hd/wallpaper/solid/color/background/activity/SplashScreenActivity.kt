package com.hd.wallpaper.solid.color.background.activity

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.airbnb.lottie.LottieAnimationView
import com.google.android.gms.common.GooglePlayServicesUtil
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.databinding.ActivitySplashScreenBinding
import com.hd.wallpaper.solid.color.background.helper.InAppBillingHandler.Companion.bindServiceIntent
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.getBoolean
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.save
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref

import java.text.SimpleDateFormat
import java.util.*

class SplashScreenActivity : AppCompatActivity() {
    private val animation: LottieAnimationView? = null
    private val animation1: LottieAnimationView? = null

    var LicenseKey: String = ""
    private var mContext: Context? = null
    private var productKeyMonth: String = "" /*productKeyMonthDiscount = "",*/
    private var productKey3Month: String = ""

    /*productKeyMonthDiscount = "",*/
    private var productKeyYear: String = ""
    private var productKeyRemoveAds: String = ""
    private var isAnimEnd: Boolean = false
    private var sharedPref: MySharedPref? = null
    private val txtSolidColor: ImageView? = null
    private val imgLogo: ImageView? = null
//    private var view1: View? = null
//    private var view2: View? = null
//    private var view3: View? = null
//    private var view4: View? = null
//    private var view5: View? = null
//    private var view6: View? = null

    var mServiceConn: ServiceConnection = object : ServiceConnection {
        public override fun onServiceDisconnected(name: ComponentName) {}
        public override fun onServiceConnected(name: ComponentName, service: IBinder) {
        }
    }

    lateinit var binding:ActivitySplashScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivitySplashScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_splash_screen)
//        Helper().startDataSync(this, this)
//        mInterstitialAd = InterstitialAd(this)
//        instance!!.openManager.fetchAd()
//        if (!getBoolean(this@SplashScreenActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
//            instance!!.openManager.fetchAd()
//        }

        mContext = this@SplashScreenActivity
        sharedPref = MySharedPref(mContext)
        initBillingProcessor()
        hideSystemUI()
//        view1 = binding.view1
//        view2 = binding.view2
//        view3 = binding.view3
//        view4 = binding.view4
//        view5 = binding.view5
//        view6 = binding.view6
//        binding.bottomTextCst.post {
//            Log.d("TAG=====>", "run: " + binding.bottomTextCst.height)
//            binding.imgMainVector.animate()
//                .translationYBy(-binding.bottomTextCst.height.toFloat())
//                .setDuration(1000).withEndAction {
//                binding.bottomTextCst.visibility = View.VISIBLE
//                binding.bottomTextCst.animate().alpha(1f).setDuration(400)
//                    .start()
//                binding.view1!!.animate().alpha(0.15f).setDuration(100).withEndAction {
//                    binding.view2!!.animate().alpha(0.15f).setDuration(100).withEndAction {
//                        binding.view3!!.animate().alpha(0.15f).setDuration(100).withEndAction {
//                            binding.view4!!.animate().alpha(0.15f).setDuration(100).withEndAction {
//                                binding.view5!!.animate().alpha(0.15f).setDuration(100).withEndAction {
//                                    binding.view6!!.animate().alpha(0.15f).setDuration(100).withEndAction {
//                                        binding.view1!!.animate().translationX(-200f).setDuration(20000)
//                                            .start()
//                                        binding.view1!!.animate().translationY(200f).setDuration(20000)
//                                            .start()
//                                        binding.view2!!.animate().translationXBy(200f).setDuration(20000)
//                                            .start()
//                                        binding.view2!!.animate().translationYBy(-200f).setDuration(20000)
//                                            .start()
//                                        binding.view3!!.animate().translationX(-200f).setDuration(20000)
//                                            .start()
//                                        binding.view3!!.animate().translationYBy(200f).setDuration(20000)
//                                            .start()
//                                        binding.view4!!.animate().translationX(100f).setDuration(20000)
//                                            .start()
//                                        binding.view4!!.animate().translationY(-200f).setDuration(20000)
//                                            .start()
//                                        binding.view5!!.animate().translationXBy(-200f).setDuration(20000)
//                                            .start()
//                                        binding.view5!!.animate().translationY(-200f).setDuration(20000)
//                                            .start()
//                                        binding.view6!!.animate().translationX(200f).setDuration(20000)
//                                            .start()
//                                        binding.view6!!.animate().translationYBy(-100f).setDuration(20000)
//                                            .start()
//                                    }.start()
//                                }.start()
//                            }.start()
//                        }.start()
//                    }.start()
//                }.start()
//            }.start()
//        }

        Handler().postDelayed({
            if (!isFinishing) {
                if (sharedPref!!.needToshowLanguage()) {
                    val c: Date = Calendar.getInstance().time
                    val df = SimpleDateFormat("dd-MMM-yyyy",Locale.ENGLISH)
                    val formattedDate: String = df.format(c)
//
                    save(this@SplashScreenActivity, AdsPrefs.ADS_FREE_DATE, formattedDate)
                    startActivity(
                        Intent(
                            this@SplashScreenActivity,
                            LanguageSelectionActivity::class.java
                        )
                    )
                    finish()

                } else if (!getBoolean(this@SplashScreenActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        startActivity(
                            Intent(
                                this@SplashScreenActivity,
                                MainStartActivity::class.java
                            )
                        )
                        finish()
                    }, 100)
                } else {
                    startActivity(Intent(this@SplashScreenActivity, MainStartActivity::class.java))
                    finish()

                }
            }
        }, 1500)
    }

    private fun initBillingProcessor() {
        //productKeyMonthDiscount = getString(R.string.ads_product_key_monthlydiscount);
        productKeyMonth = getString(R.string.ads_product_key_month)
        productKey3Month = getString(R.string.ads_product_key_month_3)
        productKeyYear = getString(R.string.ads_product_key_year)
        productKeyRemoveAds = getString(R.string.ads_product_key)
        LicenseKey = getString(R.string.licenseKey)
        Log.d("TAG=========>", "initBillingProcessor: ")
        bindServices()
    }

    private fun bindServices() {
        try {
            bindService(bindServiceIntent, mServiceConn, Context.BIND_AUTO_CREATE)
        } catch (e: Exception) {
            Log.d("TAG=====>>>>>", "bindServices: catch ")
            e.printStackTrace()
        }
    }

    private fun hideSystemUI() {
        // Set the IMMERSIVE flag.
        // Set the content to appear under the system bars so that the content
        // doesn't resize when the system bars hide and show.
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN /*
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar*/
                or View.SYSTEM_UI_FLAG_FULLSCREEN // hide status bar
                or View.SYSTEM_UI_FLAG_IMMERSIVE)
        window.decorView.setOnSystemUiVisibilityChangeListener { i ->
            if (i == 0 && View.SYSTEM_UI_FLAG_FULLSCREEN == 0) {
                window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN /*
                                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar*/
                        or View.SYSTEM_UI_FLAG_FULLSCREEN // hide status bar
                        or View.SYSTEM_UI_FLAG_IMMERSIVE)
            }
        }
    }


    override fun onResume() {
        super.onResume()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
    }

    public override fun onDestroy() {
        try {
            unbindService(mServiceConn)
        } catch (e: java.lang.Exception) {
        }
        super.onDestroy()
    }


    companion object {
        private val TAG: String = "SplashScreen12345"
        fun isPlayStoreInstalled(context: Context): Boolean {
            try {
                context.packageManager
                    .getPackageInfo(GooglePlayServicesUtil.GOOGLE_PLAY_STORE_PACKAGE, 0)
                return true
            } catch (e: PackageManager.NameNotFoundException) {
                return false
            }
        }
    }
}