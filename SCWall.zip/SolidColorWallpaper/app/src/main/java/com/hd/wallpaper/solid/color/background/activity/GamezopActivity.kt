package com.hd.wallpaper.solid.color.background.activity

import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.databinding.ActivityGamezopBinding


class GamezopActivity : AppCompatActivity() {

    lateinit var binding:ActivityGamezopBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityGamezopBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_gamezop)

        binding.webView.settings.javaScriptEnabled = true

        binding.webView.loadUrl("https://www.gamezop.com/?id=Y2_mvlugT")

        binding.webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                binding.lottieAnimation.visibility = View.GONE
                binding.webView.visibility = View.VISIBLE
            }
        }
    }

    override fun onBackPressed() {
        if (binding.webView != null && binding.webView.canGoBack()) {
            binding.webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun applyOverrideConfiguration(overrideConfiguration: Configuration) {
        if (Build.VERSION.SDK_INT in 21..22) {
            return
        }
        super.applyOverrideConfiguration(overrideConfiguration)
    }
}