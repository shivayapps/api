package com.hd.wallpaper.solid.color.background.activity

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver.Companion.cancelAlarm

import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.adapter.LiveWallpaperListAdapter
import com.hd.wallpaper.solid.color.background.adapter.WallpaperLiveSubImageAdapter
import com.hd.wallpaper.solid.color.background.adhelper.InterstitialAdHelper.isShowInterstitialAd
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.custom.BottomSheetFragment
import com.hd.wallpaper.solid.color.background.custom.GridSpacingItemDecoration
import com.hd.wallpaper.solid.color.background.databinding.ActivityAutoWallpaperChangerMainTestBinding
import com.hd.wallpaper.solid.color.background.model.AutoWallpaperModel
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.getBoolean
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelperAutoWallpaper
import java.io.File
import java.util.*

class AutoWallpaperChangerMainTestActivity constructor() : AppCompatActivity(), View.OnClickListener {
//    private var btnNext: ImageView? = null
//    private var btnShare: ImageView? = null
//    private var icSubcription: ImageView? = null
//    private var icBack: ImageView? = null
//    private var layoutMainWallpaperList: ConstraintLayout? = null
//    private var layoutNoWallpaper: ConstraintLayout? = null
//    private var wallpaperLive: ConstraintLayout? = null
//    private var btnAddWallpaper: CustomLinearLayout? = null
    private var bottomSheetFragment:BottomSheetFragment?=null

    //  private RecyclerView recyclerMainWallpaer;
    private var mContext: Context? = null
    private var mAllWallpaperList: ArrayList<AutoWallpaperModel>? = null
    private var dbHelperAutoWallpaper: DBHelperAutoWallpaper? = null
    private val liveWallpaperAdapter: LiveWallpaperListAdapter? = null
    private var mySharedPref: MySharedPref? = null
    private var isEditClicked: Boolean = false
    private var isEdit: Boolean = false
    private var isDelete: Boolean = false
//    var recyclerWallpaper: RecyclerView? = null
//    var imgrandomWatch: ImageView? = null
//    var btnDelete: ImageView? = null
//    var btnEdit: ImageView? = null
//    var btnPlay: ImageView? = null
//    var txtDelayTime: TextView? = null

    lateinit var binding:ActivityAutoWallpaperChangerMainTestBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_auto_wallpaper_changer_main_test)
        binding= ActivityAutoWallpaperChangerMainTestBinding.inflate(layoutInflater)
        setContentView(binding.root)
        System.gc()
        Runtime.getRuntime().gc()
        mContext = this@AutoWallpaperChangerMainTestActivity
        initViews()
        initViewAction()
        initListner()
    }

    private fun initViews() {
//        icBack = findViewById(R.id.icBack)
//        icSubcription = findViewById(R.id.icSubcription)
//        btnNext = findViewById(R.id.btnNext)
//        btnShare = findViewById(R.id.btnShare)
//        btnAddWallpaper = findViewById(R.id.btnAddWallpaper)
//        layoutMainWallpaperList = findViewById(R.id.layoutMainWallpaperList)
//        //    recyclerMainWallpaer = findViewById(R.id.recyclerMainWallpaer);
//        layoutNoWallpaper = findViewById(R.id.layoutNoWallpaper)
//        wallpaperLive = findViewById(R.id.wallpaperLive)
//        recyclerWallpaper = findViewById(R.id.recyclerWallpaper)
//        txtDelayTime = findViewById(R.id.txtDelayTime)
//        btnEdit = findViewById(R.id.btnEdit)
//        btnDelete = findViewById(R.id.btnDelete)
//        imgrandomWatch = findViewById(R.id.imgrandomWatch)
//        btnPlay = findViewById(R.id.btnPlay)
    }

    private fun initViewAction() {
        mySharedPref = MySharedPref(mContext)
        if (getBoolean(mContext, AdsPrefs.IS_SUBSCRIBED, false)) {
            binding.btnShare!!.setVisibility(View.VISIBLE)
            binding.icSubcription!!.setVisibility(View.GONE)
        } else {
            binding.btnShare!!.setVisibility(View.GONE)
            binding.icSubcription!!.setVisibility(View.VISIBLE)
            isShowInterstitialAd{

            }
        }
        mAllWallpaperList = ArrayList()
        dbHelperAutoWallpaper = DBHelperAutoWallpaper(mContext)
        mAllWallpaperList = dbHelperAutoWallpaper!!.allAutoWallpaper
        if (mAllWallpaperList!!.size > 0) {
            binding.btnAddWallpaper!!.setVisibility(View.GONE)
        } else {
            binding.btnAddWallpaper!!.setVisibility(View.VISIBLE)
        }
        val manager: GridLayoutManager = GridLayoutManager(this@AutoWallpaperChangerMainTestActivity, 3)
        binding.recyclerWallpaper!!.setLayoutManager(manager)
        binding.recyclerWallpaper!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(8), true))
        binding.recyclerWallpaper!!.setItemAnimator(DefaultItemAnimator())
        setDataToAdapter()
    }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = getResources()
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.getDisplayMetrics()))
    }

    private val dataWallpaper: Unit
        private get() {
            mAllWallpaperList!!.clear()
            mAllWallpaperList = dbHelperAutoWallpaper!!.allAutoWallpaper
        }

    private fun setDataToAdapter() {
        val cacheDir: String = "/Pictures/.autowallpaper"
        val fullCacheDir: File = File(Environment.getExternalStorageDirectory().toString(), cacheDir)
        mAllWallpaperList = dbHelperAutoWallpaper!!.allAutoWallpaper
        if (mAllWallpaperList!!.size > 0 && mAllWallpaperList!!.get(0).status == 1) {
            binding.imgrandomWatch!!.setImageDrawable(getResources().getDrawable(R.drawable.ic_random_select))
            binding.btnPlay!!.setImageDrawable(getResources().getDrawable(R.drawable.ic_stop))
        } else {
            binding.btnPlay!!.setImageDrawable(getResources().getDrawable(R.drawable.ic_play_auto))
            binding.imgrandomWatch!!.setImageDrawable(getResources().getDrawable(R.drawable.ic_random_unselect))
        }
        if (mAllWallpaperList!!.size > 0 && fullCacheDir.exists()) {
            binding.wallpaperLive!!.setVisibility(View.VISIBLE)
            binding.layoutNoWallpaper!!.setVisibility(View.GONE)
            val model: AutoWallpaperModel = mAllWallpaperList!!.get(0)
            val time: String?
            if (model.delaytime!!.contains("C")) {
                time = model.delaytime!!.replace("C", "").trim({ it <= ' ' })
            } else {
                time = model.delaytime
            }
            binding.txtDelayTime!!.setText(time)
            val gson: Gson = Gson()
            val token: TypeToken<ArrayList<String?>?> = object : TypeToken<ArrayList<String?>?>() {}
            val mImages: ArrayList<String> = gson.fromJson(model.imagespath, token.getType())
            val adapter: WallpaperLiveSubImageAdapter = WallpaperLiveSubImageAdapter((mContext)!!, mImages)
            binding.recyclerWallpaper!!.setAdapter(adapter)

            /*    recyclerMainWallpaer.setLayoutManager(new LinearLayoutManager(mContext, RecyclerView.VERTICAL, false));

            liveWallpaperAdapter = new LiveWallpaperListAdapter(mAllWallpaperList, mContext, new LiveWallpaperListAdapter.OnSelectAction() {
                @Override
                public void onPlay(AutoWallpaperModel autoWallpaperModel) {
                    dbHelperAutoWallpaper.updateDataRow(autoWallpaperModel.getId());
                    setAlarmAuto(autoWallpaperModel);
                }

                @Override
                public void onEdit(AutoWallpaperModel autoWallpaperModel) {
                    editWallpaper(autoWallpaperModel);
                }

                @Override
                public void onDelete(AutoWallpaperModel autoWallpaperModel) {
                    Log.d(TAG, "onDelete: "+isDelete);
                    if (!isDelete) {
                        showRemoveDialog(autoWallpaperModel);
                        isDelete = true;
                    }
                }
            });
            recyclerMainWallpaer.setAdapter(liveWallpaperAdapter);*/
        } else {
            try {
                deleteRecursive(fullCacheDir)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            dbHelperAutoWallpaper!!.deleteAllData()
            binding.wallpaperLive!!.setVisibility(View.GONE)
            binding.layoutNoWallpaper!!.setVisibility(View.VISIBLE)
        }
    }

    fun deleteRecursive(fileOrDirectory: File) {
        if (fileOrDirectory.isDirectory() && fileOrDirectory.listFiles() != null) for (child: File in fileOrDirectory.listFiles()) deleteRecursive(child)
        fileOrDirectory.delete()
    }

    private fun editWallpaper(autoWallpaperModel: AutoWallpaperModel) {
        if (!isEdit) {
            isEditClicked = true
            isEdit = true
            Constants.isAddWallpaperClicked = false
            val i: Intent = Intent(this@AutoWallpaperChangerMainTestActivity, AutoWallpaperChangerTestActivity::class.java)
            i.putExtra("AutoObject", autoWallpaperModel)
            startActivityForResult(i, 10)
        }
    }

    private fun initListner() {
        binding.icBack!!.setOnClickListener(this)
        binding.icSubcription!!.setOnClickListener(this)
        binding.btnShare!!.setOnClickListener(this)
        binding.btnNext!!.setOnClickListener(this)
        binding.btnAddWallpaper!!.setOnClickListener(this)
        binding.btnPlay!!.setOnClickListener(this)
        binding.btnEdit!!.setOnClickListener(this)
        binding.btnDelete!!.setOnClickListener(this)
        findViewById<View>(R.id.toolbar).setOnClickListener(this)
    }

    public override fun onClick(v: View) {
        when (v.getId()) {
            R.id.icBack -> onBackPressed()
            R.id.icSubcription -> showAd()
            R.id.btnShare -> shareApp()
            R.id.btnAddWallpaper -> {
                binding.btnAddWallpaper!!.setEnabled(false)
                mAllWallpaperList = dbHelperAutoWallpaper!!.allAutoWallpaper
                Constants.isAddWallpaperClicked = mAllWallpaperList!!.size > 0
                onClickAddWallpaper()
            }
            R.id.btnPlay -> if (mAllWallpaperList!!.size > 0 && mAllWallpaperList!!.get(0).status == 1) {
                binding.btnPlay!!.setImageDrawable(getResources().getDrawable(R.drawable.ic_play_auto))
                val autoWallpaperModel: AutoWallpaperModel = mAllWallpaperList!!.get(0)
                autoWallpaperModel.status = 0
                dbHelperAutoWallpaper!!.updateDataToDB(autoWallpaperModel)
                if (mySharedPref!!.alarmId != -1) {
                    cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), (mContext)!!, EventReceiver::class.java)
                }
                showSnackbar(getResources().getString(R.string.wallpaper_changer_disnabled))
                binding.imgrandomWatch!!.setImageDrawable(getResources().getDrawable(R.drawable.ic_random_unselect))
            } else {
                val autoWallpaperModel: AutoWallpaperModel = mAllWallpaperList!!.get(0)
                autoWallpaperModel.status = 1
                dbHelperAutoWallpaper!!.updateDataToDB(autoWallpaperModel)
                binding.imgrandomWatch!!.setImageDrawable(getResources().getDrawable(R.drawable.ic_random_select))
                binding.btnPlay!!.setImageDrawable(getResources().getDrawable(R.drawable.ic_stop))
                if (mAllWallpaperList!!.size > 0) {
                    setAlarmAuto(mAllWallpaperList!!.get(0))
                }
            }
            R.id.btnEdit -> if (mAllWallpaperList!!.size > 0) {
                editWallpaper(mAllWallpaperList!!.get(0))
            }
            R.id.btnDelete -> if (mAllWallpaperList!!.size > 0) {
                if (!isDelete) {
                    showRemoveDialog(mAllWallpaperList!!.get(0))
                    isDelete = true
                }

                Log.d("PANKAJ", "onClick: ")
            }
        }
    }

    private fun showAd() {
        if (!getBoolean(this@AutoWallpaperChangerMainTestActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            isShowInterstitialAd{

            }
        }
    }

    private fun shareApp() {
        val shareIntent: Intent = Intent(Intent.ACTION_SEND)
        shareIntent.setType("text/plain")
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage: String = ""
        shareMessage += "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, getResources().getString(R.string.choose_one)))
    }

    private fun onClickAddWallpaper() {
        isEditClicked = false
        try {
            startActivityForResult(Intent(this@AutoWallpaperChangerMainTestActivity, AutoWallpaperChangerTestActivity::class.java), 10)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setAlarmAuto(model: AutoWallpaperModel?) {
        if (model == null) {
            return
        }
        binding.imgrandomWatch!!.setImageDrawable(getResources().getDrawable(R.drawable.ic_random_select))
        binding.btnPlay!!.setImageDrawable(getResources().getDrawable(R.drawable.ic_stop))
        val calendar: Calendar = Calendar.getInstance()
        val id: Int = 0
        if (mySharedPref!!.alarmId != -1) {
            cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), (mContext)!!, EventReceiver::class.java)
        }
        val myIntent: Intent = Intent(mContext, EventReceiver::class.java)
        val pendingIntent: PendingIntent = PendingIntent.getBroadcast(mContext, ("2121" + id).toInt(), myIntent, PendingIntent.FLAG_IMMUTABLE)
        val alarmManager: AlarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        mySharedPref!!.alarmId = 0
        var timeInterval: Int = 0
        val interval: String? = model.delaytime
        if ((interval == "Random")) {
            timeInterval = 60 * 1000
        } else {
            if (interval!!.contains("C")) {
                interval.replace("C", "")
                interval.trim({ it <= ' ' })
            }
            val time1: Array<String> = interval.split(" ".toRegex()).toTypedArray()
            if (time1.size == 0) {
                return
            }
            val mTime: String = time1.get(0)
            val intve: Array<String> = mTime.split(":".toRegex()).toTypedArray()
            if (intve.size == 0) {
                return
            }
            val hr: Int = intve.get(0).toInt() * 60 * 60 * 1000
            val mn: Int = intve.get(1).toInt() * 60 * 1000
            val sec: Int = intve.get(2).toInt() * 1000
            timeInterval = hr + mn + sec
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    pendingIntent
            )
        } else {
            alarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    pendingIntent
            )
        }


        /*  if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
            alarmManager.setRepeating(
                    AlarmManager.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    timeInterval,
                    pendingIntent
            );
            new MySharedPref(mContext).setAlarm(id, true);
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis() + timeInterval,
                        pendingIntent
                );
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis() + timeInterval,
                        pendingIntent
                );
            } else {
                alarmManager.set(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis() + timeInterval,
                        pendingIntent
                );
            }
        }*/showSnackbar(getResources().getString(R.string.wallpaper_changer_enabled))
    }


    private fun showSnackbar(msg: String) {
        val snackbar: Snackbar = Snackbar.make(findViewById(R.id.mainLayout), msg, Snackbar.LENGTH_SHORT)
        val v: View = snackbar.getView()
        val params: CoordinatorLayout.LayoutParams = v.getLayoutParams() as CoordinatorLayout.LayoutParams
        params.gravity = Gravity.BOTTOM
        params.width = FrameLayout.LayoutParams.MATCH_PARENT
        v.setLayoutParams(params)
        v.setBackgroundColor(getResources().getColor(R.color.colorStart))
        val textView: TextView = v.findViewById(com.google.android.material.R.id.snackbar_text)
        textView.setTextColor(getResources().getColor(R.color.white))
        snackbar.show()
    }

    private fun showRemoveDialog(autoWallpaperModel: AutoWallpaperModel) {
       bottomSheetFragment = BottomSheetFragment(resources.getString(R.string.delete), getResources().getString(R.string.are_you_want_to_remove), getResources().getString(R.string.delete), getResources().getString(R.string.cancel), R.drawable.ic_delete_dialog, object : BottomSheetFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                try {
                    val cacheDir: String = "/Pictures/.autowallpaper"
                    val fullCacheDir: File = File(Environment.getExternalStorageDirectory().toString(), cacheDir)
                    deleteRecursive(fullCacheDir)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                if (dbHelperAutoWallpaper != null) {
                    if (autoWallpaperModel.status == 1) {
                        if (mySharedPref!!.alarmId != -1) {
                            cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), (mContext)!!, EventReceiver::class.java)
                        }
                    }
                    dbHelperAutoWallpaper!!.deleteData(autoWallpaperModel.id)
                    dataWallpaper
                    if (mAllWallpaperList!!.size > 0) {
                        binding.wallpaperLive!!.setVisibility(View.VISIBLE)
                        binding.btnAddWallpaper!!.setVisibility(View.GONE)
                        binding.layoutNoWallpaper!!.setVisibility(View.GONE)
                        val model: AutoWallpaperModel = mAllWallpaperList!!.get(0)
                        val time: String?
                        if (model.delaytime!!.contains("C")) {
                            time = model.delaytime!!.replace("C", "").trim({ it <= ' ' })
                        } else {
                            time = model.delaytime
                        }
                        binding.txtDelayTime!!.setText(time)
                        val gson: Gson = Gson()
                        val token: TypeToken<ArrayList<String?>?> = object : TypeToken<ArrayList<String?>?>() {}
                        val mImages: ArrayList<String> = gson.fromJson(model.imagespath, token.getType())
                        val adapter: WallpaperLiveSubImageAdapter = WallpaperLiveSubImageAdapter((mContext)!!, mImages)
                        binding.recyclerWallpaper!!.setAdapter(adapter)
                    } else {
                        binding.wallpaperLive!!.setVisibility(View.GONE)
                        binding.layoutNoWallpaper!!.setVisibility(View.VISIBLE)
                        binding.btnAddWallpaper!!.setVisibility(View.VISIBLE)
                    }
                }
                bottomSheetDialo!!.dismiss()
                isDelete = false
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
                isDelete = false
            }
        })
        bottomSheetFragment!!.setCancelable(false)
        bottomSheetFragment!!.show(getSupportFragmentManager(), "dialog")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        System.gc()
        Runtime.getRuntime().gc()
        if (requestCode == 10) {
            if (resultCode == Activity.RESULT_OK) {
                mAllWallpaperList!!.clear()
                mAllWallpaperList = dbHelperAutoWallpaper!!.allAutoWallpaper
                if (mAllWallpaperList!!.size > 0) {
                    binding.btnAddWallpaper!!.visibility = View.GONE
                } else {
                    binding.btnAddWallpaper!!.visibility = View.VISIBLE
                }
                mAllWallpaperList!!.get(0).status = 1
                setDataToAdapter()
                if (isEditClicked) {
                    isEditClicked = false
                    if (dbHelperAutoWallpaper != null) {
                        setAlarmAuto(mAllWallpaperList!!.get(0))
                    }
                }
            }
            if (resultCode == Activity.RESULT_CANCELED) {
            }
        }
    }

    override fun onResume() {
        super.onResume()
        isEdit = false
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
        if (binding.btnAddWallpaper != null) {
            binding.btnAddWallpaper!!.setEnabled(true)
        }
        if (Constants.isSubscribedW) {
            Constants.isSubscribedW = false
            recreate()
        }

        Log.d("PANKAJ", "onResume: ")
    }

    override fun onPause() {
        super.onPause()
        try {
            bottomSheetFragment!!.dismiss()
            isDelete=false
        }catch (e:Exception){

        }

    }
    companion object {
        private val TAG: String = "AutoWallpaperChangerMai"
    }
}