package com.hd.wallpaper.solid.color.background.adhelper

import android.app.Activity
import android.view.View
import android.widget.FrameLayout
import androidx.annotation.NonNull


class NativeAdvancedModelHelper(private val mContext: Activity)  {
    fun loadNativeAdvancedAd(
        @NonNull fSize: String,
        @NonNull fLayout: FrameLayout,
        fCustomAdView: View? = null,
        isNeedLayoutShow: Boolean = true,
        isAddVideoOptions: Boolean = true,
        isAdLoaded: (isNeedToRemoveCloseButton: Boolean) -> Unit = {},
        onClickAdClose: () -> Unit = {}
    ) {

    }
}