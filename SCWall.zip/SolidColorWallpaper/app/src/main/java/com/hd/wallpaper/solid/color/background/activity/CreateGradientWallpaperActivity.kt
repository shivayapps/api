package com.hd.wallpaper.solid.color.background.activity


import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ProgressDialog
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.wifiproxysettingslibrary.NetworkHelper
import com.wifiproxysettingslibrary.wifi_network.exceptions.ApiNotSupportedException
import com.wifiproxysettingslibrary.wifi_network.exceptions.NullWifiConfigurationException
import com.wifiproxysettingslibrary.wifi_network.wifi_proxy_changing_realisations.api_from_21_to_22.WifiConfiguration
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition

import com.jaredrummler.android.colorpicker.ColorPickerDialog
import com.jaredrummler.android.colorpicker.ColorPickerDialogListener

import com.hd.wallpaper.solid.color.background.paint_view.showToast
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.adapter.ColorCreateAdepter
import com.hd.wallpaper.solid.color.background.adapter.ColorCreateAdepter.setOnItemClickListener
import com.hd.wallpaper.solid.color.background.adapter.EmojiImagesAdapter
import com.hd.wallpaper.solid.color.background.adapter.EmojiImagesAdapter.OnItemClickListener
import com.hd.wallpaper.solid.color.background.adapter.StickerAdapter
import com.hd.wallpaper.solid.color.background.adhelper.InterstitialAdHelper.isShowInterstitialAd
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.constants.Constants.mGalleryBitmap
import com.hd.wallpaper.solid.color.background.constants.Constants.mGalleryUri
import com.hd.wallpaper.solid.color.background.custom.BottomSheetFragment
import com.hd.wallpaper.solid.color.background.custom.BottomSheetFragmentDiscard
import com.hd.wallpaper.solid.color.background.custom.MatrixClonable
import com.hd.wallpaper.solid.color.background.databinding.ActivityCreateGradientWallpaperBinding
import com.hd.wallpaper.solid.color.background.fragment.BottomsheetForgroundFragment
import com.hd.wallpaper.solid.color.background.fragment.BottomsheetStickerFragment
import com.hd.wallpaper.solid.color.background.imagePicker.ui.imagepicker.ImagePicker
import com.hd.wallpaper.solid.color.background.model.*
import com.hd.wallpaper.solid.color.background.model.StickerModel
import com.hd.wallpaper.solid.color.background.model.api.DataItem
import com.hd.wallpaper.solid.color.background.model.api.ImageItem
import com.hd.wallpaper.solid.color.background.newModel.ImagesItem
import com.hd.wallpaper.solid.color.background.newModel.WallpaperWeekModelNewResponse
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.getBoolean
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelper
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelperResolution
import com.xiaopo.flying.sticker.*
import com.xiaopo.flying.sticker.StickerView.OnStickerOperationListener
import java.io.File
import java.io.IOException
import java.lang.reflect.InvocationTargetException
import java.util.*
import kotlin.collections.ArrayList

class CreateGradientWallpaperActivity constructor() : AppCompatActivity(), View.OnClickListener,
    ColorPickerDialogListener {
    internal lateinit var stickerFragment: BottomsheetStickerFragment
    internal lateinit var forgroundFragment: BottomsheetForgroundFragment
    private var imgColor: CardView? = null
    private var icBack: ImageView? = null
    private var imgEmoji: ImageView? = null
    private var btnNext: ImageView? = null
    private var btnAddColor1: ImageView? = null
    private var btnAddColor2: ImageView? = null
    private var imageRotate: ImageView? = null
    private var imageGradient: ImageView? = null
    private var layoutOpacity: LinearLayout? = null
    private var mainBottomlayoutSelect: LinearLayout? = null
    private var layoutStickerColor: LinearLayout? = null
    private lateinit var verticalView: View
    private lateinit var horizontalView: View
    private var layoutSticker: LinearLayout? = null
    private var layoutImage: LinearLayout? = null
    private var btnCenterColor: LinearLayout? = null
    private var btnRotateColor: LinearLayout? = null

    // private var cradientCancel: LinearLayout? = null
    private var btnColorLayout: LinearLayout? = null
    private var colors: IntArray = IntArray(2)
    private var isColor1: Boolean = false
    private var isColor2: Boolean = false
    private var orientation: GradientDrawable.Orientation? = GradientDrawable.Orientation.TOP_BOTTOM
    private var mCurrentOrientation: Int = 0
    private var isCenter: Boolean = false
    private var isCircle: Boolean = false
    private var layoutRecycler: RelativeLayout? = null
    private var layoutColor: ConstraintLayout? = null
    private var mImageList: ArrayList<String>? = null
    private var imgForGallery: LinearLayout? = null
    private var imgGallery: ImageView? = null
    private var mySharedPref: MySharedPref? = null
    private var recyclerColor: RecyclerView? = null
    private var recyclerEmojiImage: RecyclerView? = null
    private var layoutEmojiRecycler: ConstraintLayout? = null
    private var layoutColorRecycler: ConstraintLayout? = null
    private var layoutEmojiMoreAPI: LinearLayout? = null
    private var layoutNoneEmoji: LinearLayout? = null
    private var seekBarOpacity: SeekBar? = null
    private var mColors: ArrayList<Int>? = null
    private var imgNoneColor: ImageView? = null
    private var btnNon: LinearLayout? = null
    private var progressBar: ProgressDialog? = null
    private var LayoutseekBarOpacity: LinearLayout? = null
    private var mSelectedEmojiPosition: Int = -1
    private var mSelectedColor: Int = Color.WHITE
    private var opacity: Float = 1f
    private var emojiOpacity: Float = 1f
    private var isEmojiSelected: Boolean = false
    private var isColorSelected: Boolean = false
    private var isColor2Selected: Boolean = false
    private var selectedColor: Int = Color.parseColor("#EBEBEB")
    private var selectedColor2: Int = Color.parseColor("#EBEBEB") //-8241345;
    private var isProgressed: Boolean = false
    private var isimageSelect: Boolean = false
    private var oldpos: Int = 0
    private var recyclerSticker: RecyclerView? = null
    private var layoutStickerRecycler: ConstraintLayout? = null
    private var sticker_view: StickerView? = null
    private var mSelectedSticker: DrawableSticker? = null
    private var imgGradient: ImageView? = null
    private var adapter: EmojiImagesAdapter? = null
    private var btnHeaderText: TextView? = null

    // private var layoutColorButton: LinearLayout? = null
    private var colorAdepter: ColorCreateAdepter? = null
    private var isColorOpen: Boolean = false
    private var isOpacityOpen: Boolean = false
    private var layoutMoreAPI: LinearLayout? = null
    private var layoutNoneSticker: LinearLayout? = null

    private var mForegroundList: ArrayList<ImageItem>? = null
    private var mDataList: ArrayList<DataItem>? = null

    private var mDataListNewResponse: ArrayList<com.hd.wallpaper.solid.color.background.newModel.DataItem>? =
        null
    private var mForegroundListNewResponse: ArrayList<ImagesItem?>? = null
    private var mDataListNewResponseMain: ArrayList<com.hd.wallpaper.solid.color.background.newModel.DataItem>? =
        null
    private var mAllReadyDataNewResponse: ArrayList<ArrayList<WallpaperWeekModelNewResponse?>>? =
        null
    private var mAllReadyDataStickerNewResponse: ArrayList<ArrayList<WallpaperWeekModelNewResponse?>>? =
        null

    private var mSelectedEmojiPath: String? = null
    private var emojiPath: String? = null
    private var receiver: Receiver? = null

    var bottomSheetFragment: BottomSheetFragmentDiscard? = null

    private val orientations: Array<GradientDrawable.Orientation> = arrayOf(
        GradientDrawable.Orientation.TOP_BOTTOM,
        GradientDrawable.Orientation.TR_BL,
        GradientDrawable.Orientation.RIGHT_LEFT,
        GradientDrawable.Orientation.BR_TL,
        GradientDrawable.Orientation.BOTTOM_TOP,
        GradientDrawable.Orientation.BL_TR,
        GradientDrawable.Orientation.LEFT_RIGHT,
        GradientDrawable.Orientation.TL_BR
    )
    internal lateinit var activity: CreateGradientWallpaperActivity
    private var mStickerList: ArrayList<String>? = null

//    private var mStickerModelList: ArrayList<StickerNewModel>? = null
    private var mStickerModelList: ArrayList<String>? = null
//    private var mScreenModelList: ArrayList<ScreenModel>? = null
    private var mScreenModelList: ArrayList<String>? = null

    private var isStickerSelected: Boolean = false
    private var dbHelper: DBHelper? = null
    private var stickerAdapter: StickerAdapter? = null

    private var mAllStickers: ArrayList<StickerModel>? = null
    private var mDataListNew: ArrayList<DataItem>? = null

    private var categoryNameList: ArrayList<CategoryNameIconModel>? = null
    private var categoryNameListSticker: ArrayList<CategoryNameIconModel>? = null

    private var mAllReadyData: ArrayList<ArrayList<WallpaperWeekModel?>>? = null
    private var mAllReadyDataSticker: ArrayList<ArrayList<WallpaperWeekModel?>>? = null

    private var isMoreAPIClicked: Boolean = false
    private var isMoreAPIScreenClicked: Boolean = false
    var r = Random()

    lateinit var binding: ActivityCreateGradientWallpaperBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_create_gradient_wallpaper)
        binding = ActivityCreateGradientWallpaperBinding.inflate(layoutInflater)
        setContentView(binding.root)
        System.gc()
        receiver = Receiver()

        mySharedPref = MySharedPref(this)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            startActivity(
                Intent(
                    this@CreateGradientWallpaperActivity,
                    MainStartActivity::class.java
                )
            )
            finish()
        } else {
            initViews()
            initViewAction()
            initListner()
        }
        registerReceiver(receiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))
    }

    private fun initListner() {
        icBack!!.setOnClickListener(this)
        imgForGallery!!.setOnClickListener(this)
        btnColorLayout!!.setOnClickListener(this)
        imgGallery!!.setOnClickListener(this)
        btnNext!!.setOnClickListener(this)
        btnAddColor1!!.setOnClickListener(this)
        btnAddColor2!!.setOnClickListener(this)
        btnCenterColor!!.setOnClickListener(this)
        btnRotateColor!!.setOnClickListener(this)
        layoutSticker!!.setOnClickListener(this)
        layoutOpacity!!.setOnClickListener(this)
        layoutImage!!.setOnClickListener(this)
        layoutStickerColor!!.setOnClickListener(this)
        // cradientCancel!!.setOnClickListener(this)
        //layoutColorButton!!.setOnClickListener(this)
        layoutMoreAPI!!.setOnClickListener(this)
        layoutNoneSticker!!.setOnClickListener(this)
        layoutEmojiMoreAPI!!.setOnClickListener(this)
        layoutNoneEmoji!!.setOnClickListener(this)
        imgNoneColor!!.setOnClickListener(this)
        btnNon!!.setOnClickListener(this)
    }

    private fun isNetworkConnected(): Boolean {
        val cm: ConnectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.activeNetworkInfo != null && cm.activeNetworkInfo!!.isConnected
    }

    private fun initViewAction() {
        layoutImage!!.alpha = 0.5f
        layoutOpacity!!.alpha = 0.5f
        layoutSticker!!.alpha = 0.5f
        layoutStickerColor!!.alpha = 0.5f
        btnColorLayout!!.alpha = 0.5f
        imgForGallery!!.alpha = 0.5f

        mAllStickers = ArrayList()
        dbHelper = DBHelper(this@CreateGradientWallpaperActivity)
        mGalleryBitmap = null
        if (!getBoolean(this@CreateGradientWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            Constants.isInstrastial1 = false
            isShowInterstitialAd {

            }
        }
        mForegroundList = ArrayList()

        mForegroundListNewResponse = ArrayList()

        mDataList = ArrayList()
        mDataListNew = ArrayList()

        mDataListNewResponseMain = ArrayList()
        mDataListNewResponse = ArrayList()
        try {
            checkStatus()
        } catch (e: InvocationTargetException) {
            e.printStackTrace()
        } catch (e: NoSuchMethodException) {
            e.printStackTrace()
        } catch (e: ApiNotSupportedException) {
            e.printStackTrace()
        } catch (e: NoSuchFieldException) {
            e.printStackTrace()
        } catch (e: IllegalAccessException) {
            e.printStackTrace()
        } catch (e: NullWifiConfigurationException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        com.jaredrummler.android.colorpicker.Constants.isSelectedBottom1 = false
        com.jaredrummler.android.colorpicker.Constants.isSelectedBottom2 = false
        Constants.SOLID_CREATE_SELECTED_EMOJI_IMAGE = null
        Constants.SOLID_CREATE_SELECTED_EMOJI_IMAGE_COLOR = -1
        Constants.SOLID_CREATE_OPACITY = 1f
        MyEmojiList(this).execute()
        fetchColors()
        btnNext!!.isEnabled = false
        if (Constants.isFromFrag) {
            layoutColor!!.visibility = View.GONE
            //layoutColorButton!!.visibility = View.GONE
            btnHeaderText!!.text = resources.getString(R.string.edit)
            val model: ColorModel? = Constants.selectedGWallpaper

            colors = intArrayOf(model!!.color1, model.color2)

            selectedColor = model.color1
            selectedColor2 = model.color2
            if (model.circle) {
                imgColor!!.post(Runnable { setCircleGradient(false) })
            } else {
                setGradientDrawable(model.orientation)
            }
            orientation = model.orientation
            isCircle = model.circle
            btnNext!!.alpha = 1f
            btnNext!!.isEnabled = true
            isColorSelected = true
            isColor2Selected = true
            isProgressed = true
//            oncliEmoji()
            onclikColor()
            imgEmoji!!.post(Runnable {
                if (model.imagePosition != -1) {
                    Glide.with(this@CreateGradientWallpaperActivity)
                        .load(Constants.mEmojiList[model.imagePosition])
                        .into(object : CustomTarget<Drawable?>() {
                            public override fun onResourceReady(
                                resource: Drawable,
                                transition: Transition<in Drawable?>?
                            ) {
                                isEmojiSelected = true
                                mSelectedEmojiPosition = model.imagePosition
                                imgEmoji!!.setImageDrawable(resource)
                                if (adapter != null) {
                                    adapter!!.setSelectedPosition(model.imagePosition)
                                }
                            }

                            public override fun onLoadCleared(placeholder: Drawable?) {}
                        })
                } else {
                    if (adapter != null) {
                        adapter!!.setSelectedPosition(-1)
                    }
                }
            })
        } else {
            layoutColor!!.visibility = View.GONE
            //  layoutColorButton!!.visibility = View.VISIBLE
            btnHeaderText!!.text = resources.getString(R.string.create)
//            btnNext!!.isEnabled = false
            //layoutColorButton!!.alpha = 1f
//            oncliEmoji()
            onclikColor()

            //open by default add menu
            onClick(mainBottomlayoutSelect as View)

        }
        setStatusbarColor()
        val d: Drawable = changeDrawableColor(
            this,
            R.drawable.ic_back_,
            getResources().getColor(R.color.colorPrimary)
        )
        icBack!!.setImageDrawable(d)
        seekBarOpacity!!.max = 255
        seekBarOpacity!!.progress = 255
        seekBarOpacity!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {

            public override fun onProgressChanged(
                seekBar: SeekBar,
                progress: Int,
                fromUser: Boolean
            ) {
                if (isEmojiSelected || isStickerSelected) {
                    opacity = seekBar.progress.toFloat() / 255
                    if (opacity > 0.15f) {
                        emojiOpacity = opacity
                        imgEmoji!!.alpha = seekBar.progress.toFloat() / 255
                        Constants.SOLID_CREATE_OPACITY = opacity

                    }
                    if (progress > 25) {
                        if (mSelectedSticker != null) {
                            mSelectedSticker!!.alpha = progress
                            sticker_view!!.invalidate()
                        }
                    }

                } else {
                    Toast.makeText(
                        this@CreateGradientWallpaperActivity,
                        getResources().getString(R.string.toast_wallpaper_set_seccessfully),
                        Toast.LENGTH_SHORT
                    ).show()
                    oncliEmoji()
                }
            }

            public override fun onStartTrackingTouch(seekBar: SeekBar) {}
            public override fun onStopTrackingTouch(seekBar: SeekBar) {

            }
        })
        // openEmojiList();
        openColorList()
        onStickerChange()
        addIcon()


    }

    private fun initViews() {
//        imgForGallery = findViewById(R.id.imgForGallery)
//        imgGallery = findViewById(R.id.imgGallery)
//        icBack = findViewById(R.id.icBack)
//        mainBottomlayoutSelect = findViewById(R.id.mainBottomlayoutSelect)
//        verticalView = findViewById(R.id.verticalView)
//        horizontalView = findViewById(R.id.horizontalView)
//        btnNext = findViewById(R.id.btnNext)
//        btnAddColor1 = findViewById(R.id.btnAddColor1)
//        btnAddColor2 = findViewById(R.id.btnAddColor2)
//        btnCenterColor = findViewById(R.id.btnCenterColor)
//        btnRotateColor = findViewById(R.id.btnRotateColor)
//        btnColorLayout = findViewById(R.id.btnColorLayout)
//        imgColor = findViewById(R.id.imgColor)
//
//        imgColor!!.setCardBackgroundColor(Color.parseColor("#EBEBEB"))
//        imageGradient = findViewById(R.id.imageGradient)
//        imageRotate = findViewById(R.id.imageRotate)
//        layoutRecycler = findViewById(R.id.layoutRecycler)
//        layoutColor = findViewById(R.id.layoutColor)
//        recyclerColor = findViewById(R.id.recyclerColor)
//        layoutColorRecycler = findViewById(R.id.layoutColorRecycler)
//        recyclerEmojiImage = findViewById(R.id.recyclerEmojiImage)
//        layoutEmojiRecycler = findViewById(R.id.layoutEmojiRecycler)
//        seekBarOpacity = findViewById(R.id.seekBarOpacity)
//        LayoutseekBarOpacity = findViewById(R.id.LayoutseekBarOpacity)
//        imgEmoji = findViewById(R.id.imgEmoji)
//        recyclerSticker = findViewById(R.id.recyclerSticker)
//        layoutStickerRecycler = findViewById(R.id.layoutStickerRecycler)
//        sticker_view = findViewById(R.id.sticker_view)
//        imgGradient = findViewById(R.id.imgGradient)
//        btnHeaderText = findViewById(R.id.btnHeaderText)
//        //layoutColorButton = findViewById(R.id.layoutColorButton)
//        layoutImage = findViewById(R.id.layoutImage)
//        layoutOpacity = findViewById(R.id.layoutOpacity)
//        layoutStickerColor = findViewById(R.id.layoutStickerColor)
//        layoutSticker = findViewById(R.id.layoutSticker)
//        layoutNoneSticker = findViewById(R.id.layoutNoneSticker)
//        layoutMoreAPI = findViewById(R.id.layoutMoreAPI)
//        layoutNoneEmoji = findViewById(R.id.layoutNoneEmoji)
//        layoutEmojiMoreAPI = findViewById(R.id.layoutEmojiMoreAPI)
//        imgNoneColor = findViewById(R.id.imgNoneColor)
//        btnNon = findViewById(R.id.btnNon)
//        activity = CreateGradientWallpaperActivity()
        imgForGallery = binding.imgForGallery
        imgGallery = binding.imgGallery
        icBack = binding.icBack
        mainBottomlayoutSelect = binding.mainBottomlayoutSelect
        verticalView = binding.verticalView
        horizontalView = binding.horizontalView
        btnNext = binding.btnNext
        btnAddColor1 = binding.btnAddColor1
        btnAddColor2 = binding.btnAddColor2
        btnCenterColor = binding.btnCenterColor
        btnRotateColor = binding.btnRotateColor
        btnColorLayout = binding.btnColorLayout
        imgColor = binding.imgColor

        imgColor!!.setCardBackgroundColor(Color.parseColor("#EBEBEB"))
        imageGradient = binding.imageGradient
        imageRotate = binding.imageRotate
        layoutRecycler = binding.layoutRecycler
        layoutColor = binding.layoutColor
        recyclerColor = binding.recyclerColor
        layoutColorRecycler = binding.layoutColorRecycler
        recyclerEmojiImage = binding.recyclerEmojiImage
        layoutEmojiRecycler = binding.layoutEmojiRecycler
        seekBarOpacity = binding.seekBarOpacity
        LayoutseekBarOpacity = binding.LayoutseekBarOpacity
        imgEmoji = binding.imgEmoji
        recyclerSticker = binding.recyclerSticker
        layoutStickerRecycler = binding.layoutStickerRecycler
        sticker_view = binding.stickerView
        imgGradient = binding.imgGradient
        btnHeaderText = binding.btnHeaderText
        layoutImage = binding.layoutImage
        layoutOpacity = binding.layoutOpacity
        layoutStickerColor = binding.layoutStickerColor
        layoutSticker = binding.layoutSticker
        layoutNoneSticker = binding.layoutNoneSticker
        layoutMoreAPI = binding.layoutMoreAPI
        layoutNoneEmoji = binding.layoutNoneEmoji
        layoutEmojiMoreAPI = binding.layoutEmojiMoreAPI
        imgNoneColor = binding.imgNoneColor
        btnNon = binding.btnNon
        activity = CreateGradientWallpaperActivity()
    }

    fun addIcon() {
        val deleteIcon: BitmapStickerIcon = BitmapStickerIcon(
            ContextCompat.getDrawable(
                this,
                com.xiaopo.flying.sticker.R.drawable.sticker_ic_close_white_18dp
            ),
            BitmapStickerIcon.LEFT_TOP, resources.getDimension(R.dimen._12sdp)
        )
        deleteIcon.iconEvent = DeleteIconEvent()
        val zoomIcon: BitmapStickerIcon = BitmapStickerIcon(
            ContextCompat.getDrawable(
                this,
                com.xiaopo.flying.sticker.R.drawable.sticker_ic_scale_white_18dp
            ),
            BitmapStickerIcon.RIGHT_BOTOM, getResources().getDimension(R.dimen._12sdp)
        )
        zoomIcon.iconEvent = ZoomIconEvent()
        val flipIcon: BitmapStickerIcon = BitmapStickerIcon(
            ContextCompat.getDrawable(
                this,
                com.xiaopo.flying.sticker.R.drawable.sticker_ic_flip_white_18dp
            ),
            BitmapStickerIcon.RIGHT_TOP, getResources().getDimension(R.dimen._12sdp)
        )
        flipIcon.iconEvent = FlipHorizontallyEvent()
        sticker_view!!.icons = Arrays.asList(deleteIcon, zoomIcon, flipIcon)
        sticker_view!!.setBackgroundColor(Color.TRANSPARENT)
        sticker_view!!.isLocked = false
        sticker_view!!.isConstrained = true
    }

    @Throws(
        InvocationTargetException::class,
        NoSuchMethodException::class,
        ApiNotSupportedException::class,
        NoSuchFieldException::class,
        IllegalAccessException::class,
        NullWifiConfigurationException::class
    )
    private fun checkStatus() {
        if (!NetworkHelper.isOnline(this)) {
            mForegroundList!!.clear()
        } else {
            if (NetworkHelper.isWifiConnected(this)) {
                Log.d("7891237894565", "checkStatus: ")
                val proxy: WifiConfiguration = WifiConfiguration(this)
                if (proxy.isProxySetted) {
                    mForegroundList!!.clear()
                    return
                }
            }
            if (NetworkHelper.isVpnRunning()) {
                mForegroundList!!.clear()
                return
            }

        }
    }

    private val dataForegroundNewResponse: Unit
        private get() {

            for (i in mDataListNewResponse!!.indices) {
                if (mDataListNewResponse!!.get(i)!!.id == 4) {
                    mForegroundListNewResponse!!.addAll((mDataListNewResponse!!.get(i).images!!))
                }
            }

            var mTempForgroundList: ArrayList<WallpaperWeekModelNewResponse?>

            mAllReadyDataNewResponse = ArrayList()
            mAllReadyDataStickerNewResponse = ArrayList()

            if (mDataListNewResponseMain!!.size == 0) {
                return
            }
            categoryNameList = ArrayList()
            categoryNameListSticker = ArrayList()


            for (i in mDataListNewResponseMain!!.indices) {
                mForegroundListNewResponse!!.clear()
                if (mDataListNewResponseMain!![i].name!! == "Screen") {

                    for (j in mDataListNewResponseMain!![i].allChilds!!.indices) {
                        Log.e(
                            "TAG",
                            "assaasdasadsas: ${mDataListNewResponseMain!![i].allChilds?.get(j)!!.name} ${
                                mDataListNewResponseMain!![i].allChilds?.get(j)!!.icon
                            }   "
                        )
                        categoryNameList!!.add(
                            CategoryNameIconModel(
                                mDataListNewResponseMain!![i].allChilds?.get(
                                    j
                                )!!.name!!,
                                mDataListNewResponseMain!![i].allChilds?.get(j)!!.icon.toString()
                            )
                        )
                        mForegroundListNewResponse!!.addAll(
                            (mDataListNewResponseMain!![i].allChilds?.get(
                                j
                            )!!.images)!!
                        )

                    }

                    val mWallpaperList1: ArrayList<WallpaperWeekModelNewResponse?> = ArrayList()
                    for (j in mForegroundListNewResponse!!.indices) {
                        mWallpaperList1.add(
                            WallpaperWeekModelNewResponse(
                                mForegroundListNewResponse!![j],
                                mForegroundListNewResponse!![j]!!.isPremium != 0,
                                mForegroundListNewResponse!![j]!!.coins!!
                            )
                        )
                    }

                    mTempForgroundList = ArrayList()

                    if (getBoolean(
                            this@CreateGradientWallpaperActivity,
                            AdsPrefs.IS_SUBSCRIBED,
                            false
                        )
                    ) {
                        for (j in mWallpaperList1.indices) {
                            mWallpaperList1[j]!!.isLocked = false
                        }
                        mTempForgroundList.addAll(mWallpaperList1)
                    } else {
                        for (k in mWallpaperList1.indices) {
                            val model: WallpaperWeekModelNewResponse? = mWallpaperList1[k]
                            if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                                model.isLocked = false
                            }
                            mTempForgroundList.add(model)
                        }
                    }
                    mTempForgroundList.shuffle()
                    mAllReadyDataNewResponse!!.add(mTempForgroundList)

                } else if (mDataListNewResponseMain!![i].name!! == "Sticker") {


                    for (j in mDataListNewResponseMain!![i].allChilds!!.indices) {
                        Log.e(
                            "TAG",
                            "assaasdasadsas: ${mDataListNewResponseMain!![i].allChilds?.get(j)!!.name} ${
                                mDataListNewResponseMain!![i].allChilds?.get(j)!!.icon
                            }   "
                        )
                        categoryNameListSticker!!.add(
                            CategoryNameIconModel(
                                mDataListNewResponseMain!![i].allChilds?.get(
                                    j
                                )!!.name!!,
                                mDataListNewResponseMain!![i].allChilds?.get(j)!!.icon.toString()
                            )
                        )
                        mForegroundListNewResponse!!.addAll(
                            (mDataListNewResponseMain!![i].allChilds?.get(
                                j
                            )!!.images)!!
                        )

                    }

                    val mWallpaperList1: ArrayList<WallpaperWeekModelNewResponse?> = ArrayList()
                    for (j in mForegroundListNewResponse!!.indices) {
                        mWallpaperList1.add(
                            WallpaperWeekModelNewResponse(
                                mForegroundListNewResponse!![j],
                                mForegroundListNewResponse!![j]!!.isPremium != 0,
                                mForegroundListNewResponse!![j]!!.coins!!
                            )
                        )
                    }

                    mTempForgroundList = ArrayList()

                    if (getBoolean(
                            this@CreateGradientWallpaperActivity,
                            AdsPrefs.IS_SUBSCRIBED,
                            false
                        )
                    ) {
                        for (j in mWallpaperList1.indices) {
                            mWallpaperList1[j]!!.isLocked = false
                        }
                        mTempForgroundList.addAll(mWallpaperList1)
                    } else {
                        for (k in mWallpaperList1.indices) {
                            val model: WallpaperWeekModelNewResponse? = mWallpaperList1[k]
                            if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                                model.isLocked = false
                            }
                            mTempForgroundList.add(model)
                        }
                    }
                    mTempForgroundList.shuffle()
                    mAllReadyDataStickerNewResponse!!.add(mTempForgroundList)

                }

            }

        }

    private val dataForeground: Unit
        private get() {
            for (i in mDataList!!.indices) {
                if (mDataList!!.get(i).id == 4) {
                    mForegroundList!!.addAll((mDataList!!.get(i).image)!!)
                }
            }
            var mTempForgroundList: ArrayList<WallpaperWeekModel?>

            mAllReadyData = ArrayList()
            mAllReadyDataSticker = ArrayList()

            if (mDataListNew!!.size == 0) {
                return
            }
            categoryNameList = ArrayList()
            categoryNameListSticker = ArrayList()


            for (i in mDataListNew!!.indices) {
                mForegroundList!!.clear()
                mForegroundList!!.addAll((mDataListNew!![i].image)!!)
                val mWallpaperList1: ArrayList<WallpaperWeekModel?> = ArrayList()
                for (j in mForegroundList!!.indices) {
                    mWallpaperList1.add(
                        WallpaperWeekModel(
                            mForegroundList!![j],
                            mForegroundList!![j].isPremium != 0,
                            mForegroundList!![j].coins
                        )
                    )
                }
                if (mDataListNew!![i].name!!.contains("_Screen")) {
                    val name: Array<String> =
                        mDataListNew!![i].name!!.split("_".toRegex()).toTypedArray()
                    Log.e("TAG", "asasasasasa: ${name[name.size - 1]}")
                    if (name.isEmpty()) {
                        categoryNameList!!.add(
                            CategoryNameIconModel(
                                (mDataListNew!![i].name)!!,
                                mDataListNew!![i].icon.toString()
                            )
                        )
                    } else {
                        categoryNameList!!.add(
                            CategoryNameIconModel(
                                name[name.size - 1],
                                mDataListNew!![i].icon.toString()
                            )
                        )
                    }
                    mTempForgroundList = ArrayList()
                    if (getBoolean(
                            this@CreateGradientWallpaperActivity,
                            AdsPrefs.IS_SUBSCRIBED,
                            false
                        )
                    ) {
                        for (j in mWallpaperList1.indices) {
                            mWallpaperList1[j]!!.isLocked = false
                        }
                        mTempForgroundList.addAll(mWallpaperList1)
                    } else {
                        for (k in mWallpaperList1.indices) {
                            val model: WallpaperWeekModel? = mWallpaperList1[k]
                            if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                                model.isLocked = false
                            }
                            mTempForgroundList.add(model)
                        }
                    }
                    mTempForgroundList.shuffle()
                    mAllReadyData!!.add(mTempForgroundList)
                } else if (mDataListNew!!.get(i).name!!.contains("_Sticker")) {
                    // TODO: 29/02/20 For Sticker
                    val name: Array<String> =
                        mDataListNew!![i].name!!.split("_".toRegex()).toTypedArray()
                    if (name.isEmpty()) {
                        categoryNameListSticker!!.add(
                            CategoryNameIconModel(
                                (mDataListNew!![i].name)!!,
                                mDataListNew!![i].icon.toString()
                            )
                        )
                    } else {
                        categoryNameListSticker!!.add(
                            CategoryNameIconModel(
                                name[name.size - 1],
                                mDataListNew!![i].icon.toString()
                            )
                        )
                    }
                    mTempForgroundList = ArrayList()
                    if (getBoolean(
                            this@CreateGradientWallpaperActivity,
                            AdsPrefs.IS_SUBSCRIBED,
                            false
                        )
                    ) {
                        for (j in mWallpaperList1.indices) {
                            mWallpaperList1[j]!!.isLocked = false
                        }
                        mTempForgroundList.addAll(mWallpaperList1)
                    } else {
                        for (k in mWallpaperList1.indices) {
                            val model: WallpaperWeekModel? = mWallpaperList1[k]
                            if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                                model.isLocked = false
                            }
                            mTempForgroundList.add(model)
                        }
                    }
                    mTempForgroundList.shuffle()
                    mAllReadyDataSticker!!.add(mTempForgroundList)
                }
            }
        }

    private fun onStickerChange() {
        sticker_view!!.onStickerOperationListener = object : OnStickerOperationListener {
            public override fun onStickerAdded(sticker: Sticker) {
                isStickerSelected = true
                mSelectedSticker = sticker as DrawableSticker?
                seekBarOpacity!!.progress = 255
                colorAdepter!!.setColor(Color.WHITE)
                isProgressed = true
                btnNext!!.alpha = 1f
                btnNext!!.isEnabled = true
                addIcon()
            }

            public override fun onStickerClicked(sticker: Sticker) {
                if (verticalView.visibility.equals(View.VISIBLE)) {
                    verticalView.visibility = View.GONE
                }
                if (horizontalView.visibility.equals(View.VISIBLE)) {
                    horizontalView.visibility = View.GONE
                }

            }

            public override fun onStickerDeleted(sticker: Sticker) {
                isEmojiSelected = false
                adapter!!.setSelectedPosition(-1)
                emojiPath = null
                mSelectedEmojiPosition = -1
                imgEmoji!!.setImageDrawable(null)

                if (sticker_view!!.stickers.size == 0) {
                    isStickerSelected = false
                    isProgressed = false
                }
                if (layoutOpacity!!.alpha == 1f) {
                    isOpacityOpen = true
                    isColorOpen = false
                    //layoutColorButton!!.alpha = 0.5f
                    layoutImage!!.alpha = 0.5f
                    layoutOpacity!!.alpha = 0.5f
                    layoutSticker!!.alpha = 0.5f
                    layoutStickerColor!!.alpha = 0.5f
                    btnColorLayout!!.alpha = 0.5f
                    imgForGallery!!.alpha = 0.5f
                    layoutColor!!.visibility = View.GONE
                    layoutRecycler!!.visibility = View.GONE
                    layoutStickerRecycler!!.visibility = View.GONE
                    layoutColorRecycler!!.visibility = View.GONE
                    layoutEmojiRecycler!!.visibility = View.GONE
                    LayoutseekBarOpacity!!.visibility = View.GONE
                }
                if (layoutStickerColor!!.alpha == 1f) {
                    isColorOpen = true
                    isOpacityOpen = false
                    //layoutColorButton!!.alpha = 0.5f
                    layoutImage!!.alpha = 0.5f
                    layoutOpacity!!.alpha = 0.5f
                    layoutSticker!!.alpha = 0.5f
                    layoutStickerColor!!.alpha = 0.5f
                    btnColorLayout!!.alpha = 0.5f
                    imgForGallery!!.alpha = 0.5f
                    layoutColor!!.visibility = View.GONE
                    layoutRecycler!!.visibility = View.GONE
                    layoutStickerRecycler!!.visibility = View.GONE
                    layoutColorRecycler!!.visibility = View.GONE
                    layoutEmojiRecycler!!.visibility = View.GONE
                    LayoutseekBarOpacity!!.visibility = View.GONE
                }
            }

            public override fun onStickerDragFinished(sticker: Sticker) {
                verticalView.visibility = View.GONE
                horizontalView.visibility = View.GONE

            }

            override fun onStickerDrag(sticker: Sticker) {
                verticalView.visibility = View.VISIBLE
                horizontalView.visibility = View.VISIBLE

            }

            public override fun onStickerTouchedDown(sticker: Sticker) {
                if (sticker is DrawableSticker) {
                    addIcon()
                    mSelectedSticker = sticker
                    seekBarOpacity!!.progress = mSelectedSticker!!.alphaS
                    colorAdepter!!.setColor(sticker.color)
                    if (isColorOpen) {
                        onclickBrush()
                    } else if (isOpacityOpen) {
                        onclickOpacity()
                    }
                }
            }

            public override fun onStickerZoomFinished(sticker: Sticker) {}
            public override fun onStickerFlipped(sticker: Sticker) {}
            public override fun onStickerDoubleTapped(sticker: Sticker) {}
            public override fun onStickerEditClick(sticker: Sticker) {}
            public override fun onStickerReleased() {
                if (!isEmojiSelected && layoutOpacity!!.alpha == 1f) {
                    isOpacityOpen = true
                    isColorOpen = false
                    //layoutColorButton!!.alpha = 0.5f
                    layoutImage!!.alpha = 0.5f
                    layoutOpacity!!.alpha = 0.5f
                    layoutSticker!!.alpha = 0.5f
                    layoutStickerColor!!.alpha = 0.5f
                    btnColorLayout!!.alpha = 0.5f
                    imgForGallery!!.alpha = 0.5f
                    layoutColor!!.visibility = View.GONE
                    layoutRecycler!!.visibility = View.GONE
                    layoutStickerRecycler!!.visibility = View.GONE
                    layoutColorRecycler!!.visibility = View.GONE
                    layoutEmojiRecycler!!.visibility = View.GONE
                    LayoutseekBarOpacity!!.visibility = View.GONE
                }
                if (!isEmojiSelected && layoutStickerColor!!.alpha == 1f) {
                    isColorOpen = true
                    isOpacityOpen = false
                    //layoutColorButton!!.alpha = 0.5f
                    layoutImage!!.alpha = 0.5f
                    layoutOpacity!!.alpha = 0.5f
                    layoutSticker!!.alpha = 0.5f
                    layoutStickerColor!!.alpha = 0.5f
                    btnColorLayout!!.alpha = 0.5f
                    imgForGallery!!.alpha = 0.5f
                    layoutColor!!.visibility = View.GONE
                    layoutRecycler!!.visibility = View.GONE
                    layoutStickerRecycler!!.visibility = View.GONE
                    layoutColorRecycler!!.visibility = View.GONE
                    layoutEmojiRecycler!!.visibility = View.GONE
                    LayoutseekBarOpacity!!.visibility = View.GONE
                }
            }
        }
    }

    private fun fetchColors() {
        mColors = ArrayList()
        val allColors: Array<String> = resources.getStringArray(R.array.colors_text)
        for (allColor: String in allColors) {
            mColors!!.add(Color.parseColor(allColor))
        }
    }

    private fun openColorList() {
        val manager: LinearLayoutManager = LinearLayoutManager(this)
        manager.orientation = RecyclerView.HORIZONTAL
        recyclerColor!!.layoutManager = manager
        val listener: setOnItemClickListener = label@ object : setOnItemClickListener {
            override fun OnItemClicked(color: Int, activity: Activity) {
                if (isEmojiSelected || isStickerSelected) {
                    mSelectedColor = color
                    if (mSelectedSticker != null) {
                        mSelectedSticker!!.color = mSelectedColor
                        sticker_view!!.invalidate()
                        return
                    }
                    if (mSelectedEmojiPath == null) {
                        Glide.with(this@CreateGradientWallpaperActivity)
                            .load(mImageList!![mSelectedEmojiPosition])
                            .into(object : CustomTarget<Drawable?>() {
                                public override fun onResourceReady(
                                    resource: Drawable,
                                    transition: Transition<in Drawable?>?
                                ) {
                                    resource.colorFilter =
                                        PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
                                    imgEmoji!!.setImageDrawable(resource)
                                }

                                public override fun onLoadCleared(placeholder: Drawable?) {}
                            })
                    } else {
                        Glide.with(this@CreateGradientWallpaperActivity).load(mSelectedEmojiPath)
                            .into(object : CustomTarget<Drawable?>() {
                                public override fun onResourceReady(
                                    resource: Drawable,
                                    transition: Transition<in Drawable?>?
                                ) {
                                    resource.colorFilter =
                                        PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
                                    imgEmoji!!.setImageDrawable(resource)
                                }

                                public override fun onLoadCleared(placeholder: Drawable?) {}
                            })
                    }


                } else {
                    Toast.makeText(
                        this@CreateGradientWallpaperActivity,
                        getResources().getString(R.string.toast_wallpaper_set_seccessfully),
                        Toast.LENGTH_SHORT
                    ).show()
                    oncliEmoji()
                }
            }
        }
        colorAdepter = ColorCreateAdepter((mColors)!!, this, listener)
        recyclerColor!!.adapter = colorAdepter
    }

    private fun setStatusbarColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = Color.WHITE
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.WHITE
        }
    }

    public override fun onClick(view: View) {
        when (view.id) {
            R.id.icBack -> {
                onBackPressed()
            }

            R.id.imgNoneColor -> onclickColorNone()
            R.id.btnNon -> {
                mGalleryBitmap = null
                mGalleryUri = null

                imgGallery!!.setImageBitmap(null)

                selectedColor = Color.parseColor("#EBEBEB")
                selectedColor2 = Color.parseColor("#EBEBEB")
                btnAddColor1!!.setImageDrawable(resources.getDrawable(R.drawable.ic_gradient_select))
                btnAddColor2!!.setImageDrawable(resources.getDrawable(R.drawable.ic_gradient_select))


                colors[0] = selectedColor
                colors[1] = selectedColor2
                val shape: GradientDrawable = GradientDrawable()
                shape.setColor(selectedColor)
                imgGradient!!.setImageDrawable(shape)

                colors[0] = 0
//                colors[1] = 0
                isProgressed = false
                isimageSelect = false
                isColor2Selected = false
                isColorSelected = false

                imgForGallery!!.isEnabled = true
                btnColorLayout!!.isEnabled = true
                imgForGallery!!.isEnabled = true

                layoutColor!!.visibility = View.VISIBLE

            }

            R.id.layoutNoneEmoji -> {
                isEmojiSelected = false
                adapter!!.setSelectedPosition(-1)
                emojiPath = null
                mSelectedEmojiPosition = -1
                imgEmoji!!.setImageDrawable(null)
            }

            R.id.layoutEmojiMoreAPI -> if (!isMoreAPIScreenClicked) {
                isMoreAPIScreenClicked = true
                onclickMoreAPIEmoji()
            }

            R.id.layoutNoneSticker -> {
                if (isStickerSelected && isEmojiSelected) {
                    isStickerSelected = false
                    isEmojiSelected = false
                    adapter!!.setSelectedPosition(-1)
                    emojiPath = null
                    mSelectedEmojiPosition = -1
                    imgEmoji!!.setImageDrawable(null)
                }
                sticker_view!!.removeAllStickers()
                sticker_view!!.invalidate()
                imgForGallery!!.isEnabled = true
                btnColorLayout!!.isEnabled = true
                isStickerSelected = false

            }

            R.id.layoutMoreAPI -> if (!isMoreAPIClicked) {
                isMoreAPIClicked = true
                onClickMoreAPI()
            }

            R.id.btnNext -> {
                mySharedPref!!.countExist = mySharedPref!!.countExist + 1
                Log.d("12345", "Gradient CLICK: ${mySharedPref!!.countExist}")

//                    if (mainBottomlayoutSelect!!.visibility == View.VISIBLE) {
                imgForGallery!!.isEnabled = true
                btnColorLayout!!.isEnabled = true
//                        findViewById<ConstraintLayout>(R.id.layoutColor).visibility = View.GONE
//                        findViewById<LinearLayout>(R.id.mainBottomlayoutNoneSticker).visibility = View.GONE
                findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
                //layoutColorButton!!.alpha = 0.5f
//                        layoutImage!!.alpha = 0.5f
//                        layoutOpacity!!.alpha = 0.5f
//                        layoutSticker!!.alpha = 0.5f
//                        layoutStickerColor!!.alpha = 0.5f
//                        btnColorLayout!!.alpha = 0.5f
//                        imgForGallery!!.alpha = 0.5f
                if (isimageSelect || isColorSelected || isEmojiSelected || isStickerSelected) {

                    sticker_view!!.releaseSticker()
                    verticalView.visibility = View.GONE
                    horizontalView.visibility = View.GONE
//                        findViewById<ConstraintLayout>(R.id.layoutColor).visibility = View.GONE
//                        findViewById<LinearLayout>(R.id.mainBottomlayoutNoneSticker).visibility = View.GONE
                    findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility =
                        View.VISIBLE
                    mAllStickers!!.clear()

                    var i: Int = 0
                    while (i < sticker_view!!.stickers.size) {
                        emojiPath = null
                        val mSticker: Sticker = sticker_view!!.stickers[i]
                        var model: StickerModel?
                        val sticker1: DrawableSticker = DrawableSticker(mSticker.drawable)
                        sticker1.color = (mSticker as DrawableSticker).color
                        try {
                            sticker1.alpha = mSticker.alpha
                        } catch (e: java.lang.Exception) {
                        }
                        val matrix: MatrixClonable = MatrixClonable()
                        matrix.set(mSticker.getMatrix())
                        model = StickerModel(
                            matrix,
                            false,
                            "",
                            null,
                            0,
                            0,
                            sticker1.drawable,
                            sticker1.color,
                            sticker1.alpha
                        )
                        mAllStickers!!.add(model)
                        i++
                    }
                    if (!isColor2Selected) {
                        selectedColor2 = selectedColor
                    }
                    Constants.resolutionModelGradient = GradientResolutionModel(
                        mAllStickers,
                        imgColor!!.width,
                        imgColor!!.height,
                        selectedColor,
                        selectedColor2,
                        isCircle,
                        isCenter,
                        orientation,
                        emojiPath,
                        mSelectedColor,
                        emojiOpacity
                    )
                    DBHelperResolution(this@CreateGradientWallpaperActivity).insertResolutionModelGradient(
                        Constants.resolutionModelGradient!!
                    )


                    if (!getBoolean(
                            this@CreateGradientWallpaperActivity,
                            AdsPrefs.IS_SUBSCRIBED,
                            false
                        )
                    ) {

                        isShowInterstitialAd {
                            startActivity(
                                Intent(
                                    this@CreateGradientWallpaperActivity,
                                    GradientResolutionActivity::class.java
                                )
                            )

                        }
                    } else {
                        Log.e("TAG", "h: asddsdsdsdsdsddasdasdasd")

                        startActivity(
                            Intent(
                                this@CreateGradientWallpaperActivity,
                                GradientResolutionActivity::class.java
                            )
                        )
                    }

                } else {
                    Toast.makeText(this, getString(R.string.select_color), Toast.LENGTH_SHORT)
                        .show()
                }
            }

            R.id.btnAddColor1 -> {
                isColor1 = true
                isColor2 = false
                openColorPicker(selectedColor)
            }

            R.id.btnAddColor2 -> if (colors[0] != 0) {
                isColor1 = false
                isColor2 = true
                openColorPicker(selectedColor2)
            } else {
                Toast.makeText(
                    this,
                    getResources().getString(R.string.toast_choose_previous_color),
                    Toast.LENGTH_SHORT
                ).show()
            }

            R.id.btnCenterColor -> if (isColor2Selected) {
                setCenterDrawable()
                isCircle = true
            } else {
                Toast.makeText(
                    this,
                    getResources().getString(R.string.toast_first_choose_both_colors),
                    Toast.LENGTH_SHORT
                ).show()
            }

            R.id.imgForGallery -> onclickGallery()

            R.id.btnRotateColor -> if (isColor2Selected) {
                onclickRotateColor()
                isCircle = false
            } else {
                Toast.makeText(
                    this,
                    getResources().getString(R.string.toast_first_choose_both_colors),
                    Toast.LENGTH_SHORT
                ).show()
            }

            R.id.layoutStickerColor -> onclickBrush()
            R.id.layoutImage -> oncliEmoji()
            R.id.btnColorLayout ->
                onclikColor()


//            R.id.cradientCancel -> {
//                onBackPressed()
//            }
            R.id.layoutOpacity -> onclickOpacity()
            R.id.layoutSticker -> onclickSticker()
            R.id.layoutColorButton -> {
                isOpacityOpen = false
                isColorOpen = false
                //layoutColorButton!!.alpha = 0.5f
                layoutImage!!.alpha = 0.5f
                layoutOpacity!!.alpha = 0.5f
                layoutSticker!!.alpha = 0.5f
                layoutStickerColor!!.alpha = 0.5f
                layoutRecycler!!.visibility = View.GONE
                layoutColor!!.visibility = View.GONE
                imgForGallery!!.isEnabled = true
                btnColorLayout!!.isEnabled = true
                findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
                findViewById<LinearLayout>(R.id.bottomNoneSticker).visibility = View.GONE
            }
        }
    }

    private fun showFB() {
        if (!getBoolean(this@CreateGradientWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            isShowInterstitialAd {
                startActivity(
                    Intent(
                        this@CreateGradientWallpaperActivity,
                        GradientResolutionActivity::class.java
                    )
                )
            }
        } else {
            startActivity(
                Intent(
                    this@CreateGradientWallpaperActivity,
                    GradientResolutionActivity::class.java
                )
            )
        }

    }

    private fun onclickGallery() {
//        imgForGallery!!.isEnabled = false
//        btnColorLayout!!.isEnabled = true
//        layoutColor!!.visibility = View.GONE
//        layoutColor!!.visibility = View.VI
//        layoutColor!!.alpha = 0.5f
//        layoutImage!!.alpha = 0.5f
//        layoutOpacity!!.alpha = 0.5f
//        layoutSticker!!.alpha = 0.5f
//        layoutStickerColor!!.alpha = 0.5f
//        btnColorLayout!!.alpha=0.5f
//        imgForGallery!!.alpha=0.5f


        ImagePicker.with(this)
            .setFolderMode(true)
            .setFolderTitle("Album")
            .setMultipleMode(false)
            .setImageCount(1)
            .setMaxSize(10)
            .setBackgroundColor("#ffffff")
            .setAlwaysShowDoneButton(true)
            .setRequestCode(1111)
            .setKeepScreenOn(true)
            .start()

//        layoutColor!!.visibility = View.GONE
//        layoutRecycler!!.visibility = View.GONE
//        layoutColorRecycler!!.visibility = View.GONE
//        layoutEmojiRecycler!!.visibility = View.VISIBLE
//        layoutStickerRecycler!!.visibility = View.GONE
//        LayoutseekBarOpacity!!.visibility = View.GONE

    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1111) {
            imgForGallery!!.isEnabled = true
            btnColorLayout!!.isEnabled = true
            if (mGalleryBitmap != null) {
                try {
                    selectedColor = Color.parseColor("#EBEBEB")
                    selectedColor2 = Color.parseColor("#EBEBEB")
                    colors[0] = selectedColor
                    colors[1] = selectedColor2
//                    colors[0] = 0
//                    colors[1] = 0
                    imgGallery!!.setImageBitmap(Constants.mGalleryBitmap)
                    btnNext!!.alpha = 1f
                    isProgressed = true
                    isimageSelect = true
                    btnNext!!.isEnabled = true
                    btnAddColor1!!.setImageDrawable(resources.getDrawable(R.drawable.ic_gradient_select))
                    btnAddColor2!!.setImageDrawable(resources.getDrawable(R.drawable.ic_gradient_select))
                    // onClick(cradientCancel as View)
                } catch (e: Exception) {

                }

            }
        }
    }

    private fun onclickColorNone() {

        mSelectedColor = Color.WHITE
        adapter!!.setSelectedPosition(-1)
        colorAdepter!!.setColor(mSelectedColor)
        if (mSelectedSticker != null) {
            mSelectedSticker!!.color = mSelectedColor
            sticker_view!!.invalidate()
            return
        }
        if (mSelectedEmojiPath == null) {
            Glide.with(this@CreateGradientWallpaperActivity)
                .load(mImageList!![mSelectedEmojiPosition])
                .into(object : CustomTarget<Drawable?>() {
                    public override fun onResourceReady(
                        resource: Drawable,
                        transition: Transition<in Drawable?>?
                    ) {
                        resource.colorFilter =
                            PorterDuffColorFilter(mSelectedColor, PorterDuff.Mode.SRC_IN)
                        imgEmoji!!.setImageDrawable(resource)
                    }

                    public override fun onLoadCleared(placeholder: Drawable?) {}
                })
        } else {
            Glide.with(this@CreateGradientWallpaperActivity).load(mSelectedEmojiPath)
                .into(object : CustomTarget<Drawable?>() {
                    public override fun onResourceReady(
                        resource: Drawable,
                        transition: Transition<in Drawable?>?
                    ) {
                        resource.colorFilter =
                            PorterDuffColorFilter(mSelectedColor, PorterDuff.Mode.SRC_IN)
                        imgEmoji!!.setImageDrawable(resource)
                    }

                    public override fun onLoadCleared(placeholder: Drawable?) {}
                })
        }
    }

    private fun onclickMoreAPIEmoji() {
        if (!NetworkHelper.isOnline(this)) {
            isMoreAPIScreenClicked = false
            Toast.makeText(
                this,
                getResources().getString(R.string.check_internet_connection),
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        if (isFinishing) {
            return
        }

        try {
            val onItemSelected: BottomsheetForgroundFragment.OnItemSelected =
                object : BottomsheetForgroundFragment.OnItemSelected {
                    override fun onItemSelected(path: String?) {


                        if (path != null) {
                            Log.e("TAG", "onItemSelected11: $path")

                            findViewById<ProgressBar>(R.id.proDialog).visibility = View.VISIBLE
                            isEmojiSelected = true
                            btnNext!!.isEnabled = false
                            isStickerSelected = false
                            mSelectedColor = Color.WHITE
                            mSelectedSticker = null
                            imgEmoji!!.alpha = 1f
                            seekBarOpacity!!.progress = 255
                            adapter!!.setSelectedPosition(-1)
                            mSelectedEmojiPath = path
                            emojiPath = path
                            colorAdepter!!.setColor(mSelectedColor)
                            sticker_view!!.removeAllStickers()
                            sticker_view!!.invalidate()
                            Glide.with(this@CreateGradientWallpaperActivity).load(path)
                                .into(object : CustomTarget<Drawable?>() {
                                    override fun onResourceReady(
                                        resource: Drawable,
                                        transition: Transition<in Drawable?>?
                                    ) {
                                        resource.setColorFilter(
                                            mSelectedColor,
                                            PorterDuff.Mode.SRC_IN
                                        )
                                        imgEmoji!!.setImageDrawable(resource)
                                        findViewById<ProgressBar>(R.id.proDialog).visibility =
                                            View.GONE
                                        btnNext!!.isEnabled = true
                                    }

                                    override fun onLoadCleared(placeholder: Drawable?) {

                                    }

                                    override fun onLoadFailed(errorDrawable: Drawable?) {
                                        super.onLoadFailed(errorDrawable)
                                        findViewById<ProgressBar>(R.id.proDialog).visibility =
                                            View.GONE
                                        showToast("Image Loading Failed, Please try again")
                                        btnNext!!.isEnabled = true
                                    }
                                })
                        }
                    }

                    override fun onDismiss() {
                        isMoreAPIScreenClicked = false
                    }
                }

            if (!NetworkHelper.isOnline(this)) {
                isMoreAPIScreenClicked = false
                Toast.makeText(
                    this,
                    getResources().getString(R.string.check_internet_connection),
                    Toast.LENGTH_SHORT
                ).show()
                return
            } else {
                forgroundFragment = BottomsheetForgroundFragment(
                    this,
                    mAllReadyDataNewResponse,
                    categoryNameList,
                    onItemSelected
                )
                forgroundFragment.show(supportFragmentManager, "forground_frag")
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun onClickMoreAPI() {
        if (!NetworkHelper.isOnline(this)) {
            isMoreAPIClicked = false
            Toast.makeText(
                this,
                getResources().getString(R.string.check_internet_connection),
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        if (isFinishing) {
            return
        }
        try {
            val onItemSelected: BottomsheetStickerFragment.OnItemSelected =
                object : BottomsheetStickerFragment.OnItemSelected {
                    override fun onItemSelected(path: String?) {
                        isStickerSelected = true
                        adapter!!.setSelectedPosition(-1)
                        imgEmoji!!.setImageDrawable(null)
                        mSelectedEmojiPosition = -1
                        mSelectedEmojiPath = null
                        Glide.with(this@CreateGradientWallpaperActivity).load(path)
                            .into(object : CustomTarget<Drawable?>() {
                                override fun onResourceReady(
                                    resource: Drawable,
                                    transition: Transition<in Drawable?>?
                                ) {
                                    mSelectedSticker = DrawableSticker(resource)
                                    mSelectedSticker!!.color = Color.WHITE
                                    sticker_view!!.addSticker(mSelectedSticker!!)
                                    sticker_view!!.invalidate()
                                }

                                override fun onLoadCleared(placeholder: Drawable?) {}

                            })
                    }

                    override fun onDismiss() {
                        isMoreAPIClicked = false
                    }
                }


            if (!NetworkHelper.isOnline(this)) {
                isMoreAPIClicked = false
                Toast.makeText(
                    this,
                    resources.getString(R.string.check_internet_connection),
                    Toast.LENGTH_SHORT
                ).show()
                return
            } else {
                stickerFragment = BottomsheetStickerFragment(
                    this,
                    mAllReadyDataStickerNewResponse,
                    categoryNameListSticker,
                    onItemSelected
                )
                stickerFragment.show(supportFragmentManager, "forground_frag")
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    inner class Receiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            Log.d("dsfsdf", "onReceive:  ")
            if (!NetworkHelper.isOnline(context)) {
                try {
                    stickerFragment.dismiss()
                } catch (e: java.lang.Exception) {
                    Log.d("dsfsdf", "catch: " + e.message)
                    e.printStackTrace()
                }
            }
            if (!NetworkHelper.isOnline(context)) {
                try {
                    forgroundFragment.dismiss()
                } catch (e: java.lang.Exception) {
                    Log.d("dsfsdf", "catch: " + e.message)
                    e.printStackTrace()
                }
            }

        }
    }

    private fun openEmojiList() {
        val manager: LinearLayoutManager = LinearLayoutManager(this)
        manager.orientation = RecyclerView.HORIZONTAL
        recyclerEmojiImage!!.layoutManager = manager
        val listener: OnItemClickListener = label@ object : OnItemClickListener {
            override fun onItemClick(view: View?, position: Int, activitys: Activity) {
//                if (!mScreenModelList!![position].isFree) {
//                    if (!NetworkHelper.isOnline(this@CreateGradientWallpaperActivity)) {
//                        Toast.makeText(
//                            this@CreateGradientWallpaperActivity,
//                            getResources().getString(R.string.check_internet_connection),
//                            Toast.LENGTH_SHORT
//                        ).show()
//                        return
//                    }
//                    showAdDialog(position, true)
//                } else {
//                }

                isEmojiSelected = true
                //  isProgressed = true;
                isStickerSelected = false
                mSelectedEmojiPosition = position
                mSelectedColor = Color.WHITE
                colorAdepter!!.setColor(mSelectedColor)
                mSelectedEmojiPath = null
                emojiPath = mImageList!![position]
                if (oldpos != position) {
                    imgEmoji!!.alpha = 1f
                    seekBarOpacity!!.progress = 255
                }
                oldpos = position
                mSelectedSticker = null
                sticker_view!!.removeAllStickers()
                sticker_view!!.invalidate()
                Glide.with(this@CreateGradientWallpaperActivity).load(mImageList!![position])
                    .into(object : CustomTarget<Drawable?>() {
                        public override fun onResourceReady(
                            resource: Drawable,
                            transition: Transition<in Drawable?>?
                        ) {
                            resource.setColorFilter(mSelectedColor, PorterDuff.Mode.SRC_IN)
                            imgEmoji!!.setImageDrawable(resource)
                        }

                        public override fun onLoadCleared(placeholder: Drawable?) {}
                    })

            }
        }
        adapter = EmojiImagesAdapter(this, (mScreenModelList)!!, listener)
        recyclerEmojiImage!!.adapter = adapter
        recyclerEmojiImage!!.post(Runnable {})
    }

    private fun onclickBrush() {
        if (isEmojiSelected || sticker_view!!.handlingSticker != null) {
            btnNext!!.alpha = 1f
            btnNext!!.isEnabled = true
            isColorOpen = true
            isOpacityOpen = false
            //layoutColorButton!!.alpha = 0.5f
            layoutImage!!.alpha = 0.5f
            layoutOpacity!!.alpha = 0.5f
            layoutSticker!!.alpha = 0.5f
            layoutStickerColor!!.alpha = 1f
            btnColorLayout!!.alpha = 0.5f
            imgForGallery!!.alpha = 0.5f
            layoutColor!!.visibility = View.GONE
            layoutRecycler!!.visibility = View.VISIBLE
            layoutColorRecycler!!.visibility = View.VISIBLE
            layoutEmojiRecycler!!.visibility = View.GONE
            layoutStickerRecycler!!.visibility = View.GONE
            LayoutseekBarOpacity!!.visibility = View.GONE
        } else {
            Toast.makeText(
                this,
                getResources().getString(R.string.toast_select_wallpaper_design_first),
                Toast.LENGTH_SHORT
            ).show()
            //   oncliEmoji();
        }
    }

    private fun onclikColor() {
        imgForGallery!!.isEnabled = true
        btnColorLayout!!.isEnabled = true
        layoutColor!!.visibility = View.VISIBLE

        layoutColor!!.alpha = 1f

        btnColorLayout!!.alpha = 1f
        layoutOpacity!!.alpha = 0.5f
        layoutImage!!.alpha = 0.5f
        layoutSticker!!.alpha = 0.5f
        layoutStickerColor!!.alpha = 0.5f
        imgForGallery!!.alpha = 0.5f

        layoutRecycler!!.visibility = View.GONE
        layoutColorRecycler!!.visibility = View.GONE
        layoutEmojiRecycler!!.visibility = View.GONE
        layoutStickerRecycler!!.visibility = View.GONE
        LayoutseekBarOpacity!!.visibility = View.GONE
    }

    private fun oncliEmoji() {
//        btnNext!!.alpha = 1f
//        btnNext!!.isEnabled = true
        isOpacityOpen = false
        isColorOpen = false
        //layoutColorButton!!.alpha = 0.5f
        layoutImage!!.alpha = 1f
        layoutOpacity!!.alpha = 0.5f
        layoutSticker!!.alpha = 0.5f
        layoutStickerColor!!.alpha = 0.5f
        btnColorLayout!!.alpha = 0.5f
        imgForGallery!!.alpha = 0.5f
        layoutColor!!.visibility = View.GONE
        layoutRecycler!!.visibility = View.VISIBLE
        layoutColorRecycler!!.visibility = View.GONE
        layoutEmojiRecycler!!.visibility = View.VISIBLE
        layoutStickerRecycler!!.visibility = View.GONE
        LayoutseekBarOpacity!!.visibility = View.GONE
        recyclerSticker!!.scrollToPosition(0)
    }

    private fun onclickOpacity() {
        if (isEmojiSelected || sticker_view!!.handlingSticker != null) {
            isOpacityOpen = true
            isColorOpen = false
            //layoutColorButton!!.alpha = 0.5f
            layoutImage!!.alpha = 0.5f
            layoutOpacity!!.alpha = 1f
            layoutSticker!!.alpha = 0.5f
            layoutStickerColor!!.alpha = 0.5f
            btnColorLayout!!.alpha = 0.5f
            imgForGallery!!.alpha = 0.5f
            layoutColor!!.visibility = View.GONE
            layoutRecycler!!.visibility = View.VISIBLE
            layoutStickerRecycler!!.visibility = View.GONE
            layoutColorRecycler!!.visibility = View.GONE
            layoutEmojiRecycler!!.visibility = View.GONE
            LayoutseekBarOpacity!!.visibility = View.VISIBLE
        } else {
            Toast.makeText(
                this,
                resources.getString(R.string.toast_select_wallpaper_design_first),
                Toast.LENGTH_SHORT
            ).show()
            oncliEmoji()
        }
    }

    private fun onclickSticker() {
        isOpacityOpen = false
        isColorOpen = false
        //layoutColorButton!!.alpha = 0.5f
        layoutImage!!.alpha = 0.5f
        layoutOpacity!!.alpha = 0.5f
        layoutSticker!!.alpha = 1f
        layoutStickerColor!!.alpha = 0.5f
        btnColorLayout!!.alpha = 0.5f
        imgForGallery!!.alpha = 0.5f
        layoutColor!!.visibility = View.GONE
        layoutRecycler!!.visibility = View.VISIBLE
        layoutColorRecycler!!.visibility = View.GONE
        layoutEmojiRecycler!!.visibility = View.GONE
        layoutStickerRecycler!!.visibility = View.VISIBLE
        LayoutseekBarOpacity!!.visibility = View.GONE
        layoutColor!!.visibility = View.GONE

        val editLayoutW = imgColor!!.width.div(2)
        val editLayoutS = sticker_view!!.width
        val minW = editLayoutW.minus(15)
        val minP = minW.plus(30)
        recyclerEmojiImage!!.scrollToPosition(0)

        Log.d("RERER", "$editLayoutW $editLayoutS $minW  $minP")
    }


    private fun setCenterDrawable() {
        if (isCenter) {
            imageRotate!!.setPadding(
                getResources().getDimension(R.dimen._4sdp).toInt(),
                getResources().getDimension(R.dimen._4sdp).toInt(),
                getResources().getDimension(R.dimen._4sdp).toInt(),
                getResources().getDimension(R.dimen._4sdp).toInt()
            )
            imageRotate!!.setImageDrawable(resources.getDrawable(R.drawable.ic_rotate_gradient_new))
        } else {
            imageRotate!!.setPadding(
                getResources().getDimension(R.dimen._4sdp).toInt(),
                getResources().getDimension(R.dimen._4sdp).toInt(),
                getResources().getDimension(R.dimen._4sdp).toInt(),
                getResources().getDimension(R.dimen._4sdp).toInt()
            )
            imageRotate!!.setImageDrawable(resources.getDrawable(R.drawable.ic_circle_gradient_new))
        }
        setCircleGradient(isCenter)
    }

    private fun onclickRotateColor() {
        imageGradient!!.rotation = imageGradient!!.rotation + 45
        mCurrentOrientation = (mCurrentOrientation + 1) % orientations.size
        orientation = orientations[mCurrentOrientation]
        setGradientDrawable(orientation)
    }

    private fun openColorPicker(selectedColor2: Int) {
        if (isColor1) {
            ColorPickerDialog.newBuilder()
                .setDialogType(ColorPickerDialog.TYPE_PRESETS)
                .setAllowPresets(false)
                .setDialogId(0)
                .setColor(selectedColor2)
                .setShowAlphaSlider(true)
                .show(this)
        } else {
            ColorPickerDialog.newBuilder()
                .setDialogType(ColorPickerDialog.TYPE_PRESETS)
                .setAllowPresets(false)
                .setDialogId(1)
                .setColor(selectedColor2)
                .setShowAlphaSlider(true)
                .show(this)
        }
    }

    public override fun onBackPressed() {

//            if(isProgressed) {
//            imgForGallery!!.isEnabled = true
//            btnColorLayout!!.isEnabled = true
        btnNext!!.isEnabled = true
        btnNext!!.alpha = 1f
//            findViewById<ConstraintLayout>(R.id.layoutColor).visibility = View.GONE
//            findViewById<LinearLayout>(R.id.mainBottomlayoutNoneSticker).visibility = View.GONE
//            findViewById<ConstraintLayout>(R.id.layoutColorRecycler).visibility=View.VISIBLE
        findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
        //layoutColorButton!!.alpha = 0.5f
//            layoutImage!!.alpha = 0.5f
//            layoutOpacity!!.alpha = 0.5f
//            layoutSticker!!.alpha = 0.5f
//            layoutStickerColor!!.alpha = 0.5f
//            }else{
//                showToast("Please select color/image")
//            }
        if (isProgressed || isEmojiSelected || isStickerSelected) {
            showAlertDialog()
        } else {
            finish()
        }
    }

    public override fun onColorSelected(dialogId: Int, color: Int) {
        isColorSelected = true
        isProgressed = true
        imgGradient!!.setImageDrawable(null)
        if (mGalleryBitmap != null && !mGalleryBitmap!!.isRecycled) {
            mGalleryBitmap!!.recycle()
            mGalleryBitmap = null
        }
        imgGallery!!.setImageBitmap(null)
        if (isColor1) {
            selectedColor = color
            colors[0] = color
            if (!isColor2Selected) {
                colors[1] = color
                btnCenterColor!!.alpha = 0.5f
                btnRotateColor!!.alpha = 0.5f
                // btnNext.setEnabled(false);
                // btnNext.setAlpha(0.5f);
            }
            val shape: GradientDrawable = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.setColor(color)
            shape.cornerRadius = 18f
            shape.setStroke(3, Color.BLACK)
            btnAddColor1!!.setImageDrawable(shape)
        } else {
            isColor2Selected = true
            selectedColor2 = color
            colors[1] = color
            val shape: GradientDrawable = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.setColor(color)
            shape.cornerRadius = 18f
            shape.setStroke(3, Color.BLACK)
            btnAddColor2!!.setImageDrawable(shape)

        }
        btnAddColor2!!.alpha = 1f
        setGradientDrawable(orientation)
        btnNext!!.isEnabled = true
        btnNext!!.alpha = 1f
        if (isColor2) {
            btnRotateColor!!.alpha = 1f
            btnCenterColor!!.alpha = 1f
        }

    }

    private fun setGradientDrawable(orientation: GradientDrawable.Orientation?) {
        val shape: GradientDrawable = GradientDrawable(orientation, colors)
        shape.shape = GradientDrawable.RECTANGLE
        imgGradient!!.background = shape
    }

    private fun setCircleGradient(isInner: Boolean) {
        if (isInner) {
            val new_colors: IntArray = intArrayOf(colors.get(1), colors.get(0))
            val shape: GradientDrawable = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = new_colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = imgColor!!.width.toFloat()
            imgGradient!!.background = shape
            isCenter = false
        } else {
            val shape: GradientDrawable = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = imgColor!!.width.toFloat()
            imgGradient!!.background = shape
            isCenter = true
        }
    }

    public override fun onDialogDismissed(dialogId: Int) {}

    @SuppressLint("StaticFieldLeak")
    internal inner class MyEmojiList constructor(activity: Activity) :
        AsyncTask<Void?, Void?, Void?>() {

        val activityA = activity


        override fun onPreExecute() {
            super.onPreExecute()
            progressBar = ProgressDialog(this@CreateGradientWallpaperActivity)
            progressBar!!.setMessage(getResources().getString(R.string.dialog_msg_please_wait))
            progressBar!!.setCancelable(false)
            progressBar!!.show()
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            mStickerList!!.sort()
            mImageList!!.sort()
            mStickerModelList = ArrayList()
            for (i in mStickerList!!.indices) {
//                mStickerModelList!!.add(StickerNewModel(mStickerList!![i], true))
                mStickerModelList!!.add(mStickerList!![i])
            }
            /*if (!getBoolean(this@CreateGradientWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                for (i in mStickerList!!.indices) {
                    if ((i + 1) % 5 == 0 && !dbHelper!!.checkPathExist(mStickerList!![i])) {
                        mStickerModelList!![i].isFree = false
                    }
                }
            }*/
            mScreenModelList = ArrayList()
            for (i in mImageList!!.indices) {
//                mScreenModelList!!.add(ScreenModel(mImageList!![i], true))
                mScreenModelList!!.add(mImageList!![i])
            }
            /*if (!getBoolean(this@CreateGradientWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                for (i in mImageList!!.indices) {
                    if ((i + 1) % 5 == 0 && !dbHelper!!.checkPathExist(mImageList!![i])) {
                        mScreenModelList!![i].isFree = false
                    }
                }
            }*/
            openStickerList()
            openEmojiList()
            try {
                if ((progressBar != null) && progressBar!!.isShowing) {
                    progressBar!!.dismiss()
                }

            } catch (e: IllegalArgumentException) {
                // Handle or log or ignore
            } catch (e: Exception) {
                // Handle or log or ignore
            }
        }

        protected override fun doInBackground(vararg params: Void?): Void? {
            mImageList = ArrayList()
            mStickerList = ArrayList()
            try {
                val files: Array<String>? = assets.list("screen")
                assert(files != null)
                for (name: String in files!!) {
                    mImageList!!.add("file:///android_asset/screen" + File.separator + name)
                }
                val files1: Array<String>? = assets.list("stickers")
                assert(files1 != null)
                for (name: String in files1!!) {
                    mStickerList!!.add("file:///android_asset/stickers" + File.separator + name)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            return null
        }
    }

    private fun openStickerList() {
        val manager: LinearLayoutManager = LinearLayoutManager(this)
        manager.orientation = RecyclerView.HORIZONTAL
        recyclerSticker!!.layoutManager = manager
        val onItemClickListener: StickerAdapter.OnItemClickListener =
            label@ object : OnItemClickListener, StickerAdapter.OnItemClickListener {
                override fun onItemClick(view: View?, position: Int, activitys: Activity) {
//                    if (!mStickerModelList!![position].isFree) {
//                        if (!NetworkHelper.isOnline(this@CreateGradientWallpaperActivity)) {
//                            Toast.makeText(
//                                this@CreateGradientWallpaperActivity,
//                                getResources().getString(R.string.check_internet_connection),
//                                Toast.LENGTH_SHORT
//                            ).show()
//                            return
//                        }
//                        showAdDialog(position, false)
//                    } else {
//                    }

                    isEmojiSelected = false
                    adapter!!.setSelectedPosition(-1)
                    imgEmoji!!.setImageDrawable(null)

                    mSelectedEmojiPosition = -1
                    mSelectedEmojiPath = null
                    Glide.with(this@CreateGradientWallpaperActivity)
                        .load(mStickerList!![position])
                        .into(object : CustomTarget<Drawable?>() {
                            public override fun onResourceReady(
                                resource: Drawable,
                                transition: Transition<in Drawable?>?
                            ) {
                                mSelectedSticker = DrawableSticker(resource)
                                mSelectedSticker!!.color = Color.WHITE
                                sticker_view!!.addSticker(mSelectedSticker!!)
                                sticker_view!!.invalidate()

                            }

                            public override fun onLoadCleared(placeholder: Drawable?) {}
                        })
                }

            }
        stickerAdapter = StickerAdapter(
            this@CreateGradientWallpaperActivity,
            (mStickerModelList)!!,
            onItemClickListener,
            false
        )
        recyclerSticker!!.adapter = stickerAdapter
    }

    private fun showAdDialog(position: Int, isEmoji: Boolean) {
        val msg: String
        if (isEmoji) {
            msg = getResources().getString(R.string.wathch_video_to_unlock_screen)
        } else {
            msg = getResources().getString(R.string.wathch_video_to_unlock_sticker)
        }
        val bottomSheetFragment: BottomSheetFragment = BottomSheetFragment(
            getResources().getString(R.string.watch_video),
            msg,
            getResources().getString(R.string.watch),
            getResources().getString(R.string.cancel),
            R.drawable.ic_video,
            object : BottomSheetFragment.OnButtonClickListener {
                public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                    bottomSheetDialo!!.dismiss()
                    if (isEmoji) {
                        // User earned reward.
                        dbHelper!!.insertPath(mImageList!![position])
//                        mScreenModelList!![position].isFree = true
                        // imageLock.setVisibility(View.GONE);
                        if (adapter != null) {
                            adapter!!.notifyItemChanged(position)
                        }

                        isEmojiSelected = true
                        isStickerSelected = false
                        mSelectedEmojiPosition = position
                        emojiPath = mImageList!![position]
                        mSelectedColor = Color.WHITE
                        colorAdepter!!.setColor(mSelectedColor)
                        mSelectedEmojiPath = null
                        if (oldpos != position) {
                            imgEmoji!!.alpha = 1f
                            seekBarOpacity!!.progress = 255
                        }
                        oldpos = position
                        mSelectedSticker = null
                        sticker_view!!.removeAllStickers()
                        sticker_view!!.invalidate()
                        Glide.with(this@CreateGradientWallpaperActivity)
                            .load(mImageList!![position])
                            .into(object : CustomTarget<Drawable?>() {
                                public override fun onResourceReady(
                                    resource: Drawable,
                                    transition: Transition<in Drawable?>?
                                ) {
                                    resource.setColorFilter(
                                        mSelectedColor,
                                        PorterDuff.Mode.SRC_IN
                                    )
                                    imgEmoji!!.setImageDrawable(resource)
                                }

                                public override fun onLoadCleared(placeholder: Drawable?) {}
                            })

                        Log.d(GifLiveWallPaper.TAG, "User earned the reward.")

                    } else {

                        dbHelper!!.insertPath(mStickerList!![position])
//                        mStickerModelList!!.get(position).isFree = true
                        // imageLock.setVisibility(View.GONE);
                        if (stickerAdapter != null) {
                            stickerAdapter!!.notifyItemChanged(position)
                        }

                        isEmojiSelected = false
                        adapter!!.setSelectedPosition(-1)
                        imgEmoji!!.setImageDrawable(null)
                        mSelectedEmojiPosition = -1
                        mSelectedEmojiPath = null
//                    if (!isColorSelected) {
//                        isProgressed = false
//                    }
                        Glide.with(this@CreateGradientWallpaperActivity)
                            .load(mStickerList!![position])
                            .into(object : CustomTarget<Drawable?>() {
                                public override fun onResourceReady(
                                    resource: Drawable,
                                    transition: Transition<in Drawable?>?
                                ) {
                                    mSelectedSticker = DrawableSticker(resource)
                                    mSelectedSticker!!.color = Color.WHITE
                                    sticker_view!!.addSticker(mSelectedSticker!!)
                                    sticker_view!!.invalidate()
                                }

                                public override fun onLoadCleared(placeholder: Drawable?) {}
                            })
                        Log.d(GifLiveWallPaper.TAG, "User earned the reward.")


                    }
                }

                public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                    bottomSheetDialog!!.dismiss()
                }
            })
        bottomSheetFragment.show(supportFragmentManager, "dialog")
    }

    override fun onResume() {
        super.onResume()
        imgColor!!.setCardBackgroundColor(Color.parseColor("#EBEBEB"))
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
        if (Constants.isSubscribedW) {
            recreate()
            Constants.isSubscribedW = false
        }
    }

    override fun onPause() {
        super.onPause()

        try {
            bottomSheetFragment!!.dismiss()
        } catch (e: Exception) {

        }
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(receiver)
        } catch (e: java.lang.Exception) {

        }
    }


    private fun showAlertDialog() {
        bottomSheetFragment = BottomSheetFragmentDiscard(
            getResources().getString(R.string.discard),
            getResources().getString(R.string.do_you_want_to_discard),
            getResources().getString(R.string.discard),
            getResources().getString(R.string.cancel),
            R.drawable.ic_discard_dialog,
            object : BottomSheetFragmentDiscard.OnButtonClickListener {
                public override fun onPositive(bottomSheetDialo: BottomSheetFragmentDiscard?) {
                    bottomSheetDialo!!.dismiss()
                    finish()
                }

                public override fun onNegative(bottomSheetDialog: BottomSheetFragmentDiscard?) {
                    bottomSheetDialog!!.dismiss()
                }
            })
        bottomSheetFragment!!.show(supportFragmentManager, "dialog")
    }


    companion object {
        fun changeDrawableColor(context: Context?, icon: Int, newColor: Int): Drawable {
            val mDrawable: Drawable = ContextCompat.getDrawable((context)!!, icon)!!.mutate()
            mDrawable.colorFilter = PorterDuffColorFilter(newColor, PorterDuff.Mode.SRC_IN)
            return mDrawable
        }
    }
}