package com.hd.wallpaper.solid.color.background.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.widget.ContentLoadingProgressBar
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.hd.wallpaper.solid.color.background.R
import java.util.*

class GalleryPagerAdapter(private val context: Context, private val al_my_photos: ArrayList<String>) : PagerAdapter() {
    override fun getCount(): Int {
        return al_my_photos.size
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = inflater.inflate(R.layout.gallery_image_rv, null)

        //  TouchImageView  iv = view.findViewById(R.id.adapterImage);
        val iv = view.findViewById<ImageView>(R.id.adapterImage)
        val progress: ContentLoadingProgressBar = view.findViewById(R.id.progress_circular)
        progress.show()
        iv.visibility = View.GONE
        Glide.with(context).load(al_my_photos[position]).into(object : CustomTarget<Drawable?>() {
            override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                iv.setImageDrawable(resource)
                iv.visibility = View.VISIBLE
                progress.hide()
            }

            override fun onLoadCleared(placeholder: Drawable?) {
                progress.hide()
                iv.visibility = View.VISIBLE
            }
        })
        val viewPager = container as ViewPager
        viewPager.addView(view, 0)
        return view
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        val viewPager = container as ViewPager
        val view = `object` as View
        viewPager.removeView(view)
    }

}