package com.hd.wallpaper.solid.color.background.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.model.WallpaperWeekModel
import com.hd.wallpaper.solid.color.background.newModel.WallpaperWeekModelNewResponse
import java.util.*

class ForegroundLiveAdapter(val mForegroundList: ArrayList<WallpaperWeekModelNewResponse?>?, private val mContext: Context, private val onItemSelectedListner: OnItemSelectedListner) : RecyclerView.Adapter<ForegroundLiveAdapter.MyViewholder>() {
    private val colorFilter = 0
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewholder {
        return MyViewholder(LayoutInflater.from(mContext).inflate(R.layout.rv_foreground_live, parent, false))
    }

    override fun onBindViewHolder(holder: MyViewholder, position: Int) {
        val model = mForegroundList?.get(position)
        holder.progressContent.visibility = View.VISIBLE
        holder.imgForeground.visibility = View.GONE
        holder.layoutLock.visibility = View.GONE
        holder.layoutWatchAd.visibility = View.GONE
        if (model!!.imageItem!!.thumbImage != "") {
            Glide.with(mContext).load(model.imageItem!!.thumbImage).override(400).into(object : CustomTarget<Drawable?>() {
                override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                    holder.imgForeground.setImageDrawable(resource)
                    holder.imgForeground.visibility = View.VISIBLE
                    holder.progressContent.visibility = View.GONE

                    /*if (model.isPremium()) {
                        holder.layoutSubscribe.setVisibility(View.VISIBLE);
                        holder.layoutLock.setVisibility(View.GONE);
                    } else*/
                    /*  if (!model.isLocked()) {
                        holder.layoutWatchAd.setVisibility(View.GONE);
                        holder.layoutLock.setVisibility(View.GONE);
                    } else {
                        holder.layoutWatchAd.setVisibility(View.GONE);
                        holder.layoutLock.setVisibility(View.VISIBLE);
                        holder.txtCoin.setText(String.valueOf(model.getCoins()));
                    }*/if (!model.isLocked) {
                        holder.layoutWatchAd.visibility = View.GONE
                        holder.layoutLock.visibility = View.GONE
                    } else if (model.coins <= 10) {
                        holder.layoutWatchAd.visibility = View.VISIBLE
                        holder.layoutLock.visibility = View.GONE
                    } else {
                        holder.txtCoin.text = model.coins.toString()
                        holder.layoutLock.visibility = View.VISIBLE
                    }
                }

                override fun onLoadCleared(placeholder: Drawable?) {
                    holder.imgForeground.visibility = View.VISIBLE
                    holder.progressContent.visibility = View.GONE
                }
            })
        } else {
            Glide.with(mContext).load(model.imageItem!!.image).override(400).into(object : CustomTarget<Drawable?>() {
                override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                    holder.imgForeground.setImageDrawable(resource)
                    holder.imgForeground.visibility = View.VISIBLE
                    holder.progressContent.visibility = View.GONE

                    /* if (model.isPremium()) {
                        holder.layoutSubscribe.setVisibility(View.VISIBLE);
                        holder.layoutLock.setVisibility(View.GONE);
                    } else if*/
                    /* if (!model.isLocked()) {
                        holder.layoutWatchAd.setVisibility(View.GONE);
                        holder.layoutLock.setVisibility(View.GONE);
                    } else {
                        holder.layoutWatchAd.setVisibility(View.GONE);
                        holder.layoutLock.setVisibility(View.VISIBLE);
                        holder.txtCoin.setText(String.valueOf(model.getCoins()));
                    }*/if (!model.isLocked) {
                        holder.layoutWatchAd.visibility = View.GONE
                        holder.layoutLock.visibility = View.GONE
                    } else if (model.coins <= 10) {
                        holder.layoutWatchAd.visibility = View.VISIBLE
                        holder.layoutLock.visibility = View.GONE
                    } else {
                        holder.txtCoin.text = model.coins.toString()
                        holder.layoutLock.visibility = View.VISIBLE
                    }
                }

                override fun onLoadCleared(placeholder: Drawable?) {
                    holder.imgForeground.visibility = View.VISIBLE
                    holder.progressContent.visibility = View.GONE
                }
            })
        }
        holder.imgForeground.setOnClickListener { v: View? -> onItemSelectedListner.onItemClick(model, position) }
    }

    interface OnItemSelectedListner {
        fun onItemClick(model: WallpaperWeekModelNewResponse?, position: Int)
    }

    override fun getItemCount(): Int {
        return mForegroundList!!.size
    }

    inner class MyViewholder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgForeground: ImageView = itemView.findViewById(R.id.imgForeground)
        var txtCoin: TextView = itemView.findViewById(R.id.txtCoin)
        var mainCard: CardView = itemView.findViewById(R.id.mainCard)
        var progressContent: ProgressBar = itemView.findViewById(R.id.progressContent)
        var layoutLock: RelativeLayout = itemView.findViewById(R.id.layoutLock)
        var layoutWatchAd: RelativeLayout = itemView.findViewById(R.id.layoutWatchAd)

    }

    init {
        System.gc()
        Runtime.getRuntime().gc()
    }
}