package com.hd.wallpaper.solid.color.background.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.databinding.FragmentSliderPurchaseBinding

class SliderPurchaseFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    lateinit var binding:FragmentSliderPurchaseBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {

        binding= FragmentSliderPurchaseBinding.inflate(layoutInflater,container,false)
//        setContentView(binding.root)
//        return inflater.inflate(R.layout.fragment_slider_purchase, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val bundle = arguments

        if (bundle != null) {
            binding.mainImage.setImageResource(bundle.getInt("image_id"))
            binding.txtMainTitle.text = bundle.getString("title_msg")
            binding.txtSubMessage.text = bundle.getString("sub_msg")
        }
    }

    companion object {

        fun getInstance(bundle: Bundle): SliderPurchaseFragment {
            val fragmentSlider = SliderPurchaseFragment()
            fragmentSlider.arguments = bundle
            return fragmentSlider
        }
    }
}