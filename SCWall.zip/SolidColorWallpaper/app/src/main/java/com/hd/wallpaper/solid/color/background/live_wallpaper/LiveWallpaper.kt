package com.hd.wallpaper.solid.color.background.live_wallpaper

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Handler
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hd.wallpaper.solid.color.background.live_wallpaper.LiveWallpaper
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelperAutoWallpaper
import java.io.File
import java.util.*

class LiveWallpaper : WallpaperService() {
    // public SharedPreferences sharePref;
    var dbHelperAutoWallpaper: DBHelperAutoWallpaper? = null
    var canvasWidth = 200
    var canvasHeight = 200
    private val d = Random()
    var timeInterval = 9000
    var count = 0
    internal lateinit var imageList: Array<String>
    var file: File? = null
    var mBitmap: Bitmap? = null
    var folderPath = ""

    internal inner class WallpaperEngine : Engine() {
        private var isVisibilityChanged = false
        private val paint: Paint? = null
        internal var surfaceHolder = getSurfaceHolder()
        private val handler = Handler()
        private val runnable = Runnable {
            try {
                WallpaperEng()
            } catch (throwable: Throwable) {
                throwable.printStackTrace()
            }
        }

        @Throws(Throwable::class)
        fun WallpaperEng() {
            var canvas: Canvas?
            var th: Throwable?
            try {
                canvas = surfaceHolder.lockCanvas()
                if (canvas != null) {
                    try {
                        canvasHeight = canvas.height
                        canvasWidth = canvas.width
                        if (imageList == null || imageList!!.size <= 0) {
                            //   LiveWallpaper.this.i = BitmapFactory.decodeResource(LiveWallpaper.this.getResources(), R.drawable.k9);
                            //    canvas.drawBitmap(LiveWallpaper.this.i, 0.0f, 0.0f, this.c);
                        } else {
                            if (count < imageList!!.size) {
                                val liveWallpaper = this@LiveWallpaper
                                val sb = folderPath +
                                        imageList!![count]
                                liveWallpaper.mBitmap = BitmapFactory.decodeFile(sb)
                                if (mBitmap == null) {
                                    //  LiveWallpaper.this.i = BitmapFactory.decodeResource(LiveWallpaper.this.getResources(), R.drawable.k9);
                                }
                                assert(mBitmap != null)
                                mBitmap = Bitmap.createScaledBitmap(mBitmap!!, canvasWidth, canvasHeight, false)
                                canvas.drawBitmap(mBitmap!!, 0.0f, 0.0f, paint)
                            }
                            count = if (count < imageList!!.size - 1) {
                                count + 1
                            } else {
                                0
                            }
                        }
                    } catch (th2: Throwable) {
                        th = th2
                        if (canvas != null) {
                            surfaceHolder.unlockCanvasAndPost(canvas)
                        }
                        throw th
                    }
                }
                if (canvas != null) {
                    surfaceHolder.unlockCanvasAndPost(canvas)
                }
                handler.removeCallbacks(runnable)
                if (isVisibilityChanged) {
                    handler.postDelayed(runnable, timeInterval.toLong())
                }
            } catch (th3: Throwable) {
                canvas = null
                th = th3
                throw th
            }
        }

        private val data: Unit
            private get() {
                try {
                    val model = dbHelperAutoWallpaper!!.wallpaperModel
                    if (model != null) {
                        val interval = model.delaytime
                        timeInterval = when (interval) {
                            "5 Sec" -> 5 * 1000
                            "15 Sec" -> 15 * 1000
                            "30 Sec" -> 30 * 1000
                            "2 Min" -> 2 * 60 * 1000
                            "5 Min" -> 5 * 60 * 1000
                            "15 Min" -> 15 * 60 * 1000
                            else -> 60 * 1000
                        }
                        val gson = Gson()
                        val token: TypeToken<Array<String?>?> = object : TypeToken<Array<String?>?>() {}
                        imageList = gson.fromJson(model.imagespath, token.type)
                    }
                } catch (unused: Exception) {
                    unused.printStackTrace()
                }
            }

        override fun onDestroy() {
            super.onDestroy()
            isVisibilityChanged = false
            handler.removeCallbacks(runnable)
        }

        override fun onSurfaceChanged(surfaceHolder: SurfaceHolder, i: Int, i2: Int, i3: Int) {
            try {
                data
                WallpaperEng()
            } catch (unused: Exception) {
                unused.printStackTrace()
            } catch (throwable: Throwable) {
                throwable.printStackTrace()
            }
        }

        override fun onSurfaceCreated(surfaceHolder: SurfaceHolder) {
            data
            super.onSurfaceCreated(surfaceHolder)
        }

        override fun onSurfaceDestroyed(surfaceHolder: SurfaceHolder) {
            super.onSurfaceDestroyed(surfaceHolder)
            isVisibilityChanged = false
            handler.removeCallbacks(runnable)
        }

        override fun onVisibilityChanged(isChanged: Boolean) {
            isVisibilityChanged = isChanged
            if (isChanged) {
                data
                try {
                    WallpaperEng()
                } catch (throwable: Throwable) {
                    throwable.printStackTrace()
                }
                return
            }
            handler.removeCallbacks(runnable)
        }
    }

    override fun onCreate() {
        super.onCreate()
        dbHelperAutoWallpaper = DBHelperAutoWallpaper(this)
        //  sharePref = getSharedPreferences("com.hd.wallpaper.solid.color.background", 0);
        val model = dbHelperAutoWallpaper!!.wallpaperModel
        if (model != null) {
            val interval = model.delaytime
            timeInterval = when (interval) {
                "5 Sec" -> 5 * 1000
                "15 Sec" -> 15 * 1000
                "30 Sec" -> 30 * 1000
                "2 Min" -> 2 * 60 * 1000
                "5 Min" -> 5 * 60 * 1000
                "15 Min" -> 15 * 60 * 1000
                else -> 60 * 1000
            }
            val gson = Gson()
            val token: TypeToken<Array<String?>?> = object : TypeToken<Array<String?>?>() {}
            imageList = gson.fromJson(model.imagespath, token.type)
        }

        //  timeInterval = sharePref.getInt("timeintervel", 5000);
        /* StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory().getAbsolutePath());
        sb.append("/autochangewallpaper/");
        folderPath = sb.toString();
        file = new File(folderPath);
        if (!file.exists()) {
            file.mkdirs();
        }
        imageList = file.list();*/
    }

    override fun onCreateEngine(): Engine {
        return WallpaperEngine()
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}