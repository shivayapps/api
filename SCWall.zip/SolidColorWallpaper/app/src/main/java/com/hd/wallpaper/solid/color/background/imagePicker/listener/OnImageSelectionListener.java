package com.hd.wallpaper.solid.color.background.imagePicker.listener;

import com.hd.wallpaper.solid.color.background.imagePicker.model.Image;

import java.util.List;


public interface OnImageSelectionListener {
    void onSelectionUpdate(List<Image> images);
}
