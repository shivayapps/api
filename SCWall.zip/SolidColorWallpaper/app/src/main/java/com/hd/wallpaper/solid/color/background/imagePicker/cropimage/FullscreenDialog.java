package com.hd.wallpaper.solid.color.background.imagePicker.cropimage;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.hd.wallpaper.solid.color.background.R;


public class FullscreenDialog extends DialogFragment {

    private static final String TAG = "FullscreenDialog";

    private FullscreenDialog mDialog;
    private Context mContext;
    private Bitmap crop;

    public FullscreenDialog(Bitmap crop, Context mContext) {
        this.crop = crop;
        this.mContext=mContext;

    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.FullScreenDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.croped_viewer_dialog, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageView imgCroped=view.findViewById(R.id.imgCroped);
        imgCroped.setImageBitmap(crop);

    }


    @Override
    public void onStart() {
        super.onStart();
        int width = ViewGroup.LayoutParams.MATCH_PARENT;
        int height = ViewGroup.LayoutParams.MATCH_PARENT;
        this.getDialog().getWindow().setLayout(width, height);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }
}
