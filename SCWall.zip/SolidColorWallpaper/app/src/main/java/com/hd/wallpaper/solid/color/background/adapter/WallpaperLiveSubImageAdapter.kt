package com.hd.wallpaper.solid.color.background.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.hd.wallpaper.solid.color.background.R
import java.util.*

class WallpaperLiveSubImageAdapter(private val mContext: Context, private val mImageList: ArrayList<String>) : RecyclerView.Adapter<WallpaperLiveSubImageAdapter.MyViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val v = LayoutInflater.from(mContext).inflate(R.layout.rv_wallpaper_sub_item, null)
        return MyViewHolder(v)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.progressContent.visibility = View.VISIBLE
        holder.imgEmoji.visibility = View.GONE
        Glide.with(mContext).load(mImageList[position]).override(400).into(object : CustomTarget<Drawable?>() {
            override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                holder.imgEmoji.background = resource
                holder.progressContent.visibility = View.GONE
                holder.imgEmoji.visibility = View.VISIBLE
            }

            override fun onLoadCleared(placeholder: Drawable?) {
                holder.progressContent.visibility = View.VISIBLE
                holder.imgEmoji.visibility = View.GONE
            }
        })
    }

    override fun getItemCount(): Int {
        return mImageList.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgEmoji: ImageView = itemView.findViewById(R.id.imgImage)
        var progressContent: ProgressBar = itemView.findViewById(R.id.progressContent)

    }

    init {
        System.gc()
        Runtime.getRuntime().gc()
    }
}