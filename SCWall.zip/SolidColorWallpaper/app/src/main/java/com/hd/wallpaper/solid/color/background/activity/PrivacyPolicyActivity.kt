package com.hd.wallpaper.solid.color.background.activity

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.activity.PrivacyPolicyActivity
import com.hd.wallpaper.solid.color.background.databinding.ActivityPrivacyPolicyBinding

class PrivacyPolicyActivity constructor() : AppCompatActivity() {
//    private var mWebview: WebView? = null

    lateinit var binding:ActivityPrivacyPolicyBinding
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_privacy_policy)
        binding= ActivityPrivacyPolicyBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        mWebview = findViewById(R.id.webView)
        binding.webView!!.settings.javaScriptEnabled = true // enable javascript
        binding.webView!!.webViewClient = object : WebViewClient() {
            public override fun onReceivedError(view: WebView, errorCode: Int, description: String, failingUrl: String) {
                Toast.makeText(this@PrivacyPolicyActivity, description, Toast.LENGTH_SHORT).show()
            }
        }
        binding.webView!!.loadUrl("https://agneshpipaliya.blogspot.com/2019/03/image-crop-n-wallpaper-changer.html")
        // setContentView(mWebview);
    }

    public override fun onBackPressed() {
        if (binding.webView != null && binding.webView!!.canGoBack()) {
            binding.webView!!.goBack()
        } else {
            super.onBackPressed()
        }
    }
}