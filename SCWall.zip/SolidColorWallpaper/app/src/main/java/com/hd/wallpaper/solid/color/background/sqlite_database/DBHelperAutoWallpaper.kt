package com.hd.wallpaper.solid.color.background.sqlite_database

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.hd.wallpaper.solid.color.background.model.AutoWallpaperModel
import java.util.*

class DBHelperAutoWallpaper(context: Context?) : SQLiteOpenHelper(context, DATABASE_NAME, null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        // TODO Auto-generated method stub
        db.execSQL(
                "create table auto_wallpaper " +
                        "(id integer primary key, interval text,screen_mode text,imagespath text,status integer)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // TODO Auto-generated method stub
        //  db.execSQL("DROP TABLE IF EXISTS contacts");
        //  onCreate(db);
    }

    fun insertAutoWallpaper(model: AutoWallpaperModel) {
        val db = this.writableDatabase
        deleteAllData()
        //  updateData();
        val contentValues = ContentValues()
        contentValues.put(DELAY_TIME, model.delaytime)
        contentValues.put(SCREEN_MODE, model.screenmode)
        contentValues.put(IMAGES_PATH, model.imagespath)
        contentValues.put(STATUS, model.status)
        db.insert(CONTACTS_TABLE_NAME, null, contentValues)
    }

    fun updateDataRow(id: Int) {
        updateData()
        writableDatabase.execSQL("UPDATE $CONTACTS_TABLE_NAME SET $STATUS =  1 WHERE $ID_AUTO = $id")
    }

    fun updateData() {
        writableDatabase.execSQL("UPDATE $CONTACTS_TABLE_NAME SET $STATUS =  0")
    }

    val allAutoWallpaper: ArrayList<AutoWallpaperModel>
        get() {
            val cursor = writableDatabase.rawQuery("SELECT * FROM auto_wallpaper", null)
            val employees = ArrayList<AutoWallpaperModel>()
            if (cursor.moveToFirst()) {
                do {
                    val autoWallpaperModel = AutoWallpaperModel()
                    autoWallpaperModel.id = cursor.getInt(cursor.getColumnIndex(ID_AUTO))
                    autoWallpaperModel.delaytime = cursor.getString(cursor.getColumnIndex(DELAY_TIME))
                    autoWallpaperModel.screenmode = cursor.getString(cursor.getColumnIndex(SCREEN_MODE))
                    autoWallpaperModel.imagespath = cursor.getString(cursor.getColumnIndex(IMAGES_PATH))
                    autoWallpaperModel.status = cursor.getInt(cursor.getColumnIndex(STATUS))
                    employees.add(autoWallpaperModel)
                } while (cursor.moveToNext())
            }
            return employees
        }

    fun deleteData(id: Int): Boolean {
        return writableDatabase.delete(CONTACTS_TABLE_NAME, "$ID_AUTO=$id", null) > 0
    }

    fun deleteAllData() {
        writableDatabase.delete(CONTACTS_TABLE_NAME, null, null)
    }

    // this gets called even if there is an exception somewhere above
    val wallpaperModel: AutoWallpaperModel?
        get() {
            var res: Cursor? = null
            try {
                val db = this.readableDatabase
                res = db.rawQuery("select * from auto_wallpaper", null)
                res.moveToFirst()
                while (!res.isAfterLast) {
                    if (res.getInt(res.getColumnIndex(STATUS)) == 1) {
                        val autoWallpaperModel = AutoWallpaperModel()
                        autoWallpaperModel.id = res.getInt(res.getColumnIndex(ID_AUTO))
                        autoWallpaperModel.delaytime = res.getString(res.getColumnIndex(DELAY_TIME))
                        autoWallpaperModel.screenmode = res.getString(res.getColumnIndex(SCREEN_MODE))
                        autoWallpaperModel.imagespath = res.getString(res.getColumnIndex(IMAGES_PATH))
                        autoWallpaperModel.status = res.getInt(res.getColumnIndex(STATUS))
                        return autoWallpaperModel
                    }
                    res.moveToNext()
                }
            } finally {
                // this gets called even if there is an exception somewhere above
                res?.close()
            }
            res!!.close()
            return null
        }

    fun updateDataToDB(model: AutoWallpaperModel) {
        val db = this.writableDatabase
        if (model.status == 1) {
            updateData()
        }
        val contentValues = ContentValues()
        contentValues.put(DELAY_TIME, model.delaytime)
        contentValues.put(SCREEN_MODE, model.screenmode)
        contentValues.put(IMAGES_PATH, model.imagespath)
        contentValues.put(STATUS, model.status)
        db.update(CONTACTS_TABLE_NAME, contentValues, "id=" + model.id, null)
    } /* public AutoWallpaperModel getCurrentModel() {

        Cursor res = null;

        try {
            SQLiteDatabase db = this.getReadableDatabase();
            res = db.rawQuery("select * from auto_wallpaper where status = 1", null);
            res.moveToFirst();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            // this gets called even if there is an exception somewhere above
            if (res != null)
                res.close();
        }

        return null;
    }*/

    companion object {
        const val DATABASE_NAME = "MyDBNameAuto.db"
        const val CONTACTS_TABLE_NAME = "auto_wallpaper"
        const val ID_AUTO = "id"
        const val DELAY_TIME = "interval"
        const val SCREEN_MODE = "screen_mode"
        const val IMAGES_PATH = "imagespath"
        const val STATUS = "status"
    }
}