package com.hd.wallpaper.solid.color.background.fragment

import android.app.Activity
import android.content.res.Resources
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.adapter.GallerySelectableAdapter
import com.hd.wallpaper.solid.color.background.custom.GridSpacingItemDecoration
import com.hd.wallpaper.solid.color.background.model.SavedImageModel
import java.util.*

class GallerySelectableFragment constructor() : Fragment() {
    private var layoutSubscribe: ConstraintLayout? = null
    private var btnSubscribe: ConstraintLayout? = null
    private var noImages: ConstraintLayout? = null
    private var recyclerWallpaper: RecyclerView? = null
    private var mSavedImageModels: ArrayList<SavedImageModel>? = null
    private var adapter: GallerySelectableAdapter? = null
    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                     savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_gallery_selectable, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        System.gc()
        Runtime.getRuntime().gc()
        btnSubscribe = view.findViewById(R.id.btnSubscribe)
        layoutSubscribe = view.findViewById(R.id.layoutSubscribe)
        recyclerWallpaper = view.findViewById(R.id.recyclerWallpaper)
        noImages = view.findViewById(R.id.noImages)

        /*  if (!AdsPrefs.getBoolean(getActivity(), AdsPrefs.IS_SUBSCRIBED, false)) {
            layoutSubscribe.setVisibility(View.VISIBLE);
            recyclerWallpaper.setVisibility(View.GONE);
            noImages.setVisibility(View.GONE);
            btnSubscribe.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(getActivity(), PremiumAccessActivity.class));
                }
            });

        } else {*/layoutSubscribe!!.visibility = View.GONE
        mSavedImageModels = ArrayList()
        mSavedImageModels = gettAllImages(activity)
        if (mSavedImageModels != null && mSavedImageModels!!.size > 0) {
            recyclerWallpaper!!.visibility = View.VISIBLE
            noImages!!.visibility = View.GONE
            val manager: GridLayoutManager = GridLayoutManager(activity, 3)
            recyclerWallpaper!!.layoutManager = manager
            recyclerWallpaper!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(8), true))
            recyclerWallpaper!!.itemAnimator = DefaultItemAnimator()
            val listener: GallerySelectableAdapter.setOnItemClickListener = object : GallerySelectableAdapter.setOnItemClickListener {
                public override fun OnItemClickedImage(position: Int) {}
                public override fun OnLongClickImage(position: Int) {}
            }
            adapter = GallerySelectableAdapter(mSavedImageModels!!, activity!!, listener)
            recyclerWallpaper!!.adapter = adapter
        } else {
            recyclerWallpaper!!.visibility = View.GONE
            noImages!!.visibility = View.VISIBLE
        }
        //  }
    }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }

    val dataList: ArrayList<SavedImageModel>
        get() {
            val mList: ArrayList<SavedImageModel> = ArrayList()
            if (mSavedImageModels != null) {
                for (i in mSavedImageModels!!.indices) {
                    if (mSavedImageModels!![i].isDeletedEnable) {
                        mList.add(mSavedImageModels!![i])
                    }
                }
            }
            return mList
        }

    companion object {
        fun gettAllImages(activity: Activity?): ArrayList<SavedImageModel> {

            //Remove older images to avoid copying same image twice
            val allImages: ArrayList<SavedImageModel> = ArrayList()
            val uri: Uri
            val cursor: Cursor?
            val column_index_data: Int
            var absolutePathOfImage: String? = null

            //get all images from external storage
            uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val projection: Array<String> = arrayOf(MediaStore.MediaColumns.DATA,
                    MediaStore.Images.Media.DISPLAY_NAME)
            cursor = activity!!.contentResolver.query(uri, projection, " NOT " + MediaStore.Images.Media.MIME_TYPE + " = 'image/gif'",
                    null, null)
            assert(cursor != null)
            column_index_data = cursor!!.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
            while (cursor.moveToNext()) {
                absolutePathOfImage = cursor.getString(column_index_data)
                allImages.add(SavedImageModel(absolutePathOfImage, false))
            }

            // Get all Internal storage images

            /*uri = android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI;
        cursor = activity.getContentResolver().query(uri, projection, " NOT "+MediaStore.Images.Media.MIME_TYPE+" ='image/gif'",
                null, null);
        assert cursor != null;
        column_index_data = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);

        while (cursor.moveToNext()) {
            absolutePathOfImage = cursor.getString(column_index_data);
            Log.d("TAG===>>>>>>>>>>>>>", "gettAllImages: "+absolutePathOfImage);
            allImages.add(new SavedImageModel(absolutePathOfImage,false));
        }*/return allImages
        }
    }
}