package com.hd.wallpaper.solid.color.background.paint_view.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.paint_view.adapter.BrushSelectAdapter
import com.hd.wallpaper.solid.color.background.paint_view.constant.Constants
import com.hd.wallpaper.solid.color.background.paint_view.drawing.Brush
import com.hd.wallpaper.solid.color.background.paint_view.drawing.Brushes.get
import com.hd.wallpaper.solid.color.background.databinding.ActivityBrushSelectBinding
import com.slim.face.perfect.body.shape.editor.skinny.app.decorationClass.GridSpacingItemDecoration


class BrushSelectActivity : AppCompatActivity(), BrushSelectAdapter.OnBrushSelectClick {

    private var mBrushSelectActivity: BrushSelectActivity? = null

    private var mRecyclerBrushes: RecyclerView? = null

    private var brushes: ArrayList<Brush?> = ArrayList()

    lateinit var binding:ActivityBrushSelectBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityBrushSelectBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_brush_select)
        mBrushSelectActivity = this@BrushSelectActivity

        initView()

        initViewAction()

        loadBrushData()

        mRecyclerBrushes!!.addItemDecoration(
                GridSpacingItemDecoration(
                        3, resources.getDimension(R.dimen._14sdp).toInt(), true
                )
        )
    }

    fun getBoolean(context: Context): Boolean {
        return getPrefs(context).getBoolean("subscribed", false)
    }

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences("app_center", Context.MODE_PRIVATE)
    }

    private fun shareApp() {
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage = ""
        shareMessage += "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, "Choose One..."))
    }

    private fun initView() {
        mRecyclerBrushes = findViewById(R.id.recyclerBrushes)
    }

    private fun initViewAction() {
        val imgBack: ImageView = findViewById(R.id.imgBack)
        imgBack.setOnClickListener {
            onBackPressed()
        }
        if (getBoolean(this)) {
            binding.icAd.visibility = View.GONE
            binding.icShare.visibility = View.VISIBLE
        } else {
            binding.icAd.visibility = View.VISIBLE
            binding.icShare.visibility = View.GONE
        }
        binding.icShare.setOnClickListener{
            shareApp()
        }
    }

    private fun loadBrushData() {
        val brushType = 0
       // val brushId = 0
        brushes = get(mBrushSelectActivity!!, brushType)!!

        mRecyclerBrushes!!.layoutManager = GridLayoutManager(mBrushSelectActivity, 3)
        mRecyclerBrushes!!.adapter = BrushSelectAdapter(mBrushSelectActivity!!, brushes)
    }

    override fun getSelectedBrush(position: Int) {
        setResult(-1, Intent().putExtra(Constants.EXTRA_BRUSH_ID, position))
        finish()
    }
}

