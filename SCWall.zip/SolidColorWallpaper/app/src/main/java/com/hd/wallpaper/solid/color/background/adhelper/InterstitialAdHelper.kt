package com.hd.wallpaper.solid.color.background.adhelper

import android.widget.Toast
import androidx.annotation.NonNull
import androidx.fragment.app.FragmentActivity
import com.hd.wallpaper.solid.color.background.adhelper.RewardVideoHelper.isShowRewardVideoAd

object InterstitialAdHelper {
    fun FragmentActivity.isShowInterstitialAd(isBackAds: Boolean = false, @NonNull onAdClosed: (isShowFullScreenAd: Boolean) -> Unit) {
        Toast.makeText(this,"isShowInterstitialAd", Toast.LENGTH_LONG).show()
        onAdClosed.invoke(true)
    }
}