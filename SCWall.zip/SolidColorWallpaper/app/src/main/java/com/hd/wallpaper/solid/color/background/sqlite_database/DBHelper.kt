package com.hd.wallpaper.solid.color.background.sqlite_database

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context?) : SQLiteOpenHelper(context, DATABASE_NAME, null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        // TODO Auto-generated method stub
        db.execSQL(
                "create table contacts " +
                        "(id integer primary key, path text)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS contacts")
        onCreate(db)
    }

    fun insertPath(path: String): Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put("path", path)
        if (!checkPathExist(path)) {
            db.insert("contacts", null, contentValues)
        }
        return true
    }

    fun checkPathExist(path: String): Boolean {
        var res: Cursor? = null
        var isWathced = false
        try {
            val db = this.readableDatabase
            res = db.rawQuery("select * from contacts", null)
            res.moveToFirst()
            while (!res.isAfterLast) {
                if (res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)) == path) {
                    isWathced = true
                    break
                }
                res.moveToNext()
            }
        } finally {
            // this gets called even if there is an exception somewhere above
            res?.close()
        }
        res!!.close()
        return isWathced
    }



    companion object {
        const val DATABASE_NAME = "MyDBName.db"
        const val CONTACTS_COLUMN_NAME = "path"
    }
}