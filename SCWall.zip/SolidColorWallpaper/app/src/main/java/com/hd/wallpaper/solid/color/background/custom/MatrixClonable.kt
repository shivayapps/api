package com.hd.wallpaper.solid.color.background.custom

import android.graphics.Matrix

class MatrixClonable : Matrix(), Cloneable {
    @Throws(CloneNotSupportedException::class)
    public override fun clone(): Any {
        return super.clone()
    }
}