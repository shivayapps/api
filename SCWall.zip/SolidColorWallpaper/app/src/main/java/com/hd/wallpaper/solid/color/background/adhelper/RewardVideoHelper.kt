package com.hd.wallpaper.solid.color.background.adhelper

import android.widget.Toast
import androidx.fragment.app.FragmentActivity

object RewardVideoHelper {
    fun FragmentActivity.isShowRewardVideoAd(
        onStartToLoadRewardVideoAd: () -> Unit,
        onUserEarnedReward: (isUserEarnedReward: Boolean) -> Unit,
        onAdLoaded: () -> Unit
    ) {
        Toast.makeText(this,"isShowRewardVideoAd",Toast.LENGTH_LONG).show()
        onUserEarnedReward.invoke(true)
//        onAdLoaded.invoke()
    }
}