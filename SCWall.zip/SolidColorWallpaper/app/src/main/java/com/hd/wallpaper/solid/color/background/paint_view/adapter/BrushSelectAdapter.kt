package com.hd.wallpaper.solid.color.background.paint_view.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.hd.wallpaper.solid.color.background.paint_view.drawing.Brush
import com.hd.wallpaper.solid.color.background.R

class BrushSelectAdapter(private var mContext: Context, private var brushes: ArrayList<Brush?>,private var mOnBrushSelectClick: OnBrushSelectClick = mContext as OnBrushSelectClick) :
    RecyclerView.Adapter<BrushSelectAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.rv_brush_item_layout, parent, false))

    override fun getItemCount(): Int = brushes.size - 1

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        holder.imgBrush.setImageResource(brushes[position]!!.iconId)
        holder.txtBrush.text = brushes[position]!!.name

        holder.itemView.setOnClickListener {
            mOnBrushSelectClick.getSelectedBrush(position)
        }

    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgBrush: ImageView = itemView.findViewById(R.id.imgBrush)
        val txtBrush: TextView = itemView.findViewById(R.id.txtBrush)
    }

    interface OnBrushSelectClick {
        fun getSelectedBrush(position: Int)
    }
}