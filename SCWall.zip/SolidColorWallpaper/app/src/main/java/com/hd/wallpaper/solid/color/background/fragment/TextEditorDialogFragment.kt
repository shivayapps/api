package com.hd.wallpaper.solid.color.background.fragment

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.Selection
import android.text.TextWatcher
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.fragment.app.DialogFragment
import com.hd.wallpaper.solid.color.background.R

class TextEditorDialogFragment
@Deprecated("") constructor() : DialogFragment() {
    protected var editText: EditText? = null
    private var callback: OnTextLayerCallback? = null
    var textChanges: Boolean = true
    public override fun onAttach(activity: Activity) {
        super.onAttach(activity)
        if (activity is OnTextLayerCallback) {
            callback = activity
        } else {
            throw IllegalStateException((activity.javaClass.getName()
                    + " must implement " + OnTextLayerCallback::class.java.getName()))
        }
    }

    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_text_editor_dialog, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val args: Bundle? = getArguments()
        var text: String? = ""
        if (args != null) {
            text = args.getString(ARG_TEXT)
        }
        editText = view.findViewById<View>(R.id.edit_text_view) as EditText?
        // editText.setText("");
        //  editText.setText("");
        initWithTextEntity(text)
        val finalText: String? = text
        editText!!.addTextChangedListener(object : TextWatcher {
            public override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            public override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                /*  if (textChanges) {
                    editText.setText("");
                    textChanges=false;
                }*/
            }

            public override fun afterTextChanged(s: Editable) {
                if (!(s.toString() == " ")) {
                    if (callback != null) {
                        callback!!.textChanged(s.toString())
                    }
                } else {
                    editText!!.setText(finalText)
                }
            }
        })
        view.findViewById<View>(R.id.text_editor_root).setOnClickListener(object : View.OnClickListener {
            public override fun onClick(view: View) {
                // exit when clicking on background
                dismiss()
                //callback.textChanged(editText.getText().toString());
            }
        })
    }

    private fun initWithTextEntity(text: String?) {
        editText!!.setText(text)
        editText!!.post(object : Runnable {
            public override fun run() {
                if (editText != null) {
                    Selection.setSelection(editText!!.getText(), editText!!.length())
                }
            }
        })
    }

    public override fun dismiss() {
        super.dismiss()

        // clearing memory on exit, cos manipulating with text uses bitmaps extensively
        // this does not frees memory immediately, but still can help
        System.gc()
        Runtime.getRuntime().gc()
    }

    public override fun onDetach() {
        // release links
        callback = null
        super.onDetach()
    }

    public override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog: Dialog = super.onCreateDialog(savedInstanceState)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.requestWindowFeature(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        return dialog
    }

    public override fun onStart() {
        super.onStart()
        val dialog: Dialog? = getDialog()
        if (dialog != null) {
            val window: Window? = dialog.getWindow()
            if (window != null) {
                // remove background
                window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)

                // remove dim
                val windowParams: WindowManager.LayoutParams = window.getAttributes()
                window.setDimAmount(0.0f)
                window.setAttributes(windowParams)
            }
        }
    }

    public override fun onResume() {
        super.onResume()
        editText!!.post(object : Runnable {
            public override fun run() {
                // force show the keyboard
                setEditText(true)
                editText!!.requestFocus()
                val ims: InputMethodManager = getActivity()!!.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                ims.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT)
            }
        })
    }

    private fun setEditText(gainFocus: Boolean) {
        if (!gainFocus) {
            editText!!.clearFocus()
            editText!!.clearComposingText()
        }
        editText!!.setFocusableInTouchMode(gainFocus)
        editText!!.setFocusable(gainFocus)
    }

    /*
     * Callback that passes all user input through the method
     * {@link TextEditorDialogFragment.OnTextLayerCallback#textChanged(String)}
     */
    open interface OnTextLayerCallback {
        fun textChanged(text: String)
    }

    companion object {
        val ARG_TEXT: String = "editor_text_arg"
        fun getInstance(textValue: String?): TextEditorDialogFragment {
            val fragment: TextEditorDialogFragment = TextEditorDialogFragment()
            val args: Bundle = Bundle()
            args.putString(ARG_TEXT, textValue)
            fragment.setArguments(args)
            return fragment
        }
    }
}