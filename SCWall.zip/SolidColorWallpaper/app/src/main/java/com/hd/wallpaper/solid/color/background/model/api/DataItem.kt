package com.hd.wallpaper.solid.color.background.model.api

import com.google.gson.annotations.SerializedName

class DataItem {
    @SerializedName("image")
    val image: List<ImageItem>? = null

    @SerializedName("name")
    val name: String? = null

    @SerializedName("icon")
    val icon: Any? = null

    @SerializedName("id")
    val id = 0

}