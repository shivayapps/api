package com.hd.wallpaper.solid.color.background.activity

import android.Manifest
import android.app.Activity
import android.app.ProgressDialog
import android.app.WallpaperManager
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.viewpager.widget.ViewPager
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver.Companion.cancelAlarm
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar

import com.hd.wallpaper.solid.color.background.BuildConfig
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.adapter.ViewGradientWallpaperPagerAdapter
import com.hd.wallpaper.solid.color.background.adapter.ViewWallpaperPageAdapter
import com.hd.wallpaper.solid.color.background.adhelper.InterstitialAdHelper.isShowInterstitialAd
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.custom.BottomSheetFragment
import com.hd.wallpaper.solid.color.background.databinding.ActivitySetWallpaperNewBinding
import com.hd.wallpaper.solid.color.background.model.ColorModel
import com.hd.wallpaper.solid.color.background.model.SolidColorModel
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.getBoolean
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelperAutoWallpaper
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*

class SetWallpaperActivity : AppCompatActivity(), View.OnClickListener {
    private var btnShare: ImageView? = null
    private var btnSave: ImageView? = null
    private var btnHome: ImageView? = null
    private var btnEdit: ImageView? = null
    private var btnSetWallpaper: TextView? = null
    private var mBitmap: Bitmap? = null
    private var mPermissionGranted = false
    private var mPermissionGrantedWallpaper = false
    private var isShared = false
    private var progressBar: ProgressDialog? = null
    private var mySharedPref: MySharedPref? = null
    //private var interstitialAd: InterstitialAd? = null
    var bottomSheetFragment:BottomSheetFragment?=null

    // private RelativeLayout mainLayout;
    //  private PopupWindow mPopupWindow;
    private var mainViewPage: ViewPager? = null
    private var mSolidColorWallpaper: ArrayList<SolidColorModel>? = null
    private var mGradientColorWallpaper: ArrayList<ColorModel>? = null
    private var position = 0
    private val prevPosition = 0
    private var enableToSave = true
    private var wallpaperManager: WallpaperManager? = null
    private var isSetWallpaper = false
    private var imagePaths: ArrayList<String>? = null
    private var vibrator: Vibrator? = null

    lateinit var binding:ActivitySetWallpaperNewBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivitySetWallpaperNewBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_set_wallpaper_new)
        System.gc()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(this@SetWallpaperActivity, MainStartActivity::class.java))
            finish()
        } else {
            Constants.savedPath = null
            mySharedPref = MySharedPref(this)
            if ( /*!mySharedPref.getAdsRemoved() &&*/!getBoolean(this@SetWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
//                loadInterstialAd()
//                loadInterstialAdFb()
                loadFBInter()
            }
            progressBar = ProgressDialog(this@SetWallpaperActivity)
            progressBar!!.setMessage(resources.getString(R.string.dialog_msg_please_wait))
            progressBar!!.setCancelable(false)
            initViews()
            initViewAction()
            initListner()
            Log.d("OPOPOPOP", "initViewAction: " + Constants.isGradient)

            //  initPopupWindow();
        }
    }

    private fun loadFBInter() {
//        mInterstitialAd = com.google.android.gms.ads.InterstitialAd(this)

    }

    private fun initListner() {
        btnSave!!.setOnClickListener(this)
        btnShare!!.setOnClickListener(this)
        btnSetWallpaper!!.setOnClickListener(this)
        btnHome!!.setOnClickListener(this)
        btnEdit!!.setOnClickListener(this)
    }

    private fun initViewAction() {
        if (mySharedPref!!.vibration) {
            vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        wallpaperManager = WallpaperManager.getInstance(applicationContext)
        Log.d("78456", "initViewAction: " + Constants.isGradient)
        if (Constants.isGradient) {
            position = Constants.gradientPosition
            mGradientColorWallpaper = ArrayList()
            mGradientColorWallpaper!!.addAll(Constants.mGradientColorWallpapers)
            mainViewPage!!.addOnPageChangeListener(object : OnPageChangeListener {
                override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
                override fun onPageSelected(position1: Int) {
                    position = position1
                }

                override fun onPageScrollStateChanged(state: Int) {}
            })
            setDataToAdapterGradient()
            Log.d("8797845612123", "initViewAction: " + mGradientColorWallpaper!!.size)
        } else {
            position = Constants.solidPosition
            mSolidColorWallpaper = ArrayList()
            mSolidColorWallpaper!!.addAll(Constants.mSolidColorWallpapers)

            mainViewPage!!.addOnPageChangeListener(object : OnPageChangeListener {
                override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
                override fun onPageSelected(position1: Int) {
                    position = position1
                }

                override fun onPageScrollStateChanged(state: Int) {}
            })
            setDataToAdapter()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    private val photoes: Unit
        private get() {
            imagePaths = ArrayList()
            val file = File(Constants.path)
            if (file.isDirectory) {
                val files = file.listFiles { pathname: File -> pathname.path.endsWith(".jpg") || pathname.path.endsWith(".jpeg") || pathname.path.endsWith(".png") }
                if (files.size > 0) {
                    var temp: File
                    for (i in files.indices) {
                        for (j in i + 1 until files.size) {
                            if (files[i].lastModified() < files[j].lastModified()) {
                                temp = files[i]
                                files[i] = files[j]
                                files[j] = temp
                            }
                        }
                    }
                    for (value in files) {
                        Log.d("789456132", "getPhotoes: " + value.absolutePath)
                        imagePaths!!.add(value.absolutePath)
                    }
                }
            }
        }

    private fun setDataToAdapterGradient() {
        if (mGradientColorWallpaper!!.size > 0) {
            val adapter = ViewGradientWallpaperPagerAdapter(this, mGradientColorWallpaper!!)
            mainViewPage!!.adapter = adapter
            mainViewPage!!.currentItem = position
        }
    }

    private fun setDataToAdapter() {
        if (mSolidColorWallpaper!!.size > 0) {
            val adapter = ViewWallpaperPageAdapter(this, mSolidColorWallpaper!!)
            mainViewPage!!.adapter = adapter
            mainViewPage!!.currentItem = position
        }
    }

    private fun initViews() {
//        btnSave = findViewById(R.id.btnSave)
//        btnSetWallpaper = findViewById(R.id.btnSetWallpaper)
//        btnShare = findViewById(R.id.btnShare)
//        btnHome = findViewById(R.id.btnHome)
//        btnEdit = findViewById(R.id.btnEdit)
//        mainViewPage = findViewById(R.id.mainViewPage)

        btnSave = binding.btnSave
        btnSetWallpaper = binding.btnSetWallpaper
        btnShare = binding.btnShare
        btnHome = binding.btnHome
        btnEdit = binding.btnEdit
        mainViewPage = binding.mainViewPage

    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.btnSave -> {
                isShared = false
                isSetWallpaper = false
                if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@SetWallpaperActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), READ_PERMISSION)
                } else {
                    mPermissionGranted = true
                }
                if (mPermissionGranted) {
                    Constants.savedPath = null
                    enableToSave = true
                    photoes
                    var i = 0
                    while (i < imagePaths!!.size) {
                        if (Constants.isGradient) {
                            if (Constants.path + "/Gradient_" + mainViewPage!!.currentItem + ".jpg" == imagePaths!![i]) {
                                enableToSave = false
                                break
                            }
                        } else {
                            if (Constants.path + "/Solid_" + mainViewPage!!.currentItem + ".jpg" == imagePaths!![i]) {
                                enableToSave = false
                                break
                            }
                        }
                        i++
                    }
                    if (enableToSave) {
                        showSaveDialog()
                    } else {
                        // Toast.makeText(this, "Wallpaper Already Exist.", Toast.LENGTH_SHORT).show();
                        showSnackBar(resources.getString(R.string.wallpaper_already_exist))
                    }
                }
            }
            R.id.btnSetWallpaper -> {
                if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.SET_WALLPAPER) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@SetWallpaperActivity, arrayOf(Manifest.permission.SET_WALLPAPER), WALLPAPER_PERMISSION)
                } else {
                    mPermissionGrantedWallpaper = true
                }
                if (mPermissionGrantedWallpaper) {
                    showCustomDialog()
                    // setWall();
                }
            }
            R.id.btnShare -> {
                isShared = true
                isSetWallpaper = false
                shareWallpaper()
            }
            R.id.btnEdit -> {
                /* if (!mPopupWindow.isShowing()) {
                    mPopupWindow.setWidth(ConstraintLayout.LayoutParams.WRAP_CONTENT);
                    mPopupWindow.setHeight(ConstraintLayout.LayoutParams.WRAP_CONTENT);

                    mPopupWindow.showAtLocation(mainContainer, Gravity.LEFT | Gravity.BOTTOM, (int) (btnEdit.getWidth() / 1.2f), (int) (findViewById(R.id.bottom).getHeight() * 1.6f));
                } else {
                    mPopupWindow.dismiss();
                }*/
                //  showEditDialog();
                Constants.isFromFrag = true
                if (Constants.isGradient) {
                    if (mGradientColorWallpaper != null && mGradientColorWallpaper!!.size != 0) {
                        Constants.gradientPosition = position
                        Constants.selectedGWallpaper = mGradientColorWallpaper!![position]
                        startActivity(Intent(this@SetWallpaperActivity, CreateGradientWallpaperActivity::class.java))
                    } else {
                        finish()
                    }
                } else {
                    if (mSolidColorWallpaper != null && mSolidColorWallpaper!!.size != 0) {
                        Constants.solidPosition = position
                        Constants.selectedWallpaper = mSolidColorWallpaper!![position]
                        startActivity(Intent(this@SetWallpaperActivity, CreateSolidWallpaperActivity::class.java))
                    } else {
                        finish()
                    }
                }
            }
            R.id.btnHome -> onBackPressed()
        }
    }

    private fun showEditDialog() {
        val builder1 = BottomSheetDialog(this@SetWallpaperActivity, R.style.BottomSheetDialog)
        val v = layoutInflater.inflate(R.layout.edit_wallpaper_dialog, null)
        builder1.setContentView(v)
        builder1.show()
        builder1.setOnDismissListener { dialog: DialogInterface? -> btnSetWallpaper!!.isEnabled = true }
        val btnChangeColor = v.findViewById<LinearLayout>(R.id.btnChangeColor)
        val btnAddText = v.findViewById<LinearLayout>(R.id.btnAddText)
        btnChangeColor.setOnClickListener { v1: View? ->
            builder1.dismiss()
            Constants.isFromFrag = true
            try {
                if (Constants.isGradient && mGradientColorWallpaper!!.size > 0) {
                    Constants.gradientPosition = position
                    Constants.selectedGWallpaper = mGradientColorWallpaper!![position]
                    startActivity(Intent(this@SetWallpaperActivity, CreateGradientWallpaperActivity::class.java))
                } else {
                    if (mSolidColorWallpaper!!.size > 0) {
                        Constants.solidPosition = position
                        Constants.selectedWallpaper = mSolidColorWallpaper!![position]
                        startActivity(Intent(this@SetWallpaperActivity, CreateSolidWallpaperActivity::class.java))
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        btnAddText.setOnClickListener {
            builder1.dismiss()
            if (Constants.isGradient) {
                Constants.gradientPosition = position
                Constants.selectedGWallpaper = mGradientColorWallpaper!![position]
                // startActivity(new Intent(SetWallpaperActivity.this, AddTextGradientActivity.class));
            } else {
                Constants.solidPosition = position
                Constants.selectedWallpaper = mSolidColorWallpaper!![position]
                //   startActivity(new Intent(SetWallpaperActivity.this, AddTextSolidActivity.class));
            }
        }
    }

    private fun shareWallpaper() {
        Log.d("Uri", "shareWallpaper: " + Constants.savedPath)
        if (Constants.savedPath == null) {
            if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this@SetWallpaperActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), SHARE_PERMISSION)
            } else {
                mPermissionGranted = true
            }
            if (mPermissionGranted) {
                onclickSave()
            }
        } else {
            val uri = FileProvider.getUriForFile(this@SetWallpaperActivity, BuildConfig.APPLICATION_ID.toString() + ".provider", File(Constants.savedPath))
            if (uri != null) {
                val intent = Intent(Intent.ACTION_SEND)
                intent.type = "image/jpeg"
                intent.putExtra(Intent.EXTRA_STREAM, uri)
                var shareMessage = ""
                shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
                intent.putExtra(Intent.EXTRA_TEXT, shareMessage)
                startActivityForResult(Intent.createChooser(intent, resources.getString(R.string.share_wallpaper)), 100)
            }
            Constants.savedPath = null
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && !getBoolean(this@SetWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            Log.d("TAG=====>>>>", "onActivityResult: $requestCode")
//            if (instance!!.requestNewInterstitialfb()) {
//                instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                    override fun onAdClosed() {
//                        super.onAdClosed()
//                        loadInterstialAd()
//                    }
//
//                    override fun onAdFailedToLoad(i: Int) {
//                        super.onAdFailedToLoad(i)
//                        loadInterstialAd()
//                    }
//
//                    override fun onAdLoaded() {
//                        super.onAdLoaded()
//                    }
//                }
//            }
        }
    }

    private fun showCustomDialog() {
        btnSetWallpaper!!.isEnabled = false
        val builder1 = BottomSheetDialog(this@SetWallpaperActivity, R.style.BottomSheetDialog)
        val v = layoutInflater.inflate(R.layout.dialog_setwallpaper, null)
        builder1.setContentView(v)
        builder1.show()
        builder1.setOnDismissListener { dialog: DialogInterface? -> btnSetWallpaper!!.isEnabled = true }
        val wallpaper = v.findViewById<LinearLayout>(R.id.btnHomeScreen)
        val bothwallpaper = v.findViewById<LinearLayout>(R.id.btnBoth)
        val lockscreen = v.findViewById<LinearLayout>(R.id.btnLockScreen)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            bothwallpaper.visibility = View.GONE
            lockscreen.visibility = View.GONE
        }
        lockscreen.setOnClickListener { view: View? ->
            mySharedPref!!.countExist = mySharedPref!!.countExist + 1
            builder1.dismiss()
            progressBar!!.show()
            Log.d("Click", "showCustomDialog lock: ${mySharedPref!!.countExist}")
            Handler().postDelayed({

                Log.d("Click", "INNER lock: ${mySharedPref!!.countExist}")
                // progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countExist ==3 && mySharedPref!!.visitPlay == null) {
                    mySharedPref!!.countExist=0
                   // showRateDialog()

                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@SetWallpaperActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@SetWallpaperActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({ lockScreenWallpaper() }, 400)
        }

        mySharedPref!!.countExist= mySharedPref!!.countExist
        Log.d("Click", "showCustomDialog back lock: ${mySharedPref!!.countExist}")

        wallpaper.setOnClickListener { v12: View? ->
            builder1.dismiss()
            //   Toast.makeText(ViewGradientCreatedWallpaperActivity.this, "Please Wait...", Toast.LENGTH_SHORT).show();
            mySharedPref!!.countExist = mySharedPref!!.countExist + 1
            progressBar!!.show()
            Log.d("Click", "showCustomDialog home: ${mySharedPref!!.countExist}")
            Handler().postDelayed({
                Log.d("Click", "INNER home: ${mySharedPref!!.countExist}")
//                        progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countExist >= 3 && mySharedPref!!.visitPlay == null) {
                   // showRateDialog()
                    mySharedPref!!.countExist=0
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@SetWallpaperActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@SetWallpaperActivity, EventReceiver::class.java)
            }
            Handler().postDelayed(Runnable { onclickWallpaper(false) }, 400)
        }

        mySharedPref!!.countExist=mySharedPref!!.countExist
        Log.d("Click", "showCustomDialog back home: ${mySharedPref!!.countExist}")

        bothwallpaper.setOnClickListener { v1: View? ->
            builder1.dismiss()
            //  Toast.makeText(ViewGradientCreatedWallpaperActivity.this, "Please Wait...", Toast.LENGTH_LONG).show();
            mySharedPref!!.countExist = mySharedPref!!.countExist + 1
            progressBar!!.show()
            Handler().postDelayed(object : Runnable {
                override fun run() {
                    //   progressBar.dismiss();
                    btnSetWallpaper!!.isEnabled = true
                    if (mySharedPref!!.countExist >= 3 && mySharedPref!!.visitPlay == null) {
                      //  showRateDialog()
                        mySharedPref!!.countExist=0
                    }
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@SetWallpaperActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@SetWallpaperActivity, EventReceiver::class.java)
            }
            Handler().postDelayed(object : Runnable {
                override fun run() {
                    onclickWallpaper(true)
                    lockScreenWallpaper()
                }
            }, 400)
        }
    }

    private fun setWall() {
        isSetWallpaper = true
        isShared = false
        if (Constants.savedPath == null) {
            if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this@SetWallpaperActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), SHARE_PERMISSION)
            } else {
                mPermissionGranted = true
            }
            if (mPermissionGranted) {
                onclickSave()
            }
        } else {
            val uri = FileProvider.getUriForFile(this@SetWallpaperActivity, BuildConfig.APPLICATION_ID.toString() + ".provider", File(Constants.savedPath))
            val intent = Intent("android.intent.action.ATTACH_DATA")
            intent.addCategory("android.intent.category.DEFAULT")
            intent.setDataAndType(uri, "image/jpeg")
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intent.putExtra("mimeType", "image/jpeg")
            startActivity(Intent.createChooser(intent, "Set as:"))
        }
    }

//    private fun showRateDialog() {
//        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
//        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_rate_app, viewGroup, false)
//        val builder = AlertDialog.Builder(this)
//        builder.setView(dialogView)
//        val alertDialog = builder.create()
//        Objects.requireNonNull(alertDialog.window)!!.setBackgroundDrawableResource(android.R.color.transparent)
//        alertDialog.setOnCancelListener { alertDialog.dismiss() }
//        val btnClose = dialogView.findViewById<ImageView>(R.id.btnClose)
//        btnClose.setOnClickListener { alertDialog.dismiss() }
//        val ratingBar1: ScaleRatingBar = dialogView.findViewById(R.id.ratingBar)
//        ratingBar1.setOnRatingChangeListener { ratingBar, rating, fromUser ->
//            if (rating > 2) {
//                rate_app()
//                Handler().postDelayed({ alertDialog.dismiss() }, 1000)
//            } else {
//                Toast.makeText(this, "Rate Is : $rating", Toast.LENGTH_SHORT).show()
////                sendMail()
////                //  Toast.makeText(SetWallpaperActivity.this, getResources().getString(R.string.thanks_for_review), Toast.LENGTH_SHORT).show();
//                Handler().postDelayed({ alertDialog.dismiss() }, 1000)
//            }
//        }
//
//
//        /*       dialogView.findViewById(R.id.txtNever).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mySharedPref.setDoNotAsk();
//                alertDialog.dismiss();
//
//
//            }
//        });
//*/dialogView.findViewById<View>(R.id.btnNextTime).setOnClickListener {
//            alertDialog.dismiss()
//            mySharedPref!!.countExist = 0
//        }
//        if (!this@SetWallpaperActivity.isFinishing) {
//            alertDialog.show()
//        }
//    }
//
//    private fun sendMail() {
//        mySharedPref!!.setVisitPlay()
//        /*     Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
//        emailIntent.setType("text/plain");
//        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"profagnesh009@gmail.com"});
//        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Share your valuable feedback with us to improve app quality and add more features in Solid Color Wallpaper");
//        emailIntent.setType("message/rfc822");
//        try {
//            startActivity(Intent.createChooser(emailIntent,
//                    "Send email using..."));
//        } catch (android.content.ActivityNotFoundException ex) {
//            Toast.makeText(this,
//                    "No email clients installed.",
//                    Toast.LENGTH_SHORT).show();
//        }*/
//        val send = Intent(Intent.ACTION_SENDTO)
//        val uriText = "mailto:" + Uri.encode("profagnesh009@gmail.com") +
//                "?subject=" + Uri.encode("Share valuable feedback to improve app quality of Solid Color Wallpaper") +
//                "&body=" + Uri.encode("")
//        val uri = Uri.parse(uriText)
//        send.data = uri
//        startActivity(Intent.createChooser(send, "Send Email..."))
//    }
//
//    private fun rate_app() {
//        mySharedPref!!.setVisitPlay()
//        try {
//            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
//        } catch (anfe: ActivityNotFoundException) {
//            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
//        }
//    }

    private fun lockScreenWallpaper() {
        mBitmap = outputBitmap
        Log.d("778978978465", "lockScreenWallpaper: ")
        //mBitmap =  BitmapFactory.decodeFile(imagePaths.get(position));
        if (mBitmap != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wallpaperManager!!.setBitmap(mBitmap, null, true, WallpaperManager.FLAG_LOCK) //For Lock screen
                    progressBar!!.dismiss()
                    if (vibrator != null) {
                        if (Build.VERSION.SDK_INT >= 26) {
                            vibrator!!.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                        } else {
                            vibrator!!.vibrate(200)
                        }
                    }
                    //Toast.makeText(WallpaperViewActivity.this, "Wallpaper Set Successfully.", Toast.LENGTH_SHORT).show();
                    showSnackBar(resources.getString(R.string.toast_wallpaper_set_seccessfully))
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun onclickWallpaper(isBoth: Boolean) {
        mBitmap = outputBitmap
        Log.d("778978978465", "onclickWallpaper: ")
        if (mBitmap != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wallpaperManager!!.setBitmap(mBitmap, null, true, WallpaperManager.FLAG_SYSTEM)
                } else {
                    wallpaperManager!!.setBitmap(mBitmap)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            if (!isBoth) {
                progressBar!!.dismiss()
                if (vibrator != null) {
                    if (Build.VERSION.SDK_INT >= 26) {
                        vibrator!!.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        vibrator!!.vibrate(200)
                    }
                }

                //Toast.makeText(WallpaperViewActivity.this, "Wallpaper Set Successfully.", Toast.LENGTH_SHORT).show();
                showSnackBar(resources.getString(R.string.toast_wallpaper_set_seccessfully))
            }
        } else {
            showSnackBar(resources.getString(R.string.try_again_later))
            //Toast.makeText(this, "Try Again Later!", Toast.LENGTH_SHORT).show();
        }
    }

    private fun showSnackBar(msg: String) {
        val snackbar = Snackbar.make(findViewById(R.id.mainContainer), msg, Snackbar.LENGTH_SHORT)
        val v = snackbar.view
        val params = v.layoutParams as CoordinatorLayout.LayoutParams
        params.gravity = Gravity.BOTTOM
        params.width = FrameLayout.LayoutParams.MATCH_PARENT
        v.layoutParams = params
        v.setBackgroundColor(Color.WHITE)
        val textView = v.findViewById<TextView>(com.google.android.material.R.id.snackbar_text)
        textView.setTextColor(resources.getColor(R.color.text_colour_new))
        snackbar.show()
    }

    private fun onclickSave() {
        Log.d("789123123123", "onclickSave: ")
        mBitmap = outputBitmap
        if (mBitmap != null) {
            val myDir = File(Constants.path)
            myDir.mkdirs()
            val fname: String = if (Constants.isGradient) {
                "Gradient_" + mainViewPage!!.currentItem + ".jpg"
            } else {
                "Solid_" + mainViewPage!!.currentItem + ".jpg"
            }
            val file = File(myDir, fname)
            var out: FileOutputStream? = null
            try {
                out = FileOutputStream(file)
                mBitmap!!.compress(Bitmap.CompressFormat.JPEG, 100, out)
                out.flush()
                out.close()
                Constants.savedPath = Constants.path + "/" + fname
                if (!isShared && !isSetWallpaper) {
                    //Toast.makeText(this, "Wallpaper Saved.", Toast.LENGTH_SHORT).show();
                    showSnackBar(resources.getString(R.string.wallpaper_saved))
                } else if (isSetWallpaper) {
                    showCustomDialog()
                } else {
                    shareWallpaper()
                }
            } catch (e: IOException) {
                Log.d("789123123123", "onclickSave: " + e.message)
                e.printStackTrace()
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                val scanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                val contentUri = Uri.fromFile(file)
                scanIntent.data = contentUri
                sendBroadcast(scanIntent)
            } else {
                val intent = Intent(Intent.ACTION_MEDIA_MOUNTED, Uri.parse("file://" + Environment.getExternalStorageDirectory()))
                sendBroadcast(intent)
            }
        }
    }

    private val outputBitmap: Bitmap?
        private get() {
            val v = mainViewPage!!.findViewWithTag<View>("myview" + mainViewPage!!.currentItem)
            if (v != null) {
                val bitmap = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                v.draw(canvas)
                return bitmap
            }
            return null
        }

    override fun onRequestPermissionsResult(requestCode: Int,
                                            permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            READ_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (Constants.savedPath == null) {
                        showSaveDialog()
                    } else {
                        //Toast.makeText(this, "Wallpaper Already Exist.", Toast.LENGTH_SHORT).show();
                        showSnackBar(resources.getString(R.string.wallpaper_already_exist))
                    }
                } else {
                    val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, resources.getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
            WALLPAPER_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    showCustomDialog()
                } else {
                    val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SET_WALLPAPER)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, resources.getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
            SHARE_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    shareWallpaper()
                } else {
                    val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SET_WALLPAPER)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, resources.getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
        }
    }

    private fun showSaveDialog() {
         bottomSheetFragment = BottomSheetFragment(resources.getString(R.string.save), resources.getString(R.string.do_you_want_to_save), resources.getString(R.string.save), resources.getString(R.string.cancel), R.drawable.ic_save_dialog, object : BottomSheetFragment.OnButtonClickListener {
            override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                bottomSheetDialo!!.dismiss()
                onclickSave()
            }

            override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragment!!.show(supportFragmentManager, "dialog")
    }

    override fun onPause() {
        super.onPause()
        try {
            bottomSheetFragment!!.dismiss()
        }catch (e:Exception){
            
        }
    }
    fun pemissionDialog() {
        val alertDialog: android.app.AlertDialog
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        val dialogView = LayoutInflater.from(this).inflate(R.layout.permission_dialog, viewGroup, false)
        val builder1 = android.app.AlertDialog.Builder(this)
        builder1.setView(dialogView)
        alertDialog = builder1.create()
        val cancel = dialogView.findViewById<Button>(R.id.btnCancel)
        cancel.setOnClickListener { alertDialog.dismiss() }
        val ok = dialogView.findViewById<Button>(R.id.btnOk)
        ok.setOnClickListener {
            startInstalledAppDetailsActivity(this@SetWallpaperActivity)
            alertDialog.dismiss()
        }
        alertDialog.show()
    }

    fun startInstalledAppDetailsActivity(context: Activity?) {
        if (context == null) {
            return
        }
        val i = Intent()
        i.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        i.addCategory(Intent.CATEGORY_DEFAULT)
        i.data = Uri.parse("package:" + context.packageName)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        context.startActivity(i)
    }

    override fun onBackPressed() {
            if (!getBoolean(this@SetWallpaperActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                isShowInterstitialAd{
                    finish()
                }
            } else {
                finish()
            }
    }

    override fun onStart() {
        super.onStart()
        Log.d("787897789", "onStart: ")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("787897789", "onRestart: ")
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            startActivity(Intent(this@SetWallpaperActivity, MainStartActivity::class.java))
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
    }

    companion object {
        private const val READ_PERMISSION = 101
        private const val WALLPAPER_PERMISSION = 235
        private const val SHARE_PERMISSION = 452
    }
}