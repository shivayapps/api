package com.hd.wallpaper.solid.color.background.activity

import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.Resources
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.wifiproxysettingslibrary.NetworkHelper
import com.wifiproxysettingslibrary.wifi_network.exceptions.ApiNotSupportedException
import com.wifiproxysettingslibrary.wifi_network.exceptions.NullWifiConfigurationException
import com.wifiproxysettingslibrary.wifi_network.wifi_proxy_changing_realisations.api_from_21_to_22.WifiConfiguration
import com.hd.wallpaper.solid.color.background.adhelper.RewardVideoHelper.isShowRewardVideoAd

import com.google.android.material.snackbar.Snackbar

import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.activity.GifLiveWallPaper.Companion.TAG
import com.hd.wallpaper.solid.color.background.adapter.CategaryHDAdepter
import com.hd.wallpaper.solid.color.background.adapter.WallpaperOfWeekAdapter
import com.hd.wallpaper.solid.color.background.adapter.WallpaperOfWeekAdapter.OnClickItem
import com.hd.wallpaper.solid.color.background.adapter.WallpaperOfWeekNewAdapter
import com.hd.wallpaper.solid.color.background.adhelper.InterstitialAdHelper.isShowInterstitialAd
import com.hd.wallpaper.solid.color.background.adhelper.NativeAdvancedModelHelper
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.constants.Constants.catPosition
import com.hd.wallpaper.solid.color.background.custom.BottomSheetFragment
import com.hd.wallpaper.solid.color.background.custom.GridSpacingItemDecoration
import com.hd.wallpaper.solid.color.background.databinding.ActivityWallpaperOfWeekNewBinding
import com.hd.wallpaper.solid.color.background.model.WallpaperWeekNewModel
import com.hd.wallpaper.solid.color.background.model.api.ImageItem
import com.hd.wallpaper.solid.color.background.newModel.DataItem
import com.hd.wallpaper.solid.color.background.newModel.ImagesItem
import com.hd.wallpaper.solid.color.background.newModel.WallpaperWeekNewModelClass
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.getBoolean
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelper
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelperSuscription
import java.lang.reflect.InvocationTargetException
import java.util.*
import kotlin.collections.ArrayList

class WallpaperOfWeekNewActivity constructor() : AppCompatActivity(), View.OnClickListener {
    private var icBack: ImageView? = null
    private var icSubcription: ImageView? = null
    private var btnShare: ImageView? = null
    private var recyclerWallpaper: RecyclerView? = null
    private var layoutError: View? = null
    private var layoutOffline: View? = null
    private var layoutProgress: ProgressBar? = null
    private var mDataList: ArrayList<com.hd.wallpaper.solid.color.background.model.api.DataItem>? = null
    private var mDataNewList: ArrayList<DataItem>? = null
    private var mImageNewList: ArrayList<ImagesItem?>? = null
    private var mImageNewListData: ArrayList<ImagesItem?>? = null
    private var mImageList: ArrayList<ImageItem>? = null
    private var txtRetryOffline: TextView? = null
    private var txtRetryError: TextView? = null
    private var mySharedPref: MySharedPref? = null
    private var dbHelper: DBHelper? = null
    private var dbHelperSuscription: DBHelperSuscription? = null
    private var adapter: WallpaperOfWeekAdapter? = null
    private var adapterNew: WallpaperOfWeekNewAdapter? = null

    private var adViewa: LinearLayout? = null
    private var nativeAdLayout: FrameLayout? = null


    var mCategaryHDAdepter: CategaryHDAdepter? = null
    private var mRecyclerCategery: RecyclerView? = null
    var mNewListImage: ArrayList<String> = ArrayList()
    var mNewListImageNew: ArrayList<String> = ArrayList()

//    var mRewardedAd: RewardedAd? = null
    var newList: MutableList<String> = arrayListOf()
    //    private var adView: AdView? = null

    lateinit var binding:ActivityWallpaperOfWeekNewBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_wallpaper_of_week_new)
        binding= ActivityWallpaperOfWeekNewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        System.gc()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
        initViews()
        initViewAction()
        initListner()
        Constants.HDposition = 0
        if (!getBoolean(this@WallpaperOfWeekNewActivity, AdsPrefs.IS_SUBSCRIBED, false)) {

            nativeAdLayout = findViewById(R.id.native_ad_container)
            NativeAdvancedModelHelper(this@WallpaperOfWeekNewActivity).loadNativeAdvancedAd(
                fSize = "NativeAdsSize.Medium",
                fLayout = nativeAdLayout!!,
                isAdLoaded = {}
            )
        }
    }

    private fun initListner() {
        icBack!!.setOnClickListener(this)
        icSubcription!!.setOnClickListener(this)
        txtRetryOffline!!.setOnClickListener(this)
        txtRetryError!!.setOnClickListener(this)
        btnShare!!.setOnClickListener(this)
    }

    private fun initViewAction() {

        mDataList = ArrayList()
        mDataNewList = ArrayList()
        mImageNewList = ArrayList()
        mImageNewListData = ArrayList()
        mImageList = ArrayList()
        dbHelper = DBHelper(this)
        dbHelperSuscription = DBHelperSuscription(this)
        mySharedPref = MySharedPref(this)
        if (!getBoolean(this@WallpaperOfWeekNewActivity, AdsPrefs.IS_SUBSCRIBED, false)) {


//            gameOverRewardedAd = createAndLoadRewardedAd(googleRewardVideo)
//            gameOverRewardedAd2 = createAndLoadRewardedAd(googleRewardVideo)
//            gameOverRewardedAd3 = createAndLoadRewardedAd(googleRewardVideo)
//            adView = AdView(this, facebookBanner, AdSize.BANNER_HEIGHT_50)
//            val adContainer: LinearLayout = findViewById<View>(R.id.banner_container) as LinearLayout
//            adContainer.removeAllViews()
//            adContainer.addView(adView)
//            adView!!.loadAd()
        }
        if (getBoolean(this@WallpaperOfWeekNewActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            btnShare!!.visibility = View.VISIBLE
            icSubcription!!.visibility = View.INVISIBLE
        } else {
            btnShare!!.visibility = View.GONE
            icSubcription!!.visibility = View.VISIBLE
        }
        val manager: GridLayoutManager = GridLayoutManager(this, 3)
        recyclerWallpaper!!.layoutManager = manager
        recyclerWallpaper!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(14), true))
        recyclerWallpaper!!.itemAnimator = DefaultItemAnimator()
        try {
            checkStatus()
        } catch (e: InvocationTargetException) {
            e.printStackTrace()
        } catch (e: NoSuchMethodException) {
            e.printStackTrace()
        } catch (e: ApiNotSupportedException) {
            e.printStackTrace()
        } catch (e: NoSuchFieldException) {
            e.printStackTrace()
        } catch (e: IllegalAccessException) {
            e.printStackTrace()
        } catch (e: NullWifiConfigurationException) {
            e.printStackTrace()
        }
    }

    private fun initViews() {
//        icBack = findViewById(R.id.icBack)
//        icSubcription = findViewById(R.id.icSubcription)
//        recyclerWallpaper = findViewById(R.id.recyclerWallpaper)
//        mRecyclerCategery = findViewById(R.id.recyclerCategery)
//        layoutOffline = findViewById(R.id.layoutOffline)
//        layoutError = findViewById(R.id.layoutError)
//        layoutProgress = findViewById(R.id.layoutProgress)
//        txtRetryOffline = findViewById(R.id.txtRetry)
//        txtRetryError = findViewById(R.id.txtRetryError)
//        btnShare = findViewById(R.id.btnShare)
        icBack = binding.icBack
        icSubcription = binding.icSubcription
        recyclerWallpaper = binding.recyclerWallpaper
        mRecyclerCategery = binding.recyclerCategery
        layoutOffline = binding.layoutOffline
        layoutError = binding.layoutError
        layoutProgress = binding.layoutProgress
        txtRetryOffline = binding.txtRetry
        txtRetryError = binding.txtRetryError
        btnShare = binding.btnShare
    }


    public override fun onClick(v: View) {
        when (v.getId()) {
            R.id.icBack -> onBackPressed()
            R.id.icSubcription ->                 /*if (!AdsPrefs.getBoolean(WallpaperOfWeekNewActivity.this, AdsPrefs.IS_SUBSCRIBED, false)) {
                    startActivity(new Intent(WallpaperOfWeekNewActivity.this, PremiumAccessActivity.class));
                } else {
                    showSnackBar();
                }*/onclickGames()
            R.id.txtRetry -> retry()
            R.id.btnShare -> onclickShare()
            R.id.txtRetryError -> retry()
        }
    }

    private fun onclickGames() {
        if (!NetworkHelper.isOnline(this)) {
            Toast.makeText(
                this,
                getResources().getString(R.string.check_internet_connection),
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/developer?id=shivayapps")))
        } catch (anfe: ActivityNotFoundException) {

        }
        //startActivity(Intent(this, GamezopActivity::class.java))

        /*  String url = "https://www.gamezop.com/?id=Y2_mvlugT";

        try {
            CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
            CustomTabsIntent customTabsIntent = builder.build();

            customTabsIntent.intent.setPackage("com.android.chrome");
            builder.setToolbarColor(ContextCompat.getColor(this, R.color.colorPrimary));
            builder.setShowTitle(true);
            builder.addDefaultShareMenuItem();

            builder.build().launchUrl(this, Uri.parse(url));
        } catch (Exception e) {
            CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();

            builder.setToolbarColor(getResources().getColor(R.color.colorPrimary));
            CustomTabsIntent customTabsIntent = builder.build();
            customTabsIntent.launchUrl(this, Uri.parse(url));
        }*/
    }

    private fun onclickShare() {
        val shareIntent: Intent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solid Color Wallpaper")
        var shareMessage: String = ""
        shareMessage += "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(
            Intent.createChooser(
                shareIntent,
                getResources().getString(R.string.choose_one)
            )
        )
    }

    private fun showSnackBar() {
        val snackbar: Snackbar =
            Snackbar.make(findViewById(R.id.mainLayout), "", Snackbar.LENGTH_LONG)
        val layout: Snackbar.SnackbarLayout = snackbar.view as Snackbar.SnackbarLayout
        val textView: TextView = layout.findViewById(com.google.android.material.R.id.snackbar_text)
        textView.visibility = View.INVISIBLE
        val snackView: View = LayoutInflater.from(this).inflate(R.layout.my_snackbar, null)
        layout.setPadding(0, 0, 0, 0)
        layout.addView(snackView, 0)
        snackbar.show()
    }

    private fun retry() {
        layoutProgress!!.visibility = View.VISIBLE
        layoutError!!.visibility = View.GONE
        recyclerWallpaper!!.visibility = View.VISIBLE
        layoutOffline!!.visibility = View.GONE
        try {
            checkStatus()
        } catch (e: InvocationTargetException) {
            e.printStackTrace()
        } catch (e: NoSuchMethodException) {
            e.printStackTrace()
        } catch (e: ApiNotSupportedException) {
            e.printStackTrace()
        } catch (e: NoSuchFieldException) {
            e.printStackTrace()
        } catch (e: IllegalAccessException) {
            e.printStackTrace()
        } catch (e: NullWifiConfigurationException) {
            e.printStackTrace()
        }

        Toast.makeText(this, resources.getString(R.string.no_internet_connection_found_ncheck_your_connection), Toast.LENGTH_SHORT).show()
    }

    @Throws(
        InvocationTargetException::class,
        NoSuchMethodException::class,
        ApiNotSupportedException::class,
        NoSuchFieldException::class,
        IllegalAccessException::class,
        NullWifiConfigurationException::class
    )
    private fun checkStatus() {
        if (!NetworkHelper.isOnline(this)) {
            layoutError!!.visibility = View.GONE
            recyclerWallpaper!!.visibility = View.GONE
            layoutOffline!!.visibility = View.VISIBLE
            layoutProgress!!.visibility = View.GONE
        } else {
            if (NetworkHelper.isWifiConnected(this)) {
                val proxy: WifiConfiguration = WifiConfiguration(this)
                if (proxy.isProxySetted) {
                    layoutError!!.visibility = View.GONE
                    recyclerWallpaper!!.visibility = View.GONE
                    layoutOffline!!.visibility = View.VISIBLE
                    layoutProgress!!.visibility = View.GONE
                    return
                }
            }
            if (NetworkHelper.isVpnRunning()) {
                layoutError!!.visibility = View.GONE
                recyclerWallpaper!!.visibility = View.GONE
                layoutOffline!!.visibility = View.VISIBLE
                layoutProgress!!.visibility = View.GONE
                return
            }
        }

    }


    private fun dpToPx(dp: Int): Int {
        val r: Resources = resources
        return Math.round(
            TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp.toFloat(),
                r.displayMetrics
            )
        )
    }


//    private fun setRecyclerData(newList: MutableList<String>) {
//        mRecyclerCategery!!.layoutManager = LinearLayoutManager(this,RecyclerView.HORIZONTAL,false)
//        mRecyclerCategery!!.adapter = CategaryHDAdepter(this,newList,object : CategaryHDAdepter.OnClickHdListener{
//            override fun onClickHD(position: Int, nCatName: String) {
//                Log.d(TAG, "onClickHD: $nCatName")
//                mNewListImageNew.clear()
//                for (i in mImageNewList!!.indices){
//                    if(mImageNewList!![i]!!.name == nCatName){
//                        mNewListImageNew.add(mImageNewList!![i]!!.image!!)
//                        mImageNewListData!!.addAll(mDataNewList!![i].images!!)
//                    }
//                }
//                Log.d(TAG, "onClickHD: $mNewListImageNew")
//                Log.d(TAG, "onClickHD: $mImageNewListData")
//            }
//        })
//    }


    private fun updateUI() {
        for (i in mDataList!!.indices) {
            if (mDataList!![i].id == 3) {
                mImageList!!.addAll((mDataList!![i].image)!!)
                break
            }
        }
        val mWallpaperList: ArrayList<WallpaperWeekNewModel?> = ArrayList()
        for (i in mImageList!!.indices) {
            Log.d("TAG=====>>>>", "updateUI: " + mImageList!![i].coins)
            mWallpaperList.add(
                WallpaperWeekNewModel(
                    mImageList!![i],
                    mImageList!![i].isPremium != 0,
                    mImageList!![i].image,
                    mImageList!![i].coins
                )
            )
        }
        val mTempList: ArrayList<WallpaperWeekNewModel?> = ArrayList()
        if (getBoolean(this@WallpaperOfWeekNewActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            for (image: ImageItem in mImageList!!) {
                dbHelperSuscription!!.insertPath((image.image)!!)
                Log.d("EWWWWWW", "updateUI: " + image.image)

            }
            for (i in mWallpaperList.indices) {
                mWallpaperList[i]!!.isLocked = false
            }
            mTempList.addAll(mWallpaperList)
        } else {
            dbHelperSuscription!!.deleteAllData()

            /* if (mySharedPref.getAdsRemoved()) {
                Log.d("456as", "updateUI: pur");

                if (mWallpaperList.size() >= 6) {
                    for (int i = 0; i < 6; i++) {
                        mTempList.add(mWallpaperList.get(i));
                    }
                   */
            /* for (int i = 0; i < 6; i++) {
                        mWallpaperList.remove(i);
                    }*/
            /*
                } else {
                    mTempList.addAll(mWallpaperList);
                    mWallpaperList.clear();
                }

                boolean flag = true;
                int conter = 0;
                int counterPrem = 0;
                for (int i = 6; i < mWallpaperList.size(); i++) {
                    WallpaperWeekNewModel model = mWallpaperList.get(i);

                    if (flag) {
                        model.setLocked(false);
                        model.setFree(true);
                        mTempList.add(model);
                        conter++;
                        if (conter > 5) {
                            flag = false;
                            conter = 0;
                        }
                    } else {
                        model.setPremium(true);
                        model.setFree(false);
                        mTempList.add(model);
                        counterPrem++;
                        if (counterPrem > 2) {
                            flag = true;
                            counterPrem = 0;
                        }
                    }
                }

            } else {*/
            /*  if (mWallpaperList.size() >= 6) {
                for (int i = 0; i < 6; i++) {
                    mTempList.add(mWallpaperList.get(i));
                }

                    */
            /*for (int i = 0; i < 6; i++) {
                        mWallpaperList.remove(i);
                    }*/
            /*
            } else {
                mTempList.addAll(mWallpaperList);
                mWallpaperList.clear();
            }

            boolean flag = true;
            int conter = 0;
            int counterPrem = 0;*/
            for (i in mWallpaperList.indices) {
                val model: WallpaperWeekNewModel? = mWallpaperList[i]
                if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                    model.isLocked = false
                }
                mTempList.add(model)

                //   }
            }
            mTempList.shuffle()
        }
        if (mImageList != null && mImageList!!.size > 0) {
            val onClickItem: OnClickItem = object : OnClickItem {
                override fun onClickWallpaper(
                    wallpaperWeekNewModel: WallpaperWeekNewModel?,
                    position: Int
                ) {

                    /*  if (WallpaperWeekNewModel.isPremium()) {
                        startActivity(new Intent(WallpaperOfWeekNewActivity.this, PremiumAccessActivity.class));
                    } else if (WallpaperWeekNewModel.isFree()) {
                        Intent i = new Intent(WallpaperOfWeekNewActivity.this, WallpaperWeekViewActivity.class);
                        i.putExtra("imagepath", WallpaperWeekNewModel.getImageItem().getImage());
                        startActivity(i);
                    } else {
                        if (!NetworkHelper.isOnline(WallpaperOfWeekNewActivity.this)) {
                            Toast.makeText(WallpaperOfWeekNewActivity.this, getResources().getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show();
                            return;
                        }
                        showAdDialog(WallpaperWeekNewModel, position);
                    }*/
                    if (!NetworkHelper.isOnline(this@WallpaperOfWeekNewActivity)) {
                        Toast.makeText(
                            this@WallpaperOfWeekNewActivity,
                            getResources().getString(R.string.check_internet_connection),
                            Toast.LENGTH_SHORT
                        ).show()
                        return
                    }
                    val intent: Intent = Intent(
                        this@WallpaperOfWeekNewActivity,
                        WallpaperOfWeekPagerViewActivity::class.java
                    )
                    intent.putParcelableArrayListExtra("ARRAYLIST", mTempList)
                    intent.putExtra("position", position)
                    startActivity(intent)
                }

                public override fun startAnimation() {}
            }
            adapter =
                WallpaperOfWeekAdapter(mTempList, this@WallpaperOfWeekNewActivity, onClickItem)
            recyclerWallpaper!!.adapter = adapter
        }
        layoutError!!.visibility = View.GONE
        recyclerWallpaper!!.visibility = View.VISIBLE
        layoutOffline!!.visibility = View.GONE
        layoutProgress!!.visibility = View.GONE
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun updateNewUI() {
        for (i in mDataNewList!!.indices) {
            if (mDataNewList!![i].id == 3) {
                mImageNewList!!.addAll(mDataNewList!![i].images!!)
                Log.e("TAG", "updateNewUI1111: ${mImageNewList!!.size}")
                Log.e("TAG", "updateNewUI1112: ${mDataNewList!![i].images!!.size}")
                break
            }
        }
        for (j in mImageNewList!!.indices) {
//            if(mImageNewList!![j]!!.name!!.contains("")){
//
//            }else{
            mNewListImage.add(mImageNewList!![j]!!.name!!)
//            }
        }

        val hs = HashSet<String>()

        hs.addAll(mNewListImage) // demoArrayList= name of arrayList from which u want to remove duplicates
        mNewListImage.clear()
        mNewListImage.addAll(hs)

//        var newList = mNewListImage.stream().distinct().collect(Collectors.toList())
        newList = mNewListImage

        Log.d(TAG, "updateNewUIqqqq: ${newList.size}")
        Log.d(TAG, "updateNewUIqqqq: $newList")


//        try {
//            newList.remove("")
//        } catch (e: Exception) {
//        }
        val mWallpaperList: ArrayList<WallpaperWeekNewModelClass?> = ArrayList()
        mRecyclerCategery!!.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)

        mCategaryHDAdepter = CategaryHDAdepter(this, newList, object : CategaryHDAdepter.OnClickHdListener {
            override fun onClickHD(position: Int, nCatName: String) {
                mWallpaperList.clear()
                catPosition = position
                Log.e("TAG", "onClickHD: $nCatName")
                for (i in mImageNewList!!.indices) {
                    if (mImageNewList!![i]!!.name == nCatName) {
                        mWallpaperList.add(
                            WallpaperWeekNewModelClass(
                                mImageNewList!![i],
                                mImageNewList!![i]!!.isPremium != 0,
                                mImageNewList!![i]!!.image,
                                mImageNewList!![i]!!.coins!!
                            )
                        )
                    }
                }
                Log.e("TAG", "updateNewUI1113: ${mWallpaperList.size}")

                Log.d("TAGS", "onClickHD: $mNewListImageNew")
                Log.d("TAGS", "onClickHD11: ${mImageNewListData!!.size}")


                val mTempList: ArrayList<WallpaperWeekNewModelClass?> = ArrayList()
                if (getBoolean(this@WallpaperOfWeekNewActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                    for (image: ImagesItem? in mImageNewList!!) {
                        dbHelperSuscription!!.insertPath((image!!.image)!!)
                        Log.d("EWWWWWW", "updateUI: " + image.image)

                    }
                    for (i in mWallpaperList.indices) {
                        mWallpaperList[i]!!.isLocked = false
                    }
                    mTempList.addAll(mWallpaperList)

                } else {
                    dbHelperSuscription!!.deleteAllData()
                    for (i in mWallpaperList.indices) {
                        val model: WallpaperWeekNewModelClass? = mWallpaperList[i]
                        if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                            model.isLocked = false
                        }
                        mTempList.add(model)

                        //   }
                    }
                    mTempList.shuffle()

                }
                if (mImageNewList != null && mImageNewList!!.size > 0) {
                    val onClickItem: WallpaperOfWeekNewAdapter.OnClickItem =
                        object : WallpaperOfWeekNewAdapter.OnClickItem {

                            override fun onClickWallpaper(wallpaperWeekModel: WallpaperWeekNewModelClass?, pos: Int) {
                                if (!NetworkHelper.isOnline(this@WallpaperOfWeekNewActivity)) {
                                    Toast.makeText(
                                        this@WallpaperOfWeekNewActivity,
                                        resources.getString(R.string.check_internet_connection),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    return
                                }

                                val intent = Intent(this@WallpaperOfWeekNewActivity, WallpaperOfWeekPagerViewActivity::class.java)
                                intent.putParcelableArrayListExtra("ARRAYLIST", mTempList)
                                intent.putExtra("position", pos)
                                startActivity(intent)
                            }

                            override fun startAnimation() {}
                        }
                    adapterNew =
                        WallpaperOfWeekNewAdapter(mTempList, this@WallpaperOfWeekNewActivity, onClickItem)
                    recyclerWallpaper!!.adapter = adapterNew
                }
                layoutError!!.visibility = View.GONE
                recyclerWallpaper!!.visibility = View.VISIBLE
                layoutOffline!!.visibility = View.GONE
                layoutProgress!!.visibility = View.GONE

            }
        })

        mRecyclerCategery!!.adapter = mCategaryHDAdepter
        /*for (i in mImageNewList!!.indices) {
            Log.d("TAG=====>>>>", "updateUI: " + mImageNewList!![i]!!.coins)
            mWallpaperList.add(
                WallpaperWeekNewModelClass(
                    mImageNewList!![i],
                    mImageNewList!![i]!!.isPremium != 0,
                    mImageNewList!![i]!!.image,
                    mImageNewList!![i]!!.coins!!
                )
            )
            Log.e(TAG, "updateNewUI111: ${mWallpaperList.size}")
        }
        val mTempList: ArrayList<WallpaperWeekNewModelClass?> = ArrayList()
        if (getBoolean(this@WallpaperOfWeekNewActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            for (image: ImagesItem? in mImageNewList!!) {
                dbHelperSuscription!!.insertPath((image!!.image)!!)
                Log.d("EWWWWWW", "updateUI: " + image.image)

            }
            for (i in mWallpaperList.indices) {
                mWallpaperList[i]!!.isLocked = false
            }
            mTempList.addAll(mWallpaperList)
        } else {
            dbHelperSuscription!!.deleteAllData()
            for (i in mWallpaperList.indices) {
                val model: WallpaperWeekNewModelClass? = mWallpaperList[i]
                if (dbHelper!!.checkPathExist((model!!.imageItem!!.image)!!)) {
                    model.isLocked = false
                }
                mTempList.add(model)

                //   }
            }
            mTempList.shuffle()

        }
        if (mImageNewList != null && mImageNewList!!.size > 0) {
            val onClickItem: WallpaperOfWeekNewAdapter.OnClickItem =
                object : WallpaperOfWeekNewAdapter.OnClickItem {

                    override fun onClickWallpaper(
                        wallpaperWeekModel: WallpaperWeekNewModelClass?,
                        pos: Int
                    ) {
                        if (!NetworkHelper.isOnline(this@WallpaperOfWeekNewActivity)) {
                            Toast.makeText(
                                this@WallpaperOfWeekNewActivity,
                                getResources().getString(R.string.check_internet_connection),
                                Toast.LENGTH_SHORT
                            ).show()
                            return
                        }
                        val intent: Intent = Intent(
                            this@WallpaperOfWeekNewActivity,
                            WallpaperOfWeekPagerViewActivity::class.java
                        )
                        intent.putParcelableArrayListExtra("ARRAYLIST", mTempList)
                        intent.putExtra("position", pos)
                        startActivity(intent)
                    }

                    public override fun startAnimation() {}
                }
            adapterNew =
                WallpaperOfWeekNewAdapter(mTempList, this@WallpaperOfWeekNewActivity, onClickItem)
            recyclerWallpaper!!.adapter = adapterNew
        }
        layoutError!!.visibility = View.GONE
        recyclerWallpaper!!.visibility = View.VISIBLE
        layoutOffline!!.visibility = View.GONE
        layoutProgress!!.visibility = View.GONE*/
    }

    private fun showAdDialog(model: WallpaperWeekNewModel, position: Int) {
        val bottomSheetFragment: BottomSheetFragment = BottomSheetFragment(
            getResources().getString(R.string.watch_video),
            getResources().getString(R.string.do_you_want_watch_video),
            getResources().getString(R.string.watch),
            getResources().getString(R.string.cancel),
            R.drawable.ic_video,
            object : BottomSheetFragment.OnButtonClickListener {
                public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                    bottomSheetDialo!!.dismiss()
                    showAd(position, model)
                }

                public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                    bottomSheetDialog!!.dismiss()
                }
            })
        bottomSheetFragment.show(supportFragmentManager, "dialog")
    }

    fun showAd(position: Int, model: WallpaperWeekNewModel) {
        val flag: BooleanArray = booleanArrayOf(false)
        isShowRewardVideoAd(
            onStartToLoadRewardVideoAd = {

            },
            onUserEarnedReward = { isUserEarnedReward ->
                if(isUserEarnedReward) {

                    dbHelper!!.insertPath((model.imageItem!!.image)!!)
                    model.isLocked = false
                    flag[0] = true
                    if (adapterNew != null) {
                        adapterNew!!.notifyItemChanged(position)
                    }
                }
                if (flag[0]) {
                    val i: Intent = Intent(
                        this@WallpaperOfWeekNewActivity,
                        WallpaperWeekViewActivity::class.java
                    )
                    i.putExtra("imagepath", model.imageItem!!.image)
                    startActivity(i)
                }
            },
            onAdLoaded = {

            }
        )

    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onResume() {
        super.onResume()

        Log.d(TAG, "onResume: position ${Constants.catPosition}")

//        try {
//            if (mCategaryHDAdepter!=null && mRecyclerCategery!=null){
//                finish()
//                overridePendingTransition(0,0)
//                startActivity(intent)
//                overridePendingTransition(0,0)
//
//                mRecyclerCategery!!.postDelayed(
//                    Runnable { mRecyclerCategery!!.smoothScrollToPosition(catPosition) },
//                    300
//                )
//
//                mRecyclerCategery!!.postDelayed(Runnable {
//                    mRecyclerCategery!!.findViewHolderForAdapterPosition(
//                        catPosition
//                    )!!.itemView.performClick()
//                }, 400)
////                mRecyclerCategery!!.findViewHolderForAdapterPosition(catPosition)!!.itemView.performClick()
////                mRecyclerCategery!!.adapter!!.notifyItemChanged(catPosition)
//            }
//        } catch (e: Exception) {
////            mRecyclerCategery!!.findViewHolderForLayoutPosition()
//        }

        if (Constants.isSubscribedW) {
            recreate()
            Constants.isSubscribedW = false
        }
        if (Constants.isDataChaged) {
            Constants.isDataChaged = false
            if (mImageList != null) {
                mImageList!!.clear()
                mImageNewList!!.clear()
            }


//            updateUI()

            updateNewUI()
//            recreate()
            Log.d("14-10-2021", "onResume: ")
        }
    }

    override fun onDestroy() {

        super.onDestroy()
    }


    override fun onBackPressed() {
        Log.d(TAG, "onBackPressed: clickckckc")
        if (!getBoolean(this@WallpaperOfWeekNewActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            isShowInterstitialAd {
                finish()
            }
        } else {
            Log.d(TAG, "onBackPressed: ads3")
            finish()
        }

    }


}