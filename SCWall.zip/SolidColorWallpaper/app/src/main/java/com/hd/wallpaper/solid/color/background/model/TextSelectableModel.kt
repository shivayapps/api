package com.hd.wallpaper.solid.color.background.model

class TextSelectableModel(var imgePath: String, var isDeletable: Boolean)