package com.hd.wallpaper.solid.color.background.live_wallpaper

import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.service.wallpaper.WallpaperService
import android.util.Log
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.constants.Constants

class CustomWallpaper : WallpaperService() {
    internal lateinit var mBitmap: Bitmap
    override fun onCreateEngine(): Engine {
        return WallpaperEngine()
    }

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        return Service.START_STICKY
    }

    internal inner class WallpaperEngine : Engine() {
        //Duration between slides in milliseconds
        private val SLIDE_DURATION = 8
        private val mImagesArray: IntArray
        private var mImagesArrayIndex = 0
        private val mDrawWallpaper: Thread
        private val mImageScale = "Fit to screen"
        private val customWallpaperHelper: CustomWallpaperHelper
        private fun incrementCounter() {
            mImagesArrayIndex++
            if (mImagesArrayIndex >= mImagesArray.size) {
                mImagesArrayIndex = 0
            }
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                canvas?.let { drawImage(it) }
            } finally {
                if (canvas != null) {
                    holder.unlockCanvasAndPost(canvas)
                }
            }
        }

        private fun drawImage(canvas: Canvas) {
            //Get the image and resize it
            val image = BitmapFactory.decodeResource(resources,
                    mImagesArray[mImagesArrayIndex])

            //Draw background
            customWallpaperHelper.setBackground(canvas)

            //Scale the canvas
            val mScale = customWallpaperHelper.getCanvasScale(mImageScale, mBitmap.width, mBitmap.height)
            canvas.scale(mScale!!.x, mScale.y)

            //Draw the image on screen
            val mPos = customWallpaperHelper.getImagePos(mScale, mBitmap.width, mBitmap.height)
            canvas.drawBitmap(mBitmap, mPos!!.x.toFloat(), mPos.y.toFloat(), null)
        }

        init {
            customWallpaperHelper = CustomWallpaperHelper(applicationContext, resources)
            mImagesArray = intArrayOf(R.drawable.ad_ic_box)
            mBitmap = Constants.mWallpaperBitmap!!
            Log.d("7812123123123", "WallpaperEngine: $mBitmap")
            mDrawWallpaper = Thread(Runnable {
                try {
                    while (true) {
                        drawFrame()
                        incrementCounter()
                        Thread.sleep(SLIDE_DURATION.toLong())
                    }
                } catch (e: Exception) {
                    //
                }
            })
            mDrawWallpaper.start()
            //   drawFrame();
        }
    }
}