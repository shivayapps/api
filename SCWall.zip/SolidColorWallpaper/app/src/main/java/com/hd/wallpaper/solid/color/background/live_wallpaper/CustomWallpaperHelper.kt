package com.hd.wallpaper.solid.color.background.live_wallpaper

import android.content.Context
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Point
import android.graphics.PointF
import android.view.WindowManager

class CustomWallpaperHelper(private val mContext: Context, private val mResources: Resources) {
    private val screenSize = Point()
    private var bgImageScaled: Bitmap? = null
    private var bgImagePos = Point(0, 0)
    private fun scaleBackground() {
        val imageScale = "Stretch to screen"
        val bgImage: Bitmap? = null
        if (imageScale == IMAGE_SCALE_STRETCH_TO_SCREEN) {
            bgImagePos = Point(0, 0)
            bgImageScaled = Bitmap.createScaledBitmap(bgImage!!, screenSize.x, screenSize.y, true)
        }
    }

    fun setBackground(canvas: Canvas) {
        if (bgImageScaled != null) {
            canvas.drawBitmap(bgImageScaled!!, bgImagePos.x.toFloat(), bgImagePos.y.toFloat(), null)
        } else {
            canvas.drawColor(-0x1000000)
        }
    }

    val screenWidth: Int
        get() = screenSize.x

    val screenHeight: Int
        get() = screenSize.y

    fun getImagePos(canvasScale: PointF?, imageWidth: Int, imageHeight: Int): Point {
        val imagePos = Point()
        imagePos.x = (screenSize.x - imageWidth * canvasScale!!.x).toInt() / 2
        imagePos.y = (screenSize.y - imageHeight * canvasScale.y).toInt() / 2
        return imagePos
    }

    fun getCanvasScale(imageScale: String, imageWidth: Int, imageHeight: Int): PointF {
        val canvasScale = PointF(1f, 1f)
        if (imageScale == IMAGE_SCALE_STRETCH_TO_SCREEN) {
            canvasScale.x = screenWidth / (1f * imageWidth)
            canvasScale.y = screenHeight / (1f * imageHeight)
        } else {
            var tooWide = false
            var tooTall = false
            if (screenWidth < imageWidth) {
                tooWide = true
            }
            if (screenHeight < imageHeight) {
                tooTall = true
            }
            if (tooWide && tooTall) {
                val x = imageWidth / screenWidth
                val y = imageHeight / screenHeight
                if (x > y) {
                    canvasScale.x = screenWidth / (1f * imageWidth)
                    canvasScale.y = 1f
                } else {
                    canvasScale.x = 1f
                    canvasScale.y = screenHeight / (1f * imageHeight)
                }
            } else if (tooWide) {
                canvasScale.x = screenWidth / (1f * imageWidth)
                canvasScale.y = 1f
            } else if (tooTall) {
                canvasScale.x = 1f
                canvasScale.y = screenHeight / (1f * imageHeight)
            }
        }
        return canvasScale
    }

    companion object {
        const val IMAGE_SCALE_STRETCH_TO_SCREEN = "Stretch to   screen"
        const val IMAGE_SCALE_FIT_TO_SCREEN = "Fit to screen"
    }

    init {
        val wm = mContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        screenSize.x = display.width
        screenSize.y = display.height
    }
}