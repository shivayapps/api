package com.hd.wallpaper.solid.color.background.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.model.CategoryNameIconModel

class CategoryNewAdapter(var context: Context, var mCategoryList: ArrayList<CategoryNameIconModel>, var onCLickCategory: OnCLickCategory) : RecyclerView.Adapter<CategoryNewAdapter.MyViewHolder>() {


    interface OnCLickCategory {
        fun onClickCategory(i: Int)
    }

//    class MyViewHolder(view: View) : RecyclerView.ViewHolder(view)

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val img_category: ImageView = itemView.findViewById(R.id.img_category)
        val ppBar: ProgressBar = itemView.findViewById(R.id.ppBar)
        val txt_cat_name: TextView = itemView.findViewById(R.id.txt_cat_name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(context).inflate(R.layout.rv_screen_category_new, parent, false))
    }

    override fun getItemCount(): Int {
        return mCategoryList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.txt_cat_name.text = mCategoryList[position].categoryName
        holder.ppBar.visibility=View.VISIBLE
        holder.img_category.visibility=View.GONE

        Glide.with(context).load(mCategoryList[position].categoryIcon).into(object : CustomTarget<Drawable?>() {
            override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                holder.img_category.setImageDrawable(resource)
                holder.img_category.visibility=View.VISIBLE
                holder.ppBar.visibility=View.GONE
            }

            override fun onLoadCleared(placeholder: Drawable?) {

            }
        })



        Glide.with(context).load(mCategoryList[position].categoryIcon).into(holder.img_category)
        holder.itemView.setOnClickListener {
            onCLickCategory.onClickCategory(position)
        }
    }
}