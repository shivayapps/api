package com.hd.wallpaper.solid.color.background.imagePicker.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import it.sephiroth.android.library.imagezoom.ImageViewTouch;

public class ExpandableImageViewTouch extends ImageViewTouch {

    public ExpandableImageViewTouch(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ExpandableImageViewTouch(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        View.OnTouchListener listener = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (getScale() > 1f) {
                    getParent().requestDisallowInterceptTouchEvent(true);
                } else {
                    getParent().requestDisallowInterceptTouchEvent(false);
                }
                return false;
            }
        };
        setOnTouchListener(listener);
        setDisplayType(DisplayType.FIT_TO_SCREEN);
    }

}