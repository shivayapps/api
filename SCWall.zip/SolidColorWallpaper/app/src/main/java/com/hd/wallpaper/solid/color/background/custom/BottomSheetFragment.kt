package com.hd.wallpaper.solid.color.background.custom

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.annotation.RequiresApi
import androidx.fragment.app.DialogFragment
import com.hd.wallpaper.solid.color.background.R

class BottomSheetFragment : DialogFragment {
    private var mTitle: String? = null
    private var mMessage: String? = null
    private var positive: String? = null
    private var negative: String? = null
    private var mListener: OnButtonClickListener? = null
    private var bottomSheetDialog: Dialog? = null
    private var titleImagel = 0

    constructor() {}
    constructor(mTitle: String?, mMessage: String?, positive1: String?, negative1: String?, titleImage: Int, mListener: OnButtonClickListener?) {
        this.mTitle = mTitle
        this.mMessage = mMessage
        positive = positive1
        negative = negative1
        this.mListener = mListener
        titleImagel = titleImage
    }

    interface OnButtonClickListener {
        fun onPositive(bottomSheetDialo: BottomSheetFragment?)
        fun onNegative(bottomSheetDialog: BottomSheetFragment?)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setStyle(BottomSheetDialogFragment.STYLE_NORMAL, R.style.materialButton);
        setStyle(STYLE_NO_TITLE, R.style.materialButton)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.dialog_delete_wallpaper, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val tvTitle = view.findViewById<TextView>(R.id.txtTitle)
        val tvMessgae = view.findViewById<TextView>(R.id.txtMessage)
        tvMessgae.text = mMessage
        tvTitle.text = mTitle
        try {
            (view.findViewById<View>(R.id.iv_dialog_logo) as ImageView).setImageDrawable(activity!!.resources.getDrawable(titleImagel))
        } catch (e: Exception) {
            e.printStackTrace()
        }
        (view.findViewById<View>(R.id.btnPositive) as Button).text = positive
        (view.findViewById<View>(R.id.btnNagative) as Button).text = negative
        view.findViewById<View>(R.id.btnPositive).setOnClickListener { v: View? -> mListener!!.onPositive(this@BottomSheetFragment) }
        view.findViewById<View>(R.id.btnNagative).setOnClickListener { v: View? -> mListener!!.onNegative(this@BottomSheetFragment) }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        bottomSheetDialog = dialog
        // ((View) getView().getParent()).setPadding(0,0,0,);
        val displayMetrics = DisplayMetrics()
        requireActivity().windowManager.defaultDisplay.getMetrics(displayMetrics)
        val height = displayMetrics.heightPixels
        var width = displayMetrics.widthPixels
        width -= width / 8
        bottomSheetDialog!!.window!!.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
        // setColoredNavBar(true);
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            //setWhiteNavigationBar(dialog);
        }
        return dialog
    }

    private fun setColoredNavBar(coloredNavigationBar: Boolean) {
        if (coloredNavigationBar && bottomSheetDialog!!.window != null && Build.VERSION.SDK_INT >= 21) {
            //if (isColorLight(Color.WHITE)) {
            bottomSheetDialog!!.window!!.navigationBarColor = Color.WHITE
            if (Build.VERSION.SDK_INT >= 26) {
                bottomSheetDialog!!.window!!.navigationBarColor = Color.WHITE
                var flags = bottomSheetDialog!!.window!!.decorView.systemUiVisibility
                flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                bottomSheetDialog!!.window!!.decorView.systemUiVisibility = flags
            }
            /* } else {


                if (Build.VERSION.SDK_INT >= 26) {
                    int flags = bottomSheetDialog.getWindow().getDecorView().getSystemUiVisibility();
                    flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    bottomSheetDialog.getWindow().getDecorView().setSystemUiVisibility(flags);
                }
            }*/
        }
    }

    override fun onStart() {
        super.onStart()
        /*if (getDialog() != null && getDialog().getWindow() != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Window window = getDialog().getWindow();
            window.findViewById(com.google.android.material.R.id.container).setFitsSystemWindows(false);
            // dark navigation bar icons
            View decorView = window.getDecorView();
            decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        }*/
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private fun setWhiteNavigationBar(dialog: Dialog) {
        val window = dialog.window
        if (window != null) {
            val metrics = DisplayMetrics()
            window.windowManager.defaultDisplay.getMetrics(metrics)
            val dimDrawable = GradientDrawable()
            // ...customize your dim effect here
            val navigationBarDrawable = GradientDrawable()
            navigationBarDrawable.shape = GradientDrawable.RECTANGLE
            navigationBarDrawable.setColor(Color.WHITE)
            val layers = arrayOf<Drawable>(dimDrawable, navigationBarDrawable)
            val windowBackground = LayerDrawable(layers)
            windowBackground.setLayerInsetTop(1, metrics.heightPixels)
            window.setBackgroundDrawable(windowBackground)
            var flags = dialog.window!!.decorView.systemUiVisibility
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            window.decorView.systemUiVisibility = flags
        }
    }

    private fun isColorLight(@ColorInt color: Int): Boolean {
        if (color == Color.BLACK) return false else if (color == Color.WHITE || color == Color.TRANSPARENT) return true
        val darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255
        return darkness < 0.4
    }
}