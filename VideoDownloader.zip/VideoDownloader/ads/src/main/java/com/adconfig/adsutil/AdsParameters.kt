package com.adconfig.adsutil

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import java.util.Date
import kotlin.math.truncate

class AdsParameters(context: Context) {

    private val ADS_PARAMETERS = "ADS_PARAMETERS"
    var adinterval: Long = 60

    var openCounter: Int
        get() = preferences.getInt("openCounter", 0)
        set(value) = preferences.edit().putInt("openCounter", value).apply()

    private val preferences: SharedPreferences =
        context.getSharedPreferences(ADS_PARAMETERS, Context.MODE_PRIVATE)
    var isTest = false

    var adWidth: Int
        get() = preferences.getInt("adWidth", 280)
        set(value) = preferences.edit().putInt("adWidth", value).apply()

    var showInterTime: Long
        get() = preferences.getLong("showInterTime", 0)
        set(value) = preferences.edit().putLong("showInterTime", value).apply()

    fun isNeedInterAd():Boolean{
        preferences.getBoolean("isNeedInterAd", true)
        return true
    }
    fun isNeedInterAd(value: Boolean){
        preferences.edit().putBoolean("isNeedInterAd", value).apply()
    }

//    var callNativeId: String?
//        get() = preferences.getString("call_native_id", "")
//        set(value) = preferences.edit().putString("call_native_id", value).apply()
//    var callBannerId: String?
//        get() = preferences.getString("call_banner_id", "")
//        set(value) = preferences.edit().putString("call_banner_id", value).apply()

//    var callAdType: String?
//        get() = preferences.getString("call_ad_type", "native")
//        set(value) = preferences.edit().putString("call_ad_type", value).apply()

}