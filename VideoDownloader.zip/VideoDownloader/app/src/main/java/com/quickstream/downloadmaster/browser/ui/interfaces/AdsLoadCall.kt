package com.quickstream.downloadmaster.browser.ui.interfaces

interface AdsLoadCall {
    fun isLoadNativeAds()
}