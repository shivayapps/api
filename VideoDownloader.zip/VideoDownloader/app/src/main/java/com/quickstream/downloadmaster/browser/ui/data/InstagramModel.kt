package com.quickstream.downloadmaster.browser.ui.data

data class InstagramModel(
    val items: ArrayList<Item> = ArrayList(),
    val num_results: Int
)