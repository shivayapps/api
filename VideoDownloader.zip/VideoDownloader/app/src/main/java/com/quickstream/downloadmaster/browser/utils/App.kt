package com.quickstream.downloadmaster.browser.utils

import android.content.Context
import android.os.Build
import android.os.Environment
import android.webkit.MimeTypeMap
import androidx.annotation.RequiresApi
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.quickstream.downloadmaster.browser.ui.data.DataModel
import java.io.File

class App(var context: Context) {
    fun analyze() {
        whatsAppDataVideo.clear()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            analyzeAboveR()
        } else {
            analyzeBelowR()
        }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    fun analyzeAboveR() {
        val whatsappUri = Preferences(context).getWhatsAppUri()
        val statuses = DocumentFile.fromTreeUri(context, whatsappUri!!)!!
            .listFiles()
        for (file in statuses) {
            fetchDetailsOfFile(file)
        }
    }

    private fun analyzeBelowR() {
        val path = FileUtil.getExternalStoragePublicDirectory(context, "WhatsApp") + SUFFIX_PATH
        val path1 = Environment.getExternalStorageDirectory()
            .toString() + "/Android/media/com.whatsapp/WhatsApp/Media/.Statuses"
        val directory = File(path)
        val directory1 = File(path1)
        val files = directory.listFiles()
        val files1 = directory1.listFiles()
        if (files != null && directory.exists()) {
            fetchDetails(directory)
        } else if (files1 != null && directory1.exists()) {
            fetchDetails(directory1)
        }
    }

    private fun fetchDetails(directory: File) {
        for (file in directory.listFiles()!!) {
            fetchDetailsOfFile(file)
        }
    }

    private fun fetchDetailsOfFile(file: File) {
        val extension = MimeTypeMap.getFileExtensionFromUrl(file.absolutePath)
        val type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
        if (type != null) {
            val fileUir = FileProvider.getUriForFile(
                context,
                context.packageName + ".provider",
                file
            ).toString()
            if (type == VIDEO_MP4) {
                whatsAppDataVideo.add(DataModel(fileUir))
            } else if (type == IMAGE_JPEG) {
                whatsAppDataVideo.add(DataModel(fileUir))
            }
        }
    }

    private fun fetchDetailsOfFile(file: DocumentFile) {
        val type = file.type
        if (type != null) {
            val fileUir = file.uri.toString()
            if (type == VIDEO_MP4) {
                whatsAppDataVideo.add(DataModel(fileUir ))
            } else if (type == IMAGE_JPEG) {
                whatsAppDataVideo.add(DataModel(fileUir))
            }
        }
    }

    companion object {
        const val VIDEO_MP4 = "video/mp4"
        const val IMAGE_JPEG = "image/jpeg"
        val SUFFIX_PATH = File.separator + "Media" + File.separator + ".Statuses"
        var whatsAppDataVideo = ArrayList<DataModel>()
    }
}