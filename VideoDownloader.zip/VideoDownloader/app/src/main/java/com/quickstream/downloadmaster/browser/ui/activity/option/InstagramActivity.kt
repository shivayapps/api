package com.quickstream.downloadmaster.browser.ui.activity.option

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextPaint
import android.util.Log
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.ViewPager
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView

import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.customView.VideoContentSearch
import com.quickstream.downloadmaster.browser.databinding.ActivityInstagramBinding
import com.quickstream.downloadmaster.browser.ui.activity.BaseActivity
import com.quickstream.downloadmaster.browser.ui.activity.IntroActivity
import com.quickstream.downloadmaster.browser.ui.fragment.DownloadFragment
import com.quickstream.downloadmaster.browser.ui.fragment.FacebookFragment
import com.quickstream.downloadmaster.browser.ui.fragment.InstagramFragment
import com.quickstream.downloadmaster.browser.ui.fragment.TwitterFragment
import com.quickstream.downloadmaster.browser.utils.AdCache
import com.quickstream.downloadmaster.browser.utils.Constant
import com.quickstream.downloadmaster.browser.utils.MyApplication
import com.quickstream.downloadmaster.browser.utils.Preferences
import com.quickstream.downloadmaster.browser.utils.UtilsAd
import java.net.URI
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocketFactory


class InstagramActivity : BaseActivity() {

    lateinit var binding: ActivityInstagramBinding
    lateinit var preferences: Preferences
    private var defaultSSLSF: SSLSocketFactory? = null
    var openType = ""
    var isOpenFromShare = false
    var shareUrl: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInstagramBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inti()
    }

    private fun inti() {
        openType = intent.getStringExtra(Constant.EXTRA_TYPE)!!

        try {
            isOpenFromShare = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_TO_SHARE, false)
            if (isOpenFromShare) {
                shareUrl = intent.getStringExtra(Constant.PUT_KEY_URL)!!
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        binding.loutToolbar.ivHelp.visibility = View.GONE
        binding.frameTop.visibility = View.GONE

        when (openType) {
            Constant.DOWNLOAD_INSTAGRAM -> {
                binding.loutToolbar.txtTitle.text = getString(R.string.instagram)
                binding.txtTabInsta.text = getString(R.string.instagram)
                binding.loutToolbar.ivRight.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.ic_instagram
                    )
                )
                binding.loutToolbar.ivHelp.visibility = View.VISIBLE
            }

            Constant.DOWNLOAD_FACEBOOK -> {
                binding.loutToolbar.txtTitle.text = getString(R.string.facebook)
                binding.txtTabInsta.text = getString(R.string.facebook)
                binding.loutToolbar.ivRight.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.ic_facebook
                    )
                )
            }

            Constant.DOWNLOAD_TWITTER -> {
                loadBannerAd()
                binding.loutToolbar.txtTitle.text = getString(R.string.twitter)
                binding.txtTabInsta.text = getString(R.string.twitter)

                binding.loutToolbar.ivRight.setImageDrawable(
                    ContextCompat.getDrawable(
                        this,
                        R.drawable.ic_twitter
                    )
                )
            }
        }

        preferences = Preferences(this)
        defaultSSLSF = HttpsURLConnection.getDefaultSSLSocketFactory()
        binding.loutToolbar.ivRight.visibility = View.VISIBLE

        setTab()
        intiListener()
        setSelectTab(binding.btnTabInsta, binding.btnTabDownload)
    }

//    private fun loadBannerTopAd() {
//        binding.frameTop.visibility = View.VISIBLE
//        UtilsAd.showNative(this,binding.frameTop)
//    }


    var isAdLoaded=false
    var mAdView: AdView?=null

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    private fun loadBannerAd() {
        if (!isAdLoaded) {
            val adId = getString(R.string.bannerInsta)
            BannerAdHelper.showBanner(this, binding.frameTop, binding.frameTop, adId,
                AdCache.bannerInsta, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.bannerInsta = adView
                    isAdLoaded = isLoaded
                })
        }
    }

    private fun setTab() {

        val downloadFragment = DownloadFragment.newInstance(this,
            openType,
            openType != Constant.DOWNLOAD_TWITTER
        )

        val fragmentList: java.util.ArrayList<Fragment> = ArrayList()
        when (openType) {
            Constant.DOWNLOAD_FACEBOOK -> fragmentList.add(FacebookFragment.newInstance())
            Constant.DOWNLOAD_TWITTER -> fragmentList.add(TwitterFragment.newInstance())
            else -> {
                fragmentList.add(InstagramFragment(this))
            }
        }

        fragmentList.add(downloadFragment)
        binding.viewpager.adapter = PageAdapter(supportFragmentManager, fragmentList)
        if (shareUrl.isNotEmpty()) {
            Handler(Looper.myLooper()!!).postDelayed({
                val fragment = fragmentList[0]
                if (fragment is InstagramFragment) {
                    val instagramFragment: InstagramFragment = fragment
                    instagramFragment.shareUrl(shareUrl)
                } else if (fragment is TwitterFragment) {
                    val twitterFragment: TwitterFragment = fragment
                    twitterFragment.shareUrl(shareUrl)
                }
            }, 1000)
        }
        binding.viewpager.offscreenPageLimit = 2
        binding.viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {

            }

            override fun onPageSelected(position: Int) {
                if (position == 0)
                    setSelectTab(binding.btnTabInsta, binding.btnTabDownload)
                else
                    setSelectTab(binding.btnTabDownload, binding.btnTabInsta)
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
    }

    private fun setSelectTab(btnSelect: LinearLayout, btnUnSelect: LinearLayout) {
        btnSelect.background = ContextCompat.getDrawable(this, R.drawable.btn_gradient)
        btnUnSelect.background = ContextCompat.getDrawable(this, R.drawable.btn_gray)

        if (btnSelect == binding.btnTabInsta) {
            setGradientText(binding.txtTabDownload)
            removeGradientText(binding.txtTabInsta)
        } else {
            setGradientText(binding.txtTabInsta)
            removeGradientText(binding.txtTabDownload)
        }
    }

    override fun onResume() {
        super.onResume()
        mAdView?.resume()
//        Handler(Looper.myLooper()!!).postDelayed({
//            loadNativeDownloadBrowser()
//        }, 1000)
    }


    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.loutToolbar.ivRight.setOnClickListener {
            if (openType == Constant.DOWNLOAD_TWITTER) {
                openApp("com.twitter.android", "Twitter is not Installed", this)
            } else
                startActivity(
                    Intent(
                        this,
                        BrowserDownloadActivity::class.java
                    ).putExtra(
                        Constant.PUT_KEY_URL,
                        if (openType == Constant.DOWNLOAD_INSTAGRAM) Constant.URL_Insta else Constant.URL_FB
                    )
                        .putExtra(
                            Constant.EXTRA_TYPE,
                            if (openType == Constant.DOWNLOAD_INSTAGRAM) Constant.TYPE_Insta else Constant.TYPE_FB
                        )
                )
        }
        binding.loutToolbar.ivHelp.setOnClickListener {
            val intent = Intent(this, IntroActivity::class.java)
            startActivity(intent)
        }
        binding.btnTabInsta.setOnClickListener {
            binding.viewpager.currentItem = 0
        }

        binding.btnTabDownload.setOnClickListener {
            binding.viewpager.currentItem = 1
        }
    }

    private fun openApp(packageName: String, name: String, activity: Activity) {
        try {
            val i = activity.packageManager.getLaunchIntentForPackage(packageName)
            MyApplication.disabledOpenAds()
            activity.startActivity(i)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(activity, name, Toast.LENGTH_SHORT).show()
        }
    }


    private fun getUrlWithoutParameters(url: String): String? {
        return try {
            val uri = URI(url)
            URI(
                uri.scheme,
                uri.authority,
                uri.path,
                null,  // Ignore the query part of the input url
                uri.fragment
            ).toString()
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    private fun removeGradientText(textView: TextView) {
        textView.paint.shader = null
        textView.invalidate()
    }

    private fun setGradientText(btnSelect: TextView) {
        val paint: TextPaint = btnSelect.paint
        val width = paint.measureText(btnSelect.text.toString())

//        val bitmap = BitmapFactory.decodeResource(resources, R.drawable.btn_button_big)
//        val shader: Shader = BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)

        val textShader: Shader = LinearGradient(
            0f, 0f,
            width,
            btnSelect.textSize,
            intArrayOf(
                ContextCompat.getColor(this, R.color.gradient1),
                ContextCompat.getColor(this, R.color.gradient2),
                ContextCompat.getColor(this, R.color.gradient2),
                ContextCompat.getColor(this, R.color.gradient2),
                ContextCompat.getColor(this, R.color.gradient3),
            ), null, Shader.TileMode.CLAMP
        )

        btnSelect.paint.shader = textShader
        btnSelect.invalidate()
    }

    class MyBrowser(
        var loginActivity: Activity,
        var preferences: Preferences,
    ) : WebViewClient() {

        override fun shouldOverrideUrlLoading(webView: WebView, str: String?): Boolean {
            webView.loadUrl(str!!)
            return true
        }

        override fun onPageFinished(webView: WebView?, str: String?) {
            super.onPageFinished(webView, str)
            //                loadingPageProgress.setVisibility(View.GONE)
        }


        override fun onPageStarted(webview: WebView, url: String, favicon: Bitmap) {
            //                Handler(Looper.getMainLooper()).post {
            //                    val urlBox: EditText = getBaseActivity().findViewById(R.id.inputURLText)
            //                    urlBox.setText(url)
            //                    urlBox.setSelection(urlBox.text.length)
            //                    this@BrowserWindow.url = url
            //                }
            //                view.findViewById<View>(R.id.loadingProgress).setVisibility(View.GONE)
            //                loadingPageProgress.setVisibility(View.VISIBLE)
            super.onPageStarted(webview, url, favicon)
        }

        override fun onLoadResource(view: WebView, url: String) {
            Log.d("fb :", "URL: $url")
            val viewUrl = view.url
            val title = view.title
            object : VideoContentSearch(
                loginActivity,
                url,
                viewUrl,
                title
            ) {
                override fun onStartInspectingURL() {
                    //                        Utils.Companion.disableSSLCertificateChecking()
                }

                override fun onFinishedInspectingURL(finishedAll: Boolean) {
//                    HttpsURLConnection.setDefaultSSLSocketFactory(defaultSSLSF)
                }

                override fun onVideoFound(
                    size: String?,
                    type: String?,
                    link: String?,
                    name: String?,
                    page: String?,
                    chunked: Boolean,
                    website: String?,
                    audio: Boolean
                ) {
                    Log.e("", " type==>> $type link==>> $link name==>> $name page==>> $page ")
                    //                        videoList.addItem(size, type, link, name, page, chunked, website, audio)
                    //                        updateFoundVideosBar()
                }
            }.start()
        }

    }


    class PageAdapter(fm: FragmentManager, var fragmentList: java.util.ArrayList<Fragment>) :
        FragmentPagerAdapter(fm) {
        override fun getCount(): Int {
            return fragmentList.size
        }

        override fun getItem(position: Int): Fragment {
            return fragmentList[position]
        }
    }
}

