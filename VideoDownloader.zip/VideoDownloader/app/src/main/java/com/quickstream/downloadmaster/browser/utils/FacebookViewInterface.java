package com.quickstream.downloadmaster.browser.utils;

import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.quickstream.downloadmaster.browser.ui.activity.BrowserActivity;

import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

public class FacebookViewInterface {
    public static final Companion Companion = new Companion(null);
    public static final String FACEBOOK_ACCOUNT_POSTS = "   ";
    public static final String FACEBOOK_COMPLEX_POST = "html-renderer Chrome Android";
    public static final String FACEBOOK_FEED = "_2rea _24e1 _412_ _bpa _vyy _5t8z";
    public static final String FACEBOOK_LINK_POST = "_7om2";
    public static final String FACEBOOK_MULTIPLE_POSTS = "_26pa _55x2 _56bf _55x2 jjseejtz    ";
    public static final String FACEBOOK_SEARCH_POST = "   ";
    public static final String FACEBOOK_SINGLE_POST = "_5rgr _5gh8 _3-hy async_like";
    public static final String FACEBOOK_WATCH_POSTS = "_9brz    ";
    public static int complexSize;
    public static int feedSize;
    public static int linkSize;
    public static int singleSize;
    public static int watchSize;
    private final WebView webView;
    static String TAG = "FBViewInterface";

    public static final class Companion {
        public Companion(DefaultConstructorMarker defaultConstructorMarker) {
        }
    }

    public FacebookViewInterface(BrowserActivity generalWebView, WebView webView) {
        Intrinsics.checkNotNullParameter(generalWebView, "generalWebView");
        Intrinsics.checkNotNullParameter(webView, "webView");
//        this.generalWebView = generalWebView;
        Log.e(TAG, "call");
        this.webView = webView;
    }

    private final void addButton(final String str, final String[] strArr) {
        this.webView.post(new Runnable() { // from class: com.example.downloadvideos.fragments.mainWebview.facebook.FacebookViewInterface$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                Log.e(TAG, "addButton");
                m124addButton$lambda0(strArr, FacebookViewInterface.this, str);
            }
        });
    }

    public static final void m124addButton$lambda0(String[] parents, FacebookViewInterface this$0, String parentClass) {
        Intrinsics.checkNotNullParameter(parents, "$parents");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parentClass, "$parentClass");
        int length = parents.length;
        for (int i = 0; i < length; i++) {
            String str = parents[i];
            WebView webView = this$0.getWebView();
            Log.e(TAG, "m124addButton$lambda0  loadUrl");
            webView.loadUrl("javascript:(function() { var parents=document.getElementsByClassName('" + parentClass + "');var parent=parents[" + i + "];var items=parent.getElementsByClassName('_2zi_ _zgm _2zj0'); \n\tfor (var i = 0; i < items.length; i++) { \n\t\tif(items[i].getElementsByClassName('newspan').length<1){\n    \tvar k = parent.querySelectorAll(\"div[data-store]\");\n    \tvar h = k[i].getAttribute(\"data-store\");\n    \tvar g = JSON.parse(h);    \tvar jp= k[i].getAttribute(\"data-sigil\");\n      \tif (g.type === \"video\") {\n        \tvar url = g.src;\n        \tvar mani = g.dashManifest;\n        \tvar post_link = g.videoURL;\n        \tvar button=document.createElement('button1');\n        \tbutton.style.width = '28px';\n        \tbutton.style.height = '28px';\n        \tbutton.style.marginTop = '3px';\n        \tbutton.style.marginRight = '10px';\n        \tbutton.style.marginLeft = '6px';\n        \tbutton.style.outline = 'none';\n        \tbutton.style.display = 'inline-block';\n        \tbutton.style.fontSize = '16px';\n        \tbutton.style.border = 'none';\n        \tbutton.style.color = 'black';\n        \tbutton.style.textAlign= 'center';\n        \tbutton.style.float = 'right';\n        \tbutton.style.backgroundSize = 'cover';\n        \tbutton.style.backgroundColor = '#00000000';\n        \tbutton.className='button_'+" + i + "+'_'+i;\n        \tbutton.style.backgroundImage= 'url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAABUCAMAAAArteDzAAAASFBMVEVHcEz/ixX/ihX/ixb/jBP/ixb/ixX/jA7/ihb/ixb/ixb/ihb/ixb/ixb/ixf/////xYr/lCj/o0b/6dH/+PH/tWv/2bP/8eOhVDNNAAAADnRSTlMAYHfmIYRCC9fxr5LC+WWN0pIAAAKcSURBVFjDvZnZloMgDIYrKJuKYl3e/00HW7tMhSQUZv7L2vMdIBsklwumWlRNazqltepM21SivmRKNMqepBqRQWy5jUi1X3Floy0o3shUJEOQuzRLwlbcksQrOlJZshQNK41NkiGcQa1sohTquELbZGnEvRr7lZqCx0k52PTjJBxsZzNkip4neK6VzVQgDESfC9WnY625zRb/oErU8OM2rw5zAZlmpHHw2hBq/8tYEg3O6w4dJuxYZZI33ZjDmOBXtS4FfVtqa0tBX0ut+3LQp7MSFkqG2vaA6pJQfQSoLQm1grz7BOh9/7wsVN1sb8tC7W5/VhrKyEUkAdpRd58C9ftHHGoZR/cBffwEOFWFptF5eYe6K5pYK9hO0521vKDunlhX2FItAeqpB/RgDlfY/Q0FOiwH9GDCKzWIR61DUPME+xQcpI/tpjB9oCIJOkRFmD77Ycn0TJ3RmnpBbxGfVJTpt4+H/m8qzvSGIlye36kEpncpSt5/USlM7/ykdPqgkpg+TGl33TuVxvQJRdDyqfP5aqMxfeojJumdS/2jzHyTRMpJ1FJuHIHtuiX6lcVL9DRDNclt8a+3K5oCkp4DU+IUvUxE3P9ZSILa4sW1AS5oR4YPL3UBKrYArpLXAdcUv0qGnxELzpyh+3nwweM2FLqALwkGVtKY1piTHksNVr9lhpkhG3KJPcvdGkduC/48j1QqN/nbWEBTJER52Q5CsI9gCiD7zz6KVPlQdeoj1TqXqQNdJJELFX/QQmLhxlSWsUys1adKGulJ/boIdvJ/W517aH3RSOvRvrRIbqVxUb4prUizFFklLJZXkjyPoA4PkmYSfzHmuA1kkNWmD2Tiw6jDOjkjqZqdg6zvWPbwbJ/Hsdbs4zjTMtI07gcJhDDWGfHhLgAAAABJRU5ErkJggg==)';        \tbutton.addEventListener('click', function(){mJava.getFBData(url,mani,post_link,parent.innerHTML)});\n        \tvar spn=document.createElement('span');\n        \tspn.className='newspan';\n        \tspn.style.color = 'white';\n        \tspn.appendChild(button);\n        \titems[i].style.backgroundColor = '#FFFFFF';\n        \titems[i].appendChild(spn);  \n      \t}\n\t\t}\n\t}})()");
        }
    }

    private final void addButtonComplex(final String str, final String[] strArr) {
        Log.e(TAG, "addButtonComplex ");
        this.webView.post(new Runnable() { // from class: com.example.downloadvideos.fragments.mainWebview.facebook.FacebookViewInterface$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                m125addButtonComplex$lambda5(strArr, FacebookViewInterface.this, str);
            }
        });
    }

    public static final void m125addButtonComplex$lambda5(String[] parents, FacebookViewInterface this$0, String parentClass) {
        Intrinsics.checkNotNullParameter(parents, "$parents");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parentClass, "$parentClass");
        int length = parents.length;
        for (int i = 0; i < length; i++) {
            String str = parents[i];
            WebView webView = this$0.getWebView();
            Log.e(TAG, "m125addButtonComplex$lambda5 load ");
            webView.loadUrl("javascript:(function() { var parents=document.getElementsByClassName('m bg-s5');var parenttt=document.getElementsByClassName('" + parentClass + "');var parent=parents[" + i + "];var parentt=parenttt[" + i + "];var items=parent.getElementsByClassName('inline-video-container'); \n\tfor (var i = 0; i < 1; i++) { \n\t\tif(items[i].getElementsByClassName('newspan').length<1){\n        \tvar button=document.createElement('button1');\n        \tbutton.style.width = '28px';\n        \tbutton.style.height = '28px';\n        \tbutton.style.marginTop = '4px';\n        \tbutton.style.marginBottom = '6px';\n        \tbutton.style.marginRight = '10px';\n        \tbutton.style.outline = 'none';\n        \tbutton.style.border = 'none';\n        \tbutton.style.float = 'right';\n        \tbutton.style.backgroundSize = 'cover';\n        \tbutton.style.backgroundColor = '#00000000';\n        \tbutton.className='button_'+" + i + "+'_'+i;\n        \tbutton.style.backgroundImage= 'url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAABUCAMAAAArteDzAAAASFBMVEVHcEz/ixX/ihX/ixb/jBP/ixb/ixX/jA7/ihb/ixb/ixb/ihb/ixb/ixb/ixf/////xYr/lCj/o0b/6dH/+PH/tWv/2bP/8eOhVDNNAAAADnRSTlMAYHfmIYRCC9fxr5LC+WWN0pIAAAKcSURBVFjDvZnZloMgDIYrKJuKYl3e/00HW7tMhSQUZv7L2vMdIBsklwumWlRNazqltepM21SivmRKNMqepBqRQWy5jUi1X3Floy0o3shUJEOQuzRLwlbcksQrOlJZshQNK41NkiGcQa1sohTquELbZGnEvRr7lZqCx0k52PTjJBxsZzNkip4neK6VzVQgDESfC9WnY625zRb/oErU8OM2rw5zAZlmpHHw2hBq/8tYEg3O6w4dJuxYZZI33ZjDmOBXtS4FfVtqa0tBX0ut+3LQp7MSFkqG2vaA6pJQfQSoLQm1grz7BOh9/7wsVN1sb8tC7W5/VhrKyEUkAdpRd58C9ftHHGoZR/cBffwEOFWFptF5eYe6K5pYK9hO0521vKDunlhX2FItAeqpB/RgDlfY/Q0FOiwH9GDCKzWIR61DUPME+xQcpI/tpjB9oCIJOkRFmD77Ycn0TJ3RmnpBbxGfVJTpt4+H/m8qzvSGIlye36kEpncpSt5/USlM7/ykdPqgkpg+TGl33TuVxvQJRdDyqfP5aqMxfeojJumdS/2jzHyTRMpJ1FJuHIHtuiX6lcVL9DRDNclt8a+3K5oCkp4DU+IUvUxE3P9ZSILa4sW1AS5oR4YPL3UBKrYArpLXAdcUv0qGnxELzpyh+3nwweM2FLqALwkGVtKY1piTHksNVr9lhpkhG3KJPcvdGkduC/48j1QqN/nbWEBTJER52Q5CsI9gCiD7zz6KVPlQdeoj1TqXqQNdJJELFX/QQmLhxlSWsUys1adKGulJ/boIdvJ/W517aH3RSOvRvrRIbqVxUb4prUizFFklLJZXkjyPoA4PkmYSfzHmuA1kkNWmD2Tiw6jDOjkjqZqdg6zvWPbwbJ/Hsdbs4zjTMtI07gcJhDDWGfHhLgAAAABJRU5ErkJggg==)';        \tbutton.addEventListener('click', function(){facebookDataGet.onData(parentt.innerHTML)});\n        \tvar spn=document.createElement('span');\n        \tspn.className='newspan';\n        \tspn.appendChild(button);\n        \titems[i].appendChild(spn);\n        \tfacebookDataGet.onData(parentt.innerHTML);\n\t\t}\n\t}})()");
        }
    }

    private final void addButtonLink(final String str, final String[] strArr) {
        Log.e(TAG, "addButtonLink load ");
        this.webView.post(new Runnable() { // from class: com.example.downloadvideos.fragments.mainWebview.facebook.FacebookViewInterface$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                m126addButtonLink$lambda4(strArr, FacebookViewInterface.this, str);
            }
        });
    }

    public static final void m126addButtonLink$lambda4(String[] parents, FacebookViewInterface this$0, String parentClass) {
        Intrinsics.checkNotNullParameter(parents, "$parents");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parentClass, "$parentClass");
        Log.e(TAG, "m126addButtonLink$lambda4 ");
        int length = parents.length;
        for (int i = 0; i < length; i++) {
            String str = parents[i];
            WebView webView = this$0.getWebView();
            Log.e(TAG, "m126addButtonLink$lambda4 link " + str);
            webView.loadUrl("javascript:(function() { var parents=document.getElementsByClassName('" + parentClass + "');var parent=parents[" + i + "];var items=parent.getElementsByClassName('_97ki'); \n\tfor (var i = 0; i < items.length; i++) { \n\t\tif(items[i].getElementsByClassName('newspan').length<1){\n    \tvar k = parent.querySelectorAll(\"div[data-store]\");\n    \tvar h = k[i].getAttribute(\"data-store\");\n    \tvar g = JSON.parse(h);\nvar jp=k[i].getAttribute(\"data-sigil\");\n      \tif (g.type === \"video\") {\n        \tvar url = g.src;\n        \tvar mani = g.dashManifest;\n        \tvar post_link = g.videoURL;\n        \tvar button=document.createElement('button1');\n        \tbutton.style.width = '28px';\n        \tbutton.style.height = '28px';\n        \tbutton.style.marginTop = '4px';\n        \tbutton.style.marginBottom = '6px';\n        \tbutton.style.marginRight = '10px';\n        \tbutton.style.outline = 'none';\n        \tbutton.style.border = 'none';\n        \tbutton.style.float = 'right';\n        \tbutton.style.backgroundSize = 'cover';\n        \tbutton.style.backgroundColor = '#00000000';\n        \tbutton.className='button_'+" + i + "+'_'+i;\n        \tbutton.style.backgroundImage= 'url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAABUCAMAAAArteDzAAAASFBMVEVHcEz/ixX/ihX/ixb/jBP/ixb/ixX/jA7/ihb/ixb/ixb/ihb/ixb/ixb/ixf/////xYr/lCj/o0b/6dH/+PH/tWv/2bP/8eOhVDNNAAAADnRSTlMAYHfmIYRCC9fxr5LC+WWN0pIAAAKcSURBVFjDvZnZloMgDIYrKJuKYl3e/00HW7tMhSQUZv7L2vMdIBsklwumWlRNazqltepM21SivmRKNMqepBqRQWy5jUi1X3Floy0o3shUJEOQuzRLwlbcksQrOlJZshQNK41NkiGcQa1sohTquELbZGnEvRr7lZqCx0k52PTjJBxsZzNkip4neK6VzVQgDESfC9WnY625zRb/oErU8OM2rw5zAZlmpHHw2hBq/8tYEg3O6w4dJuxYZZI33ZjDmOBXtS4FfVtqa0tBX0ut+3LQp7MSFkqG2vaA6pJQfQSoLQm1grz7BOh9/7wsVN1sb8tC7W5/VhrKyEUkAdpRd58C9ftHHGoZR/cBffwEOFWFptF5eYe6K5pYK9hO0521vKDunlhX2FItAeqpB/RgDlfY/Q0FOiwH9GDCKzWIR61DUPME+xQcpI/tpjB9oCIJOkRFmD77Ycn0TJ3RmnpBbxGfVJTpt4+H/m8qzvSGIlye36kEpncpSt5/USlM7/ykdPqgkpg+TGl33TuVxvQJRdDyqfP5aqMxfeojJumdS/2jzHyTRMpJ1FJuHIHtuiX6lcVL9DRDNclt8a+3K5oCkp4DU+IUvUxE3P9ZSILa4sW1AS5oR4YPL3UBKrYArpLXAdcUv0qGnxELzpyh+3nwweM2FLqALwkGVtKY1piTHksNVr9lhpkhG3KJPcvdGkduC/48j1QqN/nbWEBTJER52Q5CsI9gCiD7zz6KVPlQdeoj1TqXqQNdJJELFX/QQmLhxlSWsUys1adKGulJ/boIdvJ/W517aH3RSOvRvrRIbqVxUb4prUizFFklLJZXkjyPoA4PkmYSfzHmuA1kkNWmD2Tiw6jDOjkjqZqdg6zvWPbwbJ/Hsdbs4zjTMtI07gcJhDDWGfHhLgAAAABJRU5ErkJggg==)';        \tbutton.addEventListener('click', function(){mJava.getFBData(url,mani,post_link,parent.innerHTML)});\n        \tvar spn=document.createElement('span');\n        \tspn.className='newspan';\n        \tspn.appendChild(button);\n        \titems[i].appendChild(spn);\n      \t}\n\t\t}\n\t}})()");
        }
    }

    private final void addButtonMultiple(final String str, final String[] strArr) {
        Log.e(TAG, "addButtonMultiple ");
        this.webView.post(new Runnable() { // from class: com.example.downloadvideos.fragments.mainWebview.facebook.FacebookViewInterface$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                m127addButtonMultiple$lambda2(strArr, FacebookViewInterface.this, str);
            }
        });
    }

    public static final void m127addButtonMultiple$lambda2(String[] parents, FacebookViewInterface this$0, String parentClass) {
        Intrinsics.checkNotNullParameter(parents, "$parents");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parentClass, "$parentClass");
        int length = parents.length;
        Log.e(TAG, "m127addButtonMultiple$lambda2 ");
        for (int i = 0; i < length; i++) {
            String str = parents[i];
            WebView webView = this$0.getWebView();
            webView.loadUrl("javascript:(function() { var parents=document.getElementsByClassName('" + parentClass + "');var parent=parents[" + i + "];var items=parent.getElementsByClassName('_52jh _7om2 _15kk _15ks _15km _4b47 _4b46'); \n\tfor (var i = 0; i < items.length; i++) { \n\t\tif(items[i].getElementsByClassName('newspan').length<1){\n    \tvar ij = parent.querySelectorAll(\"video\");\n    \tvar mainUrl = ij[i].getAttribute(\"src\");\n    \tvar button=document.createElement('button1');\n    \tbutton.style.width = '28px';\n    \tbutton.style.height = '28px';\n    \tbutton.style.marginTop = '6px';\n    \tbutton.style.marginRight = '7px';\n    \tbutton.style.outline = 'none';\n    \tbutton.style.border = 'none';\n    \tbutton.style.float = 'right';\n    \tbutton.style.backgroundSize = 'cover';\n    \tbutton.style.backgroundColor = '#00000000';\n    \tbutton.className='button_'+" + i + "+'_'+i;\n    \tbutton.style.backgroundImage= 'url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAABUCAMAAAArteDzAAAASFBMVEVHcEz/ixX/ihX/ixb/jBP/ixb/ixX/jA7/ihb/ixb/ixb/ihb/ixb/ixb/ixf/////xYr/lCj/o0b/6dH/+PH/tWv/2bP/8eOhVDNNAAAADnRSTlMAYHfmIYRCC9fxr5LC+WWN0pIAAAKcSURBVFjDvZnZloMgDIYrKJuKYl3e/00HW7tMhSQUZv7L2vMdIBsklwumWlRNazqltepM21SivmRKNMqepBqRQWy5jUi1X3Floy0o3shUJEOQuzRLwlbcksQrOlJZshQNK41NkiGcQa1sohTquELbZGnEvRr7lZqCx0k52PTjJBxsZzNkip4neK6VzVQgDESfC9WnY625zRb/oErU8OM2rw5zAZlmpHHw2hBq/8tYEg3O6w4dJuxYZZI33ZjDmOBXtS4FfVtqa0tBX0ut+3LQp7MSFkqG2vaA6pJQfQSoLQm1grz7BOh9/7wsVN1sb8tC7W5/VhrKyEUkAdpRd58C9ftHHGoZR/cBffwEOFWFptF5eYe6K5pYK9hO0521vKDunlhX2FItAeqpB/RgDlfY/Q0FOiwH9GDCKzWIR61DUPME+xQcpI/tpjB9oCIJOkRFmD77Ycn0TJ3RmnpBbxGfVJTpt4+H/m8qzvSGIlye36kEpncpSt5/USlM7/ykdPqgkpg+TGl33TuVxvQJRdDyqfP5aqMxfeojJumdS/2jzHyTRMpJ1FJuHIHtuiX6lcVL9DRDNclt8a+3K5oCkp4DU+IUvUxE3P9ZSILa4sW1AS5oR4YPL3UBKrYArpLXAdcUv0qGnxELzpyh+3nwweM2FLqALwkGVtKY1piTHksNVr9lhpkhG3KJPcvdGkduC/48j1QqN/nbWEBTJER52Q5CsI9gCiD7zz6KVPlQdeoj1TqXqQNdJJELFX/QQmLhxlSWsUys1adKGulJ/boIdvJ/W517aH3RSOvRvrRIbqVxUb4prUizFFklLJZXkjyPoA4PkmYSfzHmuA1kkNWmD2Tiw6jDOjkjqZqdg6zvWPbwbJ/Hsdbs4zjTMtI07gcJhDDWGfHhLgAAAABJRU5ErkJggg==)';    \tbutton.addEventListener('click', function(){ mJava.getFBMultiplePost(mainUrl)});\n    \tvar spn=document.createElement('span');\n    \tspn.className='newspan';\n    \tspn.prepend(button);\n    \titems[i].appendChild(spn);\n\t\t}\n\t}})()");
        }
    }

    private final void addButtonMultipleWithoutLogin(final String str, final String[] strArr) {
        Log.e(TAG, "addButtonMultipleWithoutLogin ");
        this.webView.post(new Runnable() { // from class: com.example.downloadvideos.fragments.mainWebview.facebook.FacebookViewInterface$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                m128addButtonMultipleWithoutLogin$lambda3(strArr, FacebookViewInterface.this, str);
            }
        });
    }

    public static final void m128addButtonMultipleWithoutLogin$lambda3(String[] parents, FacebookViewInterface this$0, String parentClass) {
        Log.e(TAG, "m128addButtonMultipleWithoutLogin$lambda3 ");
        Intrinsics.checkNotNullParameter(parents, "$parents");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parentClass, "$parentClass");
        int length = parents.length;
        for (int i = 0; i < length; i++) {
            String str = parents[i];
            WebView webView = this$0.getWebView();
            webView.loadUrl("javascript:(function() { var parents=document.getElementsByClassName('" + parentClass + "');var parent=parents[" + i + "];var items=parent.getElementsByClassName('_2og4 slimLike _15kj _34qc _4b45'); \n\tfor (var i = 0; i < items.length; i++) { \n\t\tif(items[i].getElementsByClassName('newspan').length<1){\n    \tvar ij = parent.querySelectorAll(\"video\");\n    \tvar mainUrl = ij[i].getAttribute(\"src\");\n    \tvar button=document.createElement('button1');\n    \tbutton.style.width = '28px';\n    \tbutton.style.height = '28px';\n    \tbutton.style.marginBottom = '10px';\n    \tbutton.style.marginRight = '10px';\n    \tbutton.style.outline = 'none';\n    \tbutton.style.border = 'none';\n    \tbutton.style.float = 'right';\n    \tbutton.style.backgroundSize = 'cover';\n    \tbutton.style.backgroundColor = '#00000000';\n    \tbutton.className='button_'+" + i + "+'_'+i;\n    \tbutton.style.backgroundImage= 'url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAABUCAMAAAArteDzAAAASFBMVEVHcEz/ixX/ihX/ixb/jBP/ixb/ixX/jA7/ihb/ixb/ixb/ihb/ixb/ixb/ixf/////xYr/lCj/o0b/6dH/+PH/tWv/2bP/8eOhVDNNAAAADnRSTlMAYHfmIYRCC9fxr5LC+WWN0pIAAAKcSURBVFjDvZnZloMgDIYrKJuKYl3e/00HW7tMhSQUZv7L2vMdIBsklwumWlRNazqltepM21SivmRKNMqepBqRQWy5jUi1X3Floy0o3shUJEOQuzRLwlbcksQrOlJZshQNK41NkiGcQa1sohTquELbZGnEvRr7lZqCx0k52PTjJBxsZzNkip4neK6VzVQgDESfC9WnY625zRb/oErU8OM2rw5zAZlmpHHw2hBq/8tYEg3O6w4dJuxYZZI33ZjDmOBXtS4FfVtqa0tBX0ut+3LQp7MSFkqG2vaA6pJQfQSoLQm1grz7BOh9/7wsVN1sb8tC7W5/VhrKyEUkAdpRd58C9ftHHGoZR/cBffwEOFWFptF5eYe6K5pYK9hO0521vKDunlhX2FItAeqpB/RgDlfY/Q0FOiwH9GDCKzWIR61DUPME+xQcpI/tpjB9oCIJOkRFmD77Ycn0TJ3RmnpBbxGfVJTpt4+H/m8qzvSGIlye36kEpncpSt5/USlM7/ykdPqgkpg+TGl33TuVxvQJRdDyqfP5aqMxfeojJumdS/2jzHyTRMpJ1FJuHIHtuiX6lcVL9DRDNclt8a+3K5oCkp4DU+IUvUxE3P9ZSILa4sW1AS5oR4YPL3UBKrYArpLXAdcUv0qGnxELzpyh+3nwweM2FLqALwkGVtKY1piTHksNVr9lhpkhG3KJPcvdGkduC/48j1QqN/nbWEBTJER52Q5CsI9gCiD7zz6KVPlQdeoj1TqXqQNdJJELFX/QQmLhxlSWsUys1adKGulJ/boIdvJ/W517aH3RSOvRvrRIbqVxUb4prUizFFklLJZXkjyPoA4PkmYSfzHmuA1kkNWmD2Tiw6jDOjkjqZqdg6zvWPbwbJ/Hsdbs4zjTMtI07gcJhDDWGfHhLgAAAABJRU5ErkJggg==)';    \tbutton.addEventListener('click', function(){ mJava.getFBMultiplePost(mainUrl)});\n    \tvar spn=document.createElement('span');\n    \tspn.className='newspan';\n    \tspn.style.marginBottom = '10px';\n    \tspn.prepend(button);\n    \titems[i].prepend(spn);\n\t\t}\n\t}})()");
        }
    }

    private final void addButtonWatch(final String str, final String[] strArr) {
        Log.e(TAG, "addButtonWatch ");
        this.webView.post(new Runnable() { // from class: com.example.downloadvideos.fragments.mainWebview.facebook.FacebookViewInterface$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                m129addButtonWatch$lambda1(strArr, FacebookViewInterface.this, str);
            }
        });
    }

    public static final void m129addButtonWatch$lambda1(String[] parents, FacebookViewInterface this$0, String parentClass) {
        Log.e(TAG, "m129addButtonWatch$lambda1 ");
        Intrinsics.checkNotNullParameter(parents, "$parents");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parentClass, "$parentClass");
        int length = parents.length;
        for (int i = 0; i < length; i++) {
            String str = parents[i];
            WebView webView = this$0.getWebView();
            webView.loadUrl("javascript:(function() { var parents=document.getElementsByClassName('" + parentClass + "');var parent=parents[" + i + "];var items=parent.getElementsByClassName('_52jh _7om2 _15kk _15ks _15km _4b47 _4b46'); \n\tfor (var i = 0; i < items.length; i++) { \n\t\tif(items[i].getElementsByClassName('newspan').length<1){\n    \tvar k = parent.querySelectorAll(\"div[data-store]\");\n    \tvar h = k[i].getAttribute(\"data-store\");\n    \tvar g = JSON.parse(h);\nvar jp=k[i].getAttribute(\"data-sigil\");\n      \tif (g.type === \"video\") {\n        \tvar url = g.src;\n        \tvar mani = g.dashManifest;\n        \tvar post_link = g.videoURL;\n        \tvar button=document.createElement('button1');\n        \tbutton.style.width = '28px';\n        \tbutton.style.height = '28px';\n        \tbutton.style.marginTop = '4px';\n        \tbutton.style.marginBottom = '6px';\n        \tbutton.style.marginRight = '1px';\n        \tbutton.style.marginLeft = '3px';\n        \tbutton.style.outline = 'none';\n        \tbutton.style.border = 'none';\n        \tbutton.style.float = 'right';\n        \tbutton.style.backgroundSize = 'cover';\n        \tbutton.style.backgroundColor = '#00000000';\n        \tbutton.className='button_'+" + i + "+'_'+i;\n        \tbutton.style.backgroundImage= 'url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAABUCAMAAAArteDzAAAASFBMVEVHcEz/ixX/ihX/ixb/jBP/ixb/ixX/jA7/ihb/ixb/ixb/ihb/ixb/ixb/ixf/////xYr/lCj/o0b/6dH/+PH/tWv/2bP/8eOhVDNNAAAADnRSTlMAYHfmIYRCC9fxr5LC+WWN0pIAAAKcSURBVFjDvZnZloMgDIYrKJuKYl3e/00HW7tMhSQUZv7L2vMdIBsklwumWlRNazqltepM21SivmRKNMqepBqRQWy5jUi1X3Floy0o3shUJEOQuzRLwlbcksQrOlJZshQNK41NkiGcQa1sohTquELbZGnEvRr7lZqCx0k52PTjJBxsZzNkip4neK6VzVQgDESfC9WnY625zRb/oErU8OM2rw5zAZlmpHHw2hBq/8tYEg3O6w4dJuxYZZI33ZjDmOBXtS4FfVtqa0tBX0ut+3LQp7MSFkqG2vaA6pJQfQSoLQm1grz7BOh9/7wsVN1sb8tC7W5/VhrKyEUkAdpRd58C9ftHHGoZR/cBffwEOFWFptF5eYe6K5pYK9hO0521vKDunlhX2FItAeqpB/RgDlfY/Q0FOiwH9GDCKzWIR61DUPME+xQcpI/tpjB9oCIJOkRFmD77Ycn0TJ3RmnpBbxGfVJTpt4+H/m8qzvSGIlye36kEpncpSt5/USlM7/ykdPqgkpg+TGl33TuVxvQJRdDyqfP5aqMxfeojJumdS/2jzHyTRMpJ1FJuHIHtuiX6lcVL9DRDNclt8a+3K5oCkp4DU+IUvUxE3P9ZSILa4sW1AS5oR4YPL3UBKrYArpLXAdcUv0qGnxELzpyh+3nwweM2FLqALwkGVtKY1piTHksNVr9lhpkhG3KJPcvdGkduC/48j1QqN/nbWEBTJER52Q5CsI9gCiD7zz6KVPlQdeoj1TqXqQNdJJELFX/QQmLhxlSWsUys1adKGulJ/boIdvJ/W517aH3RSOvRvrRIbqVxUb4prUizFFklLJZXkjyPoA4PkmYSfzHmuA1kkNWmD2Tiw6jDOjkjqZqdg6zvWPbwbJ/Hsdbs4zjTMtI07gcJhDDWGfHhLgAAAABJRU5ErkJggg==)';        \tbutton.addEventListener('click', function(){mJava.getFBData(url,mani,post_link,parent.innerHTML)});\n        \tvar spn=document.createElement('span');\n        \tspn.className='newspan';\n        \tspn.appendChild(button);\n        \titems[i].appendChild(spn);\n      \t}\n\t\t}\n\t}})()");
        }
    }

    @JavascriptInterface
    public final void onAccountPostLoading(String[] parents) {
        Log.e(TAG, "onAccountPostLoading ");
        Intrinsics.checkNotNullParameter(parents, "parents");
        addButton(FACEBOOK_ACCOUNT_POSTS, parents);
    }

    @JavascriptInterface
    public final void onData(String data) {
        Log.e(TAG, "onData ");
        Intrinsics.checkNotNullParameter(data, "data");
//        try {
//            this.generalWebView.fbComplex(data);
//        } catch (Exception unused) {
//        }
    }

    @JavascriptInterface
    public final void onLinkPostLoading(String[] parents) {
        Log.e(TAG, "onLinkPostLoading ");
        Intrinsics.checkNotNullParameter(parents, "parents");
        if (linkSize != parents.length) {
            linkSize = parents.length;
            addButtonLink(FACEBOOK_LINK_POST, parents);
        }
    }

    @JavascriptInterface
    public final void onLoading(String[] parents) {
        Log.e(TAG, "onLoading ");
        Intrinsics.checkNotNullParameter(parents, "parents");
        if (feedSize != parents.length) {
            feedSize = parents.length;
            addButton(FACEBOOK_FEED, parents);
        }
    }

    @JavascriptInterface
    public final void onMultiplePostLoading(String[] parents) {
        Log.e(TAG, "onMultiplePostLoading ");
        Intrinsics.checkNotNullParameter(parents, "parents");
        String str = FACEBOOK_MULTIPLE_POSTS;
        addButtonMultiple(str, parents);
        addButtonMultipleWithoutLogin(str, parents);
    }

    @JavascriptInterface
    public final void onSearchPostLoading(String[] parents) {
        Log.e(TAG, "onSearchPostLoading ");
        Intrinsics.checkNotNullParameter(parents, "parents");
        addButton(FACEBOOK_SEARCH_POST, parents);
    }

    @JavascriptInterface
    public final void onSinglePostLoading(String[] parents) {
        Log.e(TAG, "onSinglePostLoading parentsSize==>> " + parents.length);
//        for (String parent : parents) {
//            Log.e(TAG, "onSinglePostLoading parent==>> " + parent);
//        }
        Intrinsics.checkNotNullParameter(parents, "parents");
        if (startsWith$default(parents[0], "<a", false, 2)) {
            complexSize = parents.length;
            StringBuilder m = m("onSinglePostLoading: ");
            m.append(parents.length);
            m.append("   html ");
            m.append(parents[0]);
//          /  Log.e("facebook", m.toString());
            addButtonComplex(FACEBOOK_COMPLEX_POST, parents);
        }
    }

    @JavascriptInterface
    public final void onWatchPostLoading(String[] parents) {
        Log.e(TAG, "onWatchPostLoading ");
        Intrinsics.checkNotNullParameter(parents, "parents");
        if (watchSize != parents.length) {
            watchSize = parents.length;
            addButtonWatch(FACEBOOK_WATCH_POSTS, parents);
        }
    }

    public final WebView getWebView() {
        return this.webView;
    }

    public static boolean startsWith$default(String str, String str2, boolean z, int i) {
        if ((i & 2) != 0) {
            z = false;
        }
        boolean z2 = z;
        Intrinsics.checkNotNullParameter(str, "<this>");
        if (!z2) {
            return str.startsWith(str2);
        }
        return regionMatches(str, 0, str2, 0, str2.length(), z2);
    }

    public static StringBuilder m(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        return sb;
    }

    public static final boolean regionMatches(String str, int i, String other, int i2, int i3, boolean z) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        Intrinsics.checkNotNullParameter(other, "other");
        if (!z) {
            return str.regionMatches(i, other, i2, i3);
        }
        return str.regionMatches(z, i, other, i2, i3);
    }
}
