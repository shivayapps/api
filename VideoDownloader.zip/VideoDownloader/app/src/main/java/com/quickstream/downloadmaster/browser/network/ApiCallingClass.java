package com.quickstream.downloadmaster.browser.network;

import android.app.Activity;
import android.util.Log;

import com.quickstream.downloadmaster.browser.utils.AppUrl;
import com.google.common.net.HttpHeaders;
import com.google.gson.JsonObject;
import com.quickstream.downloadmaster.browser.ui.interfaces.APIResponse;
import com.quickstream.downloadmaster.browser.utils.AppUrl;
import com.quickstream.downloadmaster.browser.utils.Preferences;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ApiCallingClass {
    public void callResult(Activity activity, String URL, APIResponse apiResponse) {
        AppUrl appEncrypt = new AppUrl();
        String str3 = "";
        if (URL.contains("/tv/")) {
            str3 = appEncrypt.callResultUserAgent1();
        } else if (!URL.contains("reel")) {
            str3 = appEncrypt.callResultUserAgent2();
        }
        Preferences preferences = new Preferences(activity);
        String Cookie =
                appEncrypt.cookieStart() + preferences.getInstagramUserId() + appEncrypt.cookieEnd() + preferences.getInstagramSessionID();

        Call<JsonObject> call = RestClientSimple.getInstance(activity).getService().callResult2(URL, Cookie, str3);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful() && response.code() == 200) {
                    apiResponse.onResponse(response.body());

                } else if (response.code() == 401) {
                    try {
                        try {
                            ResponseBody errorBody = response.errorBody();
                            String errorString = errorBody.string();
                            JSONObject jsonObject = new JSONObject(errorString);
                            String message = jsonObject.getString("message");
                            boolean require_login = jsonObject.getBoolean("require_login");
                            if (message == null)
                                message = "";
                            if (require_login) {
                                apiResponse.onLoginRequired();
                            } else apiResponse.onFailure(message);

                        } catch (Exception e) {
                            e.printStackTrace();
                            apiResponse.onFailure("");
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        apiResponse.onFailure("");
                    }
                } else {
                    apiResponse.onFailure("");
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                apiResponse.onFailure("");
            }
        });
    }
    public void callDpDetails(Activity activity, String url, APIResponse apiResponse) {
        AppUrl appEncrypt = new AppUrl();
        // instagramCopyENDURL
        final String URL = url + appEncrypt.instagramCopyENDURL();
        Preferences preferences = new Preferences(activity);
        String cookie =
                appEncrypt.cookieStart() + preferences.getInstagramUserId() + appEncrypt.cookieEnd() + preferences.getInstagramSessionID();

        String str3 = "";
        if (URL.contains("/tv/")) {
            // callResultUserAgent1
            str3 = appEncrypt.callResultUserAgent1();
        } else if (!URL.contains("reel")) {
            // callResultUserAgent2
            str3 = appEncrypt.callResultUserAgent2();
        }

        Call<JsonObject> call = RestClientSimple.getInstance(activity).getService().callDpSearch(URL, cookie, str3);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful() && response.code() == 200) {

                    apiResponse.onResponse(response.body());

                } else if (response.code() == 401) {
                    try {
                        try {
                            ResponseBody errorBody = response.errorBody();
                            String errorString = errorBody.string();
                            JSONObject jsonObject = new JSONObject(errorString);
                            String message = jsonObject.getString("message");
                            boolean require_login = jsonObject.getBoolean("require_login");
                            if (message == null)
                                message = "";
                            if (require_login) {
                                apiResponse.onLoginRequired();
                            } else apiResponse.onFailure(message);

                        } catch (Exception e) {
                            e.printStackTrace();
                            apiResponse.onFailure("");
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        apiResponse.onFailure("");
                    }
                } else {
                    apiResponse.onFailure("");
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                apiResponse.onFailure("");
            }
        });
    }

    public void callDpSearch(Activity activity, String userName, APIResponse apiResponse) {
        AppUrl appEncrypt = new AppUrl();
        // DpSearchBaseURL DpSearchENDURL
        final String URL = appEncrypt.DpSearchBaseURL() + userName + appEncrypt.DpSearchENDURL();
        // callResultUserAgent3
        String str3 = appEncrypt.callResultUserAgent3();
        Preferences preferences = new Preferences(activity);
        String cookie =
                appEncrypt.cookieStart() + preferences.getInstagramUserId() + appEncrypt.cookieEnd() + preferences.getInstagramSessionID();

        Call<JsonObject> call = RestClientSimple.getInstance(activity).getService().callDpSearch(URL, cookie, str3);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful() && response.code() == 200) {

                    apiResponse.onResponse(response.body());

                } else if (response.code() == 401) {
                    try {
                        try {
                            ResponseBody errorBody = response.errorBody();
                            String errorString = errorBody.string();
                            JSONObject jsonObject = new JSONObject(errorString);
                            String message = jsonObject.getString("message");
                            boolean require_login = jsonObject.getBoolean("require_login");
                            if (message == null)
                                message = "";
                            if (require_login) {
                                apiResponse.onLoginRequired();
                            } else apiResponse.onFailure(message);

                        } catch (Exception e) {
                            e.printStackTrace();
                            apiResponse.onFailure("");
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        apiResponse.onFailure("");
                    }
                } else {
                    apiResponse.onFailure("");
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                apiResponse.onFailure("");
            }
        });
    }

    public void callHDDpSearch(Activity activity, String userName, APIResponse apiResponse) {
        AppUrl appEncrypt = new AppUrl();
        String URL = appEncrypt.HDDpSearchBaseURL() + userName + appEncrypt.HDDpSearchEndURL();
        String str3 = appEncrypt.callResultUserAgent3();
        Preferences preferences = new Preferences(activity);
        String cookie =
                appEncrypt.cookieStart() + preferences.getInstagramUserId() + appEncrypt.cookieEnd() + preferences.getInstagramSessionID();

        Call<JsonObject> call = RestClientSimple.getInstance(activity).getService().callDpSearch(URL, cookie, str3);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful() && response.code() == 200) {
                    apiResponse.onResponse(response.body());

                } else {
                    apiResponse.onFailure("");
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                apiResponse.onFailure("");
            }
        });
    }

    public void getStoriesFullDetail(Activity activity, String userId, APIResponse apiResponse) {
        AppUrl appEncrypt = new AppUrl();
        // StoriesFullDetailURL
        String url = appEncrypt.StoriesFullDetailURL();

        Preferences preferences = new Preferences(activity);
        String cookie = appEncrypt.cookieStart() + preferences.getInstagramUserId() +
                appEncrypt.cookieEnd() + preferences.getInstagramSessionID();

//        ArrayList<String> browserData = (ArrayList) Stream.of((Object[]) new String[]{Utils.INSTANCE.storiesFullDetailHeader0(appEncrypt.storiesFullDetailHeader0()),
        ArrayList<String> browserData = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            browserData = (ArrayList) Stream.of((Object[]) new String[]{appEncrypt.storiesFullDetailHeader0(),
                    appEncrypt.storiesFullDetailHeader1(), appEncrypt.storiesFullDetailHeader2(),
                    appEncrypt.storiesFullDetailHeader3(), appEncrypt.storiesFullDetailHeader4(),
                    appEncrypt.storiesFullDetailHeader5(), appEncrypt.storiesFullDetailHeader6(),
                    appEncrypt.storiesFullDetailHeader7(), appEncrypt.storiesFullDetailHeader8(),
                    appEncrypt.storiesFullDetailHeader6(), appEncrypt.storiesFullDetailHeader10(), appEncrypt.storiesFullDetailHeader11(),
                    HttpHeaders.ReferrerPolicyValues.SAME_ORIGIN, appEncrypt.storiesFullDetailHeader7(),
                    appEncrypt.storiesFullDetailHeader12()}).collect(Collectors.toList());
        } else {
            browserData = new ArrayList<>();
            browserData.add(appEncrypt.storiesFullDetailHeader0());
            browserData.add(appEncrypt.storiesFullDetailHeader1());
            browserData.add(appEncrypt.storiesFullDetailHeader2());
            browserData.add(appEncrypt.storiesFullDetailHeader3());
            browserData.add(appEncrypt.storiesFullDetailHeader4());
            browserData.add(appEncrypt.storiesFullDetailHeader5());
            browserData.add(appEncrypt.storiesFullDetailHeader6());
            browserData.add(appEncrypt.storiesFullDetailHeader7());
            browserData.add(appEncrypt.storiesFullDetailHeader8());
            browserData.add(appEncrypt.storiesFullDetailHeader6());
            browserData.add(appEncrypt.storiesFullDetailHeader10());
            browserData.add(appEncrypt.storiesFullDetailHeader11());
            browserData.add(HttpHeaders.ReferrerPolicyValues.SAME_ORIGIN);
            browserData.add(appEncrypt.storiesFullDetailHeader7());
            browserData.add(appEncrypt.storiesFullDetailHeader12());
        }


        Call<JsonObject> call = RestClientSimple.getInstance(activity).getService().getStoriesFullDetail2(url, userId, cookie,
                browserData.get(0), browserData.get(1), browserData.get(2), browserData.get(3), browserData.get(4), browserData.get(5), browserData.get(6),
                browserData.get(7), browserData.get(8), browserData.get(9), browserData.get(10), browserData.get(11), browserData.get(12), browserData.get(13),
                browserData.get(14));
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful() && response.code() == 200) {

                    apiResponse.onResponse(response.body());

                } else if (response.code() == 401) {
                    try {
                        try {
                            ResponseBody errorBody = response.errorBody();
                            String errorString = errorBody.string();
                            Log.e("", "errorString===>>>> " + errorString);
                            JSONObject jsonObject = new JSONObject(errorString);
                            String message = jsonObject.getString("message");
                            boolean require_login = jsonObject.getBoolean("require_login");
                            if (message == null)
                                message = "";
                            if (require_login) {
                                apiResponse.onLoginRequired();
                            } else apiResponse.onFailure(message);

                        } catch (Exception e) {
                            e.printStackTrace();
                            apiResponse.onFailure("");
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        apiResponse.onFailure("");
                    }

                } else {
                    apiResponse.onFailure("");
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e("", "callDpDownloader onFailure==>> " + t.getMessage());
                apiResponse.onFailure("");
            }
        });
    }

    public void getStoriesApi(Activity activity, APIResponse apiResponse) {
        AppUrl appEncrypt = new AppUrl();
        Preferences preferences = new Preferences(activity);
        String cookie = appEncrypt.cookieStart() + preferences.getInstagramUserId() +
                appEncrypt.cookieEnd() + preferences.getInstagramSessionID();


        String str3 = appEncrypt.callResultUserAgent4();
        String URL = appEncrypt.storiesApiURL();
        Call<JsonObject> call = RestClientSimple.getInstance(activity).getService().getStoriesApi2(URL, cookie, str3);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful() && response.code() == 200) {

                    apiResponse.onResponse(response.body());

                } else if (response.code() == 401) {
                    try {
                        ResponseBody errorBody = response.errorBody();
                        String errorString = errorBody.string();
                        JSONObject jsonObject = new JSONObject(errorString);
                        String message = jsonObject.getString("message");
                        boolean require_login = jsonObject.getBoolean("require_login");
                        if (message == null)
                            message = "";
                        if (require_login) {
                            apiResponse.onLoginRequired();
                        } else apiResponse.onFailure(message);

                    } catch (Exception e) {
                        e.printStackTrace();
                        apiResponse.onFailure("");
                    }
                } else {
                    apiResponse.onFailure("");
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                apiResponse.onFailure("");
            }
        });
    }

}
