package com.quickstream.downloadmaster.browser.browser.event.global_download_button;

/* loaded from: classes3.dex */
public class DownloadGlobalButtonClickedEvent {
}
