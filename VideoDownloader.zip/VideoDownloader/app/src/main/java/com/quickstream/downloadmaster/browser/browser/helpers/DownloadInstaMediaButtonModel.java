package com.quickstream.downloadmaster.browser.browser.helpers;

public class DownloadInstaMediaButtonModel {
    private int button_id = 0;
    private String mediaTitle = "";
    private String fileExtention = "";
    private String domainUrl = "";
    private String targetURL = "";
    private InstaMediaType mediaType = InstaMediaType.IMAGE;
    private String videoMimeType = "";
    private String videoPosterUrl = "";

    Long downloadSizeSize = 0L;

    public Long getDownloadSizeSize() {
        return downloadSizeSize;
    }

    public void setDownloadSizeSize(Long downloadSizeSize) {
        this.downloadSizeSize = downloadSizeSize;
    }


    public enum InstaMediaType {
        IMAGE,
        VIDEO,
        REEL_IMAGE,
        REEL_VIDEO
    }

    public String getVideoMimeType() {
        return this.videoMimeType;
    }

    public void setVideoMimeType(String str) {
        this.videoMimeType = str;
    }

    public String getVideoPosterUrl() {
        return this.videoPosterUrl;
    }

    public void setVideoPosterUrl(String str) {
        this.videoPosterUrl = str;
    }

    public String getFileExtention() {
        return this.fileExtention;
    }

    public void setFileExtention(String str) {
        this.fileExtention = str;
    }

    public String toString() {
        return "dwnld-button-" + Integer.toString(this.button_id);
    }

    public int getButton_id() {
        return this.button_id;
    }

    public void setButton_id(int i) {
        this.button_id = i;
    }

    public String getMediaTitle() {
        return this.mediaTitle;
    }

    public void setMediaTitle(String str) {
        this.mediaTitle = str;
    }

    public String getDomainUrl() {
        return this.domainUrl;
    }

    public void setDomainUrl(String str) {
        this.domainUrl = str;
    }

    public String getTargetURL() {
        return this.targetURL;
    }

    public void setTargetURL(String str) {
        this.targetURL = str;
    }

    public InstaMediaType getMediaType() {
        return this.mediaType;
    }

    public void setMediaType(InstaMediaType instaMediaType) {
        this.mediaType = instaMediaType;
    }
}
