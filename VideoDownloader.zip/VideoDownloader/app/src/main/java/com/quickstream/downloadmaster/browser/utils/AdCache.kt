package com.quickstream.downloadmaster.browser.utils

import com.google.android.gms.ads.AdView

class AdCache {
    companion object {
        var bannerHome:AdView?=null
        var bannerHasTag:AdView?=null
        var bannerAllDownload:AdView?=null
        var bannerTagFull:AdView?=null
        var bannerWaStatus:AdView?=null
        var bannerDpDownload:AdView?=null
        var bannerInstaStory:AdView?=null
        var bannerInsta:AdView?=null
        var bannerDpCreation:AdView?=null
        var bannerDpGenerator:AdView?=null
        var bannerSaveImage:AdView?=null
        var bannerInstaFrag:AdView?=null
    }
}

