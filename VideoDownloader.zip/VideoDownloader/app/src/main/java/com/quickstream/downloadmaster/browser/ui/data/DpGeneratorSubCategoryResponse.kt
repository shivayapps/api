package com.quickstream.downloadmaster.browser.ui.data

class DpGeneratorSubCategoryResponse : ArrayList<DpGeneratorSubCategoryItem>()