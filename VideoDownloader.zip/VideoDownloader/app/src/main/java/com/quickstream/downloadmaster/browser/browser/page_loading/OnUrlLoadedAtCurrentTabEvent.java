package com.quickstream.downloadmaster.browser.browser.page_loading;

import android.graphics.Bitmap;

public class OnUrlLoadedAtCurrentTabEvent {
    private Bitmap favicon;
    private String pageTitle;

    public OnUrlLoadedAtCurrentTabEvent(String str, Bitmap bitmap) {
        this.pageTitle = str;
        this.favicon = bitmap;
    }

    public String getPageTitle() {
        return this.pageTitle;
    }

    public void setPageTitle(String str) {
        this.pageTitle = str;
    }

    public Bitmap getFavicon() {
        return this.favicon;
    }

    public void setFavicon(Bitmap bitmap) {
        this.favicon = bitmap;
    }
}
