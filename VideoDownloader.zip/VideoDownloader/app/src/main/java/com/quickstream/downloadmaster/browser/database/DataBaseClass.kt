package com.quickstream.downloadmaster.browser.database

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.quickstream.downloadmaster.browser.ui.data.Secure_MediaDataModal

class DataBaseClass(var context: Context?, var activity: Activity) : SQLiteOpenHelper(
    context, "video_downloader_browser.db", null, 1
) {
    private val CREATE_TABLE_HISTORY =
        "create table " + TABLE_HISTORY + "(" + COL_ID + " integer primary key autoincrement," +
                COL_NAME + " text," +
                COL_URL_TITLE + " text," +
                COL_DATE_TIME + " text);"
    private val CREATE_TABLE_BOOKMARK =
        "create table " + TABLE_BOOKMARK + "(" + COL_ID + " integer primary key autoincrement," +
                COL_NAME + " text," +
                COL_URL_TITLE + " text," +
                COL_DATE_TIME + " text);"


    override fun onCreate(sqLiteDatabase: SQLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_HISTORY)
        sqLiteDatabase.execSQL(CREATE_TABLE_BOOKMARK)
    }

    override fun onUpgrade(sqLiteDatabase: SQLiteDatabase, i: Int, i1: Int) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS $TABLE_HISTORY")
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS $TABLE_BOOKMARK")
        onCreate(sqLiteDatabase)
    }


    fun insertHistory(url: String?, date: String?, url_title: String?) {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COL_NAME, replaceCurrantString(url.toString()))
        values.put(COL_URL_TITLE, replaceCurrantString(url_title.toString()))
        values.put(COL_DATE_TIME, replaceCurrantString(date.toString()))
        db.insert(TABLE_HISTORY, null, values)
    }

    fun insertBookmark(url: String?, date: String?, url_title: String?) {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COL_NAME, replaceCurrantString(url.toString()))
        values.put(COL_DATE_TIME, replaceCurrantString(date.toString()))
        values.put(COL_URL_TITLE, replaceCurrantString(url_title.toString()))
        db.insert(TABLE_BOOKMARK, null, values)
    }


    fun deleteBookMark(url: String) {
        val database = writableDatabase
        val deleteSql = "Delete From $TABLE_BOOKMARK where $COL_NAME = '$url'"
        database.execSQL(deleteSql)
    }

    fun deleteHistory(id: Int) {
        val database = writableDatabase
        val deleteSql = "Delete From $TABLE_HISTORY where $COL_ID = $id"
        database.execSQL(deleteSql)
    }

    fun allDeletesHistory() {
        val database = writableDatabase
        database.execSQL("delete from $TABLE_HISTORY")
    }

    fun allDeletesBookMark() {
        val database = writableDatabase
        database.execSQL("delete from $TABLE_BOOKMARK")
    }

    fun replaceUpdateString(updateString: String): String {
        return if (updateString.contains("(~)")) {
            updateString.replace("(~)", "'")
        } else {
            updateString
        }
    }

    fun replaceCurrantString(currantString: String): String {
        return if (currantString.contains("'")) {
            currantString.replace("'", "(~)")
        } else {
            currantString
        }
    }

    val historyList: ArrayList<Secure_MediaDataModal>
        get() {
            val items = ArrayList<Secure_MediaDataModal>()
            val db = readableDatabase
            val query = "select * from $TABLE_HISTORY"
            val cursor = db.rawQuery(query, null)
            if (cursor != null && cursor.count > 0) {
                cursor.moveToFirst()
                do {
                    val item = Secure_MediaDataModal()
                    item.id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID))
                    item.name = replaceUpdateString(
                        cursor.getString(
                            cursor.getColumnIndexOrThrow(COL_NAME)
                        )
                    )
                    item.number = replaceUpdateString(
                        cursor.getString(
                            cursor.getColumnIndexOrThrow(COL_DATE_TIME)
                        )
                    )
                    item.path = replaceUpdateString(
                        cursor.getString(
                            cursor.getColumnIndexOrThrow(COL_URL_TITLE)
                        )
                    )
                    items.add(item)
                } while (cursor.moveToNext())
                cursor.close()
            }
            return items
        }


    val bookmarkList: ArrayList<Secure_MediaDataModal>
        get() {
            val items = ArrayList<Secure_MediaDataModal>()
            val db = readableDatabase
            val query = "select * from $TABLE_BOOKMARK"
            val cursor = db.rawQuery(query, null)
            if (cursor != null && cursor.count > 0) {
                cursor.moveToFirst()
                do {
                    val item = Secure_MediaDataModal()
                    item.id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID))
                    item.name = replaceUpdateString(
                        cursor.getString(
                            cursor.getColumnIndexOrThrow(COL_NAME)
                        )
                    )
                    item.path = replaceUpdateString(
                        cursor.getString(
                            cursor.getColumnIndexOrThrow(COL_URL_TITLE)
                        )
                    )
                    items.add(item)
                } while (cursor.moveToNext())
                cursor.close()
            }
            return items
        }


    val historyList1: ArrayList<String>
        get() {
            val items = ArrayList<String>()
            val db = readableDatabase
            val query = "select * from $TABLE_HISTORY"
            val cursor = db.rawQuery(query, null)
            if (cursor != null && cursor.count > 0) {
                cursor.moveToFirst()
                do {
                    val item = Secure_MediaDataModal()
                    item.id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID))
                    item.name = replaceUpdateString(
                        cursor.getString(
                            cursor.getColumnIndexOrThrow(COL_NAME)
                        )
                    )
                    item.number = replaceUpdateString(
                        cursor.getString(
                            cursor.getColumnIndexOrThrow(COL_DATE_TIME)
                        )
                    )
                    item.path = replaceUpdateString(
                        cursor.getString(
                            cursor.getColumnIndexOrThrow(COL_URL_TITLE)
                        )
                    )
                    items.add(item.name!!)
                } while (cursor.moveToNext())
                cursor.close()
            }
            return items
        }

    fun getUrl(url: String): Boolean {
        val db = readableDatabase
        val query =
            "select * from $TABLE_BOOKMARK where $COL_NAME = '" + replaceCurrantString(
                url
            ) + "'"
        val cursor = db.rawQuery(query, null)
        val b = cursor != null && cursor.count > 0
        cursor.close()
        return b
    }


    companion object {
        private const val COL_ID = "id"
        private const val COL_NAME = "name"
        private const val COL_URL_TITLE = "url_title"
        private const val COL_DATE_TIME = "col_date_time"
        private const val TABLE_BOOKMARK = "bookmark_table"
        private const val TABLE_HISTORY = "history_table"
    }
}