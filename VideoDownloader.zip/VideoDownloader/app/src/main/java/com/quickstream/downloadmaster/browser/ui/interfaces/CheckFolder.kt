package com.quickstream.downloadmaster.browser.ui.interfaces

interface CheckFolder {
    fun dataEmpty()
}