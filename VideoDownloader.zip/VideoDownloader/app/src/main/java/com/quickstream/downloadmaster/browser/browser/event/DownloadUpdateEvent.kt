package com.quickstream.downloadmaster.browser.browser.event

data class DownloadUpdateEvent(var deletePath: String)
