package com.quickstream.downloadmaster.browser.ui.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.SplashActivity
import com.quickstream.downloadmaster.browser.databinding.ActivityWebBrowserBinding
import com.quickstream.downloadmaster.browser.databinding.DialogExitBinding
import com.quickstream.downloadmaster.browser.ui.adapter.BrowserDataAdapter
import com.quickstream.downloadmaster.browser.ui.data.WebBrowserData
import com.quickstream.downloadmaster.browser.ui.fragment.WebBrowserFragment
import com.quickstream.downloadmaster.browser.utils.Constant
import com.quickstream.downloadmaster.browser.utils.MyApplication

class WebBrowserActivity : BaseActivity() {
    lateinit var binding: ActivityWebBrowserBinding
    var browserList: ArrayList<WebBrowserData> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWebBrowserBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inits()
        intiListener()
    }

    private fun intiListener() {
//        binding.loutToolbar.icBack.setOnClickListener {
//            onBackPressed()
//        }
    }

    override fun onResume() {
        super.onResume()
        Handler(Looper.myLooper()!!).postDelayed({
//            loadNativeDownloadBrowser()
        }, 1000)
    }

    private fun inits() {
        val action = intent.action
        var isOpenNormal = false
        if (intent.data != null && intent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY == 0) {
            Log.e("SPLASHTAG", "WEB LAUNCHED_FROM_HISTORY")
            isOpenNormal = false
        } else {
            isOpenNormal = true
            Log.e("SPLASHTAG", "WEB LAUNCHED NORMAL")
        }
        var url: String = ""
        if (action == Intent.ACTION_VIEW) {
            if (isOpenNormal) {
                startActivity(
                    Intent(
                        this,
                        SplashActivity::class.java
                    ).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                )
                finishAffinity()
//                AdconfigApplication.adConfigFinishAffinity()
            } else {
                MyApplication.disabledOpenAds()
                url = intent.data.toString()
                intent.replaceExtras(Bundle())
                intent.action = ""
                intent.data = null
                intent.flags = 0
            }
        }

//        binding.loutToolbar.txtTitle.text = getString(R.string.web_browser)
        getBrowserList()
        setDataInAdapter()
//        val bundle2 = Bundle()
//        bundle2.putString("WebBrowser_screen", "WebBrowser_screen_open")
//        firebaseAnalytics.logEvent("WebBrowser_screen_open", bundle2)

        loadFragment(WebBrowserFragment(url))
    }

    private fun loadFragment(fragment: Fragment) {
        val fm = this.supportFragmentManager
        val fragmentTransaction = fm.beginTransaction()
        fragmentTransaction.replace(R.id.browser_frame, fragment)
        fragmentTransaction.commit()
    }

    private fun setDataInAdapter() {
        binding.rvBrowserList.adapter = BrowserDataAdapter(browserList, this, clickListener = {

        })
    }

    override fun onBackPressed() {
        exitDialog()
    }

    private fun exitDialog() {
        val builder = AlertDialog.Builder(this, R.style.CustomAlertDialog).create()
        val deleteDialogLayoutBinding: DialogExitBinding =
            DialogExitBinding.inflate(LayoutInflater.from(this))
        builder.setView(deleteDialogLayoutBinding.root)
        deleteDialogLayoutBinding.txtTitle.text = "Exit"
        deleteDialogLayoutBinding.txtMsg.text = "Are you sure you want to exit the web browser?"
        deleteDialogLayoutBinding.tvNo.setOnClickListener {
            builder.dismiss()
        }
        deleteDialogLayoutBinding.tvYes.setOnClickListener {
            builder.dismiss()
            if (!MyApplication.isOpenHomeScreen)
                startActivity(
                    Intent(
                        this,
                        HomeActivity::class.java
                    ).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                )
            finishAffinity()
        }
        builder.show()
    }

    override fun onDestroy() {
        super.onDestroy()
//        MyApplication.storageCommon?.nativeAdsWebBrowser2?.postValue(null)
    }


    private fun getBrowserList() {
        browserList.add(
            WebBrowserData(
                getString(R.string.google),
                R.drawable.ic_google_browser,
                R.color.instagram_holiday_love_bg,
                "https://www.google.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.instagram),
                R.drawable.ic_instagram_browser,
                R.color.instagram_holiday_love_bg,
                Constant.URL_Insta
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.twitter),
                R.drawable.ic_twitter_browser,
                R.color.twitter_bg,
                "https://twitter.com/explore"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.LinkedIn),
                R.drawable.ic_linkedin_browser,
                R.color.linkedIn_bg,
                "https://in.linkedin.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.facebook),
                R.drawable.ic_facebook_browser,
                R.color.facebook_daily_motion_bg,
                Constant.URL_FB
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.share_chat),
                R.drawable.ic_share_chat_browser,
                R.color.Share_Chat_bg,
                "https://sharechat.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Pinterest),
                R.drawable.ic_pinterest_browser,
                R.color.pinterest_bg,
                "https://www.pinterest.com/"
            )
        )

        browserList.add(
            WebBrowserData(
                getString(R.string.imdb),
                R.drawable.ic_imdb_browser,
                R.color.IMDB_instagram_s_bg,
                "https://www.imdb.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.bittube),
                R.drawable.ic_bittube_browser,
                R.color.Bittube_Imgur_bg,
                "https://www.bittube.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Daily_Motion),
                R.drawable.ic_daily_motion_browser,
                R.color.facebook_daily_motion_bg,
                "https://www.dailymotion.com/in"
            )
        )

        browserList.add(
            WebBrowserData(
                getString(R.string.twitch),
                R.drawable.ic_twitch_browser,
                R.color.Twitch_bg,
                "https://www.twitch.tv/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.bit_chute),
                R.drawable.ic_bit_chute_browser,
                R.color.BitChute_bg,
                "https://www.bitchute.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Metacafe),
                R.drawable.ic_metacafe_browser,
                R.color.Metacafe_bg,
                "https://metacafe.metacube.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Vlipsy),
                R.drawable.ic_vlipsy_browser,
                R.color.Vlipsy_bg,
                "https://vlipsy.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Flickr),
                R.drawable.ic_flickr_browser,
                R.color.Flickr_bg,
                "https://www.flickr.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Ifunny),
                R.drawable.ic_ifunny_browser,
                R.color.Ifunny_bg,
                "https://ifunny.co/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Reddit),
                R.drawable.ic_reddit_browser,
                R.color.Reddit_bg,
                "https://www.reddit.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Rumble),
                R.drawable.ic_rumble_browser,
                R.color.Rumble_bg,
                "https://rumble.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Imgur),
                R.drawable.ic_imgur_browser,
                R.color.Bittube_Imgur_bg,
                "https://imgur.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Izlesene),
                R.drawable.ic_izlesene_browser,
                R.color.Izlesene_bg,
                "https://www.izlesene.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Onetvru),
                R.drawable.ic_onetvru_browser,
                R.color.Onetvru_bg,
                "https://www.onetv.ca/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.tumblr),
                R.drawable.ic_tumblr_browser,
                R.color.Tumblr_bg,
                "https://www.tumblr.com/"
            )
        )
    }

}