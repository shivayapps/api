package com.quickstream.downloadmaster.browser.ui.data

import java.io.Serializable

data class ImageVersions(  val candidates: List<Candidate>): Serializable
