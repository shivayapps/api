package com.quickstream.downloadmaster.browser.network


import com.quickstream.downloadmaster.browser.ui.data.DpGeneratorCategoryResponse
import com.quickstream.downloadmaster.browser.ui.data.DpGeneratorSubCategoryResponse
import com.quickstream.downloadmaster.browser.ui.data.HashtagAPIData
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Url

interface ApiService {

//    @GET("hashtag.json")
//    fun getHashtagData(): Call<HashtagAPIData>

    @GET
    fun getHashtagData(@Url url: String): Call<HashtagAPIData>


//    @GET("category")
//    fun getCategoryList(): Call<DpGeneratorCategoryResponse>

    @GET
    fun getCategoryList(@Url url: String): Call<DpGeneratorCategoryResponse>

    @GET
    fun getSubCategoryList(@Url url: String): Call<DpGeneratorSubCategoryResponse>

}