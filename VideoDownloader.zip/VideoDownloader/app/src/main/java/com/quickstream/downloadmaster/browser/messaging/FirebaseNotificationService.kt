package com.quickstream.downloadmaster.browser.messaging

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.ui.activity.HomeActivity


class FirebaseNotificationService : FirebaseMessagingService() {

    lateinit var notificationManager: NotificationManager
    private val channelId = "downloadmaster.notifications"

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        showFirebaseNotifcation(message)
    }

    private fun showFirebaseNotifcation(message: RemoteMessage) {
        val title: String? = message.notification?.title
        val body: String? = message.notification?.body

        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val intent = Intent(this, HomeActivity::class.java)

        val pendingIntent =
            PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel("gallery_channel", title, importance).apply {
                description = body
            }
            notificationManager.createNotificationChannel(channel)
        }

        val notification =
            NotificationCompat.Builder(this, channelId)
                .setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setLargeIcon(BitmapFactory.decodeResource(
                    this.resources,
                    R.mipmap.ic_launcher
                ))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .build()

        notificationManager.notify(0, notification)
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("FCM", "Refreshed token: $token")
    }

}

