package com.quickstream.downloadmaster.browser.ui.activity

import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat

import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.Task
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
//import com.google.firebase.analytics.FirebaseAnalytics
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.utils.Preferences
import com.quickstream.downloadmaster.browser.utils.UtilsAd

open class BaseActivity : AppCompatActivity() {

    var themeType = 0
    var reviewManager: ReviewManager? = null
    var reviewInfo: ReviewInfo? = null
//    lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation =
            if (Build.VERSION.SDK_INT < 9) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            themeType = Preferences(this).getThemeValue()
//        firebaseAnalytics = FirebaseAnalytics.getInstance(this)
        setAppTheme()
        getReviewInfo()
//        startReceiver()
    }

    override fun onResume() {
        super.onResume()
        setAppTheme()
    }

    private fun setAppTheme() {
        when (themeType) {
            0 -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }

            1 -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
        }
    }

    fun getReviewEmail(): String {
        return "shivayapps@outlook.com"
    }
    fun getPrivacyPolicy(): String {
        return "https://www.privacypolicies.com/live/a692d2e2-9d85-4d29-9822-01e15134fc3f"
    }


    fun checkStoragePermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_MEDIA_VIDEO
            ) == PackageManager.PERMISSION_GRANTED
        } else
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
    }

    private fun getReviewInfo() {
        reviewManager = ReviewManagerFactory.create(applicationContext)
        val manager: Task<ReviewInfo> = reviewManager!!.requestReviewFlow()
        manager.addOnCompleteListener { task: Task<ReviewInfo> ->
            if (task.isSuccessful) {
                reviewInfo = task.result
            } else {
                Toast.makeText(
                    applicationContext,
                    getString(R.string.ReviewFlowFail),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    fun checkNotificationPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else
            true
    }


}