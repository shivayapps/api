package com.quickstream.downloadmaster.browser.browser.helpers;

import java.util.ArrayList;

public class InstaPostModel {
    private int postIndex = 0;
    private String authorName = "";
    private ArrayList<DownloadInstaMediaButtonModel> downloadButtons = new ArrayList<>();

    public int getPostIndex() {
        return this.postIndex;
    }

    public void setPostIndex(int i) {
        this.postIndex = i;
    }

    public String getAuthorName() {
        return this.authorName;
    }

    public void setAuthorName(String str) {
        this.authorName = str;
    }

    public ArrayList<DownloadInstaMediaButtonModel> getDownloadButtons() {
        return this.downloadButtons;
    }

    public void setDownloadButtons(ArrayList<DownloadInstaMediaButtonModel> arrayList) {
        this.downloadButtons = arrayList;
    }
}
