package com.quickstream.downloadmaster.browser.permission;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

//import com.nabinbhandari.android.permissions.PermissionHandler;
//import com.nabinbhandari.android.permissions.Permissions;
import com.quickstream.downloadmaster.browser.R;
import com.quickstream.downloadmaster.browser.utils.MyApplication;

import java.util.ArrayList;

public class PermissionManager {
    static boolean isAllowClick = false;

    public interface callBack {
        void doNext();

        void noPermission(boolean hasAndroidPermissions);
    }

    public interface callBackWithDismiss {
        void doNext();

        void noPermission(boolean hasAndroidPermissions);

        void onDismiss();

    }

    public static String getHeaderText(String permission) {
        if (permission.matches(Manifest.permission.READ_MEDIA_IMAGES)) {
            return "Media & Storage";
        } else if (permission.matches(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            return "Media & Storage";
        } else if (permission.matches(Manifest.permission.READ_CONTACTS)) {
            return "Contacts";
        } else if (permission.matches(Manifest.permission.CAMERA)) {
            return "Camera";
        } else if (permission.matches(Manifest.permission.RECORD_AUDIO)) {
            return "Record Audio";
        } else {
            return "Other";
        }
    }

    public static String getSubText(String permission) {
        if (permission.matches(Manifest.permission.READ_MEDIA_IMAGES)) {
            return "Allowing us to access files enables you to save keyboard data.";
        } else if (permission.matches(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            return "Allowing us to access files enables you to save keyboard data.";
        } else if (permission.matches(Manifest.permission.READ_CONTACTS)) {
            return "Allowing us to access contacts for you show as typing suggestion";
        } else if (permission.matches(Manifest.permission.CAMERA)) {
            return "Allowing us to access camera functionality";
        } else if (permission.matches(Manifest.permission.RECORD_AUDIO)) {
            return "Allowing us to access record audio for voice typing";
        } else {
            return "Allowing us to access this functionality";
        }
    }

    public static int getIcon(String permission) {
        if (permission.matches(Manifest.permission.READ_MEDIA_IMAGES)) {
            return R.drawable.ic_app_logo;
        } else if (permission.matches(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            return R.drawable.ic_app_logo;
        } else if (permission.matches(Manifest.permission.READ_CONTACTS)) {
            return R.drawable.ic_app_logo;
        } else if (permission.matches(Manifest.permission.CAMERA)) {
            return R.drawable.ic_app_logo;
        } else if (permission.matches(Manifest.permission.RECORD_AUDIO)) {
            return R.drawable.ic_app_logo;
        }
        return R.drawable.ic_app_logo;
    }

    public static void doPermissionTask(Context context, callBack mcallback, String[] permissions) {
//        PreferenceManager.saveData(context, PreferenceKeys.SystemDialogOpened, true);
        //MyApp.isDialogOpen=true;
//        String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
        Log.e("PermissionTag","doPermissionTask");
        MyApplication.Companion.disabledOpenAds();
        isAllowClick = false;
        if (context != null) {
            boolean hasAndroidPermissions = hasPermissions(context, permissions);
            Activity activity = ((Activity) context);
            if (!hasAndroidPermissions /*&& !activity.isFinishing()*/) {
//                StaticMethod.isPermiationDialogOpen = true;
                //MyApp.isDialogOpen=true;
                MyApplication.Companion.disabledOpenAds();
                Log.e("PermissionTag","Permission check");
                Permissions.check(context, permissions, null/*rationale*/, null/*options*/, new PermissionHandler() {
                    @Override
                    public void onGranted() {
                        Log.e("PermissionTag","onGranted");
                        mcallback.doNext();
                    }

                    @Override
                    public void onDenied(Context context, ArrayList<String> deniedPermissions) {
                        Log.e("PermissionTag","onDenied");
                        MyApplication.Companion.disabledOpenAds();
                        super.onDenied(context, deniedPermissions);
                        boolean hasAndroidPermissions = hasPermissions(context, permissions);
                        mcallback.noPermission(hasAndroidPermissions);
                    }
                });
            } else {
                mcallback.doNext();
            }
        }
    }


    public static boolean hasPermissions(Context context, String... permissions) {

        boolean hasAllPermissions = true;

        for (String permission : permissions) {
            //you can return false instead of assigning, but by assigning you can log all permission values
            if (!hasPermission(context, permission)) {
                hasAllPermissions = false;
            }
        }

        return hasAllPermissions;

    }

    public static boolean hasPermission(Context context, String permission) {
        if (context != null) {
            int res = context.checkCallingOrSelfPermission(permission);

            Log.v("msg", "permission: " + permission + " = \t\t" +
                    (res == PackageManager.PERMISSION_GRANTED ? "GRANTED" : "DENIED"));

            return res == PackageManager.PERMISSION_GRANTED;
        } else {
            return false;
        }

    }
}
