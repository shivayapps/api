package com.quickstream.downloadmaster.browser.ui.activity

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.Bundle
import android.text.TextPaint
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.ViewPager
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.quickstream.downloadmaster.browser.R

import com.quickstream.downloadmaster.browser.browser.event.ADShowEvent
import com.quickstream.downloadmaster.browser.databinding.ActivityWhatsAppStatusBinding
import com.quickstream.downloadmaster.browser.ui.fragment.DownloadFragment
import com.quickstream.downloadmaster.browser.ui.fragment.StatusFragment
import com.quickstream.downloadmaster.browser.utils.AdCache
import com.quickstream.downloadmaster.browser.utils.Constant
import com.quickstream.downloadmaster.browser.utils.UtilsAd
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe

class WhatsAppStatusActivity : BaseActivity() {
    lateinit var binding: ActivityWhatsAppStatusBinding

    lateinit var statusFragment: StatusFragment
    lateinit var downloadFragment: DownloadFragment
    var isShowADsStatus = false
    var isShowADsDownload = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWhatsAppStatusBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inti()
        intiListener()
        EventBus.getDefault().register(this)
    }

    private fun inti() {
        binding.loutToolbar.txtTitle.text = getString(R.string.whatsapp)
        binding.loutToolbar.ivRight.visibility = View.VISIBLE
        binding.loutToolbar.ivRight.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_whatsapp
            )
        )
        setTab()

    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.btnTabStatus.setOnClickListener {
            binding.viewpager.currentItem = 0
        }

        binding.btnTabDownload.setOnClickListener {
            binding.viewpager.currentItem = 1
        }
        binding.loutToolbar.ivRight.setOnClickListener {
            openApp("com.whatsapp", "WhatsApp not Installed", this)
        }
    }

    private fun openApp(packageName: String, name: String, activity: Activity) {
        try {
            val i = activity.packageManager.getLaunchIntentForPackage(packageName!!)
            activity.startActivity(i)
        } catch (e: Exception) {
            Log.e("openApp","message===>> ${e.message}")
            e.printStackTrace()
            Toast.makeText(activity, name, Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadBannerAd() {
        if (isShowADsStatus || isShowADsDownload) {
            if (binding.frameBanner.childCount == 0) {

                if (!isAdLoaded) {
                    val adId = getString(R.string.bannerWaStatus)
                    BannerAdHelper.showBanner(this, binding.frameBanner, binding.frameBanner, adId,
                        AdCache.bannerWaStatus, { isLoaded, adView, message ->
                            mAdView = adView
                            AdCache.bannerWaStatus = adView
                            isAdLoaded = isLoaded
                        })
                }
            }
        }
    }

    var isAdLoaded=false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun setTab() {
        statusFragment = StatusFragment(adsListener = {
            isShowADsStatus = it
            loadBannerAd()
        })
        downloadFragment = DownloadFragment.newInstance(this,Constant.DOWNLOAD_WHATSAPP)
        val fragmentList: java.util.ArrayList<Fragment> = ArrayList()
        fragmentList.add(statusFragment)
        fragmentList.add(downloadFragment)

        binding.viewpager.adapter =
            PageAdapter(supportFragmentManager, fragmentList)

        binding.viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {
                if (position == 0)
                    setSelectTab(binding.btnTabStatus, binding.btnTabDownload)
                else
                    setSelectTab(binding.btnTabDownload, binding.btnTabStatus)
            }

            override fun onPageSelected(position: Int) {
                if (position == 1) {
                    val fragment: DownloadFragment =
                        (binding.viewpager.adapter as PageAdapter).instantiateItem(
                            binding.viewpager,
                            position
                        ) as DownloadFragment
                    fragment.onResume()
                    (binding.viewpager.adapter as PageAdapter).notifyDataSetChanged()
                }
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
    }

    @Subscribe
    fun onADShowEvent(adShowEvent: ADShowEvent) {
        runOnUiThread {
            isShowADsDownload = adShowEvent.isShowADs
            loadBannerAd()
        }
    }

    class PageAdapter(fm: FragmentManager, var fragmentList: java.util.ArrayList<Fragment>) :
        FragmentPagerAdapter(fm) {
        override fun getCount(): Int {
            return fragmentList.size
        }

        override fun getItem(position: Int): Fragment {
            return fragmentList[position]
        }
    }

    private fun setSelectTab(btnSelect: LinearLayout, btnUnSelect: LinearLayout) {
        btnSelect.background = ContextCompat.getDrawable(this, R.drawable.btn_gradient)
        btnUnSelect.background = ContextCompat.getDrawable(this, R.drawable.btn_gray)

        if (btnSelect == binding.btnTabStatus) {
            setGradientText(binding.txtTabDownload)
            removeGradientText(binding.txtTabStatus)
        } else {
            setGradientText(binding.txtTabStatus)
            removeGradientText(binding.txtTabDownload)
        }
    }

    private fun setGradientText(btnSelect: TextView) {
        val paint: TextPaint = btnSelect.paint
        val width = paint.measureText(btnSelect.text.toString())

        val textShader: Shader = LinearGradient(
            0f, 0f,
            width,
            btnSelect.textSize,
            intArrayOf(
                ContextCompat.getColor(this, R.color.gradient1),
                ContextCompat.getColor(this, R.color.gradient2),
                ContextCompat.getColor(this, R.color.gradient2),
                ContextCompat.getColor(this, R.color.gradient2),
                ContextCompat.getColor(this, R.color.gradient3),
            ), null, Shader.TileMode.CLAMP
        )

        btnSelect.paint.shader = textShader
        btnSelect.invalidate()
    }

    private fun removeGradientText(textView: TextView) {
        textView.paint.shader = null
        textView.invalidate()
    }
}