package com.quickstream.downloadmaster.browser.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import androidx.appcompat.app.AlertDialog
import androidx.viewpager.widget.PagerAdapter
import com.bumptech.glide.Glide
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.databinding.DeleteDialogLayoutBinding
import com.quickstream.downloadmaster.browser.databinding.ItemViewDownloadBinding
import com.quickstream.downloadmaster.browser.utils.Utils
import java.io.File
import java.util.Objects

class DownloadViewAdapter(val context: Context, val introList: ArrayList<String>,  val deleteListener: (pos: Int) -> Unit) :
    PagerAdapter() {

    override fun getCount(): Int {
        return introList.size
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object` as RelativeLayout
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val mLayoutInflater =
            context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val binding = ItemViewDownloadBinding.inflate(mLayoutInflater, container, false)

        val file = File(introList[position])

        binding.txtDownloadName.text = file.name
        Glide.with(context)
            .load(introList[position])
            .into(binding.imageDownload)

        if (Utils.isVideoFile(introList[position]))
            binding.ivPlay.visibility = View.VISIBLE
        else
            binding.ivPlay.visibility = View.GONE



        binding.ivDelete.setOnClickListener {
            val builder = AlertDialog.Builder(context, R.style.CustomAlertDialog).create()
            val deleteDialogLayoutBinding: DeleteDialogLayoutBinding =
                DeleteDialogLayoutBinding.inflate(LayoutInflater.from(context))
            builder.setView(deleteDialogLayoutBinding.root)
            deleteDialogLayoutBinding.tvNo.setOnClickListener {
                builder.dismiss()
            }

            deleteDialogLayoutBinding.tvYes.setOnClickListener {
                builder.dismiss()
                val file1 = File(introList[position])
                val d = file1.delete()
                if (d) {
                    deleteListener(position)
                }
            }
            builder.show()
        }

        binding.ivShare.setOnClickListener {
            Utils.fileShare(context,introList[position])
        }

        binding.ivPlay.setOnClickListener {

        }


        Objects.requireNonNull(container).addView(binding.root)
        return binding.root
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {

        container.removeView(`object` as RelativeLayout)
    }
}