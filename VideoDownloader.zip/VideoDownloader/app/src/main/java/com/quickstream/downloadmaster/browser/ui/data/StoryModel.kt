package com.quickstream.downloadmaster.browser.ui.data

import java.io.Serializable

data class StoryModel(val tray: List<StoryTray>): Serializable
