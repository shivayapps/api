package com.quickstream.downloadmaster.browser.browser.ui_events;


import com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel;
import com.quickstream.downloadmaster.browser.browser.helpers.FBContainerModel;
import com.quickstream.downloadmaster.browser.browser.helpers.InstaPostModel;
import com.quickstream.downloadmaster.browser.browser.helpers.InstaPostModel;

import java.util.List;

public interface ButtonsIntegratingStateHandler {
    void OnComplete_FB(List<FBContainerModel> list);

    void OnComplete_Insta(List<InstaPostModel> list);

    void OnComplete_YT(String str, List<DownloadYTVideoButtonModel> list, List<DownloadYTVideoButtonModel> list2, DownloadYTVideoButtonModel downloadYTVideoButtonModel);

    void OnError(String str);
}
