package com.quickstream.downloadmaster.browser.ui.activity.option

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.View
import android.view.Window
import android.webkit.CookieManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView

import com.google.gson.Gson
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.browser.event.DownloadDeleteEvent
import com.quickstream.downloadmaster.browser.databinding.ActivityInstaStoryBinding
import com.quickstream.downloadmaster.browser.databinding.DialogDownloadBinding
import com.quickstream.downloadmaster.browser.networkmanager.ApiManager
import com.quickstream.downloadmaster.browser.ui.activity.BaseActivity
import com.quickstream.downloadmaster.browser.ui.activity.PermissionActivity
import com.quickstream.downloadmaster.browser.ui.adapter.StoriesAdapter
import com.quickstream.downloadmaster.browser.ui.adapter.StoriesDetailsAdapter
import com.quickstream.downloadmaster.browser.ui.data.DownloadData
import com.quickstream.downloadmaster.browser.ui.data.StoriesDetailsResponse
import com.quickstream.downloadmaster.browser.ui.data.StoryItem
import com.quickstream.downloadmaster.browser.ui.data.StoryModel
import com.quickstream.downloadmaster.browser.ui.data.StoryTray
import com.quickstream.downloadmaster.browser.ui.fragment.LoginDialog
import com.quickstream.downloadmaster.browser.ui.interfaces.APIResponse
import com.quickstream.downloadmaster.browser.utils.AdCache
import com.quickstream.downloadmaster.browser.utils.Constant
import com.quickstream.downloadmaster.browser.utils.DownloadManager
import com.quickstream.downloadmaster.browser.utils.FileUtil
import com.quickstream.downloadmaster.browser.utils.Preferences
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.util.concurrent.Executors

class InstaStoryActivity : BaseActivity() {

    lateinit var binding: ActivityInstaStoryBinding
    lateinit var preferences: Preferences
    var storiesList: ArrayList<StoryTray> = ArrayList()
    var mediaList: ArrayList<StoryItem> = ArrayList()
    var storiesAdapter: StoriesAdapter? = null
    var storiesDetailsAdapter: StoriesDetailsAdapter? = null
    private var isLogin = false
    var selectDownloadPos = -1
    var storiesDetailsPos = -1
    var downloadStorePath = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInstaStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inti()
    }

    private fun inti() {
        binding.loutToolbar.txtTitle.text = getString(R.string.instaStory)
        preferences = Preferences(this)
        binding.loutToolbar.ivRight.visibility = View.GONE
        binding.txtNoStories.visibility = View.GONE
        binding.rvStories.layoutManager =
            LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        setSwitchValue()
        intiListener()
        binding.loutInstLoin.visibility = View.VISIBLE
        setLoginData()
        downloadStorePath = FileUtil.getExternalStoragePublicDirectory(
            this,
            Environment.DIRECTORY_PICTURES
        ) + File.separator + getString(
            R.string.app_name
        ) + File.separator + Constant.FOLDER_INSTAGRAM
        checkButtonDownload()
    }

    private fun checkButtonDownload() {
        val service = Executors.newSingleThreadExecutor()
        service.execute {
            val isDataIsAdded = checkPathIsNotEmpty()
            runOnUiThread {
                binding.loutToolbar.btnDownload.visibility =
                    if (isDataIsAdded) View.VISIBLE else View.GONE
            }
        }
    }

    private fun checkPathIsNotEmpty(): Boolean {
        var isDataIsAdd = false
        val file = File(downloadStorePath)
        if (file.exists()) {
            val listFile = file.listFiles()
            try {
                if (file.listFiles().isNotEmpty()) {
                    for (i in listFile.indices) {
                        val data = listFile[i]
                        if (data.isFile && data.exists() && data.length() != 0L) {
                            isDataIsAdd = true
                            break
                        }
                    }
                }
            } catch (e: NullPointerException) {
                e.printStackTrace()
            }
        }
        return isDataIsAdd
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.loutToolbar.btnDownload.setOnClickListener {
            startActivity(
                Intent(this, DownloadActivity::class.java).putExtra(
                    Constant.EXTRA_TYPE,
                    Constant.DOWNLOAD_INSTAGRAM
                )
            )
        }
        binding.switchPrivate.setOnClickListener {
            val isLoginData: Boolean = !isLogin

            binding.switchPrivate.setImageDrawable(
                ContextCompat.getDrawable(
                    this,
                    if (isLoginData) R.drawable.ic_switch_on else R.drawable.ic_switch_off
                )
            )
            if (isLoginData) {
                openLoginScreen()
            } else {
                isLogin = false
                preferences.putLoginInstagram(false)
                setLoginData()
            }
        }
        binding.btnOpenInsta.setOnClickListener {
            openLoginScreen()
        }
    }

    private fun openLoginScreen() {
        val dialog = LoginDialog(this, onLoginListener = {
            loginLauncher.launch(Intent(this, LoginActivity::class.java))
        })
        dialog.show()
    }

    private fun setStoriesAdapter() {
        storiesAdapter = StoriesAdapter(this, storiesList, clickListener = {
            getStoriesDetails(storiesList[it])
        })
        binding.rvStories.adapter = storiesAdapter
    }

    private fun setStoriesDetailsAdapter() {
        val folder = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath
                    + File.separator + getString(R.string.app_name)
                    + File.separator + Constant.FOLDER_INSTAGRAM
        )
        storiesDetailsAdapter =
            StoriesDetailsAdapter(this, mediaList, deleteListener = {
                storiesDetailsPos = it
                val fileN =
                    Constant.TYPE_Story + mediaList[it].id + if (mediaList[it].mediaType == Constant.TYPE_IMAGE) ".png" else ".mp4"
                val file = File(folder, fileN)
                val deletePath = file.path
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    FileUtil.deleteWithoutManageExternalStorage(deletePath, this)
                } else {
                    val file1 = File(deletePath)
                    val d = file1.delete()
                    if (d) {
                        EventBus.getDefault()
                            .post(DownloadDeleteEvent(deletePath, 0))
                        if (storiesDetailsAdapter != null)
                            storiesDetailsAdapter!!.notifyItemChanged(it)
                        checkButtonDownload()
                    }
                }
            }, downloadListener = {
                selectDownloadPos = it
                if (checkStoragePermissions()) {
                    setStoriesDownload()
                } else
                    storiesPermissionLauncher.launch(
                        Intent(
                            this,
                            PermissionActivity::class.java
                        )
                    )

            })
        binding.rvStoriesList.adapter = storiesDetailsAdapter
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Constant.DELETE_REQUEST_CODE && resultCode == Activity.RESULT_OK) {

            if (storiesDetailsAdapter != null)
                storiesDetailsAdapter!!.notifyItemChanged(storiesDetailsPos)
            val folder = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath
                        + File.separator + getString(R.string.app_name)
                        + File.separator + Constant.FOLDER_INSTAGRAM
            )
            val fileN =
                Constant.TYPE_Story + mediaList[storiesDetailsPos].id + if (mediaList[storiesDetailsPos].mediaType == Constant.TYPE_IMAGE) ".png" else ".mp4"
            val file = File(folder, fileN)
            val deletePath = file.path
            EventBus.getDefault()
                .post(DownloadDeleteEvent(deletePath, 0))
            checkButtonDownload()
        }
    }


    var storiesPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                setStoriesDownload()
            }
        }

    private fun setStoriesDownload() {
        val data = mediaList[selectDownloadPos]
        val downloadList: ArrayList<DownloadData> = ArrayList()
        when (data.mediaType) {
            Constant.TYPE_VIDEO -> {
                val downloadUrl = data.videoVersions[0].url
                downloadList.add(DownloadData(downloadUrl, Constant.TYPE_VIDEO, data.id))
            }

            Constant.TYPE_IMAGE -> {
                val downloadUrl = data.imageVersions2.candidates[0].url
                downloadList.add(DownloadData(downloadUrl, Constant.TYPE_IMAGE, data.id))
            }
        }
        selectDownloadPos = selectDownloadPos
        downloadUrl(downloadList, true)
    }

    var loginLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                setLoginData()
            }
            setSwitchValue()
        }

    private fun setSwitchValue() {
        isLogin = preferences.isLoginInstagram()
        binding.switchPrivate.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                if (isLogin) R.drawable.ic_switch_on else R.drawable.ic_switch_off
            )
        )
    }

    private fun setLoginData() {
        setWebCookie()
        if (preferences.isLoginInstagram()) {
            binding.loutInstaStories.visibility = View.VISIBLE
//            binding.loutInstLoin.visibility = View.GONE
            loadBannerAd()
            getStories()

        } else {
            binding.loutInstaStories.visibility = View.GONE
            binding.frameNative.visibility = View.GONE
//            binding.loutInstLoin.visibility = View.VISIBLE
            binding.txtNoStories.visibility = View.GONE
        }
    }


    private fun setWebCookie() {
        if (preferences.isLoginInstagram()) {
            val cookiesList = listOf(preferences.getInstagramCookies())
            cookiesList.forEach { item ->
                CookieManager.getInstance().setCookie("https://www.instagram.com", item)
            }
        } else {
            CookieManager.getInstance().removeAllCookie()
        }
    }

    var isAdLoaded=false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    private fun loadBannerAd() {
        binding.frameNative.visibility = View.VISIBLE
        if (!isAdLoaded) {
            val adId = getString(R.string.bannerInstaStory)
            BannerAdHelper.showBanner(this, binding.frameNative, binding.frameNative, adId,
                AdCache.bannerInstaStory, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.bannerInstaStory = adView
                    isAdLoaded = isLoaded
                })
        }
    }

    private fun getStories() {
        storiesList.clear()
        if (storiesAdapter != null)
            storiesAdapter?.notifyDataSetChanged()
        binding.progressStoriesList.visibility = View.VISIBLE

        val api = ApiManager()
        api.getStoriesApi(this, object : APIResponse {

            override fun onResponse(response: Any) {
                val storyModel = Gson().fromJson(
                    Gson().toJson(response),
                    StoryModel::class.java
                )
                runOnUiThread {
                    binding.progressStoriesList.visibility = View.GONE
                    if (storyModel != null)
                        if (storyModel.tray.isNullOrEmpty()) {
                            binding.loutInstaStories.visibility = View.VISIBLE
                            binding.txtNoStories.visibility = View.VISIBLE
                            binding.rvStories.visibility = View.GONE
                        } else {
                            binding.loutInstaStories.visibility = View.VISIBLE
                            binding.txtNoStories.visibility = View.GONE
                            binding.rvStories.visibility = View.VISIBLE
                            storyModel.let { storiesList.addAll(it.tray) }
                            if (storiesAdapter != null)
                                storiesAdapter?.notifyDataSetChanged()
                            else
                                setStoriesAdapter()
                        }
                    else {
                        binding.loutInstaStories.visibility = View.GONE
                        binding.txtNoStories.visibility = View.VISIBLE
                        binding.rvStories.visibility = View.GONE
                        Toast.makeText(
                            this@InstaStoryActivity,
                            getText(R.string.download_fail_msg),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }

            override fun onFailure(error: String) {
                runOnUiThread {
                    binding.progressStoriesList.visibility = View.GONE
                    Log.e("onError: ", "onError==>> ${error}")
                    binding.loutInstaStories.visibility = View.GONE
                    binding.txtNoStories.visibility = View.VISIBLE
                    binding.rvStories.visibility = View.GONE
                    Toast.makeText(
                        this@InstaStoryActivity,
                        getText(R.string.download_fail_msg),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onLoginRequired() {
                runOnUiThread {
                    binding.progressStoriesList.visibility = View.GONE
                    binding.loutInstaStories.visibility = View.GONE
                    binding.txtNoStories.visibility = View.VISIBLE
                    binding.rvStories.visibility = View.GONE
                    Toast.makeText(
                        this@InstaStoryActivity,
                        getString(R.string.login_retry),
                        Toast.LENGTH_SHORT
                    ).show()
                    openLoginScreen()
                }
            }
        })
//        api.getStoriesApi(this, storiesObserver)
    }

    private fun getStoriesDetails(storiesDetails: StoryTray) {
        binding.progressStoriesList.visibility = View.VISIBLE
        mediaList.clear()
        if (storiesDetailsAdapter != null)
            storiesDetailsAdapter?.notifyDataSetChanged()

        val api = ApiManager()
//        api.getStoriesFullDetail(
//            this,
//            storiesDetailInfoObserver,
//            storiesDetails.user.pk.toString()
//        )
        api.getStoriesFullDetail(this, storiesDetails.user.pk.toString(), object : APIResponse {
            override fun onResponse(response: Any) {
                val storyDetails = Gson().fromJson(
                    Gson().toJson(response),
                    StoriesDetailsResponse::class.java
                )
                runOnUiThread {
                    binding.progressStoriesList.visibility = View.GONE
                    if (storyDetails.reelsMedia.isNotEmpty() && storyDetails.reelsMedia[0].items.isNotEmpty()) {
                        mediaList.addAll(storyDetails.reelsMedia[0].items)
                        binding.rvStoriesList.visibility = View.VISIBLE
                        if (storiesDetailsAdapter != null)
                            storiesDetailsAdapter?.notifyDataSetChanged()
                        else
                            setStoriesDetailsAdapter()
                    } else {
                        binding.rvStoriesList.visibility = View.GONE
                    }
                }
            }

            override fun onFailure(error: String) {
                runOnUiThread {
                    binding.progressStoriesList.visibility = View.GONE
                    Toast.makeText(
                        this@InstaStoryActivity,
                        getText(R.string.download_fail_msg),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onLoginRequired() {
                runOnUiThread {
                    binding.progressStoriesList.visibility = View.GONE
                    Toast.makeText(
                        this@InstaStoryActivity,
                        getString(R.string.login_retry),
                        Toast.LENGTH_SHORT
                    ).show()
                    openLoginScreen()
                }
            }

        })
    }

    private fun downloadUrl(
        downloadList: ArrayList<DownloadData>,
        isStoryDownload: Boolean = false
    ) {
        if (downloadList.isEmpty()) {
            Toast.makeText(
                this,
                getString(R.string.already_downloaded),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            var dialogBinding: DialogDownloadBinding
            var dialog: Dialog
            val filesList: ArrayList<String> = ArrayList()

            this.runOnUiThread {
                dialogBinding = DialogDownloadBinding.inflate(layoutInflater)
                dialog = Dialog(this, R.style.Theme_Dialog)
                dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
                dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog.setCancelable(false)
                dialog.setCanceledOnTouchOutside(false)
                dialog.setContentView(dialogBinding.root)
                dialogBinding.progressBar.progress = 0
                dialogBinding.txtPer.text = "0%"
                dialogBinding.txtCount.text = "0/100"
                dialog.show()

                val downloadManager = DownloadManager(this)
                Observable.fromCallable {
                    for (downloadData in downloadList) {
                        this.runOnUiThread {
                            dialogBinding.progressBar.progress = 0
                            dialogBinding.txtPer.text = "0%"
                            dialogBinding.txtCount.text = "0/100"
                        }
                        val path = downloadManager.downloadFile(
                            downloadData.url,
                            if (isStoryDownload) Constant.TYPE_Story else Constant.TYPE_Insta,
                            downloadData.posterId,
                            downloadData.fileType,
                            progressUpdateListener = {
                                this.runOnUiThread {
                                    dialogBinding.progressBar.progress = it
                                    dialogBinding.txtPer.text = "$it%"
                                    dialogBinding.txtCount.text = "$it/100"
                                }
                            })
                        if (path.isNotEmpty())
                            filesList.add(path)
                    }
                    return@fromCallable ""
                }.subscribeOn(Schedulers.io())
                    .doOnError { throwable: Throwable? ->
                        this.runOnUiThread {
                            dialog.dismiss()
                            Toast.makeText(
                                this,
                                this.getText(R.string.download_fail_msg),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    .subscribe { result: String? ->
                        Log.e("", "getReels result==>> $result ")
                        this.runOnUiThread {
                            dialog.dismiss()
                            if (filesList.isNotEmpty()) {
                                if (binding.loutToolbar.btnDownload.visibility == View.GONE)
                                    checkButtonDownload()
                                if (isStoryDownload) {
                                    if (storiesDetailsAdapter != null && selectDownloadPos != -1)
                                        storiesDetailsAdapter?.notifyItemChanged(selectDownloadPos)
                                }
                            } else {
                                Toast.makeText(
                                    this,
                                    this.getText(R.string.download_fail_msg),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
            }
        }
    }

}