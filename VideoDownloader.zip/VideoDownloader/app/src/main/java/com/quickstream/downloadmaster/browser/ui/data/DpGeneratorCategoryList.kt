package com.quickstream.downloadmaster.browser.ui.data

import java.io.Serializable

data class DpGeneratorCategoryList(
    val id: Int,
    val image_url: String,
    val name: String
) : Serializable {
    var subList = ArrayList<DpGeneratorSubCategoryItem>()
    var icon: Int = -1
}