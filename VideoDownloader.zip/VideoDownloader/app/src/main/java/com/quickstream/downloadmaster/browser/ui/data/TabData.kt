package com.quickstream.downloadmaster.browser.ui.data

data class TabData(var title: String,var type: String)
