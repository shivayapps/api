package com.quickstream.downloadmaster.browser.ui.activity

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.gson.Gson
import com.quickstream.downloadmaster.browser.utils.AppUrl
import com.quickstream.downloadmaster.browser.databinding.ActivityHashtagArrayBinding

import com.quickstream.downloadmaster.browser.ui.adapter.HashtagSubDataAdapter
import com.quickstream.downloadmaster.browser.ui.data.CategoryItemItem
import com.quickstream.downloadmaster.browser.ui.data.HashtagAPIData
import com.quickstream.downloadmaster.browser.utils.Constant
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.InputStream

class HashtagArrayActivity : BaseActivity() {
    lateinit var binding: ActivityHashtagArrayBinding
    var title = ""
    var subArrayList: ArrayList<CategoryItemItem> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHashtagArrayBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inits()
        intiListener()
        getAPIData()
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
    }

    fun readJSONFromAsset(): String? {
        var json: String? = null
        try {
            val inputStream: InputStream = assets.open("hashtag/hashtag.json")
            json = inputStream.bufferedReader().use { it.readText() }
        } catch (ex: Exception) {
            ex.printStackTrace()
            return null
        }
        return json
    }
    fun parseJSON(): HashtagAPIData {
        return Gson().fromJson(readJSONFromAsset(), HashtagAPIData::class.java)
    }

    private fun getAPIData() {
//        val call: Call<HashtagAPIData> = RetrofitClient2.instance!!.myApi.getHashtagData(AppUrl().hashtagListENDURL())
//        call.enqueue(object : Callback<HashtagAPIData> {
//            override fun onResponse(call: Call<HashtagAPIData>, response: Response<HashtagAPIData>) {
        val response = readJSONFromAsset()
//        val mainList: HashtagAPIData = response.body()!!
        val mainList: HashtagAPIData = parseJSON()
//        Log.e("onResponse", "response:${response.body()}")
        val mainHashtagArray = mainList.hashtag
        for (i in mainHashtagArray.indices) {
            if (mainHashtagArray[i].categoryName == title) {
                subArrayList = mainHashtagArray[i].categoryItem
                binding.progress.visibility = View.GONE
                setAdapterData()
                break
            }
        }
//            }
//            override fun onFailure(call: Call<HashtagAPIData>, t: Throwable) {
//                binding.progress.visibility = View.GONE
//                Log.e("","onFailure==>>>  ${t.message}" )
//                Toast.makeText(applicationContext, "Please Check Your Internet Connection", Toast.LENGTH_SHORT).show()
//            }
//        })
    }

    private fun setAdapterData() {
        binding.rvHashtagArray.adapter = HashtagSubDataAdapter(subArrayList, this, this)
    }

    private fun inits() {
        binding.progress.visibility = View.VISIBLE
        title = intent.getStringExtra(Constant.PUT_KEY_HASHTAG_TITLE).toString()
        binding.loutToolbar.txtTitle.text = title

    }
}