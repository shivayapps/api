package com.quickstream.downloadmaster.browser.browser.event

import com.quickstream.downloadmaster.browser.ui.data.DownloadData

data class ProgressUpdateDownloadEvent(var data: DownloadData)