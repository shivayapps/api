package com.quickstream.downloadmaster.browser.ui.adapter

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.databinding.HashtagArrayItmeLayoutBinding
import com.quickstream.downloadmaster.browser.ui.activity.TagFullActivity
import com.quickstream.downloadmaster.browser.ui.data.CategoryItemItem
import com.quickstream.downloadmaster.browser.utils.Constant
import com.quickstream.downloadmaster.browser.utils.MyApplication

class HashtagSubDataAdapter(var hashtagDataList: ArrayList<CategoryItemItem>, var activity: Activity, var context: Context) : RecyclerView.Adapter<HashtagSubDataAdapter.MyViewHolder>() {
    inner class MyViewHolder(var binding: HashtagArrayItmeLayoutBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(HashtagArrayItmeLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun getItemCount(): Int {
        return hashtagDataList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        with(holder.binding) {
            with(hashtagDataList[position]) {
                tvSubTitle.text = subCategoryName
                setTag(subCategoryName, tag, tvTags, tvTagCounter)
                holder.itemView.setOnClickListener {
                    toggleExpand(holder.binding.llGeneral, holder.binding.ivActionGeneral)
//                    activity.startActivity(Intent(context, TagFullActivity::class.java).putExtra(Constant.PUT_KEY_TAG_STRING, tag).putExtra(Constant.PUT_KEY_SUB_TITLE, subCategoryName))
                }
                holder.binding.llCopy.setOnClickListener {
                    val clipboardManager = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clipData = ClipData.newPlainText("text", holder.binding.tvTags.text.toString())
                    clipboardManager.setPrimaryClip(clipData)
                    Toast.makeText(activity, "Text copied", Toast.LENGTH_LONG).show()
                }
                holder.binding.llShare.setOnClickListener {
                    val shareIntent = Intent()
                    shareIntent.action = Intent.ACTION_SEND
                    shareIntent.type = "text/plain"
                    shareIntent.putExtra(Intent.EXTRA_TEXT, holder.binding.tvTags.text.toString());
                    MyApplication.disabledOpenAds()
                    activity.startActivity(Intent.createChooser(shareIntent, "send to"))
                }
            }
        }
    }

    fun setTag(title: String, tag: String, tvTag: TextView, tvTagCounter: TextView) {
        if (tag != null) {
            tvTag.text = tag
//            when (title) {
//                "Memes" -> {
//                    tvTag.text = activity.getString(R.string.Memes)
//                }
//
//                "Music" -> {
//                    tvTag.text = activity.getString(R.string.Music)
//                }
//
//                "Love" -> {
//                    tvTag.text = activity.getString(R.string.Love)
//                }
//
//                "Logos" -> {
//                    tvTag.text = activity.getString(R.string.Logos)
//                }
//
//                "Sports" -> {
//                    tvTag.text = activity.getString(R.string.sports1)
//                }
//
//                "Tattoos" -> {
//                    tvTag.text = activity.getString(R.string.tattoos)
//                }
//
//                "Transport" -> {
//                    tvTag.text = activity.getString(R.string.transport)
//                }
//
//                "Stuff" -> {
//                    tvTag.text = activity.getString(R.string.stuff)
//                }
//
//                "Buildings" -> {
//                    tvTag.text = activity.getString(R.string.buildings)
//                }
//
//                "Animals" -> {
//                    tvTag.text = activity.getString(R.string.animals)
//                }
//
//                "Chars" -> {
//                    tvTag.text = activity.getString(R.string.chars)
//                }
//
//                else -> {
//                    tvTag.text = tag
//                }
//            }
            var counter = 0
            for (c in tvTag.text.toString()) {
                if (c == '#') {
                    counter++
                }
            }
            tvTagCounter.text = "$counter Tags"

        }
    }

    fun toggleExpand(mainView: View, actionView: View) {
        if (mainView.visibility == View.VISIBLE) {
            mainView.visibility = View.GONE
            actionView.animate()
                .rotation(0f)
                .setDuration(500).start()
        } else {
            mainView.visibility = View.VISIBLE
            actionView.animate()
                .rotation(90f)
                .setDuration(500).start()
        }
    }
}