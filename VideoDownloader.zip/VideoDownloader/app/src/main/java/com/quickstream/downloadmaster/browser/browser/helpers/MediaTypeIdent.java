package com.quickstream.downloadmaster.browser.browser.helpers;

public enum MediaTypeIdent {
    VIDEO,
    AUDIO,
    IMAGE
}
