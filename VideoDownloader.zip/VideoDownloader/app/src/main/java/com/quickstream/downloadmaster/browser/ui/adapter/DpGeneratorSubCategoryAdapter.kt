package com.quickstream.downloadmaster.browser.ui.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.quickstream.downloadmaster.browser.databinding.ItemDpGeneratorSubCategoryBinding
import com.quickstream.downloadmaster.browser.ui.data.DpGeneratorSubCategoryItem

class DpGeneratorSubCategoryAdapter(
    var context: Context,
    var subCategoryList: ArrayList<DpGeneratorSubCategoryItem>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<DpGeneratorSubCategoryAdapter.ViewHolder>() {
    var imageDp = ""

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemDpGeneratorSubCategoryBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return subCategoryList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.progressBar.visibility = View.VISIBLE
        Glide.with(context)
            .load(subCategoryList[position].img)
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>?,
                    isFirstResource: Boolean
                ): Boolean {
                    return false
                }

                override fun onResourceReady(
                    resource: Drawable?,
                    model: Any?,
                    target: Target<Drawable>?,
                    dataSource: DataSource?,
                    isFirstResource: Boolean
                ): Boolean {
                    holder.binding.progressBar.visibility = View.GONE
                    return false
                }
            })
            .into(holder.binding.icon)

        if (imageDp.isNotEmpty()) {
            holder.binding.userProfile.visibility = View.VISIBLE
            Glide.with(context)
                .load(imageDp)
                .into(holder.binding.userProfile)
        } else
            holder.binding.userProfile.visibility = View.GONE

        holder.binding.root.setOnClickListener {
            clickListener(position)
        }
    }

    fun setImageSelect(imageSelect: String) {
        imageDp = imageSelect
        notifyDataSetChanged()
    }

    class ViewHolder(var binding: ItemDpGeneratorSubCategoryBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }
}