package com.quickstream.downloadmaster.browser.ui.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.View
import android.view.animation.AnimationUtils
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.ViewPager
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView

import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.databinding.ActivityMyAllDownloadBinding
import com.quickstream.downloadmaster.browser.ui.activity.option.BrowserDownloadActivity
import com.quickstream.downloadmaster.browser.ui.adapter.TabAdapter
import com.quickstream.downloadmaster.browser.ui.data.TabData
import com.quickstream.downloadmaster.browser.ui.fragment.DownloadFragment
import com.quickstream.downloadmaster.browser.utils.AdCache
import com.quickstream.downloadmaster.browser.utils.Constant
import com.quickstream.downloadmaster.browser.utils.UtilsAd
import java.io.File
import java.util.concurrent.Executors

class MyAllDownloadActivity : BaseActivity() {

    lateinit var binding: ActivityMyAllDownloadBinding
    val tabList: ArrayList<TabData> = ArrayList()
    var tabSelect = 0
    var tabAdapter: TabAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyAllDownloadBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        binding.loutToolbar.txtTitle.text = getString(R.string.myDownloaded)
        binding.tvNoData.visibility = View.GONE
        setTab()
        intiListener()
        binding.btnOpenInsta.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    BrowserDownloadActivity::class.java
                ).putExtra(Constant.PUT_KEY_URL, Constant.URL_Insta)
                    .putExtra(
                        Constant.EXTRA_TYPE,
                        Constant.TYPE_Insta
                    )
            )
        }
    }

    private fun loadNativeADs() {
        if (binding.frameNative.childCount == 0) {
            binding.frameNative.visibility = View.VISIBLE
//            NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, binding.frameNative, 3)
//            NativeLoadWithShows(this).showNativeTopAlways(this, binding.frameNative)
            if (!isAdLoaded) {
                val adId = getString(R.string.bannerAllDownload)
                BannerAdHelper.showBanner(this, binding.frameBanner, binding.frameBanner, adId,
                    AdCache.bannerAllDownload, { isLoaded, adView, message ->
                        mAdView = adView
                        AdCache.bannerAllDownload = adView
                        isAdLoaded = isLoaded
                    })
            }
        }
    }

    var isAdLoaded=false
    var mAdView: AdView?=null

    var isPause = false
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        if (isPause) {
            isPause = false
            setTab()
        }
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
        isPause = true

    }

    private fun setTab() {
        val service = Executors.newSingleThreadExecutor()
        service.execute {
            getTabList()
            runOnUiThread {
                if (tabList.isEmpty()) {
//                    binding.tvNoData.visibility = View.VISIBLE
                    binding.loutInstLoin.visibility = View.VISIBLE
                    binding.rvTab.visibility = View.GONE
                    binding.viewpager.visibility = View.GONE
                    setAnimationButton()

                } else {
                    binding.tvNoData.visibility = View.GONE
                    binding.loutInstLoin.visibility = View.GONE
                    binding.rvTab.visibility = View.VISIBLE
                    binding.viewpager.visibility = View.VISIBLE
                    intTab()
                    loadNativeADs()
                }
            }
        }
    }

    private fun setAnimationButton() {
//        binding.btnOpenInsta.clearAnimation()
//        val clickAnimation = AnimationUtils.loadAnimation(this, R.anim.button_animation)
//        binding.btnOpenInsta.startAnimation(clickAnimation)
    }

    private fun intTab() {
        setTabAdapter()
        binding.viewpager.adapter = PageAdapter(this, supportFragmentManager, tabList)
        binding.viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {

            }

            override fun onPageSelected(position: Int) {
                tabSelect = position
                if (tabAdapter != null)
                    if (tabSelect != tabAdapter!!.selectTab) {
                        val p = tabAdapter!!.selectTab
                        tabAdapter!!.selectTab = tabSelect
                        tabAdapter!!.notifyItemChanged(tabSelect)
                        tabAdapter!!.notifyItemChanged(p)
                        binding.rvTab.scrollToPosition(position)
                    }
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
    }

    private fun setTabAdapter() {
        tabAdapter = TabAdapter(this, tabList, clickListener = {
            binding.viewpager.currentItem = it
        })
        binding.rvTab.adapter = tabAdapter
    }

    private fun getTabList() {
        tabList.clear()
        val folder = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath
                    + File.separator + getString(R.string.app_name)
        )

        if (folder.exists()) {
            val listFile = folder.listFiles()
            if (!listFile.isNullOrEmpty())
                for (file in listFile) {
                    if (file.isDirectory) {
                        Log.e("", "file name==>> ${file.name}")
                        val type =
                            if (file.name.equals(Constant.FOLDER_INSTAGRAM)) Constant.DOWNLOAD_INSTAGRAM
                            else if (file.name.equals(Constant.FOLDER_FACEBOOK)) Constant.DOWNLOAD_FACEBOOK
                            else if (file.name.equals(Constant.FOLDER_WHATSAPP)) Constant.DOWNLOAD_WHATSAPP
                            else if (file.name.equals(Constant.FOLDER_TWITTER)) Constant.DOWNLOAD_TWITTER
                            else if (file.name.equals(Constant.FOLDER_DP_CREATE)) Constant.DOWNLOAD_DP_CREATE
                            else if (file.name.equals(Constant.FOLDER_DP_DOWNLOADER)) Constant.DOWNLOAD_DP_DOWNLOADER
                            else ""
                        if (type.isNotEmpty())
                            tabList.add(TabData(file.name, type))
                    }
                }
        }
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener { onBackPressed() }

    }

    override fun onDestroy() {
        super.onDestroy()
//        if (binding.frameNative.childCount != 0) {
//            MyApplication.storageCommon?.nativeAdsDownload?.postValue(null)
//        }
    }

    class PageAdapter(
        var activity: Activity,
        fm: FragmentManager,
        var tabList: ArrayList<TabData>
    ) :
        FragmentPagerAdapter(fm) {
        override fun getCount(): Int {
            return tabList.size
        }

        override fun getItem(position: Int): Fragment {
            return DownloadFragment.newInstance(activity, tabList[position].type)
        }
    }
}