package com.quickstream.downloadmaster.browser.ui.data

data class BrowserTab(var tabTitle:String)
