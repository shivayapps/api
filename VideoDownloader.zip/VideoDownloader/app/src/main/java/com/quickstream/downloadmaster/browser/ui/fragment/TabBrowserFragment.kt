package com.quickstream.downloadmaster.browser.ui.fragment

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.RenderProcessGoneDetail
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.webkit.ProxyConfig

import com.arasthel.asyncjob.AsyncJob
import com.bumptech.glide.Glide
import com.google.firebase.analytics.FirebaseAnalytics
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.browser.event.StartDownloadEvent
import com.quickstream.downloadmaster.browser.databinding.DialogDownloadBinding
import com.quickstream.downloadmaster.browser.databinding.DialogLoaderBinding
import com.quickstream.downloadmaster.browser.databinding.DialogRenameBinding
import com.quickstream.downloadmaster.browser.databinding.DialogSaveBinding
import com.quickstream.downloadmaster.browser.databinding.FragmentTabBrowserBinding
import com.quickstream.downloadmaster.browser.ui.activity.PermissionActivity
import com.quickstream.downloadmaster.browser.ui.data.DownloadData
import com.quickstream.downloadmaster.browser.ui.interfaces.AdsLoadCall
import com.quickstream.downloadmaster.browser.utils.Constant
import com.quickstream.downloadmaster.browser.utils.DownloadManager
import com.quickstream.downloadmaster.browser.utils.MyApplication
import com.quickstream.downloadmaster.browser.utils.Preferences
import com.quickstream.downloadmaster.browser.utils.UtilsAd
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.apache.commons.io.FilenameUtils
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL
import java.text.DecimalFormat
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import kotlin.math.log10
import kotlin.math.pow


private const val ARG_PARAM1 = "currUrl"
private const val ARG_PARAM2 = "openType"

class TabBrowserFragment() : Fragment() {

    private var currUrl: String = ""
    private var openType: String = ""
    lateinit var binding: FragmentTabBrowserBinding
    var myChrome: MyChrome? = null
    var pageBodyGrabber: JavaScriptPseudoInterface? = null
    private var htmlBodyInProcess = false
    private var firstPageLoadingCompleteSkiped = false
    var anyFilesDownloadModels: ArrayList<com.quickstream.downloadmaster.browser.browser.helpers.AnyDownloadModel> =
        ArrayList()
    var loadingFinished = true
    var fbContainers: ArrayList<com.quickstream.downloadmaster.browser.browser.helpers.FBContainerModel> =
        ArrayList()
    var instaPosts: ArrayList<com.quickstream.downloadmaster.browser.browser.helpers.InstaPostModel> =
        ArrayList()
    lateinit var webViewClient: MyWebViewClient
    var loaderDialog: Dialog? = null
    var loginDialog: LoginDialog? = null
    private var adsLoadCall: AdsLoadCall? = null
    val reelVideoList: HashMap<String, String> = hashMapOf()
    lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            currUrl = it.getString(ARG_PARAM1).toString()
            openType = it.getString(ARG_PARAM2).toString()
        }
        EventBus.getDefault().register(this)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTabBrowserBinding.inflate(layoutInflater, container, false)
        inits()
        intDialog()
        return binding.root
    }

    private fun inits() {
        binding.btnFabDownload.visibility = View.GONE
        webViewClient = MyWebViewClient(this)
        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())

        val preferences = Preferences(requireActivity())
        if (!preferences.getInstagramCookies().isNullOrEmpty())
            CookieManager.getInstance()
                .setCookie("www.instagram.com", preferences.getInstagramCookies())
        if (!preferences.getFbCookies().isNullOrEmpty())
            CookieManager.getInstance().setCookie("www.facebook.com", preferences.getFbCookies())

        val bundle2 = Bundle()
        if (openType == Constant.TYPE_Insta) {
            bundle2.putString("BrowserDownload_screen", "InstaBrowserDownload_screen_open")
            firebaseAnalytics.logEvent("InstaBrowserDownload_screen_open", bundle2)
        } else {
            bundle2.putString("BrowserDownload_screen", "FacebookBrowserDownload_screen_open")
            firebaseAnalytics.logEvent("FacebookBrowserDownload_screen_open", bundle2)
        }


        setupWebView()
        setupHiddenWebView()
        binding.swipeRefresh.isRefreshing = false
        binding.swipeRefresh.isEnabled = false
        binding.swipeRefresh.setOnRefreshListener { binding.swipeRefresh.isRefreshing = false }
        binding.browserWv.viewTreeObserver.addOnScrollChangedListener { }
        val hashMap = getCustomHeaders()
        if (hashMap.isEmpty())
            binding.browserWv.loadUrl(currUrl)
        else
            binding.browserWv.loadUrl(currUrl, hashMap)

        binding.btnFabDownload.setOnClickListener {
            val downloadUrl = reelVideoList[currUrl]
            if (!downloadUrl.isNullOrEmpty()) {
                getReelsDownload(downloadUrl)
            }
        }
    }


    fun setAdsLoadCall(adsLoadCallListener: AdsLoadCall) {
        adsLoadCall = adsLoadCallListener
    }


    private fun setLoadNativeAd() {
        if (adsLoadCall != null)
            adsLoadCall!!.isLoadNativeAds()
    }

    private fun intDialog() {
        val dialogBinding = DialogLoaderBinding.inflate(layoutInflater)
        loaderDialog = Dialog(requireActivity(), R.style.Theme_Dialog)
        loaderDialog!!.window?.requestFeature(Window.FEATURE_NO_TITLE)
        loaderDialog!!.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        loaderDialog!!.setCancelable(false)
        loaderDialog!!.setCanceledOnTouchOutside(false)
        loaderDialog!!.setContentView(dialogBinding.root)
        loginDialog = LoginDialog(requireActivity(), onLoginListener = {

        })

    }

    private fun showInstaLoginDialog() {
        try {
            if (requireActivity() != null)
                if (!requireActivity().isFinishing)
                    if (loginDialog != null)
                        if (!loginDialog?.isShowing!!)
                            loginDialog?.show()
        } catch (_: Exception) {

        }
    }

    private fun showLoadingDialog() {
        if (loaderDialog != null)
            loaderDialog!!.show()
    }

    private fun dismissLoadingDialog() {

        try {
            if (loaderDialog != null)
                if (loaderDialog!!.isShowing)
                    loaderDialog!!.dismiss()
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("", "Exception message==>> " + e.message)

        }

    }

    private fun setupWebView() {
        val settings: WebSettings = binding.browserWv.settings
        settings.javaScriptEnabled = true
        settings.javaScriptCanOpenWindowsAutomatically = true
        settings.setRenderPriority(WebSettings.RenderPriority.HIGH)
        settings.loadsImagesAutomatically = true
        settings.allowContentAccess = true
        settings.setGeolocationEnabled(true)
        settings.setSupportMultipleWindows(false)
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.saveFormData = true
        binding.browserWv.setLayerType(WebView.LAYER_TYPE_HARDWARE, null)
        settings.domStorageEnabled = true
        binding.browserWv.isClickable = true
        val str = currUrl
        if (str != null) {
            if ((str.lowercase(Locale.getDefault()).contains("vimeo.com") || currUrl.lowercase(
                    Locale.getDefault()
                ).contains("twitter.com") || currUrl.lowercase(
                    Locale.getDefault()
                )
                    .contains("vk.com")) && (currUrl.contains(Constant.HTTP) || currUrl.contains(
                    Constant.HTTPS
                ))
            ) {
                settings.userAgentString =
                    "Mozilla/5.0 (Linux; Android 8.0.0; Nexus 5X Build/OPR4.170623.006) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Mobile Safari/537.36"
            } else if (currUrl.lowercase(Locale.getDefault())
                    .contains("youtube.com") && (currUrl.contains(Constant.HTTP) || currUrl.contains(
                    Constant.HTTPS
                ))
            ) {
                settings.userAgentString =
                    "Mozilla/5.0 (Android 13; Mobile; rv:109.0) Gecko/114.0 Firefox/114.0"
            } else if ((currUrl.lowercase(Locale.getDefault())
                    .contains("facebook.com") || currUrl.lowercase(
                    Locale.getDefault()
                ).contains("fb.watch")) && (currUrl.contains(Constant.HTTP) || currUrl.contains(
                    Constant.HTTPS
                ))
            ) {
                settings.userAgentString =
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/600.2.5 (KHTML, like Gecko) Version/8.0.2 Safari/600.2.5 (Amazonbot/0.1; +https://developer.amazon.com/support/amazonbot)"
                //                settings.setUserAgentString("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.60 Safari/537.36");
            } else {
                settings.userAgentString =
                    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1"
            }
        } else {
            settings.userAgentString =
                "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1"
        }
        val javaScriptPseudoInterface = JavaScriptPseudoInterface()
        this.pageBodyGrabber = javaScriptPseudoInterface
        javaScriptPseudoInterface.setCurrentUrl(currUrl)
        binding.browserWv.addJavascriptInterface(pageBodyGrabber!!, "HTMLOUT")
        val myChrome = MyChrome(this)
        this.myChrome = myChrome
        binding.browserWv.webChromeClient = myChrome
        binding.browserWv.webViewClient = webViewClient
        binding.browserWv.setPadding(0, 0, 0, 0)
    }

    fun getCustomHeaders(): HashMap<String, String> {
        val hashMap = HashMap<String, String>()
        val str = currUrl
        if (str != null) {
            if ((str.lowercase(Locale.getDefault()).contains("vimeo.com") || currUrl.lowercase(
                    Locale.getDefault()
                ).contains("twitter.com") || currUrl.lowercase(
                    Locale.getDefault()
                )
                    .contains("vk.com")) && (currUrl.contains(Constant.HTTP) || currUrl.contains(
                    Constant.HTTPS
                ))
            ) {
                hashMap["referer"] = "https://www.google.com/"
                hashMap["User-Agent"] =
                    "Mozilla/5.0 (Linux; Android 8.0.0; Nexus 5X Build/OPR4.170623.006) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Mobile Safari/537.36"
            } else if (currUrl.lowercase(Locale.getDefault())
                    .contains("youtube.com") && (currUrl.contains(Constant.HTTP) || currUrl.contains(
                    Constant.HTTPS
                ))
            ) {
                hashMap["referer"] = "https://www.google.com/"
                hashMap["User-Agent"] = System.getProperty("http.agent")
            } else if ((currUrl.lowercase(Locale.getDefault())
                    .contains("facebook.com") || currUrl.lowercase(
                    Locale.getDefault()
                ).contains("fb.watch")) && (currUrl.contains(Constant.HTTP) || currUrl.contains(
                    Constant.HTTPS
                ))
            ) {

                hashMap["User-Agent"] =
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/600.2.5 (KHTML, like Gecko) Version/8.0.2 Safari/600.2.5 (Amazonbot/0.1; +https://developer.amazon.com/support/amazonbot)"
            } else {
                hashMap["User-Agent"] =
                    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1"
            }
        } else {
            hashMap["referer"] = "https://www.google.com/"
            hashMap["User-Agent"] =
                "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1"
        }
        return hashMap
    }

    class MyWebViewClient(
        var browserActivity: TabBrowserFragment
    ) : WebViewClient() {

        override fun onRenderProcessGone(
            webView: WebView,
            renderProcessGoneDetail: RenderProcessGoneDetail
        ): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                !renderProcessGoneDetail.didCrash()
            } else false
        }

        override fun onPageStarted(webView: WebView, str: String, bitmap: Bitmap?) {
            Log.e("WebDecodeData", "MyWebViewClient onPageStarted url==>> $str")
            browserActivity.loadingFinished = false
            EventBus.getDefault()
                .post(
                    com.quickstream.downloadmaster.browser.browser.event.global_any_download_button.ChangeGlobalAnyDownloadButtonVisibilityEvent(
                        false,
                        false,
                        arrayListOf()
                    )
                );
            super.onPageStarted(webView, str, bitmap)
        }

        override fun onPageFinished(webView: WebView, str: String) {
            Log.e("WebDecodeData ", "MyWebViewClient onPageFinished url==>> $str")
            if (browserActivity.currUrl.lowercase(Locale.getDefault())
                    .contains("vimeo.com/log_in") || browserActivity.currUrl.lowercase(
                    Locale.getDefault()
                ).contains("vimeo.com/join")
            ) {
                AsyncJob.doOnMainThread {
                    browserActivity.currUrl = "https://vimeo.com/watch"
                    browserActivity.binding.browserWv.loadUrl(browserActivity.currUrl)
                }
            }
        }

        override fun onLoadResource(webView: WebView, str: String) {
            if (!str.lowercase(Locale.getDefault()).contains("/logging/falco")) {
                if (str.lowercase(Locale.getDefault())
                        .contains("vkvd") && str.lowercase(Locale.getDefault())
                        .contains(".mycdn.me/") || str.lowercase(
                        Locale.getDefault()
                    ).contains("vkuser.net") && str.lowercase(Locale.getDefault())
                        .contains("expires=")
                ) {
                    browserActivity.anyFilesDownloadModels.add(
                        com.quickstream.downloadmaster.browser.browser.helpers.AnyDownloadModel(
                            com.quickstream.downloadmaster.browser.browser.helpers.AnyDownloadModel.AnyFileType.VIDEO,
                            str,
                            "",
                            FilenameUtils.getBaseName(
                                URLUtil.guessFileName(str, null, null)
                            ),
                            "mp4"
                        )
                    )
                    EventBus.getDefault().post(
                        com.quickstream.downloadmaster.browser.browser.event.global_any_download_button.ChangeGlobalAnyDownloadButtonVisibilityEvent(
                            true,
                            true,
                            browserActivity.anyFilesDownloadModels
                        )
                    )
                } else if (!str.lowercase(Locale.getDefault())
                        .contains("facebook") && !str.lowercase(
                        Locale.getDefault()
                    ).contains("youtube") && !str.lowercase(Locale.getDefault())
                        .contains("instagram") && !str.lowercase(
                        Locale.getDefault()
                    ).contains("vimeo") && !str.lowercase(Locale.getDefault())
                        .contains("pinterest") && !str.lowercase(
                        Locale.getDefault()
                    ).contains("pinimg.com/videos") && FilenameUtils.getExtension(
                        URLUtil.guessFileName(str, null, null)
                    ).equals("m3u8", ignoreCase = true)
                ) {


                }
            }
            super.onLoadResource(webView, str)

            val url = webView.url

            if (url!!.contains("instagram.com/reels") && browserActivity.currUrl.contains("instagram.com/reels")) {
                val fileExtensionFromUrl3 = MimeTypeMap.getFileExtensionFromUrl(str)
                val mimeTypeFromExtension3 =
                    MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtensionFromUrl3)
                if (mimeTypeFromExtension3 != null)
                    if (mimeTypeFromExtension3.startsWith("video")) {
                        Log.e(
                            "WebDecodeData",
                            "MyWebViewClient onLoadResource current url==>> $url"
                        )
                        Log.e(
                            "WebDecodeData",
                            "MyWebViewClient onLoadResource Base current url==>> ${browserActivity.currUrl}"
                        )
                        Log.e("WebDecodeData", "MyWebViewClient onLoadResource video url==>> $str")
                        browserActivity.reelVideoList[url] = str
                        browserActivity.binding.btnFabDownload.visibility = View.VISIBLE
                    }
            }
        }

        override fun shouldInterceptRequest(
            webView: WebView,
            webResourceRequest: WebResourceRequest
        ): WebResourceResponse? {
            if (webResourceRequest.url != null && webResourceRequest.url.path != null) {
                if (webResourceRequest.url.toString()
                        .contains("pinterest.com/resource/RelatedStreamResource/get/?source_url")
                ) {
                    browserActivity.anyFilesDownloadModels.clear()
                    EventBus.getDefault().post(
                        com.quickstream.downloadmaster.browser.browser.event.global_any_download_button.ChangeGlobalAnyDownloadButtonVisibilityEvent(
                            true,
                            false,
                            browserActivity.anyFilesDownloadModels
                        )
                    )
                    browserActivity.hiddenLoadPinterestUrl(
                        webResourceRequest.url.host + webResourceRequest.url.getQueryParameter(
                            "source_url"
                        )
                    )
                }
                if (webResourceRequest.url.path!!.lowercase(Locale.getDefault())
                        .contains("youtubei/v1/browse") || webResourceRequest.url.path!!
                        .lowercase(Locale.getDefault())
                        .contains("/youtubei/v1/search") || webResourceRequest.url.path!!
                        .lowercase(Locale.getDefault())
                        .contains("/logging/falco") || webResourceRequest.url.path!!
                        .lowercase(Locale.getDefault())
                        .contains("/ajax/bz") || webResourceRequest.url.path!!
                        .lowercase(Locale.getDefault())
                        .contains("/logging_client_events") || webResourceRequest.url.path!!
                        .lowercase(Locale.getDefault())
                        .contains("/a/bz") || webResourceRequest.url.path!!
                        .lowercase(Locale.getDefault())
                        .contains("/feed/badge/") || webResourceRequest.url.path!!
                        .lowercase(Locale.getDefault())
                        .contains("/v/t") || webResourceRequest.url.path!!
                        .lowercase(Locale.getDefault())
                        .contains("/g/collect") || webResourceRequest.url.path!!
                        .lowercase(Locale.getDefault())
                        .contains("/collect") || webResourceRequest.url.toString().lowercase(
                        Locale.getDefault()
                    ).contains("pinterest.com")
                ) {
                    browserActivity.processHTML(true)
                }
            }
            return super.shouldInterceptRequest(webView, webResourceRequest)
        }
    }

    var isShowDownloadDialog = false
    private fun showDownloadDialog(downloadData: DownloadData, isShowReName: Boolean = false) {
        dismissLoadingDialog()
        if (!isShowDownloadDialog) {
            isShowDownloadDialog = true

            val bundle2 = Bundle()
            bundle2.putString("BrowserDownload_screen", "browserDownload_download_dialog_open")
            firebaseAnalytics.logEvent("browserDownload_download_dialog_open", bundle2)

            val dialogBinding = DialogSaveBinding.inflate(layoutInflater)
            val dialog = Dialog(requireActivity(), R.style.Theme_Dialog_full)
            dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window?.setGravity(Gravity.BOTTOM)
            dialog.setCancelable(false)

            dialog.setCanceledOnTouchOutside(false)
            dialog.setContentView(dialogBinding.root)

            dialogBinding.txtName.text = downloadData.posterId
            dialogBinding.txtFileSize.text = downloadData.fileSize.formatSize()
            dialogBinding.checkbox.isChecked = downloadData.isChecked
            dialogBinding.imageType.setImageDrawable(
                ContextCompat.getDrawable(
                    requireContext(),
                    if (downloadData.fileType == Constant.TYPE_IMAGE) R.drawable.ic_image else R.drawable.ic_video
                )
            )

            Glide.with(requireActivity())
                .load(downloadData.url)
                .placeholder(
                    ContextCompat.getDrawable(
                        requireActivity(),
                        R.drawable.bg_placeholder
                    )
                )
                .into(dialogBinding.imgDisplay)

            if (dialogBinding.frameNative.childCount == 0) {
                dialogBinding.frameNative.visibility = View.VISIBLE
//                NativeLoadWithShows(requireActivity()).showNativeAdsShimmerEffects(requireActivity(), dialogBinding.frameNative, 3)
//                NativeLoadWithShows(requireActivity()).showNativeTopAlways(requireActivity(),dialogBinding.frameNative)
                UtilsAd.showNative(requireActivity(),dialogBinding.frameNative)
            }

            dialogBinding.btnRename.setOnClickListener {
                downloadData.isChecked = dialogBinding.checkbox.isChecked
                dialog.dismiss()
                val renameDialogBinding = DialogRenameBinding.inflate(layoutInflater)
                val renameDialog = Dialog(requireActivity(), R.style.Theme_Dialog_full)
                renameDialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
                renameDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                renameDialog.window?.setGravity(Gravity.BOTTOM)
                renameDialog.setCancelable(false)

                renameDialog.setCanceledOnTouchOutside(false)
                renameDialog.setContentView(renameDialogBinding.root)

                renameDialogBinding.edtFileName.setText(downloadData.posterId)

                renameDialogBinding.tvYes.setOnClickListener {
                    val fileName = renameDialogBinding.edtFileName.text.trim().toString()
                    if (fileName.isNotEmpty()) {
                        val downloadManager = DownloadManager(requireActivity())
                        if (!downloadManager.checkFileDownload(
                                openType,
                                fileName,
                                downloadData.fileType
                            )
                        ) {
                            downloadData.posterId = fileName
                            renameDialog.dismiss()
                            dialogBinding.txtName.text = downloadData.posterId
                            dialog.show()
                        } else
                            Toast.makeText(
                                requireActivity(),
                                getString(R.string.file_name_exists),
                                Toast.LENGTH_SHORT
                            )
                                .show()
                    } else {
                        Toast.makeText(
                            requireActivity(),
                            getString(R.string.file_validation),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
                renameDialogBinding.tvNo.setOnClickListener {
                    renameDialog.dismiss()
                    dialog.show()
                }

                renameDialog.show()
            }

            dialogBinding.tvYes.setOnClickListener {
                if (dialogBinding.checkbox.isChecked) {
                    val fileName = downloadData.posterId
                    val downloadManager = DownloadManager(requireActivity())
                    if (!downloadManager.checkFileDownload(
                            openType,
                            fileName,
                            downloadData.fileType
                        )
                    ) {
                        if (checkStoragePermissions()) {
                            downloadData.posterId = fileName
                            downloadData.openType = openType
                            downloadData.downloadId = System.currentTimeMillis()
                            dialog.dismiss()
                            isShowDownloadDialog = false
                            setLoadNativeAd()
                            Toast.makeText(
                                requireActivity(),
                                "Start downloading",
                                Toast.LENGTH_SHORT
                            )
                                .show()
                            EventBus.getDefault().post(StartDownloadEvent(downloadData))
                        } else {
                            val intent = Intent(
                                requireActivity(),
                                PermissionActivity::class.java
                            )
                            permissionLauncher.launch(intent)
                        }
                    } else
                        Toast.makeText(
                            requireActivity(),
                            getString(R.string.file_name_exists),
                            Toast.LENGTH_SHORT
                        )
                            .show()
                } else {
                    Toast.makeText(
                        requireActivity(),
                        getString(R.string.file_selection),
                        Toast.LENGTH_SHORT
                    )
                        .show()
                }
            }

            dialogBinding.tvNo.setOnClickListener {
                dialog.dismiss()
                isShowDownloadDialog = false
                setLoadNativeAd()
            }

            dialog.show()
        }
    }


    fun Long.formatSize(): String {
        if (this <= 0) {
            return "0 B"
        }

        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (log10(toDouble()) / log10(1024.0)).toInt()
        return "${
            DecimalFormat("#,##0.#").format(
                this / 1024.0.pow(digitGroups.toDouble())
            )
        } ${units[digitGroups]}"
    }

    private fun showDialogRename(downloadData: DownloadData) {
        val renameDialogBinding = DialogRenameBinding.inflate(layoutInflater)
        val renameDialog = Dialog(requireActivity(), R.style.Theme_Dialog_full)
        renameDialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
        renameDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        renameDialog.window?.setGravity(Gravity.BOTTOM)
        renameDialog.setCancelable(false)

        renameDialog.setCanceledOnTouchOutside(false)
        renameDialog.setContentView(renameDialogBinding.root)

        renameDialogBinding.edtFileName.setText(downloadData.posterId)

        renameDialogBinding.tvYes.setOnClickListener {
            val fileName = renameDialogBinding.edtFileName.text.trim().toString()
            if (fileName.isNotEmpty()) {
                val downloadManager = DownloadManager(requireActivity())
                if (!downloadManager.checkFileDownload(openType, fileName, downloadData.fileType)) {
                    downloadData.posterId = fileName
                    renameDialog.dismiss()
                    showDownloadDialog(downloadData, true)
                } else
                    Toast.makeText(
                        requireActivity(),
                        getString(R.string.file_name_exists),
                        Toast.LENGTH_SHORT
                    )
                        .show()
            } else {
                Toast.makeText(
                    requireActivity(),
                    getString(R.string.file_validation),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        renameDialogBinding.tvNo.setOnClickListener {
            renameDialog.dismiss()
            showDownloadDialog(downloadData, true)
        }

        renameDialog.show()
    }

    var permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {

            }
        }


    fun checkStoragePermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                requireActivity(),
                android.Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                requireActivity(),
                android.Manifest.permission.READ_MEDIA_VIDEO
            ) == PackageManager.PERMISSION_GRANTED
        } else
            ActivityCompat.checkSelfPermission(
                requireActivity(),
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
    }

    private fun setupHiddenWebView() {
        val settings: WebSettings = binding.hiddenBrowserWv.settings
        settings.javaScriptEnabled = true
        settings.javaScriptCanOpenWindowsAutomatically = true
        settings.setRenderPriority(WebSettings.RenderPriority.HIGH)
        settings.loadsImagesAutomatically = true
        settings.allowContentAccess = true
        settings.setGeolocationEnabled(true)
        settings.setSupportMultipleWindows(false)
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.saveFormData = true
        binding.hiddenBrowserWv.setLayerType(WebView.LAYER_TYPE_HARDWARE, null)
        settings.domStorageEnabled = true
        binding.hiddenBrowserWv.isClickable = true
        val str = currUrl
        if (str != null) {
            if ((str.lowercase(Locale.getDefault()).contains("vimeo.com") || currUrl.lowercase(
                    Locale.getDefault()
                ).contains("twitter.com") || currUrl.lowercase(
                    Locale.getDefault()
                )
                    .contains("vk.com")) && (currUrl.contains(Constant.HTTP) || currUrl.contains(
                    Constant.HTTPS
                ))
            ) {
                settings.userAgentString =
                    "Mozilla/5.0 (Linux; Android 8.0.0; Nexus 5X Build/OPR4.170623.006) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Mobile Safari/537.36"
            } else if (currUrl.lowercase(Locale.getDefault())
                    .contains("youtube.com") && (currUrl.contains(Constant.HTTP) || currUrl.contains(
                    Constant.HTTPS
                ))
            ) {
                settings.userAgentString =
                    "Mozilla/5.0 (Android 13; Mobile; rv:109.0) Gecko/114.0 Firefox/114.0"
            } else if ((currUrl.lowercase(Locale.getDefault())
                    .contains("facebook.com") || currUrl.lowercase(
                    Locale.getDefault()
                ).contains("fb.watch")) && (currUrl.contains(Constant.HTTP) || currUrl.contains(
                    Constant.HTTPS
                ))
            ) {
                settings.userAgentString =
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/600.2.5 (KHTML, like Gecko) Version/8.0.2 Safari/600.2.5 (Amazonbot/0.1; +https://developer.amazon.com/support/amazonbot)"
            } else {
                settings.userAgentString =
                    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1"
            }
        } else {
            settings.userAgentString =
                "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1"
        }
        settings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
        settings.domStorageEnabled = true
        settings.setRenderPriority(WebSettings.RenderPriority.HIGH)
        binding.hiddenBrowserWv.webChromeClient = object :
            WebChromeClient() {
        }
        binding.hiddenBrowserWv.setPadding(0, 0, 0, 0)
    }

    class JavaScriptPseudoInterface internal constructor() {
        private var asyncJob: AsyncJob<Boolean>? = null
        private var currentUrl = ""
        var currentDomain = ""
        var currentPageBody = ""
        private var buttonsIntegrator: com.quickstream.downloadmaster.browser.browser.helpers.ButtonsIntegrator =
            com.quickstream.downloadmaster.browser.browser.helpers.ButtonsIntegrator()
        private var anyFilesParser: com.quickstream.downloadmaster.browser.browser.helpers.AnyFilesParser =
            com.quickstream.downloadmaster.browser.browser.helpers.AnyFilesParser()

        @JavascriptInterface
        fun processHTML(str: String) {
            currentPageBody = str
            val asyncJob = asyncJob
            asyncJob?.cancel()
            buttonsIntegrator.stopTasks()
            buttonsIntegrator =
                com.quickstream.downloadmaster.browser.browser.helpers.ButtonsIntegrator()
            anyFilesParser.stopTasks()
            anyFilesParser =
                com.quickstream.downloadmaster.browser.browser.helpers.AnyFilesParser()
            Log.e(
                "dataDetect",
                "JavaScriptPseudoInterface processHTML ==>> currentUrl $currentUrl "
            )
            val newSingleThreadExecutor = Executors.newSingleThreadExecutor()
            val create: AsyncJob<Boolean> = AsyncJob.AsyncJobBuilder<Boolean>().doInBackground(
                AsyncJob.AsyncAction<Boolean> {
                    if (!currentUrl.lowercase(Locale.getDefault()).contains("youtube")) {
                        if (currentUrl.lowercase(Locale.getDefault()).contains("instagram")
                            && !currentUrl.lowercase(Locale.getDefault())
                                .contains("instagram.com/reels")
                        ) {
                            Log.e(
                                "dataDetect",
                                "JavaScriptPseudoInterface integrateButtonsToInstagram "
                            )
                            buttonsIntegrator.integrateButtonsToInstagram(str,
                                currentDomain,
                                currentUrl,
                                object :
                                    com.quickstream.downloadmaster.browser.browser.ui_events.ButtonsIntegratingStateHandler {
                                    override fun OnComplete_FB(list: List<com.quickstream.downloadmaster.browser.browser.helpers.FBContainerModel?>?) {
                                        Log.e("integrateDataFetch", "OnComplete_FB")
                                    }

                                    override fun OnComplete_YT(
                                        str2: String?,
                                        list: List<com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel?>?,
                                        list2: List<com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel?>?,
                                        downloadYTVideoButtonModel: com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel?
                                    ) {
                                        Log.e("integrateDataFetch", "OnComplete_YT")
                                    }

                                    override fun OnComplete_Insta(list: List<com.quickstream.downloadmaster.browser.browser.helpers.InstaPostModel?>?) {
                                        Log.e("integrateDataFetch", "OnComplete_Insta")
                                        EventBus.getDefault().post(
                                            com.quickstream.downloadmaster.browser.browser.event.NeedModifyInstaHtmlEvent(
                                                list
                                            )
                                        )
                                    }

                                    override fun OnError(str2: String?) {
                                        Log.e("integrateDataFetch", "OnError $str2")
                                        Log.i("IntegrateButtonsToInstagram", str2!!)
                                    }
                                })
                        } else if (currentUrl.lowercase(Locale.getDefault()).contains("facebook")) {
                            buttonsIntegrator.integrateButtonsToFacebook(str,
                                currentDomain,
                                currentUrl,
                                object :
                                    com.quickstream.downloadmaster.browser.browser.ui_events.ButtonsIntegratingStateHandler {
                                    override fun OnComplete_Insta(list: List<com.quickstream.downloadmaster.browser.browser.helpers.InstaPostModel?>?) {}
                                    override fun OnComplete_YT(
                                        str2: String?,
                                        list: List<com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel?>?,
                                        list2: List<com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel?>?,
                                        downloadYTVideoButtonModel: com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel?
                                    ) {
                                    }

                                    override fun OnComplete_FB(list: List<com.quickstream.downloadmaster.browser.browser.helpers.FBContainerModel?>) {
                                        Log.e(
                                            "",
                                            "integrateButtonsToFacebook OnComplete_FB==>>> " + list.size
                                        )
                                        EventBus.getDefault().post(
                                            com.quickstream.downloadmaster.browser.browser.event.NeedModifyFBHtmlEvent(
                                                list
                                            )
                                        )
                                    }

                                    override fun OnError(str2: String?) {
                                        Log.e("integrateButtonsToFacebook", "OnError==>> $str2 ")
                                    }
                                })
                        } else if (!currentUrl.lowercase(Locale.getDefault()).contains("vimeo")) {
                            if (currentUrl.lowercase(Locale.getDefault()).contains("pinterest")) {
                                EventBus.getDefault()
                                    .post(com.quickstream.downloadmaster.browser.browser.event.NeedModifyPinterestHtmlEvent())
                            }
                        } else {
                            EventBus.getDefault()
                                .post(com.quickstream.downloadmaster.browser.browser.event.NeedModifyVimeoHtmlEvent())
                        }
                    } else {
                        buttonsIntegrator.integrateButtonsToYoutube(str,
                            currentDomain, currentUrl, object :
                                com.quickstream.downloadmaster.browser.browser.ui_events.ButtonsIntegratingStateHandler {
                                override fun OnComplete_FB(list: List<com.quickstream.downloadmaster.browser.browser.helpers.FBContainerModel?>?) {}
                                override fun OnComplete_Insta(list: List<com.quickstream.downloadmaster.browser.browser.helpers.InstaPostModel?>?) {}
                                override fun OnComplete_YT(
                                    str2: String,
                                    list: List<com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel?>?,
                                    list2: List<com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel?>?,
                                    downloadYTVideoButtonModel: com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel?
                                ) {
                                    currentPageBody = str2
                                    EventBus.getDefault().post(
                                        com.quickstream.downloadmaster.browser.browser.event.NeedModifyYoutubeHtmlEvent(
                                            str,
                                            str2,
                                            downloadYTVideoButtonModel,
                                            list,
                                            list2
                                        )
                                    )
                                }

                                override fun OnError(str2: String?) {
                                    Log.i("IntegrateButtonsToYoutube", str2!!)
                                }
                            })
                    }
                    true
                }).create()
            this.asyncJob = create
            create.executorService = newSingleThreadExecutor
            this.asyncJob!!.start()
        }

        @JavascriptInterface
        fun processYTVideoDownload(str: String) {
            val split = str.split("-".toRegex()).dropLastWhile { it.isEmpty() }
                .toTypedArray()
            if (split.size == 3) {
                if (split[1].lowercase(Locale.getDefault()).contains("shorts")) {
                    EventBus.getDefault().post(
                        com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.YoutubeDownloadBtnClickedEvent(
                            split[2].toInt() - 1,
                            com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel.YTVideoType.SHORT
                        )
                    )
                } else if (split[1].lowercase(Locale.getDefault()).contains("fullvideo")) {
                    EventBus.getDefault().post(
                        com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.YoutubeDownloadBtnClickedEvent(
                            0,
                            com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel.YTVideoType.CLASSIC_VIDEO_FULLY
                        )
                    )
                } else if (split[1].lowercase(Locale.getDefault()).contains("fullshort")) {
                    EventBus.getDefault().post(
                        com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.YoutubeDownloadBtnClickedEvent(
                            0,
                            com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel.YTVideoType.SHORT_FULLY
                        )
                    )
                } else {
                    EventBus.getDefault().post(
                        com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.YoutubeDownloadBtnClickedEvent(
                            split[2].toInt() - 1,
                            com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel.YTVideoType.CLASSIC_VIDEO_LIST
                        )
                    )
                }
            }
        }

        @JavascriptInterface
        fun processInstaDownload(str: String, str2: String?) {
            val split = str.split("-".toRegex()).dropLastWhile { it.isEmpty() }
                .toTypedArray()
            if (split.size == 5) {
                EventBus.getDefault()
                    .post(
                        com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.InstaDownloadBtnClickedEvent(
                            split[2].toInt(),
                            split[4].toInt(),
                            str2
                        )
                    )
            }
        }

        @JavascriptInterface
        fun processFBDownload(str: String) {
            val split = str.split("-".toRegex()).dropLastWhile { it.isEmpty() }
                .toTypedArray()
            if (split.size == 5) {
                EventBus.getDefault()
                    .post(
                        com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.FBDownloadBtnClickedEvent(
                            split[2].toInt(),
                            split[4].toInt()
                        )
                    )
            }
        }

        @JavascriptInterface
        fun processVimeoDownload(str: String) {
            if (str.length > 0) {
                EventBus.getDefault().post(
                    com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.VimeoDownloadBtnClickedEvent(
                        str
                    )
                )
            }
        }

        @JavascriptInterface
        fun processAnyDownload(str: String) {
            str.length
        }

        fun getCurrentUrl(): String {
            return currentUrl
        }

        fun setCurrentUrl(str: String) {
            try {
                val url = URL(str)
                currentDomain = url.protocol + "://" + url.host
            } catch (e: MalformedURLException) {
                e.printStackTrace()
            }
            currentUrl = str
        }
    }

    class MyChrome internal constructor(val browserActivity: TabBrowserFragment) :
        WebChromeClient() {
        private var mCustomView: View? = null
        private var mCustomViewCallback: CustomViewCallback? = null
        private var mFullscreenContainer: FrameLayout? = null
        private val mOriginalOrientation = 0
        private val mOriginalSystemUiVisibility = 0

        override fun onReceivedIcon(webView: WebView, bitmap: Bitmap) {
            super.onReceivedIcon(webView, bitmap)
            EventBus.getDefault().post(
                com.quickstream.downloadmaster.browser.browser.page_loading.OnUrlLoadedAtCurrentTabEvent(
                    browserActivity.binding.browserWv.getTitle(),
                    bitmap
                )
            )
        }


        override fun onProgressChanged(webView: WebView, i: Int) {
            val url = webView.url
            if (url!!.contains("instagram.com/reels") && browserActivity.currUrl.contains("instagram.com/reels") && !url.equals(
                    browserActivity.currUrl,
                    ignoreCase = true
                )
            ) {
                browserActivity.currUrl = url

                if (browserActivity.reelVideoList.containsKey(browserActivity.currUrl)) {
                    browserActivity.binding.btnFabDownload.visibility = View.VISIBLE
                } else {
                    browserActivity.binding.btnFabDownload.visibility = View.GONE
                }

                Log.e("WebDecodeData ", "MyChrome onProgressChanged $i url==>> $url")

                return
            } else {
                if (browserActivity.reelVideoList.containsKey(browserActivity.currUrl)) {
                    browserActivity.binding.btnFabDownload.visibility = View.VISIBLE
                } else {
                    browserActivity.binding.btnFabDownload.visibility = View.GONE
                }
            }

            EventBus.getDefault().post(
                com.quickstream.downloadmaster.browser.browser.ui_events.ChangeWebProgressBarEvent(
                    i
                )
            )
            if (i >= 100) {
                browserActivity.currUrl = url
                Log.e(
                    "dataDetect",
                    "MyChrome onProgressChanged ${browserActivity.currUrl}"
                )
                browserActivity.pageBodyGrabber!!.setCurrentUrl(browserActivity.currUrl)

                if (url.contains("https://www.instagram.com/accounts/login/"))
                    browserActivity.showInstaLoginDialog()

                if (!browserActivity.firstPageLoadingCompleteSkiped) {
                    browserActivity.firstPageLoadingCompleteSkiped = true
                } else {
                    if (!browserActivity.currUrl.lowercase(Locale.getDefault())
                            .contains("vimeo.com") && !browserActivity.currUrl.lowercase(
                            Locale.getDefault()
                        ).contains("twitter.com") && !browserActivity.currUrl.lowercase(
                            Locale.getDefault()
                        )
                            .contains("vk.com") || !browserActivity.currUrl.contains(Constant.HTTP) && !browserActivity.currUrl.contains(
                            Constant.HTTPS
                        )
                    ) {
                        if (!browserActivity.currUrl.lowercase(Locale.getDefault())
                                .contains("youtube.com") || !browserActivity.currUrl.contains(
                                Constant.HTTP
                            ) && !browserActivity.currUrl.contains(Constant.HTTPS)
                        ) {
                            if ((browserActivity.currUrl.lowercase(Locale.getDefault())
                                    .contains("facebook.com") || browserActivity.currUrl.lowercase(
                                    Locale.getDefault()
                                )
                                    .contains("fb.watch")) && (browserActivity.currUrl.contains(
                                    Constant.HTTP
                                ) || browserActivity.currUrl.contains(Constant.HTTPS))
                            ) {
                                browserActivity.binding.browserWv.settings.userAgentString =
                                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/600.2.5 (KHTML, like Gecko) Version/8.0.2 Safari/600.2.5 (Amazonbot/0.1; +https://developer.amazon.com/support/amazonbot)"
                            } else {
                                browserActivity.binding.browserWv.settings.userAgentString =
                                    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1"
                            }
                        } else {
                            browserActivity.binding.browserWv.settings.userAgentString =
                                "Mozilla/5.0 (Android 13; Mobile; rv:109.0) Gecko/114.0 Firefox/114.0"
                        }
                    } else {
                        browserActivity.binding.browserWv.settings.userAgentString =
                            System.getProperty("Mozilla/5.0 (Linux; Android 8.0.0; Nexus 5X Build/OPR4.170623.006) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Mobile Safari/537.36")
                    }
                    browserActivity.processHTML(true)
                }
                EventBus.getDefault()
                    .post(com.quickstream.downloadmaster.browser.browser.page_loading.PageLoadedEvent())
                EventBus.getDefault().post(
                    com.quickstream.downloadmaster.browser.browser.event.global_download_button.ChangeGlobalDownloadButtonVisibilityEvent(
                        false
                    )
                )
                browserActivity.binding.swipeRefresh.isRefreshing = false
            } else {
                Log.e(
                    "MyWebViewClient",
                    "onProgressChanged $i else url==>> ${url}"
                )
                browserActivity.firstPageLoadingCompleteSkiped = false
                AsyncJob.doOnMainThread {
                    browserActivity.binding.hiddenBrowserWv.stopLoading()
                }
                browserActivity.anyFilesDownloadModels.clear()
                EventBus.getDefault().post(
                    com.quickstream.downloadmaster.browser.browser.event.global_any_download_button.ChangeGlobalAnyDownloadButtonVisibilityEvent(
                        !url.lowercase(
                            Locale.getDefault()
                        ).contains("vimeo") && !url.lowercase(Locale.getDefault())
                            .contains("facebook.com") && !url.lowercase(
                            Locale.getDefault()
                        ).contains("fb.watch") && !url.lowercase(Locale.getDefault())
                            .contains("instagram.com") && !url.lowercase(
                            Locale.getDefault()
                        ).contains("youtube.com") && url.lowercase(Locale.getDefault())
                            .contains(ProxyConfig.MATCH_HTTP) && !url.lowercase(
                            Locale.getDefault()
                        ).contains("google.com/search"),
                        false,
                        browserActivity.anyFilesDownloadModels
                    )
                )
            }
            if (!url.lowercase(Locale.getDefault()).contains("youtube.com")) {
                return
            }
            EventBus.getDefault().post(
                com.quickstream.downloadmaster.browser.browser.event.global_any_download_button.ChangeGlobalAnyDownloadButtonVisibilityEvent(
                    true,
                    false,
                    java.util.ArrayList()
                )
            )
        }

        override fun onShowCustomView(view: View, customViewCallback: CustomViewCallback) {
            mCustomViewCallback = customViewCallback
            browserActivity.binding.webFullTargetView.addView(view)
            mCustomView = view
            browserActivity.binding.webFullTargetView.visibility = View.VISIBLE
            browserActivity.binding.webFullTargetView.bringToFront()
        }

        override fun onHideCustomView() {
            val view = mCustomView ?: return
            view.visibility = View.GONE
            browserActivity.binding.webFullTargetView.removeView(mCustomView)
            mCustomView = null
            browserActivity.binding.webFullTargetView.visibility = View.GONE
            mCustomViewCallback!!.onCustomViewHidden()
        }
    }


    fun processHTML(z: Boolean) {
        AsyncJob.doInBackground {
            try {
                if (htmlBodyInProcess && !z) {
                    return@doInBackground
                }
                htmlBodyInProcess = true
                Thread.sleep(2000)
                AsyncJob.doOnMainThread {
                    Log.e(
                        "dataDetect",
                        "main processHTML called"
                    )
                    binding.browserWv.loadUrl("javascript:window.HTMLOUT.processHTML(document.body.outerHTML);")
                }
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
        }
    }

    fun hiddenLoadPinterestUrl(str: String?) {
        AsyncJob.doOnMainThread {
            binding.hiddenBrowserWv.webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(webView: WebView, i: Int) {
                    super.onProgressChanged(webView, i)
                    if (i < 100) {
                        return
                    }
                    binding.hiddenBrowserWv.evaluateJavascript("(function() {return document.body.outerHTML;})();") { str2 ->
                        if (str2 == null || str2.length <= 4) {
                            return@evaluateJavascript
                        }
                        val replaceFirst: String =
                            str2.replace("\\u003C", "<").replaceFirst("\"", "")
                        val replace =
                            replaceFirst.substring(0, replaceFirst.length - 1)
                                .replace("\\\"", "\"")
                        AsyncJob.doInBackground {
                            com.quickstream.downloadmaster.browser.browser.helpers.AnyFilesParser.getDownloadUrlFromPinterest(
                                replace,
                                object :
                                    com.quickstream.downloadmaster.browser.browser.helpers.AnyFilesParser.AnyFilesParserHandler {
                                    override fun OnError(str3: String?) {}
                                    override fun OnComplete(list: ArrayList<com.quickstream.downloadmaster.browser.browser.helpers.AnyDownloadModel?>) {
                                        list.size
                                        EventBus.getDefault().post(
                                            com.quickstream.downloadmaster.browser.browser.event.global_any_download_button.ChangeGlobalAnyDownloadButtonVisibilityEvent(
                                                true,
                                                list.isNotEmpty(),
                                                list
//                                                list
                                            )
                                        )
                                    }
                                })
                        }
                    }
                }
            }
            binding.hiddenBrowserWv.webViewClient = object : WebViewClient() {
                override fun onPageFinished(webView: WebView, str2: String) {
                    super.onPageFinished(webView, str2)
                }
            }
            str?.let { binding.hiddenBrowserWv.loadUrl(it) }
        }
    }

    @Subscribe
    fun OnDownloadGlobalButtonClicked(downloadGlobalButtonClickedEvent: com.quickstream.downloadmaster.browser.browser.event.global_download_button.DownloadGlobalButtonClickedEvent?) {
        if (currUrl.lowercase(Locale.getDefault()).contains("shorts")) {
            AsyncJob.doInBackground {
                EventBus.getDefault().post(
                    com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.YoutubeDownloadBtnClickedEvent(
                        0,
                        com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel.YTVideoType.SHORT_FULLY
                    )
                )
            }
        }
    }


    @Subscribe
    fun onInstaDownloadBtnClicked(instaDownloadBtnClickedEvent: com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.InstaDownloadBtnClickedEvent) {
        Log.e("", "onInstaDownloadBtnClicked button Clicked")
        getInstaDownloadBtnClicked(instaDownloadBtnClickedEvent, this)
    }

    fun getReelsDownload(downloadUrl: String) {
        val dialogBinding = DialogLoaderBinding.inflate(layoutInflater)
        val dialog = Dialog(requireActivity(), R.style.Theme_Dialog)
        dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setContentView(dialogBinding.root)
        dialog.show()

        var downloadFileSize: Long = -1

        Observable.fromCallable {
            val fileSize = getFileSizeFromUrl(downloadUrl)
            downloadFileSize = fileSize
            return@fromCallable ""
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                requireActivity().runOnUiThread {
                    dialog.dismiss()
                }
            }.subscribe { result: String? ->
                requireActivity().runOnUiThread {
                    dialog.dismiss()
                    val fileName =
                        "Vid_" + System.currentTimeMillis()
                    val fileType = Constant.TYPE_VIDEO

                    val data = DownloadData(
                        downloadUrl,
                        fileType,
                        fileName,
                    )

                    data.fileSize = if (downloadFileSize == -1L) 0L else downloadFileSize
                    showDownloadDialog(data)
                }
            }
    }

    @SuppressLint("CheckResult")
    private fun getInstaDownloadBtnClicked(
        `val$event`: com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.InstaDownloadBtnClickedEvent,
        browserActivity: TabBrowserFragment
    ) {
        val dialogBinding = DialogLoaderBinding.inflate(layoutInflater)
        val dialog = Dialog(requireActivity(), R.style.Theme_Dialog)
        dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setContentView(dialogBinding.root)
        dialog.show()

        var downloadInstaMediaButtonModel: com.quickstream.downloadmaster.browser.browser.helpers.DownloadInstaMediaButtonModel? =
            null
        Observable.fromCallable {
            if (instaPosts.size > 0) {
                downloadInstaMediaButtonModel =
                    browserActivity.instaPosts[`val$event`.postIndex].downloadButtons[`val$event`.btnInPostIndex]
                downloadInstaMediaButtonModel?.mediaTitle = URLUtil.guessFileName(
                    downloadInstaMediaButtonModel?.targetURL,
                    null,
                    null
                )
                downloadInstaMediaButtonModel?.fileExtention = FilenameUtils.getExtension(
                    downloadInstaMediaButtonModel?.mediaTitle
                )
                downloadInstaMediaButtonModel?.mediaTitle = FilenameUtils.getBaseName(
                    downloadInstaMediaButtonModel?.mediaTitle
                )
                if (downloadInstaMediaButtonModel?.mediaType === com.quickstream.downloadmaster.browser.browser.helpers.DownloadInstaMediaButtonModel.InstaMediaType.VIDEO &&
                    downloadInstaMediaButtonModel?.targetURL!!.lowercase().contains("blob:")
                ) {
                    downloadInstaMediaButtonModel?.targetURL = `val$event`.getcUrl()
                }


                val fileSize = getFileSizeFromUrl(downloadInstaMediaButtonModel?.targetURL ?: "")
                downloadInstaMediaButtonModel?.downloadSizeSize = fileSize
            }
            return@fromCallable ""
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                requireActivity().runOnUiThread {
                    dialog.dismiss()
                }
            }.subscribe { result: String? ->
                requireActivity().runOnUiThread {
                    dialog.dismiss()
                    val downloadUrl: String = downloadInstaMediaButtonModel?.targetURL ?: ""
                    val downloadList: ArrayList<DownloadData> = ArrayList()

                    val fileName =
                        if (downloadInstaMediaButtonModel?.mediaType === com.quickstream.downloadmaster.browser.browser.helpers.DownloadInstaMediaButtonModel.InstaMediaType.VIDEO ||
                            downloadInstaMediaButtonModel?.mediaType === com.quickstream.downloadmaster.browser.browser.helpers.DownloadInstaMediaButtonModel.InstaMediaType.REEL_VIDEO
                        ) "Vid_" + System.currentTimeMillis() else "Img_" + System.currentTimeMillis()
                    val fileType =
                        if (downloadInstaMediaButtonModel?.mediaType === com.quickstream.downloadmaster.browser.browser.helpers.DownloadInstaMediaButtonModel.InstaMediaType.VIDEO ||
                            downloadInstaMediaButtonModel?.mediaType === com.quickstream.downloadmaster.browser.browser.helpers.DownloadInstaMediaButtonModel.InstaMediaType.REEL_VIDEO
                        ) Constant.TYPE_VIDEO else Constant.TYPE_IMAGE

                    val data = DownloadData(
                        downloadUrl,
                        fileType,
                        fileName,
                    )

                    data.fileSize = downloadInstaMediaButtonModel?.downloadSizeSize ?: 0L
                    downloadList.add(data)
                    browserActivity.showDownloadDialog(downloadList[0])
                }
            }
    }

    fun getFileSizeFromUrl(urlString: String): Long {
        var fileSize: Long = -1
        if (urlString.isNotEmpty())
            try {
                val url = URL(urlString)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "HEAD"
                connection.connect()

                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    fileSize = connection.contentLength.toLong()
                }

                connection.disconnect()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        return fileSize
    }

    @Subscribe
    fun onFBDownloadBtnClicked(fBDownloadBtnClickedEvent: com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.FBDownloadBtnClickedEvent) {
        getBDownloadBtnClicked(fBDownloadBtnClickedEvent, this)
    }

    private fun getBDownloadBtnClicked(
        fBDownloadBtnClickedEvent: com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.FBDownloadBtnClickedEvent,
        browserActivity: TabBrowserFragment
    ) {
        val fBContainerModel: com.quickstream.downloadmaster.browser.browser.helpers.FBContainerModel =
            browserActivity.fbContainers[fBDownloadBtnClickedEvent.postIndex]
        val downloadFBMediaButtonModel: com.quickstream.downloadmaster.browser.browser.helpers.DownloadFBMediaButtonModel =
            fBContainerModel.downloadButtons[fBDownloadBtnClickedEvent.btnInPostIndex]

        val dialogBinding = DialogLoaderBinding.inflate(layoutInflater)
        val dialog = Dialog(requireActivity(), R.style.Theme_Dialog)
        dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setContentView(dialogBinding.root)
        dialog.show()

        Observable.fromCallable {
            val countDownLatch = CountDownLatch(1)
            if (fBContainerModel.isMultiContainer || downloadFBMediaButtonModel.targetURL.lowercase()
                    .contains("photo.php") || downloadFBMediaButtonModel.targetURL
                    .lowercase()
                    .contains("story.php") || downloadFBMediaButtonModel.targetURL
                    .lowercase().contains("/photos/")
            ) {

                requireActivity().runOnUiThread {
                    browserActivity.binding.hiddenBrowserWv.webViewClient =
                        C0060111(
                            browserActivity, countDownLatch, downloadFBMediaButtonModel,
                            fBDownloadBtnClickedEvent
                        )
                    browserActivity.binding.hiddenBrowserWv.loadUrl(downloadFBMediaButtonModel.targetURL)
                }

            } else {
                countDownLatch.countDown()
            }
            try {
                countDownLatch.await()
            } catch (e2: InterruptedException) {
                e2.printStackTrace()
            }

            downloadFBMediaButtonModel.mediaTitle = URLUtil.guessFileName(
                downloadFBMediaButtonModel.targetURL,
                null,
                null
            )
            downloadFBMediaButtonModel.fileExtention = FilenameUtils.getExtension(
                downloadFBMediaButtonModel.mediaTitle
            )
            downloadFBMediaButtonModel.mediaTitle = FilenameUtils.getBaseName(
                downloadFBMediaButtonModel.mediaTitle
            )

            val fileSize = getFileSizeFromUrl(downloadFBMediaButtonModel?.targetURL ?: "")
            downloadFBMediaButtonModel.downloadSizeSize = fileSize

            return@fromCallable ""
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                requireActivity().runOnUiThread {
                    dialog.dismiss()
                }
            }.subscribe { result: String? ->
                requireActivity().runOnUiThread {
                    val downloadUrl: String = downloadFBMediaButtonModel.targetURL
                    val downloadList: ArrayList<DownloadData> = ArrayList()

                    val fileName =
                        if (downloadFBMediaButtonModel.mediaType === com.quickstream.downloadmaster.browser.browser.helpers.DownloadFBMediaButtonModel.FBMediaType.VIDEO) "Vid_" + System.currentTimeMillis() else "Img_" + System.currentTimeMillis()
                    val fileType =
                        if (downloadFBMediaButtonModel.mediaType === com.quickstream.downloadmaster.browser.browser.helpers.DownloadFBMediaButtonModel.FBMediaType.VIDEO) Constant.TYPE_VIDEO else Constant.TYPE_IMAGE

                    val data = DownloadData(
                        downloadUrl,
                        fileType,
                        fileName
                    )
                    data.fileSize = downloadFBMediaButtonModel?.downloadSizeSize ?: 0L
                    downloadList.add(
                        data
                    )
                    dialog.dismiss()
                    showDownloadDialog(downloadList[0])
                }
            }

    }

    @Subscribe
    fun onVimeoDownloadBtnClicked(vimeoDownloadBtnClickedEvent: com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.VimeoDownloadBtnClickedEvent) {
    }

    @Subscribe
    fun onNeedModifyInstaHtmlHandler(needModifyInstaHtmlEvent: com.quickstream.downloadmaster.browser.browser.event.NeedModifyInstaHtmlEvent) {
        Log.e("MyWebViewClient integrateDataFetch", "onNeedModifyInstaHtmlHandler")
        val downloadBtn =
            "<svg width=\"65\" height=\"64\" viewBox=\"0 0 65 64\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><ellipse cx=\"32.5\" cy=\"32\" rx=\"32.5\" ry=\"32\" fill=\"#FF2975\"/><path d=\"M32.5 64C36.768 64 40.9941 63.1723 44.9372 61.5641C48.8803 59.956 52.4631 57.5989 55.481 54.6274C58.4989 51.6559 60.8928 48.1283 62.5261 44.2459C64.1594 40.3634 65 36.2023 65 32C65 27.7977 64.1594 23.6365 62.5261 19.7541C60.8928 15.8717 58.4989 12.3441 55.481 9.37258C52.4631 6.4011 48.8803 4.044 44.9372 2.43585C40.9941 0.827702 36.768 -1.18559e-06 32.5 0L32.5 32L32.5 64Z\" fill=\"#F00055\"/><mask id=\"mask0_271_83\" style=\"mask-type:alpha\" maskUnits=\"userSpaceOnUse\" x=\"32\" y=\"0\" width=\"33\" height=\"64\"><path d=\"M32.5 64C36.768 64 40.9941 63.1723 44.9372 61.5641C48.8803 59.956 52.4631 57.5989 55.481 54.6274C58.4989 51.6559 60.8928 48.1283 62.5261 44.2459C64.1594 40.3634 65 36.2023 65 32C65 27.7977 64.1594 23.6365 62.5261 19.7541C60.8928 15.8717 58.4989 12.3441 55.481 9.37258C52.4631 6.4011 48.8803 4.044 44.9372 2.43585C40.9941 0.827702 36.768 -1.18559e-06 32.5 0L32.5 32L32.5 64Z\" fill=\"#FC025A\"/></mask><g mask=\"url(#mask0_271_83)\"><path d=\"M52.65 74.24L27.95 49.92L35.1 12.8C50.05 27.52 60.45 37.12 75.4 51.84L52.65 74.24Z\" fill=\"black\" fill-opacity=\"0.08\"/></g><path d=\"M28.5093 15.7616C28.0324 10.8558 35.0502 10.0699 36.3598 14.1153C36.6161 21.8918 36.3741 29.6931 36.4737 37.4779C38.673 35.327 40.3883 32.4646 42.8439 30.6859C45.9186 29.8007 50.004 35.2112 47.1143 38.1728C42.9577 42.9711 38.851 47.8273 34.673 52.6007C33.5627 54.1643 31.463 54.1312 30.3384 52.5925C26.1391 47.8686 22.0608 42.9877 17.9184 38.1977C14.9433 35.1863 19.1355 29.8172 22.1889 30.6032C24.6516 32.3901 26.4167 35.1781 28.5164 37.4696C28.5093 30.2309 28.495 22.9921 28.5093 15.7616Z\" fill=\"white\"/></svg>"
        AsyncJob.doOnMainThread {
            instaPosts.clear()
            instaPosts.addAll(needModifyInstaHtmlEvent.posts)
            if (binding.browserWv != null) {
                binding.browserWv.evaluateJavascript(
                    "(function() {    while (document.querySelectorAll('[class^=\"dwnld-post\"]')[0]) {        document.querySelectorAll('[class^=\"dwnld-post\"]')[0].remove();    }})();",
                    null
                )
            }
            var i = -1
            for (instaPostModel in instaPosts) {
                i++
                val it: Iterator<com.quickstream.downloadmaster.browser.browser.helpers.DownloadInstaMediaButtonModel> =
                    instaPostModel.downloadButtons.iterator()
                var i2 = -1
                while (it.hasNext()) {
                    val next = it.next()
                    i2++
                    val format = String.format(
                        "dwnld-post-%d-btn-%d",
                        Integer.valueOf(i),
                        Integer.valueOf(i2)
                    )
                    Log.e(
                        "dataDetect",
                        "onNeedModifyInstaHtmlHandler add button ==>>> " + next.targetURL
                    )

                    if (next.mediaType === com.quickstream.downloadmaster.browser.browser.helpers.DownloadInstaMediaButtonModel.InstaMediaType.IMAGE) {
                        val str =
                            "(function() {var photo = document.getElementsByTagName('article'); if (photo.length <= 0){   photo = document.getElementsByClassName('_aamn');   if (photo.length <= 0){       photo = document.getElementsByClassName('x1i10hfl')[0];   }else{       photo = photo[0];   }}else{   photo = photo[" + i + "].getElementsByClassName('_aatk')[0];}var imgs = photo.getElementsByTagName('img');var videos = photo.getElementsByTagName('video');if (imgs.length > 0 && videos.length <= 0){/*просматриваемый элемент по индексу равен элементу из цикла?*//*создадим нашу кнопку*/var dwnldBtn = document.createElement('div');dwnldBtn.class = '" + format + "'; dwnldBtn.setAttribute('class', '" + format + "'); dwnldBtn.setAttribute('downloadUrl', '" + next.targetURL + "'); dwnldBtn.innerHTML = '<div class=\"" + format + "\" style=\"min-height:10px;width:65px;height:65px;position:absolute;bottom:0;right:0;padding:15px\">$downloadBtn</div>';imgs[" + i2 + "].parentElement.parentElement.appendChild(dwnldBtn);dwnldBtn.addEventListener('click', function (e) { e.stopPropagation(); e.preventDefault(); dwnldBtn.disabled = true; setTimeout(function(){dwnldBtn.disabled = false;},1500);window.HTMLOUT.processInstaDownload(dwnldBtn.getAttribute('class'), '');}); }})();"
                        binding.browserWv.evaluateJavascript(str, null)
                    } else if (next.mediaType === com.quickstream.downloadmaster.browser.browser.helpers.DownloadInstaMediaButtonModel.InstaMediaType.REEL_IMAGE) {
                        val str2 =
                            "(function() {var img_ = document.querySelectorAll('[class*=\"_afah\"]');if (img_.length > 0){   img_ = img_[0];}var videos = img_.getElementsByTagName('img');if (videos.length > 0){/*создадим нашу кнопку*/var dwnldBtn = document.createElement('div');dwnldBtn.class = '" + format + "'; dwnldBtn.setAttribute('class', '" + format + "'); dwnldBtn.setAttribute('downloadUrl', '" + next.targetURL + "'); dwnldBtn.innerHTML = '<div class=\"" + format + "\" style=\"min-height:10px;width:65px;height:65px;position:absolute;bottom:150px;right:10;padding:15px\">$downloadBtn</div>';img_.parentElement.appendChild(dwnldBtn);dwnldBtn.addEventListener('click', function (e) { e.stopPropagation(); e.preventDefault(); dwnldBtn.disabled = true; setTimeout(function(){dwnldBtn.disabled = false;},1500);window.HTMLOUT.processInstaDownload(dwnldBtn.getAttribute('class'), dwnldBtn.getAttribute('downloadUrl'));}); }})();"
                        binding.browserWv.evaluateJavascript(str2, null)
                    } else if (next.mediaType === com.quickstream.downloadmaster.browser.browser.helpers.DownloadInstaMediaButtonModel.InstaMediaType.REEL_VIDEO) {
                        val str3 =
                            "(function() {var video = document.querySelectorAll('[class*=\"x5yr21d\"]');if (video.length > 1){   video = video[1];}var videos = video.getElementsByTagName('video');if (videos.length > 0){/*создадим нашу кнопку*/var dwnldBtn = document.createElement('div');dwnldBtn.class = '" + format + "'; dwnldBtn.setAttribute('class', '" + format + "'); dwnldBtn.setAttribute('downloadUrl', '" + next.targetURL + "'); dwnldBtn.innerHTML = '<div class=\"" + format + "\" style=\"min-height:10px;width:65px;height:65px;position:absolute;bottom:150px;right:10;padding:15px\">$downloadBtn</div>';video.parentElement.parentElement.parentElement.parentElement.parentElement.appendChild(dwnldBtn);dwnldBtn.addEventListener('click', function (e) { e.stopPropagation(); e.preventDefault(); dwnldBtn.disabled = true; setTimeout(function(){dwnldBtn.disabled = false;},1500);window.HTMLOUT.processInstaDownload(dwnldBtn.getAttribute('class'), dwnldBtn.getAttribute('downloadUrl'));}); }})();"
                        binding.browserWv.evaluateJavascript(str3, null)
                    } else {
                        val str4 =
                            "(function() {var video = document.getElementsByTagName('article');if (video.length <= 0){   video = document.getElementsByClassName('_aamn');   if (video.length <= 0){       video = document.getElementsByClassName('x1i10hfl')[0];   }else{       video = video[0];   }}else{   video = video[" + i + "].getElementsByClassName('_aatk')[0];}var videos = video.getElementsByTagName('video');if (videos.length > 0){/*просматриваемый элемент по индексу равен элементу из цикла?*//*создадим нашу кнопку*/var dwnldBtn = document.createElement('div');dwnldBtn.class = '" + format + "'; dwnldBtn.setAttribute('class', '" + format + "'); dwnldBtn.setAttribute('downloadUrl', '" + next.targetURL + "'); dwnldBtn.innerHTML = '<div class=\"" + format + "\" style=\"min-height:10px;width:50px;height:50px;position:absolute;bottom:50px;right:0;padding:15px\">$downloadBtn</div>';videos[" + i2 + "].parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.appendChild(dwnldBtn);dwnldBtn.addEventListener('click', function (e) { e.stopPropagation(); e.preventDefault(); dwnldBtn.disabled = true; setTimeout(function(){dwnldBtn.disabled = false;},1500);window.HTMLOUT.processInstaDownload(dwnldBtn.getAttribute('class'), dwnldBtn.getAttribute('downloadUrl'));}); }})();"
                        binding.browserWv.evaluateJavascript(str4, null)
                    }
                }
            }
            binding.browserWv.evaluateJavascript(
                "(function() {var nativeAppBtn = document.querySelectorAll('[class*=\"_acc8\"]');if (nativeAppBtn.length > 0){nativeAppBtn[0].remove();}})();",
                null
            )
        }
    }

    @Subscribe
    fun onNeedModifyFBHtmlHandler(needModifyFBHtmlEvent: com.quickstream.downloadmaster.browser.browser.event.NeedModifyFBHtmlEvent) {
        Log.e("", "onNeedModifyFBHtmlHandler==>> called")
        fbContainers.clear()
        fbContainers.addAll(needModifyFBHtmlEvent.containers)

        var str = ""
        var str2 = ""
        val downloadBtn =
            "<svg width=\"35\" height=\"35\" viewBox=\"0 0 35 35\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><circle cx=\"17.5\" cy=\"17.5\" r=\"17.5\" fill=\"#FF2975\"/><path d=\"M17.5 35C19.7981 35 22.0738 34.5473 24.197 33.6679C26.3202 32.7884 28.2493 31.4994 29.8744 29.8744C31.4994 28.2493 32.7884 26.3202 33.6679 24.197C34.5473 22.0738 35 19.7981 35 17.5C35 15.2019 34.5473 12.9262 33.6679 10.803C32.7884 8.67984 31.4994 6.75065 29.8744 5.12563C28.2493 3.5006 26.3202 2.21156 24.197 1.33211C22.0738 0.45265 19.7981 -6.48371e-07 17.5 0L17.5 17.5L17.5 35Z\" fill=\"#F00055\"/><mask id=\"mask0_275_116\" style=\"mask-type:alpha\" maskUnits=\"userSpaceOnUse\" x=\"17\" y=\"0\" width=\"18\" height=\"35\"><path d=\"M17.5 35C19.7981 35 22.0738 34.5473 24.197 33.6679C26.3202 32.7884 28.2493 31.4994 29.8744 29.8744C31.4994 28.2493 32.7884 26.3202 33.6679 24.197C34.5473 22.0738 35 19.7981 35 17.5C35 15.2019 34.5473 12.9262 33.6679 10.803C32.7884 8.67984 31.4994 6.75065 29.8744 5.12563C28.2493 3.5006 26.3202 2.21156 24.197 1.33211C22.0738 0.45265 19.7981 -6.48371e-07 17.5 0L17.5 17.5L17.5 35Z\" fill=\"#FC025A\"/></mask><g mask=\"url(#mask0_275_116)\"><path d=\"M28.35 40.6L15.05 27.3L18.9 7C26.95 15.05 32.55 20.3 40.6 28.35L28.35 40.6Z\" fill=\"black\" fill-opacity=\"0.08\"/></g><path d=\"M15.3511 8.61968C15.0943 5.93681 18.8732 5.50701 19.5783 7.71936C19.7163 11.9721 19.586 16.2385 19.6397 20.4958C20.8239 19.3195 21.7475 17.7541 23.0697 16.7814C24.7254 16.2973 26.9252 19.2561 25.3692 20.8758C23.1311 23.4999 20.9197 26.1556 18.67 28.7661C18.0722 29.6211 16.9416 29.603 16.336 28.7615C14.0749 26.1782 11.8789 23.5089 9.64835 20.8894C8.04637 19.2426 10.3037 16.3063 11.9478 16.7361C13.2739 17.7134 14.2243 19.238 15.3549 20.4913C15.3511 16.5326 15.3434 12.5739 15.3511 8.61968Z\" fill=\"white\"/></svg>"

        Log.e(
            "",
            "integrateButtonsToFacebook onNeedModifyFBHtmlHandler fbContainers==>> size::::: " + fbContainers.size
        )
        for (fBContainerModel in fbContainers) {
            if (fBContainerModel.downloadButtons.size > 0) {
                val indexOf = fbContainers.indexOf(fBContainerModel)
                var c = 1.toChar()
                var c2 = 0.toChar()
                if (currUrl.lowercase(Locale.getDefault()).contains("/posts/")) {
                    Log.e(
                        "integrateButtonsToFacebook",
                        "onNeedModifyFBHtmlHandler first if /posts/ "
                    )
                    val it: Iterator<com.quickstream.downloadmaster.browser.browser.helpers.DownloadFBMediaButtonModel> =
                        fBContainerModel.downloadButtons.iterator()
                    while (it.hasNext()) {
                        val next: com.quickstream.downloadmaster.browser.browser.helpers.DownloadFBMediaButtonModel =
                            it.next()
                        val indexOf2 = fBContainerModel.downloadButtons.indexOf(next)
                        val objArr = arrayOfNulls<Any>(2)
                        objArr[c2.code] = Integer.valueOf(indexOf)
                        objArr[c.code] = Integer.valueOf(indexOf2)
                        val format = String.format("dwnld-container-%d-btn-%d", *objArr)
                        str =
                            if (next.mediaType === com.quickstream.downloadmaster.browser.browser.helpers.DownloadFBMediaButtonModel.FBMediaType.VIDEO) {
                                "(function() {    var container = document.querySelectorAll('[class^=\"_56be\"]')[$indexOf];    var footer = container.querySelectorAll('[class^=\"_52jh _7om2 _15kk _15ks _4b47\"]')[0];    var videos_ = container.getElementsByTagName('video');    var video_ = videos_[$indexOf2];    if (videos_.length > 0) {        /*\u043f\u0440\u043e\u0441\u043c\u0430\u0442\u0440\u0438\u0432\u0430\u0435\u043c\u044b\u0439 \u044d\u043b\u0435\u043c\u0435\u043d\u0442 \u043f\u043e \u0438\u043d\u0434\u0435\u043a\u0441\u0443 \u0440\u0430\u0432\u0435\u043d \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u0443 \u0438\u0437 \u0446\u0438\u043a\u043b\u0430?*/        var itemsForRemove = footer.getElementsByClassName('$format');        if (itemsForRemove.length <= 0) {            /*\u0441\u043e\u0437\u0434\u0430\u0434\u0438\u043c \u043d\u0430\u0448\u0443 \u043a\u043d\u043e\u043f\u043a\u0443*/            var dwnldBtn = document.createElement('div');            dwnldBtn.class = '$format';            dwnldBtn.setAttribute('class', '$format');            dwnldBtn.setAttribute('downloadUrl', 'URL');            dwnldBtn.innerHTML = '<div style=\"min-height:5px;width:35px;height:35px;position:absolute;bottom:0;right:0;padding:5px\"><svg fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" width=\"35\" height=\"35\" viewBox=\"0 0 65 65\"><circle cx=\"32.5\" cy=\"32.5\" r=\"32.5\" transform=\"rotate(-90 32.5 32.5)\" fill=\"#6384FF\"></circle><path d=\"M33 45L33 19\" stroke=\"white\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M22 36.3056L33 47L44 36\" stroke=\"white\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg></div>';            footer.appendChild(dwnldBtn);            dwnldBtn.addEventListener('click', function(e) {                e.stopPropagation(); e.preventDefault(); dwnldBtn.disabled = true; setTimeout(function(){dwnldBtn.disabled = false;},1500);                window.HTMLOUT.processFBDownload(dwnldBtn.getAttribute('class'));/*console.log(video_);*/            });        }    }})();"
                            } else {
                                "(function() {    var container = document.querySelectorAll('[class^=\"_56be\"]')[$indexOf];    var footer = container.querySelectorAll('[class^=\"_52jh _7om2 _15kk _15ks _4b47\"]')[0];    var imgs = container.getElementsByTagName('img');    var img = imgs[$indexOf2];    if (imgs.length > 0) {        /*\u043f\u0440\u043e\u0441\u043c\u0430\u0442\u0440\u0438\u0432\u0430\u0435\u043c\u044b\u0439 \u044d\u043b\u0435\u043c\u0435\u043d\u0442 \u043f\u043e \u0438\u043d\u0434\u0435\u043a\u0441\u0443 \u0440\u0430\u0432\u0435\u043d \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u0443 \u0438\u0437 \u0446\u0438\u043a\u043b\u0430?*/        var itemsForRemove = container.getElementsByClassName('$format');        if (itemsForRemove.length <= 0) {            /*\u0441\u043e\u0437\u0434\u0430\u0434\u0438\u043c \u043d\u0430\u0448\u0443 \u043a\u043d\u043e\u043f\u043a\u0443*/            var dwnldBtn = document.createElement('div');            dwnldBtn.class = '$format';            dwnldBtn.setAttribute('class', '$format');            dwnldBtn.setAttribute('downloadUrl', 'URL');            dwnldBtn.innerHTML = '<div style=\"min-height:5px;width:35px;height:35px;position:absolute;bottom:0;right:0;padding:5px\"><svg fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" width=\"35\" height=\"35\" viewBox=\"0 0 65 65\"><circle cx=\"32.5\" cy=\"32.5\" r=\"32.5\" transform=\"rotate(-90 32.5 32.5)\" fill=\"#6384FF\"></circle><path d=\"M33 45L33 19\" stroke=\"white\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M22 36.3056L33 47L44 36\" stroke=\"white\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg></div>';            footer.appendChild(dwnldBtn);            dwnldBtn.addEventListener('click', function(e) {                e.stopPropagation(); e.preventDefault(); dwnldBtn.disabled = true; setTimeout(function(){dwnldBtn.disabled = false;},1500);                window.HTMLOUT.processFBDownload(dwnldBtn.getAttribute('class'));/*console.log(video_);*/            });        }    }})();"
                            }
                        val finalStr1 = str
                        Log.e(
                            "integrateButtonsToFacebook",
                            "onNeedModifyFBHtmlHandler==>> first if addDownloadBtn:::::  mediaTitle==> ${next.mediaTitle}"
                        )
                        AsyncJob.doOnMainThread(AsyncJob.OnMainThreadJob {
                            if (finalStr1.isEmpty()) {
                                return@OnMainThreadJob
                            }

                            binding.browserWv.evaluateJavascript(finalStr1, null)
                        })
                        c = 1.toChar()
                        c2 = 0.toChar()
                    }
                } else if (currUrl.lowercase(Locale.getDefault()).contains("photo.php")) {
                    Log.e(
                        "integrateButtonsToFacebook",
                        "onNeedModifyFBHtmlHandler sec else if photo.php "
                    )
                    val format2 =
                        String.format("dwnld-container-%d-btn-%d", Integer.valueOf(indexOf), 0)
                    val str3 =
                        "(function() {    var container = document.querySelectorAll('[class^=\"_59e9\"]')[$indexOf];    var footer = container.querySelectorAll('[class^=\"_52jh _7om2 _15kk _15ks _4b47\"]')[0];    /*\u043f\u0440\u043e\u0441\u043c\u0430\u0442\u0440\u0438\u0432\u0430\u0435\u043c\u044b\u0439 \u044d\u043b\u0435\u043c\u0435\u043d\u0442 \u043f\u043e \u0438\u043d\u0434\u0435\u043a\u0441\u0443 \u0440\u0430\u0432\u0435\u043d \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u0443 \u0438\u0437 \u0446\u0438\u043a\u043b\u0430?*/    var itemsForRemove = container.getElementsByClassName('$format2');    if (itemsForRemove.length <= 0) {       /*\u0441\u043e\u0437\u0434\u0430\u0434\u0438\u043c \u043d\u0430\u0448\u0443 \u043a\u043d\u043e\u043f\u043a\u0443*/       var dwnldBtn = document.createElement('div');       dwnldBtn.class = '$format2';       dwnldBtn.setAttribute('class', '$format2');       dwnldBtn.setAttribute('downloadUrl', 'URL');       dwnldBtn.innerHTML = '<div style=\"min-height:5px;width:35px;height:35px;position:absolute;bottom:0;right:0;padding:5px\">$downloadBtn</div>';       footer.appendChild(dwnldBtn);       dwnldBtn.addEventListener('click', function(e) {           e.stopPropagation(); e.preventDefault(); dwnldBtn.disabled = true; setTimeout(function(){dwnldBtn.disabled = false;},1500);           window.HTMLOUT.processFBDownload(dwnldBtn.getAttribute('class'));/*console.log(video_);*/        });    }})();"
                    AsyncJob.doOnMainThread {
                        Log.e(
                            "integrateButtonsToFacebook",
                            "onNeedModifyFBHtmlHandler==>> sec else if addDownloadBtn::::: authorName==> ${fBContainerModel.authorName}"
                        )
                        binding.browserWv.evaluateJavascript(str3, null)
                    }
                } else if (!fBContainerModel.isMultiContainer) {
                    Log.e(
                        "integrateButtonsToFacebook",
                        "onNeedModifyFBHtmlHandler third else if !isMultiContainer "
                    )
                    val it2: Iterator<com.quickstream.downloadmaster.browser.browser.helpers.DownloadFBMediaButtonModel> =
                        fBContainerModel.downloadButtons.iterator()
                    while (it2.hasNext()) {
                        val next2: com.quickstream.downloadmaster.browser.browser.helpers.DownloadFBMediaButtonModel =
                            it2.next()
                        val indexOf3 = fBContainerModel.downloadButtons.indexOf(next2)
                        val format3 = String.format(
                            "dwnld-container-%d-btn-%d",
                            Integer.valueOf(indexOf),
                            Integer.valueOf(indexOf3)
                        )
                        str2 =
                            if (next2.mediaType === com.quickstream.downloadmaster.browser.browser.helpers.DownloadFBMediaButtonModel.FBMediaType.VIDEO) {
                                "(function() {    var container = document.querySelectorAll('[class*=\"_5rgr\"]')[$indexOf];    var footer = container.getElementsByTagName('footer')[0];    var videos_ = container.querySelectorAll('[class^=\"_53mw\"]');    var video_ = videos_[$indexOf3];    if (videos_.length > 0) {        /*\u043f\u0440\u043e\u0441\u043c\u0430\u0442\u0440\u0438\u0432\u0430\u0435\u043c\u044b\u0439 \u044d\u043b\u0435\u043c\u0435\u043d\u0442 \u043f\u043e \u0438\u043d\u0434\u0435\u043a\u0441\u0443 \u0440\u0430\u0432\u0435\u043d \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u0443 \u0438\u0437 \u0446\u0438\u043a\u043b\u0430?*/        var itemsForRemove = footer.getElementsByClassName('$format3');        if (itemsForRemove.length <= 0) {            /*\u0441\u043e\u0437\u0434\u0430\u0434\u0438\u043c \u043d\u0430\u0448\u0443 \u043a\u043d\u043e\u043f\u043a\u0443*/            var dwnldBtn = document.createElement('div');            dwnldBtn.class = '$format3';            dwnldBtn.setAttribute('class', '$format3');            dwnldBtn.setAttribute('downloadUrl', 'URL');            dwnldBtn.innerHTML = '<div style=\"min-height:10px;width:35px;height:35px;position:absolute;bottom:0;right:0;padding:5px\">$downloadBtn</div>';            footer.appendChild(dwnldBtn);            dwnldBtn.addEventListener('click', function(e) {                e.stopPropagation(); e.preventDefault(); dwnldBtn.disabled = true; setTimeout(function(){dwnldBtn.disabled = false;},1500);                window.HTMLOUT.processFBDownload(dwnldBtn.getAttribute('class'));/*console.log(video_);*/            });        }    }})();"
                            } else {
                                "(function() {    var container = document.querySelectorAll('[class*=\"_5rgr\"]')[$indexOf];    var footer = container.getElementsByTagName('footer')[0];    var imgs_ = container.querySelectorAll('[class^=\"_39pi\"]');    var img_ = imgs_[$indexOf3];    if (imgs_.length > 0) {        /*\u043f\u0440\u043e\u0441\u043c\u0430\u0442\u0440\u0438\u0432\u0430\u0435\u043c\u044b\u0439 \u044d\u043b\u0435\u043c\u0435\u043d\u0442 \u043f\u043e \u0438\u043d\u0434\u0435\u043a\u0441\u0443 \u0440\u0430\u0432\u0435\u043d \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u0443 \u0438\u0437 \u0446\u0438\u043a\u043b\u0430?*/        var itemsForRemove = footer.getElementsByClassName('$format3');        if (itemsForRemove.length <= 0) {            /*\u0441\u043e\u0437\u0434\u0430\u0434\u0438\u043c \u043d\u0430\u0448\u0443 \u043a\u043d\u043e\u043f\u043a\u0443*/            var dwnldBtn = document.createElement('div');            dwnldBtn.class = '$format3';            dwnldBtn.setAttribute('class', '$format3');            dwnldBtn.setAttribute('downloadUrl', 'URL');            dwnldBtn.innerHTML = '<div style=\"min-height:10px;width:35px;height:35px;position:absolute;bottom:0;right:0;padding:5px\">$downloadBtn</div>';            footer.appendChild(dwnldBtn);            dwnldBtn.addEventListener('click', function(e) {                e.stopPropagation(); e.preventDefault(); dwnldBtn.disabled = true; setTimeout(function(){dwnldBtn.disabled = false;},1500);                window.HTMLOUT.processFBDownload(dwnldBtn.getAttribute('class'));/*console.log(video_);*/            });        }    }})();"
                            }
                        val finalStr = str2
                        Log.e(
                            "integrateButtonsToFacebook",
                            "onNeedModifyFBHtmlHandler==>> third else if addDownloadBtn:::::  mediaTitle==> ${next2.mediaTitle}"
                        )
                        AsyncJob.doOnMainThread(AsyncJob.OnMainThreadJob {
                            if (finalStr.isEmpty()) {
                                return@OnMainThreadJob
                            }
                            binding.browserWv.evaluateJavascript(finalStr, null)
                        })
                    }
                } else {
                    Log.e("integrateButtonsToFacebook", "onNeedModifyFBHtmlHandler  else part ")
                    val it3: Iterator<com.quickstream.downloadmaster.browser.browser.helpers.DownloadFBMediaButtonModel> =
                        fBContainerModel.downloadButtons.iterator()
                    while (it3.hasNext()) {
                        val next2: com.quickstream.downloadmaster.browser.browser.helpers.DownloadFBMediaButtonModel =
                            it3.next()
                        val indexOf4 = fBContainerModel.downloadButtons.indexOf(it3.next())
                        val format4 = String.format(
                            "dwnld-container-%d-btn-%d",
                            Integer.valueOf(indexOf),
                            Integer.valueOf(indexOf4)
                        )
                        val str4 =
                            "(function() {    var container = document.querySelectorAll('[class^=\"_55wo _5rgr _5gh8 async_like\"]')[$indexOf];    var footer = container.getElementsByTagName('footer')[0];    var mediaItems_ = container.querySelectorAll('[class^=\"_26ih\"]');    if (mediaItems_.length > 0) {        mediaItems_ = mediaItems_[$indexOf4];        var plusItems_ = mediaItems_.querySelectorAll('[class^=\"_7om2 _52we _1r5l\"]');        /*\u043f\u0440\u043e\u0441\u043c\u0430\u0442\u0440\u0438\u0432\u0430\u0435\u043c\u044b\u0439 \u044d\u043b\u0435\u043c\u0435\u043d\u0442 \u043f\u043e \u0438\u043d\u0434\u0435\u043a\u0441\u0443 \u0440\u0430\u0432\u0435\u043d \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u0443 \u0438\u0437 \u0446\u0438\u043a\u043b\u0430?*/        var itemsForRemove = mediaItems_.parentElement.getElementsByClassName('$format4');        if (itemsForRemove.length <= 0 && plusItems_.length <= 0) {            /*\u0441\u043e\u0437\u0434\u0430\u0434\u0438\u043c \u043d\u0430\u0448\u0443 \u043a\u043d\u043e\u043f\u043a\u0443*/            var rectMediaItems_ = mediaItems_.getBoundingClientRect();            var topOfBtn = mediaItems_.offsetTop + mediaItems_.offsetHeight - 45 - 10 - 15;            var leftOfBtn = mediaItems_.offsetLeft;            var dwnldBtn = document.createElement('div');            dwnldBtn.class = '$format4';            dwnldBtn.setAttribute('class', '$format4');            dwnldBtn.setAttribute('downloadUrl', 'URL');            dwnldBtn.innerHTML = `<div style=\"min-height:10px;width:45px;height:45px;position:absolute;top:\${topOfBtn}px;left:\${leftOfBtn}px;padding:15px\">$downloadBtn</div>`;            mediaItems_.parentElement.appendChild(dwnldBtn);            dwnldBtn.addEventListener('click', function(e) {                e.stopPropagation(); e.preventDefault(); dwnldBtn.disabled = true; setTimeout(function(){dwnldBtn.disabled = false;},1500);                window.HTMLOUT.processFBDownload(dwnldBtn.getAttribute('class'));/*console.log(video_);*/                            });        }    }})();"
                        AsyncJob.doOnMainThread {
                            Log.e(
                                "integrateButtonsToFacebook",
                                "onNeedModifyFBHtmlHandler==>> else part addDownloadBtn::::: authorName==> ${next2.mediaTitle}"
                            )
                            binding.browserWv.evaluateJavascript(str4, null)
                        }
                    }
                }
            }
        }
    }

    class C0060111(
        var browserActivity: TabBrowserFragment,
        val countDownLatch: CountDownLatch,
        val downloadFBMediaButtonModel1: com.quickstream.downloadmaster.browser.browser.helpers.DownloadFBMediaButtonModel,
        val fbDownloadBtn: com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.FBDownloadBtnClickedEvent
    ) : WebViewClient() {
        override fun onPageFinished(webView: WebView, str: String) {
            super.onPageFinished(webView, str)
            browserActivity.binding.hiddenBrowserWv.evaluateJavascript(
                "(function() {return document.body.outerHTML;})();",
                C006111(browserActivity, countDownLatch, downloadFBMediaButtonModel1, fbDownloadBtn)
            )
        }
    }

    class C006111(
        var browserActivity: TabBrowserFragment, val countDownLatch: CountDownLatch,
        val downloadFBMediaButtonModel: com.quickstream.downloadmaster.browser.browser.helpers.DownloadFBMediaButtonModel,
        val fBDownloadBtnClickedEvent: com.quickstream.downloadmaster.browser.browser.injected_btns_clicks.FBDownloadBtnClickedEvent,
    ) : ValueCallback<String?> {
        override fun onReceiveValue(str: String?) {
            if (str == null || str.length <= 4) {
                countDownLatch.countDown()
                return
            }
            val replaceFirst =
                str.replace("\\u003C", "<").replaceFirst("\"".toRegex(), "")
            val replace =
                replaceFirst.substring(0, replaceFirst.length - 1).replace("\\\"", "\"")
            AsyncJob.doInBackground {
                try {
                    val url =
                        URL(downloadFBMediaButtonModel.targetURL)
                    com.quickstream.downloadmaster.browser.browser.helpers.ButtonsIntegrator()
                        .integrateButtonsToFacebook(
                            replace,
                            url.protocol + "://" + url.host,
                            downloadFBMediaButtonModel.targetURL,
                            object :
                                com.quickstream.downloadmaster.browser.browser.ui_events.ButtonsIntegratingStateHandler {
                                override fun OnComplete_Insta(list: List<com.quickstream.downloadmaster.browser.browser.helpers.InstaPostModel?>?) {}

                                override fun OnComplete_YT(
                                    str2: String?,
                                    list: List<com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel?>?,
                                    list2: List<com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel?>?,
                                    downloadYTVideoButtonModel: com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel?
                                ) {
                                }

                                override fun OnComplete_FB(list: List<com.quickstream.downloadmaster.browser.browser.helpers.FBContainerModel>) {
                                    if (list.size > fBDownloadBtnClickedEvent.btnInPostIndex && list[fBDownloadBtnClickedEvent.btnInPostIndex].downloadButtons.size > 0) {
                                        downloadFBMediaButtonModel.targetURL =
                                            list[fBDownloadBtnClickedEvent.btnInPostIndex].downloadButtons[0].targetURL
                                    }
                                    countDownLatch.countDown()
                                }

                                override fun OnError(str2: String?) {
                                    countDownLatch.countDown()
                                }
                            })
                } catch (e: MalformedURLException) {
                    e.printStackTrace()
                }
            }
        }
    }

    @Subscribe
    fun onChangeGlobalDownloadButtonVisibility(changeGlobalDownloadButtonVisibilityEvent: com.quickstream.downloadmaster.browser.browser.event.global_download_button.ChangeGlobalDownloadButtonVisibilityEvent) {
        Log.e(" BrowserDownload", "GlobalDownload called")
    }

    @Subscribe
    fun onChangeGlobalAnyDownloadButtonVisibility(changeGlobalAnyDownloadButtonVisibilityEvent: com.quickstream.downloadmaster.browser.browser.event.global_any_download_button.ChangeGlobalAnyDownloadButtonVisibilityEvent) {
        Log.e(
            "BrowserDownload",
            "GlobalAnyDownload called==>> " + changeGlobalAnyDownloadButtonVisibilityEvent.anyFilesDownloadModels.size
        )

        if (!changeGlobalAnyDownloadButtonVisibilityEvent.anyFilesDownloadModels.isNullOrEmpty()) {
            for (anyFilesDownloadModel in changeGlobalAnyDownloadButtonVisibilityEvent.anyFilesDownloadModels) {
                Log.e(
                    "BrowserDownload",
                    "anyFilesDownloadModel url==>> " + anyFilesDownloadModel.downloadUrl
                )
            }
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            TabBrowserFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}