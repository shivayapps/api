package com.quickstream.downloadmaster.browser.browser.page_loading;

public class PageLoadedEvent {
}
