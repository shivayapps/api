package com.quickstream.downloadmaster.browser.browser.event


data class ADShowEvent(var isShowADs: Boolean)