package com.quickstream.downloadmaster.browser.ui.data

data class FamilyAppsModel(
    val appName: String,
    val shortDescription: String,
    val appImageLink: String,
    val appPackageName: String,
    val appPlayStoreLink: String
)