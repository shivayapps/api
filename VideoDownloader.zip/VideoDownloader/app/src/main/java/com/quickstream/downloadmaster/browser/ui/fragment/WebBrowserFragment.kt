package com.quickstream.downloadmaster.browser.ui.fragment

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.RectF
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.DownloadListener
import android.webkit.HttpAuthHandler
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.core.view.OnApplyWindowInsetsListener
import androidx.core.view.ViewCompat
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

//import com.ads.module.open.AdconfigApplication
import com.google.android.material.snackbar.BaseTransientBottomBar.BaseCallback
import com.google.android.material.snackbar.Snackbar
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.database.DataBaseClass
import com.quickstream.downloadmaster.browser.ui.activity.WebBrowserActivity
import com.quickstream.downloadmaster.browser.ui.activity.option.BrowserDownloadActivity
import com.quickstream.downloadmaster.browser.ui.adapter.BrowserDataAdapter
import com.quickstream.downloadmaster.browser.ui.adapter.WebHistoryAdapter
import com.quickstream.downloadmaster.browser.ui.adapter.WebSearchAdapter
import com.quickstream.downloadmaster.browser.ui.data.BrowserTab
import com.quickstream.downloadmaster.browser.ui.data.Secure_MediaDataModal
import com.quickstream.downloadmaster.browser.ui.data.WebBrowserData
import com.quickstream.downloadmaster.browser.utils.Constant
import com.quickstream.downloadmaster.browser.utils.MyApplication
import com.quickstream.downloadmaster.browser.utils.UtilsAd
import de.mrapp.android.tabswitcher.AbstractState
import de.mrapp.android.tabswitcher.AddTabButtonListener
import de.mrapp.android.tabswitcher.Animation
import de.mrapp.android.tabswitcher.Layout
import de.mrapp.android.tabswitcher.PeekAnimation
import de.mrapp.android.tabswitcher.PullDownGesture
import de.mrapp.android.tabswitcher.RevealAnimation
import de.mrapp.android.tabswitcher.StatefulTabSwitcherDecorator
import de.mrapp.android.tabswitcher.SwipeGesture
import de.mrapp.android.tabswitcher.Tab
import de.mrapp.android.tabswitcher.TabPreviewListener
import de.mrapp.android.tabswitcher.TabSwitcher
import de.mrapp.android.tabswitcher.TabSwitcherListener
import de.mrapp.android.util.DisplayUtil
import de.mrapp.android.util.multithreading.AbstractDataBinder
import de.mrapp.util.Condition.ensureNotNull
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class WebBrowserFragment(mUrl: String) : Fragment(), TabSwitcherListener {
    var url_strings: String? = null
    var tags = 0
    var tab_v = 0
    var new_part = 0
    var c = Calendar.getInstance().time
    var df = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault())
    var secureDataBaseClass: DataBaseClass? = null
    var url_title: String? = null
    var setViewV = false
    val tabList: ArrayList<BrowserTab> = ArrayList()
    var browserList: ArrayList<WebBrowserData> = ArrayList()

    var viewUrl: String = mUrl
    var isShowUrl: Boolean = false

    private inner class State(tab: Tab) : AbstractState(tab),
        AbstractDataBinder.Listener<ArrayAdapter<String?>?, Tab, ListView, Void?>,
        TabPreviewListener {
        private var adapter: ArrayAdapter<String?>? = null
        fun loadItems(listView: ListView) {
            ensureNotNull(listView, "The list view may not be null")
            if (adapter == null) {
                dataBinder!!.addListener(this)
                dataBinder!!.load(tab, listView)
            } else if (listView.adapter !== adapter) {
                listView.adapter = adapter
            }
        }

        override fun onLoadData(
            dataBinder: AbstractDataBinder<ArrayAdapter<String?>?, Tab, ListView, Void?>,
            key: Tab,
            vararg params: Void?,
        ): Boolean {
            return true
        }

        override fun onCanceled(
            dataBinder: AbstractDataBinder<ArrayAdapter<String?>?, Tab, ListView, Void?>,
        ) {
        }

        override fun onFinished(
            dataBinder: AbstractDataBinder<ArrayAdapter<String?>?, Tab, ListView, Void?>,
            key: Tab,
            data: ArrayAdapter<String?>?,
            view: ListView,
            vararg params: Void?,
        ) {
            if (tab == key) {
                view.adapter = data
                adapter = data
                dataBinder.removeListener(this)
            }
        }

        override fun saveInstanceState(outState: Bundle) {
            if (adapter != null && !adapter!!.isEmpty) {
                val array = arrayOfNulls<String>(adapter!!.count)
                for (i in array.indices) {
                    array[i] = adapter!!.getItem(i)
                }
                outState.putStringArray(
                    String.format(ADAPTER_STATE_EXTRA, tab.title),
                    array
                )
            }
        }

        override fun restoreInstanceState(savedInstanceState: Bundle?) {
            if (savedInstanceState != null) {
                val key = String.format(ADAPTER_STATE_EXTRA, tab.title)
                val items = savedInstanceState.getStringArray(key)
                if (!items.isNullOrEmpty()) {
                    adapter = ArrayAdapter(
                        context!!,
                        android.R.layout.simple_list_item_1, items
                    )
                }
            }
        }

        override fun onLoadTabPreview(
            tabSwitcher: TabSwitcher,
            tab: Tab,
        ): Boolean {
            return getTab() != tab || adapter != null
        }
    }

    private inner class Decorator : StatefulTabSwitcherDecorator<State?>() {
        override fun onCreateState(
            context: Context,
            tabSwitcher: TabSwitcher,
            view: View, tab: Tab,
            index: Int, viewType: Int,
            savedInstanceState: Bundle?,
        ): State? {
            Log.e("WebBrowserTab", "onCreateState")
            if (viewType == -1) {
                val state: State = State(tab)
                tabSwitcher.addTabPreviewListener(state)
                if (savedInstanceState != null) {
                    state.restoreInstanceState(savedInstanceState)
                }
                return state
            }
            return null
        }

        override fun onClearState(state: State) {
            mTabSwitcher!!.removeTabPreviewListener(state)
        }

        override fun onSaveInstanceState(
            view: View, tab: Tab,
            index: Int, viewType: Int,
            state: State?,
            outState: Bundle,
        ) {
            state?.saveInstanceState(outState)
        }

        override fun onInflateView(
            inflater: LayoutInflater,
            parent: ViewGroup?, viewType: Int,
        ): View {
            return inflater.inflate(R.layout.tab_list_view, parent, false)
        }

        public override fun onShowTab(
            context: Context,
            tabSwitcher: TabSwitcher, view: View,
            tab: Tab, index: Int, viewType: Int,
            state: State?,
            savedInstanceState: Bundle?,
        ) {
            Log.e("WebBrowserTab", "onShowTab")
            val tabSwitcherButton = findViewById<TextView>(R.id.chip1) as TextView
//            tabSwitcherButton.setOnClickListener(createTabSwitcherButtonListener())

            tabSwitcherButton.text = "${tabSwitcher.count}"
//            tabSwitcher.addListener(tabSwitcherButton)
            val tv_tt = findViewById<TextView>(R.id.tv_tttt)
            val textView = findViewById<TextView>(android.R.id.title)
            val rv_history_list = findViewById<RecyclerView>(R.id.rv_history_list)
            val tv_clear = findViewById<TextView>(R.id.tv_clear)
            val tv_clears = findViewById<TextView>(R.id.tv_clears)
            val arrayList = ArrayList<String>()
            tv_clear.setOnClickListener { v: View? ->
                rv_history_list.layoutManager = LinearLayoutManager(getContext())
                rv_history_list.adapter = WebSearchAdapter(arrayList, activity!!, view)
            }
            rv_history_list.layoutManager = LinearLayoutManager(getContext())
            rv_history_list.adapter =
                WebSearchAdapter(secureDataBaseClass!!.historyList1, activity!!, view)
            val webs = findViewById<WebView>(R.id.webs)
            val progressBar = findViewById<ProgressBar>(R.id.progressbar)
            val ll_tags = findViewById<LinearLayout>(R.id.ll_tags)
            val ll_main = findViewById<LinearLayout>(R.id.ll_mains)
            val ll_history = findViewById<LinearLayout>(R.id.ll_history)
            val iv_back_ = findViewById<ImageView>(R.id.iv_back_)
            val nodats = findViewById<ImageView>(R.id.nodats)
            val rv_history = findViewById<RecyclerView>(R.id.rv_history)
            val ll_media = findViewById<LinearLayout>(R.id.ll_media)
            val loutMainHome = findViewById<LinearLayout>(R.id.loutMainHome)
            val frameNative = findViewById<FrameLayout>(R.id.frame_native)
            val ll_search = findViewById<LinearLayout>(R.id.ll_search)
            val et_search = findViewById<EditText>(R.id.et_search)
            val loutMainSearch = findViewById<LinearLayout>(R.id.loutMainSearch)
            val ivBack = findViewById<ImageView>(R.id.ivBack)
            val ivClose = findViewById<ImageView>(R.id.ivClose)
            val iv_back = findViewById<ImageView>(R.id.iv_back)
            val iv_prev = findViewById<ImageView>(R.id.iv_priv)
            val iv_home = findViewById<ImageView>(R.id.iv_home)
            val iv_more = findViewById<ImageView>(R.id.iv_more)
            val iv_refrech = findViewById<ImageView>(R.id.iv_refresh)
            val iv_bookmark = findViewById<ImageView>(R.id.iv_bookmark)
            val tv_link = findViewById<TextView>(R.id.tv_link)
            val cancel = findViewById<TextView>(R.id.tv_cancel)
            val rvBrowserList = findViewById<RecyclerView>(R.id.rv_browser_list)
            val webSettings = webs.settings

            tabSwitcherButton.setOnClickListener(View.OnClickListener {
                Log.e(
                    "WebBrowserTab",
                    "tabSwitcherButton childCount===>>  " + frameNative.childCount
                )
                frameNative.removeAllViews()
                mTabSwitcher!!.toggleSwitcherVisibility()
            })

            if (isShowUrl && viewUrl.isNotEmpty()) {
                ll_search.visibility = View.GONE
                webs.visibility = View.VISIBLE
                ll_media.visibility = View.GONE
                loutMainHome.visibility = View.GONE
                frameNative.visibility = View.GONE
                ll_search.visibility = View.GONE
                var url = viewUrl
                webs.loadUrl(url)
                hideKeyboard(et_search)
                isShowUrl = false
                viewUrl = ""
            }


            if (frameNative.childCount == 0) {
                frameNative.visibility = View.VISIBLE
                UtilsAd.showNative(requireActivity(),frameNative)
            }

            tv_clears.setOnClickListener {
                if (tags == 0) {
                    secureDataBaseClass!!.allDeletesHistory()
                } else {
                    secureDataBaseClass!!.allDeletesBookMark()
                }
                nodats.visibility = View.VISIBLE
                tv_clears.visibility = View.GONE
                rv_history.visibility = View.GONE
            }
            webSettings.javaScriptEnabled = true
            if (new_part == 1) {
                new_part = 0
                cancel.visibility = View.GONE
                ll_search.visibility = View.GONE
                ll_media.visibility = View.VISIBLE
                loutMainHome.visibility = View.VISIBLE
                frameNative.visibility = View.VISIBLE
                webs.visibility = View.GONE
                cancel.visibility = View.GONE
                tv_link.visibility = View.GONE
                iv_refrech.visibility = View.GONE
                iv_bookmark.visibility = View.GONE
                et_search.visibility = View.VISIBLE
                loutMainSearch.visibility = View.VISIBLE
                et_search.setText("")
                webs.clearHistory()
                webs.clearFormData()
                webs.clearCache(true)
            }
            webs.webViewClient = MyWebViewClient(progressBar)
            if (!checkConnection()) {
                showDialog()
            }

            rvBrowserList.adapter =
                BrowserDataAdapter(browserList, requireContext(), clickListener = {
                    if (browserList[it].title == context.getString(R.string.instagram) || browserList[it].title == context.getString(
                            R.string.facebook
                        )
                    ) {
                        context.startActivity(
                            Intent(
                                context,
                                BrowserDownloadActivity::class.java
                            ).putExtra(Constant.PUT_KEY_URL, browserList[it].urls)
                                .putExtra(
                                    Constant.EXTRA_TYPE,
                                    if (browserList[it].title == context.getString(R.string.instagram)) Constant.TYPE_Insta else Constant.TYPE_FB
                                )
                        )
                    } else {
                        ll_search.visibility = View.GONE
                        webs.visibility = View.VISIBLE
                        ll_media.visibility = View.GONE
                        loutMainHome.visibility = View.GONE
                        frameNative.visibility = View.GONE
                        ll_search.visibility = View.GONE
                        var url = browserList[it].urls
                        if (!url.startsWith("http://") || !url.startsWith("https://")) {
                            url = "https://www.google.com/search?q=$url"
                        }
                        webs.loadUrl(url)
                        hideKeyboard(et_search)
                    }
                })

            et_search.addTextChangedListener {
                if (it.toString().isEmpty())
                    ivClose.visibility = View.GONE
                else
                    ivClose.visibility = View.VISIBLE
            }
            ivBack.setOnClickListener {
                (activity as WebBrowserActivity).onBackPressed()
            }
            ivClose.setOnClickListener {
                et_search.setText("")
                et_search.isCursorVisible = true
                et_search.requestFocus()
                cancel.visibility = View.GONE
                ll_search.visibility = View.GONE
                ll_history.visibility = View.GONE
                ll_media.visibility = View.VISIBLE
                loutMainHome.visibility = View.VISIBLE
                frameNative.visibility = View.VISIBLE
                webs.visibility = View.GONE
            }
            iv_home.setOnClickListener { v: View? ->
                val index1 = tabSwitcher.count
                val tab1 = createTab(index1)
                frameNative.removeAllViews()
                tabSwitcher.addTab(tab1, 0, createRevealAnimation())
            }
            iv_more.setOnClickListener { v: View? ->
                val popupMenu = PopupMenu(getContext(), v)
                popupMenu.menuInflater.inflate(R.menu.popup_menu, popupMenu.menu)
                popupMenu.setOnMenuItemClickListener { menuItem ->
                    when (menuItem.itemId) {
                        R.id.item_new_tab -> {
                            val index1 = tabSwitcher.count
                            val tab1 = createTab(index1)
                            tabSwitcher.addTab(tab1, 0, createRevealAnimation())
                        }

                        R.id.item_bookmark -> {
                            tags = 1
                            tv_tt.text = requireActivity().getString(R.string.Bookmark)
                            ll_main.visibility = View.GONE
                            ll_history.visibility = View.VISIBLE
                            setBookmarkList(view, rv_history)
                            if (secureDataBaseClass!!.bookmarkList.size == 0) {
                                nodats.visibility = View.VISIBLE
                                rv_history.visibility = View.GONE
                                tv_clears.visibility = View.GONE
                            } else {
                                nodats.visibility = View.GONE
                                rv_history.visibility = View.VISIBLE
                                tv_clears.visibility = View.VISIBLE
                            }
                        }

                        R.id.item_history -> {
                            tv_tt.text = requireActivity().getString(R.string.history)
                            ll_main.visibility = View.GONE
                            ll_history.visibility = View.VISIBLE
                            setHistoryList(view, rv_history)
                            tags = 0
                            if (secureDataBaseClass!!.historyList.size == 0) {
                                nodats.visibility = View.VISIBLE
                                rv_history.visibility = View.GONE
                                tv_clears.visibility = View.GONE
                            } else {
                                nodats.visibility = View.GONE
                                rv_history.visibility = View.VISIBLE
                                tv_clears.visibility = View.VISIBLE
                            }
                        }
                    }
                    return@setOnMenuItemClickListener true
                }
                popupMenu.show()
            }
            iv_back_.setOnClickListener {
                if (tags == 1) {
                    if (url_strings != null)
                        if (secureDataBaseClass!!.getUrl(url_strings!!)) {
                            iv_bookmark.setImageResource(R.drawable.ic_round_bookmark_24)
                        } else {
                            iv_bookmark.setImageResource(R.drawable.ic_round_bookmark_border_24)
                        }
                    else
                        iv_bookmark.setImageResource(R.drawable.ic_round_bookmark_border_24)
                }
                ll_main.visibility = View.VISIBLE
                ll_history.visibility = View.GONE
            }
            iv_back.setOnClickListener {
                if (webs.canGoBack()) {
                    webs.goBack()
                } else {
                    tab_v = 1
                    cancel.visibility = View.GONE
                    ll_search.visibility = View.GONE
                    ll_media.visibility = View.VISIBLE
                    loutMainHome.visibility = View.VISIBLE
                    frameNative.visibility = View.VISIBLE
                    webs.visibility = View.GONE
                    cancel.visibility = View.GONE
                    tv_link.visibility = View.GONE
                    iv_refrech.visibility = View.GONE
                    iv_bookmark.visibility = View.GONE
                    et_search.visibility = View.VISIBLE
                    loutMainSearch.visibility = View.VISIBLE
                    et_search.setText("")
                }
            }
            iv_prev.setOnClickListener {
                if (webs.canGoForward()) {
                    if (tab_v == 1) {
                        webs.visibility = View.VISIBLE
                        ll_media.visibility = View.GONE
                        loutMainHome.visibility = View.GONE
                        frameNative.visibility = View.GONE
                        tv_link.visibility = View.VISIBLE
                        iv_refrech.visibility = View.VISIBLE
                        iv_bookmark.visibility = View.VISIBLE
                        et_search.visibility = View.GONE
                        loutMainSearch.visibility = View.GONE
                        tab_v = 0
                    } else {
                        webs.goForward()
                    }
                } else {
                    if (tab_v != 0) {
                        tab_v = 0
                        webs.visibility = View.VISIBLE
                        ll_media.visibility = View.GONE
                        loutMainHome.visibility = View.GONE
                        frameNative.visibility = View.GONE
                        tv_link.visibility = View.VISIBLE
                        iv_refrech.visibility = View.VISIBLE
                        iv_bookmark.visibility = View.VISIBLE
                        et_search.visibility = View.GONE
                        loutMainSearch.visibility = View.GONE
                    }
                }
            }
            cancel.setOnClickListener {
                if (setViewV) {
                    cancel.visibility = View.GONE
                    tv_link.visibility = View.VISIBLE
                    iv_refrech.visibility = View.VISIBLE
                    iv_bookmark.visibility = View.VISIBLE
                    et_search.visibility = View.GONE
                    loutMainSearch.visibility = View.GONE
                    webs.visibility = View.VISIBLE
                    ll_search.visibility = View.GONE
                    setViewV = false
                } else {
                    cancel.visibility = View.GONE
                    ll_search.visibility = View.GONE
                    ll_media.visibility = View.VISIBLE
                    loutMainHome.visibility = View.VISIBLE
                    frameNative.visibility = View.VISIBLE
                }
            }
            et_search.setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    ll_search.visibility = View.GONE
                    webs.visibility = View.VISIBLE
                    ll_media.visibility = View.GONE
                    loutMainHome.visibility = View.GONE
                    frameNative.visibility = View.GONE
                    ll_search.visibility = View.GONE
                    tab_v = 1
                    var url = et_search.text.toString().trim { it <= ' ' }
                    if (!url.startsWith("http://") || !url.startsWith("https://")) {
                        url = "https://www.google.com/search?q=$url"
                    }
                    webs.loadUrl(url)
                    hideKeyboard(et_search)
                }
                false
            }

            webs.webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    progressBar.progress = newProgress
                    progressBar.visibility = View.VISIBLE
                    if (newProgress == 100) {
                        progressBar.visibility = View.GONE
                    }
                    super.onProgressChanged(view, newProgress)
                }

                override fun onReceivedTitle(view: WebView, title: String) {
                    super.onReceivedTitle(view, title)
                    url_title = title
                    url_strings = view.url
                    if (title.isNotEmpty())
                        tabSwitcher.getTab(index).title = title
                    secureDataBaseClass!!.insertHistory(view.url, df.format(c), title)
                }
            }
            webs.webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                    tab_v = 1
                    et_search.visibility = View.GONE
                    loutMainSearch.visibility = View.GONE
                    cancel.visibility = View.GONE
                    tv_link.visibility = View.VISIBLE
                    tv_link.text = url
                    iv_refrech.visibility = View.VISIBLE
                    iv_bookmark.visibility = View.VISIBLE
                    if (secureDataBaseClass!!.getUrl(url)) {
                        iv_bookmark.setImageResource(R.drawable.ic_round_bookmark_24)
                    } else {
                        iv_bookmark.setImageResource(R.drawable.ic_round_bookmark_border_24)
                    }
                    iv_bookmark.setOnClickListener {
                        if (secureDataBaseClass!!.getUrl(url)) {
                            iv_bookmark.setImageResource(R.drawable.ic_round_bookmark_border_24)
                            secureDataBaseClass!!.deleteBookMark(url)
                        } else {
                            iv_bookmark.setImageResource(R.drawable.ic_round_bookmark_24)
                            secureDataBaseClass!!.insertBookmark(url, df.format(c), url_title)
                        }
                    }
                    iv_refrech.setOnClickListener { webs.loadUrl(url) }
                    tv_link.setOnClickListener {
                        setViewV = true
                        et_search.visibility = View.VISIBLE
                        loutMainSearch.visibility = View.VISIBLE
                        cancel.visibility = View.VISIBLE
                        tv_link.text = url
                        tv_link.visibility = View.GONE
                        iv_refrech.visibility = View.GONE
                        iv_bookmark.visibility = View.GONE
                        ll_search.visibility = View.VISIBLE
                        webs.visibility = View.GONE
                    }
                    et_search.setText(url)
                }

                override fun onPageFinished(view: WebView, url: String) {}
                override fun onReceivedHttpAuthRequest(
                    view: WebView,
                    handler: HttpAuthHandler,
                    host: String,
                    realm: String,
                ) {
                }
            }
            webs.setDownloadListener(MyDownLoadListener())
            textView.text = tab.title
            ll_tags.visibility = if (tabSwitcher.isSwitcherShown) View.GONE else View.VISIBLE
        }

        override fun getViewTypeCount(): Int {
//            return 16
            return tabList.size
        }

        override fun getViewType(tab: Tab, index: Int): Int {
            val parameters = tab.parameters
            return parameters?.getInt(VIEW_TYPE_EXTRA) ?: 0
        }
    }

    private fun setHistoryList(view: View, recyclerView: RecyclerView) {
        val arrayList: ArrayList<Secure_MediaDataModal> = secureDataBaseClass!!.historyList
        if (arrayList.size != 0) {
            arrayList.reverse()
            val secureHistoryAdapter = WebHistoryAdapter(arrayList, activity, view, tags)
            val linearLayoutManager = LinearLayoutManager(context)
            recyclerView.layoutManager = linearLayoutManager
            recyclerView.adapter = secureHistoryAdapter
        }

    }

    private fun setBookmarkList(view: View, recyclerView: RecyclerView) {
        val arrayList: ArrayList<Secure_MediaDataModal> = secureDataBaseClass!!.bookmarkList
        if (arrayList.size != 0) {
            arrayList.reverse()
            val secureHistoryAdapter = WebHistoryAdapter(arrayList, activity, view, tags)
            val linearLayoutManager = LinearLayoutManager(context)
            recyclerView.layoutManager = linearLayoutManager
            recyclerView.adapter = secureHistoryAdapter
        }

    }

    private open class DataBinder(context: Context) :
        AbstractDataBinder<ArrayAdapter<String?>?, Tab, ListView, Void?>(context.applicationContext) {
        override fun doInBackground(
            key: Tab,
            vararg params: Void?,
        ): ArrayAdapter<String?>? {
            val array = arrayOfNulls<String>(10)
            for (i in array.indices) {
                array[i] = String.format(Locale.getDefault(), "%s, item %d", key.title, i + 1)
            }
            try {
                Thread.sleep(1000)
            } catch (e: InterruptedException) {
            }
            return ArrayAdapter(context, android.R.layout.simple_list_item_1, array)
        }

        override fun onPostExecute(
            view: ListView,
            data: ArrayAdapter<String?>?,
            duration: Long,
            vararg params: Void?,
        ) {
            if (data != null) {
                view.adapter = data
            }
        }
    }

    private var mTabSwitcher: TabSwitcher? = null
    private var decorator: Decorator? = null
    private var snackbar: Snackbar? = null
    private var dataBinder: DataBinder? = null
    private fun createWindowInsetsListener(): OnApplyWindowInsetsListener {
        return OnApplyWindowInsetsListener { v, insets ->
            val left = insets.systemWindowInsetLeft
            val top = insets.systemWindowInsetTop
            val right = insets.systemWindowInsetRight
            val bottom = insets.systemWindowInsetBottom
            mTabSwitcher!!.setPadding(left, top, right, bottom)
            var touchableAreaTop = top.toFloat()
            if (mTabSwitcher!!.layout == Layout.TABLET) {
                touchableAreaTop += resources
                    .getDimensionPixelSize(R.dimen.tablet_tab_container_height).toFloat()
            }
            val touchableArea = RectF(
                left.toFloat(),
                touchableAreaTop,
                (
                        DisplayUtil.getDisplayWidth(requireContext()) - right).toFloat(),
                touchableAreaTop + 50
//                        ThemeUtil.getDimensionPixelSize(requireContext(), 50)
            )
            mTabSwitcher!!.addDragGesture(
                SwipeGesture.Builder().setTouchableArea(touchableArea).create()
            )
            mTabSwitcher!!.addDragGesture(
                PullDownGesture.Builder().setTouchableArea(touchableArea).create()
            )
            insets
        }
    }

    private fun createAddTabListener(): View.OnClickListener {
        return View.OnClickListener {
            val index = mTabSwitcher!!.count
            val animation = createRevealAnimation()
            mTabSwitcher!!.addTab(createTab(index), 0, animation)
            Log.e("SEBrowserFragment", "createAddTabListener")
        }
    }

    private fun createToolbarMenuListener(): Toolbar.OnMenuItemClickListener {
        return Toolbar.OnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.remove_tab_menu_item -> {
                    val selectedTab = mTabSwitcher!!.selectedTab
                    if (selectedTab != null) {
                        mTabSwitcher!!.removeTab(selectedTab)
                    }
                    true
                }

                R.id.add_tab_menu_item -> {
                    val index = mTabSwitcher!!.count
                    val tab = createTab(index)
                    if (mTabSwitcher!!.isSwitcherShown) {
                        mTabSwitcher!!.addTab(tab, 0, createRevealAnimation())
                    } else {
                        mTabSwitcher!!.addTab(tab, 0, createPeekAnimation())
                    }
                    true
                }

                R.id.clear_tabs_menu_item -> {
                    new_part = 1
                    mTabSwitcher!!.clearAllSavedStates()
                    mTabSwitcher!!.clearSavedStatesWhenRemovingTabs(true)
                    mTabSwitcher!!.clearDisappearingChildren()
                    mTabSwitcher!!.clear()
                    true
                }

                else -> false
            }
        }
    }

    private fun inflateMenu() {
        mTabSwitcher!!.inflateToolbarMenu(
            if (mTabSwitcher!!.count > 0) R.menu.tab_switcher else R.menu.tab,
            createToolbarMenuListener()
        )
    }

    private fun createTabSwitcherButtonListener(): View.OnClickListener {
        return View.OnClickListener { mTabSwitcher!!.toggleSwitcherVisibility() }
    }

    private fun createAddTabButtonListener(): AddTabButtonListener {
        return AddTabButtonListener { tabSwitcher ->
            val index = tabSwitcher.count
            val tab = createTab(index)
            tabSwitcher.addTab(tab, 0)
            Log.e("SEBrowserFragment", "createAddTabButtonListener")
        }
    }

    private fun createUndoSnackbarListener(
        snackbar: Snackbar,
        index: Int,
        vararg tabs: Tab,
    ): View.OnClickListener {
        Log.e("SEBrowserFragment", "createUndoSnackbarListener $index")
        return View.OnClickListener {
            snackbar.setAction(null, null)
            if (mTabSwitcher!!.isSwitcherShown) {
                mTabSwitcher!!.addAllTabs(tabs, index)
            } else if (tabs.size == 1) {
                mTabSwitcher!!.addTab(tabs[0], 0, createPeekAnimation())
                tabList.add(index, BrowserTab(tabs[0].title.toString()))
            }
        }
    }

    private fun createUndoSnackbarCallback(
        vararg tabs: Tab,
    ): BaseCallback<Snackbar?> {
        return object : BaseCallback<Snackbar?>() {
            override fun onDismissed(snackbar: Snackbar?, event: Int) {
                if (event != DISMISS_EVENT_ACTION) {
                    for (tab in tabs) {
                        mTabSwitcher!!.clearSavedState(tab)
                        decorator!!.clearState(tab)
                    }
                }
            }
        }
    }

    private fun showUndoSnackbar(
        text: CharSequence, index: Int,
        vararg tabs: Tab,
    ) {
        snackbar = Snackbar.make(mTabSwitcher!!, text, Snackbar.LENGTH_LONG).setActionTextColor(
            ContextCompat.getColor(requireContext(), R.color.selectDotColor)
        )
        snackbar!!.setAction(
            R.string.undo, createUndoSnackbarListener(
                snackbar!!, index, *tabs
            )
        )
        snackbar!!.addCallback(createUndoSnackbarCallback(*tabs))
        snackbar!!.show()
    }

    private fun createRevealAnimation(): Animation {
        var x = 0f
        var y = 0f
        val view = navigationMenuItem
        if (view != null) {
            val location = IntArray(2)
            view.getLocationInWindow(location)
            x = location[0] + view.width / 2f
            y = location[1] + view.height / 2f
        }
        return RevealAnimation.Builder().setX(x).setY(y).create()
    }

    private fun createPeekAnimation(): Animation {
        return PeekAnimation.Builder().setX(mTabSwitcher!!.width / 2f).create()
    }

    private val navigationMenuItem: View?
        private get() {
            val toolbars = mTabSwitcher!!.toolbars
            if (toolbars != null) {
                val toolbar = if (toolbars.size > 1) toolbars[1] else toolbars[0]
                val size = toolbar.childCount
                for (i in 0 until size) {
                    val child = toolbar.getChildAt(i)
                    if (child is ImageButton) {
                        return child
                    }
                }
            }
            return null
        }

    private fun createTab(index: Int): Tab {
        val title: CharSequence = getString(R.string.tab_title)
//        val title: CharSequence = getString(R.string.tab_title, index + 1)
        val tab = Tab(title)
        val parameters = Bundle()
//        parameters.putInt(VIEW_TYPE_EXTRA, index % 16)
        parameters.putInt(VIEW_TYPE_EXTRA, index)
        tab.parameters = parameters
        return tab
    }

    override fun onSwitcherShown(tabSwitcher: TabSwitcher) {}
    override fun onSwitcherHidden(tabSwitcher: TabSwitcher) {
        if (snackbar != null) {
            snackbar!!.dismiss()
        }
    }

    override fun onSelectionChanged(
        tabSwitcher: TabSwitcher,
        selectedTabIndex: Int,
        selectedTab: Tab?,
    ) {
    }

    override fun onTabAdded(
        tabSwitcher: TabSwitcher, index: Int,
        tab: Tab, animation: Animation,
    ) {
        inflateMenu()
        TabSwitcher.setupWithMenu(tabSwitcher, createTabSwitcherButtonListener())
        Log.e("SEBrowserFragment", "onTabAdded $index")
        tabList.add(index, BrowserTab(tab.title.toString()))
    }

    override fun onTabRemoved(
        tabSwitcher: TabSwitcher, index: Int,
        tab: Tab, animation: Animation,
    ) {
        val text: CharSequence = getString(R.string.removed_tab_snackbar, tab.title)
        tabList.removeAt(index)
        showUndoSnackbar(text, index, tab)
        inflateMenu()
        TabSwitcher.setupWithMenu(tabSwitcher, createTabSwitcherButtonListener())
        Log.e("SEBrowserFragment", "onTabRemoved")
    }

    override fun onAllTabsRemoved(
        tabSwitcher: TabSwitcher,
        tabs: Array<Tab>,
        animation: Animation,
    ) {
        val text: CharSequence = getString(R.string.cleared_tabs_snackbar)
        showUndoSnackbar(text, 0, *tabs)
        tabList.clear()
        inflateMenu()
        TabSwitcher.setupWithMenu(tabSwitcher, createTabSwitcherButtonListener())
        Log.e("SEBrowserFragment", "onAllTabsRemoved")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        val view = inflater.inflate(R.layout.fragment_browser, container, false)
        tab_v = 0
        if (viewUrl.isNotEmpty()) {
            isShowUrl = true
        }
        getBrowserList()
        secureDataBaseClass = DataBaseClass(context, requireActivity())
        dataBinder = DataBinder(requireContext())
        decorator = Decorator()
        mTabSwitcher = view.findViewById(R.id.tab_switcher)
        mTabSwitcher!!.clearSavedStatesWhenRemovingTabs(false)
        ViewCompat.setOnApplyWindowInsetsListener(mTabSwitcher!!, createWindowInsetsListener())
        mTabSwitcher!!.decorator = decorator!!
        mTabSwitcher!!.addListener(this)
        mTabSwitcher!!.showToolbars(true)
        for (i in 0 until TAB_COUNT) {
            mTabSwitcher!!.addTab(createTab(i))
        }
        mTabSwitcher!!.showAddTabButton(createAddTabButtonListener())
        mTabSwitcher!!.setToolbarNavigationIcon(R.drawable.ic_plus_24dp, createAddTabListener())
        TabSwitcher.setupWithMenu(mTabSwitcher!!, createTabSwitcherButtonListener())
        inflateMenu()
        return view
    }

    private fun getBrowserList() {
        browserList.add(
            WebBrowserData(
                getString(R.string.google),
                R.drawable.ic_google_browser,
                R.color.instagram_holiday_love_bg,
                "https://www.google.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.instagram),
                R.drawable.ic_instagram_browser,
                R.color.instagram_holiday_love_bg,
                Constant.URL_Insta
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.twitter),
                R.drawable.ic_twitter_browser,
                R.color.twitter_bg,
                "https://twitter.com/explore"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.LinkedIn),
                R.drawable.ic_linkedin_browser,
                R.color.linkedIn_bg,
                "https://in.linkedin.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.facebook),
                R.drawable.ic_facebook_browser,
                R.color.facebook_daily_motion_bg,
                Constant.URL_FB
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.share_chat),
                R.drawable.ic_share_chat_browser,
                R.color.Share_Chat_bg,
                "https://sharechat.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Pinterest),
                R.drawable.ic_pinterest_browser,
                R.color.pinterest_bg,
                "https://www.pinterest.com/"
            )
        )

        browserList.add(
            WebBrowserData(
                getString(R.string.imdb),
                R.drawable.ic_imdb_browser,
                R.color.IMDB_instagram_s_bg,
                "https://www.imdb.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.bittube),
                R.drawable.ic_bittube_browser,
                R.color.Bittube_Imgur_bg,
                "https://www.bittube.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Daily_Motion),
                R.drawable.ic_daily_motion_browser,
                R.color.facebook_daily_motion_bg,
                "https://www.dailymotion.com/in"
            )
        )

        browserList.add(
            WebBrowserData(
                getString(R.string.twitch),
                R.drawable.ic_twitch_browser,
                R.color.Twitch_bg,
                "https://www.twitch.tv/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.bit_chute),
                R.drawable.ic_bit_chute_browser,
                R.color.BitChute_bg,
                "https://www.bitchute.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Metacafe),
                R.drawable.ic_metacafe_browser,
                R.color.Metacafe_bg,
                "https://metacafe.metacube.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Vlipsy),
                R.drawable.ic_vlipsy_browser,
                R.color.Vlipsy_bg,
                "https://vlipsy.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Flickr),
                R.drawable.ic_flickr_browser,
                R.color.Flickr_bg,
                "https://www.flickr.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Ifunny),
                R.drawable.ic_ifunny_browser,
                R.color.Ifunny_bg,
                "https://ifunny.co/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Reddit),
                R.drawable.ic_reddit_browser,
                R.color.Reddit_bg,
                "https://www.reddit.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Rumble),
                R.drawable.ic_rumble_browser,
                R.color.Rumble_bg,
                "https://rumble.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Imgur),
                R.drawable.ic_imgur_browser,
                R.color.Bittube_Imgur_bg,
                "https://imgur.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Izlesene),
                R.drawable.ic_izlesene_browser,
                R.color.Izlesene_bg,
                "https://www.izlesene.com/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.Onetvru),
                R.drawable.ic_onetvru_browser,
                R.color.Onetvru_bg,
                "https://www.onetv.ca/"
            )
        )
        browserList.add(
            WebBrowserData(
                getString(R.string.tumblr),
                R.drawable.ic_tumblr_browser,
                R.color.Tumblr_bg,
                "https://www.tumblr.com/"
            )
        )
    }

    private inner class MyWebViewClient(var progressBar: ProgressBar) : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            return false
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
            progressBar.visibility = View.VISIBLE
        }

        override fun onPageFinished(view: WebView, url: String) {
            super.onPageFinished(view, url)
            progressBar.visibility = View.GONE
        }
    }

    private fun checkConnection(): Boolean {
        val connectivityManager =
            requireActivity().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (connectivityManager != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val capabilities =
                    connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
                if (capabilities != null) {
                    if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        return true
                    } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        return true
                    } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                        return true
                    }
                }
            } else {
                val activeNetworkInfo = connectivityManager.activeNetworkInfo
                if (activeNetworkInfo != null && activeNetworkInfo.isConnected) {
                    return true
                }
            }
        }
        return false
    }

    private fun showDialog() {
        val builder = AlertDialog.Builder(context)
        builder.setMessage("Connect to WIFI or Exit")
            .setCancelable(false)
            .setPositiveButton("Connect to WIFI") { dialog, id -> startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
            .setNegativeButton("Exit") { dialog, id -> dialog.cancel() }
        val alert = builder.create()
        alert.show()
    }

    inner class MyDownLoadListener : DownloadListener {
        override fun onDownloadStart(
            url: String,
            userAgent: String,
            contentDisposition: String,
            mimetype: String,
            contentLength: Long,
        ) {
            if (url != null) {
                try {
                    val i = Intent(Intent.ACTION_VIEW)
                    i.data = Uri.parse(url)
                    MyApplication.disabledOpenAds()
                    startActivity(i)
                } catch (e: Exception) {
                    Toast.makeText(context, "This url not support!!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun hideKeyboard(editText: EditText) {
        val imm =
            (requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        imm.hideSoftInputFromWindow(editText.windowToken, 0)
    }

    override fun onResume() {
        super.onResume()
        tab_v = 0
    }

    companion object {
        private val VIEW_TYPE_EXTRA = WebBrowserActivity::class.java.name + "::ViewType"
        private val ADAPTER_STATE_EXTRA = State::class.java.name + "::%s::AdapterState"
        private const val TAB_COUNT = 1
    }
}