package com.quickstream.downloadmaster.browser.ui.activity.option.dpGenerator

import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.ViewPager
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.quickstream.downloadmaster.browser.utils.AppUrl
import com.quickstream.downloadmaster.browser.R

import com.quickstream.downloadmaster.browser.databinding.ActivityDpgeneratorBinding
import com.quickstream.downloadmaster.browser.network.RetrofitClient3
import com.quickstream.downloadmaster.browser.ui.activity.BaseActivity
import com.quickstream.downloadmaster.browser.ui.activity.option.DownloadActivity
import com.quickstream.downloadmaster.browser.ui.adapter.DpGeneratorCategoryAdapter
import com.quickstream.downloadmaster.browser.ui.data.DpGeneratorCategoryList
import com.quickstream.downloadmaster.browser.ui.data.DpGeneratorCategoryResponse
import com.quickstream.downloadmaster.browser.ui.data.DpGeneratorSubCategoryItem
import com.quickstream.downloadmaster.browser.ui.fragment.DPGeneratorFragment
import com.quickstream.downloadmaster.browser.utils.AdCache
import com.quickstream.downloadmaster.browser.utils.Constant
import com.quickstream.downloadmaster.browser.utils.FileUtil
import com.quickstream.downloadmaster.browser.utils.Utils
import com.quickstream.downloadmaster.browser.utils.UtilsAd
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.util.concurrent.Executors

class DPGeneratorActivity : BaseActivity() {

    lateinit var binding: ActivityDpgeneratorBinding
    var categoryList: ArrayList<DpGeneratorCategoryList> = ArrayList()
    var categoryAdapter: DpGeneratorCategoryAdapter? = null
    var tabSelect = 0
    var downloadStorePath = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDpgeneratorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inti()
    }

    private fun inti() {
        binding.loutLoading.visibility = View.GONE
        binding.loutToolbar.txtTitle.text = getString(R.string.dPGenerator)
        downloadStorePath = FileUtil.getExternalStoragePublicDirectory(
            this,
            Environment.DIRECTORY_PICTURES
        ) + File.separator + getString(
            R.string.app_name
        ) + File.separator + Constant.FOLDER_DP_CREATE

        if (Utils.isNetworkAvailable(this)) {
            getItemList()
        } else {
            binding.tvNoInternet.visibility = View.VISIBLE
            binding.tvNoData.visibility = View.GONE
            finishLoading()
        }
        checkButtonDownload()
        intiListener()
        loadBannerAd()
    }

    var isAdLoaded=false
    var mAdView: AdView?=null
    private fun loadBannerAd() {
        if (!isAdLoaded) {
            val adId = getString(R.string.banner_ads)
            BannerAdHelper.showBanner(this, binding.frameBanner, binding.frameBanner, adId,
                AdCache.bannerDpGenerator, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.bannerDpGenerator = adView
                    isAdLoaded = isLoaded
                })
        }
    }

    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        if (isPause) {
            isPause = false
            Handler(Looper.myLooper()!!).postDelayed(Runnable { checkButtonDownload() }, 500)

        }
    }

    var isPause = false

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
        isPause = true
    }

    private fun setTab() {
        binding.divider.visibility = View.VISIBLE
        binding.viewpager.offscreenPageLimit = 2
        binding.viewpager.adapter =
            PageAdapter(supportFragmentManager, categoryList, changeDataListener = { pos, subList ->
                if (categoryList[pos].subList.isNullOrEmpty())
                    categoryList[pos].subList = ArrayList()
                else
                    categoryList[pos].subList.clear()
                categoryList[pos].subList.addAll(subList)
            }, nextScreenListener = { mainPos, childPos ->
                Constant.DPGeneratorData.clear()
                Constant.DPGeneratorData.addAll(categoryList)
                startActivity(
                    Intent(this, DPCreationActivity::class.java)
                        .putExtra(Constant.EXTRA_POS, mainPos)
                        .putExtra(Constant.EXTRA_CHILD_POS, childPos)
                )
            })

        binding.viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
                Log.e("viewpagerOnPageChange", "onPageScrolled $position")

            }

            override fun onPageSelected(position: Int) {
                Log.e("viewpagerOnPageChange", "onPageSelected $position")
                tabSelect = position
                if (categoryAdapter != null)
                    if (categoryAdapter!!.tabSelect != tabSelect) {
                        val p = categoryAdapter!!.tabSelect
                        categoryAdapter!!.tabSelect = tabSelect
                        categoryAdapter!!.notifyItemChanged(tabSelect)
                        categoryAdapter!!.notifyItemChanged(p)
                        binding.rvHeader.scrollToPosition(position)
                    }
            }

            override fun onPageScrollStateChanged(state: Int) {
//                Log.e("viewpagerOnPageChange","onPageScrollStateChanged")
            }
        })
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener { onBackPressed() }
        binding.loutToolbar.btnDownload.setOnClickListener {
            startActivity(
                Intent(this, DownloadActivity::class.java).putExtra(
                    Constant.EXTRA_TYPE,
                    Constant.DOWNLOAD_DP_CREATE
                )
            )
        }
    }

    private fun checkButtonDownload() {
        val service = Executors.newSingleThreadExecutor()
        service.execute {
            val isDataIsAdded = checkPathIsNotEmpty()
            runOnUiThread {
                Log.e("checkButtonDownload", "isDataIsAdded==>> $isDataIsAdded")
                binding.loutToolbar.btnDownload.visibility =
                    if (isDataIsAdded) View.VISIBLE else View.GONE
            }
        }
    }

    private fun checkPathIsNotEmpty(): Boolean {
        var isDataIsAdd = false
        val file = File(downloadStorePath)
        val listFile = file.listFiles()
        if (file.exists()) {
            try {
                if (file.listFiles().isNotEmpty()) {
                    for (i in listFile.indices) {
                        val data = listFile[i]
                        if (data.isFile && data.exists() && data.length() != 0L) {
                            isDataIsAdd = true
                            break
                        }
                    }
                }
            } catch (e: NullPointerException) {
                e.printStackTrace()
            }
        }
        return isDataIsAdd
    }

    private fun setCategoryAdapter() {
        categoryAdapter = DpGeneratorCategoryAdapter(this, categoryList, clickListener = {
            tabSelect = it
            binding.viewpager.currentItem = tabSelect
        })
        binding.rvHeader.adapter = categoryAdapter
    }

    private fun startLoading() {
        binding.loutLoading.visibility = View.VISIBLE
    }

    private fun finishLoading() {
        runOnUiThread {
            binding.loutLoading.visibility = View.GONE
        }
    }

    private fun getItemList() {
        categoryList.clear()
        startLoading()
        val call: Call<DpGeneratorCategoryResponse> =
            RetrofitClient3.instance!!.myApi.getCategoryList(AppUrl().dpGeneratorCategoryListENDURL())
        call.enqueue(object : Callback<DpGeneratorCategoryResponse> {
            override fun onResponse(
                call: Call<DpGeneratorCategoryResponse>,
                response: Response<DpGeneratorCategoryResponse>
            ) {
                val mainList: DpGeneratorCategoryResponse = response.body()!!

                if (mainList != null)
                    categoryList.addAll(getIconList(mainList))
                if (categoryList.isNotEmpty()) {
                    if (categoryAdapter != null) {
                        categoryAdapter!!.notifyDataSetChanged()
                    } else {
                        setCategoryAdapter()
                    }
                    binding.tvNoInternet.visibility = View.GONE
                    binding.tvNoData.visibility = View.GONE
                    finishLoading()
                    setTab()
                } else {
                    finishLoading()
                    binding.tvNoData.visibility = View.VISIBLE
                }

            }

            override fun onFailure(call: Call<DpGeneratorCategoryResponse>, t: Throwable) {
                finishLoading()
                Toast.makeText(
                    this@DPGeneratorActivity,
                    getString(R.string.download_fail_msg),
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    private fun getIconList(mainList: DpGeneratorCategoryResponse): Collection<DpGeneratorCategoryList> {
        if (mainList.isNotEmpty()) {
            for (data in mainList) {
                var icon: Int = -1
                if (data.name.equals("Animal Print", true))
                    icon = R.drawable.ic_animal_print
                else if (data.name.equals("Birthday", true))
                    icon = R.drawable.ic_tab_birthday
                else if (data.name.equals("Cute", true))
                    icon = R.drawable.ic_tab_cute
                else if (data.name.equals("Flower", true))
                    icon = R.drawable.ic_tab_flower
                else if (data.name.equals("Kids", true))
                    icon = R.drawable.ic_tab_kids
                else if (data.name.equals("Love", true))
                    icon = R.drawable.ic_tab_love
                else if (data.name.equals("Nature", true))
                    icon = R.drawable.ic_nature_2
                else if (data.name.equals("Pattern", true))
                    icon = R.drawable.ic_pattern
                else if (data.name.equals("Popular", true))
                    icon = R.drawable.ic_tab_popular
                else if (data.name.equals("Text", true))
                    icon = R.drawable.ic_tab_text
                else if (data.name.equals("Texture", true))
                    icon = R.drawable.ic_texture
                else if (data.name.equals("Wedding", true))
                    icon = R.drawable.ic_tab_wedding

                data.icon = icon
            }
        }
        return mainList
    }


    class PageAdapter(
        fm: FragmentManager,
        var categoryList: java.util.ArrayList<DpGeneratorCategoryList>,
        val changeDataListener: (pos: Int, subList: ArrayList<DpGeneratorSubCategoryItem>) -> Unit,
        val nextScreenListener: (mainPos: Int, childPos: Int) -> Unit
    ) :
        FragmentPagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {
        override fun getCount(): Int {
            return categoryList.size
        }

        override fun getItem(position: Int): Fragment {
            return DPGeneratorFragment.newInstance(
                position,
                categoryList[position],
                changeDataListener, nextScreenListener
            )
        }
    }
}