package com.quickstream.downloadmaster.browser.browser.ui_events;

public class ChangeWebProgressBarEvent {
    private int progressValue;

    public ChangeWebProgressBarEvent(int i) {
        this.progressValue = i;
    }

    public int getProgressValue() {
        return this.progressValue;
    }

    public void setProgressValue(int i) {
        this.progressValue = i;
    }
}
