package com.quickstream.downloadmaster.browser.ui.activity

import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.viewpager2.widget.ViewPager2
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.databinding.ActivityIntroBinding
import com.quickstream.downloadmaster.browser.ui.adapter.IntroAdapter
import com.quickstream.downloadmaster.browser.utils.Constant
import com.quickstream.downloadmaster.browser.utils.Preferences

class IntroActivity : AppCompatActivity() {

    lateinit var binding: ActivityIntroBinding
    var introList: ArrayList<Drawable?> = ArrayList()
    var selectedPos = 0
    var adapter2: IntroAdapter? = null
    var isOpenFromBrowser = false
    lateinit var preferences: Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIntroBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        preferences = Preferences(this)
        isOpenFromBrowser = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_FROM_BROWSER, false)
        binding.loutToolbar.txtTitle.text = getString(R.string.how_to_use)
        intiListener()
        getIntroList()
        adapter2 = IntroAdapter(this, introList)
        binding.viewpager.adapter = adapter2
        binding.dotsIndicator.setViewPager2(binding.viewpager)

    }

    private fun getIntroList() {
        if (isOpenFromBrowser) {
            introList.add(ContextCompat.getDrawable(this, R.drawable.ic_inro_insta_browser_3))
            introList.add(ContextCompat.getDrawable(this, R.drawable.ic_inro_insta_browser_4))
            introList.add(ContextCompat.getDrawable(this, R.drawable.ic_inro_insta_browser_1))
            introList.add(ContextCompat.getDrawable(this, R.drawable.ic_inro_insta_browser_2))
        } else {
            introList.add(ContextCompat.getDrawable(this, R.drawable.ic_inro_insta_1))
            introList.add(ContextCompat.getDrawable(this, R.drawable.ic_inro_insta_2))
            introList.add(ContextCompat.getDrawable(this, R.drawable.ic_inro_insta_3))
        }
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.btnNext.setOnClickListener {
            if (selectedPos < introList.size - 1) {
                selectedPos++
                binding.viewpager.currentItem = selectedPos
            } else {
                if (isOpenFromBrowser)
                    preferences.putInstagramIntro(true)
                finish()
            }
        }

        binding.viewpager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels)
                Log.e("viewpager2", "onPageScrolled $position")
                selectedPos = position
                binding.btnNext.setImageDrawable(
                    ContextCompat.getDrawable(
                        this@IntroActivity,
                        if (selectedPos == introList.size - 1) R.drawable.ic_done else R.drawable.ic_right
                    )
                )

            }

            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                selectedPos = position
            }

        })
    }
}