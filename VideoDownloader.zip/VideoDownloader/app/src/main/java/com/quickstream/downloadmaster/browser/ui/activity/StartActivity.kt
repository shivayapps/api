package com.quickstream.downloadmaster.browser.ui.activity

import android.content.Intent
import android.os.Bundle
import android.view.View

import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.quickstream.downloadmaster.browser.databinding.ActivityStartBinding
import com.quickstream.downloadmaster.browser.utils.Preferences
import com.quickstream.downloadmaster.browser.utils.UtilsAd

class StartActivity : BaseActivity() {

    lateinit var preferences: Preferences
    lateinit var binding: ActivityStartBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStartBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inti()
    }

    private fun inti() {
        preferences = Preferences(this)
        binding.btnAllow.setOnClickListener {
            preferences.putStart(true)
            if (!checkNotificationPermissions()) {
                requestPermission()
            } else {
                setNext()
            }
        }
        loadNative()
    }


    private fun setNext() {
        val intent = Intent(this, HomeActivity::class.java)
        intent.putExtra("isOpenFromStart", true)
        startActivity(intent)
        finish()
    }

    private fun requestPermission() {

//                StaticMethod.isPermiationDialogOpen = true;
        //MyApp.isDialogOpen=true;
        val REQUIRED_PERMISSIONS: Array<String> = arrayOf<String>(
            android.Manifest.permission.POST_NOTIFICATIONS
        )


//        PermissionManager.doPermissionTask(
//            this@StartActivity,
//            object : PermissionManager.callBack {
//                override fun doNext() {
////                    MyApp.isDialogOpen = false
//                    setNext()
//                }
//
//                override fun noPermission(hasAndroidPermissions: Boolean) {
////                    MyApp.isDialogOpen = false;
//                    setNext()
//                }
//            },
//            REQUIRED_PERMISSIONS
//        )


        Dexter.withContext(this@StartActivity)
            .withPermissions(
                android.Manifest.permission.POST_NOTIFICATIONS
            )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    report?.let {
                        setNext()
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<PermissionRequest>?,
                    token: PermissionToken?
                ) {
                    token?.continuePermissionRequest()
                }
            }).check()
    }

    private fun loadNative() {
//        binding.frameNative.visibility = View.VISIBLE
//        UtilsAd.showNative(this,binding.frameNative)
    }

    override fun onDestroy() {
        super.onDestroy()
//        MyApplication.storageCommon?.nativeAdsStart?.postValue(
//            null
//        )
    }
}