package com.quickstream.downloadmaster.browser.ui.data

data class CarouselMedia(
    val id: String,
    val media_type: Int,
    val image_versions2: ImageVersions,
    val video_versions: List<VideoVersion>,
    val original_width: Long,
    val original_height: Long,
    val product_type: String,
)