package com.quickstream.downloadmaster.browser.ui.fragment

import android.app.Activity
import android.app.Dialog
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.quickstream.downloadmaster.browser.utils.AppUrl
import com.google.firebase.analytics.FirebaseAnalytics
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.browser.event.DownloadDeleteEvent
import com.quickstream.downloadmaster.browser.browser.event.DownloadUpdateEvent
import com.quickstream.downloadmaster.browser.databinding.DialogDownloadBinding
import com.quickstream.downloadmaster.browser.databinding.DialogLoaderBinding
import com.quickstream.downloadmaster.browser.databinding.FragmentTwitterBinding
import com.quickstream.downloadmaster.browser.ui.activity.PermissionActivity
import com.quickstream.downloadmaster.browser.ui.adapter.DownloadViewAdapter2
import com.quickstream.downloadmaster.browser.ui.data.TwitterData
import com.quickstream.downloadmaster.browser.utils.Constant
import com.quickstream.downloadmaster.browser.utils.DownloadManager
import com.quickstream.downloadmaster.browser.utils.FileUtil
import com.quickstream.downloadmaster.browser.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocketFactory


class TwitterFragment() : Fragment() {

    lateinit var binding: FragmentTwitterBinding
    lateinit var clipBoard: ClipboardManager
    private var defaultSSLSF: SSLSocketFactory? = null
    var loaderDialog: Dialog? = null
    var adapter2: DownloadViewAdapter2? = null
    var downloadList: ArrayList<String> = ArrayList()
    var currUrl: String = ""
    var selectDeletePos = -1
    lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTwitterBinding.inflate(layoutInflater, container, false)
        inti()
        return binding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    @Subscribe
    fun onDownloadDeleteEvent(downloadDeleteEvent: DownloadDeleteEvent) {
        requireActivity().runOnUiThread {
            if (downloadDeleteEvent.isOpenType != 0 && downloadDeleteEvent.deletePath.isNotEmpty())
                if (downloadList.isNotEmpty()) {
                    val list = downloadList.filter { it == downloadDeleteEvent.deletePath }
                    if (list.isNotEmpty()) {
                        downloadList.remove(downloadDeleteEvent.deletePath)
                        if (adapter2 != null)
                            adapter2!!.notifyDataSetChanged()
                        if (downloadList.size == 0) {
                            binding.loutDisplayDownload.visibility = View.GONE
                        }
                    }
                }
        }
    }

    private fun inti() {
        firebaseAnalytics = FirebaseAnalytics.getInstance(requireActivity())
        clipBoard =
            requireActivity().getSystemService(AppCompatActivity.CLIPBOARD_SERVICE) as ClipboardManager
        intiListener()
        intiWebView()
        intiLoadingDialog()
        val bundle2 = Bundle()
        bundle2.putString("TwitterDownload_screen", "TwitterDownload_screen_open")
        firebaseAnalytics.logEvent("TwitterDownload_screen_open", bundle2)
    }

    private fun intiLoadingDialog() {
        val dialogBinding = DialogLoaderBinding.inflate(layoutInflater)
        loaderDialog = Dialog(requireActivity(), R.style.Theme_Dialog)
        loaderDialog!!.window?.requestFeature(Window.FEATURE_NO_TITLE)
        loaderDialog!!.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        loaderDialog!!.setCancelable(false)
        loaderDialog!!.setCanceledOnTouchOutside(false)
        loaderDialog!!.setContentView(dialogBinding.root)
    }

    private fun intiWebView() {
        defaultSSLSF = HttpsURLConnection.getDefaultSSLSocketFactory()
        binding.webView.settings.javaScriptEnabled = true
        binding.webView.webViewClient = MyBrowser(this, defaultSSLSF)
        binding.webView.webChromeClient = object : WebChromeClient() {

            override fun onProgressChanged(webView: WebView, i: Int) {
//                binding.swipeRefreshLayout.isRefreshing = i != 100
            }
        }
    }

    private fun intiListener() {
        binding.btnPaste.setOnClickListener {
            pasteText()
//            startActivity(
//                Intent(requireActivity(), BrowserDownloadActivity::class.java).putExtra(
//                    Constant.PUT_KEY_URL, binding.edtPasteUrl.text.toString()
//                ).putExtra(
//                    Constant.EXTRA_TYPE, ""
//                )
//            )
//            startActivity(
//                Intent(requireActivity(), TwitterActivity::class.java).putExtra(
//                    Constant.PUT_KEY_URL, binding.edtPasteUrl.text.toString()
//                )
//            )
        }
        binding.btnDownload.setOnClickListener {
            checkValidation()
        }
    }

    private fun startLoading() {
        binding.loutDisplayDownload.visibility = View.GONE
        loaderDialog?.show()
    }

    private fun finishLoading() {
        loaderDialog?.dismiss()
    }

    private fun checkValidation() {
        val url = binding.edtPasteUrl.text.toString()
        if (!Utils.isNetworkAvailable(requireActivity())) {
            Toast.makeText(
                requireActivity(),
                getString(R.string.internet_connection_msg),
                Toast.LENGTH_SHORT
            ).show()
            return
        } else
            if (url.contains("twitter.com")) {
                if (checkStoragePermissions()) {
                    apiCalling = false
                    downloadingStart = false
                    startLoading()
                    currUrl = url
                    val hashMap = HashMap<String, String>()
                    hashMap["User-Agent"] =
                        "Mozilla/5.0 (Linux; Android 8.0.0; Nexus 5X Build/OPR4.170623.006) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Mobile Safari/537.36"
                    binding.webView.loadUrl(currUrl)
                } else
                    permissionLauncher.launch(
                        Intent(
                            requireActivity(),
                            PermissionActivity::class.java
                        )
                    )
            } else {
                Toast.makeText(
                    requireActivity(),
                    getString(R.string.url_instagram_validation),
                    Toast.LENGTH_SHORT
                ).show()
                return
            }
    }

    var permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                checkValidation()
            }
        }

    fun checkStoragePermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                requireActivity(),
                android.Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                requireActivity(),
                android.Manifest.permission.READ_MEDIA_VIDEO
            ) == PackageManager.PERMISSION_GRANTED
        } else
            ActivityCompat.checkSelfPermission(
                requireActivity(),
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
    }

    override fun onResume() {
        super.onResume()
        Handler(Looper.myLooper()!!).postDelayed({ pasteText() }, 200)
    }

    private fun pasteText() {
        binding.edtPasteUrl.setText("")
        if (!::clipBoard.isInitialized)
            clipBoard =
                requireActivity().getSystemService(AppCompatActivity.CLIPBOARD_SERVICE) as ClipboardManager

        try {
            if (!clipBoard.hasPrimaryClip()) {
            } else if (!clipBoard.primaryClipDescription!!.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)) {
                if (clipBoard.primaryClip!!.getItemAt(0).text.toString()
                        .contains("twitter.com")
                ) {
                    binding.edtPasteUrl.setText(clipBoard.primaryClip!!.getItemAt(0).text.toString())
                    binding.edtPasteUrl.setSelection(binding.edtPasteUrl.text.toString().length)
                    Log.e(
                        "",
                        "pasteText ==>> else if ==>> ${clipBoard.primaryClip!!.getItemAt(0).text.toString()}"
                    )
                }
            } else {
                val item = clipBoard.primaryClip!!.getItemAt(0)
                if (item.text.toString().contains("twitter.com")) {
                    binding.edtPasteUrl.setText(item.text.toString())
                    binding.edtPasteUrl.setSelection(binding.edtPasteUrl.text.toString().length)
                    Log.e("", "pasteText ==>> else ==>> ${item.text.toString()}")
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("", "pasteText ==>> message==>> ${e.message}")
        }
    }

    private fun showDisplayDownloadData(filePath: String) {
        downloadList.clear()
        downloadList.add(filePath)
        finishLoading()

        binding.loutDisplayDownload.visibility = View.VISIBLE

        adapter2 = DownloadViewAdapter2(requireActivity(), downloadList, deleteListener = {
            selectDeletePos = it
            val file1 = File(downloadList[selectDeletePos])
            val d = file1.delete()
            if (d) {
                updateToDelete()
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                FileUtil.deleteWithoutManageExternalStorage(downloadList[it], requireActivity())
            }
        })
        binding.viewpagerDownload2.adapter = adapter2
        binding.dotsIndicator.attachTo(binding.viewpagerDownload2)

        if (downloadList.size == 1)
            binding.dotsIndicator.visibility = View.GONE
        else
            binding.dotsIndicator.visibility = View.VISIBLE
    }

    private fun updateToDelete() {
        EventBus.getDefault()
            .post(DownloadDeleteEvent(downloadList[selectDeletePos], 0))
        downloadList.removeAt(selectDeletePos)
        adapter2?.notifyDataSetChanged()
        if (downloadList.size == 0) {
            binding.loutDisplayDownload.visibility = View.GONE
        } else {
            if (selectDeletePos == downloadList.size)
                binding.viewpagerDownload2.currentItem = downloadList.size - 1
            else if (selectDeletePos < downloadList.size)
                binding.viewpagerDownload2.currentItem = selectDeletePos
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Constant.DELETE_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            updateToDelete()
        }
    }

    var downloadingStart = false
    private fun downloadUrl(
        url: String, type: Int
    ) {
        if (!downloadingStart) {
            downloadingStart = true
            Log.e("", "downloadUrl==>>  $url")
            if (url.isNullOrEmpty()) {
                Toast.makeText(
                    requireActivity(),
                    getText(R.string.download_fail_msg),
                    Toast.LENGTH_SHORT
                ).show()
                return
            }

            var dialogBinding: DialogDownloadBinding
            var dialog: Dialog

            requireActivity().runOnUiThread {
                dialogBinding = DialogDownloadBinding.inflate(layoutInflater)
                dialog = Dialog(requireActivity(), R.style.Theme_Dialog)
                dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
                dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog.setCancelable(false)
                dialog.setCanceledOnTouchOutside(false)
                dialog.setContentView(dialogBinding.root)
                dialogBinding.progressBar.progress = 0
                dialogBinding.txtPer.text = "0%"
                dialogBinding.txtCount.text = "0/100"
                dialog.show()
                val dateFormated =
                    SimpleDateFormat("dd_MMM_yyyy_HH_mm_ss").format(Calendar.getInstance().timeInMillis)
                val fileName = "${if (type == Constant.TYPE_IMAGE) "Img" else "Vid"}_$dateFormated"

                val downloadManager = DownloadManager(requireActivity())
                Observable.fromCallable {
                    requireActivity().runOnUiThread {
                        dialogBinding.progressBar.progress = 0
                        dialogBinding.txtPer.text = "0%"
                        dialogBinding.txtCount.text = "0/100"
                    }
                    val path = downloadManager.downloadFile(
                        url,
                        Constant.TYPE_TWITTER,
                        fileName,
                        type,
                        progressUpdateListener = {
                            requireActivity().runOnUiThread {
                                dialogBinding.progressBar.progress = it
                                dialogBinding.txtPer.text = "$it%"
                                dialogBinding.txtCount.text = "$it/100"
                            }
                        })

                    return@fromCallable path
                }.subscribeOn(Schedulers.io())
                    .doOnError { throwable: Throwable? ->
                        requireActivity().runOnUiThread {
                            dialog.dismiss()
                            Toast.makeText(
                                requireActivity(),
                                getText(R.string.download_fail_msg),
                                Toast.LENGTH_SHORT
                            ).show()
                            downloadingStart = false
                        }
                    }
                    .subscribe { result: String? ->
                        Log.e("", "download result==>> $result ")
                        requireActivity().runOnUiThread {
                            downloadingStart = false
                            dialog.dismiss()
                            if (!result.isNullOrEmpty()) {
                                EventBus.getDefault()
                                    .post(DownloadUpdateEvent(""))
                                showDisplayDownloadData(result)
                            } else {
                                Toast.makeText(
                                    requireActivity(),
                                    getText(R.string.download_fail_msg),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
            }
        }
    }

    var apiCalling: Boolean = false
    private fun findVideo(currUrl: String) {
        if (!apiCalling) {
            apiCalling = true
            val str: String
            val split: Array<String> =
                currUrl.split("/").dropLastWhile { it.isEmpty() }
                    .toTypedArray()
            str = if (split[split.size - 1].contains("?")) {
                split[split.size - 1].split("\\?".toRegex()).dropLastWhile { it.isEmpty() }
                    .toTypedArray()[0]
            } else {
                split[split.size - 1]
            }
            val appEncrypt = AppUrl()
            val str2 = str
            val hashMap: java.util.HashMap<String, String> = java.util.HashMap<String, String>()

            val orderBy: String = appEncrypt.twitterOrderBy()
            val nope = appEncrypt.twitterNope()
            val AA = orderBy.toCharArray()[1]
            val BB = orderBy.toCharArray()[3]
            val CC = orderBy.toCharArray()[5]
            val DD = orderBy.toCharArray()[1]

            hashMap["id"] = str2
            hashMap["token"] = "$AA$BB$CC$DD$nope$CC$DD"
            val token = "$AA$BB$CC$DD$nope$CC$DD"

            val newRequestQueue = Volley.newRequestQueue(requireContext())
            val stringRequest: StringRequest =
                object : StringRequest(1, appEncrypt.twitterBaseURL(),
                    Response.Listener<String?> { str3 ->
                        Log.e("findVideo", "onResponse==>> $str3")
                        getVideos(str3)
                    }, Response.ErrorListener { volleyError ->
                        requireActivity().runOnUiThread {
                            finishLoading()
                            Toast.makeText(
                                requireContext(),
                                getString(R.string.download_fail_msg),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }) {
                    override fun getParams(): Map<String, String> {
                        val hashMap: HashMap<String, String> = HashMap<String, String>()
                        hashMap["id"] = str2
                        hashMap["token"] = token
                        return hashMap
                    }
                }
            stringRequest.retryPolicy = DefaultRetryPolicy(60000, 1, 1.0f)
            newRequestQueue.add(stringRequest)
        }
    }

    private fun getVideos(str3: String) {

        val arrayList: ArrayList<TwitterData> = ArrayList()
        var errorMsg = getString(R.string.no_media_found)
        Observable.fromCallable {
            var jSONObject: JSONObject? = null
            var str: String
            var i = 0
            val str2: String = str3
            try {
                jSONObject = JSONObject(str2)
            } catch (unused: Exception) {
                unused.printStackTrace()

            }

            if (jSONObject != null)
                if (jSONObject.getString("state") == "error") {
                    errorMsg = getString(R.string.no_media_found)
//                    errorMsg = when (jSONObject.getInt("error_code")) {
//                        1 -> getString(R.string.onairtweetcantdownload)
//                        2 -> getString(R.string.notweetfounded)
//                        3 -> getString(R.string.nomediaontweet)
//                        else -> ""
//                    }
                } else if (jSONObject.getString("state") == "success") {
                    val jSONArray = jSONObject.getJSONArray("videos")
                    var i2 = 0
                    while (i2 < jSONArray.length()) {
                        val thumbURL: String = jSONArray.getJSONObject(i2).getString("thumb")
                        val d =
                            (jSONArray.getJSONObject(i2)
                                .getDouble("size") / 1048576.0).toString()
                        val substring = d.substring(i, Math.min(d.length, 4))
//                    val string: String = this@TwitFragment.getString(R.string.image)
                        val url = jSONArray.getJSONObject(i2).getString("url")
//                        .replace("http", ProxyConfig.MATCH_HTTPS)
                        str = " mb"
                        val fileType = jSONArray.getJSONObject(i2).getString("type")

                        arrayList.add(
                            TwitterData(
                                thumbURL,
                                url,
                                "$substring$str",
                                when (fileType) {
                                    "video" -> Constant.TYPE_VIDEO
                                    "image" -> Constant.TYPE_IMAGE
                                    else -> 0
                                }
                            )
                        )
                        i2++
                        i = 0
                    }
                }

            return@fromCallable ""
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                requireActivity().runOnUiThread {
                    finishLoading()
                    Toast.makeText(
                        requireActivity(),
                        errorMsg.ifEmpty { requireActivity().getText(R.string.download_fail_msg) },
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }.subscribe { result: String? ->
                Log.e("", "getReels result==>> $result ")
                requireActivity().runOnUiThread {
                    finishLoading()
                    if (arrayList.isNotEmpty()) {
                        var data = arrayList[arrayList.size - 1]
                        downloadUrl(data.url, data.type)
                    } else {
                        Toast.makeText(
                            requireActivity(),
                            errorMsg.ifEmpty { requireActivity().getText(R.string.download_fail_msg) },
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }

    }

    fun shareUrl(shareUrl: String) {
        binding.edtPasteUrl.setText(shareUrl)
        checkValidation()
    }

    class MyBrowser(
        var activity: TwitterFragment,
        var defaultSSLSF: SSLSocketFactory?,
    ) : WebViewClient() {

        override fun shouldOverrideUrlLoading(webView: WebView, str: String?): Boolean {
//            val mimeType = URLConnection.guessContentTypeFromName(str)
//            if (mimeType != null && mimeType.startsWith("image")) {
//                Log.e("", " MyBrowser type==>> image $str")
//            }
            webView.loadUrl(str!!)
            return true
        }

        override fun onPageFinished(webView: WebView?, str: String?) {
            super.onPageFinished(webView, str)
            Log.e("", "MyBrowser onPageFinished")
//            activity.finishLoading()
        }

        override fun onLoadResource(view: WebView, url: String) {
            Log.d("fb :", "URL: $url")
            val viewUrl = view.url
            val title = view.title
            object : com.quickstream.downloadmaster.browser.customView.VideoContentSearch(activity.requireActivity(), url, viewUrl, title) {
                override fun onStartInspectingURL() {
                    Log.e("", "MyBrowser onStartInspectingURL")
//                                            Utils.Companion.disableSSLCertificateChecking()

                }

                override fun onFinishedInspectingURL(finishedAll: Boolean) {
                    Log.e("", "MyBrowser onFinishedInspectingURL")
                    HttpsURLConnection.setDefaultSSLSocketFactory(defaultSSLSF)
//                    activity.finishLoading()
                }

                override fun onVideoFound(
                    size: String?,
                    type: String?,
                    link: String?,
                    name: String?,
                    page: String?,
                    chunked: Boolean,
                    website: String?,
                    audio: Boolean
                ) {
                    Log.e(
                        "",
                        "MyBrowser sizee==>> $size type==>> $type link==>> $link name==>> $name page==>> $page "
                    )
                    if (!type.isNullOrEmpty())
                        activity.requireActivity().runOnUiThread {
                            if (type == "image" && !link.isNullOrEmpty()) {
                                activity.binding.webView.loadUrl("")
                                activity.currUrl = ""
                                activity.downloadUrl(link, Constant.TYPE_IMAGE)
                                activity.finishLoading()

                            } else if (type.startsWith("video") || type.startsWith("mp4")) {
                                activity.binding.webView.loadUrl("")
                                activity.findVideo(activity.currUrl)
                            } else {
                                activity.currUrl = ""
                                activity.binding.webView.loadUrl("")
                                activity.finishLoading()
                            }
                        }
//                    if (!link.isNullOrEmpty())
//                        activity.downloadUrl(link, Constant.TYPE_VIDEO)
                    //                        videoList.addItem(size, type, link, name, page, chunked, website, audio)
                    //                        updateFoundVideosBar()
                }
            }.start()
        }
    }


    companion object {

        @JvmStatic
        fun newInstance() = TwitterFragment()
    }
}