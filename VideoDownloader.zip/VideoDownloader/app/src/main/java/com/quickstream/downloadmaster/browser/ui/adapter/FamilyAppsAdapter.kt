package com.quickstream.downloadmaster.browser.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.quickstream.downloadmaster.browser.databinding.ItemAppsBinding
import com.quickstream.downloadmaster.browser.ui.data.FamilyAppsModel


class FamilyAppsAdapter(var context: Context, var list: ArrayList<FamilyAppsModel>, val clickListener: (pos: Int) -> Unit) : RecyclerView.Adapter<FamilyAppsAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemAppsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val model = list[position]
        holder.binding.tvTitle.text = model.appName
        holder.binding.tvDesc.text = model.shortDescription
        Glide.with(holder.binding.imgLogo.context)
            .load(model.appImageLink)
            .into(holder.binding.imgLogo)

        holder.itemView.setOnClickListener {
            clickListener(position)
        }

    }

    class ViewHolder(var binding: ItemAppsBinding) : RecyclerView.ViewHolder(binding.root)
}