package com.quickstream.downloadmaster.browser.ui.data

class DpGeneratorCategoryResponse : ArrayList<DpGeneratorCategoryList>()