package com.quickstream.downloadmaster.browser.messaging

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.quickstream.downloadmaster.browser.R

object NotificationHelper {

    fun createNotificationChannel(context: Context, title: String, message: String, importance: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel("downloadmaster_channel", title, importance).apply {
                description = message
            }
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun submitNotification(context: Context, title: String, message: String) {
        val notificationManager = NotificationManagerCompat.from(context)

        val notification =
            NotificationCompat.Builder(context, "downloadmaster_channel")
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()

        if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            notificationManager.notify(111, notification)
        }
    }

    fun submitProgressNotification(context: Context, title: String, message: String, progress: Int) {
        val notificationManager = NotificationManagerCompat.from(context)
        var m = 100
        var p = progress
        if (progress < 0) {
            m = 0
            p = 0
        }

        val notification =
            NotificationCompat.Builder(context, "downloadmaster_channel")
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setProgress(m, p, false)
                .build()

        if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            notificationManager.notify(111, notification)
        }
    }
}