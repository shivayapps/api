package com.quickstream.downloadmaster.browser.browser.event;

import com.quickstream.downloadmaster.browser.browser.helpers.FBContainerModel;

import java.util.ArrayList;
import java.util.List;


public class NeedModifyFBHtmlEvent {
    private List<FBContainerModel> containers;

    public NeedModifyFBHtmlEvent(List<FBContainerModel> list) {
        new ArrayList();
        this.containers = list;
    }

    public List<FBContainerModel> getContainers() {
        return this.containers;
    }

    public void setContainers(List<FBContainerModel> list) {
        this.containers = list;
    }
}
