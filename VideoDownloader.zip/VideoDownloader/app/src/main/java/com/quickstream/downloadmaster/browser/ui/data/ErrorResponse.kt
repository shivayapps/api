package com.quickstream.downloadmaster.browser.ui.data

import java.io.Serializable

data class ErrorResponse(
    val message: String?,
    val require_login: Boolean,
    val status: String?
):Serializable