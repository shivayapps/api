package com.quickstream.downloadmaster.browser.ui.activity

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.adconfig.AdsConfig
import com.google.android.gms.tasks.Task
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.databinding.ActivitySettingBinding
import com.quickstream.downloadmaster.browser.databinding.ThemeDialogLayoutBinding
import com.quickstream.downloadmaster.browser.ui.adapter.FamilyAppsAdapter
import com.quickstream.downloadmaster.browser.ui.data.FamilyAppsModel
import com.quickstream.downloadmaster.browser.utils.MyApplication
import com.quickstream.downloadmaster.browser.utils.Preferences
import com.quickstream.downloadmaster.browser.utils.Utils
import org.json.JSONObject


class SettingActivity : BaseActivity() {
    lateinit var binding: ActivitySettingBinding
    var themeValue = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inits()
        intiListener()
    }

    //https://www.figma.com/design/qrddnOBjkxA4OE8GZX1r3t/Dating-app-%2F-Prototype-(Community)?node-id=1-2046&node-type=canvas&t=LBFyeRudWf54ZPUm-0

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.llFamilyApp.setOnClickListener {
            startActivity(Intent(this, FamilyAppActivity::class.java))
        }
        binding.swDarkMode.isChecked = themeValue == 1
        binding.swDarkMode.setOnCheckedChangeListener { compoundButton, isChecked ->
            if (isChecked) {
                themeValue = 1
            } else {
                themeValue = 0
            }
            changeTheme(themeValue)
        }
//        binding.llDarkMode.setOnClickListener {
//            val builder = AlertDialog.Builder(this, R.style.CustomAlertDialog).create()
//            val themeDialogLayoutBinding: ThemeDialogLayoutBinding =
//                ThemeDialogLayoutBinding.inflate(LayoutInflater.from(this))
//            builder.setView(themeDialogLayoutBinding.root)
//            when (themeValue) {
//                0 -> {
//                    setThemeLayout(themeDialogLayoutBinding.ivLight, themeDialogLayoutBinding, 0)
//                }
//                1 -> {
//                    setThemeLayout(themeDialogLayoutBinding.ivDark, themeDialogLayoutBinding, 1)
//                }
//                else -> {
//                    setThemeLayout(themeDialogLayoutBinding.ivLight, themeDialogLayoutBinding, 0)
//                }
//            }
//            themeDialogLayoutBinding.ivLight.setOnClickListener {
//                setThemeLayout(themeDialogLayoutBinding.ivLight, themeDialogLayoutBinding, 0)
//            }
//            themeDialogLayoutBinding.ivDark.setOnClickListener {
//                setThemeLayout(themeDialogLayoutBinding.ivDark, themeDialogLayoutBinding, 1)
//            }
//            themeDialogLayoutBinding.ivDefault.setOnClickListener {
//                setThemeLayout(themeDialogLayoutBinding.ivDefault, themeDialogLayoutBinding, 0)
//            }
//            themeDialogLayoutBinding.tvCancel.setOnClickListener {
//                builder.dismiss()
//            }
//
//            themeDialogLayoutBinding.tvOk.setOnClickListener {
//                builder.dismiss()
//                if (themeValue != Preferences(this).getThemeValue()) {
//                    Preferences(this).putTheme(themeValue)
//                    if (themeValue == 0) {
//                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
//                    } else {
//                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
//                    }
//                    val intent = Intent(this, SettingActivity::class.java)
//                    setResult(RESULT_OK)
//                    finish()
//                    overridePendingTransition(0, 0)
//                    startActivity(intent)
//                    overridePendingTransition(0, 0)
//                }
//            }
//            builder.show()
//        }
        binding.llShare.setOnClickListener {
            try {
                val sendIntent = Intent()
                sendIntent.action = Intent.ACTION_SEND
                sendIntent.putExtra(
                    Intent.EXTRA_TEXT,
                    "Check out the App at: https://play.google.com/store/apps/details?id=$packageName"
                )
                sendIntent.type = "text/plain"
                MyApplication.disabledOpenAds()
                startActivity(sendIntent)
            } catch (e: Exception) {

            }
        }
        binding.llRateUs.setOnClickListener {
//            showRateDialog()
            AdsConfig.isSystemDialogOpen = true
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=$packageName")
                )
            )
        }
        binding.llPrivacyPolicy.setOnClickListener {
            val url = getPrivacyPolicy()
            if (url != null && url.isNotEmpty()) {
                try {
                    val builder: CustomTabsIntent.Builder = CustomTabsIntent.Builder()
                    builder.setToolbarColor(ContextCompat.getColor(this, R.color.white))
                    MyApplication.disabledOpenAds()
                    val customTabsIntent: CustomTabsIntent = builder.build()
                    customTabsIntent.intent.setPackage("com.android.chrome")
                    customTabsIntent.launchUrl(this, Uri.parse(url))

                } catch (e: Exception) {
                    val i = Intent(Intent.ACTION_VIEW)
                    i.data = Uri.parse(url)
                    MyApplication.disabledOpenAds()
                    startActivity(i)
                }
            }
        }

        binding.llFeedback.setOnClickListener {
//            startActivity(Intent(this, FeedbackActivity::class.java))
            sendEmailIntent(getReviewEmail())
        }
    }

    fun Context.sendEmailIntent(recipient: String) {
        Intent(Intent.ACTION_SENDTO).putExtra(
            Intent.EXTRA_SUBJECT,
            "${getString(R.string.app_name)} ${getString(R.string.feedback)}"
        ).apply {
            data = Uri.fromParts("mailto", recipient, null)

            try {
                MyApplication.disabledOpenAds()
                startActivity(this)
                finishAffinity()
//                adConfigFinishAffinity()
                MyApplication.isAppIsRunning = false
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(
                    this@SettingActivity, getString(R.string.not_installed), Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) {
                Toast.makeText(
                    this@SettingActivity, getString(R.string.not_installed), Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun changeTheme(themeValue: Int) {
        if (themeValue != Preferences(this).getThemeValue()) {
            Preferences(this).putTheme(themeValue)
            if (themeValue == 0) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
            val intent = Intent(this, SettingActivity::class.java)
            setResult(RESULT_OK)
            finish()
            overridePendingTransition(0, 0)
            startActivity(intent)
            overridePendingTransition(0, 0)
        }
    }

    private fun inits() {
        themeValue = Preferences(this).getThemeValue()
        binding.loutToolbar.txtTitle.text = getString(R.string.setting)
        binding.tvClearCache.text = Utils.convertFileSize(Utils.getCacheSize(this))
    }

    private fun setThemeLayout(
        selectImage: ImageView,
        themeBinding: ThemeDialogLayoutBinding,
        themeInt: Int,
    ) {
        themeBinding.ivDark.setImageResource(R.drawable.ic_un_select)
        themeBinding.ivLight.setImageResource(R.drawable.ic_un_select)
        themeBinding.ivDefault.setImageResource(R.drawable.ic_un_select)
        selectImage.setImageResource(R.drawable.ic_select)
        themeValue = themeInt
    }

//    private fun showRateDialog() {
//        val mailId = getReviewEmail()
//        val dialogBinding = DialogRateBinding.inflate(layoutInflater)
//        val dialog = Dialog(this, R.style.Theme_DialogRate)
//        dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
//        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        dialog.setCancelable(false)
//        dialog.setCanceledOnTouchOutside(false)
//        dialog.setContentView(dialogBinding.root)
//
//        dialogBinding.btnCancel.setTextColor(ContextCompat.getColor(this, R.color.whiteColor))
//        dialogBinding.btnCancel.background =
//            ContextCompat.getDrawable(this, R.drawable.btn_button_dialog)
//        dialogBinding.btnSubmit.setTextColor(ContextCompat.getColor(this, R.color.rate_disable))
//        dialogBinding.btnSubmit.background =
//            ContextCompat.getDrawable(this, R.drawable.no_button_bg)
//
//        dialog.show()
//
//        dialogBinding.btnCancel.setOnClickListener {
//            dialog.dismiss()
//        }
//        dialogBinding.btnSubmit.setOnClickListener {
//            if (dialogBinding.simpleRatingBar.rating != 0.0f) {
//                dialog.dismiss()
//                if (dialogBinding.simpleRatingBar.rating == 5.0f) {
//                    MyApplication.disabledOpenAds()
//                    startActivity(
//                        Intent(
//                            Intent.ACTION_VIEW,
//                            Uri.parse("http://play.google.com/store/apps/details?id=$packageName")
//                        )
//                    )
//
//                } else {
//                    val i = Intent(Intent.ACTION_SEND)
//                    i.type = "message/rfc822"
//                    i.putExtra(Intent.EXTRA_EMAIL, arrayOf(mailId))
//                    i.putExtra(
//                        Intent.EXTRA_SUBJECT,
//                        "${getString(R.string.app_name)} ${getString(R.string.feedback)}"
//                    )
//                    i.putExtra(Intent.EXTRA_TEXT, "")
//                    i.setPackage("com.google.android.gm")
//                    try {
//                        MyApplication.disabledOpenAds()
//                        startActivity(Intent.createChooser(i, getString(R.string.Send_mail)))
//                    } catch (ex: ActivityNotFoundException) {
//                        Toast.makeText(
//                            this,
//                            getString(R.string.not_installed),
//                            Toast.LENGTH_SHORT
//                        ).show()
//                    }
//                }
//            }
//        }
//
//        dialogBinding.simpleRatingBar.setOnRatingChangeListener { ratingBar, rating, fromUser ->
//            var alpha = 1.0f
//            if (rating == 0f) {
//                dialogBinding.btnCancel.setTextColor(
//                    ContextCompat.getColor(
//                        this,
//                        R.color.whiteColor
//                    )
//                )
//                dialogBinding.btnCancel.background =
//                    ContextCompat.getDrawable(this, R.drawable.btn_button_dialog)
//
//                dialogBinding.btnSubmit.setTextColor(
//                    ContextCompat.getColor(
//                        this,
//                        R.color.rate_disable
//                    )
//                )
//                dialogBinding.btnSubmit.background =
//                    ContextCompat.getDrawable(this, R.drawable.no_button_bg)
//            } else {
//                dialogBinding.btnSubmit.setTextColor(
//                    ContextCompat.getColor(
//                        this,
//                        R.color.whiteColor
//                    )
//                )
//                dialogBinding.btnCancel.setTextColor(
//                    ContextCompat.getColor(
//                        this,
//                        R.color.searchHint
//                    )
//                )
//                dialogBinding.btnSubmit.background =
//                    ContextCompat.getDrawable(this, R.drawable.btn_button_dialog)
//                dialogBinding.btnCancel.background =
//                    ContextCompat.getDrawable(this, R.drawable.no_button_bg)
//            }
//            when (rating) {
//                1.0f -> {
//                    dialogBinding.ivRateEmoji.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            this,
//                            R.drawable.ic_rate_1
//                        )
//                    )
//                    dialogBinding.tvTitle.text = getString(R.string.rateTitle1)
//                }
//
//                2.0f -> {
//                    dialogBinding.ivRateEmoji.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            this,
//                            R.drawable.ic_rate_2
//                        )
//                    )
//                    dialogBinding.tvTitle.text = getString(R.string.rateTitle2)
//                }
//
//                3.0f -> {
//                    dialogBinding.ivRateEmoji.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            this,
//                            R.drawable.ic_rate_3
//                        )
//                    )
//                    dialogBinding.tvTitle.text = getString(R.string.rateTitle3)
//                }
//
//                4.0f -> {
//                    dialogBinding.ivRateEmoji.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            this,
//                            R.drawable.ic_rate_4
//                        )
//                    )
//                    dialogBinding.tvTitle.text = getString(R.string.rateTitle4)
//                }
//
//                5.0f -> {
//                    dialogBinding.ivRateEmoji.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            this,
//                            R.drawable.ic_rate_5
//                        )
//                    )
//                    dialogBinding.tvTitle.text = getString(R.string.rateTitle5)
//                }
//
//                else -> {
//                    alpha = 0.5f
//                    dialogBinding.ivRateEmoji.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            this,
//                            R.drawable.ic_rate_5
//                        )
//                    )
//                    dialogBinding.tvTitle.text = getString(R.string.likeApp)
//                    dialogBinding.tvMsg.text = getString(R.string.rateMsg)
//                }
//
//            }
//
//            dialogBinding.btnSubmit.alpha = alpha
//        }
//    }

    private fun startReviewFlow() {
        if (reviewInfo != null) {
            val flow: Task<Void> = reviewManager!!.launchReviewFlow(this, reviewInfo!!)
            flow.addOnCompleteListener {
                Toast.makeText(
                    applicationContext,
                    getString(R.string.Rating_complete),
                    Toast.LENGTH_LONG
                ).show()
            }
        } else {
            Toast.makeText(applicationContext, getString(R.string.Rating_failed), Toast.LENGTH_LONG)
                .show()
        }
    }
}