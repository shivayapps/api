package com.quickstream.downloadmaster.browser.ui.data

data class DownloadData(
    var url: String,
    var fileType: Int,
    var posterId: String,
    var openType: String = "",
    var status: DownloadStatus = DownloadStatus.RUNNING,
    var downloadId: Long = -1L,
    var progress: Int = 0,
    var fileSize: Long = -1L,
    var isChecked: Boolean = true
)

enum class DownloadStatus {
    RUNNING,
    PAUSED,
    CANCELED
}

