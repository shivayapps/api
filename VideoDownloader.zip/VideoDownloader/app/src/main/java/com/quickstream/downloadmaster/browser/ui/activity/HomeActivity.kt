package com.quickstream.downloadmaster.browser.ui.activity

import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView


import com.google.android.gms.tasks.Task
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.databinding.ActivityHomeBinding
import com.quickstream.downloadmaster.browser.databinding.DialogExitBinding
import com.quickstream.downloadmaster.browser.ui.activity.option.BrowserDownloadActivity
import com.quickstream.downloadmaster.browser.ui.activity.option.DPDownloaderActivity
import com.quickstream.downloadmaster.browser.ui.activity.option.InstaStoryActivity
import com.quickstream.downloadmaster.browser.ui.activity.option.InstagramActivity
import com.quickstream.downloadmaster.browser.ui.activity.option.dpGenerator.DPGeneratorActivity
import com.quickstream.downloadmaster.browser.utils.AdCache
import com.quickstream.downloadmaster.browser.utils.AppUrl
import com.quickstream.downloadmaster.browser.utils.Constant
import com.quickstream.downloadmaster.browser.utils.MyApplication
import com.quickstream.downloadmaster.browser.utils.Preferences
import com.quickstream.downloadmaster.browser.utils.UtilsAd

class HomeActivity : BaseActivity() {

    lateinit var binding: ActivityHomeBinding
    lateinit var preferences: Preferences
    var rateCounter: Int = 0
    var isPause = false
    var isOpenFromStart = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        MyApplication.isOpenHomeScreen = true
        intView()
    }

    private fun intView() {
        preferences = Preferences(this)
        isOpenFromStart = intent.getBooleanExtra("isOpenFromStart", false)
        intiListener()

        Log.e("", " isOpenFromStart $isOpenFromStart")
        if (!isOpenFromStart)
            if (!checkNotificationPermissions()) requestPermissionNotification()

//        if (isHomeNativeOn()) {
//            loadNative()
//        } else {
        loadBannerAd()
//        }

//        checkForAppUpdate(binding.loutMain)
//        loadUrl()
    }

//    private fun loadUrl() {
//        val appEncrypt = AppUrl()
//        Log.e("AppEncrypt","==============================================================>>");
//        Log.e("AppEncrypt","hashTagBaseURL==>>"+appEncrypt.hashTagBaseURL()+"<<==");
//        Log.e("AppEncrypt","frameBaseURL==>>"+appEncrypt.frameBaseURL()+"<<==");
//        Log.e("AppEncrypt","instagramBaseURL==>>"+appEncrypt.instagramBaseURL()+"<<==");
//        Log.e("AppEncrypt","hashtagListENDURL==>>"+appEncrypt.hashtagListENDURL()+"<<==");
//        Log.e("AppEncrypt","dpGeneratorCategoryListENDURL==>>"+appEncrypt.dpGeneratorCategoryListENDURL()+"<<==");
//        Log.e("AppEncrypt","dpGeneratorSubcategoryListENDURL==>>"+appEncrypt.dpGeneratorSubcategoryListENDURL()+"<<==");
//        Log.e("AppEncrypt","instagramCopyENDURL==>>"+appEncrypt.instagramCopyENDURL()+"<<==");
//        Log.e("AppEncrypt","callResultUserAgent1==>>"+appEncrypt.callResultUserAgent1()+"<<==");
//        Log.e("AppEncrypt","callResultUserAgent2==>>"+appEncrypt.callResultUserAgent2()+"<<==");
//        Log.e("AppEncrypt","cookieStart==>>"+appEncrypt.cookieStart()+"<<==");
//        Log.e("AppEncrypt","cookieEnd==>>"+appEncrypt.cookieEnd()+"<<==");
//        Log.e("AppEncrypt","DpSearchBaseURL==>>"+appEncrypt.DpSearchBaseURL()+"<<==");
//        Log.e("AppEncrypt","DpSearchENDURL==>>"+appEncrypt.DpSearchENDURL()+"<<==");
//        Log.e("AppEncrypt","callResultUserAgent3==>>"+appEncrypt.callResultUserAgent3()+"<<==");
//        Log.e("AppEncrypt","HDDpSearchBaseURL==>>"+appEncrypt.HDDpSearchBaseURL()+"<<==");
//        Log.e("AppEncrypt","HDDpSearchEndURL==>>"+appEncrypt.HDDpSearchEndURL()+"<<==");
//        Log.e("AppEncrypt","StoriesFullDetailURL==>>"+appEncrypt.StoriesFullDetailURL()+"<<==");
//        Log.e("AppEncrypt","storiesApiURL==>>"+appEncrypt.storiesApiURL()+"<<==");
//        Log.e("AppEncrypt","callResultUserAgent4==>>"+appEncrypt.callResultUserAgent4()+"<<==");
//        Log.e("AppEncrypt","storiesFullDetailHeader0==>>"+appEncrypt.storiesFullDetailHeader0()+"<<==");
//        Log.e("AppEncrypt","storiesFullDetailHeader1==>>"+appEncrypt.storiesFullDetailHeader1()+"<<==");
//        Log.e("AppEncrypt","storiesFullDetailHeader2==>>"+appEncrypt.storiesFullDetailHeader2()+"<<==");
//        Log.e("AppEncrypt","storiesFullDetailHeader3==>>"+appEncrypt.storiesFullDetailHeader3()+"<<==");
//        Log.e("AppEncrypt","storiesFullDetailHeader4==>>"+appEncrypt.storiesFullDetailHeader4()+"<<==");
//        Log.e("AppEncrypt","storiesFullDetailHeader5==>>"+appEncrypt.storiesFullDetailHeader5()+"<<==");
//        Log.e("AppEncrypt","storiesFullDetailHeader6==>>"+appEncrypt.storiesFullDetailHeader6()+"<<==");
//        Log.e("AppEncrypt","storiesFullDetailHeader7==>>"+appEncrypt.storiesFullDetailHeader7()+"<<==");
//        Log.e("AppEncrypt","storiesFullDetailHeader8==>>"+appEncrypt.storiesFullDetailHeader8()+"<<==");
//        Log.e("AppEncrypt","storiesFullDetailHeader10==>>"+appEncrypt.storiesFullDetailHeader10()+"<<==");
//        Log.e("AppEncrypt","storiesFullDetailHeader11==>>"+appEncrypt.storiesFullDetailHeader11()+"<<==");
//        Log.e("AppEncrypt","storiesFullDetailHeader12==>>"+appEncrypt.storiesFullDetailHeader12()+"<<==");
//        Log.e("AppEncrypt","twitterBaseURL==>>"+appEncrypt.twitterBaseURL()+"<<==");
//        Log.e("AppEncrypt","twitterNope==>>"+appEncrypt.twitterNope()+"<<==");
//        Log.e("AppEncrypt","twitterOrderBy==>>"+appEncrypt.twitterOrderBy()+"<<==");
//        Log.e("AppEncrypt","storiesFullDetailHeader12==>>"+appEncrypt.storiesFullDetailHeader12()+"<<==");
//        Log.e("AppEncrypt","<<==============================================================");
//    }

//    private fun loadNative() {
//        Log.e("Krishna", " loadNative Home")
//        binding.frameNative.visibility = View.VISIBLE
////        NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, binding.frameNative, 3)
////        NativeLoadWithShows(this).showNativeTopAlways(this, binding.frameNative)
//        UtilsAd.showNative(this,binding.frameNative)
//    }

    var isAdLoaded = false
    var mAdView: AdView? = null

    private fun loadBannerAd() {
        if (!isAdLoaded) {
            val adId = getString(R.string.banner_ads)
            BannerAdHelper.showBanner(this, binding.frameBanner, binding.frameBanner, adId,
                AdCache.bannerHome, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.bannerHome = adView
                    isAdLoaded = isLoaded
                })
        }
    }


    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
//        if (!checkStoragePermissions()) Handler(Looper.myLooper()!!).postDelayed(
//            { loadNativePermission() },
//            1000
//        )
//        Handler(Looper.myLooper()!!).postDelayed({
//            loadNativeInstagram()
//            loadNativeWebBrowser()
//            loadNativeDpDownloader()
//            loadNativeDownload()
//            loadNativeDownloadBrowser()
//        }, 1000)
//        if (MyApplication.isThemeChange) {
//            MyApplication.isThemeChange = false
//            Handler(Looper.myLooper()!!).postDelayed({
//                loadNativeHome()
//            }, 700)
//        }
    }


    override fun onPause() {
        super.onPause()
        mAdView?.pause()
        isPause = true
    }

    override fun onDestroy() {
        super.onDestroy()
        MyApplication.isOpenHomeScreen = false
    }

    private fun requestPermissionNotification() {
        Dexter.withContext(this@HomeActivity).withPermissions(
            android.Manifest.permission.POST_NOTIFICATIONS
        ).withListener(object : MultiplePermissionsListener {
            override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                report?.let {

                }
            }

            override fun onPermissionRationaleShouldBeShown(
                permissions: MutableList<PermissionRequest>?, token: PermissionToken?
            ) {
                token?.continuePermissionRequest()
            }
        }).check()
    }

    private fun showHomeADIntent(intent: Intent) {
//        AdLoaderClass().showInterstitialAds(this@HomeActivity, intent)
        AdsConfig.showInterstitialAd(this) {
            startActivity(intent)
        }
    }

    private fun showHomeADIntent(onNextListener: () -> Unit) {
        AdsConfig.showInterstitialAd(this) {
            onNextListener()
        }
//        AdLoaderClass()
//            .showInterWithCallback(this, object : ClickCallback {
//                override fun clickNext() {
//                    onNextListener()
//                }
//            })
    }

    private fun intiListener() {
        binding.btnInsta.setOnClickListener {
            val intent = Intent(this, InstagramActivity::class.java).putExtra(
                Constant.EXTRA_TYPE, Constant.DOWNLOAD_INSTAGRAM
            )
            showHomeADIntent(intent)

        }
        binding.btnFb.setOnClickListener {
            val intent = Intent(
                this, BrowserDownloadActivity::class.java
            ).putExtra(
                Constant.PUT_KEY_URL, Constant.URL_FB
            ).putExtra(
                Constant.EXTRA_TYPE, Constant.TYPE_FB
            )
            showHomeADIntent(intent)
        }
//        binding.btnTwitter.setOnClickListener {
//            val intent = Intent(this, InstagramActivity::class.java).putExtra(
//                Constant.EXTRA_TYPE, Constant.DOWNLOAD_TWITTER
//            )
//            showHomeADIntent(intent)
//        }
        binding.btnHashtag.setOnClickListener {
            val intent = Intent(this, HashtagActivity::class.java)
            startActivity(intent)
        }
        binding.btnWp.setOnClickListener {
            showHomeADIntent(Intent(this, WhatsAppStatusActivity::class.java))
        }
        binding.btnMyDownloader.setOnClickListener {
            showHomeADIntent {
                if (checkStoragePermissions()) {
                    myDownloaderScreenOpen()
                } else permissionLauncher.launch(
                    Intent(
                        this, PermissionActivity::class.java
                    )
                )
            }

        }
        binding.ivWeb.setOnClickListener {
            showHomeADIntent(Intent(this, WebBrowserActivity::class.java))
        }
        binding.ivSetting.setOnClickListener {
            settingLauncher.launch(Intent(this, SettingActivity::class.java))
        }
        binding.btnDPDownloader.setOnClickListener {
            showHomeADIntent(Intent(this, DPDownloaderActivity::class.java))
        }
        binding.btnDPGenerator.setOnClickListener {
            showHomeADIntent(Intent(this, DPGeneratorActivity::class.java))
        }
        binding.btnInstaStory.setOnClickListener {
            showHomeADIntent(Intent(this, InstaStoryActivity::class.java))
        }
    }


    var permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                myDownloaderScreenOpen()
            }
        }

    private fun myDownloaderScreenOpen() {
        startActivity(Intent(this, MyAllDownloadActivity::class.java))
    }

    var settingLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                MyApplication.isThemeChange = true
                val intent = intent
//                val intent = Intent(this, HomeActivity::class.java)
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
            }
        }

    override fun onBackPressed() {
        rateCounter = preferences.getRateCounter()
//        if (rateCounter <= getReviewCounter() && !preferences.isRate()) {
//        if (getReviewCounter() != 0) {
////        if (true ) {
//            showRateDialog()
//        } else {
        exitDialog()
//        }
    }

    private fun exitDialog() {
        val builder = AlertDialog.Builder(this, R.style.CustomAlertDialog).create()
        val deleteDialogLayoutBinding: DialogExitBinding =
            DialogExitBinding.inflate(LayoutInflater.from(this))
        builder.setView(deleteDialogLayoutBinding.root)
        deleteDialogLayoutBinding.tvNo.setOnClickListener {
            builder.dismiss()
        }
        deleteDialogLayoutBinding.tvYes.setOnClickListener {
            builder.dismiss()
            finishAffinity()
//            adConfigFinishAffinity()
            MyApplication.isAppIsRunning = false
        }
        builder.show()
    }

    fun Context.sendEmailIntent(recipient: String) {
        Intent(Intent.ACTION_SENDTO).putExtra(
            Intent.EXTRA_SUBJECT,
            "${getString(R.string.app_name)} ${getString(R.string.feedback)}"
        ).apply {
            data = Uri.fromParts("mailto", recipient, null)

            try {
                MyApplication.disabledOpenAds()
                startActivity(this)
                finishAffinity()
//                adConfigFinishAffinity()
                MyApplication.isAppIsRunning = false
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(
                    this@HomeActivity, getString(R.string.not_installed), Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) {
                Toast.makeText(
                    this@HomeActivity, getString(R.string.not_installed), Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

//    private fun showRateDialog() {
//        val mailId = getReviewEmail()
//        rateCounter++
//        preferences.putRateCounter(rateCounter)
//        val dialogBinding = DialogRateBinding.inflate(layoutInflater)
//        val dialog = Dialog(this, R.style.Theme_DialogRate)
//        dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
//        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        dialog.setCancelable(false)
//        dialog.setCanceledOnTouchOutside(false)
//        dialog.setContentView(dialogBinding.root)
//
//        dialogBinding.btnCancel.setTextColor(ContextCompat.getColor(this, R.color.whiteColor))
//        dialogBinding.btnCancel.background =
//            ContextCompat.getDrawable(this, R.drawable.btn_button_dialog)
//        dialogBinding.btnSubmit.setTextColor(ContextCompat.getColor(this, R.color.rate_disable))
//        dialogBinding.btnSubmit.background =
//            ContextCompat.getDrawable(this, R.drawable.no_button_bg)
//
//        dialog.show()
//
//        dialogBinding.btnCancel.setOnClickListener {
////            minusReviewCounter()
//            dialog.dismiss()
//            finishAffinity()
////            adConfigFinishAffinity()
//            MyApplication.isAppIsRunning = false
//        }
//        dialogBinding.btnSubmit.setOnClickListener {
//            if (dialogBinding.simpleRatingBar.rating != 0.0f) {
//                dialog.dismiss()
//                preferences.putRate(true)
////                rateDoneReviewCounter()
//                if (dialogBinding.simpleRatingBar.rating == 5.0f) {
//                    MyApplication.disabledOpenAds()
//
//                    startActivity(
//                        Intent(
//                            Intent.ACTION_VIEW,
//                            Uri.parse("http://play.google.com/store/apps/details?id=$packageName")
//                        )
//                    )
//                    finishAffinity()
//                    MyApplication.isAppIsRunning = false
////                    adConfigFinishAffinity()
//                } else {
//                    val i = Intent(Intent.ACTION_SEND)
//                    i.type = "message/rfc822"
//                    i.putExtra(Intent.EXTRA_EMAIL, arrayOf(mailId))
//                    i.putExtra(
//                        Intent.EXTRA_SUBJECT,
//                        "${getString(R.string.app_name)} ${getString(R.string.feedback)}"
//                    )
//                    i.putExtra(Intent.EXTRA_TEXT, "")
//                    i.setPackage("com.google.android.gm")
//
////                    Log.e("", "getReviewEmail==>> ${getReviewEmail()}")
////                    sendEmailIntent(getReviewEmail())
//                    try {
//                        MyApplication.disabledOpenAds()
//                        startActivity(Intent.createChooser(i, getString(R.string.Send_mail)))
//                        finishAffinity()
////                        adConfigFinishAffinity()
//                        MyApplication.isAppIsRunning = false
//                    } catch (ex: ActivityNotFoundException) {
//                        Toast.makeText(
//                            this@HomeActivity, getString(R.string.not_installed), Toast.LENGTH_SHORT
//                        ).show()
//                    }
//                }
//            }
//        }
//
//        dialogBinding.simpleRatingBar.setOnRatingChangeListener { ratingBar, rating, fromUser ->
//            var alpha = 1.0f
//            if (rating == 0f) {
//                dialogBinding.btnCancel.setTextColor(
//                    ContextCompat.getColor(
//                        this, R.color.whiteColor
//                    )
//                )
//                dialogBinding.btnCancel.background =
//                    ContextCompat.getDrawable(this, R.drawable.btn_button_dialog)
//
//                dialogBinding.btnSubmit.setTextColor(
//                    ContextCompat.getColor(
//                        this, R.color.rate_disable
//                    )
//                )
//                dialogBinding.btnSubmit.background =
//                    ContextCompat.getDrawable(this, R.drawable.no_button_bg)
//            } else {
//                dialogBinding.btnSubmit.setTextColor(
//                    ContextCompat.getColor(
//                        this, R.color.whiteColor
//                    )
//                )
//                dialogBinding.btnCancel.setTextColor(
//                    ContextCompat.getColor(
//                        this, R.color.searchHint
//                    )
//                )
//                dialogBinding.btnSubmit.background =
//                    ContextCompat.getDrawable(this, R.drawable.btn_button_dialog)
//                dialogBinding.btnCancel.background =
//                    ContextCompat.getDrawable(this, R.drawable.no_button_bg)
//            }
//            when (rating) {
//                1.0f -> {
//                    dialogBinding.ivRateEmoji.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            this, R.drawable.ic_rate_1
//                        )
//                    )
//                    dialogBinding.tvTitle.text = getString(R.string.rateTitle1)
//                }
//
//                2.0f -> {
//                    dialogBinding.ivRateEmoji.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            this, R.drawable.ic_rate_2
//                        )
//                    )
//                    dialogBinding.tvTitle.text = getString(R.string.rateTitle2)
//                }
//
//                3.0f -> {
//                    dialogBinding.ivRateEmoji.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            this, R.drawable.ic_rate_3
//                        )
//                    )
//                    dialogBinding.tvTitle.text = getString(R.string.rateTitle3)
//                }
//
//                4.0f -> {
//                    dialogBinding.ivRateEmoji.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            this, R.drawable.ic_rate_4
//                        )
//                    )
//                    dialogBinding.tvTitle.text = getString(R.string.rateTitle4)
//                }
//
//                5.0f -> {
//                    dialogBinding.ivRateEmoji.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            this, R.drawable.ic_rate_5
//                        )
//                    )
//                    dialogBinding.tvTitle.text = getString(R.string.rateTitle5)
//                }
//
//                else -> {
//                    alpha = 0.5f
//                    dialogBinding.ivRateEmoji.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            this, R.drawable.ic_rate_5
//                        )
//                    )
//                    dialogBinding.tvTitle.text = getString(R.string.likeApp)
//                    dialogBinding.tvMsg.text = getString(R.string.rateMsg)
//                }
//
//            }
//
//            dialogBinding.btnSubmit.alpha = alpha
//        }
//    }

    private fun startReviewFlow() {
        if (reviewInfo != null) {
            val flow: Task<Void> = reviewManager!!.launchReviewFlow(this, reviewInfo!!)
            flow.addOnCompleteListener {
                preferences.putRate(true)
                Toast.makeText(
                    applicationContext, getString(R.string.Rating_complete), Toast.LENGTH_LONG
                ).show()
            }
        } else {
            Toast.makeText(applicationContext, getString(R.string.Rating_failed), Toast.LENGTH_LONG)
                .show()
        }
    }

}