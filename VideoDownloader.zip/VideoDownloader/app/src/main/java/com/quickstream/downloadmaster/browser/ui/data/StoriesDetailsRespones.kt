package com.quickstream.downloadmaster.browser.ui.data

import com.google.gson.annotations.SerializedName

data class StoriesDetailsResponse(
    @SerializedName("reels_media")
    val reelsMedia: List<StoryTray>,
)