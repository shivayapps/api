package com.quickstream.downloadmaster.browser.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.quickstream.downloadmaster.browser.browser.event.DownloadCompleteEvent
import com.quickstream.downloadmaster.browser.browser.event.ProgressUpdateDownloadEvent
import com.quickstream.downloadmaster.browser.browser.event.StartDownloadEvent
import com.quickstream.downloadmaster.browser.databinding.FragmentDownloadProgressBinding
import com.quickstream.downloadmaster.browser.ui.adapter.DownloadingProgressAdapter
import com.quickstream.downloadmaster.browser.ui.data.DownloadData
import com.quickstream.downloadmaster.browser.utils.MyApplication
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe


class DownloadProgressFragment() : Fragment() {

    lateinit var binding: FragmentDownloadProgressBinding
    var downloadingList: ArrayList<DownloadData> = ArrayList()
    var adapter: DownloadingProgressAdapter? = null

    public fun  DownloadProgressFragment(){

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentDownloadProgressBinding.inflate(layoutInflater, container, false)
        intView()
        return binding.root
    }

    private fun intView() {
        setAdapter()
        checkEmptyList()
    }

    private fun checkEmptyList() {
//        downloadingList.addAll(MyApplication.downloadList)
        if (downloadingList.size == 0) {
            binding.tvNoData.visibility = View.VISIBLE
            binding.recyclerView.visibility = View.GONE
        } else {
            binding.tvNoData.visibility = View.GONE
            binding.recyclerView.visibility = View.VISIBLE
        }
    }

    private fun setAdapter() {
        adapter = DownloadingProgressAdapter(requireActivity(), downloadingList)
        binding.recyclerView.adapter = adapter
    }

    @Subscribe
    fun onStartDownloadEvent(startDownloadEvent: StartDownloadEvent) {
        downloadingList.add(startDownloadEvent.data)
        requireActivity().runOnUiThread {
            checkEmptyList()
            if (adapter != null)
                adapter!!.notifyDataSetChanged()
            else
                setAdapter()
        }
    }

    @Subscribe
    fun onProgressUpdateDownloadEvent(startDownloadEvent: ProgressUpdateDownloadEvent) {
        if (downloadingList.isNotEmpty()) {
            val list =
                downloadingList.filter { startDownloadEvent.data.downloadId == it.downloadId }
            requireActivity().runOnUiThread {
                if (list.isNotEmpty()) {
                    val pos = downloadingList.indexOf(list[0])
                    downloadingList[pos].progress = startDownloadEvent.data.progress
                    if (adapter != null)
                        adapter!!.notifyItemChanged(pos)
                    else
                        setAdapter()
                }
            }
        }
    }

    @Subscribe
    fun onDownloadCompleteEvent(startDownloadEvent: DownloadCompleteEvent) {
        if (downloadingList.isNotEmpty()) {
            val list =
                downloadingList.filter { startDownloadEvent.data.downloadId == it.downloadId }
            requireActivity().runOnUiThread {
                if (list.isNotEmpty()) {
                    downloadingList.remove(list[0])
                    if (adapter != null)
                        adapter!!.notifyDataSetChanged()
                    else
                        setAdapter()
                    checkEmptyList()
                }
            }
        }
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            DownloadProgressFragment()
    }


    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }
}