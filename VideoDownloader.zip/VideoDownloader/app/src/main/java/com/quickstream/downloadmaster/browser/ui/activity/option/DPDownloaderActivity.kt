package com.quickstream.downloadmaster.browser.ui.activity.option

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView

import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.databinding.ActivityDpdownloaderBinding
import com.quickstream.downloadmaster.browser.ui.activity.BaseActivity
import com.quickstream.downloadmaster.browser.utils.AdCache
import com.quickstream.downloadmaster.browser.utils.Constant
import com.quickstream.downloadmaster.browser.utils.FileUtil
import com.quickstream.downloadmaster.browser.utils.MyApplication
import com.quickstream.downloadmaster.browser.utils.Preferences
import com.quickstream.downloadmaster.browser.utils.Utils
import com.quickstream.downloadmaster.browser.utils.UtilsAd
import java.io.File
import java.util.concurrent.Executors

class DPDownloaderActivity : BaseActivity() {

    lateinit var binding: ActivityDpdownloaderBinding
    lateinit var clipBoard: ClipboardManager
    lateinit var preferences: Preferences
    var downloadStorePath = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDpdownloaderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initView()
    }

    private fun initView() {
        clipBoard =
            getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        preferences = Preferences(this)
        binding.loutToolbar.txtTitle.text = getString(R.string.DPDownloader)
        initListener()
        downloadStorePath = FileUtil.getExternalStoragePublicDirectory(
            this,
            Environment.DIRECTORY_PICTURES
        ) + File.separator + getString(
            R.string.app_name
        ) + File.separator + Constant.FOLDER_DP_DOWNLOADER
        checkButtonDownload()
        loadBannerAd()
    }


    var isAdLoaded=false
    var mAdView: AdView?=null

    private fun loadBannerAd() {
        binding.frameNative.visibility = View.VISIBLE
        if (!isAdLoaded) {
            val adId = getString(R.string.bannerDpDownload)
            BannerAdHelper.showBanner(this, binding.frameNative, binding.frameNative, adId,
                AdCache.bannerDpDownload, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.bannerDpDownload = adView
                    isAdLoaded = isLoaded
                })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        //MyApplication.storageCommon?nativeAdsDpDownloader?.postValue(null)
    }

    private fun initListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.loutToolbar.btnDownload.setOnClickListener {
            startActivity(
                Intent(this, DownloadActivity::class.java).putExtra(
                    Constant.EXTRA_TYPE,
                    Constant.DOWNLOAD_DP_DOWNLOADER
                )
            )
        }
        binding.btnPaste.setOnClickListener {
            pasteText()
        }
        binding.btnSearch.setOnClickListener {
            checkSearchValidation()
        }
    }

    private fun checkSearchValidation() {
        val url = binding.edtPasteUrl.text.toString().trim()
        if (url.isEmpty()) {
            Toast.makeText(
                this,
                getString(R.string.url_username_dp),
                Toast.LENGTH_SHORT
            ).show()
            return
        } else if (!Utils.isNetworkAvailable(this)) {
            Toast.makeText(
                this,
                getString(R.string.internet_connection_msg),
                Toast.LENGTH_SHORT
            ).show()
            return
        } else {
            if (url.isValidUrl()) {
                if (url.contains("www.instagram.com") || url.contains("/p/") || url.contains("/stories/")
                    || url.contains("/reel/") || !url.startsWith("https://instagram.com/")
                ) {
                    Toast.makeText(
                        this,
                        getString(R.string.url_dp),
                        Toast.LENGTH_SHORT
                    ).show()
                    return
                }
            }
            profileLauncher.launch(
                Intent(this, ProfileListActivity::class.java)
                    .putExtra(Constant.EXTRA_USERNAME, url)
            )
        }
    }

    var profileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            binding.edtPasteUrl.setText("")
        }

    fun String.isValidUrl(): Boolean = Patterns.WEB_URL.matcher(this).matches()

    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        if (isPause) {
            isPause = false
            Handler(Looper.myLooper()!!).postDelayed(Runnable { checkButtonDownload() }, 500)

        }
    }

    var isPause = false

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
        isPause = true
    }

    private fun pasteText() {

        binding.edtPasteUrl.setText("")
        if (!::clipBoard.isInitialized)
            clipBoard =
                getSystemService(CLIPBOARD_SERVICE) as ClipboardManager

        try {
            if (!clipBoard.hasPrimaryClip()) {
            } else if (!clipBoard.primaryClipDescription!!.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)) {
                if (clipBoard.primaryClip!!.getItemAt(0).text.toString()
                        .contains("instagram.com")
                ) {
                    binding.edtPasteUrl.setText(clipBoard.primaryClip!!.getItemAt(0).text.toString())
                    binding.edtPasteUrl.setSelection(binding.edtPasteUrl.text.toString().length)

                }
            } else {
                val item = clipBoard.primaryClip!!.getItemAt(0)
                if (item.text.toString().contains("instagram.com")) {
                    binding.edtPasteUrl.setText(item.text.toString())
                    binding.edtPasteUrl.setSelection(binding.edtPasteUrl.text.toString().length)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private fun checkButtonDownload() {
        val service = Executors.newSingleThreadExecutor()
        service.execute {
            val isDataIsAdded = checkPathIsNotEmpty()
            runOnUiThread {
                Log.e("checkButtonDownload", "isDataIsAdded==>> $isDataIsAdded")
                binding.loutToolbar.btnDownload.visibility =
                    if (isDataIsAdded) View.VISIBLE else View.GONE
            }
        }
    }


    private fun checkPathIsNotEmpty(): Boolean {
        var isDataIsAdd = false
        val file = File(downloadStorePath)
        val listFile = file.listFiles()
        if (file.exists()) {
            try {
                if (file.listFiles().isNotEmpty()) {
                    for (i in listFile.indices) {
                        val data = listFile[i]
                        if (data.isFile && data.exists() && data.length() != 0L) {
                            isDataIsAdd = true
                            break
                        }
                    }
                }
            } catch (e: NullPointerException) {
                e.printStackTrace()
            }
        }
        return isDataIsAdd
    }

}