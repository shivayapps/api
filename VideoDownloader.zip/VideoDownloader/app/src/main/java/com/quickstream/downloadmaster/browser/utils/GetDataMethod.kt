package com.quickstream.downloadmaster.browser.utils

import android.content.Context
import com.quickstream.downloadmaster.browser.ui.data.DataModel
import java.io.File
import java.util.Collections


class GetDataMethod(val context: Context) {
    fun getAllList(path: String): ArrayList<DataModel> {
        val arrayList: ArrayList<DataModel> = ArrayList()
        val file = File(path)
        val listFile = file.listFiles()
        try {
            if (file.listFiles().size < 0) {
            } else {
                for (i in listFile.indices) {
                    val data = listFile[i]
                    if (data.isFile && data.exists() && data.length() != 0L)
                        arrayList.add(DataModel(data.path, data.lastModified()))
                }
            }
        } catch (e: NullPointerException) {
            e.printStackTrace()
        }

        if (arrayList.size != 0)
            Collections.sort(arrayList, Comparator { t1, t2 ->
                return@Comparator t2.date.compareTo(t1.date)
            })
        return arrayList
    }
}