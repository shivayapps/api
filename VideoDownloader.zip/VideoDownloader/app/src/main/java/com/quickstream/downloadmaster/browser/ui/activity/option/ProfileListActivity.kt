package com.quickstream.downloadmaster.browser.ui.activity.option

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import com.google.gson.Gson
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.databinding.ActivityProfileListBinding
import com.quickstream.downloadmaster.browser.networkmanager.ApiManager
import com.quickstream.downloadmaster.browser.ui.activity.BaseActivity
import com.quickstream.downloadmaster.browser.ui.adapter.ProfileListAdapter
import com.quickstream.downloadmaster.browser.ui.data.DpResponse
import com.quickstream.downloadmaster.browser.ui.data.DpSearchResponse
import com.quickstream.downloadmaster.browser.ui.data.UserList
import com.quickstream.downloadmaster.browser.ui.fragment.LoginDialog
import com.quickstream.downloadmaster.browser.ui.interfaces.APIResponse
import com.quickstream.downloadmaster.browser.utils.Constant
import java.net.URI

class ProfileListActivity : BaseActivity() {

    lateinit var binding: ActivityProfileListBinding
    val profileList: ArrayList<UserList> = ArrayList()
    var adapter: ProfileListAdapter? = null
    var userName: String? = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inti()
    }

    private fun inti() {
        userName = intent.getStringExtra(Constant.EXTRA_USERNAME)
        binding.loutToolbar.txtTitle.text = getString(R.string.profileList)
        setAdapter()
        initListener()
        if (userName.isNullOrEmpty())
            userName = ""
        getProfileList()
    }

    private fun setAdapter() {
        adapter = ProfileListAdapter(this, profileList, clickListener = {
            val data = profileList[it]
            Constant.profileData.clear()
            Constant.profileData.add(data)
            startActivity(Intent(this, PreviewActivity::class.java))
        })
        binding.recyclerView.adapter = adapter
    }

    private fun initListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
    }

    private fun finishLoading() {
        runOnUiThread {
            binding.loutLoading.visibility = View.GONE
        }
    }

    var loginLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                getProfileList()
            }
        }

    private fun openLoginScreen() {
        val dialog = LoginDialog(this, onLoginListener = {
            loginLauncher.launch(Intent(this, LoginActivity::class.java))
        })
        dialog.show()

    }

    fun String.isValidUrl(): Boolean = Patterns.WEB_URL.matcher(this).matches()

    fun url(str: String?): String {
        return try {
            val uri = URI(str)
            URI(uri.scheme, uri.authority, uri.path, null, uri.fragment).toString()
        } catch (e2: Exception) {
            e2.printStackTrace()
            ""
        }
    }

    private fun setUpdateDisplayData() {
        if (adapter != null)
            adapter?.notifyDataSetChanged()

        if (profileList.isEmpty()) {
            binding.recyclerView.visibility = View.GONE
            binding.txtNoData.visibility = View.VISIBLE
        } else {
            binding.recyclerView.visibility = View.VISIBLE
            binding.txtNoData.visibility = View.GONE
        }
    }

    private fun getProfileList() {
        binding.loutLoading.visibility = View.VISIBLE
        val api = ApiManager()
        if (userName!!.isValidUrl()) {
            val str = url(userName)
            api.callDpDetails(this, str, object : APIResponse {
                override fun onResponse(response: Any) {
                    val dpSearchResponse = Gson().fromJson(
                        Gson().toJson(response),
                        DpResponse::class.java
                    )
                    if (dpSearchResponse != null) {
                        try {
                            val user = dpSearchResponse.graphql.user
                            val data = UserList(0, user)
                            runOnUiThread {
                                finishLoading()
                                profileList.add(data)
                                setUpdateDisplayData()
                            }
                        } catch (e: Exception) {
                            runOnUiThread {
                                finishLoading()
                                setUpdateDisplayData()
                            }
                        }
                    } else{
                        runOnUiThread {
                            finishLoading()
                            setUpdateDisplayData()
                        }
                    }
                }

                override fun onFailure(error: String) {
                    runOnUiThread {
                        finishLoading()
                        setUpdateDisplayData()
                    }
                }

                override fun onLoginRequired() {
                    runOnUiThread {
                        finishLoading()
                        openLoginScreen()

                    }
                }
            })
        } else {

            api.callDpSearch(this, userName, object : APIResponse {
                override fun onResponse(response: Any) {
                    val dpSearchResponse = Gson().fromJson(
                        Gson().toJson(response),
                        DpSearchResponse::class.java
                    )
                    val userList = dpSearchResponse.users
                    runOnUiThread {
                        finishLoading()
                        if (userList.isNotEmpty()) {
                            profileList.addAll(userList)
                        }
                        setUpdateDisplayData()
                    }
                }

                override fun onFailure(error: String) {
                    runOnUiThread {
                        finishLoading()
                        setUpdateDisplayData()
                    }
                }

                override fun onLoginRequired() {
                    runOnUiThread {
                        finishLoading()
                        openLoginScreen()
                    }
                }
            })
        }
    }

}