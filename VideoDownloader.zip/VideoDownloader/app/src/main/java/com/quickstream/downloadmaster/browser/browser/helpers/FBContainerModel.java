package com.quickstream.downloadmaster.browser.browser.helpers;

import java.util.ArrayList;

public class FBContainerModel {
    private int postIndex = 0;
    private String authorName = "";
    private boolean multiContainer = false;
    private ArrayList<DownloadFBMediaButtonModel> downloadButtons = new ArrayList<>();

    public int getPostIndex() {
        return this.postIndex;
    }

    public void setPostIndex(int i) {
        this.postIndex = i;
    }

    public String getAuthorName() {
        return this.authorName;
    }

    public void setAuthorName(String str) {
        this.authorName = str;
    }

    public ArrayList<DownloadFBMediaButtonModel> getDownloadButtons() {
        return this.downloadButtons;
    }

    public void setDownloadButtons(ArrayList<DownloadFBMediaButtonModel> arrayList) {
        this.downloadButtons = arrayList;
    }

    public boolean isMultiContainer() {
        return this.multiContainer;
    }

    public void setMultiContainer(boolean z) {
        this.multiContainer = z;
    }
}
