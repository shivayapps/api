package com.quickstream.downloadmaster.browser.ui.data

import java.io.Serializable

data class VideoVersion(
    val height: Int,
    val id: String,
    val type: Int,
    val url: String,
    val width: Int
): Serializable