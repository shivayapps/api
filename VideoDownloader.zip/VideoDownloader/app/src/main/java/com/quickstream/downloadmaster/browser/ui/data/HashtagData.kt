package com.quickstream.downloadmaster.browser.ui.data

import com.quickstream.downloadmaster.browser.R


data class HashtagData(
    var title: String = null ?: "",
//    var imageIcon: Int = null ?: R.drawable.ic_hashtag,
    var imageTint: Int = null ?: R.color.popular_bg)
