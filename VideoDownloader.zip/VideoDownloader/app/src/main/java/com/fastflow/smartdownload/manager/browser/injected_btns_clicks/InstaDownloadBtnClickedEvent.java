package com.fastflow.smartdownload.manager.browser.injected_btns_clicks;

public class InstaDownloadBtnClickedEvent {
    int btnInPostIndex;
    String cUrl;
    int postIndex;

    public InstaDownloadBtnClickedEvent(int i, int i2, String str) {
        this.postIndex = i;
        this.btnInPostIndex = i2;
        this.cUrl = str;
    }

    public int getPostIndex() {
        return this.postIndex;
    }

    public void setPostIndex(int i) {
        this.postIndex = i;
    }

    public int getBtnInPostIndex() {
        return this.btnInPostIndex;
    }

    public void setBtnInPostIndex(int i) {
        this.btnInPostIndex = i;
    }

    public String getcUrl() {
        return this.cUrl;
    }

    public void setcUrl(String str) {
        this.cUrl = str;
    }
}
