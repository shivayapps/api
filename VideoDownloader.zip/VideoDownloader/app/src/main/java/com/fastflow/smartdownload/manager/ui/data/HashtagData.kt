package com.fastflow.smartdownload.manager.ui.data

import com.fastflow.smartdownload.manager.R


data class HashtagData(
    var title: String = null ?: "",
//    var imageIcon: Int = null ?: R.drawable.ic_hashtag,
    var imageTint: Int = null ?: R.color.popular_bg)
