package com.fastflow.smartdownload.manager.browser.event

import com.fastflow.smartdownload.manager.ui.data.DownloadData

data class DownloadCompleteEvent(var data: DownloadData)