package com.fastflow.smartdownload.manager.browser.injected_btns_clicks;


import com.fastflow.smartdownload.manager.browser.helpers.DownloadYTVideoButtonModel;

public class YoutubeDownloadBtnClickedEvent {
    int buttonIndex;
    DownloadYTVideoButtonModel.YTVideoType ytVideoType;

    public YoutubeDownloadBtnClickedEvent(int i, DownloadYTVideoButtonModel.YTVideoType yTVideoType) {
        this.buttonIndex = -1;
        DownloadYTVideoButtonModel.YTVideoType yTVideoType2 = DownloadYTVideoButtonModel.YTVideoType.CLASSIC_VIDEO_LIST;
        this.buttonIndex = i;
        this.ytVideoType = yTVideoType;
    }

    public int getButtonIndex() {
        return this.buttonIndex;
    }

    public void setButtonIndex(int i) {
        this.buttonIndex = i;
    }

    public DownloadYTVideoButtonModel.YTVideoType getYtVideoType() {
        return this.ytVideoType;
    }

    public void setYtVideoType(DownloadYTVideoButtonModel.YTVideoType yTVideoType) {
        this.ytVideoType = yTVideoType;
    }
}
