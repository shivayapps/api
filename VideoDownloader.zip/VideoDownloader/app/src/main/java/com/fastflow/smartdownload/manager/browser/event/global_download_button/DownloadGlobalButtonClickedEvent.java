package com.fastflow.smartdownload.manager.browser.event.global_download_button;

/* loaded from: classes3.dex */
public class DownloadGlobalButtonClickedEvent {
}
