package com.fastflow.smartdownload.manager.ui.fragment

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment


import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.browser.event.ADShowEvent
import com.fastflow.smartdownload.manager.browser.event.DownloadCompleteEvent
import com.fastflow.smartdownload.manager.browser.event.DownloadDeleteEvent
import com.fastflow.smartdownload.manager.browser.event.DownloadUpdateEvent
import com.fastflow.smartdownload.manager.databinding.FragmentDownloadBinding
import com.fastflow.smartdownload.manager.ui.activity.PermissionActivity
import com.fastflow.smartdownload.manager.ui.activity.option.BrowserDownloadActivity
import com.fastflow.smartdownload.manager.ui.adapter.DownloadAdapter
import com.fastflow.smartdownload.manager.ui.data.DataModel
import com.fastflow.smartdownload.manager.ui.interfaces.CheckFolder
import com.fastflow.smartdownload.manager.utils.Constant
import com.fastflow.smartdownload.manager.utils.FileUtil
import com.fastflow.smartdownload.manager.utils.GetDataMethod
import com.fastflow.smartdownload.manager.utils.UtilsAd
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import java.io.File
import java.util.concurrent.Executors

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "isShowBannerAd"
private const val ARG_PARAM3 = "isOpenFromBrowser"

class DownloadFragment() : Fragment(), CheckFolder {

    public fun DownloadFragment() {}

    private var param1: String? = null
    lateinit var binding: FragmentDownloadBinding
    var path = " "
    var downloadStatusList: ArrayList<DataModel> = ArrayList()
    var downloadAdapter: DownloadAdapter? = null
    var selectPos = -1
    var isShowBannerAd = false
    var isOpenFromBrowser = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            isShowBannerAd = it.getBoolean(ARG_PARAM2)
            isOpenFromBrowser = it.getBoolean(ARG_PARAM3)
        }
        EventBus.getDefault().register(this)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentDownloadBinding.inflate(layoutInflater, container, false)
        getList()
        binding.btnPermissionStorage.setOnClickListener {
            startActivity(Intent(activity, PermissionActivity::class.java))
        }
        binding.btnOpenInsta.setOnClickListener {
            startActivity(
                Intent(
                    activity,
                    BrowserDownloadActivity::class.java
                ).putExtra(Constant.PUT_KEY_URL, Constant.URL_Insta)
                    .putExtra(
                        Constant.EXTRA_TYPE,
                        Constant.TYPE_Insta
                    )
            )
        }
        return binding.root
    }


    private fun checkInstaBannerShow(): Boolean {
        if (!isOpenFromBrowser && param1.equals(Constant.DOWNLOAD_INSTAGRAM))
                return true
        return false
    }

    private fun getList() {
        val folderName =
            if (param1.equals(Constant.DOWNLOAD_WHATSAPP))
                Constant.FOLDER_WHATSAPP
            else if (param1.equals(Constant.DOWNLOAD_INSTAGRAM))
                Constant.FOLDER_INSTAGRAM
            else if (param1.equals(Constant.DOWNLOAD_FACEBOOK))
                Constant.FOLDER_FACEBOOK
            else if (param1.equals(Constant.DOWNLOAD_TWITTER))
                Constant.FOLDER_TWITTER
            else if (param1.equals(Constant.DOWNLOAD_DP_CREATE))
                Constant.FOLDER_DP_CREATE
            else if (param1.equals(Constant.DOWNLOAD_DP_DOWNLOADER))
                Constant.FOLDER_DP_DOWNLOADER
            else ""

        path = if (folderName.isNotEmpty()) {
            FileUtil.getExternalStoragePublicDirectory(
                requireActivity(),
                Environment.DIRECTORY_PICTURES
            ) + File.separator + getString(
                R.string.app_name
            ) + File.separator + folderName
        } else {
            ""
        }
        setDataInAdapter()
    }

    private fun setDataInAdapter() {
        if (checkStoragePermissions()) {
            binding.llPermissionLayout.visibility = View.GONE
            binding.rvDownload.visibility = View.VISIBLE
            val service = Executors.newSingleThreadExecutor()
            service.execute {
                requireActivity().runOnUiThread { binding.progress.visibility = View.VISIBLE }
                downloadStatusList = GetDataMethod(requireActivity()).getAllList(path)
                requireActivity().runOnUiThread {
                    binding.progress.visibility = View.GONE
                    setAdapterLayouts()
                }
            }
        } else {
            binding.llPermissionLayout.visibility = View.VISIBLE
            binding.rvDownload.visibility = View.GONE
        }
    }

    fun checkStoragePermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                requireActivity(),
                android.Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                requireActivity(),
                android.Manifest.permission.READ_MEDIA_VIDEO
            ) == PackageManager.PERMISSION_GRANTED
        } else
            ActivityCompat.checkSelfPermission(
                requireActivity(),
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
    }

    private fun loadNativeADs() {
        if (binding.frameNative.childCount == 0) {
            binding.frameNative.visibility = View.VISIBLE
//            NativeLoadWithShows(activity).showNativeAdsShimmerEffects(activity, binding.frameNative, 3)
//            NativeLoadWithShows(activity).showNativeTopAlways(activity, binding.frameNative)
            UtilsAd.showNative(requireActivity(),binding.frameNative)
        }
    }

    private fun loadNativeADsBrowserDownload() {
        if (binding.frameNative.childCount == 0) {
            binding.frameNative.visibility = View.VISIBLE
//            NativeLoadWithShows(activity).showNativeAdsShimmerEffects(activity, binding.frameNative, 3)
//            NativeLoadWithShows(activity).showNativeTopAlways(activity, binding.frameNative)
            UtilsAd.showNative(requireActivity(),binding.frameNative)
        }
    }


    private fun loadBannerAd() {
        if (binding.frameBanner.childCount == 0) {
//            AdUtils().loadSmallBanner(activity, binding.frameBanner)
            UtilsAd.showNative(requireActivity(),binding.frameBanner)
        }
    }


    private fun setAnimationButton() {
//        binding.btnOpenInsta.clearAnimation()
//        val clickAnimation = AnimationUtils.loadAnimation(activity, R.anim.button_animation)
//        binding.btnOpenInsta.startAnimation(clickAnimation)
    }

    var isCallingDelete: Boolean = false
    private fun setAdapterLayouts() {
        if (downloadStatusList.size == 0) {
            if (checkInstaBannerShow()){
                binding.tvNoData.visibility = View.GONE
                binding.loutInstBanner.visibility = View.VISIBLE
                setAnimationButton()
            } else {
                binding.tvNoData.visibility = View.VISIBLE
                binding.loutInstBanner.visibility = View.GONE
            }
            binding.frameBanner.visibility = View.GONE
            binding.frameBanner.removeAllViews()
            EventBus.getDefault().post(ADShowEvent(false))
        } else {
            binding.tvNoData.visibility = View.GONE
            binding.loutInstBanner.visibility = View.GONE
            EventBus.getDefault().post(ADShowEvent(true))
            if (isShowBannerAd) {
                binding.frameBanner.visibility = View.VISIBLE
                if (param1.equals(Constant.DOWNLOAD_WHATSAPP))
                    loadBannerAd()
                else {
                    if (isOpenFromBrowser)
                        loadNativeADsBrowserDownload()
                    else
                        loadNativeADs()
                }
            }
        }
        downloadAdapter =
            DownloadAdapter(
                downloadStatusList,
                requireActivity(),
                this,
                deleteListener = {
                    selectPos = it
                    val deletePath = downloadStatusList[it].path
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        isCallingDelete = true
                        FileUtil.deleteWithoutManageExternalStorage(deletePath, this)
                    } else {
                        val file1 = File(deletePath)
                        val d = file1.delete()
                        if (d) {
                            EventBus.getDefault()
                                .post(DownloadDeleteEvent(deletePath, 1))
                            downloadStatusList.removeAt(it)
                            downloadAdapter!!.notifyDataSetChanged()
                            if (downloadStatusList.size == 0) {
                                dataEmpty()
                            }
                        }
                    }
                })
        binding.rvDownload.adapter = downloadAdapter

    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == Constant.DELETE_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                val deletePath = downloadStatusList[selectPos].path
                EventBus.getDefault()
                    .post(DownloadDeleteEvent(deletePath, 1))
                downloadStatusList.removeAt(selectPos)
                downloadAdapter!!.notifyDataSetChanged()
                if (downloadStatusList.size == 0) {
                    dataEmpty()
                }
            }

            Handler(Looper.myLooper()!!).postDelayed({
                isCallingDelete = false
            }, 1000)
        }
    }

    companion object {
        fun newInstance(
            activity: Activity,
            param1: String,
            isShowBannerAd: Boolean = false,
            isOpenFromBrowser: Boolean = false
        ) =
            DownloadFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putBoolean(ARG_PARAM2, isShowBannerAd)
                    putBoolean(ARG_PARAM3, isOpenFromBrowser)
                }
            }

    }

    @Subscribe
    fun onDownloadCompleteEvent(startDownloadEvent: DownloadCompleteEvent) {
        requireActivity().runOnUiThread {
            getList()
        }
    }

    @Subscribe
    fun onDownloadUpdateEvent(startDownloadEvent: DownloadUpdateEvent) {
        requireActivity().runOnUiThread {
            setDataInAdapter()
        }
    }

    @Subscribe
    fun onDownloadDeleteEvent(downloadDeleteEvent: DownloadDeleteEvent) {
        requireActivity().runOnUiThread {
            if (downloadDeleteEvent.isOpenType != 1 && downloadDeleteEvent.deletePath.isNotEmpty())
                if (downloadStatusList.isNotEmpty()) {
                    val list =
                        downloadStatusList.filter { it.path == downloadDeleteEvent.deletePath }
                    if (list.isNotEmpty()) {
                        downloadStatusList.remove(list[0])
                        setAdapterLayouts()
                    }
                }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!isCallingDelete)
            setDataInAdapter()
    }

    override fun dataEmpty() {
        EventBus.getDefault().post(ADShowEvent(false))
        binding.tvNoData.visibility = View.VISIBLE
        binding.frameBanner.visibility = View.GONE
        binding.frameBanner.removeAllViews()
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
//        if (!param1.equals(Constant.DOWNLOAD_WHATSAPP)) {
//            if (isOpenFromBrowser)
//                MyApplication.storageCommon?.nativeAdsBrowserDownload?.postValue(null)
//            else
//                MyApplication.storageCommon?.nativeAdsDownload?.postValue(null)
//        }
    }
}