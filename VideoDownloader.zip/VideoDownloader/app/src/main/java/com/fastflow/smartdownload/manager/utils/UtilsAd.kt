package com.fastflow.smartdownload.manager.utils

import android.content.Context
import android.view.View
import android.widget.FrameLayout
import androidx.appcompat.app.AlertDialog
import com.fastflow.smartdownload.manager.R


object UtilsAd {

    fun showNative(context:Context,frameLayout: FrameLayout) {
        val contentView = View.inflate(context, R.layout.item_adview, null)
        frameLayout.addView(contentView)
    }

    fun showADIntent(context:Context,onNextListener: () -> Unit) {
        val alertDialogBuilder = AlertDialog.Builder(context)
        alertDialogBuilder.setTitle("AdView")
//            .setMessage("----")
            .setPositiveButton("Ok") { dialog, which ->
                dialog.dismiss()
                onNextListener.invoke()
            }.setCancelable(false).create().show()
    }

}