package com.fastflow.smartdownload.manager.ui.fragment

import android.app.Activity
import android.app.Dialog
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.animation.AnimationUtils
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView

import com.fastflow.smartdownload.manager.utils.AppUrl
//import com.google.firebase.analytics.FirebaseAnalytics
import com.google.gson.Gson
import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.browser.event.DownloadDeleteEvent
import com.fastflow.smartdownload.manager.browser.event.DownloadUpdateEvent
import com.fastflow.smartdownload.manager.customView.VideoContentSearch
import com.fastflow.smartdownload.manager.databinding.DialogDownloadBinding
import com.fastflow.smartdownload.manager.databinding.DialogHowToUseBinding
import com.fastflow.smartdownload.manager.databinding.FragmentInstagramBinding
import com.fastflow.smartdownload.manager.networkmanager.ApiManager
import com.fastflow.smartdownload.manager.ui.activity.IntroActivity
import com.fastflow.smartdownload.manager.ui.activity.PermissionActivity
import com.fastflow.smartdownload.manager.ui.activity.option.BrowserDownloadActivity
import com.fastflow.smartdownload.manager.ui.activity.option.LoginActivity
import com.fastflow.smartdownload.manager.ui.adapter.DownloadViewAdapter
import com.fastflow.smartdownload.manager.ui.adapter.DownloadViewAdapter2
import com.fastflow.smartdownload.manager.ui.adapter.StoriesAdapter
import com.fastflow.smartdownload.manager.ui.adapter.StoriesDetailsAdapter
import com.fastflow.smartdownload.manager.ui.data.DownloadData
import com.fastflow.smartdownload.manager.ui.data.InstagramModel
import com.fastflow.smartdownload.manager.ui.data.StoriesDetailsResponse
import com.fastflow.smartdownload.manager.ui.data.StoryItem
import com.fastflow.smartdownload.manager.ui.data.StoryModel
import com.fastflow.smartdownload.manager.ui.data.StoryTray
import com.fastflow.smartdownload.manager.ui.interfaces.APIResponse
import com.fastflow.smartdownload.manager.utils.AdCache
import com.fastflow.smartdownload.manager.utils.Constant
import com.fastflow.smartdownload.manager.utils.DownloadManager
import com.fastflow.smartdownload.manager.utils.FileUtil
import com.fastflow.smartdownload.manager.utils.MyApplication
import com.fastflow.smartdownload.manager.utils.Preferences
import com.fastflow.smartdownload.manager.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.io.File
import java.net.URI
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocketFactory


class InstagramFragment(val activity: Activity) : Fragment() {

    public fun InstagramFragment() {

    }

    lateinit var binding: FragmentInstagramBinding
    lateinit var preferences: Preferences
    private var defaultSSLSF: SSLSocketFactory? = null
    var isLoginOpenFromDownload: Boolean = false
    var storiesList: ArrayList<StoryTray> = ArrayList()
    var mediaList: ArrayList<StoryItem> = ArrayList()
    var storiesAdapter: StoriesAdapter? = null
    var storiesDetailsAdapter: StoriesDetailsAdapter? = null
    var adapter2: DownloadViewAdapter2? = null
    var downloadList: ArrayList<String> = ArrayList()
    var selectDownloadPos = -1
    var selectDeletePos = -1
    var storiesDetailsPos = -1
    var isOpenDeleteFromStories = false
    lateinit var clipBoard: ClipboardManager
    private var isLogin = false
//    lateinit var firebaseAnalytics: FirebaseAnalytics


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
//        MyApplication.storageCommon?.nativeAdsInstagram?.postValue(
//            null
//        )
    }

    @Subscribe
    fun onDownloadDeleteEvent(downloadDeleteEvent: DownloadDeleteEvent) {
        activity.runOnUiThread {
            if (downloadDeleteEvent.isOpenType != 0 && downloadDeleteEvent.deletePath.isNotEmpty())
                if (downloadList.isNotEmpty()) {
                    val list = downloadList.filter { it == downloadDeleteEvent.deletePath }
                    if (list.isNotEmpty()) {
                        downloadList.remove(downloadDeleteEvent.deletePath)
                        if (adapter2 != null)
                            adapter2!!.notifyDataSetChanged()
                        if (downloadList.size == 0) {
                            binding.loutDisplayDownload.visibility = View.GONE
                        }
                    }
                }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInstagramBinding.inflate(layoutInflater, container, false)
        inti()
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        Handler(Looper.myLooper()!!).postDelayed({ pasteText() }, 200)
    }

    fun shareUrl(shareUrl: String) {
        binding.edtPasteUrl.setText(shareUrl)
        if (preferences.isLoginInstagram())
            checkValidation()
    }

    private fun setStoriesAdapter() {
        try {
            if (activity != null)
                storiesAdapter = StoriesAdapter(activity, storiesList, clickListener = {
                    getStoriesDetails(storiesList[it])
                })
            binding.rvStories.adapter = storiesAdapter
        } catch (e: Exception) {

        }
    }

    private fun setStoriesDetailsAdapter() {
        val folder = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath
                    + File.separator + getString(R.string.app_name)
                    + File.separator + Constant.FOLDER_INSTAGRAM
        )

        storiesDetailsAdapter =
            StoriesDetailsAdapter(activity, mediaList, deleteListener = {
                storiesDetailsPos = it
                val fileN =
                    Constant.TYPE_Story + mediaList[it].id + if (mediaList[it].mediaType == Constant.TYPE_IMAGE) ".png" else ".mp4"
                val file = File(folder, fileN)
                val deletePath = file.path
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    isOpenDeleteFromStories = true
                    FileUtil.deleteWithoutManageExternalStorage(deletePath, this)
                } else {
                    val file1 = File(deletePath)
                    val d = file1.delete()
                    if (d) {
                        EventBus.getDefault()
                            .post(DownloadDeleteEvent(deletePath, 0))
                        if (storiesDetailsAdapter != null)
                            storiesDetailsAdapter!!.notifyItemChanged(it)
                    }
                }
            }, downloadListener = {
                selectDownloadPos = it
                if (checkStoragePermissions()) {
                    setStoriesDownload()
                } else
                    storiesPermissionLauncher.launch(
                        Intent(
                            activity,
                            PermissionActivity::class.java
                        )
                    )
            })
        binding.rvStoriesList.adapter = storiesDetailsAdapter
    }

    private fun setStoriesDownload() {
        val data = mediaList[selectDownloadPos]
        val downloadList: ArrayList<DownloadData> = ArrayList()
        when (data.mediaType) {
            Constant.TYPE_VIDEO -> {
                val downloadUrl = data.videoVersions[0].url
                downloadList.add(DownloadData(downloadUrl, Constant.TYPE_VIDEO, data.id))
            }

            Constant.TYPE_IMAGE -> {
                val downloadUrl = data.imageVersions2.candidates[0].url
                downloadList.add(DownloadData(downloadUrl, Constant.TYPE_IMAGE, data.id))
            }
        }
        downloadUrl(downloadList, true)
    }

    var loginLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                if (isLoginOpenFromDownload) {
                    isLoginOpenFromDownload = false
                    setWebCookie()
                } else
                    setLoginData()
            }
            setSwitchValue()
        }

    private fun inti() {
//        firebaseAnalytics = FirebaseAnalytics.getInstance(activity)
        clipBoard =
            activity.getSystemService(AppCompatActivity.CLIPBOARD_SERVICE) as ClipboardManager
        preferences = Preferences(activity)

        if (!preferences.isInstagramIntro()) {
            showHowToUseDialog()
        }

        defaultSSLSF = HttpsURLConnection.getDefaultSSLSocketFactory()
        setSwitchValue()
        binding.rvStories.layoutManager =
            LinearLayoutManager(activity, RecyclerView.HORIZONTAL, false)
        binding.rvStoriesList.layoutManager =
            GridLayoutManager(activity, 3)
        binding.loutInstLoin.visibility = View.VISIBLE
        intiListener()
        intiWebView()
        Log.e("", "inti setLoginData")
        setLoginData()
        binding.loutLoading.visibility = View.GONE
        binding.loutDisplayDownload.visibility = View.GONE

        loadBannerAd()

//        val bundle2 = Bundle()
//        bundle2.putString("InstagramDownload_screen", "InstagramDownload_screen_open")
//        firebaseAnalytics.logEvent("InstagramDownload_screen_open", bundle2)

//        val clickAnimation = AnimationUtils.loadAnimation(activity, R.anim.button_animation)
//        binding.btnOpenInsta.startAnimation(clickAnimation)
    }

    private fun showHowToUseDialog() {
        val dialogBinding = DialogHowToUseBinding.inflate(layoutInflater)
        val dialog = Dialog(requireActivity(), R.style.Theme_Dialog_full)
        dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setGravity(Gravity.BOTTOM)
        dialog.setCancelable(true)

        dialog.setCanceledOnTouchOutside(true)
        dialog.setContentView(dialogBinding.root)
        dialogBinding.ivClose.setOnClickListener {
            dialog.dismiss()
            preferences.putInstagramIntro(true)
        }
        dialogBinding.btnView.setOnClickListener {
            dialog.dismiss()
            startActivity(
                Intent(
                    activity,
                    IntroActivity::class.java
                ).putExtra(Constant.EXTRA_IS_OPEN_FROM_BROWSER, true)
            )
        }

        dialog.show()
    }


    var isAdLoaded=false
    var mAdView: AdView?=null

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    private fun loadBannerAd() {
        binding.frameNative.visibility = View.VISIBLE
        if (MyApplication.isAdsEnable && !isAdLoaded) {
            val adId = getString(R.string.bannerInstaFrag)
            BannerAdHelper.showBanner(activity, binding.frameNative, binding.frameNative, adId,
                AdCache.bannerInstaFrag, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.bannerInstaFrag = adView
                    isAdLoaded = isLoaded
                })
        }
    }



    private fun setSwitchValue() {
        isLogin = preferences.isLoginInstagram()
        binding.switchPrivate.setImageDrawable(
            ContextCompat.getDrawable(
                requireContext(),
                if (isLogin) R.drawable.ic_switch_on else R.drawable.ic_switch_off
            )
        )
    }

    private fun setLoginData() {
        setWebCookie()
        if (preferences.isLoginInstagram()) {
            binding.loutInstaStories.visibility = View.VISIBLE
//            binding.loutInstLoin.visibility = View.GONE

            getStories()
        } else {
            binding.loutInstaStories.visibility = View.GONE
//            binding.loutInstLoin.visibility = View.VISIBLE
            binding.loutLoading.visibility = View.GONE
            binding.loutLoading.visibility = View.GONE
            binding.txtNoStories.visibility = View.GONE
        }
    }

    private fun getStories() {
        storiesList.clear()
        if (storiesAdapter != null)
            storiesAdapter?.notifyDataSetChanged()
        binding.progressStoriesList.visibility = View.VISIBLE
        val api = ApiManager()
        api.getStoriesApi(activity, object : APIResponse {

            override fun onResponse(response: Any) {
                val storyModel = Gson().fromJson(
                    Gson().toJson(response),
                    StoryModel::class.java
                )
                if (activity != null && !activity.isFinishing)
                    activity.runOnUiThread {
                        binding.progressStoriesList.visibility = View.GONE
                        if (storyModel != null)
                            if (storyModel.tray.isNullOrEmpty()) {
                                binding.loutInstaStories.visibility = View.VISIBLE
                                binding.txtNoStories.visibility = View.VISIBLE
                                binding.rvStories.visibility = View.GONE
                            } else {
                                binding.loutInstaStories.visibility = View.VISIBLE
                                binding.txtNoStories.visibility = View.GONE
                                binding.rvStories.visibility = View.VISIBLE
                                storiesList.addAll(storyModel.tray)
                                if (storiesAdapter != null)
                                    storiesAdapter?.notifyDataSetChanged()
                                else
                                    setStoriesAdapter()
                            }
                    }
            }

            override fun onFailure(error: String) {
                if (activity != null && !activity.isFinishing)
                    activity.runOnUiThread {
                        binding.progressStoriesList.visibility = View.GONE
                        binding.loutInstaStories.visibility = View.GONE
                        binding.txtNoStories.visibility = View.VISIBLE
                        binding.rvStories.visibility = View.GONE
                    }
            }

            override fun onLoginRequired() {
                if (activity != null && !activity.isFinishing)
                    activity.runOnUiThread {
                        binding.progressStoriesList.visibility = View.GONE
                        binding.loutInstaStories.visibility = View.GONE
                        binding.txtNoStories.visibility = View.VISIBLE
                        binding.rvStories.visibility = View.GONE
                        setLoginRequired()
                    }
            }
        })
    }

    private fun setLoginRequired() {
        preferences.putLoginInstagram(false)
        setLoginData()
        setSwitchValue()
    }

    private fun getStoriesDetails(storiesDetails: StoryTray) {
        binding.progressStoriesList.visibility = View.VISIBLE
        mediaList.clear()
        if (storiesDetailsAdapter != null)
            storiesDetailsAdapter?.notifyDataSetChanged()

        val api = ApiManager()
//        api.getStoriesFullDetail(
//            activity,
//            storiesDetailInfoObserver,
//            storiesDetails.user.pk.toString()
//        )
        api.getStoriesFullDetail(
            activity,
            storiesDetails.user.pk.toString(),
            object : APIResponse {
                override fun onResponse(response: Any) {
                    val storyDetails = Gson().fromJson(
                        Gson().toJson(response),
                        StoriesDetailsResponse::class.java
                    )
                    if (activity != null && !activity.isFinishing)
                        activity.runOnUiThread {
                            binding.progressStoriesList.visibility = View.GONE
                            if (storyDetails.reelsMedia == null)
                                binding.rvStoriesList.visibility = View.GONE
                            else {
                                if (storyDetails.reelsMedia.isNotEmpty() && storyDetails.reelsMedia[0].items.isNotEmpty()) {
                                    mediaList.addAll(storyDetails.reelsMedia[0].items)
                                    binding.rvStoriesList.visibility = View.VISIBLE
                                    if (storiesDetailsAdapter != null)
                                        storiesDetailsAdapter?.notifyDataSetChanged()
                                    else
                                        setStoriesDetailsAdapter()
                                } else {
                                    binding.rvStoriesList.visibility = View.GONE
                                }
                            }
                        }
                }

                override fun onFailure(error: String) {
                    if (activity != null && !activity.isFinishing)
                        activity.runOnUiThread {
                            binding.progressStoriesList.visibility = View.GONE
                        }
                }

                override fun onLoginRequired() {
                    if (activity != null && !activity.isFinishing)
                        activity.runOnUiThread {
                            binding.progressStoriesList.visibility = View.GONE
                            setLoginRequired()
                        }
                }

            })
    }

    private fun intiWebView() {
        binding.webView.settings.javaScriptEnabled = true
        binding.webView.webViewClient = MyBrowser(this, defaultSSLSF)
        binding.webView.webChromeClient = object : WebChromeClient() {

            override fun onProgressChanged(webView: WebView, i: Int) {
//                binding.swipeRefreshLayout.isRefreshing = i != 100
            }
        }
    }

    private fun setWebCookie() {
        if (preferences.isLoginInstagram()) {
            val cookiesList = listOf(preferences.getInstagramCookies())
            cookiesList.forEach { item ->
                CookieManager.getInstance().setCookie("https://www.instagram.com", item)
            }
        } else {
            CookieManager.getInstance().removeAllCookie()
        }
    }

    private fun showLoginDialog(isDownload: Boolean = false) {
        val dialog = LoginDialog(activity, onLoginListener = {
            isLoginOpenFromDownload = isDownload
            loginLauncher.launch(Intent(activity, LoginActivity::class.java))
        })
        dialog.show()
    }

    private fun intiListener() {
        binding.btnPaste.setOnClickListener {
            pasteText()
        }
        binding.btnDownload.setOnClickListener {
            if (!preferences.isLoginInstagram())
                showLoginDialog(true)
            else
                checkValidation()
        }

        binding.switchPrivate.setOnClickListener {
            val isLoginData: Boolean = !isLogin

            if (!isLoginData)
                binding.switchPrivate.setImageDrawable(
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.ic_switch_off
                    )
                )
            if (isLoginData) {
                showLoginDialog()
            } else {
                isLogin = false
                preferences.putLoginInstagram(false)
                setLoginData()
            }
        }

        binding.btnOpenInsta.setOnClickListener {
//            openLoginScreen()
            startActivity(
                Intent(
                    activity,
                    BrowserDownloadActivity::class.java
                ).putExtra(Constant.PUT_KEY_URL, Constant.URL_Insta)
                    .putExtra(
                        Constant.EXTRA_TYPE,
                        Constant.TYPE_Insta
                    )
            )
        }
    }

    private fun pasteText() {
        binding.edtPasteUrl.setText("")
        if (!::clipBoard.isInitialized)
            clipBoard =
                activity.getSystemService(AppCompatActivity.CLIPBOARD_SERVICE) as ClipboardManager

        try {
            if (!clipBoard.hasPrimaryClip()) {
            } else if (!clipBoard.primaryClipDescription!!.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)) {
                if (clipBoard.primaryClip!!.getItemAt(0).text.toString()
                        .contains("instagram.com")
                ) {
                    binding.edtPasteUrl.setText(clipBoard.primaryClip!!.getItemAt(0).text.toString())
                    binding.edtPasteUrl.setSelection(binding.edtPasteUrl.text.toString().length)
                    Log.e(
                        "",
                        "pasteText ==>> else if ==>> ${clipBoard.primaryClip!!.getItemAt(0).text.toString()}"
                    )
                }
            } else {
                val item = clipBoard.primaryClip!!.getItemAt(0)
                if (item.text.toString().contains("instagram.com")) {
                    binding.edtPasteUrl.setText(item.text.toString())
                    binding.edtPasteUrl.setSelection(binding.edtPasteUrl.text.toString().length)
                    Log.e("", "pasteText ==>> else ==>> ${item.text.toString()}")
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("", "pasteText ==>> message==>> ${e.message}")
        }
    }

    private fun checkValidation() {
        val url = binding.edtPasteUrl.text.toString()
        if (!Utils.isNetworkAvailable(activity)) {
            Toast.makeText(
                activity,
                getString(R.string.internet_connection_msg),
                Toast.LENGTH_SHORT
            ).show()
            return
        } else
            if (url.contains("www.instagram.com/p/") || url.contains("www.instagram.com/reel/")) {
                if (checkStoragePermissions())
                    fetchUrlData()
                else
                    permissionLauncher.launch(
                        Intent(
                            activity,
                            PermissionActivity::class.java
                        )
                    )
            } else {
                Toast.makeText(
                    activity,
                    getString(R.string.url_instagram_validation),
                    Toast.LENGTH_SHORT
                ).show()
                return
            }
    }


    var permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                checkValidation()
            }
        }

    var storiesPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                setStoriesDownload()
            }
        }

    fun checkStoragePermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                activity,
                android.Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                activity,
                android.Manifest.permission.READ_MEDIA_VIDEO
            ) == PackageManager.PERMISSION_GRANTED
        } else
            ActivityCompat.checkSelfPermission(
                activity,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
    }

    private fun loadUrl(url: String) {
        startLoading()
        binding.webView.loadUrl(url)
    }

    private fun startLoading() {
        binding.loutDisplayDownload.visibility = View.GONE
        binding.loutLoading.visibility = View.VISIBLE
    }

    private fun finishLoading() {
        activity.runOnUiThread {
            binding.loutLoading.visibility = View.GONE
        }
    }

    private fun showDisplayDownloadData(fileList: ArrayList<String>) {
        downloadList.clear()
        downloadList.addAll(fileList)
        finishLoading()

        binding.loutDisplayDownload.visibility = View.VISIBLE
        val adapter = DownloadViewAdapter(activity, fileList, deleteListener = {
//            fileList.removeAt(it)
//            if (fileList.size == 0) {
//                binding.loutDisplayDownload.visibility = View.GONE
//            } else {
//                showDisplayDownloadData(fileList)
//                if (it < fileList.size)
//                    binding.viewpagerDownload.currentItem = it
//            }
        })
        adapter2 = DownloadViewAdapter2(activity, downloadList, deleteListener = {
            selectDeletePos = it
            val file1 = File(downloadList[selectDeletePos])
            val d = file1.delete()
            if (d) {
                updateToDelete()
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                isOpenDeleteFromStories = false
                FileUtil.deleteWithoutManageExternalStorage(downloadList[it], activity)
            }
        })
        binding.viewpagerDownload2.adapter = adapter2
        binding.dotsIndicator.attachTo(binding.viewpagerDownload2)
        if (downloadList.size == 1)
            binding.dotsIndicator.visibility = View.GONE
        else
            binding.dotsIndicator.visibility = View.VISIBLE
    }

    private fun updateToDelete() {
        EventBus.getDefault()
            .post(DownloadDeleteEvent(downloadList[selectDeletePos], 0))
        downloadList.removeAt(selectDeletePos)
        adapter2?.notifyDataSetChanged()
        if (downloadList.size == 0) {
            binding.loutDisplayDownload.visibility = View.GONE
        } else {
            if (selectDeletePos == downloadList.size)
                binding.viewpagerDownload2.currentItem = downloadList.size - 1
            else if (selectDeletePos < downloadList.size)
                binding.viewpagerDownload2.currentItem = selectDeletePos
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Constant.DELETE_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            if (isOpenDeleteFromStories) {
                isOpenDeleteFromStories = false
                if (storiesDetailsAdapter != null)
                    storiesDetailsAdapter!!.notifyItemChanged(storiesDetailsPos)
                val folder = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath
                            + File.separator + getString(R.string.app_name)
                            + File.separator + Constant.FOLDER_INSTAGRAM
                )
                val fileN =
                    Constant.TYPE_Story + mediaList[storiesDetailsPos].id + if (mediaList[storiesDetailsPos].mediaType == Constant.TYPE_IMAGE) ".png" else ".mp4"
                val file = File(folder, fileN)
                val deletePath = file.path
                EventBus.getDefault()
                    .post(DownloadDeleteEvent(deletePath, 0))
            } else
                updateToDelete()
        }
    }

    fun setUrlFormat(str: String?): String {
        return try {
            val uri = URI(str)
            URI(uri.scheme, uri.authority, uri.path, null, uri.fragment).toString()
        } catch (e2: Exception) {
            e2.printStackTrace()
            ""
        }
    }

    private fun fetchUrlData() {
        val url = binding.edtPasteUrl.text.toString()
//        if (url.startsWith("https://www.instagram.com/reel/")) {
        if (url.isNotEmpty()) {
            // instagramCopyENDURL
            val str = setUrlFormat(url) + AppUrl().instagramCopyENDURL()

            startLoading()
            val api = ApiManager()
//            api.callResult(activity, instaObserver, str, cookie)
            api.callResult(activity, str, object : APIResponse {
                override fun onResponse(response: Any) {
                    val versionList = Gson().fromJson(
                        Gson().toJson(response),
                        InstagramModel::class.java
                    )
                    activity.runOnUiThread {
                        if (versionList != null)
                            if (versionList.items != null) {
                                if (versionList.items.size != 0) {
                                    val downloadList: ArrayList<DownloadData> = ArrayList()
                                    val downloadManager = DownloadManager(activity)
                                    var posterId = versionList.items[0].id
                                    when (versionList.items[0].media_type) {
                                        Constant.TYPE_VIDEO -> {
                                            if (!downloadManager.checkFileDownload(
                                                    Constant.TYPE_Insta,
                                                    posterId,
                                                    Constant.TYPE_VIDEO
                                                )
                                            ) {
                                                val downloadUrl =
                                                    versionList.items[0].video_versions[0].url
                                                downloadList.add(
                                                    DownloadData(
                                                        downloadUrl,
                                                        Constant.TYPE_VIDEO,
                                                        posterId
                                                    )
                                                )
                                            }
                                        }

                                        Constant.TYPE_IMAGE -> {
                                            if (!downloadManager.checkFileDownload(
                                                    Constant.TYPE_Insta,
                                                    posterId,
                                                    Constant.TYPE_IMAGE
                                                )
                                            ) {
                                                val downloadUrl =
                                                    versionList.items[0].image_versions2.candidates[0].url
                                                downloadList.add(
                                                    DownloadData(
                                                        downloadUrl,
                                                        Constant.TYPE_IMAGE,
                                                        posterId
                                                    )
                                                )
                                            }
                                        }

                                        Constant.TYPE_POST_MULTIPLE -> {
                                            for (carouselMedia in versionList.items[0].carousel_media) {
                                                posterId = carouselMedia.id
                                                if (carouselMedia.media_type == Constant.TYPE_IMAGE) {
                                                    if (!downloadManager.checkFileDownload(
                                                            Constant.TYPE_Insta,
                                                            posterId,
                                                            Constant.TYPE_IMAGE
                                                        )
                                                    ) {
                                                        val downloadUrl =
                                                            if (carouselMedia.image_versions2.candidates.size < 2) {
                                                                carouselMedia.image_versions2.candidates[0].url
                                                            } else
                                                                carouselMedia.image_versions2.candidates[1].url
                                                        downloadList.add(
                                                            DownloadData(
                                                                downloadUrl,
                                                                Constant.TYPE_IMAGE,
                                                                posterId
                                                            )
                                                        )
                                                    }

                                                } else if (carouselMedia.media_type == Constant.TYPE_VIDEO) {
                                                    if (!downloadManager.checkFileDownload(
                                                            Constant.TYPE_Insta,
                                                            posterId,
                                                            Constant.TYPE_VIDEO
                                                        )
                                                    ) {
                                                        val downloadUrl =
                                                            carouselMedia.video_versions[0].url
                                                        downloadList.add(
                                                            DownloadData(
                                                                downloadUrl,
                                                                Constant.TYPE_VIDEO,
                                                                posterId
                                                            )
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    downloadUrl(downloadList)
                                } else {
                                    finishLoading()
                                    Toast.makeText(
                                        activity,
                                        getString(R.string.download_fail_msg),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } else {
                                finishLoading()
                                Toast.makeText(
                                    activity,
                                    getString(R.string.download_fail_msg),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        else {
                            finishLoading()
                            Toast.makeText(
                                activity,
                                getString(R.string.download_fail_msg),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }

                override fun onFailure(error: String) {
                    finishLoading()
                    Toast.makeText(
                        activity,
                        error.ifEmpty { getString(R.string.download_fail_msg) },
                        Toast.LENGTH_SHORT
                    ).show()
                }

                override fun onLoginRequired() {
                    finishLoading()
                    setLoginRequired()
                }

            })

        } else {
//            startActivity(Intent(this, LoginActivity::class.java).putExtra("url", url))
//            loadUrl(url)

//            // launching a new coroutine
//
            val thread = Thread {
                val document: Document =
                    Jsoup.connect(url)
                        .cookie(
                            "Cookie",
                            "ds_user_id=${preferences.getInstagramUserId() ?: ""}; sessionid=${preferences.getInstagramSessionID() ?: ""}"
                        )
//                        .userAgent("Instagram 9.5.2 (iPhone7,2; iPhone OS 9_3_3; en_US; en-US; scale=2.00; 750x1334) AppleWebKit/420+")
                        .get()
//                Log.e("", "JsoupBody  ${document.body()}")
                document.body()
                val img: Element? = document.select("react-root").first()
                Log.e("", "JsoupBodyimg  ${img.toString()}")
                Log.e("", "JsoupBody  ${document.body()}")

            }
            thread.start()
        }
//            for (headline in newsHeadlines) {
//                log(
//                    "%s\n\t%s",
//                    headline.attr("title"), headline.absUrl("href")
//                )
//            }
//            val quotesApi = RetrofitHelper.getInstance().create(Api::class.java)
//            val headers = mutableMapOf<String, String>()
//            headers["Cookie"] =
//                "ds_user_id=${preferences.getInstagramUserId() ?: ""}; sessionid=${preferences.getInstagramSessionID() ?: ""}"
//            var UrlWithoutQP = getUrlWithoutParameters(url)
//            UrlWithoutQP = "$UrlWithoutQP?__a=1"
//            var userAgent =
//                "Instagram 9.5.2 (iPhone7,2; iPhone OS 9_3_3; en_US; en-US; scale=2.00; 750x1334) AppleWebKit/420+"
//            if (UrlWithoutQP.contains("reel")) {
//                userAgent = ""
//            }
//            headers["User-Agent"] = userAgent
//            GlobalScope.launch {
//                val result = quotesApi.getQuotes(UrlWithoutQP, headers)
//                if (result != null)
//                // Checking the results
//                    Log.d("API: ", " btnDownload respone==>>>  " + result.body().toString())
//            }
    }


    private fun downloadUrl(
        downloadList: ArrayList<DownloadData>,
        isStoryDownload: Boolean = false
    ) {
        finishLoading()
        if (downloadList.isEmpty()) {
            Toast.makeText(
                requireContext(),
                getString(R.string.already_downloaded),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            var dialogBinding: DialogDownloadBinding
            var dialog: Dialog
            val filesList: ArrayList<String> = ArrayList()

            activity.runOnUiThread {
                finishLoading()
                dialogBinding = DialogDownloadBinding.inflate(layoutInflater)
                dialog = Dialog(activity, R.style.Theme_Dialog)
                dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
                dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog.setCancelable(false)
                dialog.setCanceledOnTouchOutside(false)
                dialog.setContentView(dialogBinding.root)
                dialogBinding.progressBar.progress = 0
                dialogBinding.txtPer.text = "0%"
                dialogBinding.txtCount.text = "0/100"
                dialog.show()

                val downloadManager = DownloadManager(activity)
                Observable.fromCallable {
                    for (downloadData in downloadList) {
                        activity.runOnUiThread {
                            dialogBinding.progressBar.progress = 0
                            dialogBinding.txtPer.text = "0%"
                            dialogBinding.txtCount.text = "0/100"
                        }
                        val path = downloadManager.downloadFile(
                            downloadData.url,
                            if (isStoryDownload) Constant.TYPE_Story else Constant.TYPE_Insta,
                            downloadData.posterId,
                            downloadData.fileType,
                            progressUpdateListener = {
                                activity.runOnUiThread {
                                    dialogBinding.progressBar.progress = it
                                    dialogBinding.txtPer.text = "$it%"
                                    dialogBinding.txtCount.text = "$it/100"
                                }
                            })
                        if (path.isNotEmpty())
                            filesList.add(path)
                    }
                    return@fromCallable ""
                }.subscribeOn(Schedulers.io())
                    .doOnError { throwable: Throwable? ->
                        activity.runOnUiThread {
                            dialog.dismiss()
                            Toast.makeText(
                                activity,
                                activity.getText(R.string.download_fail_msg),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    .subscribe { result: String? ->
                        Log.e("", "getReels result==>> $result ")
                        activity.runOnUiThread {
                            dialog.dismiss()
                            if (filesList.isNotEmpty()) {
                                EventBus.getDefault()
                                    .post(DownloadUpdateEvent(""))
                                if (isStoryDownload) {
                                    if (storiesDetailsAdapter != null && selectDownloadPos != -1)
                                        storiesDetailsAdapter?.notifyItemChanged(selectDownloadPos)
                                } else {
                                    showDisplayDownloadData(filesList)
                                }
                            } else {
                                Toast.makeText(
                                    activity,
                                    activity.getText(R.string.download_fail_msg),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
            }
        }
    }

    class MyBrowser(
        var activity: InstagramFragment,
        var defaultSSLSF: SSLSocketFactory?,
    ) : WebViewClient() {

        override fun shouldOverrideUrlLoading(webView: WebView, str: String?): Boolean {
            webView.loadUrl(str!!)
            return true
        }

        override fun onPageFinished(webView: WebView?, str: String?) {
            super.onPageFinished(webView, str)
            Log.e("", "MyBrowser onPageFinished")
//            activity.finishLoading()
        }

        override fun onLoadResource(view: WebView, url: String) {
            Log.d("fb :", "URL: $url")
            val viewUrl = view.url
            val title = view.title
            object : VideoContentSearch(
                activity.activity,
                url,
                viewUrl,
                title
            ) {
                override fun onStartInspectingURL() {
                    Log.e("", "MyBrowser onStartInspectingURL")
//                                            Utils.Companion.disableSSLCertificateChecking()

                }

                override fun onFinishedInspectingURL(finishedAll: Boolean) {
                    Log.e("", "MyBrowser onFinishedInspectingURL")
                    HttpsURLConnection.setDefaultSSLSocketFactory(defaultSSLSF)
                    activity.finishLoading()
                }

                override fun onVideoFound(
                    size: String?,
                    type: String?,
                    link: String?,
                    name: String?,
                    page: String?,
                    chunked: Boolean,
                    website: String?,
                    audio: Boolean
                ) {

                    Log.e(
                        "",
                        "MyBrowser type==>> $type link==>> $link name==>> $name page==>> $page "
                    )
//                    if (!link.isNullOrEmpty())
//                        activity.downloadUrl(link, Constant.TYPE_VIDEO)
                    //                        videoList.addItem(size, type, link, name, page, chunked, website, audio)
                    //                        updateFoundVideosBar()
                }
            }.start()
        }
    }

}