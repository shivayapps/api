package com.fastflow.smartdownload.manager.utils

import android.content.Context
import java.util.regex.Pattern

class TwitterVideo(val context: Context) {

    fun parseQuery(inputQuery: String) {
        val type = getQueryType(inputQuery)
//        var res = arrayListOf<ResultItem?>()
        try {
//            res = getDefault(inputQuery, true)
//            when (type) {
//                "Search" -> {
//                    res = repository.search(inputQuery, resetResults)
//                }
//                "YT_Video" -> {
//                    res = repository.getOne(inputQuery, resetResults)
//                }
//                "YT_Playlist" -> {
//                    res = repository.getPlaylist(inputQuery, resetResults)
//                }
//                "Default" -> {
//
//                }
//            }
        } catch (e: Exception) {
//            Log.e(tag, e.toString())
        }
    }

    private fun getQueryType(inputQuery: String) : String {
        var type = "Search"
        val p = Pattern.compile("^(https?)://(www.)?(music.)?youtu(.be)?")
        val m = p.matcher(inputQuery)
        if (m.find()) {
            type = "YT_Video"
            if (inputQuery.contains("playlist?list=")) {
                type = "YT_Playlist"
            }
        } else if (inputQuery.contains("http")) {
            type = "Default"
        }
        return type
    }

//    suspend fun getDefault(inputQuery: String, resetResults: Boolean) : ArrayList<ResultItem?> {
//        val infoUtil = InfoUtil(context)
//        try {
//            val items = infoUtil.getFromYTDL(inputQuery)
//            if (resetResults) {
//                deleteAll()
//                itemCount.value = items.size
//            }else{
//                items.forEach { it!!.playlistTitle = "ytdlnis-Search" }
//            }
//            items.forEach {
//                resultDao.insert(it!!)
//            }
//            return items
//        } catch (e: Exception) {
//            Log.e(tag, e.toString())
//        }
//        return arrayListOf()
//    }
}