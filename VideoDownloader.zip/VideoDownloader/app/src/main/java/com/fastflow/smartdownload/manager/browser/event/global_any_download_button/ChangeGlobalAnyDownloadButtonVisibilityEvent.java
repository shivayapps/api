package com.fastflow.smartdownload.manager.browser.event.global_any_download_button;


import com.fastflow.smartdownload.manager.browser.helpers.AnyDownloadModel;

import java.util.ArrayList;
import java.util.List;


public class ChangeGlobalAnyDownloadButtonVisibilityEvent {
    private ArrayList<AnyDownloadModel> anyFilesDownloadModels;
    private boolean normalColor;
    private boolean visible;

    public ChangeGlobalAnyDownloadButtonVisibilityEvent(boolean z, boolean z2, ArrayList<AnyDownloadModel> list) {
        this.visible = false;
        this.normalColor = false;
        new ArrayList();
        this.visible = z;
        this.normalColor = z2;
        this.anyFilesDownloadModels = list;
    }

    public boolean isVisible() {
        return this.visible;
    }

    public void setVisible(boolean z) {
        this.visible = z;
    }

    public List<AnyDownloadModel> getAnyFilesDownloadModels() {
        return this.anyFilesDownloadModels;
    }

    public void setAnyFilesDownloadModels(ArrayList<AnyDownloadModel> list) {
        this.anyFilesDownloadModels = list;
    }

    public boolean isNormalColor() {
        return this.normalColor;
    }

    public void setNormalColor(boolean z) {
        this.normalColor = z;
    }
}
