package com.fastflow.smartdownload.manager.ui.activity.option.dpGenerator

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.View
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.fastflow.smartdownload.manager.R

import com.fastflow.smartdownload.manager.browser.event.DownloadDeleteEvent
import com.fastflow.smartdownload.manager.databinding.ActivitySaveImageBinding
import com.fastflow.smartdownload.manager.ui.activity.BaseActivity
import com.fastflow.smartdownload.manager.ui.adapter.SaveAdapter
import com.fastflow.smartdownload.manager.ui.data.DataModel
import com.fastflow.smartdownload.manager.ui.interfaces.CheckFolder
import com.fastflow.smartdownload.manager.utils.AdCache
import com.fastflow.smartdownload.manager.utils.Constant
import com.fastflow.smartdownload.manager.utils.FileUtil
import com.fastflow.smartdownload.manager.utils.GetDataMethod
import com.fastflow.smartdownload.manager.utils.MyApplication
import com.fastflow.smartdownload.manager.utils.UtilsAd
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.util.concurrent.Executors

class SaveImageActivity : BaseActivity(), CheckFolder {

    lateinit var binding: ActivitySaveImageBinding
    var path = " "
    var downloadStatusList: ArrayList<DataModel> = ArrayList()
    var downloadAdapter: SaveAdapter? = null
    var selectPos = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySaveImageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        binding.loutToolbar.txtTitle.text = getString(R.string.savedImage)

        path =
            FileUtil.getExternalStoragePublicDirectory(
                this,
                Environment.DIRECTORY_PICTURES
            ) + File.separator + getString(
                R.string.app_name
            ) + File.separator + Constant.FOLDER_DP_CREATE

        setDataInAdapter()
        intiListener()
    }

    var isAdLoaded=false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    private fun loadBannerAd() {
        if (MyApplication.isAdsEnable && !isAdLoaded) {
            val adId = getString(R.string.bannerSaveImage)
            BannerAdHelper.showBanner(this, binding.frameBanner, binding.frameBanner, adId,
                AdCache.bannerSaveImage, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.bannerSaveImage = adView
                    isAdLoaded = isLoaded
                })
        }
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener { onBackPressed() }
    }

    private fun setDataInAdapter() {
        val service = Executors.newSingleThreadExecutor()
        service.execute {
            runOnUiThread { binding.progress.visibility = View.VISIBLE }
            downloadStatusList = GetDataMethod(this).getAllList(path)
            runOnUiThread {
                binding.progress.visibility = View.GONE
                setAdapterLayouts()
            }
        }
    }

    private fun setAdapterLayouts() {
        if (downloadStatusList.size == 0) {
            binding.tvNoData.visibility = View.VISIBLE
        } else {
            binding.tvNoData.visibility = View.GONE
            loadBannerAd()
        }
        downloadAdapter =
            SaveAdapter(downloadStatusList, this, this, this, deleteListener = {
                selectPos = it
                val deletePath = downloadStatusList[it].path
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    FileUtil.deleteWithoutManageExternalStorage(deletePath, this)
                } else {
                    val file1 = File(deletePath)
                    val d = file1.delete()
                    if (d) {
                        EventBus.getDefault()
                            .post(DownloadDeleteEvent(deletePath, 1))
                        downloadStatusList.removeAt(it)
                        downloadAdapter!!.notifyDataSetChanged()
                        if (downloadStatusList.size == 0) {
                            dataEmpty()
                        }
                    }
                }
            })
        binding.rvDownload.adapter = downloadAdapter
    }

    override fun dataEmpty() {
        binding.tvNoData.visibility = View.VISIBLE
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Constant.DELETE_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val deletePath = downloadStatusList[selectPos].path
            EventBus.getDefault()
                .post(DownloadDeleteEvent(deletePath, 1))
            downloadStatusList.removeAt(selectPos)
            downloadAdapter!!.notifyDataSetChanged()
            if (downloadStatusList.size == 0) {
                dataEmpty()
            }
        }
    }

}