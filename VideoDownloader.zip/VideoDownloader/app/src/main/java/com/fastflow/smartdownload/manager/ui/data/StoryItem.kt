package com.fastflow.smartdownload.manager.ui.data

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class StoryItem( @SerializedName("taken_at")
                      val takenAt: Long,
                      val pk: Long,
                      val id: String,
                      @SerializedName("device_timestamp")
                      val deviceTimestamp: Long,
                      @SerializedName("media_type")
                      val mediaType: Int,
                      val code: String,
                      @SerializedName("client_cache_key")
                      val clientCacheKey: String,
                      @SerializedName("is_reel_media")
                      val isReelMedia: Boolean,
                      @SerializedName("is_terminal_video_segment")
                      val isTerminalVideoSegment: Boolean,
                      @SerializedName("image_versions2")
                      val imageVersions2: ImageVersions,
                      @SerializedName("original_width")
                      val originalWidth: Long,
                      @SerializedName("original_height")
                      val originalHeight: Long,
                      @SerializedName("product_type")
                      val productType: String,
                      @SerializedName("is_paid_partnership")
                      val isPaidPartnership: Boolean,
                      @SerializedName("imported_taken_at")
                      val importedTakenAt: Long,
                      @SerializedName("expiring_at")
                      val expiringAt: Long,
                      @SerializedName("video_codec")
                      val videoCodec: String,
                      @SerializedName("number_of_qualities")
                      val numberOfQualities: Long,
                      @SerializedName("video_versions")
                      val videoVersions: List<VideoVersion>,
                      @SerializedName("has_audio")
                      val hasAudio: Boolean,
                      @SerializedName("video_duration")
                      val videoDuration: Double,) : Serializable
