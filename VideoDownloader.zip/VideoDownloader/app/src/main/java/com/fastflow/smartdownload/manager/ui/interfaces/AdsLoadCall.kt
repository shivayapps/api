package com.fastflow.smartdownload.manager.ui.interfaces

interface AdsLoadCall {
    fun isLoadNativeAds()
}