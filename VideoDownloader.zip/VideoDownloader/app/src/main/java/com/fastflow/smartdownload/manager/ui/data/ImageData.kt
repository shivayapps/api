package com.fastflow.smartdownload.manager.ui.data

import java.nio.file.Path

data class ImageData(var path: Path)
