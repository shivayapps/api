package com.fastflow.smartdownload.manager.browser.event

import com.fastflow.smartdownload.manager.ui.data.DownloadData

data class ProgressUpdateDownloadEvent(var data: DownloadData)