package com.fastflow.smartdownload.manager.browser.ui_events;


import com.fastflow.smartdownload.manager.browser.helpers.DownloadYTVideoButtonModel;
import com.fastflow.smartdownload.manager.browser.helpers.FBContainerModel;
import com.fastflow.smartdownload.manager.browser.helpers.InstaPostModel;
import com.fastflow.smartdownload.manager.browser.helpers.InstaPostModel;

import java.util.List;

public interface ButtonsIntegratingStateHandler {
    void OnComplete_FB(List<FBContainerModel> list);

    void OnComplete_Insta(List<InstaPostModel> list);

    void OnComplete_YT(String str, List<DownloadYTVideoButtonModel> list, List<DownloadYTVideoButtonModel> list2, DownloadYTVideoButtonModel downloadYTVideoButtonModel);

    void OnError(String str);
}
