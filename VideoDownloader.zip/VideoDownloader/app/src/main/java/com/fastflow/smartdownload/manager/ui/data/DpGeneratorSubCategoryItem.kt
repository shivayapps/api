package com.fastflow.smartdownload.manager.ui.data

import java.io.Serializable

data class DpGeneratorSubCategoryItem(
    val category_id: Int,
    val created_at: String,
    val deleted_at: Any,
    val id: Int,
    val image_name: String,
    val img: String,
    val name: String,
    val updated_at: String
) : Serializable