package com.fastflow.smartdownload.manager.ui.adapter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.fastflow.smartdownload.manager.databinding.HashtegItemLayoutBinding
import com.fastflow.smartdownload.manager.ui.activity.HashtagArrayActivity
import com.fastflow.smartdownload.manager.ui.data.HashtagData
import com.fastflow.smartdownload.manager.utils.Constant

class HashtagDataAdapter(var hashtagDataList: ArrayList<HashtagData>, var activity: Activity, var context: Context) : RecyclerView.Adapter<HashtagDataAdapter.MyViewHolder>() {
    inner class MyViewHolder(var binding: HashtegItemLayoutBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(HashtegItemLayoutBinding.inflate(LayoutInflater.from(parent.context),parent,false))
    }

    override fun getItemCount(): Int {
        return hashtagDataList.size
    }
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        with(holder.binding){
            with(hashtagDataList[position]){
//                ivBg.setColorFilter(ContextCompat.getColor(context, imageTint), android.graphics.PorterDuff.Mode.SRC_IN)
//                ivImage.setImageResource(imageIcon)
                tvTitle.text = title
                holder.itemView.setOnClickListener {
                    activity.startActivity(Intent(context,HashtagArrayActivity::class.java).putExtra(Constant.PUT_KEY_HASHTAG_TITLE,title))
                }
            }
        }
    }
}