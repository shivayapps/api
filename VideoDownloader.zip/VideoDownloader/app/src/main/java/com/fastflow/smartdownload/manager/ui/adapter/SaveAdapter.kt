package com.fastflow.smartdownload.manager.ui.adapter


import android.app.Activity
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.databinding.DeleteDialogLayoutBinding
import com.fastflow.smartdownload.manager.databinding.ItemSaveBinding
import com.fastflow.smartdownload.manager.ui.activity.FileFullViewActivity
import com.fastflow.smartdownload.manager.ui.data.DataModel
import com.fastflow.smartdownload.manager.ui.interfaces.CheckFolder
import com.fastflow.smartdownload.manager.utils.Constant
import com.fastflow.smartdownload.manager.utils.Utils


class SaveAdapter(
    var statusList: ArrayList<DataModel>,
    var context: Context,
    var activity: Activity,
    var checkFolder: CheckFolder,
    val deleteListener: (pos: Int) -> Unit
) : RecyclerView.Adapter<SaveAdapter.MyViewHolder>() {
    inner class MyViewHolder(var binding: ItemSaveBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(
            ItemSaveBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return statusList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        with(holder.binding) {
            with(statusList[position]) {
                ivDelete.visibility = View.VISIBLE
                ivDownload.visibility = View.GONE
//                val file = File(path)
//                val ext = file.name.substring(file.name.lastIndexOf("."))
//                if (ext == ".mp4" || ext == ".webm") {
//                    ivPlay.visibility = View.VISIBLE
//                } else {
//                    ivPlay.visibility = View.GONE
//                }
                Glide.with(context)
                    .load(path)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(imageDownload)
                ivDelete.setOnClickListener {
                    val builder = AlertDialog.Builder(context, R.style.CustomAlertDialog).create()
                    val deleteDialogLayoutBinding: DeleteDialogLayoutBinding =
                        DeleteDialogLayoutBinding.inflate(LayoutInflater.from(context))
                    builder.setView(deleteDialogLayoutBinding.root)
                    deleteDialogLayoutBinding.tvNo.setOnClickListener {
                        builder.dismiss()
                    }

                    deleteDialogLayoutBinding.tvYes.setOnClickListener {
                        builder.dismiss()
                        deleteListener(position)
//                        val file1 = File(path)
//                        val d = file1.delete()
//                        if (d) {
//                            statusList.removeAt(position)
//                            notifyDataSetChanged()
//                            if (statusList.size == 0) {
//                                checkFolder.dataEmpty()
//                            }
//                        }
                    }
                    builder.show()
                }
                ivShare.setOnClickListener {
                    Utils.fileShare(activity,path)
                }
                holder.itemView.setOnClickListener {
                    Constant.dataArrayList.clear()
                    Constant.dataArrayList.addAll(statusList)
                    activity.startActivity(Intent(context, FileFullViewActivity::class.java).putExtra(
                        Constant.PUT_KEY_POSTION,position).putExtra(
                        Constant.PUT_KEY_EVENT,
                        Constant.VALUE_KEY_DOWNLOAD))
                }
            }
        }
    }
}