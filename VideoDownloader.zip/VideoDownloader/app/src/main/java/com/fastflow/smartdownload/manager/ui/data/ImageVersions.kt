package com.fastflow.smartdownload.manager.ui.data

import java.io.Serializable

data class ImageVersions(  val candidates: List<Candidate>): Serializable
