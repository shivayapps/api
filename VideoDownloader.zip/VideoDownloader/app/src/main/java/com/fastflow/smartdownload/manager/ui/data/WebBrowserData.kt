package com.fastflow.smartdownload.manager.ui.data

import com.fastflow.smartdownload.manager.R


data class WebBrowserData(
    var title: String = null ?: "",
//    var imageIcon: Int = null ?: R.drawable.ic_instagram_browser,
    var imageTint: Int = null ?: R.color.instagram_holiday_love_bg,
    var urls: String = null ?: "https://www.google.com/"
)
