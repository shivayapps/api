package com.fastflow.smartdownload.manager.ui.adapter

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.LinearGradient
import android.graphics.Shader
import android.text.TextPaint
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.databinding.ItemTabFolderBinding
import com.fastflow.smartdownload.manager.ui.data.TabData

class TabAdapter(
    var context: Context,
    var tabList: ArrayList<TabData>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<TabAdapter.ViewHolder>() {

    var selectTab = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemTabFolderBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return tabList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.txtTab.text = tabList[position].title

        holder.binding.btnTab.background = if (selectTab == position) ContextCompat.getDrawable(
            context,
            R.drawable.btn_gradient
        ) else ContextCompat.getDrawable(context, R.drawable.btn_gray)

        if (selectTab == position)
            removeGradientText(holder.binding.txtTab)
        else
            setGradientText(holder.binding.txtTab)

        holder.binding.btnTab.setOnClickListener {
            val p = selectTab
            selectTab = position
            clickListener(position)
            notifyItemChanged(selectTab)
            notifyItemChanged(p)
        }
    }

    class ViewHolder(var binding: ItemTabFolderBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

    private fun removeGradientText(textView: TextView) {
        textView.paint.shader = null
        textView.invalidate()
    }

    private fun setGradientText(btnSelect: TextView) {
        val paint: TextPaint = btnSelect.paint
        val width = paint.measureText(btnSelect.text.toString())

//        val bitmap = BitmapFactory.decodeResource(context.resources, R.drawable.btn_button_big)
//        val shader: Shader = BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)

        val textShader: Shader = LinearGradient(
            0f, 0f,
            width,
            btnSelect.textSize,
            intArrayOf(
                ContextCompat.getColor(context, R.color.gradient1),
                ContextCompat.getColor(context, R.color.gradient2),
                ContextCompat.getColor(context, R.color.gradient2),
                ContextCompat.getColor(context, R.color.gradient2),
                ContextCompat.getColor(context, R.color.gradient3),
            ), null, Shader.TileMode.CLAMP
        )

        btnSelect.paint.shader = textShader
        btnSelect.invalidate()
    }
}