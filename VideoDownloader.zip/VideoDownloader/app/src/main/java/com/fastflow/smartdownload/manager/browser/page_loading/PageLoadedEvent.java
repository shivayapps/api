package com.fastflow.smartdownload.manager.browser.page_loading;

public class PageLoadedEvent {
}
