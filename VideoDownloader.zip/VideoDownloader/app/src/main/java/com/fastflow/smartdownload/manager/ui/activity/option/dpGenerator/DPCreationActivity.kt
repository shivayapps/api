package com.fastflow.smartdownload.manager.ui.activity.option.dpGenerator

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.animation.RotateAnimation
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.adconfig.adsutil.admob.BannerAdHelper
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.google.android.gms.ads.AdView
import com.google.gson.Gson
import com.nostra13.universalimageloader.core.ImageLoader
import com.fastflow.smartdownload.manager.utils.AppUrl
import com.fastflow.smartdownload.manager.R

import com.fastflow.smartdownload.manager.databinding.ActivityDpcreationBinding
import com.fastflow.smartdownload.manager.ui.activity.BaseActivity
import com.fastflow.smartdownload.manager.ui.activity.PermissionActivity
import com.fastflow.smartdownload.manager.ui.adapter.DpGeneratorCategoryAdapter
import com.fastflow.smartdownload.manager.ui.adapter.DpGeneratorSubCategoryAdapter
import com.fastflow.smartdownload.manager.ui.data.DpGeneratorCategoryList
import com.fastflow.smartdownload.manager.ui.data.DpGeneratorSubCategoryItem
import com.fastflow.smartdownload.manager.ui.data.DpGeneratorSubCategoryResponse
import com.fastflow.smartdownload.manager.utils.AdCache
import com.fastflow.smartdownload.manager.utils.Constant
import com.fastflow.smartdownload.manager.utils.MyApplication
import com.fastflow.smartdownload.manager.utils.Utils
import com.fastflow.smartdownload.manager.utils.UtilsAd
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream


class DPCreationActivity : BaseActivity() {

    lateinit var binding: ActivityDpcreationBinding
    var tabSelect = 0
    var childPos = 0
    var categoryList: ArrayList<DpGeneratorCategoryList> = ArrayList()
    var categoryAdapter: DpGeneratorCategoryAdapter? = null
    var subCategoryAdapter: DpGeneratorSubCategoryAdapter? = null
    var imageSelect = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDpcreationBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        loadBannerAd()
        tabSelect = intent.getIntExtra(Constant.EXTRA_POS, 0)
        childPos = intent.getIntExtra(Constant.EXTRA_CHILD_POS, 0)
        val list = Constant.DPGeneratorData
        categoryList.addAll(list)
        binding.loutToolbar.txtTitle.text = getString(R.string.dp_frame)

        setDpRing()
        intiListener()
        setCategoryAdapter()
        setSubList()

        binding.rvHeader.scrollToPosition(tabSelect)
        binding.profileImage.post {
//            val radius = resources.getDimension(R.dimen.corner_radius)
            val radius: Float = (binding.profileImage.width / 2).toFloat()
            val shapeAppearanceModel = binding.profileImage.shapeAppearanceModel.toBuilder()
                .setAllCornerSizes(radius)
                .build()
            binding.profileImage.shapeAppearanceModel = shapeAppearanceModel
        }
    }


    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadBannerAd() {
        if (MyApplication.isAdsEnable && !isAdLoaded) {
            val adId = getString(R.string.bannerDpCreation)
            BannerAdHelper.showBanner(this, binding.frameBanner, binding.frameBanner, adId,
                AdCache.bannerDpCreation, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.bannerDpCreation = adView
                    isAdLoaded = isLoaded
                })
        }
    }

    private fun setDpRing() {
        var ring = ""
        if (categoryList[tabSelect].subList.isNotEmpty())
            ring = categoryList[tabSelect].subList[childPos].img
        if (ring.isNotEmpty()) {
//            binding.progressBar.visibility = View.VISIBLE
            ImageLoader.getInstance()
                .displayImage(
                    "assets://png/${ring}",
                    binding.ringImage
                )
//            Glide.with(this)
//                .load(ring)
//                .listener(object : RequestListener<Drawable> {
//                    override fun onLoadFailed(
//                        e: GlideException?,
//                        model: Any?,
//                        target: Target<Drawable>?,
//                        isFirstResource: Boolean
//                    ): Boolean {
//                        binding.progressBar.visibility = View.GONE
//                        return false
//                    }
//
//                    override fun onResourceReady(
//                        resource: Drawable?,
//                        model: Any?,
//                        target: Target<Drawable>?,
//                        dataSource: DataSource?,
//                        isFirstResource: Boolean
//                    ): Boolean {
//                        binding.progressBar.visibility = View.GONE
//                        val rotateAnimation = RotateAnimation(0.0f, 360.0f, 1, 0.5f, 1, 0.5f)
//                        rotateAnimation.duration = 1000L
//                        rotateAnimation.interpolator = LinearInterpolator()
//                        binding.ringImage.startAnimation(rotateAnimation)
//                        return false
//                    }
//                })
//                .into(binding.ringImage)
        }
    }

    var permissionImageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                if (checkStoragePermissions()) {
                    openGallery()
                }
            }
        }


    var permissionSaveLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                if (checkStoragePermissions()) {
                    imageStore()
                }
            }
        }


    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener { onBackPressed() }
        binding.loutToolbar.btnSave.setOnClickListener {
            if (imageSelect.isNotEmpty()) {
                if (checkStoragePermissions())
                    imageStore()
                else {
                    val intent = Intent(
                        this,
                        PermissionActivity::class.java
                    )
                    permissionSaveLauncher.launch(intent)
                }
            } else {
                Toast.makeText(
                    this,
                    getString(R.string.image_select_validation),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        binding.btnSelectPhoto.setOnClickListener {
            if (checkStoragePermissions()) {
                openGallery()
            } else {
                val intent = Intent(
                    this,
                    PermissionActivity::class.java
                )
                permissionImageLauncher.launch(intent)
            }
        }
    }

    private fun imageStore() {
        val bitmap =
            Bitmap.createBitmap(
                binding.loutImage.width,
                binding.loutImage.height,
                Bitmap.Config.ARGB_8888
            )
        val canvas = Canvas(bitmap)
        binding.loutImage.draw(canvas)
        val path = saveBitmap(bitmap)
        if (path.isNotEmpty()) {
            startActivity(Intent(this, SaveImageActivity::class.java))
            finish()
        }
    }

    private fun openGallery() {
        selectImageLauncher.launch(Intent(this, GalleryActivity::class.java))
    }

    private fun setImageData() {
        binding.progressBar.visibility = View.VISIBLE
        Glide.with(this)
            .load(imageSelect)
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>?,
                    isFirstResource: Boolean
                ): Boolean {
                    binding.progressBar.visibility = View.GONE
                    return false
                }

                override fun onResourceReady(
                    resource: Drawable?,
                    model: Any?,
                    target: Target<Drawable>?,
                    dataSource: DataSource?,
                    isFirstResource: Boolean
                ): Boolean {
                    binding.progressBar.visibility = View.GONE
                    return false
                }
            })
            .into(binding.profileImage)
    }

    private fun setButton() {
        if (imageSelect.isEmpty()) {
            binding.btnSelectPhoto.visibility = View.VISIBLE
            binding.loutToolbar.btnSave.visibility = View.GONE
        } else {
            binding.btnSelectPhoto.visibility = View.VISIBLE
            binding.loutToolbar.btnSave.visibility = View.VISIBLE
        }
    }

    private fun setCategoryAdapter() {
        categoryAdapter = DpGeneratorCategoryAdapter(this, categoryList, clickListener = {
            tabSelect = it
            setSubList()
        })
        categoryAdapter!!.tabSelect = tabSelect
        binding.rvHeader.adapter = categoryAdapter
    }

    private fun setSubList() {
        if (!categoryList[tabSelect].subList.isNullOrEmpty()) {
            setSubCategoryAdapter()
        } else {
            getSubCategoryList()
        } /*else {
            binding.recyclerView.visibility = View.GONE
            finishLoading()
        }*/
    }


    private fun setSubCategoryAdapter() {
        val subList: ArrayList<DpGeneratorSubCategoryItem> = ArrayList()
        if (!categoryList[tabSelect].subList.isNullOrEmpty())
            subList.addAll(categoryList[tabSelect].subList)

        binding.recyclerView.visibility = View.VISIBLE
        subCategoryAdapter =
            DpGeneratorSubCategoryAdapter(this, subList, clickListener = {
                childPos = it
                setDpRing()
            })
        subCategoryAdapter!!.setImageSelect(imageSelect)
        binding.recyclerView.adapter = subCategoryAdapter
    }

    var selectImageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                if (result.data != null) {
                    val image = result.data!!.getStringExtra(Constant.EXTRA_SELECT_IMAGE)!!
                    if (imageSelect != image) {
                        imageSelect = image
                        if (subCategoryAdapter != null)
                            subCategoryAdapter!!.setImageSelect(imageSelect)
                        setImageData()
                    }
                    setButton()
                }
            }
        }

    fun saveBitmap(bmp: Bitmap): String {
        val bytes = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bytes)
        val folder = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath
                    + File.separator + getString(R.string.app_name)
                    + File.separator + Constant.FOLDER_DP_CREATE
        )
        if (!folder.exists())
            folder.mkdirs()
        val f = File(
            folder, "Img_" + System.currentTimeMillis() + ".png"
        )
        var outStream: OutputStream? = null
        try {
            outStream = FileOutputStream(f)
            bmp.compress(Bitmap.CompressFormat.PNG, 100, outStream)
            outStream.flush()
            outStream.close()
            return f.path
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return ""
    }

    private fun startLoading() {
        binding.loutLoading.visibility = View.VISIBLE
    }

    private fun finishLoading() {
        binding.loutLoading.visibility = View.GONE
    }


    fun readJSONFromAsset(name: String): String? {
        var json: String? = null
        try {
            val inputStream: InputStream = assets.open("hashtag/${name}.json")
            json = inputStream.bufferedReader().use { it.readText() }
        } catch (ex: Exception) {
            ex.printStackTrace()
            return null
        }
        return json
    }

    fun parseJSON(name: String): DpGeneratorSubCategoryResponse {
        return Gson().fromJson(readJSONFromAsset(name), DpGeneratorSubCategoryResponse::class.java)
    }

    private fun getSubCategoryList() {
        startLoading()
//        val call: Call<DpGeneratorSubCategoryResponse> =
//            RetrofitClient3.instance!!.myApi.getSubCategoryList(AppUrl().dpGeneratorSubcategoryListENDURL() + categoryList[tabSelect].id)
//
//        Log.e("DpGeneratorResponse.001", "getSubCategoryList===>https://apidpframe.appomania.co.in/api/${AppUrl().dpGeneratorSubcategoryListENDURL() + categoryList[tabSelect].id}<===")
//
//        call.enqueue(object : Callback<DpGeneratorSubCategoryResponse> {
//            override fun onResponse(
//                call: Call<DpGeneratorSubCategoryResponse>,
//                response: Response<DpGeneratorSubCategoryResponse>
//            ) {
                val response = parseJSON("subcategory_${categoryList[tabSelect].id}")
                val list: DpGeneratorSubCategoryResponse = response
                if (categoryList[tabSelect].subList.isNullOrEmpty())
                    categoryList[tabSelect].subList = ArrayList()
                else
                    categoryList[tabSelect].subList.clear()
                categoryList[tabSelect].subList.addAll(list)
                finishLoading()
                setSubCategoryAdapter()
//            }
//            override fun onFailure(call: Call<DpGeneratorSubCategoryResponse>, t: Throwable) {
//                finishLoading()
//                Toast.makeText(
//                    this@DPCreationActivity,
//                    getString(R.string.download_fail_msg),
//                    Toast.LENGTH_SHORT
//                ).show()
//            }
//        })
    }
}