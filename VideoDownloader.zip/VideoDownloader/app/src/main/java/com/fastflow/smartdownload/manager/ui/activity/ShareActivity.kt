package com.fastflow.smartdownload.manager.ui.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.ui.activity.option.BrowserDownloadActivity
import com.fastflow.smartdownload.manager.ui.activity.option.InstagramActivity
import com.fastflow.smartdownload.manager.utils.Constant
import com.fastflow.smartdownload.manager.utils.MyApplication
import com.fastflow.smartdownload.manager.utils.Preferences

class ShareActivity : BaseActivity() {

    lateinit var preferences: Preferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MyApplication.disabledOpenAds()
        setContentView(R.layout.activity_share)

        preferences = Preferences(this)
        val action = intent.action
        if (action == Intent.ACTION_SEND) {
            shareOpen()
        } else
            appNotSupport()
    }

    private fun shareOpen() {
        val action = intent.action
        val type = intent.type
        Log.e("shareOpen", "action===>> $action  type===>> $type")
        if (Intent.ACTION_SEND == action && type != null) {
            val url = intent.getStringExtra(Intent.EXTRA_TEXT)
            Log.e("", "ShareActivity Link:::url  $url")
            if (type.startsWith("text/") && url != null) {
                if (url.isValidUrl()) {
                    if (url.contains("instagram.com")) {
                        if ((url.contains("www.instagram.com/p/") || url.contains("www.instagram.com/reel/")) && preferences.isLoginInstagram()) {
                            // link to paste screen
                            openShareToScreen(
                                Intent(
                                    this,
                                    InstagramActivity::class.java
                                ).putExtra(Constant.EXTRA_TYPE, Constant.DOWNLOAD_INSTAGRAM)
                                    .putExtra(Constant.EXTRA_IS_OPEN_TO_SHARE, true)
                                    .putExtra(Constant.PUT_KEY_URL, url)
                            )

                        } else {
                            // insta Browser
                            openShareToScreen(
                                Intent(
                                    this,
                                    BrowserDownloadActivity::class.java
                                ).putExtra(
                                    Constant.PUT_KEY_URL,
                                    url
                                )
                                    .putExtra(
                                        Constant.EXTRA_TYPE, Constant.TYPE_Insta
                                    )
                            )
                        }
                    } else if (url.contains("facebook") || url.contains("facebook.com") || url.contains(
                            "fb.watch"
                        )
                    ) {
                        // fb Browser
                        openShareToScreen(
                            Intent(
                                this,
                                BrowserDownloadActivity::class.java
                            ).putExtra(
                                Constant.PUT_KEY_URL,
                                url
                            )
                                .putExtra(
                                    Constant.EXTRA_TYPE, Constant.TYPE_FB
                                )
                        )
                    } else if (url.contains("twitter.com")) {
                        // twitter
                        openShareToScreen(
                            Intent(
                                this,
                                InstagramActivity::class.java
                            ).putExtra(Constant.EXTRA_TYPE, Constant.DOWNLOAD_TWITTER)
                                .putExtra(Constant.EXTRA_IS_OPEN_TO_SHARE, true)
                                .putExtra(Constant.PUT_KEY_URL, url)
                        )
                    } else {
                        // open default Browser
                        openShareToScreen(
                            Intent(
                                this,
                                BrowserActivity::class.java
                            ).putExtra(Constant.PUT_KEY_URL, url)
                        )
                    }
                } else
                    appNotSupport()
            } else
                appNotSupport()
        } else
            appNotSupport()
    }

    private fun openShareToScreen(intent: Intent) {
        if (!MyApplication.isOpenHomeScreen) {
            val intents = arrayOf(Intent(this, HomeActivity::class.java), intent)
            startActivities(intents)
        } else
            startActivity(intent)
        finish()
    }

    private fun appNotSupport() {
        Toast.makeText(this, "This url not support!!", Toast.LENGTH_SHORT).show()
        finish()
    }

    fun String.isValidUrl(): Boolean = Patterns.WEB_URL.matcher(this).matches()
}