package com.fastflow.smartdownload.manager.utils

import com.fastflow.smartdownload.manager.ui.data.DataModel
import com.fastflow.smartdownload.manager.ui.data.DpGeneratorCategoryList
import com.fastflow.smartdownload.manager.ui.data.UserList

object Constant {
    const val DELETE_REQUEST_CODE: Int = 1011

    val PREF_NAME: String = "AllVideoDownloader"
    val PREF_KEY_START: String = "key_star"
    val PREF_KEY_RATE: String = "key_RATE"
    val PREF_KEY_RATE_COUNTER: String = "key_rate_Count"
    val PREF_KEY_LOGIN_INSTA: String = "key_is_login_insta"
    val PREF_KEY_INSTA_USER_ID: String = "key_is_insta_UserID"
    val PREF_KEY_INSTA_TOKEN: String = "key_is_insta_token"
    val PREF_KEY_INSTA_SESSION_ID: String = "key_is_insta_sessionID"
    val PREF_KEY_INSTA_COOKIES: String = "key_is_insta_Cookies"
    val PREF_KEY_INSTA_INTRO: String = "key_is_insta_intro"
    val PREF_KEY_FB_INTRO: String = "key_is_Fb_intro"

    val PREF_KEY_LOGIN_FB: String = "key_is_login_fb"
    val PREF_KEY_FB_USER_ID: String = "key_is_fb_UserID"
    val PREF_KEY_FB_TOKEN: String = "key_is_fb_token"
    val PREF_KEY_FB_SESSION_ID: String = "key_is_fb_sessionID"
    val PREF_KEY_FB_COOKIES: String = "key_is_fb_Cookies"

    val PUT_KEY_HASHTAG_TITLE: String = "key_put_hashtag_title"
    val PREF_KEY_THEME: String = "key_is_theme"
    val PREF_WHATSAPP_URI = "key_is_whatsapp_uri"
    val PUT_KEY_URL = "key_put_url"
    val PUT_KEY_TAG_STRING = "key_put_tag_string"
    val PUT_KEY_SUB_TITLE = "key_put_sub_title"
    val PUT_KEY_POSTION = "key_put_position"
    val PUT_KEY_EVENT = "key_put_event"
    val VALUE_KEY_STATUS = "key_value_status"
    val VALUE_KEY_DOWNLOAD = "key_value_download"
    var dataArrayList :ArrayList<DataModel> = ArrayList()
    var profileData :ArrayList<UserList> = ArrayList()
    var DPGeneratorData :ArrayList<DpGeneratorCategoryList> = ArrayList()

    const val HTTP = "http://"
    const val HTTPS = "https://"


//    val TYPE_VIDEO: Int = 1
//    val URL_Insta: String = "https://www.instagram.com/login/"
//    val URL_Insta: String = "https://www.instagram.com/"
    val URL_Insta: String = "https://www.instagram.com/accounts/login/"
    val URL_FB: String = "https://www.facebook.com/"
    val TYPE_Insta: String = "Insta_"
    val TYPE_Story: String = "Story_"
    val TYPE_FB: String = "FB"
    val TYPE_TWITTER: String = "Twitter"
    val TYPE_DP_DOWNLOAD: String = "DP_download"

    val FOLDER_INSTAGRAM: String = "Insta Saver"
    val FOLDER_DP_DOWNLOADER: String = "DP Downloader"
    val FOLDER_DP_CREATE: String = "DP Create"
    val FOLDER_FACEBOOK: String = "Facebook Saver"
    val FOLDER_TWITTER: String = "Twitter Saver"
    val FOLDER_WHATSAPP: String = "WhatsApp"


    val TYPE_VIDEO: Int = 2
    val TYPE_IMAGE: Int = 1
    val TYPE_POST_MULTIPLE: Int = 8

    val DOWNLOAD_INSTAGRAM: String = "Instagram"
    val DOWNLOAD_WHATSAPP: String = "whatsapp"
    val DOWNLOAD_FACEBOOK: String = "Facebook"
    val DOWNLOAD_TWITTER: String = "Twitter"
    val DOWNLOAD_DP_DOWNLOADER: String = "DP Downloader"
    val DOWNLOAD_DP_CREATE: String = "DP Create"


    val EXTRA_USERNAME: String = "username"
    val EXTRA_TYPE: String = "type"
    val EXTRA_IS_OPEN_TO_SHARE: String = "isOpenFromShare"
    val EXTRA_POS: String = "DPCreator_pos"
    val EXTRA_CHILD_POS: String = "DPCreator_childPos"
    val EXTRA_SELECT_IMAGE: String = "image_select"
    val EXTRA_IS_OPEN_FROM_SPLASH: String = "extra_is_open_from_splash"
    val EXTRA_IS_OPEN_FROM_BROWSER: String = "extra_is_open_from_Browser"

}