package com.fastflow.smartdownload.manager.browser.helpers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class HelpFuncs {
    public static Gson Gson() {
        return new GsonBuilder().serializeNulls().create();
    }
}
