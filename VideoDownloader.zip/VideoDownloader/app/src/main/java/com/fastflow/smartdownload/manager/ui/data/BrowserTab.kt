package com.fastflow.smartdownload.manager.ui.data

data class BrowserTab(var tabTitle:String)
