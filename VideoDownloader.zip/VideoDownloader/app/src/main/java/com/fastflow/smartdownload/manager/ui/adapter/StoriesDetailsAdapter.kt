package com.fastflow.smartdownload.manager.ui.adapter

import android.content.Context
import android.content.Intent
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.databinding.DeleteDialogLayoutBinding
import com.fastflow.smartdownload.manager.databinding.ItemStoriesDetailsBinding
import com.fastflow.smartdownload.manager.ui.activity.FileFullViewActivity
import com.fastflow.smartdownload.manager.ui.data.DataModel
import com.fastflow.smartdownload.manager.ui.data.StoryItem
import com.fastflow.smartdownload.manager.utils.Constant
import com.fastflow.smartdownload.manager.utils.Utils
import java.io.File

class StoriesDetailsAdapter(
    var context: Context,
    var categoryList: ArrayList<StoryItem>,
    val deleteListener: (pos: Int) -> Unit,
    val downloadListener: (pos: Int) -> Unit,
) :
    RecyclerView.Adapter<StoriesDetailsAdapter.ViewHolder>() {


    val folder = File(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath
                + File.separator + context.getString(R.string.app_name)
                + File.separator + Constant.FOLDER_INSTAGRAM
    )


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemStoriesDetailsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return categoryList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = categoryList[position]
        val url: String = when (data.mediaType) {
            Constant.TYPE_VIDEO ->
                data.videoVersions[0].url

            Constant.TYPE_IMAGE ->
                data.imageVersions2.candidates[0].url

            else -> ""
        }

        if (data.mediaType == Constant.TYPE_VIDEO)
            holder.binding.ivPlay.visibility = View.VISIBLE
        else
            holder.binding.ivPlay.visibility = View.GONE


        Glide.with(context)
            .load(url)
            .into(holder.binding.imageDownload)

        val fileN =
            Constant.TYPE_Story + data.id + if (data.mediaType == Constant.TYPE_IMAGE) ".png" else ".mp4"
        val file = File(folder, fileN)
        if (file.exists()) {
            holder.binding.ivShare.visibility = View.VISIBLE
            holder.binding.ivDelete.visibility = View.VISIBLE
            holder.binding.ivDownload.visibility = View.GONE
        } else {
            holder.binding.ivShare.visibility = View.GONE
            holder.binding.ivDelete.visibility = View.GONE
            holder.binding.ivDownload.visibility = View.VISIBLE
        }


        holder.binding.ivDownload.setOnClickListener {
            downloadListener(position)
        }

        holder.binding.ivDelete.setOnClickListener {
            val builder = AlertDialog.Builder(context, R.style.CustomAlertDialog).create()
            val deleteDialogLayoutBinding: DeleteDialogLayoutBinding =
                DeleteDialogLayoutBinding.inflate(LayoutInflater.from(context))
            builder.setView(deleteDialogLayoutBinding.root)
            deleteDialogLayoutBinding.tvNo.setOnClickListener {
                builder.dismiss()
            }

            deleteDialogLayoutBinding.tvYes.setOnClickListener {
                builder.dismiss()
                deleteListener(position)
            }
            builder.show()
        }
        holder.binding.ivShare.setOnClickListener {
            Utils.fileShare(context, file.path)
        }

        holder.itemView.setOnClickListener {
            if (file.exists()) {
                val statusList: ArrayList<DataModel> = ArrayList()
                statusList.add(DataModel(file.path))

                Constant.dataArrayList.clear()
                Constant.dataArrayList.addAll(statusList)
                context.startActivity(
                    Intent(context, FileFullViewActivity::class.java).putExtra(
                        Constant.PUT_KEY_POSTION, position
                    ).putExtra(
                        Constant.PUT_KEY_EVENT,
                        Constant.VALUE_KEY_DOWNLOAD
                    )
                )
            }
        }

    }

    class ViewHolder(var binding: ItemStoriesDetailsBinding) :
        RecyclerView.ViewHolder(binding.root) {


    }
}