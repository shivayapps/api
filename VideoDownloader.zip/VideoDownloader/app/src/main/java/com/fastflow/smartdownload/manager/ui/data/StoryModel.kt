package com.fastflow.smartdownload.manager.ui.data

import java.io.Serializable

data class StoryModel(val tray: List<StoryTray>): Serializable
