package com.fastflow.smartdownload.manager.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.fastflow.smartdownload.manager.databinding.ItemProfileRingBinding
import com.fastflow.smartdownload.manager.ui.data.UserList

class ProfileListAdapter(
    var context: Context,
    var categoryList: ArrayList<UserList>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<ProfileListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemProfileRingBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return categoryList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.txtUserName.text = categoryList[position].user.username
        holder.binding.txtFullName.text = categoryList[position].user.fullName
        Glide.with(context)
            .load(categoryList[position].user.profilePicUrl)
            .into(holder.binding.imgProfile)

        holder.binding.root.setOnClickListener {
            clickListener(position)
        }
    }

    class ViewHolder(var binding: ItemProfileRingBinding) :
        RecyclerView.ViewHolder(binding.root) {

    }
}