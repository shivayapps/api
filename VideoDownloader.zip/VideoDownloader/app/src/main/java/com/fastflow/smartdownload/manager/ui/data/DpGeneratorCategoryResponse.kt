package com.fastflow.smartdownload.manager.ui.data

class DpGeneratorCategoryResponse : ArrayList<DpGeneratorCategoryList>()