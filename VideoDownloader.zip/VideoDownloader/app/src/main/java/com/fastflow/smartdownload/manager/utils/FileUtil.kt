package com.fastflow.smartdownload.manager.utils

import android.app.Activity
import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Build.VERSION.SDK_INT
import android.os.Environment
import android.os.storage.StorageManager
import android.provider.BaseColumns
import android.provider.MediaStore
import androidx.annotation.RequiresApi
import androidx.documentfile.provider.DocumentFile
import androidx.fragment.app.Fragment
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.nio.channels.FileChannel

object FileUtil {

    fun saveImage(folder:String,img:String,image: Bitmap): String? {
        var savedImagePath: String? = null
//        val imageFileName = "JPEG_" + "FILE_NAME" + ".jpg"
        val imageFileName = img
        val storageDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                .toString() + "/"+folder
        )
        var success = true
        if (!storageDir.exists()) {
            success = storageDir.mkdirs()
        }
        if (success) {
            val imageFile = File(storageDir, imageFileName)
            savedImagePath = imageFile.getAbsolutePath()
            try {
                val fOut: OutputStream = FileOutputStream(imageFile)
                image.compress(Bitmap.CompressFormat.JPEG, 100, fOut)
                fOut.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // Add the image to the system gallery
//            galleryAddPic(savedImagePath)
        }
        return savedImagePath
    }

    fun getExternalStoragePublicDirectory(context: Context, type: String?): String {
        var type = type
        type = type ?: ""
        if (SDK_INT >= Build.VERSION_CODES.R) {
            val manager = context.getSystemService(Context.STORAGE_SERVICE) as StorageManager
            val volumes = manager.storageVolumes
            for (volume in volumes) {
                if (volume.isPrimary) return volume.directory!!.path + File.separator + type
            }
        }
        return Environment.getExternalStoragePublicDirectory(type).toString()
    }

    private fun getValidFile(path: String?, name: String, extension: String): String? {
        var path = path
        var num = 1
        if (path == null) {
            return "$name.$extension"
        }
        path = path + name.replace("[\\|\\\\\\?\\*<>\":\n]+".toRegex(), "_") + "." + extension
        var file = File(path)
        while (file.exists()) {
            path = file.parent + "/" + name + "(" + num++ + ")" + "." + extension
            file = File(path)
        }
        return path
    }

    fun copyFileData(context: Context, src: Uri?, dest: Uri) {
        try {
            val inChannel = (context.contentResolver.openInputStream(
                src!!
            ) as FileInputStream?)!!.channel
            val outChannel: FileChannel
            outChannel = try {
                FileOutputStream(
                    context.contentResolver.openFileDescriptor(dest, "w")!!.fileDescriptor
                ).channel
            } catch (e: FileNotFoundException) {
                FileOutputStream(dest.path).channel
            }
            inChannel.transferTo(0, inChannel.size(), outChannel)
            inChannel.close()
            outChannel.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    fun dataPathToNewUri(
        context: Context?,
        parentUri: Uri,
        fileName: String,
        mimeType: String?,
        exp: String
    ): Uri {
        val directory: DocumentFile?
        return try {
            directory = DocumentFile.fromTreeUri(context!!, parentUri)
            val file = directory!!.createFile(mimeType!!, fileName)
            file!!.uri
        } catch (e: IllegalArgumentException) {
            Uri.fromFile(File(getValidFile(parentUri.path + File.separator, fileName, exp)))
        } catch (e: NullPointerException) {
            Uri.fromFile(File(getValidFile(parentUri.path + File.separator, fileName, exp)))
        }
    }


    @RequiresApi(Build.VERSION_CODES.R)
    fun deleteWithoutManageExternalStorage(path: String, activity: Activity) {
//        val delete = File(path).delete()
//        Log.e("deleteWithoutManage","delete==>> $delete")
//        if (!delete) {
            val file11 = File(path)
            val ext1 = file11.name.substring(file11.name.lastIndexOf("."))
            val uri: Uri
            if (ext1 == ".mp4" || ext1 == ".webm") {
                uri = getContentUriId1(Uri.parse(path), activity)
            } else if (ext1 == ".png" || ext1 == ".jpg" || ext1 == ".jpeg") {
                uri = getContentUriId(Uri.parse(path), activity)
            } else {
                uri = getContentUriIdAudio(Uri.parse(path), activity)
            }
            deleteAPI301(uri, activity)
//        }

    }

    @RequiresApi(Build.VERSION_CODES.R)
    fun deleteWithoutManageExternalStorage(path: String, activity: Fragment) {
//        val delete = File(path).delete()
//        Log.e("deleteWithoutManage","delete==>> $delete")
//        if (!delete) {
        val file11 = File(path)
        val ext1 = file11.name.substring(file11.name.lastIndexOf("."))
        val uri: Uri
        if (ext1 == ".mp4" || ext1 == ".webm") {
            uri = getContentUriId1(Uri.parse(path), activity.requireActivity())
        } else if (ext1 == ".png" || ext1 == ".jpg" || ext1 == ".jpeg") {
            uri = getContentUriId(Uri.parse(path), activity.requireActivity())
        } else {
            uri = getContentUriIdAudio(Uri.parse(path), activity.requireActivity())
        }
        deleteAPI3011(uri, activity)
//        }

    }


    @RequiresApi(api = Build.VERSION_CODES.R)
    private fun deleteAPI301(imageUri: Uri, activity: Activity) {
        val contentResolver: ContentResolver = activity.contentResolver
        // API 30
        val uriList: ArrayList<Uri> = ArrayList()
        uriList.add(imageUri)

//        Collections.addAll(uriList, imageUri)
        val pendingIntent = MediaStore.createDeleteRequest(contentResolver, uriList)

        try {
            activity.startIntentSenderForResult(
                pendingIntent.intentSender,
                Constant.DELETE_REQUEST_CODE,
                null,
                0,
                0,
                0,
                null
            )
        } catch (e: Exception) {
           e.printStackTrace()
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.R)
    private fun deleteAPI3011(imageUri: Uri, activity: Fragment) {
        val contentResolver: ContentResolver = activity.requireActivity().contentResolver
        // API 30
        val uriList: ArrayList<Uri> = ArrayList()
        uriList.add(imageUri)

//        Collections.addAll(uriList, imageUri)
        val pendingIntent = MediaStore.createDeleteRequest(contentResolver, uriList)

        try {
            activity.startIntentSenderForResult(
                pendingIntent.intentSender,
                Constant.DELETE_REQUEST_CODE,
                null,
                0,
                0,
                0,
                null
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private fun getContentUriIdAudio(imageUri: Uri, activity: Activity): Uri {
        val projections = arrayOf(MediaStore.MediaColumns._ID)
        val cursor: Cursor? = activity.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projections,
            MediaStore.MediaColumns.DATA + "=?", arrayOf(imageUri.path), null
        )
        var id: Long = 0
        if (cursor != null) {
            if (cursor.count > 0) {
                cursor.moveToFirst()
                id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID))
            }
        }
        cursor?.close()
        return Uri.withAppendedPath(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            id.toInt().toString()
        )
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun getContentUriId(imageUri: Uri, activity: Activity): Uri {
        val projections = arrayOf(MediaStore.Images.Media._ID)
        val cursor: Cursor? = activity.contentResolver.query(
//            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            MediaStore.Images.Media.getContentUri(
                MediaStore.VOLUME_EXTERNAL
            ),
            projections,
            MediaStore.Video.Media.DATA + "=?", arrayOf(imageUri.path), null
        )
        var id: Long = 0
        if (cursor != null) {
            if (cursor.count > 0) {
                cursor.moveToFirst()
                id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
            }
        }
        cursor?.close()
        return Uri.withAppendedPath(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            id.toInt().toString()
        )
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun getContentUriId1(imageUri: Uri, activity: Activity): Uri {
//        val projections = arrayOf(MediaStore.MediaColumns._ID)
        val projections = arrayOf( MediaStore.Video.Media._ID)
        val cursor: Cursor? = activity.contentResolver.query(
            MediaStore.Video.Media.getContentUri(
                MediaStore.VOLUME_EXTERNAL
            ),
//            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            projections,
//            MediaStore.MediaColumns.DATA + "=?", arrayOf(imageUri.path), null
            MediaStore.Video.Media.DATA + "=?", arrayOf(imageUri.path), null
        )
        var id: Long = 0
        if (cursor != null) {
            if (cursor.count > 0) {
                cursor.moveToFirst()
                id = cursor.getLong(cursor.getColumnIndexOrThrow( MediaStore.Video.Media._ID))
            }
        }
        cursor?.close()
        return Uri.withAppendedPath(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            id.toInt().toString()
        )
    }
}