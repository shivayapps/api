package com.fastflow.smartdownload.manager.ui.data

data class DataModel(var path: String = null ?: "", val date: Long = 0L)
