package com.fastflow.smartdownload.manager.ui.activity

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.Window
import androidx.activity.result.contract.ActivityResultContracts

import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.databinding.ActivityPermissionBinding
import com.fastflow.smartdownload.manager.databinding.DialogPermissionDeniedBinding
import com.fastflow.smartdownload.manager.permission.PermissionManager
import com.fastflow.smartdownload.manager.utils.Constant
import com.fastflow.smartdownload.manager.utils.MyApplication
import com.fastflow.smartdownload.manager.utils.Preferences
import com.fastflow.smartdownload.manager.utils.UtilsAd

class PermissionActivity : BaseActivity() {

    lateinit var binding: ActivityPermissionBinding
    lateinit var preferences: Preferences
    var isOpenFromSplash: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inti()
    }

    private fun startNextScreen() {
        if (isOpenFromSplash) {
            val intent = if (!preferences.isStar())
                Intent(this, StartActivity::class.java)
            else Intent(this, HomeActivity::class.java)
            startActivity(intent)
        } else
            setResult(RESULT_OK)
        finish()
    }

    private fun inti() {
        isOpenFromSplash = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, false)
        preferences = Preferences(this)


        binding.txtMsg.text =
            if (isOpenFromSplash) getString(R.string.notificationPermissionMsg) else getString(R.string.permissionMsg)
        binding.btnAllow.setOnClickListener {

            requestPermission()
        }
        if (!isOpenFromSplash)
            loadNativeAd()
    }

    private fun loadNativeAd() {
//        binding.frameNative.visibility = View.VISIBLE
//        NativeLoadWithShows(this).showNativeAdsShimmerEffects(this, binding.frameNative, 3)
//        NativeLoadWithShows(this).showNativeTopAlways(this, binding.frameNative)
//        UtilsAd.showNative(this,binding.frameNative)
    }

    override fun onDestroy() {
        super.onDestroy()
//        if (!isOpenFromSplash)
//            MyApplication.storageCommon?.nativeAdsPermission?.postValue(
//                null
//            )
    }

    override fun onPause() {
        super.onPause()
        MyApplication.disabledOpenAds()
    }

    override fun onResume() {
        Log.e("PermissionTag", "onResume")
        MyApplication.disabledOpenAds()
        super.onResume()
    }

    var permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            if (checkStoragePermissions())
                startNextScreen()
            else
                requestPermission()
        }

    private fun requestPermission() {
//        if (isPermissionOpen()) {
//            MyApplication.disabledOpenAds()
//        }
        val list: ArrayList<String> = ArrayList()
        if (isOpenFromSplash) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                list.add(android.Manifest.permission.POST_NOTIFICATIONS)
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                list.add(android.Manifest.permission.READ_MEDIA_IMAGES)
                list.add(android.Manifest.permission.READ_MEDIA_VIDEO)
            } else list.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }


        val REQUIRED_PERMISSIONS: Array<String>
        if (isOpenFromSplash) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                REQUIRED_PERMISSIONS = arrayOf<String>(
                    android.Manifest.permission.POST_NOTIFICATIONS
                )
            } else
                REQUIRED_PERMISSIONS = arrayOf<String>()
        } else {
            REQUIRED_PERMISSIONS = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                arrayOf<String>(
                    android.Manifest.permission.READ_MEDIA_IMAGES,
                    android.Manifest.permission.READ_MEDIA_VIDEO
                )
            } else {
                arrayOf<String>(
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
            }
        }
        MyApplication.disabledOpenAds()
        PermissionManager.doPermissionTask(
            this@PermissionActivity,
            object : PermissionManager.callBack {
                override fun doNext() {
//                    MyApp.isDialogOpen = false
                    startNextScreen()
                }

                override fun noPermission(hasAndroidPermissions: Boolean) {
//                    MyApp.isDialogOpen = false;
//                    Toast.makeText(
//                            this@PermissionActivity,
//                    getString(R.string.permission_denied_msg),
//                    Toast.LENGTH_SHORT
//                    ).show()
                }
            },
            REQUIRED_PERMISSIONS
        )

//        Dexter.withContext(this@PermissionActivity)
//            .withPermissions(
//                list
//            )
//            .withListener(object : MultiplePermissionsListener {
//                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
//                    report?.let {
//                        if (report.areAllPermissionsGranted()) {
//                            startNextScreen()
//                        } else if (report.isAnyPermissionPermanentlyDenied) {
//                            showPermissionDeniedDialog()
//                        } else {
//                            if (isOpenFromSplash)
//                                startNextScreen()
//                            else
//                                Toast.makeText(
//                                    this@PermissionActivity,
//                                    getString(R.string.permission_denied_msg),
//                                    Toast.LENGTH_SHORT
//                                ).show()
//                        }
//                    }
//                }
//
//                override fun onPermissionRationaleShouldBeShown(
//                    permissions: MutableList<PermissionRequest>?,
//                    token: PermissionToken?
//                ) {
//                    token?.continuePermissionRequest()
//                }
//            }).check()
    }

    private fun showPermissionDeniedDialog() {
        val dialogBinding = DialogPermissionDeniedBinding.inflate(layoutInflater)
        val dialog = Dialog(this, R.style.Theme_Dialog)
        dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setContentView(dialogBinding.root)
        dialog.show()

        dialogBinding.btnOK.setOnClickListener {
//            if (isPermissionOpen()) {
//                MyApplication.disabledOpenAds()
//            }
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            val uri = Uri.fromParts("package", packageName, null)
            intent.data = uri
            permissionLauncher.launch(intent)
        }

        dialogBinding.btnCancel.setOnClickListener {
            dialog.dismiss()
        }
    }

}