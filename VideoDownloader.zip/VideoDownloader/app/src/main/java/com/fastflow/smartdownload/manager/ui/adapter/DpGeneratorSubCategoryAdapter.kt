package com.fastflow.smartdownload.manager.ui.adapter

import android.content.Context
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator
import com.nostra13.universalimageloader.core.DisplayImageOptions
import com.nostra13.universalimageloader.core.ImageLoader
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration
import com.nostra13.universalimageloader.core.assist.ImageScaleType
import com.nostra13.universalimageloader.core.assist.QueueProcessingType
import com.fastflow.smartdownload.manager.databinding.ItemDpGeneratorSubCategoryBinding
import com.fastflow.smartdownload.manager.ui.data.DpGeneratorSubCategoryItem

class DpGeneratorSubCategoryAdapter(
    var context: Context,
    var subCategoryList: ArrayList<DpGeneratorSubCategoryItem>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<DpGeneratorSubCategoryAdapter.ViewHolder>() {
    var imageDp = ""

    init {
        val defaultOptions = DisplayImageOptions.Builder().cacheInMemory(true).cacheOnDisc(true)
            .showImageOnLoading(17301633).showImageForEmptyUri(17301543).showImageOnFail(17301624)
            .considerExifParams(true).bitmapConfig(
                Bitmap.Config.RGB_565
            ).imageScaleType(ImageScaleType.EXACTLY_STRETCHED).build()
        ImageLoader.getInstance().init(
            ImageLoaderConfiguration.Builder(context).threadPriority(3)
                .denyCacheImageMultipleSizesInMemory()
                .discCacheFileNameGenerator(Md5FileNameGenerator())
                .tasksProcessingOrder(QueueProcessingType.LIFO).defaultDisplayImageOptions(null)
                .build()
        )

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemDpGeneratorSubCategoryBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return subCategoryList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        holder.binding.progressBar.visibility = View.VISIBLE
//        Log.e("SubCategoryAdapter.001", "getSubCategory===>${subCategoryList[position].img}<===")
        ImageLoader.getInstance()
            .displayImage(
                "assets://png/${subCategoryList[position].img}",
                holder.binding.icon
            )

//        Glide.with(context)
//            .load(subCategoryList[position].img)
//            .listener(object : RequestListener<Drawable> {
//                override fun onLoadFailed(
//                    e: GlideException?,
//                    model: Any?,
//                    target: Target<Drawable>?,
//                    isFirstResource: Boolean
//                ): Boolean {
//                    return false
//                }
//
//                override fun onResourceReady(
//                    resource: Drawable?,
//                    model: Any?,
//                    target: Target<Drawable>?,
//                    dataSource: DataSource?,
//                    isFirstResource: Boolean
//                ): Boolean {
//                    holder.binding.progressBar.visibility = View.GONE
//                    return false
//                }
//            })
//            .into(holder.binding.icon)

        if (imageDp.isNotEmpty()) {
            holder.binding.userProfile.visibility = View.VISIBLE
            Glide.with(context)
                .load(imageDp)
                .into(holder.binding.userProfile)
        } else
            holder.binding.userProfile.visibility = View.GONE

        holder.binding.root.setOnClickListener {
            clickListener(position)
        }
    }

    fun setImageSelect(imageSelect: String) {
        imageDp = imageSelect
        notifyDataSetChanged()
    }

    class ViewHolder(var binding: ItemDpGeneratorSubCategoryBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }
}