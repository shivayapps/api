package com.fastflow.smartdownload.manager.browser.helpers;

public class AnyDownloadModel {
    private AnyFileType anyFileType;
    private String downloadUrl;
    private String fileExtention;
    private String fileTitle;
    private String thumbUrl;

    public enum AnyFileType {
        IMAGE,
        VIDEO
    }

    public AnyDownloadModel(AnyFileType anyFileType, String str, String str2, String str3, String str4) {
        AnyFileType anyFileType2 = AnyFileType.IMAGE;
        this.anyFileType = anyFileType;
        this.downloadUrl = str;
        this.thumbUrl = str2;
        this.fileTitle = str3;
        this.fileExtention = str4;
    }

    public AnyFileType getAnyFileType() {
        return this.anyFileType;
    }

    public void setAnyFileType(AnyFileType anyFileType) {
        this.anyFileType = anyFileType;
    }

    public String getDownloadUrl() {
        return this.downloadUrl;
    }

    public void setDownloadUrl(String str) {
        this.downloadUrl = str;
    }

    public String getThumbUrl() {
        return this.thumbUrl;
    }

    public void setThumbUrl(String str) {
        this.thumbUrl = str;
    }

    public String getFileTitle() {
        return this.fileTitle;
    }

    public void setFileTitle(String str) {
        this.fileTitle = str;
    }

    public String getFileExtention() {
        return this.fileExtention;
    }

    public void setFileExtention(String str) {
        this.fileExtention = str;
    }
}
