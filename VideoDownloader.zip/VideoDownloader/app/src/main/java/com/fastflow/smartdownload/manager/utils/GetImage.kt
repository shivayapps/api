package com.fastflow.smartdownload.manager.utils

import android.content.Context
import android.provider.MediaStore
import android.util.Log

class GetImage(val context: Context) {

    fun getPhotoPath(): HashMap<String, ArrayList<String>> {
        val hashMap: HashMap<String, ArrayList<String>> = HashMap()
        val projection = arrayOf(
            MediaStore.Images.Media.DATA,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
        )
        val orderBy = MediaStore.Images.ImageColumns.DATE_ADDED  + " DESC"
        val cursor = context.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projection,
            null,
            null,
            orderBy
        )
        val all = "All Images"

        if (cursor != null && cursor.moveToFirst()) {
//            this.count = imagecursor.getCount();
//            for (int i = 0; i < this.count; i++) {
            do {
                val path =
                    cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                val folderName =
                    cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME))

                Log.e("GetImage","folderName==>> $folderName  path==>> $path")
                val allList: ArrayList<String> = ArrayList()
                if (hashMap.containsKey(all)) {
                    val list = hashMap[all]
                    if (!list.isNullOrEmpty())
                        allList.addAll(list)
                }
                allList.add(path)
                hashMap[all] = allList

                if (folderName != null) {
                    val imageList: ArrayList<String> = ArrayList()
                    val list = hashMap[folderName]
                    if (!list.isNullOrEmpty())
                        imageList.addAll(list)
                    imageList.add(path)
                    hashMap[folderName] = imageList
                }

            } while (cursor.moveToNext())
        }
        cursor!!.close()
        return hashMap
    }
}