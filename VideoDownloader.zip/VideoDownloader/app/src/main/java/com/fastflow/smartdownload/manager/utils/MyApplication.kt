package com.fastflow.smartdownload.manager.utils

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.multidex.MultiDexApplication
import com.adconfig.AdsConfig
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.WelcomeBackActivity
//import com.ads.module.open.AdconfigApplication
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.SplashActivity
import com.fastflow.smartdownload.manager.browser.event.DownloadCompleteEvent
import com.fastflow.smartdownload.manager.browser.event.ProgressUpdateDownloadEvent
import com.fastflow.smartdownload.manager.ui.activity.PermissionActivity
import com.fastflow.smartdownload.manager.ui.data.DownloadData
import com.fastflow.smartdownload.manager.ui.data.FamilyAppsModel
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.greenrobot.eventbus.EventBus
import org.json.JSONObject

class MyApplication : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {

    override fun onCreate() {
        super.onCreate()
        myapplication = this
        downloadList = ArrayList()
        isOpenHomeScreen = false
        isAppIsRunning = false

        setupRemoteConfig()
//        MobileAds.initialize(this) { }
//        AudienceNetworkAds.initialize(this);

        val AdmobAppOpenId = getString(R.string.open_all)

        AdsConfig.builder()
            .setTestDeviceId("43D54D26FD5DBC346211511E0DFD64F9")
            .setAdmobAppOpenId(AdmobAppOpenId)
            .build(this)

        setAppLifecycleListener(this)
        initMobileAds()
        isThemeChange = false

        context = this
    }

    private fun setupRemoteConfig() {
        val firebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
        val configSettings = FirebaseRemoteConfigSettings.Builder().setFetchTimeoutInSeconds(2000)
            .setMinimumFetchIntervalInSeconds(0).build()
        firebaseRemoteConfig.setConfigSettingsAsync(configSettings)


        firebaseRemoteConfig.fetchAndActivate().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                try {
                    //familyApps
//                    val isAdsEnableValue = firebaseRemoteConfig.getBoolean("isAdsEnable")
//                    Log.e("fetchFamilyApps", "isAdsEnableValue:$isAdsEnableValue")
//                    isAdsEnable = isAdsEnableValue
                } catch (e: Exception) {
                    Log.d("fetchFamilyApps", "Exception:${e.message}")
                } finally {

                }
            } else {
                Log.d("fetchFamilyApps", "Failed:${task.exception}")
            }
        }

    }


    companion object {
        var isOpenAdHide = false
        var downloadList: ArrayList<DownloadData> = ArrayList()
        var downloadingStar = false
        var isAppIsRunning: Boolean = false
        lateinit var myapplication: MyApplication
        var context: Context? = null
        var isOpenHomeScreen = false
        var isAdsEnable = true

        var isThemeChange: Boolean = false

        fun disabledOpenAds() {
            AdsConfig.isSystemDialogOpen = true
//        AdconfigApplication.disabledOpenAds()
            isOpenAdHide = true
//        Log.e("hello123456789", "${isOpenAdHide} Disebled Ads")

        }

        fun addDownloadFiles(downloadData: DownloadData) {
            downloadList.add(downloadData)
            if (!downloadingStar)
                startDownload()
        }

        private fun startDownload() {
            downloadingStar = true
            val downloadManager = DownloadManager(myapplication)
            val filesList: ArrayList<String> = ArrayList()
            Observable.fromCallable {
                var i = 0
                while (i < downloadList.size) {
                    var downloadData = downloadList[i]
                    val path = downloadManager.downloadFile(
                        downloadData.url,
                        downloadData.openType,
                        downloadData.posterId,
                        downloadData.fileType,
                        progressUpdateListener = {
                            downloadData.progress = it
                            EventBus.getDefault().post(ProgressUpdateDownloadEvent(downloadData))
                        })
                    if (path.isNotEmpty()) {
                        filesList.add(path)
                        EventBus.getDefault().post(DownloadCompleteEvent(downloadData))
                    }
                    i++
                }
                return@fromCallable ""
            }.subscribeOn(Schedulers.io())
                .doOnError { throwable: Throwable? ->
                    downloadingStar = false
                }
                .subscribe { result: String? ->
                    downloadingStar = false
                    downloadList.clear()
                }
        }
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (fCurrentActivity is SplashActivity) {
            return false
        } else if (fCurrentActivity is PermissionActivity) {
            return false
        } else if (AdsConfig.isSystemDialogOpen) {
            AdsConfig.isSystemDialogOpen = false
            return false
        }
//        return true
        return isAdsEnable
    }


    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
                if (OpenAdHelper.isAdAvailable()) {
                    val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
                    intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
                    fCurrentActivity.startActivity(intent)
                }
            }
    }

    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {

    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {

    }

}