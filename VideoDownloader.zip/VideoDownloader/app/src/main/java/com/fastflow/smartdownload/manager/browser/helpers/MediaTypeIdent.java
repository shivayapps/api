package com.fastflow.smartdownload.manager.browser.helpers;

public enum MediaTypeIdent {
    VIDEO,
    AUDIO,
    IMAGE
}
