package com.fastflow.smartdownload.manager.browser.event

data class DownloadDeleteEvent(var deletePath: String, var isOpenType: Int)
