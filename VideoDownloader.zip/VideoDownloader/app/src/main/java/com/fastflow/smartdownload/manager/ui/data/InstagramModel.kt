package com.fastflow.smartdownload.manager.ui.data

data class InstagramModel(
    val items: ArrayList<Item> = ArrayList(),
    val num_results: Int
)