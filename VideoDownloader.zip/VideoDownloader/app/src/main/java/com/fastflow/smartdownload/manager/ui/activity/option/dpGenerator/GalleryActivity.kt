package com.fastflow.smartdownload.manager.ui.activity.option.dpGenerator

import android.content.Intent
import android.os.Bundle
import android.view.View
import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.databinding.ActivityGalleryBinding
import com.fastflow.smartdownload.manager.ui.activity.BaseActivity
import com.fastflow.smartdownload.manager.ui.adapter.AlbumAdapter
import com.fastflow.smartdownload.manager.ui.adapter.ImageAdapter
import com.fastflow.smartdownload.manager.utils.Constant
import com.fastflow.smartdownload.manager.utils.GetImage
import java.util.concurrent.Executors

class GalleryActivity : BaseActivity() {

    lateinit var binding: ActivityGalleryBinding
    private var imageList: HashMap<String, ArrayList<String>> = HashMap()
    var albumAdapter: AlbumAdapter? = null
    var albumSelect = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGalleryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        binding.loutToolbar.txtTitle.text = getString(R.string.select_Photos)
        binding.loutToolbar.ivRight.visibility = View.GONE
        getImageList()
        intListener()
    }

    private fun intListener() {
        binding.loutToolbar.icBack.setOnClickListener { onBackPressed() }

    }

    private fun setImageAlbumAdapter() {
        albumAdapter = AlbumAdapter(this, imageList, clickListener = {
            albumSelect = it
            setImageList()
        })
        binding.rvAlbum.adapter = albumAdapter
    }

    private fun setImageList() {
        val keyByIndex = imageList.keys.elementAt(albumSelect)
        val list = imageList.getValue(keyByIndex)
        val imageAdapter = ImageAdapter(this, list, clickListener = {
            setResult(RESULT_OK, Intent().putExtra(Constant.EXTRA_SELECT_IMAGE,list[it]))
            finish()
        })
        binding.recyclerView.adapter = imageAdapter
    }

    private fun getImageList() {
        binding.loutLoading.visibility = View.VISIBLE
        val service22 = Executors.newSingleThreadExecutor()
        service22.execute {
            imageList = GetImage(this).getPhotoPath()
            runOnUiThread {
                binding.loutLoading.visibility = View.GONE
                if (imageList.isEmpty()) {
                    binding.recyclerView.visibility = View.GONE
                    binding.rvAlbum.visibility = View.GONE
                    binding.divider.visibility = View.GONE
                    binding.tvNoData.visibility = View.VISIBLE
                } else {
                    binding.recyclerView.visibility = View.VISIBLE
                    binding.rvAlbum.visibility = View.VISIBLE
                    binding.divider.visibility = View.VISIBLE
                    binding.tvNoData.visibility = View.GONE
                    setImageAlbumAdapter()
                    setImageList()
                }
            }
        }
    }
}