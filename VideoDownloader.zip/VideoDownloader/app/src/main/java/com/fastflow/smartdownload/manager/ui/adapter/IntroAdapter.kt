package com.fastflow.smartdownload.manager.ui.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.fastflow.smartdownload.manager.databinding.ItemIntroBinding

class IntroAdapter(
    val context: Context,
    val fileList: ArrayList<Drawable?>,
) :
    RecyclerView.Adapter<IntroAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemIntroBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        Glide.with(context)
            .load(fileList[position])
            .into(holder.binding.image)

    }

    override fun getItemCount(): Int {
        return fileList.size
    }

    class ViewHolder(val binding: ItemIntroBinding) : RecyclerView.ViewHolder(binding.root)
}