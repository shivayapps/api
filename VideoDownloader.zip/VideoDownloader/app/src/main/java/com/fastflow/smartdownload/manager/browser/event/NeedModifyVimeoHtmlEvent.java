package com.fastflow.smartdownload.manager.browser.event;

public class NeedModifyVimeoHtmlEvent {
}
