package com.fastflow.smartdownload.manager.ui.activity.option

import android.os.Bundle
import androidx.fragment.app.Fragment
import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.databinding.ActivityDownloadBinding
import com.fastflow.smartdownload.manager.ui.activity.BaseActivity
import com.fastflow.smartdownload.manager.ui.fragment.DownloadFragment
import com.fastflow.smartdownload.manager.utils.Constant

class DownloadActivity : BaseActivity() {

    lateinit var binding: ActivityDownloadBinding
    var openType = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDownloadBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        openType = intent.getStringExtra(Constant.EXTRA_TYPE)!!
        binding.loutToolbar.txtTitle.text = "Download"

        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }

        val downloadFragment = DownloadFragment.newInstance(this,
            openType,
            true
        )
        loadFragment(downloadFragment)
    }

    private fun loadFragment(fragment: Fragment) {
        val fm = this.supportFragmentManager
        val fragmentTransaction = fm.beginTransaction()
        fragmentTransaction.replace(R.id.frame_download, fragment)
        fragmentTransaction.commit()
    }
}