package com.fastflow.smartdownload.manager.ui.data

data class Item(
    val has_audio: Boolean,
    val id: String,
    val media_type: Int,
    val number_of_qualities: Int,
    val product_type: String,
    val video_duration: Double,
    val video_versions: List<VideoVersion>,
    val image_versions2: ImageVersions,
    val carousel_media_count: Long,
    val carousel_media: List<CarouselMedia>,
    val carousel_media_ids: List<Long>,
)