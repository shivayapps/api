package com.fastflow.smartdownload.manager.ui.activity.option

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.Window
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.databinding.ActivityPreviewBinding
import com.fastflow.smartdownload.manager.databinding.DialogDownloadBinding
import com.fastflow.smartdownload.manager.databinding.DialogLoaderBinding
import com.fastflow.smartdownload.manager.networkmanager.ApiManager
import com.fastflow.smartdownload.manager.ui.activity.BaseActivity
import com.fastflow.smartdownload.manager.ui.activity.PermissionActivity
import com.fastflow.smartdownload.manager.ui.data.DpResponse
import com.fastflow.smartdownload.manager.ui.data.User
import com.fastflow.smartdownload.manager.ui.data.UserList
import com.fastflow.smartdownload.manager.ui.interfaces.APIResponse
import com.fastflow.smartdownload.manager.utils.Constant
import com.fastflow.smartdownload.manager.utils.DownloadManager
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import java.text.SimpleDateFormat
import java.util.Calendar

class PreviewActivity : BaseActivity() {

    lateinit var binding: ActivityPreviewBinding
    var userData: UserList? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inti()
    }

    private fun inti() {
        binding.loutToolbar.txtTitle.text = getString(R.string.preview)
        val user = Constant.profileData[0].user
        userData = UserList(
            Constant.profileData[0].position,
            User(
                user.pk,
                user.pkId,
                user.username,
                user.fullName,
                user.isPrivate,
                user.isVerified,
                user.profilePicId,
                user.profilePicUrl,
                user.hdProfilePicUrl
            )
        )
        initListener()
        setData()
    }

    private fun setData() {
        if (userData != null) {
            binding.txtUserName.text = userData!!.user.username
            binding.txtFullName.text = userData!!.user.fullName
            val url =
                if (!userData!!.user.hdProfilePicUrl.isNullOrBlank()) userData!!.user.hdProfilePicUrl else userData!!.user.profilePicUrl
            Log.e("", "url==>>  $url")
            Glide.with(this)
                .load(url)
                .into(binding.useProfile)
            if (userData!!.user.hdProfilePicUrl.isNullOrBlank()) {
                binding.btnHd.visibility = View.VISIBLE
                binding.btnDownloadProfile.visibility = View.GONE
            } else {
                binding.btnHd.visibility = View.GONE
                binding.btnDownloadProfile.visibility = View.VISIBLE
            }
        }
    }


    private fun initListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            if (binding.loutLoading.visibility == View.GONE)
                onBackPressed()
        }
        binding.btnHd.setOnClickListener {
            getHDProfile()
        }

        binding.btnDownloadProfile.setOnClickListener {
            if (checkStoragePermissions()) {
                downloadProfile()
            } else
                permissionLauncher.launch(
                    Intent(
                        this,
                        PermissionActivity::class.java
                    )
                )
        }
    }

    var permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                downloadProfile()
            }
        }

    private fun downloadProfile() {
        if (userData != null)
            downloadUrl(userData!!.user.hdProfilePicUrl ?: "", userData!!.user.username)
    }


    private fun getHDProfile() {
        val dialogBinding = DialogLoaderBinding.inflate(layoutInflater)
        val loaderDialog = Dialog(this, R.style.Theme_Dialog)
        loaderDialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
        loaderDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        loaderDialog.setCancelable(false)
        loaderDialog.setCanceledOnTouchOutside(false)
        loaderDialog.setContentView(dialogBinding.root)
        loaderDialog.show()

        val api = ApiManager()
        val userName = userData!!.user.username
        api.callHDDpSearch(this, userName, object : APIResponse {
            override fun onResponse(response: Any) {
                val dpSearchResponse = Gson().fromJson(
                    Gson().toJson(response),
                    DpResponse::class.java
                )
                val userList = dpSearchResponse.graphql.user
                val user = Constant.profileData[0].user
                userData = UserList(
                    Constant.profileData[0].position, User(
                        user.pk,
                        user.pkId,
                        user.username,
                        user.fullName,
                        user.isPrivate,
                        user.isVerified,
                        user.profilePicId,
                        user.profilePicUrl,
                        userList.hdProfilePicUrl
                    )
                )
                runOnUiThread {
                    setData()
                    loaderDialog.dismiss()
                }
            }

            override fun onFailure(error: String) {
                runOnUiThread {
                    loaderDialog.dismiss()
                    Toast.makeText(
                        this@PreviewActivity,
                        getText(R.string.download_fail_msg),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onLoginRequired() {
                runOnUiThread {
                    loaderDialog.dismiss()
                    startActivity(Intent(this@PreviewActivity, LoginActivity::class.java))
                }
            }
        })
    }

    private fun downloadUrl(
        url: String, username: String
    ) {
        if (url.isNullOrEmpty()) {
            Toast.makeText(
                this,
                getText(R.string.download_fail_msg),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        var dialogBinding: DialogDownloadBinding
        var dialog: Dialog

        runOnUiThread {
            dialogBinding = DialogDownloadBinding.inflate(layoutInflater)
            dialog = Dialog(this, R.style.Theme_Dialog)
            dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setCancelable(false)
            dialog.setCanceledOnTouchOutside(false)
            dialog.setContentView(dialogBinding.root)
            dialogBinding.progressBar.progress = 0
            dialogBinding.txtPer.text = "0%"
            dialogBinding.txtCount.text = "0/100"
            dialog.show()
            val dateFormated =
                SimpleDateFormat("dd_MMM_yyyy_HH_mm_ss").format(Calendar.getInstance().timeInMillis)
            val fileName = "${username}_$dateFormated"

            val downloadManager = DownloadManager(this)
            Observable.fromCallable {
                runOnUiThread {
                    dialogBinding.progressBar.progress = 0
                    dialogBinding.txtPer.text = "0%"
                    dialogBinding.txtCount.text = "0/100"
                }
                val path = downloadManager.downloadFile(
                    url,
                    Constant.TYPE_DP_DOWNLOAD,
                    fileName,
                    Constant.TYPE_IMAGE,
                    progressUpdateListener = {
                        runOnUiThread {
                            dialogBinding.progressBar.progress = it
                            dialogBinding.txtPer.text = "$it%"
                            dialogBinding.txtCount.text = "$it/100"
                        }
                    })

                return@fromCallable path
            }.subscribeOn(Schedulers.io())
                .doOnError { throwable: Throwable? ->
                    runOnUiThread {
                        dialog.dismiss()
                        Toast.makeText(
                            this,
                            getText(R.string.download_fail_msg),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
                .subscribe { result: String? ->
                    Log.e("", "getReels result==>> $result ")
                    runOnUiThread {
                        dialog.dismiss()
                        if (!result.isNullOrEmpty()) {
                            Toast.makeText(
                                this,
                                getText(R.string.image_save),
                                Toast.LENGTH_SHORT
                            ).show()
                            finish()
                        } else {
                            Toast.makeText(
                                this,
                                getText(R.string.download_fail_msg),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
        }
    }

}