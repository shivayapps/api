package com.fastflow.smartdownload.manager.ui.data

class DpGeneratorSubCategoryResponse : ArrayList<DpGeneratorSubCategoryItem>()