package com.fastflow.smartdownload.manager.network


import com.fastflow.smartdownload.manager.ui.data.DpGeneratorCategoryResponse
import com.fastflow.smartdownload.manager.ui.data.DpGeneratorSubCategoryResponse
import com.fastflow.smartdownload.manager.ui.data.HashtagAPIData
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Url

interface ApiService {

//    @GET("hashtag.json")
//    fun getHashtagData(): Call<HashtagAPIData>

    @GET
    fun getHashtagData(@Url url: String): Call<HashtagAPIData>


//    @GET("category")
//    fun getCategoryList(): Call<DpGeneratorCategoryResponse>

    @GET
    fun getCategoryList(@Url url: String): Call<DpGeneratorCategoryResponse>

    @GET
    fun getSubCategoryList(@Url url: String): Call<DpGeneratorSubCategoryResponse>

}