package com.fastflow.smartdownload.manager.ui.data

data class TabData(var title: String,var type: String)
