package com.fastflow.smartdownload.manager.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.fastflow.smartdownload.manager.databinding.ItemImageBinding

class ImageAdapter(
    var context: Context,
    var imageList: ArrayList<String>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<ImageAdapter.ViewHolder>() {

    var albumSelect = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemImageBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return imageList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        Glide.with(context)
            .load(imageList[position])
            .into(holder.binding.image)


        holder.binding.root.setOnClickListener {
            val p = albumSelect
            albumSelect = position
            clickListener(position)
            notifyItemChanged(p)
            notifyItemChanged(albumSelect)
        }
    }

    class ViewHolder(var binding: ItemImageBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }
}