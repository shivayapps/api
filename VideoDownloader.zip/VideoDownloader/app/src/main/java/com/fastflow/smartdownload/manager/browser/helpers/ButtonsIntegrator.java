package com.fastflow.smartdownload.manager.browser.helpers;

import android.net.Uri;
import android.util.Log;
import android.webkit.URLUtil;

import com.google.gson.JsonObject;
import com.fastflow.smartdownload.manager.browser.ui_events.ButtonsIntegratingStateHandler;
import com.fastflow.smartdownload.manager.browser.ui_events.ButtonsIntegratingStateHandler;

import org.apache.commons.io.FilenameUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Entities;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CountDownLatch;


public class ButtonsIntegrator {
    CountDownLatch countDownLatch;
    DownloadYTVideoButtonModel currentVideoButtonModel_yt;
    List<DownloadYTVideoButtonModel> downloadShortsButtons_yt;
    List<DownloadYTVideoButtonModel> downloadVideoButtons_yt;
    Elements foundedContainers_fb;
    Elements foundedPosts_insta;
    Elements foundedShorts_yt;
    Elements foundedVideosInSearch_yt;
    Elements foundedVideos_yt;
    int totalLatch = 0;
    boolean forcedStop = false;
    List<InstaPostModel> instaPosts = new ArrayList();
    List<FBContainerModel> fbContainers = new ArrayList();

    public void integrateButtonsToYoutube(String str, String str2, String str3, ButtonsIntegratingStateHandler buttonsIntegratingStateHandler) {
        this.forcedStop = false;
        this.currentVideoButtonModel_yt = new DownloadYTVideoButtonModel();
        this.downloadVideoButtons_yt = new ArrayList();
        this.downloadShortsButtons_yt = new ArrayList();
        Document parse = Jsoup.parse(str);
        this.foundedVideos_yt = parse.getElementsByClass("media-item-thumbnail-container");
        this.foundedVideosInSearch_yt = new Elements();
        this.foundedShorts_yt = parse.getElementsByClass("reel-item-endpoint");
        this.totalLatch = this.foundedVideos_yt.size() + this.foundedShorts_yt.size() + this.foundedVideosInSearch_yt.size();
        this.countDownLatch = new CountDownLatch(this.totalLatch);
        if (str3.toLowerCase().contains("youtube.com/watch") || str3.toLowerCase().contains("youtube.com/short")) {
            this.totalLatch = this.foundedVideos_yt.size() + this.foundedShorts_yt.size() + this.foundedVideosInSearch_yt.size() + 1;
            this.countDownLatch = new CountDownLatch(this.totalLatch);
            this.currentVideoButtonModel_yt.setVideoType(DownloadYTVideoButtonModel.YTVideoType.CLASSIC_VIDEO_FULLY);
            if (str3.toLowerCase().contains("youtube.com/short")) {
                this.currentVideoButtonModel_yt.setVideoType(DownloadYTVideoButtonModel.YTVideoType.SHORT_FULLY);
            }
            this.currentVideoButtonModel_yt.setButton_id(0);
            this.currentVideoButtonModel_yt.setTargetURL(str3);
            this.currentVideoButtonModel_yt.setDomainUrl(str2);
        }
        Iterator<Element> it = this.foundedVideos_yt.iterator();
        while (it.hasNext()) {
            Element next = it.next();
            if (this.forcedStop) {
                break;
            }
            DownloadYTVideoButtonModel downloadYTVideoButtonModel = new DownloadYTVideoButtonModel();
            downloadYTVideoButtonModel.setVideoType(DownloadYTVideoButtonModel.YTVideoType.CLASSIC_VIDEO_LIST);
            downloadYTVideoButtonModel.setButton_id(0);
            downloadYTVideoButtonModel.setTargetURL(next.attributes().get("href"));
            downloadYTVideoButtonModel.setDomainUrl(str2);
            this.downloadVideoButtons_yt.add(downloadYTVideoButtonModel);
        }
        Iterator<Element> it2 = this.foundedShorts_yt.iterator();
        while (it2.hasNext()) {
            Element next2 = it2.next();
            if (this.forcedStop) {
                break;
            }
            DownloadYTVideoButtonModel downloadYTVideoButtonModel2 = new DownloadYTVideoButtonModel();
            downloadYTVideoButtonModel2.setVideoType(DownloadYTVideoButtonModel.YTVideoType.SHORT);
            downloadYTVideoButtonModel2.setButton_id(0);
            downloadYTVideoButtonModel2.setTargetURL(next2.attributes().get("href"));
            downloadYTVideoButtonModel2.setDomainUrl(str2);
            this.downloadShortsButtons_yt.add(downloadYTVideoButtonModel2);
        }
        if (!this.forcedStop) {
            parse.outputSettings(new Document.OutputSettings().prettyPrint(false));
            buttonsIntegratingStateHandler.OnComplete_YT(parse.body().outerHtml().replaceAll("\\\\n", "\n"), this.downloadVideoButtons_yt, this.downloadShortsButtons_yt, this.currentVideoButtonModel_yt);
            return;
        }
        buttonsIntegratingStateHandler.OnError("Процесс остановлен принудительно!");
    }

    public void integrateButtonsToInstagram(String str, String str2, String str3, ButtonsIntegratingStateHandler buttonsIntegratingStateHandler) {
        Log.e("integrateDataFetch", "integrateButtonsToInstagram");
        Log.e("MyWebViewClient", "integrateButtonsToInstagram  currentUrl==>>>>" + str3);
        Iterator<Element> it;
        int i = 0;
        this.forcedStop = false;
        this.instaPosts = new ArrayList();
        Document parse = Jsoup.parse(str);
        parse.outputSettings().escapeMode(Entities.EscapeMode.base);
        Elements elementsByTag = parse.getElementsByTag("article");
        this.foundedPosts_insta = elementsByTag;
        if (elementsByTag.size() <= 0) {
            this.foundedPosts_insta = parse.getElementsByClass("_aamn");
        }
        if (this.foundedPosts_insta.size() <= 0) {
            this.foundedPosts_insta = parse.getElementsByClass("x1i10hfl");
        }
        this.totalLatch = this.foundedPosts_insta.size();
        this.countDownLatch = new CountDownLatch(this.totalLatch);
        Iterator<Element> it2 = this.foundedPosts_insta.iterator();
        while (it2.hasNext()) {
            Log.e("integrateButtons", "while call "+ foundedPosts_insta.size());
            Element next = it2.next();
            if (this.forcedStop) {
                break;
            }
            InstaPostModel instaPostModel = new InstaPostModel();
            Elements elementsByTag2 = next.getElementsByTag("header");
            if (elementsByTag2.size() > 0) {
                Elements elementsByTag3 = elementsByTag2.get(i).getElementsByTag("a");
                if (elementsByTag3.size() > 1) {
                    instaPostModel.setAuthorName(elementsByTag3.get(1).text());
                }
            }
            ArrayList arrayList = new ArrayList();
            Elements elementsByTag4 = next.getElementsByTag("ul");
            Iterator<Element> it3 = it2;
            if (elementsByTag4.size() > 0) {
                Iterator<Element> it4 = elementsByTag4.get(0).getElementsByTag("li").iterator();


                while (it4.hasNext()) {
                    Element next2 = it4.next();
                    Elements elementsByTag5 = next2.getElementsByTag("img");
                    Elements elementsByTag6 = next2.getElementsByTag("video");
                    for (Element element : elementsByTag5) {
                        Log.e("integrateButtons", "elementsByTag5 url==>>" + element.attributes().get("src").replace("\\\"", ""));
                    }
                    for (Element element : elementsByTag6) {
                        Log.e("integrateButtons", "elementsByTag6 url==>>" + element.attributes().get("src").replace("\\\"", ""));
                    }
                    if (elementsByTag5.size() > 0 && elementsByTag6.size() == 0) {
                        DownloadInstaMediaButtonModel downloadInstaMediaButtonModel = new DownloadInstaMediaButtonModel();
                        it = it4;
                        downloadInstaMediaButtonModel.setMediaType(DownloadInstaMediaButtonModel.InstaMediaType.IMAGE);
                        downloadInstaMediaButtonModel.setButton_id(0);
                        downloadInstaMediaButtonModel.setTargetURL(elementsByTag5.get(0).attributes().get("src").replace("\\\"", ""));
                        downloadInstaMediaButtonModel.setDomainUrl(str2);
                        arrayList.add(downloadInstaMediaButtonModel);
                        Log.e("MyWebViewClient", "integrateButtonsToInstagram  findPosterUrl==>>>>" + downloadInstaMediaButtonModel.getTargetURL());
                    } else {
                        it = it4;
                        if (elementsByTag6.size() > 0) {
                            DownloadInstaMediaButtonModel downloadInstaMediaButtonModel2 = new DownloadInstaMediaButtonModel();
                            downloadInstaMediaButtonModel2.setMediaType(DownloadInstaMediaButtonModel.InstaMediaType.VIDEO);
                            downloadInstaMediaButtonModel2.setButton_id(0);
                            downloadInstaMediaButtonModel2.setTargetURL(elementsByTag6.get(0).attributes().get("src").replace("\\\"", ""));
                            downloadInstaMediaButtonModel2.setDomainUrl(str2);
                            downloadInstaMediaButtonModel2.setVideoPosterUrl(elementsByTag6.get(0).attributes().get("poster").replace("\\\"", ""));
                            downloadInstaMediaButtonModel2.setVideoMimeType(elementsByTag6.get(0).attributes().get("type").replace("\\\"", ""));
                            arrayList.add(downloadInstaMediaButtonModel2);
                            Log.e("MyWebViewClient", "integrateButtonsToInstagram  findPosterUrl==>>>>" + downloadInstaMediaButtonModel2.getTargetURL());
                        }
                    }
                    it4 = it;
                }
            } else {
                Elements elementsByTag7 = next.getElementsByTag("img");
                Elements elementsByTag8 = next.getElementsByTag("video");
                if (elementsByTag7.size() > 0 && elementsByTag7.size() <= 0) {
                    Iterator<Element> it5 = elementsByTag7.iterator();
                    for (Element element : elementsByTag8) {
                        Log.e("integrateButtons", "elementsByTag7.size" + elementsByTag7.size() +" elementsByTag7 url==>>" + element.attributes().get("src").replace("\\\"", ""));
                    }

                    while (true) {
                        if (!it5.hasNext()) {
                            break;
                        }
                        Element next3 = it5.next();
                        if (!next3.attributes().get("alt").toLowerCase().contains(instaPostModel.getAuthorName())) {
                            DownloadInstaMediaButtonModel downloadInstaMediaButtonModel3 = new DownloadInstaMediaButtonModel();
                            downloadInstaMediaButtonModel3.setMediaType(DownloadInstaMediaButtonModel.InstaMediaType.IMAGE);
                            downloadInstaMediaButtonModel3.setButton_id(0);
                            downloadInstaMediaButtonModel3.setTargetURL(next3.attributes().get("src").replace("\\\"", ""));
                            downloadInstaMediaButtonModel3.setDomainUrl(str2);
                            arrayList.add(downloadInstaMediaButtonModel3);
                            Log.e("MyWebViewClient", "integrateButtonsToInstagram  findPosterUrl==>>>>" + downloadInstaMediaButtonModel3.getTargetURL());
                            break;
                        }
                    }
                }
                if (elementsByTag8.size() > 0) {
                    Iterator<Element> it6 = elementsByTag8.iterator();
                    for (Element element : elementsByTag8) {
                        Log.e("integrateButtons", "elementsByTag8 url==>>" + element.attributes().get("src").replace("\\\"", ""));
                    }
                    while (it6.hasNext()) {
                        Element next4 = it6.next();
                        DownloadInstaMediaButtonModel downloadInstaMediaButtonModel4 = new DownloadInstaMediaButtonModel();
                        downloadInstaMediaButtonModel4.setMediaType(DownloadInstaMediaButtonModel.InstaMediaType.VIDEO);
                        downloadInstaMediaButtonModel4.setButton_id(0);
                        downloadInstaMediaButtonModel4.setTargetURL(next4.attributes().get("src").replace("\\\"", ""));
                        downloadInstaMediaButtonModel4.setDomainUrl(str2);
                        downloadInstaMediaButtonModel4.setVideoPosterUrl(next4.attributes().get("poster").replace("\\\"", ""));
                        downloadInstaMediaButtonModel4.setVideoMimeType(next4.attributes().get("type").replace("\\\"", ""));
                        arrayList.add(downloadInstaMediaButtonModel4);
                        Log.e("MyWebViewClient", "integrateButtonsToInstagram  findPosterUrl==>>>>" + downloadInstaMediaButtonModel4.getTargetURL());
                    }
                }
            }
            if (arrayList.size() > 0) {
                instaPostModel.setDownloadButtons(new ArrayList<>(arrayList));
                instaPostModel.setPostIndex(this.instaPosts.size());
                this.instaPosts.add(instaPostModel);
            }
            it2 = it3;
            i = 0;
        }

        if (this.instaPosts.size() <= 0) {
            Elements elementsByAttributeValueContaining = parse.getElementsByAttributeValueContaining("class", "x5yr21d");
            this.foundedPosts_insta = elementsByAttributeValueContaining;
            if (elementsByAttributeValueContaining.size() > 1) {
                InstaPostModel instaPostModel2 = new InstaPostModel();
                Elements elementsByTag9 = this.foundedPosts_insta.get(1).getElementsByTag("video");
                ArrayList arrayList2 = new ArrayList();
                if (elementsByTag9.size() > 0) {
                    Iterator<Element> it7 = elementsByTag9.iterator();
                    for (Element element : elementsByTag9) {
                        Log.e("integrateButtons",  "elementsByTag9.size" + elementsByTag9.size() +" elementsByTag9 url==>>" + element.attributes().get("src").replace("\\\"", ""));
                    }
                    while (it7.hasNext()) {
                        Element next5 = it7.next();
                        DownloadInstaMediaButtonModel downloadInstaMediaButtonModel5 = new DownloadInstaMediaButtonModel();
                        downloadInstaMediaButtonModel5.setMediaType(DownloadInstaMediaButtonModel.InstaMediaType.REEL_VIDEO);
                        downloadInstaMediaButtonModel5.setButton_id(0);
                        downloadInstaMediaButtonModel5.setTargetURL(next5.attributes().get("src").replace("\\\"", ""));
                        downloadInstaMediaButtonModel5.setDomainUrl(str2);
                        downloadInstaMediaButtonModel5.setVideoMimeType(next5.attributes().get("type").replace("\\\"", ""));
                        arrayList2.add(downloadInstaMediaButtonModel5);
                        Log.e("MyWebViewClient", "integrateButtonsToInstagram  findPosterUrl==>>>>" + downloadInstaMediaButtonModel5.getTargetURL());

                    }
                }
                if (arrayList2.size() > 0) {
                    instaPostModel2.setDownloadButtons(new ArrayList<>(arrayList2));
                    instaPostModel2.setPostIndex(this.instaPosts.size());
                    this.instaPosts.add(instaPostModel2);
                }
            }
        }
        if (this.instaPosts.size() <= 0) {
            Elements elementsByAttributeValueContaining2 = parse.getElementsByAttributeValueContaining("class", "_afah");
            this.foundedPosts_insta = elementsByAttributeValueContaining2;
            if (elementsByAttributeValueContaining2.size() > 0) {
                InstaPostModel instaPostModel3 = new InstaPostModel();
                ArrayList arrayList3 = new ArrayList();
                Elements elementsByTag10 = this.foundedPosts_insta.get(0).getElementsByTag("img");
                if (elementsByTag10.size() > 0) {
                    for (Element element : elementsByTag10) {
                        Log.e("integrateButtons", "elementsByTag10 url==>>" + element.attributes().get("src").replace("\\\"", ""));
                    }
                    Iterator<Element> it8 = elementsByTag10.iterator();
                    if (it8.hasNext()) {
                        DownloadInstaMediaButtonModel downloadInstaMediaButtonModel6 = new DownloadInstaMediaButtonModel();
                        downloadInstaMediaButtonModel6.setMediaType(DownloadInstaMediaButtonModel.InstaMediaType.REEL_IMAGE);
                        downloadInstaMediaButtonModel6.setButton_id(0);
                        downloadInstaMediaButtonModel6.setTargetURL(it8.next().attributes().get("src").replace("\\\"", ""));
                        downloadInstaMediaButtonModel6.setDomainUrl(str2);
                        arrayList3.add(downloadInstaMediaButtonModel6);
                        Log.e("MyWebViewClient", "integrateButtonsToInstagram  findPosterUrl==>>>>" + downloadInstaMediaButtonModel6.getTargetURL());

                    }
                }
                if (arrayList3.size() > 0) {
                    instaPostModel3.setDownloadButtons(new ArrayList<>(arrayList3));
                    instaPostModel3.setPostIndex(this.instaPosts.size());
                    this.instaPosts.add(instaPostModel3);
                }
            }
        }
        if (!this.forcedStop) {
            buttonsIntegratingStateHandler.OnComplete_Insta(this.instaPosts);
        } else {
            buttonsIntegratingStateHandler.OnError("Процесс остановлен принудительно!");
        }
    }

    public void integrateButtonsToFacebook(String str, String str2, String str3, ButtonsIntegratingStateHandler buttonsIntegratingStateHandler) {
        Log.e("integrateButtonsToFacebook", "finding the data start");
        try {


            String str4;
            String str5;
            String str6;
            String str7;
            Iterator<Element> it;
            String str8;
            String str9 = null;
            String str10;
            String str11 = null;
            FBContainerModel fBContainerModel = null;
            String str12 = "";
            String str13 = "";
            JsonObject jsonObject = null;
            DownloadFBMediaButtonModel downloadFBMediaButtonModel = null;
            Iterator<Element> it2;
            Iterator<Element> it3 = null;
            String str14;
            String str15;
            ButtonsIntegrator buttonsIntegrator = this;
            String str16 = "photoset_token";
            buttonsIntegrator.forcedStop = false;
            buttonsIntegrator.fbContainers = new ArrayList();
            Document parse = Jsoup.parse(str);
            String str17 = "/posts/";
            String str18 = "video";
            String str19 = "data-store";
            String str20 = "_53mw";
            String str21 = "src";
            Exception e = null;
            if (str3.contains("/posts/")) {
                Log.e("integrateButtonsToFacebook", "finding Data if /posts/");
                Elements elementsByAttributeValueContaining = parse.getElementsByAttributeValueContaining("class", "_56be");
                buttonsIntegrator.foundedContainers_fb = elementsByAttributeValueContaining;
                if (elementsByAttributeValueContaining.size() <= 0) {
                    buttonsIntegrator.foundedContainers_fb = parse.getElementsByAttributeValueContaining("class", "_53mw");
                }
                Iterator<Element> it4 = buttonsIntegrator.foundedContainers_fb.iterator();
                while (it4.hasNext()) {
                    Element next = it4.next();
                    Iterator<Element> it5 = it4;
                    if (buttonsIntegrator.forcedStop) {
                        Log.e("integrateButtonsToFacebook", "finding the data forcedStop if /posts/");
                        break;
                    }
                    FBContainerModel fBContainerModel2 = new FBContainerModel();
                    Elements elementsByTag = next.getElementsByTag("img");
                    Elements elementsByTag2 = next.getElementsByTag(str18);
                    String str22 = str20;
                    DownloadFBMediaButtonModel downloadFBMediaButtonModel2 = new DownloadFBMediaButtonModel();
                    String str23 = str17;
                    if (elementsByTag.size() > 0) {
                        str14 = str16;
                        Element element = elementsByTag.get(0);
                        downloadFBMediaButtonModel2.setMediaType(DownloadFBMediaButtonModel.FBMediaType.IMAGE);
                        downloadFBMediaButtonModel2.setDomainUrl(str2);
                        if (element.attributes().get("src").charAt(0) == 'h') {
                            downloadFBMediaButtonModel2.setTargetURL(element.attributes().get("src"));
                        } else {
                            String replaceFirst = element.attributes().get("src").replaceFirst("\"", "");
                            downloadFBMediaButtonModel2.setTargetURL(replaceFirst.substring(1, replaceFirst.length() - 2));
                        }
                        fBContainerModel2.getDownloadButtons().add(downloadFBMediaButtonModel2);
                    } else {
                        str14 = str16;
                        if (elementsByTag2.size() > 0) {
                            Element element2 = elementsByTag2.get(0);
                            downloadFBMediaButtonModel2.setMediaType(DownloadFBMediaButtonModel.FBMediaType.VIDEO);
                            downloadFBMediaButtonModel2.setDomainUrl(str2);
                            str15 = str18;
                            if (element2.attributes().get("src").charAt(0) == 'h') {
                                downloadFBMediaButtonModel2.setTargetURL(element2.attributes().get("src"));
                                downloadFBMediaButtonModel2.setVideoPosterUrl(element2.attributes().get("poster"));
                            } else {
                                String replaceFirst2 = element2.attributes().get("src").replaceFirst("\"", "");
                                String replaceFirst3 = element2.attributes().get("poster").replaceFirst("\"", "");
                                downloadFBMediaButtonModel2.setTargetURL(replaceFirst2.substring(1, replaceFirst2.length() - 2));
                                downloadFBMediaButtonModel2.setVideoPosterUrl(replaceFirst3.substring(1, replaceFirst3.length() - 2));
                            }
                            fBContainerModel2.getDownloadButtons().add(downloadFBMediaButtonModel2);
                            buttonsIntegrator.fbContainers.add(fBContainerModel2);
                            it4 = it5;
                            str20 = str22;
                            str16 = str14;
                            str17 = str23;
                            str18 = str15;
                        }
                    }
                    str15 = str18;
                    buttonsIntegrator.fbContainers.add(fBContainerModel2);
                    it4 = it5;
                    str20 = str22;
                    str16 = str14;
                    str17 = str23;
                    str18 = str15;
                }
                str4 = str16;
                str5 = str17;
                str6 = str18;
                str7 = str20;
            } else {
                Log.e("integrateButtonsToFacebook", "finding Data  else called");
                str4 = "photoset_token";
                str5 = "/posts/";
                str6 = "video";
                str7 = "_53mw";
                if (str3.contains("photo.php") || str3.contains("/photos/")) {
                    Log.e("integrateButtonsToFacebook", "finding Data  else if photo.php /photos/");
                    Elements elementsByAttributeValueContaining2 = parse.getElementsByAttributeValueContaining("class", "_57-o");
                    buttonsIntegrator.foundedContainers_fb = elementsByAttributeValueContaining2;
                    Iterator<Element> it6 = elementsByAttributeValueContaining2.iterator();
                    if (it6.hasNext()) {
                        Element next2 = it6.next();
                        if (!buttonsIntegrator.forcedStop) {
                            FBContainerModel fBContainerModel3 = new FBContainerModel();
                            DownloadFBMediaButtonModel downloadFBMediaButtonModel3 = new DownloadFBMediaButtonModel();
                            Elements elementsByAttributeValueContaining3 = next2.getElementsByAttributeValueContaining("class", "img");
                            if (elementsByAttributeValueContaining3.size() > 0) {
                                String attr = elementsByAttributeValueContaining3.get(0).attr("data-store");
                                if (attr.contains("\\\"")) {
                                    attr = attr.substring(2, attr.length() - 2);
                                }
                                downloadFBMediaButtonModel3.setMediaType(DownloadFBMediaButtonModel.FBMediaType.IMAGE);
                                downloadFBMediaButtonModel3.setDomainUrl(str2);
                                downloadFBMediaButtonModel3.setTargetURL(((JsonObject) HelpFuncs.Gson().fromJson(attr, JsonObject.class)).getAsJsonPrimitive("imgsrc").getAsString().replace("\\/", "/"));
                                fBContainerModel3.getDownloadButtons().add(downloadFBMediaButtonModel3);
                            }
                            buttonsIntegrator.fbContainers.add(fBContainerModel3);
                        }
                    }
                }
            }
            Elements elements = buttonsIntegrator.foundedContainers_fb;
            if (elements == null || elements.size() <= 0) {
                Elements elementsByAttributeValueContaining4 = parse.getElementsByAttributeValueContaining("class", "_5rgr");
                buttonsIntegrator.foundedContainers_fb = elementsByAttributeValueContaining4;
                Iterator<Element> it7 = elementsByAttributeValueContaining4.iterator();
                while (it7.hasNext()) {
                    Element next3 = it7.next();
                    if (buttonsIntegrator.forcedStop) {
                        Log.e("integrateButtonsToFacebook", "finding the data forcedStop  else called");
                        break;
                    }
                    try {
                        fBContainerModel = new FBContainerModel();
                        Elements elementsByAttributeValueContaining5 = next3.getElementsByAttributeValueContaining("class", "_26ii _-_b");
                        if (elementsByAttributeValueContaining5.size() > 0) {
                            try {
                                fBContainerModel.setMultiContainer(true);
                                Elements elementsByAttributeValueContaining6 = elementsByAttributeValueContaining5.get(0).getElementsByAttributeValueContaining("class", "_26ih");
                                Elements elementsByAttributeValueContaining7 = next3.getElementsByAttributeValueContaining("class", "_52jd _52jb");
                                it = it7;
                                try {
                                    Elements elementsByAttributeValueContaining8 = next3.getElementsByAttributeValueContaining("class", "_3q6s _78cw");
                                    str13 = str21;
                                    try {
                                        if (elementsByAttributeValueContaining8.size() > 0) {
                                            str12 = str19;
                                            try {
                                                Elements elementsByTag3 = elementsByAttributeValueContaining8.get(0).getElementsByTag("a");
                                                if (elementsByTag3.size() > 0) {
                                                    Element element3 = elementsByTag3.get(0);
                                                    fBContainerModel.setAuthorName(element3.attributes().get("href").substring(1, element3.attributes().get("href").indexOf("?")));
                                                }
                                            } catch (Exception e1) {
                                                e = e1;
                                                buttonsIntegrator = this;
                                                str8 = str12;
                                                str10 = str4;
                                                str9 = str13;
                                                str11 = str6;
                                                e1.printStackTrace();
                                                str4 = str10;
                                                str6 = str11;
                                                str21 = str9;
                                                str19 = str8;
                                                it7 = it;
                                            }
                                        } else {
                                            str12 = str19;
                                            if (elementsByAttributeValueContaining7.size() > 0) {
                                                Elements elementsByTag4 = elementsByAttributeValueContaining7.get(0).getElementsByTag("a");
                                                if (elementsByTag4.size() > 0) {
                                                    Element element4 = elementsByTag4.get(0);
                                                    fBContainerModel.setAuthorName(element4.attributes().get("href").substring(1, element4.attributes().get("href").indexOf("?")));
                                                    it2 = elementsByAttributeValueContaining6.iterator();
                                                    while (it2.hasNext()) {
                                                        Element next4 = it2.next();
                                                        Elements elementsByAttributeValueContaining9 = next4.getElementsByAttributeValueContaining("role", "img");
                                                        if (elementsByAttributeValueContaining9.size() > 0) {
                                                            DownloadFBMediaButtonModel downloadFBMediaButtonModel4 = new DownloadFBMediaButtonModel();
                                                            str11 = str6;
                                                            try {
                                                                if (elementsByAttributeValueContaining9.get(0).attributes().get("aria-label").equalsIgnoreCase(str11)) {
                                                                    try {
                                                                        downloadFBMediaButtonModel4.setMediaType(DownloadFBMediaButtonModel.FBMediaType.VIDEO);
                                                                    } catch (Exception e2) {
                                                                        e = e2;
                                                                        buttonsIntegrator = this;
                                                                        str8 = str12;
                                                                        str10 = str4;
                                                                        str9 = str13;
                                                                        e.printStackTrace();
                                                                        str4 = str10;
                                                                        str6 = str11;
                                                                        str21 = str9;
                                                                        str19 = str8;
                                                                        it7 = it;
                                                                    }
                                                                } else {
                                                                    downloadFBMediaButtonModel4.setMediaType(DownloadFBMediaButtonModel.FBMediaType.IMAGE);
                                                                }
                                                                Uri parse2 = Uri.parse(str2 + next4.attributes().get("href").replaceFirst("#!", "").replaceFirst("!#", ""));
                                                                downloadFBMediaButtonModel4.setDomainUrl(str2);
                                                                str10 = str4;
                                                                try {
                                                                    if (parse2.getQueryParameter(str10) == null) {
                                                                        downloadFBMediaButtonModel4.setTargetURL(parse2.toString());
                                                                        it3 = it2;
                                                                    } else {
                                                                        it3 = it2;
                                                                        String str24 = str5;
                                                                        try {
                                                                            str5 = str24;
                                                                            downloadFBMediaButtonModel4.setTargetURL(str2 + "/" + fBContainerModel.getAuthorName() + str24 + parse2.getQueryParameter(str10) + "/?photo_id=" + parse2.getQueryParameter("photo"));
                                                                            downloadFBMediaButtonModel4.setTargetURL(downloadFBMediaButtonModel4.getTargetURL().replace("//posts", "/posts"));
                                                                        } catch (Exception e3) {
                                                                            e = e3;
                                                                            str5 = str24;
                                                                            buttonsIntegrator = this;
                                                                            str8 = str12;
                                                                            str9 = str13;
                                                                            e.printStackTrace();
                                                                            str4 = str10;
                                                                            str6 = str11;
                                                                            str21 = str9;
                                                                            str19 = str8;
                                                                            it7 = it;
                                                                        }
                                                                    }
                                                                    fBContainerModel.getDownloadButtons().add(downloadFBMediaButtonModel4);
                                                                } catch (Exception e4) {
                                                                    e = e4;
                                                                }
                                                            } catch (Exception e5) {
                                                                e = e5;
                                                                str10 = str4;
                                                            }
                                                        } else {
                                                            str10 = str4;
                                                            str11 = str6;
                                                            it3 = it2;
                                                        }
                                                        str6 = str11;
                                                        it2 = it3;
                                                        str4 = str10;
                                                    }
                                                }
                                            }
                                        }
                                        it2 = elementsByAttributeValueContaining6.iterator();
                                        while (it2.hasNext()) {
                                        }
                                    } catch (Exception e6) {
                                        e = e6;
                                        str10 = str4;
                                        str11 = str6;
                                    }
                                } catch (Exception e7) {
                                    e = e7;
                                    str13 = str21;
                                    str10 = str4;
                                    str11 = str6;
                                    buttonsIntegrator = this;
                                    str8 = str19;
                                    str9 = str13;
                                    e.printStackTrace();
                                    str4 = str10;
                                    str6 = str11;
                                    str21 = str9;
                                    str19 = str8;
                                    it7 = it;
                                }
                            } catch (Exception e8) {
                                e = e8;
                                it = it7;
                            }
                        } else {
                            it = it7;
                            str12 = str19;
                            str13 = str21;
                        }
                        str10 = str4;
                        str11 = str6;
                        if (fBContainerModel.isMultiContainer()) {
                            str8 = str12;
                            str9 = str13;
                        } else {
                            String str25 = str7;
                            try {
                                Elements elementsByAttributeValueContaining10 = next3.getElementsByAttributeValueContaining("class", str25);
                                if (elementsByAttributeValueContaining10.size() > 0) {
                                    try {
                                        Attributes attributes = elementsByAttributeValueContaining10.get(0).attributes();
                                        str8 = str12;
                                        try {
                                            jsonObject = (JsonObject) HelpFuncs.Gson().fromJson(attributes.get(str8), JsonObject.class);
                                            downloadFBMediaButtonModel = new DownloadFBMediaButtonModel();
                                            downloadFBMediaButtonModel.setMediaType(DownloadFBMediaButtonModel.FBMediaType.VIDEO);
                                            downloadFBMediaButtonModel.setDomainUrl(str2);
                                            str9 = str13;
                                        } catch (Exception e9) {
                                            e = e9;
                                            str9 = str13;
                                            str7 = str25;
                                            buttonsIntegrator = this;
                                            e.printStackTrace();
                                            str4 = str10;
                                            str6 = str11;
                                            str21 = str9;
                                            str19 = str8;
                                            it7 = it;
                                        }
                                        try {
                                            downloadFBMediaButtonModel.setTargetURL(jsonObject.getAsJsonPrimitive(str9).getAsString());
                                            String extension = FilenameUtils.getExtension(URLUtil.guessFileName(downloadFBMediaButtonModel.getTargetURL(), null, null));
                                            if (extension != null && !extension.contains("mpd")) {
                                                fBContainerModel.getDownloadButtons().add(downloadFBMediaButtonModel);
                                            }
                                        } catch (Exception e10) {
                                            e = e10;
                                            str7 = str25;
                                            buttonsIntegrator = this;
                                            e.printStackTrace();
                                            str4 = str10;
                                            str6 = str11;
                                            str21 = str9;
                                            str19 = str8;
                                            it7 = it;
                                        }
                                    } catch (Exception e11) {
                                        e = e11;
                                        str8 = str12;
                                    }
                                } else {
                                    str8 = str12;
                                    str9 = str13;
                                    Elements elementsByAttributeValueContaining11 = next3.getElementsByAttributeValueContaining("class", "_39pi");
                                    if (elementsByAttributeValueContaining11.size() > 0) {
                                        Element element5 = elementsByAttributeValueContaining11.get(0);
                                        DownloadFBMediaButtonModel downloadFBMediaButtonModel5 = new DownloadFBMediaButtonModel();
                                        str7 = str25;
                                        try {
                                            downloadFBMediaButtonModel5.setMediaType(DownloadFBMediaButtonModel.FBMediaType.IMAGE);
                                            downloadFBMediaButtonModel5.setDomainUrl(str2);
                                            downloadFBMediaButtonModel5.setTargetURL(element5.attributes().get("href").replaceFirst("#!", "").replaceFirst("!#", ""));
                                            fBContainerModel.getDownloadButtons().add(downloadFBMediaButtonModel5);
                                        } catch (Exception e12) {
                                            e = e12;
                                            buttonsIntegrator = this;
                                            e.printStackTrace();
                                            str4 = str10;
                                            str6 = str11;
                                            str21 = str9;
                                            str19 = str8;
                                            it7 = it;
                                        }
                                    }
                                }
                                str7 = str25;
                            } catch (Exception e13) {
                                e = e13;
                                str7 = str25;
                                str8 = str12;
                                str9 = str13;
                            }
                        }
                        buttonsIntegrator = this;
                    } catch (Exception e14) {
                        e = e14;
                        it = it7;
                        str8 = str19;
                        str9 = str21;
                        str10 = str4;
                    }
                    try {
                        buttonsIntegrator.fbContainers.add(fBContainerModel);
                    } catch (Exception e15) {
                        e = e15;
                        e.printStackTrace();
                        str4 = str10;
                        str6 = str11;
                        str21 = str9;
                        str19 = str8;
                        it7 = it;
                    }
                    str4 = str10;
                    str6 = str11;
                    str21 = str9;
                    str19 = str8;
                    it7 = it;
                }
            }

            if (e != null)
                Log.e("", "integrateButtonsToFacebook error Message==>>> " + e.getMessage());

            if (!buttonsIntegrator.forcedStop) {
                buttonsIntegratingStateHandler.OnComplete_FB(buttonsIntegrator.fbContainers);
            } else {
                buttonsIntegratingStateHandler.OnError("\u041f\u0440\u043e\u0446\u0435\u0441\u0441 \u043e\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d \u043f\u0440\u0438\u043d\u0443\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e!");
            }
        } catch (Exception exception) {
            exception.printStackTrace();
            buttonsIntegratingStateHandler.OnError(exception.getMessage());
        }
        Log.e("integrateButtonsToFacebook", "called finish the method");
    }

    public void stopTasks() {
        this.forcedStop = true;
    }
}
