package com.fastflow.smartdownload.manager.ui.data

data class FamilyAppsModel(
    val appName: String,
    val isHot: Int=0,
    val shortDescription: String,
    val appImageLink: String,
    val appPackageName: String,
    val appPlayStoreLink: String
)