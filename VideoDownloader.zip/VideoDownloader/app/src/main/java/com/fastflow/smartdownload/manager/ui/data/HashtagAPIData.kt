package com.fastflow.smartdownload.manager.ui.data

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class HashtagAPIData(

    @SerializedName("Hashtag")
    val hashtag: ArrayList<HashtagItem> = ArrayList()
) : Serializable

data class CategoryItemItem(

    @SerializedName("SubCategoryName")
    val subCategoryName: String = "",

    @SerializedName("tag")
    val tag: String = ""
) : Serializable

data class HashtagItem(

    @SerializedName("CategoryName")
    val categoryName: String = "",

    @SerializedName("CategoryItem")
    val categoryItem: ArrayList<CategoryItemItem> = ArrayList()
) : Serializable
