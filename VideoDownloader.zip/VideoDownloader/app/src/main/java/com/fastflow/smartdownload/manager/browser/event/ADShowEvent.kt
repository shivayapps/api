package com.fastflow.smartdownload.manager.browser.event


data class ADShowEvent(var isShowADs: Boolean)