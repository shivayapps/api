package com.fastflow.smartdownload.manager.ui.adapter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.databinding.ItemStoriesDetailsBinding
import com.fastflow.smartdownload.manager.ui.activity.FileFullViewActivity
import com.fastflow.smartdownload.manager.ui.activity.PermissionActivity
import com.fastflow.smartdownload.manager.ui.data.DataModel
import com.fastflow.smartdownload.manager.utils.Constant
import com.fastflow.smartdownload.manager.utils.FileUtil
import com.fastflow.smartdownload.manager.utils.Utils
import java.io.File
import java.util.concurrent.Executors


class StatusAdapter(
    var statusList: ArrayList<DataModel>,
    var context: Context,
    var activity: Activity,
) : RecyclerView.Adapter<StatusAdapter.MyViewHolder>() {
    inner class MyViewHolder(var binding: ItemStoriesDetailsBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(
            ItemStoriesDetailsBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return statusList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        with(holder.binding) {
            with(statusList[position]) {
                ivDownload.visibility = View.VISIBLE
                ivDelete.visibility = View.GONE
                val file = File(path)
                val ext = file.name.substring(file.name.lastIndexOf("."))
                if (ext == ".mp4" || ext == ".webm") {
                    ivPlay.visibility = View.VISIBLE
                } else {
                    ivPlay.visibility = View.GONE
                }
                Glide.with(context)
                    .load(path)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(imageDownload)
                ivDownload.setOnClickListener {
                    if (checkStoragePermissions()) {
                        saveFiles(path)
                    } else {
                        context.startActivity(Intent(context, PermissionActivity::class.java))
                    }
                }
                ivShare.setOnClickListener {
                    val isAbove11WP = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
                    Utils.fileShare(activity, path, isAbove11WP)
                }

                holder.itemView.setOnClickListener {
                    Constant.dataArrayList.clear()
                    Constant.dataArrayList.addAll(statusList)
                    activity.startActivity(
                        Intent(
                            context,
                            FileFullViewActivity::class.java
                        ).putExtra(Constant.PUT_KEY_POSTION, position)
                            .putExtra(Constant.PUT_KEY_EVENT, Constant.VALUE_KEY_STATUS)
                    )
                }
            }
        }
    }

    fun checkStoragePermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                context,
                android.Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                context,
                android.Manifest.permission.READ_MEDIA_VIDEO
            ) == PackageManager.PERMISSION_GRANTED
        } else
            ActivityCompat.checkSelfPermission(
                context,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
    }

    var path: String = FileUtil.getExternalStoragePublicDirectory(
        activity,
        Environment.DIRECTORY_PICTURES
    ) + File.separator + context.getString(R.string.app_name) + File.separator + Constant.FOLDER_WHATSAPP + "/"
    var mainType: String = ""
    var exp: String = ""
    private fun saveFiles(paths: String) {
        val service22 = Executors.newSingleThreadExecutor()
        service22.execute {
            activity.runOnUiThread { }
            val file = File(paths)
            val ext = file.name.substring(file.name.lastIndexOf("."))
            if (ext == ".mp4" || ext == ".webm") {
                mainType = "video/mp4"
                exp = "mp4"
            } else {
                mainType = "image/jpeg"
                exp = "jpeg"
            }
            copyFiles(path, mainType, exp, paths)
            activity.runOnUiThread {
                Toast.makeText(activity, activity.getString(R.string.save), Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }

    private fun copyFiles(path: String, mainType: String, exp: String, paths: String) {
        val file1 = File(path)
        if (!file1.exists()) {
            file1.mkdirs()
        }
        val ss = Uri.fromFile(File(path))
        val fileNames = "GBWhatsapp2025196" + getFileName(Uri.parse(paths))
        val uri: Uri = FileUtil.dataPathToNewUri(
            activity,
            ss,
            fileNames,
            MimeTypeMap.getSingleton().getExtensionFromMimeType(mainType),
            exp
        )
        FileUtil.copyFileData(activity, Uri.parse(paths), uri)
    }

    private fun getFileName(uri: Uri): String {
        var name: String? = null
        if (uri.scheme == "content") {
            val cursor: Cursor? =
                activity.contentResolver.query(uri, null, null, null, null)
            if (cursor != null) {
                if (cursor.moveToFirst()) name =
                    cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
                cursor.close()
            }
        } else if (uri.scheme == "file") name = uri.lastPathSegment
        return name!!.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()[0]
    }
}