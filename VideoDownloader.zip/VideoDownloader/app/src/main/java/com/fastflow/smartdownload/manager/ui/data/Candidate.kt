package com.fastflow.smartdownload.manager.ui.data

import java.io.Serializable

data class Candidate(
    val width: Long,
    val height: Long,
    val url: String,
): Serializable