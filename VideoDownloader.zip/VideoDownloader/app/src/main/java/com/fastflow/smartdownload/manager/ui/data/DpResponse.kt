package com.fastflow.smartdownload.manager.ui.data

data class DpResponse(val graphql: Graphql)

data class Graphql(
    val user: User,
)
