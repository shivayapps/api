package com.fastflow.smartdownload.manager.browser.event

import com.fastflow.smartdownload.manager.ui.data.DownloadData

data class StartDownloadEvent(var data: DownloadData)