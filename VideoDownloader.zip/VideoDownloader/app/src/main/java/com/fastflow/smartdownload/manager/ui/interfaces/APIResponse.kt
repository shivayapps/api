package com.fastflow.smartdownload.manager.ui.interfaces

interface APIResponse {
    fun onResponse(response: Any)
    fun onFailure(error: String= "")
    fun onLoginRequired()
}