package com.fastflow.smartdownload.manager.ui.data

import java.io.Serializable

data class StoryTray(val id: Long,
                     val strong_id__: String,
                     val latest_reel_media: Long,
                     val expiring_at: Long,
                     val seen: Long,
                     val reel_type: String,
                     val user: User,
                     val story_duration_secs: Long,
                     val media_count: Long,
                     val has_video: Boolean,
                     val items: List<StoryItem>,) : Serializable