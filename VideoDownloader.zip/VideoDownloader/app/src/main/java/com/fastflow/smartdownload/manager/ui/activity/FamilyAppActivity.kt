package com.fastflow.smartdownload.manager.ui.activity

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.adconfig.AdsConfig
import com.google.android.gms.tasks.Task
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.databinding.ActivityFamilyAppBinding
import com.fastflow.smartdownload.manager.databinding.ThemeDialogLayoutBinding
import com.fastflow.smartdownload.manager.ui.adapter.FamilyAppsAdapter
import com.fastflow.smartdownload.manager.ui.data.FamilyAppsModel
import com.fastflow.smartdownload.manager.utils.MyApplication
import com.fastflow.smartdownload.manager.utils.Preferences
import com.fastflow.smartdownload.manager.utils.Utils
import org.json.JSONObject


class FamilyAppActivity : BaseActivity() {
    lateinit var binding: ActivityFamilyAppBinding
    var themeValue = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFamilyAppBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inits()
        intiListener()
        val remoteConfig = FirebaseRemoteConfig.getInstance()
        fetchFamilyApps(remoteConfig)
    }

    private fun fetchFamilyApps(remoteConfig: FirebaseRemoteConfig) {
        Log.e("fetchFamilyApps", "fetchFamilyApps")

        remoteConfig.setConfigSettingsAsync(
            FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(0)
                .build()
        )
        remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)
        // Fetch the remote config
        remoteConfig.fetchAndActivate().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                try {
                    //familyApps
                    val jsonArrayString = remoteConfig.getString("familyApps")
                    val jsonArrayString1 = "{\n" +
                            "\"isNeedToShow\": true,\n" +
                            "\"data\": [\n" +
                            "{\n" +
                            "\"app_name\": \"Video Downloader for All\",\n" +
                            "\"short_description\": \"Video Downloader for All\",\n" +
                            "\"app_image_link\":\"https://play-lh.googleusercontent.com/1jfO2cBw4sLb-cDK3_b3-xsELyfaGuakxK7BvC69CZJFIHezdyJBP48fGCc6Y-oS81U=s64-rw\",\n" +
                            "\"app_package_name\": \"com.fastflow.smartdownload.manager\",\n" +
                            "\"app_playstore_link\":\n" +
                            "\"https://play.google.com/store/apps/details?id=com.fastflow.smartdownload.manager\"\n" +
                            "},{\n" +
                            "\"app_name\": \"Bank Balance Statement Check\",\n" +
                            "\"short_description\": \"Bank Balance Statement Check\",\n" +
                            "\"app_image_link\":\"https://play-lh.googleusercontent.com/LS8cnmkzPFXXdMJ-NPYTynVeo1yy5p24seS3Ow9ZpRj5pZi0W0QK4MA2gcdrZkC8lITa=s64-rw\",\n" +
                            "\"app_package_name\": \"com.bankbalanceinquiry.ministatement\",\n" +
                            "\"app_playstore_link\":\n" +
                            "\"https://play.google.com/store/apps/details?id=com.bankbalanceinquiry.ministatement\"\n" +
                            "},{\n" +
                            "\"app_name\": \"HD Video Music Player\",\n" +
                            "\"short_description\": \"HD Video Music Player\",\n" +
                            "\"app_image_link\":\"https://play-lh.googleusercontent.com/ca8nbtuEjPbNm-lhDTvGAuuK-lv_Uif17_eBWb6yRFE142bqkdSEAQY1rLqr5SbvaA=s64-rw\",\n" +
                            "\"app_package_name\": \"com.mediaplayer.video.player.videoplayer.music\",\n" +
                            "\"app_playstore_link\":\n" +
                            "\"https://play.google.com/store/apps/details?id=com.mediaplayer.video.player.videoplayer.music\"\n" +
                            "},{\n" +
                            "\"app_name\": \"QR - Barcode Scan and Create\",\n" +
                            "\"short_description\": \"QR - Barcode Scan and Create\",\n" +
                            "\"app_image_link\":\"https://play-lh.googleusercontent.com/-po-K23Daoq_u0GIkLtF57sJYoPejAjSdSnj2fyYuEyslM6mHpIZj71eI8EZfVVDBNQ=s64-rw\",\n" +
                            "\"app_package_name\": \"com.qr.barcode.scanner.shivayapps\",\n" +
                            "\"app_playstore_link\":\n" +
                            "\"https://play.google.com/store/apps/details?id=com.qr.barcode.scanner.shivayapps\"\n" +
                            "}\n" +
                            "]\n" +
                            "}"
                    Log.e("fetchFamilyApps", "jsonArrayString:$jsonArrayString")

                    val jsonObjFamily = JSONObject(jsonArrayString)

//                    GalleryApp.familyAppStatus = jsonObjFamily.getBoolean("isNeedToShow")
//                    Log.e("fetchFamilyApps", "familyAppStatus:${GalleryApp.familyAppStatus}")

                    val jsonArray = jsonObjFamily.getJSONArray("data")
                    Log.e("fetchFamilyApps", "jsonArray:${jsonArray}")

                    appList.clear()

                    for (i in 0 until jsonArray.length()) {

                        val appName = jsonArray.getJSONObject(i).getString("app_name")
                        val shortDescription =
                            jsonArray.getJSONObject(i).getString("short_description")
                        val appImageLink = jsonArray.getJSONObject(i).getString("app_image_link")
                        val appPackageName =
                            jsonArray.getJSONObject(i).getString("app_package_name")
                        val appPlayStoreLink =
                            jsonArray.getJSONObject(i).getString("app_playstore_link")

                        if (appPackageName != "com.fastflow.smartdownload.manager") {

                            val model = FamilyAppsModel(
                                appName = appName,
                                shortDescription = shortDescription,
                                appImageLink = appImageLink,
                                appPackageName = appPackageName,
                                appPlayStoreLink = appPlayStoreLink
                            )

                            appList.add(model)
                        }
                    }

                    Log.e("fetchFamilyApps", "familyAppList.size:${appList.size}")

                } catch (e: Exception) {
                    Log.d("fetchFamilyApps", "Exception:${e.message}")
                } finally {
                    initFamilyApps()
                }
            } else {
                Log.d("fetchFamilyApps", "Failed:${task.exception}")
            }
        }
    }

    lateinit var adapter: FamilyAppsAdapter
    var appList = ArrayList<FamilyAppsModel>()
    private fun initFamilyApps() {
//        appList.addAll(GalleryApp.familyAppList)
        Log.e("fetchFamilyApps", "FamilyAppActivity.size:${appList.size}")
        binding.recyclerView.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        adapter = FamilyAppsAdapter(this@FamilyAppActivity,
            appList,
            clickListener = { pos ->
                val link = appList[pos].appPlayStoreLink
                val i = Intent(Intent.ACTION_VIEW)
                i.data = Uri.parse(link)
                AdsConfig.isSystemDialogOpen = true
                startActivity(i)
            })
        binding.recyclerView.adapter = adapter

    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
//        binding.llDarkMode.setOnClickListener {
//            val builder = AlertDialog.Builder(this, R.style.CustomAlertDialog).create()
//            val themeDialogLayoutBinding: ThemeDialogLayoutBinding =
//                ThemeDialogLayoutBinding.inflate(LayoutInflater.from(this))
//            builder.setView(themeDialogLayoutBinding.root)
//            when (themeValue) {
//                0 -> {
//                    setThemeLayout(themeDialogLayoutBinding.ivLight, themeDialogLayoutBinding, 0)
//                }
//                1 -> {
//                    setThemeLayout(themeDialogLayoutBinding.ivDark, themeDialogLayoutBinding, 1)
//                }
//                else -> {
//                    setThemeLayout(themeDialogLayoutBinding.ivLight, themeDialogLayoutBinding, 0)
//                }
//            }
//            themeDialogLayoutBinding.ivLight.setOnClickListener {
//                setThemeLayout(themeDialogLayoutBinding.ivLight, themeDialogLayoutBinding, 0)
//            }
//            themeDialogLayoutBinding.ivDark.setOnClickListener {
//                setThemeLayout(themeDialogLayoutBinding.ivDark, themeDialogLayoutBinding, 1)
//            }
//            themeDialogLayoutBinding.ivDefault.setOnClickListener {
//                setThemeLayout(themeDialogLayoutBinding.ivDefault, themeDialogLayoutBinding, 0)
//            }
//            themeDialogLayoutBinding.tvCancel.setOnClickListener {
//                builder.dismiss()
//            }
//
//            themeDialogLayoutBinding.tvOk.setOnClickListener {
//                builder.dismiss()
//                if (themeValue != Preferences(this).getThemeValue()) {
//                    Preferences(this).putTheme(themeValue)
//                    if (themeValue == 0) {
//                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
//                    } else {
//                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
//                    }
//                    val intent = Intent(this, SettingActivity::class.java)
//                    setResult(RESULT_OK)
//                    finish()
//                    overridePendingTransition(0, 0)
//                    startActivity(intent)
//                    overridePendingTransition(0, 0)
//                }
//            }
//            builder.show()
//        }


    }


    private fun inits() {
        themeValue = Preferences(this).getThemeValue()
        binding.loutToolbar.txtTitle.text = "More from us"
    }

    private fun setThemeLayout(
        selectImage: ImageView,
        themeBinding: ThemeDialogLayoutBinding,
        themeInt: Int,
    ) {
        themeBinding.ivDark.setImageResource(R.drawable.ic_un_select)
        themeBinding.ivLight.setImageResource(R.drawable.ic_un_select)
        themeBinding.ivDefault.setImageResource(R.drawable.ic_un_select)
        selectImage.setImageResource(R.drawable.ic_select)
        themeValue = themeInt
    }

    private fun startReviewFlow() {
        if (reviewInfo != null) {
            val flow: Task<Void> = reviewManager!!.launchReviewFlow(this, reviewInfo!!)
            flow.addOnCompleteListener {
                Toast.makeText(
                    applicationContext,
                    getString(R.string.Rating_complete),
                    Toast.LENGTH_LONG
                ).show()
            }
        } else {
            Toast.makeText(applicationContext, getString(R.string.Rating_failed), Toast.LENGTH_LONG)
                .show()
        }
    }
}