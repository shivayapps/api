package com.fastflow.smartdownload.manager.browser.event

data class DownloadUpdateEvent(var deletePath: String)
