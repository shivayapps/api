package com.fastflow.smartdownload.manager

import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.util.DisplayMetrics
import android.util.Log
import android.util.Patterns
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.appcompat.app.AppCompatActivity
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd
//import com.ads.module.open.AdconfigApplication
import com.fastflow.smartdownload.manager.ui.activity.BrowserActivity
import com.fastflow.smartdownload.manager.ui.activity.HomeActivity
import com.fastflow.smartdownload.manager.ui.activity.StartActivity
import com.fastflow.smartdownload.manager.ui.activity.WebBrowserActivity
import com.fastflow.smartdownload.manager.ui.activity.option.BrowserDownloadActivity
import com.fastflow.smartdownload.manager.ui.activity.option.InstagramActivity
import com.fastflow.smartdownload.manager.utils.Constant
import com.fastflow.smartdownload.manager.utils.MyApplication
import com.fastflow.smartdownload.manager.utils.Preferences
import com.fastflow.smartdownload.manager.utils.UtilsAd

class SplashActivity : AppCompatActivity() {

    lateinit var preferences: Preferences
    var themeType = 0

    private lateinit var countDownTimer: CountDownTimer
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        if (MyApplication.isAppIsRunning) {
//            AdconfigApplication.adConfigFinishAffinity()
//        }else
//            MyApplication.isAppIsRunning = true
        requestedOrientation =
            if (Build.VERSION.SDK_INT < 9) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
//        MyApplication.disabledOpenAds()
        Log.e("", "SplashActivity open")
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        themeType = Preferences(this).getThemeValue()
        setAppTheme()
        setContentView(R.layout.activity_splash)

        intiView()
    }
    private fun initAdSize() {
        val display = windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val widthPixels = outMetrics.widthPixels.toFloat()

        val density = outMetrics.density
        val adWidth = (widthPixels / density).toInt()

        AdsParameters(this@SplashActivity).adWidth = adWidth
    }

    private fun createTimerSec() {

        val totalTimeMillis = if (MyApplication.isAdsEnable) 6 else 2

        countDownTimer = object : CountDownTimer(totalTimeMillis * 1000L, 1000) {

            override fun onTick(l: Long) {

            }

            override fun onFinish() {
                gotoMainScreen()
            }
        }
        countDownTimer.start()
    }

    private fun gotoMainScreen() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
    }

    private fun setAppTheme() {
        when (themeType) {
            0 -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }

            1 -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
        }
    }

    private fun intiView() {
        initAdSize()
        preferences = Preferences(this)
        val action = intent.action
        var url: String = ""

        if (intent.data != null && intent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY == 0) {
            Log.e("SPLASHTAG", "LAUNCHED_FROM_HISTORY")
            if (action == Intent.ACTION_VIEW) {
                MyApplication.disabledOpenAds()
                url = intent.data.toString()
                intent.replaceExtras(Bundle())
                intent.action = ""
                intent.data = null
                intent.flags = 0
                val intent = Intent(this, WebBrowserActivity::class.java)
                intent.putExtra("Url", url)
                startActivity(intent)
            } else
                openToSplash()
        } else {
            openToSplash()
        }
    }

    private fun openToSplash() {
        Log.e("SPLASHTAG", "LAUNCHED NORMAL")
        if (!preferences.isStar()) {
            startActivity(Intent(this, StartActivity::class.java))
        } else {
            val mainIntent = Intent(this, HomeActivity::class.java)
            createTimerSec()
            if (MyApplication.isAdsEnable) {
                val AdmobAppOpenId = getString(R.string.open_all)
                OpenAdHelper.loadOpenAdId(this, {
                    countDownTimer.cancel()
                    isShowOpenAd(
                        { isLoaded ->//onAdClosed
                            startActivity(mainIntent)
                        }
                    )
                }, AdmobAppOpenId)
            }
        }
//        splashAPICalling(
//            intent,
//            if (BuildConfig.DEBUG) "com.testing.json" else "${BuildConfig.APPLICATION_ID}.json",
//            BuildConfig.VERSION_NAME
//        )
    }

//    private fun nextScreen(): Intent {
//        return if (!preferences.isStar())
//            Intent(this, StartActivity::class.java)
////        else if (!checkNotificationPermissions())
////            Intent(
////                this,
////                PermissionActivity::class.java
////            ).putExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, true)
//        else
//            Intent(this, HomeActivity::class.java)
//    }

    override fun onBackPressed() {
        finishAffinity()
//        AdconfigApplication.adConfigFinishAffinity()
    }

    private fun shareOpen() {
        val action = intent.action
        val type = intent.type
        Log.e("shareOpen", "action===>> $action  type===>> $type")
        if (Intent.ACTION_SEND == action && type != null) {
            val url = intent.getStringExtra(Intent.EXTRA_TEXT)
            Log.e("", "ShareActivity Link:::url  $url")
            if (type.startsWith("text/") && url != null) {
                if (url.isValidUrl()) {
                    if (url.contains("instagram.com")) {
                        if ((url.contains("www.instagram.com/p/") || url.contains("www.instagram.com/reel/")) && preferences.isLoginInstagram()) {
                            // link to paste screen
                            openShareToScreen(
                                Intent(
                                    this,
                                    InstagramActivity::class.java
                                ).putExtra(Constant.EXTRA_TYPE, Constant.DOWNLOAD_INSTAGRAM)
                                    .putExtra(Constant.EXTRA_IS_OPEN_TO_SHARE, true)
                                    .putExtra(Constant.PUT_KEY_URL, url)
                            )

                        } else {
                            // insta Browser
                            openShareToScreen(
                                Intent(
                                    this,
                                    BrowserDownloadActivity::class.java
                                ).putExtra(
                                    Constant.PUT_KEY_URL,
                                    url
                                )
                                    .putExtra(
                                        Constant.EXTRA_TYPE, Constant.TYPE_Insta
                                    )
                            )
                        }
                    } else if (url.contains("facebook") || url.contains("facebook.com") || url.contains(
                            "fb.watch"
                        )
                    ) {
                        // fb Browser
                        openShareToScreen(
                            Intent(
                                this,
                                BrowserDownloadActivity::class.java
                            ).putExtra(
                                Constant.PUT_KEY_URL,
                                url
                            )
                                .putExtra(
                                    Constant.EXTRA_TYPE, Constant.TYPE_FB
                                )
                        )
                    } else if (url.contains("twitter.com")) {
                        // twitter
                        openShareToScreen(
                            Intent(
                                this,
                                InstagramActivity::class.java
                            ).putExtra(Constant.EXTRA_TYPE, Constant.DOWNLOAD_TWITTER)
                                .putExtra(Constant.EXTRA_IS_OPEN_TO_SHARE, true)
                                .putExtra(Constant.PUT_KEY_URL, url)
                        )
                    } else {
                        // open default Browser
                        openShareToScreen(
                            Intent(
                                this,
                                BrowserActivity::class.java
                            ).putExtra(Constant.PUT_KEY_URL, url)
                        )
                    }
                } else
                    appNotSupport()
            } else
                appNotSupport()
        } else
            appNotSupport()
    }

    private fun openShareToScreen(intent: Intent) {
        if (!MyApplication.isOpenHomeScreen) {
            val intents = arrayOf(Intent(this, HomeActivity::class.java), intent)
            startActivities(intents)
        } else
            startActivity(intent)
        finish()
    }

    private fun checkStoragePermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_MEDIA_VIDEO
            ) == PackageManager.PERMISSION_GRANTED
        } else
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
    }

    private fun appNotSupport() {
        Toast.makeText(this, "This url not support!!", Toast.LENGTH_SHORT).show()
        finish()
    }

    fun String.isValidUrl(): Boolean = Patterns.WEB_URL.matcher(this).matches()
}