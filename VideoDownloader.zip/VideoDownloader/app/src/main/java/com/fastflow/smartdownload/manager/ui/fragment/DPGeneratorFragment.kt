package com.fastflow.smartdownload.manager.ui.fragment

import android.graphics.Bitmap
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.fastflow.smartdownload.manager.utils.AppUrl
import com.google.gson.Gson
import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.databinding.FragmentDPGeneratorBinding
import com.fastflow.smartdownload.manager.ui.adapter.DpGeneratorSubCategoryAdapter
import com.fastflow.smartdownload.manager.ui.data.DpGeneratorCategoryList
import com.fastflow.smartdownload.manager.ui.data.DpGeneratorCategoryResponse
import com.fastflow.smartdownload.manager.ui.data.DpGeneratorSubCategoryItem
import com.fastflow.smartdownload.manager.ui.data.DpGeneratorSubCategoryResponse
import com.fastflow.smartdownload.manager.utils.Utils
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream


private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class DPGeneratorFragment(
    val changeDataListener: (pos: Int, subList: ArrayList<DpGeneratorSubCategoryItem>) -> Unit,
    val nextScreenListener: (mainPos: Int, childPos: Int) -> Unit
) :
    Fragment() {

    lateinit var binding: FragmentDPGeneratorBinding
    private var position: Int = 0
    private var categoryData: DpGeneratorCategoryList? = null
    var subList = ArrayList<DpGeneratorSubCategoryItem>()
    lateinit var call: Call<DpGeneratorSubCategoryResponse>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            position = it.getInt(ARG_PARAM1)
            val param2 = it.getString(ARG_PARAM2)
            val gson = Gson()
            categoryData = gson.fromJson(param2, DpGeneratorCategoryList::class.java)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentDPGeneratorBinding.inflate(layoutInflater, container, false)
        intView()
        return binding.root
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::call.isInitialized && call.isExecuted) {
            call.cancel()
        }
    }

    private fun intView() {
        binding.recyclerView.layoutManager = GridLayoutManager(requireActivity(), 4)
        subList = ArrayList<DpGeneratorSubCategoryItem>()
        if (!categoryData?.subList.isNullOrEmpty()) {
            categoryData?.subList?.let { subList.addAll(it) }
        }

        if (subList.isNotEmpty()) {
            finishLoading()
            setSubCategoryAdapter()
        } else if (Utils.isNetworkAvailable(requireActivity())) {
            getSubCategoryList()
        } else {
            binding.tvNoInternet.visibility = View.VISIBLE
            binding.tvNoData.visibility = View.GONE
            binding.recyclerView.visibility = View.GONE
            finishLoading()
        }
    }

    private fun setSubCategoryAdapter() {
        if (requireActivity() != null) {
            binding.recyclerView.visibility = View.VISIBLE
            val subCategoryAdapter =
                DpGeneratorSubCategoryAdapter(requireActivity(), subList, clickListener = {
                    nextScreenListener(position, it)
                })
            binding.recyclerView.adapter = subCategoryAdapter
        }
    }


    private fun startLoading() {
        binding.loutLoading.visibility = View.VISIBLE
    }

    private fun finishLoading() {
        binding.loutLoading.visibility = View.GONE
    }


    fun readJSONFromAsset(name: String): String? {
        var json: String? = null
        try {
            val inputStream: InputStream = requireActivity().assets.open("hashtag/${name}.json")
            json = inputStream.bufferedReader().use { it.readText() }
        } catch (ex: Exception) {
            ex.printStackTrace()
            return null
        }
        return json
    }

    fun parseJSON(name: String): DpGeneratorSubCategoryResponse {
        return Gson().fromJson(readJSONFromAsset(name), DpGeneratorSubCategoryResponse::class.java)
    }

    private fun getSubCategoryList() {
        startLoading()
        val id = categoryData?.id ?: 1

//        call =
//            RetrofitClient3.instance!!.myApi.getSubCategoryList(AppUrl().dpGeneratorSubcategoryListENDURL() + id)
//        Log.e("DpGeneratorResponse.002", "getSubCategoryList===>https://apidpframe.appomania.co.in/api/${AppUrl().dpGeneratorSubcategoryListENDURL() + id}<===")

//        call.enqueue(object : Callback<DpGeneratorSubCategoryResponse> {
//            override fun onResponse(
//                call: Call<DpGeneratorSubCategoryResponse>,
//                response: Response<DpGeneratorSubCategoryResponse>
//            ) {
//        if (requireActivity() != null)
        if (!requireActivity().isFinishing) {
            val response = parseJSON("subcategory_${id}")
            val list: DpGeneratorSubCategoryResponse = response
            if (categoryData!!.subList.isNullOrEmpty())
                categoryData!!.subList = ArrayList()
            else
                categoryData!!.subList.clear()
            subList.addAll(list)
            categoryData!!.subList.addAll(list)
            finishLoading()
            setSubCategoryAdapter()
            changeDataListener(position, subList)
        }
//            }
//
//            override fun onFailure(call: Call<DpGeneratorSubCategoryResponse>, t: Throwable) {
//                try {
//                    if (requireActivity() != null)
//                        if (!requireActivity().isFinishing) {
//                            finishLoading()
//                            Toast.makeText(
//                                requireActivity(),
//                                getString(R.string.download_fail_msg),
//                                Toast.LENGTH_SHORT
//                            ).show()
//                        }
//                } catch (e: Exception) {
//                    e.printStackTrace()
//                }
//            }
//        })
    }

    companion object {
        @JvmStatic
        fun newInstance(
            param1: Int,
            param2: DpGeneratorCategoryList,
            changeDataListener: (pos: Int, subList: ArrayList<DpGeneratorSubCategoryItem>) -> Unit,
            nextScreenListener: (mainPos: Int, childPos: Int) -> Unit
        ) =
            DPGeneratorFragment(changeDataListener, nextScreenListener).apply {
                val gson = Gson()
                val jsonInString = gson.toJson(param2)
                arguments = Bundle().apply {
                    putInt(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, jsonInString)
                }
            }
    }
}