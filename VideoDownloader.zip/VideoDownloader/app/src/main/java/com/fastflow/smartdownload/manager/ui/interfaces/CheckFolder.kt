package com.fastflow.smartdownload.manager.ui.interfaces

interface CheckFolder {
    fun dataEmpty()
}