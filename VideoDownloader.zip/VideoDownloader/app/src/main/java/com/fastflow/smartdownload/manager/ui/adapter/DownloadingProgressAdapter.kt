package com.fastflow.smartdownload.manager.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.fastflow.smartdownload.manager.R
import com.fastflow.smartdownload.manager.databinding.ItemDownloadingBinding
import com.fastflow.smartdownload.manager.ui.data.DownloadData
import com.fastflow.smartdownload.manager.utils.Constant

class DownloadingProgressAdapter(
    var context: Context,
    var downloadingList: ArrayList<DownloadData>,
) :
    RecyclerView.Adapter<DownloadingProgressAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemDownloadingBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return downloadingList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.txtFileName.text =
            downloadingList[position].posterId + if (downloadingList[position].fileType == Constant.TYPE_IMAGE) ".png" else ".mp4"
        holder.binding.txtPer.text = "${downloadingList[position].progress}%"
        holder.binding.progressBar.progress = downloadingList[position].progress

        holder.binding.imageType.setImageDrawable(
            ContextCompat.getDrawable(
                context,
                if (downloadingList[position].fileType == Constant.TYPE_IMAGE) R.drawable.ic_image else R.drawable.ic_video
            )
        )
    }

    class ViewHolder(var binding: ItemDownloadingBinding) :
        RecyclerView.ViewHolder(binding.root) {

    }
}