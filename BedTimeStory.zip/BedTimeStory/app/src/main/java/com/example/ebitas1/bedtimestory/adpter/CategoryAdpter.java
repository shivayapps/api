package com.example.ebitas1.bedtimestory.adpter;

import android.content.Context;
import androidx.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.ebitas1.bedtimestory.R;
import com.example.ebitas1.bedtimestory.model.Category;

import java.util.List;

public class CategoryAdpter extends RecyclerView.Adapter<CategoryAdpter.CustomViewHolder> {

    private List<Category> mListCategory;
    private Context mContext;
    int[] imageViews = {R.drawable.backgroundone, R.drawable.backgroundtwo, R.drawable.backgroundthree, R.drawable.backgroundfour,
            R.drawable.backgroundfive, R.drawable.backgroundsix};


    public CategoryAdpter(List<Category> mListCategory, Context mContext) {
        this.mListCategory = mListCategory;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        View view = layoutInflater.inflate(R.layout.row_layout_main, null, false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder viewHolder, final int pos) {
        Category c = mListCategory.get(pos);
        viewHolder.mCatName.setText(c.getCatName());
        int currentPoi = pos;
        viewHolder.mRelative.setBackgroundResource(imageViews[currentPoi]);

     /*   if(pos==mListCategory.size()-1)
        {
            viewHolder.mLinear.setVisibility(View.VISIBLE);
        }
        else
        {
            viewHolder.mLinear.setVisibility(View.GONE);
        }
*/
    }

    @Override
    public int getItemCount() {
        return mListCategory.size();
    }


    public class CustomViewHolder extends RecyclerView.ViewHolder {

        private ImageView mCatIcon;
        private TextView mCatName;
        private RelativeLayout mRelative;
        private LinearLayout mLinear;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);

            mCatName = (TextView) itemView.findViewById(R.id.catname);
            mRelative = (RelativeLayout) itemView.findViewById(R.id.relative);
            mLinear = (LinearLayout) itemView.findViewById(R.id.linear_icon);
        }
    }

}
