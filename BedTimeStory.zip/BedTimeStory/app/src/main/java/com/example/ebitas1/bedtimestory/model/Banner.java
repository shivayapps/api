package com.example.ebitas1.bedtimestory.model;

/**
 * Awesome Pojo Generator
 */
public class Banner {

    private String banner_color;

    private Integer is_clickable;

    private String image_url;

    private String banner_text;

    private String link;

    private String last_modified_date;

    private Integer offer_inapp_id;

    private String id;

    private String text_color;

    private String type;

    private Integer redirection;

    private Integer multi_enable;

    public Banner() {
    }

    public Banner(String id) {
        this.id = id;
    }


    public Banner(String id, String banner_text, String banner_color, String text_color) {
        this.banner_color = banner_color;
        this.banner_text = banner_text;
        this.last_modified_date = last_modified_date;
        this.text_color = text_color;
        this.id = id;

    }

    public Banner(String banner_color, Integer is_clickable, String image_url, String banner_text, String link, String last_modified_date, Integer offer_inapp_id, String id, String text_color, String type, Integer redirection, Integer multi_enable) {
        this.banner_color = banner_color;
        this.is_clickable = is_clickable;
        this.image_url = image_url;
        this.banner_text = banner_text;
        this.link = link;
        this.last_modified_date = last_modified_date;
        this.offer_inapp_id = offer_inapp_id;
        this.id = id;
        this.text_color = text_color;
        this.type = type;
        this.redirection = redirection;
        this.multi_enable = multi_enable;
    }

    public void setBanner_color(String banner_color) {
        this.banner_color = banner_color;
    }

    public String getBanner_color() {
        return banner_color;
    }

    public void setIs_clickable(Integer is_clickable) {
        this.is_clickable = is_clickable;
    }

    public Integer getIs_clickable() {
        return is_clickable;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setBanner_text(String banner_text) {
        this.banner_text = banner_text;
    }

    public String getBanner_text() {
        return banner_text;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getLink() {
        return link;
    }

    public void setLast_modified_date(String last_modified_date) {
        this.last_modified_date = last_modified_date;
    }

    public String getLast_modified_date() {
        return last_modified_date;
    }

    public void setOffer_inapp_id(Integer offer_inapp_id) {
        this.offer_inapp_id = offer_inapp_id;
    }

    public Integer getOffer_inapp_id() {
        return offer_inapp_id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setText_color(String text_color) {
        this.text_color = text_color;
    }

    public String getText_color() {
        return text_color;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setRedirection(Integer redirection) {
        this.redirection = redirection;
    }

    public Integer getRedirection() {
        return redirection;
    }

    public void setMulti_enable(Integer multi_enable) {
        this.multi_enable = multi_enable;
    }

    public Integer getMulti_enable() {
        return multi_enable;
    }
}