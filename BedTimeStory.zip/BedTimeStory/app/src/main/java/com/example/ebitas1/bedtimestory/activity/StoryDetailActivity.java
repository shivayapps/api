package com.example.ebitas1.bedtimestory.activity;

import android.support.design.widget.Snackbar;
import androidx.core.app.Fragment;
import androidx.core.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ebitas1.bedtimestory.R;
import com.example.ebitas1.bedtimestory.adpter.FragmentPagerAdapter;
import com.example.ebitas1.bedtimestory.database.DatabaseHelper;
import com.example.ebitas1.bedtimestory.model.BedTimeStory;
import com.example.ebitas1.bedtimestory.utill.CommonMethod;
import com.example.ebitas1.bedtimestory.utill.ConnectionDetector;
import com.example.ebitas1.bedtimestory.utill.Constant;
import com.example.ebitas1.bedtimestory.utill.SharedprefrenceClass;
import com.example.ebitas1.bedtimestory.viewPagerList.PageTransformer;
import com.example.ebitas1.bedtimestory.viewPagerList.SwipeFragment;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.NativeAppInstallAd;
import com.google.android.gms.ads.formats.NativeAppInstallAdView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class StoryDetailActivity extends AppCompatActivity implements View.OnClickListener {

    private RelativeLayout mRelativeRoot;
    private ConnectionDetector mConnectionDetector;
    private LinearLayout mLinearNativeAds;
    private ViewPager mViewPager;
    private int pos;
    private List<BedTimeStory> mStoryList;
    DatabaseHelper mDatabaseHelper;
    FragmentPagerAdapter fragmentPagerAdapter;
    private int miFontSize;
    private SharedprefrenceClass sharedprefrenceClass;

    private boolean isFontPlus = false;
    private boolean isFontMinus = false;


    public LinearLayout mFontPlus, mFontMinus;
    public ImageView mImgFontPlus;
    public ImageView mImgFontMinus;


    private ImageView mImgFav;

    public CardView mCardView;
    private Fragment fragment;
    LinearLayout linearLayout, linearfavLayout;
    View v;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_detail);


        initActionBar();
        init();
    }


    private void initActionBar() {
        this.getSupportActionBar().setDisplayShowCustomEnabled(true);
        this.getSupportActionBar().setDisplayShowTitleEnabled(false);
        final LayoutInflater inflator = LayoutInflater.from(this);
        v = inflator.inflate(R.layout.custom_title_view2, null);

        mImgFav = (ImageView) v.findViewById(R.id.img_icon4);

        linearLayout = ((LinearLayout) v.findViewById(R.id.linear_img1));
        linearLayout.setVisibility(View.VISIBLE);


        linearfavLayout = ((LinearLayout) v.findViewById(R.id.linea_fav));
        linearfavLayout.setVisibility(View.VISIBLE);

        this.getSupportActionBar().setCustomView(v);
        Toolbar parent = (Toolbar) v.getParent();
        parent.setPadding(3, 0, 0, 0);//for tab otherwise give space in tab
        parent.setContentInsetsAbsolute(0, 0);

    }

    public void customTitleView(final int pos) {


        ((TextView) v.findViewById(R.id.action_title1)).setText(mStoryList.get(pos).getStory_name());

      /*  LinearLayout linearfontLayout = ((LinearLayout) v.findViewById(R.id.linear_textchange));
        linearfontLayout.setVisibility(View.VISIBLE);
        linearfontLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCardView.getVisibility() == View.VISIBLE) {
                    mCardView.setVisibility(View.GONE);
                } else {
                    mCardView.setVisibility(View.VISIBLE);
                }
            }
        });


        LinearLayout linearShareLayout = ((LinearLayout) v.findViewById(R.id.linear_share));
        linearShareLayout.setVisibility(View.VISIBLE);
        linearShareLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  onBackPressed();
            }
        });

*/

    }


    private void init() {
        mStoryList = new ArrayList<>();
        mRelativeRoot = (RelativeLayout) findViewById(R.id.relative);
        mLinearNativeAds = (LinearLayout) findViewById(R.id.linear_ads);
        mViewPager = (ViewPager) findViewById(R.id.pager);

        mCardView = (CardView) findViewById(R.id.cardView);
        mFontMinus = (LinearLayout) findViewById(R.id.font_minus);
        mFontPlus = (LinearLayout) findViewById(R.id.font_plus);


        mConnectionDetector = new ConnectionDetector();
        sharedprefrenceClass = SharedprefrenceClass.getInstance(this);
        Bundle b = getIntent().getExtras();

        if (b.containsKey(Constant.POS)) {
            pos = b.getInt(Constant.POS, 0);

            mDatabaseHelper = new DatabaseHelper(StoryDetailActivity.this);


            File database = getApplicationContext().getDatabasePath(DatabaseHelper.DB_name);
            if (false == database.exists()) {
                mDatabaseHelper.getReadableDatabase();
                mDatabaseHelper.copyDatabase(this);
            }

            fragment = getSupportFragmentManager().findFragmentByTag("android:switcher:" + R.id.pager + ":" + mViewPager.getCurrentItem());
            if (mViewPager.getCurrentItem() == pos && fragment != null) {
                //((SwipeFragment) fragment).loadSlokDataInTextView1(miPosition);
            }
        }
        pos = b.getInt(Constant.POS, 0);

        Log.e("POS", ":::POS:::" + pos);
        //mStoryList.addAll(mDatabaseHelper.getlist_story());
        mStoryList = mDatabaseHelper.getlist_story();

        mImgFontMinus = (ImageView) findViewById(R.id.imgfontminus);
        mImgFontPlus = (ImageView) findViewById(R.id.imgfontplus);

        CommonMethod.toastMsg(this, "" + mStoryList.get(pos).getIs_fav());

        setUpView();
        onClickEvents();
        setFontSize(pos);
        customTitleView(pos);
        setFavoriteData(pos);

    }


    private void onClickEvents() {
        mFontPlus.setOnClickListener(this);
        mFontMinus.setOnClickListener(this);
        linearLayout.setOnClickListener(this);
        linearfavLayout.setOnClickListener(this);
    }

    private void hidecard() {
        if (mCardView.getVisibility() == View.VISIBLE) {
            mCardView.setVisibility(View.GONE);
        }
    }

    private void setUpView() {
        fragmentPagerAdapter = new FragmentPagerAdapter(getSupportFragmentManager(), mStoryList);
        mViewPager.setPageTransformer(false, new PageTransformer());
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int currentpage, float v, int i1) {

                //CommonMethod.toastMsg(StoryDetailActivity.this, "" + currentpage);
                pos = currentpage;
                //Log.e("_------------", "" + pos);
                //customTitleView();
            }

            @Override
            public void onPageSelected(int pos) {

                hidecard();
                setFontSize(pos);
                customTitleView(pos);
                setFavoriteData(pos);
                fragment = getSupportFragmentManager().findFragmentByTag("android:switcher:" + R.id.pager + ":" + mViewPager.getCurrentItem());

            }

            @Override
            public void onPageScrollStateChanged(int i) {
            }
        });
        mViewPager.invalidate();
        mViewPager.setAdapter(fragmentPagerAdapter);


    }

    public void setFavoriteData(int pos) {
        if (mStoryList.get(pos).getIs_fav() == 1) {
            mImgFav.setImageResource(R.drawable.ic_fill_favorite);
        } else {
            mImgFav.setImageResource(R.drawable.ic_un_favorite);
        }
    }

    private void setFontSize(int pos) {

        miFontSize = sharedprefrenceClass.getInteger(StoryDetailActivity.this, Constant.FONT_SIZE, 16);
        isFontPlus = sharedprefrenceClass.getBoolean(StoryDetailActivity.this, Constant.IS_FONT_BIG, false);
        isFontMinus = sharedprefrenceClass.getBoolean(StoryDetailActivity.this, Constant.IS_FONT_SMALL, false);
        if (isFontPlus == true) {
            mImgFontPlus.setImageResource(R.drawable.ic_fill_font_plus);

        } else {
            mImgFontPlus.setImageResource(R.drawable.ic_font_plus);
        }
        if (isFontMinus == true) {
            mImgFontMinus.setImageResource(R.drawable.ic_fill_font_minus);
        } else {
            mImgFontMinus.setImageResource(R.drawable.ic_font_minus);
        }

        fragment = getSupportFragmentManager().findFragmentByTag("android:switcher:" + R.id.pager + ":" + mViewPager.getCurrentItem());
        if (mViewPager.getCurrentItem() == pos && fragment != null) {
            ((SwipeFragment) fragment).setFontSize(miFontSize);
        }
    }

    public void setFontIcon(int pos) {

        fragment = getSupportFragmentManager().findFragmentByTag("android:switcher:" + R.id.pager + ":" + mViewPager.getCurrentItem());
        if (mViewPager.getCurrentItem() == pos && fragment != null) {
            ((SwipeFragment) fragment).setFontSize(miFontSize);
        }
    }


    //Native Ads
    private void refreshAd(boolean requestAppInstallAds, boolean requestContentAds, final View view) {
        AdLoader.Builder builder = new AdLoader.Builder(StoryDetailActivity.this, getString(R.string.native_ads_id));
        if (requestAppInstallAds) {
            builder.forAppInstallAd(new NativeAppInstallAd.OnAppInstallAdLoadedListener() {
                @Override
                public void onAppInstallAdLoaded(NativeAppInstallAd ad) {
                    NativeAppInstallAdView adView = (NativeAppInstallAdView) getLayoutInflater().inflate(R.layout.partial_native_ads, null);
                    FrameLayout frameLayout = view.findViewById(R.id.framelayout_home_ads);
                    //cardView_home_native_ads = (CardView) view.findViewById(R.id.cardView_home_native_ads);
                    //cardView_home_native_ads.setVisibility(View.VISIBLE);
                    populateAppInstallAdView(ad, adView);
                    frameLayout.removeAllViews();
                    frameLayout.addView(adView);

                }
            });
        }

        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(false)
                .build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new com.google.android.gms.ads.AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
                Log.e("onAdFailedToLoad: ", "" + errorCode);
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void populateAppInstallAdView(NativeAppInstallAd nativeAppInstallAd,
                                          NativeAppInstallAdView adView) {
        VideoController vc = nativeAppInstallAd.getVideoController();


        vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
            public void onVideoEnd() {
                super.onVideoEnd();
            }
        });

        adView.setHeadlineView(adView.findViewById(R.id.appinstall_headline));
        adView.setBodyView(adView.findViewById(R.id.appinstall_body));
        adView.setCallToActionView(adView.findViewById(R.id.appinstall_call_to_action));
        adView.setIconView(adView.findViewById(R.id.appinstall_app_icon));
        adView.setStarRatingView(adView.findViewById(R.id.appinstall_stars));

        // Some assets are guaranteed to be in every NativeAppInstallAd.
        if (nativeAppInstallAd.getHeadline() != null)
            ((TextView) adView.getHeadlineView()).setText(nativeAppInstallAd.getHeadline());

        if (nativeAppInstallAd.getBody() != null)
            ((TextView) adView.getBodyView()).setText(nativeAppInstallAd.getBody());

        if (nativeAppInstallAd.getCallToAction() != null)
            ((Button) adView.getCallToActionView()).setText(nativeAppInstallAd.getCallToAction());

        if (nativeAppInstallAd.getIcon().getDrawable() != null)
            ((ImageView) adView.getIconView()).setImageDrawable(nativeAppInstallAd.getIcon().getDrawable());

        com.google.android.gms.ads.formats.MediaView mediaView = adView.findViewById(R.id.appinstall_media);
        ImageView mainImageView = adView.findViewById(R.id.appinstall_image);


        if (nativeAppInstallAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAppInstallAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }
        // Assign native ad object to the native view.
        adView.setNativeAd(nativeAppInstallAd);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mViewPager.setCurrentItem(pos, true);
        setFavoriteData(pos);

        if (mConnectionDetector.check_internet(this)) {
            mLinearNativeAds = (LinearLayout) findViewById(R.id.linear_ads);
            mLinearNativeAds.setVisibility(View.VISIBLE);
            refreshAd(true, false, mRelativeRoot);

        } else {
            mLinearNativeAds.setVisibility(View.GONE);
        }

    }


    @Override
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.linear_img1:
                finish();
                break;


            case R.id.linea_fav:
                hidecard();
                if (mStoryList.get(pos).getIs_fav() == 0) {
                    long setfavorite = mDatabaseHelper.updateFavoriteData(1, Integer.parseInt(mStoryList.get(pos).getStory_id()));
                    if (setfavorite > 0) {
                        mImgFav.setImageResource(R.drawable.ic_fill_favorite);
                        mStoryList.get(pos).setIs_fav(1);
                        CommonMethod.toastMsg(StoryDetailActivity.this, "Yessssssss" + mStoryList.get(pos).getIs_fav());
                        Snackbar.make(mRelativeRoot, "" + "Add To fav", Snackbar.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Can not Set as a Favorite", Toast.LENGTH_SHORT).show();
                    }
                } else if (mStoryList.get(pos).getIs_fav() == 1) {
                    long setfavorite = mDatabaseHelper.updateFavoriteData(0, Integer.parseInt(mStoryList.get(pos).getStory_id()));
                    if (setfavorite > 0) {
                        mImgFav.setImageResource(R.drawable.ic_un_favorite);
                        mStoryList.get(pos).setIs_fav(0);
                        CommonMethod.toastMsg(StoryDetailActivity.this, "Yessssssss" + mStoryList.get(pos).getIs_fav());

                        Snackbar.make(mRelativeRoot, "" + "Remove From", Snackbar.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Can not Remove as a favorite", Toast.LENGTH_SHORT).show();
                    }

                }
                break;

            case R.id.font_minus:

                miFontSize = sharedprefrenceClass.getInteger(StoryDetailActivity.this, Constant.FONT_SIZE, 16);
                if (miFontSize > 12) {
                    miFontSize--;
                    isFontMinus = true;
                    isFontPlus = false;
                    sharedprefrenceClass.setInteger(StoryDetailActivity.this, Constant.FONT_SIZE, miFontSize);
                    sharedprefrenceClass.setBoolean(StoryDetailActivity.this, Constant.IS_FONT_SMALL, isFontMinus);
                    sharedprefrenceClass.setBoolean(StoryDetailActivity.this, Constant.IS_FONT_BIG, isFontPlus);
                    setFontSize(pos);
                } else {
                    isFontMinus = false;
                    mImgFontMinus.setImageResource(R.drawable.ic_font_minus);
                    sharedprefrenceClass.setBoolean(StoryDetailActivity.this, Constant.IS_FONT_SMALL, isFontMinus);
                    Snackbar.make(view, "" + getResources().getString(R.string.minimum_limit), Snackbar.LENGTH_SHORT).show();
                }


                break;


            case R.id.font_plus:

                miFontSize = sharedprefrenceClass.getInteger(StoryDetailActivity.this, Constant.FONT_SIZE, 16);
                if (miFontSize < 26) {
                    miFontSize++;
                    isFontPlus = true;
                    isFontMinus = false;
                    sharedprefrenceClass.setInteger(StoryDetailActivity.this, Constant.FONT_SIZE, miFontSize);
                    sharedprefrenceClass.setBoolean(StoryDetailActivity.this, Constant.IS_FONT_BIG, isFontPlus);
                    sharedprefrenceClass.setBoolean(StoryDetailActivity.this, Constant.IS_FONT_SMALL, isFontMinus);
                    setFontSize(pos);

                } else {
                    isFontPlus = false;
                    mImgFontPlus.setImageResource(R.drawable.ic_font_plus);
                    sharedprefrenceClass.setBoolean(StoryDetailActivity.this, Constant.IS_FONT_BIG, isFontPlus);
                    Snackbar.make(view, "" + getResources().getString(R.string.maximum_limit), Snackbar.LENGTH_SHORT).show();
                }
                break;

        }

    }
}
