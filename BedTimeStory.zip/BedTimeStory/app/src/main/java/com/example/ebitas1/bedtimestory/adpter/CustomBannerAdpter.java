package com.example.ebitas1.bedtimestory.adpter;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import androidx.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.ebitas1.bedtimestory.R;
import com.example.ebitas1.bedtimestory.model.Banner;
import com.example.ebitas1.bedtimestory.utill.ConnectionDetector;
import com.example.ebitas1.bedtimestory.utill.HelperClass;
import com.example.ebitas1.bedtimestory.utill.SharedprefrenceClass;

import java.util.List;

public class CustomBannerAdpter extends RecyclerView.Adapter<CustomBannerAdpter.CustomViewHolder> {

    private List<Banner> mlistBanner;
    private Context mContext;
    private  RatingBar rating_bar;
    private TextView mTextViewRatingValue;
    private RelativeLayout mRelative;
    private boolean flag1;
    View view;
    AppCompatActivity mactivity;
    private SharedprefrenceClass sharedprefrenceClass;
    private ConnectionDetector mConnectionDetector;

    public CustomBannerAdpter(List<Banner> mlistBanner, Context mContext, AppCompatActivity mactivity) {
        mConnectionDetector=new ConnectionDetector();
        this.mlistBanner = mlistBanner;
        this.mContext = mContext;
        this.mactivity=mactivity;
        sharedprefrenceClass = SharedprefrenceClass.getInstance(mContext);
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater=LayoutInflater.from(mContext);
            view = layoutInflater.inflate(R.layout.row_layout_banner, null, false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final CustomViewHolder customViewHolder, final int i) {

        Banner mBanner=mlistBanner.get(i);
        customViewHolder.mtxtData.setText(mBanner.getBanner_text());
        customViewHolder.mLinearData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
         //       showSayThanksDialog(mactivity.getResources().getString(R.string.say_thanks), mactivity.getResources().getString(R.string.txt_say_thanks),mactivity);

                HelperClass.showRateDialog(mContext);
                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {

                        customViewHolder.mLinearData.setClickable(true);

                    }
                }, 1000);
            }
        });
        customViewHolder.mClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder1 = new AlertDialog.Builder(mactivity);
                builder1.setMessage(R.string.msg);
                builder1.setCancelable(true);

                builder1.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                flag1=true;
                                sharedprefrenceClass.saveCheck("flag", flag1);

                                mlistBanner.remove(i);
                                notifyItemChanged(i);


                            }
                        });

                builder1.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                dialog.cancel();
                            }
                        });

                AlertDialog alert11 = builder1.create();
                alert11.show();

            }
        });
    }

    @Override
    public int getItemCount() {
        return mlistBanner.size();
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder
    {
        private ImageView mClose;
        private TextView mtxtData;
        private LinearLayout mLinearData;
        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);

            mClose=(ImageView) itemView.findViewById(R.id.img_close);
            mLinearData=(LinearLayout) itemView.findViewById(R.id.linear_data);
            mtxtData=(TextView) itemView.findViewById(R.id.txt_banner);
            mRelative=(RelativeLayout) itemView.findViewById(R.id.relative);
        }
    }

    /*private void showSayThanksDialog(String title, String message,Activity activity) {

        final View dialogView = View.inflate(activity, R.layout.dialog_say_thanks, null);
        final AlertDialog mAlertDialog = new AlertDialog.Builder(mContext)
                .setView(dialogView)
                .setCancelable(false)
                .create();

        TextView txt_rate_title = (TextView) dialogView.findViewById(R.id.txt_rate_title);
        TextView buttonPositive = (TextView) dialogView.findViewById(R.id.textview_positive);
        TextView buttonNegative = (TextView) dialogView.findViewById(R.id.textview_negative);
        TextView txt_rate_message = (TextView) dialogView.findViewById(R.id.txt_rate_message);
        mTextViewRatingValue = (TextView) dialogView.findViewById(R.id.textview_rate_app_value);
        rating_bar = (RatingBar) dialogView.findViewById(R.id.rating_bar);

        rating_bar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {

                if (rating_bar.getRating() == 1.0f) {
                    mTextViewRatingValue.setText(mContext.getResources().getString(R.string.rate_app_one_star));
                } else if (rating_bar.getRating() == 2.0f) {
                    mTextViewRatingValue.setText(mContext.getResources().getString(R.string.rate_app_two_star));
                } else if (rating_bar.getRating() == 3.0f) {
                    mTextViewRatingValue.setText(mContext.getResources().getString(R.string.rate_app_three_star));
                } else if (rating_bar.getRating() == 4.0f) {
                    mTextViewRatingValue.setText(mContext.getResources().getString(R.string.rate_app_four_star));
                } else if (rating_bar.getRating() == 5.0f) {
                    mTextViewRatingValue.setText(mactivity.getResources().getString(R.string.rate_app_five_star));
                }
            }
        });
        txt_rate_message.setText(message);
        txt_rate_title.setText(title);
        buttonPositive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (rating_bar.getRating() == 5) {
                    showRateDialog();
                    mAlertDialog.dismiss();
                } else if (rating_bar.getRating() < 5 && rating_bar.getRating() >= 1) {
                    showRateDialog1();
                    mAlertDialog.dismiss();
                } else {
                    Snackbar.make(dialogView, "" + mactivity.getResources().getString(R.string.rate_app_zero_star), Snackbar.LENGTH_SHORT).show();
                }
            }
        });
        buttonNegative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAlertDialog.dismiss();
            }
        });
        mAlertDialog.show();
        Window window = mAlertDialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);

    }
*/
    /*private void showRateDialog1() {

        String versionName;
        PackageInfo pInfo = null;
        try {
            pInfo = mactivity.getPackageManager().getPackageInfo(mactivity.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        versionName = pInfo.versionName;
        String country = "";
        try {
            TelephonyManager tm = (TelephonyManager) mactivity.getSystemService(Context.TELEPHONY_SERVICE);
            String countryCode = tm.getNetworkCountryIso();
            Locale loc = new Locale("", countryCode);
            country = loc.getDisplayCountry();
        } catch (Exception e) {
            e.printStackTrace();
        }

        final String EMAIL = "apps@ebizzinfotech.com";
        final String SUBJECT = "Suggestion/Feedback:" + mactivity.getResources().getString(R.string.app_name);
        final String BODY = "Your Message" + "\n" +
                "Device Information :" + "\n" + mactivity.getResources().getString(R.string.app_name) +"\n"+
                "Version:" + versionName + "\n" +
                "Rating:" +  rating_bar.getRating()+"\n "+
                "Device Name:" + Build.MODEL + "\n" +
                "Android API:" + Build.VERSION.RELEASE + "\n" +
                "Android Version:" + Build.VERSION.SDK_INT + "\n" +
                "Country:" + country;

        Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + EMAIL));
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, SUBJECT);
        emailIntent.putExtra(Intent.EXTRA_TEXT, BODY);
        sharedprefrenceClass.saveCheck("flag", true);
        mactivity.startActivity(Intent.createChooser(emailIntent, mactivity.getResources().getString(R.string.rate_app)));

    }

    private void showRateDialog() {
        sharedprefrenceClass.saveCheck("flag", true);
        final String APP_PNAME = mactivity.getPackageName();
        if (mConnectionDetector.check_internet(mactivity)) {
            Intent intent = null;
            try {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("market://details?id=" + APP_PNAME));
                mactivity.startActivity(intent);
            } catch (ActivityNotFoundException e) {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri
                        .parse("https://play.google.com/store/apps/details?id="
                                + APP_PNAME));

                mactivity.startActivity(intent);

            }
        } else {
            Snackbar.make(mRelative, mContext.getResources().getString(R.string.offline_message), Snackbar.LENGTH_LONG).show();
        }

    }*/
}
