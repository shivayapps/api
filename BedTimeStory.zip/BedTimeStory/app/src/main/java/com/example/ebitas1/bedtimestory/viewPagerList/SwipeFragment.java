package com.example.ebitas1.bedtimestory.viewPagerList;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.example.ebitas1.bedtimestory.R;
import com.example.ebitas1.bedtimestory.database.DatabaseHelper;
import com.example.ebitas1.bedtimestory.model.BedTimeStory;
import com.example.ebitas1.bedtimestory.utill.Constant;
import com.example.ebitas1.bedtimestory.utill.SharedprefrenceClass;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class SwipeFragment extends Fragment implements View.OnClickListener {
    int position;
    int fontsize;
    List<BedTimeStory> list;
    View swipeView;
    String storyContent;
    SharedprefrenceClass sharedprefrenceClass;
    TextView mStoryContent;
    LinearLayout mReadData;
    int read;

    TextView mTxtRead;
    ImageView mImgRead;

    int[] imageViews = {R.drawable.backgroundone, R.drawable.backgroundtwo, R.drawable.backgroundthree, R.drawable.backgroundfour,
            R.drawable.backgroundfive, R.drawable.backgroundsix};

    RelativeLayout relativebg;
    DatabaseHelper mDatabaseHelper;

      @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
          list=new ArrayList<>();
          mDatabaseHelper = new DatabaseHelper(getActivity());
          sharedprefrenceClass = SharedprefrenceClass.getInstance(getActivity());
          File database = getActivity().getDatabasePath(DatabaseHelper.DB_name);
          if (false == database.exists()) {
              mDatabaseHelper.getReadableDatabase();
              // Copy database
              mDatabaseHelper.copyDatabase(getContext());
          }


          list=mDatabaseHelper.getlist_story();
        Bundle args = getArguments();
        position = args.getInt("position");
        storyContent = args.getString("content");
        read=args.getInt("readcontent",0);



        //list = args.getParcelableArrayList("array_list");

        // Log.e("ListSizeeeee", "::::ListSize::::" + list.size());


        fontsize = sharedprefrenceClass.getInteger(getContext(), Constant.FONT_SIZE, 16);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        swipeView = inflater.inflate(R.layout.story_details, container, false);
        init(swipeView);
        return swipeView;
    }



    private void init(View view) {
        mStoryContent = (TextView) view.findViewById(R.id.story_content);
        mStoryContent.setText(storyContent);
        relativebg = (RelativeLayout) view.findViewById(R.id.relative);
        mReadData = (LinearLayout) view.findViewById(R.id.linearreadData);
        mImgRead=(ImageView)view.findViewById(R.id.ic_read);
        mTxtRead=(TextView) view.findViewById(R.id.ic_txt_read);
        int currentPoi = position;

        int pindex = 0;

        if (currentPoi >= 6) {
            pindex = currentPoi % 6;
        } else {
            pindex = currentPoi;
        }
        Log.e("pindex", "" + pindex);

        relativebg.setBackgroundResource(imageViews[pindex]);

        onClick();
    }


    private void onClick()
    {
        mReadData.setOnClickListener(this);
    }

    public Fragment newInstance(int position, String listStory,int read) {
        SwipeFragment swipeFragment = new SwipeFragment();
        Bundle args = new Bundle();
        args.putInt("position", position);
        args.putString("content", listStory);
        args.putInt("readcontent",read);
        //args.putParcelableArrayList("array_list", (ArrayList<? extends Parcelable>) listStory);
        swipeFragment.setArguments(args);
        return swipeFragment;
    }

    public void setFontSize(int size) {
        mStoryContent.setTextSize(size);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
           /* case R.id.linearreadData:

                if (list.get(position).getIs_read() == 0) {
                    long setfavorite = mDatabaseHelper.updateMarkASReadData(Integer.parseInt(list.get(position).getStory_id()), 1);
                    if (setfavorite > 0) {
//                        moimgbtnMarkAsRead.setBackgroundResource(R.drawable.red_button);
//                        image_read.setImageResource(R.drawable.ic_unread);
//                        mark_read_textview.setTextColor(getResources().getColor(R.color.colorPrimary));
//                        mark_read_textview.setText(getResources().getString(R.string.markAsUnreadSnackBar));
                        list.get(position).setIs_read(1);
                        setMarkAsReadData(position);
                    }
                } else if (list.get(position).getIs_read() == 1) {
                    long setfavorite = mDatabaseHelper.updateMarkASReadData(Integer.parseInt(list.get(position).getStory_id()), 0);
                    if (setfavorite > 0) {
//                        moimgbtnMarkAsRead.setBackgroundResource(R.drawable.unread_button);
//                        image_read.setImageResource(R.drawable.ic_read);
//                        mark_read_textview.setTextColor(getResources().getColor(R.color.unread));
//                        mark_read_textview.setText(getResources().getString(R.string.markAsReadSnackBar));
                        list.get(position).setIs_read(0);
                        setMarkAsReadData(position);
                    }
                }
                break;*/
        }
    }





    public void setMarkAsReadData(int position) {
        //  1=mark as read
        //  0=mark as unread
        if (list.get(position).getIs_read() == 1) {
            mReadData.setBackgroundColor(getResources().getColor(R.color.colorAccent));
            mImgRead.setImageResource(R.drawable.ic_mark_unread);
            mTxtRead.setTextColor(getResources().getColor(R.color.colorPrimaryDark));
            mTxtRead.setText(getResources().getString(R.string.mark_unread));
        } else {
            mReadData.setBackgroundResource(R.drawable.shaperounded);
            mImgRead.setImageResource(R.drawable.ic_mark_read);
            mTxtRead.setTextColor(getResources().getColor(R.color.colorActionbarText));
            mTxtRead.setText(getResources().getString(R.string.mark_read));

        }
    }

    @Override
    public void onResume() {
        super.onResume();
        setMarkAsReadData(position);
    }
}
