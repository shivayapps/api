package com.example.ebitas1.bedtimestory.utill;

public class Constant {

    public static final String POS = "position";
    public static final String FONT_SIZE = "FontSize";
    public static final String IS_FONT_BIG = "FontBig";
    public static final String IS_FONT_SMALL = "FontSmall";


}
