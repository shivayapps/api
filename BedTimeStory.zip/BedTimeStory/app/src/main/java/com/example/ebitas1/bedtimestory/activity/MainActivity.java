package com.example.ebitas1.bedtimestory.activity;

import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.ebitas1.bedtimestory.R;
import com.example.ebitas1.bedtimestory.adpter.CategoryAdpter;
import com.example.ebitas1.bedtimestory.adpter.CustomBannerAdpter;
import com.example.ebitas1.bedtimestory.model.Banner;
import com.example.ebitas1.bedtimestory.model.Category;
import com.example.ebitas1.bedtimestory.recyclerClick.RecyclerItemClickListener;
import com.example.ebitas1.bedtimestory.utill.CommonMethod;
import com.example.ebitas1.bedtimestory.utill.ConnectionDetector;
import com.example.ebitas1.bedtimestory.utill.HelperClass;
import com.example.ebitas1.bedtimestory.utill.SharedprefrenceClass;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.NativeAppInstallAd;
import com.google.android.gms.ads.formats.NativeAppInstallAdView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    private RelativeLayout mRelativeRoot;
    private RecyclerView mRecycleCategory;
    private CategoryAdpter mCatAdpter;
    private List<Category> mlistCat;
    //Check Connection
    private ConnectionDetector mConnectionDetector;
    //Native Ads
    private LinearLayout mLinearNativeAds;
    //big Native Ads

    SharedprefrenceClass sharedprefrenceClass;
    private long mback_pressed;
    //private BottomNavigationView mBottomNavigation;
    protected OnBackPressedListener mOnBackPressedListener;


    private CustomBannerAdpter mbanner_adpter;
    List<Banner> mcontent_list;
    LinearLayoutManager mlm;
    private RecyclerView mbanner_add;
    private LinearLayout linearbanner_id;
    private Intent i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mConnectionDetector = new ConnectionDetector();
        customTitleView();
        init();
        setUpView();
    }

    private void customTitleView() {
        this.getSupportActionBar().setDisplayShowCustomEnabled(true);
        this.getSupportActionBar().setDisplayShowTitleEnabled(false);
        final LayoutInflater inflator = LayoutInflater.from(this);
        View v = inflator.inflate(R.layout.custom_title_view, null);

        ((TextView) v.findViewById(R.id.action_title)).setText("Bed Time Stories");
        this.getSupportActionBar().setCustomView(v);
        Toolbar parent = (Toolbar) v.getParent();
        parent.setPadding(3, 0, 0, 0);//for tab otherwise give space in tab
        parent.setContentInsetsAbsolute(0, 0);

    }

    private void init() {
        //
        mbanner_add = (RecyclerView) findViewById(R.id.recycler_banner);

        mLinearNativeAds = (LinearLayout) findViewById(R.id.linear_ads);
        linearbanner_id = (LinearLayout) findViewById(R.id.linearbanner_id);
        mRelativeRoot = (RelativeLayout) findViewById(R.id.relative_main);
        mRecycleCategory = (RecyclerView) findViewById(R.id.recycler_category);
        sharedprefrenceClass = SharedprefrenceClass.getInstance(MainActivity.this);

        Log.e("pk---------",""+getPackageName());

    }


    private void setUpView() {
        mlistCat = new ArrayList<>();
        mlistCat.add(new Category("Read Stories"));
        mlistCat.add(new Category("Quick Read"));
        mlistCat.add(new Category("Favorite Stories"));
        mlistCat.add(new Category("More Apps"));
        mlistCat.add(new Category("Rate App"));
        mlistCat.add(new Category("App of the Day"));

        mCatAdpter = new CategoryAdpter(mlistCat, MainActivity.this);
        mRecycleCategory.setLayoutManager(new GridLayoutManager(this, 2));
        mRecycleCategory.setAdapter(mCatAdpter);

        mRecycleCategory.addOnItemTouchListener(
                new RecyclerItemClickListener(this, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        // TODO Handle item click

                        if (position == 0) {
                            i = new Intent(MainActivity.this, StoryListActivity.class);
                            startActivity(i);
                        } else if (position == 1) {
                          /*  i=new Intent(MainActivity.this,ChatWithMsg.class);
                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right);
                            startActivity(i);*/
                        } else if (position == 2) {
/*
                            i=new Intent(MainActivity.this,ChatWithBlankActivity.class);
                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right);
                            startActivity(i);
*/
                        } else if (position == 3) {
                            if (mConnectionDetector.check_internet(MainActivity.this)) {
                                i = new Intent(MainActivity.this, MoreAppsActivity.class);
                                // overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right);
                                startActivity(i);
                            } else {
                                CommonMethod.SnackBar(mRelativeRoot, getResources().getString(R.string.offline_message));
                            }
                        } else if (position == 4) {
                            HelperClass.showRateDialog(MainActivity.this);
                        } else if (position == 5) {
                            HelperClass.shareApp(MainActivity.this);
                        }

                    }

                }));

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {

            if (mConnectionDetector.check_internet(this)) {
                startActivity(new Intent(MainActivity.this, Privacyactivity.class));
            } else {
                CommonMethod.SnackBar(mRelativeRoot, getResources().getString(R.string.offline_message));
            }

            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    //Native Ads
    private void refreshAd(boolean requestAppInstallAds, boolean requestContentAds, final View view) {
        AdLoader.Builder builder = new AdLoader.Builder(MainActivity.this, getString(R.string.native_ads_id));
        if (requestAppInstallAds) {
            builder.forAppInstallAd(new NativeAppInstallAd.OnAppInstallAdLoadedListener() {
                @Override
                public void onAppInstallAdLoaded(NativeAppInstallAd ad) {
                    NativeAppInstallAdView adView = (NativeAppInstallAdView) getLayoutInflater()
                            .inflate(R.layout.partial_native_ads, null);
                    FrameLayout frameLayout = view.findViewById(R.id.framelayout_home_ads);
                    //cardView_home_native_ads = (CardView) view.findViewById(R.id.cardView_home_native_ads);
                    //cardView_home_native_ads.setVisibility(View.VISIBLE);
                    populateAppInstallAdView(ad, adView);
                    frameLayout.removeAllViews();
                    frameLayout.addView(adView);

                }
            });
        }

        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(false)
                .build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new com.google.android.gms.ads.AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
                Log.e("onAdFailedToLoad: ", "" + errorCode);
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void populateAppInstallAdView(NativeAppInstallAd nativeAppInstallAd,
                                          NativeAppInstallAdView adView) {
        VideoController vc = nativeAppInstallAd.getVideoController();


        vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
            public void onVideoEnd() {
                super.onVideoEnd();
            }
        });

        adView.setHeadlineView(adView.findViewById(R.id.appinstall_headline));
        adView.setBodyView(adView.findViewById(R.id.appinstall_body));
        adView.setCallToActionView(adView.findViewById(R.id.appinstall_call_to_action));
        adView.setIconView(adView.findViewById(R.id.appinstall_app_icon));
        adView.setStarRatingView(adView.findViewById(R.id.appinstall_stars));

        // Some assets are guaranteed to be in every NativeAppInstallAd.
        if (nativeAppInstallAd.getHeadline() != null)
            ((TextView) adView.getHeadlineView()).setText(nativeAppInstallAd.getHeadline());

        if (nativeAppInstallAd.getBody() != null)
            ((TextView) adView.getBodyView()).setText(nativeAppInstallAd.getBody());

        if (nativeAppInstallAd.getCallToAction() != null)
            ((Button) adView.getCallToActionView()).setText(nativeAppInstallAd.getCallToAction());

        if (nativeAppInstallAd.getIcon().getDrawable() != null)
            ((ImageView) adView.getIconView()).setImageDrawable(nativeAppInstallAd.getIcon().getDrawable());

        com.google.android.gms.ads.formats.MediaView mediaView = adView.findViewById(R.id.appinstall_media);
        ImageView mainImageView = adView.findViewById(R.id.appinstall_image);


        if (nativeAppInstallAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAppInstallAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }
        // Assign native ad object to the native view.
        adView.setNativeAd(nativeAppInstallAd);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (mConnectionDetector.check_internet(this)) {
            mLinearNativeAds.setVisibility(View.VISIBLE);

            refreshAd(true, false, mRelativeRoot);

        } else {
            mLinearNativeAds.setVisibility(View.GONE);
        }


        if (mConnectionDetector.check_internet(this)) {
            if (sharedprefrenceClass.getCheck("flag") == true) {
                linearbanner_id.setVisibility(View.GONE);

            } else if (sharedprefrenceClass.getCheck("flag") == false) {
                linearbanner_id.setVisibility(View.VISIBLE);
                loadBanner();
            } else if (sharedprefrenceClass.getvalue("data") == true) {
                sharedprefrenceClass.saveCheck("flag", true);
                linearbanner_id.setVisibility(View.GONE);
            } else {
                linearbanner_id.setVisibility(View.VISIBLE);
                loadBanner();
            }
        } else {
            mbanner_add.setVisibility(View.GONE);
        }
    }


    //load Banner
    public void loadBanner() {
        mcontent_list = new ArrayList<>();
        mcontent_list.add(new Banner("1", "If you liked the #BedTimeStory application, would you share your feedback for this Application", "#000000", "#ffffff"));
        mbanner_adpter = new CustomBannerAdpter(mcontent_list, this, MainActivity.this);
        mlm = new LinearLayoutManager(this);
        mlm.setOrientation(LinearLayoutManager.VERTICAL);
        mbanner_add.setAdapter(mbanner_adpter);
        mbanner_add.setLayoutManager(mlm);
        mbanner_adpter.notifyDataSetChanged();
    }

    public interface OnBackPressedListener {
        void doBack();
    }

    @Override
    public void onBackPressed() {
        int count = getSupportFragmentManager().getBackStackEntryCount();
        if (mOnBackPressedListener != null) {
            mOnBackPressedListener.doBack();
        } else {
            if (count == 0) {
                exitApplication();
            } else {
                getSupportFragmentManager().popBackStack();
            }
        }
    }


    public void exitApplication() {

        if (mback_pressed + 3000 > System.currentTimeMillis()) {
            super.onBackPressed();
        } else {
            Snackbar.make(mRecycleCategory, "Please click back again to exit.", Snackbar.LENGTH_LONG).show();
        }
        mback_pressed = System.currentTimeMillis();
    }

}
