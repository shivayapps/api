package com.example.ebitas1.bedtimestory.adpter;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import androidx.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.ebitas1.bedtimestory.R;
import com.example.ebitas1.bedtimestory.model.More_Apps;

import java.util.List;

public class MoreAppsAdpter extends RecyclerView.Adapter<MoreAppsAdpter.CustomViewHolder> {

    private List<More_Apps> mListMoreApps;
    private Context mContext;

    public MoreAppsAdpter(List<More_Apps> mListCategory, Context mContext) {
        this.mListMoreApps = mListCategory;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        View view = layoutInflater.inflate(R.layout.row_layout_apps, null, false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder viewHolder, final int pos) {

        final More_Apps m = mListMoreApps.get(pos);
        viewHolder.mMoreName.setText(m.getApp_name());
        viewHolder.mMoreDesc.setText(m.getApp_desc());
        Glide.with(mContext).load(m.getApp_icon_url()).into(viewHolder.mMoreIcon);

        viewHolder.mBtnInstall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isAppInstalled = appInstalledOrNot(m.getApp_package_name());
                if (isAppInstalled) {
                    Intent LaunchIntent = mContext.getPackageManager()
                            .getLaunchIntentForPackage(m.getApp_package_name());
                    mContext.startActivity(LaunchIntent);
                } else {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(m.getApp_short_url()));
                    mContext.startActivity(i);
                }
            }
        });

        if (pos == mListMoreApps.size() - 1) {
            viewHolder.view.setVisibility(View.GONE);
        } else {
            viewHolder.view.setVisibility(View.VISIBLE);
        }

    }

    @Override
    public int getItemCount() {
        return mListMoreApps.size();
    }


    public class CustomViewHolder extends RecyclerView.ViewHolder {

        private ImageView mMoreIcon;
        private TextView mMoreName;
        private TextView mMoreDesc;
        private Button mBtnInstall;
        private View view;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);

            mMoreIcon = (ImageView) itemView.findViewById(R.id.app_icon);
            mMoreName = (TextView) itemView.findViewById(R.id.app_name);
            mMoreDesc = (TextView) itemView.findViewById(R.id.app_desc);
            mBtnInstall = (Button) itemView.findViewById(R.id.btnInstall);
            view = itemView.findViewById(R.id.view);
        }
    }


    private boolean appInstalledOrNot(String uri) {
        PackageManager pm = mContext.getPackageManager();
        try {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
        }

        return false;
    }


}
