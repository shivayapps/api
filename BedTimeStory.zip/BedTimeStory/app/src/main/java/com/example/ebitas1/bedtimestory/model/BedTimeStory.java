package com.example.ebitas1.bedtimestory.model;

import android.os.Parcel;
import android.os.Parcelable;

public class BedTimeStory implements Parcelable {

    private String story_id, story_name, story_content;
    private int is_fav, is_read;

    public BedTimeStory() {
        this.story_id = story_id;
        this.story_name = story_name;
        this.story_content = story_content;
        this.is_fav = is_fav;
        this.is_read = is_read;
    }


    public BedTimeStory(String story_id, String story_name, String story_content, int is_fav, int is_read) {
        this.story_id = story_id;
        this.story_name = story_name;
        this.story_content = story_content;
        this.is_fav = is_fav;
        this.is_read = is_read;
    }


    protected BedTimeStory(Parcel in) {
        readFromParcel(in);
    }

    public static final Creator<BedTimeStory> CREATOR = new Creator<BedTimeStory>() {
        @Override
        public BedTimeStory createFromParcel(Parcel in) {
            return new BedTimeStory(in);
        }

        @Override
        public BedTimeStory[] newArray(int size) {
            return new BedTimeStory[size];
        }
    };

    public String getStory_id() {
        return story_id;
    }

    public void setStory_id(String story_id) {
        this.story_id = story_id;
    }

    public String getStory_name() {
        return story_name;
    }

    public void setStory_name(String story_name) {
        this.story_name = story_name;
    }

    public String getStory_content() {
        return story_content;
    }

    public void setStory_content(String story_content) {
        this.story_content = story_content;
    }

    public int getIs_fav() {
        return is_fav;
    }

    public void setIs_fav(int is_fav) {
        this.is_fav = is_fav;
    }

    public int getIs_read() {
        return is_read;
    }

    public void setIs_read(int is_read) {
        this.is_read = is_read;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(story_id);
        parcel.writeString(story_name);
        parcel.writeString(story_content);
        parcel.writeInt(is_fav);
        parcel.writeInt(is_read);
    }

    public void readFromParcel(Parcel parcel) {
        this.story_id = parcel.readString();
        this.story_name = parcel.readString();
        this.story_content = parcel.readString();
        this.is_fav = parcel.readInt();
        this.is_read = parcel.readInt();
    }


}
