package com.example.ebitas1.bedtimestory.model;

public class Category {


    private int CatIcon;
    private String CatName;

    public Category(String catName) {
        CatName = catName;
    }

    public Category(int catIcon, String catName) {
        CatIcon = catIcon;
        CatName = catName;
    }


    public int getCatIcon() {
        return CatIcon;
    }

    public void setCatIcon(int catIcon) {
        CatIcon = catIcon;
    }

    public String getCatName() {
        return CatName;
    }

    public void setCatName(String catName) {
        CatName = catName;
    }
}
