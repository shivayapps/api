package com.example.ebitas1.bedtimestory.activity;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Handler;
import androidx.core.content.res.ResourcesCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.example.ebitas1.bedtimestory.R;
import com.example.ebitas1.bedtimestory.utill.ConnectionDetector;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

public class SplashScreen extends AppCompatActivity {

    private InterstitialAd moInterstitialAd;
    private static int SPLASH_TIME_OUT = 3000;
    private TextView mversion_code,mtxtversion;
    private boolean isAdLoaded = false;
    private boolean isMainActivityShow = false;
    private Intent mainIntant;
    ConnectionDetector connectionDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        connectionDetector=new ConnectionDetector();
        init();
        getCode();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (connectionDetector.check_internet(SplashScreen.this)) {
                    loadInterstitialAd();
                } else {
                    mainIntant = new Intent(SplashScreen.this, MainActivity.class);
                    startActivity(mainIntant);
                    finish();
                }
            }
        }, SPLASH_TIME_OUT);
    }


    private void init()
    {

        mversion_code=(TextView) findViewById(R.id.txtversion_code);
        mtxtversion=(TextView) findViewById(R.id.txtversion);
    }
    public void getCode() {
        PackageInfo pinfo = null;
        try {
            pinfo = getPackageManager().getPackageInfo(getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        int versionNumber = pinfo.versionCode;
        String versionName = pinfo.versionName;

        Typeface typeface = ResourcesCompat.getFont(SplashScreen.this, R.font.chewyregular);
        mversion_code.setText(versionName);
        mversion_code.setTypeface(typeface);
        mtxtversion.setTypeface(typeface);

    }
    private void loadInterstitialAd() {
        try {
            moInterstitialAd = new InterstitialAd(this);
            moInterstitialAd.setAdUnitId(getResources().getString(R.string.fullscreen_ads_id));
            moInterstitialAd.loadAd(new AdRequest.Builder().build());

            final Handler handler = new Handler();
            moInterstitialAd.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                    if (moInterstitialAd.isLoaded() && isMainActivityShow == false) {
                        moInterstitialAd.show();
                        isAdLoaded = true;
                    } else {
                        isAdLoaded = false;
                    }
                }

                @Override
                public void onAdClosed() {

                    mainIntant = new Intent(SplashScreen.this, MainActivity.class);
                    startActivity(mainIntant);
                    finish();

                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                    super.onAdFailedToLoad(errorCode);
                    //do your intent code

                    mainIntant = new Intent(SplashScreen.this, MainActivity.class);
                    startActivity(mainIntant);
                    finish();
                }
            });

        } catch (Exception e) {
            Log.e("Error", "inrequestadd: " + e.getMessage());
        }

    }

    @Override
    public void onBackPressed() {

    }

}
