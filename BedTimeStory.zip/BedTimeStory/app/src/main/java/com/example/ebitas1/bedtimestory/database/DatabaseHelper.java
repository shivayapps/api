package com.example.ebitas1.bedtimestory.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

import com.example.ebitas1.bedtimestory.model.BedTimeStory;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private Context mContext;
    public static final String DB_name = "bedtime.sqlite";
    public static String TABLE_NAME = "tbl_story";
    private final String DB_Location;
    private SQLiteDatabase mDatabase;

    private static final String CATID = "id";
    private static final String ISREAD = "mark_read";
    private static final String ISFAV = "favourite";

    public DatabaseHelper(Context context) {
        super(context, DB_name, null, 1);
        this.mContext = context;
        DB_Location = "/data/data/" + context.getPackageName() + "/databases/";
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            db.disableWriteAheadLogging();
        }
    }

    public void openDatabase() {
        String DBPath = mContext.getDatabasePath(DB_name).getAbsolutePath();
        if (mDatabase != null && mDatabase.isOpen()) {
            return;
        }
        mDatabase = SQLiteDatabase.openDatabase(DBPath, null, SQLiteDatabase.OPEN_READWRITE);
    }

    public void closeDatabase() {
        if (mDatabase != null) {
            mDatabase.close();
        }
    }

    public boolean copyDatabase(Context mContext) {
        InputStream mInputStream = null;
        OutputStream mOutputStream = null;
        try {
            mInputStream = mContext.getAssets().open(DB_name);
            String outFileName = DB_Location + DB_name;

            Log.e("sshddgh",""+outFileName);
            mOutputStream = new FileOutputStream(outFileName);
            byte[] buff = new byte[1024];
            int length = 0;
            while ((length = mInputStream.read(buff)) > 0) {
                mOutputStream.write(buff, 0, length);
            }
            mOutputStream.flush();
            mOutputStream.close();
            Log.w("MainActivity", "DB Copied");
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (mInputStream != null) {
                    mInputStream.close();
                }
                if (mOutputStream != null) {
                    mOutputStream.close();
                }
            } catch (IOException e) {

            }
        }
    }


    public List<BedTimeStory> getlist_story() {
        List<BedTimeStory> page = new ArrayList<>();
        openDatabase();
        Cursor cursor;
        openDatabase();
        cursor = mDatabase.rawQuery("SELECT * FROM " + TABLE_NAME , null);
        if (cursor.getCount() > 0) {
            if (cursor.moveToFirst()) {
                do {
                    page.add(new BedTimeStory(cursor.getString(0), cursor.getString(1),  cursor.getString(2), cursor.getInt(3), cursor.getInt(4)));

                } while (cursor.moveToNext());

            }
        }
        cursor.close();
        closeDatabase();
        return page;
    }

   /* public List<ShlokGetSet> getFavoriteDataFromDatabase() {
        ShlokGetSet mDatabse_GetSet_Obj = null;
        List<ShlokGetSet> mDatabase_Getset_list = new ArrayList<>();
        openDatabase();
        Cursor mCursor = mDatabase.rawQuery("SELECT a_n,s_n,s,t,f,mr,sanskrit_shlok_title FROM " + TABLE_NAME + " WHERE  f = '" + 1 + "'", null);
        mCursor.moveToFirst();
        while (!mCursor.isAfterLast()) {
            mDatabse_GetSet_Obj = new ShlokGetSet(mCursor.getInt(0), mCursor.getInt(1), mCursor.getString(2), mCursor.getString(3), mCursor.getInt(4), mCursor.getInt(5), mCursor.getString(6));
            mDatabase_Getset_list.add(mDatabse_GetSet_Obj);
            mCursor.moveToNext();
        }
        mCursor.close();
        closeDatabase();
        return mDatabase_Getset_list;
    }

    public List<ShlokGetSet> getRandomDataFromDatabase() {
        ShlokGetSet mDatabse_GetSet_Obj = null;
        List<ShlokGetSet> mDatabase_Getset_list = new ArrayList<>();
        openDatabase();
        Cursor mCursor = mDatabase.rawQuery("SELECT a_n,s_n,s,t,f,mr,sanskrit_shlok_title FROM " + TABLE_NAME + " ORDER BY RANDOM()", null);
        mCursor.moveToFirst();
        while (!mCursor.isAfterLast()) {
            mDatabse_GetSet_Obj = new ShlokGetSet(mCursor.getInt(0), mCursor.getInt(1), mCursor.getString(2), mCursor.getString(3), mCursor.getInt(4), mCursor.getInt(5), mCursor.getString(6));
            mDatabase_Getset_list.add(mDatabse_GetSet_Obj);
            mCursor.moveToNext();
        }
        mCursor.close();
        closeDatabase();
        return mDatabase_Getset_list;
    }

    public long updateFavoriteData(int miAdhyayNum, int val, int shlok_no) {
        long returnValue;
        ContentValues contentValues = new ContentValues();
        contentValues.put("a_n", miAdhyayNum);
        contentValues.put("f", val);
        contentValues.put("s_n", shlok_no);
        String[] whereArgs = {String.valueOf(miAdhyayNum), String.valueOf(shlok_no)};
        openDatabase();
        returnValue = mDatabase.update(TABLE_NAME,
                contentValues,
                "a_n" + " = ? AND " + "s_n" + " = ?",
                whereArgs);

        closeDatabase();
        return returnValue;
    }


    public long updateMarkASReadData(int shlok_no, int val, int miAdhyayNum) {
        long returnValue;
        ContentValues contentValues = new ContentValues();
        contentValues.put("s_n", shlok_no);
        contentValues.put("mr", val);
        contentValues.put("a_n", miAdhyayNum);
        String[] whereArgs = {String.valueOf(shlok_no), String.valueOf(miAdhyayNum)};
        openDatabase();
        returnValue = mDatabase.update(TABLE_NAME,
                contentValues,
                "s_n" + " = ? AND " + "a_n" + " = ?",
                whereArgs);
        closeDatabase();
        return returnValue;
    }
*/


    public long updateFavoriteData(int val, int value) {
        long returnValue;


        ContentValues contentValues = new ContentValues();
        contentValues.put(ISFAV, val);
        contentValues.put(CATID, value);
        Log.e("Gounnnnnnnnngg","----------------");
        String[] whereArgs = {String.valueOf(value)};
        openDatabase();
        returnValue = mDatabase.update(TABLE_NAME, contentValues, CATID + " = ?",whereArgs );
        //returnValue=db.update(TBNAME, contentValues, "i, new String[value]);
        closeDatabase();

        String valData="UPDATE tbl_story SET favourite= " + 1 +" WHERE id = "+14143;
        return returnValue;
    }


    public long updateMarkASReadData(int id, int read) {
        long returnValue;
        SQLiteDatabase db = getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(CATID, id);
        contentValues.put(ISREAD, read);

        openDatabase();
        String[] whereArgs = {String.valueOf(id)};
        returnValue = db.update(TABLE_NAME,
                contentValues,
                CATID + " = ? ",
                whereArgs);
        closeDatabase();
        return returnValue;
    }
}
