package com.example.ebitas1.bedtimestory.activity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.ebitas1.bedtimestory.R;
import com.example.ebitas1.bedtimestory.utill.ConnectionDetector;
import com.example.ebitas1.bedtimestory.utill.UtillUrl;

public class Privacyactivity extends AppCompatActivity {

    ConnectionDetector connectionDetector;
    private WebView webView;
    private RelativeLayout relative_policy;
    private CustomWebViewClient mcustomWebViewClient;
    private ProgressBar progressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_activity);

        customTitleView();
        init();

    }



    private  void customTitleView()
    {

        this.getSupportActionBar().setDisplayShowCustomEnabled(true);
        this.getSupportActionBar().setDisplayShowTitleEnabled(false);
        LayoutInflater inflator = LayoutInflater.from(this);
        View v = inflator.inflate(R.layout.custom_title_view, null);

        ((TextView)v.findViewById(R.id.action_title)).setText("Privacy Policy");

        LinearLayout linearLayout=((LinearLayout)v.findViewById(R.id.linear_img));
        linearLayout.setVisibility(View.VISIBLE);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        this.getSupportActionBar().setCustomView(v);
        Toolbar parent = (Toolbar) v.getParent();
        parent.setPadding(3, 0, 0, 0);//for tab otherwise give space in tab
        parent.setContentInsetsAbsolute(0, 0);

    }

    private void init()
    {
        connectionDetector=new ConnectionDetector();
        progressBar = (ProgressBar) findViewById(R.id.progressBar1);
        relative_policy=(RelativeLayout) findViewById(R.id.relative_policy);
    }

    private void setUpView()
    {
        if (!connectionDetector.check_internet(Privacyactivity.this)) {
            progressBar.setVisibility(View.GONE);
            Snackbar.make(relative_policy, getResources().getString(R.string.offline_message), Snackbar.LENGTH_SHORT).show();
        } else {
            webView = (WebView) findViewById(R.id.webview_privacy_policy);
            mcustomWebViewClient = new CustomWebViewClient();
            webView.setWebViewClient(mcustomWebViewClient);
            webView.clearCache(true);
            webView.clearHistory();
            webView.getSettings().setJavaScriptEnabled(true);
            webView.loadUrl(UtillUrl.privacy_policy);
        }

    }

    public void onBackPressed() {
        super.onBackPressed();
    }


    //webview
    private class CustomWebViewClient extends WebViewClient {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            // TODO Auto-generated method stub
            super.onPageStarted(view, url, favicon);
        }

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (!connectionDetector.check_internet(Privacyactivity.this)) {
                Snackbar.make(relative_policy, getResources().getString(R.string.offline_message), Snackbar.LENGTH_SHORT).show();
            } else {
                view.loadUrl(UtillUrl.privacy_policy);
            }
            return true;
        }


        @Override
        public void onPageFinished(WebView view, String url) {
            // TODO Auto-generated method stub
            super.onPageFinished(view, url);

            progressBar.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        setUpView();
    }
}
