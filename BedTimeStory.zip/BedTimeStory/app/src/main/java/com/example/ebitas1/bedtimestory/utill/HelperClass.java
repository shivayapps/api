package com.example.ebitas1.bedtimestory.utill;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

import com.example.ebitas1.bedtimestory.BuildConfig;
import com.example.ebitas1.bedtimestory.R;

public class HelperClass {

    static ConnectionDetector mConnectionDetector = new ConnectionDetector();
    public static void showRateDialog(final Context mContext) {
        final String APP_PNAME = mContext.getPackageName();
        if (mConnectionDetector.check_internet(mContext)) {
            Intent intent = null;
            try {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("market://details?id=" + APP_PNAME));
                mContext.startActivity(intent);
            } catch (ActivityNotFoundException e) {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri
                        .parse("https://play.google.com/store/apps/details?id="
                                + APP_PNAME));
                mContext.startActivity(intent);
            }
        } else {
            Toast.makeText(mContext, mContext.getResources().getString(R.string.offline_message), Toast.LENGTH_LONG).show();
        }
    }


    public static void shareApp(Context context)
    {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "My application name");
            String shareMessage= "\nLet me recommend you this application\n\n";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID +"\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            context.startActivity(Intent.createChooser(shareIntent, "choose one"));
        } catch(Exception e) {
            //e.toString();
        }
    }
}
