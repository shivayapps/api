package com.example.ebitas1.bedtimestory.model;


/**
 * Awesome Pojo Generator
 */
public class More_Apps {


    private String app_name;

    private String app_package_name;

    private Integer enable;

    private String app_icon_url;

    private String id;

    private String app_desc;

    private String app_short_url;

    public More_Apps() {
    }

    public More_Apps(String app_name, String app_package_name, Integer enable, String app_icon_url, String id, String app_desc, String app_short_url) {
        this.app_name = app_name;
        this.app_package_name = app_package_name;
        this.enable = enable;
        this.app_icon_url = app_icon_url;
        this.id = id;
        this.app_desc = app_desc;
        this.app_short_url = app_short_url;
    }

    public void setApp_name(String app_name) {
        this.app_name = app_name;
    }

    public String getApp_name() {
        return app_name;
    }

    public void setApp_package_name(String app_package_name) {
        this.app_package_name = app_package_name;
    }

    public String getApp_package_name() {
        return app_package_name;
    }

    public void setEnable(Integer enable) {
        this.enable = enable;
    }

    public Integer getEnable() {
        return enable;
    }

    public void setApp_icon_url(String app_icon_url) {
        this.app_icon_url = app_icon_url;
    }

    public String getApp_icon_url() {
        return app_icon_url;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setApp_desc(String app_desc) {
        this.app_desc = app_desc;
    }

    public String getApp_desc() {
        return app_desc;
    }

    public void setApp_short_url(String app_short_url) {
        this.app_short_url = app_short_url;
    }

    public String getApp_short_url() {
        return app_short_url;
    }
}