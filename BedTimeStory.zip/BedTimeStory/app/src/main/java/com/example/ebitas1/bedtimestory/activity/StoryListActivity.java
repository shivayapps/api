package com.example.ebitas1.bedtimestory.activity;

import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.ebitas1.bedtimestory.R;
import com.example.ebitas1.bedtimestory.adpter.StoryListAdpter;
import com.example.ebitas1.bedtimestory.database.DatabaseHelper;
import com.example.ebitas1.bedtimestory.model.BedTimeStory;
import com.example.ebitas1.bedtimestory.recyclerClick.RecyclerItemClickListener;
import com.example.ebitas1.bedtimestory.utill.ConnectionDetector;
import com.example.ebitas1.bedtimestory.utill.Constant;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.NativeAppInstallAd;
import com.google.android.gms.ads.formats.NativeAppInstallAdView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class StoryListActivity extends AppCompatActivity {


    private RecyclerView mRecyclerView;
    private List<BedTimeStory> mListStory;
    private LinearLayoutManager mLinearLayoutManager;
    private StoryListAdpter mStoryListAdpter;
    private DatabaseHelper mDatabaseHelper;
    private ConnectionDetector mConnectionDetector;
    private RelativeLayout mRelativeRoot;
    private LinearLayout mLinearNativeAds;
    private String KEY_RECYCLER_STATE = "recycler_state";
    private Bundle mBundleRecyclerViewState;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_list);
        mConnectionDetector=new ConnectionDetector();

        customTitleView();
        init();
        setUpView();
    }

    private void customTitleView() {
        this.getSupportActionBar().setDisplayShowCustomEnabled(true);
        this.getSupportActionBar().setDisplayShowTitleEnabled(false);
        final LayoutInflater inflator = LayoutInflater.from(this);
        View v = inflator.inflate(R.layout.custom_title_view, null);

        ((TextView) v.findViewById(R.id.action_title)).setText("Read Stories");
        LinearLayout linearLayout=((LinearLayout)v.findViewById(R.id.linear_img));
        linearLayout.setVisibility(View.VISIBLE);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        this.getSupportActionBar().setCustomView(v);
        Toolbar parent = (Toolbar) v.getParent();
        parent.setPadding(3, 0, 0, 0);//for tab otherwise give space in tab
        parent.setContentInsetsAbsolute(0, 0);

    }


    private void init()
    {
        mRecyclerView=(RecyclerView) findViewById(R.id.recylerview);
        mListStory=new ArrayList<>();
        mRelativeRoot=(RelativeLayout)findViewById(R.id.relative);
        mLinearNativeAds=(LinearLayout)findViewById(R.id.linear_ads);

        mDatabaseHelper = new DatabaseHelper(StoryListActivity.this);
        //Check Exist Database
        File database = getApplicationContext().getDatabasePath(DatabaseHelper.DB_name);
        if (false == database.exists()) {
            mDatabaseHelper.getReadableDatabase();
            // Copy database
            mDatabaseHelper.copyDatabase(this);
        }

    }

    private void setUpView()
    {
        mListStory.addAll(mDatabaseHelper.getlist_story());
        mStoryListAdpter=new StoryListAdpter(mListStory,StoryListActivity.this);
        mLinearLayoutManager=new LinearLayoutManager(this);
        mLinearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(mLinearLayoutManager);
        mRecyclerView.setAdapter(mStoryListAdpter);

        onClickEvents();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }


    private void onClickEvents() {
        mRecyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(this, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {


                            Intent intent = new Intent(StoryListActivity.this, StoryDetailActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putInt(Constant.POS, position);
                            intent.putExtras(bundle);
                            startActivity(intent);

                    }
                })
        );
    }




    @Override
    public void onPause() {
        super.onPause();
        mBundleRecyclerViewState = new Bundle();
        Parcelable listState = mRecyclerView.getLayoutManager().onSaveInstanceState();
        mBundleRecyclerViewState.putParcelable(KEY_RECYCLER_STATE, listState);
    }
    //Native Ads
    private void refreshAd(boolean requestAppInstallAds, boolean requestContentAds, final View view) {
        AdLoader.Builder builder = new AdLoader.Builder(StoryListActivity.this, getString(R.string.native_ads_id));
        if (requestAppInstallAds) {
            builder.forAppInstallAd(new NativeAppInstallAd.OnAppInstallAdLoadedListener() {
                @Override
                public void onAppInstallAdLoaded(NativeAppInstallAd ad) {
                    NativeAppInstallAdView adView = (NativeAppInstallAdView) getLayoutInflater()
                            .inflate(R.layout.partial_native_ads, null);
                    FrameLayout frameLayout = view.findViewById(R.id.framelayout_home_ads);
                    //cardView_home_native_ads = (CardView) view.findViewById(R.id.cardView_home_native_ads);
                    //cardView_home_native_ads.setVisibility(View.VISIBLE);
                    populateAppInstallAdView(ad, adView);
                    frameLayout.removeAllViews();
                    frameLayout.addView(adView);

                }
            });
        }

        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(false)
                .build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new com.google.android.gms.ads.AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
                Log.e("onAdFailedToLoad: ", "" + errorCode);
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void populateAppInstallAdView(NativeAppInstallAd nativeAppInstallAd,
                                          NativeAppInstallAdView adView) {
        VideoController vc = nativeAppInstallAd.getVideoController();


        vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
            public void onVideoEnd() {
                super.onVideoEnd();
            }
        });

        adView.setHeadlineView(adView.findViewById(R.id.appinstall_headline));
        adView.setBodyView(adView.findViewById(R.id.appinstall_body));
        adView.setCallToActionView(adView.findViewById(R.id.appinstall_call_to_action));
        adView.setIconView(adView.findViewById(R.id.appinstall_app_icon));
        adView.setStarRatingView(adView.findViewById(R.id.appinstall_stars));

        // Some assets are guaranteed to be in every NativeAppInstallAd.
        if (nativeAppInstallAd.getHeadline() != null)
            ((TextView) adView.getHeadlineView()).setText(nativeAppInstallAd.getHeadline());

        if (nativeAppInstallAd.getBody() != null)
            ((TextView) adView.getBodyView()).setText(nativeAppInstallAd.getBody());

        if (nativeAppInstallAd.getCallToAction() != null)
            ((Button) adView.getCallToActionView()).setText(nativeAppInstallAd.getCallToAction());

        if (nativeAppInstallAd.getIcon().getDrawable() != null)
            ((ImageView) adView.getIconView()).setImageDrawable(nativeAppInstallAd.getIcon().getDrawable());

        com.google.android.gms.ads.formats.MediaView mediaView = adView.findViewById(R.id.appinstall_media);
        ImageView mainImageView = adView.findViewById(R.id.appinstall_image);


        if (nativeAppInstallAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAppInstallAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }
        // Assign native ad object to the native view.
        adView.setNativeAd(nativeAppInstallAd);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (mConnectionDetector.check_internet(this)) {
            mLinearNativeAds.setVisibility(View.VISIBLE);

            refreshAd(true, false, mRelativeRoot);

        } else {
            mLinearNativeAds.setVisibility(View.GONE);
        }


        if (mBundleRecyclerViewState != null) {
            Parcelable listState = mBundleRecyclerViewState.getParcelable(KEY_RECYCLER_STATE);
            mRecyclerView.getLayoutManager().onRestoreInstanceState(listState);
        }



    }

}
