package com.example.ebitas1.bedtimestory.adpter;

import androidx.core.app.Fragment;
import androidx.core.app.FragmentManager;
import android.util.Log;


import com.example.ebitas1.bedtimestory.model.BedTimeStory;
import com.example.ebitas1.bedtimestory.viewPagerList.SwipeFragment;

import java.util.List;

public class FragmentPagerAdapter extends androidx.core.app.FragmentPagerAdapter {
    private static final String TAG = FragmentPagerAdapter.class.getSimpleName();
    List<BedTimeStory> mlistStory;
    SwipeFragment fragment;
    int size = 16;

    public FragmentPagerAdapter(FragmentManager fm, List<BedTimeStory> mList) {
        super(fm);
        this.mlistStory = mList;
        Log.e(TAG, ":::AdpterListSize:::" + mlistStory.size());
    }

    @Override
    public Fragment getItem(int position) {
        fragment = new SwipeFragment();
        return fragment.newInstance(position, mlistStory.get(position).getStory_content(),mlistStory.get(position).getIs_read());
    }

    @Override
    public int getCount() {
        return mlistStory.size();
    }


}

