package com.example.ebitas1.bedtimestory.activity;

import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ebitas1.bedtimestory.R;
import com.example.ebitas1.bedtimestory.adpter.MoreAppsAdpter;
import com.example.ebitas1.bedtimestory.model.More_Apps;
import com.example.ebitas1.bedtimestory.utill.ConnectionDetector;
import com.example.ebitas1.bedtimestory.utill.UtillUrl;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MoreAppsActivity extends AppCompatActivity {
    ConnectionDetector connectionDetector;
    List<More_Apps>  mMoreAppList;
    private RecyclerView mRecyclerMoreApp;
    private RelativeLayout mRelativeMoreApp;
    private MoreAppsAdpter mMoreAppAdpter;
    private LinearLayoutManager mlinearLayoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_apps);

        customTitleView();
        init();
    }


    private  void customTitleView()
    {

        this.getSupportActionBar().setDisplayShowCustomEnabled(true);
        this.getSupportActionBar().setDisplayShowTitleEnabled(false);
        LayoutInflater inflator = LayoutInflater.from(this);
        View v = inflator.inflate(R.layout.custom_title_view, null);

        ((TextView)v.findViewById(R.id.action_title)).setText("More Apps");

        LinearLayout linearLayout=((LinearLayout)v.findViewById(R.id.linear_img));
        linearLayout.setVisibility(View.VISIBLE);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        this.getSupportActionBar().setCustomView(v);
        Toolbar parent = (Toolbar) v.getParent();
        parent.setPadding(3, 0, 0, 0);//for tab otherwise give space in tab
        parent.setContentInsetsAbsolute(0, 0);

    }



    private void init()
    {

        connectionDetector=new ConnectionDetector();
        mMoreAppList=new ArrayList();
        mRecyclerMoreApp=(RecyclerView) findViewById(R.id.recyclerMoreapps);
        mRelativeMoreApp=(RelativeLayout)findViewById(R.id.relative_moreapps);
        if (connectionDetector.check_internet(MoreAppsActivity.this)) {
            loadJsonData();
        } else {
            Snackbar snackbar = Snackbar.make(mRelativeMoreApp, getResources().getString(R.string.offline_message), Snackbar.LENGTH_SHORT);
            snackbar.show();
        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }





    //Load data from web service
    private void loadJsonData() {
        final ProgressBar progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.VISIBLE);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, UtillUrl.url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressBar.setVisibility(View.INVISIBLE);

                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray otherappsArray = obj.getJSONArray("otherapps");
                            for (int i = 0; i < otherappsArray.length(); i++) {
                                JSONObject otherappsObject = otherappsArray.getJSONObject(i);
                                String id = otherappsObject.getString("id");
                                String app_name = otherappsObject.getString("app_name");
                                String app_desc = otherappsObject.getString("app_desc");
                                String app_package_name = otherappsObject.getString("app_package_name");
                                String app_short_url = otherappsObject.getString("app_short_url");
                                String app_icon_url = otherappsObject.getString("app_icon_url");
                                More_Apps more_apps = new More_Apps();
                                more_apps.setId(id);
                                more_apps.setApp_name(app_name);
                                more_apps.setApp_desc(app_desc);
                                more_apps.setApp_icon_url(app_icon_url);
                                more_apps.setApp_package_name(app_package_name);
                                more_apps.setApp_short_url(app_short_url);
                                mMoreAppList.add(more_apps);

                            }
                            mMoreAppAdpter=new MoreAppsAdpter(mMoreAppList,MoreAppsActivity.this);
                            mlinearLayoutManager=new LinearLayoutManager(getApplicationContext());
                            mlinearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                            mRecyclerMoreApp.setAdapter(mMoreAppAdpter);
                            mRecyclerMoreApp.setLayoutManager(mlinearLayoutManager);
                            mMoreAppAdpter.notifyDataSetChanged();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                       // Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    /*//Native Ads
    private void refreshAd(boolean requestAppInstallAds, boolean requestContentAds, final View view) {
        AdLoader.Builder builder = new AdLoader.Builder(MoreAppsActivity.this, getString(R.string.native_ads_id));
        if (requestAppInstallAds) {
            builder.forAppInstallAd(new NativeAppInstallAd.OnAppInstallAdLoadedListener() {
                @Override
                public void onAppInstallAdLoaded(NativeAppInstallAd ad) {
                    NativeAppInstallAdView adView = (NativeAppInstallAdView) getLayoutInflater()
                            .inflate(R.layout.partial_native_ads, null);
                    FrameLayout frameLayout = view.findViewById(R.id.framelayout_home_ads);
                    //cardView_home_native_ads = (CardView) view.findViewById(R.id.cardView_home_native_ads);
                    //cardView_home_native_ads.setVisibility(View.VISIBLE);
                    populateAppInstallAdView(ad, adView);
                    frameLayout.removeAllViews();
                    frameLayout.addView(adView);

                }
            });
        }

        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(false)
                .build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new com.google.android.gms.ads.AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
                Log.e("onAdFailedToLoad: ", "" + errorCode);
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void populateAppInstallAdView(NativeAppInstallAd nativeAppInstallAd,
                                          NativeAppInstallAdView adView) {
        VideoController vc = nativeAppInstallAd.getVideoController();


        vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
            public void onVideoEnd() {
                super.onVideoEnd();
            }
        });

        adView.setHeadlineView(adView.findViewById(R.id.appinstall_headline));
        adView.setBodyView(adView.findViewById(R.id.appinstall_body));
        adView.setCallToActionView(adView.findViewById(R.id.appinstall_call_to_action));
        adView.setIconView(adView.findViewById(R.id.appinstall_app_icon));
        adView.setStarRatingView(adView.findViewById(R.id.appinstall_stars));

        // Some assets are guaranteed to be in every NativeAppInstallAd.
        if (nativeAppInstallAd.getHeadline() != null)
            ((TextView) adView.getHeadlineView()).setText(nativeAppInstallAd.getHeadline());

        if (nativeAppInstallAd.getBody() != null)
            ((TextView) adView.getBodyView()).setText(nativeAppInstallAd.getBody());

        if (nativeAppInstallAd.getCallToAction() != null)
            ((Button) adView.getCallToActionView()).setText(nativeAppInstallAd.getCallToAction());

        if (nativeAppInstallAd.getIcon().getDrawable() != null)
            ((ImageView) adView.getIconView()).setImageDrawable(nativeAppInstallAd.getIcon().getDrawable());

        com.google.android.gms.ads.formats.MediaView mediaView = adView.findViewById(R.id.appinstall_media);
        ImageView mainImageView = adView.findViewById(R.id.appinstall_image);


        if (nativeAppInstallAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAppInstallAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }
        // Assign native ad object to the native view.
        adView.setNativeAd(nativeAppInstallAd);
    }
*/
    @Override
    protected void onResume() {
        super.onResume();

/*
        if (connectionDetector.check_internet(this)) {
            mLinearNativeAds.setVisibility(View.VISIBLE);
            mCardViewLinearNativeAds.setVisibility(View.VISIBLE);
            refreshAd(true, false, mRelativeMsg);
            bigbannerrefreshAd(true,true);
        } else {
            mLinearNativeAds.setVisibility(View.GONE);
            mCardViewLinearNativeAds.setVisibility(View.GONE);
        }
*/
    }

   /* private void bigbannerrefreshAd(boolean requestAppInstallAds, boolean requestContentAds) {
        AdLoader.Builder builder = new AdLoader.Builder(MoreAppsActivity.this, getResources().getString(R.string.BIG_ADMOB_AD_UNIT_ID));
        if (requestAppInstallAds) {
            builder.forAppInstallAd(new NativeAppInstallAd.OnAppInstallAdLoadedListener() {
                @Override
                public void onAppInstallAdLoaded(NativeAppInstallAd ad) {
                    // if (isAdded()) {
                    FrameLayout frameLayout =
                            mFrameLayoutNativeAds.findViewById(R.id.big_banner_framelayout_detail_ads);
                    NativeAppInstallAdView adView = (NativeAppInstallAdView) getLayoutInflater()
                            .inflate(R.layout.partial_drawer_big_native_ads, null);
                    bigbannerpopulateAppInstallAdView(ad, adView);
                    frameLayout.removeAllViews();
                    frameLayout.addView(adView);
                    // }
                }
            });
        }

        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(true)
                .build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new com.google.android.gms.ads.AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());
//        mVideoStatus.setText("");
    }
*/
/*
    private void bigbannerpopulateAppInstallAdView(NativeAppInstallAd nativeAppInstallAd,
                                                   NativeAppInstallAdView adView) {
        // Get the video controller for the ad. One will always be provided, even if the ad doesn't
        // have a video asset.
        VideoController vc = nativeAppInstallAd.getVideoController();

        // Create a new VideoLifecycleCallbacks object and pass it to the VideoController. The
        // VideoController will call methods on this object when events occur in the video
        // lifecycle.
        vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
            public void onVideoEnd() {
                // Publishers should allow native ads to complete video playback before refreshing
                // or replacing them with another ad in the same UI location.
//                mRefresh.setEnabled(true);
                //mVideoStatus.setText("Video status: Video playback has ended.");
                super.onVideoEnd();
            }
        });
        adView.setMediaView(adView.<MediaView>findViewById(R.id.media_image));
        adView.setHeadlineView(adView.findViewById(R.id.appinstall_headline));
        adView.setBodyView(adView.findViewById(R.id.appinstall_body));
        adView.setCallToActionView(adView.findViewById(R.id.appinstall_call_to_action));
        adView.setIconView(adView.findViewById(R.id.appinstall_app_icon));
        adView.setStarRatingView(adView.findViewById(R.id.appinstall_stars));

        // Some assets are guaranteed to be in every NativeAppInstallAd.
        ((TextView) adView.getHeadlineView()).setText(nativeAppInstallAd.getHeadline());
        ((TextView) adView.getBodyView()).setText(nativeAppInstallAd.getBody());
        ((Button) adView.getCallToActionView()).setText(nativeAppInstallAd.getCallToAction());
        ((ImageView) adView.getIconView()).setImageDrawable(
                nativeAppInstallAd.getIcon().getDrawable());

        // Assign native ad object to the native view.
        adView.setNativeAd(nativeAppInstallAd);
    }
*/

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

}
