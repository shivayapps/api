package com.example.ebitas1.bedtimestory.adpter;

import android.content.Context;

import androidx.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.ebitas1.bedtimestory.R;
import com.example.ebitas1.bedtimestory.model.BedTimeStory;

import java.util.List;

public class StoryListAdpter extends RecyclerView.Adapter<StoryListAdpter.CustomViewHolder> {

    private List<BedTimeStory> mListCategory;
    private Context mContext;
    int[] imageViews = {R.drawable.backgroundone, R.drawable.backgroundtwo, R.drawable.backgroundthree, R.drawable.backgroundfour,
            R.drawable.backgroundfive, R.drawable.backgroundsix};


    public StoryListAdpter(List<BedTimeStory> mListCategory, Context mContext) {
        this.mListCategory = mListCategory;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        View view = layoutInflater.inflate(R.layout.row_layout_list, null, false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder viewHolder, final int pos) {
        BedTimeStory c = mListCategory.get(pos);
        viewHolder.mStoryName.setText(c.getStory_name());
        int pindex = 0;
        int currentPoi = pos;


        if(currentPoi>=6){
            pindex=currentPoi%6;
        }else {
            pindex=currentPoi;
        }
        Log.e("pindex",""+pindex);

        viewHolder.mLinear.setBackgroundResource(imageViews[pindex]);

      /*  viewHolder.mLinear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(mContext,StoryDetailActivity.class);
                i.putExtra(Constant.POS,pos);
                mContext.startActivity(i);
            }
        });
*/

    }
    @Override
    public int getItemCount() {
        return mListCategory.size();
    }


    public class CustomViewHolder extends RecyclerView.ViewHolder {

        private TextView mStoryName;
        private LinearLayout mLinear;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);

            mStoryName = (TextView) itemView.findViewById(R.id.txtView);
            mLinear = (LinearLayout) itemView.findViewById(R.id.linearbg);
        }
    }

}
