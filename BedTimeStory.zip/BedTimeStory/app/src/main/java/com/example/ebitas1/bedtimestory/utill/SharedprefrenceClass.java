package com.example.ebitas1.bedtimestory.utill;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class SharedprefrenceClass {

    private static SharedprefrenceClass myprefernce;
    private static SharedPreferences sharedPreferences;

    public static SharedprefrenceClass getInstance(Context context) {
        if (myprefernce == null) {
            myprefernce = new SharedprefrenceClass(context);
        }
        return myprefernce;
    }

    private SharedprefrenceClass(Context context) {
        sharedPreferences = context.getSharedPreferences("mypref", Context.MODE_PRIVATE);
    }

    public void savevaluefont(String key, int value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putInt(key,value);
        prefsEditor.commit();
    }


    public int getvaluefont(String key) {
        if (sharedPreferences != null) {
            return sharedPreferences.getInt(key,0 );
        }
        return 0;
    }

    public void savevaluefonticon(String key, boolean value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putBoolean(key,value);
        prefsEditor.commit();
    }


    public Boolean getvaluefonticon(String key) {
        if (sharedPreferences != null) {
            return sharedPreferences.getBoolean(key, false);
        }
        return true;
    }


    //Use  for Save (value true or false)
    public void saveCheck(String key, boolean value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putBoolean(key, value);
        prefsEditor.commit();
    }


    public Boolean getCheck(String key) {
        if (sharedPreferences != null) {
            return sharedPreferences.getBoolean(key, false);
        }
        return false;
    }



    //Use  for boolean application(Check  Rate or not)
    public void savevalue(String key, boolean value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putBoolean(key,value);
        prefsEditor.commit();
    }


    public Boolean getvalue(String key) {
        if (sharedPreferences != null) {
            return sharedPreferences.getBoolean(key, false);
        }
        return true;
    }

    //Use  for save Open & close application
    public void saveOpenappshare(String key, int value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putInt(key, value);
        prefsEditor.commit();

    }


    public Integer getOpenApplicationShare(String key) {
        if (sharedPreferences != null) {
            return sharedPreferences.getInt(key, 0);
        }
        return 0;
    }


    //Use  for save Open & close application
    public void saveOpenapp(String key, int value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putInt(key, value);
        prefsEditor.commit();

    }


    public Integer getOpenApplication(String key) {
        if (sharedPreferences != null) {
            return sharedPreferences.getInt(key, 0);
        }
        return 0;
    }



    //Use  for save Bannaer
    public void saveOpenapp2(String key, int value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putInt(key, value);
        prefsEditor.commit();

    }


    public Integer getOpenApplication2(String key) {
        if (sharedPreferences != null) {
            return sharedPreferences.getInt(key, 0);
        }
        return 0;
    }


    //Use  for save Data-Use for content
    public void saveData(String key, String value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putString(key, value);
        prefsEditor.commit();

    }


    public String getData(String key) {
        if (sharedPreferences != null) {
            return sharedPreferences.getString(key, "");
        }
        return "";
    }

    //Use  for save Data2-Use For  Story Name
    public void saveData2(String key, String value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putString(key, value);
        prefsEditor.commit();

    }


    public String getData2(String key) {
        if (sharedPreferences != null) {
            return sharedPreferences.getString(key,"");
        }
        return "";
    }



    //Use  for save Data3--Use For Moral
    public void saveData3(String key, String value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putString(key, value);
        prefsEditor.commit();

    }


    public String getData3(String key) {
        if (sharedPreferences != null) {
            return sharedPreferences.getString(key,"");
        }
        return "";
    }


    //Use  for save Data3--Use For categtory
    public void saveData4(String key, String value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putString(key, value);
        prefsEditor.commit();

    }


    public String getData4(String key) {
        if (sharedPreferences != null) {
            return sharedPreferences.getString(key,"");
        }
        return "";
    }



    public static Integer getInteger(Context context, String key, int defaultValue) {

        if (sharedPreferences != null) {
            return sharedPreferences.getInt(key,defaultValue);
        }
        else
        {
            return defaultValue;
        }
    }


    public static void setInteger(Context context, String key, Integer Value) {

        sharedPreferences = PreferenceManager
                .getDefaultSharedPreferences(context);
        SharedPreferences.Editor sEdit = sharedPreferences.edit();
        sEdit.putInt(key, Value);
        sEdit.commit();

    }


    public static void setBoolean(Context context, String key, Boolean Value) {
        sharedPreferences = PreferenceManager
                .getDefaultSharedPreferences(context);
        SharedPreferences.Editor sEdit = sharedPreferences.edit();
        sEdit.putBoolean(key, Value);
        sEdit.commit();

    }



    public static Boolean getBoolean(Context context, String key, Boolean Value) {
        sharedPreferences = PreferenceManager
                .getDefaultSharedPreferences(context);
        Boolean value = sharedPreferences.getBoolean(key, Value);
        return value;
    }

}
