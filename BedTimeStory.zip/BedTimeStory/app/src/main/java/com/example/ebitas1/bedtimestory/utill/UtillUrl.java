package com.example.ebitas1.bedtimestory.utill;

public class UtillUrl {
    public static String url = "http://apps.ebizzprojects.com/CommonAppsData/moralstory/api/1.0/app_data.php";
    public static  String privacy_policy="http://apps.ebizzprojects.com/privacy_policy.html";
}

