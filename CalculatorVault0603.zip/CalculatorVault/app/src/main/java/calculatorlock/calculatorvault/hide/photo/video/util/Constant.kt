package calculatorlock.calculatorvault.hide.photo.video.util

object Constant {
    var isGridlayout = true
    var KEY_PASS = "key_pass"
    var FORGOT_PASS = "11223344"
    var DEFAULT_PASS = "987987987"

    val AudioArray = arrayOf(
        "3ga", "4mp", "8svx", "a2m", "aa", "aa3", "aac", "aax", "abc", "abm", "ac3",
        "acd", "acd-bak", "acd-zip", "acm", "act", "adg", "adt", "adts", "afc", "agm", "agr", "aif", "aifc", "aiff", "akp",
        "alc", "als", "amf", "amr", "ams", "amxd", "amz", "aob", "ape", "apl", "asd", "at3", "au", "aud", "aup", "band",
        "bap", "bdd", "bidule", "bun", "bwf", "bww", "caf", "caff", "cda", "cdda", "cdlx", "cdo", "cdr", "cel", "cfa",
        "cidb", "ckb", "conform", "copy", "cpr", "cpt", "csh", "cts", "cwb", "cwp", "dcf", "dcm", "dct", "dewf", "df2",
        "dfc", "dig", "dls", "dm", "dmf", "dmsa", "dmse", "dra", "drg", "ds2", "dsf", "dsm", "dss", "dtm", "dts", "dtshd",
        "dvf", "dwd", "efa", "efk", "efq", "efs", "efv", "emd", "emp", "emx", "esps", "f2r", "f32", "f3r", "f4a", "f64",
        "fdp", "fev", "flac", "flp", "frg", "fsb", "fsm", "ftm", "fzf", "fzv", "g721", "g723", "g726", "gbs", "gig", "gp5",
        "gpbank", "gpk", "gpx", "groove", "gsm", "hsb", "ics", "iff", "igp", "isma", "iti", "k26", "kar", "kfn", "koz", "kpl",
        "krz", "ksf", "kt3", "logic", "lso", "lwv", "m3u", "m3u8", "m4a", "m4b", "m4p", "m4r", "ma1", "mbr", "med", "mgv", "mid",
        "midi", "miniusf", "mka", "mmf", "mmm", "mmp", "mo3", "mod", "mp2", "mp3", "mpa", "mpc", "mpdp", "mpga", "mscz", "mte",
        "mtf", "mti", "mtm", "mtp", "mts", "mus", "mux", "mx5", "mxmf", "myr", "nbs", "ncw", "nkb", "nkc", "nki", "nkm",
        "nks", "nkx", "nra", "nrt", "nsa", "nsf", "nst", "ntn", "nwc", "odm", "oga", "ogg", "okt", "oma", "omf", "omg",
        "omx", "opus", "ots", "ove", "ovw", "pca", "pcast", "pcg", "peak", "pek", "pk", "pkf", "pla", "pls", "ply", "pna",
        "psf", "psm", "ptf", "ptm", "pts", "qcp", "r1m", "ra", "ram", "rax", "rbs", "rex", "rfl", "rip", "rmi", "rmj", "rmx",
        "rng", "rns", "rol", "rsn", "rso", "rti", "rx2", "s3i", "s3m", "sap", "sbi", "sc2", "scs11", "sd", "sd2", "sdat", "sds",
        "seq", "ses", "sesx", "sf2", "sfk", "sfl", "shn", "sib", "slp", "slx", "sma", "smf", "smp", "snd", "sng", "sou", "sppack",
        "sprg", "sseq", "stap", "stm", "stx", "sty", "svd", "swa", "sxt", "syh", "syn", "syw", "syx", "tak", "td0", "tg", "tta",
        "txw", "u", "uax", "ult", "uni", "usf", "usflib", "uw", "uwf", "vag", "vap", "vc3", "vlc", "vmd", "vmo", "voc", "vox",
        "voxal", "vpl", "vpm", "vqf", "vrf", "vsq", "vyf", "w01", "w64", "wav", "wave", "wax", "wfb", "wfd", "wfp", "wma",
        "wow", "wpk", "wpp", "wproj", "wrk", "wus", "wut", "wv", "wvc", "wve", "wwu", "xa", "xfs", "xm", "xrns", "xspf", "zpl", "zvd"
    )

    val DocumentArray = arrayOf(
        "323", "abw", "asc", "azw", "azw1", "bib", "cls", "csv", "diff", "doc", "docx", "eml", "enex",
        "epub", "fdx", "htm", "html", "ics", "icz", "lit", "lst", "ltx", "mml", "mobi", "mpp",
        "mpx", "msg", "nb", "numbers", "odp", "ods", "odt", "pdf", "pdx", "pot", "pps", "ppsx", "ppt",
        "pptm", "pptx", "prc", "qpw", "qvw", "rtf", "rtx", "sdc", "sig", "sty", "tex", "text", "tpz",
        "ts", "tsv", "txt", "uls", "vdx", "wb3", "wks", "wpd", "wps", "wpt", "xfdf", "xlr", "xls", "xlsx",
        "xltm", "xltx", "xsl", "xslt", "yml","7z", "apk", "arc", "boo", "c", "c++", "cpp", "csh", "cxx", "d", "etx",
        "gcd", "h++", "hh", "hpp", "hs", "htc", "hxx", "java", "lhs", "moc", "p", "pas", "php",
        "rar", "tar", "tcl", "vcf", "vcs", "zip")

}