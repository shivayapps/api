package calculatorlock.calculatorvault.hide.photo.video.db

class PhotoItem : BaseItem {
    override var id = 0
    override var displayName: String? = null
    override var path: String? = null
    override var newPath: String? = null
    override var size: Long = 0
    override var mimeType: String? = null
    var isChecked = false

    constructor(id: Int, displayName: String?, path: String?) : super(id, displayName, path) {}
    constructor(id: Int, displayName: String?, path: String?, size: Long) : super(
        id,
        displayName,
        path,
        size
    ) {
    }

    constructor(
        id: Int,
        displayName: String?,
        path: String?,
        size: Long,
        modified: Long,
        mimeType: String?
    ) : super(id, displayName, path, size, modified, mimeType) {
    }

    constructor(
        anInt: Int,
        displayName: String?,
        oripath: String?,
        newpath: String?,
        size: Long,
        mimeType: String?,
        cId: String?,
        trash: Int
    ) {
        id = anInt
        this.displayName = displayName
        path = oripath
        newPath = newpath
        this.size = size
        this.mimeType = mimeType
    }

    constructor() {}

    override fun toString(): String {
        return "PhotoItem{" +
                "checked=" + isChecked +
                '}'
    }

    companion object {
        const val TABLE_NAME = "tabImage"
        const val COLUMN_ID = "id"
        const val COLUMN_DNAME = "displayName"
        const val COLUMN_ORIPATH = "oripath"
        const val COLUMN_NEWPATH = "newpath"
        const val COLUMN_SIZE = "filesize"
        const val COLUMN_MIMETYPE = "mimeType"
        const val COLUMN_CLOUD_FILE_ID = "cloud_file_id"
        const val COLUMN_TRASH = "trash"

        // Create table SQL query
        const val CREATE_TABLE = ("CREATE TABLE " + TABLE_NAME + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_DNAME + " TEXT,"
                + COLUMN_ORIPATH + " TEXT,"
                + COLUMN_NEWPATH + " TEXT,"
                + COLUMN_SIZE + " LONG,"
                + COLUMN_MIMETYPE + " TEXT,"
                + COLUMN_CLOUD_FILE_ID + " TEXT DEFAULT null,"
                + COLUMN_TRASH + " INTEGER DEFAULT 0"
                + ")")
    }
}