package calculatorlock.calculatorvault.hide.photo.video.db


class VideoItem : BaseItem {
    override var id = 0
    override var displayName: String? = null
    override var path: String? = null
    override var newPath: String? = null
    override var size: Long = 0
    override var mimeType: String? = null
    var duration: Long = 0
    var isChecked = false

    constructor(
        anInt: Int,
        displayName: String?,
        oripath: String?,
        newpath: String?,
        size: Long,
        duration: Long,
        mimeType: String?
    ) {
        id = anInt
        this.displayName = displayName
        path = oripath
        newPath = newpath
        this.size = size
        this.duration = duration
        this.mimeType = mimeType
    }

    constructor(
        id: Int,
        displayName: String?,
        path: String?,
        size: Long,
        duration: Long,
        mimeType: String?
    ) : super(id, displayName, path, size, duration, mimeType) {
        this.duration = duration
    }

    constructor(
        id: Int,
        displayName: String?,
        path: String?,
        size: Long,
        modified: Long,
        duration: Long,
        mimeType: String?
    ) : super(id, displayName, path, size, modified, mimeType) {
        this.duration = duration
    }

    constructor() {}

    companion object {
        const val TABLE_NAME = "tabVideo"
        const val COLUMN_ID = "id"
        const val COLUMN_DNAME = "displayName"
        const val COLUMN_ORIPATH = "oripath"
        const val COLUMN_NEWPATH = "newpath"
        const val COLUMN_SIZE = "filesize"
        const val COLUMN_MIMETYPE = "mimeType"
        const val COLUMN_CLOUD_FILE_ID = "cloud_file_id"
        const val COLUMN_TRASH = "trash"

        // Create table SQL query
        const val CREATE_TABLE = ("CREATE TABLE " + TABLE_NAME + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_DNAME + " TEXT,"
                + COLUMN_ORIPATH + " TEXT,"
                + COLUMN_NEWPATH + " TEXT,"
                + COLUMN_SIZE + " LONG DEFAULT 0,"
                + COLUMN_MIMETYPE + " TEXT,"
                + COLUMN_CLOUD_FILE_ID + " TEXT DEFAULT null,"
                + COLUMN_TRASH + " INTEGER DEFAULT 0"
                + ")")
    }
}