package calculatorlock.calculatorvault.hide.photo.video.filepicker

import android.content.pm.ActivityInfo
import android.net.Uri
import calculatorlock.calculatorvault.hide.photo.video.R
import java.util.ArrayList

import calculatorlock.calculatorvault.hide.photo.video.filepicker.models.BaseFile
import calculatorlock.calculatorvault.hide.photo.video.filepicker.models.FileType
import calculatorlock.calculatorvault.hide.photo.video.filepicker.models.sort.SortingTypes
import java.util.LinkedHashSet

/**
 * Created by droidNinja on 29/07/16.
 */
object PickerManager {
    private var maxCount = FilePickerConst.DEFAULT_MAX_COUNT
    private var showImages = true
    var cameraDrawable = R.drawable.ic_camera
    var sortingType = SortingTypes.NONE

    val selectedPhotos: ArrayList<Uri> = ArrayList()
    val selectedFiles: ArrayList<Uri> = ArrayList()

    private val fileTypes: LinkedHashSet<FileType> = LinkedHashSet()

    var theme: Int = R.style.LibAppTheme

    var title: String? = null

    private var showVideos: Boolean = false

    var isShowGif: Boolean = false

    private var showSelectAll = false

    var imageFileSize: Int = FilePickerConst.DEFAULT_FILE_SIZE
    var videoFileSize: Int = FilePickerConst.DEFAULT_FILE_SIZE

    var isDocSupport = true
        get() = field

    var isEnableCamera = true

    /**
     * Recyclerview span count for both folder and detail screen
     * Default Folder span is 2
     * Default Detail Span is 3
     */
    var spanTypes = mutableMapOf(
            FilePickerConst.SPAN_TYPE.FOLDER_SPAN to 2,
            FilePickerConst.SPAN_TYPE.DETAIL_SPAN to 3
    )

    /**
     * The preferred screen orientation this activity would like to run in.
     * From the {@link android.R.attr#screenOrientation} attribute, one of
     * {@link #SCREEN_ORIENTATION_UNSPECIFIED},
     * {@link #SCREEN_ORIENTATION_LANDSCAPE},
     * {@link #SCREEN_ORIENTATION_PORTRAIT},
     * {@link #SCREEN_ORIENTATION_USER},
     * {@link #SCREEN_ORIENTATION_BEHIND},
     * {@link #SCREEN_ORIENTATION_SENSOR},
     * {@link #SCREEN_ORIENTATION_NOSENSOR},
     * {@link #SCREEN_ORIENTATION_SENSOR_LANDSCAPE},
     * {@link #SCREEN_ORIENTATION_SENSOR_PORTRAIT},
     * {@link #SCREEN_ORIENTATION_REVERSE_LANDSCAPE},
     * {@link #SCREEN_ORIENTATION_REVERSE_PORTRAIT},
     * {@link #SCREEN_ORIENTATION_FULL_SENSOR},
     * {@link #SCREEN_ORIENTATION_USER_LANDSCAPE},
     * {@link #SCREEN_ORIENTATION_USER_PORTRAIT},
     * {@link #SCREEN_ORIENTATION_FULL_USER},
     * {@link #SCREEN_ORIENTATION_LOCKED},
     */
    var orientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        get() = field

    var isShowFolderView = true

    val currentCount: Int
        get() = selectedPhotos.size + selectedFiles.size

    fun setMaxCount(count: Int) {
        reset()
        this.maxCount = count
    }

    fun getMaxCount(): Int {
        return maxCount
    }

    fun add(path: Uri?, type: Int) {
        if (path != null && shouldAdd()) {
            if (!selectedPhotos.contains(path) && type == FilePickerConst.FILE_TYPE_AUDIO) {
                selectedPhotos.add(path)
            } else if (!selectedFiles.contains(path) && type == FilePickerConst.FILE_TYPE_DOCUMENT) {
                selectedFiles.add(path)
            } else {
                return
            }
        }
    }

    fun add(paths: List<Uri>, type: Int) {
        for (index in paths.indices) {
            add(paths[index], type)
        }
    }

    fun remove(path: Uri?, type: Int) {
        if (type == FilePickerConst.FILE_TYPE_AUDIO && selectedPhotos.contains(path)) {
            selectedPhotos.remove(path)
        } else if (type == FilePickerConst.FILE_TYPE_DOCUMENT) {
            selectedFiles.remove(path)
        }
    }

    fun shouldAdd(): Boolean {
        return if (maxCount == -1) true else currentCount < maxCount
    }

    fun getSelectedFilePaths(files: ArrayList<BaseFile>): ArrayList<Uri> {
        val paths = ArrayList<Uri>()
        for (index in files.indices) {
            paths.add(files[index].path)
        }
        return paths
    }

    fun reset() {
        selectedFiles.clear()
        selectedPhotos.clear()
        fileTypes.clear()
        maxCount = -1
    }

    fun clearSelections() {
        selectedPhotos.clear()
        selectedFiles.clear()
    }

    fun deleteMedia(paths: List<Uri>) {
        selectedPhotos.removeAll(paths)
    }

    fun showVideo(): Boolean {
        return showVideos
    }

    fun setShowVideos(showVideos: Boolean) {
        this.showVideos = showVideos
    }

    fun showImages(): Boolean {
        return showImages
    }

    fun setShowImages(showImages: Boolean) {
        this.showImages = showImages
    }

    fun addFileType(fileType: FileType) {
        fileTypes.add(fileType)
    }

    val AudioArray = arrayOf(
        "3ga", "4mp", "8svx", "a2m", "aa", "aa3", "aac", "aax", "abc", "abm", "ac3",
        "acd", "acd-bak", "acd-zip", "acm", "act", "adg", "adt", "adts", "afc", "agm", "agr", "aif", "aifc", "aiff", "akp",
        "alc", "als", "amf", "amr", "ams", "amxd", "amz", "aob", "ape", "apl", "asd", "at3", "au", "aud", "aup", "band",
        "bap", "bdd", "bidule", "bun", "bwf", "bww", "caf", "caff", "cda", "cdda", "cdlx", "cdo", "cdr", "cel", "cfa",
        "cidb", "ckb", "conform", "copy", "cpr", "cpt", "csh", "cts", "cwb", "cwp", "dcf", "dcm", "dct", "dewf", "df2",
        "dfc", "dig", "dls", "dm", "dmf", "dmsa", "dmse", "dra", "drg", "ds2", "dsf", "dsm", "dss", "dtm", "dts", "dtshd",
        "dvf", "dwd", "efa", "efk", "efq", "efs", "efv", "emd", "emp", "emx", "esps", "f2r", "f32", "f3r", "f4a", "f64",
        "fdp", "fev", "flac", "flp", "frg", "fsb", "fsm", "ftm", "fzf", "fzv", "g721", "g723", "g726", "gbs", "gig", "gp5",
        "gpbank", "gpk", "gpx", "groove", "gsm", "hsb", "ics", "iff", "igp", "isma", "iti", "k26", "kar", "kfn", "koz", "kpl",
        "krz", "ksf", "kt3", "logic", "lso", "lwv", "m3u", "m3u8", "m4a", "m4b", "m4p", "m4r", "ma1", "mbr", "med", "mgv", "mid",
        "midi", "miniusf", "mka", "mmf", "mmm", "mmp", "mo3", "mod", "mp2", "mp3", "mpa", "mpc", "mpdp", "mpga", "mscz", "mte",
        "mtf", "mti", "mtm", "mtp", "mts", "mus", "mux", "mx5", "mxmf", "myr", "nbs", "ncw", "nkb", "nkc", "nki", "nkm",
        "nks", "nkx", "nra", "nrt", "nsa", "nsf", "nst", "ntn", "nwc", "odm", "oga", "ogg", "okt", "oma", "omf", "omg",
        "omx", "opus", "ots", "ove", "ovw", "pca", "pcast", "pcg", "peak", "pek", "pk", "pkf", "pla", "pls", "ply", "pna",
        "psf", "psm", "ptf", "ptm", "pts", "qcp", "r1m", "ra", "ram", "rax", "rbs", "rex", "rfl", "rip", "rmi", "rmj", "rmx",
        "rng", "rns", "rol", "rsn", "rso", "rti", "rx2", "s3i", "s3m", "sap", "sbi", "sc2", "scs11", "sd", "sd2", "sdat", "sds",
        "seq", "ses", "sesx", "sf2", "sfk", "sfl", "shn", "sib", "slp", "slx", "sma", "smf", "smp", "snd", "sng", "sou", "sppack",
        "sprg", "sseq", "stap", "stm", "stx", "sty", "svd", "swa", "sxt", "syh", "syn", "syw", "syx", "tak", "td0", "tg", "tta",
        "txw", "u", "uax", "ult", "uni", "usf", "usflib", "uw", "uwf", "vag", "vap", "vc3", "vlc", "vmd", "vmo", "voc", "vox",
        "voxal", "vpl", "vpm", "vqf", "vrf", "vsq", "vyf", "w01", "w64", "wav", "wave", "wax", "wfb", "wfd", "wfp", "wma",
        "wow", "wpk", "wpp", "wproj", "wrk", "wus", "wut", "wv", "wvc", "wve", "wwu", "xa", "xfs", "xm", "xrns", "xspf", "zpl", "zvd"
    )

    fun addAudioTypes() {
        fileTypes.add(FileType(FilePickerConst.AUDIO, AudioArray, R.drawable.icon_file_doc))
    }

    val DocumentArray = arrayOf(
        "323", "abw", "asc", "azw", "azw1", "bib", "cls", "csv", "diff", "doc", "docx", "eml", "enex",
        "epub", "fdx", "htm", "html", "ics", "icz", "lit", "lst", "ltx", "mml", "mobi", "mpp",
        "mpx", "msg", "nb", "numbers", "odp", "ods", "odt", "pdf", "pdx", "pot", "pps", "ppsx", "ppt",
        "pptm", "pptx", "prc", "qpw", "qvw", "rtf", "rtx", "sdc", "sig", "sty", "tex", "text", "tpz",
        "ts", "tsv", "txt", "uls", "vdx", "wb3", "wks", "wpd", "wps", "wpt", "xfdf", "xlr", "xls", "xlsx",
        "xltm", "xltx", "xsl", "xslt", "yml","7z", "apk", "arc", "boo", "c", "c++", "cpp", "csh", "cxx", "d", "etx",
        "gcd", "h++", "hh", "hpp", "hs", "htc", "hxx", "java", "lhs", "moc", "p", "pas", "php",
        "rar", "tar", "tcl", "vcf", "vcs", "zip")

    fun addDocTypes() {
        fileTypes.add(FileType(FilePickerConst.DOC, DocumentArray, R.drawable.icon_file_doc))
    }

    fun getFileTypes(): ArrayList<FileType> {
        return ArrayList(fileTypes)
    }

    fun hasSelectAll(): Boolean {
        return maxCount == -1 && showSelectAll
    }

    fun enableSelectAll(showSelectAll: Boolean) {
        this.showSelectAll = showSelectAll
    }
}
