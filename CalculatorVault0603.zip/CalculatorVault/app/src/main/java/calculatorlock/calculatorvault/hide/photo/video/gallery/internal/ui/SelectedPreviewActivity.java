package calculatorlock.calculatorvault.hide.photo.video.gallery.internal.ui;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


import calculatorlock.calculatorvault.hide.photo.video.gallery.internal.entity.Item;
import calculatorlock.calculatorvault.hide.photo.video.gallery.internal.entity.SelectionSpec;
import calculatorlock.calculatorvault.hide.photo.video.gallery.internal.model.SelectedItemCollection;

import java.util.List;

public class SelectedPreviewActivity extends BasePreviewActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!SelectionSpec.getInstance().hasInited) {
            setResult(RESULT_CANCELED);
            finish();
            return;
        }

        Bundle bundle = getIntent().getBundleExtra(EXTRA_DEFAULT_BUNDLE);
        List<Item> selected = bundle.getParcelableArrayList(SelectedItemCollection.STATE_SELECTION);
        mAdapter.addAll(selected);
        mAdapter.notifyDataSetChanged();
        if (mSpec.countable) {
            mCheckView.setCheckedNum(1);
        } else {
            mCheckView.setChecked(true);
        }
        mPreviousPos = 0;
        updateSize(selected.get(0));
    }

    @NonNull
    @Override
    public AppCompatActivity getContext() {
        return SelectedPreviewActivity.this;
    }

    @Override
    public void initViews() {

    }

    @Override
    public void initAds() {

    }

    @Override
    public void initData() {

    }

    @Override
    public void initActions() {

    }
}
