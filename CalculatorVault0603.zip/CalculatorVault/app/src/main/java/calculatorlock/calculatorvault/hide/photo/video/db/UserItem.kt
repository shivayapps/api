package calculatorlock.calculatorvault.hide.photo.video.db


class UserItem {
    var id = 0
    var pwd: String? = null
    var squestion: String? = null
    var answer: String? = null
    var email: String? = null
    var forgotPin: String? = null

    constructor() {}
    constructor(
        id: Int,
        pwd: String?,
        squestion: String?,
        answer: String?,
        email: String?,
        forgotPin: String?
    ) {
        this.id = id
        this.pwd = pwd
        this.squestion = squestion
        this.answer = answer
        this.email = email
        this.forgotPin = forgotPin
    }

    constructor(id: Int, pwd: String?, squestion: String?, answer: String?) {
        this.id = id
        this.pwd = pwd
        this.squestion = squestion
        this.answer = answer
    }

    override fun toString(): String {
        return "UserItem{" +
                "id=" + id +
                ", pwd='" + pwd + '\'' +
                ", squestion='" + squestion + '\'' +
                ", answer='" + answer + '\'' +
                ", email='" + email + '\'' +
                ", forgotPin='" + forgotPin + '\'' +
                '}'
    }

    companion object {
        const val TABLE_NAME = "tabUser"
        const val COLUMN_ID = "id"
        const val COLUMN_PWD = "passwrod"
        const val COLUMN_SQUESTION = "squestion"
        const val COLUMN_ANSWER = "answer"
        const val COLUMN_EMAIL = "email"
        const val COLUMN_FORGOT_PIN = "forgot_pin"

        // Create table SQL query
        const val CREATE_TABLE = ("CREATE TABLE " + TABLE_NAME + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_PWD + " TEXT,"
                + COLUMN_SQUESTION + " TEXT,"
                + COLUMN_ANSWER + " TEXT,"
                + COLUMN_EMAIL + " TEXT,"
                + COLUMN_FORGOT_PIN + " TEXT"
                + ")")
    }
}