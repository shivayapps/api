package calculatorlock.calculatorvault.hide.photo.video.filepicker.adapters

import android.content.Context
import android.net.Uri
import androidx.recyclerview.widget.RecyclerView
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView

import com.bumptech.glide.RequestManager
import com.bumptech.glide.request.RequestOptions

import java.io.File
import java.util.ArrayList

import calculatorlock.calculatorvault.hide.photo.video.filepicker.FilePickerConst
import calculatorlock.calculatorvault.hide.photo.video.filepicker.PickerManager
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.filepicker.models.Media
import calculatorlock.calculatorvault.hide.photo.video.filepicker.utils.AndroidLifecycleUtils
import calculatorlock.calculatorvault.hide.photo.video.filepicker.views.SmoothCheckBox
import calculatorlock.calculatorvault.hide.photo.video.gallery.internal.ui.widget.CheckView

class PhotoGridAdapter(private val context: Context,
                       private val glide: RequestManager,
                       medias: List<Media>,
                       selectedPaths: MutableList<Uri>,
                       private val showCamera: Boolean,
                       private val mListener: FileAdapterListener?) : SelectableAdapter<PhotoGridAdapter.PhotoViewHolder, Media>(medias, selectedPaths) {
    private var imageSize: Int = 0
    private var cameraOnClickListener: View.OnClickListener? = null

    init {
        setColumnNumber(context, 3)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoViewHolder {
        val itemView = LayoutInflater.from(context).inflate(R.layout.item_photo_layout, parent, false)

        return PhotoViewHolder(itemView)
    }

    override fun getItemViewType(position: Int): Int {
        return if (showCamera)
            if (position == 0) ITEM_TYPE_CAMERA else ITEM_TYPE_PHOTO
        else
            ITEM_TYPE_PHOTO
    }

    override fun onBindViewHolder(holder: PhotoViewHolder, position: Int) {
        if (getItemViewType(position) == ITEM_TYPE_PHOTO) {

            val media = items[if (showCamera) position - 1 else position]

            if (AndroidLifecycleUtils.canLoadImage(holder.imageView.context)) {
                glide.load(media.path)
                        .apply(RequestOptions
                                .centerCropTransform()
                                .override(imageSize, imageSize)
                                .placeholder(R.drawable.image_placeholder))
                        .thumbnail(0.5f)
                        .into(holder.imageView)
            }


            if (media.mediaType == FilePickerConst.MEDIA_TYPE_VIDEO) {
                holder.videoIcon.visibility = View.VISIBLE
            }
            else {
                holder.videoIcon.visibility = View.GONE
            }

            holder.itemView.setOnClickListener { onItemClicked(holder, media) }

            holder.checkBox.visibility = View.GONE
            holder.checkBox.setOnClickListener { onItemClicked(holder, media) }

            //if true, your checkbox will be selected, else unselected
            holder.checkBox.setChecked(isSelected(media))

            holder.selectBg.visibility = if (isSelected(media)) View.VISIBLE else View.GONE
            holder.checkBox.visibility = if (isSelected(media)) View.VISIBLE else View.GONE

            if(holder.checkBox.getChecked()) {
                holder.checkBox.visibility = View.VISIBLE
            } else {
                holder.checkBox.visibility = View.GONE
            }

            if(PickerManager.currentCount>=1) holder.checkBox.visibility = View.VISIBLE
            Log.e("PickerManager", "currentCount: ${PickerManager.currentCount}")

            holder.checkBox.setOnClickListener {
                toggleSelection(media)
                holder.selectBg.visibility = if (holder.checkBox.isSelected) View.VISIBLE else View.GONE

                if (holder.checkBox.isSelected) {
                    if(PickerManager.currentCount>=1) holder.checkBox.visibility = View.VISIBLE
                    PickerManager.add(media.path, FilePickerConst.FILE_TYPE_AUDIO)
                } else {
                    holder.checkBox.visibility = View.GONE
                    PickerManager.remove(media.path, FilePickerConst.FILE_TYPE_AUDIO)
                }

                mListener?.onItemSelected()
            }

//            holder.checkBox.setOnCheckedChangeListener(object : SmoothCheckBox.OnCheckedChangeListener {
//                override fun onCheckedChanged(checkBox: SmoothCheckBox, isChecked: Boolean) {
//                    toggleSelection(media)
//                    holder.selectBg.visibility = if (isChecked) View.VISIBLE else View.GONE
//
//                    if (isChecked) {
//                        holder.checkBox.visibility = View.VISIBLE
//                        PickerManager.add(media.path, FilePickerConst.FILE_TYPE_AUDIO)
//                    } else {
//                        holder.checkBox.visibility = View.GONE
//                        PickerManager.remove(media.path, FilePickerConst.FILE_TYPE_AUDIO)
//                    }
//
//                    mListener?.onItemSelected()
//                }
//            })

        } else {
            holder.imageView.setImageResource(PickerManager.cameraDrawable)
            holder.checkBox.visibility = View.GONE
            holder.itemView.setOnClickListener(cameraOnClickListener)
            holder.videoIcon.visibility = View.GONE
        }
    }

    private fun onItemClicked(holder: PhotoViewHolder, media: Media) {
        if (PickerManager.getMaxCount() == 1) {
            PickerManager.add(media.path, FilePickerConst.FILE_TYPE_AUDIO)
            mListener?.onItemSelected()
        } else if (holder.checkBox.isSelected || PickerManager.shouldAdd()) {
            holder.checkBox.setChecked(!holder.checkBox.isSelected)
        }
    }

    private fun setColumnNumber(context: Context, columnNum: Int) {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        wm.defaultDisplay.getMetrics(metrics)
        val widthPixels = metrics.widthPixels
        imageSize = widthPixels / columnNum
    }

    override fun getItemCount(): Int {
        return if (showCamera) items.size + 1 else items.size
    }

    fun setCameraListener(onClickListener: View.OnClickListener) {
        this.cameraOnClickListener = onClickListener
    }

    class PhotoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

//        var checkBox: SmoothCheckBox
        var checkBox: CheckView

        var imageView: ImageView

        var videoIcon: ImageView

        var selectBg: View

        init {
            checkBox = itemView.findViewById<View>(R.id.checkbox) as CheckView
            imageView = itemView.findViewById<View>(R.id.iv_photo) as ImageView
            videoIcon = itemView.findViewById<View>(R.id.video_icon) as ImageView
            selectBg = itemView.findViewById(R.id.transparent_bg)
        }
    }

    companion object {

        val ITEM_TYPE_CAMERA = 100
        val ITEM_TYPE_PHOTO = 101
    }
}
