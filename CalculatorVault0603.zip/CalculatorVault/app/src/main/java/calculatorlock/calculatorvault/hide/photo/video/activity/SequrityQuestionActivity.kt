package calculatorlock.calculatorvault.hide.photo.video.activity

import android.content.Context
import android.content.Intent
import android.graphics.PorterDuff
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import calculatorlock.calculatorvault.hide.photo.video.MyCommonBaseActivity
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.db.DatabaseHelper
import calculatorlock.calculatorvault.hide.photo.video.db.UserItem
import calculatorlock.calculatorvault.hide.photo.video.util.DialogHelper
import kotlinx.android.synthetic.main.activity_security_queation.*

class SequrityQuestionActivity : MyCommonBaseActivity(), View.OnClickListener {

    private var mContext: Context? = null
    private var mIvBack: ImageView? = null

    //    private var mSpinnerQuestions: Spinner? = null
    private var mEtAnswer: EditText? = null
    private var mBtnShow: TextView? = null
    private var mFromWhere: String = ""
    private var mPin: String? = ""
    private var uId: Long = 0

    var databaseHelper: DatabaseHelper? = null
    var userItem: UserItem? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_security_queation)
        mActivity = this@SequrityQuestionActivity
        mContext = this@SequrityQuestionActivity

        val intent = intent


        if (intent.hasExtra("fromWhere")) {
            mFromWhere = intent.getStringExtra("fromWhere")!!
        }
        if (intent.hasExtra("uId")) {
            uId = intent.getLongExtra("uId", 0)
        }
        if (intent.hasExtra("pwd")) {
            mPin = intent.getStringExtra("pwd")
        }

        initViewActions()
    }

    override fun getContext(): AppCompatActivity {
        return this@SequrityQuestionActivity
    }

    private fun initViewActions() {
        mBtnShow!!.setOnClickListener(this)
        mIvBack!!.setOnClickListener(this)
        databaseHelper = DatabaseHelper(this@SequrityQuestionActivity)

        if (mFromWhere.equals("initialSetup", ignoreCase = true) || mFromWhere.equals("changePwd", ignoreCase = true)) {
            spinner_security_questions!!.setSelection(0, true)
            mBtnShow!!.setText(R.string.set_answer)
        } else {
            userItem = databaseHelper!!.getUser()

            val stringQuestionvalue = resources.getStringArray(R.array.array_question)
            var qPos = 0

            if (userItem != null) {
                for (i in stringQuestionvalue.indices) {
                    if (userItem!!.squestion.equals(stringQuestionvalue.get(i), true)) qPos = i
                }
                spinner_security_questions!!.setSelection(qPos, true)
            }
            mBtnShow!!.setText(R.string.show_passcode)
        }
    }

    override fun initViews() {
//        mDBImageVideo = ImageVideoDatabase(mActivity)

        mIvBack = findViewById(R.id.iv_back)
//        mSpinnerQuestions = findViewById(R.id.spinner_security_questions)
        mEtAnswer = findViewById(R.id.et_security_answer)
        mBtnShow = findViewById(R.id.btn_security_show)
    }

    override fun initAds() {

    }

    override fun initData() {

        val stringQuestionvalue = resources.getStringArray(R.array.array_question)
        val adapter: ArrayAdapter<String> = ArrayAdapter<String>(this, R.layout.spinner_item, stringQuestionvalue)
        spinner_security_questions.adapter = adapter
        spinner_security_questions.onItemSelectedListener=object :AdapterView.OnItemSelectedListener{
            override fun onItemSelected(adapterView: AdapterView<*>?, view: View?, i: Int, l: Long) {
                val selected=adapterView?.selectedItemPosition
                (spinner_security_questions.selectedView as TextView).setTextColor(resources.getColor(R.color.white))
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }
        spinner_security_questions.background.setColorFilter(resources.getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);

    }

    override fun initActions() {

    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.iv_back -> onBackPressed()
            R.id.btn_security_show -> {
                if (mFromWhere.equals("initialSetup", ignoreCase = true)|| mFromWhere.equals("changePwd", ignoreCase = true)) {

                    if (mEtAnswer!!.text.toString().trim { it <= ' ' }.length != 0) {
                        setQuestionsAnswer(
                            spinner_security_questions!!.getItemAtPosition(spinner_security_questions!!.selectedItemPosition).toString(),
                            mEtAnswer!!.text.toString().trim { it <= ' ' })
                    } else {
                        Toast.makeText(this, "Answer is not valid.", Toast.LENGTH_LONG).show()
                    }
                } else {
                    showPasscode(mEtAnswer!!.text.toString().trim { it <= ' ' })
                }
            }
        }
    }

    private fun setQuestionsAnswer(question: String, answer: String) {
        val lUserModel = UserItem()
        lUserModel.id = 1
        lUserModel.squestion = question
        lUserModel.answer = answer

        var dbUpdate: Long = 0L
//        if(mFromWhere.equals("changePwd", ignoreCase = true)) {
//            dbUpdate = databaseHelper!!.updateUserPinSecurityQue(uId.toString(),mPin, question, answer).toLong()
//        } else {
//            dbUpdate = databaseHelper!!.insertUser(mPin, question, answer)
//        }

        databaseHelper!!.deleteUser()
        dbUpdate = databaseHelper!!.insertUser(mPin, question, answer)

        if (dbUpdate <= 0) {
            Log.e("SecurityActivity", "setQuestionsAnswer: Table not updated!!! $dbUpdate")
            Toast.makeText(mActivity, "Something went wrong setting answer please try again.", Toast.LENGTH_LONG).show()
        } else {
            Log.e("SecurityActivity", "setQuestionsAnswer: QUESTION_ANSWER_ADDED $dbUpdate")
            DialogHelper.securityConfirmDialog(
                this@SequrityQuestionActivity,
                question,
                answer,mFromWhere,
                mPin!!
            )
        }

        userItem = databaseHelper!!.getUser()
    }

    private fun showPasscode(answer: String) {
        if (TextUtils.isEmpty(answer)) {
            Toast.makeText(this, getString(R.string.answer_cannot_be_empty), Toast.LENGTH_LONG).show()
        } else if (!isAnswerValid(answer)) {
            Toast.makeText(this, getString(R.string.answer_did_not_match_to_your_question), Toast.LENGTH_LONG).show()
        } else {
            //Toast.makeText(this, "Answer matched.", Toast.LENGTH_LONG).show();
            displayPasscodeDialog()
        }
    }

    private fun displayPasscodeDialog() {
//        DialogHelper.securityConfirmDialog(
//            this@SequrityQuestionActivity,
//            getString(R.string.Recover_passcode),
//            getString(R.string.your_passcode_is) + userItem!!.pwd.toString() + "=",
//            mFromWhere
//        )
        DialogHelper.securityConfirmDialog(
            this@SequrityQuestionActivity,
            userItem!!.squestion,
            userItem!!.answer.toString(),
            mFromWhere,
            userItem!!.pwd!!
        )
    }

    private fun isAnswerValid(answer: String): Boolean {
        return try {
            val stringQuestionvalue = resources.getStringArray(R.array.array_question)

            Log.e(
                "isAnswerValid",
                "isAnswerValid_Q01: ${stringQuestionvalue.get(spinner_security_questions!!.selectedItemPosition)}"
            )
            Log.e("isAnswerValid", "isAnswerValid_Q02: ${userItem!!.squestion}")
            Log.e("isAnswerValid", "isAnswerValid_A01: ${answer}")
            Log.e("isAnswerValid", "isAnswerValid_A02: ${userItem!!.answer}")

//            if (userItem.getSquestion() === mSpinnerQuestions!!.selectedItemPosition) userItem.getAnswer()
            if (userItem!!.squestion == stringQuestionvalue.get(spinner_security_questions!!.selectedItemPosition))
                userItem!!.answer.equals(answer, true) else false
        } catch (ex: Exception) {
            false
        }
    }

    override fun onBackPressed() {
        if (mFromWhere.equals("forgotPass", ignoreCase = true)) {
            val act: Intent = Intent(this@SequrityQuestionActivity, MainActivity::class.java)
            act.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
            act.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            act.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(act)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        } else {
            mFromWhere=""
            mPin=""
            uId=0
            super.onBackPressed()
        }
    }
}