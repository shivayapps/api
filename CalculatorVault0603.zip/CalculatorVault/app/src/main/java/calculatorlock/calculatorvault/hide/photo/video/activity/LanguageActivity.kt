package calculatorlock.calculatorvault.hide.photo.video.activity


import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import calculatorlock.calculatorvault.hide.photo.video.MyCommonBaseActivity
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.adapters.LanguageAdapter
import calculatorlock.calculatorvault.hide.photo.video.callback.RVClickListener
import calculatorlock.calculatorvault.hide.photo.video.multilang.LocaleManager
import calculatorlock.calculatorvault.hide.photo.video.multilang.Locales
import calculatorlock.calculatorvault.hide.photo.video.util.Language
import calculatorlock.calculatorvault.hide.photo.video.util.SharedPrefsConstant
import calculatorlock.calculatorvault.hide.photo.video.util.getLanguageOptions
import com.example.app.ads.helper.GiftIconHelper
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import kotlinx.android.synthetic.main.activity_language.*
import java.util.*


class LanguageActivity : MyCommonBaseActivity(), View.OnClickListener {

//    var mContext: Context? = null
    private var languageClick = Language(R.string.english, "en")

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_language)
//        mContext = this@LanguageActivity

        initAction()
        initData()


    }


    private fun initAction() {
        iv_back.setOnClickListener(this)
    }

    override fun initData() {

        val languageOptions = getLanguageOptions()

        val languageAdapter =
            LanguageAdapter(mActivity!!, languageOptions, object : RVClickListener {
                override fun onItemClick(position: Int) {
                    languageOptions[position].isSelected = true
                    languageClick = languageOptions[position]
                    dialogChangeLanguage(languageClick)
                }
            })
//        rv_language.addItemDecoration(RvGridSpacingItemDecoration(1, 0, true))
        rv_language.adapter = languageAdapter
    }

    override fun initActions() {

    }


    private fun dialogChangeLanguage(languageClick: Language) {
        val dialog = Dialog(mActivity!!)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_language_confirm)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<View>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.dismiss()
        }
        dialog.findViewById<View>(R.id.dialogButtonOk).setOnClickListener {

            SharedPrefsConstant.save(
                mActivity,
                SharedPrefsConstant.SELECTED_LANGUAGE,
                languageClick.type
            )
            SharedPrefsConstant.save(
                mActivity,
                SharedPrefsConstant.SELECTED_LANGUAGE_LABLE,
                getString(languageClick.name)
            )
            Log.e("ChangeLanguage", "languageClick:" + languageClick.type)
            manageLanguage()

            dialog.dismiss()
        }
        dialog.show()
    }


    fun manageLanguage() {
        LocaleManager.setNewLocale(mActivity, languageClick.type)

        SharedPrefsConstant.savePref(mActivity, "isLocaleChanged", true)
        onBackPressed()

//        SharedPrefsConstant.save(mActivity, SharedPrefsConstant.SELECTED_LANGUAGE, languageClick.type)
//        SharedPrefsConstant.save(mActivity,SharedPrefsConstant.SELECTED_LANGUAGE_LABLE, getString(languageClick.name))

    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.iv_back -> onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        restartIfRequires()
    }

    private fun restartIfRequires() {
        if (mPreviousSelectedLanguageKey != LocaleManager.getLanguagePref(this@LanguageActivity)) {
            SharedPrefsConstant.savePref(this, SharedPrefsConstant.IS_REFRESH_HOME, true)
            Log.e("TAG", "restartIfRequires: ")
            recreate()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        } else {
            SharedPrefsConstant.savePref(this, SharedPrefsConstant.IS_REFRESH_HOME, false)
        }
    }

    override fun getContext(): AppCompatActivity {
        return this@LanguageActivity
    }

    override fun initViews() {
    }

    override fun initAds() {


    }

}