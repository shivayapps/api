package calculatorlock.calculatorvault.hide.photo.video.hide

import android.app.Activity
import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaPlayer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.webkit.MimeTypeMap
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import calculatorlock.calculatorvault.hide.photo.video.MyCommonBaseActivity
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.activity.DashBoardActivity
import calculatorlock.calculatorvault.hide.photo.video.adapters.AudioListAdapter
import calculatorlock.calculatorvault.hide.photo.video.callback.OnItemClickListener
import calculatorlock.calculatorvault.hide.photo.video.db.AudioItem
import calculatorlock.calculatorvault.hide.photo.video.db.DatabaseHelper
import calculatorlock.calculatorvault.hide.photo.video.db.VideoItem
import calculatorlock.calculatorvault.hide.photo.video.filepicker.FilePickerBuilder
import calculatorlock.calculatorvault.hide.photo.video.filepicker.FilePickerConst
import calculatorlock.calculatorvault.hide.photo.video.filepicker.models.sort.SortingTypes
import calculatorlock.calculatorvault.hide.photo.video.filepicker.utils.ContentUriUtils
import calculatorlock.calculatorvault.hide.photo.video.util.*
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import kotlinx.android.synthetic.main.activity_hide_image.*
import java.io.File
import java.util.*
import kotlin.collections.ArrayList

private const val REQUEST_CODE_CHOOSE = 101

class HideAudioActivity : MyCommonBaseActivity() {

//    var mActivity: Activity? = null
    var view: View? = null
    var imageListAdapter: AudioListAdapter? = null
    var databaseHelper: DatabaseHelper? = null
    private var countSelected = 0

    var isSelectedMode = false
    var imagesList: ArrayList<AudioItem> = java.util.ArrayList<AudioItem>()
    var gridLayoutManager: GridLayoutManager? = null

//    private lateinit var progressDialog: CustomProgressDialog
//    private var progressStyle: CustomProgressDialog.ProgressStyle = CustomProgressDialog.ProgressStyle.SpinnerStyle


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hide_image)

//        mActivity = this@HideAudioActivity


//        progressDialog = CustomProgressDialog(mActivity)
//        progressDialog.setMessage("Please wait...")
//        progressDialog.setCancelable(false)
//        progressDialog.setProgressStyle(CustomProgressDialog.ProgressStyle.HorizontalStyle)
//        progressStyle = CustomProgressDialog.ProgressStyle.HorizontalStyle

        createImageDir()

    }

    override fun getContext(): AppCompatActivity {
        return this@HideAudioActivity
    }

    override fun initAds() {

    }

    override fun initData() {

    }

    override fun initActions() {
        iv_back.setOnClickListener {
            onBackPressed()
//            val intent = Intent(this, MainActivity::class.java)
//            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
//            startActivity(intent)
        }

        action_select_all.setOnClickListener {

            action_select_all.checked = !action_select_all.checked
            selectAll(action_select_all.checked)
        }
        action_delete.setOnClickListener {
            dialogDeletePhotoView(this@HideAudioActivity)
        }
        action_unhide.setOnClickListener {
            dialogUnhideFile(this@HideAudioActivity)
        }
        iv_photo.setOnClickListener {
            choosePicture()
        }
    }

    override fun initViews() {
        databaseHelper = DatabaseHelper(this@HideAudioActivity)
        home_tv_title.setText(getString(R.string.label_audio))

//        val no = if (isGridlayout) 3 else 1
        gridLayoutManager = GridLayoutManager(mActivity, 1)
        recycler_photolist.setHasFixedSize(true)
        recycler_photolist.layoutManager = gridLayoutManager

        //ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(mActivity, R.dimen.item_space);
        //recycler_photolist.addItemDecoration(itemDecoration);
        imagesList = databaseHelper?.allAudios!!
        Collections.reverse(imagesList)

        imageListAdapter = AudioListAdapter(mActivity!!, imagesList)
        imageListAdapter!!.setItemClickEvent(object :
            OnItemClickListener {
            override fun onItemClick(position: Int) {
                if (isSelectedMode) {
                    enableActionMode(isSelectedMode)

                    toggleSelection(position)

                    home_tv_title.setText(countSelected.toString() + " " + getString(R.string.selected))
                    if (countSelected == 0) {
                        deselectAll()

                        isSelectedMode = false
                        enableActionMode(isSelectedMode)
                    }
                    imageListAdapter!!.isSelectedMode = isSelectedMode
                    action_select_all.checked = imagesList.size == countSelected
                    imageListAdapter!!.notifyDataSetChanged()
                } else {

                    val intent = Intent()
                    intent.action = Intent.ACTION_VIEW
                    val lFileUri = FileProvider.getUriForFile(
                        this@HideAudioActivity, applicationContext.packageName + ".provider", File(
                            imagesList!![position].newPath
                        )
                    )
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    intent.setDataAndType(lFileUri, "audio/*")
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)

                }
            }

            override fun onItemLongClick(position: Int) {
                isSelectedMode = true
                enableActionMode(isSelectedMode)
//                if (actionMode == null) {
//                    actionMode = startActionMode(callback)
//                }
                toggleSelection(position)
                //actionMode?.setTitle(countSelected.toString() + " " + getString(R.string.selected))
                home_tv_title?.setText("${countSelected.toString()}  ${getString(R.string.selected)}")
                if (countSelected == 0) {
//                    actionMode?.finish()
                    isSelectedMode = false
                    enableActionMode(isSelectedMode)
                    deselectAll()
                }
                imageListAdapter!!.isSelectedMode = isSelectedMode
                action_select_all.checked = imagesList.size == countSelected
                imageListAdapter!!.notifyDataSetChanged()
            }
        })
//        imageListAdapter!!.setImageResize(Utils.getImageResize(mActivity, recycler_photolist))

        recycler_photolist.adapter = imageListAdapter

        Log.e("imagesList", "${imagesList.size}")
        if (imagesList.size == 0) {
            empty_view.visibility = View.VISIBLE
        } else {
            empty_view.visibility = View.GONE
        }

        if (isOnline()) {
            NativeAdvancedModelHelper(this@HideAudioActivity).loadNativeAdvancedAd(
                NativeAdsSize.Medium,
                findViewById(R.id.adViewContainer)
            )
        }
    }

    private fun enableActionMode(enable: Boolean) {
        if (enable) {
            action_unhide.visibility = View.VISIBLE
            action_delete.visibility = View.VISIBLE
            action_select_all.visibility = View.VISIBLE
            iv_photo.visibility = View.GONE
        } else {
            home_tv_title.setText(getString(R.string.label_image))
            action_unhide.visibility = View.GONE
            action_delete.visibility = View.GONE
            action_select_all.visibility = View.GONE
            iv_photo.visibility = View.VISIBLE
        }
    }

//    private fun enableActionMode(enable: Boolean) {
//        if(enable) {
//            action_menu.visibility=View.VISIBLE
//            iv_photo.visibility=View.GONE
//        } else {
//            home_tv_title.setText(getString(R.string.label_audio))
//            action_menu.visibility=View.GONE
//            iv_photo.visibility=View.VISIBLE
//        }
//    }

    private fun toggleSelection(position: Int) {
        imagesList[position].isChecked = !imagesList[position].isChecked
        if (imagesList[position].isChecked) {
            countSelected++
        } else {
            countSelected--
        }

        action_select_all.checked=imagesList.size==countSelected
    }

    private fun selectAll(boolean: Boolean) {
        var i = 0
        val l = imagesList.size
        while (i < l) {
            imagesList[i].isChecked = boolean
            i++
        }
        countSelected = imagesList.size

        if(boolean){
            countSelected = imagesList.size
            home_tv_title.setText(countSelected.toString() + " " + getString(R.string.selected))
        } else {
            countSelected = 0
            home_tv_title.setText(getString(R.string.label_audio))
        }

        imageListAdapter!!.notifyDataSetChanged()
    }

    private fun deselectAll() {
        var i = 0
        val l = imagesList.size
        while (i < l) {
            imagesList[i].isChecked = false
            i++
        }
        isSelectedMode = false
        countSelected = 0
        imageListAdapter!!.isSelectedMode = isSelectedMode
        action_select_all.checked=imagesList.size==countSelected
        enableActionMode(false)
        home_tv_title.setText(getString(R.string.label_audio))
        imageListAdapter!!.notifyDataSetChanged()
    }

    private fun createImageDir() {
        val myDirectory: File = File(hidePath)
        if (!myDirectory.exists()) {
            myDirectory.mkdirs()
            Log.e("TAG", "createImageDir: mkdir")
        } else {
        }
        createNoImageDir()
    }

    private fun createNoImageDir() {
        val myDirectory: File = File(nohideAudio)
        if (!myDirectory.exists()) {
            myDirectory.mkdirs()
            Log.e("TAG", "createImageDir: mkdir")
        } else {
            Log.e("TAG", "createImageDir:not exi ")
        }
    }


    fun unHideFile(selected:AudioItem) {
//        val selected = getSelected()
//        for (i in selected.indices) {
        val file = File(selected.newPath)
        val targetLocation = File(selected.path)
        val file1 = File(targetLocation.parent)
        if (!file1.exists()) {
            file1.mkdirs()
        }
        if (file.renameTo(targetLocation)) {
            databaseHelper!!.deleteAudioItem(selected)
            addImageToGallery(
                this@HideAudioActivity,
                targetLocation.absolutePath,
                selected.mimeType
            )
        }
        Thread.sleep(1500)
//            progressDialog.setProgress(i+1)
//        }
//        isSelectedMode=false
//        imageListAdapter!!.isSelectedMode=isSelectedMode
//        enableActionMode(isSelectedMode)
//        countSelected = 0
//        initView()
    }

    fun unHideFile(selected:ArrayList<AudioItem>) {
        for (i in selected.indices) {
            val file = File(selected[i].newPath)
            val targetLocation = File(selected[i].path)
            val file1 = File(targetLocation.parent)
            if (!file1.exists()) {
                file1.mkdirs()
            }
            if (file.renameTo(targetLocation)) {
                databaseHelper!!.deleteAudioItem(selected[i])
//                addImageToGallery(
//                    this@HideAudioActivity,
//                    targetLocation.absolutePath,
//                    selected[i].getMimeType()
//                )
            }
            Thread.sleep(1500)
        }
        isSelectedMode = false
        imageListAdapter!!.isSelectedMode = isSelectedMode
        enableActionMode(isSelectedMode)
        countSelected = 0
        initViews()
    }

    private fun hideFile(path: String) {
        Log.e("TAG", "hideFile: path: $path")
        val file: File = File(path)
        val fileName = file.name
        val oriPath = file.absolutePath
        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(getExtension(fileName))

        val targetLocation = File(nohideAudio + fileName + ".bin")
        if (file.renameTo(targetLocation)) {
            removeAllForPaths(file, mActivity)
            databaseHelper!!.insertAudio(
                fileName,
                oriPath,
                targetLocation.absolutePath,
                file.length(),
                mimeType
            )
        }
        initViews()
    }

    private fun getVideoDuration(uriOfFile: String?): Long {
        val mp = MediaPlayer.create(this, Uri.parse(uriOfFile)) ?: return 0L
        val duration = mp.duration
        mp.release()
        return duration.toLong()
//        return String.format(
//            "%d min, %d sec",
//            TimeUnit.MILLISECONDS.toMinutes(duration.toLong()),
//            TimeUnit.MILLISECONDS.toSeconds(duration.toLong()) - TimeUnit.MINUTES.toSeconds(
//                TimeUnit.MILLISECONDS.toMinutes(duration.toLong())
//            )
//        )
    }

    private fun removeAllForPaths(file: File, context: Context?) {
        val where = MediaStore.MediaColumns.DATA + "=?"
        val selectionArgs = arrayOf(
            file.absolutePath
        )
        val contentResolver = mActivity!!.contentResolver
        val filesUri = MediaStore.Files.getContentUri("external")
        contentResolver.delete(filesUri, where, selectionArgs)
        if (file.exists()) {
            contentResolver.delete(filesUri, where, selectionArgs)
        }
    }

    private fun addImageToGallery(context: Context, filePath: String, mimetype: String?) {
        try {
            val values = ContentValues()
            values.put(MediaStore.MediaColumns.DATE_TAKEN, System.currentTimeMillis())
            values.put(MediaStore.MediaColumns.MIME_TYPE, mimetype)
            values.put(MediaStore.MediaColumns.DATA, filePath)
            context.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            MediaScannerConnection.scanFile(
                context, arrayOf(filePath), null
            ) { path, uri -> }
        } catch (e:Exception){ }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        Log.e("TAG", "onActivityResult: requestCode: $requestCode")
        when (requestCode) {
            FilePickerConst.REQUEST_CODE_DOC -> if (resultCode == Activity.RESULT_OK && data != null) {
                val mSelected = data.getParcelableArrayListExtra<Uri>(FilePickerConst.KEY_SELECTED_DOCS)
                Log.e("TAG", "onActivityResult: mSelected: ${mSelected!!.size}")

                hideFileWithProgress(mSelected)
//                object : AsyncTask<Void, Int, Void>() {
//                    var dialog: android.app.AlertDialog? = null
//                    var progressBar: ProgressBar? = null
//                    override fun onPreExecute() {
//                        super.onPreExecute()
//                        try {
//                            val alertDialogBuilder = android.app.AlertDialog.Builder(mActivity)
//                            val inflater = mActivity!!.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
//                            val view = inflater.inflate(R.layout.dialog_progress, null)
//                            alertDialogBuilder.setView(view)
//                            alertDialogBuilder.setCancelable(false)
//                            dialog = alertDialogBuilder.create()
//                            dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
//                            dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//                            progressBar = view.findViewById(R.id.progress_bar)
//                            progressBar!!.max=mSelected.size
//
//                            dialog!!.setOnDismissListener {
//                            }
//                            if (!dialog!!.isShowing) {
//                                dialog!!.show()
//                            }
//                        } catch (e: Exception) {
//                            Log.e("mmmmmgggggg", "55555:" + e)
//                            e.printStackTrace()
//                        }
//                    }
//
//                    override fun doInBackground(vararg voids: Void): Void? {
//                        Handler(Looper.getMainLooper()).run {
//                            if (mSelected!!.isNotEmpty() && mSelected.size > 0) {
//                                for (i in mSelected.indices) {
//                                    hideFileWithProgress(mSelected[i])
//                                    publishProgress((i+1).toInt())
//                                }
//                            }
//                        }
//                        return null
//                    }
//
//                    override fun onProgressUpdate(vararg values: Int?) {
//                        super.onProgressUpdate(*values)
//                        progressBar!!.progress=values[0]!!.toInt()
//                    }
//                    override fun onPostExecute(result: Void?) {
//                        super.onPostExecute(result)
////                                progressDialog.dismiss()
//                        dialog!!.dismiss()
//                    }
//                }.execute()
            }
        }
    }


//    fun hideFileWithProgress(mSelected: Uri) {
    fun hideFileWithProgress(mSelected: MutableList<Uri>) {

        object : AsyncTask<Void, Int, Void>() {

            var dialog: android.app.AlertDialog? = null
            var progressBar: ProgressBar? = null
            override fun onPreExecute() {
                super.onPreExecute()
                try {
                    val alertDialogBuilder = android.app.AlertDialog.Builder(mActivity)
                    val inflater = mActivity!!.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
                    val view = inflater.inflate(R.layout.dialog_progress, null)
                    alertDialogBuilder.setView(view)
                    alertDialogBuilder.setCancelable(false)
                    dialog = alertDialogBuilder.create()
                    dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
                    dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                    progressBar = view.findViewById(R.id.progress_bar)
                    mActivity!!.runOnUiThread{
                        progressBar!!.max=mSelected.size
                    }
                    Log.e("hideFileWithProgress", "mSelected.size:" + mSelected.size)
                    Log.e("hideFileWithProgress", "progressBar!!.max:" + progressBar!!.max)

                    dialog!!.setOnDismissListener {
                    }
                    if (!dialog!!.isShowing) {
                        dialog!!.show()
                    }
                } catch (e: Exception) {
                    Log.e("mmmmmgggggg", "55555:" + e)
                    e.printStackTrace()
                }
            }

            override fun doInBackground(vararg voids: Void): Void? {
                Handler(Looper.getMainLooper()).run {
                    if (mSelected.isNotEmpty() && mSelected.size > 0) {
                        for (i in mSelected.indices) {
//                            hideFileWithProgress(mSelected[i])
                            if (mSelected != null) {
                                mActivity!!.runOnUiThread {
                                    val original = ContentUriUtils.getFilePath(mActivity!!, mSelected[i])
                                    hideFile(original!!)
                                }
                            }
                            Log.e("hideFileWithProgress", "onProgressUpdate000" +i)
//                            progressBar!!.progress=(i+1)
                            Thread.sleep(1500)
                            publishProgress((i+1).toInt())
                        }
                    }
                }
                return null
            }
            override fun onProgressUpdate(vararg values: Int?) {
                super.onProgressUpdate(*values)
                mActivity!!.runOnUiThread {
                    progressBar!!.progress=values[0]!!
                }
            }
            override fun onPostExecute(result: Void?) {
                super.onPostExecute(result)
//                                progressDialog.dismiss()
                dialog!!.dismiss()
            }
        }.execute()

    }

    fun dialogUnhideFile(act: Activity) {

        val selected = getSelected()
        DialogHelper.alertDialog(
            act,
            getString(R.string.ask_unhide_audio),
            getString(R.string.ask_sure_unhide_audio),
            object : DialogHelper.DialogListener {
                override fun onPositiveClick() {

                    object : AsyncTask<Void, Int, Void>() {

                        var dialog: android.app.AlertDialog? = null
                        var progressBar: ProgressBar? = null

                        override fun onPreExecute() {
                            super.onPreExecute()

                            val alertDialogBuilder = android.app.AlertDialog.Builder(mActivity)
                            val inflater = mActivity!!.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
                            val view = inflater.inflate(R.layout.dialog_progress, null)
                            alertDialogBuilder.setView(view)
                            alertDialogBuilder.setCancelable(false)
                            dialog = alertDialogBuilder.create()
                            dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
                            dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                            progressBar = view.findViewById(R.id.progress_bar)
                            progressBar!!.max=selected.size

                            dialog!!.setOnDismissListener {
                            }
                            if (!dialog!!.isShowing) {
                                dialog!!.show()
                            }
                        }

                        override fun doInBackground(vararg voids: Void): Void? {
                            Handler(Looper.getMainLooper()).run {
//                                val selected = getSelected()
                                for (i in selected.indices) {
                                    unHideFile(selected[i])
                                    publishProgress((i+1).toInt())
                                }
                            }
                            return null
                        }

                        override fun onProgressUpdate(vararg values: Int?) {
                            super.onProgressUpdate(*values)
                            progressBar!!.progress=values[0]!!.toInt()
                        }

                        override fun onPostExecute(result: Void?) {
                            super.onPostExecute(result)
//                            progressDialog.dismiss()
                            dialog!!.dismiss()
                            isSelectedMode=false
                            imageListAdapter!!.isSelectedMode=isSelectedMode
                            enableActionMode(isSelectedMode)
                            countSelected = 0
                            initViews()
                        }
                    }.execute()

                }

                override fun onNegativeClick() {

                }
            })
    }

    fun dialogDeletePhotoView(act: Activity) {
        val selected: ArrayList<AudioItem> = getSelected()
        DialogHelper.alertDialog(
            act,
            "Delete Audios?",
            "Delete the selected ${selected.size} audios?",
            object : DialogHelper.DialogListener {
                override fun onPositiveClick() {
                    deletImage(selected, true)
                }

                override fun onNegativeClick() {

                }
            })
    }

    private fun deletImage(selected: ArrayList<AudioItem>, isCheckedTrash: Boolean) {

        object : AsyncTask<Void, Int, Void>() {

            var dialog: android.app.AlertDialog? = null
            var progressBar: ProgressBar? = null
            override fun onPreExecute() {
                super.onPreExecute()
                try {
                    val alertDialogBuilder = android.app.AlertDialog.Builder(mActivity)
                    val inflater = mActivity!!.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
                    val view = inflater.inflate(R.layout.dialog_progress, null)
                    alertDialogBuilder.setView(view)
                    alertDialogBuilder.setCancelable(false)
                    dialog = alertDialogBuilder.create()
                    dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
                    dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                    progressBar = view.findViewById(R.id.progress_bar)
                    progressBar!!.max=selected.size

                    dialog!!.setOnDismissListener {
                    }
                    if (!dialog!!.isShowing) {
                        dialog!!.show()
                    }
                } catch (e: Exception) {
                    Log.e("mmmmmgggggg", "55555:" + e)
                    e.printStackTrace()
                }
            }

            override fun doInBackground(vararg voids: Void): Void? {
                Handler(Looper.getMainLooper()).run {

                    if (selected.isNotEmpty() && selected.size > 0) {

                        for (i in selected.indices) {
                            val file = File(selected[i].newPath)
                            val targetLocation = File(selected[i].path)
                            val file1 = File(targetLocation.parent)
                            if (!file1.exists()) {
                                file1.mkdirs()
                            }
                            databaseHelper!!.movewTrathAudio(selected[i].id)
                            publishProgress((i+1).toInt())

                        }
                    }
                }
                return null
            }
            override fun onProgressUpdate(vararg values: Int?) {
                super.onProgressUpdate(*values)
                progressBar!!.progress=values[0]!!.toInt()
            }

            override fun onPostExecute(result: Void?) {
                super.onPostExecute(result)
                dialog!!.dismiss()
                initViews()
                deselectAll()
            }
        }.execute()

//        DeleteCloudFileTask(
//            this@HideAudioActivity,
//            selected,
//            isCheckedTrash
//        ).execute()
    }

    private fun getSelected(): java.util.ArrayList<AudioItem> {
        val selectedImages = java.util.ArrayList<AudioItem>()
        var i = 0
        val l = imagesList.size
        while (i < l) {
            if (imagesList[i].isChecked) {
                selectedImages.add(imagesList[i])
            }
            i++
        }
        return selectedImages
    }

    private fun choosePicture() {

        if (isOnline() && AdsManager(mActivity).isClickToShowAds()) {
            isShowInterstitialAd {
                FilePickerBuilder.instance
                    .setMaxCount(10)
                    .setActivityTheme(R.style.FilePickerTheme)
                    .setActivityTitle("Audio")
                    .setImageSizeLimit(5)
                    .setVideoSizeLimit(20)
                    .addFileSupport("File", Constant.AudioArray, R.drawable.ic_audio)
                    .enableDocSupport(true)
                    .enableSelectAll(true)
                    .sortDocumentsBy(SortingTypes.NAME)
                    .withOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
                    .pickFile(this)
            }
        } else {

            FilePickerBuilder.instance
                .setMaxCount(10)
                .setActivityTheme(R.style.FilePickerTheme)
                .setActivityTitle("Please select audio")
                .setImageSizeLimit(5)
                .setVideoSizeLimit(20)
                .addFileSupport("File", Constant.AudioArray, R.drawable.ic_audio)
                .enableDocSupport(true)
                .enableSelectAll(true)
                .sortDocumentsBy(SortingTypes.NAME)
                .withOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
                .pickFile(this)

        }
    }

}