package calculatorlock.calculatorvault.hide.photo.video.adapters

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.callback.RVClickListener
import calculatorlock.calculatorvault.hide.photo.video.util.Info
import calculatorlock.calculatorvault.hide.photo.video.util.loadImage


class MainDashBoardAdapter(
    val mContext: Activity,
    private val layout: Int,
    private val backupOptions: MutableList<Info>,
    val listener: RVClickListener
) : RecyclerView.Adapter<MainDashBoardAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(mContext).inflate(layout, parent, false))
    }

    override fun getItemCount(): Int {
        return backupOptions.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val nearby = backupOptions[position]
        val title = mContext.getString(nearby.name)
        holder.tvTitle.text = title
        holder.tvTitle.isSelected = true
        mContext.loadImage(nearby.thumb, holder.ivThumb, null)

        holder.itemView.setOnClickListener { listener.onItemClick(position) }
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTitle: TextView = itemView.findViewById(R.id.tv_title)
        val ivThumb: ImageView = itemView.findViewById(R.id.iv_thumb)
    }
}