package calculatorlock.calculatorvault.hide.photo.video.filepicker.fragments

interface PhotoPickerFragmentListener {
    fun onItemSelected()
    fun setToolbarTitle(count: Int)
}