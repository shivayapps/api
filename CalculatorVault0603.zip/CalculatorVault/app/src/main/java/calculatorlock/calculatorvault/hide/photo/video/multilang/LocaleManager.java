package calculatorlock.calculatorvault.hide.photo.video.multilang;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.preference.PreferenceManager;
import android.util.Log;

import androidx.annotation.StringDef;
import androidx.appcompat.app.AppCompatActivity;


import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.Locale;

import calculatorlock.calculatorvault.hide.photo.video.util.SharedPrefsConstant;

public class LocaleManager {

    public static final String ENGLISH = "en";
    public static final String HINDI = "hi";
    public static final String MARATHI = "mr";
    public static final String GUJARATI = "gu";
    public static final String TAMIL = "ta";
    public static final String TELUGU = "te";
    public static final String KANNADA = "kn";


    @Retention(RetentionPolicy.SOURCE)
    @StringDef({ENGLISH, HINDI, MARATHI, GUJARATI, TAMIL, TELUGU})
    public @interface LocaleDef {
        String[] SUPPORTED_LOCALES = {ENGLISH, HINDI, MARATHI, GUJARATI, TAMIL, TELUGU};
    }

    /**
     * SharedPreferences Key
     */
    private static final String LANGUAGE_KEY = "language_key";

    /**
     * set current pref locale
     */
    public static Context setLocale(Context mContext) {
        return updateResources(mContext, getLanguagePref(mContext));
    }

    /**
     * Set new Locale with context
     */
    public static Context setNewLocale(Context mContext, @LocaleDef String language) {
        setLanguagePref(mContext, language);
        return updateResources(mContext, language);
    }

    /**
     * Set new Locale with context
     */
    public static Context setTempLocale(Context mContext) {
        return updateResources(mContext, ENGLISH);
    }

    /**
     * Get saved Locale from SharedPreferences
     *
     * @param mContext current context
     * @return current locale key by default return english locale
     */
    public static String getLanguagePref(Context mContext) {
        SharedPreferences mPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        return mPreferences.getString(LANGUAGE_KEY, ENGLISH);
    }

    public static Boolean isLanguageReset(Context mContext) {
        SharedPreferences mPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        return mPreferences.getBoolean("isLanguageReset", false);
    }
    public static void ResetLanguage(Context mContext) {
        SharedPreferences mPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        mPreferences.edit().putBoolean("isLanguageReset", true).commit();
    }

    /**
     * set pref key
     */
    public static void setLanguagePref(Context mContext, String localeKey) {
//        SharedPrefsConstant.savePref(mContext, SharedPrefsConstant.PRF_IS_LANGUAGE, true);
        SharedPreferences mPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        mPreferences.edit().putString(LANGUAGE_KEY, localeKey).apply();
    }


    public static Context updateResources(Context activity, String languageCode) {
        Log.e("TAG", "updateResources: " + languageCode);
        Locale locale = new Locale(languageCode, "IN");
        Locale.setDefault(locale);
        Resources resources = activity.getResources();
        Configuration config = resources.getConfiguration();
        config.setLocale(locale);
        resources.updateConfiguration(config, resources.getDisplayMetrics());
        return activity;
    }


    /**
     * get current locale
     */
    public static Locale getLocale(Resources res) {
        Configuration config = res.getConfiguration();
        return Build.VERSION.SDK_INT >= 24 ? config.getLocales().get(0) : config.locale;
    }

    private void setLocale(AppCompatActivity mContext, @LocaleDef String language) {
        LocaleManager.setNewLocale(mContext, language);
        Intent intent = mContext.getIntent();
        mContext.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
    }


}