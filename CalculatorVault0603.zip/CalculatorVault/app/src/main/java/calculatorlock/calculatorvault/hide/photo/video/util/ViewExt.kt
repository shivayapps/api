package calculatorlock.calculatorvault.hide.photo.video.util

import android.view.View
import androidx.core.view.ViewCompat

internal fun View.setVisible(isVisible: Boolean, animate: Boolean = false, onEnd: (() -> Unit)? = null) {
    if (animate) {
        if (isVisible) {
            alpha = 0f
            setVisible(true)
        }
        ViewCompat.animate(this)
                .alpha(if (isVisible) 1f else 0f)
                .withEndAction {
                    if (!isVisible) {
                        setVisible(false)
                    }
                    onEnd?.invoke()
                }
    } else {
        visibility = if (isVisible) View.VISIBLE else View.GONE
    }
}
