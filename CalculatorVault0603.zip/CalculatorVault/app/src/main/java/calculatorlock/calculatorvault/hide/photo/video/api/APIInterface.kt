package calculatorlock.calculatorvault.hide.photo.video.api
////////calculatorlock.calculatorvault.hide.photo.video

import retrofit2.Call
import retrofit2.http.*


interface APIInterface {

//    @FormUrlEncoded
    @POST("app_setting.php")
    fun doGetAllData( @Header("ApiKey") apiKey: String, @Header("Content-Type") contentType: String, @Header("pakagename") pakageName: String): Call<ApiData>

}
