package calculatorlock.calculatorvault.hide.photo.video.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.util.Log
import calculatorlock.calculatorvault.hide.photo.video.util.hidePath
import java.io.File
import java.util.*
import kotlin.collections.ArrayList

class DatabaseHelper(context: Context?) :
    SQLiteOpenHelper(context, hidePath + File.separator + DATABASE_NAME, null, DATABASE_VERSION) {
    private val database: SQLiteDatabase? = null

    override fun onCreate(db: SQLiteDatabase) {
//        this.db = db;
        db.execSQL(UserItem.CREATE_TABLE)
        db.execSQL(PhotoItem.CREATE_TABLE)
        db.execSQL(VideoItem.CREATE_TABLE)
        db.execSQL(AudioItem.CREATE_TABLE)
        db.execSQL(FileItem.CREATE_TABLE)
        db.execSQL(NotesItem.CREATE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
//        if (newVersion == 2) {
//        } else {
//            db.execSQL("DROP TABLE IF EXISTS " + UserItem.TABLE_NAME)
//            db.execSQL("DROP TABLE IF EXISTS " + PhotoItem.TABLE_NAME)
//            db.execSQL("DROP TABLE IF EXISTS " + VideoItem.TABLE_NAME)
//            db.execSQL("DROP TABLE IF EXISTS " + AudioItem.TABLE_NAME)
//            db.execSQL("DROP TABLE IF EXISTS " + FileItem.TABLE_NAME)
//            db.execSQL("DROP TABLE IF EXISTS " + NotesItem.TABLE_NAME)
//            onCreate(db)
//        }
    }

    //=================== tab user =======================
    fun initUser(): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(UserItem.COLUMN_PWD, "")
        values.put(UserItem.COLUMN_SQUESTION, "")
        values.put(UserItem.COLUMN_ANSWER, "")
        val id = db.insert(UserItem.TABLE_NAME, null, values)
        db.close()
        return id
    }


    fun insertUser(pwd: String?, squestion: String?, answer: String?): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(UserItem.COLUMN_PWD, pwd)
        values.put(UserItem.COLUMN_SQUESTION, squestion)
        values.put(UserItem.COLUMN_ANSWER, answer)
        val id = db.insert(UserItem.TABLE_NAME, null, values)
        Log.e("insertUser", "pwd:${pwd}")
        Log.e("insertUser", "squestion:${squestion}")
        Log.e("insertUser", "answer:${answer}")
        db.close()
        return id
    }

    fun insertUser(pwd: String?, squestion: String?, answer: String?, email: String?): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(UserItem.COLUMN_PWD, pwd)
        values.put(UserItem.COLUMN_SQUESTION, squestion)
        values.put(UserItem.COLUMN_ANSWER, answer)
        values.put(UserItem.COLUMN_EMAIL, email)
        val id = db.insert(UserItem.TABLE_NAME, null, values)
        db.close()
        return id
    }

    fun updateUserEmail(email: String?): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(UserItem.COLUMN_EMAIL, email)
        return db.update(
            UserItem.TABLE_NAME,
            values,
            UserItem.COLUMN_ID + "=?", arrayOf(1.toString())
        )
    }

    fun getUser(): UserItem {
        val db = this.readableDatabase
        val cursor = db.query(
            UserItem.TABLE_NAME, arrayOf(
                UserItem.COLUMN_ID,
                UserItem.COLUMN_PWD,
                UserItem.COLUMN_SQUESTION,
                UserItem.COLUMN_ANSWER,
                UserItem.COLUMN_EMAIL,
                UserItem.COLUMN_FORGOT_PIN
            ), null, null, null, null, null, null
        )
        cursor?.moveToFirst()
        val notes = ArrayList<UserItem>()
//        var note = UserItem(1, "", "", "", "", "")
        Log.e("getUser", "cursor!!.count:${cursor!!.count}")
        if (cursor.count > 0) {
            do {
                val note = UserItem(
                    cursor.getInt(cursor.getColumnIndex(UserItem.COLUMN_ID)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_PWD)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_SQUESTION)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_ANSWER)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_EMAIL)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_FORGOT_PIN))
                )

                Log.e("getUser", "COLUMN_ID:${note.id}")
                Log.e("getUser", "COLUMN_PWD:${note.pwd}")
                Log.e("getUser", "COLUMN_SQUESTION:${note.squestion}")
                Log.e("getUser", "COLUMN_ANSWER:${note.answer}")
                Log.e("getUser", "COLUMN_EMAIL:${note.email}")
                Log.e("getUser", "COLUMN_FORGOT_PIN:${note.forgotPin}")
                notes.add(note)
            } while (cursor.moveToNext())

        } else {
//            initUser()
            notes.add(UserItem())
        }
        cursor.close()
        return notes.get(0)
    }

    fun updatePIN(id:Int,pin: String?): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(UserItem.COLUMN_PWD, pin)
        // updating row
        return db.update(
            UserItem.TABLE_NAME,
            values,
            UserItem.COLUMN_ID + " = ?",
            arrayOf(id.toString())
        )
    }

//    fun deleteUser1(pwd: String?, squestion: String?, answer: String?): Long {
//
//        // Select all Query
//        val selectQuery = "DELETE FROM " + UserItem.TABLE_NAME
//        val db = this.writableDatabase
//        val cursor = db.rawQuery(selectQuery, null)
//
//        db.close()
//    }

    fun deleteUser(): Int {
        val db = this.writableDatabase
        return db.delete(UserItem.TABLE_NAME, null, null)
    }

    fun updateNote(notesId: Int, notes: String?): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(NotesItem.COLUMN_DNAME, notes)
        // updating row
        return db.update(
            NotesItem.TABLE_NAME,
            values,
            NotesItem.COLUMN_ID + " = ?",
            arrayOf(notesId.toString())
        )
    }

    val userData: UserItem
        get() {
            val db = this.readableDatabase
            val cursor = db.query(
                UserItem.TABLE_NAME, arrayOf(
                    UserItem.COLUMN_ID,
                    UserItem.COLUMN_PWD,
                    UserItem.COLUMN_SQUESTION,
                    UserItem.COLUMN_ANSWER,
                    UserItem.COLUMN_EMAIL,
                    UserItem.COLUMN_FORGOT_PIN
                ),
                null, null, null, null, null
            )
            cursor?.moveToFirst()
            var note = UserItem(0, "", "", "", "", "")
            if (cursor!!.count > 0) {
                note = UserItem(
                    cursor.getInt(cursor.getColumnIndex(UserItem.COLUMN_ID)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_PWD)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_SQUESTION)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_ANSWER)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_EMAIL)),
                    cursor.getString(cursor.getColumnIndex(UserItem.COLUMN_FORGOT_PIN))
                )
            }
            cursor.close()
            return note
        }

    fun updateUserForgotPin(forgotPin: String?): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(UserItem.COLUMN_FORGOT_PIN, forgotPin)
        // updating row
        return db.update(
            UserItem.TABLE_NAME,
            values,
            UserItem.COLUMN_ID + " = ?",
            arrayOf(1.toString())
        )
    }

    fun updateUserPinSecurityQue(
        uId: String?,
        pin: String?,
        questionValue: String?,
        ans: String?
    ): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(UserItem.COLUMN_PWD, pin)
        values.put(UserItem.COLUMN_SQUESTION, questionValue)
        values.put(UserItem.COLUMN_ANSWER, ans)
        // updating row
        return db.update(
            UserItem.TABLE_NAME,
            values,
            UserItem.COLUMN_ID + " = ?",
            arrayOf(uId.toString())
        )
    }

    fun insertNotes(
        displayName: String?,
    ): Long {
        Log.e(TAG, "insertNotes: $displayName")
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(NotesItem.COLUMN_DNAME, displayName)
//        values.put(NotesItem.COLUMN_ORIPATH, oripath)
//        values.put(NotesItem.COLUMN_NEWPATH, newpath)
//        values.put(NotesItem.COLUMN_SIZE, size)
//        values.put(NotesItem.COLUMN_MIMETYPE, mimeType)
        values.put(NotesItem.COLUMN_CLOUD_FILE_ID, "null")
        values.put(NotesItem.COLUMN_TRASH, 0)
        val id = db.insert(NotesItem.TABLE_NAME, null, values)
        db.close()
        return id
    }

    //============= tab Image============
    fun insertImage(
        displayName: String?,
        oripath: String?,
        newpath: String?,
        size: Long,
        mimeType: String?
    ): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(PhotoItem.COLUMN_DNAME, displayName)
        values.put(PhotoItem.COLUMN_ORIPATH, oripath)
        values.put(PhotoItem.COLUMN_NEWPATH, newpath)
        values.put(PhotoItem.COLUMN_SIZE, size)
        values.put(PhotoItem.COLUMN_MIMETYPE, mimeType)
        values.put(PhotoItem.COLUMN_CLOUD_FILE_ID, "null")
        values.put(PhotoItem.COLUMN_TRASH, 0)
        val id = db.insert(PhotoItem.TABLE_NAME, null, values)
        db.close()
        return id
    }

    fun getImages(id: Long): PhotoItem {
        val db = this.readableDatabase
        val cursor = db.query(
            PhotoItem.TABLE_NAME,
            arrayOf(
                PhotoItem.COLUMN_ID,
                PhotoItem.COLUMN_DNAME,
                PhotoItem.COLUMN_ORIPATH,
                PhotoItem.COLUMN_NEWPATH,
                PhotoItem.COLUMN_SIZE,
                PhotoItem.COLUMN_MIMETYPE,
                PhotoItem.COLUMN_CLOUD_FILE_ID,
                PhotoItem.COLUMN_TRASH
            ),
            PhotoItem.COLUMN_ID + "=?",
            arrayOf(id.toString()),
            null,
            null,
            null,
            null
        )
        cursor?.moveToFirst()
        val note = PhotoItem(
            cursor!!.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_ID)),
            cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_DNAME)),
            cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_ORIPATH)),
            cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_NEWPATH)),
            cursor.getLong(cursor.getColumnIndex(PhotoItem.COLUMN_SIZE)),
            cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_MIMETYPE)),
            cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_CLOUD_FILE_ID)),
            cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_TRASH))
        )
        cursor.close()
        return note
    }

    val allImages: ArrayList<PhotoItem>
        get() {
            Log.e("allImages", "allImages")
            val notes = ArrayList<PhotoItem>()
            val columns = arrayOf(
                PhotoItem.COLUMN_ID,
                PhotoItem.COLUMN_DNAME,
                PhotoItem.COLUMN_ORIPATH,
                PhotoItem.COLUMN_NEWPATH,
                PhotoItem.COLUMN_SIZE,
                PhotoItem.COLUMN_MIMETYPE,
                PhotoItem.COLUMN_CLOUD_FILE_ID,
                PhotoItem.COLUMN_TRASH
            )


            // Select all Query
//            val selectQuery = "SELECT * FROM " + PhotoItem.TABLE_NAME
            val db = this.writableDatabase
//            val cursor = db.rawQuery(selectQuery, null)

//            val db = this.writableDatabase
//            val cursor = db.query(
//                PhotoItem.TABLE_NAME,
//                columns,
//                null,
//                null,
//                null,
//                null,
//                null
//            )
            val cursor = db.query(
                PhotoItem.TABLE_NAME,
                columns,
                PhotoItem.COLUMN_TRASH + "=?",
                arrayOf("0"),
                null,
                null,
                null
            )
            Log.e("allImages", "cursor.count:${cursor.count}")
            if (cursor.count > 0) {
                if (cursor.moveToFirst()) {
                    do {
                        val note = PhotoItem()
                        note.id = cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_ID))
                        note.displayName = cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_DNAME))
                        note.path = cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_ORIPATH))
                        note.newPath = cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_NEWPATH))
                        note.size = cursor.getLong(cursor.getColumnIndex(PhotoItem.COLUMN_SIZE))
                        note.mimeType = cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_MIMETYPE))
                        note.couldId = cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_CLOUD_FILE_ID))
                        note.isTrash = cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_TRASH))
                        notes.add(note)
                    } while (cursor.moveToNext())
                }
            }
            db.close()
            return notes
        }

    val trashImages: ArrayList<PhotoItem>
        get() {
            val notes = ArrayList<PhotoItem>()
            val selectQuery =
                "SELECT  * FROM " + PhotoItem.TABLE_NAME + " ORDER BY " + PhotoItem.COLUMN_ID + " DESC"
            val columns = arrayOf(
                PhotoItem.COLUMN_ID,
                PhotoItem.COLUMN_DNAME,
                PhotoItem.COLUMN_ORIPATH,
                PhotoItem.COLUMN_NEWPATH,
                PhotoItem.COLUMN_SIZE,
                PhotoItem.COLUMN_MIMETYPE,
                PhotoItem.COLUMN_CLOUD_FILE_ID,
                PhotoItem.COLUMN_TRASH
            )
            val db = this.writableDatabase
            val cursor = db.query(
                PhotoItem.TABLE_NAME,
                columns,
                PhotoItem.COLUMN_TRASH + "=?",
                arrayOf("1"),
                null,
                null,
                null
            )
            if (cursor.moveToFirst()) {
                do {
                    val note = PhotoItem()
                    note.id = cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_ID))
                    note.displayName =
                        cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_DNAME))
                    note.path = cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_ORIPATH))
                    note.newPath = cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_NEWPATH))
                    note.size = cursor.getLong(cursor.getColumnIndex(PhotoItem.COLUMN_SIZE))
                    note.mimeType =
                        cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_MIMETYPE))
                    note.couldId =
                        cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_CLOUD_FILE_ID))
                    note.isTrash = cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_TRASH))
                    notes.add(note)
                } while (cursor.moveToNext())
            }
            db.close()
            return notes
        }

    //        Cursor findEntry = db.query("sku_table", columns, "owner=? and price=?", new String[] { owner, price }, null, null, null);
    val backupImages: ArrayList<PhotoItem>
        get() {
            val notes = ArrayList<PhotoItem>()
            val columns = arrayOf(
                PhotoItem.COLUMN_ID,
                PhotoItem.COLUMN_DNAME,
                PhotoItem.COLUMN_ORIPATH,
                PhotoItem.COLUMN_NEWPATH,
                PhotoItem.COLUMN_SIZE,
                PhotoItem.COLUMN_MIMETYPE,
                PhotoItem.COLUMN_CLOUD_FILE_ID,
                PhotoItem.COLUMN_TRASH
            )
            val db = this.writableDatabase
            //        Cursor findEntry = db.query("sku_table", columns, "owner=? and price=?", new String[] { owner, price }, null, null, null);
            val cursor = db.query(
                PhotoItem.TABLE_NAME,
                columns,
                PhotoItem.COLUMN_CLOUD_FILE_ID + "=?",
                arrayOf("null"),
                null,
                null,
                null
            )
            Log.e("TAG", "getBackupImages: " + cursor.count)
            if (cursor.moveToFirst()) {
                do {
                    val note = PhotoItem()
                    note.id = cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_ID))
                    note.displayName =
                        cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_DNAME))
                    note.path = cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_ORIPATH))
                    note.newPath = cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_NEWPATH))
                    note.size = cursor.getLong(cursor.getColumnIndex(PhotoItem.COLUMN_SIZE))
                    note.mimeType =
                        cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_MIMETYPE))
                    note.couldId =
                        cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_CLOUD_FILE_ID))
                    note.isTrash = cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_TRASH))
                    notes.add(note)
                } while (cursor.moveToNext())
            }
            db.close()
            return notes
        }
    val restoreImages: ArrayList<PhotoItem>
        get() {
            val notes = ArrayList<PhotoItem>()
            val selectQuery =
                "SELECT  * FROM " + PhotoItem.TABLE_NAME + " ORDER BY " + PhotoItem.COLUMN_ID + " DESC"
            val columns = arrayOf(
                PhotoItem.COLUMN_ID,
                PhotoItem.COLUMN_DNAME,
                PhotoItem.COLUMN_ORIPATH,
                PhotoItem.COLUMN_NEWPATH,
                PhotoItem.COLUMN_SIZE,
                PhotoItem.COLUMN_MIMETYPE,
                PhotoItem.COLUMN_CLOUD_FILE_ID,
                PhotoItem.COLUMN_TRASH
            )
            val db = this.writableDatabase
            val cursor = db.query(
                PhotoItem.TABLE_NAME,
                columns,
                PhotoItem.COLUMN_TRASH + "=?",
                arrayOf("2"),
                null,
                null,
                null
            )
            if (cursor.moveToFirst()) {
                do {
                    val note = PhotoItem()
                    note.id = cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_ID))
                    note.displayName =
                        cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_DNAME))
                    note.path = cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_ORIPATH))
                    note.newPath = cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_NEWPATH))
                    note.size = cursor.getLong(cursor.getColumnIndex(PhotoItem.COLUMN_SIZE))
                    note.mimeType =
                        cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_MIMETYPE))
                    note.couldId =
                        cursor.getString(cursor.getColumnIndex(PhotoItem.COLUMN_CLOUD_FILE_ID))
                    note.isTrash = cursor.getInt(cursor.getColumnIndex(PhotoItem.COLUMN_TRASH))
                    notes.add(note)
                } while (cursor.moveToNext())
            }
            db.close()
            return notes
        }
    val notesCount: Int
        get() {
            val countQuery = "SELECT  * FROM " + PhotoItem.TABLE_NAME
            val db = this.readableDatabase
            val cursor = db.rawQuery(countQuery, null)
            val count = cursor.count
            cursor.close()
            return count
        }

    fun updateImgCloudID(id: Int, couldfileide: String?): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(PhotoItem.COLUMN_CLOUD_FILE_ID, couldfileide)
        return db.update(
            PhotoItem.TABLE_NAME,
            values,
            PhotoItem.COLUMN_ID + " = ?",
            arrayOf(id.toString())
        )
    }

    fun movewTrathPhoto(id: Int): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(PhotoItem.COLUMN_TRASH, 1)
        return db.update(
            PhotoItem.TABLE_NAME,
            values,
            PhotoItem.COLUMN_ID + " = ?",
            arrayOf(id.toString())
        )
    }

    fun reCoverPhoto(id: Int): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(PhotoItem.COLUMN_TRASH, 0)
        return db.update(
            PhotoItem.TABLE_NAME,
            values,
            PhotoItem.COLUMN_ID + " = ?",
            arrayOf(id.toString())
        )
    }

    fun deletePhotoTrash(id: Int): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(PhotoItem.COLUMN_TRASH, 2)
        return db.update(
            PhotoItem.TABLE_NAME,
            values,
            PhotoItem.COLUMN_ID + " = ?",
            arrayOf(id.toString())
        )
    }

    fun deletePhotoItem(note: PhotoItem) {
        val db = this.writableDatabase
        db.delete(
            PhotoItem.TABLE_NAME,
            PhotoItem.COLUMN_ID + " = ?",
            arrayOf(note.id.toString())
        )
        db.close()
    }

    fun deleteNotesItem(note: NotesItem) {
        val db = this.writableDatabase
        db.delete(
            NotesItem.TABLE_NAME,
            NotesItem.COLUMN_ID + " = ?",
            arrayOf(note.id.toString())
        )
        db.close()
    }

    //=================== tabVideos=====================
    fun insertVideo(
        displayName: String?,
        oripath: String?,
        newpath: String?,
        size: Long,
        duration: Long,
        mimeType: String?
    ): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(VideoItem.COLUMN_DNAME, displayName)
        values.put(VideoItem.COLUMN_ORIPATH, oripath)
        values.put(VideoItem.COLUMN_NEWPATH, newpath)
        values.put(VideoItem.COLUMN_SIZE, size)
        values.put(VideoItem.COLUMN_MIMETYPE, mimeType)
        values.put(VideoItem.COLUMN_CLOUD_FILE_ID, "null")
        values.put(VideoItem.COLUMN_TRASH, 0)
        val id = db.insert(VideoItem.TABLE_NAME, null, values)
        db.close()
        return id
    }

    fun insertAudio(
        displayName: String?,
        oripath: String?,
        newpath: String?,
        size: Long,
        mimeType: String?
    ): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(AudioItem.COLUMN_DNAME, displayName)
        values.put(AudioItem.COLUMN_ORIPATH, oripath)
        values.put(AudioItem.COLUMN_NEWPATH, newpath)
        values.put(AudioItem.COLUMN_SIZE, size)
        values.put(AudioItem.COLUMN_MIMETYPE, mimeType)
        values.put(AudioItem.COLUMN_CLOUD_FILE_ID, "null")
        values.put(AudioItem.COLUMN_TRASH, 0)
        val id = db.insert(AudioItem.TABLE_NAME, null, values)
        db.close()
        Log.e(TAG, "insertAudio: displayName: $displayName" )
        Log.e(TAG, "insertAudio: oripath: $oripath" )
        Log.e(TAG, "insertAudio: newpath: $newpath" )
        Log.e(TAG, "insertAudio: size: $size" )
        Log.e(TAG, "insertAudio: mimeType: $mimeType" )
        return id
    }

    val allVideos: ArrayList<VideoItem>
        get() {
            val notes = ArrayList<VideoItem>()
            val columns = arrayOf(
                VideoItem.COLUMN_ID,
                VideoItem.COLUMN_DNAME,
                VideoItem.COLUMN_ORIPATH,
                VideoItem.COLUMN_NEWPATH,
                VideoItem.COLUMN_SIZE,
                VideoItem.COLUMN_MIMETYPE,
                VideoItem.COLUMN_CLOUD_FILE_ID,
                VideoItem.COLUMN_TRASH
            )
//            val selectQuery = "SELECT * FROM " + VideoItem.TABLE_NAME
//            val db = this.writableDatabase
//            val cursor = db.rawQuery(selectQuery, null)

            val db = this.writableDatabase
            val cursor = db.query(
                VideoItem.TABLE_NAME,
                columns,
                VideoItem.COLUMN_TRASH + "=?",
                arrayOf("0"),
                null,
                null,
                null
            )
            if (cursor.count > 0) {
                if (cursor.moveToFirst()) {
                    do {
                        val note = VideoItem()
                        note.id = cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_ID))
                        note.displayName = cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_DNAME))
                        note.path = cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_ORIPATH))
                        note.newPath = cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_NEWPATH))
                        note.size = cursor.getLong(cursor.getColumnIndex(VideoItem.COLUMN_SIZE))
                        note.mimeType = cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_MIMETYPE))
                        note.couldId = cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_CLOUD_FILE_ID))
                        note.isTrash = cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_TRASH))
                        notes.add(note)
                    } while (cursor.moveToNext())
                }
            }
            db.close()
            return notes
        }
    val backupVideos: ArrayList<VideoItem>
        get() {
            val notes = ArrayList<VideoItem>()
            val columns = arrayOf(
                VideoItem.COLUMN_ID,
                VideoItem.COLUMN_DNAME,
                VideoItem.COLUMN_ORIPATH,
                VideoItem.COLUMN_NEWPATH,
                VideoItem.COLUMN_SIZE,
                VideoItem.COLUMN_MIMETYPE,
                VideoItem.COLUMN_CLOUD_FILE_ID,
                VideoItem.COLUMN_TRASH
            )
            val db = this.writableDatabase
            val cursor = db.query(
                VideoItem.TABLE_NAME,
                columns,
                VideoItem.COLUMN_CLOUD_FILE_ID + "=?",
                arrayOf("null"),
                null,
                null,
                null
            )
            Log.e("TAG", "getBackupImages: " + cursor.count)
            if (cursor.moveToFirst()) {
                do {
                    val note = VideoItem()
                    note.id = cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_ID))
                    note.displayName =
                        cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_DNAME))
                    note.path = cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_ORIPATH))
                    note.newPath = cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_NEWPATH))
                    note.size = cursor.getLong(cursor.getColumnIndex(VideoItem.COLUMN_SIZE))
                    note.mimeType =
                        cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_MIMETYPE))
                    note.couldId =
                        cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_CLOUD_FILE_ID))
                    note.isTrash = cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_TRASH))
                    notes.add(note)
                } while (cursor.moveToNext())
            }
            db.close()
            return notes
        }
    val trashVideo: ArrayList<VideoItem>
        get() {
            val notes = ArrayList<VideoItem>()
            val selectQuery =
                "SELECT  * FROM " + VideoItem.TABLE_NAME + " ORDER BY " + VideoItem.COLUMN_ID + " DESC"
            val columns = arrayOf(
                VideoItem.COLUMN_ID,
                VideoItem.COLUMN_DNAME,
                VideoItem.COLUMN_ORIPATH,
                VideoItem.COLUMN_NEWPATH,
                VideoItem.COLUMN_SIZE,
                VideoItem.COLUMN_MIMETYPE,
                VideoItem.COLUMN_CLOUD_FILE_ID,
                VideoItem.COLUMN_TRASH
            )
            val db = this.writableDatabase
            val cursor = db.query(
                VideoItem.TABLE_NAME,
                columns,
                VideoItem.COLUMN_TRASH + "=?",
                arrayOf("1"),
                null,
                null,
                null
            )
            if (cursor.moveToFirst()) {
                do {
                    val note = VideoItem()
                    note.id = cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_ID))
                    note.displayName =
                        cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_DNAME))
                    note.path = cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_ORIPATH))
                    note.newPath = cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_NEWPATH))
                    note.size = cursor.getLong(cursor.getColumnIndex(VideoItem.COLUMN_SIZE))
                    note.mimeType =
                        cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_MIMETYPE))
                    note.couldId =
                        cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_CLOUD_FILE_ID))
                    note.isTrash = cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_TRASH))
                    notes.add(note)
                } while (cursor.moveToNext())
            }
            db.close()
            return notes
        }
    val restoreVideo: ArrayList<VideoItem>
        get() {
            val notes = ArrayList<VideoItem>()
            val selectQuery =
                "SELECT  * FROM " + VideoItem.TABLE_NAME + " ORDER BY " + VideoItem.COLUMN_ID + " DESC"
            val columns = arrayOf(
                VideoItem.COLUMN_ID,
                VideoItem.COLUMN_DNAME,
                VideoItem.COLUMN_ORIPATH,
                VideoItem.COLUMN_NEWPATH,
                VideoItem.COLUMN_SIZE,
                VideoItem.COLUMN_MIMETYPE,
                VideoItem.COLUMN_CLOUD_FILE_ID,
                VideoItem.COLUMN_TRASH
            )
            val db = this.writableDatabase
            val cursor = db.query(
                VideoItem.TABLE_NAME,
                columns,
                VideoItem.COLUMN_TRASH + "=?",
                arrayOf("2"),
                null,
                null,
                null
            )
            if (cursor.moveToFirst()) {
                do {
                    val note = VideoItem()
                    note.id = cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_ID))
                    note.displayName =
                        cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_DNAME))
                    note.path = cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_ORIPATH))
                    note.newPath = cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_NEWPATH))
                    note.size = cursor.getLong(cursor.getColumnIndex(VideoItem.COLUMN_SIZE))
                    note.mimeType =
                        cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_MIMETYPE))
                    note.couldId =
                        cursor.getString(cursor.getColumnIndex(VideoItem.COLUMN_CLOUD_FILE_ID))
                    note.isTrash = cursor.getInt(cursor.getColumnIndex(VideoItem.COLUMN_TRASH))
                    notes.add(note)
                } while (cursor.moveToNext())
            }
            db.close()
            return notes
        }

    fun updateVideoCloudID(id: Int, couldfileide: String?): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(VideoItem.COLUMN_CLOUD_FILE_ID, couldfileide)
        return db.update(
            VideoItem.TABLE_NAME,
            values,
            VideoItem.COLUMN_ID + " = ?",
            arrayOf(id.toString())
        )
    }

    fun movewTrathVideo(id: Int): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(VideoItem.COLUMN_TRASH, 1)
        return db.update(
            VideoItem.TABLE_NAME,
            values,
            VideoItem.COLUMN_ID + " = ?",
            arrayOf(id.toString())
        )
    }

    fun deleteVideoTrash(id: Int): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(VideoItem.COLUMN_TRASH, 2)
        return db.update(
            VideoItem.TABLE_NAME,
            values,
            VideoItem.COLUMN_ID + " = ?",
            arrayOf(id.toString())
        )
    }

    fun deleteVideoItem(note: VideoItem) {
        val db = this.writableDatabase
        db.delete(
            VideoItem.TABLE_NAME,
            VideoItem.COLUMN_ID + " = ?",
            arrayOf(note.id.toString())
        )
        db.close()
    }

    fun deleteAudioItem(note: AudioItem) {
        val db = this.writableDatabase
        db.delete(
            AudioItem.TABLE_NAME,
            VideoItem.COLUMN_ID + " = ?",
            arrayOf(note.id.toString())
        )
        db.close()
    }

    //================= for tab file
    fun insertFile(
        displayName: String?,
        oripath: String?,
        newpath: String?,
        size: Long,
        mimeType: String?
    ): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(FileItem.COLUMN_DNAME, displayName)
        values.put(FileItem.COLUMN_ORIPATH, oripath)
        values.put(FileItem.COLUMN_NEWPATH, newpath)
        values.put(FileItem.COLUMN_SIZE, size)
        values.put(FileItem.COLUMN_CLOUD_FILE_ID, "null")
        values.put(FileItem.COLUMN_TRASH, 0)
        values.put(FileItem.COLUMN_MIMETYPE, mimeType)
        val id = db.insert(FileItem.TABLE_NAME, null, values)
        db.close()
        return id
    }

    fun getFiles(id: Long): FileItem {
        val db = this.readableDatabase
        val cursor = db.query(
            FileItem.TABLE_NAME,
            arrayOf(
                FileItem.COLUMN_ID,
                FileItem.COLUMN_DNAME,
                FileItem.COLUMN_ORIPATH,
                FileItem.COLUMN_NEWPATH,
                FileItem.COLUMN_SIZE,
                FileItem.COLUMN_MIMETYPE
            ),
            FileItem.COLUMN_ID + "=?",
            arrayOf(id.toString()),
            null,
            null,
            null,
            null
        )
        cursor?.moveToFirst()
        val note = FileItem(
            cursor!!.getInt(cursor.getColumnIndex(FileItem.COLUMN_ID)),
            cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_DNAME)),
            cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_ORIPATH)),
            cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_NEWPATH)),
            cursor.getLong(cursor.getColumnIndex(FileItem.COLUMN_SIZE)),
            cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_MIMETYPE))
        )
        cursor.close()
        return note
    }

    val allAudios: ArrayList<AudioItem>
        get() {
            val notes = ArrayList<AudioItem>()
            val columns = arrayOf(
                AudioItem.COLUMN_ID,
                AudioItem.COLUMN_DNAME,
                AudioItem.COLUMN_ORIPATH,
                AudioItem.COLUMN_NEWPATH,
                AudioItem.COLUMN_SIZE,
                AudioItem.COLUMN_MIMETYPE,
                AudioItem.COLUMN_CLOUD_FILE_ID,
                AudioItem.COLUMN_TRASH
            )
//            val selectQuery = "SELECT * FROM " + AudioItem.TABLE_NAME
//            val db = this.writableDatabase
//            val cursor = db.rawQuery(selectQuery, null)
            val db = this.writableDatabase
            val cursor = db.query(
                AudioItem.TABLE_NAME,
                columns,
                AudioItem.COLUMN_TRASH + "=?",
                arrayOf("0"),
                null,
                null,
                null
            )
            if (cursor.count > 0) {
                if (cursor.moveToFirst()) {
                    do {
                        val note = AudioItem()
                        note.id = cursor.getInt(cursor.getColumnIndex(AudioItem.COLUMN_ID))
                        note.displayName = cursor.getString(cursor.getColumnIndex(AudioItem.COLUMN_DNAME))
                        note.path = cursor.getString(cursor.getColumnIndex(AudioItem.COLUMN_ORIPATH))
                        note.newPath = cursor.getString(cursor.getColumnIndex(AudioItem.COLUMN_NEWPATH))
                        note.size = cursor.getLong(cursor.getColumnIndex(AudioItem.COLUMN_SIZE))
                        note.mimeType = cursor.getString(cursor.getColumnIndex(AudioItem.COLUMN_MIMETYPE))
                        note.couldId = cursor.getString(cursor.getColumnIndex(AudioItem.COLUMN_CLOUD_FILE_ID))
                        note.isTrash = cursor.getInt(cursor.getColumnIndex(AudioItem.COLUMN_TRASH))
                        notes.add(note)
                    } while (cursor.moveToNext())
                }
            }
            db.close()
            return notes
        }


    val allNotes: ArrayList<NotesItem>
        get() {
            val notes = ArrayList<NotesItem>()
            val columns = arrayOf(
                NotesItem.COLUMN_ID,
                NotesItem.COLUMN_DNAME,
                NotesItem.COLUMN_ORIPATH,
                NotesItem.COLUMN_NEWPATH,
                NotesItem.COLUMN_SIZE,
                NotesItem.COLUMN_MIMETYPE,
                NotesItem.COLUMN_CLOUD_FILE_ID,
                NotesItem.COLUMN_TRASH
            )
            val selectQuery = "SELECT * FROM " + NotesItem.TABLE_NAME
            val db = this.writableDatabase
            val cursor = db.rawQuery(selectQuery, null)

            Log.e(TAG, "allNotes:"+cursor.count )

            if (cursor.count > 0) {
                if (cursor.moveToFirst()) {
                    do {
                        val note = NotesItem()
                        note.id = (cursor.getInt(cursor.getColumnIndex(NotesItem.COLUMN_ID)))
                        note.displayName = (cursor.getString(cursor.getColumnIndex(NotesItem.COLUMN_DNAME)))
                        note.path = (cursor.getString(cursor.getColumnIndex(NotesItem.COLUMN_ORIPATH)))

                        val color: Int = Color.argb(255, Random().nextInt(256), Random().nextInt(256), Random().nextInt(256))
                        note.path=color.toString()
                        note.newPath = (cursor.getString(cursor.getColumnIndex(NotesItem.COLUMN_NEWPATH)))
                        note.size = (cursor.getLong(cursor.getColumnIndex(NotesItem.COLUMN_SIZE)))
                        note.mimeType = (cursor.getString(cursor.getColumnIndex(NotesItem.COLUMN_MIMETYPE)))
                        note.couldId = cursor.getString(cursor.getColumnIndex(NotesItem.COLUMN_CLOUD_FILE_ID))
                        note.isTrash = cursor.getInt(cursor.getColumnIndex(NotesItem.COLUMN_TRASH))
                        notes.add(note)
                    } while (cursor.moveToNext())
                }
            }
            db.close()
            return notes
        }


    val allFiles: ArrayList<FileItem>
        get() {
            val notes = ArrayList<FileItem>()
            val columns = arrayOf(
                FileItem.COLUMN_ID,
                FileItem.COLUMN_DNAME,
                FileItem.COLUMN_ORIPATH,
                FileItem.COLUMN_NEWPATH,
                FileItem.COLUMN_SIZE,
                FileItem.COLUMN_MIMETYPE,
                FileItem.COLUMN_CLOUD_FILE_ID,
                FileItem.COLUMN_TRASH
            )
            val db = this.writableDatabase
            val cursor = db.query(
                FileItem.TABLE_NAME,
                columns,
                FileItem.COLUMN_TRASH + "=?",
                arrayOf("0"),
                null,
                null,
                null
            )
            if (cursor.count > 0) {
                if (cursor.moveToFirst()) {
                    do {
                        val note = FileItem()
                        note.id = (cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_ID)))
                        note.displayName =
                            (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_DNAME)))
                        note.path =
                            (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_ORIPATH)))
                        note.newPath =
                            (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_NEWPATH)))
                        note.size = (cursor.getLong(cursor.getColumnIndex(FileItem.COLUMN_SIZE)))
                        note.mimeType =
                            (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_MIMETYPE)))
                        note.couldId =
                            cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_CLOUD_FILE_ID))
                        note.isTrash = cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_TRASH))
                        notes.add(note)
                    } while (cursor.moveToNext())
                }
            }
            db.close()
            return notes
        }

    val trashFiels: ArrayList<FileItem>
        get() {
            val notes = ArrayList<FileItem>()
            val selectQuery =
                "SELECT  * FROM " + FileItem.TABLE_NAME + " ORDER BY " + FileItem.COLUMN_ID + " DESC"
            val columns = arrayOf(
                FileItem.COLUMN_ID,
                FileItem.COLUMN_DNAME,
                FileItem.COLUMN_ORIPATH,
                FileItem.COLUMN_NEWPATH,
                FileItem.COLUMN_SIZE,
                FileItem.COLUMN_MIMETYPE,
                FileItem.COLUMN_CLOUD_FILE_ID,
                FileItem.COLUMN_TRASH
            )
            val db = this.writableDatabase
            val cursor = db.query(
                FileItem.TABLE_NAME,
                columns,
                FileItem.COLUMN_TRASH + "=?",
                arrayOf("1"),
                null,
                null,
                null
            )
            if (cursor.moveToFirst()) {
                do {
                    val note = FileItem()
                    note.id = (cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_ID)))
                    note.displayName =
                        (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_DNAME)))
                    note.path = (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_ORIPATH)))
                    note.newPath =
                        (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_NEWPATH)))
                    note.size = (cursor.getLong(cursor.getColumnIndex(FileItem.COLUMN_SIZE)))
                    note.mimeType =
                        (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_MIMETYPE)))
                    note.couldId =
                        cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_CLOUD_FILE_ID))
                    note.isTrash = cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_TRASH))
                    notes.add(note)
                } while (cursor.moveToNext())
            }
            db.close()
            return notes
        }
    val backupFiels: ArrayList<FileItem>
        get() {
            val notes = ArrayList<FileItem>()
            val columns = arrayOf(
                FileItem.COLUMN_ID,
                FileItem.COLUMN_DNAME,
                FileItem.COLUMN_ORIPATH,
                FileItem.COLUMN_NEWPATH,
                FileItem.COLUMN_SIZE,
                FileItem.COLUMN_MIMETYPE,
                FileItem.COLUMN_CLOUD_FILE_ID,
                FileItem.COLUMN_TRASH
            )
            val db = this.writableDatabase
            val cursor = db.query(
                FileItem.TABLE_NAME,
                columns,
                FileItem.COLUMN_CLOUD_FILE_ID + "=?",
                arrayOf("null1"),
                null,
                null,
                null
            )
            Log.e("TAG", "getBackupImages: " + cursor.count)
            if (cursor.moveToFirst()) {
                do {
                    val note = FileItem()
                    note.id = (cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_ID)))
                    note.displayName =
                        (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_DNAME)))
                    note.path = (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_ORIPATH)))
                    note.newPath =
                        (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_NEWPATH)))
                    note.size = (cursor.getLong(cursor.getColumnIndex(FileItem.COLUMN_SIZE)))
                    note.mimeType =
                        (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_MIMETYPE)))
                    note.couldId =
                        cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_CLOUD_FILE_ID))
                    note.isTrash = cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_TRASH))
                    notes.add(note)
                } while (cursor.moveToNext())
            }
            db.close()
            return notes
        }
    val restoreFile: ArrayList<FileItem>
        get() {
            val notes = ArrayList<FileItem>()
            val selectQuery =
                "SELECT  * FROM " + FileItem.TABLE_NAME + " ORDER BY " + FileItem.COLUMN_ID + " DESC"
            val columns = arrayOf(
                FileItem.COLUMN_ID,
                FileItem.COLUMN_DNAME,
                FileItem.COLUMN_ORIPATH,
                FileItem.COLUMN_NEWPATH,
                FileItem.COLUMN_SIZE,
                FileItem.COLUMN_MIMETYPE,
                FileItem.COLUMN_CLOUD_FILE_ID,
                FileItem.COLUMN_TRASH
            )
            val db = this.writableDatabase
            val cursor = db.query(
                FileItem.TABLE_NAME,
                columns,
                FileItem.COLUMN_TRASH + "=?",
                arrayOf("2"),
                null,
                null,
                null
            )
            if (cursor.moveToFirst()) {
                do {
                    val note = FileItem()
                    note.id = (cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_ID)))
                    note.displayName =
                        (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_DNAME)))
                    note.path = (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_ORIPATH)))
                    note.newPath =
                        (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_NEWPATH)))
                    note.size = (cursor.getLong(cursor.getColumnIndex(FileItem.COLUMN_SIZE)))
                    note.mimeType =
                        (cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_MIMETYPE)))
                    note.couldId =
                        cursor.getString(cursor.getColumnIndex(FileItem.COLUMN_CLOUD_FILE_ID))
                    note.isTrash = cursor.getInt(cursor.getColumnIndex(FileItem.COLUMN_TRASH))
                    notes.add(note)
                } while (cursor.moveToNext())
            }
            db.close()
            return notes
        }

    fun updateFileCloudID(id: Int, couldfileide: String?): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(FileItem.COLUMN_CLOUD_FILE_ID, couldfileide)
        return db.update(
            FileItem.TABLE_NAME,
            values,
            FileItem.COLUMN_ID + " = ?",
            arrayOf(id.toString())
        )
    }

    fun movewTrathAudio(id: Int): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(AudioItem.COLUMN_TRASH, 1)
        return db.update(
            AudioItem.TABLE_NAME,
            values,
            AudioItem.COLUMN_ID + " = ?",
            arrayOf(id.toString())
        )
    }

    fun movewTrathFile(id: Int): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(FileItem.COLUMN_TRASH, 1)
        return db.update(
            FileItem.TABLE_NAME,
            values,
            FileItem.COLUMN_ID + " = ?",
            arrayOf(id.toString())
        )
    }

    fun reCoverFile(id: Int): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(FileItem.COLUMN_TRASH, 0)
        return db.update(
            FileItem.TABLE_NAME,
            values,
            FileItem.COLUMN_ID + " = ?",
            arrayOf(id.toString())
        )
    }

    fun deleteFileTrash(id: Int): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(FileItem.COLUMN_TRASH, 2)
        return db.update(
            FileItem.TABLE_NAME,
            values,
            FileItem.COLUMN_ID + " = ?",
            arrayOf(id.toString())
        )
    }

    fun deleteFileItem(note: FileItem) {
        val db = this.writableDatabase
        db.delete(
            FileItem.TABLE_NAME,
            FileItem.COLUMN_ID + " = ?",
            arrayOf(note.id.toString())
        )
        db.close()
    }

    val TAG = "DatabaseHelper"

    companion object {
        const val DATABASE_NAME = "calculatorlock.db"
        private const val DATABASE_VERSION = 1
        fun checkDataBase(mContext: Context): Boolean {
            val databasePath = mContext.getDatabasePath(hidePath + "/" + DATABASE_NAME)
            return databasePath.exists()
        }
    }
}