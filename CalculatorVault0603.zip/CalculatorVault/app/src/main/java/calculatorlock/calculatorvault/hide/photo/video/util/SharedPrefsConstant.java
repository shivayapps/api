package calculatorlock.calculatorvault.hide.photo.video.util;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;

import java.util.List;
import java.util.Map;

public class SharedPrefsConstant {

    private static final String SHARED_PREFS_FILE_NAME = "calculatorvault";
    public static final String SELECTED_LANGUAGE = "selectedLocale";
    public static final String SELECTED_LANGUAGE_LABLE = "selectedLocaleLable";
    public static String PRF_IS_LANGUAGE = "PRF_IS_LANGUAGE";
    public static String IS_REFRESH_HOME = "IS_REFRESH_HOME";


    private static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(SHARED_PREFS_FILE_NAME, Context.MODE_PRIVATE);
    }

    public static boolean getInitial(Context context) {
        return getPrefs(context).getBoolean("initial", false);
    }

    public static void setInitial(Context context,boolean value) {
        getPrefs(context).edit().putBoolean("initial", value).apply();
    }
    public static Map<String, ?> getResults(Context context) {
        return getPrefs(context).getAll();
    }

    public static void clearPrefs(Context context) {
        getPrefs(context).edit().clear().apply();
    }

    public static boolean contain(Context context, String key) {
        return getPrefs(context).contains(key);
    }

    public static void savePref(Context context, String key, boolean value) {
        getPrefs(context).edit().putBoolean(key, value).commit();
    }

    private static SharedPreferences getPrefsNoti(Context context) {
        return context.getSharedPreferences(SHARED_PREFS_FILE_NAME, Context.MODE_MULTI_PROCESS);
    }

    public static void savePrefNoti(Context context, String key, boolean value) {
//        if(key.equals("isDeleteFromEmpty")){
//            isSelfDeleted=value;
//        } else
            getPrefsNoti(context).edit().putBoolean(key, value).commit();
    }

    public static boolean getBooleanNoti(Context context, String key, boolean defaultValue) {
//        if(key.equals("isDeleteFromEmpty")){
//            return isSelfDeleted;
//        } else
            return getPrefsNoti(context).getBoolean(key, defaultValue);
    }

    public static void saveStringNoti(Context context, String key, String value) {
        getPrefsNoti(context).edit().putString(key, value).apply();
    }

    public static String getStringNoti(Context context, String key) {
        return getPrefsNoti(context).getString(key, "");
    }


    //Get Booleans
    public static boolean getBoolean(Context context, String key) {
        return getPrefs(context).getBoolean(key, false);
    }

    //Get Booleans if not found return a predefined default value
    public static boolean getBoolean(Context context, String key, boolean defaultValue) {
        return getPrefs(context).getBoolean(key, defaultValue);
    }


    //Strings
    public static void save(Context context, String key, String value) {
        getPrefs(context).edit().putString(key, value).apply();
    }


    public static String getString(Context context, String key) {
        return getPrefs(context).getString(key, "");
    }

    public static String getString(Context context, String key, String defaultValue) {
        return getPrefs(context).getString(key, defaultValue);
    }

    //Integers
    public static void save(Context context, String key, int value) {
        getPrefs(context).edit().putInt(key, value).apply();
    }

    public static int getInt(Context context, String key) {
        return getPrefs(context).getInt(key, 0);
    }

    public static int getInt1(Context context, String key) {
        return getPrefs(context).getInt(key, -1);
    }

    public static int getInt(Context context, String key, int defaultValue) {
        return getPrefs(context).getInt(key, defaultValue);
    }

    //Floats
    public static void save(Context context, String key, float value) {
        getPrefs(context).edit().putFloat(key, value).apply();
    }

    public static float getFloat(Context context, String key) {
        return getPrefs(context).getFloat(key, 0);
    }

    public static float getFloat(Context context, String key, float defaultValue) {
        return getPrefs(context).getFloat(key, defaultValue);
    }

    //Longs
    public static void save(Context context, String key, long value) {
        getPrefs(context).edit().putLong(key, value).apply();
    }


    public static long getLong(Context context, String key) {
        return getPrefs(context).getLong(key, 0);
    }

    public static long getLong(Context context, String key, long defaultValue) {
        return getPrefs(context).getLong(key, defaultValue);
    }

    public static void removeKey(Context context, String key) {
        getPrefs(context).edit().remove(key).apply();
    }

    //Integers
    public static void saveclick(Context context, String key, int value) {
        getPrefs(context).edit().putInt(key, value).apply();
    }

    public static int getIntclick(Context context, String key) {
        return getPrefs(context).getInt(key, 0);
    }

    //get pattern
    public static String getPattern(Context context, String key) {
        return getPrefs(context).getString(key, "");
    }

    //Save pattern
    public static void savePattern(Context context, String key, String value) {
        getPrefs(context).edit().putString(key, value).commit();
    }

    public static boolean isApplicationSentToBackground(final Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> tasks = null;
        try {
            if (am != null) {
                tasks = am.getRunningTasks(1);
            }
            if (tasks != null && !tasks.isEmpty()) {
                ComponentName topActivity = tasks.get(0).topActivity;
                return !topActivity.getPackageName().equals(context.getPackageName());
            }
        } catch (Exception e) {

        }

        return false;
    }
}