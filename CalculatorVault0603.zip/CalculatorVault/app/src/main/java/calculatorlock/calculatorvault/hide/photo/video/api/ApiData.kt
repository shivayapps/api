package calculatorlock.calculatorvault.hide.photo.video.api

import android.os.Parcelable
import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
class ApiData : Parcelable {
    @SerializedName("code") var code: Int? = null
    @SerializedName("msg") var data: ApiResponse? = null
    @SerializedName("app") var app: String? = null
}

@Keep
class ApiResponse {
    @SerializedName("ads_second")
    var clickCount: Int = 0
    @SerializedName("Google_appid")
    var googleAppId: String = ""
    @SerializedName("google_banner")
    var googleBanner: String = ""
    @SerializedName("google_native")
    var googleNative: String = ""
    @SerializedName("google_native_banner")
    var googleNativeBanner: String = ""
    @SerializedName("google_intrestitial")
    var googleIntrestitial: String = ""
    @SerializedName("google_app_open")
    var googleAppOpen: String = ""
}

