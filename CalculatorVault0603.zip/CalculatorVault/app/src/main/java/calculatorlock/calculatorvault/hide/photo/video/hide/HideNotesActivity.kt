package calculatorlock.calculatorvault.hide.photo.video.hide

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaScannerConnection
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.webkit.MimeTypeMap
import android.widget.ProgressBar
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import calculatorlock.calculatorvault.hide.photo.video.MyCommonBaseActivity
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.activity.AddNotesActivity
import calculatorlock.calculatorvault.hide.photo.video.adapters.NotesListAdapter
import calculatorlock.calculatorvault.hide.photo.video.callback.OnItemClickListener
import calculatorlock.calculatorvault.hide.photo.video.db.DatabaseHelper
import calculatorlock.calculatorvault.hide.photo.video.db.NotesItem
import calculatorlock.calculatorvault.hide.photo.video.util.*
import calculatorlock.calculatorvault.hide.photo.video.util.Constant.isGridlayout
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import kotlinx.android.synthetic.main.activity_hide_image.*
import java.io.File

private const val REQUEST_CODE_CHOOSE = 101

class HideNotesActivity : MyCommonBaseActivity() {

//    var mContext: Context? = null
    var imageListAdapter: NotesListAdapter? = null
    var databaseHelper: DatabaseHelper? = null
    private var countSelected = 0
//    private var actionMode: ActionMode? = null
    var isSelectedMode = false
    var imagesList: java.util.ArrayList<NotesItem> = java.util.ArrayList<NotesItem>()
    var gridLayoutManager: GridLayoutManager? = null


//    private val callback: ActionMode.Callback = object : ActionMode.Callback {
//        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
//            val menuInflater = mode.menuInflater
//            menuInflater.inflate(R.menu.menu_unhide, menu)
//            actionMode = mode
//            countSelected = 0
//            return true
//        }
//
//        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
//            return false
//        }
//
//        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
//            val i = item.itemId
//            if (i == R.id.action_unhide) {
//                dialogUnhideFile(this@HideNotesActivity)
//                return true
//            } else if (i == R.id.action_delete) {
//                dialogDeletePhotoView(this@HideNotesActivity)
//                return true
//            }
//            return false
//        }
//
//        override fun onDestroyActionMode(mode: ActionMode) {
//            if (countSelected > 0) {
//                deselectAll()
//            }
//            actionMode = null
//        }
//    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hide_image)


//        databaseHelper = DatabaseHelper(this@HideNotesActivity)

        createImageDir()

        if (isOnline()) {
            NativeAdvancedModelHelper(this@HideNotesActivity).loadNativeAdvancedAd(
                NativeAdsSize.Medium,
                findViewById(R.id.adViewContainer)
            )
        }
    }

    override fun getContext(): AppCompatActivity {
        return this@HideNotesActivity
    }

    override fun initActions() {
        iv_back.setOnClickListener {
            onBackPressed()
//            val intent = Intent(this, MainActivity::class.java)
//            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
//            startActivity(intent)
        }
        action_select_all.setOnClickListener {

            action_select_all.checked = !action_select_all.checked
            selectAll(action_select_all.checked)
        }
        action_delete.setOnClickListener {
            dialogDeletePhotoView(this@HideNotesActivity)
        }
//        action_unhide.setOnClickListener {
//            dialogUnhideFile(this@HideNotesActivity)
//        }
        iv_photo.setOnClickListener {
            choosePicture()
        }
    }
    override fun initViews() {
        databaseHelper = DatabaseHelper(this@HideNotesActivity)
        home_tv_title.setText(getString(R.string.label_notes))

        val no = if (isGridlayout) 2 else 1
        gridLayoutManager = GridLayoutManager(mActivity, no)
        recycler_photolist.setHasFixedSize(true)
        recycler_photolist.layoutManager = gridLayoutManager

        //ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(mContext, R.dimen.item_space);
        //recycler_photolist.addItemDecoration(itemDecoration);
        imagesList = databaseHelper?.allNotes!!
        imageListAdapter = NotesListAdapter(mActivity!!, imagesList)
        imageListAdapter!!.setItemClickEvent(object :
            OnItemClickListener {
            override fun onItemClick(position: Int) {
                if (isSelectedMode) {
                    toggleSelection(position)
                    home_tv_title.setText(countSelected.toString() + " " + getString(R.string.selected))
                    if (countSelected == 0) {
                        deselectAll()
//                        actionMode?.finish()
                        isSelectedMode = false
                        enableActionMode(isSelectedMode)
                    }
                    imageListAdapter!!.isSelectedMode=isSelectedMode
                    action_select_all.checked = imagesList.size == countSelected
                    imageListAdapter!!.notifyDataSetChanged()
                } else {
                    val intent = Intent(mActivity, AddNotesActivity::class.java)
                    intent.putExtra("notesId", imagesList[position].id)
                    intent.putExtra("notesText", imagesList[position].displayName)
                    startActivity(intent)
                }
            }

            override fun onItemLongClick(position: Int) {
                isSelectedMode = true
                enableActionMode(isSelectedMode)
//                if (actionMode == null) {
//                    actionMode = startActionMode(callback)
//                }
                toggleSelection(position)
                //actionMode?.setTitle(countSelected.toString() + " " + getString(R.string.selected))
                home_tv_title?.setText("${countSelected.toString()}  ${getString(R.string.selected)}")
                if (countSelected == 0) {
//                    actionMode?.finish()
                    isSelectedMode = false
                    enableActionMode(isSelectedMode)
                    deselectAll()
                }
                imageListAdapter!!.isSelectedMode=isSelectedMode
                action_select_all.checked = imagesList.size == countSelected
                imageListAdapter!!.notifyDataSetChanged()
            }
        })

        recycler_photolist.adapter = imageListAdapter

        Log.e("imagesList","${imagesList.size}")
        if(imagesList.size==0) {
            empty_view.visibility=View.VISIBLE
        } else {
            empty_view.visibility=View.GONE
        }
    }

    override fun initAds() {

    }

    override fun initData() {

    }

    private fun enableActionMode(enable: Boolean) {
        if(enable) {
            home_tv_title.setText(countSelected.toString() + " " + getString(R.string.selected))
//            action_unhide.visibility=View.VISIBLE
            action_delete.visibility=View.VISIBLE
            action_select_all.visibility=View.VISIBLE
            iv_photo.visibility=View.GONE
        } else {
            home_tv_title.setText(getString(R.string.label_image))
//            action_unhide.visibility=View.GONE
            action_delete.visibility=View.GONE
            action_select_all.visibility=View.GONE
            iv_photo.visibility=View.VISIBLE
        }
    }

//    private fun enableActionMode(enable: Boolean) {
//        if(enable) {
//            action_menu.visibility=View.VISIBLE
//            iv_photo.visibility=View.GONE
//        } else {
//            home_tv_title.setText(getString(R.string.label_notes))
//            action_menu.visibility=View.GONE
//            iv_photo.visibility=View.VISIBLE
//        }
//    }

    private fun toggleSelection(position: Int) {
        imagesList[position].isChecked = !imagesList[position].isChecked
        if (imagesList[position].isChecked) {
            countSelected++
        } else {
            countSelected--
        }
        action_select_all.checked=imagesList.size==countSelected
    }
    private fun selectAll(checked: Boolean) {
        var i = 0
        val l = imagesList.size
        while (i < l) {
            imagesList[i].isChecked = checked
            i++
        }
//        isSelectedMode = false
        countSelected = imagesList.size

        if(checked){
            countSelected = imagesList.size
            home_tv_title.setText(countSelected.toString() + " " + getString(R.string.selected))
        } else {
            countSelected = 0
            home_tv_title.setText(getString(R.string.label_notes))
        }

        //action_select_all.checked=imagesList.size==countSelected
        imageListAdapter!!.notifyDataSetChanged()
    }

    private fun deselectAll() {
        var i = 0
        val l = imagesList.size
        while (i < l) {
            imagesList[i].isChecked = false
            i++
        }
        isSelectedMode = false
        countSelected = 0
        home_tv_title.setText(getString(R.string.label_notes))
        action_select_all.checked=imagesList.size==countSelected
        enableActionMode(false)
    }
    private fun createImageDir() {
        val myDirectory: File = File(hidePath)
        if (!myDirectory.exists()) {
            myDirectory.mkdirs()
            Log.e("TAG", "createImageDir: mkdir")
        } else {
        }
    }


    fun unHideFile() {
        val selected = getSelected()
        for (i in selected.indices) {
            val file = File(selected[i].newPath)
            val targetLocation = File(selected[i].path)
            val file1 = File(targetLocation.parent)
            if (!file1.exists()) {
                file1.mkdirs()
            }
            if (file.renameTo(targetLocation)) {
                databaseHelper!!.deleteNotesItem(selected[i])
                addImageToGallery(
                    this@HideNotesActivity,
                    targetLocation.absolutePath,
                    selected[i].mimeType
                )
            }
        }
        //if (actionMode != null) actionMode!!.finish()
        isSelectedMode=false
        imageListAdapter!!.isSelectedMode=isSelectedMode
        enableActionMode(isSelectedMode)
        countSelected = 0
        initViews()
    }

    private fun hideFile(path: String) {
        val file: File = File(path)
        val fileName = file.name
        val oriPath = file.absolutePath
        val mimeType=MimeTypeMap.getSingleton().getMimeTypeFromExtension(getExtension(fileName))

        val targetLocation = File(nohideImage + fileName + ".bin")
        if (file.renameTo(targetLocation)) {
            removeAllForPaths(file, mActivity)
            databaseHelper!!.insertImage(
                fileName,
                oriPath,
                targetLocation.absolutePath,
                file.length(),
                mimeType
            )
        }

        initViews()
    }

    private fun removeAllForPaths(file: File, context: Context?) {
        val where = MediaStore.MediaColumns.DATA + "=?"
        val selectionArgs = arrayOf(
            file.absolutePath
        )
        val contentResolver = mActivity!!.contentResolver
        val filesUri = MediaStore.Files.getContentUri("external")
        contentResolver.delete(filesUri, where, selectionArgs)
        if (file.exists()) {
            contentResolver.delete(filesUri, where, selectionArgs)
        }
    }

    private fun addImageToGallery(context: Context, filePath: String, mimetype: String?) {
        val values = ContentValues()
        values.put(MediaStore.MediaColumns.DATE_TAKEN, System.currentTimeMillis())
        values.put(MediaStore.MediaColumns.MIME_TYPE, mimetype)
        values.put(MediaStore.MediaColumns.DATA, filePath)
        context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        MediaScannerConnection.scanFile(
            context, arrayOf(filePath), null
        ) { path, uri -> }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode){
            REQUEST_CODE_CHOOSE -> {
                when(resultCode) {
                    Activity.RESULT_OK -> {
                        imagesList = databaseHelper?.allNotes!!
                        imageListAdapter!!.setData(imagesList)
                        if(imagesList.size==0) {
                            empty_view.visibility=View.VISIBLE
                        } else {
                            empty_view.visibility=View.GONE
                        }
//                        val mSelected = AGallery.obtainResult(data)
//                        if (mSelected.isNotEmpty() && mSelected.size > 0) {
//                            val paths = AGallery.obtainPathResult(data)
//                            for (path in paths) {
////                                imageArrayList.add(path)
//                                hideFile(path)
//                            }
//                        } else {
//                            Toast.makeText(this@HideNotesActivity, getString(R.string.you_have_select) + mSelected.size + getString(R.string.images), Toast.LENGTH_SHORT).show()
//                        }
                    }
//                    Activity.RESULT_CANCELED -> {
//                        Toast.makeText(this@HideNotesActivity, getString(R.string.cancel_image_selection), Toast.LENGTH_SHORT).show()
//                    }
//                    else -> {
//                        Toast.makeText(this@HideNotesActivity, getString(R.string.failed_image_selection), Toast.LENGTH_SHORT).show()
//                    }
                }
            }
        }
    }


    fun dialogUnhideFile(act: Activity) {

        val builder = AlertDialog.Builder(act)
        builder.setTitle("Unhide Photos?")
        builder.setMessage("Are you sure want to restore(unhide) selected photos?")
        builder.setPositiveButton(
            "Yes"
        ) { dialog, which ->
            unHideFile()
            dialog.dismiss()
        }
        builder.setNegativeButton(
            "No"
        ) { dialog, which -> dialog.dismiss() }
        val alertDialog = builder.create()
        alertDialog.show()

    }

    fun dialogDeletePhotoView(act: Activity) {

        val selected: ArrayList<NotesItem> = getSelected()
        DialogHelper.alertDialog(
            act,
            "Delete Note?",
            "Delete the selected ${selected.size} notes?",
            object : DialogHelper.DialogListener {
                override fun onPositiveClick() {
                    deleteNotes(selected, true)
                }

                override fun onNegativeClick() {

                }
            })

    }


    private fun deleteNotes(selected: ArrayList<NotesItem>,isCheckedTrash: Boolean) {

        object : AsyncTask<Void, Int, Void>() {

            var dialog: android.app.AlertDialog? = null
            var progressBar: ProgressBar? = null
            override fun onPreExecute() {
                super.onPreExecute()
                try {
                    val alertDialogBuilder = android.app.AlertDialog.Builder(mActivity)
                    val inflater = mActivity!!.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
                    val view = inflater.inflate(R.layout.dialog_progress, null)
                    alertDialogBuilder.setView(view)
                    alertDialogBuilder.setCancelable(false)
                    dialog = alertDialogBuilder.create()
                    dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
                    dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                    progressBar = view.findViewById(R.id.progress_bar)
                    progressBar!!.max=selected.size

                    dialog!!.setOnDismissListener {
                    }
                    if (!dialog!!.isShowing) {
                        dialog!!.show()
                    }
                } catch (e: Exception) {
                    Log.e("mmmmmgggggg", "55555:" + e)
                    e.printStackTrace()
                }
            }

            override fun doInBackground(vararg voids: Void): Void? {
                Handler(Looper.getMainLooper()).run {

                    if (selected.isNotEmpty() && selected.size > 0) {

                        for (i in selected.indices) {
                            databaseHelper!!.deleteNotesItem(selected[i])
                            publishProgress((i+1))
                        }
                    }
                }
                return null
            }
            override fun onProgressUpdate(vararg values: Int?) {
                super.onProgressUpdate(*values)
                progressBar!!.progress=values[0]!!.toInt()
            }

            override fun onPostExecute(result: Void?) {
                super.onPostExecute(result)
                dialog!!.dismiss()
                initViews()
                deselectAll()
            }
        }.execute()

//        DeleteCloudFileTask(
//            this@HideNotesActivity,
//            selected,
//            isCheckedTrash
//        ).execute()
    }

    private fun getSelected(): java.util.ArrayList<NotesItem> {
        val selectedImages = java.util.ArrayList<NotesItem>()
        var i = 0
        val l = imagesList.size
        while (i < l) {
            if (imagesList[i].isChecked) {
                selectedImages.add(imagesList[i])
            }
            i++
        }
        return selectedImages
    }

    private fun choosePicture() {
        startActivityForResult(Intent(this@HideNotesActivity,AddNotesActivity::class.java),REQUEST_CODE_CHOOSE)
    }

}