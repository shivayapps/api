package calculatorlock.calculatorvault.hide.photo.video.util

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkInfo
import android.net.Uri
import android.os.Build
import android.util.Log
import android.view.View
import android.widget.ImageView
import androidx.browser.customtabs.CustomTabsIntent
import calculatorlock.calculatorvault.hide.photo.video.R
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
enum class Type {
    INFO_GROUP_01,
    INFO_GROUP_02,
    INFO_GROUP_03,
    INFO_GROUP_04,
    INFO_GROUP_05,
    INFO_GROUP_06,
    INFO_GROUP_07,
    INFO_GROUP_08,
    INFO_GROUP_09,
    INFO_GROUP_10
}

data class Info(val name: Int,val type: Type, val thumb: Int)

fun getDashBoardOptions(): MutableList<Info> {
    val options: MutableList<Info> = ArrayList()
    options.add(Info(R.string.label_image, Type.INFO_GROUP_01,R.drawable.ic_image))     //gallery
    options.add(Info(R.string.label_video, Type.INFO_GROUP_02,R.drawable.ic_video))     //video
    options.add(Info(R.string.label_audio, Type.INFO_GROUP_03,R.drawable.ic_audio))     //audio
    options.add(Info(R.string.label_file, Type.INFO_GROUP_05,R.drawable.ic_file))     //document
    options.add(Info(R.string.label_notes, Type.INFO_GROUP_07,R.drawable.ic_notes))     //notes
    options.add(Info(R.string.label_more_app, Type.INFO_GROUP_09,R.drawable.ic_other))     //settings
    //options.add(Info(R.string.app_name, Type.INFO_GROUP_10,R.drawable.ic_group_10))     //disguice icon
    return options
}

data class Language(val name: Int, val type: String, var isSelected: Boolean = false)

fun getLanguageOptions(): MutableList<Language> {
    val options: MutableList<Language> = ArrayList()
    options.add(Language(R.string.english, "en", true))
    options.add(Language(R.string.hindi, "hi"))
    options.add(Language(R.string.urdu, "ur"))
    options.add(Language(R.string.portuguese, "pt"))
    options.add(Language(R.string.russian, "pt"))
    return options
}

fun Context.isOnline(): Boolean {
    val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val capabilities =
            connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
        if (capabilities != null) {
            return when {
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                        || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                        || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                -> return true
                else -> false
            }
        }
    } else {
        try {
            val activeNetworkInfo: NetworkInfo? = connectivityManager.activeNetworkInfo
            if (activeNetworkInfo != null && activeNetworkInfo.isConnected) {
                return true
            }
        } catch (e: Exception) {
            Log.e("isNetworkAvailable", e.toString())
        }
    }
    return false
}

fun Context.loadImage(resId: Int, imageView: ImageView, progressBar: View?) {

//    val thumbnail = R.drawable.ic_logo
//    val thumbnailRequest = Glide.with(this).load(thumbnail)

    Glide.with(this)
        .load(resId)
//        .placeholder(thumbnail)
//        .error(thumbnail)
//        .thumbnail(thumbnailRequest)
        .centerInside()
        .listener(object : RequestListener<Drawable> {
            override fun onLoadFailed(
                e: GlideException?,
                model: Any?,
                target: Target<Drawable>?,
                isFirstResource: Boolean
            ): Boolean {
                progressBar?.visibility = View.GONE
                imageView.visibility = View.VISIBLE
                return false
            }

            override fun onResourceReady(
                resource: Drawable?,
                model: Any?,
                target: Target<Drawable>?,
                dataSource: DataSource?,
                isFirstResource: Boolean
            ): Boolean {
                progressBar?.visibility = View.GONE
                imageView.visibility = View.VISIBLE
                return false
            }


        }).into(imageView)
}


fun Context.showAppInMarket() {
    val uri = Uri.parse("market://details?id=" + this.packageName)
    val intent = Intent(Intent.ACTION_VIEW, uri).apply {
        flags = Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK
    }
    if (intent.resolveActivity(this.packageManager) != null) {
        startActivity(intent)
    }
}

fun Context.shareApp() {
    val i = Intent(Intent.ACTION_SEND)
    i.type = "text/plain"
    i.putExtra(Intent.EXTRA_SUBJECT, resources.getString(R.string.app_name))
    val appname = this.getString(R.string.app_name)
    val sAux = this.getString(R.string.msg_share_app, appname, packageName)
    i.putExtra(Intent.EXTRA_TEXT, sAux)
    startActivity(Intent.createChooser(i, "Choose one"))
}

fun Context.launchPrivacyPolicy() {
    CustomTabsIntent.Builder().build().launchUrl(this, Uri.parse(getString(R.string.link_privacy_policy)))
}
fun Context.launchMoreApps() {
    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.link_more_apps))))
}


private var progressDialog: ProgressDialog? = null

fun Context.showProgress(progress: Int) {
    if (progressDialog != null) {
        progressDialog!!.progress = progress
    }
}

fun Context.showProgress(message: String?,maxProgress:Int=100) {
    if (progressDialog != null) {
        progressDialog!!.setMessage(message)
        if (!progressDialog!!.isShowing) {
            progressDialog!!.show()
        }
    } else {
        progressDialog = ProgressDialog(this,R.style.MyTheme)
        progressDialog!!.setCancelable(false)
        progressDialog!!.setMessage(message)
        progressDialog!!.max = maxProgress
        progressDialog!!.progress = 0
        progressDialog!!.show()
    }
}

fun Context.dismissProgress() {
    if (progressDialog != null) {
        if (progressDialog!!.isShowing) {
            progressDialog!!.dismiss()
            progressDialog = null
        }
    }
}
