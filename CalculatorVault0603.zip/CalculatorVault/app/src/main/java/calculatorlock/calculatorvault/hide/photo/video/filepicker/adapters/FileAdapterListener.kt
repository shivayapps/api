package calculatorlock.calculatorvault.hide.photo.video.filepicker.adapters

interface FileAdapterListener {
    fun onItemSelected()
}