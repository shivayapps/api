package calculatorlock.calculatorvault.hide.photo.video.util

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.telephony.TelephonyManager
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.util.ratingview.SmartRatingBar
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import java.util.*


val mTAG: String = "ExitDialogs"

var RATING = -1


//fun Activity.exitDialog(interstitialAd: InterstitialAd?) {
//    try {
////        val inflater = (this as Activity).layoutInflater
//        val alertLayout = LayoutInflater.from(this).inflate(R.layout.dialog_exit, null)
//        val tvTitle = alertLayout.findViewById<TextView>(R.id.exit_tv_title)
//        val tvDesc = alertLayout.findViewById<TextView>(R.id.exit_tv_desc)
//        val btnNo = alertLayout.findViewById<TextView>(R.id.exit_btn_no)
//        val btnYes = alertLayout.findViewById<TextView>(R.id.exit_btn_yes)
//        val tf = Typeface.createFromAsset(assets, fontPath)
//        val tfBold = Typeface.createFromAsset(assets, fontPathBold)
//        tvTitle.typeface = tfBold
//        tvDesc.typeface = tf
//        btnNo.typeface = tf
//        btnYes.typeface = tf
//
//        val adContainer = alertLayout.findViewById<FrameLayout>(R.id.ad_view_container)
//        val alert = AlertDialog.Builder(this)
//        alert.setView(alertLayout)
//        alert.setCancelable(false)
//        val dialog = alert.create()
//        btnNo.setOnClickListener {
//            dialog.dismiss()
//            MyApplication.isExit = false
//        }
//        btnYes.setOnClickListener {
//            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 3000) {
//                return@setOnClickListener
//            }
//            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
//
//            ExitSPHelper(this).updateExitCount()
//            dialog.dismiss()
////            MyApplication.isInternalCall = false
////            isInterstitialShown = true
//            nextScreen(interstitialAd)
//        }
//        dialog.show()
//
//        if (AdsManager(this).isNeedToShowAds() && NetworkManager.isInternetConnected(this)) {
//            NativeAdvancedModelHelper(this).loadNativeAdvancedAd(
//                NativeAdsSize.Big,
//                adContainer
//            )
//        }
//
//    } catch (ignored: Exception) {
//        Log.e(mTAG, ignored.toString())
//    }
//}

//fun Context.nextScreen(interstitialAd: InterstitialAd?) {
//    val activity: FragmentActivity = this as FragmentActivity
//    if (AdsManager(activity).isNeedToShowAds()) {
//        if (interstitialAd != null) {
//            if (!SharedPrefsConstant.getBoolean(
//                    activity,
//                    SharedPrefsConstant.IS_APP_IN_BACKGROUND,
//                    true
//                )
//            ) {
//                MyApplication.isInterstitialShown = true
//                interstitialAd.show(activity)
//            }
//        } else {
//            redirectNextActivity(activity)
//        }
//    } else {
//        redirectNextActivity(activity)
//    }
//}

//private fun FragmentActivity.redirectNextActivity(activity: FragmentActivity) {
//    val i = Intent(activity, ExitActivity::class.java)
//    startActivity(i)
//}


fun Context.reportBug(subject: String, errorMessage: String, ratingValue: Int) {

    // Get App Version
    var subject = subject
    var pInfo: PackageInfo? = null
    try {
        pInfo = packageManager.getPackageInfo(packageName, 0)
    } catch (e: PackageManager.NameNotFoundException) {
        e.printStackTrace()
    }
    val version = pInfo!!.versionName

    // Device Name
    val deviceName = Build.MANUFACTURER + " " + Build.MODEL

    // OS Version
    val osVersion = Build.VERSION.RELEASE
    val osAPI = Build.VERSION.SDK_INT

    // Get Country Name
    var country = ""
    try {
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        var countryCode: String? = ""
        if (tm != null) {
            countryCode = tm.networkCountryIso
        }
        val loc = Locale("", countryCode)
        country = loc.displayCountry
    } catch (e: java.lang.Exception) {
        e.printStackTrace()
    }
    val mapPermission = HashMap<String, Boolean>()

    //Intent email = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto", "appguru34@gmail.com", null));
    //email.putExtra(Intent.EXTRA_SUBJECT, subject);
    val mIterator: Iterator<Map.Entry<String, Boolean>> = mapPermission.entries.iterator()
    var mExtraText = ""
    while (mIterator.hasNext()) {
        val (key, value) = mIterator.next()
        if (key.trim { it <= ' ' }.length > 0) {
            mExtraText += "$key : ${if (value) "YES" else "NO"}"
        }
    }
    val body = "Your message: $errorMessage " +
            "Rating :$ratingValue " +
            "Device Information - ${resources.getString(R.string.app_name)} " +
            "Version : $version " +
            "Device Name : $deviceName " +
            "Android API : $osAPI " +
            "Android Version : $osVersion " +
            "Country : $country".trimIndent()

    //"\nExtraText : "+mExtraText;
    subject = subject + " " + resources.getString(R.string.app_name)
    try {
        startActivity(
            Intent.createChooser(
                Intent(
                    Intent.ACTION_SENDTO,
                    Uri.parse(
                        "mailto:" + resources.getString(R.string.email)
                                + "?cc=&subject=" + Uri.encode(subject).toString()
                                + "&body=" + Uri.encode(body)
                    )
                ), getString(R.string.email_choose_from_client)
            )
        )
    } catch (ex: ActivityNotFoundException) {
    }
}


fun Context.ratingDialog(listener: OnRateListener) {
    try {
        Log.e(mTAG, "Rate Dialog called")

        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_rate_new)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val imageIcon: ImageView = dialog.findViewById(R.id.imageIcon)
        val ratingStar: SmartRatingBar = dialog.findViewById(R.id.rb_stars)
        val btnDismiss = dialog.findViewById<TextView>(R.id.dialogButtonClose)
        val btnOk = dialog.findViewById<TextView>(R.id.dialogButtonok)
        val tvTitle = dialog.findViewById<TextView>(R.id.rate_tv_title)


        btnDismiss.setOnClickListener {
            ExitSPHelper(this).saveDismissed(true)
            RATING = -1
//            SharedPrefsConstant.save(this,ShareConstants.RATE_LATTER,1)
            listener.onRate(-1)
            dialog.dismiss()
        }

        btnOk.setOnClickListener {
            Log.e(mTAG, "ratingStar.rating : ${ratingStar.rating}")
            dialog.dismiss()
            RATING = ratingStar.rating.toInt()
            ExitSPHelper(this).saveRate()
            listener.onRate(RATING)
        }
//        dialog.setOnDismissListener { listener.onRate(RATING) }
        ratingStar.setOnRatingBarChangeListener { ratingBar, rating, fromUser ->

            when(rating.toInt()) {
                1->{
                    imageIcon.setImageResource(R.drawable.ic_rate_one)
                }
                2->{
                    imageIcon.setImageResource(R.drawable.ic_rate_two)
                }
                3->{
                    imageIcon.setImageResource(R.drawable.ic_rate_three)
                }
                4->{
                    imageIcon.setImageResource(R.drawable.ic_rate_four)
                }
                5->{
                    imageIcon.setImageResource(R.drawable.ic_rate_five)
                }
            }

            RATING = rating.toInt()
//            ExitSPHelper(this).saveRate()
        }

        dialog.show()
    } catch (ignored: Exception) {
        Log.e(mTAG, ignored.toString())
    }
}


//fun Activity.inAppReview() {
//    Log.i(TAG, "inAppReview")
//    try {
//        val manager: ReviewManager = ReviewManagerFactory.create(this)
//        val request = manager.requestReviewFlow()
//        request.addOnCompleteListener { task ->
//            if (task.isSuccessful) {
//                Log.i(TAG, "task: success")
//                // We can get the ReviewInfo object
//                val reviewInfo: ReviewInfo = task.result
//                val flow: Task<Void> = manager.launchReviewFlow(this, reviewInfo)
//                flow.addOnCompleteListener { result ->
//                    when {
//                        result.isSuccessful -> {
//                            Log.i(TAG, "result: success: " + result.result)
//                        }
//                        result.isComplete -> {
//                            Log.i(TAG, "result: complete: " + result.result)
//                        }
//                        else -> {
//                            Log.e(TAG, "result: failure: " + result.exception)
//                        }
//                    }
//                }
//            } else {
//                //Problem in receiving object
//                Log.e(TAG, "task: failure")
//                rateApp()
//            }
//        }
//    } catch (activityNotFound: ActivityNotFoundException) {
//        Log.e(TAG, "Error: $activityNotFound")
//        rateApp()
//    }
//}


fun Context.rateApp() {
    try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
    } catch (e: ActivityNotFoundException) {
        Log.e(mTAG, e.toString())
        startActivity(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
            )
        )
    }
}

interface OnRateListener {
    fun onRate(rate: Int)
}