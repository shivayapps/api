package calculatorlock.calculatorvault.hide.photo.video.util

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.view.View
import android.view.Window
import android.widget.ImageView
import android.widget.TextView
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.activity.DashBoardActivity
import calculatorlock.calculatorvault.hide.photo.video.db.BaseItem
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

object DialogHelper {
    interface DialogListener {
        fun onPositiveClick()
        fun onNegativeClick()
    }

    //    public static void SetNewPasswordDialog(Context mContext) {
    //        LayoutInflater inflater = ((Activity) mContext).getLayoutInflater();
    //        View alertLayout = inflater.inflate(R.layout.layout_set_password, null);
    //        final TextView gotIt = alertLayout.findViewById(R.id.tv_got_it);
    //
    //        AlertDialog.Builder alert = new AlertDialog.Builder(mContext);
    //        alert.setView(alertLayout);
    //        alert.setCancelable(false);
    //        final AlertDialog dialog = alert.create();
    //        dialog.show();
    //
    //        gotIt.setOnClickListener(view -> dialog.dismiss());
    //
    //    }
    //    public static void ResetPasswordDialog(Context mContext) {
    //        LayoutInflater inflater = ((Activity) mContext).getLayoutInflater();
    //        View alertLayout = inflater.inflate(R.layout.layout_reset_password, null);
    //        final TextView gotIt = alertLayout.findViewById(R.id.tv_got_it);
    //
    //        AlertDialog.Builder alert = new AlertDialog.Builder(mContext);
    //        alert.setView(alertLayout);
    //        alert.setCancelable(false);
    //        final AlertDialog dialog = alert.create();
    //        dialog.show();
    //
    //        gotIt.setOnClickListener(view -> dialog.dismiss());
    //
    //    }
    //    public static void SetRecoverMailDialog(Context mContext) {
    //        LayoutInflater inflater = ((Activity) mContext).getLayoutInflater();
    //        View alertLayout = inflater.inflate(R.layout.layout_recover_mail, null);
    //        final TextView gotIt = alertLayout.findViewById(R.id.tv_got_it);
    //
    //        AlertDialog.Builder alert = new AlertDialog.Builder(mContext);
    //        alert.setView(alertLayout);
    //        alert.setCancelable(false);
    //        final AlertDialog dialog = alert.create();
    //        dialog.show();
    //
    //        gotIt.setOnClickListener(view -> dialog.dismiss());
    //
    //    }
    //    public static void VeryImportantDialog(Context mContext) {
    //        LayoutInflater inflater = ((Activity) mContext).getLayoutInflater();
    //        View alertLayout = inflater.inflate(R.layout.layout_very_important, null);
    //        final TextView gotIt = alertLayout.findViewById(R.id.tv_got_it);
    //
    //        AlertDialog.Builder alert = new AlertDialog.Builder(mContext);
    //        alert.setView(alertLayout);
    //        alert.setCancelable(false);
    //        final AlertDialog dialog = alert.create();
    //        dialog.show();
    //
    //        gotIt.setOnClickListener(view -> dialog.dismiss());
    //
    //    }
    //    public static void DecoyPassCodeDialog(Activity mContext) {
    //        LayoutInflater inflater = ((Activity) mContext).getLayoutInflater();
    //        View alertLayout = inflater.inflate(R.layout.layout_decoy_passcode, null);
    //        final TextView gotIt = alertLayout.findViewById(R.id.tv_got_it);
    //
    //        AlertDialog.Builder alert = new AlertDialog.Builder(mContext);
    //        alert.setView(alertLayout);
    //        alert.setCancelable(false);
    //        final AlertDialog dialog = alert.create();
    //        dialog.show();
    //
    //        gotIt.setOnClickListener(view -> {
    //            Intent iDecoy = new Intent(mContext, DecoyPasscodeActivity.class);
    //            mContext.startActivity(iDecoy);
    //            mContext.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    //            dialog.dismiss();
    //        });
    //    }

    fun infoDialog(mContext: Context, info: BaseItem) {
        val inflater = (mContext as Activity).layoutInflater
        val alertLayout = inflater.inflate(R.layout.layout_info, null)
        val gotIt = alertLayout.findViewById<TextView>(R.id.tv_got_it)
        val iv_image = alertLayout.findViewById<ImageView>(R.id.iv_image)
        val tv_name = alertLayout.findViewById<TextView>(R.id.tv_name)
        val tv_current_path = alertLayout.findViewById<TextView>(R.id.tv_current_path)
        val tv_original_path = alertLayout.findViewById<TextView>(R.id.tv_original_path)
        val tv_added_on = alertLayout.findViewById<TextView>(R.id.tv_added_on)

        tv_name.text = info.displayName
        tv_current_path.text = info.newPath
        tv_original_path.text = info.path
        tv_added_on.text = info.path

        val options: RequestOptions = RequestOptions()
            .centerCrop()
            .placeholder(R.drawable.ic_logo)

        Glide.with(mContext)
            .load(info.newPath)
            .apply(options)
            .into(iv_image)

        val alert = AlertDialog.Builder(mContext)
        alert.setView(alertLayout)
        alert.setCancelable(false)
        val dialog = alert.create()
        dialog.window!!.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
        gotIt.setOnClickListener(View.OnClickListener { v: View? ->
//            Intent intent = new Intent(mContext, DashBoardActivity.class);
//            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//            ((Activity) mContext).startActivity(intent);
//            ((Activity) mContext).finish();
            dialog.dismiss()
        })
    }

    fun messageDialog(mContext: Context, title: String?, message: String?) {
        val inflater = (mContext as Activity).layoutInflater
        val alertLayout = inflater.inflate(R.layout.layout_passcode, null)
        val gotIt = alertLayout.findViewById<TextView>(R.id.tv_got_it)
        val tv_title = alertLayout.findViewById<TextView>(R.id.tv_title)
        val tv_message = alertLayout.findViewById<TextView>(R.id.tv_message)
        tv_title.text = title
        tv_message.text = message
        val alert = AlertDialog.Builder(mContext)
        alert.setView(alertLayout)
        alert.setCancelable(false)
        val dialog = alert.create()
        dialog.window!!.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
        gotIt.setOnClickListener(View.OnClickListener { v: View? ->
//            Intent intent = new Intent(mContext, DashBoardActivity.class);
//            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//            ((Activity) mContext).startActivity(intent);
//            ((Activity) mContext).finish();
            dialog.dismiss()
        })
    }

    fun antiLossNote(mContext: Context) {
        val inflater = (mContext as Activity).layoutInflater
        val alertLayout = inflater.inflate(R.layout.dialog_anti_loss, null)
        val gotIt = alertLayout.findViewById<TextView>(R.id.tv_got_it)
        val tv_title = alertLayout.findViewById<TextView>(R.id.tv_title)

        val alert = AlertDialog.Builder(mContext)
        alert.setView(alertLayout)
        alert.setCancelable(false)
        val dialog = alert.create()
        dialog.window!!.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
        gotIt.setOnClickListener(View.OnClickListener { v: View? ->
//            Intent intent = new Intent(mContext, DashBoardActivity.class);
//            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//            ((Activity) mContext).startActivity(intent);
//            ((Activity) mContext).finish();
            dialog.dismiss()
        })
    }

    fun alertDialog(mContext: Context, title: String?, message: String?, listener: DialogListener) {
        val inflater = (mContext as Activity).layoutInflater
        val alertLayout = inflater.inflate(R.layout.layout_alert, null)
        val btnCancel = alertLayout.findViewById<TextView>(R.id.tv_cancel)
        val btnOk = alertLayout.findViewById<TextView>(R.id.tv_ok)
        val tv_title = alertLayout.findViewById<TextView>(R.id.tv_title)
        val tv_message = alertLayout.findViewById<TextView>(R.id.tv_message)
        tv_title.text = title
        tv_message.text = message
        val alert = AlertDialog.Builder(mContext)
        alert.setView(alertLayout)
        alert.setCancelable(false)
        val dialog = alert.create()
        dialog.window!!.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
        btnOk.setOnClickListener(View.OnClickListener { v: View? ->
            listener.onPositiveClick()
            dialog.dismiss()
        })
        btnCancel.setOnClickListener(View.OnClickListener { v: View? ->
            listener.onNegativeClick()
            dialog.dismiss()
        })
    }

    fun securityConfirmDialog(
        mContext: Context,
        qus: String?,
        ans: String?,
        mFromWhere: String?,
        mPin: String = ""
    ) {
        val inflater = (mContext as Activity).layoutInflater
        val alertLayout = inflater.inflate(R.layout.layout_security, null)
        val gotIt = alertLayout.findViewById<TextView>(R.id.tv_got_it)
        val tv_qus = alertLayout.findViewById<TextView>(R.id.tv_qus)
        val tv_ans = alertLayout.findViewById<TextView>(R.id.tv_ans)
        val tv_pwd_label = alertLayout.findViewById<TextView>(R.id.tv_pwd_label)
        val tv_pwd = alertLayout.findViewById<TextView>(R.id.tv_pwd)
        tv_qus.text = qus
        tv_ans.text = ans
        if (mPin.isEmpty()) {
            tv_pwd_label.visibility = View.GONE
            tv_pwd.visibility = View.GONE
        } else {
            tv_pwd.text = mPin
        }
        val alert = AlertDialog.Builder(mContext)
        alert.setView(alertLayout)
        alert.setCancelable(false)
        val dialog = alert.create()
        dialog.window!!.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
        gotIt.setOnClickListener(View.OnClickListener { v: View? ->

            if (mFromWhere.equals("changePwd", ignoreCase = true)) {
                mContext.finish()
            } else {
                val intent = Intent(mContext, DashBoardActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                mContext.startActivity(intent)
                mContext.finish()
            }
            dialog.dismiss()
        })
    }
}