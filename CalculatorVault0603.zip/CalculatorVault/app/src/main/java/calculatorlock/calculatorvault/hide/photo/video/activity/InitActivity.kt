package calculatorlock.calculatorvault.hide.photo.video.activity

import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.isDigitsOnly
import calculatorlock.calculatorvault.hide.photo.video.MyCommonBaseActivity
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.db.DatabaseHelper
import calculatorlock.calculatorvault.hide.photo.video.db.UserItem
import calculatorlock.calculatorvault.hide.photo.video.util.Constant
import calculatorlock.calculatorvault.hide.photo.video.util.permission_gallery
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlinx.android.synthetic.main.activity_main.*
import org.mariuszgromada.math.mxparser.Expression
import java.text.DecimalFormat

class InitActivity : MyCommonBaseActivity() {

    var mContext: Context? = null
    var databaseHelper: DatabaseHelper? = null
    var tempPwd = ""
    var confirmPwd = ""
    var initialSetup = false
    private var mFromWhere: String? = ""
    var userItem = UserItem()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mContext = this@InitActivity
        databaseHelper = DatabaseHelper(mContext)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            checkAllFilePermission()
        } else {
            checkPermissions()
        }

        button_clear.setOnClickListener {
            input.text = ""
            output.text = ""
        }

        button_bracket.setOnClickListener {
            if (!initialSetup) input.text = addToInputText("(")
        }
        button_bracket_r.setOnClickListener {
            if (!initialSetup) input.text = addToInputText(")")
        }
        button_croxx.setOnClickListener {
            input.text = ""
            output.text = ""
//            if (!initialSetup) {
//                val removedLast = input.text.toString().dropLast(1)
//                input.text = removedLast
//                showResult()
//            } else {
//                val removedLast = output.text.toString().dropLast(1)
//                output.text = removedLast
//                //showResult()
//            }
        }
        button_0.setOnClickListener {
            if (!initialSetup) {
                input.text =
                    addToInputText("0")
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            } else {
                val inputStr = output.text.toString() + "0"
                output.text = inputStr
            }
        }
        button_1.setOnClickListener {
            if (!initialSetup) {
                input.text = addToInputText("1")
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            } else {
                val inputStr = output.text.toString() + "1"
                output.text = inputStr
            }
        }
        button_2.setOnClickListener {
            if (!initialSetup) {
                input.text = addToInputText("2")
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            } else {
                val inputStr = output.text.toString() + "2"
                output.text = inputStr
            }
        }
        button_3.setOnClickListener {
            if (!initialSetup) {
                input.text = addToInputText("3")
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            } else {
                val inputStr = output.text.toString() + "3"
                output.text = inputStr
            }
        }
        button_4.setOnClickListener {
            if (!initialSetup) {
                input.text = addToInputText("4")
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            } else {
                val inputStr = output.text.toString() + "4"
                output.text = inputStr
            }
        }
        button_5.setOnClickListener {
            if (!initialSetup) {
                input.text = addToInputText("5")
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            } else {
                val inputStr = output.text.toString() + "5"
                output.text = inputStr
            }
        }
        button_6.setOnClickListener {
            if (!initialSetup) {
                input.text = addToInputText("6")
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            } else {
                val inputStr = output.text.toString() + "6"
                output.text = inputStr
            }
        }
        button_7.setOnClickListener {
            if (!initialSetup) {
                input.text = addToInputText("7")
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            } else {
                val inputStr = output.text.toString() + "7"
                output.text = inputStr
            }
        }
        button_8.setOnClickListener {
            if (!initialSetup) {
                input.text = addToInputText("8")
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            } else {
                val inputStr = output.text.toString() + "8"
                output.text = inputStr
            }
        }
        button_9.setOnClickListener {
            if (!initialSetup) {
                input.text = addToInputText("9")
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            } else {
                val inputStr = output.text.toString() + "9"
                output.text = inputStr
            }
        }
        button_dot.setOnClickListener {
            if (!initialSetup) {
                input.text = addToInputText(".")
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            }
        }
        button_division.setOnClickListener {
            if (!initialSetup) {
                input.text = addToInputText("÷") // ALT + 0247
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            }
        }
        button_multiply.setOnClickListener {
            if (!initialSetup) {
                input.text = addToInputText("×") // ALT + 0215
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            }
        }

        button_subtraction.setOnClickListener {
            if (!initialSetup) {
                input.text = addToInputText("-")
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            }
        }
        button_addition.setOnClickListener {
            if (!initialSetup) {
                input.text = addToInputText("+")
                Handler(Looper.getMainLooper()).postDelayed({
                    showResult()
                }, 10)
            }
        }

        button_equals.setOnClickListener {
            if (initialSetup) {
                if (output.text.isDigitsOnly() && output.text.length == 4) {
                    if (tempPwd.isNullOrEmpty()) {
                        tempPwd = output.text.toString()
                        input.text = "****"
                        output.text = ""
                        txt_hint.text = "Confirm you password, press \"=\""
                    } else if (confirmPwd.isNullOrEmpty()) {
                        confirmPwd = output.text.toString()
                        input.text = "****"
                        output.text = "****"
                        //txt_hint.text="Confirm you password, press \"=\""
                    }
                    if (tempPwd.length == 4 && confirmPwd.length == 4 && tempPwd.equals(confirmPwd)) {
                        userItem.pwd = confirmPwd
                        if(mFromWhere.equals("changePwd",true)) {
                            databaseHelper!!.updatePIN(userItem.id,confirmPwd)
                        }
//                        databaseHelper!!.updatePIN(confirmPwd)
//                        databaseHelper!!.insertUser(confirmPwd,"","")
                        gotoNextActivity(confirmPwd)
                    }
                } else {
                    output.error = "Please enter valid password"
                }
            } else {

//            if(SharedPrefsConstant.getString(this,Constant.KEY_PASS,Constant.DEFAULT_PASS)==getInputExpression()) {
                if (userItem.pwd == getInputExpression()) {
                    gotoNextActivity(confirmPwd)
                } else if(Constant.FORGOT_PASS==getInputExpression()){

                    val intent = Intent(this, SequrityQuestionActivity::class.java)
                    intent.putExtra("fromWhere", "forgotPass")
                    intent.putExtra("pwd", userItem.pwd)
                    intent.putExtra("uId", 1)
                    startActivity(intent)
                } else {
                    showFinalResult()
                }
            }
        }
    }

    override fun getContext(): AppCompatActivity {
        return this@InitActivity
    }

    override fun initViews() {

    }

    override fun initAds() {

    }

    override fun initData() {

    }

    override fun initActions() {

    }

    private fun initialSetup() {
        if (intent.hasExtra("fromWhere")) {
            mFromWhere = intent.getStringExtra("fromWhere")
        }
        databaseHelper = DatabaseHelper(mContext)
        userItem = databaseHelper!!.getUser()

        if(mFromWhere.equals("changePwd",true)) {
            userItem.pwd=""
        }

        if (userItem.pwd.isNullOrEmpty()) {
            initialSetup = true
            txt_hint.text = "Press any four digit password and press \"=\""
            output.maxEms=4
        }
    }

    override fun onBackPressed() {
        //super.onBackPressed()
        if(mFromWhere.isNullOrEmpty()) {
            finishAffinity()
        }
    }


    private fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                initialSetup()
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                try {
                    startActivityForResult(intent, 2296)
                } catch (e: ActivityNotFoundException) {
                }
            }
        }
    }

    fun showSettingsDialog() {
        val dialog = Dialog(this@InitActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<TextView>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            openSettings()
        }
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
        }
        dialog.show()
    }

    private fun openSettings() {

        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)

    }

    private fun checkPermissions() {

        Dexter.withContext(this@InitActivity)
            .withPermissions(*permission_gallery)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                    when {
                        report.areAllPermissionsGranted() -> {
                            initialSetup()
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            Toast.makeText(
                                this@InitActivity, getString(R.string.permission_required),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest>,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            }).check()

    }


    private fun gotoNextActivity(pwd: String) {
        if (initialSetup) {
            if( userItem.squestion.isNullOrEmpty() &&  userItem.answer.isNullOrEmpty()) {
                val intent = Intent(this, SequrityQuestionActivity::class.java)
                intent.putExtra("fromWhere", "initialSetup")
                intent.putExtra("pwd", pwd)
                startActivity(intent)
            } else if(mFromWhere.equals("recent",true)) {
                finish()
            } else {
                val intent = Intent(this, DashBoardActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
        } else if(mFromWhere.equals("recent",true)) {
            finish()
        } else  {
            val intent = Intent(this, DashBoardActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
    }

    val arrOperation = arrayOf("+", "-", "*", "÷")
    private fun addToInputText(buttonValue: String): String {
        val inputStr = input.text.toString() + "" + buttonValue
        return inputStr
    }

    private fun getInputExpression(): String {
        var expression = input.text.replace(Regex("÷"), "/")
        expression = expression.replace(Regex("×"), "*")
        return expression
    }

    private fun showFinalResult() {
        try {
            val expression = getInputExpression()
            val result = Expression(expression).calculate()

            if (result.isNaN()) {
                // Show Error Message
                input.text = ""
                output.text = ""
//                input.setTextColor(ContextCompat.getColor(this, R.color.red))
            } else {
                // Show Result
                input.text = DecimalFormat("0.######").format(result).toString()
                output.text = ""
//                output.setTextColor(ContextCompat.getColor(this, R.color.green))
            }
        } catch (e: Exception) {
            // Show Error Message
            input.text = ""
            output.text = ""
//            output.setTextColor(ContextCompat.getColor(this, R.color.red))
        }
    }

    private fun showResult() {
        try {
            var expression = getInputExpression()
            if (expression.endsWith("+") || expression.endsWith("-") || expression.endsWith("*") || expression.endsWith(
                    "/"
                )
            ) {
                expression = input.text.substring(0, input.text.length - 1)
            }
            val result = Expression(expression).calculate()

            if (result.isNaN()) {
                // Show Error Message
                output.text = ""
//                output.setTextColor(ContextCompat.getColor(this, R.color.red))
            } else {
                // Show Result
                output.text = DecimalFormat("0.######").format(result).toString()
//                output.setTextColor(ContextCompat.getColor(this, R.color.green))
            }
        } catch (e: Exception) {
            // Show Error Message
            output.text = ""
//            output.setTextColor(ContextCompat.getColor(this, R.color.red))
        }
    }

}