package calculatorlock.calculatorvault.hide.photo.video.activity

import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import calculatorlock.calculatorvault.hide.photo.video.MyCommonBaseActivity
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.api.APIClient
import calculatorlock.calculatorvault.hide.photo.video.api.APIInterface
import calculatorlock.calculatorvault.hide.photo.video.api.ApiData
import calculatorlock.calculatorvault.hide.photo.video.api.ApiResponse
import calculatorlock.calculatorvault.hide.photo.video.db.DatabaseHelper
import calculatorlock.calculatorvault.hide.photo.video.util.*
import com.example.app.ads.helper.*
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.openad.OpenAdHelper
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.example.app.ads.helper.openad.AppOpenApplication
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SplashActivity : MyCommonBaseActivity(), View.OnClickListener {

//    lateinit var mContext: Activity

    private val TAG = javaClass.simpleName
    private var adsCountDownTimer: AdsCountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
//        mContext = getContext()

        getAndSetData()
        initAds()

    }


    override fun initViews() {

    }

    private fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                //initialSetup()
                initActions()
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                try {
                    startActivityForResult(intent, 2296)
                } catch (e: ActivityNotFoundException) {
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    initActions()
                } else {
                    Toast.makeText(
                        mActivity,
                        getString(R.string.permission_required),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    fun showSettingsDialog() {
        val dialog = Dialog(this@SplashActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<TextView>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            openSettings()
        }
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
        }
        dialog.show()
    }

    private fun openSettings() {

        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)

    }

    private fun checkPermissions() {

        Dexter.withContext(this@SplashActivity)
            .withPermissions(*permission_gallery)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                    when {
                        report.areAllPermissionsGranted() -> {
                            initActions()
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            Toast.makeText(
                                this@SplashActivity, getString(R.string.permission_required),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest>,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            }).check()

    }

    override fun initAds() {
        InterstitialAdHelper.loadInterstitialAd(this@SplashActivity, false)
    }

    override fun initData() {

    }

    fun initPermission() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            checkAllFilePermission()
        } else {
            checkPermissions()
        }
    }

    override fun initActions() {
        adsCountDownTimer = if (isOnline()) {
            AdsCountDownTimer(5000, 1000)
        } else {
            AdsCountDownTimer(1000, 100)
        }
        adsCountDownTimer!!.start()

        if (!mActivity.isOnline()) {
            startWithoutRemoveAds()
        } else {
            startSplashDelay()
        }
    }

    private fun startWithoutRemoveAds() {
    }


    public override fun onPause() {
        super.onPause()
        if (adsCountDownTimer != null) {
            adsCountDownTimer!!.cancel()
        }

    }

    override fun onBackPressed() {
        super.onBackPressed()
        System.exit(0)
        finishAffinity()
    }


    public override fun onResume() {
        super.onResume()

        Log.i(TAG, "onResume")

        Log.i(TAG, "Ads loaded..")
        adsCountDownTimer?.cancel()

        Log.i(TAG, "Ads not loaded or may be null")
        initPermission()

    }

    override fun getContext(): AppCompatActivity {
        return this@SplashActivity
    }

    /**
     * AdsCountDownTimer for 5 sec delay
     */
    inner class AdsCountDownTimer(millisInFuture: Long, countDownInterval: Long) :
        CountDownTimer(millisInFuture, countDownInterval) {
        override fun onTick(millisUntilFinished: Long) {}
        override fun onFinish() {
            Log.i(TAG, "countDownTimer: onFinish")

            if (mActivity.isOnline() && AdsManager(mActivity).isClickToShowAds()) {
                isShowInterstitialAd {
                    startSplashHome()
                }
            } else {
                startSplashHome()
            }

        }
    }

    /**
     * If app is not purchased or subscription not found start count down for 5 sec and load ad
     */
    private fun startSplashDelay() {
        adsCountDownTimer?.cancel()
        adsCountDownTimer = if (mActivity.isOnline()) {
            AdsCountDownTimer(5000, 1000)
        } else {
            AdsCountDownTimer(1000, 1000)
        }
        adsCountDownTimer!!.start()
        Log.i(TAG, "Loading...")
    }

    /**
     * Start your splash home our desire activity
     */
    private fun startSplashHome() {
        generateDatabase("calculatorlock.db")
        DatabaseHelper(mActivity)

        if (adsCountDownTimer != null) {
            adsCountDownTimer!!.cancel()
        }

        val i = Intent(mActivity, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        this@SplashActivity.finish()
    }


    var apiInterface: APIInterface? = null
    private fun getAndSetData() {
        val googleAppId = SharedPrefsConstant.getString(this, "googleAppId")
        val googleBanner = SharedPrefsConstant.getString(this, "googleBanner")
        val googleNativeBanner = SharedPrefsConstant.getString(this, "googleNativeBanner")
        val googleIntrestitial = SharedPrefsConstant.getString(this, "googleIntrestitial")
        val googleAppOpen = SharedPrefsConstant.getString(this, "googleAppOpen")
        val adsCount = SharedPrefsConstant.getInt(this, "clickCount")
        AdsManager(mActivity).setClickToShowAds(adsCount)


        admob_app_id = googleAppId!!
        admob_banner_ad_id = googleBanner!!
        admob_interstitial_ad_id = googleIntrestitial!!
        admob_native_advanced_ad_id = googleNativeBanner!!
        admob_reward_video_ad_id = ""
        admob_interstitial_ad_reward_id = ""
        admob_open_ad_id = googleAppOpen!!

        Log.e("MainActivity", "getAndSetData()")

//        showProgress(null)

        apiInterface = APIClient.client?.create(APIInterface::class.java)

        val apiKey = getString(R.string.apiKey)
        val contentType = getString(R.string.contentType)
        val call: Call<ApiData>? = apiInterface?.doGetAllData(apiKey, contentType, packageName)

        Log.e("MainActivity", "getAndSetData-apiKey:" + apiKey)
        Log.e("MainActivity", "getAndSetData-contentType:" + contentType)
        Log.e("MainActivity", "getAndSetData-packageName:" + packageName)
        call!!.enqueue(object : Callback<ApiData> {
            override fun onResponse(call: Call<ApiData>, response: Response<ApiData>) {
                Log.e("MainActivity", "onResponse-001:" + response.body())
                if (response.body() != null) {
                    Log.e("MainActivity", "onResponse-message:" + response.body()!!.code)
                    Log.e("MainActivity", "onResponse-status:" + response.body()!!.app)
                    val templateData = response.body()
                    if (response.body()!!.code == 200) {
                        setAdMobData(templateData!!.data!!)
                    }
//                    dismissProgress()
                }
            }

            override fun onFailure(call: Call<ApiData>, t: Throwable) {
//                dismissProgress()
                Log.e("MainActivity", "onFailure:" + t.message)
                Toast.makeText(
                    this@SplashActivity,
                    "MainActivity:onFailure:" + t.message,
                    Toast.LENGTH_LONG
                ).show()
                call.cancel()
            }
        })
    }

    private fun setAdMobData(response: ApiResponse) {
//        Log.e("MainActivity", "setAdMobData-googleAppOpen:" + response.googleAppOpen)
//        Log.e("MainActivity", "setAdMobData-googleBanner:" + response.googleBanner)
//        Log.e("MainActivity", "setAdMobData-googleNative:" + response.googleNative)
//        Log.e("MainActivity", "setAdMobData-googleNativeBanner:" + response.googleNativeBanner)
//        Log.e("MainActivity", "setAdMobData-googleIntrestitial:" + response.googleIntrestitial)
//        Log.e("MainActivity", "setAdMobData-clickCount:" + response.clickCount)

        val googleAppId = if(response.googleAppId!=null) response.googleAppId else ""
        val googleBanner =  if(response.googleBanner!=null) response.googleBanner else ""
        val googleNativeBanner =  if(response.googleNativeBanner!=null) response.googleNativeBanner else ""
        val googleIntrestitial =  if(response.googleIntrestitial!=null) response.googleIntrestitial else ""
        val googleAppOpen =  if(response.googleAppOpen!=null) response.googleAppOpen else ""
        val clickCount =  if(response.clickCount!=null) response.clickCount else ""

//        admob_interstitial_ad_id=googleIntrestitial!!

        admob_app_id = googleAppId
        admob_banner_ad_id = googleBanner
        admob_interstitial_ad_id = googleIntrestitial
        admob_native_advanced_ad_id = googleNativeBanner
        admob_reward_video_ad_id = ""
        admob_interstitial_ad_reward_id = ""
        admob_open_ad_id = googleAppOpen

        SharedPrefsConstant.save(this, "googleAppId", response.googleAppId)
        SharedPrefsConstant.save(this, "googleBanner", response.googleBanner)
        SharedPrefsConstant.save(this, "googleNativeBanner", response.googleNativeBanner)
        SharedPrefsConstant.save(this, "googleIntrestitial", response.googleIntrestitial)
        SharedPrefsConstant.save(this, "googleAppOpen", response.googleAppOpen)
        SharedPrefsConstant.save(this, "clickCount", response.clickCount)
        AdsManager(mActivity).setClickToShowAds(response.clickCount)

        VasuAdsConfig.with(this)
            .isEnableOpenAd(true)
            .needToTakeAllTestAdID(false)
            .needToBlockInterstitialAd(false)
            .setAdmobAppId(googleAppId)
            .setAdmobBannerAdId(googleBanner)
            .setAdmobNativeAdvancedAdId(googleNativeBanner)
            .setAdmobInterstitialAdId(googleIntrestitial)
            .setAdmobOpenAdId(googleAppOpen)
            .initialize()
        OpenAdHelper.loadOpenAd(this)

    }

    var mLastClickTime: Long = 0
    var mMinDuration = 1000

//    override fun onClick(v: View?) {
//
//        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
//            return
//        }
//        mLastClickTime = SystemClock.elapsedRealtime()
//    }
}