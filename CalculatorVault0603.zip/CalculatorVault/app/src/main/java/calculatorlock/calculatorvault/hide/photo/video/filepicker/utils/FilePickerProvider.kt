package calculatorlock.calculatorvault.hide.photo.video.filepicker.utils

import androidx.core.content.FileProvider

/**
 * Created by Donglu on 2017/6/7.
 */

class FilePickerProvider : FileProvider()