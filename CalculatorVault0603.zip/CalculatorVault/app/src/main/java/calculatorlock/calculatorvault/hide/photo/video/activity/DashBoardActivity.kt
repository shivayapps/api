package calculatorlock.calculatorvault.hide.photo.video.activity

import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.util.Log
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import calculatorlock.calculatorvault.hide.photo.video.MyCommonBaseActivity
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.adapters.MainDashBoardAdapter
import calculatorlock.calculatorvault.hide.photo.video.callback.RVClickListener
import calculatorlock.calculatorvault.hide.photo.video.hide.*
import calculatorlock.calculatorvault.hide.photo.video.util.*
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlinx.android.synthetic.main.activity_dash_board.*

class DashBoardActivity : MyCommonBaseActivity() {

    //    var isExiting: Boolean = false
    var backupAdapter: MainDashBoardAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dash_board)

        if (isOnline()) {
            NativeAdvancedModelHelper(this@DashBoardActivity).loadNativeAdvancedAd(
                NativeAdsSize.Big,
                findViewById(R.id.adViewContainer)
            )
        }

        if (ExitSPHelper(this).isDismissed()) {
            ExitSPHelper(this).saveDismissed(false)
        }
        ExitSPHelper(this).updateExitCount()

    }

    override fun getContext(): AppCompatActivity {
        return this@DashBoardActivity
    }

    private var dashBoardClick: Info? = null
    override fun initViews() {

        val dashBoardOptions = getDashBoardOptions()
        backupAdapter = MainDashBoardAdapter(
            mActivity,
            R.layout.raw_main_screen_item,
            dashBoardOptions,
            object : RVClickListener {
                override fun onItemClick(position: Int) {
                    dashBoardClick = dashBoardOptions[position]
                    manageClick()
                }
            })
//        home_rv_dashboard.addItemDecoration(RvGridSpacingItemDecoration(3, 6, true))
        home_rv_dashboard.adapter = backupAdapter
    }

    override fun initAds() {
    }

    override fun initData() {
    }

    override fun initActions() {
//        iv_back.setOnClickListener {
//        val intent = Intent(this, MainActivity::class.java)
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
//        startActivity(intent)
//        }
        iv_setting.setOnClickListener {
            if (isOnline() && AdsManager(mActivity).isClickToShowAds()) {
                isShowInterstitialAd {
                    startActivity(Intent(this@DashBoardActivity, SettingsActivity::class.java))
                }
            } else {
                startActivity(Intent(this@DashBoardActivity, SettingsActivity::class.java))
            }
        }
    }

    override fun onBackPressed() {
//        super.onBackPressed()
        displayExitDialog()
    }

    private fun displayExitDialog() {
        val sp = ExitSPHelper(this)
        Log.e(mTAG, "displayExitDialog isRated: ${sp.isRated()}")
        Log.e(mTAG, "displayExitDialog getExitCount: ${sp.getExitCount()}")
        Log.e(mTAG, "displayExitDialog isDismissed: ${sp.isDismissed()}")

        if (!sp.isRated() && sp.getExitCount() >= 5 && !sp.isDismissed()) {
            ratingDialog(object : OnRateListener {
                override fun onRate(rate: Int) {
                    if (rate >= 4) {
                        rateApp()
                    } else if (rate >= 0) {
                        reportBug("Feedback/Suggestion","",rate)
                    }
                }
            })
        } else {
            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
    }

    private fun manageClick() {
        if (dashBoardClick != null) {
            when (dashBoardClick!!.type) {
                Type.INFO_GROUP_01 -> {
                    //gallery

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        checkAllFilePermission()
                    } else {
                        checkPermissions()
                    }
                }
                Type.INFO_GROUP_02 -> {
                    //video

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        checkAllFilePermission()
                    } else {
                        checkPermissions()
                    }
                }
                Type.INFO_GROUP_03 -> {
                    //audio
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        checkAllFilePermission()
                    } else {
                        checkPermissions()
                    }
                }
                Type.INFO_GROUP_04 -> {
                    //app lock
                }
                Type.INFO_GROUP_05 -> {
                    //document

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        checkAllFilePermission()
                    } else {
                        checkPermissions()
                    }
                }
                Type.INFO_GROUP_06 -> {
                    //file manager
                }
                Type.INFO_GROUP_07 -> {
                    //notes
                    if (isOnline() && AdsManager(mActivity).isClickToShowAds()) {
                        isShowInterstitialAd {
                            startActivity(Intent(this, HideNotesActivity::class.java))
                        }
                    } else {
                        startActivity(Intent(this, HideNotesActivity::class.java))
                    }
                }
                Type.INFO_GROUP_08 -> {
                    //recycle bin
                }
                Type.INFO_GROUP_09 -> {
                    //settings
                    launchMoreApps()
                }
                Type.INFO_GROUP_10 -> {
                    //disguise icon
                }
            }
        }
    }

    private fun goToNextActivity() {
        if (dashBoardClick != null) {
            when (dashBoardClick!!.type) {
                Type.INFO_GROUP_01 -> {
                    //gallery
                    if (isOnline() && AdsManager(mActivity).isClickToShowAds()) {
                        isShowInterstitialAd {
                            startActivity(Intent(this, HideImageActivity::class.java))
                        }
                    } else {
                        startActivity(Intent(this, HideImageActivity::class.java))
                    }
                }
                Type.INFO_GROUP_02 -> {
                    //video
                    if (isOnline() && AdsManager(mActivity).isClickToShowAds()) {
                        isShowInterstitialAd {
                            startActivity(Intent(this, HideVideoActivity::class.java))
                        }
                    } else {
                        startActivity(Intent(this, HideVideoActivity::class.java))
                    }
                }
                Type.INFO_GROUP_03 -> {
                    //audio
                    if (isOnline() && AdsManager(mActivity).isClickToShowAds()) {
                        isShowInterstitialAd {
                            startActivity(Intent(this, HideAudioActivity::class.java))
                        }
                    } else {
                        startActivity(Intent(this, HideAudioActivity::class.java))
                    }
                }
                Type.INFO_GROUP_04 -> {
                    //app lock
                }
                Type.INFO_GROUP_05 -> {
                    //document
                    if (isOnline() && AdsManager(mActivity).isClickToShowAds()) {
                        isShowInterstitialAd {
                            startActivity(Intent(this, HideFileActivity::class.java))
                        }
                    } else {
                        startActivity(Intent(this, HideFileActivity::class.java))
                    }
                }
                Type.INFO_GROUP_06 -> {
                    //file manager
                }
                Type.INFO_GROUP_07 -> {
                    //notes
                }
                Type.INFO_GROUP_08 -> {
                    //recycle bin
                }
                Type.INFO_GROUP_09 -> {
                    //settings
                    if (isOnline() && AdsManager(mActivity).isClickToShowAds()) {
                        isShowInterstitialAd {
                            launchMoreApps()
                        }
                    } else {
                        launchMoreApps()
                    }
                }
                Type.INFO_GROUP_10 -> {
                    //disguise icon
                }
            }
        }
    }

    private fun checkPermissions() {

        Dexter.withContext(this@DashBoardActivity)
            .withPermissions(*permission_gallery)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                    when {
                        report.areAllPermissionsGranted() -> {
                            goToNextActivity()
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            Toast.makeText(
                                this@DashBoardActivity, getString(R.string.permission_required),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest>,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            }).check()
    }


    private fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                goToNextActivity()
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                try {
                    startActivityForResult(intent, 2296)
                } catch (e: ActivityNotFoundException) {
                }
            }
        }
    }

    fun showSettingsDialog() {
        val dialog = Dialog(this@DashBoardActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<TextView>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            openSettings()
        }
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
        }
        dialog.show()
    }

    private fun openSettings() {

        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)

    }

}