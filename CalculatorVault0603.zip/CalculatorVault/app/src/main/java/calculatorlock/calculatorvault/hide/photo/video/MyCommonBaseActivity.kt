package calculatorlock.calculatorvault.hide.photo.video

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import calculatorlock.calculatorvault.hide.photo.video.multilang.LocaleManager
import calculatorlock.calculatorvault.hide.photo.video.multilang.Locales
import calculatorlock.calculatorvault.hide.photo.video.util.SharedPrefsConstant

abstract class MyCommonBaseActivity : AppCompatActivity(), View.OnClickListener {

    lateinit var mActivity: AppCompatActivity

    var mPreviousSelectedLanguageKey = Locales.English.toString()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mActivity = getContext()

        if(!LocaleManager.isLanguageReset(this@MyCommonBaseActivity)) {
            LocaleManager.setNewLocale(this@MyCommonBaseActivity,"en")
            LocaleManager.ResetLanguage(this@MyCommonBaseActivity)
        }

        LocaleManager.setLocale(this@MyCommonBaseActivity)

        mPreviousSelectedLanguageKey = LocaleManager.getLanguagePref(this@MyCommonBaseActivity)

    }

//    override fun updateLocale(locale: Locale) {
//        super.updateLocale(locale)
//    }

    override fun onResume() {
        super.onResume()
        restartIfRequires()
    }

    private fun restartIfRequires() {
        if (mPreviousSelectedLanguageKey != LocaleManager.getLanguagePref(this@MyCommonBaseActivity)) {
            SharedPrefsConstant.savePref(this, SharedPrefsConstant.IS_REFRESH_HOME, true)
            Log.e("TAG", "restartIfRequires: ")
            recreate()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        } else {
            SharedPrefsConstant.savePref(this, SharedPrefsConstant.IS_REFRESH_HOME, false)
        }
    }



    override fun setContentView(layout: Int) {
        super.setContentView(layout)
        initViews()
        initAds()
        initData()
        initActions()
    }


    /**
     * ToDo. Set the context of activity
     *
     * @return The context of activity.
     */
    abstract fun getContext(): AppCompatActivity

    /**
     * ToDo. Use this method to setup views.
     */
    abstract fun initViews()

    /**
     * ToDo. Use this method to setup ads.
     */
    abstract fun initAds()

    /**
     * ToDo. Use this method to initialize data to view components.
     */
    abstract fun initData()

    /**
     * ToDo. Use this method to initialize action on view components.
     */
    abstract fun initActions()

    override fun onClick(view: View) {
    }



}