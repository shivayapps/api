package calculatorlock.calculatorvault.hide.photo.video.adapters

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.callback.RVClickListener
import calculatorlock.calculatorvault.hide.photo.video.gallery.internal.ui.widget.CheckView
import calculatorlock.calculatorvault.hide.photo.video.util.Language
import calculatorlock.calculatorvault.hide.photo.video.util.SharedPrefsConstant
import calculatorlock.calculatorvault.hide.photo.video.util.camelCaseString


class LanguageAdapter(
    val mContext: Context,
    private val languageOptions: MutableList<Language>,
    val listener: RVClickListener
) : RecyclerView.Adapter<LanguageAdapter.ViewHolder>() {

    var oldPosition=0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.raw_language, parent, false))
    }

    override fun getItemCount(): Int {
        return languageOptions.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val language = languageOptions[position]
        val title = mContext.getString(language.name)
        holder.tvTitle.text = camelCaseString(title)
        holder.tvTitle.isSelected = true


        if(language.type== SharedPrefsConstant.getString(mContext, SharedPrefsConstant.SELECTED_LANGUAGE, "en")!!) {
            holder.cbLanguage.checked=true
            Log.e("ChangeLanguage","true.position:"+position)
        } else {
            holder.cbLanguage.checked=false
            Log.e("ChangeLanguage","false.position:"+position)
        }
//        holder.itemView.setOnClickListener { listener.onItemClick(position) }
//        holder.cbLanguage.setOnCheckedChangeListener { buttonView, isChecked ->
//            if(isChecked) {
//                languageOptions[position].isSelected = true
//                languageOptions[oldPosition].isSelected = false
//                listener.onItemClick(position)
//                notifyDataSetChanged()
//            }
//        }

        holder.itemView.setOnClickListener {
//            holder.cbLanguage.isSelected=true
            if(!holder.cbLanguage.checked) {
                languageOptions[position].isSelected = true
                languageOptions[oldPosition].isSelected = false
                listener.onItemClick(position)
                notifyDataSetChanged()
            }
        }

    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTitle: TextView = itemView.findViewById(R.id.label_text)
        val cbLanguage: CheckView = itemView.findViewById(R.id.cb_select)
    }
}