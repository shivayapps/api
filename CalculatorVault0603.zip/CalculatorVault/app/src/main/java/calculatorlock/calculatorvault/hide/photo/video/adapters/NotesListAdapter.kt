package calculatorlock.calculatorvault.hide.photo.video.adapters

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.callback.OnItemClickListener
import calculatorlock.calculatorvault.hide.photo.video.db.NotesItem
import calculatorlock.calculatorvault.hide.photo.video.gallery.internal.ui.widget.CheckView
import calculatorlock.calculatorvault.hide.photo.video.util.Constant
import java.util.*

class NotesListAdapter(mcContext: Context, mediaFiles: ArrayList<NotesItem>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    var onItemClickListener: OnItemClickListener? = null
    var mContext: Context

    var isSelectedMode: Boolean = false
        get() = field
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    private var mediaFiles = ArrayList<NotesItem>()
    fun setData(mediaFiles: ArrayList<NotesItem>) {
        this.mediaFiles = mediaFiles
        notifyDataSetChanged()
    }

    fun setItemClickEvent(onItemClickListener: OnItemClickListener?) {
        this.onItemClickListener = onItemClickListener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(
            R.layout.row_notes_adapter,
            parent,
            false
        )
        return ViewHolderList(view)
    }

    var isSelected = false
    override fun getItemViewType(position: Int): Int {
        return if (Constant.isGridlayout) 0 else 1
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val viewHolderList = holder as ViewHolderList

//        val color: Int = Color.argb(255, Random().nextInt(256), Random().nextInt(256), Random().nextInt(256))

        val color=mediaFiles[position].path!!.toInt()
        viewHolderList.view_decore.setBackgroundColor(color)

        viewHolderList.tv_filename.text = mediaFiles[position].displayName
        viewHolderList.tv_filename.visibility = View.VISIBLE

        if (isSelectedMode) viewHolderList.top_toolbar.visibility = View.VISIBLE
        else viewHolderList.top_toolbar.visibility = View.GONE

        if(isSelectedMode) viewHolderList.top_toolbar.visibility=View.VISIBLE
        else viewHolderList.top_toolbar.visibility=View.GONE

        if (mediaFiles[position].isChecked) {
            viewHolderList.iv_chek.setChecked(true)
        } else {
            viewHolderList.iv_chek.setChecked(false)
        }
        viewHolderList.iv_chek.setOnClickListener {
            if (onItemClickListener != null) {
                onItemClickListener!!.onItemClick(position)
            }
        }
        viewHolderList.frm_root.setOnClickListener {
            if (onItemClickListener != null) {
                onItemClickListener!!.onItemClick(position)
            }
        }
        viewHolderList.iv_chek.setOnLongClickListener {
            if (onItemClickListener != null) {
                onItemClickListener!!.onItemLongClick(position)
                isSelected = true
            }
            false
        }
        viewHolderList.frm_root.setOnLongClickListener {
            if (onItemClickListener != null) {
                onItemClickListener!!.onItemLongClick(position)
                isSelected = true
            }
            false
        }
//            }
    }

    override fun getItemCount(): Int {
        return mediaFiles.size
    }

    inner class ViewHolderList internal constructor(view: View) : RecyclerView.ViewHolder(view) {

        var frm_root: LinearLayout
        var iv_chek: CheckView
        var tv_filename: TextView
        var top_toolbar: FrameLayout
        var view_decore: View

        init {
            tv_filename = view.findViewById(R.id.tv_filename)
            frm_root = view.findViewById(R.id.frm_root)
            iv_chek = view.findViewById(R.id.check_view)
            top_toolbar = view.findViewById(R.id.top_toolbar)
            view_decore = view.findViewById(R.id.view_decore)
        }
    }

    init {
        this.mediaFiles = mediaFiles
        mContext = mcContext
    }
}