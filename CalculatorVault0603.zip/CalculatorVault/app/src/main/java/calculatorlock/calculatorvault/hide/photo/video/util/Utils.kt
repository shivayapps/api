package calculatorlock.calculatorvault.hide.photo.video.util

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

//open class Utils {
//    companion object {
val permission_gallery =
    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)

var hidePath = Environment.getExternalStorageDirectory().absolutePath + "/.calculatorlock"
val nohideImage = Environment.getExternalStorageDirectory().absolutePath + "/.calculatorlock/" + ".nomedia/" + ".Photo/"
val nohideVideo = Environment.getExternalStorageDirectory().absolutePath + "/.calculatorlock/" + ".nomedia/" + ".Video/"
val nohideAudio = Environment.getExternalStorageDirectory().absolutePath + "/.calculatorlock/" + ".nomedia/" + ".Audio/"
val nohideFile = Environment.getExternalStorageDirectory().absolutePath + "/.calculatorlock/" + ".nomedia/" + ".Files/"
//val hidePath = "/.calculatorlock"
//val nohideImage = "/.calculatorlock/" + ".nomedia/" + ".Photo/"
//val nohideVideo = "/.calculatorlock/" + ".nomedia/" + ".Video/"
//val nohideAudio = "/.calculatorlock/" + ".nomedia/" + ".Audio/"
//val nohideFile = "/.calculatorlock/" + ".nomedia/" + ".Files/"

fun camelCaseString(string: String): String {
    val words = string.split(" ").toMutableList()
    var output = ""
    for (word in words) {
        output += word.capitalize() + " "
    }
    return output.trim()
}

fun String.areDigitsOnly() = matches(Regex("[0-9]+"))

fun String.areLettersOnly() = matches(Regex("[a-zA-Z]+"))

fun Context.getRealPathFromURI(uri: Uri): String? {
    if (uri.scheme == "file") {
        return uri.path
    }
    if (isDownloadsDocument(uri)) {
        val id = DocumentsContract.getDocumentId(uri)
        if (id.areDigitsOnly()) {
            val newUri = ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), id.toLong())
            val path = getDataColumn(newUri)
            if (path != null) {
                return path
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && id.startsWith("msf:")) {
            val split = id.split(":")
            val selection = "_id=?"
            val selectionArgs = arrayOf(split[1])
            return getDataColumn(MediaStore.Downloads.EXTERNAL_CONTENT_URI, selection, selectionArgs)
        }
    } else if (isExternalStorageDocument(uri)) {
        val documentId = DocumentsContract.getDocumentId(uri)
        val parts = documentId.split(":")
        if (parts[0].equals("primary", true)) {
            return "${Environment.getExternalStorageDirectory().absolutePath}/${parts[1]}"
        }
    } else if (isMediaDocument(uri)) {
        val documentId = DocumentsContract.getDocumentId(uri)
        val split = documentId.split(":").dropLastWhile { it.isEmpty() }.toTypedArray()
        val type = split[0]

        val contentUri = when (type) {
            "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }

        val selection = "_id=?"
        val selectionArgs = arrayOf(split[1])
        val path = getDataColumn(contentUri, selection, selectionArgs)
        if (path != null) {
            return path
        }
    }

    return getDataColumn(uri)
}

fun Context.getDataColumn(uri: Uri, selection: String? = null, selectionArgs: Array<String>? = null): String? {
    try {
        val projection = arrayOf(MediaStore.Files.FileColumns.DATA)
        val cursor = contentResolver.query(uri, projection, selection, selectionArgs, null)
        cursor?.use {
            if (cursor.moveToFirst()) {
                val data = cursor.getStringValue(MediaStore.Files.FileColumns.DATA)
                if (data != "null") {
                    return data
                }
            }
        }
    } catch (e: Exception) {
    }
    return null
}

fun Context.getMediaDuration(uriOfFile: String?): String? {
    val mp = MediaPlayer.create(this, Uri.parse(uriOfFile))
        ?: return ""
    val duration = mp.duration
    mp.release()
    return String.format(
        "%d min, %d sec",
        TimeUnit.MILLISECONDS.toMinutes(duration.toLong()),
        TimeUnit.MILLISECONDS.toSeconds(duration.toLong()) - TimeUnit.MINUTES.toSeconds(
            TimeUnit.MILLISECONDS.toMinutes(duration.toLong())
        )
    )
}

private fun isMediaDocument(uri: Uri) = uri.authority == "com.android.providers.media.documents"

private fun isDownloadsDocument(uri: Uri) = uri.authority == "com.android.providers.downloads.documents"

private fun isExternalStorageDocument(uri: Uri) = uri.authority == "com.android.externalstorage.documents"


fun generateDatabase(name:String): File {
//    val timeStamp = SimpleDateFormat("ddMMyyyy_HH_mm_ss", Locale.getDefault()).format(Date())
//    val FILENAME = "${prefix}_$timeStamp.${ext}"

    hidePath = Environment.getExternalStorageDirectory().toString()
    val path = hidePath + "/.calculatorlock"
    val dir = File(path)
    if (!dir.exists()) {
        dir.mkdir()
    }
    var filePath = dir.path + File.separator + name
    val file = File(dir.path + File.separator + name)

    if (File(filePath).exists()) {
        File(filePath).delete()
    }
    if (!File(file.parent!!).exists()) {
        File(file.parent!!).mkdir()
    }

    if (!file.exists()) File(file.parent).mkdirs()
    return file
}

fun generateEmptyFile(prefix: String, ext: String): File {
    val timeStamp = SimpleDateFormat("ddMMyyyy_HH_mm_ss", Locale.getDefault()).format(Date())
    val FILENAME = "${prefix}_$timeStamp.${ext}"

    hidePath = Environment.getExternalStorageDirectory().toString()
    val path = hidePath + ".calculatorlock"
    val dir = File(path)
    if (!dir.exists()) {
        dir.mkdir()
    }
    var filePath = dir.path + File.separator + FILENAME
    val file = File(dir.path + File.separator + FILENAME)

    if (File(filePath).exists()) {
        File(filePath).delete()
    }
    if (!File(file.parent!!).exists()) {
        File(file.parent!!).mkdir()
    }

    if (!file.exists()) File(file.parent).mkdirs()
    return file
}

// storage, G M K B
fun convertStorage(size: Long): String? {
    val kb: Long = 1024
    val mb = kb * 1024
    val gb = mb * 1024
    return if (size >= gb) {
        String.format("%.1f GB", size.toFloat() / gb)
    } else if (size >= mb) {
        val f = size.toFloat() / mb
        String.format(if (f > 100) "%.0f MB" else "%.1f MB", f)
    } else if (size >= kb) {
        val f = size.toFloat() / kb
        String.format(if (f > 100) "%.0f KB" else "%.1f KB", f)
    } else String.format("%d B", size)
}


fun getExtension(filename: String?): String {
    if (filename == null) {
        return ""
    }
    val index = indexOfExtension(filename)
    return if (index == -1) {
        ""
    } else {
        filename.substring(index + 1)
    }
}

fun indexOfExtension(filename: String?): Int {
    if (filename == null) {
        return -1
    }
    val extensionPos = filename.lastIndexOf('.')
    val lastSeparator = indexOfLastSeparator(filename)
    return if (lastSeparator > extensionPos) -1 else extensionPos
}

fun indexOfLastSeparator(filename: String?): Int {
    if (filename == null) {
        return -1
    }
    val lastUnixPos = filename.lastIndexOf('/')
    val lastWindowsPos = filename.lastIndexOf('\\')
    return Math.max(lastUnixPos, lastWindowsPos)
}
//    }
//}