package calculatorlock.calculatorvault.hide.photo.video.callback

interface OnItemClickListener {
    fun onItemClick(position: Int)
    fun onItemLongClick(position: Int)
}