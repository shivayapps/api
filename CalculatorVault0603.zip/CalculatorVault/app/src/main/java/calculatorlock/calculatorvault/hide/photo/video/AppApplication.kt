package calculatorlock.calculatorvault.hide.photo.video

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.util.Log
import androidx.multidex.MultiDex
import calculatorlock.calculatorvault.hide.photo.video.activity.*
import calculatorlock.calculatorvault.hide.photo.video.filepicker.FilePickerActivity
import calculatorlock.calculatorvault.hide.photo.video.filepicker.MediaDetailsActivity
import calculatorlock.calculatorvault.hide.photo.video.gallery.internal.ui.AlbumPreviewActivity
import calculatorlock.calculatorvault.hide.photo.video.gallery.internal.ui.SelectedPreviewActivity
import calculatorlock.calculatorvault.hide.photo.video.gallery.ui.GalleryActivity
import calculatorlock.calculatorvault.hide.photo.video.hide.*
import calculatorlock.calculatorvault.hide.photo.video.util.SharedPrefsConstant
import com.example.app.ads.helper.VasuAdsConfig
import com.example.app.ads.helper.openad.AppOpenApplication
import com.example.app.ads.helper.openad.OpenAdHelper
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException

class AppApplication : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {

    private val TAG = javaClass.simpleName

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        MultiDex.install(this)
    }

    override fun onCreate() {
        super.onCreate()

        setAppLifecycleListener(this)
        initMobileAds("")

        val googleAppId = SharedPrefsConstant.getString(this, "googleAppId")
        val googleBanner = SharedPrefsConstant.getString(this, "googleBanner")
        val googleNativeBanner = SharedPrefsConstant.getString(this, "googleNativeBanner")
        val googleIntrestitial = SharedPrefsConstant.getString(this, "googleIntrestitial")
        val googleAppOpen = SharedPrefsConstant.getString(this, "googleAppOpen")

//        if (googleAppId.isNullOrEmpty()
//            || googleBanner.isNullOrEmpty()
//            || googleNativeBanner.isNullOrEmpty()
//            || googleIntrestitial.isNullOrEmpty()
//            || googleAppOpen.isNullOrEmpty()) {
//            isNeedToShowAds = false;
//        } else {
//            isNeedToShowAds = true;
//        }

        VasuAdsConfig.with(this)
            .isEnableOpenAd(true)
            .needToTakeAllTestAdID(true)
            .needToBlockInterstitialAd(false)
            .setAdmobAppId(googleAppId!!)
            .setAdmobBannerAdId(googleBanner!!)
            .setAdmobNativeAdvancedAdId(googleNativeBanner!!)
            .setAdmobInterstitialAdId(googleIntrestitial!!)
            .setAdmobOpenAdId(googleAppOpen!!)
            .initialize()
        OpenAdHelper.loadOpenAd(this)

//        initMobileAds(getAdsTestDeviceId())

    }

    @SuppressLint("HardwareIds")
    private fun getAdsTestDeviceId(): String {
        return try {
            val androidId: String = Settings.Secure.getString(this.contentResolver, Settings.Secure.ANDROID_ID)
            val md5Data = customMD5(androidId)
            val deviceId = md5Data?.uppercase(java.util.Locale.ENGLISH) ?: "null"
            println("getDeviceId: $deviceId")
            deviceId
        } catch (e: Exception) {
            e.toString()
        }
    }

    private fun customMD5(md5: String): String? {
        try {
            val md = MessageDigest.getInstance("MD5")
            val array = md.digest(md5.toByteArray())
            val sb = StringBuffer()
            for (i in array.indices) {
                sb.append(Integer.toHexString(array[i].toInt() and 0xFF or 0x100).substring(1, 3))
            }
            return sb.toString()
        } catch (e: NoSuchAlgorithmException) {
        }
        return null
    }


    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        Log.e(TAG, "onResumeApp: fCurrentActivity::${fCurrentActivity.localClassName}")
        val isNeedToShowAd: Boolean = when {
            fCurrentActivity is MainActivity -> {
                Log.d(TAG, "onResumeApp: fCurrentActivity is SplashActivity")
                true
            }

            fCurrentActivity is DashBoardActivity -> {
                resumeFromRecent()
                Log.d(TAG, "onResumeApp: fCurrentActivity is ExitActivity")
                true
            }
            fCurrentActivity is FullScreenViewActivity -> {
                resumeFromRecent()
                Log.d(TAG, "onResumeApp: fCurrentActivity is ExitActivity")
                true
            }
            fCurrentActivity is SettingsActivity -> {
                resumeFromRecent()
                Log.d(TAG, "onResumeApp: fCurrentActivity is ExitActivity")
                true
            }
            fCurrentActivity is AddNotesActivity -> {
                resumeFromRecent()
                Log.d(TAG, "onResumeApp: fCurrentActivity is ExitActivity")
                true
            }
            fCurrentActivity is HideAudioActivity -> {
                resumeFromRecent()
                Log.d(TAG, "onResumeApp: fCurrentActivity is ExitActivity")
                true
            }
            fCurrentActivity is HideFileActivity -> {
                resumeFromRecent()
                Log.d(TAG, "onResumeApp: fCurrentActivity is ExitActivity")
                true
            }
            fCurrentActivity is HideImageActivity -> {
                resumeFromRecent()
                Log.d(TAG, "onResumeApp: fCurrentActivity is ExitActivity")
                true
            }
            fCurrentActivity is HideNotesActivity -> {
                resumeFromRecent()
                Log.d(TAG, "onResumeApp: fCurrentActivity is ExitActivity")
                true
            }
            fCurrentActivity is HideVideoActivity -> {
                resumeFromRecent()
                Log.d(TAG, "onResumeApp: fCurrentActivity is ExitActivity")
                true
            }
            fCurrentActivity is GalleryActivity -> {
                resumeFromRecent()
                Log.d(TAG, "onResumeApp: fCurrentActivity is ExitActivity")
                true
            }
            fCurrentActivity is AlbumPreviewActivity -> {
                resumeFromRecent()
                Log.d(TAG, "onResumeApp: fCurrentActivity is ExitActivity")
                true
            }
            fCurrentActivity is SelectedPreviewActivity -> {
                resumeFromRecent()
                Log.d(TAG, "onResumeApp: fCurrentActivity is ExitActivity")
                true
            }
            fCurrentActivity is FilePickerActivity -> {
                resumeFromRecent()
                Log.d(TAG, "onResumeApp: fCurrentActivity is ExitActivity")
                true
            }
            fCurrentActivity is MediaDetailsActivity -> {
                resumeFromRecent()
                Log.d(TAG, "onResumeApp: fCurrentActivity is ExitActivity")
                true
            }

            else -> {
                false
            }
        }

        return isNeedToShowAd
    }

    fun resumeFromRecent() {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("fromWhere", "recent")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

}