package calculatorlock.calculatorvault.hide.photo.video.activity

import android.app.Activity
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import calculatorlock.calculatorvault.hide.photo.video.MyCommonBaseActivity
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.db.DatabaseHelper
import calculatorlock.calculatorvault.hide.photo.video.multilang.Locales
import kotlinx.android.synthetic.main.activity_add_notes.*

class AddNotesActivity : MyCommonBaseActivity() {

    var mContext: Context? = null
    var view: View? = null
    private var countSelected = 0
    private var actionMode: ActionMode? = null
    var isSelectedMode = false
    var databaseHelper: DatabaseHelper? = null

    var notesText=""
    var notesId=0
    var isUpdate=false

    override fun onBackPressed() {
        setResult(Activity.RESULT_OK)
        super.onBackPressed()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_notes)
        mContext=this@AddNotesActivity
        databaseHelper = DatabaseHelper(this@AddNotesActivity)

        if(intent.hasExtra("notesText")) {
            notesText=intent.getStringExtra("notesText")!!
            isUpdate=true
            et_notes.setText(notesText)
        }
        if(intent.hasExtra("notesId")) {
            notesId=intent.getIntExtra("notesId",0)
            isUpdate=true
        }


    }

    override fun getContext(): AppCompatActivity {
        return this@AddNotesActivity
    }

    override fun initViews() {
        iv_back.setOnClickListener {
            onBackPressed()
        }
        iv_done.setOnClickListener {
            if(et_notes.text.toString().isNotEmpty()) {
                if(isUpdate) {
                    databaseHelper!!.updateNote(notesId,et_notes.text.toString())
                } else {
                    databaseHelper!!.insertNotes(et_notes.text.toString())
                }
                onBackPressed()
            } else {
                et_notes.error="Please Enter Notes"
            }
        }
    }

    override fun initAds() {
    }

    override fun initData() {
    }

    override fun initActions() {
    }
}