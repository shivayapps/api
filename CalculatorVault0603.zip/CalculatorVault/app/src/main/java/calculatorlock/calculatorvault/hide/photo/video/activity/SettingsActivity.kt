package calculatorlock.calculatorvault.hide.photo.video.activity

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.browser.customtabs.CustomTabsIntent
import calculatorlock.calculatorvault.hide.photo.video.MyCommonBaseActivity
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.db.DatabaseHelper
import calculatorlock.calculatorvault.hide.photo.video.db.UserItem
import calculatorlock.calculatorvault.hide.photo.video.multilang.LocaleManager
import calculatorlock.calculatorvault.hide.photo.video.util.DialogHelper
import calculatorlock.calculatorvault.hide.photo.video.util.launchPrivacyPolicy
import calculatorlock.calculatorvault.hide.photo.video.util.shareApp
import calculatorlock.calculatorvault.hide.photo.video.util.showAppInMarket
import kotlinx.android.synthetic.main.activity_settings.*
import kotlinx.android.synthetic.main.activity_settings.iv_back

class SettingsActivity : MyCommonBaseActivity() {

    var databaseHelper: DatabaseHelper? = null
    var userItem: UserItem? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

//        if(!LocaleManager.isLanguageReset(this@SettingsActivity)) {
//            LocaleManager.setNewLocale(this@SettingsActivity,"en")
//            LocaleManager.ResetLanguage(this@SettingsActivity)
//        }
//        LocaleManager.setLocale(this@SettingsActivity)
    }

    override fun getContext(): AppCompatActivity {
        return this@SettingsActivity
    }

    override fun initViews() {

    }

    override fun initAds() {

    }

    override fun initData() {

        databaseHelper = DatabaseHelper(this@SettingsActivity)
        userItem = databaseHelper!!.getUser()
    }

    override fun initActions() {
        iv_back.setOnClickListener {
//            val intent = Intent(this, MainActivity::class.java)
//            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
//            startActivity(intent)
            onBackPressed()
        }
        tv_got_it.setOnClickListener {
            lay_forget.visibility=View.GONE
        }
        btn_change_pwd.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("fromWhere", "changePwd")
            startActivity(intent)
        }
        btn_change_lang.setOnClickListener {
            val intent = Intent(this, LanguageActivity::class.java)
            startActivity(intent)
        }
        btn_change_que.setOnClickListener {
            val intent = Intent(this, SequrityQuestionActivity::class.java)
//            intent.putExtra("fromWhere", "initialSetup")
//            userItem = databaseHelper!!.getUser()
            intent.putExtra("fromWhere", "changePwd")
            intent.putExtra("pwd", userItem!!.pwd)
            intent.putExtra("uId", userItem!!.id)
            startActivity(intent)
        }
//        btn_recycle_bin.setOnClickListener {
//        }
        btn_anti_loss.setOnClickListener {
            val title=getString(R.string.anti_loss)
            DialogHelper.antiLossNote(this@SettingsActivity)
        }
        btn_rate.setOnClickListener {
            showAppInMarket()
        }
        btn_share.setOnClickListener {
            shareApp()
        }
        btn_privacy.setOnClickListener {
            launchPrivacyPolicy()
        }

    }

}