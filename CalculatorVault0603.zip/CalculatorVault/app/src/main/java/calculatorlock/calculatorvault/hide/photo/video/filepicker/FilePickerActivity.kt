package calculatorlock.calculatorvault.hide.photo.video.filepicker

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.filepicker.fragments.DocFragment
import calculatorlock.calculatorvault.hide.photo.video.filepicker.fragments.DocPickerFragment
import calculatorlock.calculatorvault.hide.photo.video.filepicker.fragments.MediaPickerFragment
import calculatorlock.calculatorvault.hide.photo.video.filepicker.fragments.PhotoPickerFragmentListener
import calculatorlock.calculatorvault.hide.photo.video.filepicker.utils.FragmentUtil
import kotlinx.android.synthetic.main.activity_file_picker.*
import java.util.*

class FilePickerActivity : BaseFilePickerActivity(), PhotoPickerFragmentListener, DocFragment.DocFragmentListener, DocPickerFragment.DocPickerFragmentListener, MediaPickerFragment.MediaPickerFragmentListener {
    private var type: Int = 0

    @SuppressLint("MissingSuperCall")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState, R.layout.activity_file_picker)
    }

    override fun initView() {
        val intent = intent
        if (intent != null) {
            val selectedPaths: ArrayList<Uri>? = intent.getParcelableArrayListExtra(FilePickerConst.KEY_SELECTED_MEDIA)
            type = intent.getIntExtra(FilePickerConst.EXTRA_PICKER_TYPE, FilePickerConst.AUDIO_PICKER)

            if (selectedPaths != null) {

                if (PickerManager.getMaxCount() == 1) {
                    selectedPaths.clear()
                }

                PickerManager.clearSelections()
                if (type == FilePickerConst.AUDIO_PICKER) {
                    PickerManager.add(selectedPaths, FilePickerConst.FILE_TYPE_AUDIO)
                } else {
                    PickerManager.add(selectedPaths, FilePickerConst.FILE_TYPE_DOCUMENT)
                }
            }

//            setToolbarTitle(PickerManager.currentCount)
            openSpecificFragment(type)

//            if (type == FilePickerConst.AUDIO_PICKER) {
//                home_tv_title.setText(R.string.select_photo_text)
//            } else {
//                home_tv_title.setText(R.string.select_doc_text)
//            }
            home_tv_title.setText(PickerManager.title)
        }

        iv_back.setOnClickListener {
            onBackPressed()
        }
        button_apply.setOnClickListener {
            if (type == FilePickerConst.AUDIO_PICKER) {
                returnData(PickerManager.selectedPhotos)
            } else {
                returnData(PickerManager.selectedFiles)
            }
        }

    }

    override fun getContext(): AppCompatActivity {
        return this@FilePickerActivity
    }

    override fun initViews() {

    }

    override fun initAds() {

    }

    override fun initData() {

    }

    override fun initActions() {

    }

    override fun setToolbarTitle(count: Int) {

        button_apply.setText(getString(R.string.button_apply, count));
//        if (actionBar != null) {
//            val maxCount = PickerManager.getMaxCount()
//            if (maxCount == -1 && count > 0) {
//                actionBar.title = String.format(getString(R.string.attachments_num), count)
//                button_apply.setText(getString(R.string.button_apply, count));
//            } else if (maxCount > 0 && count > 0) {
//                actionBar.title = String.format(getString(R.string.attachments_title_text), count, maxCount)
//            } else if (!TextUtils.isEmpty(PickerManager.title)) {
//                actionBar.title = PickerManager.title
//            } else {
//            }
//        }
    }

    private fun openSpecificFragment(type: Int) {
        if (type == FilePickerConst.AUDIO_PICKER) {
            val photoFragment = DocPickerFragment.newInstance()
            FragmentUtil.replaceFragment(this, R.id.container, photoFragment)
        } else {
            val photoFragment = DocPickerFragment.newInstance()
            FragmentUtil.replaceFragment(this, R.id.container, photoFragment)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.picker_menu, menu)
        val menuItem = menu.findItem(R.id.action_done)
        if (menuItem != null) {
            menuItem.isVisible = PickerManager.getMaxCount() != 1
        }
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val i = item.itemId
        if (i == R.id.action_done) {
            if (type == FilePickerConst.AUDIO_PICKER) {
                returnData(PickerManager.selectedPhotos)
            } else {
                returnData(PickerManager.selectedFiles)
            }

            return true
        } else if (i == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        super.onBackPressed()
        setResult(Activity.RESULT_CANCELED)
        finish()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            FilePickerConst.REQUEST_CODE_MEDIA_DETAIL -> if (resultCode == Activity.RESULT_OK) {
                if (type == FilePickerConst.AUDIO_PICKER) {
                    returnData(PickerManager.selectedPhotos)
                } else {
                    returnData(PickerManager.selectedFiles)
                }
            } else {
                setToolbarTitle(PickerManager.currentCount)
            }
        }
    }

    private fun returnData(paths: ArrayList<Uri>) {
        val intent = Intent()
        if (type == FilePickerConst.AUDIO_PICKER) {
            intent.putParcelableArrayListExtra(FilePickerConst.KEY_SELECTED_MEDIA, paths)
        } else {
            intent.putParcelableArrayListExtra(FilePickerConst.KEY_SELECTED_DOCS, paths)
        }

        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    override fun onDestroy() {
        PickerManager.reset()
        super.onDestroy()
    }

    override fun onItemSelected() {
        val currentCount = PickerManager.currentCount
        setToolbarTitle(currentCount)

        if (PickerManager.getMaxCount() == 1 && currentCount == 1) {
            returnData(
                    if (type == FilePickerConst.AUDIO_PICKER)
                        PickerManager.selectedPhotos
                    else
                        PickerManager.selectedFiles)
        }
    }

    companion object {

        private val TAG = FilePickerActivity::class.java.simpleName
    }
}
