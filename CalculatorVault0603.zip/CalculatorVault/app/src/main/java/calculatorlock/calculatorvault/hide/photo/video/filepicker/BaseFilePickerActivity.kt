package calculatorlock.calculatorvault.hide.photo.video.filepicker

import android.os.Bundle
import androidx.annotation.LayoutRes
import calculatorlock.calculatorvault.hide.photo.video.MyCommonBaseActivity
import calculatorlock.calculatorvault.hide.photo.video.R
import com.google.android.material.appbar.MaterialToolbar

/**
 * Created by droidNinja on 22/07/17.
 */

abstract class BaseFilePickerActivity : MyCommonBaseActivity() {

    protected fun onCreate(savedInstanceState: Bundle?, @LayoutRes layout: Int) {
        super.onCreate(savedInstanceState)
        setTheme(PickerManager.theme)
        setContentView(layout)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        //set orientation
        requestedOrientation = PickerManager.orientation
        initView()
    }

    protected abstract fun initView()
}
