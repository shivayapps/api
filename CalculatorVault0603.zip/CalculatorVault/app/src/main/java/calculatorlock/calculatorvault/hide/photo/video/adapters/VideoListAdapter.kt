package calculatorlock.calculatorvault.hide.photo.video.adapters

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import calculatorlock.calculatorvault.hide.photo.video.db.VideoItem
import androidx.recyclerview.widget.RecyclerView
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.callback.OnItemClickListener
import calculatorlock.calculatorvault.hide.photo.video.gallery.internal.ui.widget.CheckView
import calculatorlock.calculatorvault.hide.photo.video.util.Constant
import calculatorlock.calculatorvault.hide.photo.video.util.*
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.Glide
import java.io.File
import java.util.ArrayList

class VideoListAdapter(mcContext: Context, mediaFiles: ArrayList<VideoItem>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    var onItemClickListener: OnItemClickListener? = null
    var spanCount = 1
    var mContext: Context

    var isSelectedMode: Boolean = false
        get() = field
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    private var mediaFiles = ArrayList<VideoItem>()
    fun setData(mediaFiles: ArrayList<VideoItem>) {
        this.mediaFiles = mediaFiles
        notifyDataSetChanged()
    }

    fun setGridCount(spanCount: Int) {
        this.spanCount = spanCount
    }

    fun setItemClickEvent(onItemClickListener: OnItemClickListener?) {
        this.onItemClickListener = onItemClickListener
    }

//    fun setImageResize(imageSize: Int) {
//        mImageResize = imageSize
//    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (!Constant.isGridlayout) {
            val view = LayoutInflater.from(parent.context).inflate(
                R.layout.row_file_adapter,
                parent,
                false
            )
            ViewHolderList(view)
        } else {
            val view = LayoutInflater.from(parent.context).inflate(
                R.layout.row_image_adapter,
                parent,
                false
            )
            ViewHolderGrid(view)
        }
    }

    var isSelected = false
    override fun getItemViewType(position: Int): Int {
        return if (Constant.isGridlayout) 0 else 1
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (getItemViewType(position) == 0) {
            val viewHolderGrid = holder as ViewHolderGrid
            val mediaFile = File(mediaFiles[position].newPath)
            if (mediaFile.exists()) {
                val options: RequestOptions = RequestOptions()
                    .centerCrop()
//                    .override(mImageResize, mImageResize)
                    .placeholder(R.drawable.ic_video)
                val parth = mediaFile.absolutePath
                val targetLocation = File(parth)
                viewHolderGrid.media_thumbnail.visibility = View.VISIBLE
                Glide.with(mContext)
                    .load(Uri.fromFile(targetLocation))
                    .apply(options)
                    .into(viewHolderGrid.media_thumbnail)
                viewHolderGrid.tv_filename.text = mediaFiles[position].displayName
                viewHolderGrid.tv_filename.isSelected=true
//                viewHolderGrid.tv_size.setText(convertStorage(targetLocation.length()))

                val duration=mContext.getMediaDuration(mediaFiles[position].newPath)
                viewHolderGrid.tv_size.text = "${convertStorage(targetLocation.length())}"
                viewHolderGrid.tv_duration.text = "${duration}"

//                viewHolderGrid.tv_filename.visibility = View.GONE
//                viewHolderGrid.tv_size.visibility = View.GONE
                viewHolderGrid.iv_video.visibility = View.VISIBLE
//                viewHolderGrid.iv_chek.layoutParams.height = mImageResize
//                viewHolderGrid.iv_chek.layoutParams.width = mImageResize
                viewHolderGrid.iv_chek.requestLayout()

                if(isSelectedMode) viewHolderGrid.top_toolbar.visibility=View.VISIBLE
                else viewHolderGrid.top_toolbar.visibility=View.GONE

                if (mediaFiles[position].isChecked) {
                    viewHolderGrid.iv_chek.setChecked(true)
//                    viewHolderGrid.iv_chek.visibility = View.VISIBLE
//                    viewHolderGrid.iv_chek.setImageResource(R.drawable.ic_check_box_black_24dp)
                } else {
                    viewHolderGrid.iv_chek.setChecked(false)
//                    viewHolderGrid.iv_chek.setImageResource(R.drawable.ic_check_box_outline_blank_black_24dp)
//                    if (isSelected) viewHolderGrid.iv_chek.visibility =
//                        View.VISIBLE else viewHolderGrid.iv_chek.visibility = View.INVISIBLE
                }

                viewHolderGrid.iv_chek.setOnClickListener {
                    if (onItemClickListener != null) {
                        onItemClickListener!!.onItemClick(position)
                    }
                }
                viewHolderGrid.frm_root.setOnClickListener {
                    if (onItemClickListener != null) {
                        onItemClickListener!!.onItemClick(position)
                    }
                }
                viewHolderGrid.iv_chek.setOnLongClickListener {
                    if (onItemClickListener != null) {
                        onItemClickListener!!.onItemLongClick(position)
                    }
                    false
                }
                viewHolderGrid.frm_root.setOnLongClickListener {
                    if (onItemClickListener != null) {
                        onItemClickListener!!.onItemLongClick(position)
                    }
                    false
                }
            }
        } else if (getItemViewType(position) == 1) {
            val viewHolderList = holder as ViewHolderList
            val mediaFile = File(mediaFiles[position].newPath)
            if (mediaFile.exists()) {
                val options: RequestOptions = RequestOptions()
                    .placeholder(R.drawable.ic_video)
                val parth = mediaFile.absolutePath
                val targetLocation = File(parth)
                viewHolderList.media_thumbnail.visibility = View.VISIBLE
                Glide.with(mContext)
                    .load(Uri.fromFile(targetLocation))
                    .apply(options)
                    .into(viewHolderList.media_thumbnail)
                viewHolderList.tv_filename.text = mediaFiles[position].displayName
                viewHolderList.tv_filename.isSelected=true
//                viewHolderList.tv_size.text = convertStorage(targetLocation.length())

                val duration=mContext.getMediaDuration(mediaFiles[position].newPath)
                viewHolderList.tv_size.text = "${convertStorage(targetLocation.length())}"
                viewHolderList.tv_duration.text = "${duration}"

                viewHolderList.tv_filename.visibility = View.VISIBLE
                viewHolderList.tv_size.visibility = View.VISIBLE
                viewHolderList.iv_video.visibility = View.VISIBLE

                if(isSelectedMode) viewHolderList.top_toolbar.visibility=View.VISIBLE
                else viewHolderList.top_toolbar.visibility=View.GONE

                if (mediaFiles[position].isChecked) {
                    viewHolderList.iv_chek.setChecked(true)
//                    viewHolderList.iv_chek.visibility = View.VISIBLE
//                    viewHolderList.iv_chek.setImageResource(R.drawable.ic_check_box_black_24dp)
                } else {
                    viewHolderList.iv_chek.setChecked(false)
//                    viewHolderList.iv_chek.setImageResource(R.drawable.ic_check_box_outline_blank_black_24dp)
//                    if (isSelected) viewHolderList.iv_chek.visibility =
//                        View.VISIBLE else viewHolderList.iv_chek.visibility = View.INVISIBLE
                }
                viewHolderList.iv_chek.setOnClickListener {
                    if (onItemClickListener != null) {
                        onItemClickListener!!.onItemClick(position)
                    }
                }
                viewHolderList.frm_root.setOnClickListener {
                    if (onItemClickListener != null) {
                        onItemClickListener!!.onItemClick(position)
                    }
                }
                viewHolderList.iv_chek.setOnLongClickListener {
                    if (onItemClickListener != null) {
                        onItemClickListener!!.onItemLongClick(position)
                        isSelected = true
                    }
                    false
                }
                viewHolderList.frm_root.setOnLongClickListener {
                    if (onItemClickListener != null) {
                        onItemClickListener!!.onItemLongClick(position)
                        isSelected = true
                    }
                    false
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return mediaFiles.size
    }

    inner class ViewHolderGrid internal constructor(view: View) : RecyclerView.ViewHolder(view) {
        var frm_root: LinearLayout
        var media_thumbnail: ImageView
        var iv_video: ImageView
        var iv_chek: CheckView
        var top_toolbar: FrameLayout
        var tv_filename: TextView
        var tv_size: TextView
        var tv_duration: TextView

        init {
            media_thumbnail = view.findViewById(R.id.media_thumbnail)
            iv_video = view.findViewById(R.id.iv_video)
            tv_filename = view.findViewById(R.id.tv_filename)
            tv_duration = view.findViewById(R.id.tv_duration)
            tv_size = view.findViewById(R.id.tv_size)
            frm_root = view.findViewById(R.id.frm_root)
            iv_chek = view.findViewById(R.id.check_view)
            top_toolbar = view.findViewById(R.id.top_toolbar)
        }
    }

    inner class ViewHolderList internal constructor(view: View) : RecyclerView.ViewHolder(view) {
        var frm_root: LinearLayout
        var media_thumbnail: ImageView
        var iv_video: ImageView
        var iv_chek: CheckView
        var top_toolbar: FrameLayout
        var tv_filename: TextView
        var tv_size: TextView
        var tv_duration: TextView

        init {
            media_thumbnail = view.findViewById(R.id.media_thumbnail)
            iv_video = view.findViewById(R.id.iv_video)
            tv_filename = view.findViewById(R.id.tv_filename)
            tv_size = view.findViewById(R.id.tv_size)
            tv_duration = view.findViewById(R.id.tv_duration)
            frm_root = view.findViewById(R.id.frm_root)
            iv_chek = view.findViewById(R.id.check_view)
            top_toolbar = view.findViewById(R.id.top_toolbar)
        }
    }

    init {
        this.mediaFiles = mediaFiles
        mContext = mcContext
    }
}