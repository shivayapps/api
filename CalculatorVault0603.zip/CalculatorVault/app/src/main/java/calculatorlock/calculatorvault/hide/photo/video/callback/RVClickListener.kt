package calculatorlock.calculatorvault.hide.photo.video.callback

interface RVClickListener {
    fun onItemClick(position: Int)
}