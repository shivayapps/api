package calculatorlock.calculatorvault.hide.photo.video.hide

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaPlayer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.webkit.MimeTypeMap
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import calculatorlock.calculatorvault.hide.photo.video.MyCommonBaseActivity
import calculatorlock.calculatorvault.hide.photo.video.R
import calculatorlock.calculatorvault.hide.photo.video.adapters.FileListAdapter
import calculatorlock.calculatorvault.hide.photo.video.callback.OnItemClickListener
import calculatorlock.calculatorvault.hide.photo.video.db.DatabaseHelper
import calculatorlock.calculatorvault.hide.photo.video.db.FileItem
import calculatorlock.calculatorvault.hide.photo.video.filepicker.FilePickerBuilder
import calculatorlock.calculatorvault.hide.photo.video.filepicker.FilePickerConst
import calculatorlock.calculatorvault.hide.photo.video.filepicker.models.sort.SortingTypes
import calculatorlock.calculatorvault.hide.photo.video.filepicker.utils.ContentUriUtils
import calculatorlock.calculatorvault.hide.photo.video.util.*
import calculatorlock.calculatorvault.hide.photo.video.util.Constant.isGridlayout
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import kotlinx.android.synthetic.main.activity_hide_image.*
import java.io.File
import java.util.*

private const val REQUEST_CODE_CHOOSE = 101

class HideFileActivity : MyCommonBaseActivity() {

//    private var imageArrayList: ArrayList<String> = ArrayList()

//    var mContext: Activity? = null
    var view: View? = null
    var imageListAdapter: FileListAdapter? = null
    var databaseHelper: DatabaseHelper? = null
    private var countSelected = 0

    //    private var actionMode: ActionMode? = null
    var isSelectedMode = false
    var imagesList: ArrayList<FileItem> = java.util.ArrayList<FileItem>()
    var gridLayoutManager: GridLayoutManager? = null

//    private lateinit var progressDialog: CustomProgressDialog
//    private var progressStyle: CustomProgressDialog.ProgressStyle = CustomProgressDialog.ProgressStyle.SpinnerStyle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hide_image)

//        mContext = this@HideFileActivity


//        progressDialog = CustomProgressDialog(mActivity)
//        progressDialog.setMessage("Please wait...")
//        progressDialog.setCancelable(false)
//        progressDialog.setProgressStyle(CustomProgressDialog.ProgressStyle.HorizontalStyle)
//        progressStyle = CustomProgressDialog.ProgressStyle.HorizontalStyle

        createImageDir()

    }

    override fun getContext(): AppCompatActivity {
        return this@HideFileActivity
    }

    override fun initActions() {
        iv_back.setOnClickListener {
            onBackPressed()
//            val intent = Intent(this, MainActivity::class.java)
//            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
//            startActivity(intent)
        }
        action_select_all.setOnClickListener {

            action_select_all.checked = !action_select_all.checked
            selectAll(action_select_all.checked)
        }
        action_delete.setOnClickListener {
            dialogDeletePhotoView(this@HideFileActivity)
        }
        action_unhide.setOnClickListener {
            dialogUnhideFile(this@HideFileActivity)
        }
        iv_photo.setOnClickListener {
            choosePicture()
        }
    }

    override fun initViews() {
        databaseHelper = DatabaseHelper(this@HideFileActivity)
        home_tv_title.setText(getString(R.string.label_file))

        val no = if (isGridlayout) 3 else 1
        gridLayoutManager = GridLayoutManager(mActivity, 1)
        recycler_photolist.setHasFixedSize(true)
        recycler_photolist.layoutManager = gridLayoutManager

        //ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(mActivity, R.dimen.item_space);
        //recycler_photolist.addItemDecoration(itemDecoration);
        imagesList = databaseHelper?.allFiles!!
        Collections.reverse(imagesList)

        imageListAdapter = FileListAdapter(mActivity!!, imagesList)
        imageListAdapter!!.setItemClickEvent(object :
            OnItemClickListener {
            override fun onItemClick(position: Int) {
                if (isSelectedMode) {
//                    if (actionMode == null) {
//                        actionMode = startActionMode(callback)
//                    }
                    toggleSelection(position)
                    //actionMode?.setTitle(countSelected.toString() + " " + getString(R.string.selected))
                    home_tv_title.setText(countSelected.toString() + " " + getString(R.string.selected))
                    if (countSelected == 0) {
                        deselectAll()
//                        actionMode?.finish()
                        isSelectedMode = false
                        enableActionMode(isSelectedMode)
                    }
                    imageListAdapter!!.isSelectedMode=isSelectedMode
                    action_select_all.checked = imagesList.size == countSelected
                    imageListAdapter!!.notifyDataSetChanged()
                } else {
                    val intent = Intent()
                    intent.action = Intent.ACTION_VIEW
                    val lFileUri = FileProvider.getUriForFile(
                        this@HideFileActivity, applicationContext.packageName + ".provider", File(
                            imagesList!![position].newPath
                        )
                    )
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    intent.setDataAndType(lFileUri, "*/*")
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                }
            }

            override fun onItemLongClick(position: Int) {
                isSelectedMode = true
                enableActionMode(isSelectedMode)
//                if (actionMode == null) {
//                    actionMode = startActionMode(callback)
//                }
                toggleSelection(position)
                //actionMode?.setTitle(countSelected.toString() + " " + getString(R.string.selected))
                home_tv_title?.setText("${countSelected.toString()}  ${getString(R.string.selected)}")
                if (countSelected == 0) {
//                    actionMode?.finish()
                    isSelectedMode = false
                    enableActionMode(isSelectedMode)
                    deselectAll()
                }
                imageListAdapter!!.isSelectedMode=isSelectedMode
                action_select_all.checked = imagesList.size == countSelected
                imageListAdapter!!.notifyDataSetChanged()
            }
        })
//        imageListAdapter!!.setImageResize(Utils.getImageResize(mActivity, recycler_photolist))

        recycler_photolist.adapter = imageListAdapter

        Log.e("imagesList", "${imagesList.size}")
        if (imagesList.size == 0) {
            empty_view.visibility = View.VISIBLE
        } else {
            empty_view.visibility = View.GONE
        }

        if (isOnline()) {
            NativeAdvancedModelHelper(this@HideFileActivity).loadNativeAdvancedAd(
                NativeAdsSize.Medium,
                findViewById(R.id.adViewContainer)
            )
        }

    }

    override fun initAds() {
    }

    override fun initData() {
    }


    private fun enableActionMode(enable: Boolean) {
        if(enable) {
            action_unhide.visibility=View.VISIBLE
            action_delete.visibility=View.VISIBLE
            action_select_all.visibility=View.VISIBLE
            iv_photo.visibility=View.GONE
        } else {
            home_tv_title.setText(getString(R.string.label_image))
            action_unhide.visibility=View.GONE
            action_delete.visibility=View.GONE
            action_select_all.visibility=View.GONE
            iv_photo.visibility=View.VISIBLE
        }
    }

//    private fun enableActionMode(enable: Boolean) {
//        if (enable) {
//            action_menu.visibility = View.VISIBLE
//            iv_photo.visibility = View.GONE
//        } else {
//            home_tv_title.setText(getString(R.string.label_file))
//            action_menu.visibility = View.GONE
//            iv_photo.visibility = View.VISIBLE
//        }
//    }

    private fun toggleSelection(position: Int) {
        imagesList[position].isChecked = !imagesList[position].isChecked
        if (imagesList[position].isChecked) {
            countSelected++
        } else {
            countSelected--
        }
        action_select_all.checked=imagesList.size==countSelected
    }
    private fun selectAll(checked: Boolean) {
        var i = 0
        val l = imagesList.size
        while (i < l) {
            imagesList[i].isChecked = checked
            i++
        }
        countSelected = imagesList.size

        if(checked) {
            countSelected = imagesList.size
            home_tv_title.setText(countSelected.toString() + " " + getString(R.string.selected))
        } else {
            countSelected = 0
            home_tv_title.setText(getString(R.string.label_file))
        }

        imageListAdapter!!.notifyDataSetChanged()
    }

    private fun deselectAll() {
        var i = 0
        val l = imagesList.size
        while (i < l) {
            imagesList[i].isChecked = false
            i++
        }
        isSelectedMode = false
        countSelected = 0
        imageListAdapter!!.isSelectedMode=isSelectedMode
        action_select_all.checked=imagesList.size==countSelected
        home_tv_title.setText(getString(R.string.label_file))
        enableActionMode(false)
        imageListAdapter!!.notifyDataSetChanged()
    }

    private fun createImageDir() {
        val myDirectory: File = File(hidePath)
        if (!myDirectory.exists()) {
            myDirectory.mkdirs()
            Log.e("TAG", "createImageDir: mkdir")
        } else {
        }
        createNoImageDir()
    }

    private fun createNoImageDir() {
        val myDirectory: File = File(nohideFile)
        if (!myDirectory.exists()) {
            myDirectory.mkdirs()
            Log.e("TAG", "createImageDir: mkdir")
        } else {
            Log.e("TAG", "createImageDir:not exi ")
        }
    }


    fun unHideFile(selected:FileItem) {
//        val selected = getSelected()
//        for (i in selected.indices) {
            val file = File(selected.newPath)
            val targetLocation = File(selected.path)
            val file1 = File(targetLocation.parent)
            if (!file1.exists()) {
                file1.mkdirs()
            }
            if (file.renameTo(targetLocation)) {
                databaseHelper!!.deleteFileItem(selected)
            }
            Thread.sleep(1500)
//            progressDialog.setProgress(i+1)
//        }
        //if (actionMode != null) actionMode!!.finish()
//        isSelectedMode = false
//        imageListAdapter!!.isSelectedMode=isSelectedMode
//        enableActionMode(isSelectedMode)
//        countSelected = 0
//        initView()
    }

    private fun hideFile(path: String) {
        val file: File = File(path)
        val fileName = file.name
        val oriPath = file.absolutePath
        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(getExtension(fileName))

        val targetLocation = File(nohideFile + fileName + ".bin")
        if (file.renameTo(targetLocation)) {
            removeAllForPaths(file, mActivity)
            databaseHelper!!.insertFile(
                fileName,
                oriPath,
                targetLocation.absolutePath,
                file.length(),
                mimeType
            )
        }
        initViews()
    }

    private fun getVideoDuration(uriOfFile: String?): Long {
        val mp = MediaPlayer.create(this, Uri.parse(uriOfFile)) ?: return 0L
        val duration = mp.duration
        mp.release()
        return duration.toLong()
    }

    private fun removeAllForPaths(file: File, context: Context?) {
        val where = MediaStore.MediaColumns.DATA + "=?"
        val selectionArgs = arrayOf(
            file.absolutePath
        )
        val contentResolver = mActivity!!.contentResolver
        val filesUri = MediaStore.Files.getContentUri("external")
        contentResolver.delete(filesUri, where, selectionArgs)
        if (file.exists()) {
            contentResolver.delete(filesUri, where, selectionArgs)
        }
    }

    private fun addImageToGallery(context: Context, filePath: String, mimetype: String?) {
        val values = ContentValues()
        values.put(MediaStore.MediaColumns.DATE_TAKEN, System.currentTimeMillis())
        values.put(MediaStore.MediaColumns.MIME_TYPE, mimetype)
        values.put(MediaStore.MediaColumns.DATA, filePath)
        context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        MediaScannerConnection.scanFile(
            context, arrayOf(filePath), null
        ) { path, uri -> }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when (requestCode) {
            FilePickerConst.REQUEST_CODE_DOC -> if (resultCode == Activity.RESULT_OK && data != null) {
                val mSelected = data.getParcelableArrayListExtra<Uri>(FilePickerConst.KEY_SELECTED_DOCS)
                hideFileWithProgress(mSelected!!)

            }
        }
    }


    private fun getRealPathFromURI(contentURI: Uri): String? {
        val projection = arrayOf(MediaStore.Files.FileColumns.DATA)
        val cursor = managedQuery(contentURI, projection, null, null, null)
        val column_index = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)
        cursor.moveToFirst()
        return cursor.getString(column_index)
    }

    fun dialogUnhideFile(act: Activity) {

        val selected = getSelected()
        DialogHelper.alertDialog(
            act,
            getString(R.string.ask_unhide_file),
            getString(R.string.ask_sure_unhide_file),
            object : DialogHelper.DialogListener {
                override fun onPositiveClick() {

                    object : AsyncTask<Void, Int, Void>() {
                        var dialog: android.app.AlertDialog? = null
                        var progressBar: ProgressBar? = null

                        override fun onPreExecute() {
                            super.onPreExecute()

                            val alertDialogBuilder = android.app.AlertDialog.Builder(mActivity)
                            val inflater = mActivity!!.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
                            val view = inflater.inflate(R.layout.dialog_progress, null)
                            alertDialogBuilder.setView(view)
                            alertDialogBuilder.setCancelable(false)
                            dialog = alertDialogBuilder.create()
                            dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
                            dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                            progressBar = view.findViewById(R.id.progress_bar)
                            progressBar!!.max=selected.size

                            dialog!!.setOnDismissListener {
                            }
                            if (!dialog!!.isShowing) {
                                dialog!!.show()
                            }
                        }

                        override fun doInBackground(vararg voids: Void): Void? {
                            Handler(Looper.getMainLooper()).run {
//                                val selected = getSelected()
                                for (i in selected.indices) {
                                    unHideFile(selected[i])
                                    publishProgress((i+1).toInt())
                                }
                            }
                            return null
                        }


                        override fun onProgressUpdate(vararg values: Int?) {
                            super.onProgressUpdate(*values)
                            progressBar!!.progress=values[0]!!.toInt()
                        }

                        override fun onPostExecute(result: Void?) {
                            super.onPostExecute(result)
//                            progressDialog.dismiss()
                            dialog!!.dismiss()
                            isSelectedMode=false
                            imageListAdapter!!.isSelectedMode=isSelectedMode
                            enableActionMode(isSelectedMode)
                            countSelected = 0
                            initViews()
                        }
                    }.execute()
                }

                override fun onNegativeClick() {

                }
            })

    }

    fun hideFileWithProgress(mSelected: MutableList<Uri>) {

        object : AsyncTask<Void, Int, Void>() {

            var dialog: android.app.AlertDialog? = null
            var progressBar: ProgressBar? = null
            override fun onPreExecute() {
                super.onPreExecute()
                try {
                    val alertDialogBuilder = android.app.AlertDialog.Builder(mActivity)
                    val inflater = mActivity!!.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
                    val view = inflater.inflate(R.layout.dialog_progress, null)
                    alertDialogBuilder.setView(view)
                    alertDialogBuilder.setCancelable(false)
                    dialog = alertDialogBuilder.create()
                    dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
                    dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                    progressBar = view.findViewById(R.id.progress_bar)
                    mActivity!!.runOnUiThread{
                        progressBar!!.max=mSelected.size
                    }
                    Log.e("hideFileWithProgress", "mSelected.size:" + mSelected.size)
                    Log.e("hideFileWithProgress", "progressBar!!.max:" + progressBar!!.max)

                    dialog!!.setOnDismissListener {
                    }
                    if (!dialog!!.isShowing) {
                        dialog!!.show()
                    }
                } catch (e: Exception) {
                    Log.e("mmmmmgggggg", "55555:" + e)
                    e.printStackTrace()
                }
            }

            override fun doInBackground(vararg voids: Void): Void? {
                Handler(Looper.getMainLooper()).run {
                    if (mSelected.isNotEmpty() && mSelected.size > 0) {
                        for (i in mSelected.indices) {
//                            hideFileWithProgress(mSelected[i])
                            if (mSelected != null) {
                                mActivity!!.runOnUiThread {
                                    val original = ContentUriUtils.getFilePath(mActivity!!, mSelected[i])
                                    hideFile(original!!)
                                }
                            }
                            Log.e("hideFileWithProgress", "onProgressUpdate000" +i)
//                            progressBar!!.progress=(i+1)
                            Thread.sleep(1500)
                            publishProgress((i+1).toInt())
                        }
                    }
                }
                return null
            }
            override fun onProgressUpdate(vararg values: Int?) {
                super.onProgressUpdate(*values)
                mActivity!!.runOnUiThread {
                    progressBar!!.progress=values[0]!!
                }
            }
            override fun onPostExecute(result: Void?) {
                super.onPostExecute(result)
//                                progressDialog.dismiss()
                dialog!!.dismiss()
            }
        }.execute()

    }

    fun dialogDeletePhotoView(act: Activity) {

        val selected: ArrayList<FileItem> = getSelected()
        DialogHelper.alertDialog(
            act,
            "Delete Files?",
            "Delete the selected ${selected.size} files?",
            object : DialogHelper.DialogListener {
                override fun onPositiveClick() {
                    deletImage(selected, true)
                }

                override fun onNegativeClick() {

                }
            })
    }

    private fun deletImage(selected: ArrayList<FileItem>, isCheckedTrash: Boolean) {

        object : AsyncTask<Void, Int, Void>() {

            var dialog: android.app.AlertDialog? = null
            var progressBar: ProgressBar? = null
            override fun onPreExecute() {
                super.onPreExecute()
                try {
                    val alertDialogBuilder = android.app.AlertDialog.Builder(mActivity)
                    val inflater = mActivity!!.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
                    val view = inflater.inflate(R.layout.dialog_progress, null)
                    alertDialogBuilder.setView(view)
                    alertDialogBuilder.setCancelable(false)
                    dialog = alertDialogBuilder.create()
                    dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
                    dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                    progressBar = view.findViewById(R.id.progress_bar)
                    progressBar!!.max=selected.size

                    dialog!!.setOnDismissListener {
                    }
                    if (!dialog!!.isShowing) {
                        dialog!!.show()
                    }
                } catch (e: Exception) {
                    Log.e("mmmmmgggggg", "55555:" + e)
                    e.printStackTrace()
                }
            }

            override fun doInBackground(vararg voids: Void): Void? {
                Handler(Looper.getMainLooper()).run {

                    if (selected.isNotEmpty() && selected.size > 0) {

                        for (i in selected.indices) {
                            val file = File(selected[i].newPath)
                            val targetLocation = File(selected[i].path)
                            val file1 = File(targetLocation.parent)
                            if (!file1.exists()) {
                                file1.mkdirs()
                            }
                            databaseHelper!!.movewTrathFile(selected[i].id)
                            publishProgress((i+1).toInt())

                        }
                    }
                }
                return null
            }
            override fun onProgressUpdate(vararg values: Int?) {
                super.onProgressUpdate(*values)
                progressBar!!.progress=values[0]!!.toInt()
            }

            override fun onPostExecute(result: Void?) {
                super.onPostExecute(result)
                dialog!!.dismiss()
                initViews()
                deselectAll()
            }
        }.execute()

//        DeleteCloudFileTask(
//            this@HideFileActivity,
//            selected,
//            isCheckedTrash
//        ).execute()
    }

    private fun getSelected(): java.util.ArrayList<FileItem> {
        val selectedImages = java.util.ArrayList<FileItem>()
        var i = 0
        val l = imagesList.size
        while (i < l) {
            if (imagesList[i].isChecked) {
                selectedImages.add(imagesList[i])
            }
            i++
        }
        return selectedImages
    }

    //    private val photoPaths = java.util.ArrayList<Uri>()
    private fun choosePicture() {

        if (isOnline() && AdsManager(mActivity).isClickToShowAds()) {
            isShowInterstitialAd {
                FilePickerBuilder.instance
                    .setActivityTheme(R.style.FilePickerTheme)
                    .setActivityTitle("Document")
                    .setImageSizeLimit(5)
                    .setVideoSizeLimit(20)
                    .setMaxCount(10)
                    .addFileSupport("File", Constant.DocumentArray, R.drawable.ic_file)
                    .enableDocSupport(true)
                    .enableSelectAll(true)
                    .sortDocumentsBy(SortingTypes.NAME)
                    .withOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
                    .pickFile(this)

            }
        }
        else {

            FilePickerBuilder.instance
                .setMaxCount(10)
                .setActivityTheme(R.style.FilePickerTheme)
                .setActivityTitle("Please select doc")
                .setImageSizeLimit(5)
                .setVideoSizeLimit(20)
                .addFileSupport("File", Constant.DocumentArray, R.drawable.ic_file)
                .enableDocSupport(true)
                .enableSelectAll(true)
                .sortDocumentsBy(SortingTypes.NAME)
                .withOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
                .pickFile(this)

        }
    }

}