package calculatorlock.calculatorvault.hide.photo.video.db

import java.io.Serializable

open class BaseItem : Serializable {
    open var id = 0
    open var displayName: String? = null
    open var path: String? = null
    open var newPath: String? = null
    open var size: Long = 0
    var modified: Long = 0
    open var mimeType: String? = null
    var couldId: String? = null
    var isTrash //if 0 = no and 1 = yes
            = 0

    constructor() {}
    constructor(
        id: Int,
        displayName: String?,
        path: String?,
        size: Long,
        modified: Long,
        mimeType: String?
    ) {
        this.id = id
        this.displayName = displayName
        this.path = path
        this.size = size
        this.modified = modified
        this.mimeType = mimeType
    }

    @JvmOverloads
    constructor(id: Int, displayName: String?, path: String?, size: Long = 0, modified: Long = 0) {
    }
}