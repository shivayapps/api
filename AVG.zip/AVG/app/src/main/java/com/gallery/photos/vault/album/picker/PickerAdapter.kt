package com.gallery.photos.vault.album.picker

import android.app.Activity
import android.text.format.DateFormat
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.databinding.ItemHeaderBinding
import com.gallery.photos.vault.album.databinding.ItemPictureBinding
import com.gallery.photos.vault.album.extension.beVisible
import com.gallery.photos.vault.album.extension.getFilenameExtension
import com.gallery.photos.vault.album.extension.getFilenameFromPath
import com.gallery.photos.vault.album.extension.getParentFolder
import com.gallery.photos.vault.album.model.AlbumData
import com.gallery.photos.vault.album.model.PictureData
import com.gallery.photos.vault.album.utils.Constant
import com.gallery.photos.vault.album.utils.Preferences
import com.gallery.photos.vault.album.utils.TIME_FORMAT_12
import com.gallery.photos.vault.album.utils.TIME_FORMAT_24
import com.qtalk.recyclerviewfastscroller.RecyclerViewFastScroller
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class PickerAdapter(
    var context: Activity,
    var pictures: ArrayList<Any>,
    val clickListener: (pos: Int) -> Unit,
    val longClickListener: (pos: Int) -> Unit,
    val headerSelectListener: (pos: Int) -> Unit,
    var needShowMore: Boolean = false,
    var showMoreAfter: Int = 10
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

//    var needShowMore=false
//    var showMoreAfter=10

    fun setShowMore(showMore: Boolean, count: Int) {
        needShowMore = showMore
        showMoreAfter = count
        notifyDataSetChanged()
    }

    val ITEM_PHOTOS_TYPE = 2
    val ITEM_HEADER_TYPE = 1

    val format = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
    var preferences: Preferences = Preferences(context)

    override fun getItemViewType(position: Int): Int {
        return if (position >= 0 && position < pictures.size) {
            if (pictures[position] is AlbumData) {
                ITEM_HEADER_TYPE
            } else {
                ITEM_PHOTOS_TYPE
            }
        } else -1
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == ITEM_HEADER_TYPE) {
            val binding =
                ItemHeaderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            HeaderViewHolder(binding)
        } else {
            val binding =
                ItemPictureBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            PictureViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder
        if (position >= 0 && position < pictures.size)
            if (getItemViewType(position) == ITEM_HEADER_TYPE) {
                val headerViewHolder: HeaderViewHolder = holder as HeaderViewHolder

                val albumData = pictures[position] as AlbumData
//            headerViewHolder.itemView.tag=albumData.folderPath
//            holder.itemView.tag = holder

                var strDate: String = albumData.title
                val calendar = Calendar.getInstance()
                val today = format.format(calendar.timeInMillis)
                calendar.add(Calendar.DATE, -1)
                val yesterday = format.format(calendar.timeInMillis)

                if (albumData.title == today) strDate = context.getString(R.string.Today)
                else if (albumData.title == yesterday) strDate =
                    context.getString(R.string.Yesterday)

                if (preferences.getShowFileCount()) {
                    strDate += " (${albumData.pictureData.size})"
                }

                headerViewHolder.binding.txtHeader.text = strDate
                headerViewHolder.binding.btnSelect.beVisible()


                headerViewHolder.binding.btnSelect.setImageDrawable(
                    if (albumData.isSelected) ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_check_right
                    )
                    else ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_check_off
                    )
                )
                headerViewHolder.binding.btnSelect.setOnClickListener {
                    headerSelectListener(position)
                }

            } else {

                val pictureViewHolder = holder as PictureViewHolder
                val pictureData: PictureData = pictures[position] as PictureData

                Glide.with(context.application).load(pictureData.filePath)
                    .into(pictureViewHolder.binding.image)

                pictureViewHolder.binding.icVideo.visibility =
                    if (pictureData.isVideo) View.VISIBLE else View.GONE


                if (pictureData.isCheckboxVisible) {
                    pictureViewHolder.binding.icUnSelect.visibility = View.VISIBLE
                    pictureViewHolder.binding.icSelect.visibility =
                        if (pictureData.isSelected) View.VISIBLE else View.GONE
                    pictureViewHolder.binding.icFavourite.visibility = View.GONE
                } else {
                    pictureViewHolder.binding.icUnSelect.visibility = View.GONE
                    pictureViewHolder.binding.icSelect.visibility = View.GONE

                    pictureViewHolder.binding.icFavourite.visibility =
                        if (pictureData.isFavorite) View.VISIBLE else View.GONE
                }

                holder.binding.loutMain.setOnClickListener {
                    clickListener(position)
                }
                holder.binding.loutMain.setOnLongClickListener {
                    longClickListener(position)
                    true
                }
            }
    }

    override fun getItemCount(): Int {
        if (needShowMore && pictures.size > showMoreAfter) return showMoreAfter
        else return pictures.size
    }

    class HeaderViewHolder(var binding: ItemHeaderBinding) : RecyclerView.ViewHolder(binding.root)

    class PictureViewHolder(var binding: ItemPictureBinding) : RecyclerView.ViewHolder(binding.root)

}