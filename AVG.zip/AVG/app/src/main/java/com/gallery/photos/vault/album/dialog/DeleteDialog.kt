package com.gallery.photos.vault.album.dialog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.viewbinding.ViewBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.databinding.DialogDeleteBinding
import com.gallery.photos.vault.album.databinding.DialogDeleteDarkBinding

class DeleteDialog(
    var mContext: Context,
//    var msg: String,
    val btnClickListener: (isPermanent: Boolean) -> Unit,
    val useDarkMode:Boolean?=true
//    val positiveBtnClickListener: () -> Unit
) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: ViewBinding
//    lateinit var bindingDialog: DialogDeleteBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogDeleteBinding.inflate(layoutInflater, container, false)
        if(useDarkMode!!) bindingDialog = DialogDeleteDarkBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        bindingDialog.root.findViewById<TextView>(R.id.txtRestoredMsg).visibility = View.GONE
        bindingDialog.root.findViewById<TextView>(R.id.btnCancel).setOnClickListener { dismiss() }
        bindingDialog.root.findViewById<TextView>(R.id.btnDelete).setOnClickListener {
            dismiss()
            btnClickListener.invoke(false)
        }
        bindingDialog.root.findViewById<TextView>(R.id.btnPermanent).setOnClickListener {
            dismiss()
            btnClickListener.invoke(true)
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}