package com.backup.restore.device.image.contacts.recovery.mainduplicate.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.contacts.recovery.mainduplicate.adapter.IndividualOtherAdapter.OthersViewHolder
import com.gallery.photos.vault.album.mainduplicate.callbacks.MarkedListener
import com.gallery.photos.vault.album.mainduplicate.model.IndividualGroupModel
import com.gallery.photos.vault.album.mainduplicate.model.ItemDuplicateModel
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions
import com.gallery.photos.vault.album.mainduplicate.adapter.ListOthersAdapter
import java.util.*

class IndividualOtherAdapter(
    var individualOtherAdapterContext: Context,
    var otherMarkedListener: MarkedListener,
    var groupOfDupesOthers: List<IndividualGroupModel>) : RecyclerView.Adapter<OthersViewHolder>() {

    var mLayoutManager: LinearLayoutManager? = null

    class OthersViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var checkBox: CheckBox = itemView.findViewById<View>(R.id.cb_grp_checkbox) as CheckBox
        var recyclerView: RecyclerView = itemView.findViewById<View>(R.id.rv_documents) as RecyclerView
        var textView: TextView = itemView.findViewById(R.id.tv_grp_name)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OthersViewHolder {
        return OthersViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.adapter_media_others, parent, false))
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: OthersViewHolder, position: Int) {
        val individualGroup = groupOfDupesOthers[position]
        holder.textView.text = "Set " + individualGroup.groupTag
        holder.checkBox.isChecked = individualGroup.isCheckBox
        mLayoutManager = LinearLayoutManager(individualOtherAdapterContext)
        val listOthersAdapter = ListOthersAdapter(individualOtherAdapterContext, otherMarkedListener, groupOfDupesOthers[position], individualGroup.individualGrpOfDupes!!, holder.checkBox)
        holder.recyclerView.layoutManager = mLayoutManager
        holder.recyclerView.adapter = listOthersAdapter

        holder.checkBox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            buttonView.setOnClickListener {
                individualGroup.isCheckBox = isChecked
                val listOthersAdapter1 = ListOthersAdapter(individualOtherAdapterContext, otherMarkedListener, groupOfDupesOthers[position], setCheckBox(individualGroup.individualGrpOfDupes, isChecked), holder.checkBox)
                holder.recyclerView.adapter = listOthersAdapter1
                listOthersAdapter1.notifyDataSetChanged()
            }
        }
    }

    override fun getItemCount(): Int {
        return groupOfDupesOthers.size
    }

    private fun setCheckBox(otherItems: List<ItemDuplicateModel>?, value: Boolean): List<ItemDuplicateModel> {
        val lListOfDupes: MutableList<ItemDuplicateModel> = ArrayList()
        for (i in otherItems!!.indices) {
            val otherItem = otherItems[i]
            when {
                i != 0 -> {
                    if (!value) {
                        com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_others.remove(otherItem)
                        com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.subSizeOthers(otherItem.sizeOfTheFile)
                        otherMarkedListener.updateMarked()
                    } else if (!otherItem.isFileCheckBox) {
                        com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_others.add(otherItem)
                        com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.addSizeOthers(otherItem.sizeOfTheFile)
                        otherMarkedListener.updateMarked()
                    }
                    otherItem.isFileCheckBox = value
                    lListOfDupes.add(otherItem)
                }
                otherItem.isFileCheckBox -> {
                    com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_others.remove(otherItem)
                    otherItem.isFileCheckBox = false
                    lListOfDupes.add(otherItem)
                }
                else -> {
                    otherItem.isFileCheckBox = false
                    lListOfDupes.add(otherItem)
                }
            }
        }
        return lListOfDupes
    }
}