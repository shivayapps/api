package com.gallery.photos.vault.album.dialog

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import com.gallery.photos.vault.album.databinding.DialogSlideshowBinding
import com.gallery.photos.vault.album.helper.RadioItem
import com.gallery.photos.vault.album.utils.Constant
import com.gallery.photos.vault.album.utils.Preferences
//import com.gallery.photos.vault.album.utils.SLIDESHOW_ANIMATION_FADE

//import com.gallery.photos.vault.album.utils.SLIDESHOW_ANIMATION_SLIDE

class SlideshowDialog(val updateListener: () -> Unit) :
    DialogFragment() {

    lateinit var bindingDialog: DialogSlideshowBinding
    lateinit var preferences: Preferences
    var slideEffect = 0
    var slideTime = 1

    override fun onResume() {
        super.onResume()
        dialog!!.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)
        val window = dialog.window
        val attributes = window?.attributes
//        attributes?.gravity = Gravity.BOTTOM
        window?.attributes = attributes
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        return dialog
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogSlideshowBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        preferences = Preferences(requireActivity())
        slideEffect = preferences.getInt(Constant.PREF_SLIDE_EFFECT)
        slideTime = preferences.getInt(Constant.PREF_SLIDE_TIME, 1)

        intListener()

        bindingDialog.checkVideo.isChecked = preferences.getBoolean(Constant.PREF_SLIDE_INCLUDE_VIDEO)
        bindingDialog.checkGif.isChecked = preferences.getBoolean(Constant.PREF_SLIDE_INCLUDE_GIF)
        bindingDialog.checkRandom.isChecked = preferences.getBoolean(Constant.PREF_SLIDE_RANDOM_ORDER)
        bindingDialog.checkBackward.isChecked = preferences.getBoolean(Constant.PREF_SLIDE_BACKWARD)
        bindingDialog.checkLoop.isChecked = preferences.getBoolean(Constant.PREF_SLIDE_LOOP)
        bindingDialog.edtTime.text = "${slideTime}s"

        bindingDialog.tvEffect.text=Constant.AnimationTypes.entries[slideEffect].value


        bindingDialog.tvEffect.setOnClickListener {
//            bindingDialog.llEffect.visibility=View.VISIBLE

            val items: ArrayList<RadioItem> = ArrayList()

            for(effect in Constant.AnimationTypes.entries) {
                items.add(RadioItem(effect.id,effect.value))
            }

            val radioGroupDialog=RadioGroupDialog(items, slideEffect) {

                slideEffect=it
                preferences.setInt(Constant.PREF_SLIDE_EFFECT, slideEffect)
                bindingDialog.tvEffect.text=items[slideEffect].title
            }
            radioGroupDialog.show(parentFragmentManager, radioGroupDialog.tag)
        }


        bindingDialog.icMinus.setOnClickListener {
            if(slideTime>=1) {
                slideTime -= 1
                bindingDialog.edtTime.text = "${slideTime}s"
            }
        }
        bindingDialog.icPlus.setOnClickListener {
            slideTime += 1
            bindingDialog.edtTime.text = "${slideTime}s"
        }


    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOK.setOnClickListener {

            preferences.setBoolean(
                Constant.PREF_SLIDE_INCLUDE_VIDEO,
                bindingDialog.checkVideo.isChecked
            )
            preferences.setBoolean(
                Constant.PREF_SLIDE_INCLUDE_GIF,
                bindingDialog.checkGif.isChecked
            )
            preferences.setBoolean(
                Constant.PREF_SLIDE_RANDOM_ORDER,
                bindingDialog.checkRandom.isChecked
            )
            preferences.setBoolean(
                Constant.PREF_SLIDE_BACKWARD,
                bindingDialog.checkBackward.isChecked
            )
            preferences.setBoolean(Constant.PREF_SLIDE_LOOP, bindingDialog.checkLoop.isChecked)

            preferences.setInt(Constant.PREF_SLIDE_EFFECT, slideEffect)
            preferences.setInt(Constant.PREF_SLIDE_TIME, slideTime)

            dismiss()
            updateListener()
        }
    }

}