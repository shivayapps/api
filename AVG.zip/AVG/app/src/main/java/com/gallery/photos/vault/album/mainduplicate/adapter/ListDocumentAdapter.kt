package com.gallery.photos.vault.album.mainduplicate.adapter

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photos.vault.album.mainduplicate.callbacks.MarkedListener
import com.gallery.photos.vault.album.mainduplicate.model.IndividualGroupModel
import com.gallery.photos.vault.album.mainduplicate.model.ItemDuplicateModel
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions
import com.gallery.photos.vault.album.mainduplicate.utils.MyUtils
import com.gallery.photos.vault.album.mainduplicate.utils.PreviewDialog
import com.gallery.photos.vault.album.mainduplicate.utils.ShareConstants

class ListDocumentAdapter(
    var listDocumentAdapterContext: Context,
    var documentsMarkedListener: MarkedListener,
    var individualGroupDocuments: IndividualGroupModel,
    var document: List<ItemDuplicateModel>,
    var parentCheckbox: CheckBox
) : RecyclerView.Adapter<ListDocumentAdapter.DocumentViewHolder>() {

    var inflater: LayoutInflater = listDocumentAdapterContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    var totalNumberOfflineInSet = 0

    class DocumentViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var documentCheckbox: CheckBox = itemView.findViewById<View>(R.id.documentcheckbox) as CheckBox
        var documentFileName: TextView = itemView.findViewById(R.id.fileName)
        var documentFilePath: TextView = itemView.findViewById(R.id.filePath)
        var documentFileSize: TextView = itemView.findViewById(R.id.fileSize)
        var imageView: ImageView = itemView.findViewById(R.id.documentFile)
        var linearLayout: LinearLayout = itemView.findViewById(R.id.linear_documents_click)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DocumentViewHolder {
        return DocumentViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.row_list_of_document_files_item, parent, false)
        )
    }

    override fun onBindViewHolder(holder: DocumentViewHolder, position: Int) {
        val lDocumentItem = document[position]
        holder.documentFileName.text = com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.getFileName(lDocumentItem.filePath)
        holder.documentFileSize.text = com.gallery.photos.vault.album.mainduplicate.utils.ShareConstants.getReadableFileSize(lDocumentItem.sizeOfTheFile)
        holder.documentFilePath.text = lDocumentItem.filePath
        holder.documentCheckbox.isChecked = lDocumentItem.isFileCheckBox
        holder.imageView.setOnClickListener {
            if (SystemClock.elapsedRealtime() - com.gallery.photos.vault.album.mainduplicate.utils.ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            com.gallery.photos.vault.album.mainduplicate.utils.ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
//            val intent = Intent(listDocumentAdapterContext, PreviewDocumentDuplicateActivity::class.java)
//            val bundle = Bundle()
//            bundle.putSerializable("documentFile", lDocumentItem)
//            intent.putExtras(bundle)
//            intent.putExtra("totalNumberOfFiles", totalNumberOfflineInSet)
//            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
//            listDocumentAdapterContext.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(listDocumentAdapterContext, R.anim.slide_from_right, R.anim.slide_from_left).toBundle())

            PreviewDialog.showPreviewDialog(listDocumentAdapterContext, lDocumentItem)
        }
        holder.linearLayout.setOnClickListener {
            if (SystemClock.elapsedRealtime() - com.gallery.photos.vault.album.mainduplicate.utils.ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            com.gallery.photos.vault.album.mainduplicate.utils.ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
//            val intent = Intent(listDocumentAdapterContext, PreviewDocumentDuplicateActivity::class.java)
//            val bundle = Bundle()
//            bundle.putSerializable("documentFile", lDocumentItem)
//            intent.putExtras(bundle)
//            intent.putExtra("totalNumberOfFiles", totalNumberOfflineInSet)
//            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
//            listDocumentAdapterContext.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(listDocumentAdapterContext, R.anim.slide_from_right, R.anim.slide_from_left).toBundle())

            PreviewDialog.showPreviewDialog(listDocumentAdapterContext, lDocumentItem)
        }
        holder.documentCheckbox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            buttonView.setOnClickListener {
                lDocumentItem.isFileCheckBox = isChecked
                var selectCount = 0
                val numOffline = itemCount
                if (lDocumentItem.isFileCheckBox) {
                    for (i in 0 until itemCount) {
                        if (document[i].isFileCheckBox) {
                            selectCount++
                        }
                    }
                    if (selectCount != numOffline) {
                        com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_documents.add(lDocumentItem)
                        com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.addSizeDocuments(lDocumentItem.sizeOfTheFile)
                        documentsMarkedListener.updateMarked()
                        individualGroupDocuments.isCheckBox = true
                        parentCheckbox.isChecked = true
                    }
                } else {
                    com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_documents.remove(lDocumentItem)
                    com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.subSizeDocuments(lDocumentItem.sizeOfTheFile)
                    documentsMarkedListener.updateMarked()
                }
                if (selectCount < numOffline - 1) {
                    parentCheckbox.isChecked = false
                    individualGroupDocuments.isCheckBox = false
                } else {
                    parentCheckbox.isChecked = true
                    individualGroupDocuments.isCheckBox = true
                }
                if (numOffline == selectCount) {
                    com.gallery.photos.vault.album.mainduplicate.utils.MyUtils.showToastMsg(
                        listDocumentAdapterContext,
                        listDocumentAdapterContext.getString(R.string.error_not_select_all_document_in_same)
                    )
                    lDocumentItem.isFileCheckBox = false
                    holder.documentCheckbox.isChecked = false
                    return@setOnClickListener
                }
                lDocumentItem.isFileCheckBox = isChecked
            }
        }
    }

    override fun getItemCount(): Int {
        totalNumberOfflineInSet = document.size
        return totalNumberOfflineInSet
    }

}