package com.gallery.photos.vault.album.utils

import android.content.Context
import android.content.SharedPreferences
import android.os.Environment
import android.text.format.DateFormat
import android.util.Log
import androidx.core.content.ContextCompat
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.extension.getInternalStoragePath
import com.gallery.photos.vault.album.model.AlbumData
import com.gallery.photos.vault.album.model.PictureData
import com.gallery.photos.vault.album.utils.Constant.ASPECT_RATIO_FREE
import java.text.SimpleDateFormat
import java.util.LinkedList
import java.util.Locale


class Preferences(var context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("Gallery", Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = prefs.edit()

    fun saveObjectList(objectList: ArrayList<Any>) {
        Log.e("Preferences","saveObjectList.size:${objectList.size}")
        val editor: SharedPreferences.Editor = prefs.edit()
        val gson = Gson()
        val json = gson.toJson(objectList)

        Log.e("Preferences","saveObjectList.json:${json}")
        editor.putString("media_list", json)
        editor.apply()
    }
    fun getObjectList(): ArrayList<Any> {
        val gson = Gson()
        val json: String = prefs.getString("media_list", "")?:""
        Log.e("Preferences","getObjectList.json:${json}")
        val type: Type = object : TypeToken<ArrayList<Any>>() {}.type
        val objectList: ArrayList<Any> = gson.fromJson(json, type)
        Log.e("Preferences","getObjectList.size:${objectList.size}")
        return objectList
    }
    fun saveMediaList(objectList: ArrayList<PictureData>) {
        Log.e("Preferences","saveMediaList.size:${objectList.size}")
        val editor: SharedPreferences.Editor = prefs.edit()
        val gson = Gson()
        val json = gson.toJson(objectList)

//        Log.e("Preferences","saveObjectList.json:${json}")
        editor.putString("media_list", json)
        editor.apply()
    }
    fun getMediaList(): ArrayList<PictureData> {
        val gson = Gson()
        val json: String = prefs.getString("media_list", "")?:""
//        Log.e("Preferences","getObjectList.json:${json}")
        val type: Type = object : TypeToken<ArrayList<PictureData>>() {}.type
        val objectList: ArrayList<PictureData> = gson.fromJson(json, type)
        Log.e("Preferences","getMediaList.size:${objectList.size}")
        return objectList
    }
    fun saveAlbumList(objectList: ArrayList<AlbumData>) {
        Log.e("Preferences","saveAlbumList.size:${objectList.size}")
        val editor: SharedPreferences.Editor = prefs.edit()
        val gson = Gson()
        val json = gson.toJson(objectList)

//        Log.e("Preferences","saveObjectList.json:${json}")
        editor.putString("album_list", json)
        editor.apply()
    }
    fun getAlbumList(): ArrayList<AlbumData> {
        val gson = Gson()
        val json: String = prefs.getString("album_list", "")?:""
//        Log.e("Preferences","getObjectList.json:${json}")
        val type: Type = object : TypeToken<ArrayList<AlbumData>>() {}.type
        val objectList: ArrayList<AlbumData> = gson.fromJson(json, type)
        Log.e("Preferences","getAlbumList.size:${objectList.size}")
        return objectList
    }

    var isFirstTimeInstall: Boolean
        get() = prefs.getBoolean("isFirstTimeInstall", true)
        set(value) = prefs.edit().putBoolean("isFirstTimeInstall", value).apply()
    var isEnableAds: Boolean
        get() = prefs.getBoolean("isEnableAds", true)
        set(value) = prefs.edit().putBoolean("isEnableAds", value).apply()
    var isEnableOpenAds: Boolean
        get() = prefs.getBoolean("isEnableOpenAds", true)
        set(value) = prefs.edit().putBoolean("isEnableOpenAds", value).apply()
    var isRatingDone: Boolean
        get() = prefs.getBoolean("isRatingDone", false)
        set(allowVideoGestures) = prefs.edit().putBoolean("isRatingDone", allowVideoGestures).apply()
    var isNeedInterAd: Boolean
        get() = prefs.getBoolean("isNeedInterAd", true)
        set(allowVideoGestures) = prefs.edit().putBoolean("isNeedInterAd", allowVideoGestures).apply()

    var refreshMedia: Boolean
        get() = prefs.getBoolean("addedNewMedia", false)
        set(allowVideoGestures) = prefs.edit().putBoolean("addedNewMedia", allowVideoGestures).apply()
    var scanMedia: Boolean
        get() = prefs.getBoolean("scanMedia", false)
        set(allowVideoGestures) = prefs.edit().putBoolean("scanMedia", allowVideoGestures).apply()
    var deleteAfter30Days: Boolean
        get() = prefs.getBoolean("deleteAfter30Days", false)
        set(deleteAfter30Days) = prefs.edit().putBoolean("deleteAfter30Days", deleteAfter30Days).apply()

//    fun addFolderProtection(path: String) {
//        prefs.edit()
//            .putBoolean("isProtected$path", true)
//            .apply()
//    }
//    fun removeFolderProtection(path: String) {
//        prefs.edit()
//            .remove("isProtected$path")
//            .apply()
//    }

//    fun isFolderProtected(path: String) =prefs.getBoolean("isProtected$path", false)


    var allowDownGesture: Boolean
        get() = prefs.getBoolean("allow_down_gesture", true)
        set(allowDownGesture) = prefs.edit().putBoolean("allow_down_gesture", allowDownGesture).apply()

    var deleteEmptyFolders: Boolean
        get() = prefs.getBoolean("deleteEmptyFolders", true)
        set(deleteEmptyFolders) = prefs.edit().putBoolean("deleteEmptyFolders", deleteEmptyFolders).apply()

    var allowVideoGestures: Boolean
        get() = prefs.getBoolean("allow_video_gestures", true)
        set(allowVideoGestures) = prefs.edit().putBoolean("allow_video_gestures", allowVideoGestures).apply()

    var autoplayVideos: Boolean
        get() = prefs.getBoolean("autoplay_videos", false)
        set(autoplayVideos) = prefs.edit().putBoolean("autoplay_videos", autoplayVideos).apply()

    var lastEditorCropAspectRatio: Int
        get() = prefs.getInt("LAST_EDITOR_CROP_ASPECT_RATIO", ASPECT_RATIO_FREE)
        set(lastEditorCropAspectRatio) = prefs.edit().putInt("LAST_EDITOR_CROP_ASPECT_RATIO", lastEditorCropAspectRatio).apply()

    var lastEditorCropOtherAspectRatioX: Float
        get() = prefs.getFloat("LAST_EDITOR_CROP_OTHER_ASPECT_RATIO_X", 2f)
        set(lastEditorCropOtherAspectRatioX) = prefs.edit().putFloat("LAST_EDITOR_CROP_OTHER_ASPECT_RATIO_X", lastEditorCropOtherAspectRatioX).apply()

    var lastEditorCropOtherAspectRatioY: Float
        get() = prefs.getFloat("LAST_EDITOR_CROP_OTHER_ASPECT_RATIO_Y", 1f)
        set(lastEditorCropOtherAspectRatioY) = prefs.edit().putFloat("LAST_EDITOR_CROP_OTHER_ASPECT_RATIO_Y", lastEditorCropOtherAspectRatioY).apply()

    var lastEditorDrawColor: Int
        get() = prefs.getInt("LAST_EDITOR_DRAW_COLOR", ContextCompat.getColor(context, R.color.color_primary))
        set(lastEditorDrawColor) = prefs.edit().putInt("LAST_EDITOR_DRAW_COLOR", lastEditorDrawColor).apply()

    var lastEditorBrushSize: Int
        get() = prefs.getInt("LAST_EDITOR_BRUSH_SIZE", 50)
        set(lastEditorBrushSize) = prefs.edit().putInt("LAST_EDITOR_BRUSH_SIZE", lastEditorBrushSize).apply()

    // color picker last used colors
    var colorPickerRecentColors: LinkedList<Int>
        get(): LinkedList<Int> {
            val defaultList = arrayListOf(
                ContextCompat.getColor(context, R.color.color_picker_1),
                ContextCompat.getColor(context, R.color.color_picker_5),
                ContextCompat.getColor(context, R.color.color_picker_10),
                ContextCompat.getColor(context, R.color.color_picker_15),
                ContextCompat.getColor(context, R.color.color_picker_20)
            )
            return LinkedList(prefs.getString("COLOR_PICKER_RECENT_COLORS", null)?.lines()?.map { it.toInt() } ?: defaultList)
        }
        set(recentColors) = prefs.edit().putString("COLOR_PICKER_RECENT_COLORS", recentColors.joinToString(separator = "\n")).apply()

//    var openVideosOnSeparateScreen: Boolean
//        get() = prefs.getBoolean(Constant.OPEN_VIDEOS_ON_SEPARATE_SCREEN, false)
//        set(openVideosOnSeparateScreen) = prefs.edit().putBoolean(Constant.OPEN_VIDEOS_ON_SEPARATE_SCREEN, openVideosOnSeparateScreen).apply()

//    var bottomActions: Boolean
//        get() = prefs.getBoolean(Constant.BOTTOM_ACTIONS, true)
//        set(bottomActions) = prefs.edit().putBoolean(Constant.BOTTOM_ACTIONS, bottomActions).apply()

    var use24HourFormat: Boolean
        get() = prefs.getBoolean("USE_24_HOUR_FORMAT", DateFormat.is24HourFormat(context))
        set(use24HourFormat) = prefs.edit().putBoolean("USE_24_HOUR_FORMAT", use24HourFormat).apply()

    var dateFormat: String
        get() = prefs.getString("DATE_FORMAT", getDefaultDateFormat())!!
        set(dateFormat) = prefs.edit().putString("DATE_FORMAT", dateFormat).apply()

    private fun getDefaultDateFormat(): String {
        val format = DateFormat.getDateFormat(context)
        val pattern = (format as SimpleDateFormat).toLocalizedPattern()
        return when (pattern.lowercase().replace(" ", "")) {
            "d.M.y" -> DATE_FORMAT_ONE
            "dd/mm/y" -> DATE_FORMAT_TWO
            "mm/dd/y" -> DATE_FORMAT_THREE
            "y-mm-dd" -> DATE_FORMAT_FOUR
            "dmmmmy" -> DATE_FORMAT_FIVE
            "mmmmdy" -> DATE_FORMAT_SIX
            "mm-dd-y" -> DATE_FORMAT_SEVEN
            "dd-mm-y" -> DATE_FORMAT_EIGHT
            else -> DATE_FORMAT_ONE
        }
    }

    var enableFingerprint: Boolean
        get() = prefs.getBoolean("USE_FINGERPRINT", false)
        set(enableFingerprint) = prefs.edit().putBoolean("USE_FINGERPRINT", enableFingerprint).apply()
    var hideSystemUI: Boolean
        get() = prefs.getBoolean("HIDE_SYSTEM_UI", false)
        set(hideSystemUI) = prefs.edit().putBoolean("HIDE_SYSTEM_UI", hideSystemUI).apply()
//
//    var hideVault: Boolean
//        get() = prefs.getBoolean("VAULT_VISIBILITY", false)
//        set(hideVault) = prefs.edit().putBoolean("VAULT_VISIBILITY", hideVault).apply()
//    var hintExclude: Boolean
//        get() = prefs.getBoolean("hintExclude", false)
//        set(hideVault) = prefs.edit().putBoolean("hintExclude", hideVault).apply()
//    var hintRecycle: Boolean
//        get() = prefs.getBoolean("hintRecycle", false)
//        set(hideVault) = prefs.edit().putBoolean("hintRecycle", hideVault).apply()

    var maxBrightness: Boolean
        get() = prefs.getBoolean("MAX_BRIGHTNESS", false)
        set(maxBrightness) = prefs.edit().putBoolean("MAX_BRIGHTNESS", maxBrightness).apply()

    var keepLastModified: Boolean
        get() = prefs.getBoolean("KEEP_LAST_MODIFIED", true)
        set(keepLastModified) = prefs.edit().putBoolean("KEEP_LAST_MODIFIED", keepLastModified).apply()

    var passwordRetryCount: Int
        get() = prefs.getInt("PASSWORD_RETRY_COUNT", 0)
        set(passwordRetryCount) = prefs.edit().putInt("PASSWORD_RETRY_COUNT", passwordRetryCount).apply()


    var passwordCountdownStartMs: Long
        get() = prefs.getLong("PASSWORD_COUNTDOWN_START_MS", 0L)
        set(passwordCountdownStartMs) = prefs.edit().putLong("PASSWORD_COUNTDOWN_START_MS", passwordCountdownStartMs).apply()

    fun removeLastVideoPosition(path: String) {
        prefs.edit().remove("${Constant.LAST_VIDEO_POSITION_PREFIX}${path.lowercase(Locale.getDefault())}").apply()
    }

    fun saveLastVideoPosition(path: String, value: Int) {
        if (path.isNotEmpty()) {
            prefs.edit().putInt("${Constant.LAST_VIDEO_POSITION_PREFIX}${path.lowercase(Locale.getDefault())}", value).apply()
        }
    }

    fun getLastVideoPosition(path: String) = prefs.getInt("${Constant.LAST_VIDEO_POSITION_PREFIX}${path.lowercase(
        Locale.getDefault())}", 0)

    fun getAllLastVideoPositions() = prefs.all.filterKeys {
        it.startsWith(Constant.LAST_VIDEO_POSITION_PREFIX)
    }

    var loopVideos: Boolean
        get() = prefs.getBoolean("loop_videos", false)
        set(loop) = prefs.edit().putBoolean("loop_videos", loop).apply()

    var rememberLastVideoPosition: Boolean
        get() = prefs.getBoolean("remember_last_video_position", false)
        set(rememberLastVideoPosition) {
            if (!rememberLastVideoPosition) {
                getAllLastVideoPositions().forEach {
                    prefs.edit().remove(it.key).apply()
                }
            }
            prefs.edit().putBoolean("remember_last_video_position", rememberLastVideoPosition).apply()
        }

    var showNotch: Boolean
        get() = prefs.getBoolean("show_notch", true)
        set(showNotch) = prefs.edit().putBoolean("show_notch", showNotch).apply()

    var screenRotation: Int
        get() = prefs.getInt("screen_rotation", Constant.ROTATE_BY_SYSTEM_SETTING)
        set(screenRotation) = prefs.edit().putInt("screen_rotation", screenRotation).apply()
    var saveEditAction: Int
        get() = prefs.getInt("saveEditAction", Constant.SAVE_AS_COPY)
        set(value) = prefs.edit().putInt("saveEditAction", value).apply()

//    var hintEditShown: Boolean
//        get() = prefs.getBoolean("hintEditShown", false)
//        set(value) = prefs.edit().putBoolean("hintEditShown", value).apply()
    var isConfirmEditAction: Boolean
        get() = prefs.getBoolean("isConfirmEditAction", false)
        set(value) = prefs.edit().putBoolean("isConfirmEditAction", value).apply()

    var blackBackground: Boolean
        get() = prefs.getBoolean("dark_background", true)
        set(blackBackground) = prefs.edit().putBoolean("dark_background", blackBackground).apply()

    var showExtendedDetails: Boolean
        get() = prefs.getBoolean("show_extended_details", false)
        set(showExtendedDetails) = prefs.edit().putBoolean("show_extended_details", showExtendedDetails).apply()

    var hideExtendedDetails: Boolean
        get() = prefs.getBoolean("hide_extended_details", false)
        set(hideExtendedDetails) = prefs.edit().putBoolean("hide_extended_details", hideExtendedDetails).apply()

    var extendedDetails: Int
        get() = prefs.getInt("extended_details", Constant.EXT_RESOLUTION or Constant.EXT_LAST_MODIFIED or Constant.EXT_EXIF_PROPERTIES)
        set(extendedDetails) = prefs.edit().putInt("extended_details", extendedDetails).apply()

    var showHighestQuality: Boolean
        get() = prefs.getBoolean("show_highest_quality", false)
        set(showHighestQuality) = prefs.edit().putBoolean("show_highest_quality", showHighestQuality).apply()

    var allowPhotoGestures: Boolean
        get() = prefs.getBoolean("allow_photo_gestures", false)
        set(allowPhotoGestures) = prefs.edit().putBoolean("allow_photo_gestures", allowPhotoGestures).apply()

    var allowZoomingImages: Boolean
        get() = prefs.getBoolean("allow_zooming_images", true)
        set(allowZoomingImages) = prefs.edit().putBoolean("allow_zooming_images", allowZoomingImages).apply()

    var allowInstantChange: Boolean
        get() = prefs.getBoolean("allow_instant_change", false)
        set(allowInstantChange) = prefs.edit().putBoolean("allow_instant_change", allowInstantChange).apply()

    var allowOneToOneZoom: Boolean
        get() = prefs.getBoolean("allow_one_to_one_zoom", false)
        set(allowOneToOneZoom) = prefs.edit().putBoolean("allow_one_to_one_zoom", allowOneToOneZoom).apply()

    var allowRotatingWithGestures: Boolean
        get() = prefs.getBoolean("allow_rotating_with_gestures", true)
        set(allowRotatingWithGestures) = prefs.edit().putBoolean("allow_rotating_with_gestures", allowRotatingWithGestures).apply()
    var isSetLanguage: Boolean
        get() = prefs.getBoolean("isSetLanguage", false)
        set(isSetLanguage) = prefs.edit().putBoolean("isSetLanguage", isSetLanguage).apply()

    fun getCoverImage(album: String):String {
        return prefs.getString("AlbumCover$album", "")?:""
    }
    fun setCoverImage(album: String,path: String)  {
        editor.putString("AlbumCover$album",path)
        editor.apply()
    }

    var appOpenCounter: Int
        get() = prefs.getInt("appOpenCounter", 0)
        set(appOpenCounter) = prefs.edit().putInt("appOpenCounter", appOpenCounter).apply()

    var splashCounter: Int
        get() = prefs.getInt("splashCounter", 0)
        set(splashCounter) = prefs.edit().putInt("splashCounter", splashCounter).apply()

    fun putTheme(themeValue: Int) {
        editor.putInt("key_theme", themeValue)
        editor.apply()
    }

    fun getThemeValue(): Int {
        return prefs.getInt("key_theme", Constant.THEME_LIGHT)
    }

    fun setSelectLanguage(result: Int) {
        editor.putInt("language", result)
        editor.apply()
    }

    fun getSelectLanguage(): Int {
        return prefs.getInt("language", 0)
    }

//    fun setAlbumSortType(result: Int) {
//        editor.putInt("folder_sort_type", result)
//        editor.apply()
//    }

//    fun getAlbumSortType(): Int {
//        return prefs.getInt("folder_sort_type", Constant.SORT_LAST_MODIFIED)
//    }

    fun setSortType(result: Int) {
        editor.putInt("sort_type", result)
        editor.apply()
    }

    fun getSortType(): Int {
        return prefs.getInt("sort_type", Constant.SORT_LAST_MODIFIED)
    }

    fun setFilterMedia(result: Int) {
        editor.putInt("filter_media", result)
        editor.apply()
    }

    fun getFilterMedia(): Int {
        return prefs.getInt("filter_media", getDefaultFileFilter())
    }

    fun setGroupBy(result: Int) {
        editor.putInt("group_by", result)
        editor.apply()
    }
    fun getGroupBy(): Int {
        return prefs.getInt("group_by", Constant.GROUP_BY_LAST_MODIFIED_DAILY)
    }

    fun setGroupOrderBy(result: Int) {
        editor.putInt("group_order_by", result)
        editor.apply()
    }
    fun getGroupOrderBy(): Int {
        return prefs.getInt("group_order_by", Constant.GROUP_BY_NONE)
    }

//    fun setAlbumSortOrder(result: Int) {
//        editor.putInt("prefs_folder_sort_order", result)
//        editor.apply()
//    }

//    fun getAlbumSortOrder(): Int {
//        return prefs.getInt("prefs_folder_sort_order", Constant.SORT_LAST_MODIFIED)
//    }

    fun setInt(key:String,result: Int) {
        editor.putInt(key, result)
        editor.apply()
    }

    fun getInt(key:String,default:Int?=0): Int {
        return prefs.getInt(key, default!!)
    }
    fun setString(key:String,result: String) {
        editor.putString(key, result)
        editor.apply()
    }

    fun getString(key:String,default:String?=""): String {
        return prefs.getString(key, default!!)?:""
    }

    fun setBoolean(key:String,result: Boolean) {
        editor.putBoolean(key, result)
        editor.apply()
    }

    fun getBoolean(key:String,default: Boolean?=false): Boolean {
        return prefs.getBoolean(key, default!!)
    }

    fun setSortOrder(result: Int) {
        editor.putInt("sort_order", result)
        editor.apply()
    }

    fun getSortOrder(): Int {
        return prefs.getInt("sort_order", Constant.ORDER_DESCENDING)
    }

    fun setGridCount(result: Int) {
        editor.putInt("grid_count", result)
        editor.apply()
    }

    fun getGridCount(): Int {
        return prefs.getInt("grid_count", 3)
    }


    fun putShowGrid(result: Boolean) {
        editor.putBoolean("is_grid", result)
        editor.apply()
    }

    fun getShowGrid(): Boolean {
        return prefs.getBoolean("is_grid", true)
    }
    fun putShowFileCount(result: Boolean) {
        editor.putBoolean("show_file_count", result)
        editor.apply()
    }

    fun getShowFileCount(): Boolean {
        return prefs.getBoolean("show_file_count", false)
    }

    fun putShowPinLock(result: Boolean) {
        editor.putBoolean("lock_style", result)
        editor.apply()
    }

    fun getShowPINLock(): Boolean {
        return prefs.getBoolean("lock_style", true)
    }

    fun putSetPass(result: Boolean) {
        editor.putBoolean("passcode_set", result)
        editor.apply()
    }

    fun getSetPass(): Boolean {
        return prefs.getBoolean("passcode_set", false)
    }

    fun putPass(result: String) {
        editor.putString("passcode", result)
        editor.apply()
    }

    fun getPass(): String? {
        return prefs.getString("passcode", "")
    }

    fun putSetPattern(result: Boolean) {
        editor.putBoolean("pattern_set", result)
        editor.apply()
    }

    fun getSetPattern(): Boolean {
        return prefs.getBoolean("pattern_set", false)
    }

    fun putPattern(result: String) {
        editor.putString("pattern", result)
        editor.apply()
    }

    fun getPattern(): String? {
        return prefs.getString("pattern", "")
    }

    fun putSetQuestion(result: Boolean) {
        editor.putBoolean("security_set", result)
        editor.apply()
    }

    fun getSetQuestion(): Boolean {
        return prefs.getBoolean("security_set", false)
    }
    fun putIgnoreQuestion(result: Boolean) {
        editor.putBoolean("ignore_security_question", result)
        editor.apply()
    }
    fun getIgnoreQuestion(): Boolean {
        return prefs.getBoolean("ignore_security_question", false)
    }

//    var securityEmail: String
//        get() = prefs.getString(Constant.PREF_SECURITY_EMAIL, "")?:""
//        set(securityEmail) = prefs.edit().putString(Constant.PREF_SECURITY_EMAIL, securityEmail).apply()
//    fun putSecurityEmail(result: String) {
//        editor.putString(Constant.PREF_SECURITY_EMAIL, result)
//        editor.apply()
//    }
//    fun getSecurityEmail(): String {
//        return prefs.getString(Constant.PREF_SECURITY_EMAIL, "")?:""
//    }
    fun putSecurityQuestion(result: Int) {
        editor.putInt("security_question", result)
        editor.apply()
    }

    fun getSecurityQuestion(): Int {
        return prefs.getInt("security_question", 0)
    }


    fun putAnswerQuestion(result: String) {
        editor.putString("security_ans", result)
        editor.apply()
    }

    fun getAnswerQuestion(): String? {
        return prefs.getString("security_ans", "")
    }

    fun putVeriCode(result: String,time:Long) {
        editor.putString("security_otp", result)
        editor.putLong("security_otp_time", time)
        editor.apply()
    }

    fun getVeriCode(): String {
        return prefs.getString("security_otp", "")?:""
    }
    fun getOtpTimeOut(): Long {
        return prefs.getLong("security_otp_time", 0)?:0
    }

    var shouldShowHidden = showHiddenMedia || temporarilyShowHidden

    var showHiddenMedia: Boolean
        get() = prefs.getBoolean("SHOW_HIDDEN_MEDIA", false)
        set(showHiddenFolders) = prefs.edit().putBoolean("SHOW_HIDDEN_MEDIA", showHiddenFolders).apply()

    var temporarilyShowHidden: Boolean
        get() = prefs.getBoolean("TEMPORARILY_SHOW_HIDDEN", false)
        set(temporarilyShowHidden) = prefs.edit().putBoolean("TEMPORARILY_SHOW_HIDDEN", temporarilyShowHidden).apply()

    var temporarilyShowExcluded: Boolean
        get() = prefs.getBoolean("TEMPORARILY_SHOW_EXCLUDED", false)
        set(temporarilyShowExcluded) = prefs.edit().putBoolean("TEMPORARILY_SHOW_EXCLUDED", temporarilyShowExcluded).apply()

    // if a user hides a folder, then enables temporary hidden folder displaying, make sure we show it properly
    var everShownFolders: Set<String>
        get() = prefs.getStringSet("EVER_SHOWN_FOLDERS", getEverShownFolders())!!
        set(everShownFolders) = prefs.edit().putStringSet("EVER_SHOWN_FOLDERS", everShownFolders).apply()

    var internalStoragePath: String
        get() = prefs.getString("INTERNAL_STORAGE_PATH", getDefaultInternalPath())!!
        set(internalStoragePath) = prefs.edit().putString("INTERNAL_STORAGE_PATH", internalStoragePath).apply()

    private fun getDefaultInternalPath() = if (prefs.contains("INTERNAL_STORAGE_PATH")) "" else context.getInternalStoragePath()

    private fun getEverShownFolders() = hashSetOf(
        internalStoragePath,
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).absolutePath,
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath,
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath,
        "${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath}/Screenshots",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Images",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Images/Sent",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Video",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Video/Sent",
        "$internalStoragePath/WhatsApp/Media/.Statuses",
        "$internalStoragePath/Android/media/com.whatsapp/WhatsApp/Media",
        "$internalStoragePath/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images",
        "$internalStoragePath/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Video"
    )

    fun getIncludeList(): ArrayList<String> {
        val list: ArrayList<String> = ArrayList()
        val response: String =
            prefs.getString("included_list", "") ?: ""
        if (!response.isNullOrEmpty()) {
            val delimiter = "(,/^)"
            val stringArray = response.split(delimiter)
            if (!stringArray.isNullOrEmpty())
                list.addAll(stringArray)
        }
        return list
    }

    fun setIncludeList(list: ArrayList<String>) {
        val delimiter = "(,/^)"
        val resultString = if (list.isEmpty())
            "" else
            list.joinToString(delimiter)
        Log.e("TAGPREF", "SETResultString $resultString")
        val editor: SharedPreferences.Editor = prefs.edit()
        editor.putString("included_list", resultString)
        editor.apply()
    }

    fun getExcludeList(): ArrayList<String> {
        val list: ArrayList<String> = ArrayList()
        val response: String =
            prefs.getString("excluded_list", "") ?: ""
        if (!response.isNullOrEmpty()) {
            val delimiter = "(,/^)"
            val stringArray = response.split(delimiter)
            if (!stringArray.isNullOrEmpty())
                list.addAll(stringArray)
        }
        return list
    }

    fun setExcludeList(list: ArrayList<String>) {
        val delimiter = "(,/^)"
        val resultString = if (list.isEmpty())
            "" else
            list.joinToString(delimiter)
        Log.e("TAGPREF", "SETResultString $resultString")
        val editor: SharedPreferences.Editor = prefs.edit()
        editor.putString("excluded_list", resultString)
        editor.apply()
    }

    fun getFavoriteList(): ArrayList<String> {
        val list: ArrayList<String> = ArrayList()
//        try {
//            val response: String =
//                sharedPreferences.getString("Favorite_list", "")!!
//            if (response.isNotEmpty()) {
//                val gson = Gson()
//                val typeToken: TypeToken<List<String>> = object : TypeToken<List<String>>() {}
//
////                val type = object : TypeToken<List<String>>() {}.type
//                val type = typeToken.type
//                list = gson.fromJson(response, type)
//            }
//        } catch (e: Exception) {
//            Log.e("printStackTrace","printStackTrace:$e")
//        }
        val response: String =
            prefs.getString("Favorite_list", "") ?: ""
        if (!response.isNullOrEmpty()) {
            val delimiter = "(,/^)"
            val stringArray = response.split(delimiter)
            if (!stringArray.isNullOrEmpty())
                list.addAll(stringArray)
        }
        return list
    }

    fun setFavoriteList(list: ArrayList<String>) {

        val delimiter = "(,/^)"
        val resultString = if (list.isEmpty())
            "" else
            list.joinToString(delimiter)
        Log.e("TAGPREF", "SETResultString $resultString")
        val editor: SharedPreferences.Editor = prefs.edit()
        editor.putString("Favorite_list", resultString)
        editor.apply()
    }

    fun getPinAlbumList(): ArrayList<String> {
        val list: ArrayList<String> = ArrayList()
        val response: String =
            prefs.getString("pin_top_list", "") ?: ""
        if (!response.isNullOrEmpty()) {
            val delimiter = "(,/^)"
            val stringArray = response.split(delimiter)
            if (!stringArray.isNullOrEmpty())
                list.addAll(stringArray)
        }
        return list
    }

    fun setPinAlbumList(list: ArrayList<String>) {
        val delimiter = "(,/^)"
        val resultString = if (list.isEmpty())
            "" else
            list.joinToString(delimiter)
        Log.e("TAGPREF", "SETResultString $resultString")
        val editor: SharedPreferences.Editor = prefs.edit()
        editor.putString("pin_top_list", resultString)
        editor.apply()
    }


}