package com.gallery.photos.vault.album.notes.adapter

import android.graphics.BitmapFactory
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photos.vault.album.notes.entities.Notes
import com.gallery.photos.vault.album.databinding.ItemRvNotesBinding


class NotesAdapter() : RecyclerView.Adapter<NotesAdapter.NotesViewHolder>() {

    var arrList = ArrayList<Notes>()
    var listener : onItemClickListener? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotesViewHolder {
        val binding =
            ItemRvNotesBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NotesViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NotesViewHolder, position: Int) {

        holder.binding.tvTitle.text = arrList[position].title
        holder.binding.tvDesc.text = arrList[position].noteText
        holder.binding.tvDateTime.text = arrList[position].dateTime


        if (arrList[position].color != null) {
            holder.binding.cardView.setCardBackgroundColor(Color.parseColor(arrList[position].color))
        } else {
            null
        }

        val imgPath=arrList[position].imgPath.trim()

        if (imgPath.isNotEmpty()) {
            Log.e("aaaaa","path:${arrList[position].imgPath}")
            holder.binding.imgNote.setImageBitmap(BitmapFactory.decodeFile(arrList[position].imgPath))
            holder.binding.imgNote.visibility = View.VISIBLE
        } else {
            Log.e("aaaaa","path:----")
            holder.binding.imgNote.visibility = View.GONE
        }

        if (arrList[position].webLink.isNotEmpty()) {
            holder.binding.tvWebLink.text = arrList[position].webLink
            holder.binding.tvWebLink.visibility = View.VISIBLE
        } else {
            holder.binding.tvWebLink.visibility = View.GONE
        }

        holder.binding.cardView.setOnClickListener {
            listener!!.onClicked(arrList[position].id!!)
        }

    }

    override fun getItemCount(): Int {
        return arrList.size
    }



    fun setData(arrNotesList: List<Notes>) {
        arrList = arrNotesList as ArrayList<Notes>
    }

    fun setOnClickListener(listener1 : onItemClickListener) {
        listener = listener1
    }

    inner class NotesViewHolder(var binding: ItemRvNotesBinding) : RecyclerView.ViewHolder(binding.root) {}

//    inner class NotesViewHolder(view: View) : RecyclerView.ViewHolder(view)


    interface onItemClickListener {
        fun onClicked(notesId : Int)
    }

}