package com.gallery.photos.vault.album.interfaces;

public interface OnImageScanListener {
    void onImageScan(int value);
    void onScanCompleted();
}