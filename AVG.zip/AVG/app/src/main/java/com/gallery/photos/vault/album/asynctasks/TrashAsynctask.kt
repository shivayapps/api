package com.gallery.photos.vault.album.asynctasks

import android.content.Context
import android.os.AsyncTask
import com.gallery.photos.vault.album.helper.MediaFetcher
import com.gallery.photos.vault.album.model.PictureData
import com.gallery.photos.vault.album.utils.Constant
import com.gallery.photos.vault.album.utils.Preferences
import com.gallery.photos.vault.album.utils.SHOW_ALL


class TrashAsynctask(
    val context: Context,
    val callback: (isComplete: Boolean) -> Unit
) :
    AsyncTask<Void, Void, Boolean>() {

    val config = Preferences(context)

    override fun doInBackground(vararg params: Void): Boolean {


        return true
    }

    override fun onPostExecute(isComplete: Boolean) {
        super.onPostExecute(isComplete)
        callback(isComplete)
    }

    fun stopFetching() {
        cancel(true)
    }
}
