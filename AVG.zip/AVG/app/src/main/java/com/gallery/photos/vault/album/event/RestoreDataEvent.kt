package com.gallery.photos.vault.album.event

import com.gallery.photos.vault.album.model.RestoreData
import java.util.ArrayList

data class RestoreDataEvent(var restoreList: ArrayList<RestoreData>)
