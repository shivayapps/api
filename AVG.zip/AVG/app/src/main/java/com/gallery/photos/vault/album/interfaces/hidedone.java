package com.gallery.photos.vault.album.interfaces;

public interface hidedone {
        void hideComplete();
    }