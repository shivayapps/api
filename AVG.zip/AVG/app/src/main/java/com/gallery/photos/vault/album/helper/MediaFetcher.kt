package com.gallery.photos.vault.album.helper

import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.os.Bundle
import android.os.Environment
import android.os.Environment.isExternalStorageManager
import android.provider.BaseColumns
import android.provider.MediaStore
import com.gallery.photos.vault.album.extension.getDistinctPath
import com.gallery.photos.vault.album.extension.getDoesFilePathExist
import com.gallery.photos.vault.album.extension.getDuration
import com.gallery.photos.vault.album.extension.getFilenameFromPath
import com.gallery.photos.vault.album.extension.getIntValue
import com.gallery.photos.vault.album.extension.getLongValue
import com.gallery.photos.vault.album.extension.getNoMediaFoldersSync
import com.gallery.photos.vault.album.extension.getParentPath
import com.gallery.photos.vault.album.extension.getStringValue
import com.gallery.photos.vault.album.extension.isGif
import com.gallery.photos.vault.album.extension.isImageFast
import com.gallery.photos.vault.album.extension.isRawFast
import com.gallery.photos.vault.album.extension.isSvg
import com.gallery.photos.vault.album.extension.isVideoFast
import com.gallery.photos.vault.album.extension.normalizeString
import com.gallery.photos.vault.album.extension.queryCursor
import com.gallery.photos.vault.album.extension.shouldFolderBeVisible
import com.gallery.photos.vault.album.extension.showErrorToast
import com.gallery.photos.vault.album.model.AlbumData
import com.gallery.photos.vault.album.model.PictureData
import com.gallery.photos.vault.album.utils.Constant
import com.gallery.photos.vault.album.utils.Constant.GROUP_BY_DATE_TAKEN_DAILY
import com.gallery.photos.vault.album.utils.Constant.GROUP_BY_DATE_TAKEN_MONTHLY
import com.gallery.photos.vault.album.utils.Constant.GROUP_BY_LAST_MODIFIED_DAILY
import com.gallery.photos.vault.album.utils.Constant.GROUP_BY_LAST_MODIFIED_MONTHLY
import com.gallery.photos.vault.album.utils.Constant.GROUP_BY_NONE
import com.gallery.photos.vault.album.utils.Constant.ORDER_DESCENDING
import com.gallery.photos.vault.album.utils.NOMEDIA
import com.gallery.photos.vault.album.utils.Preferences
import com.gallery.photos.vault.album.utils.SHOW_ALL
import com.gallery.photos.vault.album.utils.TYPE_GIFS
import com.gallery.photos.vault.album.utils.TYPE_IMAGES
//import com.gallery.photos.vault.album.utils.TYPE_PORTRAITS
//import com.gallery.photos.vault.album.utils.TYPE_RAWS
//import com.gallery.photos.vault.album.utils.TYPE_SVGS
import com.gallery.photos.vault.album.utils.TYPE_VIDEOS
import com.gallery.photos.vault.album.utils.isRPlus
import com.gallery.photos.vault.album.utils.photoExtensions
import com.gallery.photos.vault.album.utils.rawExtensions
import com.gallery.photos.vault.album.utils.videoExtensions
import java.io.File
import java.util.Locale

class MediaFetcher(val context: Context) {

    var shouldStop = false
    val config = Preferences(context)

    fun getFoldersToScan(): ArrayList<String> {
        return try {
//            val OTGPath = context.config.OTGPath
            val folders = getLatestFileFolders()
            folders.addAll(arrayListOf(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
                    .toString(),
                "${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)}/Camera",
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                    .toString()
            ).filter { context.getDoesFilePathExist(it) })

            val filterMedia = config.getFilterMedia()
            val uri = MediaStore.Files.getContentUri("external")
            val projection = arrayOf(MediaStore.Images.Media.DATA)
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()
            val cursor =
                context.contentResolver.query(uri, projection, selection, selectionArgs, null)
            folders.addAll(parseCursor(cursor!!))

//            val config = context.config
            val shouldShowHidden = config.shouldShowHidden
            val excludedPaths = arrayListOf("")
            val includedPaths = arrayListOf("")
//            val excludedPaths = if (config.temporarilyShowExcluded) {
//                ArrayList()
//            } else {
//                config.getExcludeList()
//            }

//            val includedPaths = config.getIncludeList()


            val folderNoMediaStatuses = HashMap<String, Boolean>()
            val distinctPathsMap = HashMap<String, String>()
            val distinctPaths = folders.distinctBy {
                when {
                    distinctPathsMap.containsKey(it) -> distinctPathsMap[it]
                    else -> {
                        val distinct = it.getDistinctPath()
                        distinctPathsMap[it.getParentPath()] = distinct.getParentPath()
                        distinct
                    }
                }
            }

            val noMediaFolders = context.getNoMediaFoldersSync()
            noMediaFolders.forEach { folder ->
                folderNoMediaStatuses["$folder/$NOMEDIA"] = true
            }

            distinctPaths.filter {
                it.shouldFolderBeVisible(
                    excludedPaths,
                    includedPaths,
                    shouldShowHidden,
                    folderNoMediaStatuses
                ) { path, hasNoMedia ->
                    folderNoMediaStatuses[path] = hasNoMedia
                }
            }.toMutableList() as ArrayList<String>
        } catch (e: Exception) {
            ArrayList()
        }
    }


    private fun parseCursor(cursor: Cursor): LinkedHashSet<String> {
        val foldersToIgnore = arrayListOf("/storage/emulated/legacy")
        //val config = context.config
//        val includedFolders = config.getIncludeList()
        val includedFolders = arrayListOf("")
//        val OTGPath = config.OTGPath

//        val foldersToScan = config.everShownFolders.filter { it == FAVORITES || it == RECYCLE_BIN || context.getDoesFilePathExist(it, OTGPath) }.toHashSet()
        val foldersToScan =
            config.everShownFolders.filter { context.getDoesFilePathExist(it) }.toHashSet()

        cursor.use {
            if (cursor.moveToFirst()) {
                do {
                    val path = cursor.getStringValue(MediaStore.Images.Media.DATA)
                    val parentPath = File(path).parent ?: continue
                    if (!includedFolders.contains(parentPath) && !foldersToIgnore.contains(
                            parentPath
                        )
                    ) {
                        foldersToScan.add(parentPath)
                    }
                } while (cursor.moveToNext())
            }
        }

        includedFolders.forEach {
            addFolder(foldersToScan, it)
        }

        return foldersToScan.toMutableSet() as LinkedHashSet<String>
    }

    private fun addFolder(curFolders: HashSet<String>, folder: String) {
        curFolders.add(folder)
        val files = File(folder).listFiles() ?: return
        for (file in files) {
            if (file.isDirectory) {
                addFolder(curFolders, file.absolutePath)
            }
        }
    }

    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            }
//        }

//        if (filterMedia and TYPE_SVGS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }


        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }


        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                args.add("%$it")
//            }
//        }
//
//        if (filterMedia and TYPE_SVGS != 0) {
//            args.add("%.svg")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            args.add("%.jpg")
//            args.add("%.jpeg")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }


        return args
    }

    private fun getLatestFileFolders(): LinkedHashSet<String> {
        val uri = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(MediaStore.Images.ImageColumns.DATA)
        val parents = LinkedHashSet<String>()
        var cursor: Cursor? = null
        try {
            if (isRPlus()) {
                val bundle = Bundle().apply {
                    putInt(ContentResolver.QUERY_ARG_LIMIT, 10)
                    putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(BaseColumns._ID))
                    putInt(
                        ContentResolver.QUERY_ARG_SORT_DIRECTION,
                        ContentResolver.QUERY_SORT_DIRECTION_DESCENDING
                    )
                }

                cursor = context.contentResolver.query(uri, projection, bundle, null)
                if (cursor?.moveToFirst() == true) {
                    do {
                        val path =
                            cursor.getStringValue(MediaStore.Images.ImageColumns.DATA) ?: continue
                        parents.add(path.getParentPath())
                    } while (cursor.moveToNext())
                }
            } else {
                val sorting = "${BaseColumns._ID} DESC LIMIT 10"
                cursor = context.contentResolver.query(uri, projection, null, null, sorting)
                if (cursor?.moveToFirst() == true) {
                    do {
                        val path =
                            cursor.getStringValue(MediaStore.Images.ImageColumns.DATA) ?: continue
                        parents.add(path.getParentPath())
                    } while (cursor.moveToNext())
                }
            }
        } catch (e: Exception) {
            context.showErrorToast(e)
        } finally {
            cursor?.close()
        }

        return parents
    }

    fun getFilesFrom(
        curPath: String,
        isPickImage: Boolean,
        isPickVideo: Boolean,
        getProperDateTaken: Boolean,
        getProperLastModified: Boolean,
        getProperFileSize: Boolean,
        favoritePaths: ArrayList<String>,
        getVideoDurations: Boolean,
        lastModifieds: HashMap<String, Long>,
        dateTakens: HashMap<String, Long>,
        android11Files: HashMap<String, ArrayList<PictureData>>?
    ): ArrayList<PictureData> {
        val filterMedia = config.getFilterMedia()
        if (filterMedia == 0) {
            return ArrayList()
        }

        val curMedia = ArrayList<PictureData>()
//        if (context.isPathOnOTG(curPath)) {
//            if (context.hasOTGConnected()) {
//                val newMedia = getMediaOnOTG(curPath, isPickImage, isPickVideo, filterMedia, favoritePaths, getVideoDurations)
//                curMedia.addAll(newMedia)
//            }
//        } else {
//            if (curPath != FAVORITES && curPath != RECYCLE_BIN && isRPlus() && !isExternalStorageManager()) {
        if (isRPlus() && !isExternalStorageManager()) {
            if (android11Files?.containsKey(curPath.lowercase(Locale.getDefault())) == true) {
                curMedia.addAll(android11Files[curPath.lowercase(Locale.getDefault())]!!)
            } else if (android11Files == null) {
                val files = getAndroid11FolderMedia(
                    isPickImage,
                    isPickVideo,
                    favoritePaths,
                    false,
                    getProperDateTaken,
                    dateTakens
                )
                if (files.containsKey(curPath.lowercase(Locale.getDefault()))) {
                    curMedia.addAll(files[curPath.lowercase(Locale.getDefault())]!!)
                }
            }
        }

        if (curMedia.isEmpty()) {
            val newMedia = getMediaInFolder(
                curPath,
                isPickImage,
                isPickVideo,
                filterMedia,
                getProperDateTaken,
                getProperLastModified,
                getProperFileSize,
                favoritePaths,
                getVideoDurations,
                lastModifieds.clone() as HashMap<String, Long>,
                dateTakens.clone() as HashMap<String, Long>
            )

//                if (curPath == FAVORITES && isRPlus() && !isExternalStorageManager()) {
            if (isRPlus() && !isExternalStorageManager()) {
                val files =
                    getAndroid11FolderMedia(
                        isPickImage,
                        isPickVideo,
                        favoritePaths,
                        true,
                        getProperDateTaken,
                        dateTakens.clone() as HashMap<String, Long>
                    )
                newMedia.forEach { newMedium ->
                    for ((folder, media) in files) {
                        media.forEach { medium ->
                            if (medium.filePath == newMedium.filePath) {
                                newMedium.fileSize = medium.fileSize
                            }
                        }
                    }
                }
            }
            curMedia.addAll(newMedia)
        }
//        }

        sortMedia(curMedia, config.getSortType())
        return curMedia
    }

    private fun getFolderSizes(folder: String): HashMap<String, Long> {
        val sizes = HashMap<String, Long>()
//        if (folder != FAVORITES) {
        val projection = arrayOf(
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE
        )

        val uri = MediaStore.Files.getContentUri("external")
        val selection =
            "${MediaStore.Images.Media.DATA} LIKE ? AND ${MediaStore.Images.Media.DATA} NOT LIKE ?"
        val selectionArgs = arrayOf("$folder/%", "$folder/%/%")

        context.queryCursor(uri, projection, selection, selectionArgs) { cursor ->
            try {
                val size = cursor.getLongValue(MediaStore.Images.Media.SIZE)
                if (size != 0L) {
                    val name = cursor.getStringValue(MediaStore.Images.Media.DISPLAY_NAME)
                    sizes["$folder/$name"] = size
                }
            } catch (e: Exception) {
            }
        }
//        }

        return sizes
    }

    fun sortMedia(media: ArrayList<PictureData>, sorting: Int) {
//        if (sorting and SORT_BY_RANDOM != 0) {
//            media.shuffle()
//            return
//        }

        media.sortWith { o1, o2 ->
            o1 as PictureData
            o2 as PictureData
            var result = when {
                sorting and Constant.SORT_NAME != 0 -> {
//                    if (sorting and SORT_USE_NUMERIC_VALUE != 0) {
//                        AlphanumericComparator().compare(o1.name.normalizeString().lowercase(Locale.getDefault()), o2.name.normalizeString().lowercase(Locale.getDefault()))
//                    } else {
                    o1.fileName.normalizeString().lowercase(Locale.getDefault())
                        .compareTo(o2.fileName.normalizeString().lowercase(Locale.getDefault()))
//                    }
                }

                sorting and Constant.SORT_PATH != 0 -> {
//                    if (sorting and SORT_USE_NUMERIC_VALUE != 0) {
//                        AlphanumericComparator().compare(o1.path.lowercase(Locale.getDefault()), o2.path.lowercase(Locale.getDefault()))
//                    } else {
                    o1.filePath.lowercase(Locale.getDefault())
                        .compareTo(o2.filePath.lowercase(Locale.getDefault()))
//                    }
                }

                sorting and Constant.SORT_SIZE != 0 -> o1.fileSize.compareTo(o2.fileSize)
                sorting and Constant.SORT_LAST_MODIFIED != 0 -> o1.date.compareTo(o2.date)
                else -> o1.dateTaken.compareTo(o2.dateTaken)
            }

//            if (sorting and SORT_DESCENDING != 0) {
//                result *= -1
//            }
            result
        }
    }


    fun groupMedia(media: ArrayList<PictureData>, path: String): ArrayList<AlbumData> {
        val pathToCheck = if (path.isEmpty()) SHOW_ALL else path
        val currentGrouping = config.getSortOrder()
        if (currentGrouping and GROUP_BY_NONE != 0) {
            return media as ArrayList<AlbumData>
        }

        val thumbnailItems = ArrayList<AlbumData>()
//        if (config.scrollHorizontally) {
//            media.mapTo(thumbnailItems) { it }
//            return thumbnailItems
//        }

        val mediumGroups = LinkedHashMap<String, ArrayList<PictureData>>()
        media.forEach {
//            val key = it.getGroupingKey(currentGrouping)
            val key = ""
            if (!mediumGroups.containsKey(key)) {
                mediumGroups[key] = ArrayList()
            }
            mediumGroups[key]!!.add(it)
        }

        val sortDescending = currentGrouping and ORDER_DESCENDING != 0
        val sorted =
            if (currentGrouping and GROUP_BY_LAST_MODIFIED_DAILY != 0 || currentGrouping and GROUP_BY_LAST_MODIFIED_MONTHLY != 0 ||
                currentGrouping and GROUP_BY_DATE_TAKEN_DAILY != 0 || currentGrouping and GROUP_BY_DATE_TAKEN_MONTHLY != 0
            ) {
                mediumGroups.toSortedMap(if (sortDescending) compareByDescending {
                    it.toLongOrNull() ?: 0L
                } else {
                    compareBy { it.toLongOrNull() ?: 0L }
                })
            } else {
                mediumGroups.toSortedMap(if (sortDescending) compareByDescending { it } else compareBy { it })
            }

        mediumGroups.clear()
        for ((key, value) in sorted) {
            mediumGroups[key] = value
        }

//        val today = formatDate(System.currentTimeMillis().toString(), true)
//        val yesterday = formatDate((System.currentTimeMillis() - DAY_SECONDS * 1000).toString(), true)
//        for ((key, value) in mediumGroups) {
//            var currentGridPosition = 0
//            val sectionKey = getFormattedKey(key, currentGrouping, today, yesterday, value.size)
//            thumbnailItems.add(ThumbnailSection(sectionKey))
//
//            value.forEach {
//                it.gridPosition = currentGridPosition++
//            }
//
//            thumbnailItems.addAll(value)
//        }

        return thumbnailItems
    }

    private fun getMediaInFolder(
        folder: String,
        isPickImage: Boolean,
        isPickVideo: Boolean,
        filterMedia: Int,
        getProperDateTaken: Boolean,
        getProperLastModified: Boolean,
        getProperFileSize: Boolean,
        favoritePaths: ArrayList<String>,
        getVideoDurations: Boolean,
        lastModifieds: HashMap<String, Long>,
        dateTakens: HashMap<String, Long>
    ): ArrayList<PictureData> {
        val media = ArrayList<PictureData>()
//        val isRecycleBin = folder == RECYCLE_BIN
        val isRecycleBin = false
//        val deletedMedia = if (isRecycleBin) {
//            context.getUpdatedDeletedMedia()
//        } else {
//            ArrayList()
//        }

//        val config = context.config
//        val checkProperFileSize = getProperFileSize || config.fileLoadingPriority == PRIORITY_COMPROMISE
        val checkProperFileSize = getProperFileSize
//        val checkFileExistence = config.fileLoadingPriority == PRIORITY_VALIDITY

        val showHidden = config.shouldShowHidden
//        val showPortraits = filterMedia and TYPE_PORTRAITS != 0
//        val fileSizes = if (checkProperFileSize || checkFileExistence) getFolderSizes(folder) else HashMap()
        val fileSizes = if (checkProperFileSize) getFolderSizes(folder) else HashMap()

        val files = File(folder).listFiles()?.toMutableList() ?: return media
//        val files = when (folder) {
//            FAVORITES -> favoritePaths.filter { showHidden || !it.contains("/.") }.map { File(it) }.toMutableList() as ArrayList<File>
//            RECYCLE_BIN -> deletedMedia.map { File(it.path) }.toMutableList() as ArrayList<File>
//            else -> File(folder).listFiles()?.toMutableList() ?: return media
//        }

        for (curFile in files) {
            var file = curFile
            if (shouldStop) {
                break
            }

            var path = file.absolutePath
            var isPortrait = false
            val isImage = path.isImageFast()
            val isVideo = if (isImage) false else path.isVideoFast()
//            val isGif = if (isImage || isVideo) false else path.isGif()
            val isGif = if (isImage) false else path.isGif()
            val isRaw = if (isImage || isVideo || isGif) false else path.isRawFast()
            val isSvg = if (isImage || isVideo || isGif || isRaw) false else path.isSvg()

//            if (!isImage && !isVideo && !isGif && !isRaw && !isSvg) {
//                if (showPortraits && file.name.startsWith("img_", true) && file.isDirectory) {
//                    val portraitFiles = file.listFiles() ?: continue
//                    val cover = portraitFiles.firstOrNull { it.name.contains("cover", true) }
//                        ?: portraitFiles.firstOrNull()
//                    if (cover != null && !files.contains(cover)) {
//                        file = cover
//                        path = cover.absolutePath
//                        isPortrait = true
//                    } else {
//                        continue
//                    }
//                } else {
//                    continue
//                }
//            }

            if (isVideo && (isPickImage || filterMedia and TYPE_VIDEOS == 0))
                continue

            if (isImage && (isPickVideo || filterMedia and TYPE_IMAGES == 0))
                continue

            if (isGif && filterMedia and TYPE_GIFS == 0)
                continue

//            if (isRaw && filterMedia and TYPE_RAWS == 0)
//                continue
//
//            if (isSvg && filterMedia and TYPE_SVGS == 0)
//                continue

            val filename = file.name
            if (!showHidden && filename.startsWith('.'))
                continue

            var size = 0L
//            if (checkProperFileSize || checkFileExistence) {
            if (checkProperFileSize) {
                var newSize = fileSizes.remove(path)
                if (newSize == null) {
                    newSize = file.length()
                }
                size = newSize
            }

//            if ((checkProperFileSize || checkFileExistence) && size <= 0L) {
            if ((checkProperFileSize) && size <= 0L) {
                continue
            }

//            if (checkFileExistence && (!file.exists() || !file.isFile)) {
            if ((!file.exists() || !file.isFile)) {
                continue
            }

            if (isRecycleBin) {
//                deletedMedia.firstOrNull { it.path == path }?.apply {
//                    media.add(this)
//                }
            } else {
                var lastModified: Long
                var newLastModified = lastModifieds.remove(path)
                if (newLastModified == null) {
                    newLastModified = if (getProperLastModified) {
                        file.lastModified()
                    } else {
                        0L
                    }
                }
                lastModified = newLastModified

                var dateTaken = lastModified
                val videoDuration =
                    if (getVideoDurations && isVideo) context.getDuration(path) ?: 0 else 0

                if (getProperDateTaken) {
                    var newDateTaken = dateTakens.remove(path)
                    if (newDateTaken == null) {
                        newDateTaken = if (getProperLastModified) {
                            lastModified
                        } else {
                            file.lastModified()
                        }
                    }
                    dateTaken = newDateTaken
                }

                val type = when {
                    isVideo -> TYPE_VIDEOS
                    isGif -> TYPE_GIFS
//                    isRaw -> TYPE_RAWS
//                    isSvg -> TYPE_SVGS
//                    isPortrait -> TYPE_PORTRAITS
                    else -> TYPE_IMAGES
                }

                val isFavorite = favoritePaths.contains(path)
                val medium = PictureData(
                    path,
                    filename,
                    path.getParentPath().getFilenameFromPath(),
                    lastModified,
                    dateTaken,
                    size,
                    isVideo,
                    videoDuration.toLong(),
                    path.getParentPath(),
                    false,
                    false,
                    isFavorite,
                    false,
                    ""
                )
//                val medium = PictureData(null, filename, path, file.parent, lastModified, dateTaken, size, type, videoDuration, isFavorite, 0L, 0L)
                media.add(medium)
            }
        }

        return media
    }

    fun getAndroid11FolderMedia(
        isPickImage: Boolean,
        isPickVideo: Boolean,
        favoritePaths: ArrayList<String>,
        getFavoritePathsOnly: Boolean,
        getProperDateTaken: Boolean,
        dateTakens: HashMap<String, Long>
    ): HashMap<String, ArrayList<PictureData>> {
        val media = HashMap<String, ArrayList<PictureData>>()
        if (!isRPlus() || Environment.isExternalStorageManager()) {
            return media
        }

        val filterMedia = config.getFilterMedia()
        val showHidden = config.shouldShowHidden

        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATA,
            MediaStore.Images.Media.DATE_MODIFIED,
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.SIZE,
            MediaStore.MediaColumns.DURATION
        )

        val uri = MediaStore.Files.getContentUri("external")

        context.queryCursor(uri, projection) { cursor ->
            if (shouldStop) {
                return@queryCursor
            }

            try {
                val mediaStoreId = cursor.getLongValue(MediaStore.Images.Media._ID)
                val filename = cursor.getStringValue(MediaStore.Images.Media.DISPLAY_NAME)
                val path = cursor.getStringValue(MediaStore.Images.Media.DATA)
                if (getFavoritePathsOnly && !favoritePaths.contains(path)) {
                    return@queryCursor
                }

                val isPortrait = false
                val isImage = path.isImageFast()
                val isVideo = if (isImage) false else path.isVideoFast()
//                val isGif = if (isImage || isVideo) false else path.isGif()
                val isGif = if (isImage) false else path.isGif()
                val isRaw = if (isImage || isVideo || isGif) false else path.isRawFast()
                val isSvg = if (isImage || isVideo || isGif || isRaw) false else path.isSvg()

                if (!isImage && !isVideo && !isGif && !isRaw && !isSvg) {
                    return@queryCursor
                }

                if (isVideo && (isPickImage || filterMedia and TYPE_VIDEOS == 0))
                    return@queryCursor

                if (isImage && (isPickVideo || filterMedia and TYPE_IMAGES == 0))
                    return@queryCursor

                if (isGif && filterMedia and TYPE_GIFS == 0)
                    return@queryCursor

//                if (isRaw && filterMedia and TYPE_RAWS == 0)
//                    return@queryCursor
//
//                if (isSvg && filterMedia and TYPE_SVGS == 0)
//                    return@queryCursor

                if (!showHidden && filename.startsWith('.'))
                    return@queryCursor

                val size = cursor.getLongValue(MediaStore.Images.Media.SIZE)
                if (size <= 0L) {
                    return@queryCursor
                }

                val type = when {
                    isVideo -> TYPE_VIDEOS
                    isGif -> TYPE_GIFS
//                    isRaw -> TYPE_RAWS
//                    isSvg -> TYPE_SVGS
//                    isPortrait -> TYPE_PORTRAITS
                    else -> TYPE_IMAGES
                }

                val lastModified = cursor.getLongValue(MediaStore.Images.Media.DATE_MODIFIED) * 1000
                var dateTaken = cursor.getLongValue(MediaStore.Images.Media.DATE_TAKEN)

                if (getProperDateTaken) {
                    dateTaken = dateTakens.remove(path) ?: lastModified
                }

                if (dateTaken == 0L) {
                    dateTaken = lastModified
                }

                val videoDuration =
                    Math.round(cursor.getIntValue(MediaStore.MediaColumns.DURATION) / 1000.toDouble())
                val isFavorite = favoritePaths.contains(path)
                val medium = PictureData(
                    path,
                    filename,
                    path.getParentPath().getFilenameFromPath(),
                    lastModified,
                    dateTaken,
                    size,
                    isVideo,
                    videoDuration,
                    path.getParentPath(),
                    false,
                    false,
                    isFavorite,
                    false,
                    ""
                )
//                    Medium(null, filename, path, path.getParentPath(), lastModified, dateTaken, size, type, videoDuration, isFavorite, 0L, mediaStoreId)
                val parent = medium.folderName.lowercase(Locale.getDefault())
                val currentFolderMedia = media[parent]
                if (currentFolderMedia == null) {
                    media[parent] = ArrayList<PictureData>()
                }

                media[parent]?.add(medium)
            } catch (e: Exception) {
            }
        }

        return media
    }

    fun getDateTakens(): HashMap<String, Long> {
        val dateTakens = HashMap<String, Long>()
        val projection = arrayOf(
            MediaStore.Images.Media.DATA,
            MediaStore.Images.Media.DATE_TAKEN
        )

        val uri = MediaStore.Files.getContentUri("external")

        try {
            context.queryCursor(uri, projection) { cursor ->
                try {
                    val dateTaken = cursor.getLongValue(MediaStore.Images.Media.DATE_TAKEN)
                    if (dateTaken != 0L) {
                        val path = cursor.getStringValue(MediaStore.Images.Media.DATA)
                        dateTakens[path] = dateTaken
                    }
                } catch (e: Exception) {
                }
            }

//            val dateTakenValues = context.dateTakensDB.getAllDateTakens()
//            dateTakenValues.forEach {
//                dateTakens[it.fullPath] = it.taken
//            }
        } catch (e: Exception) {
        }

        return dateTakens
    }

    fun getLastModifieds(): HashMap<String, Long> {
        val lastModifieds = HashMap<String, Long>()
        val projection = arrayOf(
            MediaStore.Images.Media.DATA,
            MediaStore.Images.Media.DATE_MODIFIED
        )

        val uri = MediaStore.Files.getContentUri("external")

        try {
            context.queryCursor(uri, projection) { cursor ->
                try {
                    val lastModified =
                        cursor.getLongValue(MediaStore.Images.Media.DATE_MODIFIED) * 1000
                    if (lastModified != 0L) {
                        val path = cursor.getStringValue(MediaStore.Images.Media.DATA)
                        lastModifieds[path] = lastModified
                    }
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }

        return lastModifieds
    }

}