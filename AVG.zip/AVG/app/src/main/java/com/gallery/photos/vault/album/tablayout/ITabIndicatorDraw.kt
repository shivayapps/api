package com.gallery.photos.vault.album.tablayout

import android.graphics.Canvas


interface ITabIndicatorDraw {

    /**绘制指示器
     * [positionOffset] 页面偏移量*/
    fun onDrawTabIndicator(
        tabIndicator: DslTabIndicator,
        canvas: Canvas,
        positionOffset: Float
    )

}