package com.gallery.photos.vault.album.dialog

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Point
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.text.format.DateFormat
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.core.content.FileProvider
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.databinding.DialogBatchRenameBinding
import com.gallery.photos.vault.album.extension.beGone
import com.gallery.photos.vault.album.extension.beVisible
import com.gallery.photos.vault.album.extension.ensureTwoDigits
import com.gallery.photos.vault.album.extension.getDoesFilePathExist
import com.gallery.photos.vault.album.extension.getFilenameFromPath
import com.gallery.photos.vault.album.extension.getParentPath
import com.gallery.photos.vault.album.extension.isAValidFilename
import com.gallery.photos.vault.album.extension.isMediaFile
import com.gallery.photos.vault.album.extension.showErrorToast
import com.gallery.photos.vault.album.extension.toast
import com.gallery.photos.vault.album.utils.Constant
import com.gallery.photos.vault.album.utils.Preferences
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class BatchFolderRenameDialog(
    var mContext: Activity,
    val useMediaFileExtension: Boolean,
    var listAlbumData: ArrayList<String>,
    val updateImageListener: () -> Unit
) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogBatchRenameBinding
    var preferences: Preferences = Preferences(mContext)

    //    lateinit var tabsAdapter: RenameAdapter
//    lateinit var viewPager: ViewPager2
//    lateinit var paths: ArrayList<String>
    val paths: ArrayList<String> = ArrayList()

    //    var oldName = ""
    var type = Constant.RENAME_SIMPLE

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogBatchRenameBinding.inflate(layoutInflater, container, false)
        intView()
        intListener()
        return bindingDialog.root
    }


    private fun intView() {
        if (isAdded) {
            paths.addAll(listAlbumData)
            bindingDialog.loutTab.observeIndexChange { fromIndex, toIndex, reselect, fromUser ->
                type = when {
                    toIndex == 0 -> {
                        bindingDialog.renameSimpleRadioGroup.beVisible()
                        bindingDialog.renameItemsLabel.beGone()
                        Constant.RENAME_SIMPLE
                    }

                    else -> {
                        bindingDialog.renameSimpleRadioGroup.beGone()
                        bindingDialog.renameItemsLabel.beVisible()
                        Constant.RENAME_PATTERN
                    }
                }
            }
        }
    }

    private fun intListener() {

        bindingDialog.btnCancel.setOnClickListener { dismiss() }

        bindingDialog.btnRename.setOnClickListener {
//            bindingDialog.dialogTabViewPager.currentItem
//            tabsAdapter.dialogConfirmed(useMediaFileExtension, viewPager.currentItem) {
//            val progressDialog = ProgressDialog(
//                mContext,
//                0,
//                0,
//                getString(R.string.saving),
//                ""
//            )

            bindingDialog.llProgress.beVisible()
            if (type == Constant.RENAME_SIMPLE) {
                dialogConfirmedSimple(useMediaFileExtension) {
                    mContext.runOnUiThread {
                        bindingDialog.llProgress.beGone()
                    }
                    if (it) {
                        updateImageListener.invoke()
                    }
                    dismiss()
                }
            } else {
                dialogConfirmedPattern(useMediaFileExtension) {
                    mContext.runOnUiThread {
                        bindingDialog.llProgress.beGone()
                    }
                    if (it) {
                        updateImageListener.invoke()
                    }
                    dismiss()
                }
            }
        }
    }


    fun dialogConfirmedSimple(
        useMediaFileExtension: Boolean, callback: (success: Boolean) -> Unit
    ) {
        try {
            Log.e("renameFile", "dialogConfirmedSimple dialogConfirmed->$useMediaFileExtension")
//        stopLooping = false
            val valueToAdd = bindingDialog.renameValue.text.toString()

            val append =
                bindingDialog.renameSimpleRadioGroup.checkedRadioButtonId == bindingDialog.renameSimpleRadioAppend.id

            if (valueToAdd.isEmpty()) {
                mContext?.toast(R.string.invalid_name)
//            callback(false)
                return
            }

            if (!valueToAdd.isAValidFilename()) {
                mContext?.toast(R.string.invalid_name)
//            callback(false)
                return
            }

            val validPaths = paths.filter { mContext?.getDoesFilePathExist(it) == true }
            val firstPath = validPaths.firstOrNull()

            if (firstPath == null) {
                mContext?.toast(R.string.unknown_error_occurred)
                callback(false)
                dismiss()
                return
            }

            var pathsCnt = validPaths.size
            for (path in validPaths) {
                Log.e("renameFile", "dialogConfirmedSimple validPaths->$path")

                val fullName = path.getFilenameFromPath()
                var dotAt = fullName.lastIndexOf(".")
                if (dotAt == -1) {
                    dotAt = fullName.length
                }

                val name = fullName.substring(0, dotAt)
                val extension =
                    if (fullName.contains(".")) ".${fullName.getFilenameExtension()}" else ""

                val newName = if (append) {
                    "$name$valueToAdd$extension"
                } else {
                    "$valueToAdd$fullName"
                }

                val newPath = "${path.getParentPath()}/$newName"

                if (mContext?.getDoesFilePathExist(newPath) == true) {
                    continue
                }

                Log.e("renameFile", "dialogConfirmedSimple path->$path, newPath->$newPath")
                if (renameFile(path, newName)) {
                    pathsCnt--
                    if (pathsCnt == 0) {
                        callback(true)
                    }
                } else {
                    Log.e("renameFile", "dialogConfirmedSimple renameFile-> failed")
                }
            }
        } catch (e: Exception) {
            callback.invoke(false)
            Log.e("printStackTrace", "printStackTrace:$e")
        }
    }

    var ignoreClicks = false
    var stopLooping =
        false     // we should request the permission on Android 30+ for all uris at once, not one by one
    var currentIncrementalNumber = 1
    var numbersCnt = 0
    fun dialogConfirmedPattern(
        useMediaFileExtension: Boolean, callback: (success: Boolean) -> Unit
    ) {
        try {
            Log.e("renameFile", "dialogConfirmedPattern->$useMediaFileExtension")
            stopLooping = false
            if (ignoreClicks) {
                return
            }

            val newNameRaw = bindingDialog.renameValue.text.toString()
            if (newNameRaw.isEmpty()) {
                mContext?.toast(R.string.invalid_name)
                callback(false)
                return
            }

            val validPaths = paths.filter { mContext?.getDoesFilePathExist(it) == true }
            val firstPath = validPaths.firstOrNull()
//        val sdFilePath = validPaths.firstOrNull { mContext?.isPathOnSD(it) == true } ?: firstPath
//        if (firstPath == null || sdFilePath == null) {
            if (firstPath == null) {
                mContext?.toast(R.string.unknown_error_occurred)
                callback(false)
                dismiss()
                return
            }

            var pathsCnt = validPaths.size
            numbersCnt = pathsCnt.toString().length
            for (path in validPaths) {
                Log.e("renameFile", "dialogConfirmedPattern validPaths->$path")

                try {
                    val newPath = getNewPath(path, useMediaFileExtension) ?: continue

                    Log.e("renameFile", "dialogConfirmedPattern path->$path, newPath->$newPath")
                    if (renameFile(path, newPath)) {
                        pathsCnt--
                        if (pathsCnt == 0) {
                            callback(true)
                        }
                    } else {
                        Log.e("renameFile", "dialogConfirmedPattern renameFile-> failed")
                    }

                } catch (e: Exception) {
                    callback(false)
                    Log.e("renameFile", "dialogConfirmedPattern Exception-> $e")
                    mContext?.showErrorToast(e)
                }
            }

        } catch (e: Exception) {
            callback.invoke(false)
            Log.e("printStackTrace", "printStackTrace:$e")
        }
    }

    fun renameFile(oldPath: String, strNewFileName: String): Boolean {

        var renamed = false
        try {

            val renameFilePath: String =
                File(oldPath).parent.toString() + File.separator + strNewFileName
            val oldFile: File = File(oldPath)

            val renameFile = File(renameFilePath)
            renamed = oldFile.renameTo(renameFile)
            Log.e("renameFile", "dialogConfirmedSimple $oldFile.renameTo->$renameFile")

            MediaScannerConnection.scanFile(context,
                arrayOf<String>(renameFile.path),
                null,
                MediaScannerConnection.OnScanCompletedListener { path: String?, uri: Uri? -> })

            MediaScannerConnection.scanFile(context,
                arrayOf<String>(oldFile.path),
                null,
                MediaScannerConnection.OnScanCompletedListener { path: String?, uri: Uri? -> })

//        if (renamed)
//            return renameFilePath
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }
        return renamed

//        return ""
    }

    private fun getNewPath(path: String, useMediaFileExtension: Boolean): String? {
        Log.e("renameFile", "dialogConfirmedPattern getNewPath")
//        try {
//            val exif = ExifInterface(path)
//            var dateTime = if (isNougatPlus()) {
//                exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL) ?: exif.getAttribute(
//                    ExifInterface.TAG_DATETIME
//                )
//            } else {
//                exif.getAttribute(ExifInterface.TAG_DATETIME)
//            }

//            if (dateTime == null) {
        val calendar = Calendar.getInstance(Locale.ENGLISH)
        calendar.timeInMillis = File(path).lastModified()
        val dateTime = DateFormat.format("yyyy:MM:dd kk:mm:ss", calendar).toString()
//            }

        val pattern = if (dateTime.substring(
                4, 5
            ) == "-"
        ) "yyyy-MM-dd kk:mm:ss" else "yyyy:MM:dd kk:mm:ss"
        val simpleDateFormat = SimpleDateFormat(pattern, Locale.ENGLISH)

        val dt = simpleDateFormat.parse(dateTime.replace("T", " "))
        val cal = Calendar.getInstance()
        cal.time = dt
        val year = cal.get(Calendar.YEAR).toString()
        val month = (cal.get(Calendar.MONTH) + 1).ensureTwoDigits()
        val day = (cal.get(Calendar.DAY_OF_MONTH)).ensureTwoDigits()
        val hours = (cal.get(Calendar.HOUR_OF_DAY)).ensureTwoDigits()
        val minutes = (cal.get(Calendar.MINUTE)).ensureTwoDigits()
        val seconds = (cal.get(Calendar.SECOND)).ensureTwoDigits()

        var newName = bindingDialog.renameValue.text.toString().replace("%Y", year, false)
            .replace("%M", month, false).replace("%D", day, false).replace("%h", hours, false)
            .replace("%m", minutes, false).replace("%s", seconds, false)
            .replace("%i", String.format("%0${numbersCnt}d", currentIncrementalNumber))

        if (newName.isEmpty()) {
            return null
        }

        currentIncrementalNumber++
        if ((!newName.contains(".") && path.contains(".")) || (useMediaFileExtension && !".${
                newName.substringAfterLast(
                    "."
                )
            }".isMediaFile())
        ) {
            val extension = path.substringAfterLast(".")
            newName += ".$extension"
        }

        var newPath = "${path.getParentPath()}/$newName"

        var currentIndex = 0
        while (mContext?.getDoesFilePathExist(newPath) == true) {
            currentIndex++
            var extension = ""
            val name = if (newName.contains(".")) {
                extension = ".${newName.substringAfterLast(".")}"
                newName.substringBeforeLast(".")
            } else {
                newName
            }

            newPath = "${path.getParentPath()}/$name~$currentIndex$extension"
        }

        Log.e("renameFile", "dialogConfirmedPattern newName:$newName")
        return newName
//        } catch (e: Exception) {
//            Log.e("renameFile", "dialogConfirmedPattern Exception:$e")
//            return null
//        }
    }

    private fun getViewValue(view: EditText): Int {
        val textValue = view.text.toString().trim()
        return if (textValue.isEmpty()) 0 else textValue.toInt()
    }

    private fun setRename(oldPath: String, renamePath: String) {
//        EventBus.getDefault().post(RenameEvent(oldPath, renamePath))
        val list = preferences.getFavoriteList()
        if (list.contains(oldPath)) {
            list.remove(oldPath)
            list.add(0, renamePath)
            preferences.setFavoriteList(list)
        }
    }

//    private fun renameFile(strNewFileName: String): String {
////        var renamed = false
////        val renameFilePath: String =
////            File(listAlbumData.folderPath).parent.toString() + File.separator + strNewFileName
////        val oldFile: File = File(listAlbumData.folderPath)
////        val renameFile = File(renameFilePath)
////        renamed = oldFile.renameTo(renameFile)
////        MediaScannerConnection.scanFile(context, arrayOf<String>(renameFile.path), null,
////            OnScanCompletedListener { path: String?, uri: Uri? -> })
////        MediaScannerConnection.scanFile(context, arrayOf<String>(oldFile.path), null,
////            OnScanCompletedListener { path: String?, uri: Uri? -> })
////        if (renamed)
////            return renameFilePath
//        return ""
//    }

    fun String.getImageResolution(): Point {
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(this, options)

        val width = options.outWidth
        val height = options.outHeight
        return if (width > 0 && height > 0) {
            Point(options.outWidth, options.outHeight)
        } else {
            Point(0, 0)
        }
    }

    fun resizeImage(bitmap: Bitmap, imagePath: String): String? {

        val imageFile = File(imagePath)
        if (imageFile.exists()) {
            imageFile.delete()
            val deleteUrl = FileProvider.getUriForFile(
                mContext, "${mContext.packageName}.provider", imageFile
            )
            val contentResolver = mContext.contentResolver
            contentResolver.delete(deleteUrl, null, null)

            MediaScannerConnection.scanFile(
                mContext, arrayOf(imageFile.path), null
            ) { path: String?, uri: Uri? -> }
        }

        try {
            val stream = FileOutputStream(imageFile)
            bitmap.compress(imageFile.path.getCompressionFormat(), 100, stream)

            val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
            val contentUri = Uri.fromFile(imageFile)
            mediaScanIntent.data = contentUri
            mContext.sendBroadcast(mediaScanIntent)

            stream.flush()
            stream.close()

            MediaScannerConnection.scanFile(
                mContext, arrayOf<String>(imageFile.path), null
            ) { path, uri ->
            }
            return imagePath
        } catch (e: IOException) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }
        return null
    }

    fun String.getFilenameExtension() = substring(lastIndexOf(".") + 1)
    fun String.getCompressionFormat() = when (getFilenameExtension().lowercase()) {
        "png" -> Bitmap.CompressFormat.PNG
        "webp" -> Bitmap.CompressFormat.WEBP
        else -> Bitmap.CompressFormat.JPEG
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}

