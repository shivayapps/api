package com.gallery.photos.vault.album.dialog

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Point
import android.media.MediaScannerConnection
import android.media.MediaScannerConnection.OnScanCompletedListener
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.core.content.FileProvider
import androidx.core.widget.addTextChangedListener
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.databinding.DialogRenameBinding
import com.gallery.photos.vault.album.event.RenameEvent
import com.gallery.photos.vault.album.extension.toast
import com.gallery.photos.vault.album.model.AlbumData
import com.gallery.photos.vault.album.utils.Preferences
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class RenameFolderDialog(
    var mContext: Activity,
    var pictureData: AlbumData,
    val positiveBtnClickListener: (renamePath: String, oldPath: String) -> Unit,
    val updateImageListener: () -> Unit
) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogRenameBinding
    var preferences: Preferences = Preferences(mContext)
    var oldName = ""
//    var type = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogRenameBinding.inflate(layoutInflater, container, false)
        intView()
        intListener()
        return bindingDialog.root
    }


    private fun intView() {

//        val separated: List<String> = pictureData.title.split(".")

        oldName = pictureData.title
//        type = separated[1]
        Log.e("", "oldName $oldName")
        bindingDialog.edtName.setText(oldName)
        bindingDialog.edtName.requestFocus()

    }

    private fun intListener() {
        bindingDialog.edtName.addTextChangedListener {
            bindingDialog.icClear.visibility = if (bindingDialog.edtName.text?.trim().toString()
                    .isNotEmpty()
            ) View.VISIBLE else View.GONE
        }
        bindingDialog.icClear.setOnClickListener {
            bindingDialog.edtName.setText("")
        }
        bindingDialog.btnCancel.setOnClickListener { dismiss() }

        bindingDialog.btnRename.setOnClickListener {

            val strNewFileName = bindingDialog.edtName.text.toString().trim()
            if (strNewFileName.isNotEmpty()) {
                val renameFile = File(pictureData.folderPath.replace(oldName, strNewFileName))
                if (!renameFile.exists() || oldName == strNewFileName) {
                    if (oldName != strNewFileName) {
                        val renamePath = renameFile(strNewFileName)
                        if (renamePath.isNotEmpty()) {
                            setRename(pictureData.folderPath, renamePath)
                            dismiss()

                            mContext.toast(getString(R.string.rename_successfully))
                            positiveBtnClickListener(renamePath, pictureData.folderPath)
                        } else {
                            dismiss()

                            mContext.toast(getString(R.string.failed))
                        }
                    } else {
                        dismiss()
                    }
                } else {
                    mContext.toast(getString(R.string.rename_validation2))
                }
            } else
                mContext.toast(getString(R.string.rename_validation))
        }
    }

    private fun getViewValue(view: EditText): Int {
        val textValue = view.text.toString().trim()
        return if (textValue.isEmpty()) 0 else textValue.toInt()
    }

    private fun setRename(oldPath: String, renamePath: String) {
//        EventBus.getDefault().post(RenameEvent(oldPath, renamePath))
        val list = preferences.getFavoriteList()
        if (list.contains(oldPath)) {
            list.remove(oldPath)
            list.add(0, renamePath)
            preferences.setFavoriteList(list)
        }
    }

    private fun renameFile(strNewFileName: String): String {

        var renamed = false
        val renameFilePath: String =
            File(pictureData.folderPath).parent.toString() + File.separator + strNewFileName
        val oldFile: File = File(pictureData.folderPath)
        val renameFile = File(renameFilePath)
        renamed = oldFile.renameTo(renameFile)

        MediaScannerConnection.scanFile(context, arrayOf<String>(renameFile.path), null,
            OnScanCompletedListener { path: String?, uri: Uri? -> })

        MediaScannerConnection.scanFile(context, arrayOf<String>(oldFile.path), null,
            OnScanCompletedListener { path: String?, uri: Uri? -> })

        if (renamed)
            return renameFilePath

        return ""
    }

    fun String.getImageResolution(): Point {
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(this, options)

        val width = options.outWidth
        val height = options.outHeight
        return if (width > 0 && height > 0) {
            Point(options.outWidth, options.outHeight)
        } else {
            Point(0, 0)
        }
    }

    fun resizeImage(bitmap: Bitmap, imagePath: String): String? {

        val imageFile = File(imagePath)
        if (imageFile.exists()) {
            imageFile.delete()
            val deleteUrl = FileProvider.getUriForFile(
                mContext,
                "${mContext.packageName}.provider", imageFile
            )
            val contentResolver = mContext.contentResolver
            contentResolver.delete(deleteUrl, null, null)

            MediaScannerConnection.scanFile(
                mContext,
                arrayOf(imageFile.path),
                null
            ) { path: String?, uri: Uri? -> }
        }

        try {
            val stream = FileOutputStream(imageFile)
            bitmap.compress(imageFile.path.getCompressionFormat(), 100, stream)

            val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
            val contentUri = Uri.fromFile(imageFile)
            mediaScanIntent.data = contentUri
            mContext.sendBroadcast(mediaScanIntent)

            stream.flush()
            stream.close()

            MediaScannerConnection.scanFile(
                mContext, arrayOf<String>(imageFile.path), null
            ) { path, uri ->
            }
            return imagePath
        } catch (e: IOException) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
        return null
    }

    fun String.getFilenameExtension() = substring(lastIndexOf(".") + 1)
    fun String.getCompressionFormat() = when (getFilenameExtension().lowercase()) {
        "png" -> Bitmap.CompressFormat.PNG
        "webp" -> Bitmap.CompressFormat.WEBP
        else -> Bitmap.CompressFormat.JPEG
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}

