package com.gallery.photos.vault.album.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.databinding.DialogFilterMediaBinding
import com.gallery.photos.vault.album.utils.Preferences
import com.gallery.photos.vault.album.utils.TYPE_GIFS
import com.gallery.photos.vault.album.utils.TYPE_IMAGES
//import com.gallery.photos.vault.album.utils.TYPE_PORTRAITS
//import com.gallery.photos.vault.album.utils.TYPE_RAWS
//import com.gallery.photos.vault.album.utils.TYPE_SVGS
import com.gallery.photos.vault.album.utils.TYPE_VIDEOS
import com.gallery.photos.vault.album.utils.getDefaultFileFilter

class FilterMediaDialog(val updateListener: () -> Unit) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogFilterMediaBinding
    lateinit var preferences: Preferences
    var filterMedia = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogFilterMediaBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {

        preferences = Preferences(requireActivity())
        filterMedia=preferences.getFilterMedia()

        intListener()
        bindingDialog.cbImages.isChecked = filterMedia and TYPE_IMAGES != 0
        bindingDialog.cbVideos.isChecked = filterMedia and TYPE_VIDEOS != 0
        bindingDialog.cbGif.isChecked = filterMedia and TYPE_GIFS != 0
//        bindingDialog.cbRaw.isChecked = filterMedia and TYPE_RAWS != 0
//        bindingDialog.cbSvgs.isChecked = filterMedia and TYPE_SVGS != 0
//        bindingDialog.cbPortraits.isChecked = filterMedia and TYPE_PORTRAITS != 0
    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOK.setOnClickListener {

            var result = 0
            if (bindingDialog.cbImages.isChecked)
                result += TYPE_IMAGES
            if (bindingDialog.cbVideos.isChecked)
                result += TYPE_VIDEOS
            if (bindingDialog.cbGif.isChecked)
                result += TYPE_GIFS
//            if (bindingDialog.cbRaw.isChecked)
//                result += TYPE_RAWS
//            if (bindingDialog.cbSvgs.isChecked)
//                result += TYPE_SVGS
//            if (bindingDialog.cbPortraits.isChecked)
//                result += TYPE_PORTRAITS

            if (result == 0) {
                result = getDefaultFileFilter()
            }

            if (filterMedia != result) {
                preferences.setFilterMedia(result)
                updateListener()
            }
            dismiss()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}