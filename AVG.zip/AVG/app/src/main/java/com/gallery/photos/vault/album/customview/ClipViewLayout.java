package com.gallery.photos.vault.album.customview;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.gallery.photos.vault.album.R;

import java.io.IOException;

public class ClipViewLayout extends RelativeLayout {
    //Crop original image
    private ImageView imageView;
    //crop box
    private ClipView clipView;
    //The horizontal spacing of the cropping box, specified in the xml layout file
    private float mHorizontalPadding;
    //The vertical spacing of the cropping frame, calculated
    private float mVerticalPadding;
    //Image zoom and move operation matrix
    private Matrix matrix = new Matrix();
    //The original operation matrix of the image that has been scaled and moved
    private Matrix savedMatrix = new Matrix();
    //Action flag: None
    private static final int NONE = 0;
    //Action flag: drag
    private static final int DRAG = 1;
    //Action flag: Zoom
    private static final int ZOOM = 2;
    //initialization action flag
    private int mode = NONE;
    //Record starting coordinates
    private PointF start = new PointF();
    //Record the coordinates of the middle point of the two fingers when zooming
    private PointF mid = new PointF();
    private float oldDist = 1f;
    //9 values used to store the matrix
    private final float[] matrixValues = new float[9];
    //Minimum zoom ratio
    private float minScale;
    //Maximum zoom ratio
    private float maxScale = 4;


    public ClipViewLayout(Context context) {
        this(context, null);
    }

    public ClipViewLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ClipViewLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    //Initialize control custom properties
    public void init(Context context, AttributeSet attrs) {
        TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.ClipViewLayout);

        //Get the left and right margins of the clipping box, the default is 50dp
        mHorizontalPadding = array.getDimensionPixelSize(R.styleable.ClipViewLayout_mHorizontalPadding,
                (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 50, getResources().getDisplayMetrics()));
        //Get the width of the cropping box border, default 1dp
        int clipBorderWidth = array.getDimensionPixelSize(R.styleable.ClipViewLayout_clipBorderWidth,
                (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1, getResources().getDisplayMetrics()));
        //Cropping frame type (circle or rectangle)
        int clipType = array.getInt(R.styleable.ClipViewLayout_clipType, 1);

        //Recycle
        array.recycle();
        clipView = new ClipView(context);
        //Set cropping frame type
        clipView.setClipType(clipType == 1 ? ClipView.ClipType.CIRCLE : ClipView.ClipType.RECTANGLE);
        //Set cut box border
        clipView.setClipBorderWidth(clipBorderWidth);
        //Set the horizontal spacing of the clipping box
        clipView.setmHorizontalPadding(mHorizontalPadding);
        imageView = new ImageView(context);
        //Relative layout layout parameters
        android.view.ViewGroup.LayoutParams lp = new LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT);
        this.addView(imageView, lp);
        this.addView(clipView, lp);
    }


    /**
     * Initialization picture
     */
//    public void setImageSrc(final Uri uri) {
    public void setImageSrc(String path) {
        //You need to wait until the imageView is drawn before initializing the original image.
        ViewTreeObserver observer = imageView.getViewTreeObserver();
        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                initSrcPic(path);
                imageView.getViewTreeObserver().removeGlobalOnLayoutListener(this);
            }
        });
    }

    /**
     * Initialization picture
     * step 1: decode and output a photo of about 720*1280. Because the original image may be larger, loading it directly will cause OOM.
     * step 2: scale the image and move it to the middle of imageView
     */
    public void initSrcPic(String path) {
//        if (uri == null) {
//            return;
//        }
//        Log.d("evan", "**********clip_view uri*******  " + uri);
//        String path = getRealFilePathFromUri(getContext(), uri);
        Log.d("evan", "**********clip_view path*******  " + path);
        if (TextUtils.isEmpty(path)) {
            return;
        }

        //Decode here to produce photos of around 720*1280 to prevent OOM
        Bitmap bitmap = decodeSampledBitmap(path, 720, 1280);
        if (bitmap == null) {
            return;
        }

        //Photos taken in vertical screen will be rotated 90 degrees if used directly. The following code rotates the angle.
        int rotation = getExifOrientation(path); //Query rotation angle
        Matrix m = new Matrix();
        m.setRotate(rotation);
        bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), m, true);

        //Image zoom ratio
        float scale;
        if (bitmap.getWidth() >= bitmap.getHeight()) {//wide picture
            scale = (float) imageView.getWidth() / bitmap.getWidth();
            //If the height is smaller than the cropping area after scaling, the scaling ratio between the cropping area and height will be used as the final scaling ratio.
            Rect rect = clipView.getClipRect();
            //High minimum zoom ratio
            minScale = rect.height() / (float) bitmap.getHeight();
            if (scale < minScale) {
                scale = minScale;
            }
        } else {//high chart
            //High zoom ratio
            scale = (float) imageView.getHeight() / bitmap.getHeight();
            //If the width is smaller than the cropping area after scaling, the scaling ratio between the cropping area and the width will be used as the final scaling ratio.
            Rect rect = clipView.getClipRect();
            //Minimum zoom ratio for width
            minScale = rect.width() / (float) bitmap.getWidth();
            if (scale < minScale) {
                scale = minScale;
            }
        }
        // Zoom
        matrix.postScale(scale, scale);
        // Pan, pan the zoomed image to the center of the imageview
        //center x of imageView
        int midX = imageView.getWidth() / 2;
        //center y of imageView
        int midY = imageView.getHeight() / 2;
        //center x of bitmap
        int imageMidX = (int) (bitmap.getWidth() * scale / 2);
        //center y of bitmap
        int imageMidY = (int) (bitmap.getHeight() * scale / 2);
        matrix.postTranslate(midX - imageMidX, midY - imageMidY);
        imageView.setScaleType(ImageView.ScaleType.MATRIX);
        imageView.setImageMatrix(matrix);
        imageView.setImageBitmap(bitmap);
    }

    /**
     * Query image rotation angle
     */
    public static int getExifOrientation(String filepath) {// YOUR MEDIA PATH AS STRING
        int degree = 0;
        ExifInterface exif = null;
        try {
            exif = new ExifInterface(filepath);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        if (exif != null) {
            int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, -1);
            if (orientation != -1) {
                switch (orientation) {
                    case ExifInterface.ORIENTATION_ROTATE_90:
                        degree = 90;
                        break;
                    case ExifInterface.ORIENTATION_ROTATE_180:
                        degree = 180;
                        break;
                    case ExifInterface.ORIENTATION_ROTATE_270:
                        degree = 270;
                        break;
                }

            }
        }
        return degree;
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                savedMatrix.set(matrix);
                //Set starting point position
                start.set(event.getX(), event.getY());
                mode = DRAG;
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                //The distance between the two fingers when starting to put it down
                oldDist = spacing(event);
                if (oldDist > 10f) {
                    savedMatrix.set(matrix);
                    midPoint(mid, event);
                    mode = ZOOM;
                }
                break;
            case MotionEvent.ACTION_UP:
                break;
            case MotionEvent.ACTION_POINTER_UP:
                mode = NONE;
                break;
            case MotionEvent.ACTION_MOVE:
                if (mode == DRAG) { //drag
                    matrix.set(savedMatrix);
                    float dx = event.getX() - start.x;
                    float dy = event.getY() - start.y;
                    mVerticalPadding = clipView.getClipRect().top;
                    matrix.postTranslate(dx, dy);
                    //Check boundaries
                    checkBorder();
                } else if (mode == ZOOM) { //Zoom
                    //The distance between two fingers after zooming
                    float newDist = spacing(event);
                    if (newDist > 10f) {
                        //Gesture scaling
                        float scale = newDist / oldDist;
                        if (scale < 1) { //zoom out
                            if (getScale() > minScale) {
                                matrix.set(savedMatrix);
                                mVerticalPadding = clipView.getClipRect().top;
                                matrix.postScale(scale, scale, mid.x, mid.y);
                                //If zoomed below the minimum range, return to the minimum range size.
                                while (getScale() < minScale) {
                                    //Return to the minimum range magnification ratio
                                    scale = 1 + 0.01F;
                                    matrix.postScale(scale, scale, mid.x, mid.y);
                                }
                            }
                            //Boundary checking
                            checkBorder();
                        } else { //enlarge
                            if (getScale() <= maxScale) {
                                matrix.set(savedMatrix);
                                mVerticalPadding = clipView.getClipRect().top;
                                matrix.postScale(scale, scale, mid.x, mid.y);
                            }
                        }
                    }
                }
                imageView.setImageMatrix(matrix);
                break;
        }
        return true;
    }

    /**
     * Get the range of the image based on the Matrix of the current image
     */
    private RectF getMatrixRectF(Matrix matrix) {
        RectF rect = new RectF();
        Drawable d = imageView.getDrawable();
        if (null != d) {
            rect.set(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
            matrix.mapRect(rect);
        }
        return rect;
    }

    /**
     * Boundary detection
     */
    private void checkBorder() {
        RectF rect = getMatrixRectF(matrix);
        float deltaX = 0;
        float deltaY = 0;
        int width = imageView.getWidth();
        int height = imageView.getHeight();
        // If the width or height is larger than the screen, the control range is; the 0.001 here is because the loss of precision will cause problems, but the error is generally very small, so we directly add a 0.01
        if (rect.width() >= width - 2 * mHorizontalPadding) {
            if (rect.left > mHorizontalPadding) {
                deltaX = -rect.left + mHorizontalPadding;
            }
            if (rect.right < width - mHorizontalPadding) {
                deltaX = width - mHorizontalPadding - rect.right;
            }
        }
        if (rect.height() >= height - 2 * mVerticalPadding) {
            if (rect.top > mVerticalPadding) {
                deltaY = -rect.top + mVerticalPadding;
            }
            if (rect.bottom < height - mVerticalPadding) {
                deltaY = height - mVerticalPadding - rect.bottom;
            }
        }
        matrix.postTranslate(deltaX, deltaY);
    }

    /**
     * 获得当前的缩放比例
     */
    public final float getScale() {
        matrix.getValues(matrixValues);
        return matrixValues[Matrix.MSCALE_X];
    }


    /**
     * When multi-touching, calculate the distance between the first two fingers placed down.
     */
    private float spacing(MotionEvent event) {
        float x = event.getX(0) - event.getX(1);
        float y = event.getY(0) - event.getY(1);
        return (float) Math.sqrt(x * x + y * y);
    }

    /**
     * During multi-touch, calculate the center coordinates of the first two fingers placed down.
     */
    private void midPoint(PointF point, MotionEvent event) {
        float x = event.getX(0) + event.getX(1);
        float y = event.getY(0) + event.getY(1);
        point.set(x / 2, y / 2);
    }


    /**
     * Get cutout
     */
    public Bitmap clip() {
        imageView.setDrawingCacheEnabled(true);
        imageView.buildDrawingCache();
        Rect rect = clipView.getClipRect();
        Bitmap cropBitmap = null;
        Bitmap zoomedCropBitmap = null;
        try {
            cropBitmap = Bitmap.createBitmap(imageView.getDrawingCache(), rect.left, rect.top, rect.width(), rect.height());
            zoomedCropBitmap = zoomBitmap(cropBitmap, 200, 200);
        } catch (Exception e) {
            Log.e("printStackTrace","printStackTrace:$e");
        }
        if (cropBitmap != null) {
            cropBitmap.recycle();
        }
        // 释放资源
        imageView.destroyDrawingCache();
        return zoomedCropBitmap;
    }


    /**
     * Image compression
     *
     * @param filePath
     * @param reqWidth  expected width
     * @param reqHeight high expectations
     * @return
     */
    public static Bitmap decodeSampledBitmap(String filePath, int reqWidth,
                                             int reqHeight) {

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        //bitmap is null
        Bitmap bitmap = BitmapFactory.decodeFile(filePath, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth,
                reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(filePath, options);
    }

    /**
     * CalculateInSampleSize
     * The smaller value of a wide compression ratio and a high compression ratio takes a value close to a power of 2.
     * For example, the compression ratio of width is 3, the compression ratio of height is 5, take the smaller value 3, and InSampleSize must be the power of 2, take the closest power of 2 4
     *
     * @param options
     * @param reqWidth
     * @param reqHeight
     * @return
     */
    public static int calculateInSampleSize(BitmapFactory.Options options,
                                            int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            // Calculate ratios of height and width to requested height and
            // width
            final int heightRatio = Math.round((float) height
                    / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);

            // Choose the smallest ratio as inSampleSize value, this will
            // guarantee
            // a final image with both dimensions larger than or equal to the
            // requested height and width.
            int ratio = heightRatio < widthRatio ? heightRatio : widthRatio;
            // inSampleSize can only be a power of 2. Take ratio to the nearest power of 2.
            if (ratio < 3)
                inSampleSize = ratio;
            else if (ratio < 6.5)
                inSampleSize = 4;
            else if (ratio < 8)
                inSampleSize = 8;
            else
                inSampleSize = ratio;
        }

        return inSampleSize;
    }

    /**
     * Scale the image to the specified width and height
     * <p/>
     * If the image is not compressed proportionally, the image will be stretched.
     *
     * @param bitmap source bitmap object
     * @param w      width to scale
     * @param h      height to scale
     * @return New Bitmap object
     */
    public static Bitmap zoomBitmap(Bitmap bitmap, int w, int h) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        Matrix matrix = new Matrix();
        float scaleWidth = ((float) w / width);
        float scaleHeight = ((float) h / height);
        matrix.postScale(scaleWidth, scaleHeight);
        Bitmap newBmp = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, false);
        return newBmp;
    }


}
