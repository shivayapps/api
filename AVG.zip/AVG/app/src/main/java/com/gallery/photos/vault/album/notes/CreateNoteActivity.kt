package com.gallery.photos.vault.album.notes

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Patterns
import android.view.View
import android.widget.Toast
import com.gallery.photos.vault.album.R
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.gallery.photos.vault.album.notes.database.NotesDataBase
import com.gallery.photos.vault.album.databinding.ActivityCreateNoteBinding
import com.gallery.photos.vault.album.notes.entities.Notes
import com.gallery.photos.vault.album.notes.util.NoteBottomSheetFragment
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.Date

class CreateNoteActivity : AppCompatActivity(){
    var selectedColor = "#3e434e"
    var currentTime: String = ""

    // Permission Private Read & Write
    private var READ_STORAGE_PERM = 123
    private var REQUEST_CODE_IMAGE = 456

    private var webLink = ""
    private var selectedImagePath = ""

    private var noteId = -1

    private lateinit var binding: ActivityCreateNoteBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        noteId = intent.getIntExtra("noteId", -1)


        if (noteId != -1) {
            CoroutineScope(Dispatchers.IO).launch {

                var notes = NotesDataBase.getDataBase(this@CreateNoteActivity).noteDao().getSpecificNote(noteId)

                binding.colorView.setBackgroundColor(Color.parseColor(notes.color))

                binding.etNoteTitle.setText(notes.title)
                binding.etNoteDesc.setText(notes.noteText)


                if (notes.imgPath != "") {
                    selectedImagePath = notes.imgPath!!
                    binding.imgNote.setImageBitmap(BitmapFactory.decodeFile(notes.imgPath))
                    binding.layoutImage.visibility = View.VISIBLE
                    binding.imgNote.visibility = View.VISIBLE
                    binding.imgDelete.visibility = View.VISIBLE
                } else {
                    binding.layoutImage.visibility = View.GONE
                    binding.imgNote.visibility = View.GONE
                    binding.imgDelete.visibility = View.GONE
                }

                if (notes.webLink != "") {
                    webLink = notes.webLink!!
                    binding.tvWebLink.text = notes.webLink
                    binding.layoutWebUrl.visibility = View.VISIBLE
                    binding.imgUrlDelete.visibility = View.VISIBLE
                    binding.etWebLink.setText(notes.webLink)
                } else {
                    binding.imgUrlDelete.visibility = View.GONE
                    binding.layoutWebUrl.visibility = View.GONE
                }
            }
        }

        // Register & Unregister broadcast receiver
        LocalBroadcastManager.getInstance(this).registerReceiver(
            BroadcastReceiver, IntentFilter("bottom_sheet_action")
        )

        // Find View By ID
//        val tvDateTime = view.findViewById<TextView>(R.id.tvDateTime)
//        val imgDone = view.findViewById<ImageView>(R.id.imgDone)
//        val imgBack = view.findViewById<ImageView>(R.id.imgBack)

        binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))

        // Date & Time
        val sdf = SimpleDateFormat("dd-MM-yyyy")
        currentTime = sdf.format(Date())

        binding.txtTitle.text = currentTime

        // Done
        binding.imgDone.setOnClickListener {

            if (noteId != -1) {
                updateNote()
            } else {
                saveNote()
            }
        }

        // Back Button
        binding.icBack.setOnClickListener {
            onBackPressed()
        }

        // Show More Button
        binding.imgMore.setOnClickListener {
            val noteBottomSheetFragment = NoteBottomSheetFragment.newInstance(noteId)
            noteBottomSheetFragment.show(supportFragmentManager, noteBottomSheetFragment.tag)
        }

        // Delete Image
        binding.imgDelete.setOnClickListener {
            selectedImagePath = ""
            binding.layoutImage.visibility = View.GONE
        }

        binding.btnOk.setOnClickListener {
            if (binding.etWebLink.text.toString().trim().isNotEmpty()) {
                checkWebUrl()
            } else {
                Toast.makeText(this, "Url is Required", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnCancel.setOnClickListener {
            if (noteId != -1) {
                binding.tvWebLink.visibility = View.VISIBLE
                binding.layoutWebUrl.visibility = View.GONE
            } else {
                binding.layoutWebUrl.visibility = View.GONE
            }
        }

        binding.imgUrlDelete.setOnClickListener {
            webLink = ""
            binding.tvWebLink.visibility = View.GONE
            binding.imgUrlDelete.visibility = View.GONE
            binding.layoutWebUrl.visibility = View.GONE
        }

        binding.tvWebLink.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(binding.etWebLink.text.toString()))
            startActivity(intent)
        }

    }


    private fun updateNote(){

        CoroutineScope(Dispatchers.IO).launch {
            val notes = NotesDataBase.getDataBase(this@CreateNoteActivity).noteDao().getSpecificNote(noteId)

            notes.title = binding.etNoteTitle?.text.toString()
            notes.noteText = binding.etNoteDesc?.text.toString()
            notes.dateTime = currentTime
            notes.color = selectedColor
            notes.imgPath = selectedImagePath
            notes.webLink = webLink

            NotesDataBase.getDataBase(this@CreateNoteActivity).noteDao().updateNotes(notes)
            binding.etNoteTitle?.setText("")
            binding.etNoteDesc?.setText("")
            binding.layoutImage.visibility = View.GONE
            binding.imgNote.visibility = View.GONE
            binding.tvWebLink.visibility = View.GONE
            finish()

        }
    }

    private fun saveNote(){
        if (binding.etNoteTitle?.text.isNullOrEmpty()){
            Snackbar.make(binding.root, "Title is Required", Snackbar.LENGTH_LONG).setAction(getString(R.string.ok), View.OnClickListener { null }).show()
        }
        else if (binding.etNoteDesc?.text.isNullOrEmpty()){
            Snackbar.make(binding.root, "Notes Description Must Not Be Empty", Snackbar.LENGTH_LONG).setAction(getString(R.string.ok), View.OnClickListener { null }).show()
        }
        else {
            CoroutineScope(Dispatchers.IO).launch {
                var notes = Notes()
                notes.title = binding.etNoteTitle?.text.toString()
                notes.noteText = binding.etNoteDesc?.text.toString()
                notes.dateTime = currentTime
                notes.color = selectedColor
                notes.imgPath = selectedImagePath
                notes.webLink = webLink

                NotesDataBase.getDataBase(this@CreateNoteActivity).noteDao().insertNotes(notes)
                binding.etNoteTitle?.setText("")
                binding.etNoteDesc?.setText("")
                binding.layoutImage.visibility = View.GONE
                binding.imgNote.visibility = View.GONE
                binding.tvWebLink.visibility = View.GONE
                finish()
            }
        }

    }

    private fun deleteNote()  {
        CoroutineScope(Dispatchers.IO).launch {
            NotesDataBase.getDataBase(this@CreateNoteActivity).noteDao().deleteSpecificNote(noteId)
            finish()
        }
    }

    private fun checkWebUrl() {
        if (Patterns.WEB_URL.matcher(binding.etWebLink.text.toString()).matches()) {
            binding.layoutWebUrl.visibility = View.GONE
            binding.etWebLink.isEnabled = false
            webLink = binding.etWebLink.text.toString()
            binding.tvWebLink.visibility = View.VISIBLE
            binding.tvWebLink.text = binding.etWebLink.text.toString()
        } else {
            Toast.makeText(this, "Url is not Valid", Toast.LENGTH_SHORT).show()
        }
    }

    private val BroadcastReceiver : BroadcastReceiver = object :  BroadcastReceiver() {
        override fun onReceive(p0: Context?, p1: Intent?) {

            val actionColor = p1!!.getStringExtra("action")
            when(actionColor!!){

                "Blue" -> {
                    selectedColor = p1.getStringExtra("selectedColor")!!
                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                }

                "Cyan" -> {
                    selectedColor = p1.getStringExtra("selectedColor")!!
                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                }

                "Green" -> {
                    selectedColor = p1.getStringExtra("selectedColor")!!
                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                }

                "Orange" -> {
                    selectedColor = p1.getStringExtra("selectedColor")!!
                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                }

                "Purple" -> {
                    selectedColor = p1.getStringExtra("selectedColor")!!
                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                }

                "Red" -> {
                    selectedColor = p1.getStringExtra("selectedColor")!!
                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                }

                "Yellow" -> {
                    selectedColor = p1.getStringExtra("selectedColor")!!
                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                }

                "Brown" -> {
                    selectedColor = p1.getStringExtra("selectedColor")!!
                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                }

                "Indigo" -> {
                    selectedColor = p1.getStringExtra("selectedColor")!!
                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                }

                "Image" -> {
                    pickImageFromGallery()
                    binding.layoutWebUrl.visibility = View.GONE
                }

                "WebUrl" -> {
                    binding.layoutWebUrl.visibility = View.VISIBLE
                }

                "DeleteNote" -> {
                    deleteNote()
                }

                else -> {
                    binding.layoutImage.visibility = View.GONE
                    binding.imgNote.visibility = View.GONE
                    binding.layoutWebUrl.visibility = View.GONE
                    selectedColor = p1.getStringExtra("selectedColor")!!
                    binding.colorView.setBackgroundColor(Color.parseColor(selectedColor))
                }

            }

        }
    }



    private fun pickImageFromGallery() {
        var intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        if (intent.resolveActivity(packageManager) != null) {
            startActivityForResult(intent, REQUEST_CODE_IMAGE)
        }
    }

    private fun getPathFromUri(contentUri : Uri): String? {
        var filePath : String? = null
        var cursor = contentResolver.query(contentUri, null, null, null, null)
        if (cursor == null) {
            filePath = contentUri.path
        } else {
            cursor.moveToFirst()
            var index = cursor.getColumnIndex("_data")
            filePath = cursor.getString(index)
            cursor.close()
        }
        return filePath
    }

    // Setup About Image
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_CODE_IMAGE && resultCode == RESULT_OK) {
            if (data != null) {

                var selectedImageUrl = data.data

                if (selectedImageUrl != null) {
                    try {

                        var inputStream = contentResolver.openInputStream(selectedImageUrl)
                        var bitmap = BitmapFactory.decodeStream(inputStream)
                        binding.imgNote.setImageBitmap(bitmap)
                        binding.imgNote.visibility = View.VISIBLE
                        binding.layoutImage.visibility = View.VISIBLE

                        selectedImagePath = getPathFromUri(selectedImageUrl)!!

                    }catch (e: Exception) {
                        Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(BroadcastReceiver)
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

}