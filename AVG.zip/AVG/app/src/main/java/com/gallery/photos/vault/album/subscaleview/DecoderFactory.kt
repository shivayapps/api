package com.gallery.photos.vault.album.subscaleview

interface DecoderFactory<T> {
    fun make(): T
}
