package com.gallery.photos.vault.album.mainduplicate

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.AnimRes
import androidx.annotation.AnimatorRes
import androidx.annotation.RequiresApi
import androidx.annotation.UiThread
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.ActivityOptionsCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.util.Pair
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.OutputStream
import java.util.*
import java.util.regex.Pattern

import kotlinx.coroutines.launch
import java.io.InputStream
import kotlin.collections.ArrayList

abstract class BaseSimpleActivity : AppCompatActivity() {
    var copyMoveCallback: ((destinationPath: String) -> Unit)? = null
    var actionOnPermission: ((granted: Boolean) -> Unit)? = null
    var isAskingPermissions = false
    var isAskingPermissionsActionNull = false
    var useDynamicTheme = true
    var showTransparentTop = false
    var checkedDocumentPath = ""
    var configItemsToExport = LinkedHashMap<String, Any>()
    var mRequestCode: Int = 0

    val launcher: ActivityResultLauncher<Intent> =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result: ActivityResult ->
            fromActivityResult(
                requestCode = mRequestCode,
                resultCode = result.resultCode,
                resultData = result.data
            )
        }

    val GENERIC_PERM_HANDLER = 100

    companion object {
        var funAfterSAFPermission: ((success: Boolean) -> Unit)? = null
    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onStop() {
        super.onStop()
        actionOnPermission = null
    }

    override fun onDestroy() {
//        notificationManager.cancelAll()
        super.onDestroy()
        funAfterSAFPermission = null
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

//    override fun attachBaseContext(newBase: Context) {
//        if (newBase.baseConfig.useEnglish) {
//            super.attachBaseContext(MyContextWrapper(newBase).wrap(newBase, "en"))
//        } else {
//            super.attachBaseContext(newBase)
//        }
//    }



    private fun isRootUri(uri: Uri) = DocumentsContract.getTreeDocumentId(uri).endsWith(":")

    private fun isInternalStorage(uri: Uri) = isExternalStorageDocument(uri) && DocumentsContract.getTreeDocumentId(uri).contains("primary")

    private fun isExternalStorageDocument(uri: Uri) = "com.android.externalstorage.documents" == uri.authority



    fun checkPermissionabove11(): Boolean {

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Log.e("TAG", "onCreate:SDK_INT    " + Build.VERSION.SDK_INT)
            Environment.isExternalStorageManager()
        } else {
            val result = ContextCompat.checkSelfPermission(
                this,
                "android.permission.MANAGE_EXTERNAL_STORAGE"
            )
            val result1 =
                ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE")
            result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        isAskingPermissions = false
        if (requestCode == GENERIC_PERM_HANDLER && grantResults.isNotEmpty()) {
            actionOnPermission?.invoke(grantResults[0] == 0)
            if (actionOnPermission == null)
                isAskingPermissionsActionNull = true
        }
    }

    open fun launchActivityForResult(
        fIntent: Intent,
        fRequestCode: Int,
        @AnimatorRes @AnimRes fEnterAnimId: Int = android.R.anim.fade_in,
        @AnimatorRes @AnimRes fExitAnimId: Int = android.R.anim.fade_out
    ) {
        mRequestCode = fRequestCode
        launcher.launch(
            fIntent,
            ActivityOptionsCompat.makeCustomAnimation(this, fEnterAnimId, fExitAnimId)
        )
    }

    /**
     * This Method will replace your default method of [onActivityResult]
     *
     * @param requestCode The integer request code originally supplied to launchActivityForResult(), allowing you to identify who this result came from.
     * @param resultCode The integer result code returned by the child activity through its setResult().
     * @param data An Intent, which can return result data to the caller (various data can be attached to Intent "extras").
     */
    @UiThread
    open fun fromActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        val partition = try {
            checkedDocumentPath.substring(9, 18)
        } catch (e: Exception) {
            ""
        }
//        val sdOtgPattern = Pattern.compile(SD_OTG_SHORT)
//
//        if (requestCode == OPEN_DOCUMENT_TREE) {
//            if (resultCode == Activity.RESULT_OK && resultData != null && resultData.data != null) {
//                val isProperPartition = partition.isEmpty() || !sdOtgPattern.matcher(partition).matches() || (sdOtgPattern.matcher(partition).matches() && resultData.dataString!!.contains(partition))
//                if (isProperSDFolder(resultData.data!!) && isProperPartition) {
//                    if (resultData.dataString == baseConfig.OTGTreeUri) {
//                        toast(R.string.sd_card_usb_same)
//                        return
//                    }
//
//                    saveTreeUri(resultData)
//                    funAfterSAFPermission?.invoke(true)
//                    funAfterSAFPermission = null
//                } else {
//                    toast(R.string.wrong_root_selected)
//                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
//                    launchActivityForResult(intent, requestCode)
//                }
//            } else {
//                funAfterSAFPermission?.invoke(false)
//            }
//        } else if (requestCode == OPEN_DOCUMENT_TREE_OTG) {
//            if (resultCode == Activity.RESULT_OK && resultData != null && resultData.data != null) {
//                val isProperPartition = partition.isEmpty() || !sdOtgPattern.matcher(partition).matches() || (sdOtgPattern.matcher(partition).matches() && resultData.dataString!!.contains(partition))
//                if (isProperOTGFolder(resultData.data!!) && isProperPartition) {
//                    if (resultData.dataString == baseConfig.treeUri) {
//                        funAfterSAFPermission?.invoke(false)
//                        toast(R.string.sd_card_usb_same)
//                        return
//                    }
//                    baseConfig.OTGTreeUri = resultData.dataString!!
//                    baseConfig.OTGPartition = baseConfig.OTGTreeUri.removeSuffix("%3A").substringAfterLast('/').trimEnd('/')
//                    updateOTGPathFromPartition()
//
//                    val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
//                    applicationContext.contentResolver.takePersistableUriPermission(resultData.data!!, takeFlags)
//
//                    funAfterSAFPermission?.invoke(true)
//                    funAfterSAFPermission = null
//                } else {
//                    toast(R.string.wrong_root_selected_usb)
//                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
//                    launchActivityForResult(intent, requestCode)
//                }
//            } else {
//                funAfterSAFPermission?.invoke(false)
//            }
//        } else if (requestCode == SELECT_EXPORT_SETTINGS_FILE_INTENT && resultCode == Activity.RESULT_OK && resultData != null && resultData.data != null) {
//            val outputStream = contentResolver.openOutputStream(resultData.data!!)
//            exportSettingsTo(outputStream, configItemsToExport)
//        }
    }


}
