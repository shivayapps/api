package com.gallery.photos.vault.album.mainduplicate.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions;
import com.gallery.photos.vault.album.mainduplicate.model.DuplicateFoundAndSize;
import com.gallery.photos.vault.album.mainduplicate.model.IndividualGroupModel;
import com.gallery.photos.vault.album.mainduplicate.model.ItemDuplicateModel;
import com.gallery.photos.vault.album.mainduplicate.model.Md5Model;

import java.util.ArrayList;
import java.util.List;

import static com.gallery.photos.vault.album.mainduplicate.utils.MyUtils.logError;


public class DBHandler extends SQLiteOpenHelper {
    public static int totalNumberOfDuplicatesAudios = 0;
    public static int totalNumberOfDuplicatesAudiosForNotification = 0;
    public static int totalNumberOfDuplicatesDocuments = 0;
    public static int totalNumberOfDuplicatesDocumentsForNotification = 0;
    public static int totalNumberOfDuplicatesOthers = 0;
    public static int totalNumberOfDuplicatesOthersForNotification = 0;
    public static int totalNumberOfDuplicatesPhotos = 0;
    public static int totalNumberOfDuplicatesPhotosForNotification = 0;
    public static int totalNumberOfDuplicatesVideos = 0;
    public static int totalNumberOfDuplicatesVideosForNotification = 0;
    public int groupTagMediaAudios = 0;
    public int groupTagMediaDocuments = 0;
    public int groupTagMediaOthers = 0;
    public int groupTagMediaPhotos = 0;
    public int groupTagMediaVideos = 0;

    public DBHandler(Context context) {
        super(context, GlobalVarsAndFunctions.DATABASE_NAME, null, 1);
    }

    public void onCreate(SQLiteDatabase db) {
        logError("MD5 database Created");
        db.execSQL("CREATE TABLE allFilesInfoTable( md5 TEXT, path TEXT, extension TEXT)");
        db.execSQL("CREATE TABLE allFilesInfoTableNotification( md5 TEXT, path TEXT, extension TEXT)");
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        logError("MD5 database updated");
        db.execSQL("DROP TABLE IF EXISTS allFilesInfoTable");
        db.execSQL("DROP TABLE IF EXISTS allFilesInfoTableNotification");
        onCreate(db);
    }

    public void addMd5ValueOfFiles(Md5Model md5Model) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GlobalVarsAndFunctions.KEY_MD5, md5Model.getMd5Value());
        values.put(GlobalVarsAndFunctions.KEY_PATH, md5Model.getFilePath());
        values.put(GlobalVarsAndFunctions.KEY_EXTENSION, md5Model.getExtension().toLowerCase());
        db.insert(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO, null, values);
        db.close();
    }

    public void addMd5ValueOfFilesForNotification(Md5Model md5Model) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GlobalVarsAndFunctions.KEY_MD5, md5Model.getMd5Value());
        values.put(GlobalVarsAndFunctions.KEY_PATH, md5Model.getFilePath());
        values.put(GlobalVarsAndFunctions.KEY_EXTENSION, md5Model.getExtension().toLowerCase());
        db.insert(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO_NOTIFICATION, null, values);
        db.close();
    }

    public void getDuplicateFiles(Context context, String sqlQuery, String md5, String extension) {
        String toLowerCase = extension.toLowerCase();
        Log.e("TAG", "groupDuplicateAccordingToFormats: hashcode --> " + toLowerCase.hashCode());
        int obj = -1;
        switch (toLowerCase.hashCode()) {
            case 1422702:
                if (toLowerCase.equals(GlobalVarsAndFunctions.GP3)) {
                    obj = 31;
                    break;
                }
                break;
            case 44103874:
                if (toLowerCase.equals(GlobalVarsAndFunctions.GP33)) {
                    obj = 55;
                    break;
                }
                break;
            case 1436279:
                if (toLowerCase.equals(GlobalVarsAndFunctions.ABMP)) {
                    obj = 7;
                    break;
                }
                break;
            case 1444051:
                if (toLowerCase.equals(GlobalVarsAndFunctions.AJPG)) {
                    obj = 1;
                    break;
                }
                break;
            case 1447973:
                if (toLowerCase.equals(GlobalVarsAndFunctions.NRW)) {
                    obj = 23;
                    break;
                }
                break;
            case 1449755:
                if (toLowerCase.equals(GlobalVarsAndFunctions.APNG)) {
                    obj = 5;
                    break;
                }
                break;
            case 1466709:
                if (toLowerCase.equals(GlobalVarsAndFunctions.AAC)) {
                    obj = 35;
                    break;
                }
                break;
            case 1467270:
                if (toLowerCase.equals(GlobalVarsAndFunctions.ASF)) {
                    obj = 30;
                    break;
                }
                break;
            case 1467366:
                if (toLowerCase.equals(GlobalVarsAndFunctions.AVI)) {
                    obj = 34;
                    break;
                }
                break;
            case 1468055:
                if (toLowerCase.equals(GlobalVarsAndFunctions.BMP)) {
                    obj = 6;
                    break;
                }
                break;
            case 1468858:
                if (toLowerCase.equals(GlobalVarsAndFunctions.CHM)) {
                    obj = 52;
                    break;
                }
                break;
            case 1469109:
                if (toLowerCase.equals(GlobalVarsAndFunctions.CR2)) {
                    obj = 18;
                    break;
                }
                break;
            case 1469113:
                if (toLowerCase.equals(GlobalVarsAndFunctions.CPT)) {
                    obj = 13;
                    break;
                }
                break;
            case 1469178:
                if (toLowerCase.equals(GlobalVarsAndFunctions.CRW)) {
                    obj = 17;
                    break;
                }
                break;
            case 1469208:
                if (toLowerCase.equals(GlobalVarsAndFunctions.CSV)) {
                    obj = 48;
                    break;
                }
                break;
            case 1469999:
                if (toLowerCase.equals(GlobalVarsAndFunctions.DNG)) {
                    obj = 21;
                    break;
                }
                break;
            case 1470026:
                if (toLowerCase.equals(GlobalVarsAndFunctions.DOC)) {
                    obj = 42;
                    break;
                }
                break;
            case 1470278:
                if (toLowerCase.equals(GlobalVarsAndFunctions.DWG)) {
                    obj = 14;
                    break;
                }
                break;
            case 1472726:
                if (toLowerCase.equals(GlobalVarsAndFunctions.GIF)) {
                    obj = 12;
                    break;
                }
                break;
            case 1475827:
                if (toLowerCase.equals(GlobalVarsAndFunctions.JPG)) {
                    obj = 0;
                    break;
                }
                break;
            case 1476412:
                if (toLowerCase.equals(GlobalVarsAndFunctions.KDC)) {
                    obj = 22;
                    break;
                }
                break;
            case 1476844:
                if (toLowerCase.equals(GlobalVarsAndFunctions.M4A)) {
                    obj = 38;
                    break;
                }
                break;
            case 1476865:
                if (toLowerCase.equals(GlobalVarsAndFunctions.M4V)) {
                    obj = 32;
                    break;
                }
                break;
            case 1478658:
                if (toLowerCase.equals(GlobalVarsAndFunctions.MP3)) {
                    obj = 36;
                    break;
                }
                break;
            case 1478659:
                if (toLowerCase.equals(GlobalVarsAndFunctions.MP4)) {
                    obj = 26;
                    break;
                }
                break;
            case 1478694:
                if (toLowerCase.equals(GlobalVarsAndFunctions.MOV)) {
                    obj = 33;
                    break;
                }
                break;
            case 1480693:
                if (toLowerCase.equals(GlobalVarsAndFunctions.ORF)) {
                    obj = 24;
                    break;
                }
                break;
            case 1481187:
                if (toLowerCase.equals(GlobalVarsAndFunctions.PCD)) {
                    obj = 15;
                    break;
                }
                break;
            case 1481220:
                if (toLowerCase.equals(GlobalVarsAndFunctions.PDF)) {
                    obj = 40;
                    break;
                }
                break;
            case 1481372:
                if (toLowerCase.equals(GlobalVarsAndFunctions.PIC)) {
                    obj = 11;
                    break;
                }
                break;
            case 1481531:
                if (toLowerCase.equals(GlobalVarsAndFunctions.PNG)) {
                    obj = 4;
                    break;
                }
                break;
            case 1481606:
                if (toLowerCase.equals(GlobalVarsAndFunctions.PPT)) {
                    obj = 46;
                    break;
                }
                break;
            case 1481683:
                if (toLowerCase.equals(GlobalVarsAndFunctions.PSD)) {
                    obj = 10;
                    break;
                }
                break;
            case 1483066:
                if (toLowerCase.equals(GlobalVarsAndFunctions.RAW)) {
                    obj = 19;
                    break;
                }
                break;
            case 1483638:
                if (toLowerCase.equals(GlobalVarsAndFunctions.RTF)) {
                    obj = 51;
                    break;
                }
                break;
            case 1484485:
                if (toLowerCase.equals(GlobalVarsAndFunctions.SR2)) {
                    obj = 25;
                    break;
                }
                break;
            case 1484537:
                if (toLowerCase.equals(GlobalVarsAndFunctions.SRF)) {
                    obj = 20;
                    break;
                }
                break;
            case 1485219:
                if (toLowerCase.equals(GlobalVarsAndFunctions.TIF)) {
                    obj = 9;
                    break;
                }
                break;
            case 1485698:
                if (toLowerCase.equals(GlobalVarsAndFunctions.TXT)) {
                    obj = 41;
                    break;
                }
                break;
            case 1487870:
                if (toLowerCase.equals(GlobalVarsAndFunctions.WAV)) {
                    obj = 39;
                    break;
                }
                break;
            case 1488221:
                if (toLowerCase.equals(GlobalVarsAndFunctions.WMA)) {
                    obj = 37;
                    break;
                }
                break;
            case 1488242:
                if (toLowerCase.equals(GlobalVarsAndFunctions.WMV)) {
                    obj = 27;
                    break;
                }
                break;
            case 1488320:
                if (toLowerCase.equals(GlobalVarsAndFunctions.WPG)) {
                    obj = 16;
                    break;
                }
                break;
            case 1489169:
                if (toLowerCase.equals(GlobalVarsAndFunctions.XLS)) {
                    obj = 45;
                    break;
                }
                break;
            case 1489170:
                if (toLowerCase.equals(GlobalVarsAndFunctions.XLT)) {
                    obj = 49;
                    break;
                }
                break;
            case 44765590:
                if (toLowerCase.equals(GlobalVarsAndFunctions.AJPEG)) {
                    obj = 3;
                    break;
                }
                break;
            case 45565749:
                if (toLowerCase.equals(GlobalVarsAndFunctions.DIVX)) {
                    obj = 29;
                    break;
                }
                break;
            case 45570926:
                if (toLowerCase.equals(GlobalVarsAndFunctions.DOCX)) {
                    obj = 43;
                    break;
                }
                break;
            case 45750678:
                if (toLowerCase.equals(GlobalVarsAndFunctions.JPEG)) {
                    obj = 2;
                    break;
                }
                break;
            case 45929906:
                if (toLowerCase.equals(GlobalVarsAndFunctions.PPTX)) {
                    obj = 47;
                    break;
                }
                break;
            case 46041891:
                if (toLowerCase.equals(GlobalVarsAndFunctions.TIFF)) {
                    obj = 8;
                    break;
                }
                break;
            case 46164359:
                if (toLowerCase.equals(GlobalVarsAndFunctions.XLSX)) {
                    obj = 44;
                    break;
                }
                break;
            case 46164390:
                if (toLowerCase.equals(GlobalVarsAndFunctions.XLTX)) {
                    obj = 50;
                    break;
                }
                break;
            case 46173639:
                if (toLowerCase.equals(GlobalVarsAndFunctions.XVID)) {
                    obj = 28;
                    break;
                }
                break;
            case 1478570:
                if (toLowerCase.equals(GlobalVarsAndFunctions.MKV)) {
                    obj = 53;
                    break;
                }
            case 46127306:
                if (toLowerCase.equals(GlobalVarsAndFunctions.WEBP)) {
                    obj = 54;
                    break;
                }
            case 45680645:
                if (toLowerCase.equals(GlobalVarsAndFunctions.HEIC)) {
                    obj = 56;
                    break;
                }
        }

        switch (obj) {
            case 0:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.JPG, md5);
                return;
            case 1:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.AJPG, md5);
                return;
            case 2:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.JPEG, md5);
                return;
            case 3:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.AJPEG, md5);
                return;
            case 4:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.PNG, md5);
                return;
            case 5:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.APNG, md5);
                return;
            case 6:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.BMP, md5);
                return;
            case 7:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.ABMP, md5);
                return;
            case 8:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.TIFF, md5);
                return;
            case 9:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.TIF, md5);
                return;
            case 10:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.PSD, md5);
                return;
            case 11:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.PIC, md5);
                return;
            case 12:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.GIF, md5);
                return;
            case 13:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.CPT, md5);
                return;
            case 14:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.DWG, md5);
                return;
            case 15:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.PCD, md5);
                return;
            case 16:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.WPG, md5);
                return;
            case 17:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.CRW, md5);
                return;
            case 18:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.CR2, md5);
                return;
            case 19:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.RAW, md5);
                return;
            case 20:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.SRF, md5);
                return;
            case 21:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.DNG, md5);
                return;
            case 22:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.KDC, md5);
                return;
            case 23:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.NRW, md5);
                return;
            case 24:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.ORF, md5);
                return;
            case 25:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.SR2, md5);
                return;
            case 26:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.VIDEOS, GlobalVarsAndFunctions.MP4, md5);
                return;
            case 27:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.VIDEOS, GlobalVarsAndFunctions.WMV, md5);
                return;
            case 28:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.VIDEOS, GlobalVarsAndFunctions.XVID, md5);
                return;
            case 29:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.VIDEOS, GlobalVarsAndFunctions.DIVX, md5);
                return;
            case 30:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.VIDEOS, GlobalVarsAndFunctions.ASF, md5);
                return;
            case 31:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.VIDEOS, GlobalVarsAndFunctions.GP3, md5);
                return;
            case 32:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.VIDEOS, GlobalVarsAndFunctions.M4V, md5);
                return;
            case 33:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.VIDEOS, GlobalVarsAndFunctions.MOV, md5);
                return;
            case 34:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.VIDEOS, GlobalVarsAndFunctions.AVI, md5);
                return;
            case 35:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.AUDIOS, GlobalVarsAndFunctions.AAC, md5);
                return;
            case 36:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.AUDIOS, GlobalVarsAndFunctions.MP3, md5);
                return;
            case 37:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.AUDIOS, GlobalVarsAndFunctions.WMA, md5);
                return;
            case 38:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.AUDIOS, GlobalVarsAndFunctions.M4A, md5);
                return;
            case 39:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.AUDIOS, GlobalVarsAndFunctions.WAV, md5);
                return;
            case 40:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.DOCUMENTS, GlobalVarsAndFunctions.PDF, md5);
                return;
            case 41:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.DOCUMENTS, GlobalVarsAndFunctions.TXT, md5);
                return;
            case 42:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.DOCUMENTS, GlobalVarsAndFunctions.DOC, md5);
                return;
            case 43:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.DOCUMENTS, GlobalVarsAndFunctions.DOCX, md5);
                return;
            case 44:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.DOCUMENTS, GlobalVarsAndFunctions.XLSX, md5);
                return;
            case 45:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.DOCUMENTS, GlobalVarsAndFunctions.XLS, md5);
                return;
            case 46:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.DOCUMENTS, GlobalVarsAndFunctions.PPT, md5);
                return;
            case 47:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.DOCUMENTS, GlobalVarsAndFunctions.PPTX, md5);
                return;
            case 48:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.DOCUMENTS, GlobalVarsAndFunctions.CSV, md5);
                return;
            case 49:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.DOCUMENTS, GlobalVarsAndFunctions.XLT, md5);
                return;
            case 50:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.DOCUMENTS, GlobalVarsAndFunctions.XLTX, md5);
                return;
            case 51:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.DOCUMENTS, GlobalVarsAndFunctions.RTF, md5);
                return;
            case 52:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.DOCUMENTS, GlobalVarsAndFunctions.CHM, md5);
                return;
            case 53:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.VIDEOS, GlobalVarsAndFunctions.MKV, md5);
                return;
            case 54:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.WEBP, md5);
                return;
            case 55:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.VIDEOS, GlobalVarsAndFunctions.GP33, md5);
                return;
            case 56:
                getDuplicatesFromTable(context, sqlQuery, GlobalVarsAndFunctions.PHOTOS, GlobalVarsAndFunctions.HEIC, md5);
                return;
            default:
                if (GlobalVarsAndFunctions.getFileName(extension.toLowerCase()).startsWith(".")) {
                    GlobalVarsAndFunctions.uniqueOthersExtensionBeforeDuplicates.add(extension.toLowerCase());
                    GlobalVarsAndFunctions.uniqueOtherExtensionsMap.put(md5, extension.toLowerCase());
                    GlobalVarsAndFunctions.notificationUniqueOtherExtensionsMap.put(md5, extension.toLowerCase());
                    return;
                }
                return;
        }
    }

    private void groupTheExtensions(String md5, String extension) {
        if (GlobalVarsAndFunctions.getListOfPhotosExtensions().contains(extension.toLowerCase())) {
            GlobalVarsAndFunctions.uniquePhotosExtension.add(extension.toLowerCase());
        } else if (GlobalVarsAndFunctions.getListOfVideosExtensions().contains(extension.toLowerCase())) {
            GlobalVarsAndFunctions.uniqueVideosExtension.add(extension.toLowerCase());
        } else if (GlobalVarsAndFunctions.getListOfAudiosExtensions().contains(extension.toLowerCase())) {
            GlobalVarsAndFunctions.uniqueAudiosExtension.add(extension.toLowerCase());
        } else if (GlobalVarsAndFunctions.getListOfDocumentsExtensions().contains(extension.toLowerCase())) {
            GlobalVarsAndFunctions.uniqueDocumentsExtension.add(extension.toLowerCase());
        } else {
            GlobalVarsAndFunctions.uniqueOthersExtensionAfterDuplicates.add(extension.toLowerCase());
        }
    }

    public void getDuplicatesFromTable(Context context, String sqlQuery, String typeOfFile, String extension, String md5) {
        int obj = -1;
        switch (typeOfFile.hashCode()) {
            case -1406804131:
                if (typeOfFile.equals(GlobalVarsAndFunctions.AUDIOS)) {
                    obj = 2;
                    break;
                }
                break;
            case -1006804125:
                if (typeOfFile.equals(GlobalVarsAndFunctions.OTHERS)) {
                    obj = 4;
                    break;
                }
                break;
            case -989034367:
                if (typeOfFile.equals(GlobalVarsAndFunctions.PHOTOS)) {
                    obj = 0;
                    break;
                }
                break;
            case -816678056:
                if (typeOfFile.equals(GlobalVarsAndFunctions.VIDEOS)) {
                    obj = 1;
                    break;
                }
                break;
            case 943542968:
                if (typeOfFile.equals(GlobalVarsAndFunctions.DOCUMENTS)) {
                    obj = 3;
                    break;
                }
                break;
        }
        switch (obj) {
            case 0:
                List<ItemDuplicateModel> duplicatePhotosFilesSet = individualGroupPhotos(sqlQuery, GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO);
                if (duplicatePhotosFilesSet.size() > 1) {
                    groupTheExtensions(md5, extension);
                    IndividualGroupModel individualGroupPhotos = new IndividualGroupModel();
                    individualGroupPhotos.setCheckBox(true);
                    individualGroupPhotos.setGroupExtension(extension.toLowerCase());
                    individualGroupPhotos.setGroupTag(this.groupTagMediaPhotos);
                    individualGroupPhotos.setIndividualGrpOfDupes(duplicatePhotosFilesSet);
                    GlobalVarsAndFunctions.listOfGroupedDuplicatesPhotos.add(individualGroupPhotos);
                    return;
                }
                return;
            case 1:
                List<ItemDuplicateModel> duplicateVideosFilesSet = individualGroupVideos(context, sqlQuery, GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO);
                if (duplicateVideosFilesSet.size() > 1) {
                    groupTheExtensions(md5, extension);
                    IndividualGroupModel individualGroupVideos = new IndividualGroupModel();
                    individualGroupVideos.setCheckBox(true);
                    individualGroupVideos.setGroupExtension(extension.toLowerCase());
                    individualGroupVideos.setGroupTag(this.groupTagMediaVideos);
                    individualGroupVideos.setIndividualGrpOfDupes(duplicateVideosFilesSet);
                    GlobalVarsAndFunctions.listOfGroupedDuplicatesVideos.add(individualGroupVideos);
                    return;
                }
                return;
            case 2:
                List<ItemDuplicateModel> duplicateAudioFilesSet = individualGroupAudios(context, sqlQuery, GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO);
                if (duplicateAudioFilesSet.size() > 1) {
                    groupTheExtensions(md5, extension);
                    IndividualGroupModel individualGroupAudios = new IndividualGroupModel();
                    individualGroupAudios.setCheckBox(true);
                    individualGroupAudios.setGroupExtension(extension.toLowerCase());
                    individualGroupAudios.setGroupTag(this.groupTagMediaAudios);
                    individualGroupAudios.setIndividualGrpOfDupes(duplicateAudioFilesSet);
                    GlobalVarsAndFunctions.listOfGroupedDuplicatesAudios.add(individualGroupAudios);
                    return;
                }
                return;
            case 3:
                List<ItemDuplicateModel> duplicateDocumentsFilesSet = individualGroupDocuments(sqlQuery, GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO);
                if (duplicateDocumentsFilesSet.size() > 1) {
                    groupTheExtensions(md5, extension);
                    IndividualGroupModel individualGroupDocuments = new IndividualGroupModel();
                    individualGroupDocuments.setCheckBox(true);
                    individualGroupDocuments.setGroupExtension(extension.toLowerCase());
                    individualGroupDocuments.setGroupTag(this.groupTagMediaDocuments);
                    individualGroupDocuments.setIndividualGrpOfDupes(duplicateDocumentsFilesSet);
                    GlobalVarsAndFunctions.listOfGroupedDuplicatesDocument.add(individualGroupDocuments);
                    return;
                }
                return;
            case 4:
                List<ItemDuplicateModel> duplicateOthersFilesSet = individualGroupOthers(sqlQuery);
                if (duplicateOthersFilesSet.size() > 1) {
                    groupTheExtensions(md5, extension);
                    IndividualGroupModel individualGroupOthers = new IndividualGroupModel();
                    individualGroupOthers.setCheckBox(true);
                    individualGroupOthers.setGroupExtension(extension.toLowerCase());
                    individualGroupOthers.setGroupTag(this.groupTagMediaOthers);
                    individualGroupOthers.setIndividualGrpOfDupes(duplicateOthersFilesSet);
                    GlobalVarsAndFunctions.listOfGroupedDuplicatesOthers.add(individualGroupOthers);
                    return;
                }
                return;
            default:
                return;
        }
    }

    private List<ItemDuplicateModel> individualGroupPhotos(String sqlQuery, String tableName) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        List<ItemDuplicateModel> list = new ArrayList<>();
        if (sqlQuery != null) {
            try {
                int totalDuplicates;
                cursor = db.rawQuery(sqlQuery, null);
                if (tableName.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                    totalDuplicates = totalNumberOfDuplicatesPhotos;
                } else {
                    totalDuplicates = totalNumberOfDuplicatesPhotosForNotification;
                }
                int leaveOriginalImageSize = 0;
                if (cursor != null && cursor.getCount() > 1) {
                    this.groupTagMediaPhotos++;
                    if (cursor.moveToFirst()) {
                        do {
                            logError(" photos Path: " + cursor.getString(0) + " Extension: " + cursor.getString(1));
                            if (leaveOriginalImageSize != 0) {
                                if (tableName.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                                    totalDuplicates = totalNumberOfDuplicatesPhotos();
                                } else {
                                    totalNumberOfDuplicatesPhotosForNotification++;
                                    totalDuplicates = totalNumberOfDuplicatesPhotosForNotification;
                                }
                            }
                            leaveOriginalImageSize++;
                            ItemDuplicateModel imageItem = new ItemDuplicateModel();
                            imageItem.setFilePath(cursor.getString(0));
                            imageItem.setFileCheckBox(true);
                            imageItem.setFilePosition(leaveOriginalImageSize);
                            imageItem.setFileItemGrpTag(this.groupTagMediaPhotos);
                            imageItem.setSizeOfTheFile(GlobalVarsAndFunctions.getFileSize(cursor.getString(0)));
                            imageItem.setImageResolution(GlobalVarsAndFunctions.getImageResolution(cursor.getString(0)));
                            imageItem.setFileDateAndTime(GlobalVarsAndFunctions.getDateAndTime(cursor.getString(0)));
                            list.add(imageItem);
                        } while (cursor.moveToNext());
                    }
                    cursor.close();
                    if (tableName.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                        DuplicateFoundAndSize.setTotalDuplicatePhotos(totalDuplicates);
                    }
                }
            } catch (Exception e) {
                if (db != null) {
                    db.close();
                }
                if (cursor != null) {
                    cursor.close();
                }
            } catch (Throwable th) {
                if (db != null) {
                    db.close();
                }
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        if (db != null) {
            db.close();
        }
        if (cursor != null) {
            cursor.close();
        }
        return list;
    }

    private List<ItemDuplicateModel> individualGroupVideos(Context context, String sqlQuery, String tableName) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        List<ItemDuplicateModel> list = new ArrayList<>();
        if (sqlQuery != null) {
            try {
                int totalDuplicates;
                cursor = db.rawQuery(sqlQuery, null);
                if (tableName.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                    totalDuplicates = totalNumberOfDuplicatesVideos;
                } else {
                    totalDuplicates = totalNumberOfDuplicatesVideosForNotification;
                }
                int leaveOriginalVideoSize = 0;
                if (cursor != null && cursor.getCount() > 1) {
                    this.groupTagMediaVideos++;
                    if (cursor.moveToFirst()) {
                        do {
                            logError(" Video Path: " + cursor.getString(0));
                            if (leaveOriginalVideoSize != 0) {
                                if (tableName.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                                    totalDuplicates = totalNumberOfDuplicatesVideos();
                                } else {
                                    totalNumberOfDuplicatesVideosForNotification++;
                                    totalDuplicates = totalNumberOfDuplicatesVideosForNotification;
                                }
                            }
                            leaveOriginalVideoSize++;
                            ItemDuplicateModel videoItem = new ItemDuplicateModel();
                            videoItem.setFilePath(cursor.getString(0));
                            videoItem.setFileCheckBox(true);
                            videoItem.setFilePosition(leaveOriginalVideoSize);
                            videoItem.setFileItemGrpTag(this.groupTagMediaVideos);
                            videoItem.setSizeOfTheFile(GlobalVarsAndFunctions.getFileSize(cursor.getString(0)));
                            videoItem.setFileDuration(GlobalVarsAndFunctions.getVideoDuration(context, cursor.getString(0)));
                            videoItem.setFileDateAndTime(GlobalVarsAndFunctions.getDateAndTime(cursor.getString(0)));
                            list.add(videoItem);
                        } while (cursor.moveToNext());
                    }
                    cursor.close();
                    if (tableName.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                        DuplicateFoundAndSize.setTotalDuplicateVideos(totalDuplicates);
                    }
                }
            } catch (Exception e) {
                if (db != null) {
                    db.close();
                }
                if (cursor != null) {
                    cursor.close();
                }
            } catch (Throwable th) {
                if (db != null) {
                    db.close();
                }
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        if (db != null) {
            db.close();
        }
        if (cursor != null) {
            cursor.close();
        }
        return list;
    }

    private List<ItemDuplicateModel> individualGroupAudios(Context context, String sqlQuery, String tableName) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        List<ItemDuplicateModel> list = new ArrayList<>();
        if (sqlQuery != null) {
            try {
                int totalDuplicates;
                cursor = db.rawQuery(sqlQuery, null);
                if (tableName.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                    totalDuplicates = totalNumberOfDuplicatesAudios;
                } else {
                    totalDuplicates = totalNumberOfDuplicatesAudiosForNotification;
                }
                int leaveOriginalAudioSize = 0;
                if (cursor != null && cursor.getCount() > 1) {
                    this.groupTagMediaAudios++;
                    if (cursor.moveToFirst()) {
                        do {
                            logError(" Audio's Path: " + cursor.getString(0));
                            if (leaveOriginalAudioSize != 0) {
                                if (tableName.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                                    totalDuplicates = totalNumberOfDuplicatesAudios();
                                } else {
                                    totalNumberOfDuplicatesAudiosForNotification++;
                                    totalDuplicates = totalNumberOfDuplicatesAudiosForNotification;
                                }
                            }
                            leaveOriginalAudioSize++;
                            ItemDuplicateModel audioItem = new ItemDuplicateModel();
                            audioItem.setFilePath(cursor.getString(0));
                            audioItem.setFileCheckBox(true);
                            audioItem.setFilePosition(leaveOriginalAudioSize);
                            audioItem.setFileItemGrpTag(this.groupTagMediaAudios);
                            audioItem.setSizeOfTheFile(GlobalVarsAndFunctions.getFileSize(cursor.getString(0)));
                            audioItem.setFileDuration(GlobalVarsAndFunctions.getVideoDuration(context, cursor.getString(0)));
                            audioItem.setFileDateAndTime(GlobalVarsAndFunctions.getDateAndTime(cursor.getString(0)));
                            list.add(audioItem);
                        } while (cursor.moveToNext());
                    }
                    cursor.close();
                    if (tableName.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                        DuplicateFoundAndSize.setTotalDuplicateAudios(totalDuplicates);
                    }
                }
            } catch (Exception e) {
                if (db != null) {
                    db.close();
                }
                if (cursor != null) {
                    cursor.close();
                }
            } catch (Throwable th) {
                if (db != null) {
                    db.close();
                }
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        if (db != null) {
            db.close();
        }
        if (cursor != null) {
            cursor.close();
        }
        return list;
    }

    private List<ItemDuplicateModel> individualGroupDocuments(String sqlQuery, String tableName) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        List<ItemDuplicateModel> list = new ArrayList<>();
        if (sqlQuery != null) {
            try {
                int totalDuplicates;
                cursor = db.rawQuery(sqlQuery, null);
                if (tableName.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                    totalDuplicates = totalNumberOfDuplicatesDocuments;
                } else {
                    totalDuplicates = totalNumberOfDuplicatesDocumentsForNotification;
                }
                int leaveOriginalDocumentSize = 0;
                if (cursor != null && cursor.getCount() > 1) {
                    this.groupTagMediaDocuments++;
                    if (cursor.moveToFirst()) {
                        do {
                            logError(" Document's Path: " + cursor.getString(0));
                            if (leaveOriginalDocumentSize != 0) {
                                if (tableName.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                                    totalDuplicates = totalNumberOfDuplicatesDocuments();
                                } else {
                                    totalNumberOfDuplicatesDocumentsForNotification++;
                                    totalDuplicates = totalNumberOfDuplicatesDocumentsForNotification;
                                }
                            }
                            leaveOriginalDocumentSize++;
                            ItemDuplicateModel documentItem = new ItemDuplicateModel();
                            documentItem.setFilePath(cursor.getString(0));
                            documentItem.setFileCheckBox(true);
                            documentItem.setFilePosition(leaveOriginalDocumentSize);
                            documentItem.setFileItemGrpTag(this.groupTagMediaDocuments);
                            documentItem.setSizeOfTheFile(GlobalVarsAndFunctions.getFileSize(cursor.getString(0)));
                            documentItem.setFileDateAndTime(GlobalVarsAndFunctions.getDateAndTime(cursor.getString(0)));
                            list.add(documentItem);
                        } while (cursor.moveToNext());
                    }
                    cursor.close();
                    if (tableName.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                        DuplicateFoundAndSize.setTotalDuplicateDocuments(totalDuplicates);
                    }
                }
            } catch (Exception e) {
                if (db != null) {
                    db.close();
                }
                if (cursor != null) {
                    cursor.close();
                }
            } catch (Throwable th) {
                if (db != null) {
                    db.close();
                }
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        if (db != null) {
            db.close();
        }
        if (cursor != null) {
            cursor.close();
        }
        return list;
    }

    private List<ItemDuplicateModel> individualGroupOthers(String sqlQuery) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        List<ItemDuplicateModel> list = new ArrayList<>();
        if (sqlQuery != null) {
            try {
                int totalDuplicates;
                cursor = db.rawQuery(sqlQuery, null);
                if (GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                    totalDuplicates = totalNumberOfDuplicatesOthers;
                } else {
                    totalDuplicates = totalNumberOfDuplicatesOthersForNotification;
                }
                int leaveOriginalOtherSize = 0;
                if (cursor != null && cursor.getCount() > 1) {
                    this.groupTagMediaOthers++;
                    if (cursor.moveToFirst()) {
                        do {
                            logError(" Other's Path: " + cursor.getString(0));
                            if (leaveOriginalOtherSize != 0) {
                                if (GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                                    totalDuplicates = totalNumberOfDuplicatesOthers();
                                } else {
                                    totalNumberOfDuplicatesOthersForNotification++;
                                    totalDuplicates = totalNumberOfDuplicatesOthersForNotification;
                                }
                            }
                            leaveOriginalOtherSize++;
                            ItemDuplicateModel otherItem = new ItemDuplicateModel();
                            otherItem.setFilePath(cursor.getString(0));
                            otherItem.setFileCheckBox(true);
                            otherItem.setFilePosition(leaveOriginalOtherSize);
                            otherItem.setFileItemGrpTag(this.groupTagMediaOthers);
                            otherItem.setSizeOfTheFile(GlobalVarsAndFunctions.getFileSize(cursor.getString(0)));
                            otherItem.setFileDateAndTime(GlobalVarsAndFunctions.getDateAndTime(cursor.getString(0)));
                            list.add(otherItem);
                        } while (cursor.moveToNext());
                    }
                    cursor.close();
                    if (GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO.equals(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO)) {
                        DuplicateFoundAndSize.setTotalDuplicateOthers(totalDuplicates);
                    }
                }
            } catch (Exception e) {
                if (db != null) {
                    db.close();
                }
                if (cursor != null) {
                    cursor.close();
                }
            } catch (Throwable th) {
                db.close();
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        if (db != null) {
            db.close();
        }
        if (cursor != null) {
            cursor.close();
        }
        return list;
    }

    public void clearAllFilesInfoTable() {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO, null, null);
    }

    private int totalNumberOfDuplicatesPhotos() {
        totalNumberOfDuplicatesPhotos++;
        return totalNumberOfDuplicatesPhotos;
    }

    private int totalNumberOfDuplicatesVideos() {
        totalNumberOfDuplicatesVideos++;
        return totalNumberOfDuplicatesVideos;
    }

    private int totalNumberOfDuplicatesAudios() {
        totalNumberOfDuplicatesAudios++;
        return totalNumberOfDuplicatesAudios;
    }

    private int totalNumberOfDuplicatesDocuments() {
        totalNumberOfDuplicatesDocuments++;
        return totalNumberOfDuplicatesDocuments;
    }

    private int totalNumberOfDuplicatesOthers() {
        totalNumberOfDuplicatesOthers++;
        return totalNumberOfDuplicatesOthers;
    }


}
