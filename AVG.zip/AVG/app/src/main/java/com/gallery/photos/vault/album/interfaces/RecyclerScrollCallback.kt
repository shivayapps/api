package com.gallery.photos.vault.album.interfaces

interface RecyclerScrollCallback {
    fun onScrolled(scrollY: Int)
}
