package com.gallery.photos.vault.album.browser.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photos.vault.album.browser.model.WebBrowserData
import com.gallery.photos.vault.album.databinding.BrowserItemLayoutBinding

class BrowserDataAdapter(
    var browserDataList: ArrayList<WebBrowserData>,
    var context: Context,
    val clickListener: (pos: Int) -> Unit
) : RecyclerView.Adapter<BrowserDataAdapter.MyViewHolder>() {
    inner class MyViewHolder(var binding: BrowserItemLayoutBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(
            BrowserItemLayoutBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return browserDataList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        with(holder.binding) {
            with(browserDataList[position]) {
                ivImage.setImageResource(imageIcon)
                tvName.text = title
                holder.itemView.setOnClickListener {
                    clickListener(position)

//                    if (title == context.getString(R.string.instagram) || title == context.getString(
//                            R.string.facebook
//                        )
//                    ) {
//                        context.startActivity(
//                            Intent(
//                                context,
//                                BrowserDownloadActivity::class.java
//                            ).putExtra(Constant.PUT_KEY_URL, urls)
//                                .putExtra(
//                                    Constant.EXTRA_TYPE,
//                                    if (title == context.getString(R.string.instagram)) Constant.TYPE_Insta else Constant.TYPE_FB
//                                )
//                        )
//                    } else
//                        context.startActivity(
//                            Intent(
//                                context,
//                                BrowserActivity::class.java
//                            ).putExtra(Constant.PUT_KEY_URL, urls)
//                        )
                }
            }
        }
    }
}