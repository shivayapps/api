package com.gallery.photos.vault.album.secret.fragment

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import com.andrognito.patternlockview.PatternLockView
import com.andrognito.patternlockview.listener.PatternLockViewListener
import com.andrognito.patternlockview.utils.PatternLockUtils
//import com.google.firebase.analytics.FirebaseAnalytics
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.databinding.FragmentLockBinding
import com.gallery.photos.vault.album.dialog.ResetStyleDialog
import com.gallery.photos.vault.album.dialog.SecurityQuestionDialog
import com.gallery.photos.vault.album.secret.activity.PrivateActivity
import com.gallery.photos.vault.album.secret.activity.ResetLockActivity
import com.gallery.photos.vault.album.utils.Constant
import com.gallery.photos.vault.album.utils.Preferences

class LockFragment(
    var activity: Activity
//    , private val isOpenPrivate: Boolean = false
    ,
    private val isResetPass: Boolean = false,
    private val isChangePass: Boolean = false,
    val lockListener: (icUnLock: Boolean) -> Unit
) : Fragment() {

    lateinit var binding: FragmentLockBinding
    lateinit var preferences: Preferences
    var temp = 0
    var passcode = ""
    var isForgotPassOpen = false
    var isShowPinLock = false
    lateinit var animation: Animation


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLockBinding.inflate(layoutInflater, container, false)
        preferences = Preferences(activity)
        isShowPinLock = preferences.getShowPINLock()
        animation = AnimationUtils.loadAnimation(activity, R.anim.anim_shake)
        intView()
        initListener()


        return binding.root
    }

    private fun setErrorAnimation(view: View) {
        view.startAnimation(animation)
    }

    fun changeLockStyle() {
        isShowPinLock = preferences.getShowPINLock()
        Log.e("LockFragment", "changeLockStyle:$isShowPinLock")
        intView()
    }

    fun intView() {
        if (::binding.isInitialized) {

            temp = 0
            passcode = ""
            binding.pass.setText("")
            binding.patterLockView.clearPattern()

            setLockViewUpdate()

            if (isChangePass) {
                binding.title.text =
                    if (isShowPinLock) getString(R.string.enter_your_current_PIN) else getString(R.string.draw_your_current_pattern)
                temp = -1
                binding.forgot.visibility = View.GONE
                binding.btnSwitch.visibility = View.GONE
            } else {
                if (isShowPinLock) {
                    if (preferences.getSetPass()) {
                        binding.title.text = getString(R.string.enter_your_PIN)
                        binding.forgot.visibility = View.VISIBLE
                        binding.btnSwitch.visibility = View.GONE
                    } else {
                        binding.title.text = getString(R.string.set_your_PIN)
                        binding.forgot.visibility = View.GONE
                        binding.btnSwitch.visibility = View.VISIBLE
                    }
                } else {
                    if (preferences.getSetPattern()) {
                        binding.title.text = getString(R.string.draw_your_pattern)
                        binding.forgot.visibility = View.VISIBLE
                        binding.btnSwitch.visibility = View.GONE
                    } else {
                        binding.title.text = getString(R.string.draw_an_unlock_pattern)
                        binding.forgot.visibility = View.GONE
                        binding.btnSwitch.visibility = View.VISIBLE
                    }
                }
            }
        }
    }


    private fun setLockViewUpdate() {
        if (isShowPinLock) {
            binding.patterLockView.visibility = View.GONE
            binding.tvErrorMsg.visibility = View.GONE
            binding.loutPinNumber.visibility = View.VISIBLE
            binding.loutPinDots.visibility = View.VISIBLE
            binding.txtSwitch.text = getString(R.string.switch_to_pattern)

        } else {
            binding.patterLockView.visibility = View.VISIBLE
            binding.tvErrorMsg.visibility = View.INVISIBLE
            binding.loutPinNumber.visibility = View.INVISIBLE
            binding.loutPinDots.visibility = View.GONE
            binding.txtSwitch.text = getString(R.string.switch_to_pin)
        }
    }

    private fun initListener() {
        binding.btnSwitch.setOnClickListener {
            isShowPinLock = !isShowPinLock
            intView()
        }

        binding.forgot.setOnClickListener {
            isForgotPassOpen = true
            setQuestion(1)
        }
        binding.btnNo0.setOnClickListener {
            binding.pass.setText(binding.pass.text.toString().trim() + "0")
        }
        binding.btnNo1.setOnClickListener {
            binding.pass.setText(
                binding.pass.text.toString().trim() + "1"
            )
        }
        binding.btnNo2.setOnClickListener {
            binding.pass.setText(
                binding.pass.text.toString().trim() + "2"
            )
        }
        binding.btnNo3.setOnClickListener {
            binding.pass.setText(
                binding.pass.text.toString().trim() + "3"
            )
        }
        binding.btnNo4.setOnClickListener {
            binding.pass.setText(
                binding.pass.text.toString().trim() + "4"
            )
        }
        binding.btnNo5.setOnClickListener {
            binding.pass.setText(
                binding.pass.text.toString().trim() + "5"
            )
        }
        binding.btnNo6.setOnClickListener {
            binding.pass.setText(
                binding.pass.text.toString().trim() + "6"
            )
        }
        binding.btnNo7.setOnClickListener {
            binding.pass.setText(
                binding.pass.text.toString().trim() + "7"
            )
        }
        binding.btnNo8.setOnClickListener {
            binding.pass.setText(
                binding.pass.text.toString().trim() + "8"
            )
        }
        binding.btnNo9.setOnClickListener {
            binding.pass.setText(
                binding.pass.text.toString().trim() + "9"
            )
        }

        binding.clear.setOnClickListener {
            if (binding.pass.text.isNotEmpty()) {
                binding.pass.setText(
                    binding.pass.text.toString().substring(0, binding.pass.length() - 1)
                )
                binding.pass.setSelection(binding.pass.text.length)
            }
        }

        binding.patterLockView.addPatternLockListener(object : PatternLockViewListener {
            override fun onStarted() {
                Log.d("TAGPATTERN", "onStarted ")
                binding.tvErrorMsg.visibility = View.INVISIBLE
            }

            override fun onProgress(progressPattern: MutableList<PatternLockView.Dot>?) {

            }

            override fun onComplete(pattern: MutableList<PatternLockView.Dot>?) {
                val strPattern = PatternLockUtils.patternToString(binding.patterLockView, pattern)
                Log.d(
                    "TAGPATTERN", "Pattern complete: $strPattern"
                )
                if (strPattern.length < 4)
                    setPatterErrorMsg(getString(R.string.patter_validation))
                else
                    setNextPatternScreen(strPattern)

            }

            override fun onCleared() {
                Log.d("TAGPATTERN", "onCleared ")
            }
        })

        binding.pass.addTextChangedListener {
            val length = it?.length
            when (length) {
                0 -> {
                    unSelectDot(binding.p1)
                    unSelectDot(binding.p2)
                    unSelectDot(binding.p3)
                    unSelectDot(binding.p4)
                }

                1 -> {
                    selectDot(binding.p1)
                    unSelectDot(binding.p2)
                    unSelectDot(binding.p3)
                    unSelectDot(binding.p4)
                }

                2 -> {
                    selectDot(binding.p1)
                    selectDot(binding.p2)
                    unSelectDot(binding.p3)
                    unSelectDot(binding.p4)
                }

                3 -> {
                    selectDot(binding.p1)
                    selectDot(binding.p2)
                    selectDot(binding.p3)
                    unSelectDot(binding.p4)
                }

                4 -> {
                    selectDot(binding.p1)
                    selectDot(binding.p2)
                    selectDot(binding.p3)
                    selectDot(binding.p4)
                }
            }
            if (length == 4) {
                setNextScreen()
            }
        }
    }

    private fun setNextPatternScreen(strPattern: String) {
        if (!preferences.getSetPattern() || (isChangePass && temp != -1)) {
            if (temp == 0) {
                passcode = strPattern
                temp = 1
                binding.patterLockView.setViewMode(PatternLockView.PatternViewMode.CORRECT)
                Handler(Looper.myLooper()!!).postDelayed({
                    binding.title.text =
                        if (isChangePass) getString(R.string.draw_confirm_new_pattern) else
                            getString(R.string.draw_pattern_again)
                    binding.patterLockView.clearPattern()
                }, 20)
            } else {
                if (passcode == strPattern) {
                    Log.e("LockFragment", "pattern_change_successfully-002")
                    preferences.putPattern(passcode)
                    binding.patterLockView.setViewMode(PatternLockView.PatternViewMode.CORRECT)
                    Toast.makeText(
                        activity,
                        if (isChangePass) getString(R.string.pattern_change_successfully) else getString(
                            R.string.pattern_set_successfully
                        ),
                        Toast.LENGTH_SHORT
                    ).show()
                    setPasswordSuccess()
                } else
                    setPatterErrorMsg(getString(R.string.pattern_not_match))

            }
        } else {
            if (preferences.getPattern() == strPattern) {
                binding.patterLockView.setViewMode(PatternLockView.PatternViewMode.CORRECT)
                if (isChangePass) {
                    Handler(Looper.myLooper()!!).postDelayed({
                        temp = 0
                        binding.title.text = getString(R.string.draw_your_new_pattern)
                        binding.patterLockView.clearPattern()
                    }, 30)
                } else
                    setPasswordSuccess()
            } else {
                setPatterErrorMsg(getString(R.string.pattern_not_match))
            }
        }
    }

    private fun setPatterErrorMsg(errorMsg: String) {
        binding.patterLockView.setViewMode(PatternLockView.PatternViewMode.WRONG)
        binding.tvErrorMsg.visibility = View.VISIBLE
        binding.tvErrorMsg.text = errorMsg
        setErrorAnimation(binding.tvErrorMsg)
    }

    private fun setNextScreen() {
        if (!preferences.getSetPass() || (isChangePass && temp != -1)) {
            if (temp == 0) {
                passcode = binding.pass.text.trim().toString()
                temp = 1
                Handler(Looper.myLooper()!!).postDelayed({
                    binding.title.text =
                        if (isChangePass) getString(R.string.confirm_your_new_PIN) else getString(R.string.confirm_your_PIN)
                    binding.pass.setText("")
                }, 30)
            } else {
                if (passcode == binding.pass.text.trim().toString()) {
                    preferences.putPass(passcode)
                    Toast.makeText(
                        activity,
                        if (isChangePass) getString(R.string.PIN_change_successfully) else getString(
                            R.string.PIN_set_successfully
                        ),
                        Toast.LENGTH_SHORT
                    ).show()
                    if (isShowPinLock)
                        preferences.putSetPass(true)
                    else
                        preferences.putSetPattern(true)

                    setPasswordSuccess()
                } else {
                    Handler(Looper.myLooper()!!).postDelayed({
                        binding.pass.setText("")
                    }, 30)
                    Toast.makeText(
                        activity,
                        R.string.PIN_not_match,
                        Toast.LENGTH_SHORT
                    ).show()
                    setErrorAnimation(binding.loutPinDots)
                }
            }
        } else {
            if (preferences.getPass() == binding.pass.text.trim().toString()) {
                if (isChangePass) {
                    Handler(Looper.myLooper()!!).postDelayed({
                        temp = 0
                        binding.title.text = getString(R.string.enter_your_new_PIN)
                        binding.pass.setText("")
                    }, 30)
                } else
                    setPasswordSuccess()
            } else {
                Handler(Looper.myLooper()!!).postDelayed({
                    binding.pass.setText("")
                }, 30)
                Toast.makeText(
                    activity,
                    R.string.wrong_PIN,
                    Toast.LENGTH_SHORT
                ).show()
                setErrorAnimation(binding.loutPinDots)
            }
        }
    }

    private fun setPasswordSuccess() {
        Log.e("LockFragment", "setPasswordSuccess")
        if (isResetPass) {
            if (isShowPinLock)
                preferences.putSetPass(true)
            else
                preferences.putSetPattern(true)
            preferences.putSetQuestion(true)
        }
        preferences.putShowPinLock(isShowPinLock)

        Log.e("LockFragment", "getIgnoreQuestion:${preferences.getIgnoreQuestion()}")
        if (preferences.getIgnoreQuestion()) {
            lockListener(true)
        } else {
            setQuestion(0)
        }
    }

    var resetLockResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            val intent = Intent(activity, PrivateActivity::class.java)
            startActivity(intent)
            lockListener.invoke(false)
        } else {
            Log.e("LockFragment", "lockActivityResultLauncher:intView")
        }
    }

//    var lockActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
//        ActivityResultContracts.StartActivityForResult()
//    ) { result: ActivityResult ->
//        if (result.resultCode == AppCompatActivity.RESULT_OK) {
//            Log.e("LockFragment", "lockActivityResultLauncher:$isForgotPassOpen")
//
//                if (isForgotPassOpen) {
//                    isForgotPassOpen = false
//                    changeLockStyle()
//                } else {
//                    lockListener(true)
//                }
//
//
//        } else {
//            Log.e("LockFragment", "lockActivityResultLauncher:intView")
//            if(preferences.securityEmail.isEmpty()) {
//                preferences.putSetPass(false)
//                preferences.putShowPinLock(true)
//                preferences.putSetPattern(false)
//            }
//            intView()
//        }
//    }


//    private fun setQuestion(pos: Int) {
//        val intent = Intent(activity, SecurityQuestionActivity::class.java)
//        intent.putExtra(Constant.EXTRA_OPEN_TYPE_QUE, pos)
//        intent.putExtra(Constant.EXTRA_IS_OPEN_PRIVATE, isOpenPrivate)
//        lockActivityResultLauncher.launch(intent)
//    }


    private fun setQuestion(pos: Int) {
        Log.e("LockFragment", "setQuestion:$pos")
        if (pos == 1) {
            val resetStyleDialog =
                ResetStyleDialog(activity, methodListener = {
//                    if (it == 1) {
//                        val clientMail = preferences.securityEmail
//                        val progressDialog =
//                            ProgressDialog(activity, ProgressDialog.THEME_DEVICE_DEFAULT_DARK)
//                        progressDialog.show()
////                        MailUtil.requestOtp(activity,clientMail, subject, content, mailListener = {
//                        MailUtil.requestOtp(activity, mailListener = {
//                            progressDialog.dismiss()
//                            if (it) {
//                                activity.toast("Reset password send to $clientMail")
//                                val intent = Intent(activity, OtpActivity::class.java)
//                                activity.startActivity(intent)
//                                lockListener.invoke(false)
//                            } else {
//                                activity.toast("Something went wron please try again latter.")
//                            }
//                        })
//
//                    } else if (it == 2) {
                        val securityQuestionDialog =
                            SecurityQuestionDialog(activity, type = 1, updateListener = {
                                if (it) {
                                    preferences.putSetPass(false)
                                    preferences.putShowPinLock(true)
                                    preferences.putSetPattern(false)
                                    resetLockResultLauncher.launch(
                                        Intent(
                                            activity,
                                            ResetLockActivity::class.java
                                        ).putExtra(Constant.EXTRA_RESET_PASS, true)
                                    )
                                }
                            })
                        securityQuestionDialog.show(
                            childFragmentManager,
                            securityQuestionDialog.tag
                        )
//                    }
                })
            resetStyleDialog.show(childFragmentManager, resetStyleDialog.tag)
        } else {
            lockListener.invoke(true)
//            if (preferences.securityEmail.isEmpty()) {
//                val intent = Intent(activity, SecurityEmailActivity::class.java)
//                lockActivityResultLauncher.launch(intent)
//            } else
//                lockListener.invoke(true)

        }
    }

    private fun unSelectDot(image: AppCompatImageView) {
        image.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_pass_dot_unfill))
    }

    private fun selectDot(image: AppCompatImageView) {
        image.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_pass_dot_fill))
    }


}