package com.gallery.photos.vault.album.caller


//class SetupFragmentReceiver : BroadcastReceiver(), DatePickerDialog.OnDateSetListener,
//    TimePickerDialog.OnTimeSetListener {
//
//    private lateinit var mContext: Context
//    private var currentDay = 0
//    private var currentMonth = 0
//    private var currentYear = 0
//    private var currentHour = 0
//    private var currentMinute = 0
//
//    private var savedDay = 0
//    private var savedMonth = 0
//    private var savedYear = 0
//    private var savedHour = 0
//    private var savedMinute = 0
//
//    private val colorAdapter: ColorAdapter by lazy {
//        ColorAdapter(object : ColorAdapter.ClickListeners {
//            override fun onClick(color: String) {
//
//            }
//        })
//    }
//
//    override fun onReceive(context: Context, intent: Intent) {
//        Log.d("CallerActivity", "onReceive:SetupFragmentReceiver:${intent.action}")
//
//        if (intent.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
//            this.mContext = context
//            val preferences = Preferences(context)
//            Log.d("CallerActivity", "preferences.isShowCallInfo:${preferences.isShowCallInfo}")
//            if (preferences.isShowCallInfo) {
//                when (intent.getStringExtra(TelephonyManager.EXTRA_STATE)) {
//                    TelephonyManager.EXTRA_STATE_IDLE -> {
//
//                        // Phone is in an idle state (no calls)
//                        Log.d("CallerActivity", "Phone is idle 1")
//                        if (isWindowShowing) {
//                            floatWindowLayoutParam?.windowAnimations = R.style.enterAnim
//
//                            val animSlideIn = AnimatorSet()
//                            animSlideIn.playTogether(
//                                ObjectAnimator.ofFloat(binding?.root, "translationX", 100f)
//                            )
//                            animSlideIn.duration = 5000
//                            animSlideIn.start()
//                            if (Settings.canDrawOverlays(mContext)) {
//                                floatWindowLayoutParam?.let {
//                                    windowManager?.updateViewLayout(
//                                        binding?.root,
//                                        it
//                                    )
//                                }
//                            }
//
//
//                            stopCounter()
//                            if (Settings.canDrawOverlays(mContext)) {
//                                windowManager?.removeViewImmediate(binding!!.root)
//                            }
//
//                            subView =
//                                LayoutInflater.from(mContext).inflate(
//                                   com.gallery.photos.vault.album.R.layout.layout_gallery,
//                                    null
//                                )
//
////                            customEvent("callercad_open")
////                            val pref = AppPreferences(context)
//                            if (!preferences.isCallLog){
//                                preferences.isCallLog=true
////                                customCallerEvent(todayDate())
//                                Log.d("CallerActivity", "onReceive: customCallerEvent ${todayDate()}")
//                            }
//
//
//                            val mIntent = Intent(mContext, CallerActivity::class.java)
//                            mIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
//                            mIntent.putExtra("fromwhere", "ser")
//                            mContext.startActivity(mIntent)
//
//                            isWindowShowing = false
//                        }
//                    }
//
//                    TelephonyManager.EXTRA_STATE_RINGING -> {
//
////                        val serviceIntent = Intent(
////                            context,
////                            PhoneStateForegroundService::class.java
////                        )
////                        context.startService(serviceIntent)
//
//                        // Phone is ringing
//                        Log.d("CallerActivity", "Phone is ringing 1")
//                        if (!isWindowShowing) {
//
//                            /*
//                                                        context?.startActivity(Intent(context, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK))
//                            */
//
//                            displayWindow(CallState.STATE_RINGING)
//                            val calendar = Calendar.getInstance()
//                            val hourOfDay = calendar.get(Calendar.HOUR_OF_DAY)
//                            val minute = calendar.get(Calendar.MINUTE)
//                            callStartTime = "$hourOfDay:$minute"
//                            isWindowShowing = true
//                        }
//                    }
//
//                    TelephonyManager.EXTRA_STATE_OFFHOOK -> {
//
//                        // Phone is in an off-hook state (call in progress)
//                        Log.d("CallerActivity", "Call in progress 1")
//                        if (!isWindowShowing) {
//                            displayWindow(CallState.STATE_OFFHOOK)
//                            if (callStartTime == "") {
//                                val calendar = Calendar.getInstance()
//                                val hourOfDay = calendar.get(Calendar.HOUR_OF_DAY)
//                                val minute = calendar.get(Calendar.MINUTE)
//                                callStartTime = "$hourOfDay:$minute"
//                            }
//                            isWindowShowing = true
//                        }
//                    }
//                }
//            }
//        }
//    }
//
//    private fun todayDate(): String {
//        val today: LocalDate = LocalDate.now()
//        val formatter: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
//        return today.format(formatter)
//    }
//
//    private fun displayWindow(state: CallState) {
//        val metrics = mContext.resources.displayMetrics
//        val height = metrics.heightPixels
//
//
//        windowManager = mContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
////        floatView = LayoutInflater.from(mContext).inflate(R.layout.overlay_layout, null)
//        binding = OverlayLayoutBinding.inflate(LayoutInflater.from(mContext))
////        binding!!.root.setBackgroundDrawable(null)
//
//        val layoutFlag =
//            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
//
//        floatWindowLayoutParam = WindowManager.LayoutParams(
//            WindowManager.LayoutParams.WRAP_CONTENT,
//            WindowManager.LayoutParams.WRAP_CONTENT,
//            layoutFlag,
//            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
//                    or WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
//                    or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
//                    or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
//            PixelFormat.TRANSLUCENT
//        )
//
////        floatWindowLayoutParam = WindowManager.LayoutParams(
////            WindowManager.LayoutParams.MATCH_PARENT,
////            WindowManager.LayoutParams.MATCH_PARENT,
////            layoutFlag,
////            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
////                    or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
////                    or WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS
////                    or WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION,
////            PixelFormat.TRANSLUCENT
////        )
//
//        if (isWindowShowing) {
//            if (Settings.canDrawOverlays(mContext)) {
//                windowManager?.removeViewImmediate(binding!!.root)
//            }
//        }
//
//        floatWindowLayoutParam?.gravity = Gravity.RIGHT
//        floatWindowLayoutParam?.windowAnimations = R.style.enterAnim
//        floatWindowLayoutParam?.x = 0
//        floatWindowLayoutParam?.y = height / 5
//
//        val animSlideIn = AnimatorSet()
//        animSlideIn.playTogether(
//            ObjectAnimator.ofFloat(binding!!.root, "translationX", 0f),
//            ObjectAnimator.ofFloat(binding!!.root, "translationY", 0f)
//        )
//        animSlideIn.duration = 5000
//        animSlideIn.start()
//
//        val space = ItemSpace()
//        val adapter = TaskListAdapter()
//
//        val colorList =
//            arrayListOf("#6044CC", "#9285CA", "#6F9DFF", "#C0985B", "#FF9798", "#CC8245", "#0CCA98")
//        val formatter = DateTimeFormatter.ofPattern("E, d MMM")
//        val today = LocalDate.now()
//        val tomorrow = today.plusDays(1)
//        val datesList = generateDateList(today, 28, formatter, today, tomorrow)
//
//        val hourList = generateHourList()
//        val currentHour = java.time.LocalDateTime.now().hour
//        val currentHourPosition = hourList.indexOf(currentHour.toString())
//        Log.d("CallerActivity", "onViewCreated: currentHour => $currentHourPosition")
//
//        val minuteList = generateTimeIntervals()
//        val currentMinute = java.time.LocalDateTime.now().minute
//        val currentMinutePosition = minuteList.indexOf(currentMinute.toString())
//        Log.d("CallerActivity", "onViewCreated: currentMinute => $currentMinutePosition")
//
//        binding?.layoutReminder?.datePicker?.data = datesList
//        binding?.layoutReminder?.hourPicker?.data = hourList
//        binding?.layoutReminder?.minutesPicker?.data = minuteList
//
////        binding.hourPicker.setSelectedItemPosition(currentHourPosition, true)
////        binding.minutesPicker.setSelectedItemPosition(currentMinutePosition, true)
//
//        binding?.layoutReminder?.hourPicker?.selectedItemPosition
//
//        binding?.layoutReminder?.recyclerView?.addItemDecoration(space)
//        binding?.layoutReminder?.recyclerView?.adapter = adapter
////        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
//
//        colorAdapter.submitList(colorList)
//        binding?.layoutReminder?.mRVColor?.adapter = colorAdapter
//
//
////        val taskDao = TaskDatabase.getDatabase(mContext).taskDao()
////        val repository = TaskRepository(taskDao)
////        val task = repository.allTasksList
//////
////        adapter.submitList(task)
//
//        setMessageView(mContext)
//        binding!!.layoutMessage.root.visibility = View.GONE
//        binding!!.layoutMessage.imgCloseMessage.visibility = View.VISIBLE
//
//        val audioManager = mContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
//        if (audioManager.isMicrophoneMute)
//            binding?.imgMute?.setImageResource(R.drawable.ic_window_mic_on)
//        else
//            binding?.imgMute?.setImageResource(R.drawable.ic_window_mic_off)
//
//        binding?.mIVUser?.setOnClickListener {
//            binding!!.constraintMain.layoutTransition.enableTransitionType(LayoutTransition.CHANGING)
//            if (binding?.linearOption?.orientation == LinearLayout.HORIZONTAL) {
//                binding?.mIVSlide?.rotation = 180.0f
//                binding?.linearOption?.orientation = LinearLayout.VERTICAL
//                binding?.mTVDuration?.visibility = View.GONE
//                binding?.mTVNumber?.visibility = View.GONE
//                val set = ConstraintSet()
//                set.clone(binding!!.constraintMain)
//                set.connect(
//                    binding!!.linearOption.id,
//                    ConstraintSet.RIGHT,
//                    binding!!.constraintUser.id,
//                    ConstraintSet.RIGHT
//                )
//                set.connect(
//                    binding!!.linearOption.id,
//                    ConstraintSet.TOP,
//                    binding!!.mIVAppIcon.id,
//                    ConstraintSet.BOTTOM
//                )
//                set.applyTo(binding!!.constraintMain)
//            } else {
//                binding?.mIVSlide?.rotation = 0f
//                binding?.linearOption?.orientation = LinearLayout.HORIZONTAL
//                binding?.mTVDuration?.visibility = View.VISIBLE
//                binding?.mTVNumber?.visibility = View.VISIBLE
//                val set = ConstraintSet()
//                set.clone(binding!!.constraintMain)
//                set.connect(
//                    binding!!.linearOption.id,
//                    ConstraintSet.RIGHT,
//                    binding!!.mIVAppIcon.id,
//                    ConstraintSet.LEFT
//                )
//                set.connect(
//                    binding!!.linearOption.id,
//                    ConstraintSet.TOP,
//                    binding!!.constraintUser.id,
//                    ConstraintSet.BOTTOM
//                )
//                set.applyTo(binding!!.constraintMain)
//            }
//        }
//        binding!!.mIVSlide.setOnClickListener {
//            binding!!.mIVUser.performClick()
//        }
//
//        binding?.imgCalendar?.setOnClickListener {
//            if (binding?.linearOption?.orientation == LinearLayout.HORIZONTAL) {
//                binding?.constraintMain?.layoutTransition?.enableTransitionType(LayoutTransition.CHANGING)
//                binding?.mIVSlide?.rotation = 180.0f
//                binding?.linearOption?.orientation = LinearLayout.VERTICAL
//                binding?.mTVDuration?.visibility = View.GONE
//                binding?.mTVNumber?.visibility = View.GONE
//                val set = ConstraintSet()
//                set.clone(binding?.constraintMain)
//                binding?.linearOption?.id?.let { it1 ->
//                    set.connect(
//                        it1,
//                        ConstraintSet.RIGHT,
//                        binding!!.constraintUser.id,
//                        ConstraintSet.RIGHT
//                    )
//                }
//                set.connect(
//                    binding!!.linearOption.id,
//                    ConstraintSet.TOP,
//                    binding!!.mIVAppIcon.id,
//                    ConstraintSet.BOTTOM
//                )
//                set.applyTo(binding!!.constraintMain)
//            }
//            openCalendar(mContext)
//        }
//        binding!!.imgMessage.setOnClickListener {
//            binding?.constraintMain?.visibility = View.GONE
//            binding?.layoutMessage?.root?.visibility = View.VISIBLE
//        }
//        /* binding!!.imgReminder.setOnClickListener {
//             binding!!.constraintMain.visibility = View.GONE
//             binding!!.layoutReminder.root.visibility = View.VISIBLE
//         }*/
//        binding?.imgMute?.setOnClickListener {
//            val stateMic = !audioManager.isMicrophoneMute
//            audioManager.isMicrophoneMute = stateMic
//            if (stateMic)
//                binding!!.imgMute.setImageResource(R.drawable.ic_window_mic_on)
//            else
//                binding!!.imgMute.setImageResource(R.drawable.ic_window_mic_off)
//        }
//        binding!!.layoutMessage.imgCloseMessage.setOnClickListener {
//            binding?.constraintMain?.visibility = View.VISIBLE
//            binding?.layoutMessage?.root?.visibility = View.GONE
//        }
//        binding?.layoutReminder?.imgCloseReminder?.setOnClickListener {
//            binding?.constraintMain?.visibility = View.VISIBLE
//            binding?.layoutReminder?.root?.visibility = View.GONE
//        }
//
//
//        windowManager?.let { window ->
//            Log.d("CallerActivity", "displayWindow: windowManager $windowManager")
//            binding?.let {
//                Log.d("CallerActivity", "displayWindow: binding $binding")
//                if (Settings.canDrawOverlays(mContext)) {
//                    window.addView(
//                        it.root,
//                        floatWindowLayoutParam
//                    )
//                }
//
//            }
//
//        }
//
//        if (state == CallState.STATE_RINGING || state == CallState.STATE_OFFHOOK) {
//            binding?.mTVDuration?.let { startCounter(it) }
//        }
//
//        binding?.mIVAppIcon?.setOnTouchListener(
//            object : View.OnTouchListener {
//                private var initialY = 0
//                private var initialTouchY = 0f
//
//                override fun onTouch(v: View, event: MotionEvent): Boolean {
//                    floatWindowLayoutParam?.let {
//                        when (event.action) {
//                            MotionEvent.ACTION_DOWN -> {
//                                binding?.root?.alpha = 0.4f
//                                initialY = it.y
//                                initialTouchY = event.rawY
//
//                                return true
//                            }
//
//                            MotionEvent.ACTION_UP -> {
//                                binding?.root?.alpha = 1f
//                                return true
//                            }
//
//                            MotionEvent.ACTION_MOVE -> {
//                                it.y = initialY + (event.rawY - initialTouchY).toInt()
//                                if (Settings.canDrawOverlays(mContext)) {
//                                    windowManager?.updateViewLayout(
//                                        binding?.root,
//                                        it
//                                    )
//                                }
//                                return true
//                            }
//
//                            else -> {}
//                        }
//                    }
//                    return false
//                }
//            })
//        binding?.constraintUser?.setOnTouchListener(
//            object : View.OnTouchListener {
//                private var initialY = 0
//                private var initialTouchY = 0f
//
//                override fun onTouch(v: View, event: MotionEvent): Boolean {
//                    if (Settings.canDrawOverlays(mContext)) {
//                        floatWindowLayoutParam?.let {
//                            when (event.action) {
//                                MotionEvent.ACTION_DOWN -> {
//                                    binding?.root?.alpha = 0.4f
//                                    initialY = it.y
//                                    initialTouchY = event.rawY
//
//                                    return true
//                                }
//
//                                MotionEvent.ACTION_UP -> {
//                                    binding?.root?.alpha = 1f
//                                    return true
//                                }
//
//                                MotionEvent.ACTION_MOVE -> {
//                                    it.y = initialY + (event.rawY - initialTouchY).toInt()
//                                    windowManager?.updateViewLayout(
//                                        binding?.root,
//                                        it
//                                    )
//
//                                    return true
//                                }
//
//                                else -> {}
//                            }
//                        }
//
//                    }
//                    return false
//                }
//            })
//
//    }
//
//    private fun startCounter(duration: TextView) {
//        timer = Timer()
//        seconds = 0
//        timer?.scheduleAtFixedRate(object : TimerTask() {
//            override fun run() {
//                seconds++
//                val minutes = seconds / 60
//                val remainingSeconds = seconds % 60
//
//                val formattedTime = String.format("%02d:%02d", minutes, remainingSeconds)
//                Log.d("CallerActivity", "duration: $formattedTime")
//                CoroutineScope(Dispatchers.Main).launch {
//                    duration.text = "duration: $formattedTime"
//                    Log.d("CallerActivity", "formattedTime: $formattedTime\n ${CallerActivity.formattedTime}")
//                    CallerActivity.formattedTime = formattedTime
//                }
//            }
//        }, 0, 1000)
//    }
//
//    private fun stopCounter() {
//        timer?.cancel()
//    }
//
//    private fun setMessageView(mContext: Context) {
//        binding!!.layoutMessage.radioGroup.setOnCheckedChangeListener { _, i ->
//            when (i) {
//                binding!!.layoutMessage.radioButton1.id -> {
//                    setMessageRadioButton(
//                        mContext,
//                        binding!!.layoutMessage.radioButton1,
//                        binding!!.layoutMessage.radioButton1,
//                        binding!!.layoutMessage.radioButton2,
//                        binding!!.layoutMessage.radioButton3
//                    )
//                    binding!!.layoutMessage.radioButton1.setDrawableRightTouch {
//                        sendSMS(binding!!.layoutMessage.radioButton1.text.toString())
//                    }
//
//                }
//
//                binding!!.layoutMessage.radioButton2.id -> {
//                    setMessageRadioButton(
//                        mContext,
//                        binding!!.layoutMessage.radioButton2,
//                        binding!!.layoutMessage.radioButton1,
//                        binding!!.layoutMessage.radioButton2,
//                        binding!!.layoutMessage.radioButton3
//                    )
//                    binding!!.layoutMessage.radioButton2.setDrawableRightTouch {
//                        sendSMS(binding!!.layoutMessage.radioButton2.text.toString())
//                    }
//                }
//
//                binding!!.layoutMessage.radioButton3.id -> {
//                    setMessageRadioButton(
//                        mContext,
//                        binding!!.layoutMessage.radioButton3,
//                        binding!!.layoutMessage.radioButton1,
//                        binding!!.layoutMessage.radioButton2,
//                        binding!!.layoutMessage.radioButton3
//                    )
//                    binding!!.layoutMessage.radioButton3.setDrawableRightTouch {
//                        sendSMS(binding!!.layoutMessage.radioButton3.text.toString())
//                    }
//                }
//
//            }
//        }
//
//
//        binding!!.layoutMessage.editText.onFocusChangeListener =
//            View.OnFocusChangeListener { p0, p1 ->
//                if (p1) {
//                    binding!!.layoutMessage.radioGroup.clearCheck()
//                    setMessageRadioButton(
//                        mContext,
//                        null,
//                        binding!!.layoutMessage.radioButton1,
//                        binding!!.layoutMessage.radioButton2,
//                        binding!!.layoutMessage.radioButton3
//                    )
//                }
//            }
//
//        binding!!.layoutMessage.editText.setDrawableRightTouch {
//            sendSMS(binding!!.layoutMessage.editText.text.toString())
//        }
//    }
//
//    private fun setMessageRadioButton(
//        mContext: Context,
//        selectedView: RadioButton?,
//        unSelectedView1: RadioButton,
//        unSelectedView2: RadioButton,
//        unSelectedView3: RadioButton
//    ) {
//        val drawable = ContextCompat.getDrawable(mContext, R.drawable.ic_send)
//        unSelectedView1.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null)
//        unSelectedView2.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null)
//        unSelectedView3.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null)
//        binding!!.layoutMessage.editText.setCompoundDrawablesWithIntrinsicBounds(
//            null,
//            null,
//            null,
//            null
//        )
//        if (selectedView != null) {
//            selectedView.setCompoundDrawablesWithIntrinsicBounds(null, null, drawable, null)
//            binding!!.layoutMessage.editText.clearFocus()
//        } else {
//            binding!!.layoutMessage.editText.setCompoundDrawablesWithIntrinsicBounds(
//                null,
//                null,
//                drawable,
//                null
//            )
//        }
//    }
//
//    private fun sendSMS(sms: String) {
//        binding!!.constraintMain.layoutTransition.enableTransitionType(LayoutTransition.CHANGING)
//
//        binding!!.constraintMain.visibility = View.VISIBLE
//        binding!!.layoutMessage.root.visibility = View.GONE
//
//        if (binding!!.linearOption.orientation == LinearLayout.HORIZONTAL) {
//            binding!!.mIVSlide.rotation = 180.0f
//            binding!!.linearOption.orientation = LinearLayout.VERTICAL
//            binding!!.mTVDuration.visibility = View.GONE
//            binding!!.mTVNumber.visibility = View.GONE
//            val set = ConstraintSet()
//            set.clone(binding!!.constraintMain)
//            set.connect(
//                binding!!.linearOption.id,
//                ConstraintSet.RIGHT,
//                binding!!.constraintUser.id,
//                ConstraintSet.RIGHT
//            )
//            set.connect(
//                binding!!.linearOption.id,
//                ConstraintSet.TOP,
//                binding!!.mIVAppIcon.id,
//                ConstraintSet.BOTTOM
//            )
//            set.applyTo(binding!!.constraintMain)
//        }
//
//        val mIntent = Intent(Intent.ACTION_VIEW)
//        mIntent.data = Uri.parse("sms:")
//        mIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
//        mIntent.putExtra("sms_body", sms)
//        mContext.startActivity(mIntent)
//    }
//
//    private fun openCalendar(mContext: Context) {
//        val mIntent = Intent(
//            Intent.ACTION_VIEW,
//            CalendarContract.CONTENT_URI.buildUpon().appendPath("time").build()
//        )
//        mIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
//        mContext.startActivity(mIntent)
//    }
//
//    private fun showToast(message: String) {
//        val toast = Toast.makeText(mContext, message, Toast.LENGTH_SHORT)
//        toast.show()
//    }
//
//    private fun getDateCalendar() {
//        val cal = Calendar.getInstance()
//        currentDay = cal.get(Calendar.DAY_OF_MONTH)
//        currentMonth = cal.get(Calendar.MONTH)
//        currentYear = cal.get(Calendar.YEAR)
//    }
//
//    private fun getTimeCalendar() {
//        val cal = Calendar.getInstance()
//        currentHour = cal.get(Calendar.HOUR_OF_DAY)
//        currentMinute = cal.get(Calendar.MINUTE)
//    }
//
//
//
//    @SuppressLint("SetTextI18n")
//    override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
//        savedDay = dayOfMonth
//        savedMonth = month
//        savedYear = year
//
//        var flag = 1
//        if (savedYear < currentYear)
//            flag = -1
//        else if (savedYear == currentYear && savedMonth < currentMonth)
//            flag = -1
//        else if (savedYear == currentYear && savedMonth == currentMonth && savedDay < currentDay)
//            flag = -1
//
//        if (flag == 1) {
//            var displayDay = savedDay.toString()
//            var displayMonth = savedMonth.toString()
//
//            if (savedDay < 10)
//                displayDay = "0$displayDay"
//            if (savedMonth < 10)
//                displayMonth = "0$displayMonth"
//
//            binding?.layoutReminder?.newDateTextBox?.text =
//                "$displayDay / $displayMonth / $savedYear"
//        } else
//            showToast("Please enter a valid date!")
//    }
//
//    @SuppressLint("SetTextI18n")
//    override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
//
//        savedHour = hourOfDay
//        savedMinute = minute
//
//        var displayHour: String
//        var displayMinute: String
//        var status: String
//
//        if (savedHour > 12) {
//            displayHour = (savedHour - 12).toString()
//            status = "PM"
//        } else {
//            displayHour = savedHour.toString()
//            status = "AM"
//        }
//
//        displayMinute = savedMinute.toString()
//
//        if (displayHour.toInt() < 10)
//            displayHour = "0$displayHour"
//
//        if (displayMinute.toInt() < 10)
//            displayMinute = "0$displayMinute"
//
//        binding?.layoutReminder?.newTimeTextBox?.text = "$displayHour:$displayMinute  $status"
//    }
//
//    private fun generateDateList(
//        startDate: LocalDate,
//        numberOfDays: Int,
//        formatter: DateTimeFormatter,
//        today: LocalDate,
//        tomorrow: LocalDate
//    ): List<String> {
//        val dateList = mutableListOf<String>()
//
//        repeat(numberOfDays) {
//            val currentDate = startDate.plusDays(it.toLong())
//            val formattedDate = currentDate.format(formatter)
//            when (currentDate) {
//                today -> dateList.add("Today")
//                tomorrow -> dateList.add("Tomorrow")
//                else -> dateList.add(formattedDate)
//            }
//        }
//
//        return dateList
//    }
//
//    private fun generateHourList(): List<String> {
//        val hourList = mutableListOf<String>()
//
//        for (hour in 0..23) {
//            hourList.add("$hour")
//        }
//        return hourList
//    }
//
//    private fun generateTimeIntervals(): List<String> {
//        val timeIntervals = mutableListOf<String>()
//
//        var hour = 0
//        var minute = 0
//
//        while (hour < 24) {
//            val formattedTime = minute
//            timeIntervals.add("$formattedTime")
//
//            minute += 5
//            if (minute == 60) {
//                minute = 0
//                hour++
//            }
//        }
//
//        return timeIntervals
//    }
//
//}