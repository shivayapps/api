package com.gallery.photos.vault.album.activities.exploremap

import android.app.Activity
import android.content.Intent
import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photos.vault.album.activities.ImageListActivity
import com.gallery.photos.vault.album.adapter.PlaceAdapter
import com.gallery.photos.vault.album.customview.MyGridLayoutManager
import com.gallery.photos.vault.album.database.AppDatabase
import com.gallery.photos.vault.album.database.LocationEntity
import com.gallery.photos.vault.album.databinding.FragmentGridBinding
import com.gallery.photos.vault.album.model.AlbumData
import com.gallery.photos.vault.album.model.PictureData
import com.gallery.photos.vault.album.model.PlaceData
import com.gallery.photos.vault.album.utils.Constant
import com.gallery.photos.vault.album.utils.Preferences
import java.io.File
import java.util.Locale


class GridFragment : Fragment() {


    lateinit var activity: Activity
    lateinit var preferences: Preferences
    lateinit var dataBase: AppDatabase
    var albumList: ArrayList<PlaceData> = ArrayList()
    var albumAdapter: PlaceAdapter? = null

    public fun setData(list: ArrayList<PlaceData>){
        albumList.clear()
        albumList.addAll(list)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    lateinit var binding: FragmentGridBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        binding = FragmentGridBinding.inflate(layoutInflater, container, false)
        if(isAdded && !isDetached) {
            initView()
        }
        return binding.root
    }

    private fun initView() {
        activity = requireActivity()
        preferences = Preferences(activity)

        albumAdapter = PlaceAdapter(activity, albumList,
            clickListener = {
                val albumData = albumList[it]
                openImageList(albumData)
            })

        binding.recyclerViewPlace.adapter = albumAdapter

        val layoutManager = binding.recyclerViewPlace.layoutManager as MyGridLayoutManager
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanCount = 3

        initData()
    }

    private fun initData() {
        dataBase = AppDatabase.getInstance(activity)
        dataBase.dataDao().getLocationLiveEntityList()
            .observe(requireActivity()) { places: List<LocationEntity> ->
                sortImage(places)
            }
    }

    private fun openImageList(placeData: PlaceData) {

        Constant.albumData = AlbumData(
            placeData.place,
            placeData.pictureData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        val intent=Intent(activity, ImageListActivity::class.java)
        intent.putExtra("isFromMap",true)
        intent.putExtra("lati",placeData.lati)
        intent.putExtra("long",placeData.long)
        startActivity(intent)
    }

    private fun sortImage(placeList: List<LocationEntity>) {
//        val placeList = dataBase.dataDao().getLocationEntityList()
        Log.e("MapExploreActivity", "sortImage:::placeList.${placeList.size}")
        albumList.clear()
        placeList.forEach { data ->

            val strKey = data.title

            var imagesData1: ArrayList<PictureData> = ArrayList()

            val file = File(data.path)
            if(file.exists()) {

                val pictureData = PictureData(
                    file.path,
                    file.name,
                    file.parentFile.name,
                    file.lastModified(),
                    file.lastModified(),
                    file.length()
                )
                for (i in albumList.indices) {
                    if (albumList[i].place == strKey) {
                        albumList[i].pictureData.add(pictureData)
                    }
                }

                if (albumList.filter { it.place == strKey }.isNullOrEmpty()) {
                    imagesData1.add(pictureData)
                    val placeData = PlaceData(imagesData1, data.title, data.latitude, data.longitude)
                    albumList.add(placeData)
                }
            }
            else {
                dataBase.dataDao().deleteLocationEntity(data)
            }
        }

        getImageOnMap()
        setEmptyData()
    }

    private fun setEmptyData() {
        if (albumList != null && albumList.size != 0) {
            binding.recyclerViewPlace.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.recyclerViewPlace.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    fun getImageOnMap() {
//        val layoutManager = binding.recyclerViewPlace.layoutManager as MyGridLayoutManager
//        layoutManager.orientation = RecyclerView.VERTICAL
//        (binding.recyclerViewPlace.layoutManager as MyGridLayoutManager).spanCount =3
        Log.e("MapExploreActivity", "getImageOnMap:::albumWisePictures:${albumList.size}")
//        if (albumList != null && albumList.size > 0) {
//            albumList.forEach { album ->
////          for (album in albumList) {
//                addMarker(album)
//            }
//        }

        activity.runOnUiThread{
            if(albumAdapter!=null) {
                albumAdapter?.notifyDataSetChanged()
            }
        }
    }

    private fun latLongToAddressString(latitude: Float, longitude: Float): String {
        var addressString = ""
        val geocoder = Geocoder(activity, Locale.getDefault())
        try {
            val addresses: List<Address>? =
                geocoder.getFromLocation(latitude.toDouble(), longitude.toDouble(), 1)
            if (addresses != null) {
                val returnedAddress: Address = addresses[0]
                val strReturnedAddress = StringBuilder("")

                Log.w(
                    "MapExploreActivity",
                    "addressline:::==================================================="
                )
                Log.w(
                    "MapExploreActivity",
                    "addressline:::adminArea==>:${returnedAddress.adminArea}"
                )
                Log.w(
                    "MapExploreActivity",
                    "addressline:::featureName==>:${returnedAddress.featureName}"
                )
                Log.w("MapExploreActivity", "addressline:::locality==>:${returnedAddress.locality}")
                Log.w(
                    "MapExploreActivity",
                    "addressline:::subLocality==>:${returnedAddress.subLocality}"
                )
                Log.w(
                    "MapExploreActivity",
                    "addressline:::countryName==>:${returnedAddress.countryName}"
                )
                Log.w(
                    "MapExploreActivity",
                    "addressline:::subAdminArea==>:${returnedAddress.subAdminArea}"
                )
                Log.w("MapExploreActivity", "addressline:::premises==>:${returnedAddress.premises}")


                if (returnedAddress.subLocality != null) {
                    strReturnedAddress.append(returnedAddress.subLocality)
                } else if (returnedAddress.locality != null) {
                    strReturnedAddress.append(returnedAddress.locality)
                }

                addressString = strReturnedAddress.toString()
            }
        } catch (e: Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
        return addressString
    }

}