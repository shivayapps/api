package com.gallery.photos.vault.album.calendardaterangepicker.customviews

class InvalidDateException(message: String) : IllegalArgumentException(message)
