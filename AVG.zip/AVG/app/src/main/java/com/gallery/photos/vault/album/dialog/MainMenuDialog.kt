package com.gallery.photos.vault.album.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.databinding.DialogMainMenuBinding
import com.gallery.photos.vault.album.utils.Preferences

class MainMenuDialog(val clickListener: (type: Int) -> Unit) :
    BottomSheetDialogFragment() {

    lateinit var binding: DialogMainMenuBinding
    lateinit var preferences: Preferences
    var isShowGrid = false
    var gridCount = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DialogMainMenuBinding.inflate(layoutInflater, container, false)
        intView()
        return binding.root
    }

    private fun intView() {
        preferences = Preferences(requireActivity())
        isShowGrid = preferences.getShowGrid()
        gridCount = preferences.getGridCount()
        selectedGrid = gridCount

//        binding.btnGroup.visibility = View.VISIBLE
//        binding.btnList.visibility = View.VISIBLE
//        binding.btnGrid.visibility = View.VISIBLE
//        binding.btnChangeViewType.visibility =  if (isShowAlbumTab) View.VISIBLE else View.GONE

        intListener()
        setView()
        setColumnView()

    }

    var selectedGrid = -1
    private fun intListener() {
        binding.btnSortBy.setOnClickListener {
            dismiss()
            clickListener(1)
        }
        binding.btnGroup.setOnClickListener {
            dismiss()
            clickListener(2)
        }
        binding.btnFilterMedia.setOnClickListener {
            dismiss()
            clickListener(3)
        }

        binding.btnDisplayedColumns.setOnClickListener {
            dismiss()
            clickListener(4)
        }

        binding.btnRecycleBin.setOnClickListener {
            dismiss()
            clickListener(5)
        }
        binding.btnSetting.setOnClickListener {
            dismiss()
            clickListener(6)
        }

    }

    private fun setView() {
//            if (isShowGrid) {
//                binding.btnGrid.visibility = View.GONE
//                binding.btnList.visibility = View.VISIBLE
//            } else {
//                binding.btnGrid.visibility = View.VISIBLE
//                binding.btnList.visibility = View.GONE
//            }
    }

    private fun setColumnView() {
        when (selectedGrid) {
        }
    }


    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}