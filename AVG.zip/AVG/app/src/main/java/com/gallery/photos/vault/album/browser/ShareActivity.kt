package com.gallery.photos.vault.album.browser

import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.adconfig.AdsConfig
//import com.ads.module.open.AdconfigApplication

import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.SplashActivity
import com.gallery.photos.vault.album.base.BaseActivity
import com.gallery.photos.vault.album.utils.Constant

class ShareActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_share)
        intview()
    }

    private fun intview() {
        val action = intent.action
        var isOpenNormal = false
        if (intent.data != null && intent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY == 0) {
            Log.e("SPLASHTAG", "WEB LAUNCHED_FROM_HISTORY")
            isOpenNormal = false
        } else {
            isOpenNormal = true
            Log.e("SPLASHTAG", "WEB LAUNCHED NORMAL")
        }

        var url: String = ""
        if (action == Intent.ACTION_VIEW) {
            if (isOpenNormal) {
                startActivity(
                    Intent(
                        this,
                        SplashActivity::class.java
                    ).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                )
                finishAffinity()
            } else {
                AdsConfig.isSystemDialogOpen=true
                url = intent.data.toString()
                intent.replaceExtras(Bundle())
                intent.action = ""
                intent.data = null
                intent.flags = 0
                openShareToScreen(
                    Intent(
                        this,
                        WebBrowserActivity::class.java
                    ).putExtra(Constant.EXTRA_BROWSER_URL, url)
                )
            }
        } else {
            finishAffinity()
//            AdconfigApplication.adConfigFinishAffinity()
        }


    }

    private fun openShareToScreen(intent: Intent) {
        startActivity(intent)
        finish()
    }
}