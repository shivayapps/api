package com.gallery.photos.vault.album.mainduplicate.utils;

import android.graphics.Bitmap;


import java.io.File;
import java.text.DecimalFormat;
import java.util.Comparator;

public class ShareConstants {


    public static Boolean isBackup = false;
    public static Boolean isBackupFromPhoto = false;
    public static File path = null;
    public static int count = 0;
    public static String date_time = "";
    public static int position = 0;

    public static String user_name = "";
    public static String user_number = "";
    public static int user_position;
    public static int new_position;

    public static Bitmap user_image = null;

    public static int fav_position;
    public static boolean fav_activity = false;
    public static int fav_contact_id = -1;

    public static final String RATE_RECOVER_APK_COUNT = "rateRecoverAPKCount";
    public static final String RATE_BACKUP_CONTACT_COUNT = "rateBackupContactCount";
    public static final String RATE_DUPLICATE_COUNT = "rateDuplicateCount";

    public static String mRootPath = "";
    public static long mLastClickTime = 0;
    public static boolean isManualClick = false;
    public static boolean isManualHiddenClick = false;
    public static final String IS_ADS_REMOVED = "is_ads_removed";



    public static String getReadableFileSize(long size) {
        try {
            if (size <= 0) {
                return "0 KB";
            }
            final String[] units = new String[]{"B", "KB", "MB", "GB", "TB","PB"};
            int digitGroups = (int) (Math.log10(size) / Math.log10(1000));
            return new DecimalFormat("#,##0.##").format(size / Math.pow(1000, digitGroups)) + " " + units[digitGroups];
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    //------------------------------------- Recovered -------------------------------------//

    public static class RecoveredDateAscending implements Comparator<File> {
        public int compare(File left, File right) {
            return Long.compare(right.lastModified(), left.lastModified());
        }
    }

    public static class RecoveredDateDescending implements Comparator<File> {
        public int compare(File left, File right) {
            return Long.compare(left.lastModified(), right.lastModified());
        }
    }

    public static class RecoveredSizeAscending implements Comparator<File> {
        public int compare(File left, File right) {
            return (int) (left.length() - right.length());
        }
    }

    public static class RecoveredSizeDescending implements Comparator<File> {
        public int compare(File left, File right) {
            return (int) (right.length() - left.length());
        }
    }




    public static int getFolderSize(File dir) {
        if (dir.exists()) {
            int result = 0;
            File[] fileList = dir.listFiles();
            if (fileList != null) {
                for (File file : fileList) {
                    if (file.isDirectory()) {
                        result += getFolderSize(file);
                    } else {
                        result += file.length();
                    }
                }
            }
            return result;
        }
        return 0;
    }


}
