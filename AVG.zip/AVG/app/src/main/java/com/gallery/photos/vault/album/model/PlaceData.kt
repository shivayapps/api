package com.gallery.photos.vault.album.model

data class PlaceData(
    var pictureData: ArrayList<PictureData> = ArrayList(),
//    var path: String = "",
    var place: String = "",
    var lati: Float = 0F,
    var long: Float = 0F
)