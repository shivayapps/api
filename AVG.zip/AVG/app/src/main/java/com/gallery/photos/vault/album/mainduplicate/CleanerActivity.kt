package com.gallery.photos.vault.album.mainduplicate

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PorterDuff
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.gallery.photos.vault.album.BuildConfig
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.activities.RecentlyDeleteActivity
import com.gallery.photos.vault.album.activities.SettingActivity
import com.gallery.photos.vault.album.adapter.PictureAdapter
import com.gallery.photos.vault.album.base.BaseActivity
import com.gallery.photos.vault.album.customview.MyGridLayoutManager
import com.gallery.photos.vault.album.customview.MyRecyclerView
import com.gallery.photos.vault.album.database.AppDatabase
import com.gallery.photos.vault.album.databinding.ActivityCleanerBinding
import com.gallery.photos.vault.album.databinding.PopBottomMenuBinding
import com.gallery.photos.vault.album.dialog.ConfirmationDialog
import com.gallery.photos.vault.album.dialog.CreateAlbumDialog
import com.gallery.photos.vault.album.dialog.DeleteDialog
import com.gallery.photos.vault.album.dialog.DetailsDialog
import com.gallery.photos.vault.album.dialog.DisplayedColumnsDialog
import com.gallery.photos.vault.album.dialog.FilterMediaDialog
import com.gallery.photos.vault.album.dialog.GroupDialog
import com.gallery.photos.vault.album.dialog.MainMenuDialog
import com.gallery.photos.vault.album.dialog.ProgressDialog
import com.gallery.photos.vault.album.dialog.RenameDialog
import com.gallery.photos.vault.album.dialog.ResizeDialog
import com.gallery.photos.vault.album.dialog.SelectAlbumFullDialog
import com.gallery.photos.vault.album.dialog.SortDialog
import com.gallery.photos.vault.album.dialog.BatchFolderRenameDialog
import com.gallery.photos.vault.album.dialog.SelectAlbumDialog
import com.gallery.photos.vault.album.event.CopyMoveEvent
import com.gallery.photos.vault.album.event.DeleteEvent
import com.gallery.photos.vault.album.event.DisplayDeleteEvent
import com.gallery.photos.vault.album.event.RenameEvent
import com.gallery.photos.vault.album.event.RestoreDataEvent
import com.gallery.photos.vault.album.event.UpdateFavoriteEvent
import com.gallery.photos.vault.album.extension.beGone
import com.gallery.photos.vault.album.extension.beVisible
import com.gallery.photos.vault.album.extension.beVisibleIf
import com.gallery.photos.vault.album.extension.getFilenameExtension
import com.gallery.photos.vault.album.extension.getFilenameFromPath
import com.gallery.photos.vault.album.extension.getFinalUriFromPath
import com.gallery.photos.vault.album.extension.getParentFolder
import com.gallery.photos.vault.album.extension.getUriMimeType
import com.gallery.photos.vault.album.extension.isApng
import com.gallery.photos.vault.album.extension.isGif
import com.gallery.photos.vault.album.extension.isImageFast
import com.gallery.photos.vault.album.extension.isPng
import com.gallery.photos.vault.album.extension.isPortrait
import com.gallery.photos.vault.album.extension.isSvg
import com.gallery.photos.vault.album.extension.isVideoFast
import com.gallery.photos.vault.album.extension.openEditorIntent
import com.gallery.photos.vault.album.extension.openPath
import com.gallery.photos.vault.album.extension.scanPathRecursively
import com.gallery.photos.vault.album.extension.showErrorToast
import com.gallery.photos.vault.album.extension.toast
import com.gallery.photos.vault.album.model.AlbumData
import com.gallery.photos.vault.album.model.PictureData
import com.gallery.photos.vault.album.utils.AdCache
import com.gallery.photos.vault.album.utils.Constant
import com.gallery.photos.vault.album.utils.MAX_COLUMN_COUNT_PICTURE
import com.gallery.photos.vault.album.utils.PopupWindowHelper
import com.gallery.photos.vault.album.utils.Preferences
import com.gallery.photos.vault.album.utils.TYPE_GIFS
import com.gallery.photos.vault.album.utils.TYPE_IMAGES
import com.gallery.photos.vault.album.utils.TYPE_VIDEOS

import com.gallery.photos.vault.album.utils.Utils
import com.gallery.photos.vault.album.utils.ensureBackgroundThread
import com.gallery.photos.vault.album.utils.photoExtensions
import com.gallery.photos.vault.album.utils.rawExtensions
import com.gallery.photos.vault.album.utils.videoExtensions
import com.gallery.photos.vault.album.viewpager.PhotoVideoActivity
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import vi.imagestopdf.CreatePDFListener
import vi.imagestopdf.PDFEngine
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Collections
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class CleanerActivity : BaseActivity() {

    lateinit var preferences: Preferences
    var pictures = ArrayList<Any>()

    var imageListAdapter: PictureAdapter? = null
    var selectedItem = 0
    var isCheckSearchOn = false
    var isSelectAll = false

    private var folderPath: String = ""

    private var lastLongPressedItem = -1
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mDragListener: MyRecyclerView.MyDragListener? = null

    lateinit var binding: ActivityCleanerBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if(preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this,getString(R.string.inter_all))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivityCleanerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadBanner()

//        EventBus.getDefault().register(this)
        if (intent.hasExtra("folderPath")) {
            folderPath = intent.getStringExtra("folderPath")!!
        }
        Log.e("ImageListActivity", "folderPath:$folderPath")


        intView()
    }

    override fun onDestroy() {
        super.onDestroy()
//        EventBus.getDefault().unregister(this)
    }

    private fun intView() {
        pictures = Constant.pictures
//        binding.txtTitle.text = albumData.title

        getData()

        binding.swipeRefreshLayout.setOnRefreshListener {
            if (binding.swipeRefreshLayout.isEnabled)
                getData()
            else
                binding.swipeRefreshLayout.isRefreshing = false
        }
        intListener()
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()

    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadBanner() {
        if (!isAdLoaded) {

            val isFirstSession = preferences.splashCounter == 1
            val adId =getString(R.string.b_imageListActivity)

            BannerAdHelper.showBanner(this,
                binding.layoutBanner.mFLAd,
                binding.layoutBottomAd,
                adId,
                AdCache.imageListAdView,
                { isLoaded, adView, message ->
                    if (!isDestroyed) {
                        mAdView = adView
                        AdCache.imageListAdView = adView
                        isAdLoaded = isLoaded
                    }
                })
        }
    }


    private fun getMarkerBitmapFromView(photoPath: String, size: Int): Bitmap {
        val customMarkerView: View =
            (getSystemService(AppCompatActivity.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(
                R.layout.custom_marker,
                null
            )
        val markerImageView = customMarkerView.findViewById<View>(R.id.profile_image) as ImageView
        val markerCounter = customMarkerView.findViewById<View>(R.id.txtCount) as TextView
        markerCounter.text = "$size"

        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        val bitmap = BitmapFactory.decodeFile(photoPath, options)
        markerImageView.setImageBitmap(bitmap)

        customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        customMarkerView.layout(
            0,
            0,
            customMarkerView.measuredWidth,
            customMarkerView.measuredHeight
        )
        customMarkerView.buildDrawingCache()
        val returnedBitmap = Bitmap.createBitmap(
            customMarkerView.measuredWidth, customMarkerView.measuredHeight,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(returnedBitmap)
        canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN)
        val drawable = customMarkerView.background
        drawable?.draw(canvas)
        customMarkerView.draw(canvas)
        return returnedBitmap
    }

    private fun initZoomListener() {
        val isGridShow = preferences.getShowGrid()
        if (isGridShow) {
            val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
            mZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 2) {
                        reduceColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT_PICTURE) {
                        increaseColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            mZoomListener = null
        }
    }

    fun setupZoomListener(zoomListener: MyRecyclerView.MyZoomListener?) {
        binding.pictureRecycler.setupZoomListener(zoomListener)
    }

    private fun initDragListener() {

        mDragListener = object : MyRecyclerView.MyDragListener {
            override fun selectItem(position: Int) {
                toggleItemSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int
            ) {
                selectItemRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedItem = -1
                }
            }

        }
    }

    fun setupDragListener(dragListener: MyRecyclerView.MyDragListener?) {
        binding.pictureRecycler.setupDragListener(dragListener)
    }

    protected fun selectItemRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleItemSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleItemSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleItemSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleItemSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleItemSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {
//        pictureAdapter.getItemViewType(pos)
//        if (select && !getIsItemSelectable(pos)) {
        try {
            if (select && pictures[pos] is AlbumData) {
                return
            }

            if (pictures[pos] is PictureData) {

                if (select) {
                    (pictures[pos] as PictureData).isSelected = true
//                (pictures[pos] as PictureData).isCheckboxVisible = true
//                selectedKeys.add(itemKey)
                } else {
                    (pictures[pos] as PictureData).isSelected = false
//                (pictures[pos] as PictureData).isCheckboxVisible = false
//                selectedKeys.remove(itemKey)
                }
            }
        } catch (e: Exception) {

        }


        imageListAdapter?.notifyItemChanged(pos)
        setSelectedFile()
    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            setSelectAllColor()
        }

        binding.btnDelete.setOnClickListener {
            showDeleteDialog()
        }


        binding.icMenu.setOnClickListener {
            showMenu()
        }

    }

    private fun reduceColumnCount() {
        val selectedGrid = preferences.getGridCount()
        if (selectedGrid > 2) {
            preferences.setGridCount(selectedGrid - 1)
        }
        setColumnView()
    }

    private fun increaseColumnCount() {
        val selectedGrid = preferences.getGridCount()
        if (selectedGrid < MAX_COLUMN_COUNT_PICTURE) {
            preferences.setGridCount(selectedGrid + 1)
        }
        setColumnView()
    }


    private fun setColumnView() {
        (binding.pictureRecycler.layoutManager as MyGridLayoutManager).spanCount =
            preferences.getGridCount()
        imageListAdapter?.apply {
            notifyItemRangeChanged(0, pictures.size)
        }
        setRvLayoutManager()
    }

    private fun showMenu() {
        val dialog = MainMenuDialog(clickListener = {
            when (it) {
                1 -> {//show sort
                    showSortDialog()
                }

                2 -> {//show group
                    showGroupByDialog()
                }

                3 -> {//show filter
                    val filterMediaDialog = FilterMediaDialog(updateListener = {
                        getData()
                    })
                    filterMediaDialog.show(supportFragmentManager, filterMediaDialog.tag)
                }

                4 -> {
                    // displayed Columns
                    val displayColumnsDialog = DisplayedColumnsDialog(
                        updateListener = {
                            setRvLayoutManager()
//                            photosFragment.setRvLayoutManager()
//                            albumFragment.setRvLayoutManager()
                        })
                    displayColumnsDialog.show(supportFragmentManager, displayColumnsDialog.tag)
                }

                5 -> {
                    startActivity(Intent(this, RecentlyDeleteActivity::class.java))
                }

                6 -> {
                    settingLauncher.launch(Intent(this, SettingActivity::class.java))
                }
            }
        })
        dialog.show(supportFragmentManager, dialog.tag)

    }

    private fun showSortDialog() {
        val sortDialog = SortDialog( updateListener = {
            getData()
//            photosFragment.setFilterData()
//            albumFragment.setFilterData()
        })
        sortDialog.show(supportFragmentManager, sortDialog.tag)
    }

    private fun showGroupByDialog() {
        val groupDialog = GroupDialog(updateListener = {
            getData()
//            photosFragment.setList()
//            albumFragment.setFilterData()
        })
        groupDialog.show(supportFragmentManager, groupDialog.tag)
    }

    fun showDetailsDialog() {

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]

        val detailsDialog = DetailsDialog(pictureData, false)
        detailsDialog.show(supportFragmentManager, detailsDialog.tag)
    }

    fun openEditor(path: String) {
        val newPath = path.removePrefix("file://")
        openEditorIntent(newPath)
    }

    fun setAs() {

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]

        ensureBackgroundThread {
            val newUri =
                getFinalUriFromPath(pictureData.filePath, BuildConfig.APPLICATION_ID)
                    ?: return@ensureBackgroundThread
            Intent().apply {
                action = Intent.ACTION_ATTACH_DATA
                setDataAndType(newUri, getUriMimeType(pictureData.filePath, newUri))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val chooser = Intent.createChooser(this, getString(R.string.set_as))

                try {
                    startActivityForResult(chooser, 101)
                } catch (e: ActivityNotFoundException) {
                    toast(R.string.no_app_found)
                } catch (e: Exception) {
                    showErrorToast(e)
                }
            }
        }

    }

    fun showRenameDialog() {

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        val pictureData = selectImage.get(0)

        val renameDialog =
            RenameDialog(
                this,
                pictureData,
                positiveBtnClickListener = { renamePath, oldPath ->
                    notifyAdapter()
                })
        renameDialog.show(supportFragmentManager, renameDialog.tag)
    }

    private fun setData() {
        enableScroll()
        binding.swipeRefreshLayout.isRefreshing = false
        if (imageListAdapter != null) notifyAdapter() else initAdapter()
//        RxBus.getInstance().post(CountShowEvent())
        setEmptyData()
    }

    private fun setEmptyData() {
        if (pictures != null && pictures.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.layoutBottomAd.beVisible()
//            loadBanner()
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.layoutBottomAd.beGone()
        }
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
//        val gridLayoutManager = GridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
        val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = gridCount
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (imageListAdapter!!.getItemViewType(position) == imageListAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }

    }

    private fun initAdapter() {
        setRvLayoutManager()
        imageListAdapter = PictureAdapter(this, pictures, clickListener = {
            if (pictures[it] is PictureData) {
                val pictureData = pictures[it] as PictureData
                if (pictureData.isCheckboxVisible && !isCheckSearchOn) {
                    pictureData.isSelected = !pictureData.isSelected
                    imageListAdapter?.notifyItemChanged(it)
                    setSelectedFile()
                } else {
                    val dataList = ArrayList<PictureData>()
                    var displayPos = 0
                    for (i in pictures.indices) {
                        if (pictures[i] is PictureData) {
                            dataList.add(pictures[i] as PictureData)
                            if (it == i) {
                                displayPos = dataList.size - 1
                            }
                        }
                    }
                    Constant.displayImageList = ArrayList()
                    Constant.displayImageList.addAll(dataList)
                    Constant.selectedPosition = displayPos
                    if (Constant.displayImageList.size > 0) {
                        val intent = Intent(this, PhotoVideoActivity::class.java)
                        intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
//                    startActivity(intent)
                        photoVideoLauncher.launch(intent)
                    }
                }
            }
        }, longClickListener = {

            lastLongPressedItem = it
            binding.pictureRecycler.setDragSelectActive(it)
            lastLongPressedItem = if (lastLongPressedItem == -1) {
                it
            } else {
                val min = min(lastLongPressedItem, it)
                val max = max(lastLongPressedItem, it)
                for (i in min..max) {
                    toggleItemSelection(true, i, false)
                }
//                    updateTitle()
                it
            }

            if (!isCheckSearchOn) {
                if (pictures[it] is PictureData) {
                    val pictureData = pictures[it] as PictureData
                    for (i in pictures.indices) {
                        if (pictures[i] != null)
                            if (pictures[i] is AlbumData) {
                                val model = pictures[i] as AlbumData
                                model.isCheckboxVisible = true
                            } else if (pictures[i] is PictureData) {
                                val model = pictures[i] as PictureData
                                model.isCheckboxVisible = true
                            }
                    }
                    pictureData.isCheckboxVisible = true
                    pictureData.isSelected = true
                    notifyAdapter()
                    setSelectedFile()
                }
            }
        }, headerSelectListener = {
            if (pictures[it] is AlbumData) {
                val albumData = pictures[it] as AlbumData
                val isSelectAll = !albumData.isSelected
                albumData.isSelected = isSelectAll
                var pos = it + 1
                while (pos < pictures.size) {
                    if (pictures[pos] is PictureData) {
                        val model = pictures[pos] as PictureData
                        model.isSelected = isSelectAll
                        pos++
                    } else if (pictures[pos] is AlbumData) {
                        break
                    }
                }
                notifyAdapter()
                setSelectedFile()
            }
        })

        binding.pictureRecycler.adapter = imageListAdapter
//        val primaryColor = resources.getColor(R.color.color_primary)
//        binding.imageListFastscroller.updateColors(primaryColor)


        initZoomListener()
        setupZoomListener(mZoomListener)
        initDragListener()
        setupDragListener(mDragListener)

    }


    var photoVideoLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            if (preferences.refreshMedia) {
                try {
                    scanPathRecursively(folderPath) {
                    }
                } catch (e: Exception) {
                }
//                selectedItem = 0
//                notifyAdapter()
//                binding.swipeRefreshLayout.isEnabled = true
//                longClickListener(false, 0, false)
//                setEmptyData()
                refreshData()
//                refreshData(allList)
            }
        }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        imageListAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is PictureData) {
                val model = pictures[i] as PictureData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    imageListAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        binding.swipeRefreshLayout.isEnabled = false
//        binding.imageListFastscroller.isEnabled=false
//        binding.swipeRefreshLayout.isEnabled = selected == 0
        selectedItem = selected
    }

    override fun onBackPressed() {
        if (binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
        } else
            if (preferences.isNeedInterAd) {
                AdsConfig.showInterstitialAd(this) {
                    if (it) preferences.isNeedInterAd = false
                    finish()
                }
            } else {
                finish()
            }
    }

    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
//        binding.swipeRefreshLayout.isEnabled = !isShowSelection
//        binding.imageListFastscroller.isEnabled = isShowSelection

        binding.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE
        isSelectAll = isAllSelect
        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE
        binding.groupToolbarHeader.visibility = if (isShowSelection) View.GONE else View.VISIBLE

        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
//        binding.swipeRefreshLayout.isEnabled = false
//        binding.swipeRefreshLayout.isEnabled = (isShowSelection && selectedItem != 0)

        setSelectAllColor()
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                    }
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    private fun setClose() {
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isCheckboxVisible = false
                    model.isSelected = false
                }
        }
        binding.swipeRefreshLayout.isEnabled = true
        notifyAdapter()
        selectedItem = 0
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {

            val deleteDialog = DeleteDialog.newInstance(
                this,
//                getString(R.string.selected_delete_msg),
                btnClickListener = {
                    deletePhoto(it)
                })
            deleteDialog.show()
        }
    }

    private fun refreshData() {
//        pictures.removeAll(selectImage.toSet())
//        pictures.clear()
//        if (folderPath.isNotEmpty()) {
//
//            allList.clear()
//            allBackList.clear()
//
//            disableScroll()
//            binding.swipeRefreshLayout.isRefreshing = true
//            Observable.fromCallable<Boolean> {
//                Log.e("ImageListActivity", "getData.folderPath:$folderPath")
//                if (folderPath.isNotEmpty()) getImages()
//                setFilter()
//                true
//            }.subscribeOn(Schedulers.io())
//                .doOnError { _: Throwable? ->
//                    runOnUiThread { setData() }
//                }
//                .subscribe { _: Boolean? ->
//                    runOnUiThread { setData() }
//                }
//        } else {
//            getData()
//        }
    }

    @SuppressLint("CheckResult")
    private fun deletePhoto(isPermanent: Boolean) {
        val deleteList = ArrayList<String>()

        preferences.refreshMedia = true
        preferences.scanMedia = true

        val progressDialog = ProgressDialog(
            this,
            R.drawable.ic_drawer_delete,
            selectedItem,
            getString(R.string.Deleting),
            ""
        )
//        progressDialog.isCancelable = false
        progressDialog.show()

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
//                            runOnUiThread {
//                                bindingDialog.txtTitle.text = model.fileName
//                            }

//                            dataBase.dataDao().getLocationEntity(model.filePath)
                            val entity = dataBase.dataDao().getLocationEntity(model.filePath)
                            if (entity != null) {
                                dataBase.dataDao().deleteLocationEntity(entity)
                            }

                            val isDelete =
                                Utils.deleteFile(this, model.filePath, dataBase, isPermanent)
                            if (isDelete) {
                                deleteList.add(model.filePath)
                                runOnUiThread {
                                    progressDialog.setProgress(deleteList.size, selectedItem)
//                                    bindingDialog.txtProgressCount.text =
//                                        deleteList.size.toString() + "/" + selectedItem
//                                    bindingDialog.progressBar.progress = deleteList.size
                                }
                            }
                        } else {
                            model.isCheckboxVisible = false
                        }
                    } else if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false
                    }
            }

            var i = 0
            while (i < pictures.size) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
//        EventBus.getDefault().post(DeleteEvent(1, deleteList))
        selectedItem = 0
        notifyAdapter()
        binding.swipeRefreshLayout.isEnabled = true
        longClickListener(false, 0, false)
        setEmptyData()

        toast(getString(R.string.Delete_successfully))
        deleteMainList(deleteList)

    }

    private fun deleteMainList(deleteList: ArrayList<String>) {
//        if (deleteList.size != 0) {
//            for (path in deleteList) {
//                for (pictureData in allList) {
//                    if (pictureData.filePath == path) {
//                        allList.remove(pictureData)
//                        break
//                    }
//                }
//            }
//            for (path in deleteList) {
//                for (pictureData in allBackList) {
//                    if (pictureData.filePath == path) {
//                        allBackList.remove(pictureData)
//                        break
//                    }
//                }
//            }
//        }
    }

    private fun getData() {
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        setData()
    }


    private fun notifyAdapter() {
        if (imageListAdapter != null) {
            binding.pictureRecycler.post {
                imageListAdapter?.notifyDataSetChanged()
            }
//            imageListAdapter?.notifyDataSetChanged()
        }
    }

    private fun getDayStartTS(ts: Long, resetDays: Boolean): Long {
        val calendar = Calendar.getInstance(Locale.ENGLISH).apply {
            timeInMillis = ts
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            if (resetDays) {
                set(Calendar.DAY_OF_MONTH, 1)
            }
        }

        return calendar.timeInMillis
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onUpdateFavoriteEvent(event: UpdateFavoriteEvent) {
        updateFavoriteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDisplayDeleteEvent(event: DisplayDeleteEvent) {
        displayDeleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDeleteEvent(event: DeleteEvent) {
        deleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRenameEvent(event: RenameEvent) {
        renameEvent(event)
    }

    private fun updateFavoriteEvent(event: UpdateFavoriteEvent) {

        if (event.path.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (picture in pictures) {
                    if (picture is PictureData) {
                        val pictureData: PictureData = picture as PictureData
                        if (pictureData.filePath == event.path) {
                            pictureData.isFavorite = event.isFavorite
                            break
                        }
                    }
                }
                notifyAdapter()
            }
//            if (allList.isNotEmpty())
//                for (pictureData in allList) {
//                    if (pictureData.filePath == event.path) {
//                        pictureData.isFavorite = event.isFavorite
//                        break
//                    }
//                }
//            if (allBackList.isNotEmpty())
//                for (pictureData in allBackList) {
//                    if (pictureData.filePath == event.path) {
//                        pictureData.isFavorite = event.isFavorite
//                        break
//                    }
//                }
        }
        if (event.unFavoriteList.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (favPath in event.unFavoriteList) {
                    for (picture in pictures) {
                        if (picture is PictureData) {
                            val pictureData: PictureData = picture as PictureData
                            if (pictureData.filePath == favPath) {
                                pictureData.isFavorite = event.isFavorite
                                break
                            }
                        }
                    }
                }
                notifyAdapter()
            }
//            if (allList.isNotEmpty())
//                for (favPath in event.unFavoriteList) {
//                    for (pictureData in allList) {
//                        if (pictureData.filePath == favPath) {
//                            pictureData.isFavorite = event.isFavorite
//                            break
//                        }
//                    }
//                }

//            if (allBackList.isNotEmpty())
//                for (favPath in event.unFavoriteList) {
//                    for (pictureData in allBackList) {
//                        if (pictureData.filePath == favPath) {
//                            pictureData.isFavorite = event.isFavorite
//                            break
//                        }
//                    }
//                }
        }

    }

    private fun displayDeleteEvent(event: DisplayDeleteEvent) {
        if (event.deleteList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun renameEvent(event: RenameEvent) {
        if (event.oldPath.isNotEmpty() && event.renamePath.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (picture in pictures) {
                    if (picture is PictureData) {
                        val model = pictures as PictureData
                        if (model.filePath == event.oldPath) {
                            model.filePath = event.renamePath
                            model.fileName = File(event.renamePath).name
                            model.fileSize = File(event.renamePath).length()
                            break
                        }
                    }
                }
            }
            imageListAdapter?.notifyDataSetChanged()

//            if (allBackList.isNotEmpty()) {
//                for (pictureData in allBackList) {
//                    if (pictureData.filePath == event.oldPath) {
//                        pictureData.filePath = event.renamePath
//                        pictureData.fileName = File(event.renamePath).name
//                        pictureData.fileSize = File(event.renamePath).length()
//                        break
//                    }
//                }
//
//                for (pictureData in allList) {
//                    if (pictureData.filePath == event.oldPath) {
//                        pictureData.filePath = event.renamePath
//                        pictureData.fileName = File(event.renamePath).name
//                        pictureData.fileSize = File(event.renamePath).length()
//                        break
//                    }
//                }
//            }
        }
    }

    private fun deleteEvent(event: DeleteEvent) {
        if (event.deleteList.isNotEmpty() && event.pos != 0)
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun updateDeleteImageData(deleteList: ArrayList<String>) {
        if (pictures.isNotEmpty()) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < pictures.size) {
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.filePath == deleteList[d]) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                            if (d == deleteList.size - 1) {
                                break
                            }
                        }
                    }
                    i++
                }
            }
            notifyAdapter()
            setEmptyData()
        }
    }

    private fun disableScroll() {
        binding.pictureRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.pictureRecycler.suppressLayout(false)
    }


}