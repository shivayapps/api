package com.gallery.photos.vault.album.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.gallery.photos.vault.album.calendardaterangepicker.customviews.CalendarListener
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.databinding.DialogCalendarBinding

import com.gallery.photos.vault.album.utils.Preferences
import java.util.Calendar
import java.util.Locale

class CalendarDialog(
    var selectedTime: Long = 0L,
    val updateListener: (startDate: Calendar,endDate: Calendar) -> Unit,
) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogCalendarBinding
    lateinit var preferences: Preferences

    lateinit var pickEndDate:Calendar
    lateinit var pickStartDate:Calendar

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogCalendarBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        preferences = Preferences(requireActivity())

        selectedTime = Calendar.getInstance(Locale.ENGLISH).timeInMillis

//        bindingDialog.activityMainViewCustomCalendar.setOnDateSelectedListener { date ->
//            val cal = Calendar.getInstance(Locale.ENGLISH)
//            cal.set(Calendar.DATE, date.day)
//            cal.set(Calendar.MONTH, date.month)
//            cal.set(Calendar.YEAR, date.year)
//
//            selectedTime = cal.timeInMillis
//        }

        bindingDialog.cdrvCalendar.setCalendarListener(object : CalendarListener {
            override fun onFirstDateSelected(startDate: Calendar) {
                pickStartDate=startDate
            }

            override fun onDateRangeSelected(startDate: Calendar, endDate: Calendar) {
                pickEndDate=endDate
                pickStartDate=startDate
//                updateListener.invoke(startDate,endDate)
            }
        })


        intListener()
    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            bindingDialog.cdrvCalendar.resetAllSelectedViews()
//            bindingDialog.activityMainViewCustomCalendar.buildCalendarView()
            //dismiss()
        }
        bindingDialog.btnOK.setOnClickListener {
            dismiss()
            updateListener.invoke(pickStartDate,pickEndDate)
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}