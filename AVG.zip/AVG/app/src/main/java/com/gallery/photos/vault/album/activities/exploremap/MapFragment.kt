package com.gallery.photos.vault.album.activities.exploremap

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PorterDuff
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.activities.ImageListActivity
import com.gallery.photos.vault.album.database.AppDatabase
import com.gallery.photos.vault.album.database.LocationEntity
import com.gallery.photos.vault.album.databinding.FragmentMapBinding
import com.gallery.photos.vault.album.model.AlbumData
import com.gallery.photos.vault.album.model.PictureData
import com.gallery.photos.vault.album.model.PlaceData
import com.gallery.photos.vault.album.utils.Constant
import com.gallery.photos.vault.album.utils.Preferences
import java.io.File


class MapFragment : Fragment() {
    //(
//    var activity: Activity,
//    val longClickListener: (isShowSelection: Boolean, selected: Int, isAllSelect: Boolean) -> Unit
//)

    lateinit var activity: Activity
    lateinit var preferences: Preferences
    private var googleMap: GoogleMap? = null
    lateinit var dataBase: AppDatabase
    var albumList: ArrayList<PlaceData> = ArrayList()

    public fun setData(list: ArrayList<PlaceData>) {
        albumList.clear()
        albumList.addAll(list)
    }


    lateinit var binding: FragmentMapBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        binding = FragmentMapBinding.inflate(layoutInflater, container, false)

        binding.map.onCreate(savedInstanceState)

        if (isAdded && !isDetached) {
            initView()
        }
        return binding.root
    }

    private fun initView() {
        activity = requireActivity()
        preferences = Preferences(activity)
        getData()

    }

    private fun getData() {
        dataBase = AppDatabase.getInstance(activity)
        binding.map.getMapAsync { map ->
            googleMap = map
            initData()
            googleMap?.setOnMarkerClickListener { marker ->
                val markerTag = marker.tag as? String
                Log.e("MapExploreActivity", "MarkerClickListener.markerTag::$markerTag")
                for (album in albumList) {
                    Log.e("MapExploreActivity", "MarkerClickListener.place::${album.place}")
                }
                val albumData = albumList.firstOrNull { it.place == markerTag }!!
                openImageList(albumData)

//            setBackAlbumData()
                true
            }
        }

    }

    private fun initData() {
        dataBase.dataDao().getLocationLiveEntityList()
            .observe(requireActivity()) { places: List<LocationEntity> ->
                sortImage(places)
            }

    }

    //    var albumAdapter: PlaceAdapter? = null
    fun getImageOnMap() {

        Log.e("MapExploreActivity", "getImageOnMap:::albumWisePictures:${albumList.size}")
        if (albumList != null && albumList.size > 0) {
            albumList.forEach { album ->
                addMarker(album)
            }

            val lat = albumList[0].lati.toDouble()
            val lng = albumList[0].long.toDouble()
            if (lat != null && lng != null) {
                val location = LatLng(lat, lng)
                googleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(location,7f));
                googleMap?.animateCamera(CameraUpdateFactory.zoomIn());
                googleMap?.animateCamera(CameraUpdateFactory.zoomTo(7f), 2000, null);
            }
        }

//        BottomSheetUtils.findBottomSheetView(binding.bottomSheet);
    }

    private fun openImageList(placeData: PlaceData) {

        Constant.albumData = AlbumData(
            placeData.place,
            placeData.pictureData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        val intent=Intent(activity, ImageListActivity::class.java)
        intent.putExtra("isFromMap",true)
        intent.putExtra("lati",placeData.lati)
        intent.putExtra("long",placeData.long)
        startActivity(intent)
    }

    private fun sortImage(placeList: List<LocationEntity>) {
//        val placeList = dataBase.dataDao().getLocationEntityList()
        Log.e("MapExploreActivity", "sortImage:::placeList.${placeList.size}")
        if(placeList.isEmpty()) {
            googleMap?.clear()
        }
        albumList.clear()
        placeList.forEach { data ->

            val strKey = data.title

            var imagesData1: ArrayList<PictureData> = ArrayList()

            val file = File(data.path)
            if(file.exists()) {

                val pictureData = PictureData(
                    file.path,
                    file.name,
                    file.parentFile.name,
                    file.lastModified(),
                    file.lastModified(),
                    file.length()
                )
                for (i in albumList.indices) {
                    if (albumList[i].place == strKey) {
                        albumList[i].pictureData.add(pictureData)
                    }
                }

                if (albumList.filter { it.place == strKey }.isNullOrEmpty()) {
                    imagesData1.add(pictureData)
                    val placeData = PlaceData(imagesData1, data.title, data.latitude, data.longitude)
                    albumList.add(placeData)
                }
            }
            else {
                dataBase.dataDao().deleteLocationEntity(data)
            }
        }

        getImageOnMap()
    }

    private fun addMarker(album: PlaceData) {
        val lat = album.lati.toDouble()
        val lng = album.long.toDouble()
        if (lat != null && lng != null) {
            val location = LatLng(lat, lng)

            Log.e("MapExploreActivity", "getImageOnMap:::addMarker==>lat:${lat}, lng:${lng}")

            val marker = googleMap?.addMarker(
                MarkerOptions()
                    .position(location)
                    .icon(
                        BitmapDescriptorFactory.fromBitmap(
                            getMarkerBitmapFromView(album.pictureData.firstOrNull()!!.filePath,album.pictureData.size)
                        )
                    )
            )

            marker?.tag = album.place

        }
    }

    private fun getMarkerBitmapFromView(photoPath: String,size:Int): Bitmap {
        val customMarkerView: View =
            (activity.getSystemService(AppCompatActivity.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(
                R.layout.custom_marker,
                null
            )
        val markerImageView = customMarkerView.findViewById<View>(R.id.profile_image) as ImageView
        val markerCounter = customMarkerView.findViewById<View>(R.id.txtCount) as TextView
        markerCounter.text="$size"

        val options = BitmapFactory.Options().apply {
            inSampleSize=30
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        val bitmap = BitmapFactory.decodeFile(photoPath, options)
        markerImageView.setImageBitmap(bitmap)

        customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        customMarkerView.layout(
            0,
            0,
            customMarkerView.measuredWidth,
            customMarkerView.measuredHeight
        )
        customMarkerView.buildDrawingCache()
        val returnedBitmap = Bitmap.createBitmap(
            customMarkerView.measuredWidth, customMarkerView.measuredHeight,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(returnedBitmap)
        canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN)
        val drawable = customMarkerView.background
        drawable?.draw(canvas)
        customMarkerView.draw(canvas)
        return returnedBitmap
    }



}