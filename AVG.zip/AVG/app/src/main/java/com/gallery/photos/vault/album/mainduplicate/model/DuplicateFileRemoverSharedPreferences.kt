package com.gallery.photos.vault.album.mainduplicate.model

import android.content.Context
import android.content.SharedPreferences

object DuplicateFileRemoverSharedPreferences {
    var DUPLICATE_FILE_REMOVER_PREF = "duplicateFileRemoverPref"
    var FILES_CLEANED = "filesCleaned"
    var MANDATORY_FIRST_RATE_US_POP_UP = "mandatoryFirstTimeRateUsPopUp"
    var RATE_US = "rateUs"

    fun getDuplicateFileRemoverPref(context: Context): SharedPreferences {
        return context.getSharedPreferences(DUPLICATE_FILE_REMOVER_PREF, 0)
    }

    fun getFilesCleaned(context: Context): Int {
        return getDuplicateFileRemoverPref(context).getInt(FILES_CLEANED, 0)
    }

    fun setFilesCleaned(context: Context, value: Int) {
        getDuplicateFileRemoverPref(context).edit().putInt(FILES_CLEANED, value).apply()
    }

    @JvmStatic
    fun setStopScan(context: Context, isStopScanning: Boolean) {
        getDuplicateFileRemoverPref(context).edit().putBoolean("STOP_SCANNING", isStopScanning).apply()
    }

    @JvmStatic
    fun isScanningStop(context: Context): Boolean {
        return getDuplicateFileRemoverPref(context).getBoolean("STOP_SCANNING", false)
    }

    @JvmStatic
    fun getMandatoryRateUsPopUsFlag(context: Context): Boolean {
        return getDuplicateFileRemoverPref(context).getBoolean(MANDATORY_FIRST_RATE_US_POP_UP, false)
    }

    @JvmStatic
    fun setMandatoryRateUsPopUsFlag(context: Context, value: Boolean) {
        getDuplicateFileRemoverPref(context).edit().putBoolean(MANDATORY_FIRST_RATE_US_POP_UP, value).apply()
    }

    @JvmStatic
    fun getRateUsPopUpLimit(context: Context): Int {
        return getDuplicateFileRemoverPref(context).getInt(RATE_US, 0)
    }

    @JvmStatic
    fun setRateUsPopUpLimit(context: Context, value: Int) {
        getDuplicateFileRemoverPref(context).edit().putInt(RATE_US, value).apply()
    }

    fun isInitiateRescanAndEnterImagePageFirstTimeAfterScan(context: Context): Boolean {
        return getDuplicateFileRemoverPref(context).getBoolean("IMAGE_RESCAN_ENTER_PAGE_FIRST_TIME", true)
    }

    @JvmStatic
    fun setInitiateRescanAndEnterImagePageFirstTimeAfterScan(context: Context, value: Boolean) {
        getDuplicateFileRemoverPref(context).edit().putBoolean("IMAGE_RESCAN_ENTER_PAGE_FIRST_TIME", value).apply()
    }

    fun isInitiateRescanAndEnterVidePageFirstTimeAfterScan(context: Context): Boolean {
        return getDuplicateFileRemoverPref(context).getBoolean("VIDEO_RESCAN_ENTER_PAGE_FIRST_TIME", true)
    }

    @JvmStatic
    fun setInitiateRescanAndEnterVideoPageFirstTimeAfterScan(context: Context, value: Boolean) {
        getDuplicateFileRemoverPref(context).edit().putBoolean("VIDEO_RESCAN_ENTER_PAGE_FIRST_TIME", value).apply()
    }

    fun isInitiateRescanAndEnterAudioPageFirstTimeAfterScan(context: Context): Boolean {
        return getDuplicateFileRemoverPref(context).getBoolean("AUDIO_RESCAN_ENTER_PAGE_FIRST_TIME", true)
    }

    @JvmStatic
    fun setInitiateRescanAndEnterAudioPageFirstTimeAfterScan(context: Context, value: Boolean) {
        getDuplicateFileRemoverPref(context).edit().putBoolean("AUDIO_RESCAN_ENTER_PAGE_FIRST_TIME", value).apply()
    }

    fun isInitiateRescanAndEnterDocumentPageFirstTimeAfterScan(context: Context): Boolean {
        return getDuplicateFileRemoverPref(context).getBoolean("DOCUMENT_RESCAN_ENTER_PAGE_FIRST_TIME", true)
    }

    @JvmStatic
    fun setInitiateRescanAndEnterDocumentPageFirstTimeAfterScan(context: Context, value: Boolean) {
        getDuplicateFileRemoverPref(context).edit().putBoolean("DOCUMENT_RESCAN_ENTER_PAGE_FIRST_TIME", value).apply()
    }

    fun isInitiateRescanAndEnterOtherPageFirstTimeAfterScan(context: Context): Boolean {
        return getDuplicateFileRemoverPref(context).getBoolean("OTHER_RESCAN_ENTER_PAGE_FIRST_TIME", true)
    }

    @JvmStatic
    fun setInitiateRescanAndEnterOtherPageFirstTimeAfterScan(context: Context, value: Boolean) {
        getDuplicateFileRemoverPref(context).edit().putBoolean("OTHER_RESCAN_ENTER_PAGE_FIRST_TIME", value).apply()
    }

    fun isInitiateImagePageAfterApplyFilter(context: Context): Boolean {
        return getDuplicateFileRemoverPref(context).getBoolean("ENTER_IMAGE_PAGE_AFTER_APPLY_FILTER", true)
    }

    fun setInitiateImagePageAfterApplyFilter(context: Context, value: Boolean) {
        getDuplicateFileRemoverPref(context).edit().putBoolean("ENTER_IMAGE_PAGE_AFTER_APPLY_FILTER", value).apply()
    }

    fun isInitiateVideoPageAfterApplyFilter(context: Context): Boolean {
        return getDuplicateFileRemoverPref(context).getBoolean("ENTER_VIDEO_PAGE_AFTER_APPLY_FILTER", true)
    }

    fun setInitiateVideoPageAfterApplyFilter(context: Context, value: Boolean) {
        getDuplicateFileRemoverPref(context).edit().putBoolean("ENTER_VIDEO_PAGE_AFTER_APPLY_FILTER", value).apply()
    }

    fun isInitiateAudioPageAfterApplyFilter(context: Context): Boolean {
        return getDuplicateFileRemoverPref(context).getBoolean("ENTER_AUDIO_PAGE_AFTER_APPLY_FILTER", true)
    }

    fun setInitiateAudioPageAfterApplyFilter(context: Context, value: Boolean) {
        getDuplicateFileRemoverPref(context).edit().putBoolean("ENTER_AUDIO_PAGE_AFTER_APPLY_FILTER", value).apply()
    }

    fun isInitiateDocumentPageAfterApplyFilter(context: Context): Boolean {
        return getDuplicateFileRemoverPref(context).getBoolean("ENTER_DOCUMENT_PAGE_AFTER_APPLY_FILTER", true)
    }

    fun setInitiateDocumentPageAfterApplyFilter(context: Context, value: Boolean) {
        getDuplicateFileRemoverPref(context).edit().putBoolean("ENTER_DOCUMENT_PAGE_AFTER_APPLY_FILTER", value).apply()
    }

    fun isInitiateOtherPageAfterApplyFilter(context: Context): Boolean {
        return getDuplicateFileRemoverPref(context).getBoolean("ENTER_OTHERS_PAGE_AFTER_APPLY_FILTER", true)
    }

    fun setInitiateOtherPageAfterApplyFilter(context: Context, value: Boolean) {
        getDuplicateFileRemoverPref(context).edit().putBoolean("ENTER_OTHERS_PAGE_AFTER_APPLY_FILTER", value).apply()
    }

    fun setStorageAccessFrameWorkURIPermission(context: Context, value: String?) {
        getDuplicateFileRemoverPref(context).edit().putString("STORAGE_ACCESS_FRAMEWORK_PERMISSION_PATH", value).apply()
    }

    fun setStopScanForNotification(context: Context?, isStopScanning: Boolean) {
        getDuplicateFileRemoverPref(context!!).edit().putBoolean("STOP_SCANNING_ForNotification", isStopScanning).commit()
    }

    fun isScannigStopForNotification(context: Context?): Boolean {
        return getDuplicateFileRemoverPref(context!!).getBoolean("STOP_SCANNING_ForNotification", true)
    }
    fun setNavigateFromHome(context: Context?, value: Boolean) {
        getDuplicateFileRemoverPref(context!!).edit().putBoolean("NAVIGATE_FROM_HOME", value).commit()
    }

    fun isNavigateFromHome(context: Context?): Boolean {
        return getDuplicateFileRemoverPref(context!!).getBoolean("NAVIGATE_FROM_HOME", true)
    }


    @JvmStatic
    fun getStorageAccessFrameWorkURIPermission(context: Context): String? {
        return getDuplicateFileRemoverPref(context).getString("STORAGE_ACCESS_FRAMEWORK_PERMISSION_PATH", null)
    }
}