package com.gallery.photos.vault.album.model

data class RestoreData(var path: String, var deletedPath: String)