package com.gallery.photos.vault.album.mainduplicate;

import android.content.Context;
import android.util.Log;

import com.gallery.photos.vault.album.mainduplicate.model.DuplicateFileRemoverSharedPreferences;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5Checksum {

    public String fileToMD5(String filePath, Context context) {
        String str = null;
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            InputStream is = new FileInputStream(new File(filePath));
            byte[] buffer = new byte[8192];
            while (true) {
                try {
                    int read = is.read(buffer);
                    if (read <= 0 || DuplicateFileRemoverSharedPreferences.isScanningStop(context)) {
                        break;
                    }
                    digest.update(buffer, 0, read);
                } catch (IOException e) {
                    e.printStackTrace();
//                    throw new RuntimeException("Unable to process file for MD5", e);
                } catch (Throwable th) {
                    is.close();
                }
            }
            str = String.format("%32s", new BigInteger(1, digest.digest()).toString(16)).replace(' ', '0');
            is.close();
        } catch (NoSuchAlgorithmException | IOException e5) {
            Log.e("MD5Checksum", "fileToMD5: " + e5.getMessage());
        }
        return str;
    }

}
