package com.gallery.photos.vault.album.dialog

import android.app.Activity
import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.viewbinding.ViewBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.databinding.DialogChangeLockStyleBinding
import com.gallery.photos.vault.album.databinding.DialogChangeLockStyleDarkBinding
import com.gallery.photos.vault.album.utils.Preferences

class ChangLockStyleDialog(
    var mContext: Activity,
    val updateListener: (isShowPinLock:Boolean) -> Unit,
    val useDarkMode:Boolean?=false
) : BottomSheetDialogFragment() {

//    lateinit var bindingDialog: DialogChangeLockStyleBinding
    lateinit var bindingDialog: ViewBinding
    var preferences: Preferences = Preferences(mContext)
    var isShowPinLock = false


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogChangeLockStyleBinding.inflate(layoutInflater, container, false)
        if(useDarkMode!!) bindingDialog = DialogChangeLockStyleDarkBinding.inflate(layoutInflater, container, false)

        intView()
        intListener()
        return bindingDialog.root
    }


    private fun intView() {
//        if(useDarkMode!!) {
//            bindingDialog.llMain.backgroundTintList= ColorStateList.valueOf(Color.parseColor("##222222"))
//        }

        isShowPinLock = preferences.getShowPINLock()
        if (isShowPinLock) {
            bindingDialog.root.findViewById<RadioButton>(R.id.rbPinLock).isChecked = true
            bindingDialog.root.findViewById<RadioButton>(R.id.rbPatternLock).isChecked = false
//            bindingDialog.rbPinLock.isChecked = false
//            bindingDialog.rbPatternLock.isChecked = false
        } else {
            bindingDialog.root.findViewById<RadioButton>(R.id.rbPinLock).isChecked = false
            bindingDialog.root.findViewById<RadioButton>(R.id.rbPatternLock).isChecked = true
//            bindingDialog.rbPinLock.isChecked = false
//            bindingDialog.rbPatternLock.isChecked = true
        }
    }

    private fun intListener() {
//        bindingDialog.btnCancel.setOnClickListener {
        bindingDialog.root.findViewById<TextView>(R.id.btnCancel).setOnClickListener {
            dismiss()
        }
//        bindingDialog.btnOK.setOnClickListener {
            bindingDialog.root.findViewById<TextView>(R.id.btnOK).setOnClickListener {
//            val selectedRadioButtonId: Int = bindingDialog.grpOption.checkedRadioButtonId
            val selectedRadioButtonId: Int = bindingDialog.root.findViewById<RadioGroup>(R.id.grpOption).checkedRadioButtonId
            var isPinSelected = when (selectedRadioButtonId) {
//                bindingDialog.rbPinLock.id -> true
                (R.id.rbPinLock) -> true
//                bindingDialog.rbPatternLock.id -> false
                (R.id.rbPatternLock) -> false
                else -> false
            }
            dismiss()
            updateListener.invoke(isPinSelected)
//            preferences.putShowPinLock(isShowPinLock)
        }

    }


//    override fun getTheme(): Int = if(useDarkMode!!) R.style.BottomSheetDialogThemeDark else R.style.BottomSheetDialogTheme
    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}

