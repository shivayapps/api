package com.gallery.photos.vault.album.mainduplicate.callbacks

interface SearchListener {
    fun checkScanFinish()
    fun updateUi(vararg count: String?)
}