package com.gallery.photos.vault.album.calendardaterangepicker.models

internal enum class DateTiming {
    NONE,
    START,
    END
}
