package com.gallery.photos.vault.album.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.databinding.DialogProgressBinding
import com.gallery.photos.vault.album.extension.beGone

class ProgressDialog(
    val activity: Activity,
    @DrawableRes val resId: Int,
    val maxProgress: Int,
    val txtTopTitle: String,
    val txtTitle: String,
) : Dialog(activity) {

    lateinit var bindingDialog: DialogProgressBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.navigationBarColor = ContextCompat.getColor(activity, R.color.dialogBg)
        window?.setGravity(Gravity.BOTTOM)

        bindingDialog = DialogProgressBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }

    fun setProgress(progress: Int, size: Int) {
        //    bindingDialog?.txtProgressCount?.text = size.toString() + "/" + progress
        bindingDialog.txtProgressCount.text = (progress-1).toString() + "/" +size.toString()
        bindingDialog.progressBar.progress = progress
        Log.e("ProgressDialog", "setProgress:$progress")
    }


//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        bindingDialog = DialogProgressBinding.inflate(layoutInflater, container, false)
//        intView()
//        return bindingDialog?.root!!
//    }

    private fun intView() {
        bindingDialog.txtTopTitle.text = ""
        bindingDialog.txtTitle.text = txtTopTitle
        if(resId!=0) bindingDialog.icIcon.setImageResource(resId)
        else bindingDialog.icIcon.beGone()

        if(maxProgress>0) bindingDialog.progressBar.max=maxProgress
        else bindingDialog.progressBar.isIndeterminate=true

        Log.e("ProgressDialog", "maxProgress:$maxProgress")
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}