package com.gallery.photos.vault.album.event

data class HideEvent(var isUpdate: Boolean = false)
