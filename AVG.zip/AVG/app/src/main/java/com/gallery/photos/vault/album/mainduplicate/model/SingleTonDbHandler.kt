package com.gallery.photos.vault.album.mainduplicate.model

import android.content.Context

class SingleTonDbHandler(var singleTonDbHandlerContext: Context) {
    val instance: com.gallery.photos.vault.album.mainduplicate.model.DBHandler?
        get() {
            if (mInstance == null) {
                mInstance =
                    com.gallery.photos.vault.album.mainduplicate.model.DBHandler(
                        singleTonDbHandlerContext
                    )
            }
            return mInstance
        }

    companion object {
        var mInstance: com.gallery.photos.vault.album.mainduplicate.model.DBHandler? = null
    }
}