package com.gallery.photos.vault.album.secret.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.databinding.ItemAlbumDarkBinding
import com.gallery.photos.vault.album.extension.beGone
import com.gallery.photos.vault.album.extension.beVisible
import com.gallery.photos.vault.album.extension.beVisibleIf
import com.gallery.photos.vault.album.model.AlbumData
import com.gallery.photos.vault.album.utils.Preferences


class PrivateAlbumAdapter(
    var context: Context,
    var albumList: ArrayList<AlbumData>,
    val clickListener: (pos: Int) -> Unit,
    val longClickListener: (pos: Int) -> Unit,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var preferences: Preferences = Preferences(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = ItemAlbumDarkBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AlbumGridViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder

        val albumGridViewHolder = holder as AlbumGridViewHolder
        val albumData: AlbumData = albumList[position] as AlbumData

        albumGridViewHolder.binding.txtTitle.text = albumData.title
        if(albumData.isCustomAlbum) {
            if (albumData.title==context.getString(R.string.add)) {
                albumGridViewHolder.binding.icAddAlbum.beVisible()
                albumGridViewHolder.binding.image.beGone()
            }
        } else {
            if (albumData.pictureData.isNotEmpty()) {
                albumGridViewHolder.binding.txtCount.text = "${albumData.pictureData.size}"

                albumGridViewHolder.binding.mapImage.beGone()
                albumGridViewHolder.binding.image.beVisible()

                Glide.with(context.applicationContext)
                    .load(albumData.pictureData[0].filePath)
                    .into(albumGridViewHolder.binding.image)


                albumGridViewHolder.binding.ivGif.beVisibleIf(
                    albumData.pictureData[0].filePath.endsWith(
                        "gif",
                        true
                    )
                )

            } else {
                albumGridViewHolder.binding.txtCount.text = "0"
                albumGridViewHolder.binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_image_placeholder
                    )
                )
            }
        }

        albumGridViewHolder.binding.viewFront.setOnClickListener {
            clickListener(position)
        }
        albumGridViewHolder.binding.viewFront.setOnLongClickListener {
            longClickListener(position)
            true
        }

        if (albumData.isCheckboxVisible) {
            albumGridViewHolder.binding.icUnSelect.visibility = View.VISIBLE
            albumGridViewHolder.binding.icSelect.visibility =
                if (albumData.isSelected) View.VISIBLE else View.GONE
//                albumGridViewHolder.binding.icFavourite.visibility = View.GONE
        } else {
            albumGridViewHolder.binding.icUnSelect.visibility = View.GONE
            albumGridViewHolder.binding.icSelect.visibility = View.GONE
//                albumGridViewHolder.binding.icFavourite.visibility =
//                    if (albumData.isFavorite) View.VISIBLE else View.GONE
        }

    }

    override fun getItemCount(): Int {
        return albumList.size
    }

    class AlbumGridViewHolder(var binding: ItemAlbumDarkBinding) :
        RecyclerView.ViewHolder(binding.root)

}