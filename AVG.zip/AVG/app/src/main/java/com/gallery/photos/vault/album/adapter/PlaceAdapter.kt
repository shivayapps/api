package com.gallery.photos.vault.album.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.databinding.ItemAlbumListBinding
import com.gallery.photos.vault.album.databinding.ItemAlbumPlaceBinding
import com.gallery.photos.vault.album.databinding.ItemHeaderBinding
import com.gallery.photos.vault.album.model.PlaceData
import com.gallery.photos.vault.album.utils.Preferences

class PlaceAdapter(
    var context: Context,
    var albumList: ArrayList<PlaceData>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

//    val ITEM_ALBUM_HEADER_TYPE = 0
//    val ITEM_ALBUM_GRID_TYPE = 1
//    val ITEM_ALBUM_LIST_TYPE = 2

    var preferences: Preferences = Preferences(context)

    var pinList: ArrayList<String> = ArrayList()

    init {
        pinList = preferences.getPinAlbumList()
    }

    fun updatePinList() {
        pinList = preferences.getPinAlbumList()
    }

//    override fun getItemViewType(position: Int): Int {
//        return if (preferences.getShowGrid()) {
////            ITEM_ALBUM_GRID_TYPE
//            if (albumList[position].isCustomAlbum && albumList[position].title.contains(
//                    "more",
//                    true
//                )
//            ) {
//                ITEM_ALBUM_HEADER_TYPE
//            } else {
//                ITEM_ALBUM_GRID_TYPE
//            }
//        } else {
////            ITEM_ALBUM_LIST_TYPE
//            if (albumList[position].isCustomAlbum && albumList[position].title.contains(
//                    "more",
//                    true
//                )
//            ) {
//                ITEM_ALBUM_HEADER_TYPE
//            } else {
//                ITEM_ALBUM_LIST_TYPE
//            }
//        }
//    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
         val binding = ItemAlbumPlaceBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AlbumGridViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder

        val albumGridViewHolder = holder as AlbumGridViewHolder
        val albumData: PlaceData = albumList[position] as PlaceData

        albumGridViewHolder.binding.txtTitle.text = albumData.place
        if (albumData.pictureData.isNotEmpty()) {
            Glide.with(context.applicationContext)
                .load(albumData.pictureData[0].filePath)
                .into(albumGridViewHolder.binding.image)

            albumGridViewHolder.binding.txtCount.text = "${albumData.pictureData.size}"
        } else {
            albumGridViewHolder.binding.txtCount.text = "0"
            albumGridViewHolder.binding.image.setImageDrawable(
                ContextCompat.getDrawable(
                    context,
                    R.drawable.ic_image_placeholder
                )
            )
        }

        albumGridViewHolder.binding.root.setOnClickListener {
            clickListener(position)
        }
//        albumGridViewHolder.binding.root.setOnLongClickListener {
//            longClickListener(position)
//            true
//        }
    }

    override fun getItemCount(): Int {
        return albumList.size
    }

    class HeaderViewHolder(var binding: ItemHeaderBinding) : RecyclerView.ViewHolder(binding.root)

    class AlbumGridViewHolder(var binding: ItemAlbumPlaceBinding) :
        RecyclerView.ViewHolder(binding.root)

    class AlbumListViewHolder(var binding: ItemAlbumListBinding) :
        RecyclerView.ViewHolder(binding.root)

}