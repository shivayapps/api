package com.gallery.photos.vault.album.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.databinding.DialogPermissionDetailBinding
import com.gallery.photos.vault.album.databinding.DialogProgressBinding
import com.gallery.photos.vault.album.extension.beGone

class PermissionDetailDialog(
    val activity: Activity,
    val clickListener: (isClick: Boolean) -> Unit
) : Dialog(activity) {

    lateinit var bindingDialog: DialogPermissionDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.navigationBarColor = ContextCompat.getColor(activity, R.color.dialogBg)
        window?.setGravity(Gravity.BOTTOM)

        bindingDialog = DialogPermissionDetailBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }


    private fun intView() {
        bindingDialog.btnOK.setOnClickListener {
            dismiss()
            clickListener.invoke(true)
        }
    }

}