package com.gallery.photos.vault.album.mainduplicate.utils

import android.content.Context
import com.gallery.photos.vault.album.dialog.DuplicatePreviewDialog
import com.gallery.photos.vault.album.mainduplicate.model.ItemDuplicateModel


object PreviewDialog {
    fun showPreviewDialog(activity: Context, mItemDuplicateModel: ItemDuplicateModel) {
        DuplicatePreviewDialog(activity,mItemDuplicateModel) {

        }
    }
}