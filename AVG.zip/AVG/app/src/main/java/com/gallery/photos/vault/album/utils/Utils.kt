package com.gallery.photos.vault.album.utils

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Point
import android.media.MediaScannerConnection
import android.net.Uri
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.viewModelScope
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.database.AppDatabase
import com.gallery.photos.vault.album.database.HiddenData
import com.gallery.photos.vault.album.database.RecentDeleteData
import com.gallery.photos.vault.album.dialog.ProgressDialog
import com.gallery.photos.vault.album.event.CopyMoveEvent
import com.gallery.photos.vault.album.event.DisplayDeleteEvent
import com.gallery.photos.vault.album.event.HideEvent
import com.gallery.photos.vault.album.event.RestoreDataEvent
import com.gallery.photos.vault.album.extension.getFilenameExtension
import com.gallery.photos.vault.album.extension.getIntValue
import com.gallery.photos.vault.album.extension.getLongValue
import com.gallery.photos.vault.album.extension.rescanPath
import com.gallery.photos.vault.album.extension.splitIntoParts
import com.gallery.photos.vault.album.model.PictureData
import com.gallery.photos.vault.album.model.RestoreData
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.net.URLConnection
import java.util.concurrent.Executors

object Utils {

    public fun getScreenWidth(context: Context): Int {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val displayMetrics = DisplayMetrics()
//        windowManager.defaultDisplay.getMetrics(displayMetrics)
//        return displayMetrics.widthPixels
        return windowManager.defaultDisplay.width
//        return getPointSize(context).x
    }

    public fun getScreenHeight(context: Context): Int {
        return getPointSize(context).y
    }

    private fun getPointSize(context: Context): Point {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val size = Point()
        display.getSize(size)
        return size
    }

    fun getMimeTypeFromFilePath(filePath: String): String? {
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(getFilenameExtension(filePath))
    }

    fun getFilenameExtension(path: String): String {
        return path.substring(path.lastIndexOf(".") + 1)
    }

    fun isVideoFile(path: String): Boolean {
        val mimeType = URLConnection.guessContentTypeFromName(path)
        return mimeType != null && mimeType.startsWith("video")
    }

    fun shareFilesList(activity: Context, uris: ArrayList<Uri>) {
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE)
        intent.type = "*/*"
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(
            Intent.createChooser(
                intent,
                activity.getString(R.string.share_with)
            )
        )
    }

    fun shareFile(context: Context, filePath: String) {
        val file = File(filePath)
        val shareUri = FileProvider.getUriForFile(
            context,
            context.packageName + ".provider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = getMimeTypeFromFilePath(file.path)
        intent.putExtra(Intent.EXTRA_STREAM, shareUri)
        try {
            context.startActivity(
                Intent.createChooser(
                    intent,
                    context.getString(R.string.share_with)
                )
            )
        } catch (e: Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
            Toast.makeText(
                context,
                context.getString(R.string.no_supported_image),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun deleteFile(
        context: Context,
        filePath: String,
        dataBase: AppDatabase,
        isPermanent: Boolean? = false
    ): Boolean {
        val file = File(filePath)
        val copyFileName = file.name
        val targetFolder = File(Constant.DELETE_PATH)
        if (!targetFolder.exists())
            targetFolder.mkdirs()
        val targetPath = targetFolder.path + File.separator + copyFileName
        val targetFile = File(targetPath)
        var deletedPath = ""
        var isDelete = false

        if (isPermanent!!) {
            isDelete = file.delete()
            MediaScannerConnection.scanFile(
                context, arrayOf<String>(file.path), null
            ) { path: String?, uri: Uri? -> }

            return isDelete
        } else {
//            if (targetFile.exists()) {
            try {
                deletedPath = targetFile.path
                isDelete = com.gallery.photos.vault.album.utils.StorageUtils.moveFile(
                    file,
                    targetFile,
                    context
                )
                MediaScannerConnection.scanFile(
                    context, arrayOf<String>(file.path), null
                ) { path: String?, uri: Uri? -> }
                MediaScannerConnection.scanFile(
                    context, arrayOf<String>(targetFile.path), null
                ) { path: String?, uri: Uri? -> }
            } catch (e: FileAlreadyExistsException) {

                val separated =
                    file.name.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }
                        .toTypedArray()
                val name = separated[0]
                var type = ""
                if (separated.size != 1)
                    type = "." + separated[1]
                val newPath2 =
                    targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + type
                val file2 = File(newPath2)
                deletedPath = file2.path
                isDelete = com.gallery.photos.vault.album.utils.StorageUtils.moveFile(
                    file,
                    file2,
                    context
                )
                MediaScannerConnection.scanFile(
                    context, arrayOf<String>(file.path), null
                ) { path: String?, uri: Uri? -> }
                MediaScannerConnection.scanFile(
                    context, arrayOf<String>(file2.path), null
                ) { path: String?, uri: Uri? -> }
            }

//            } else {
//                deletedPath = targetFile.path
//                isDelete = StorageUtils.moveFile(
//                    file,
//                    targetFile,
//                    context
//                )
//            }

            if (isDelete) dataBase.dataDao()
                .insertRecentDelete(RecentDeleteData(0, deletedPath, file.parent))

            return isDelete
        }

    }

    fun deleteHideFile(
        context: Context,
        data: PictureData,
        dataBase: AppDatabase,
        isPermanent: Boolean
    ): Boolean {
        val file = File(data.filePath)
        val model = dataBase.vaultDao().getDataFromPath(data.filePath)

        if (isPermanent) {
            val isDelete = file.delete()
            val deleteUrl = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider", file
            )
            val contentResolver = context.contentResolver
            contentResolver.delete(deleteUrl, null, null)
            if (isDelete) dataBase.vaultDao().deleteHide(model)
            MediaScannerConnection.scanFile(
                context, arrayOf<String>(file.path), null
            ) { path: String?, uri: Uri? -> }
        } else {
            model.isDeleted = true
            dataBase.vaultDao().update(model)
        }

        return true
    }

    fun recentlyDeleteHideFile(
        context: Context,
        data: PictureData,
        dataBase: AppDatabase
    ): Boolean {
        val file = File(data.filePath)

        val isDelete = file.delete()
//        val deleteUrl = FileProvider.getUriForFile(
//            context,
//            "${context.packageName}.provider", file
//        )
//        val contentResolver = context.contentResolver
//        contentResolver.delete(deleteUrl, null, null)


        if (isDelete)
            dataBase.dataDao()
                .removeRecentDelete(
                    RecentDeleteData(
                        data.idDataBase,
                        data.filePath,
                        data.restorePath
                    )
                )

        MediaScannerConnection.scanFile(
            context, arrayOf<String>(file.path), null
        ) { path: String?, uri: Uri? -> }

        return isDelete
    }

    fun copyFiles(
        activity: AppCompatActivity,
        selectPath: String,
        copyMoveList: ArrayList<PictureData>,
        selectedItem: Int,
        copyListener: () -> Unit,
    ) {
        val targetFolder = File(selectPath)
        val copyFiles = ArrayList<String>()
        val keepLastModified = Preferences(activity).keepLastModified
        if (!targetFolder.exists()) {
            targetFolder.mkdirs()
        }


        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_copy_dialog,
            copyMoveList.size,
            activity.getString(R.string.Copying),
            ""
        )
        progressDialog.isCancelable = false
        progressDialog.show(activity.supportFragmentManager, progressDialog.tag)

        Observable.fromCallable {
            try {
                for (i in copyMoveList.indices) {
                    val copyFile = File(copyMoveList[i].filePath)
//                    if (copyFile.exists()) {
                    try {
                        val copyFileName = copyFile.name
                        val targetPath = targetFolder.path + File.separator + copyFileName
                        val targetFile = File(targetPath)

                        if (targetFile.exists()) {
                            val separated =
                                copyFile.name.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }
                                    .toTypedArray()
                            val name = separated[0]
                            val type = separated[1]
                            val newPath2 =
                                targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + "." + type
                            val file2 = File(newPath2)
                            val isCopied: Boolean =
                                com.gallery.photos.vault.album.utils.StorageUtils.copyFile(
                                    copyFile,
                                    file2,
                                    activity
                                )
                            if (isCopied) {
                                copyFiles.add(file2.path)
                            }
                        } else {
                            val isCopied: Boolean =
                                com.gallery.photos.vault.album.utils.StorageUtils.copyFile(
                                    copyFile,
                                    targetFile,
                                    activity
                                )
                            if (isCopied) {
                                copyFiles.add(targetFile.path)
                            }
                        }
                        if (keepLastModified) {
                            updateLastModifiedValues(activity, copyFile, targetFile)
                            activity.rescanPath(targetFile.path)
                        }
//                        activity.runOnUiThread {
                        progressDialog.setProgress(copyFiles.size, selectedItem)
                    } catch (e: FileNotFoundException) {

                    }
//                        }
                }
//                }
            } catch (e: java.lang.Exception) {
                Log.e("copyFiles", "Exception.001:$e")
                Log.e("printStackTrace","printStackTrace:$e")
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
                    copyListener()
//                    EventBus.getDefault().post(
//                        CopyMoveEvent(
//                            copyFiles,
//                            targetFolder.name,
//                            targetFolder.absolutePath,
//                            ArrayList()
//                        )
//                    )

                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
                    copyListener()
//                    EventBus.getDefault().post(
//                        CopyMoveEvent(
//                            copyFiles,
//                            targetFolder.name,
//                            targetFolder.absolutePath,
//                            ArrayList()
//                        )
//                    )
                }
            }
    }

    private fun updateLastModifiedValues(
        activity: Activity, source: File, destination: File
    ) {
        copyOldLastModified(activity, source.path, destination.path)
        val lastModified = File(source.path).lastModified()
        if (lastModified != 0L) {
            File(destination.path).setLastModified(lastModified)
        }
    }

    private fun copyOldLastModified(
        activity: Activity, sourcePath: String, destinationPath: String
    ) {
        val projection = arrayOf(
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.DATE_MODIFIED
        )

        val uri = MediaStore.Files.getContentUri("external")
        val selection = "${MediaStore.MediaColumns.DATA} = ?"
        var selectionArgs = arrayOf(sourcePath)
        val cursor = activity.applicationContext.contentResolver.query(
            uri,
            projection,
            selection,
            selectionArgs,
            null
        )

        cursor?.use {
            if (cursor.moveToFirst()) {
                val dateTaken = cursor.getLongValue(MediaStore.Images.Media.DATE_TAKEN)
                val dateModified = cursor.getIntValue(MediaStore.Images.Media.DATE_MODIFIED)

                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DATE_TAKEN, dateTaken)
                    put(MediaStore.Images.Media.DATE_MODIFIED, dateModified)
                }

                selectionArgs = arrayOf(destinationPath)
                activity.applicationContext.contentResolver.update(
                    uri,
                    values,
                    selection,
                    selectionArgs
                )
            }
        }
    }

    fun moveFiles(
        activity: AppCompatActivity,
        selectPath: String,
        copyMoveList: ArrayList<PictureData>,
        selectedItem: Int,
        copyListener: () -> Unit,
        isOpenFromFavorite: Boolean = false,
        isImportFiles: Boolean = false,
    ) {
        val targetFolder = File(selectPath)
        val moveList = ArrayList<String>()
        val deleteList = ArrayList<String>()
        val keepLastModified = Preferences(activity).keepLastModified
        if (!targetFolder.exists()) {
            targetFolder.mkdirs()
        }

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_move_dialog,
            copyMoveList.size,
            if (isImportFiles) activity.getString(R.string.Importing) else activity.getString(R.string.Moving),
            ""
        )
        progressDialog.isCancelable = false
        progressDialog.show(activity.supportFragmentManager, progressDialog.tag)

        Observable.fromCallable {
            val favList = Preferences(activity).getFavoriteList()
            try {
                for (i in copyMoveList.indices) {
//                    activity.runOnUiThread(Runnable {
//                        progressDialog.setTitle(copyMoveList[i].fileName)
//                    })
                    val moveFile = File(copyMoveList[i].filePath)
//                    if (moveFile.exists()) {

                    try {

                        val moveFileName = moveFile.name
                        val targetPath = targetFolder.path + File.separator + moveFileName
                        val targetFile = File(targetPath)
                        if (targetFile.exists()) {
                            val separated =
                                moveFile.name.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }
                                    .toTypedArray()
                            val name = separated[0]
                            val type = separated[1]
                            val newPath2 =
                                targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + "." + type
                            val file2 = File(newPath2)
                            val isMove: Boolean =
                                com.gallery.photos.vault.album.utils.StorageUtils.moveFile(
                                    moveFile,
                                    file2,
                                    activity
                                )
                            if (isMove) {
                                moveList.add(file2.path)
                                deleteList.add(moveFile.path)
                                if (favList.isNotEmpty()) {
                                    if (favList.contains(moveFile.path)) {
                                        val fPos = favList.indexOf(moveFile.path)
                                        if (fPos != -1) {
                                            favList[fPos] = file2.path
                                        }
                                    }
                                }
                            }
                        } else {
                            val isMove: Boolean =
                                com.gallery.photos.vault.album.utils.StorageUtils.moveFile(
                                    moveFile,
                                    targetFile,
                                    activity
                                )
                            if (isMove) {
                                moveList.add(targetFile.path)
                                deleteList.add(moveFile.path)

                                if (favList.isNotEmpty()) {
                                    if (favList.contains(moveFile.path)) {
                                        val fPos = favList.indexOf(moveFile.path)
                                        if (fPos != -1) {
                                            favList[fPos] = targetFile.path
                                        }
                                    }
                                }
                            }

                        }

                        if (keepLastModified) {
                            updateLastModifiedValues(activity, moveFile, targetFile)
                            activity.rescanPath(targetFile.path)
                        }
                        activity.runOnUiThread {
                            progressDialog.setProgress(moveList.size, selectedItem)
                        }
                    } catch (e: FileNotFoundException) {
                    }

//                    }
                }
            } catch (e: java.lang.Exception) {
                Log.e("printStackTrace","printStackTrace:$e")
            }
            if (favList.isNotEmpty())
                Preferences(activity).setFavoriteList(favList)
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
//                    if (progressDialog.isShowing)
                    progressDialog.dismiss()
                    copyListener()
//                    EventBus.getDefault().post(
//                        CopyMoveEvent(
//                            moveList,
//                            targetFolder.name,
//                            targetFolder.absolutePath,
//                            deleteList
//                        )
//                    )
                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
                    copyListener()
//                    EventBus.getDefault().post(
//                        CopyMoveEvent(
//                            moveList,
//                            targetFolder.name,
//                            targetFolder.absolutePath,
//                            deleteList,
//                            isOpenFromFavorite
//                        )
//                    )
                }
            }
    }

    fun hideFiles(
        activity: AppCompatActivity,
        pictures: ArrayList<PictureData>,
        selectedItem: Int,
        hideListener: () -> Unit,
        customFolder: String = "",
        isFromFav: Boolean = false
    ) {
        Log.e("hideFiles", "pictures:${pictures.size}")
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_move_dialog,
            pictures.size,
            activity.getString(
                R.string
                    .hiding
            ),
            ""
        )
        progressDialog.isCancelable = false
        progressDialog.show(activity.supportFragmentManager, progressDialog.tag)

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)
            var hideDirPath = File(Constant.HIDE_PATH)
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
//                        activity.runOnUiThread {
//                            progressDialog.setTitle(pictures[i].fileName)
//                        }
                        val to = try {
                            File(model.filePath)
                        } catch (e: java.lang.Exception) {
                            Log.e("printStackTrace","printStackTrace:$e")
                            File(model.filePath)
                        }
                        try {
                            Log.e("hideFiles", "001 =========\nto:$to,\nhideDirPath:${hideDirPath}")
                            val hidePath: String? = hideFile(activity, to, hideDirPath)
                            val extension = to.name.substring(to.name.lastIndexOf("."))

                            if (!hidePath.isNullOrEmpty()) {
                                var folder = File(to.parent).name
                                if (customFolder.isNotEmpty()) folder = customFolder
                                var isVideo = 0
                                if (Utils.isVideoFile(to.path)) {
                                    isVideo = 1
                                }
                                Log.e(
                                    "hideFiles",
                                    "002 =========\nhidePath:$hidePath,\nparent:${to.parent},\nisVideo:$isVideo,\nextension:$extension,\nfolder:$folder"
                                )

                                dataBase.vaultDao().hide(
                                    HiddenData(
                                        0,
                                        hidePath,
                                        to.parent,
                                        isVideo,
                                        extension,
                                        folder
                                    )
                                )
                            }

                        } catch (e: IOException) {
                            Log.e("printStackTrace","printStackTrace:$e")
                        }
                        deleteList.add(model.filePath)
                        activity.runOnUiThread {
                            progressDialog.setProgress(deleteList.size, pictures.size)
                        }

//                        val isDelete = Utils.fileDelete(activity, model.filePath)
//                        if (isDelete) {
//                            deleteList.add(model.filePath)
//                        }
                    }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
                    hideListener()
//                    EventBus.getDefault().post(DisplayDeleteEvent(deleteList, isFromFav))
//                    EventBus.getDefault().post(HideEvent())
                    Log.e("PrivateTag", "HideEvent funCall")


                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
                    progressDialog.dismiss()
                    hideListener()
//                    EventBus.getDefault().post(DisplayDeleteEvent(deleteList, isFromFav))
//                    EventBus.getDefault().post(HideEvent())
                    Log.e("PrivateTag", "HideEvent funCall")
                }
            }
    }

    fun deleteFiles(
        activity: AppCompatActivity,
        selectImage: ArrayList<PictureData>,
        isPermanent: Boolean,
        hideListener: (ArrayList<String>) -> Unit,
    ) {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.ic_drawer_delete,
            selectImage.size,
            activity.getString(R.string.Deleting),
            ""
        )
        progressDialog.isCancelable = false
        progressDialog.show(activity.supportFragmentManager, progressDialog.tag)

        val scope = CoroutineScope(Dispatchers.IO + CoroutineName("DeleteScope"))
        var deleteCount = 1
//        val split = selectImage.splitIntoParts(Runtime.getRuntime().availableProcessors())
        val split = selectImage.splitIntoParts(2)
        val dataBase = AppDatabase.getInstance(activity)
        split.map { list ->
            scope.async {
//                val cleanList = mutableListOf<PictureData>()
                for (model in list) {
                    val isDelete = deleteFile(activity, model.filePath, dataBase, isPermanent)
                    if (isDelete) {
                        deleteCount++
                        deleteList.add(model.filePath)
                        progressDialog.setProgress(deleteCount, selectImage.size)
                    } else {
                        deleteCount++
                        progressDialog.setProgress(deleteCount, selectImage.size)
                    }

                    if (deleteCount == selectImage.size) {
                        progressDialog.dismiss()
                        hideListener.invoke(deleteList)
                    }
                }
//                deleteList
            }
        }
//        hideListener.invoke(deleteList)
//        return asyncClean.awaitAll().flatten()
//        val executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors())
//        executor.execute {
//            val dataBase = AppDatabase.getInstance(activity)
//
//            for (i in selectImage.indices) {
//                if (selectImage[i] != null) if (selectImage[i] is PictureData) {
//                    val model = selectImage[i] as PictureData
//                    val isDelete = deleteFile(activity, model.filePath, dataBase, isPermanent)
//                    if (isDelete) {
//                        deleteCount++
//                        deleteList.add(model.filePath)
//                        progressDialog.setProgress(deleteCount, selectImage.size)
//                    }
//                }
//            }
//
//        }
//        hideListener(deleteList)

//        Observable.fromCallable {
//            val dataBase = AppDatabase.getInstance(activity)
//
//            for (i in selectImage.indices) {
//                if (selectImage[i] != null) if (selectImage[i] is PictureData) {
//                    val model = selectImage[i] as PictureData
//                    val isDelete = deleteFile(activity, model.filePath, dataBase, isPermanent)
//                    if (isDelete) {
//                        deleteCount++
//                        deleteList.add(model.filePath)
//                        progressDialog.setProgress(deleteCount, selectImage.size)
//                    }
//                }
//            }
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                activity.runOnUiThread {
//                    progressDialog.dismiss()
//                    hideListener(deleteList)
//                }
//            }
//            .subscribe { _: Boolean? ->
//                activity.runOnUiThread {
//                    progressDialog.dismiss()
//                    hideListener(deleteList)
//                }
//            }
    }

    fun unHideFiles(
        activity: AppCompatActivity,
        pictures: ArrayList<PictureData>,
        selectedItem: Int,
        hideListener: () -> Unit,
    ) {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_move_dialog,
            pictures.size,
            activity.getString(R.string.UnHiding),
            ""
        )
        progressDialog.isCancelable = false
        progressDialog.show(activity.supportFragmentManager, progressDialog.tag)

        val restoreList: ArrayList<RestoreData> = ArrayList()

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    val dataModel = dataBase.vaultDao().getDataFromPath(model.filePath)

                    val unHideDirPath = File(model.restorePath)
//                    activity.runOnUiThread {
////                        txtTitle.text = pictures[i].fileName
//                        progressDialog.setTitle(pictures[i].fileName)
//                    }
                    val to = try {
                        File(model.filePath)
                    } catch (e: java.lang.Exception) {
                        Log.e("printStackTrace","printStackTrace:$e")
                        File(model.filePath)
                    }
                    try {

                        Log.e("hideFiles", "111 =========\nto:$to,\nunHideDirPath:${unHideDirPath}")
                        var hidePath: String = ""
                        if (dataModel != null)
                            hidePath = unHideFile(activity, to, unHideDirPath, dataModel.extension)

                        if (!hidePath.isNullOrEmpty()) {
                            //dataBase.vaultDao().getDataFromPath(model.filePath)
                            restoreList.add(RestoreData(hidePath, model.filePath))
                            val dataModel = dataBase.vaultDao().getDataFromPath(model.filePath)
                            dataBase.vaultDao().unHide(dataModel)

                        }
                    } catch (e: IOException) {
                        Log.e("printStackTrace","printStackTrace:$e")
                    } catch (e: Exception) {
                        Log.e("printStackTrace","printStackTrace:$e")
                    }
                    deleteList.add(model.filePath)
                    activity.runOnUiThread {
                        progressDialog.setProgress(deleteList.size, pictures.size)
//                        txtProgressCount.text =
//                            deleteList.size.toString() + "/" + pictures.size
//                        progressBar.progress = deleteList.size
                    }

//                        val isDelete = Utils.fileDelete(activity, model.filePath)
//                        if (isDelete) {
//                            deleteList.add(model.filePath)
//                            activity.runOnUiThread {
//                                txtProgressCount.text =
//                                    deleteList.size.toString() + "/" + selectedItem
//                                progressBar.progress = deleteList.size
//                            }
//                        }
                }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
//                    EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                    hideListener()
                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
//                    EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                    hideListener()
                }
            }
    }

    private fun unHideFile(activity: Activity, file: File, dir: File, extension: String): String {
        try {
            if (!dir.exists())
                dir.mkdirs()

//            val newFile: File = getUnHideFileName(0, dir, file.name,extension)
            val name = file.name + "$extension"
            val newFile = File(dir, name)
//            val newFile: File = getUnHideFileName(0, dir, file.name,extension)
            Log.e(
                "hideFiles",
                "222 =========\nfile.path:${file.path},\nfile.name:${file.name},\nnewFile.path:${newFile.path},\nnewFile.name:${newFile.name}"
            )

            FileOutputStream(newFile).channel.use { outputChannel ->
                FileInputStream(file).channel.use { inputChannel ->
                    inputChannel.transferTo(0, inputChannel.size(), outputChannel)
                    inputChannel.close()
                    file.delete()
//                    val deleteUrl = FileProvider.getUriForFile(
//                        activity,
//                        "${activity.packageName}.provider", file
//                    )
//                    val contentResolver = activity.contentResolver
//                    contentResolver.delete(deleteUrl, null, null)

                    MediaScannerConnection.scanFile(
                        activity,
                        arrayOf(file.path),
                        null
                    ) { path: String?, uri: Uri? -> }
                    MediaScannerConnection.scanFile(
                        activity,
                        arrayOf(newFile.path),
                        null
                    ) { path: String?, uri: Uri? -> }
                    return newFile.path
                }
            }
        } catch (e: Exception) {
            Log.e("hideFiles", "unHideFile.Exception:${e}")
            Log.e("printStackTrace","printStackTrace:$e")
            return ""
        }
    }

    private fun restoreFile(activity: Activity, file: File, dir: File): String? {
        try {
            if (!dir.exists())
                dir.mkdirs()

//            val newFile: File = getHideFileName(0, dir, file.name)
            val newFile: File =
                getUnHideFileName(0, dir, file.name, file.name.getFilenameExtension())
            Log.e(
                "hideFiles",
                "003 =========\nfile.path:${file.path},\nfile.name:${file.name},\nnewFile.path:${newFile.path},\nnewFile.name:${newFile.name}"
            )

            FileOutputStream(newFile).channel.use { outputChannel ->
                FileInputStream(file).channel.use { inputChannel ->
                    inputChannel.transferTo(0, inputChannel.size(), outputChannel)
                    inputChannel.close()
                    file.delete()
//                    val deleteUrl = FileProvider.getUriForFile(
//                        activity,
//                        "${activity.packageName}.provider", file
//                    )
//                    val contentResolver = activity.contentResolver
//                    contentResolver.delete(deleteUrl, null, null)

                    MediaScannerConnection.scanFile(
                        activity,
                        arrayOf(file.path),
                        null
                    ) { path: String?, uri: Uri? -> }
                    MediaScannerConnection.scanFile(
                        activity,
                        arrayOf(newFile.path),
                        null
                    ) { path: String?, uri: Uri? -> }
                    return newFile.path
                }
            }
        } catch (e: Exception) {
            Log.e("hideFiles", "hideFile.Exception:${e}")
            Log.e("printStackTrace","printStackTrace:$e")
            return null
        }
    }

    private fun hideFile(activity: Activity, file: File, dir: File): String? {
        try {
            if (!dir.exists())
                dir.mkdirs()

            val newFile: File = getHideFileName(0, dir, file.name)
            Log.e(
                "hideFiles",
                "003 =========\nfile.path:${file.path},\nfile.name:${file.name},\nnewFile.path:${newFile.path},\nnewFile.name:${newFile.name}"
            )

            FileOutputStream(newFile).channel.use { outputChannel ->
                FileInputStream(file).channel.use { inputChannel ->
                    inputChannel.transferTo(0, inputChannel.size(), outputChannel)
                    inputChannel.close()
                    file.delete()

                    return newFile.path
                }
            }
        } catch (e: Exception) {
            Log.e("hideFiles", "hideFile.Exception:${e}")
            Log.e("printStackTrace","printStackTrace:$e")
            return null
        }
    }

    private fun getUnHideFileName(count: Int, dir: File, strName: String, extension: String): File {
        var i = count
//        val extension = strName.substring(strName.lastIndexOf("."))
//        var name = strName.replace(extension,"")
//        var name = strName+"$extension"
        var name = strName
        var check = File(dir, name)
        if (check.exists()) {
            i++
            if (name.contains(".")) {
                if (name.indexOf(".") > 0) {
//                    val extension = name.substring(name.lastIndexOf("."))
                    name = name.substring(0, name.lastIndexOf(".")) + "(" + i + ")" + ".$extension"
//                    name = name.substring(0, name.lastIndexOf(".")) + "(" + i + ")" + extension
                }
            } else {
                name = "$name($i)"
            }
            check = getUnHideFileName(i, dir, name, extension)
        }
        return check
    }

    private fun getHideFileName(count: Int, dir: File, strName: String): File {
        var i = count
        val extension = strName.substring(strName.lastIndexOf("."))
        var name = strName.replace(extension, "")
        Log.e("getHideFileName", "strName:$strName, name:$name, extension:$extension")
        var check = File(dir, name)
        if (check.exists()) {
            i++
            if (name.contains(".")) {
                if (name.indexOf(".") > 0) {
                    name = name.substring(0, name.lastIndexOf(".")) + "(" + i + ")"
                }
            } else {
                name = "$name($i)"
            }
            //"${name}${extension}"
            check = getHideFileName(i, dir, "${name}${extension}")
        }
        return check
    }

    fun restoreFile(
        activity: AppCompatActivity,
        model: PictureData,
        dataBase: AppDatabase
    ): ArrayList<RestoreData> {
//        var dialog: Dialog? = null
//        var txt_top_title: TextView? = null
//        var txtProgressCount: TextView? = null
//        var progressBar: ProgressBar? = null

        val unHideDirPath = File(model.restorePath)
        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_move_dialog,
            1,
            activity.getString(R.string.Restoring),
            ""
        )
        progressDialog.isCancelable = false
        progressDialog.show(activity.supportFragmentManager, progressDialog.tag)

        val to = try {
            File(model.filePath)
        } catch (e: java.lang.Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
            File(model.filePath)
        }
        val restoreList: ArrayList<RestoreData> = ArrayList()
        try {
            val hidePath: String? = restoreFile(activity, to, unHideDirPath)
            if (!hidePath.isNullOrEmpty()) {
                restoreList.add(RestoreData(hidePath, model.filePath))
                dataBase.dataDao().removeRecentDelete(
                    RecentDeleteData(
                        model.idDataBase,
                        model.filePath,
                        model.restorePath
                    )
                )
            }
        } catch (e: IOException) {
            Log.e("printStackTrace","printStackTrace:$e")
        }

        activity.runOnUiThread {
            progressDialog.setProgress(1, 1)
//            txtProgressCount!!.text = "1/1"
//            progressBar!!.progress = 1
            progressDialog.dismiss()
        }
        activity.runOnUiThread {
            progressDialog.dismiss()
        }
//        android.os.Handler(Looper.myLooper()!!).postDelayed({
//            dialog!!.dismiss()
//        }, 300)
        return restoreList
    }


    fun recoverFiles(
        activity: AppCompatActivity,
        pictures: ArrayList<PictureData>,
        selectedItem: Int,
        hideListener: () -> Unit,
    ) {
        val deleteList = ArrayList<String>()


        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_move_dialog,
            pictures.size,
            activity.getString(R.string.Restoring),
            ""
        )
        progressDialog.isCancelable = false
        progressDialog.show(activity.supportFragmentManager, progressDialog.tag)

        val restoreList: ArrayList<RestoreData> = ArrayList()

        Observable.fromCallable {
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData

//                    var unHideDirPath = File(model.restorePath)
                    var unHideDirPath = File(Constant.RECOVER_PATH)

                    val to = try {
                        File(model.filePath)
                    } catch (e: java.lang.Exception) {
                        Log.e("printStackTrace","printStackTrace:$e")
                        File(model.filePath)
                    }
                    try {

                        Log.e("hideFiles", "111 =========\nto:$to,\nunHideDirPath:${unHideDirPath}")
//                        val hidePath: String? = unHideFile(activity, to, unHideDirPath,pictures[i].filePath.getFilenameExtension())
                        val hidePath: String = unHideFile(activity, to, unHideDirPath, "")

                        if (!hidePath.isNullOrEmpty()) {
                            //dataBase.vaultDao().getDataFromPath(model.filePath)
                            restoreList.add(RestoreData(hidePath, model.filePath))
                        }
                    } catch (e: IOException) {
                        Log.e("printStackTrace","printStackTrace:$e")
                    }
                    deleteList.add(model.filePath)
                    activity.runOnUiThread {
                        progressDialog.setProgress(deleteList.size, pictures.size)
//                        txtProgressCount.text =
//                            deleteList.size.toString() + "/" + pictures.size
//                        progressBar.progress = deleteList.size
                    }
                }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
//                    EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                    hideListener()
                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
//                    EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                    hideListener()
                }
            }
    }

//    fun recoverFiles1(
//        activity: Activity,
//        pictures: ArrayList<PictureData>,
//        selectedItem: Int,
//        hideListener: () -> Unit,
//    ) {
//        val deleteList = ArrayList<String>()
//        val dialog = Dialog(activity, R.style.Dialog)
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
//        dialog.setCancelable(false)
//        dialog.setContentView(R.layout.dialog_delete_progress)
//        dialog.setCanceledOnTouchOutside(false)
//        dialog.window?.setGravity(Gravity.BOTTOM)
//        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//
//
//        val icIcon: ImageView = dialog.findViewById(R.id.icIcon)
//        val txtTitle: TextView = dialog.findViewById(R.id.txt_title)
//        val txt_top_title: TextView = dialog.findViewById(R.id.txt_top_title)
//        val txtProgressCount: TextView = dialog.findViewById(R.id.txt_progress_count)
//        val progressBar: ProgressBar = dialog.findViewById(R.id.progress_bar)
//
//        icIcon.setImageResource(R.drawable.icon_move_dialog)
//        progressBar.max = selectedItem
//        txt_top_title.text = activity.getText(R.string.Restoring)
//        activity.runOnUiThread {
//            txtProgressCount.text = deleteList.size.toString() + "/" + selectedItem
//            progressBar.progress = deleteList.size
//        }
//        dialog.show()
//
//        val restoreList: ArrayList<RestoreData> = ArrayList()
//
//        Observable.fromCallable {
//            for (i in pictures.indices) {
//                if (pictures[i] != null) if (pictures[i] is PictureData) {
//                    val model = pictures[i] as PictureData
//                    var unHideDirPath = File(Constant.RECOVER_PATH)
//                    activity.runOnUiThread {
//                        txtTitle.text = pictures[i].fileName
//                    }
//                    val to = try {
//                        File(model.filePath)
//                    } catch (e: java.lang.Exception) {
//                        Log.e("printStackTrace","printStackTrace:$e")
//                        File(model.filePath)
//                    }
//                    try {
//                        val hidePath: String? = hideFile(activity, to, unHideDirPath)
//                        if (!hidePath.isNullOrEmpty()) {
//                            restoreList.add(RestoreData(hidePath, model.filePath))
//                        }
//                    } catch (e: IOException) {
//                        Log.e("printStackTrace","printStackTrace:$e")
//                    }
//                    deleteList.add(model.filePath)
//                    activity.runOnUiThread {
//                        txtProgressCount.text =
//                            deleteList.size.toString() + "/" + selectedItem
//                        progressBar.progress = deleteList.size
//                    }
//                }
//            }
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                activity.runOnUiThread {
//                    if (dialog.isShowing)
//                        dialog.dismiss()
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
//                    hideListener()
//                }
//            }
//            .subscribe { _: Boolean? ->
//                activity.runOnUiThread {
//                    if (dialog.isShowing)
//                        dialog.dismiss()
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
//                    hideListener()
//                }
//            }
//    }

    fun restoreFiles(
        activity: AppCompatActivity,
        pictures: ArrayList<PictureData>,
        selectedItem: Int,
        hideListener: () -> Unit,
    ) {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_move_dialog,
            pictures.size,
            activity.getString(R.string.Restoring),
            ""
        )
        progressDialog.isCancelable = false
        progressDialog.show(activity.supportFragmentManager, progressDialog.tag)

        val restoreList: ArrayList<RestoreData> = ArrayList()

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    var unHideDirPath = File(model.restorePath)
//                    activity.runOnUiThread {
//                        progressDialog.setTitle(pictures[i].fileName)
//                    }
                    val to = try {
                        File(model.filePath)
                    } catch (e: java.lang.Exception) {
                        Log.e("printStackTrace","printStackTrace:$e")
                        File(model.filePath)
                    }
                    try {
                        val hidePath: String? = restoreFile(activity, to, unHideDirPath)
                        if (!hidePath.isNullOrEmpty()) {
                            restoreList.add(RestoreData(hidePath, model.filePath))
                            dataBase.dataDao().removeRecentDelete(
                                RecentDeleteData(
                                    model.idDataBase,
                                    model.filePath,
                                    model.restorePath
                                )
                            )
                        }
                    } catch (e: IOException) {
                        Log.e("printStackTrace","printStackTrace:$e")
                    }
                    deleteList.add(model.filePath)
                    activity.runOnUiThread {
                        progressDialog.setProgress(deleteList.size, pictures.size)
                    }

//                        val isDelete = Utils.fileDelete(activity, model.filePath)
//                        if (isDelete) {
//                            deleteList.add(model.filePath)
//                            activity.runOnUiThread {
//                                txtProgressCount.text =
//                                    deleteList.size.toString() + "/" + selectedItem
//                                progressBar.progress = deleteList.size
//                            }
//                        }
                }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    if (progressDialog.isVisible)
                        progressDialog.dismiss()
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
                    hideListener()
                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    if (progressDialog.isVisible)
                        progressDialog.dismiss()
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
                    hideListener()
                }
            }
    }

    fun restoreVaultFiles(
        activity: AppCompatActivity,
        pictures: ArrayList<PictureData>,
        selectedItem: Int,
        hideListener: () -> Unit,
    ) {
        val deleteList = ArrayList<String>()
        val progressDialog = ProgressDialog(
            activity,
            R.drawable.icon_move_dialog,
            pictures.size,
            activity.getString(R.string.Restoring),
            ""
        )
        progressDialog.isCancelable = false
        progressDialog.show(activity.supportFragmentManager, progressDialog.tag)

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
//                    var unHideDirPath = File(model.restorePath)

//                    val to = try {
//                        File(model.filePath)
//                    } catch (e: java.lang.Exception) {
//                        Log.e("printStackTrace","printStackTrace:$e")
//                        File(model.filePath)
//                    }
                    try {
//                        val hidePath: String? = hideFile(activity, to, unHideDirPath)
//                        if (!hidePath.isNullOrEmpty()) {
//                            restoreList.add(RestoreData(hidePath, model.filePath))
                        val dataModel = dataBase.vaultDao().getDataFromPath(model.filePath)
                        dataModel.isDeleted = false
                        dataBase.vaultDao().update(dataModel)
//                        }
                    } catch (e: IOException) {
                        Log.e("printStackTrace","printStackTrace:$e")
                    }
                    deleteList.add(model.filePath)
                    activity.runOnUiThread {
                        progressDialog.setProgress(deleteList.size, selectedItem)
//                        txtProgressCount.text =
//                            deleteList.size.toString() + "/" + selectedItem
//                        progressBar.progress = deleteList.size
                    }


                }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
                    hideListener()
                }
            }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
//                    EventBus.getDefault().post(RestoreDataEvent(restoreList))
                    hideListener()
                }
            }
    }

}