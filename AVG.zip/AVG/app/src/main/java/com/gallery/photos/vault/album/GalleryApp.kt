package com.gallery.photos.vault.album

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.bumptech.glide.Glide
import com.gallery.photos.vault.album.activities.WelcomeBackActivity

import com.github.ajalt.reprint.core.Reprint
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.squareup.picasso.Downloader
import com.squareup.picasso.Picasso
import com.gallery.photos.vault.album.activities.setup.PermissionActivity
import com.gallery.photos.vault.album.extension.beGone
import com.gallery.photos.vault.album.extension.getParentFolder
import com.gallery.photos.vault.album.model.PictureData
import com.gallery.photos.vault.album.utils.Preferences
import com.gallery.photos.vault.album.utils.TYPE_GIFS
import com.gallery.photos.vault.album.utils.TYPE_IMAGES
import com.gallery.photos.vault.album.utils.TYPE_VIDEOS
import com.gallery.photos.vault.album.utils.photoExtensions
import com.gallery.photos.vault.album.utils.rawExtensions
import com.gallery.photos.vault.album.utils.videoExtensions
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.Request
import okhttp3.Response
import java.io.File

class GalleryApp : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {

    lateinit var remoteConfig: FirebaseRemoteConfig
    override fun onCreate() {
        super.onCreate()
        com.gallery.photos.vault.album.GalleryApp.Companion.mContext = applicationContext

        Reprint.initialize(this)
        Picasso.setSingletonInstance(Picasso.Builder(this).downloader(object : Downloader {
            override fun load(request: Request) = Response.Builder().build()

            override fun shutdown() {}
        }).build())

        com.gallery.photos.vault.album.GalleryApp.Companion.preferences = Preferences(applicationContext)
        FirebaseApp.initializeApp(applicationContext)
        FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(!BuildConfig.VERSION_NAME.contains("test"));

        MobileAds.initialize(applicationContext)
        remoteConfig = FirebaseRemoteConfig.getInstance()
        remoteConfig.reset()
        com.gallery.photos.vault.album.GalleryApp.Companion.mFirebaseAnalytics = FirebaseAnalytics.getInstance(applicationContext)

        var AdmobInterstitialAdId = getString(R.string.inter_language)
        var AdmobAppOpenId = getString(R.string.open_all)

        if (!com.gallery.photos.vault.album.GalleryApp.Companion.preferences.isFirstTimeInstall) {
            AdmobInterstitialAdId = getString(R.string.inter_all)
//            AdmobAppOpenId = getString(R.string.open_all2)
        }

        val isEnableAds = com.gallery.photos.vault.album.GalleryApp.Companion.preferences.isEnableAds
        val isEnableOpenAds = preferences.isEnableOpenAds

        AdsConfig.builder()
            .isEnableAds(isEnableAds)
            .isEnableOpenAds(isEnableOpenAds)
            .setTestDeviceId("43D54D26FD5DBC346211511E0DFD64F9")
            .setAdmobInterstitialAdId(AdmobInterstitialAdId)
            .setAdmobAppOpenId(AdmobAppOpenId)
            .build(this)

        setAppLifecycleListener(this)
        initMobileAds()

//        OpenAdHelper.loadOpenAd(this)

        fireBaseConfigGet()

//        getAllMedia()
    }

    private fun fireBaseConfigGet() {
        try {
            remoteConfig.setConfigSettingsAsync(
                FirebaseRemoteConfigSettings.Builder()
                    .setMinimumFetchIntervalInSeconds(0)
                    .setFetchTimeoutInSeconds(3)
                    .build()
            )

            remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)
            remoteConfig.fetch(0)
                .addOnCompleteListener { task: Task<Void?> ->
                    var errorString = ""
                    if (task.isSuccessful) {
                        Log.e("fireBaseConfigGet", "Successful")
                        remoteConfig.fetchAndActivate()

//                        val isEnableAds: Boolean = remoteConfig.getBoolean("isEnableAds")
//                        val isEnableOpenAd: Boolean = remoteConfig.getBoolean("isEnableOpenAd")
                        val isEnableAds=true
                        val isEnableOpenAd=true

//                        val isCallDialogClosable: Boolean = remoteConfig.getBoolean("isCallDialogClosable")
//                        val needToShowCallerCad: Boolean = remoteConfig.getBoolean("needToShowCallerCad")

//                        val call_native_id: String = remoteConfig.getString("call_native_id")
//                        val call_banner_id: String = remoteConfig.getString("call_banner_id")
//                        val call_ad_type: String = remoteConfig.getString("call_ad_type")

//                        Log.e("fireBaseConfigGet", "isCallDialogClosable:$isCallDialogClosable")
//                        Log.e("fireBaseConfigGet", "needToShowCallerCad:$needToShowCallerCad")
//                        Log.e("fireBaseConfigGet", "call_native_id:$call_native_id")
//                        Log.e("fireBaseConfigGet", "call_banner_id:$call_banner_id")
//                        Log.e("fireBaseConfigGet", "call_ad_type:$call_ad_type")

//                        adsPref.callNativeId = call_native_id
//                        adsPref.callBannerId = call_banner_id
//                        adsPref.callBannerId = "ca-app-pub-4729058785930330/1463197190"
//                        adsPref.callAdType = call_ad_type
                        Log.e("fireBaseConfigGet", "isEnableAds:$isEnableAds")
                        Log.e("fireBaseConfigGet", "isEnableOpenAd:$isEnableOpenAd")


                        preferences.isEnableAds=isEnableAds
                        preferences.isEnableOpenAds=isEnableAds
                        Config.isAdsEnable = isEnableAds
                        Config.isOpenAdEnable = isEnableOpenAd

                        errorString = " task is successful  "

                    } else {
                        Log.e("fireBaseConfigGet", "Failed:${task.exception}")
                        errorString = "task is canceled"
                    }
                }
        } catch (e: java.lang.Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
    }

    companion object {
        var allMediaList = ArrayList<PictureData>()
        private lateinit var mContext: Context
        lateinit var mFirebaseAnalytics: FirebaseAnalytics
        lateinit var preferences: Preferences

        fun getContext(): Context {
            return com.gallery.photos.vault.album.GalleryApp.Companion.mContext
        }

        private fun getAllMedia() {

            Observable.fromCallable {
                Log.e("getAllMediaTimer", "startGetAllMedia")
                Log.e("getAllMedia", "getAllMedia")
                com.gallery.photos.vault.album.GalleryApp.Companion.getImages()
                true
            }.subscribeOn(Schedulers.io())
                .doOnError { throwable: Throwable? ->
                    Log.e("getAllMediaTimer", "doOnError:" + throwable)
                    com.gallery.photos.vault.album.GalleryApp.Companion.preferences.saveMediaList(
                        com.gallery.photos.vault.album.GalleryApp.Companion.allMediaList
                    )
//                runOnUiThread {
//                    setFilterData()
//                }
                }
                .subscribe { result: Boolean? ->
                    Log.e("getAllMediaTimer", "result:" + result)
                    com.gallery.photos.vault.album.GalleryApp.Companion.preferences.saveMediaList(
                        com.gallery.photos.vault.album.GalleryApp.Companion.allMediaList
                    )
//                runOnUiThread {
//                    setFilterData()
//                }
                }

        }


        private fun getImages() {
            Log.e("getAllMediaTimer", "start.getImages")
            Log.e("getAllMedia", "getImages")
            val mCursor: Cursor?
            val folderList: MutableList<String> = ArrayList<String>()
            val favList: ArrayList<String> = ArrayList()
            favList.addAll(com.gallery.photos.vault.album.GalleryApp.Companion.preferences.getFavoriteList())

            val excludeList: ArrayList<String> = ArrayList()
            excludeList.addAll(com.gallery.photos.vault.album.GalleryApp.Companion.preferences.getExcludeList())

            try {
                val BUCKET_DISPLAY_NAME: String
                BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
                val projection = arrayOf(
                    MediaStore.Images.Media.DATA,
                    BUCKET_DISPLAY_NAME,
                    MediaStore.MediaColumns.DATE_MODIFIED,
                    MediaStore.MediaColumns.DATE_TAKEN,
                    MediaStore.MediaColumns.DISPLAY_NAME,
                    MediaStore.MediaColumns.SIZE,
                )

                val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                } else {
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                }

//            val uri = MediaStore.Files.getContentUri("external")

                val filterMedia = com.gallery.photos.vault.album.GalleryApp.Companion.preferences.getFilterMedia()
                val selection =
                    com.gallery.photos.vault.album.GalleryApp.Companion.getSelectionQuery(
                        filterMedia
                    )
                val selectionArgs = com.gallery.photos.vault.album.GalleryApp.Companion.getSelectionArgsQuery(
                    filterMedia
                ).toTypedArray()

                mCursor = com.gallery.photos.vault.album.GalleryApp.Companion.mContext.contentResolver?.query(
                    uri,  // Uri
                    projection,  // Projection
                    selection,
                    selectionArgs,
                    MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
                )
                if (mCursor != null) {
//                Log.e("contentResolver.001", "getImages.mCursor.count::${mCursor.count}")
                    mCursor.moveToFirst()
                    val photoDataArrayList: ArrayList<PictureData> = ArrayList<PictureData>()
                    mCursor.moveToFirst()
                    while (!mCursor.isAfterLast) {
                        //2sec
                        val path =
                            mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                        val title =
                            mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                        var bucketPath = ""
                        bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                        var bucketName =
                            mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))
                        if (bucketName == null) bucketName = path.getParentFolder()

                        val fileSizeLength =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))

                        var excluded = false
                        excluded = excludeList.any { bucketPath.startsWith(it) }

                        if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty() && !excluded) {
                            var d =
                                mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                            d *= 1000
                            var dt =
                                mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                            dt *= 1000
                            if (dt == 0L)
                                dt = d

                            val pictureData =
                                PictureData(path, title, bucketName, d, dt, fileSizeLength, false)
                            pictureData.isFavorite = favList.contains(path)
                            com.gallery.photos.vault.album.GalleryApp.Companion.allMediaList.add(pictureData)
                            Log.e("getAllMedia", "allMediaList.add:$title")

                        }
                        mCursor.moveToNext()
                    }
                    mCursor.close()
                } else Log.e("getAllMedia", "getImages.mCursor.null::")
            } catch (e: Exception) {
                Log.e("getAllMedia", "getImages.Exception::$e")
                Log.e("printStackTrace","printStackTrace:$e")
            } finally {
                Log.e("getAllMediaTimer", "end.getImages")
                Log.e("getAllMedia", "getImages.finally")
                com.gallery.photos.vault.album.GalleryApp.Companion.getVideos()
            }
        }
        private fun getVideos() {
            Log.e("getAllMediaTimer", "start.getVideos")
            Log.e("getAllMedia", "getVideos")
            var title: String
            var path: String
            val duration: Int
            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

            val projection = arrayOf(
                MediaStore.Video.VideoColumns.DATA,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.VideoColumns.SIZE,
                MediaStore.Video.VideoColumns.DURATION,
                MediaStore.Video.VideoColumns.DATE_MODIFIED,
                MediaStore.Video.VideoColumns.DATE_TAKEN,
                MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            )
            val folderList: MutableList<String> = ArrayList<String>()

            val excludeList: ArrayList<String> = ArrayList()
            excludeList.addAll(com.gallery.photos.vault.album.GalleryApp.Companion.preferences?.getExcludeList()!!)

            val favList: ArrayList<String> = ArrayList()
            favList.addAll(com.gallery.photos.vault.album.GalleryApp.Companion.preferences?.getFavoriteList()!!)
            try {
                val filterMedia = com.gallery.photos.vault.album.GalleryApp.Companion.preferences?.getFilterMedia()!!
                val selection =
                    com.gallery.photos.vault.album.GalleryApp.Companion.getSelectionQuery(
                        filterMedia
                    )
                val selectionArgs = com.gallery.photos.vault.album.GalleryApp.Companion.getSelectionArgsQuery(
                    filterMedia
                ).toTypedArray()

                val cursor = com.gallery.photos.vault.album.GalleryApp.Companion.mContext.contentResolver?.query(
                    uri,
                    projection,
                    selection,
                    selectionArgs,
                    MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
                )

                if (cursor != null) {
//                Log.e("contentResolver.001", "getVideos.mCursor.count::${cursor.count}")
                    duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                    cursor.moveToFirst()
                    while (!cursor.isAfterLast) {
                        path =
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                        title =
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                        var bucketName =
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                        if (bucketName == null) bucketName = path.getParentFolder()

                        var bucketPath = ""
                        bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                        var excluded = false
                        excluded = excludeList.any { bucketPath.startsWith(it) }

                        if (!folderList.contains(bucketPath)&& !excluded) {
                            var d =
                                cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                            d *= 1000
                            val fileSizeLength =
                                cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                            var dt =
                                cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))

                            dt *= 1000
                            if (dt == 0L)
                                dt = d

//                        Log.e("contentResolver.001", "getVideos path:$path, title:$title, bucketName:$bucketName, d:$d, dt:$dt, fileSizeLength:$fileSizeLength, duration:$duration")
                            val pictureData = PictureData(
                                path,
                                title,
                                bucketName,
                                d,
                                dt,
                                fileSizeLength,
                                true,
                                cursor.getLong(duration)
                            )
                            pictureData.isFavorite = favList.contains(path)
                            pictureData.isVideo = true
                            com.gallery.photos.vault.album.GalleryApp.Companion.allMediaList.add(pictureData)
                            Log.e("getAllMedia", "allMediaList.add:$title")

                        }
                        cursor.moveToNext()
                    }
                    cursor.close()
                } else
                    Log.e("getAllMedia", "getVideos.mCursor.null::")
            } catch (exp: java.lang.Exception) {
                Log.e("getAllMedia", "Exception.getVideos::$exp")
                exp.printStackTrace()
            } finally {
                Log.e("getAllMediaTimer", "end.getVideos")
                Log.e("getAllMedia", "getVideos.finally")
            }
        }
        private fun getSelectionQuery(filterMedia: Int): String {
            val query = StringBuilder()
            if (filterMedia and TYPE_IMAGES != 0) {
                photoExtensions.forEach {
                    query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
                }
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

                rawExtensions.forEach {
                    query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
                }
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }

            if (filterMedia and TYPE_VIDEOS != 0) {
                videoExtensions.forEach {
                    query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
                }
            }

            if (filterMedia and TYPE_GIFS != 0) {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }

            return query.toString().trim().removeSuffix("OR")
        }
        private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
            val args = ArrayList<String>()
            if (filterMedia and TYPE_IMAGES != 0) {
                photoExtensions.forEach {
                    args.add("%$it")
                }
                args.add("%.jpg")
                args.add("%.jpeg")
                rawExtensions.forEach {
                    args.add("%$it")
                }
                args.add("%.svg")
            }

            if (filterMedia and TYPE_VIDEOS != 0) {
                videoExtensions.forEach {
                    args.add("%$it")
                }
            }

            if (filterMedia and TYPE_GIFS != 0) {
                args.add("%.gif")
            }

            return args
        }

    }

//    override fun onPauseApp(fCurrentActivity: Activity) {
//
//    }
    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (fCurrentActivity is com.gallery.photos.vault.album.SplashActivity) {
            return false
        } else if (fCurrentActivity is PermissionActivity) {
            return false
        } /*else if (fCurrentActivity is CallerActivity) {
            return false
        }*/ else if (AdsConfig.isSystemDialogOpen) {
            AdsConfig.isSystemDialogOpen = false
            return false
        }
        return true
    }

    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
//            if (!OpenAdHelper.isAdAvailable()) {
                val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
                intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
                fCurrentActivity.startActivity(intent)
//            }
//            else {
//                logMessages("app_appopen_created", fCurrentActivity.localClassName)
//            }
            }
    }

    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {
    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {
    }


}
