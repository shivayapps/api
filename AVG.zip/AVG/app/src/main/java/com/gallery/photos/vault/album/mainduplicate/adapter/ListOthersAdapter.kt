package com.gallery.photos.vault.album.mainduplicate.adapter

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photos.vault.album.mainduplicate.adapter.ListOthersAdapter.OtherViewHolder
import com.gallery.photos.vault.album.mainduplicate.callbacks.MarkedListener
import com.gallery.photos.vault.album.mainduplicate.model.IndividualGroupModel
import com.gallery.photos.vault.album.mainduplicate.model.ItemDuplicateModel
import com.gallery.photos.vault.album.R
import com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions
import com.gallery.photos.vault.album.mainduplicate.utils.MyUtils
import com.gallery.photos.vault.album.mainduplicate.utils.PreviewDialog
import com.gallery.photos.vault.album.mainduplicate.utils.ShareConstants

class ListOthersAdapter(
    var listOtherAdapterContext: Context,
    var otherMarkedListener: MarkedListener,
    var individualGroupOthers: IndividualGroupModel,
    var others: List<ItemDuplicateModel>,
    var parentCheckbox: CheckBox) : RecyclerView.Adapter<OtherViewHolder>() {

    var inflater: LayoutInflater = listOtherAdapterContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    var totalNumberOfflineInSet = 0

    class OtherViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imageView: ImageView = itemView.findViewById(R.id.documentFile)
        var linearLayout: LinearLayout = itemView.findViewById(R.id.linear_other_click)
        var otherCheckbox: CheckBox = itemView.findViewById<View>(R.id.documentcheckbox) as CheckBox
        var otherFileName: TextView = itemView.findViewById(R.id.fileName)
        var otherFilePath: TextView = itemView.findViewById(R.id.filePath)
        var otherFileSize: TextView = itemView.findViewById(R.id.fileSize)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OtherViewHolder {
        return OtherViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.row_list_of_others_files_item, parent, false))
    }

    override fun onBindViewHolder(holder: OtherViewHolder, position: Int) {
        val lOtherItem = others[position]
        holder.otherFileName.text = com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.getFileName(lOtherItem.filePath)
        holder.otherFileSize.text = com.gallery.photos.vault.album.mainduplicate.utils.ShareConstants.getReadableFileSize(lOtherItem.sizeOfTheFile)
        holder.otherFilePath.text = lOtherItem.filePath
        holder.otherCheckbox.isChecked = lOtherItem.isFileCheckBox
        holder.imageView.setOnClickListener {
            if (SystemClock.elapsedRealtime() - com.gallery.photos.vault.album.mainduplicate.utils.ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            com.gallery.photos.vault.album.mainduplicate.utils.ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
//            val intent = Intent(listOtherAdapterContext, PreviewOthersDuplicateActivity::class.java)
//            val bundle = Bundle()
//            bundle.putSerializable("otherFiles", lOtherItem)
//            intent.putExtras(bundle)
//            intent.putExtra("totalNumberOfFiles", totalNumberOfflineInSet)
//            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
//            listOtherAdapterContext.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(listOtherAdapterContext, R.anim.slide_from_right, R.anim.slide_from_left).toBundle())

            PreviewDialog.showPreviewDialog(listOtherAdapterContext, lOtherItem)
        }
        holder.linearLayout.setOnClickListener {
            if (SystemClock.elapsedRealtime() - com.gallery.photos.vault.album.mainduplicate.utils.ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            com.gallery.photos.vault.album.mainduplicate.utils.ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
//            val intent = Intent(listOtherAdapterContext, PreviewOthersDuplicateActivity::class.java)
//            val bundle = Bundle()
//            bundle.putSerializable("otherFiles", lOtherItem)
//            intent.putExtras(bundle)
//            intent.putExtra("totalNumberOfFiles", totalNumberOfflineInSet)
//            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
//            listOtherAdapterContext.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(listOtherAdapterContext, R.anim.slide_from_right, R.anim.slide_from_left).toBundle())

            PreviewDialog.showPreviewDialog(listOtherAdapterContext, lOtherItem)
        }
        holder.otherCheckbox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            buttonView.setOnClickListener {
                lOtherItem.isFileCheckBox = isChecked
                var selectCount = 0
                val numOffline = itemCount
                if (lOtherItem.isFileCheckBox) {
                    for (i in 0 until itemCount) {
                        if (others[i].isFileCheckBox) {
                            selectCount++
                        }
                    }
                    if (selectCount != numOffline) {
                        com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_others.add(lOtherItem)
                        com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.addSizeOthers(lOtherItem.sizeOfTheFile)
                        otherMarkedListener.updateMarked()
                        individualGroupOthers.isCheckBox = true
                        parentCheckbox.isChecked = true
                    }
                } else {
                    com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_others.remove(lOtherItem)
                    com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions.subSizeOthers(lOtherItem.sizeOfTheFile)
                    otherMarkedListener.updateMarked()
                }
                if (selectCount < numOffline - 1) {
                    parentCheckbox.isChecked = false
                    individualGroupOthers.isCheckBox = false
                } else {
                    parentCheckbox.isChecked = true
                    individualGroupOthers.isCheckBox = true
                }
                if (numOffline == selectCount) {
                    com.gallery.photos.vault.album.mainduplicate.utils.MyUtils.showToastMsg(
                        listOtherAdapterContext,
                        listOtherAdapterContext.getString(R.string.error_not_select_all_other_in_same)
                    )
                    lOtherItem.isFileCheckBox = false
                    holder.otherCheckbox.isChecked = false
                    return@setOnClickListener
                }
                lOtherItem.isFileCheckBox = isChecked
            }
        }
    }

    override fun getItemCount(): Int {
        totalNumberOfflineInSet = others.size
        return totalNumberOfflineInSet
    }

}