package com.gallery.photos.vault.album.asynctasks

import android.content.Context
import android.os.AsyncTask
import com.gallery.photos.vault.album.helper.MediaFetcher
import com.gallery.photos.vault.album.model.PictureData
import com.gallery.photos.vault.album.utils.Constant
import com.gallery.photos.vault.album.utils.Preferences
import com.gallery.photos.vault.album.utils.SHOW_ALL


class GetMediaAsynctask(
    val context: Context,
    val mPath: String,
    val isPickImage: Boolean = false,
    val isPickVideo: Boolean = false,
    val showAll: Boolean,
    val callback: (media: ArrayList<PictureData>) -> Unit
) :
    AsyncTask<Void, Void, ArrayList<PictureData>>() {
    private val mediaFetcher = MediaFetcher(context)
    val config = Preferences(context)

    override fun doInBackground(vararg params: Void): ArrayList<PictureData> {

        val pathToUse = if (showAll) SHOW_ALL else mPath
        val folderGrouping = config.getGroupBy()
        val folderSorting = config.getSortType()
        val getProperDateTaken = folderSorting and Constant.SORT_DATE_TAKEN != 0 ||
                folderGrouping and Constant.GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                folderGrouping and Constant.GROUP_BY_DATE_TAKEN_MONTHLY != 0

        val getProperLastModified = folderSorting and Constant.SORT_DATE_TAKEN != 0 ||
                folderGrouping and Constant.GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                folderGrouping and Constant.GROUP_BY_LAST_MODIFIED_MONTHLY != 0

        val getProperFileSize = folderSorting and Constant.SORT_SIZE != 0
        val favoritePaths = config.getFavoriteList()
//        val getVideoDurations = context.config.showThumbnailVideoDuration
        val getVideoDurations = false
        val lastModifieds =
            if (getProperLastModified) mediaFetcher.getLastModifieds()
            else HashMap()

        val dateTakens =
            if (getProperDateTaken) mediaFetcher.getDateTakens()
            else HashMap()

        val media =
            if (showAll) {
//            val foldersToScan = mediaFetcher.getFoldersToScan().filter { it != RECYCLE_BIN && it != FAVORITES && !context.config.isFolderProtected(it) }
//                val foldersToScan = mediaFetcher.getFoldersToScan().filter { !config.isFolderProtected(it) }
                val foldersToScan = mediaFetcher.getFoldersToScan()
                val media = ArrayList<PictureData>()
                foldersToScan.forEach {
                    val newMedia = mediaFetcher.getFilesFrom(
                        it,
                        isPickImage,
                        isPickVideo,
                        getProperDateTaken,
                        getProperLastModified,
                        getProperFileSize,
                        favoritePaths,
                        getVideoDurations,
                        lastModifieds,
                        dateTakens.clone() as HashMap<String, Long>,
                        null
                    )
                    media.addAll(newMedia)
                }

                mediaFetcher.sortMedia(media, config.getSortType())
                media
            } else {
                mediaFetcher.getFilesFrom(
                    mPath,
                    isPickImage,
                    isPickVideo,
                    getProperDateTaken,
                    getProperLastModified,
                    getProperFileSize,
                    favoritePaths,
                    getVideoDurations,
                    lastModifieds,
                    dateTakens,
                    null
                )
            }

//        return mediaFetcher.groupMedia(media, pathToUse)
        return media
    }

    override fun onPostExecute(media: ArrayList<PictureData>) {
        super.onPostExecute(media)
        callback(media)
    }

    fun stopFetching() {
        mediaFetcher.shouldStop = true
        cancel(true)
    }
}
