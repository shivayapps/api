package com.gallery.photos.vault.album.mainduplicate.asynctask;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;

import com.gallery.photos.vault.album.R;
import com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions;
import com.gallery.photos.vault.album.mainduplicate.activity.duplicateactivities.DuplicateAudiosDuplicateActivity;
import com.gallery.photos.vault.album.mainduplicate.activity.duplicateactivities.DuplicateDocumentsDuplicateActivity;
import com.gallery.photos.vault.album.mainduplicate.activity.duplicateactivities.DuplicateImageDuplicateActivity;
import com.gallery.photos.vault.album.mainduplicate.activity.duplicateactivities.DuplicateOthersDuplicateActivity;
import com.gallery.photos.vault.album.mainduplicate.activity.duplicateactivities.DuplicateVideosDuplicateActivity;
import com.gallery.photos.vault.album.mainduplicate.callbacks.SearchListener;
import com.gallery.photos.vault.album.mainduplicate.model.DuplicateFileRemoverSharedPreferences;
import com.gallery.photos.vault.album.mainduplicate.model.DuplicateFoundAndSize;
import com.gallery.photos.vault.album.mainduplicate.model.Md5Model;
import com.gallery.photos.vault.album.mainduplicate.model.SingleTonDbHandler;

import java.io.File;
import java.util.Map.Entry;

import static com.gallery.photos.vault.album.mainduplicate.utils.MyUtils.getSD_CardPath_M;
import static com.gallery.photos.vault.album.mainduplicate.utils.MyUtils.logError;

import com.gallery.photos.vault.album.mainduplicate.GlobalVarsAndFunctions;
import com.gallery.photos.vault.album.mainduplicate.model.DuplicateFileRemoverSharedPreferences;
import com.gallery.photos.vault.album.mainduplicate.model.DuplicateFoundAndSize;
import com.gallery.photos.vault.album.mainduplicate.model.Md5Model;
import com.gallery.photos.vault.album.mainduplicate.model.SingleTonDbHandler;
import com.gallery.photos.vault.album.mainduplicate.utils.MyUtils;


@SuppressWarnings("deprecation")
@SuppressLint("StaticFieldLeak")
public class ReadingAllFilesAsyncTask extends AsyncTask<Void, String, Void> {
    private static final String LOG_TAG = "ReadingAllAudioFiles";
    int count = 1;
    File file1 = new File(GlobalVarsAndFunctions.SDCARD_1);
    File file2 = new File(GlobalVarsAndFunctions.SDCARD_2);
    File file3 = new File(GlobalVarsAndFunctions.SDCARD_3);
    File file4 = new File(GlobalVarsAndFunctions.SDCARD_4);
    File file5 = new File(GlobalVarsAndFunctions.SDCARD_5);
    File file6 = new File(GlobalVarsAndFunctions.SDCARD_6);
    Context readingAllFilesContext;
    SearchListener searchListener;
    String[] updateProgress;
    SingleTonDbHandler singleTonDbHandler;
    String mCheckIsType;

    public ReadingAllFilesAsyncTask(Context context, SearchListener searchListeners, String isCheckType) {
        readingAllFilesContext = context;
        searchListener = searchListeners;
        mCheckIsType = isCheckType;
    }

    protected void onPreExecute() {
        super.onPreExecute();
        resetAllBeforeStartScan();
    }

    private void resetAllBeforeStartScan() {
        DuplicateFileRemoverSharedPreferences.setStopScan(readingAllFilesContext, false);
        DuplicateFileRemoverSharedPreferences.setInitiateRescanAndEnterImagePageFirstTimeAfterScan(readingAllFilesContext, true);
        DuplicateFileRemoverSharedPreferences.setInitiateRescanAndEnterVideoPageFirstTimeAfterScan(readingAllFilesContext, true);
        DuplicateFileRemoverSharedPreferences.setInitiateRescanAndEnterAudioPageFirstTimeAfterScan(readingAllFilesContext, true);
        DuplicateFileRemoverSharedPreferences.setInitiateRescanAndEnterDocumentPageFirstTimeAfterScan(readingAllFilesContext, true);
        DuplicateFileRemoverSharedPreferences.setInitiateRescanAndEnterOtherPageFirstTimeAfterScan(readingAllFilesContext, true);
        clearFilterList();
        singleTonDbHandler = new SingleTonDbHandler(readingAllFilesContext);
        singleTonDbHandler.getInstance().clearAllFilesInfoTable();
        GlobalVarsAndFunctions.resetOneTimePopUp();
        DuplicateFoundAndSize.setTotalDuplicatePhotos(0);
        DuplicateFoundAndSize.setTotalDuplicateVideos(0);
        DuplicateFoundAndSize.setTotalDuplicateAudios(0);
        DuplicateFoundAndSize.setTotalDuplicateDocuments(0);
        DuplicateFoundAndSize.setTotalDuplicateOthers(0);
        singleTonDbHandler.getInstance().groupTagMediaPhotos = 0;
        singleTonDbHandler.getInstance().groupTagMediaVideos = 0;
        singleTonDbHandler.getInstance().groupTagMediaAudios = 0;
        singleTonDbHandler.getInstance().groupTagMediaDocuments = 0;
        singleTonDbHandler.getInstance().groupTagMediaOthers = 0;
        GlobalVarsAndFunctions.listOfGroupedDuplicatesPhotos.clear();
        GlobalVarsAndFunctions.listOfGroupedDuplicatesVideos.clear();
        GlobalVarsAndFunctions.listOfGroupedDuplicatesAudios.clear();
        GlobalVarsAndFunctions.listOfGroupedDuplicatesDocument.clear();
        GlobalVarsAndFunctions.listOfGroupedDuplicatesOthers.clear();
        GlobalVarsAndFunctions.uniqueMd5Value.clear();
        GlobalVarsAndFunctions.uniqueExtension.clear();
        GlobalVarsAndFunctions.uniqueOtherExtensionsMap.clear();
        GlobalVarsAndFunctions.notificationUniqueOtherExtensionsMap.clear();
        GlobalVarsAndFunctions.uniqueAudiosExtension.clear();
        GlobalVarsAndFunctions.uniqueDocumentsExtension.clear();
        GlobalVarsAndFunctions.uniquePhotosExtension.clear();
        GlobalVarsAndFunctions.uniqueVideosExtension.clear();
        GlobalVarsAndFunctions.uniqueOthersExtensionAfterDuplicates.clear();
        GlobalVarsAndFunctions.uniqueOthersExtensionBeforeDuplicates.clear();
    }

    private void clearFilterList() {
        DuplicateAudiosDuplicateActivity.filterListAudios.clear();
        DuplicateImageDuplicateActivity.filterListPhotos.clear();
        DuplicateVideosDuplicateActivity.filterListVideos.clear();
        DuplicateDocumentsDuplicateActivity.filterListDocuments.clear();
        DuplicateOthersDuplicateActivity.filterListOthers.clear();
    }

    protected void onProgressUpdate(String... values) {
        super.onProgressUpdate(values);
        searchListener.updateUi(values);
    }

    protected Void doInBackground(Void... params) {
        walkDir(Environment.getExternalStorageDirectory());
        if (file1.exists()) {
            walkDir(file1);
        } else if (file2.exists()) {
            walkDir(file2);
        } else if (file3.exists()) {
            walkDir(file3);
        } else if (file4.exists()) {
            walkDir(file4);
        } else if (file5.exists()) {
            walkDir(file5);
        } else if (file6.exists()) {
            walkDir(file6);
        } else {
            String externalStorageFilePath = MyUtils.getSD_CardPath_M(readingAllFilesContext);
            if (externalStorageFilePath != null) {
                walkDir(new File(externalStorageFilePath));
            }
        }
        if (!DuplicateFileRemoverSharedPreferences.isScanningStop(readingAllFilesContext)) {
            updateProgress = new String[]{"Sorting", readingAllFilesContext.getString(R.string.label_duplicate_please_wait)};
            groupDuplicateAccordingToFormats();
        }
        return null;
    }

    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        Log.e(LOG_TAG, "onPostExecute: isCheck " + DuplicateFileRemoverSharedPreferences.isScanningStop(readingAllFilesContext));
        if (!DuplicateFileRemoverSharedPreferences.isScanningStop(readingAllFilesContext)) {
            Log.e(LOG_TAG, "onPostExecute: checkScanFinish");
            searchListener.checkScanFinish();
        } else {
            Log.e(LOG_TAG, "onPostExecute: isCheck else " + DuplicateFileRemoverSharedPreferences.isScanningStop(readingAllFilesContext));
        }
    }

    public void walkDir(File dir) {
        File[] listFile = dir.listFiles();
        if (listFile != null && !DuplicateFileRemoverSharedPreferences.isScanningStop(readingAllFilesContext)) {
            int i = 0;
            while (i < listFile.length) {
                if (!DuplicateFileRemoverSharedPreferences.isScanningStop(readingAllFilesContext)) {
                    if (!listFile[i].isDirectory()) {
                        String filePath = listFile[i].getAbsolutePath();
                        if (!DuplicateFileRemoverSharedPreferences.isScanningStop(readingAllFilesContext)) {
                            boolean isConditionTrue = false;

                            switch (mCheckIsType) {
                                case "Audio":
                                    isConditionTrue = GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.AAC)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.MP3)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.WMA)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.M4A)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.OGG)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.WAV);
                                    break;
                                case "Document":
                                    isConditionTrue = GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.DOC)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.DOCX)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.TXT)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.PDF)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.XLS)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.XLSX)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.PPT)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.PPTX)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.CSV)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.XLT)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.XLTX)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.RTF)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.CHM);
                                    break;
                                case "Image":
                                    isConditionTrue = GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.JPG)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.AJPG)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.JPEG)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.PNG)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.BMP)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.TIFF)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.PSD)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.PIC)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.GIF)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.WEBP)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.HEIC)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.DWG)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.RAW)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.SRF)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.DNG)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.KDC)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.NRW)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.ORF)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.CPT);
                                    break;
                                case "Other":
                                    isConditionTrue = GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.ZIP)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.WMV)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.APK)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.VCF)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.OGGOTHER)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.DB);
                                    break;
                                case "Video":
                                    isConditionTrue = GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.MP4)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.WMV)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.XVID)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.DIVX)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.ASF)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.GP3)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.GP33)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.M4V)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.MOV)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.MKV)
                                            || GlobalVarsAndFunctions.getFileName(filePath).endsWith(GlobalVarsAndFunctions.AVI);
                                    break;
                            }

                            if (isConditionTrue) {
                                count++;
                                updateProgress = new String[]{"Scanning", "" + count};
                                publishProgress(updateProgress);
                                Md5Model md5Model = new Md5Model();
                                String md5CheckSum = GlobalVarsAndFunctions.getMd5Checksum(filePath, readingAllFilesContext);
                                md5Model.setMd5Value(md5CheckSum);
                                md5Model.setFilePath(filePath);
                                md5Model.setExtension("." + GlobalVarsAndFunctions.getExtension(filePath));
                                GlobalVarsAndFunctions.uniqueMd5Value.put(md5CheckSum, "." + GlobalVarsAndFunctions.getExtension(filePath));
                                GlobalVarsAndFunctions.uniqueExtension.add("." + GlobalVarsAndFunctions.getExtension(filePath));
                                addToDb(md5Model);
                            }
                        }
                    } else if (!(listFile[i].getAbsolutePath().contains("data") ||listFile[i].getAbsolutePath().contains("obj")
                            ||listFile[i].getAbsolutePath().contains("obb") ||
                            listFile[i].getAbsolutePath().contains("system") ||
                            listFile[i].getAbsolutePath().contains("LOST.DIR") ||
                            listFile[i].getName().startsWith(".") ||
                            listFile[i].getAbsolutePath().contains("cache"))) {
                        walkDir(listFile[i]);
                    }
                }
                i++;
            }
        }
    }

    private void addToDb(Md5Model md5Model) {
        singleTonDbHandler.getInstance().addMd5ValueOfFiles(md5Model);
    }

    private void groupDuplicateAccordingToFormats() {
        onProgressUpdate(updateProgress);
        for (Entry<String, String> entry : GlobalVarsAndFunctions.uniqueMd5Value.entrySet()) {
            if (!DuplicateFileRemoverSharedPreferences.isScanningStop(readingAllFilesContext)) {
                Log.e(LOG_TAG, "groupDuplicateAccordingToFormats: " + entry.getValue());
                singleTonDbHandler.getInstance().getDuplicateFiles(readingAllFilesContext, GlobalVarsAndFunctions.readDuplicateFiles(entry.getKey(), entry.getValue(), GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO), entry.getKey(), entry.getValue());
            }
        }
        GlobalVarsAndFunctions.tempFilterListPhotos.clear();
        GlobalVarsAndFunctions.tempFilterListVideos.clear();
        GlobalVarsAndFunctions.tempFilterListAudios.clear();
        GlobalVarsAndFunctions.tempFilterListDocuments.clear();
        GlobalVarsAndFunctions.tempFilterListOthers.clear();
        for (String extension : GlobalVarsAndFunctions.uniquePhotosExtension) {
            if (!DuplicateFileRemoverSharedPreferences.isScanningStop(readingAllFilesContext)) {
                GlobalVarsAndFunctions.tempFilterListPhotos.put(extension, Boolean.FALSE);
            }
        }
        for (String extension2 : GlobalVarsAndFunctions.uniqueVideosExtension) {
            if (!DuplicateFileRemoverSharedPreferences.isScanningStop(readingAllFilesContext)) {
                GlobalVarsAndFunctions.tempFilterListVideos.put(extension2, Boolean.FALSE);
            }
        }
        for (String extension22 : GlobalVarsAndFunctions.uniqueAudiosExtension) {
            if (!DuplicateFileRemoverSharedPreferences.isScanningStop(readingAllFilesContext)) {
                GlobalVarsAndFunctions.tempFilterListAudios.put(extension22, Boolean.FALSE);
            }
        }
        for (String extension222 : GlobalVarsAndFunctions.uniqueDocumentsExtension) {
            if (!DuplicateFileRemoverSharedPreferences.isScanningStop(readingAllFilesContext)) {
                GlobalVarsAndFunctions.tempFilterListDocuments.put(extension222, Boolean.FALSE);
            }
        }
        for (Entry<String, String> entry2 : GlobalVarsAndFunctions.uniqueOtherExtensionsMap.entrySet()) {
            if (!DuplicateFileRemoverSharedPreferences.isScanningStop(readingAllFilesContext)) {
                MyUtils.logError("In others: " + entry2.getKey() + "ext: " + entry2.getValue());
                String readOtherDuplicatesFiles = "select path,extension from allFilesInfoTable where md5 = '" + entry2.getKey() + "'" + " and " + GlobalVarsAndFunctions.KEY_EXTENSION + " = '" + entry2.getValue() + "'";
                singleTonDbHandler.getInstance().getDuplicatesFromTable(readingAllFilesContext, readOtherDuplicatesFiles, GlobalVarsAndFunctions.OTHERS, entry2.getValue(), entry2.getKey());
            }
        }
        MyUtils.logError("Others File extensions: " + GlobalVarsAndFunctions.uniqueOthersExtensionAfterDuplicates);
        for (String extension2222 : GlobalVarsAndFunctions.uniqueOthersExtensionAfterDuplicates) {
            if (!DuplicateFileRemoverSharedPreferences.isScanningStop(readingAllFilesContext)) {
                GlobalVarsAndFunctions.tempFilterListOthers.put(extension2222, Boolean.FALSE);
            }
        }
    }

    public void stopAsyncTask() {
        MyUtils.logError("Scanning is stopped!!!!!!!!");
        DuplicateFileRemoverSharedPreferences.setStopScan(readingAllFilesContext, true);
    }
}