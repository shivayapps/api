package com.gallery.photos.vault.album.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "hiddenData")
data class HiddenData(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0
    , var hidePath: String
    , var restorePath: String
    , var isVideo: Int=0
    , var extension: String
    , var folder: String
    , var isDeleted: Boolean=false
)