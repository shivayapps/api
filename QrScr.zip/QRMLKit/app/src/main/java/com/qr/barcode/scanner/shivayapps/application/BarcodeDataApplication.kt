package com.qr.barcode.scanner.shivayapps.application

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.annotation.Keep
import com.adconfig.AdsConfig
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.WelcomeBackActivity
import com.qr.barcode.scanner.shivayapps.R
import dagger.hilt.android.HiltAndroidApp


@Keep
@HiltAndroidApp
class BarcodeDataApplication : AppOpenApplication(),AppOpenApplication.AppLifecycleListener {


    override fun initApp() {
//        super.initApp()

        val AdmobAppOpenId = getString(R.string.admob_open)
        AdsConfig.builder()
            .setTestDeviceId("0")
            .setAdmobAppOpenId(AdmobAppOpenId)
            .build(this)

        setAppLifecycleListener(this)
        initMobileAds()
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (AdsConfig.isSystemDialogOpen) {
            Handler(Looper.getMainLooper()).postDelayed({
                AdsConfig.isSystemDialogOpen = false
            }, 2000)
            return false
        }
        return true
    }

    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
                if (OpenAdHelper.isAdAvailable()) {
                    val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
                    intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
                    fCurrentActivity.startActivity(intent)
                }
            }
    }

    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {

    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {

    }
}