/*
 * Copyright 2023 Yatik
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.qr.barcode.scanner.shivayapps.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Parcelable
import android.util.DisplayMetrics
import android.util.Log
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.navigation.fragment.findNavController
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.qr.barcode.scanner.shivayapps.R
import com.qr.barcode.scanner.shivayapps.databinding.ActivityMainBinding
import com.qr.barcode.scanner.shivayapps.ui.fragments.cropper.CropperFragment
import com.qr.barcode.scanner.shivayapps.utils.AdCache
import com.qr.barcode.scanner.shivayapps.utils.ThemeManager.Companion.updateTheme
import com.qr.barcode.scanner.shivayapps.utils.Utilities
import com.qr.barcode.scanner.shivayapps.utils.statusBarHeight
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        updateTheme(this@MainActivity)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Utilities().setSystemBars(window, this)
        //WindowCompat.setDecorFitsSystemWindows(window, false)

        ViewCompat.setOnApplyWindowInsetsListener(binding.mainLayout) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
//        val settingsFragment = findViewById<LinearLayout>(R.id.settings_frag)
//        ViewCompat.setOnApplyWindowInsetsListener(settingsFragment) { v, windowInsets ->
//            val insets = windowInsets.getInsets(
//                WindowInsetsCompat.Type.systemBars()
//                        or WindowInsetsCompat.Type.displayCutout()
//            )
//            v.updatePadding(
//                left = insets.left,
//                right = insets.right,
//                bottom = insets.bottom,
//            )
//            windowInsets
//        }
        //WindowCompat.setDecorFitsSystemWindows(window, false)
//        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
//            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
//            insets
//        }

//        binding.root.setPadding(0, statusBarHeight, 0, 0)

        when (intent?.action) {
            Intent.ACTION_SEND -> if (intent.type?.startsWith("image/") == true) {
                val bundle = Bundle()
                @Suppress("DEPRECATION")
                (intent.getParcelableExtra<Parcelable>(Intent.EXTRA_STREAM) as? Uri)?.let {
                    bundle.putString(CropperFragment.ARG_KEY, it.toString())
                    val navHostFragment =
                        supportFragmentManager.findFragmentById(R.id.main_nav_host_fragment)
                    val navController = navHostFragment?.findNavController()
                    navController?.navigate(
                        R.id.cropperFragment, bundle
                    )
                }
            }
        }
        initAdSize()
        loadAds()
    }

    private fun initAdSize() {
        Log.d("TAG", "initAdSize.001")
        val display = windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val widthPixels = outMetrics.widthPixels.toFloat()

        val density = outMetrics.density
        val adWidth = (widthPixels / density).toInt()

        AdsParameters(this@MainActivity).adWidth = adWidth
        Log.d("TAG", "initAdSize.002")
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    fun loadAds() {
        val adId = getString(R.string.admob_banner)
        BannerAdHelper.showBanner(
            this, binding.bannerContainer, binding.bannerContainer, adId,
            AdCache.bannerDetail, { isLoaded, adView, message ->
                AdCache.bannerDetail = adView
                mAdView = adView
                isAdLoaded = isLoaded
            }
        )
    }

}
