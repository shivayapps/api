plugins {
    id("com.android.application")
    id("kotlin-android")
    id("androidx.navigation.safeargs.kotlin")
    id("kotlin-parcelize")
    id("org.jetbrains.kotlin.android")
    id("com.google.dagger.hilt.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.qr.barcode.scanner.shivayapps"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.qr.barcode.scanner.shivayapps"
        minSdk = 23
        targetSdk = 35
        versionCode = 15
        versionName = "1.5"

        multiDexEnabled = true
        testInstrumentationRunner = "com.qr.barcode.scanner.shivayapps.HiltTestRunner"

        ksp {
            arg("room.schemaLocation", "$projectDir/schemas")
        }
    }

    sourceSets["androidTest"].assets.srcDirs(
        file("$projectDir/schemas")
    )

    signingConfigs {
        create("key") {
            storeFile = file("com.qr.barcode.scanner.jks")
            storePassword = "com.qr.barcode.scanner"
            keyAlias = "com.qr.barcode.scanner"
            keyPassword = "com.qr.barcode.scanner"
        }
    }

    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("key")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                file("proguard-rules.pro")
            )

            resValue("string", "ads_application_id", "ca-app-pub-2750800778809761~3583992336")
            resValue("string", "admob_banner", "ca-app-pub-2750800778809761/8996101110")
            resValue("string", "admob_native", "ca-app-pub-2750800778809761/9851971494")
            resValue("string", "admob_inter", "ca-app-pub-2750800778809761/2622264459")
            resValue("string", "admob_open", "ca-app-pub-2750800778809761/1715257335")
        }

        getByName("debug") {
            signingConfig = signingConfigs.getByName("key")
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                file("proguard-rules.pro")
            )

            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")
            resValue("string", "admob_banner", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "admob_native", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "admob_inter", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "admob_open", "ca-app-pub-3940256099942544/9257395921")
        }
    }

    buildFeatures {
        viewBinding = true
    }

    packaging {
        resources {
            excludes += "META-INF/atomicfu.kotlin_module"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
        kotlinOptions.jvmTarget = "17"
    }

    tasks.withType<com.google.devtools.ksp.gradle.KspTask>().configureEach {
        kotlinOptions.jvmTarget = "17"
    }
}

dependencies {

    implementation("androidx.preference:preference-ktx:1.2.1")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.test:runner:1.5.2")
    testImplementation("junit:junit:4.13.2")

    implementation("androidx.multidex:multidex:2.0.1")
    implementation("com.android.billingclient:billing-ktx:7.0.0")
    implementation("com.google.android.gms:play-services-ads:23.1.0")
    api("com.facebook.shimmer:shimmer:0.5.0")
    implementation("com.intuit.sdp:sdp-android:1.1.0")

    implementation("androidx.lifecycle:lifecycle-extensions:2.2.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.1")
    annotationProcessor("androidx.lifecycle:lifecycle-compiler:2.6.1")

    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // Navigation
    val nav_version = "2.7.7"
    implementation("androidx.navigation:navigation-fragment-ktx:$nav_version")
    implementation("androidx.navigation:navigation-ui-ktx:$nav_version")

    // CameraX
    val camerax_version = "1.3.1"
    implementation("androidx.camera:camera-core:$camerax_version")
    implementation("androidx.camera:camera-camera2:$camerax_version")
    implementation("androidx.camera:camera-view:$camerax_version")
    implementation("androidx.camera:camera-lifecycle:$camerax_version")

    // ML Kit
    implementation("com.google.mlkit:barcode-scanning:17.3.0")

    // Firebase
    implementation(platform("com.google.firebase:firebase-bom:34.3.0"))
    implementation("com.google.firebase:firebase-crashlytics")
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-messaging")
    implementation("com.google.firebase:firebase-config")

    // Fragments
    val fragment_version = "1.6.2"
    implementation("androidx.fragment:fragment-ktx:$fragment_version")
    debugImplementation("androidx.fragment:fragment-testing:$fragment_version")

    implementation("androidx.coordinatorlayout:coordinatorlayout:1.2.0")

    // Room
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")
    annotationProcessor("androidx.room:room-compiler:$roomVersion")
    androidTestImplementation("androidx.room:room-testing:$roomVersion")

    // Lifecycle
    val lifecycleVersion = "2.7.0"
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:$lifecycleVersion")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:$lifecycleVersion")
    implementation("androidx.lifecycle:lifecycle-common-java8:$lifecycleVersion")

    // Coroutines
    val coroutines = "1.5.2"
    api("org.jetbrains.kotlinx:kotlinx-coroutines-core:$coroutines")
    api("org.jetbrains.kotlinx:kotlinx-coroutines-android:$coroutines")

    // Hilt
    implementation("com.google.dagger:hilt-android:2.51.1")
    ksp("com.google.dagger:hilt-android-compiler:2.51.1")

    // Retrofit
    implementation("com.squareup.retrofit2:retrofit:2.6.0")
    implementation("com.squareup.retrofit2:converter-gson:2.6.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.5.0")

    implementation("androidx.browser:browser:1.7.0")

    // Paging
    val paging_version = "3.3.6"
    implementation("androidx.paging:paging-runtime-ktx:$paging_version")
    implementation("androidx.room:room-paging:2.6.1")
    testImplementation("androidx.paging:paging-common-ktx:$paging_version")

    // Test libs
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.7.1")
    androidTestImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.7.1")
    testImplementation("junit:junit:4.13.2")
    testImplementation("androidx.arch.core:core-testing:2.2.0")
    androidTestImplementation("androidx.test:core:1.4.0")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.arch.core:core-testing:2.2.0")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
    androidTestImplementation("androidx.test.espresso:espresso-contrib:3.3.0")
    androidTestImplementation("androidx.test.espresso:espresso-intents:3.5.1")

    implementation("com.google.zxing:core:3.4.1")
    implementation("org.jsoup:jsoup:1.15.4")
    implementation("io.coil-kt:coil:2.3.0")
    implementation("com.facebook.shimmer:shimmer:0.5.0")
    implementation("com.vanniktech:android-image-cropper:4.5.0")

    testImplementation("com.squareup.okhttp3:mockwebserver:4.6.0")
}
