package com.bankbalanceinquiry.ministatement.Events;

import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;

import java.util.ArrayList;

public class SmsList {

    private ArrayList<HomeAccoutList> homeAccoutLists;
    private ArrayList<HomeAccoutList> allTransactionList;


    public SmsList(ArrayList<HomeAccoutList> homeAccoutLists, ArrayList<HomeAccoutList> allTransactionList) {
        this.homeAccoutLists = homeAccoutLists;
        this.allTransactionList = allTransactionList;
    }

    public ArrayList<HomeAccoutList> getHomeAccoutLists() {
        return homeAccoutLists;
    }

    public void setHomeAccoutLists(ArrayList<HomeAccoutList> homeAccoutLists) {
        this.homeAccoutLists = homeAccoutLists;
    }

    public ArrayList<HomeAccoutList> getAllTransactionList() {
        return allTransactionList;
    }

    public void setAllTransactionList(ArrayList<HomeAccoutList> allTransactionList) {
        this.allTransactionList = allTransactionList;
    }
}
