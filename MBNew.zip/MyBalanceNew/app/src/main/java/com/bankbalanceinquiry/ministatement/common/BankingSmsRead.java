package com.bankbalanceinquiry.ministatement.common;

import android.text.TextUtils;
import android.util.Log;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BankingSmsRead {

    public static void DenaBankDetails() {
        String s = "MAT:TO:My address email;SUB:My title;BODY:My content;;";
        String[] arrayString = s.split(";");

        String email = arrayString[0];
        String title = arrayString[1];
        String body = arrayString[2];

        email = email.substring(email.indexOf("MAT:TO:") + 7);
        title = title.substring(title.indexOf("SUB:") + 4);
        body = body.substring(body.indexOf("BODY:") + 5);

        Log.e("email", email + " title" + title
                + " body " + body);
    }


    public static void SMSok() {
        //   String ss = "Amount of Rs. 0000 is credited to A/C XXXX1111 on date 14-04-2020 Available Clear Bal is Rs. 100.78";
        String ss = "Dear Customer, your Account Number XXXXXX6377 has been credited by Rs 215.000 being DBT/DBTL funds transfer on 19/05/2015 - CENTRAL BANK OF INDIA";
        Pattern regEx
                = Pattern.compile("[0-9]*[Xx\\*]*[0-9]*[Xx\\*]+[0-9]{3,}");
        // Find instance of pattern matches
        Matcher m = regEx.matcher(ss);
        if (m.find()) {
            try {
                Log.e("amount_value= ", "" + m.group(0));
                String amount = (m.group(0).replaceAll("inr", ""));
                amount = amount.replaceAll("rs", "");
                amount = amount.replaceAll("inr", "");
                amount = amount.replaceAll(" ", "");
                amount = amount.replaceAll(",", "");
                Log.e("amountamount", amount);
                // smsDto.setAmount(Double.valueOf(amount));
              /*  String Transactiontype = "";
                if (ss.contains("debited") ||
                        ss.contains("purchasing") || ss.contains("purchase") ||
                        ss.contains("dr")) {
                    Transactiontype = "0";
                    //smsDto.setTransactionType("0");
                } else if (ss.contains("credited") ||ss.contains("cr")) {
                   // smsDto.setTransactionType("1");
                    Transactiontype = "1";
                }*/
                // smsDto.setParsed("1");
                Log.e("matchedValue= ", "" + amount);
               /* if (!Character.isDigit(smsDto.getSenderid().charAt(0)))
                    resSms.add(smsDto);
*/

               /* Log.e("BANKINGDATA==>",
                        "amount " + Double.valueOf(amount)

                );*/

            } catch (Exception e) {
                e.printStackTrace();
                Log.e("No_matchedValue ", e.getMessage());
            }
        } else {
            Log.e("No_matchedValue ", "No_matchedValue ");
        }
    }

    // Final Code
    public static String SMSBodyToGetAccountNumber(String ss) {
       /* String FinalAccountNumber = "";
        Pattern regEx = Pattern.compile("[0-9]*[Xx\\*]*[0-9]*[Xx\\*]+[0-9]{3,}");
        Matcher m = regEx.matcher(ss);
        if (m.find()) {
            try {
                Log.e("amount_value= ", "" + m.group(0));
                String amount = (m.group(0).replaceAll("inr", ""));
                amount = amount.replaceAll("rs", "");
                amount = amount.replaceAll("inr", "");
                amount = amount.replaceAll(" ", "");
                amount = amount.replaceAll(",", "");
                FinalAccountNumber = amount.replaceAll("X", "");
                Log.e("SMSBODY TO", "Account No" + FinalAccountNumber);
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("No_matchedValue ", e.getMessage());
            }
        } else {
            FinalAccountNumber = "";
            Log.e("No_matchedValue ", "No_matchedValue ");
        }
        return FinalAccountNumber; */

//        String FinalAccountNumber = "";
//        Pattern regEx = Pattern.compile("[0-9]*[Xx\\*]*[0-9]*[Xx\\*]+[0-9]{3,}");
//        Matcher m = regEx.matcher(ss);
//        if (m.find())
//        {
//            try {
//                Log.e("amount_value= ", "" + m.group(0));
//                String amount = (m.group(0).replaceAll("inr", ""));
//                amount = amount.replaceAll("rs", "");
//                amount = amount.replaceAll("inr", "");
//                amount = amount.replaceAll(" ", "");
//                amount = amount.replaceAll(",", "");
//                FinalAccountNumber = amount.replaceAll("X", "");
//                Log.e("SMSBODY TO", "Account No" + FinalAccountNumber);
//            } catch (Exception e) {
//                e.printStackTrace();
//                Log.e("No_matchedValue ", e.getMessage());
//            }
//        } else if (TextUtils.isEmpty(FinalAccountNumber)) {
//            ss.toLowerCase().contains("a/c");
//            {
//                if (ss.toLowerCase().indexOf("a/c".toLowerCase()) > -1) {
//                    String[] separated = ss.toLowerCase().split("a/c");
//                    if (separated.length > 1) {
//                        String[] separatednew = separated[1].split(" ");
//                        for (int ii = 0; ii < separatednew.length; ii++) {
//                            String FinalAccoutnNo = separatednew[ii];
//                            if (!TextUtils.isEmpty(FinalAccoutnNo) && !FinalAccoutnNo.equals(".")) {
//                                FinalAccountNumber = FinalAccoutnNo;
//                                break;
//                            }
//                        }
//                    }
//                }
//            }
//        } else {
//            FinalAccountNumber = "";
//            Log.e("No_matchedValue ", "No_matchedValue ");
//        }
//        return FinalAccountNumber;

        String FinalAccountNumber = "";
        Pattern regEx = Pattern.compile("[0-9]*[Xx\\*]*[0-9]*[Xx\\*]+[0-9]{3,}");
        Matcher m = regEx.matcher(ss);

        String Check = ss.toLowerCase();
        if (Check.contains("a/c")) {
            if (ss.toLowerCase().indexOf("a/c".toLowerCase()) > -1) {
                String[] separated = ss.toLowerCase().split("a/c");
                if (separated.length > 1) {

                    String All = separated[1];
                    Log.e("All", All);
                    String[] separatednew = separated[1].split(" ");
                    for (int ii = 0; ii < separatednew.length; ii++) {
                        String FinalAccoutnNo = separatednew[ii];
                        Log.e("ACNOAAAAA", FinalAccoutnNo);
                        if (!TextUtils.isEmpty(FinalAccoutnNo)
                                && !FinalAccoutnNo.equals(".")
                                && TextUtils.isDigitsOnly(FinalAccoutnNo)
                                || FinalAccoutnNo.toLowerCase().contains("x")) {
                            //FinalAccountNumber = FinalAccoutnNo;
                            FinalAccountNumber = FinalAccoutnNo.toLowerCase().replaceAll("x", "");
                            break;
                        }
                    }
                }
            } else {
                try {
                    Log.e("amount_value= ", "" + m.group(0));
                    String amount = (m.group(0).replaceAll("inr", ""));
                    amount = amount.replaceAll("rs", "");
                    amount = amount.replaceAll("inr", "");
                    amount = amount.replaceAll(" ", "");
                    amount = amount.replaceAll(",", "");
                    FinalAccountNumber = amount.replaceAll("X", "");
                    Log.e("SMSBODY TO", "Account No" + FinalAccountNumber);
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("No_matchedValue ", e.getMessage());
                }
            }
        } else if (m.find()) {
            try
            {
                Log.e("amount_value= ", "" + m.group(0));
                String amount = (m.group(0).replaceAll("inr", ""));
                amount = amount.replaceAll("rs", "");
                amount = amount.replaceAll("inr", "");
                amount = amount.replaceAll(" ", "");
                amount = amount.replaceAll(",", "");
                FinalAccountNumber = amount.toLowerCase().replaceAll("x", "");
                Log.e("SMSBODY TO", "Account No" + FinalAccountNumber);
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("No_matchedValue ", e.getMessage());
            }
        } else {
            FinalAccountNumber = "";
            Log.e("No_matchedValue ", "No_matchedValue ");
        }
        return FinalAccountNumber;
    }

    public static String SMSBodyToGetAccountNumberWithoutHideNo(String ss) {
        String FinalAccountNumber = "";
        Pattern regEx = Pattern.compile("[0-9]*[Xx\\*]*[0-9]*[Xx\\*]+[0-9]{3,}");
        Matcher m = regEx.matcher(ss);

        Pattern regExNew = Pattern.compile("([Xx])\\w+");
        Matcher mnew = regExNew.matcher(ss);
        if (m.find()) {
            try {
                Log.e("amount_value= ", "" + m.group(0));
                String amount = (m.group(0));
                FinalAccountNumber = amount;
                Log.e("SMSBODY TO", "Account No" + FinalAccountNumber);
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("No_matchedValue ", e.getMessage());
            }
        } else if (mnew.find()) {
            FinalAccountNumber = mnew.group();
            Log.e("Testtttaatta", " Martch" + mnew.group() + "");
        } else {
            FinalAccountNumber = "";
            Log.e("No_matchedValue ", "No_matchedValue ");
        }
        return FinalAccountNumber;
    }

    public static String SMSBodyToGetTotalAmount(String ss) {
        String FinalAccountNumber = "";
        Pattern regEx = Pattern.compile("[rR][sS]\\.?\\s[,\\d]+\\.?\\d{0,2}|[iI][nN][rR]\\.?\\s*[,\\d]+\\.?\\d{0,2}");
        Matcher m = regEx.matcher(ss);

        Pattern regExRS = Pattern.compile("[Rs]\\w+");
        Matcher mRS = regExRS.matcher(ss);
        if (mRS.find()) {
            String aaa = mRS.group();
            String numberOnly = aaa.replaceAll("[^0-9]", "");
            Log.e("mRSmRSmRS TO", "Account No" + numberOnly);
        }

        if (m.find()) {
            try {
                Log.e("amount_value= ", "" + m.group(0));
                String amount = (m.group(0).replaceAll("inr", ""));
                amount = amount.replaceAll("rs", "");
                amount = amount.replaceAll("Rs.", "");
                amount = amount.replaceAll("inr", "");
                amount = amount.replaceAll("INR", "");
                amount = amount.replaceAll(" ", "");
                amount = amount.replaceAll(",", "");
                FinalAccountNumber = amount;
                Log.e("SMSBODY TO", "Account No" + FinalAccountNumber);
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("No_matchedValue ", e.getMessage());
            }

        } else {
            FinalAccountNumber = "";
            Log.e("No_matchedValue ", "No_matchedValue TotalAmount");
        }

        if (FinalAccountNumber.contains(".")) {
            String Replacedot = FinalAccountNumber.replace(".", " ");
            String[] separated = Replacedot.split(" ");
            if (!TextUtils.isEmpty(Replacedot)) {
                if (separated.length > 0) {
                    FinalAccountNumber = separated[0];
                }
            }
            if (FinalAccountNumber.equals(".")) {
                FinalAccountNumber = "";
            }
        }


        return FinalAccountNumber;
    }


    public static String SMSBodyToGetTotalAmountCash(String ss) {
        String FinalAccountNumber = "";
        Pattern regEx = Pattern.compile("[rR][sS]\\.?\\s[,\\d]+\\.?\\d{0,2}|[iI][nN][rR]\\.?\\s*[,\\d]+\\.?\\d{0,2}");
        Matcher m = regEx.matcher(ss);

        Pattern regExRS = Pattern.compile("[Rs][.]\\w+");
        Matcher mRS = regExRS.matcher(ss);
        if (m.find()) {
            try {
                Log.e("amount_value= ", "" + m.group(0));
                String amount = (m.group(0).replaceAll("inr", ""));
                amount = amount.replaceAll("rs", "");
                amount = amount.replaceAll("Rs.", "");
                amount = amount.replaceAll("inr", "");
                amount = amount.replaceAll("INR", "");
                amount = amount.replaceAll(" ", "");
                amount = amount.replaceAll(",", "");
                FinalAccountNumber = amount;
                Log.e("SMSBODY TO", "Account No" + FinalAccountNumber);
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("No_matchedValue ", e.getMessage());
            }
        } else if (mRS.find()) {
            String amount = mRS.group();
            amount = amount.replaceAll("rs", "");
            amount = amount.replaceAll("s\\.", "");
            amount = amount.replaceAll("Rs\\.", "");
            amount = amount.replaceAll("inr", "");
            amount = amount.replaceAll("INR", "");
            amount = amount.replaceAll(" ", "");
            amount = amount.replaceAll(",", "");
            FinalAccountNumber = amount;
        } else {
            FinalAccountNumber = "";
            Log.e("No_matchedValue ", "No_matchedValue TotalAmount");
        }

        if (FinalAccountNumber.contains(".")) {
            String Replacedot = FinalAccountNumber.replace(".", " ");
            String[] separated = Replacedot.split(" ");
            if (!TextUtils.isEmpty(Replacedot)) {
                if (separated.length > 0) {
                    FinalAccountNumber = separated[0];
                }
            }
            if (FinalAccountNumber.equals(".")) {
                FinalAccountNumber = "";
            }
        }
        return FinalAccountNumber;
    }

    public static String SMSBodyToAvilableBalance(String ss) {
        String FinalAccountNumber = "";
        String[] separated = ss.split("Available Clear Bal is Rs || Available Balance is INR");
        if (separated.length > 1) {
            Log.e("separatedseparated ", separated[1] + "\n");
        } else {
            Log.e("separatedseparated", " Nuu");
        }
        // ss = "Dear Customer, your Acct XX983 is credited with salary of INR 21,000.00 on 07-Apr-20. Info: NEFT-N098200390. The Available Balance is INR 2,23,017.00";
        //Pattern regEx = Pattern.compile("[Ii][Nn][Rr](\\\\s*.\\\\s*\\\\d*)\n[rR][sS](\\\\s*.\\\\s*\\\\d*)");
        Matcher m = Pattern.compile("([0-9]{4,6})").matcher(ss);
        if (m.find()) {
            try {
                Log.e("mmmmmmmm", m.group(1));
                Log.e("amount_value= ", "" + m.group(0));
                String amount = (m.group(0).replaceAll("inr", ""));
                amount = amount.replaceAll("rs", "");
                amount = amount.replaceAll("inr", "");
                amount = amount.replaceAll(" ", "");
                amount = amount.replaceAll(",", "");
                FinalAccountNumber = amount.replaceAll("Rs.", "");
                Log.e("SMSBODY TO", "Account No" + FinalAccountNumber);
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("No_matchedValue ", e.getMessage());
            }
        } else {
            FinalAccountNumber = "";
            Log.e("No_matchedValue ", "No_matchedValue ");
        }
        return FinalAccountNumber;
    }

    public static String SMSBodyToGetCreditDabit(String ss) {
        Pattern regEx = Pattern.compile("(?=.*[Aa]ccount.*|.*[Aa]/[Cc].*|.*[Aa][Cc][Cc][Tt].*|.*[Cc][Aa][Rr][Dd].*)(?=.*[Cc]redit.*|.*[Dd]ebit.*)(?=.*[Ii][Nn][Rr].*|.*[Rr][Ss].*)");
        Matcher m = regEx.matcher(ss);
        String Type = "NoTransaction";
        if (m.find()) {
            if (ss.contains("debited") ||
                    ss.contains("purchasing") || ss.contains("purchase") || ss.contains("dr")) {
                Type = "0";
            } else if (ss.contains("credited") || ss.contains("cr") || ss.contains("Credit")) {
                Type = "1";
            }
/*
            else if (ss.contains("credited") || ss.contains("cr")) {
                Type = "1";
            }*/
            Log.e("matchedValueCreditDab", "" + Type);
            if (!Character.isDigit(ss.charAt(0))) {
                Log.e("isDEEEE", "Yesss");
            } else {
                Type = "NoTransaction";
            }
        }
        return Type;
    }

    public static String SMSMerchantName(String ss) {
        String FinalAccountNumber = "NOO";
        //Pattern regEx = Pattern.compile("(?i)(?:\\sat\\s|in\\*)([A-Za-z0-9]*\\s?-?\\s?[A-Za-z0-9]*\\s?-?\\.?)");
        Pattern regEx = Pattern.compile("[and].*");
        Matcher m = regEx.matcher(ss);
        if (m.find()) {
            try {
                FinalAccountNumber = m.group().trim();
                Log.e("SMSBODY TO", "Account No" + m.group(0));
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("No_matchedValue ", e.getMessage());
            }
        } else {
            FinalAccountNumber = "NOO";
            Log.e("No_matchedValue ", "No_matchedValue ");
        }
        return FinalAccountNumber;
    }

    public static String SMSBodyToGetCreditDabitCash(String ss) {
        Pattern regEx = Pattern.compile("(?=.*[Aa]ccount.*|.*[Aa]/[Cc].*|.*[Aa][Cc][Cc][Tt].*|.*[Cc][Aa][Rr][Dd].*)(?=.*[Cc]redit.*|.*[Dd]ebit.*)(?=.*[Ii][Nn][Rr].*|.*[Rr][Ss].*)");
        Matcher m = regEx.matcher(ss);
        String Type = "NoTransaction";
        if (m.find()) {
            if (ss.contains("debited") ||
                    ss.contains("purchasing") || ss.contains("purchase") || ss.contains("dr")) {
                Type = "0";
            } else if (ss.contains("credited") || ss.contains("cr")) {
                Type = "NoTransaction";
            }

            Log.e("matchedValueCreditDab", "" + Type);
            if (!Character.isDigit(ss.charAt(0))) {
                Log.e("isDEEEE", "Yesss");
            } else {
                Type = "NoTransaction";
            }
        }
        return Type;
    }

    public static String CheckIsTransactionSmsOrNot(String Body) {

        Pattern regEx
                = Pattern.compile("(?=.*[Aa]ccount.*|.*[Aa]/[Cc].*|.*[Aa][Cc][Cc][Tt].*|.*[Cc][Aa][Rr][Dd].*)(?=.*[Cc]redit.*|.*[Dd]ebit.*)(?=.*[Ii][Nn][Rr].*|.*[Rr][Ss].*)");
        // Find instance of pattern matches
        Matcher m = regEx.matcher(Body);
        if (m.find()) {
            Body = "Yes";
        } else {
            Body = "";
        }

        return Body;
    }


}
