package com.video.aimagic.onboardingflow.core

import android.view.View
import android.widget.ImageView
import com.video.aimagic.R

fun applyParallaxEffect(page: View, position: Float) {
    val parallaxView = page.findViewById<ImageView?>(R.id.img) ?: return

    when {
        position <= 1 -> parallaxView.translationX = -position * (page.width / 2)
    }
}