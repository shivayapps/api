package com.video.aimagic.faceswap.model;


public class FaceSwapUrl implements java.io.Serializable {
    private String tag;
    private String userType;
    private String content;
    private String watchAd;
    private String url;



    public FaceSwapUrl(String tag, String userType, String content, String watchAd, String url) {
        this.tag = tag;
        this.userType = userType;
        this.content = content;
        this.watchAd = watchAd;
        this.url = url;
    }

    // Getters and setters
    public String getTag() { return tag; }
    public void setTag(String tag) { this.tag = tag; }

    public String getUserType() { return userType; }
    public void setUserType(String userType) { this.userType = userType; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getWatchAd() { return watchAd; }
    public void setWatchAd(String watchAd) { this.watchAd = watchAd; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
}
