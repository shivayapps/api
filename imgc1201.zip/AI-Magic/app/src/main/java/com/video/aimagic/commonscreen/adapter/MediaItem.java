package com.video.aimagic.commonscreen.adapter;

import android.net.Uri;

public class MediaItem {
    public static final int TYPE_IMAGE = 1;
    public static final int TYPE_VIDEO = 2;

    public String name;
    public Uri uri;
    public int type;
    public long duration;     // video only
    public float aspectRatio; // width / height

    public MediaItem(String name, Uri uri, int type, long duration) {
        this.name = name;
        this.uri = uri;
        this.type = type;
        this.duration = duration;
    }
}


//public class MediaItem {
//
//    public static final int TYPE_IMAGE = 1;
//    public static final int TYPE_VIDEO = 2;
//
//    public String name;
//    public Uri uri;
//    public int type;
//    public long duration; // video only
//    public float aspectRatio = -1f; // width / height
//
//    public MediaItem(String name, Uri uri, int type, long duration) {
//        this.name = name;
//        this.uri = uri;
//        this.type = type;
//        this.duration = duration;
//    }
//}
//
