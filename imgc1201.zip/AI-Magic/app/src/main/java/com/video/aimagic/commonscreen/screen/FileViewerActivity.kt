package com.video.aimagic.commonscreen.screen

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.video.aimagic.App
import com.video.aimagic.R
import com.video.aimagic.commonscreen.adapter.MediaItem
import com.video.aimagic.databinding.ActivityFileViewerBinding
import com.video.aimagic.singletone.ConfirmDialog

class FileViewerActivity : AppCompatActivity() {

    private var fileList: ArrayList<MediaItem> = ArrayList()
    lateinit var binding: ActivityFileViewerBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityFileViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        fileList.addAll(App.displayListItem)
        val startPosition = intent.getIntExtra("POSITION", 0)

        Log.e("MMMMGGGG", "startPosition:${startPosition}")
        Log.e("MMMMGGGG", "fileList:${fileList.size}")
        val adapter = FileViewPagerAdapter(this, fileList)
        binding.viewPager.adapter = adapter
        binding.viewPager.setCurrentItem(startPosition, false)

        binding.onBackButton.setOnClickListener {
            finish()
        }
        binding.llShare.setOnClickListener {
            getCurrentItem()?.let { shareFile(it) }
        }
        binding.llDelete.setOnClickListener {
            getCurrentItem()?.let { confirmDelete(it) }
        }
    }
    private fun getCurrentItem(): MediaItem? {
        val position = binding.viewPager.currentItem
        return if (position in fileList.indices) fileList[position] else null
    }

    private fun shareFile(item: MediaItem) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = if (item.type== MediaItem.TYPE_VIDEO) "video/*" else "image/*"
            putExtra(Intent.EXTRA_STREAM, item.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(shareIntent, "Share via"))
    }

    private fun confirmDelete(item: MediaItem) {
        ConfirmDialog(this@FileViewerActivity, 1) { isSave: Boolean ->
            if (isSave) {
                deleteFile(item)
            } else {
                finish()
            }
        }.show()

    }


    private fun deleteFile(item: MediaItem) {
        try {
            val rows = contentResolver.delete(item.uri, null, null)

            if (rows > 0) {
                val pos = binding.viewPager.currentItem
                fileList.removeAt(pos)
                binding.viewPager.adapter?.notifyItemRemoved(pos)

                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()

                if (fileList.isEmpty()) finish()
            }
        } catch (e: SecurityException) {
            Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    class FileViewPagerAdapter(
        private val activity: Activity,
        private val files: List<MediaItem>
    ) : RecyclerView.Adapter<FileViewPagerAdapter.FileViewHolder>() {

        override fun getItemCount() = files.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.items_viewpager, parent, false)
            return FileViewHolder(view)
        }

        override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
            val item = files[position]

            holder.imageView.visibility = View.GONE
            holder.videoView.visibility = View.GONE

            if (item.type == MediaItem.TYPE_VIDEO) {
                // VIDEO
                holder.videoView.visibility = View.VISIBLE
                holder.videoView.setVideoURI(item.uri)
//                holder.videoView.setOnPreparedListener { mp ->
//                    mp.isLooping = true
//                    holder.videoView.start()
//                }
                holder.videoView.setOnPreparedListener { mp ->
                    mp.isLooping = true

                    val videoWidth = mp.videoWidth
                    val videoHeight = mp.videoHeight

                    val viewWidth = holder.videoView.width
                    val viewHeight = holder.videoView.height

                    val videoRatio = videoWidth.toFloat() / videoHeight
                    val viewRatio = viewWidth.toFloat() / viewHeight

                    val layoutParams = holder.videoView.layoutParams

                    if (videoRatio > viewRatio) {
                        // Video is wider → fit width
                        layoutParams.width = viewWidth
                        layoutParams.height = (viewWidth / videoRatio).toInt()
                    } else {
                        // Video is taller → fit height
                        layoutParams.height = viewHeight
                        layoutParams.width = (viewHeight * videoRatio).toInt()
                    }

                    holder.videoView.layoutParams = layoutParams
                    holder.videoView.start()
                }

            } else {
                // IMAGE
                holder.imageView.visibility = View.VISIBLE
                Glide.with(holder.itemView)
                    .load(item.uri)
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .into(holder.imageView)
            }
        }

        override fun onViewRecycled(holder: FileViewHolder) {
            super.onViewRecycled(holder)
            holder.videoView.stopPlayback()
        }

        class FileViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val imageView: ImageView = view.findViewById(R.id.imageView)
            val videoView: VideoView = view.findViewById(R.id.videoView)
        }
    }


}