package com.video.aimagic.aivideos.api;


import com.video.aimagic.utils.appconfig.AppConfig;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.logging.HttpLoggingInterceptor;

public class MediaConversionHandler {
    private static MediaConversionHandler sharedInstance;
    private final OkHttpClient httpClient;

    private MediaConversionHandler() {

        HttpLoggingInterceptor logInterceptor = new HttpLoggingInterceptor();
        logInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        this.httpClient = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .addInterceptor(logInterceptor)
                .build();
    }

    public static synchronized MediaConversionHandler getSharedInstance() {
        if (sharedInstance == null) {
            sharedInstance = new MediaConversionHandler();
        }
        return sharedInstance;
    }

    // Helper method to create default parameters
    public static Map<String, String> generateDefaultParams(
            @Nullable String animationEffect,
            @Nullable String accountType) {

        Map<String, String> parameters = new HashMap<>();

        // Required parameters with defaults
        parameters.put("app_name", AppConfig.DEFAULT_APP_NAME);

        if (animationEffect != null) {
            parameters.put("effect_name", animationEffect);
        }

        parameters.put("apk_version", "V91");
        parameters.put("platform", "android");

        if (accountType != null) {
            parameters.put("user_type", accountType);
        }

        return parameters;
    }

    // Helper method to create default headers
    public static Map<String, String> generateDefaultHeaders(
            @Nullable String appVerificationToken,
            @Nullable String notificationToken) {

        Map<String, String> headerMap = new HashMap<>();

        // Required headers
        headerMap.put("accept", "application/json");
        headerMap.put("Content-Type", "multipart/form-data");

        // Optional headers
        if (appVerificationToken != null) {
            headerMap.put("x-firebase-appcheck", appVerificationToken);
        }

        if (notificationToken != null) {
            headerMap.put("fcmtoken", notificationToken);
        }

        return headerMap;
    }

    public void transformImageToVideo(
            @NotNull File sourceImage,
            @NotNull Map<String, String> queryParams,
            @NotNull Map<String, String> requestHeaders,
            @NotNull Callback responseHandler) {

        // Validate required parameters
        if (sourceImage == null || !sourceImage.exists()) {
            throw new IllegalArgumentException("Source image file must exist");
        }

        if (queryParams == null || queryParams.isEmpty()) {
            throw new IllegalArgumentException("Query parameters cannot be null or empty");
        }

        if (requestHeaders == null || requestHeaders.isEmpty()) {
            throw new IllegalArgumentException("Request headers cannot be null or empty");
        }

        if (responseHandler == null) {
            throw new IllegalArgumentException("Response handler cannot be null");
        }

        RequestBody formBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("input_image", sourceImage.getName(),
                        RequestBody.create(sourceImage, MediaType.parse("image/png")))
                .build();


            HttpUrl.Builder urlConstructor = HttpUrl.parse("https://image-video.aapthi.in/Image2Video/").newBuilder();
            for (Map.Entry<String, String> param : queryParams.entrySet()) {
                if (param.getKey() != null && param.getValue() != null) {
                    urlConstructor.addQueryParameter(param.getKey(), param.getValue());
                }
            }

            // Build request with headers
            Request.Builder requestConstructor = new Request.Builder()
                    .url(urlConstructor.build())
                    .post(formBody)
                    .addHeader("accept", "application/json")
                    .addHeader("Content-Type", "multipart/form-data");

            for (Map.Entry<String, String> header : requestHeaders.entrySet()) {
                if (header.getKey() != null && header.getValue() != null) {
                    requestConstructor.addHeader(header.getKey(), header.getValue());
                }
            }

            // Execute the request asynchronously
            httpClient.newCall(requestConstructor.build()).enqueue(responseHandler);

    }
}