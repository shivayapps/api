package com.video.aimagic;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.adconfig.AdsConfig;
import com.adconfig.adsutil.admob.AdmobIntersAdImpl;
import com.video.aimagic.commonscreen.screen.HomeScreen;
import com.video.aimagic.databinding.ActivitySplashBinding;
import com.video.aimagic.onboardingflow.dataset.CustomOnBoardingPrefManager;
import com.video.aimagic.onboardingflow.screen.CustomOnBoardingActivity;
import com.video.aimagic.utils.appconfig.StartActivityGlobally;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class SplashScreen extends AppCompatActivity {


    private final String TAG = "OnLaunchScreen";
    private ActivitySplashBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
//        ExtensionsKt.applySystemBarInsets(binding.getRoot());

        setGradientColorToText();
        loadAds();
    }

    private void loadAds() {
        String interAdId = getString(R.string.inter_ad);
        new AdmobIntersAdImpl().load(this, interAdId, new Function1<Boolean, Unit>() {
            @Override
            public Unit invoke(Boolean isLoaded) {
                Log.d("TAG", "Interstitial loaded: " + isLoaded);
                showAdAndNavigate();
                return Unit.INSTANCE;
            }
        });
    }
    private void showAdAndNavigate() {
        AdsConfig.Companion.showInterstitialAd(this, new Function1<Boolean, Unit>() {
            @Override
            public Unit invoke(Boolean aBoolean) {
                navigateNext();
                return null;
            }
        });
    }

    private void navigateNext() {
        if (new CustomOnBoardingPrefManager(SplashScreen.this).getInitialAppLaunch()) {
            new CustomOnBoardingPrefManager(SplashScreen.this).setInitialAppLaunch(false);
            navigateUser(CustomOnBoardingActivity.class);
        } else {
            navigateUser(HomeScreen.class);
        }
    }


    @SuppressWarnings("unchecked")
    private void navigateUser(Class<? extends Activity> targetActivity) {
        StartActivityGlobally.navigateToActivityWithFeature(SplashScreen.this, targetActivity);
        finish();
    }

    private void setGradientColorToText() {
        Shader textShader = new LinearGradient(
                0, 0,
                binding.tvTitle.getPaint().measureText(binding.tvTitle.getText().toString()), // end x
                0,
                new int[]{
                        Color.parseColor("#FB5CD8"),
                        Color.parseColor("#EF60B3"),
                        Color.parseColor("#9F3CD2")
                },
                null,
                Shader.TileMode.CLAMP
        );
        binding.tvTitle.getPaint().setShader(textShader);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}