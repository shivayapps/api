package com.moving.photo.editor.callback

interface ProgressUpdateListener {
    fun onImageProgressFrameUpdate(f: Float)
}