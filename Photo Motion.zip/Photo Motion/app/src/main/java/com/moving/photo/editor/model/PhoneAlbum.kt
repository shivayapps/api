package com.moving.photo.editor.model

import com.moving.photo.editor.model.PhonePhoto
import java.util.*

class PhoneAlbum {
    var albumPhotos: Vector<PhonePhoto>? = null
        get() {
            if (field == null) {
                field = Vector()
            }
            return field
        }
    var coverUri: String? = null
    var id = 0
    var name: String? = null
}