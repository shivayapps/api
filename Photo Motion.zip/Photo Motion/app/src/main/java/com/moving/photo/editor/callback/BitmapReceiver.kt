package com.moving.photo.editor.callback

import android.graphics.Bitmap

interface BitmapReceiver {
    fun onBitmapReceived(list: List<Bitmap>)
}