package com.moving.photo.editor.callback

import com.moving.photo.editor.model.EffectData

interface ClickListener {
    fun onClick(effectData: EffectData?, i: Int)
}