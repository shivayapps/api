package com.moving.photo.editor.model

class StickerData(
    var stickerId: Int,
    var stickerName: String,
    var stickerFolderNameFPath: String,
    var isSelected: Boolean,
    var stickerThumb: Int
)