package com.photo.effect.motion.editor.customView;

import android.graphics.Bitmap;
import java.util.ArrayList;
import java.util.List;

public class ShareClass {
    public static List<Bitmap> foBitmapList = new ArrayList();
    public static boolean isViewRemoved = false;
}
