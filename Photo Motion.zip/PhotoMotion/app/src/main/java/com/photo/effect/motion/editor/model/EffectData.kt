package com.photo.effect.motion.editor.model

class EffectData(
    var effectId: Int,
    var effectName: String,
    var effectGIFPath: String,
    var isSelected: Boolean,
    var effectThumb: Int,
    var assetFolderName: String
)