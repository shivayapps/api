package com.photo.effect.motion.editor.model

class PhonePhoto {
    var albumName: String? = null
    var id = 0
    var photoUri: String? = null
}