package com.photo.effect.motion.editor.callback

interface TaskSaveListener {
    fun onError(str: String?)
    fun onSaved(filePath: String?)
    fun onSaving(i: Int)
    fun onStartSave(i: Int)
}