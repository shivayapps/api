package com.photo.effect.motion.editor.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.content.FileProvider;

import com.example.app.ads.helper.InterstitialAdHelper;
import com.example.app.ads.helper.NativeAdsSize;

import com.example.app.ads.helper.NativeAdvancedModelHelper;
import com.photo.effect.motion.editor.permission.PermissionManager;
import com.photo.effect.motion.editor.photoAlbum.MyAlbumActivity;
import com.photo.effect.motion.editor.BuildConfig;
import com.photo.effect.motion.editor.MyApp;
import com.photo.effect.motion.editor.R;
import com.photo.effect.motion.editor.utils.Share;

import org.apache.http.protocol.HTTP;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;


public class MainActivity extends BaseParentActivity implements OnClickListener {
    private static final String TAG = "MainAct";
    private static final int MY_PERMISSIONS_REQUEST_CAMERA_PIP_CAM = 103;
    private static final int MY_PERMISSIONS_REQUEST_CAMERA_PIP_CAM2 = 104;
    private static final int MY_PERMISSIONS_REQUEST_CAMERA_PIP_CAM3 = 105;
    public MainActivity moActivity;
    public String mSelectedOutputPath;
    public String mSelectedImagePath;
    public Uri mSelectedImageUri;
    ActivityResultLauncher<Intent> cameraResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    // There are no request codes
                    Intent data = result.getData();
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        mSelectedImagePath = mSelectedOutputPath;
                        if (stringIsNotEmpty(mSelectedImagePath)) {
                            File fileImageClick = new File(mSelectedImagePath);
                            if (fileImageClick.exists()) {
                                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
                                    mSelectedImageUri = Uri.fromFile(fileImageClick);
                                } else {
                                    mSelectedImageUri = FileProvider.getUriForFile(MainActivity.this, BuildConfig.APPLICATION_ID + ".provider", fileImageClick);
                                }
                                if (mSelectedImageUri == null) {
                                    Toast.makeText(MainActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                Share.SAVED_BITMAP = mSelectedImageUri;
                                Share.imageUrl = mSelectedImagePath;
                                startActivity(new Intent(MainActivity.this, CropActivity.class));
                            }
                        }
                    }

                }
            });
    private LinearLayout lin_camera;
    private LinearLayout lin_gallery;
    private LinearLayout lin_my_creation;
    private LinearLayout lin_share;
    private LinearLayout lin_rate_us;
    private LinearLayout lin_more_app;


//    public static boolean requestCameraPermissionApp(Activity activity) {
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//            if (ActivityCompat.checkSelfPermission(activity, CAMERA) != PackageManager.PERMISSION_GRANTED
//                    || ActivityCompat.checkSelfPermission(activity, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
//                ActivityCompat.requestPermissions(activity, new String[]{CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_CAMERA_PIP_CAM);
//                return false;
//            }
//
//        } else {
//            if (ActivityCompat.checkSelfPermission(activity, CAMERA) != PackageManager.PERMISSION_GRANTED
//                    || ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)
//                    != PackageManager.PERMISSION_GRANTED) {
//                ActivityCompat.requestPermissions(activity, new String[]{CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_CAMERA_PIP_CAM);
//                return false;
//            }
//        }
//
//        return true;
//    }

//    public static boolean requestCameraPermissionApp3(Activity activity) {
//
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//            if (ActivityCompat.checkSelfPermission(activity, CAMERA) != PackageManager.PERMISSION_GRANTED
//                    || ActivityCompat.checkSelfPermission(activity, Manifest.permission.READ_EXTERNAL_STORAGE)
//                    != PackageManager.PERMISSION_GRANTED) {
//                ActivityCompat.requestPermissions(activity, new String[]{CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_CAMERA_PIP_CAM3);
//                return false;
//            }
//
//        } else {
//            if (ActivityCompat.checkSelfPermission(activity, CAMERA) != PackageManager.PERMISSION_GRANTED
//                    || ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)
//                    != PackageManager.PERMISSION_GRANTED) {
//                ActivityCompat.requestPermissions(activity, new String[]{CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_CAMERA_PIP_CAM3);
//                return false;
//            }
//        }
//
//
//        return true;
//    }


//    public static boolean checkForCameraPermission(Activity activity) {
//
//        if (ActivityCompat.checkSelfPermission(activity, CAMERA)
//                != PackageManager.PERMISSION_GRANTED) {
//            return false;
//        }
//        return true;
//    }

//    public boolean requestCameraPermissionApp2(Activity activity) {
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//            if (ActivityCompat.checkSelfPermission(activity, CAMERA) != PackageManager.PERMISSION_GRANTED
//                    || ActivityCompat.checkSelfPermission(activity, Manifest.permission.READ_EXTERNAL_STORAGE)
//                    != PackageManager.PERMISSION_GRANTED) {
//                ActivityCompat.requestPermissions(activity, new String[]{CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_CAMERA_PIP_CAM2);
//                return false;
//            }
//
//        } else {
//            if (ActivityCompat.checkSelfPermission(activity, CAMERA) != PackageManager.PERMISSION_GRANTED
//                    || ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)
//                    != PackageManager.PERMISSION_GRANTED) {
//                ActivityCompat.requestPermissions(activity, new String[]{CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_CAMERA_PIP_CAM2);
//                return false;
//            }
//        }
//
//
//        return true;
//    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_home);
        this.moActivity = this;
        initViews();

        FrameLayout frame_native = findViewById(R.id.frame_native);
        new NativeAdvancedModelHelper(MainActivity.this).loadNativeAdvancedAd(NativeAdsSize.Big, frame_native, null, true, true, new Function1<Boolean, Unit>() {
            @Override
            public Unit invoke(Boolean aBoolean) {
                return null;
            }
        }, new Function0<Unit>() {
            @Override
            public Unit invoke() {
                return null;
            }
        });


        TextView tvPrivacyPolicy= findViewById(R.id.tvPrivacyPolicy);
        String str = "By clicking i'm agree with our privacy policy";

        SpannableString ss = new SpannableString(str);
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View view) {
//                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(getResources().getString(R.string.privacy_policy)));
//                startActivity(browserIntent);

                new CustomTabsIntent.Builder().build().launchUrl(MainActivity.this, Uri.parse(getString(R.string.privacy_policy)));

            }

            @Override
            public void updateDrawState(TextPaint textPaint) {
                super.updateDrawState(textPaint);
                textPaint.setUnderlineText(false);
            }
        };


        int start = str.indexOf("privacy");
        int end = str.length();
        ss.setSpan(clickableSpan, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tvPrivacyPolicy.setText(ss);
        tvPrivacyPolicy.setMovementMethod(LinkMovementMethod.getInstance());
        tvPrivacyPolicy.setHighlightColor(Color.TRANSPARENT);

        initViewListeners();
        if (MyApp.checkForStoragePermission(this)) {
            MyApp.deleteTemp();
        }
    }


    private void initViewListeners() {
        lin_gallery.setOnClickListener(this);
        lin_camera.setOnClickListener(this);
        lin_my_creation.setOnClickListener(this);
        lin_share.setOnClickListener(this);
        lin_rate_us.setOnClickListener(this);
        lin_more_app.setOnClickListener(this);
    }

    private void initViews() {
        lin_gallery = findViewById(R.id.lin_gallery);
        lin_camera = findViewById(R.id.lin_camera);
        lin_my_creation = findViewById(R.id.lin_my_creation);
        lin_share = findViewById(R.id.lin_share);
        lin_rate_us = findViewById(R.id.lin_rate_us);
        lin_more_app = findViewById(R.id.lin_more_app);
    }

    @SuppressLint("NonConstantResourceId")
    public void onClick(@NotNull View view) {
        switch (view.getId()) {
            case R.id.lin_camera:
//                if (requestCameraPermissionApp(MainActivity.this)) {
                    toOpenCamera();
//                }
                return;
            case R.id.lin_gallery:
//                if (requestCameraPermissionApp2(MainActivity.this)) {
                    toGallery();
//                }
                return;
            case R.id.lin_rate_us:
                final String appPackageName = getApplication().getPackageName();
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
                } catch (android.content.ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + appPackageName)));
                }
                return;

            case R.id.lin_my_creation:
//                if (requestCameraPermissionApp3(MainActivity.this)) {
                    requestMyCreation();
//                }
                return;
            case R.id.lin_more_app:
                Uri webpage = Uri.parse("https://play.google.com/store/apps/developer?id=shivayapps");
//                if (!url_netBank.startsWith("http://") && !url_netBank.startsWith("https://")) {
//                    webpage = Uri.parse("http://" + url_netBank);
//                }
                Intent i = new Intent(Intent.ACTION_VIEW, webpage);
//                            i.setData(webpage);
                if (i.resolveActivity(getPackageManager()) != null) {
                    startActivity(i);
                }

                return;
            case R.id.lin_share:
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType(HTTP.PLAIN_TEXT_TYPE);
                intent.putExtra("android.intent.extra.SUBJECT", getResources().getString(R.string.app_name));
                StringBuilder sb = new StringBuilder();
                sb.append("Download this amazing ");
                sb.append(getResources().getString(R.string.app_name));
                sb.append(" app from play store\n\n");
                String sb2 = sb.toString();
                StringBuilder sb3 = new StringBuilder();
                sb3.append(sb2);
                sb3.append("https://play.google.com/store/apps/details?id=");
                sb3.append(getPackageName());
                sb3.append("\n\n");
                intent.putExtra("android.intent.extra.TEXT", sb3.toString());
                startActivity(Intent.createChooser(intent, "Choose one"));
                return;
            default:
                return;
        }
    }

    private void toGallery() {
        PermissionManager.doPermissionTask(MainActivity.this, new PermissionManager.callBack() {
            @Override
            public void doNext() {
                MyApp.isDialogOpen=false;

                Intent intent = new Intent(moActivity, GalleryListActivity.class);
                if (MyApp.getApplication().needToShowAd()) {
                    InterstitialAdHelper.INSTANCE.isShowInterstitialAd(MainActivity.this, true, new Function1<Boolean, Unit>() {
                        @Override
                        public Unit invoke(Boolean aBoolean) {
                            startActivity(intent);
                            return null;
                        }
                    });

                } else {
                    startActivity(intent);
                }
            }

            @Override
            public void noPermission(boolean hasAndroidPermissions) {
                MyApp.isDialogOpen=false;
                Toast.makeText(MainActivity.this, R.string.storage_permission_not_granted, Toast.LENGTH_SHORT).show();
            }
        },new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE});


    }

    private void requestMyCreation() {
        PermissionManager.doPermissionTask(MainActivity.this, new PermissionManager.callBack() {
            @Override
            public void doNext() {
                MyApp.isDialogOpen=false;
                Intent intent = new Intent(moActivity, MyAlbumActivity.class);
                if (MyApp.getApplication().needToShowAd()) {
                    InterstitialAdHelper.INSTANCE.isShowInterstitialAd(MainActivity.this, true, new Function1<Boolean, Unit>() {
                        @Override
                        public Unit invoke(Boolean aBoolean) {
                            startActivity(intent);
                            return null;
                        }
                    });
                } else {
                    startActivity(intent);
                }
            }

            @Override
            public void noPermission(boolean hasAndroidPermissions) {
                MyApp.isDialogOpen=false;
                Toast.makeText(MainActivity.this, R.string.storage_permission_not_granted, Toast.LENGTH_SHORT).show();
            }
        },new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE});
    }

//    @Override
//    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
//
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        switch (requestCode) {
//            case MY_PERMISSIONS_REQUEST_CAMERA_PIP_CAM: {
//                if (!checkForCameraPermission(this)) {
//                    Toast.makeText(this, R.string.phone_camera_permission_not_granted, Toast.LENGTH_SHORT).show();
//                } else if (!ApplicationClass.checkForStoragePermission(this)) {
//                    Toast.makeText(this, R.string.storage_permission_not_granted, Toast.LENGTH_SHORT).show();
//                } else if (checkForCameraPermission(this) && ApplicationClass.checkForStoragePermission(this)) {
//                    toOpenCamera();
//                    return;
//                }
//                requestCameraPermissionApp(MainActivity.this);
//                return;
//            }
//
//            case MY_PERMISSIONS_REQUEST_CAMERA_PIP_CAM2: {
//                if (!ApplicationClass.checkForStoragePermission(this))
//                    Toast.makeText(this, R.string.storage_permission_not_granted, Toast.LENGTH_SHORT).show();
//                else {
//                    toGallery();
//                }
//                return;
//            }
//
//            case MY_PERMISSIONS_REQUEST_CAMERA_PIP_CAM3: {
//                if (!ApplicationClass.checkForStoragePermission(this))
//                    Toast.makeText(this, R.string.storage_permission_not_granted, Toast.LENGTH_SHORT).show();
//                else {
//                    requestMyCreation();
//                }
//                return;
//            }
//        }
//    }

    private void toOpenCamera() {
        PermissionManager.doPermissionTask(MainActivity.this, new PermissionManager.callBack() {
            @Override
            public void doNext() {

                MyApp.isDialogOpen=false;
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                Uri photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".provider", createImageFile());
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

//                Intent intent = new Intent(moActivity, GalleryListActivity.class);
                if (intent.resolveActivity(getApplicationContext().getPackageManager()) != null) {
                    cameraResultLauncher.launch(intent);
                }
//                if (MyApp.getApplication().needToShowAd()) {
//                    InterstitialAdHelper.INSTANCE.isShowInterstitialAd(MainActivity.this, true, new Function1<Boolean, Unit>() {
//                        @Override
//                        public Unit invoke(Boolean aBoolean) {
//
//                            return null;
//                        }
//                    });
//
//                } else {
//                    if (intent.resolveActivity(getApplicationContext().getPackageManager()) != null) {
//                        cameraResultLauncher.launch(intent);
//                    }
//                }

            }

            @Override
            public void noPermission(boolean hasAndroidPermissions) {
                MyApp.isDialogOpen=false;
                Toast.makeText(MainActivity.this, R.string.phone_camera_permission_not_granted, Toast.LENGTH_SHORT).show();

            }
        },new String[]{Manifest.permission.CAMERA,Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE});

    }

    private File createImageFile() {
        File storageDir = new File(Environment.getExternalStorageDirectory(), "Android/data/" + BuildConfig.APPLICATION_ID + "/CamPic/");
        storageDir.mkdirs();
        File image = null;
        try {
            image = new File(storageDir, getString(R.string.app_folder3));
            if (image.exists())
                image.delete();
            image.createNewFile();

            mSelectedOutputPath = image.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return image;
    }

    public boolean stringIsNotEmpty(String string) {
        if (string != null && !string.equals("null")) {
            if (!string.trim().equals("")) {
                return true;
            }
        }
        return false;
    }

}
